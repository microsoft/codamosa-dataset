

# Generated at 2022-06-22 03:28:13.994509
# Unit test for function is_future
def test_is_future():
    f: Any = Future()
    assert is_future(f)
    g = futures.Future()
    assert is_future(g)

# Generated at 2022-06-22 03:28:24.665243
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    def task(i):
        time.sleep(i)
        return i

    ioloop = IOLoop.current()
    tf = ioloop.run_in_executor(None, task, 1)
    sf = Future()
    chain_future(tf, sf)
    assert not sf.done()
    ioloop.run_sync(lambda: None)
    assert sf.done()
    assert sf.result() == 1

    tf = Future()
    sf = ioloop.run_in_executor(None, task, 1)
    chain_future(tf, sf)

    class DummyTask(object):
        called = False

        def run(self, tf):
            self.called = True
            assert tf is tf
            # Exercise

# Generated at 2022-06-22 03:28:28.587062
# Unit test for function is_future
def test_is_future():
    assert isinstance(Future(), Future)
    assert not isinstance(object(), Future)
    assert not isinstance(1, Future)
    if hasattr(futures.Future(), "add_done_callback"):
        assert isinstance(futures.Future(), Future)

# Generated at 2022-06-22 03:28:32.339895
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    dummy_executor.submit(lambda x:x+1, 1)
    dummy_executor.shutdown()
    dummy_executor.submit(lambda x:x*2, 2)
    dummy_executor.shutdown(False)


# Generated at 2022-06-22 03:28:39.108471
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() is None



# Generated at 2022-06-22 03:28:40.236102
# Unit test for function is_future
def test_is_future():
    future = Future()
    assert is_future(future)

# Generated at 2022-06-22 03:28:46.585866
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    result = []
    f = Future()
    future_add_done_callback(f, result.append)
    f.set_result("foo")
    f = Future()
    future_add_done_callback(f, result.append)
    f.set_result("bar")
    f = Future()
    future_add_done_callback(f, result.append)
    f.set_result("baz")
    assert result == ["foo", "bar", "baz"]



# Generated at 2022-06-22 03:28:58.652817
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 'res')
    assert future.done()
    assert future.result() == 'res'

    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 'res')
    future.cancel()
    assert future.done()
    # on Python 3.5, the result is None
    # on Python 3.7, the result is 'res'
    assert future.cancelled()



# Generated at 2022-06-22 03:29:01.125632
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b

    result = dummy_executor.submit(func, 5, 2).result()
    assert result == 7



# Generated at 2022-06-22 03:29:04.585467
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(fut):
        callback.result = fut.result()

    f = Future()
    future_add_done_callback(f, callback)
    f.set_result("foobar")
    assert "foobar" == callback.result

    f = Future()
    f.set_result("foobaz")
    callback.result = None
    future_add_done_callback(f, callback)
    assert "foobaz" == callback.result



# Generated at 2022-06-22 03:29:16.434416
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    future_set_exc_info(f, sys.exc_info())
    assert isinstance(f.exception(), TypeError)  # this is what sys.exc_info() returns
    f = Future()
    try:
        raise TypeError("foo")
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    assert isinstance(f.exception(), TypeError)



# Generated at 2022-06-22 03:29:18.287858
# Unit test for function is_future
def test_is_future():
    class Foo:
        pass

    foo = Foo()
    is_future(foo)
    is_future(Future())

# Generated at 2022-06-22 03:29:29.127578
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.platform.asyncio import AsyncIOMainLoop

    try:
        AsyncIOMainLoop().install()
    except IOError:
        # already installed, can't install more than once
        pass

    async def test():
        # noinspection PyUnreachableCode
        if False:
            yield

    fut = test()

    fut.cancel()

    # It is safe to set the exception on a cancelled Future
    future_set_exception_unless_cancelled(fut, ValueError())
    assert fut.exception() is not None

    # This should fail as the Future has been cancelled.
    with pytest.raises(Exception):
        fut.result()

# Generated at 2022-06-22 03:29:39.413967
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    def f():
        # type: () -> None
        raise ValueError()

    future = Future()
    try:
        f()
    except:
        future_set_exc_info(future, sys.exc_info())

    assert future.exception() is not None

    future = Future()
    future_set_exc_info(future, (None, None, None))
    assert future.exception() is None

    future = Future()
    future_set_exc_info(future, (None, ValueError(), None))
    assert isinstance(future.exception(), ValueError)



# Generated at 2022-06-22 03:29:43.679244
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop

    ioloop = tornado.ioloop.IOLoop()

    class MyTest(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            return 42

    instance = MyTest()
    e = instance.foo()
    assert is_future(e)
    ioloop.run_sync(lambda: e)
    assert e.result() == 42

# Generated at 2022-06-22 03:29:50.644696
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def bar(self, arg: int) -> int:
            return arg + 1

    f = Foo()
    future = f.bar(42)
    assert isinstance(future, (Future, futures.Future))
    assert future.result() == 43


# Unit tests for function chain_future

# Generated at 2022-06-22 03:29:57.926288
# Unit test for function chain_future
def test_chain_future():
    import unittest.mock as mock
    import functools

    inner = mock.Mock(spec=Future)
    outer = futures.Future()
    chain_future(inner, outer)
    assert not outer.done()

    inner.result.return_value = 'result'
    inner.set_result(None)
    assert outer.result() == 'result'
    inner.result.assert_called_with()

    exception = RuntimeError()
    inner = mock.Mock(spec=Future)
    outer = futures.Future()
    chain_future(inner, outer)
    assert not outer.done()
    inner.set_exception(exception)
    try:
        outer.result()
        assert False, 'outer should raise exception'
    except RuntimeError:
        pass
    # TODO: inner.exception

# Generated at 2022-06-22 03:30:00.692779
# Unit test for function is_future
def test_is_future():
    import concurrent.futures
    from tornado.concurrent import Future

    assert is_future(concurrent.futures.Future())
    assert is_future(Future())

# Generated at 2022-06-22 03:30:10.959042
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures

    executor = concurrent.futures.ThreadPoolExecutor(1)

    class MyFuture(object):
        def __init__(self, executor):
            self.executor = executor
        def done(self):
            return False
        def add_done_callback(self, callback):
            self.executor.submit(callback, self)

    class MyFuture2(MyFuture):
        def __init__(self, executor):
            super(MyFuture2, self).__init__(executor)
            self.callbacks = []
        def add_done_callback(self, callback):
            self.callbacks.append(callback)
        def trigger(self):
            for callback in self.callbacks:
                self.executor.submit(callback, self)


# Generated at 2022-06-22 03:30:17.915551
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()
    result = None

    def callback(fut):
        nonlocal result
        result = fut.result()
        io_loop.stop()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert not f2.done()
    f2.add_done_callback(callback)
    io_loop.start()
    assert result == 42



# Generated at 2022-06-22 03:30:30.815816
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.cancelled() == False
    assert future.result() == 5
    future.cancel()
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
test_future_set_result_unless_cancelled()

# Generated at 2022-06-22 03:30:35.080608
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    class NotAFuture(object):
        pass

    class DummyFuture(Future):
        pass

    assert is_future(Future())
    assert is_future(DummyFuture())
    assert not is_future(object())
    assert not is_future(NotAFuture())

# Generated at 2022-06-22 03:30:38.273027
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    f = executor.submit(lambda: 3)
    assert f.result() == 3


# Generated at 2022-06-22 03:30:39.560314
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    exc = ReturnValueIgnoredError()  # type: ignore

# Generated at 2022-06-22 03:30:45.185213
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    
    @run_on_executor
    def test_fn(future):
        try:
            raise Exception("test exception")
        except Exception:
            future_set_exc_info(future, sys.exc_info())
    
    test_fn(future)
    return future


# Generated at 2022-06-22 03:30:48.934862
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    futures = []
    futures.append(Future())
    futures.append(concurrent.futures.Future())
    for f in futures:
        future_set_result_unless_cancelled(f, "result")
        assert f.result() == "result"
        f.cancel()


# Generated at 2022-06-22 03:30:55.012897
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    def cb(fut):
        pass
    future_add_done_callback(f, cb)
    test_future_add_done_callback()
    # This is to check that the overloads are specified correctly.
    import mypy
    assert mypy.api.run(['-c', 'from tornado.concurrent import futures']) == 0
    assert mypy.api.run(['-c', 'from tornado.concurrent import future']) == 0
    assert mypy.api.run(['-c', 'from tornado.concurrent import return_future']) == 0
    assert mypy.api.run(['-c', 'from tornado.concurrent import run_on_executor']) == 0

# Generated at 2022-06-22 03:30:59.733380
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 100)
    assert future.result() == 100
    future_set_result_unless_cancelled(future, 100)
    assert future.result() == 100

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 100)
    assert future.cancelled()



# Generated at 2022-06-22 03:31:04.733852
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    def test():
        return "foo"

    assert dummy_executor.submit(test, "a", "b", kwarg_1=1, kwarg_2=2).result() == "foo"



# Generated at 2022-06-22 03:31:09.031978
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception("Testing future_set_exception_unless_cancelled")
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-22 03:33:11.221698
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(func, 1, 2)
    dummy_executor.submit(func, 1, 2, 3)
    dummy_executor.submit(func)


# Generated at 2022-06-22 03:33:12.829499
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # noqa: F811
    rvie = ReturnValueIgnoredError()
    assert rvie is not None

# Generated at 2022-06-22 03:33:14.370967
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError("foo")
    assert str(e) == "foo"

# Generated at 2022-06-22 03:33:17.485346
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    global dummy_executor
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda x: x ** 2, 15)
    assert future.result() == 225


# Generated at 2022-06-22 03:33:20.860063
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-22 03:33:24.632012
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError('hello'))
    assert f.exception() is None



# Generated at 2022-06-22 03:33:28.774686
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ZeroDivisionError)
    assert f.exception()
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ZeroDivisionError)
    assert f.cancelled()
    #future_set_exception_unless_cancelled(f, ZeroDivisionError)

if __name__ == '__main__':
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-22 03:33:39.243973
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.ioloop import IOLoop
    import traceback
    try:
        x = 1 / 0  # type: ignore
    except ZeroDivisionError:
        exc_info = sys.exc_info()

    def check_future_exc_info(future: Future[Any]) -> None:
        assert isinstance(future.exception(), ZeroDivisionError)
        assert future.exception().__traceback__ is exc_info[2]

    f1 = Future()
    f2 = Future()
    f3 = Future()
    future_set_exc_info(f1, exc_info)
    future_set_exc_info(f2, exc_info)
    future_set_exc_info(f3, exc_info)

# Generated at 2022-06-22 03:33:46.198737
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    asyncio_future = Future()  # type: Future
    conc_future = futures.Future()  # type: futures.Future
    chain_future(conc_future, asyncio_future)

    @tornado.gen.coroutine
    def test():
        result = yield asyncio_future
        assert result == 42

    conc_future.set_result(42)
    tornado.testing.gen_test(test)()

# Generated at 2022-06-22 03:33:58.608581
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import mock

    @mock.patch("tornado.concurrent.future_add_done_callback")
    def check(mock_future_add_done_callback, b_done):
        a = mock.MagicMock()
        b = mock.MagicMock()
        b.done.return_value = b_done

        chain_future(a, b)
        if b_done:
            mock_future_add_done_callback.assert_not_called()
        else:
            mock_future_add_done_callback.assert_called_once_with(a, mock.ANY)

    check(b_done=False)
    check(b_done=True)


if __name__ == "__main__":
    import unittest

    unittest.main()