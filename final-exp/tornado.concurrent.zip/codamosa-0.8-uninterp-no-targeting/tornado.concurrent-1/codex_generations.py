

# Generated at 2022-06-22 03:28:08.221898
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-22 03:28:09.762179
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    ex = DummyExecutor()
    ex.shutdown()
    return ex


# Generated at 2022-06-22 03:28:20.010444
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = dummy_executor
    def fn(a, b, c):
        return [a, b, c]
    future = executor.submit(fn, 1, 2, 3)
    assert future.result() == [1, 2, 3]
    def fn():
        raise ValueError(123)
    future = executor.submit(fn)
    e = future.exception()
    assert isinstance(e, ValueError)
    assert e.args == (123,)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 03:28:26.233559
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError()
    assert not e.args
    e = ReturnValueIgnoredError("foo")
    assert e.args == ("foo",)
    e = ReturnValueIgnoredError(message="foo")
    assert e.args == ("foo",)

# Generated at 2022-06-22 03:28:34.929905
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()  # type: Future[_T]
    try:
        raise ValueError("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
        assert future.done()
        assert not future.cancelled()
        assert future.exception() is not None
        assert isinstance(future.exception(), ValueError)
        assert str(future.exception()) == "Future exception was never retrieved"
    # Make sure we can set it a second time.
    try:
        raise ValueError("foo2")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
        assert future.done()
        assert not future.cancelled()
        assert future.exception() is not None
        assert isinstance(future.exception(), ValueError)

# Generated at 2022-06-22 03:28:44.049547
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    # This is called as part of the main tests. pylint: disable=undefined-variable
    assert "run_on_executor" in globals()

    class A(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self, arg, kwarg=None):
            # type: (int, Optional[int]) -> int
            return arg + (kwarg or 0)

    a = A()
    f = a.foo(10, kwarg=20)
    assert f.result() == 30



# Generated at 2022-06-22 03:28:53.106496
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class Obj(object):
        executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            # type: (int) -> int
            return arg + 1

    o = Obj()
    IOLoop.current().run_sync(functools.partial(o.func, 1))
    assert o.func(1) == 2



# Generated at 2022-06-22 03:29:01.303023
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.get_event_loop()
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, None)
    assert future.result() is None
    future_set_result_unless_cancelled(future, None)
    assert future.result() is None
    future_set_result_unless_cancelled(future, None)
    assert future.result() is None
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    with pytest.raises(asyncio.CancelledError):
        future.result()

# Generated at 2022-06-22 03:29:02.898243
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError as e:
        assert str(e) == ReturnValueIgnoredError.__doc__

# Generated at 2022-06-22 03:29:03.954046
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor().shutdown()

# Generated at 2022-06-22 03:29:15.181717
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    async def f():
        future = Future()  # type: Future
        future_set_exception_unless_cancelled(future, ZeroDivisionError)
        await future

    with pytest.raises(ZeroDivisionError):
        asyncio.run(f(), debug=True)

    async def f():
        future = Future()  # type: Future
        future.cancel()
        future_set_exception_unless_cancelled(future, ZeroDivisionError)

    asyncio.run(f())

# Generated at 2022-06-22 03:29:24.924441
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class Error(Exception):
        pass

    future = Future()
    future.set_result(1)
    # If the Future is already done, logs the exception instead
    future_set_exception_unless_cancelled(future, Error())

    future = Future()
    future.cancel()
    # If the Future is already cancelled, logs the exception instead
    future_set_exception_unless_cancelled(future, Error())

    future = Future()
    # If the Future is not done and not cancelled, this raises an exception
    # instead of logging it
    future_set_exception_unless_cancelled(future, Error())

# Generated at 2022-06-22 03:29:31.543786
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # Given
    executor = dummy_executor
    test_func = lambda: 2 + 2
    test_args = ()
    test_kwargs = {}
    expected_result = 4
    # When
    future = executor.submit(test_func, *test_args, **test_kwargs)
    actual_result = future.result()
    # Then
    assert expected_result == actual_result

# Generated at 2022-06-22 03:29:38.790422
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    conc = futures.Future()

    def callback(future):
        future.result()

    def err(future):
        future.exception()

    future_add_done_callback(future, callback)
    future_add_done_callback(future, err)
    future.set_result(None)

    future_add_done_callback(conc, callback)
    future_add_done_callback(conc, err)
    conc.set_result(None)

# Generated at 2022-06-22 03:29:45.235702
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    # test submit
    f = executor.submit(lambda x, y: x/y, 10, 2)
    assert f.result() == 5
    f = executor.submit(lambda: x/y, 10, 0)
    assert "division by zero" in f.exception().__str__()
    # test shutdown
    executor.shutdown()

# Generated at 2022-06-22 03:29:57.996080
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop
    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()
    from tornado.platform.asyncio import to_asyncio_future
    from concurrent.futures import Future as CFuture

    ioloop = tornado.ioloop.IOLoop()
    obj = object()

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def bar(self):
            return 7

        @run_on_executor
        def bar_exc(self):
            raise Exception(42)

        @run_on_executor
        def bar_exc_str(self):
            raise "doom"


# Generated at 2022-06-22 03:30:04.645396
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    # Set the result of future if it's not cancelled
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5

    # Don't set the result if future is already cancelled
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 5)
    assert future.cancelled()



# Generated at 2022-06-22 03:30:13.022634
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado import gen, testing

    def func(a, b):
        return a + b

    @gen.coroutine
    def test_func():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        ioloop = IOLoop.instance()
        ioloop.add_future(f1, lambda f: f2.set_result(f.result() + 1))
        f1.set_result(1)
        raise gen.Return(f2)

    @gen.coroutine
    def test_func2():
        # Test that chain_future does not trigger a callback before its
        # target future is done.
        f1 = Future()
        f2 = Future()

# Generated at 2022-06-22 03:30:22.968317
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import unittest.mock

    # TODO: This is not the most efficient way to verify
    # that the callback was called, but it has the benefit
    # of exercising the exception-handling code paths
    # of the future_add_done_callback function.
    # Also note that this test does not attempt to test
    # the behavior of the callback itself, just the utility
    # function.
    for FutureType in (futures.Future, Future):
        m = unittest.mock.Mock()
        future = FutureType()
        future_add_done_callback(future, m)
        future.set_result("foo")
        m.assert_called_once_with(future)

        # As above, but with a future that is already
        # done (test the "else" block)
        m = unitt

# Generated at 2022-06-22 03:30:28.484261
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    try:
        dummy_executor.shutdown()
    except NotImplementedError:
        print("Unit test for method 'shutdown' of class 'DummyExecutor' does not pass.")
        return
    print("Unit test for method 'shutdown' of class 'DummyExecutor' pass.")

# Generated at 2022-06-22 03:30:43.942564
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Issue #1593
    import time
    import unittest

    class FutureSetResultUnlessCancelled(unittest.TestCase):
        def test_future_set_result_unless_cancelled(self):
            # This test is messy due to the hybrid of asyncio.Future and
            # concurrent.futures.Future
            f = Future()

            # This thread will try to cancel `f` and set it to done in the
            # same step.  The order of these operations doesn't matter.
            def try_to_cancel_and_set_result_f():
                # Cancel `f`
                f.cancel()
                # time.sleep() is a hacky way to ensure that `f` is really
                # cancelled before we set it to done.
                time.sleep(0.1)
                future_set

# Generated at 2022-06-22 03:30:45.716286
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError('error')
# attributes: ['args', 'with_traceback']

# Generated at 2022-06-22 03:30:50.882209
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.concurrent import Future, run_on_executor

    class Foo(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def func(self, arg):
            return arg + 1

    foo_obj = Foo(dummy_executor)
    future = foo_obj.func(1)
    assert isinstance(future, Future)
    assert future.result() == 2

# Generated at 2022-06-22 03:30:53.436107
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-22 03:30:55.605920
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = DummyExecutor().submit(lambda x: x, 42)
    future.result() == 42

# Generated at 2022-06-22 03:31:04.601173
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # Test that a Future added by future_add_done_callback will be returned
    # by future.done() even if the Future has already been added by
    # Future.add_done_callback
    async_future = Future()
    conc_future = futures.Future()
    chain_future(conc_future, async_future)
    future_add_done_callback(async_future, lambda f: None)
    conc_future.set_result(None)
    assert async_future.done()



# Generated at 2022-06-22 03:31:11.010618
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    f2 = Future()
    f2._state = f2._FINISHED

    # callback is invoked immediately when future is already done
    callback = mock.Mock()
    future_add_done_callback(f2, callback)
    callback.assert_called_once_with(f2)

    # callback is called later when future is not done
    callback.reset_mock()
    future_add_done_callback(future, callback)
    # callback is not called yet
    assert not callback.called
    future.set_result(1)
    callback.assert_called_once_with(future)

# Generated at 2022-06-22 03:31:22.887779
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class E(Exception):
        pass
    f = Future()
    future_set_exception_unless_cancelled(f, E())
    assert f.exception() is not None
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, E())
    assert f.exception() is None

if typing.TYPE_CHECKING:
    # Additional type stubs for IDEs
    from typing import Sequence  # noqa: F401

    def multi_future(
        fs: Union["Future[_T]", Sequence["Future[_T]"]], io_loop: Any = None
    ) -> "Future[Union[_T, Sequence[_T]]]":
        ...  # pragma: no cover


# Generated at 2022-06-22 03:31:34.600699
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import typing
    from typing import cast, Callable, TypeVar, Tuple, Any
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test

    T = TypeVar("T")

    class MyFuture(Future[T]):
        def __init__(self, value: T) -> None:
            super(MyFuture, self).__init__()
            self.set_result(value)

    class MyAsyncTestCase(AsyncTestCase):
        @gen_test
        def test_future_add_done_callback(self) -> None:
            result: Tuple[Any, ...] = ()
            future = MyFuture(123)

            def callback(f: Future[int]) -> None:
                nonlocal result
                if isinstance(f, Future):
                    result = (f.result(), 123)


# Generated at 2022-06-22 03:31:38.539822
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:31:43.337292
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit(lambda: None).result() == None


# Generated at 2022-06-22 03:31:47.960551
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = futures.Future()
    future_set_exception_unless_cancelled(f, RuntimeError())
    assert f.exception() is not None
    f = futures.Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError())
    assert f.exception() is None



# Generated at 2022-06-22 03:31:58.546685
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # result propagation
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    # exception propagation
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert isinstance(f2.exception(), ZeroDivisionError)
    # exception propagation to concurrent.futures.Future
    f1 = Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert isinstance(f2.exception(), ZeroDivisionError)
    # cancellation

# Generated at 2022-06-22 03:32:10.298364
# Unit test for function run_on_executor
def test_run_on_executor():
    """Make sure that this decorator wraps a method properly"""
    class SubA(object):
        @run_on_executor
        def runme(self):
            return "foo"

        @run_on_executor(executor='_thread_pool')
        def runme_with_executor(self):
            return "foo"

    class SubB(SubA):
        executor = dummy_executor
        _thread_pool = dummy_executor

    a = SubA()
    a.runme()
    # Just to check that the following line actually runs
    assert a.runme().result() == "foo"
    # Just to check that the following line actually runs
    assert SubB().runme().result() == "foo"
    # Just to check that the following line actually runs
    assert SubB().runme_with

# Generated at 2022-06-22 03:32:14.105194
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    future_1 = dummy_executor.submit(pow, 2, 10)
    assert future_1.result() == 1024
    future_2 = dummy_executor.submit(pow, 2, 11)
    assert future_2.result() == 2048

# Generated at 2022-06-22 03:32:20.909023
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f3 = Future()
    chain_future(f1, f3)
    assert f3.result() == 42

# Generated at 2022-06-22 03:32:21.986166
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    dummy_executor.shutdown()


# Generated at 2022-06-22 03:32:28.089158
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    f.set_exception(ZeroDivisionError())
    with f:
        pass
    f = Future()
    future_set_exc_info(f, sys.exc_info())
    with f:
        pass
    f = Future()
    future_set_exc_info(f, (ZeroDivisionError, ZeroDivisionError(), None))
    with f:
        pass

# Generated at 2022-06-22 03:32:37.792171
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    assert not f.done()
    errored = [0]

    def callback(future):
        assert future is f
        assert future.done()
        errored[0] = int(future.exception() is None)

    future_add_done_callback(f, callback)
    f.set_result(None)
    assert errored[0] == 1

    f = Future()
    future_add_done_callback(f, callback)
    errored[0] = 0
    f.set_exception(Exception())
    assert errored[0] == 0

    f = Future()
    assert not f.done()
    errored[0] = 0

    def replace_callback(future):
        assert future is f
        assert future.done()

# Generated at 2022-06-22 03:32:42.454592
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    print("-- unit test for method submit of class DummyExecutor --")
    helper = DummyExecutor()
    f = helper.submit(lambda x, y: x + y, 2, 3)
    print("result: " + str(f.result()))


# Generated at 2022-06-22 03:32:53.796026
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    global ReturnValueIgnoredError
    try:
        # Simulate Tornado 4.0 and earlier
        class ReturnValueIgnoredError(object):
            pass
    except:
        pass

    try:
        raise ReturnValueIgnoredError('ignored')
    except ReturnValueIgnoredError:
        pass
    try:
        raise ReturnValueIgnoredError('ignored').with_traceback(sys.exc_info()[2])
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:32:55.857939
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    '''Test method shutdown of class DummyExecutor'''
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:33:03.916293
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async def async_test():
        f = Future()
        future_set_result_unless_cancelled(f, None)
        assert f.done()
        assert f.result() is None
        f = Future()
        f.cancel()
        future_set_result_unless_cancelled(f, None)
        assert f.done()
        assert f.cancelled()

    asyncio.run(async_test())



# Generated at 2022-06-22 03:33:12.667557
# Unit test for function run_on_executor
def test_run_on_executor():
    class A(object):
        executor = dummy_executor

        @run_on_executor
        def fn(self, arg):
            return arg ** 2

        @run_on_executor(executor="_thread_pool")
        def fn2(self, arg):
            return arg ** 2

    a = A()

    @asyncio.coroutine
    def test_fn():
        result = yield a.fn(3)
        assert result == 9
        result = yield a.fn2(3)
        assert result == 9
        try:
            yield a.fn(dict())
        except TypeError:
            pass
        else:
            assert False
        try:
            yield a.fn2(dict())
        except TypeError:
            pass
        else:
            assert False

    asyncio.get_event

# Generated at 2022-06-22 03:33:21.402174
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42
    f = Future()
    future_set_result_unless_cancelled(f, None)
    assert f.result() is None
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, None)
    assert f.cancelled()

# Generated at 2022-06-22 03:33:28.006633
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    try:
        future.set_result(1)
        assert False, "set_result() should raise an exception"
    except Exception as e:
        assert (
            str(e) == "Cannot set result on a done future."
        ), "The exception raised contains unexpected message"
    future_set_result_unless_cancelled(future, 1)



# Generated at 2022-06-22 03:33:37.504939
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled(): # noqa: F811
    # type: () -> None
    future = Future()  # type: Future[int]
    exception = ValueError()
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is exception
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is exception
    future_set_result_unless_cancelled(future, None)
    assert future.result() is None
    future_set_exception_unless_cancelled(future, exception)
    assert future.result() is None

# Generated at 2022-06-22 03:33:39.713448
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda x, y: x + y, 3, 4)
    assert future.result() == 7



# Generated at 2022-06-22 03:33:41.367925
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()


# Generated at 2022-06-22 03:33:50.158138
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import time, functools
    f = Future()
    result = []
    future_add_done_callback(f, functools.partial(result.append, 'done'))
    f.set_result(None)
    assert result == ['done']  # check that callback was invoked synchronously

    f = Future()
    result = []

    def callback(future):
        result.append('done')
        time.sleep(1000)  # simulate slow callback
    future_add_done_callback(f, callback)
    f.set_result(None)
    assert result == ['done']  # check that callback was invoked synchronously

# Generated at 2022-06-22 03:33:56.729346
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = DummyExecutor()
    assert a.submit(lambda: 1)
    try:
        a.shutdown()
    except Exception:
        assert False


# Generated at 2022-06-22 03:33:57.944856
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: () -> None
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:34:00.614546
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    print(executor.submit(lambda : 1).done())

if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-22 03:34:11.456690
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class OldFuture(object):
        def __init__(self) -> None:
            self.result_or_exc = _NO_RESULT
            self.exc_info = None  # type: Optional[Tuple[type, BaseException, types.TracebackType]]

        def set_result(self, r: Any) -> None:
            self.result_or_exc = r

        def set_exception(self, e: BaseException) -> None:
            self.result_or_exc = e

        def set_exc_info(self, tb: Tuple[type, BaseException, types.TracebackType]) -> None:
            self.exc_info = tb

    future = OldFuture()

    def f(x: Any) -> None:
        if x:
            raise Exception("foo")


# Generated at 2022-06-22 03:34:13.657159
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    with f:
        future_set_exception_unless_cancelled(f, ValueError)


# Generated at 2022-06-22 03:34:16.752259
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


if typing.TYPE_CHECKING:
    from typing import GenericMeta  # noqa: F401
    from typing import TypeVar  # noqa: F401

    _Var = TypeVar("_Var")



# Generated at 2022-06-22 03:34:20.170868
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass
    else:
        assert False, "ReturnValueIgnoredError constructor failed"



# Generated at 2022-06-22 03:34:29.881854
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo:
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(1)
            self.io_loop = IOLoop.current()

        @run_on_executor
        def bar(self, baz: Any) -> Future:
            return baz * 3

        @run_on_executor()
        def baz(self, baz: Any) -> Future:
            return baz * 7

    foo = Foo()
    f = foo.bar(3)
    f.add_done_callback(lambda x: x.result())
    assert f.result() == 9
    f2 = foo.baz(3)
    f2.add_done_callback(lambda x: x.result())
    assert f2.result() == 21

# Generated at 2022-06-22 03:34:34.511074
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    class Obj:
        executor = dummy_executor

        @run_on_executor
        def task(x):
            return x * x

    obj = Obj()
    f = obj.task(3)
    assert f.result() == 9
    assert f.done()
    f = obj.task(4)
    assert f.result() == 16
    assert f.done()



# Generated at 2022-06-22 03:34:36.060900
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-22 03:34:44.993207
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class NotCancelled(Exception):
        pass
    class Cancelled(Exception):
        pass
    f = asyncio.Future()
    future_set_exception_unless_cancelled(f, NotCancelled)
    assert f.exception() == NotCancelled
    f = asyncio.Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Cancelled)

# Generated at 2022-06-22 03:34:46.252706
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda x: 2 * x, 2).result() == 4

# Generated at 2022-06-22 03:34:52.714532
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def _test_future_add_done_callback(future: "Future[_T]") -> None:
        future_result = [0]
        callback_result = [0]

        def callback(future) -> None:
            future_result[0] = future.result()
            callback_result[0] += 1

        future_add_done_callback(future, callback)
        assert callback_result[0] == 1
        assert future_result[0] == 1

    _test_future_add_done_callback(Future())
    _test_future_add_done_callback(asyncio.Future())



# Generated at 2022-06-22 03:34:56.326866
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass



# Generated at 2022-06-22 03:35:05.932191
# Unit test for function chain_future
def test_chain_future():
    result = []

    def get_callback(suffix: str) -> Callable[[Future], None]:
        def callback(future: Future) -> None:
            result.append("%s-done" % suffix)
            try:
                result.append("%s-result:%r" % (suffix, future.result()))
            except Exception:
                result.append("%s-error:%r" % (suffix, future.exception()))

        return callback

    source = Future()
    dest = Future()
    chain_future(source, dest)
    future_add_done_callback(dest, get_callback("dest"))
    future_add_done_callback(source, get_callback("source"))
    source.set_result("source-result")

# Generated at 2022-06-22 03:35:18.193608
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.test.util

    io_loop = tornado.platform.asyncio.AsyncIOMainLoop()
    executor = futures.ThreadPoolExecutor(1)
    io_loop.set_default_executor(executor)
    io_loop.make_current()

    class A(object):
        def __init__(self):
            # type: () -> None
            self.executor = executor

        @tornado.concurrent.run_on_executor
        def f(self, x):
            # type: (int) -> int
            return x ** 2


# Generated at 2022-06-22 03:35:27.492724
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    """Pass the result of one Future to another.
    """
    first_done = [False]
    second_done = [False]
    first_result = [None]

    def done():
        # type: () -> None
        first_done[0] = True

    def done2(future):
        # type: (Future) -> None
        second_done[0] = True
        first_result[0] = future.result()

    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f2.add_done_callback(done)
    f.add_done_callback(done2)
    f.set_result(123)
    assert first_done[0]
    assert second_done[0]

# Generated at 2022-06-22 03:35:39.574910
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def add_done_callback_test(f: Future, callback: Callable[..., None]) -> None:
        try:
            future_add_done_callback(f, callback)
        except:
            print("error")
            raise

    def raise_error(f: Future) -> None:
        raise RuntimeError("error")

    def callback(f: Future) -> None:
        # If the future is completed, the callback will be called immediately
        print("ok")

    f1 = Future()
    add_done_callback_test(f1, callback)
    # f1 is not done yet. The callback will be called when it's done.
    f1.set_result(True)  # Now the callback is called

    # If the callback itself raises an error, it should be suppressed
    f2 = Future()
    add_done

# Generated at 2022-06-22 03:35:46.273777
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert future.done() is False
    future_set_result_unless_cancelled(future, 42)
    assert future.done() is True
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.done() is True
    assert future.cancelled() is True



# Generated at 2022-06-22 03:35:48.085733
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-22 03:35:54.590198
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(x):
        return x+1
    result = dummy_executor.submit(test_func, 1)
    print(result.result())
    print(result.done())


# Generated at 2022-06-22 03:35:55.642877
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:36:08.501344
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.platform.asyncio import to_asyncio_future

    io_loop = IOLoop()

    async def async_foo(n: int) -> int:
        await asyncio.sleep(0.01)
        return n

    def regular_foo(n: int) -> int:
        io_loop.add_timeout(io_loop.time() + 0.01, lambda: None)
        io_loop.start()
        return n

    def finish(future: Future) -> None:
        io_loop.stop()
        assert future.result() == 42
        io_loop.close()

    # Test chaining a concurrent.futures.Future with an asyncio.Future
    f1 = dummy_executor.submit(regular_foo, 42)

# Generated at 2022-06-22 03:36:14.256353
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    fut = Future()
    fut.set_result(1)
    result = []
    future_add_done_callback(fut, result.append)
    assert result == [fut]
    fut = futures.Future()
    fut.set_result(1)
    result = []
    future_add_done_callback(fut, result.append)
    assert result == [fut]



# Generated at 2022-06-22 03:36:15.894571
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:36:25.922908
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b

    assert dummy_executor.submit(func, 1, 2).result() == 3
    assert dummy_executor.submit(func, 1, b=2).result() == 3

    def func2():
        return 1/0

    with pytest.raises(ZeroDivisionError):
        dummy_executor.submit(func2).result()

    class TestClass:
        def __init__(self):
            self.e = DummyExecutor()

        @run_on_executor
        def func(self, a, b):
            return a + b

    obj = TestClass()
    assert obj.e.submit(obj.func, 1, 2).result() == 3

# Generated at 2022-06-22 03:36:31.621897
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future1 = Future()
    future_set_result_unless_cancelled(future1, 0)
    assert future1.result() == 0
    future2 = Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2, 0)
    assert future2.cancelled()

# Generated at 2022-06-22 03:36:41.580809
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.httpserver
    from tornado.ioloop import IOLoop
    from tornado.web import Application, RequestHandler
    import datetime
    import time
    class MainHandler(RequestHandler):
        executor = dummy_executor
        def get(self):
            # Runs on the IOLoop, not the executor.
            print("Running on IOLoop")
            self.write("Hello, world")
            self.finish()
        
        @run_on_executor(executor='executor') # Runs on the executor.
        def background_task(self):
            time.sleep(0.2)
            print("Running on executor")
            return datetime.datetime.now().strftime("%A, %d. %B %Y %I:%M%p") 
        

# Generated at 2022-06-22 03:36:45.015077
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:36:54.737996
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()
            self.addCleanup(self.io_loop.close)

        @run_on_executor
        def sync_func(self, a, b):
            return a + b

        async def async_func(self, a, b):
            return await self.sync_func(a, b)

        def test_run_on_executor(self):
            f = self.sync_func(1, 2)
            self.io_loop.add_future(f, self.io_loop.stop)

# Generated at 2022-06-22 03:37:04.161475
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert not f.done()
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.done()
    assert f.result() == 42

# Generated at 2022-06-22 03:37:15.365746
# Unit test for function chain_future
def test_chain_future():
    future = Future()  # type: Future[int]
    chained = Future()  # type: Future[int]
    chain_future(future, chained)

    assert not chained.done()
    future.set_result(1)
    assert chained.result() == 1
    future.set_result(2)
    assert chained.result() == 1

    future = Future()  # type: Future[int]
    chained = Future()  # type: Future[int]
    chain_future(future, chained)
    assert not chained.done()
    future.set_exception(RuntimeError())
    assert not chained.done()
    try:
        chained.result()
        assert False
    except RuntimeError:
        pass
    future.set_exception(RuntimeError())

# Generated at 2022-06-22 03:37:17.184896
# Unit test for function is_future
def test_is_future():
    assert is_future(Future()) is True
    assert is_future(futures.Future()) is True
    assert is_future(object()) is False

# Generated at 2022-06-22 03:37:17.991921
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("Test")

# Generated at 2022-06-22 03:37:23.100211
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    executor = DummyExecutor()
    dummy_future = executor.submit(lambda : 0)
    assert dummy_future.done()
    assert dummy_future.result() == 0

# Generated at 2022-06-22 03:37:25.885462
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    fut = Future()
    fut.cancel()
    exc = Exception()
    future_set_exception_unless_cancelled(fut, exc)

# Generated at 2022-06-22 03:37:34.572826
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado import gen

    @gen.coroutine
    def test():
        loop = gen.coroutine.current_loop()
        f = Future()
        try:
            yield f
            raise gen.Return(False)
        except Exception:
            future_set_exc_info(f, sys.exc_info())
            raise
        finally:
            loop.add_callback(loop.stop)

    loop = asyncio.get_event_loop()
    loop.add_callback(test)
    loop.run_forever()

# Generated at 2022-06-22 03:37:40.386208
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), ZeroDivisionError)


if hasattr(Future, "add_done_callback"):
    # Use the native implementation in 3.4.2 and later
    future_add_done_callback = Future.add_done_callback.__func__  # type: ignore

# Generated at 2022-06-22 03:37:41.282201
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()
    return 0

# Generated at 2022-06-22 03:37:53.149019
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()  # type: Future
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10
    future_set_result_unless_cancelled(future, 20)
    assert future.result() == 10
    future = Future()  # type: Future
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10
    future.cancel()
    future_set_result_unless_cancelled(future, 20)
    assert future.cancelled()
    future = Future()  # type: Future
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10
    future.cancel()
    exc = Exception()
    future_set_exception_unless_c