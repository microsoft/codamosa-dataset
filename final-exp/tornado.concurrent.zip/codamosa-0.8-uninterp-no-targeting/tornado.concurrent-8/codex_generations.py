

# Generated at 2022-06-22 03:28:09.722593
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        def test_future_add_done_callback(self):
            future = Future()
            @gen_test
            def callback(future):
                self.assertTrue(future.done())
            future_add_done_callback(future, callback)
            future.set_result(None)

    TestCase().test_future_add_done_callback()



# Generated at 2022-06-22 03:28:19.186661
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    future.set_result(None)
    future2 = Future()
    future2.set_result(True)
    future_add_done_callback(future, lambda f: f.set_result(True))
    future_add_done_callback(future, lambda f: f.set_result(False))
    future_add_done_callback(future2, lambda f: f.set_result(False))
    assert future.result()
    assert future2.result()



# Generated at 2022-06-22 03:28:27.579740
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    if sys.version_info[:2] >= (3, 5):
        future = Future()
    else:
        import asyncio
        future = asyncio.Future()

    exc = RuntimeError()

    future_set_exc_info(future, (RuntimeError, exc, None))
    assert future.exception() == exc
    future_set_exc_info(future, (RuntimeError, None, None))
    assert future.exception() is not None
    assert isinstance(future.exception(), RuntimeError)

    # Future is not canceled, so new exception is set
    future_set_exc_info(future, (RuntimeError, exc, None))
    assert future.exception() == exc
    assert future.cancelled() is False

    future.cancel()
    # Future is canceled, so new exception is not set
   

# Generated at 2022-06-22 03:28:35.646323
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    expected = object()

    f = Future()
    g = Future()
    chain_future(f, g)

    f.set_result(expected)
    loop.run_sync(lambda: g)
    assert g.result() is expected

    # If the second future is already cancelled, the first one's
    # result should not be copied
    f = Future()
    g = Future()
    g.cancel()
    chain_future(f, g)
    f.set_result(object())
    if isinstance(f, Future):
        # asyncio.Future should raise an exception
        g.exception()

    # If the second future is cancelled after the first one completes,
    # its result should not be copied
    f = Future()

# Generated at 2022-06-22 03:28:41.023293
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyTest(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, x):
            return x + 1

    t = MyTest()
    assert is_future(t.func(41))
    assert t.func(41).result() == 42



# Generated at 2022-06-22 03:28:47.803800
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f1 = Future()
    f2 = Future()
    try:
        raise ZeroDivisionError()
    except ZeroDivisionError:
        f1.set_exc_info(sys.exc_info())
    f2.set_exc_info(sys.exc_info())
    assert f1.exception() is not None
    assert f2.exception() is not None
    assert f1.exception() is f2.exception()
    # Make sure fields of the traceback are set in Tornado's wrapper
    assert f1.exc_info()[2].tb_frame is sys.exc_info()[2].tb_frame

# Generated at 2022-06-22 03:28:51.591679
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado import gen
    from tornado.ioloop import IOLoop

    async def test_fn():
        future = Future()
        future_set_result_unless_cancelled(future, "foo")
        assert "foo" == await future

    future = test_fn()
    IOLoop.current().run_sync(future)

    future_2 = Future()
    future_2.cancel()
    future_set_result_unless_cancelled(future_2, "bar")
    assert future_2.cancelled() == True

# Generated at 2022-06-22 03:28:52.298203
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:28:55.115293
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    """
    it = DummyExecutor()
    fut = it.submit(lambda: 1 + 2)

    assert fut.result() == 3
    """
    pass


# Generated at 2022-06-22 03:28:59.582362
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import asyncio
    dumyExe = DummyExecutor()
    future = dumyExe.submit(power, 2, 3)
    io_loop = asyncio.get_event_loop()
    io_loop.run_until_complete(future)
    print(future.result())



# Generated at 2022-06-22 03:29:14.905953
# Unit test for function chain_future
def test_chain_future():
    """This function can be called from the command line to
    test that Futures chained together behave as expected.
    """
    import tornado.testing
    import tornado.ioloop

    def cb1(f):
        print("cb1")
        raise Exception("exc_from_cb1")

    def cb2(f):
        print("cb2")
        raise Exception("exc_from_cb2")

    def cb3(f):
        print("cb3")
        raise Exception("exc_from_cb3")

    f1 = Future()
    f2 = Future()
    f3 = Future()
    tornado.ioloop.IOLoop.current().add_future(f3, lambda tf3: tf3.result())
    chain_future(f1, f2)
    chain_future(f2, f3)


# Generated at 2022-06-22 03:29:18.881133
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    def f(self):
        return 42

    @run_on_executor
    def g(self):
        return 42

    def dummy_executor(f):
        future = Future()
        future_set_result_unless_cancelled(future, f())
        return future

    # This is an example error message that we hoped to catch in the future.
    error_message = r"""Cannot use @run_on_executor with asynchronous functions;
use the executor directly instead of decorating the asynchronous function.

Example:
    def f(self):
        yield gen.something()
    executor.submit(f, self)

This restriction may be relaxed in the future."""

    # This line will produce a warning in the future

# Generated at 2022-06-22 03:29:21.776246
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()


# Generated at 2022-06-22 03:29:34.345560
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # pragma: nocover
    import time
    import tornado.testing
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop

    # Set up an asyncio event loop
    asyncio.set_event_loop(asyncio.new_event_loop())

    # Set up a Tornado ioloop
    io_loop = tornado.ioloop.IOLoop()
    async_io_loop = AsyncIOMainLoop()
    async_io_loop.make_current()

    # Test the behavior of future_add_done_callback on a concurrent.futures.Future
    done = False
    def test_callback_concurrent():
        nonlocal done
        assert done is False
        done = True
    future = futures.Future()

# Generated at 2022-06-22 03:29:35.881772
# Unit test for function is_future
def test_is_future():
    assert not is_future((Future(),))
    assert is_future(Future())



# Generated at 2022-06-22 03:29:40.259120
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # ATTENTION: Please do not remove this function even if it is identified
    # as "unused". It is used in a unit test.
    # pylint: disable=unused-variable
    foo = DummyExecutor()

# Generated at 2022-06-22 03:29:47.632567
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    executor = concurrent.futures.ThreadPoolExecutor(1)
    io_loop = asyncio.new_event_loop()

    class MyTestCase(unittest.TestCase):
        executor = executor
        io_loop = io_loop

        @run_on_executor
        def return5(self):
            return 5

        def test_run_on_executor(self):
            # This should still work
            future = self.return5()
            self.assertEqual(future_await(future), 5)

        @run_on_executor
        def raise_error(self):
            raise Exception

        def test_run_on_executor_exception(self):
            # This should still work
            future = self.raise_error()

# Generated at 2022-06-22 03:29:48.744379
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:29:50.887473
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())
    assert not is_future(object())

# Generated at 2022-06-22 03:30:03.331439
# Unit test for function run_on_executor
def test_run_on_executor():
    def check_future_result(fut, expected_result):
        assert fut.result() == expected_result

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def bar(self, arg):
            return arg + 1

        @run_on_executor
        def baz(self):
            raise Exception('error in baz')

        @run_on_executor(executor="executor")
        def quux(self):
            pass

    f = Foo()
    fut = f.bar(10)
    fut.add_done_callback(functools.partial(check_future_result, expected_result=11))
    assert not fut.done()
    assert fut.result() == 11

    fut = f.baz()

# Generated at 2022-06-22 03:30:07.611033
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    with pytest.raises(TypeError):
        ReturnValueIgnoredError("hello", "world")

# Generated at 2022-06-22 03:30:08.491996
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    DummyExecutor().submit(lambda: 2)

# Generated at 2022-06-22 03:30:21.005441
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from unittest import mock

    io_loop = mock.Mock()

    class Thing(object):
        executor = dummy_executor
        io_loop = io_loop

        @run_on_executor
        def blocking_method(self):
            return 42

        @run_on_executor(executor="_thread_pool_executor")
        def other_blocking_method(self):
            return 24

    class ThingTest(unittest.TestCase):
        def test_blocking(self):
            thing = Thing()
            future = thing.blocking_method()
            self.assertEqual(future.result(), 42)
            thing._thread_pool_executor.submit.assert_not_called()
            self.assertFalse(io_loop.add_future.called)


# Generated at 2022-06-22 03:30:28.634961
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda x: x, 3)
    assert future.result() == 3
    future = dummy_executor.submit(lambda x, y: x * y, 3, 3)
    assert future.result() == 9
    future = dummy_executor.submit(lambda x, y: x / y, 3, 0)
    try:
        future.result()
    except ZeroDivisionError:
        pass

# Generated at 2022-06-22 03:30:30.602204
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    e = ReturnValueIgnoredError(1)
    assert isinstance(e, Exception)

# Generated at 2022-06-22 03:30:35.267472
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.concurrent import Future
    future = Future()
    l = []
    future_add_done_callback(future, lambda f: l.append(1))
    future_add_done_callback(future, lambda f: l.append(2))
    future.set_result(3)
    assert l == [1, 2]

# Generated at 2022-06-22 03:30:44.317627
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    exec = DummyExecutor()
    f = exec.submit(lambda: 2 + 2)
    assert f.result() == 4
    f = exec.submit(lambda: 2 / 0)
    try:
        f.result()
        raise Exception("should have failed")
    except ZeroDivisionError:
        pass
    f = exec.submit(lambda: "foo".foo)
    try:
        f.result()
        raise Exception("should have failed")
    except AttributeError:
        pass


# Generated at 2022-06-22 03:30:52.444463
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    AsyncTestCase.__test__ = False
    class HelperCase(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result("foo")
            result = yield g
            self.assertEquals("foo", result)

        @gen_test
        def test_chain_future_exception(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_exception(Exception("foo"))
            with self.assertRaises(Exception) as cm:
                yield g
            self.assertEquals("foo", str(cm.exception))


# Generated at 2022-06-22 03:30:55.102727
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()
    assert True, "shutdown() method of DummyExecutor works"


# Generated at 2022-06-22 03:31:07.996488
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    with mock.patch('tornado.concurrent.traceback_Future.Future') as m:
        future = m.return_value
        future_set_exc_info(future, sys.exc_info())
        future.set_exc_info.assert_called_with(sys.exc_info())
        future.set_exc_info.reset_mock()
        future_set_exc_info(future, None)
        assert not future.set_exc_info.called
        future_set_exc_info(future, (None,))
        assert not future.set_exc_info.called
    with mock.patch('tornado.concurrent.asyncio.Future') as m:
        future = m.return_value
        future_set_exc_info(future, sys.exc_info())
        assert not future.set_

# Generated at 2022-06-22 03:32:37.733018
# Unit test for function run_on_executor
def test_run_on_executor():
    import multiprocessing
    import threading
    import time

    pool = multiprocessing.Pool(2)

    class Foo(object):
        executor = pool

        @run_on_executor
        def bar(self, a, b, callback=None):
            return a + b

    f = Foo()

    # Check that the executor-based version works
    future = f.bar(1, 2, callback=None)
    assert future.result() == 3
    future = f.bar(1, 2, callback=None)
    assert future.result() == 3

    # Check that the blocking version works
    class Blocking(object):
        executor = pool

        @run_on_executor
        def blocking(self):
            time.sleep(0.1)
            return 42

    b = Blocking()

# Generated at 2022-06-22 03:32:45.515325
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import threading
    from tornado.log import app_log
    from tornado.testing import AsyncTestCase

    class TestHandler(AsyncTestCase):
        def setUp(self):
            super(TestHandler, self).setUp()
            self.logger = logging.getLogger("tornado.test.concurrent")
            self.handler = logging.StreamHandler()
            self.logger.addHandler(self.handler)

        def tearDown(self):
            super(TestHandler, self).tearDown()
            self.logger.removeHandler(self.handler)
            self.handler.close()

        def test_exception_logged(self):
            test_future = Future()
            test_future.cancel()
            exception_to_raise = Exception("Test Exception")

# Generated at 2022-06-22 03:32:47.534128
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-22 03:32:53.181850
# Unit test for function chain_future
def test_chain_future():
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

# Generated at 2022-06-22 03:32:54.157731
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())

# Generated at 2022-06-22 03:32:55.688370
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(futures.Future())
    assert not is_future(object())
    assert not is_future(None)

# Generated at 2022-06-22 03:32:59.681104
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func():
        return 1
    executor = DummyExecutor()
    future = executor.submit(func, 1, 2)
    assert future.result() == 1


# Generated at 2022-06-22 03:33:00.799087
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:33:03.858019
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    from tornado.platform.asyncio import DummyExecutor
    assert DummyExecutor().submit(lambda: None)

# Generated at 2022-06-22 03:33:04.922602
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-22 03:34:29.847571
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x * 2, 10)
    assert future.result() == 20

# Generated at 2022-06-22 03:34:37.132384
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    ##### Tests for method submit
    def func():
        # type: () -> str
        return 'return value'
    def func_args(a, b, *args, **kwargs):
        # type: (int, str, *int, **Any) -> str
        return 'return value'
    executor = dummy_executor
    future = executor.submit(func)
    assert future.result() == 'return value'
    future = executor.submit(func_args, 0, '1')
    assert future.result() == 'return value'
    future = executor.submit(func_args, 0, '1', 2, 3, 4, foo=0, bar='1')
    assert future.result() == 'return value'

# Generated at 2022-06-22 03:34:42.533737
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()



# Generated at 2022-06-22 03:34:44.107553
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-22 03:34:46.663660
# Unit test for function is_future
def test_is_future():
    assert is_future(concurrent.futures.Future())
    assert is_future(asyncio.Future())
    assert not is_future(object())
    assert not is_future(1)



# Generated at 2022-06-22 03:34:52.789009
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def long_running(self):
            return 42

    @gen_test
    def test():
        AsyncIOMainLoop().install()
        foo = Foo()
        for i in range(10):
            future = foo.long_running()
            assert future.result() == 42
            yield future

    test()

# Generated at 2022-06-22 03:34:55.946599
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())
    assert is_future(Future())

# Generated at 2022-06-22 03:34:58.031870
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future1 = Future()  # type: Future
    future1.cancel()
    future_set_result_unless_cancelled(future1, 42)
    return


# Generated at 2022-06-22 03:35:04.419855
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    the_list = []

    def callback(the_future):
        the_list.append(the_future)
    future_add_done_callback(future, callback)
    assert not the_list, "Callback should not have been invoked yet"
    future_set_result_unless_cancelled(future, None)
    assert future in the_list, "Callback should have been invoked exactly once"



# Generated at 2022-06-22 03:35:06.487322
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    assert isinstance(ReturnValueIgnoredError("foo"), Exception)

# Generated at 2022-06-22 03:36:29.569087
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():  # noqa: F811
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled()



# Generated at 2022-06-22 03:36:39.934657
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from concurrent.futures import Future as Concurrent_Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOLoop

    results = []
    _ioloop = IOLoop()
    _asyncio_loop = AsyncIOLoop()

    def callback(future):
        results.append(future)

    # tornado.concurrent.Future
    future1 = Future()
    future_add_done_callback(future1, callback)
    IOLoop.current().add_future(future1, lambda f: _ioloop.stop())
    future1.set_result(future1)

    # concurrent.futures.Future
    future2 = Concurrent_Future()
    future_add_done_callback(future2, callback)
    _asyncio_loop.add_

# Generated at 2022-06-22 03:36:45.632987
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    if not isinstance(a, Future):
        # concurrent.futures.Future
        a.set_result(42)
    assert b.result() == 42

    b = Future()
    a = Future()
    chain_future(a, b)
    if not isinstance(a, Future):
        # concurrent.futures.Future
        a.set_result(42)
    assert b.result() == 42



# Generated at 2022-06-22 03:36:55.086778
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    from unittest.mock import patch
    import concurrent.futures
    import tornado.httpclient
    import tornado.ioloop
    import tornado.stack_context

    io_loop = tornado.ioloop.IOLoop.current()

    def f():
        assert False, "should not be called"

    f2 = tornado.testing.gen_test(f)

    with patch.object(app_log, "error") as error:
        future_set_exc_info(
            concurrent.futures.Future(),
            (
                type(None),
                tornado.httpclient.HTTPError(599),
                type(None),
            ),
        )

# Generated at 2022-06-22 03:36:56.141994
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:36:58.495923
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)  # type: ignore
    assert not is_future(0)
    assert is_future(Future())
    asyncio.Future()
    assert is_future(asyncio.Future())

# Generated at 2022-06-22 03:37:05.158727
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 123)
    assert future.result() == 123
    future_1 = Future()
    future_1.cancel()
    future_set_result_unless_cancelled(future_1, 123)
    assert future_1.result() is None

# Generated at 2022-06-22 03:37:12.819590
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            f.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_and_check_status(None)

# Generated at 2022-06-22 03:37:14.080631
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-22 03:37:15.755110
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass