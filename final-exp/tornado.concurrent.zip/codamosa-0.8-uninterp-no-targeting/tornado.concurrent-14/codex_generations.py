

# Generated at 2022-06-22 03:28:15.015942
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pool_executor = DummyExecutor()
    pool_executor.shutdown()

# Generated at 2022-06-22 03:28:18.200993
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())  # type: ignore
    assert not is_future(1)

# Generated at 2022-06-22 03:28:19.231412
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("dummy")

# Generated at 2022-06-22 03:28:20.919445
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())



# Generated at 2022-06-22 03:28:25.079726
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 4)
    assert f.cancelled()
    assert not f.done()

    f2 = Future()
    future_set_result_unless_cancelled(f2, 4)
    assert not f2.cancelled()
    assert f2.done()

# Generated at 2022-06-22 03:28:34.238346
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # This test doesn't actually test anything; it just confirms that
    # the following code compiles.

    def combine_futures(future1: Future[int], future2: Future[int]) -> Future[int]:
        combined_future = Future()
        future_add_done_callback(future1, lambda future: _combine_callback(future, combined_future, future2))
        future_add_done_callback(future2, lambda future: _combine_callback(future, combined_future, future1))
        return combined_future


# Generated at 2022-06-22 03:28:36.939391
# Unit test for function is_future
def test_is_future():
    assert(is_future(Future()))
    assert(is_future(futures.Future()))
    assert(not is_future(None))

# Generated at 2022-06-22 03:28:39.489915
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.test.util as test_util
    test_util.raise_exc_info((ZeroDivisionError, ZeroDivisionError("hello"), None))

# Generated at 2022-06-22 03:28:44.095893
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, RuntimeError("test exception"))

    if not f.cancelled() and f.exception() is not None:
        # Correct exception
        return
    assert f.exception() is None



# Generated at 2022-06-22 03:28:51.252075
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise SyntaxError
    except:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    future = Future()
    try:
        raise SyntaxError
    except:
        future.set_exc_info(sys.exc_info())
    assert future.exception() is not None

# Generated at 2022-06-22 03:29:08.695019
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def _test_future_set_exception_unless_cancelled():
        future = Future()
        future.cancel()
        try:
            future_set_exception_unless_cancelled(future, Exception())
        except asyncio.InvalidStateError:
            assert False, "Exception should not be raised."
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(_test_future_set_exception_unless_cancelled())


# Generated at 2022-06-22 03:29:14.480131
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def function(self, x, y, z):
            return x + y + z

    f = Foo()
    f_future = f.function(1, 2, z=3)
    assert is_future(f_future)
    assert f_future.result() == 6

# Generated at 2022-06-22 03:29:21.776712
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # pragma: no cover
    # type: () -> None
    def callback(future):
        assert future.done()
        assert future.result() == future_data

    future_data = object()
    f1 = Future()
    assert not f1.done()
    future_add_done_callback(f1, callback)
    f1.set_result(future_data)
    f2 = Future()
    f2.set_result(None)
    future_add_done_callback(f2, callback)

# Generated at 2022-06-22 03:29:22.949803
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:29:24.599703
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit

# Generated at 2022-06-22 03:29:26.247101
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = DummyExecutor()

# Generated at 2022-06-22 03:29:28.129297
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    testFuture = dummy_executor.submit(lambda: 1)
    assert testFuture.result() == 1


# Generated at 2022-06-22 03:29:40.781527
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.concurrent import (
        Future,
        run_on_executor,
        future_set_result_unless_cancelled,
        future_set_exc_info,
    )
    from tornado.log import app_log
    from tornado import gen

    @gen.coroutine
    def test_function(self, base, exponent):
        if (yield self.executor.submit(pow, base, exponent)) == 8:
            raise gen.Return("Test function works")
        else:
            raise gen.Return("Test function does not work")

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.executor = dummy_executor
            self.answer = Future()


# Generated at 2022-06-22 03:29:46.055682
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, "bar")
    assert future.result() == "bar"
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "bar")
    assert future.cancelled()

# Generated at 2022-06-22 03:29:51.326154
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        value = ReturnValueIgnoredError.__new__(ReturnValueIgnoredError)
    except TypeError:
        # Old-style classes (aka pre-2.2) do not
        # allow calling __new__ we can't create
        # an instance... we cannot create this
        # exception.
        pass

# Generated at 2022-06-22 03:30:13.874963
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado import gen
    import time

    class TestDummyExecutor(AsyncTestCase):
        @gen_test
        def test_submit(self):
            @gen.coroutine
            def sleep():
                time.sleep(0.05)
                raise gen.Return(5)

            @gen.coroutine
            def f():
                res = yield sleep()
                self.assertEqual(res, 5)
                raise gen.Return(res)

            res = yield f()
            self.assertEqual(res, 5)

    TestDummyExecutor().test_submit()



# Generated at 2022-06-22 03:30:16.696395
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    def test(future):
        future_set_exception_unless_cancelled(future, Exception())

    future.add_done_callback(test)
    future.set_result(1)

# Generated at 2022-06-22 03:30:21.173348
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()



# Generated at 2022-06-22 03:30:32.772280
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # trivial Future-based implementation to avoid depending on concurrent.futures
    class Future(object):  # type: ignore[no-redef]
        def __init__(self):
            self._done = False
            self._result = None
            self._exc_info = None
            self._callbacks = []

        def __repr__(self):
            state = 'done' if self._done else 'pending'
            return '<%s %s>' % (self._result, state)

        def cancel(self):
            pass

        def cancelled(self):
            return False

        def running(self):
            return False

        def done(self):
            return self._done

        def result(self):
            return self._result

        def exception(self):
            return self._exc_

# Generated at 2022-06-22 03:30:33.821744
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError('message')

# Generated at 2022-06-22 03:30:44.364836
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from concurrent import futures
    from tornado import gen

    executor = futures.ThreadPoolExecutor(1)

    @gen.coroutine
    def test():
        fut = executor.submit(lambda: 42)
        # Test a Future from concurrent.futures.
        future_add_done_callback(fut, lambda f: f.result())
        yield fut

        fut = gen.convert_yielded(executor.submit(lambda: 42))
        # Test a Future from tornado.concurrent.
        future_add_done_callback(fut, lambda f: f.result())
        yield fut

    gen.coroutine(test)()



# Generated at 2022-06-22 03:30:46.835122
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    global dummy_executor
    x = dummy_executor.submit(lambda a, b: a+b, 1, 2)
    assert x is not None


# Generated at 2022-06-22 03:30:48.657256
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10



# Generated at 2022-06-22 03:30:52.157436
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(test_DummyExecutor_submit, 1, 2)
    assert future.result() == (1, 2)

# Generated at 2022-06-22 03:31:00.549005
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    # Future is not cancelled, it's fine to set exception.
    assert not future.cancelled()
    future_set_exception_unless_cancelled(future, Exception("123"))

    future = Future()
    # Impossible to get here, because Tornado already catches base exception.
    future_set_exception_unless_cancelled(future, None)  # type: ignore

    future = Future()
    future.cancel()
    assert future.cancelled()
    # Future is cancelled, and we log the exception.
    future_set_exception_unless_cancelled(future, Exception("123"))
    assert future.cancelled()  # Future is still cancelled.

    # For concurrent.futures.Future
    future = futures.Future()
    assert not future.cancelled()
   

# Generated at 2022-06-22 03:31:59.608867
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-22 03:32:01.141355
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dmy = DummyExecutor()
    dmy.shutdown()

# Generated at 2022-06-22 03:32:08.616684
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, RuntimeError('expected 1, got 2'))
    assert future.done()
    assert future.exception() is not None
    future = asyncio.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError('expected 1, got 2'))
    assert future.cancelled()

# Generated at 2022-06-22 03:32:11.243117
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    def fn_test_DummyExecutor_shutdown(obj) -> int:
        return 1

    dummy_executor.submit(fn_test_DummyExecutor_shutdown, 1)
    dummy_executor.shutdown(False)

# Generated at 2022-06-22 03:32:17.101860
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future: Future) -> None:
        callback.called = True

    callback.called = False

    # Future
    f = Future()
    future_add_done_callback(f, callback)
    assert not callback.called
    f.set_result(None)
    assert callback.called

    # concurrent.futures.Future
    callback.called = False
    f = futures.Future()
    future_add_done_callback(f, callback)
    f.set_result(None)
    assert callback.called



# Generated at 2022-06-22 03:32:29.420693
# Unit test for function chain_future
def test_chain_future():

    log = []  # type: typing.List[str]

    done = False

    def cb(result):
        log.append("cb")

    f2 = Future()
    f2.add_done_callback(cb)
    chain_future(Future(), f2)
    f2.add_done_callback(lambda result: setattr(result, 'done', True))

    def f2_done(future):
        log.append("f2 done")
        assert future.result() is None
        assert future.done
        if done:
            asyncio.get_event_loop().stop()

    f2.add_done_callback(f2_done)

    def f1_done(future):
        log.append("f1 done")
        assert future.exception() == RuntimeError("test")
        f2.set

# Generated at 2022-06-22 03:32:32.081334
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def func_to_be_executed(*args):
        return "DONE"
    assert DummyExecutor().submit(func_to_be_executed, 1)

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-22 03:32:36.739912
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        pass
    f1 = Future()
    f2 = Future()
    future_add_done_callback(f1, callback)
    future_add_done_callback(f2, callback)
    f1.set_result(None)
    f2.set_result(None)

# Generated at 2022-06-22 03:32:41.870774
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    flag = []

    def set_flag(*args: Any, **kwargs: Any) -> None:
        flag.append(True)

    future_add_done_callback(f, set_flag)

    assert flag
    flag.clear()

    with f:
        pass

    future_add_done_callback(f, set_flag)
    assert flag



# Generated at 2022-06-22 03:32:54.335681
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    from tornado import gen

    @gen.coroutine
    def f1():
        yield gen.moment
        return 42

    @gen.coroutine
    def f2():
        yield gen.moment
        return 42

    async def f3():
        return 42

    l = []
    # test conc.futures
    future_add_done_callback(f1(), lambda f: l.append(f.result()))
    future_add_done_callback(f1(), lambda f: l.append(f.result()))
    assert l == []

    AsyncIOMainLoop().start()
    AsyncIOMainLoop().install()
    f1()
    assert len(l) == 2
    assert l[0]

# Generated at 2022-06-22 03:34:48.986099
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    try:
        from unittest import mock
    except ImportError:
        import mock

    dummy_executor = dummy_executor
    # assert isinstance(dummy_executor, DummyExecutor)
    # assert isinstance(dummy_executor, futures.Executor)

    f = mock.Mock()
    dummy_executor.submit(f, 1, two=2)
    f.assert_called_once_with(1, two=2)
    f.reset_mock()

    e = RuntimeError()
    f.side_effect = e
    dummy_executor.submit(f, 1, two=2)
    f.assert_called_once_with(1, two=2)

    f.reset_mock()
    f.side_effect = e
    future

# Generated at 2022-06-22 03:34:55.037806
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.iostream import StreamClosedError

    @gen.coroutine
    def f():
        for i in range(5):
            yield gen.moment
            print(i)

    @gen.coroutine
    def g():
        print('g')

    f = g = IOLoop.current().run_in_executor(None, f)

    # IOLoop.current().stop()


if __name__ == '__main__':
    test_DummyExecutor()
    # tornado.ioloop.IOLoop.instance().start()

# Generated at 2022-06-22 03:34:56.652144
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda: 1)



# Generated at 2022-06-22 03:35:06.192669
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import concurrent.futures
    import functools

    executor = concurrent.futures.ThreadPoolExecutor(1)

    @run_on_executor(executor)
    def b():
        return 42

    @run_on_executor(executor)
    def c():
        return b()

    @run_on_executor(executor)
    def d():
        # raise an exception
        raise Exception("foo")

    @run_on_executor(executor)
    def e():
        return d()

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear

# Generated at 2022-06-22 03:35:18.519809
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # Test with an asyncio.Future
    future = Future()
    try:
        1/0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
        future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    try:
        future.result()
        assert False, "did not get expected exception"
    except ZeroDivisionError:
        pass

    # Test with a non-asyncio future
    future = futures.Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    try:
        future.result()
        assert False, "did not get expected exception"
    except ZeroDivisionError:
        pass


if __name__ == "__main__":
    test

# Generated at 2022-06-22 03:35:20.504197
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()  # type: Any
    executor.submit(lambda x: x*x, 2)
    executor.shutdown()

# Generated at 2022-06-22 03:35:21.716535
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit(lambda: 42)
    return

# Generated at 2022-06-22 03:35:26.803598
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "bar")
    assert future.cancelled()
    assert future.exception() is None
    assert future.result() is None

# Generated at 2022-06-22 03:35:38.126498
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # If a future is cancelled and it is set exception, it should only be logged
    from tornado.testing import AsyncTestCase

    class TestFuture(AsyncTestCase):
        def test_future(self):
            loop = asyncio.get_event_loop()
            future = asyncio.Future()
            future.cancel()
            future_set_exception_unless_cancelled(future, Exception())
            self.assertEqual(1, len(self.io_loop.asyncio_events[loop]))
            self.io_loop.call_later(0, loop.stop)
            loop.run_forever()
            self.assertEqual(0, len(self.io_loop.asyncio_events[loop]))

    # If a future is cancelled and it is set exception, it should NOT be logged

# Generated at 2022-06-22 03:35:43.474851
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()

    class MyException(Exception):
        pass

    try:
        raise MyException
    except MyException:
        future_set_exc_info(f, sys.exc_info())
        assert isinstance(f.exception(), MyException)

# Generated at 2022-06-22 03:37:30.941488
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:37:34.421795
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, None)
    assert f.cancelled()


# Generated at 2022-06-22 03:37:36.262326
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError(None, None, None)
    assert e.args[0] == None
    assert e.args[1] == None
    assert e.args[2] == None

# Generated at 2022-06-22 03:37:48.206059
# Unit test for function chain_future
def test_chain_future():
    def get_future(done: bool) -> Future[int]:
        future: Future[int] = Future()
        if done:
            future.set_result(42)
        return future

    future1: Future[int] = get_future(done=False)
    future2: Future[int] = get_future(done=False)
    future3: Future[int] = get_future(done=True)

    chain_future(future1, future2)
    assert not future2.done()

    future1.set_result(42)
    assert future2.done()
    assert future2.result() == 42

    future2 = get_future(done=False)
    chain_future(future3, future2)
    assert future2.done()
    assert future2.result() == 42

# Generated at 2022-06-22 03:37:50.582265
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    '''
    >>> test_DummyExecutor()
    '''
    # Test, to see if the executor is created
    dummy_executor = DummyExecutor()
    pass


# Generated at 2022-06-22 03:37:53.037385
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda: 'OK')
    assert future.result() == 'OK'


# Generated at 2022-06-22 03:37:56.716548
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    """"""
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError as e:
        assert str(e) == "returned value ignored"