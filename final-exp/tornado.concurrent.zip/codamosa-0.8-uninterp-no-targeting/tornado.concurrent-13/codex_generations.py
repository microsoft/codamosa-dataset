

# Generated at 2022-06-22 03:28:22.525480
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.concurrent import Future, TracebackFuture

    f = Future()
    try:
        i = 1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
        future_set_exc_info(f, exc_info)
        assert f.exception() == exc_info[1]

    # test that the TracebackFuture extension to tornado.concurrent.Future
    # is also supported by future_set_exc_info
    f = TracebackFuture()
    try:
        i = 1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
        future_set_exc_info(f, exc_info)
        assert f.exception() == exc_info[1]


if __name__ == "__main__":
    import unittest

# Generated at 2022-06-22 03:28:32.624988
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.gen import Return

    future = Future()

    def raise_exc():
        raise KeyError("foo")

    def raise_return():
        raise Return(42)

    future_set_exc_info(future, sys.exc_info())
    assert future.exception()

    future_set_exc_info(future, sys.exc_info())
    assert future.exception()

    future = Future()
    try:
        raise_exc()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), KeyError)

    future = Future()
    try:
        raise_return()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), Return)

# Generated at 2022-06-22 03:28:35.890897
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError("Test error")
    except ReturnValueIgnoredError as e:
        assert str(e) == "Test error"

# Generated at 2022-06-22 03:28:46.742143
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert not future.cancelled()
    assert future.done()
    assert future.exception() is exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.cancelled()  # unchanged
    assert not future.done()   # unchanged
    # This is somewhat implementation detail dependent, but
    # covers what the code uses (kqevents)
    # On macOS, the exception is swallowed.
    # On Linux and Windows, it is logged.
    # TODO: on Linux, it's logged twice? https://github.com/tornadoweb/tornado/issues/2526

# Generated at 2022-06-22 03:28:51.490130
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    assert hasattr(dummy_executor, 'shutdown')
    assert isinstance(dummy_executor.shutdown, types.MethodType)


# Generated at 2022-06-22 03:28:56.505967
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f1 = Future()
    result = []
    future_add_done_callback(f1, lambda future: result.append(future))
    f1.set_result(1)
    result[0]
    f2 = Future()
    f2.set_result(2)
    future_add_done_callback(f2, lambda future: result.append(future))
    result[1]

# Generated at 2022-06-22 03:28:59.096166
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    de = DummyExecutor()
    future = de.submit(lambda x, y: x+y, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-22 03:29:03.808398
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()

    def check_future(f):
        assert f.exception() == ValueError()

    def raise_error():
        raise ValueError()

    future_add_done_callback(f, check_future)
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-22 03:29:14.337626
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent.futures import Future
    from concurrent.futures import DummyExecutor
    de = DummyExecutor(True)
    assert de is not None
    f = de.submit(lambda : 'a')
    assert isinstance(f, Future)
    assert f.result() == 'a'
    f = de.submit(lambda : 1/0)
    assert isinstance(f, Future)
    try:
        f.result()
    except ZeroDivisionError as zde:
        assert zde
    assert f.done()
    assert f.exception()
    assert f.cancelled() == False
    assert f.running() == False



# Generated at 2022-06-22 03:29:15.400455
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    assert type(executor.submit(lambda: 2)) == futures.Future

# Generated at 2022-06-22 03:29:27.421480
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future: Future[int] = Future()
    future_set_result_unless_cancelled(future, 212)
    assert future.result() == 212
    future.cancel()
    future_set_result_unless_cancelled(future, 212)  # No error!



# Generated at 2022-06-22 03:29:40.042727
# Unit test for function run_on_executor
def test_run_on_executor():
    class A:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def sync_func(self):
            return 1

        @run_on_executor(executor='_thread_pool')
        def sync_func_2(self):
            return 2

        def end(self):
            raise Exception("end of the test case")

        def test_case(self):
            future = self.sync_func()
            future.add_done_callback(self.check_retval_1)
            return future

        def test_case_2(self):
            future = self.sync_func_2()
            future.add_done_callback(self.check_retval_2)
            return future


# Generated at 2022-06-22 03:29:42.247833
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    dummy_executor.submit(function)

# function for testing constructor of DummyExecutor class

# Generated at 2022-06-22 03:29:49.851746
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None
    assert future.cancelled()


if __name__ == "__main__":
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-22 03:29:51.458341
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(Future())

# Generated at 2022-06-22 03:29:55.203270
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    print("Unit test for method submit of class DummyExecutor")
    dummy_executor.submit(test_success, ())
    dummy_executor.submit(test_error)



# Generated at 2022-06-22 03:29:56.335454
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    r = ReturnValueIgnoredError()
    assert True

# Generated at 2022-06-22 03:30:01.314858
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 10)
    assert f.done()
    assert f.cancelled()

    f = Future()
    future_set_result_unless_cancelled(f, 10)
    assert f.done()
    assert f.result() == 10

# Generated at 2022-06-22 03:30:11.382782
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self) -> None:
            self.executor.shutdown()

        def blocking_task(self, arg: int) -> int:
            return arg * 2

        @run_on_executor
        def test_method_async(self, arg: int) -> Future:
            return self.blocking_task(arg)

        def test_async(self) -> None:
            future = self.test_method_async(10)
            result = self.io_loop.run_sync(future)

# Generated at 2022-06-22 03:30:19.277362
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    try:
        import asyncio
    except ImportError:
        return
    f = asyncio.Future()
    assert not f.done()
    called = [False]
    future_add_done_callback(f, lambda f: called.__setitem__(0, True))
    assert called[0]
    f = asyncio.Future()
    assert not f.done()
    future_add_done_callback(f, lambda f: called.__setitem__(0, True))
    assert not called[0]
    f.set_result(42)
    assert called[0]

# Generated at 2022-06-22 03:30:29.057130
# Unit test for function chain_future
def test_chain_future():
    test_future = concurrent.futures.Future()
    chain_future(test_future, Future())

test_chain_future()

# Generated at 2022-06-22 03:30:30.137872
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    t = DummyExecutor()
    return t

# Generated at 2022-06-22 03:30:36.370198
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def set_result_unless_cancelled(future: Future[int]) -> None:
        future_set_result_unless_cancelled(future, 1)

    future = Future()
    set_result_unless_cancelled(future)
    assert future.cancelled()
    future = Future()
    future.set_result(1)
    set_result_unless_cancelled(future)
    assert future.done()



# Generated at 2022-06-22 03:30:42.388644
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "value")
    assert future.result() == "value"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "value")
    assert future.cancelled()

# Generated at 2022-06-22 03:30:48.654280
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    class Future(object):
        def __init__(self):
            self.done = False
            self.cb = None

        def add_done_callback(self, cb):
            assert not self.cb
            self.cb = cb

        def set_done(self):
            self.done = True
            self.cb(self)

    f = Future()
    future_add_done_callback(f, lambda f: None)
    f.set_done()



# Generated at 2022-06-22 03:30:49.700183
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()


# Generated at 2022-06-22 03:30:56.884558
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future_set_result_unless_cancelled(future, 2)
    future_set_result_unless_cancelled(future, 3)
    assert future.result() == 2

test_future_set_result_unless_cancelled()


# Generated at 2022-06-22 03:31:03.250594
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def callback_func(future: Future) -> None:
        print("callback_func()")
        print(future.result())

    print("start")

    executor = DummyExecutor()
    future = executor.submit(lambda x: x + 1, 1)
    future.add_done_callback(callback_func)
    future.cancel()

    print("end")

# Generated at 2022-06-22 03:31:11.564459
# Unit test for function run_on_executor
def test_run_on_executor():
    o = types.SimpleNamespace()
    o.executor = futures.ThreadPoolExecutor(1)
    o.executor_called = False

    @run_on_executor
    def f(self):
        self.executor_called = True

    @run_on_executor(executor="_thread_pool")
    def f2(self):
        self.executor_called = True

    @run_on_executor(executor="_thread_pool")
    def f3(self):
        raise Exception

    f(o)
    assert o.executor_called
    o.executor_called = False
    o._thread_pool = o.executor
    f2(o)
    assert o.executor_called
    o.executor_called = False


# Generated at 2022-06-22 03:31:23.358421
# Unit test for function chain_future
def test_chain_future():
    with futures.ThreadPoolExecutor(1) as executor:

        @run_on_executor(executor="executor")
        def func(s: str) -> str:
            return s

        f1 = Future()
        f2 = Future()
        f3 = Future()
        chain_future(f1, f2)
        chain_future(f1, f3)
        f1.set_result(None)

        f4 = Future()
        f5 = Future()
        f6 = Future()
        chain_future(f4, f5)
        chain_future(f4, f6)
        f4.set_exception(RuntimeError())

        f7 = func("hi")
        f8 = Future()
        f9 = Future()
        chain_future(f7, f8)
        chain

# Generated at 2022-06-22 03:31:35.469564
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    conc_future = futures.Future()  # type: futures.Future[_T]
    future_set_result_unless_cancelled(conc_future, 10)
    assert conc_future.result() == 10

    async_future = Future()  # type: Future[_T]
    future_set_result_unless_cancelled(async_future, 10)
    assert async_future.result() == 10

    async_future = Future()  # type: Future[_T]
    async_future.cancel()
    future_set_result_unless_cancelled(async_future, 10)
    assert async_future.cancelled()
    assert async_future.result() is None


# Generated at 2022-06-22 03:31:45.852715
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    with unittest.mock.patch.object(futures.Future, "set_result") as set_result:
        f1 = futures.Future()
        f2 = futures.Future()
        chain_future(f1, f2)
        assert f2.set_result.call_count == 0
        f1.set_result(None)
        assert f2.set_result.call_count == 1

    with unittest.mock.patch.object(futures.Future, "set_exception") as set_exception:
        f1 = futures.Future()
        f2 = futures.Future()
        chain_future(f1, f2)
        assert f2.set_exception.call_count == 0
        f1.set_

# Generated at 2022-06-22 03:31:48.220400
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("1"))
    future_set_exception_unless_cancelled(future, Exception("2"))

# Generated at 2022-06-22 03:31:53.292372
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
  foo = DummyExecutor()
  def func(x):
    return x + 3
  a = foo.submit(func, 1)
  assert(a.result() == 4)
  
if __name__ == "__main__":
  test_DummyExecutor_submit()

# Generated at 2022-06-22 03:31:54.238341
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit

# Generated at 2022-06-22 03:31:59.151172
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    def run(future):
        future.set_result(123)

    def done(f):
        loop.stop()
        assert f.result() == 123

    f = Future()
    loop.run_in_executor(dummy_executor, run, f)
    f.add_done_callback(done)
    loop.start()

# Generated at 2022-06-22 03:32:09.766667
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    with f.extend([]) as _f:
        # First, make sure it works when the Future is not cancelled.
        future_set_exception_unless_cancelled(_f, RuntimeError("oops"))
        assert _f.done()
        with pytest.raises(RuntimeError, match="oops"):
            _f.result()

        # Now check that it works when the Future is cancelled.
        _f.cancel()
        future_set_exception_unless_cancelled(_f, RuntimeError("oops"))
        assert _f.done()
        with pytest.raises(asyncio.CancelledError):
            _f.result()



# Generated at 2022-06-22 03:32:11.092162
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class ReturnValueIgnoredError(Exception):
        pass



# Generated at 2022-06-22 03:32:12.010228
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:32:18.852247
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    from tornado.gen import TimeoutError
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, ExpectLog, gen_test

    class Test(AsyncTestCase):
        @gen_test
        async def test_future_set_exc_info(self):
            # type: () -> None
            future = Future()  # type: Future[str]
            exc = TimeoutError()

            def raise_exc():
                # type: () -> None
                raise exc

            IOLoop.current().add_callback(raise_exc)
            with ExpectLog(app_log, "Exception after Future was cancelled"):
                future_set_exc_info(future, sys.exc_info())
                await future
            self.assertEqual(exc, future.exception())

   

# Generated at 2022-06-22 03:32:26.852080
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception()
    except Exception:
        future_set_exc_info(f, sys.exc_info())
        assert f.exception() is not None
    assert f.done()
    assert not f.cancelled()

# Generated at 2022-06-22 03:32:35.383773
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def callback(f: Future) -> None:
        assert f.exception() is None

    # Not cancelled
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("error"))
    future_add_done_callback(future, callback)

    # Cancelled
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("error"))
    future_add_done_callback(future, callback)

    # Cancelled, but no error
    future = Future()
    future_add_done_callback(future, callback)

# Generated at 2022-06-22 03:32:42.830487
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    old_future = futures.Future()
    new_future = Future()
    try:
        raise ValueError
    except ValueError:
        exc_info = sys.exc_info()
    future_set_exc_info(old_future, exc_info)
    future_set_exc_info(new_future, exc_info)
    for future in old_future, new_future:
        assert future.exception() is not None
        assert isinstance(future.exception(), ValueError)
        future_set_exc_info(future, exc_info)
        with pytest.raises(RuntimeError):
            future.result()

# Generated at 2022-06-22 03:32:55.060196
# Unit test for function chain_future
def test_chain_future():
    import functools

    @functools.lru_cache(None)  # type: ignore
    def chain_future_result(a: Future, b: Future) -> int:
        if a.cancelled():
            return 0
        elif hasattr(a, "exc_info") and a.exc_info() is not None:  # type: ignore
            return 1
        elif a.exception() is not None:
            return 2
        elif b.cancelled():
            return 3
        elif hasattr(b, "exc_info") and b.exc_info() is not None:  # type: ignore
            return 4
        elif b.exception() is not None:
            return 5
        else:
            return 6

    import tornado.ioloop


# Generated at 2022-06-22 03:33:07.222405
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOLoop

    class Foo(object):
        def __init__(self, result):
            self.result = result

        def __repr__(self):
            return "Foo({!r})".format(self.result)

        @run_on_executor
        def bar(self, a, b):
            return self.result + a + b

    @run_on_executor(executor="_thread_pool")
    def baz(a, b):
        return a + b

    if AsyncIOLoop.initialized():
        io_loop = AsyncIOLoop.current()
        io_loop.make_current()
    else:
        io_loop = IOLoop.current()

# Generated at 2022-06-22 03:33:09.055687
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    x = DummyExecutor()
    x.shutdown(True)

# Generated at 2022-06-22 03:33:11.732559
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(asyncio.Future())
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)


# Generated at 2022-06-22 03:33:14.456742
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test_future")

    assert future.result() == "test_future"



# Generated at 2022-06-22 03:33:25.707077
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import gen_test, AsyncTestCase
    from concurrent.futures import ThreadPoolExecutor

    class Handler(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            super(Handler, self).__init__(*args, **kwargs)
            self._thread_pool = ThreadPoolExecutor(1)

        @run_on_executor(executor="_thread_pool")
        def f(self):
            raise Exception()

        @gen_test
        async def test_future_set_exception_unless_cancelled(self):
            future = self.f()
            future.cancel()
            self.assertTrue(future.cancelled())
            with self.assertRaises(Exception):
                await future

# Generated at 2022-06-22 03:33:32.310702
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception("test_future_set_exception_unless_cancelled")

    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-22 03:33:43.037325
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    def callback(future):
        assert future.done()
    future.add_done_callback(callback)  # should be called later
    future.set_result(0)  # should run the callback


# Generated at 2022-06-22 03:33:46.612063
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    from tornado.ioloop import IOLoop

    def f():
        pass

    def callback(f):
        raise ReturnValueIgnoredError("unittest")

    IOLoop.current().add_future(f, callback)

# Generated at 2022-06-22 03:33:49.008622
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda x: x, 1)
    assert future.result() == 1

# Generated at 2022-06-22 03:34:01.971219
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class A(object):
        def __init__(self, ioloop):
            # type: (IOLoop) -> None
            self.executor = ThreadPoolExecutor(1)
            self.io_loop = ioloop

        @run_on_executor
        def foo(self):
            # type: () -> None
            pass

    ioloop = IOLoop()
    ioloop.make_current()
    a = A(ioloop)
    future = a.foo()
    assert isinstance(future, Future)
    assert isinstance(a.executor, ThreadPoolExecutor)
    ioloop.add_future(future, lambda x: ioloop.stop())
    ioloop.start()
    a.executor.shutdown()



# Generated at 2022-06-22 03:34:11.370788
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestClass(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def foo(self):
            # type: () -> int
            return 42

    class TestCase(AsyncTestCase):
        @gen_test
        def test_run_on_executor(self):
            obj = TestClass()
            res = yield obj.foo()
            self.assertEqual(42, res)

    AsyncIOMainLoop().install()
    unittest.main()

# Generated at 2022-06-22 03:34:17.907580
# Unit test for function chain_future
def test_chain_future():
    import unittest.mock

    mock_callback = unittest.mock.Mock()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.add_done_callback(mock_callback)
    assert f2.done() is False
    f1.set_result(42)
    assert f2.done() is True
    assert f2.result() == 42
    mock_callback.assert_called_once_with(f2)



# Generated at 2022-06-22 03:34:29.113465
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    import asyncio
    import functools
    import unittest

    class TestFutureSetResultUnlessCancelled(unittest.TestCase):
        def test_set_result_unless_cancelled(self):
            # type: () -> None
            loop = asyncio.get_event_loop()

            @functools.wraps(future_set_result_unless_cancelled)
            def set_result_unless_cancelled(
                future: "asyncio.Future[_T]", value: _T
            ) -> None:
                future_set_result_unless_cancelled(future, value)


# Generated at 2022-06-22 03:34:34.511157
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()
    future_set_exception_unless_cancelled(f, RuntimeError())
    assert f.exception() is not None
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError())
    assert f.exception() is None


if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-22 03:34:37.049963
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    """Test the method submit of class DummyExecutor"""
    future = dummy_executor.submit(lambda: 42)
    assert future.result() == 42
    assert future.done() == True
    assert future.cancelled() == False
    assert future.exception() == None


# Generated at 2022-06-22 03:34:43.489472
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test
    from tornado.testing import AsyncTestCase

    class MyAsyncTestCase(AsyncTestCase):
        def test_chain_future(self):
            @gen_test
            def foo():
                f = Future()
                chain_future(f, Future())
                f.set_result(None)

    MyAsyncTestCase().run()

# Generated at 2022-06-22 03:35:07.019341
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import gen

    @gen.coroutine
    def f():
        yield gen.moment
        raise gen.Return(3)

    @gen.coroutine
    def g():
        yield gen.moment
        raise gen.Return(4)

    # test return value
    assert dummy_executor.submit(f).result() == 3
    assert dummy_executor.submit(f, 3, 4, d=5).result() == 3

    # test exception
    try:
        dummy_executor.submit(g, 3, 4, d=5).result()
        assert False
    except Exception:
        assert True
    try:
        dummy_executor.submit(g).result()
        assert False
    except Exception:
        assert True

    # test cancellation
    future = dummy_executor.submit(f)


# Generated at 2022-06-22 03:35:18.332041
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()
    future = asyncio.Future() # type: ignore

    # Set a result
    future_set_exception_unless_cancelled(future, Exception("test_future_set_exception_unless_cancelled"))
    assert future.exception() is not None

    # Cancel the Future and check, we get no exception
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test_future_set_exception_unless_cancelled, cancelled"))

    loop.close()

# Generated at 2022-06-22 03:35:21.001734
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception('test')
    except Exception:
        future_set_exc_info(future, sys.exc_info())
        assert future.exception() is not None

# Generated at 2022-06-22 03:35:30.784767
# Unit test for function run_on_executor
def test_run_on_executor():
    class FakeFuture:
        done = False
        cancelled = False
        result = None

        def cancel(self):
            self.cancelled = True

        def result(self):
            return self.result

        def set_result(self, result):
            self.result = result
            self.done = True

        def add_done_callback(self, callback):
            callback(self)

    test_future = FakeFuture()

    class TestObj:
        def __init__(self, future):
            self.executor = future

        @run_on_executor
        def fn(self, arg):
            self.fn_arg = arg
            return test_future

    testobj = TestObj(test_future)
    future = testobj.fn(42)

    # test return value is an asyncio.Future

# Generated at 2022-06-22 03:35:31.427800
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-22 03:35:41.321276
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fn_test() -> None:
        pass

    # Prepare
    test_executor = DummyExecutor()
    test_function = fn_test
    test_args = "test_args"
    test_kwargs = {"test_kwargs_key": "test_kwargs_value"}

    # Execute
    test_result = test_executor.submit(
        fn=test_function, args=test_args, kwargs=test_kwargs
    )

    # Assert
    assert isinstance(test_result, futures.Future)
    assert test_result.done()

# Generated at 2022-06-22 03:35:47.560539
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    done = []
    def callback(future):
        done.append(future.result() if future.result() is not None else "nowt")
    f1 = Future()
    f2 = Future()
    future_add_done_callback(f1, callback)
    f1.set_result(3)
    future_add_done_callback(f2, callback)
    f2.set_result(5)
    assert done == [3, 5]



# Generated at 2022-06-22 03:35:48.895683
# Unit test for function is_future
def test_is_future():
    f: Future[int] = Future()
    assert is_future(f)
    assert not is_future(object())

# Generated at 2022-06-22 03:35:55.966418
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    # The class to be tested
    class DummyExecutor:
        def submit(
            self, fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "futures.Future[_T]":
            future = futures.Future()  # type: futures.Future[_T]
            try:
                future_set_result_unless_cancelled(future, fn(*args, **kwargs))
            except Exception:
                future_set_exc_info(future, sys.exc_info())
            return future

        def shutdown(self, wait: bool = True) -> None:
            pass

    # Simulation
    exc = DummyExecutor()
    exc_submit = exc.submit(lambda : True)
    # Check
    assert(exc_submit.result())


# Generated at 2022-06-22 03:36:08.589481
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import functools
    import platform

    if platform.python_implementation() == "PyPy":
        # This test hangs on PyPy.
        return

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest

    # The methods, classes, and attributes all have different names
    # in the different versions.
    if AsyncIOMainLoop.initialized():
        executor_attr = "executor"
        io_loop_attr = "loop"
        has_exception = "exception"
        io_loop_class = asyncio.get_event_loop
        future_class = asyncio.Future
        result_class = concurrent.futures._base.FINISHED