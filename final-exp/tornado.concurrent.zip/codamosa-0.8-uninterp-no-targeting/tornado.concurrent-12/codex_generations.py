

# Generated at 2022-06-22 03:28:14.209941
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert not is_future(None)

# Generated at 2022-06-22 03:28:24.857945
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import sys
    import time
    import threading
    import traceback
    import unittest
    from concurrent import futures

    def sleep(sec):
        time.sleep(sec)
        return "ok"

    class TestDummyExecutor(unittest.TestCase):
        def test_run_thread_tasks(self):
            with futures.ThreadPoolExecutor(max_workers=3) as executor:
                future1 = executor.submit(sleep, 1)
                future2 = executor.submit(sleep, 2)
                future3 = executor.submit(sleep, 3)
                self.assertEqual(future1.result(), "ok")
                self.assertEqual(future2.result(), "ok")
                self.assertEqual(future3.result(), "ok")

    loader = unittest.Test

# Generated at 2022-06-22 03:28:27.384897
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    d.shutdown(wait=False)
    d.shutdown(wait=None)


# Generated at 2022-06-22 03:28:32.184970
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    try:
        raise Exception('test')
    except:
        future_set_exception_unless_cancelled(future, sys.exc_info())
    assert future.exception() is not None
    future = Future()
    assert not future.cancel()
    future_set_exception_unless_cancelled(future, sys.exc_info())

# Generated at 2022-06-22 03:28:45.008874
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    def callback(future):
        # type: (Future) -> None
        future.result()
        results.append(future)

    loop = asyncio.get_event_loop()
    results = []

    fut = Future()
    future_add_done_callback(fut, callback)
    assert not results
    fut.set_result(1)
    loop.run_until_complete(fut)
    assert results == [fut]

    fut = Future()
    fut.set_result(1)
    future_add_done_callback(fut, callback)
    assert results == [fut]

    fut = Future()
    fut.set_exception(ValueError())
    future_add_done_callback(fut, callback)
    assert results == [fut]

# Generated at 2022-06-22 03:28:45.863600
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:28:50.999374
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    assert f.cancel()
    called = False

    def callback(future):
        nonlocal called
        called = True

    future_add_done_callback(f, callback)
    assert called



# Generated at 2022-06-22 03:28:53.477364
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.cancelled()

# Generated at 2022-06-22 03:28:58.843314
# Unit test for function chain_future
def test_chain_future():
    import time
    import threading
    import logging

    logging.basicConfig(level=logging.DEBUG)
    io_loop = IOLoop()
    io_loop.make_current()
    executor = ThreadPoolExecutor(2)

    def thread_func():
        try:
            io_loop.start()
        except Exception as e:
            logging.error(e)

    thread = threading.Thread(target=thread_func)
    thread.start()

    @gen.coroutine
    def _run():
        logging.info('start')
        fut = yield executor.submit(time.sleep, 5)
        logging.info('done')

    try:
        io_loop.run_sync(_run)
    except KeyboardInterrupt:
        pass
    finally:
        io_loop.stop()
        time

# Generated at 2022-06-22 03:29:06.426944
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    """Test that run_on_executor works and executes the function synchronously."""
    class TestObj(object):
        def __init__(self):
            self.executor = dummy_executor

        def __repr__(self):
            return "<TestObj>"

        @run_on_executor
        def method(self):
            # type: () -> int
            return 42

    test = TestObj()
    future = test.method()
    assert isinstance(future, Future)
    assert future.result() == 42

# Generated at 2022-06-22 03:29:12.391869
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    try:
        raise ReturnValueIgnoredError("Test message")
    except ReturnValueIgnoredError as e:
        assert str(e) == "Test message"

# Generated at 2022-06-22 03:29:24.603456
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import unittest

    try:
        from unittest import mock  # noqa: F401 (type stub)
    except ImportError:
        import mock  # type: ignore

    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    self.assertTrue(future.done())
    self.assertIsInstance(future.exception(), ValueError)

    future = Future()
    future.cancel()
    with mock.patch('logging.error') as log_error:
        future_set_exception_unless_cancelled(future, ValueError())
    self.assertFalse(future.done())
    log_error.assert_called_once_with(
        'Exception after Future was cancelled',
        exc_info=mock.ANY)
    exc_

# Generated at 2022-06-22 03:29:36.532432
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import threading
    from tornado.ioloop import IOLoop
    from tornado.platform.auto import set_close_exec
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test, main

    if isinstance(IOLoop.current(), AsyncIOMainLoop):
        raise unittest.SkipTest("cannot be mixed with AsyncIOMainLoop")

    class TestFutureSetResultUnlessCancelled(AsyncTestCase):
        def test_future_set_result_unless_cancelled(self):
            # type: () -> None
            callback_future = Future()  # type: Future
            executor = ThreadExecutor()

# Generated at 2022-06-22 03:29:41.756038
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    future_set_exc_info(f, sys.exc_info())
    assert isinstance(f.exception(), Exception)
    if sys.version_info >= (3,):
        assert f.exception().__traceback__ is not None



# Generated at 2022-06-22 03:29:43.734242
# Unit test for function is_future
def test_is_future():  # pragma: no cover
    assert is_future(DummyExecutor().submit(lambda: None))



# Generated at 2022-06-22 03:29:45.235247
# Unit test for function is_future
def test_is_future():
    assert is_future(Future()) and is_future(futures.Future())

# Generated at 2022-06-22 03:29:50.877962
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass
    try:
        raise ReturnValueIgnoredError("foo")
    except ReturnValueIgnoredError:
        pass
    try:
        raise ReturnValueIgnoredError(future=None)
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:29:54.163450
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    future = Future()
    future_add_done_callback(future, lambda f: None)



# Generated at 2022-06-22 03:30:04.782499
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest

    class TestException(Exception):
        pass

    class FutureTest(unittest.TestCase):
        def setUp(self):
            self.future = Future()

        def test_set_exc_info(self):
            future_set_exc_info(self.future, (TestException, TestException(), None))
            self.assertIsInstance(self.future.exception(), TestException)

        def test_set_exc_info_future_cancelled(self):
            self.future.cancel()
            future_set_exc_info(self.future, (TestException, TestException(), None))
            self.assertEqual(self.future.exception(), None)

    unittest.main()

# Generated at 2022-06-22 03:30:06.420563
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    x = ReturnValueIgnoredError('err')
    assert x.args[0] == 'err'


# Generated at 2022-06-22 03:30:13.930114
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test, ExpectLog

    class FutureTest(AsyncTestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = Future()
            with ExpectLog(
                app_log, "Error in callback", required=True
            ):
                future_set_exception_unless_cancelled(future, Exception())

# Generated at 2022-06-22 03:30:15.269129
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    assert executor is not None


# Generated at 2022-06-22 03:30:19.812585
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 5)
    assert f.result() == 5
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled()
    assert not f.done()

# Generated at 2022-06-22 03:30:31.553331
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import collections

    @run_on_executor
    def f():
        pass

    mock_executor = unittest.mock.Mock()
    m = collections.namedtuple("mock", ["executor"])(mock_executor)
    f(m)
    mock_executor.submit.assert_called_once_with(f, m)
    mock_executor.shutdown.assert_not_called()

    m = collections.namedtuple("mock", ["executor", "io_loop"])(mock_executor, unittest.mock.Mock())
    f(m)
    mock_executor.submit.assert_called_with(f, m)
    mock_executor.shutdown.assert_not_called()


# Generated at 2022-06-22 03:30:37.493248
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1

    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-22 03:30:45.463264
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def test(func):
        future = Future()
        events = []

        def f(future):
            events.append("callback")
        func(future, f)
        events.append("after callback")
        assert events == ["after callback"]
        future.set_result(None)
        assert events == ["after callback", "callback"]

    yield test, future_add_done_callback
    yield test, futures.Future.add_done_callback



# Generated at 2022-06-22 03:30:51.253207
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = asyncio.Future()
    try:
        raise ValueError('foo')
    except ValueError:
        tb = sys.exc_info()[2]
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), ValueError)
    assert tb.tb_next.tb_frame is future.exception().__traceback__.tb_next.tb_frame

# Generated at 2022-06-22 03:30:52.309765
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass


# Generated at 2022-06-22 03:30:54.880740
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # DummyExecutor is used by @return_future decorator in tornado.gen
    dummy_executor.submit(lambda: 1)
    pass


# Generated at 2022-06-22 03:30:57.452361
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    assert executor.submit(lambda: 0) is not None
    executor.submit(lambda: 0)
    executor.shutdown(False)



# Generated at 2022-06-22 03:31:03.588915
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() is None


# Generated at 2022-06-22 03:31:11.748631
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import unittest as ut


    @run_on_executor('_thread_pool')
    def run_on_executor_test(self, arg1, arg2):
        return arg1 + arg2


    class RunOnExecutorTest(ut.TestCase):
        def setUp(self):
            self._thread_pool = unittest.mock.Mock(spec=futures.Executor)

        def test_run_on_executor(self):
            self._thread_pool.submit.return_value = futures.Future()
            self._thread_pool.submit.return_value.result = 3
            result = run_on_executor_test(self, 1, 2)

# Generated at 2022-06-22 03:31:23.393719
# Unit test for function chain_future
def test_chain_future():
    import random
    import time

    def slow_add(x, y):
        time.sleep(0.001 * random.randint(1, 10))
        return x + y

    def slow_error(x, y):
        time.sleep(random.randint(1, 10) * 0.01)
        raise ValueError("slow_error")

    def get_result(future):
        try:
            return future.result()
        except ValueError:
            return "value error"

    @run_on_executor
    def get_slow_add(x, y):
        return slow_add(x, y)

    def callback_1(future):
        future.result()

    def callback_2(future):
        raise ValueError("callback_2")


# Generated at 2022-06-22 03:31:32.990142
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f2.result() == 42


__all__ = (
    "Future",
    "ReturnValueIgnoredError",
    "chain_future",
    "dummy_executor",
    "future_add_done_callback",
    "future_set_result_unless_cancelled",
    "future_set_exception_unless_cancelled",
    "future_set_exc_info",
    "is_future",
    "run_on_executor",
)

# Generated at 2022-06-22 03:31:34.830141
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError())

# Generated at 2022-06-22 03:31:36.725419
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    pass

# Generated at 2022-06-22 03:31:39.068952
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    ex = DummyExecutor()
    future = ex.submit(lambda: 1+2)
    assert future.result() == 3



# Generated at 2022-06-22 03:31:48.064120
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import to_asyncio_future

    def callback(future):
        futures.append(future)

    for cls in (Future, futures.Future):
        future1 = cls()
        future2 = cls()
        futures = []
        future_add_done_callback(future1, callback)
        chain_future(future1, future2)
        future1.set_result(42)
        assert futures == [future1]
        assert future2.result() == 42

        future1 = cls()
        future2 = cls()
        futures = []
        chain_future(future1, future2)
        future_add_done_callback(future1, callback)
        future1.set_result(42)
        assert futures == [future1]
        assert future2.result()

# Generated at 2022-06-22 03:31:51.336922
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    @typing.overload
    def f(x: "Future[_T]") -> None:
        pass

    @typing.overload
    def f(x: "futures.Future[_T]") -> None:
        pass

    @f.register  # noqa: F811
    def f(x: "Union[Future[_T], futures.Future[_T]]") -> None:
        pass

    f(Future())
    f(futures.Future())

# Generated at 2022-06-22 03:31:55.941121
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    async def f():
        a, b = Future(), Future()
        chain_future(a, b)
        a.set_result(42)
        self.assertEqual(42, await b)

    tornado.testing.IOLoopTestCase().run_sync(f)