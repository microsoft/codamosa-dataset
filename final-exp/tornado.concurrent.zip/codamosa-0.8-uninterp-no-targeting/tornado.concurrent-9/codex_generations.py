

# Generated at 2022-06-22 03:28:09.520299
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:28:13.312246
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda : None)
    assert isinstance(future, Future)
    assert future.done()

# Generated at 2022-06-22 03:28:17.641066
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def dummy_func(value):
        return value

    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(dummy_func, 3)
    assert future.result() == 3

# Generated at 2022-06-22 03:28:25.186986
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest.mock as mock

    future = Future()
    exc = ValueError()
    with mock.patch('tornado.gen.app_log') as al:
        future_set_exception_unless_cancelled(future, exc)
        assert future.exception() == exc
        al.error.assert_not_called()
    future = Future()
    future.cancel()
    with mock.patch('tornado.gen.app_log') as al:
        future_set_exc_info(future, (None, exc, None))
        al.error.assert_called_once_with("Exception after Future was cancelled", exc_info=exc)

# Generated at 2022-06-22 03:28:25.881253
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:28:34.750066
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import concurrent.futures
    import functools
    import tornado.testing
    from tornado.ioloop import IOLoop

    future = concurrent.futures.Future()
    results = []
    cb = functools.partial(results.append, 1)
    future_add_done_callback(future, cb)
    future.set_result(2)
    assert results == [1]
    future = Future()
    IOLoop.current().add_future(future, lambda f: results.append(f.result()))
    future.set_result(3)
    assert results == [1, 2]
    future = Future()
    future.set_result(4)
    future_add_done_callback(future, lambda f: results.append(f.result()))

# Generated at 2022-06-22 03:28:39.912759
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    d_e = DummyExecutor()
    def test_function(x: int) -> int:
        return x ** 2
    test_future = d_e.submit(test_function, 2)
    assert test_future.result() == 4, "DummyExecutor submit method doesn't work"

# Generated at 2022-06-22 03:28:47.961012
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.ioloop
    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()

        @run_on_executor
        def func(self):
            return 1234

        def test_func(self):
            f = self.func()

            def callback(f):
                self.assertEqual(f.result(), 1234)
                self.io_loop.stop()

            f.add_done_callback(callback)
            self.io_loop.start()

    unittest.main()

# Generated at 2022-06-22 03:28:49.255796
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # noqa
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:28:51.252434
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:29:04.844025
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOMainLoop
    import tornado.testing

    class ExecutorTestCase(tornado.testing.AsyncTestCase):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, x: int, y: int) -> int:
            return x + y

        def test_run_on_executor(self) -> None:
            self.assertEqual(self.func(1, 2), 3)


# Generated at 2022-06-22 03:29:06.989130
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:29:12.153739
# Unit test for function is_future
def test_is_future():
    try:
        import asyncio
        asyncio.Future()
        assert is_future(Future())
    except ImportError:
        pass
    assert is_future(futures.Future())
    assert not is_future(object())
    assert not is_future(None)
    assert not is_future(1)

# Generated at 2022-06-22 03:29:14.904581
# Unit test for function is_future
def test_is_future():
    def good():
        return is_future(Future())

    def bad():
        return is_future(object())

    assert good()
    assert not bad()

# Generated at 2022-06-22 03:29:25.977720
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    # f1, f2 not done
    assert not f1.done()
    assert not f2.done()

    f1.set_result(1)
    assert f1.done()
    assert f2.done()
    assert f2.result() == 1

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("foo"))
    assert f1.done()
    assert f2.done()
    assert isinstance(f2.exception(), Exception)

# Generated at 2022-06-22 03:29:37.695797
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    import logging
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future

    # Tests that the exception is logged if no handler is provided.
    future1 = to_asyncio_future(Future())
    future1.set_exception(RuntimeError())
    test_logger = logging.getLogger("tornado.test_future")
    with mock.patch.object(test_logger, "error") as log_mock:
        future_set_exception_unless_cancelled(future1, RuntimeError())
        log_mock.assert_called_once()

    AsyncIOMainLoop().install()
    future2 = Future()
    future2.set_exception(RuntimeError())
   

# Generated at 2022-06-22 03:29:40.523291
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    f = dummy_executor.submit(lambda: 1)
    assert(f.result() == 1)

# Generated at 2022-06-22 03:29:43.023431
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    '''Call the submit method on class DummyExecutor
    '''
    def test_method(*args, **kwargs):
        # type: (*Any, **Any) -> None
        return 1
    dummy_executor.submit(test_method, 1)

# Generated at 2022-06-22 03:29:50.832548
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.testing import AsyncTestCase, gen_test

    class FutureSetExcInfoTest(AsyncTestCase):
        @gen_test
        def test_future_set_exc_info(self):
            future = Future()
            try:
                raise ValueError("test")
            except Exception:
                future_set_exc_info(future, sys.exc_info())
            with self.assertRaises(ValueError) as cm:
                yield future
            self.assertEqual("test", str(cm.exception))

# Generated at 2022-06-22 03:29:54.109367
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    @run_on_executor
    def foo(x):
        return 1

    result = foo(1)
    assert result.result() == 1

# Generated at 2022-06-22 03:30:00.253160
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:30:09.161866
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class MyClass(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking(self, x, y):
            return x + y

    class RunOnExecutorTest(unittest.TestCase):
        def test_run_on_executor(self):
            obj = MyClass()
            result = IOLoop.current().run_sync(lambda: obj.blocking(1, 2))
            self.assertEqual(result, 3)

    unittest.main()

# Generated at 2022-06-22 03:30:19.682094
# Unit test for function run_on_executor
def test_run_on_executor():
    def f():
        pass

    def g(self: object) -> None:
        pass

    assert run_on_executor(g) is g
    assert run_on_executor(executor="_thread_pool")(g) is not g
    assert run_on_executor(executor="_thread_pool")(g)(None) is not None
    assert run_on_executor(executor="_thread_pool")(f)(None) is None
    assert run_on_executor(executor="_thread_pool")(f)("a", "b") is None
    assert run_on_executor(executor="_thread_pool")(f)(a="a", b="b") is None

# Generated at 2022-06-22 03:30:23.053002
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))

# Generated at 2022-06-22 03:30:23.963370
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-22 03:30:27.605859
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future()) is True
    assert is_future(Future()) is True
    assert is_future(None) is False

# Generated at 2022-06-22 03:30:29.109166
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    return ReturnValueIgnoredError('test_ReturnValueIgnoredError')


# Generated at 2022-06-22 03:30:39.163091
# Unit test for function run_on_executor
def test_run_on_executor():
    import logging
    import tornado.testing
    import concurrent.futures

    logging.getLogger().setLevel(logging.DEBUG)

    class Foo(object):
        executor = concurrent.futures.ThreadPoolExecutor(10)

        @run_on_executor
        def bar(self):
            logging.info("in bar")
            return 42

    class TestRunOnExecutor(tornado.testing.AsyncTestCase):
        def test_bar(self):
            foo = Foo()
            self.assertEqual(foo.bar(), 42)

    tornado.testing.main()


if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-22 03:30:44.462266
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    """Tests that ``is_future`` recognizes known types."""
    assert is_future(None) == False
    assert is_future(1) == False
    assert is_future(object) == False

    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-22 03:30:50.510860
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # noqa: no cover
    import sys
    import tornado.testing
    import tornado.ioloop
    import concurrent.futures

    def function():
        raise Exception()

    future = concurrent.futures.Future()
    future_set_exc_info(future, sys.exc_info())
    future.result()

    future = asyncio.Future()
    future_set_exc_info(future, sys.exc_info())
    tornado.testing.gen_test(function)(tornado.ioloop.IOLoop.current())
    future.result()

# Generated at 2022-06-22 03:31:07.087937
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    dummy_executor.submit(lambda x: 1, 1)

# Generated at 2022-06-22 03:31:10.286599
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    result = [False]

    def callback(future):
        result[0] = future.result()

    future_add_done_callback(f, callback)
    f.set_result(True)
    assert result[0]



# Generated at 2022-06-22 03:31:13.179790
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    global dummy_executor
    try:
        dummy_executor.submit(lambda x: x, 1)
    except Exception:
        assert False

# Generated at 2022-06-22 03:31:15.062819
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:31:23.538434
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    f2 = Future()
    chain_future(f2, f)
    chain_future(f, f2)
    chain_future(f2, f)
    f2.set_exception(RuntimeError())
    exc = RuntimeError()
    try:
        f.result()
        assert False
    except RuntimeError as err:
        assert err is exc
    try:
        f2.result()
        assert False
    except RuntimeError as err:
        assert err is exc
try:
    test_chain_future()
except Exception:
    pass
else:
    del test_chain_future

# Generated at 2022-06-22 03:31:34.680959
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self, result):
            self.executor = dummy_executor
            self.result = result

        @run_on_executor
        def future_func(self):
            return self.result

        @run_on_executor()
        def future_func_args(self):
            return self.result

        @run_on_executor(executor="_thread_pool")
        def future_func_keywords(self):
            return self.result

    f = Foo(True)
    future = f.future_func()
    assert isinstance(future, Futures)
    assert future.result() == True
    future = f.future_func_args()
    assert isinstance(future, Futures)
    assert future.result() == True
    future = f.future

# Generated at 2022-06-22 03:31:37.749510
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    """DummyExecutor should not raise error when shutdown"""
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:31:42.153618
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def cb(f): pass
    f = Future()
    future_add_done_callback(f, cb)
    f.set_result(None)
    f = asyncio.Future()
    future_add_done_callback(f, cb)
    f.set_result(None)



# Generated at 2022-06-22 03:31:46.669524
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    future = Future()
    try:
        raise Exception("foo")
    except:
        future_set_exc_info(future, sys.exc_info())
    assert future.done()
    assert isinstance(future.exception(), Exception)
    assert future.exception().args[0] == "foo"



# Generated at 2022-06-22 03:31:55.208376
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    """
    >>> test_DummyExecutor()
    """
    executor = DummyExecutor()
    future = executor.submit(lambda : 4)
    assert future.result() == 4
    future = executor.submit(lambda : 1/0)
    try:
        future.result()
        assert False
    except ZeroDivisionError:
        pass
    future = executor.submit(lambda : 1/0)
    try:
        future.exception()
        assert False
    except ZeroDivisionError:
        pass
    executor.shutdown(wait=True)
