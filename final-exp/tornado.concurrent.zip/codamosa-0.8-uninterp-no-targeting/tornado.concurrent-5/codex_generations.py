

# Generated at 2022-06-22 03:28:23.724110
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def f(self, x, y, z=None):
            return x + y + z

        @run_on_executor
        def exception_example(self):
            1 / 0

        @run_on_executor(executor="my_executor")
        def f2(self):
            return 42

        @run_on_executor
        def f3(self, x, y, z=None):
            raise ReturnValueIgnoredError()
            return x + y + z

        @run_on_executor
        def f4(self, x, y, z=None):
            return x + y + z

    foo = Foo()
    foo.my_executor = dummy_executor
    future = foo

# Generated at 2022-06-22 03:28:25.163150
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda: 1)
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:28:27.608127
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x, 1)
    assert(future.result() == 1)

# Generated at 2022-06-22 03:28:30.279397
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future("asdf")

# Generated at 2022-06-22 03:28:35.264104
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async def async_test(arg1, arg2):
        print(arg1, arg2)
        return arg1 + arg2
    future = dummy_executor.submit(async_test, "hello", "world")
    print(future.result())



# Generated at 2022-06-22 03:28:46.328769
# Unit test for function run_on_executor
def test_run_on_executor():
    if hasattr(asyncio, "Task"):
        # Trust that asyncio's own tests cover this.
        return

    future = Future()  # type: Future[int]

    class Example(object):
        executor = dummy_executor
        _thread_pool = dummy_executor

        @run_on_executor
        def foo(self, arg):
            future_set_result_unless_cancelled(future, arg)

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            future_set_result_unless_cancelled(future, None)

        @run_on_executor(executor="_thread_pool")
        def baz(self):
            pass

    e = Example()

    e.foo(6)

# Generated at 2022-06-22 03:28:50.792998
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass
    else:
        assert False, "Failed to raise ReturnValueIgnoredError"

# Generated at 2022-06-22 03:28:59.362088
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.concurrent import TracebackFuture

    # Test that Future class works with it
    future = Future()
    added_callback = False
    future_add_done_callback(future, lambda f: (f, added_callback))
    assert not added_callback
    future.set_result(None)
    assert added_callback

    # Test that TracebackFuture class works with it
    future = TracebackFuture()
    added_callback = False
    future_add_done_callback(future, lambda f: (f, added_callback))
    assert not added_callback
    future.set_result(None)
    assert added_callback



# Generated at 2022-06-22 03:29:11.449136
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class Foo:
        # type: ignore
        def __init__(self, arg: int) -> None:
            pass

    def fun(arg: int) -> str:
        return "FOO"

    def fun2(arg: int) -> int:
        return arg

    # Verify that _generate_traceback can generate a traceback
    try:
        Foo("hello")
    except TypeError as e: # we don't care about the details
        error1 = ReturnValueIgnoredError("error1")
        error1.__cause__ = e
        frame = error1._generate_traceback()

    # Verify that _generate_traceback handles async def functions
    async def fun3() -> None:
        return

    fun3()

    # Verify that _generate_traceback can generate a traceback

# Generated at 2022-06-22 03:29:12.874394
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown(wait=True)

# Generated at 2022-06-22 03:29:25.884007
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda x: x, 1)
    assert future.result() == 1
    assert future.exception() is None
    assert not future.cancelled()
    assert future.done() is True
    assert future.running() is False

    future = dummy_executor.submit(lambda x: 1 / x, 0)
    assert future.result() is None
    assert isinstance(future.exception(), ZeroDivisionError)
    assert not future.cancelled()
    assert future.done() is True
    assert future.running() is False



# Generated at 2022-06-22 03:29:26.576873
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert True

# Generated at 2022-06-22 03:29:38.278077
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado import gen

    # Test IOLoop.run_sync
    @gen.coroutine
    def f():
        a = Future()
        b = Future()
        chain_future(a, b)
        IOLoop.current().add_callback(lambda: a.set_result(42))
        result = yield b
        raise gen.Return(result)

    assert f() == 42

    # Test old-style callback
    class OldStyleCallback:
        def __call__(self, future):
            self.future = future

    @gen.coroutine
    def g():
        a = Future()
        b = Future()
        chain_future(a, b)
        IOLoop.current().add_callback(lambda: a.set_result(42))
        callback = Old

# Generated at 2022-06-22 03:29:41.806363
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def plus(a, b):
        return a + b
    future = dummy_executor.submit(plus, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-22 03:29:46.646815
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception("test")
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    assert isinstance(f.exception(), Exception)
    assert "test" in str(f.exception())
    assert f.cancelled() is False



# Generated at 2022-06-22 03:29:54.584665
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import ioloop
    from tornado import testing

    test_loop = ioloop.IOLoop.current()
    executor = dummy_executor
    future = executor.submit(lambda x: x * x, 2)
    future.add_done_callback(
        lambda future: test_loop.stop() if future.result() == 4 else False)
    test_loop.start()
    assert future.result() == 4



# Generated at 2022-06-22 03:30:05.851116
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    from unittest import mock

    class TestFuture(Future):
        def __init__(self, is_cancelled: bool) -> None:
            super().__init__()
            self._is_cancelled = is_cancelled

        def cancelled(self) -> bool:
            return self._is_cancelled

        def set_result(self, value: int) -> None:
            assert value == 5
            assert not self.done()

    class TestFutures(unittest.TestCase):
        def test_future(self) -> None:
            future = TestFuture(False)
            future_set_result_unless_cancelled(future, 5)

        def test_cancelled_future(self) -> None:
            future = TestFuture(True)


# Generated at 2022-06-22 03:30:13.765587
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def f(self, x, y):
            return x + y

    io_loop = IOLoop()
    foo = Foo()
    f = foo.f(1, 2)
    io_loop.add_future(f, lambda f: io_loop.stop())
    io_loop.start()
    assert f.result() == 3

    @run_on_executor
    def g(x, y):
        return x + y

    f = g(3, 4)
    io_loop.add_future(f, lambda f: io_loop.stop())
    io_loop.start()
    assert f.result()

# Generated at 2022-06-22 03:30:19.814194
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.done()
    assert f.result() == 42
    future_set_result_unless_cancelled(f, 100)
    assert f.result() == 42

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() is None


# Generated at 2022-06-22 03:30:25.216266
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # basic test
    def dummy_func(a, b, c):
        return b - (a + c)

    ret = dummy_executor.submit(dummy_func, 1, 2, 3).result()
    assert ret == -4

    # test throw exception
    def dummy_func(a, b, c):
        raise Exception("could not compute")

    with pytest.raises(Exception):
        dummy_executor.submit(dummy_func, 1, 2, 3)


# Generated at 2022-06-22 03:30:31.943714
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import time

    ex = DummyExecutor()
    f = ex.submit(time.sleep, 3)
    assert f.result() is None
    ex.shutdown()


# Generated at 2022-06-22 03:30:43.319416
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from concurrent.futures.thread import ThreadPoolExecutor
    from tornado.testing import AsyncTestCase, gen_test

    class FutureTest(AsyncTestCase):
        executor = ThreadPoolExecutor(1)

        @gen_test
        async def test_future_set_exception_unless_cancelled(self):
            future = concurrent.futures.Future()
            future.cancel()
            future_set_exception_unless_cancelled(future, ValueError("test"))
            future = Future()
            future.cancel()
            future_set_exception_unless_cancelled(future, ValueError("test"))

    FutureTest().test_future_set_exception_unless_cancelled()

# Generated at 2022-06-22 03:30:48.306062
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    @gen.coroutine
    def check(future):
        # type: (Future[int]) -> None
        result = yield future
        assert result == 1

    future = Future()
    future_add_done_callback(future, lambda f: check(f))
    future.set_result(1)


# Undeprecated aliases for asyncio.as_completed and as_completed

# Generated at 2022-06-22 03:30:53.889857
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = concurrent.futures.Future()

    def callback(future):
        assert future.done()
        future._test_done = True

    future_add_done_callback(future, callback)
    assert not future._test_done
    future.set_result(None)
    assert future._test_done
    future = Future()
    future_add_done_callback(future, callback)
    assert not future._test_done
    future.set_result(None)
    assert future._test_done


# In Python 3.5.2, concurrent.futures.as_completed() returns a generator
# instead of a list. This wrapper forces it to be a list.

# Generated at 2022-06-22 03:30:59.575814
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    from asyncio import Future
    from concurrent.futures import Future as CFuture
    from tornado.concurrent import Future
    from tornado.concurrent import Future as TFuture
    from tornado.platform.asyncio import to_asyncio_future

    assert not is_future(None)
    assert is_future(Future())
    assert is_future(CFuture())
    assert is_future(Future())
    assert is_future(TFuture())
    assert is_future(to_asyncio_future(Future()))

# Generated at 2022-06-22 03:31:07.724355
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()

    result = {"done_callback": 0}

    def cb(future):
        result["done_callback"] += 1

    future_add_done_callback(f, cb)
    assert result["done_callback"] == 0

    future_set_result_unless_cancelled(f, None)
    assert result["done_callback"] == 1

    future_add_done_callback(f, cb)
    assert result["done_callback"] == 2



# Generated at 2022-06-22 03:31:09.201242
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    executor.submit()
    executor.shutdown()

# Generated at 2022-06-22 03:31:11.044578
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # noqa: F811
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:31:17.526195
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 100)
    assert future.result() == 100

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 100)
    assert future.cancelled()

# Generated at 2022-06-22 03:31:22.530035
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        future_set_exc_info(future, sys.exc_info())
    if hasattr(future, "exception_info"):
        assert isinstance(future.exception_info()[1], ZeroDivisionError)
    else:
        assert isinstance(future.exception(), ZeroDivisionError)

# Generated at 2022-06-22 03:31:32.796317
# Unit test for function is_future
def test_is_future():
    import asyncio
    from concurrent import futures

    assert is_future(futures.Future())
    assert is_future(asyncio.Future())


if __name__ == "__main__":
    test_is_future()

# Generated at 2022-06-22 03:31:41.371174
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    exc1 = RuntimeError("first exception")

    future_set_exception_unless_cancelled(future, exc1)

    assert future.exception() == exc1

    future.cancel()

    exc2 = RuntimeError("second exception")

    future_set_exception_unless_cancelled(future, exc2)

    assert future.exception() == exc1


if __name__ == "__main__":
    import unittest
    from tornado.testing import AsyncTestCase


    class FutureTest(AsyncTestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = Future()

            exc1 = RuntimeError("first exception")

            future_set_exception_unless_cancelled(future, exc1)

            self.assertE

# Generated at 2022-06-22 03:31:43.552443
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    def noop():
        pass

    fake_self = types.SimpleNamespace()
    fake_self.executor = DummyExecutor()
    fn = run_on_executor(noop)
    fn(fake_self)

# Generated at 2022-06-22 03:31:44.787041
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError("message")
    except ReturnValueIgnoredError as e:
        print(e)

# Generated at 2022-06-22 03:31:56.198373
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    from tornado.concurrent import Future
    from tornado.testing import gen_test

    f = Future()
    f.set_result(None)
    assert f.done()

    @gen_test
    def test():
        # type: () -> None
        yield f
    test()

    # Future.add_done_callback
    f = Future()
    future_add_done_callback(f, lambda f: f.set_result(None))
    f.set_result(None)

    # concurrent.futures.Future
    f = futures.Future()
    future_add_done_callback(f, lambda f: f.set_result(None))
    f.set_result(None)

# Generated at 2022-06-22 03:31:58.113561
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(futures.Future())  # type: ignore

# Generated at 2022-06-22 03:32:00.822602
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = DummyExecutor()
    b = a.submit(lambda v: v + 5, 10)
    assert type(b) == futures.Future
    # All Future objects are true
    assert is_future(b)
    assert b.result() == 15
    a.shutdown()

# Generated at 2022-06-22 03:32:04.157515
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()
    assert dummy_executor.shutdown() is None



# Generated at 2022-06-22 03:32:14.701904
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    def f():
        # type: () -> None
        future_set_exc_info(Future(), sys.exc_info())

    assert_raises(Exception, f)

    fut = Future()
    fut.set_exception(Exception())
    # Subsequent set_exception is a no-op:
    future_set_exc_info(fut, (None, None, None))
    # Must call set_exc_info twice for an asyncio Future:
    future_set_exc_info(fut, sys.exc_info())
    assert_raises(Exception, fut.result)

    fut = Future()
    fut.set_exception(Exception())
    # Subsequent set_exception is a no-op:

# Generated at 2022-06-22 03:32:15.755091
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())

# Generated at 2022-06-22 03:32:29.596704
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise Exception("smoke test")
    except Exception:
        exc_info = sys.exc_info()

    f = Future()
    future_set_exc_info(f, exc_info)

    destroyed = []  # type: typing.List[Exception]
    def on_destroy(x):
        destroyed.append(x)

    f.add_done_callback(on_destroy)
    f.result()

# Generated at 2022-06-22 03:32:38.663398
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop, PeriodicCallback
    from tornado.platform.asyncio import to_asyncio_future
    from concurrent.futures import ThreadPoolExecutor
    from tornado.concurrent import Future
    from tornado.gen import coroutine, Return
    from tornado import gen
    import asyncio
    from tornado.platform.asyncio import AsyncIOLoop
    import pytest

    @coroutine
    def f1(a):
        yield gen.sleep(1)
        yield gen.moment
        raise gen.Return([a])

    @coroutine
    def f2(a):
        yield gen.sleep(1)
        raise gen.Return([a])

    @coroutine
    def f3(a, b=1):
        yield gen.sleep(1)

# Generated at 2022-06-22 03:32:43.895414
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from tornado.concurrent import Future

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def do(self, val):
            return val

    foo = Foo()

    future = foo.do("abc")
    assert future.result() == "abc"
    assert isinstance(future, Future)


if __name__ == "__main__":
    import unittest
    import tornado

    tornado.testing.main()

# Generated at 2022-06-22 03:32:49.093066
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(a,b):
        return a+b
    f = dummy_executor.submit(foo,1,2)
    assert f.result()==3

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-22 03:32:54.536484
# Unit test for function run_on_executor
def test_run_on_executor():

    def return_42():
        return 42

    class Test(object):
        executor = dummy_executor
        return_42 = run_on_executor(return_42)

        def __init__(self):
            self.future = self.return_42()
            assert is_future(self.future)

    test = Test()

    assert test.future.result() == 42

# Generated at 2022-06-22 03:33:06.726887
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import io
    import sys

    f = Future()
    try:
        raise RuntimeError()
    except RuntimeError:
        future_set_exc_info(f, sys.exc_info())
    assert f.exc_info() == sys.exc_info()

    f = Future()
    try:
        raise io.UnsupportedOperation()
    except:
        future_set_exc_info(f, sys.exc_info())
    assert f.exc_info() == sys.exc_info()

    f = Future()
    try:
        raise ValueError('hello')
    except:
        future_set_exc_info(f, sys.exc_info())
    assert f.exc_info() == sys.exc_info()

    f = Future()
    future_set_exc_info(f, None)

# Generated at 2022-06-22 03:33:09.137050
# Unit test for function is_future
def test_is_future():
    class Myfuture(Future):
        pass
    assert is_future(Future())
    assert is_future(Myfuture())
    assert not is_future("not a future")

# Generated at 2022-06-22 03:33:15.804189
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from concurrent.futures import ThreadPoolExecutor

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_run_on_executor(self):
            self.res = None

            class Test(object):
                @run_on_executor
                def func(self, arg, kwarg=None):
                    return arg, kwarg


# Generated at 2022-06-22 03:33:27.350046
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado.gen

    future_list = []

    @tornado.gen.coroutine
    def set_exception_unless_cancelled_coroutine_test():
        f = Future()
        future_list.append(f)
        yield f
        raise Exception("Error should be expected")

    @tornado.gen.coroutine
    def test_function():
        f = Future()
        future_list.append(f)
        yield f
        future_set_exception_unless_cancelled(f, Exception("Error should be expected"))


# Generated at 2022-06-22 03:33:35.494569
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception().__class__ == ZeroDivisionError.__class__

# Generated at 2022-06-22 03:34:06.773946
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from tornado.ioloop import IOLoop, PeriodicCallback

    from concurrent.futures import Future as _Future

    class TestRunOnExecutor(unittest.TestCase):
        def test_basic(self):
            calls = []

            class Foo(object):
                @run_on_executor
                def bar(self, a, b, c):
                    calls.append((a, b, c))
                    return "foo" + str(a) + str(b) + str(c)

            foo = Foo()
            foo.executor = dummy_executor

            future = foo.bar(1, 2, c=3)
            self.assertIsInstance(future, Future)
            result = self.io_loop.run_sync(future.result)

# Generated at 2022-06-22 03:34:09.180953
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def dummy_method():
        print("Dummy method")
    dummy_executor.submit(dummy_method)

test_DummyExecutor_submit()

# Generated at 2022-06-22 03:34:10.790418
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    executor.submit(print, "Hello World!")


# Generated at 2022-06-22 03:34:18.817022
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    try:
        from unittest.mock import patch
    except ImportError:
        from unittest.mock import patch
    import asyncio
    from tornado.ioloop import IOLoop

    future = asyncio.Future()
    future_set_result_unless_cancelled(future, "test")
    with patch.object(future, 'set_result') as mocked_set_result:
        mocked_set_result.side_effect = asyncio.InvalidStateError("test")
        future_set_result_unless_cancelled(future, "test2")
        IOLoop.current().run_sync(future)
        mocked_set_result.assert_not_called()

# Generated at 2022-06-22 03:34:29.669906
# Unit test for function chain_future
def test_chain_future():
    dummy = object()

    async def async_function(arg, future):
        future_set_result_unless_cancelled(future, arg)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(dummy)
    assert f2.result() is dummy

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(dummy)
    assert f2.result() is None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_exception(RuntimeError)

# Generated at 2022-06-22 03:34:37.078371
# Unit test for function chain_future
def test_chain_future():
    def f():
        return 3

    def g():
        raise Exception("callback error")

    # Callback chain from f() to g()
    a = Future()  # type: Future[int]
    b = Future()  # type: Future[int]
    chain_future(a, b)
    assert not a.done()
    assert not b.done()
    a.set_result(f())
    assert b.result() == 3
    # Exception chain from g() to f()
    c = Future()  # type: Future[int]
    d = Future()  # type: Future[int]
    chain_future(c, d)
    assert not c.done()
    assert not d.done()
    c.set_result(g())
    assert isinstance(d.exception(), Exception)
    # Test with

# Generated at 2022-06-22 03:34:39.412308
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    print(executor)


# Generated at 2022-06-22 03:34:40.688287
# Unit test for function is_future
def test_is_future():
    is_future(object())


del typing

# Generated at 2022-06-22 03:34:42.533353
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(print, 1)
    dummy_executor.shutdown()


# Generated at 2022-06-22 03:34:44.394413
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    asyncio.run(DummyExecutor().submit(None, None))
    pass


# Generated at 2022-06-22 03:35:24.573385
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    de = DummyExecutor()
    de.shutdown()
    de.shutdown(True)
    de.shutdown(False)


# Generated at 2022-06-22 03:35:25.521307
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass


# Generated at 2022-06-22 03:35:36.109104
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    import threading
    import time

    class Worker(object):
        def __init__(self, thread_pool, callback_arg=None):
            self.thread_pool = thread_pool
            self._callback_arg = callback_arg
            self.thread_id = None

        @run_on_executor
        def run(self, foo=None):
            self.thread_id = threading.get_ident()
            return foo

        @run_on_executor
        def run_with_callback(self, foo=None):
            self.thread_id = threading.get_ident()
            return foo

        @run_on_executor
        def run_with_callback_arg(self, foo=None):
            self.thread_id = threading.get_ident()

# Generated at 2022-06-22 03:35:44.674627
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    value = 123
    future_set_result_unless_cancelled(future, value)
    assert future.result() == value

    future = Future()
    future.cancel()
    with pytest.raises(asyncio.CancelledError):
        future.result()
    future_set_result_unless_cancelled(future, value)
    assert future.cancelled()



# Generated at 2022-06-22 03:35:47.445525
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    obj1 = DummyExecutor()  # type: DummyExecutor
    obj2 = DummyExecutor()  # type: DummyExecutor
    assert(obj1 == obj2)

# Generated at 2022-06-22 03:35:50.148144
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    try:
        dummy_executor.submit(lambda : 3, 3)
    except Exception:
        assert False


# Generated at 2022-06-22 03:35:54.441708
# Unit test for function chain_future
def test_chain_future():
    # Test the most common use.
    @gen.coroutine
    def f():
        print('coroutine')
        raise gen.Return('result')

    @gen.coroutine
    def g():
        print('coroutine 2')

    future = Future()
    chain_future(f(), future)
    chain_future(g(), future)
    IOLoop.current().run_sync(lambda: future)

# Generated at 2022-06-22 03:36:00.103947
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()

# Generated at 2022-06-22 03:36:00.703183
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    pass

# Generated at 2022-06-22 03:36:01.629255
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-22 03:36:40.092205
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)

# Generated at 2022-06-22 03:36:42.133703
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-22 03:36:44.859838
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError())

# Generated at 2022-06-22 03:36:53.624261
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.future1 = Future()
            self.future2 = Future()

        def test_chain_normal(self):
            self.future1.set_result("foo")
            chain_future(self.future1, self.future2)
            self.assertEqual("foo", self.future2.result())

        def test_chain_with_result_before_chaining(self):
            self.future1.set_result("foo")
            self.future2.set_result("bar")
            chain_future(self.future1, self.future2)
            self.assertEqual("bar", self.future2.result())


# Generated at 2022-06-22 03:36:59.370599
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    results = []

    def cb(f):
        assert f is future
        results.append(f)

    future_add_done_callback(future, cb)
    assert results == []

    future_set_result_unless_cancelled(future, 42)
    assert results == [future]

    future_add_done_callback(future, cb)
    assert results == [future, future]



# Generated at 2022-06-22 03:37:06.595469
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    import tornado.ioloop
    ioloop = tornado.ioloop.IOLoop.current()
    executor = DummyExecutor()
    def async_work():
        return 3
    def callback(future):
        assert future.result() == 3
        ioloop.stop()
    future = executor.submit(async_work)
    future.add_done_callback(callback)
    ioloop.start()
    executor.shutdown()

# Generated at 2022-06-22 03:37:09.827262
# Unit test for function is_future
def test_is_future():
    def create_future(value):
        if sys.version_info >= (3, 5, 2):
            return Future()
        else:
            return futures.Future()
    # type: ignore
    x = create_future(1)
    assert is_future(x) is True
    x = 1
    assert is_future(x) is False

# Generated at 2022-06-22 03:37:18.591333
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado import gen

    @gen.coroutine
    def foo(s):
        raise gen.Return(s)
    with futures.ThreadPoolExecutor(1) as executor:
        fa = executor.submit(foo, "a")
        fb = executor.submit(foo, "b")
        fc = executor.submit(foo, "c")
        la = [None]
        lb = [None]
        lc = [None]

        def done_callback(future):
            la[0] = future.result()

        def done_callback2(future):
            lb[0] = future.result()

        def done_callback3(future):
            lc[0] = future.result()

        future_add_done_callback(fa, done_callback)

# Generated at 2022-06-22 03:37:20.892570
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    foo = DummyExecutor()
    assert foo


# Generated at 2022-06-22 03:37:21.913422
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()