

# Generated at 2022-06-22 03:28:08.191519
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    assert isinstance(executor,futures.Executor)


# Generated at 2022-06-22 03:28:13.652231
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def fn(x):
        return x+1
    print(fn(5))
    print(fn(6))
    f = dummy_executor.submit(fn, 4)
    print(f.result())

if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-22 03:28:20.709559
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise Exception("foo")
    except Exception:
        future = Future()
        future_set_exc_info(future, sys.exc_info())
        # Mypy doesn't understand that future_set_exc_info can't return,
        # but at runtime it won't return anything.
        # Pass our exception through the Future to make sure it didn't
        # get dropped on the floor.
        future.exception()



# Generated at 2022-06-22 03:28:29.526437
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from concurrent.futures import Future as ConcFuture
    from tornado.concurrent import Future
    import asyncio

    loop = asyncio.get_event_loop()
    set_loop(loop)

    def mul(p):
        return p*2

    def add(p):
        return p+1

    def cb(future):
        return future.result()

    def test1(future: Future):
        assert future.result() == 4

    def test2(future: ConcFuture):
        assert future.result() == 5

    future = concurrent_future_to_asyncio_future(
        loop.run_in_executor(None, mul, 2)
    )
    future_add_done_callback(future, test1)
    f2 = future_to_concurrent_future(future)
    future_add

# Generated at 2022-06-22 03:28:33.477491
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    try:
        f.result()
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-22 03:28:35.631902
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    a = DummyExecutor()
    assert a.shutdown() == None


# Generated at 2022-06-22 03:28:42.684365
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise Exception("error1")
    except Exception:
        exc_info = sys.exc_info()
    # type: Tuple[type(Exception), BaseException, types.TracebackType]
    future = Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    assert str(future.exception()) == "error1"



# Generated at 2022-06-22 03:28:51.581721
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    callback_args = [False, None]

    def callback(f):
        callback_args[0] = True
        callback_args[1] = f

    future_add_done_callback(f, callback)
    assert callback_args[0] is False
    assert callback_args[1] is None

    f.set_result(3)
    assert callback_args[0] is True
    assert callback_args[1] is f
    assert callback_args[1].result() == 3



# Generated at 2022-06-22 03:28:53.337825
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    asyncio.Future()  # type: ignore
    Future()  # type: ignore

# Generated at 2022-06-22 03:28:55.389089
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    conc_future = executor.submit(lambda: 1)
    assert conc_future.result() == 1

# Generated at 2022-06-22 03:29:09.515304
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    executor.submit(_add, 1, 2)
    assert False



# Generated at 2022-06-22 03:29:20.938818
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    if hasattr(ReturnValueIgnoredError, '__init__'):
        assertReturnValueIgnoredError = True
        try:
            raise ReturnValueIgnoredError()
        except ReturnValueIgnoredError as e:
            assert type(e) == ReturnValueIgnoredError
            assert isinstance(e, Exception)
            assert str(e) == ''
        except:  # pragma: no cover
            assertReturnValueIgnoredError = False
        if not assertReturnValueIgnoredError:
            return False
        try:
            raise ReturnValueIgnoredError('user message')
        except ReturnValueIgnoredError as e:
            assert type(e) == ReturnValueIgnoredError
            assert isinstance(e, Exception)
            assert str(e) == 'user message'

# Generated at 2022-06-22 03:29:23.771802
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    import pytest
    dummy_executor.shutdown()
    pytest.fail("Test with assert statement is not implemented yet!!")

# Generated at 2022-06-22 03:29:35.724408
# Unit test for function run_on_executor
def test_run_on_executor(): # pragma: no cover
    from tornado.ioloop import IOLoop
    import time

    def run_on_executor_decorator(self: Any, *args: Any, **kwargs: Any) -> Future:
        async_future = Future()  # type: Future
        conc_future = getattr(self, executor).submit(fn, self, *args, **kwargs)
        chain_future(conc_future, async_future)
        return async_future

    class TestClass(object):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super(TestClass, self).__init__(*args, **kwargs)
            self._pool = futures.ThreadPoolExecutor(5)
            self.executor = "_pool"
            self.io_loop = IOL

# Generated at 2022-06-22 03:29:38.013416
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    print("dummy_executor:", dummy_executor)

# Generated at 2022-06-22 03:29:43.250135
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-22 03:29:45.593454
# Unit test for function is_future
def test_is_future():
    assert not is_future(object())
    assert is_future(Future())
    assert is_future(futures.Future())


# Generated at 2022-06-22 03:29:57.289608
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.testing import gen_test

    @run_on_executor
    def function(x: int, y: int) -> int:
        return x + y

    class User(object):
        def __init__(self):
            self.executor = dummy_executor

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.user = User()

        @gen_test
        async def test_function(self):
            result = await function(self.user, 1, y=2)
            self.assertEqual(result, 3)

    test_instance = TestRunOnExecutor()
    test_instance.setUp()
    test_instance.test_function()

# Generated at 2022-06-22 03:29:59.511681
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    ex = DummyExecutor()
    assert ex.shutdown() == None


# Generated at 2022-06-22 03:30:05.986882
# Unit test for function chain_future
def test_chain_future():
    @gen.coroutine
    def f1():
        yield gen.sleep(0.01)
        raise Exception("test")

    @gen.coroutine
    def f2():
        yield gen.sleep(0.02)
        raise Exception("unreachable")

    f1 = f1()
    f2 = f2()
    chain_future(f1, f2)
    try:
        yield f1
    except Exception:
        pass
    try:
        yield f2
    except Exception:
        pass
    assert f1.exception() and f2.exception()

# Generated at 2022-06-22 03:31:59.896242
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    ...


# Generated at 2022-06-22 03:32:04.905714
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    def foo(a, b):
        return a + b
    future = dummy_executor.submit(foo,1,2)
    result = future.result()
    assert result == 3

# Generated at 2022-06-22 03:32:15.342586
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.ioloop
    import random

    io_loop = tornado.ioloop.IOLoop.current()
    f1 = Future()
    f2 = Future()
    f3 = Future()
    result = None
    f1.add_done_callback(lambda f: f2.set_result('f2'))
    f2.add_done_callback(lambda f: f3.set_result(f.result() + 'f3'))
    f3.add_done_callback(lambda f: setattr(io_loop, 'stop', True))

    def start():
        io_loop.stop = False
        f1.set_result('f1')

    io_loop.add_callback(start)

# Generated at 2022-06-22 03:32:21.822098
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    try:
        raise ValueError
    except ValueError as e:
        exc_info = sys.exc_info()
        f = Future()
        future_set_exc_info(f, exc_info)
        exc = f.exception()
        assert exc is e

# Generated at 2022-06-22 03:32:22.447882
# Unit test for function is_future
def test_is_future():
    is_future({})

# Generated at 2022-06-22 03:32:24.370819
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown(wait=True)

# Generated at 2022-06-22 03:32:27.913297
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    _this_file = __file__
    with open(__file__, "rb") as f:
        try:
            f.read()
        except IOError as e:
            print(e)


# Generated at 2022-06-22 03:32:30.300043
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test exception"))



# Generated at 2022-06-22 03:32:31.156505
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:32:41.591633
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio

    class A:
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def foo(self, arg) -> int:
            return arg

        @run_on_executor
        def callback(self, future: futures.Future, arg) -> None:
            future.set_result(arg)

        async def bar(self, arg) -> int:
            return await self.foo(arg)

    a = A()
    assert isinstance(a.foo(1), Future)
    assert a.foo(1).result() == 1
    loop = asyncio.get_event_loop()
    assert loop.run_until_complete(a.bar(2)) == 2
    fut = futures.Future()

# Generated at 2022-06-22 03:37:35.596275
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = asyncio.CancelledError()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-22 03:37:37.982925
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def foo(a, b):
        return a + b

    dummy_executor = DummyExecutor()
    f = dummy_executor.submit(foo, 1, 2)
    assert f.result() == 3

# Generated at 2022-06-22 03:37:46.279188
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    assert future.exception()

    future = Future()
    future.cancel()
    try:
        future_set_exception_unless_cancelled(future, ValueError("test"))
    except Exception:
        # OK if we log another exception
        pass
    assert future.cancelled()



# Generated at 2022-06-22 03:37:50.654896
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError()
    except:
        future_set_exc_info(future, sys.exc_info())
        assert future.exception() is not None

        future_set_exc_info(future, (None, None, None))
        assert future.exception() is not None

# Generated at 2022-06-22 03:37:59.187956
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(object):
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def slow(self, arg, kwarg=None):
            return arg + kwarg

    foo = Foo()

    class Bar(object):
        @run_on_executor(executor="executor")
        def slow(self, arg, kwarg=None):
            return arg + kwarg

    bar = Bar()
    bar.executor = foo.executor
