

# Generated at 2022-06-22 03:28:21.150152
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import tornado.testing
    import tornado.ioloop

    future = Future()
    future_set_result_unless_cancelled(future, "aaa")

    @tornado.gen.coroutine
    def coroutine():
        nonlocal future
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, "aaa")

        future = Future()
        future_set_result_unless_cancelled(future, "aaa")
        future.cancel()

    tornado.testing.gen_test(coroutine)()
    tornado.ioloop.IOLoop.current().start()

# Generated at 2022-06-22 03:28:32.467811
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    ioloop = asyncio.new_event_loop()
    asyncio.set_event_loop(ioloop)

    f = Future()
    f2 = Future()

# Generated at 2022-06-22 03:28:45.053385
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import logging
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import run_on_executor

    logger = logging.getLogger(__name__)

    class TestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.executor = futures.ThreadPoolExecutor(
                max_workers=1, thread_name_prefix="test_run_on_executor"
            )
            self.executor_called = False
            self.executor_called2 = False
            self.executor_thread_id = None

        def tearDown(self):
            self.executor.shutdown(wait=True)
            super().tearDown()


# Generated at 2022-06-22 03:28:49.871315
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception("foo")
    except:
        exc_info = sys.exc_info()
    future_set_exc_info(f, exc_info)
    raise_exc_info(f.exc_info())

# Generated at 2022-06-22 03:28:52.525636
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor = DummyExecutor()
    try:
        dummy_executor.shutdown()
        assert True
    except:
        assert False

# Generated at 2022-06-22 03:29:03.272162
# Unit test for function chain_future
def test_chain_future():
    @gen.coroutine
    def f1():
        yield gen.Task(IOLoop.current().add_callback)
        return 42

    @gen.coroutine
    def f2():
        try:
            yield f1()
            raise Exception("did not get exception")
        except Exception:
            assert sys.exc_info()[1].args == ("hello",)
            # re-raise allows us to inspect the traceback
            raise

    f3 = Future()
    chain_future(f1(), f3)
    f1_raised = []
    f3_raised = []

    def f1_errback(f: Future) -> None:
        f1_raised.append(True)
        assert isinstance(f.exception(), Exception)
        assert f.exception().args == ("hello",)


# Generated at 2022-06-22 03:29:06.006094
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    # f.result()  # this would raise an exception

# Generated at 2022-06-22 03:29:09.457162
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError("Test message")
    assert e.message == "Test message"
    assert str(e) == "Test message"

# Generated at 2022-06-22 03:29:14.195103
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda: 42)
    assert future.done()
    assert future.result() == 42
    future = executor.submit(lambda : 1/0)
    assert future.done()
    assert isinstance(future.exception(), ZeroDivisionError)

# Generated at 2022-06-22 03:29:15.538600
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_set_exception_unless_cancelled(Future(), Exception())

# Generated at 2022-06-22 03:32:37.394874
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass


# Generated at 2022-06-22 03:32:45.333474
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    @gen_test
    def test_chain_future_gen(io_loop: "IOLoop") -> None:
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(3)
        self.assertEqual(f2.result(), 3)
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_exception(ValueError())
        with self.assertRaises(ValueError):
            f2.result()

    # Unit test for function future_set_result_unless_cancelled

# Generated at 2022-06-22 03:32:46.954184
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    return ReturnValueIgnoredError("test")



# Generated at 2022-06-22 03:32:48.680023
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:32:57.763028
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    print("Running test_DummyExecutor_submit...")
    print("Creating instance of DummyExecutor...")
    myExec = DummyExecutor()
    print("Submitting a job to the DummyExecutor...")
    myFuture = myExec.submit(add, 2, 3)
    print("Checking future completion...")
    assert myFuture.done() == True
    print("Getting result...")
    myResult = myFuture.result()
    print("Result is: " + str(myResult))
    assert myResult == 5
    print("test_DummyExecutor_submit done!")


# Generated at 2022-06-22 03:33:01.626009
# Unit test for function chain_future
def test_chain_future():
    import tornado.platform.asyncio
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest

    tornado.platform.asyncio.AsyncIOMainLoop().install()

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1, f2 = Future(), Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-22 03:33:09.901962
# Unit test for function chain_future
def test_chain_future():
    if not hasattr(Future, "add_done_callback"):
        # python 3.5. In python 3.6.2, this function is deprecated in
        # favor of add_done_callback but is still there.
        return
    f = Future()
    f1 = Future()
    chain_future(f, f1)
    f.set_result(4)
    assert f1.result() == 4
    f = Future()
    f1 = Future()
    f.set_result(5)
    chain_future(f, f1)
    assert f1.result() == 5



# Generated at 2022-06-22 03:33:15.047449
# Unit test for function chain_future
def test_chain_future():
    main_done = Future()
    other_done = Future()
    main_done.add_done_callback(
        lambda future: future_set_result_unless_cancelled(other_done, future.result())
    )
    chain_future(main_done, other_done)
    if isinstance(main_done, Future):
        future_set_result_unless_cancelled(main_done, None)
    else:
        # concurrent.futures.Future
        main_done.set_result(None)
    main_result = other_done.result()
    assert main_result is None

# Generated at 2022-06-22 03:33:21.251818
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())


FutureT = typing.TypeVar("FutureT", bound="asyncio.Future")  # noqa: E0239
_FutureT = typing.TypeVar("_FutureT", bound=futures.Future)
_Future_T = typing.TypeVar("_Future_T", bound="Future[_T]")



# Generated at 2022-06-22 03:33:24.581253
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    assert d.submit(lambda: 1).result() == 1

# Unit tests for function future_set_exc_info

# Generated at 2022-06-22 03:37:55.930217
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def assert_equals(a, b):
        assert a == b

    def assert_raises(a, b):
        assert a in b

    d = DummyExecutor()
    assert_equals(d.submit(lambda: 1).result(), 1)
    assert_raises(TypeError, d.submit, None)
    assert_raises(TypeError, d.submit, lambda: None, [])(
        "DummyExecutor.submit() takes at most 1 positional argument (%d given)"
    )

# Generated at 2022-06-22 03:38:02.087814
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    print("start")
    def add1(x:int)->int:
        return x+1
    a = DummyExecutor()
    b = a.submit(add1, 1)
    print(b.done()) # false
    print(b.result()) # 2


if __name__ == "__main__":
    test_DummyExecutor_submit()