

# Generated at 2022-06-22 03:28:07.855499
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def f():
        return 1
    assert f() == 1

# Generated at 2022-06-22 03:28:20.445391
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    import tornado
    from tornado.platform.asyncio import AsyncIOMainLoop

    class SetResultUnlessCancelledTest(unittest.TestCase):
        def setUp(self):
            self.loop = AsyncIOMainLoop()
            self.loop.make_current()
            self.addCleanup(self.loop.close)

        def test_cancel(self):
            future = Future()
            future.cancel()
            with self.assertRaises(tornado.util.CancelledError):
                future.result()

            future_set_result_unless_cancelled(future, 1)
            self.assertEqual(future.result(), 1)

        def test_set_result(self):
            future = Future()
            self.assertFalse(future.done())
           

# Generated at 2022-06-22 03:28:25.510491
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_cls = Future if hasattr(Future, "cancel") else futures.Future  # type: ignore
    future = future_cls()
    future_set_result_unless_cancelled(future, None)
    future_set_result_unless_cancelled(future, None)
    future.cancel()
    future_set_result_unless_cancelled(future, None)


test_future_set_result_unless_cancelled()

# Generated at 2022-06-22 03:28:26.593434
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("test")

# Generated at 2022-06-22 03:28:29.685175
# Unit test for function is_future
def test_is_future():
    assert (is_future(Future()) and
            is_future(futures.Future()) and
            is_future(dummy_executor.submit(lambda: None)))

# Generated at 2022-06-22 03:28:33.588413
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    done = Future()
    exc = RuntimeError()
    future_set_exception_unless_cancelled(done, exc)
    assert done.exception() == exc
    done.cancel()
    exc2 = RuntimeError()
    future_set_exception_unless_cancelled(done, exc2)
    assert done.exception() == exc

# Generated at 2022-06-22 03:28:36.549260
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception('foo'))

# Generated at 2022-06-22 03:28:40.344070
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    ex = DummyExecutor()
    ex.submit(print, 1)
    ex.shutdown(wait=False)
    assert ex.submit(print, 2) == None


# Generated at 2022-06-22 03:28:43.257368
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    future1 = dummy_executor.submit(lambda: "test")
    assert future1.result() == "test"


# Generated at 2022-06-22 03:28:49.188521
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest.mock

    future = Future()
    future_set_exc_info(future, sys.exc_info())
    unittest.mock.sentinel.assert_called_with(future)
    future.add_done_callback.assert_called_with(unittest.mock.sentinel)



# Generated at 2022-06-22 03:31:59.815505
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("test")

# Generated at 2022-06-22 03:32:11.531723
# Unit test for function is_future
def test_is_future():
    from tornado.concurrent import Future

    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(object())


if __name__ == "__main__":
    import unittest
    import tornado.testing

    class FutureTest(unittest.TestCase):
        def setUp(self):
            self.result = None
            self.exc_info = None

        def callback(self, future):
            self.result = future.result()
            self.exc_info = future.exc_info()

        def test_return_value_ignored(self):
            @return_future
            def f(arg, callback):
                self.assertEqual(arg, 123)
                callback(arg)
                return "foo"

            self.assertEqual(f(123), "foo")

# Generated at 2022-06-22 03:32:14.955267
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert not future.cancelled()
    assert 42 == future.result()



# Generated at 2022-06-22 03:32:20.909343
# Unit test for function chain_future
def test_chain_future():
    async def f(_):
        return 1

    async def g(_):
        return 2

    future = f(None)
    chain_future(future, f(None))
    assert f(None).result() == 1
    assert g(None).result() == 2


# Generated at 2022-06-22 03:32:23.817270
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError(
            "Async methods must be used with @gen.coroutine"
        )
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:32:26.803866
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()

    future_set_exception_unless_cancelled(f, KeyError('foo'))

# Generated at 2022-06-22 03:32:27.640557
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(object())

# Generated at 2022-06-22 03:32:34.819682
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    result = []

    def cb(f):
        result.extend(['done', f])
    future_add_done_callback(future, cb)
    assert not result
    future.set_result(None)
    assert result == ['done', future]
    future = Future()
    result = []
    future_add_done_callback(future, cb)
    assert result == ['done', future]



# Generated at 2022-06-22 03:32:43.206637
# Unit test for function chain_future
def test_chain_future():
    from tornado_py2.ioloop import IOLoop

    def cb_a(future):
        assert not future.cancelled()
        raise Exception()

    def cb_b(future):
        pass

    def cb_c(future):
        f.set_result(future.result())

    # Create a future
    f = Future()
    # Add callbacks
    f.add_done_callback(cb_a)
    f.add_done_callback(cb_b)
    f.add_done_callback(cb_c)

    # Create the future
    f2 = Future()
    # Chain it
    chain_future(f, f2)
    # Run the loop
    IOLoop.current().start()

# Generated at 2022-06-22 03:32:48.140305
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future("foo")
    assert not is_future(object())
    assert is_future(Future())
    assert is_future(futures.Future())
    import asyncio
    assert is_future(asyncio.Future())

# Generated at 2022-06-22 03:35:14.253560
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    with pytest.raises(TypeError, match=r'__init__\(\) takes 0 positional arguments but 1 was given'):
        ReturnValueIgnoredError(['a'])  # type: ignore

# Generated at 2022-06-22 03:35:17.576811
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    x=DummyExecutor()
    # x.submit(int, 1)
    pass



# Generated at 2022-06-22 03:35:21.044378
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def func():
        raise Exception("test")
    future = Future()
    try:
        func()
    except:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception().args[0] == "test"

# Generated at 2022-06-22 03:35:30.831080
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    class TestFuture(Future):
        def __init__(self, is_cancelled: bool = False) -> None:
            super().__init__()
            self._is_cancelled = is_cancelled

        def cancelled(self):
            return self._is_cancelled

    class TestException(Exception):
        pass

    future_cancelled = TestFuture(is_cancelled=True)
    future_cancelled.set_result(0)
    future_cancelled.set_exception(TestException())
    future_cancelled.set_result(1)
    future_cancelled.set_exception(TestException())

    future_not_cancelled = TestFuture(is_cancelled=False)

# Generated at 2022-06-22 03:35:35.856493
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    ev = asyncio.Event()
    f = Future()
    future_add_done_callback(f, ev.set)
    ev.wait(1)

    assert not f.done()
    f.set_result(None)
    ev.wait(1)
    assert f.done()

# Generated at 2022-06-22 03:35:38.698521
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)



# Generated at 2022-06-22 03:35:44.028316
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
	e = DummyExecutor()
	f = e.submit(lambda x: x**2, 7)
	if f.result() != 49:
		raise ValueError("Test 'test_DummyExecutor' failed!")
test_DummyExecutor()


# Generated at 2022-06-22 03:35:46.710643
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    executor = DummyExecutor()
    assert executor != None
    assert isinstance(executor, DummyExecutor)


# Generated at 2022-06-22 03:35:54.062176
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = Future()
    test_future.cancel()
    with pytest.raises(asyncio.InvalidStateError):
        test_future.set_result(True)

    # Since it is cancelled can't set result - should not throw exception
    future_set_result_unless_cancelled(test_future, True)

    test_future = Future()
    test_future.set_result(True)
    future_set_result_unless_cancelled(test_future, True)

# Generated at 2022-06-22 03:35:56.124918
# Unit test for function is_future
def test_is_future():
    f = futures.Future()
    assert is_future(f)
    assert is_future(asyncio.Future())