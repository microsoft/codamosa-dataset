

# Generated at 2022-06-22 03:28:06.809196
# Unit test for function is_future
def test_is_future():
    is_future(asyncio.Future())



# Generated at 2022-06-22 03:28:08.328926
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())  # type: ignore

# Generated at 2022-06-22 03:28:13.437841
# Unit test for function is_future
def test_is_future():
    tornado.ioloop.IOLoop().run_sync(
        lambda: is_future(asyncio.Future())
    )  # type: ignore


Futures = typing.Union[Tuple[Future, ...], "Future"]



# Generated at 2022-06-22 03:28:17.777277
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(print, 2)
    assert future.done(), "The future object must be done."
    assert future.result() is None, "The future object's result must be None."


# Generated at 2022-06-22 03:28:20.659736
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except:
        future_set_exc_info(future, sys.exc_info())
    future.add_done_callback(lambda f: f.result())

# Generated at 2022-06-22 03:28:29.494457
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase
    from tornado.ioloop import IOLoop
    import tornado.gen

    io_loop = IOLoop.current()

    class TestChainFuture(AsyncTestCase):
        def test_future_chain(self):
            async_future_a = Future()
            async_future_b = Future()
            chain_future(async_future_a, async_future_b)
            self.assertFalse(async_future_b.done())
            async_future_a.set_result(42)
            result = await tornado.gen.with_timeout(
                io_loop.time() + 1, async_future_b
            )
            self.assertEqual(result, 42)
            self.assertTrue(async_future_b.done())

    TestChainFuture().test_future

# Generated at 2022-06-22 03:28:31.797928
# Unit test for function is_future
def test_is_future():
    assert isinstance(Future(), Future)
    assert is_future(Future())



# Generated at 2022-06-22 03:28:44.554855
# Unit test for function run_on_executor
def test_run_on_executor():
    future = Future()

    class Obj(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            assert self is obj
            assert arg == 42
            return arg + 1

        @run_on_executor(executor="executor2")
        def func2(self, arg):
            assert self is obj
            assert arg == 43
            return arg + 1

        executor2 = dummy_executor

    obj = Obj()
    func = obj.func
    assert isinstance(func(42), Future)

    func2 = obj.func2
    assert isinstance(func2(43), Future)

    obj.executor = dummy_executor
    func = obj.func
    assert isinstance(func(44), Future)


# Generated at 2022-06-22 03:28:56.149261
# Unit test for function run_on_executor
def test_run_on_executor():
    try:
        import tornado.concurrent
        future_class = tornado.concurrent.Future
    except ImportError:
        future_class = Future

    class MyTestClass:
        def __init__(self):
            self.executor = dummy_executor

        def func(self, a, b):
            return a + b

        # Signature of the decorated method must match the original one
        @run_on_executor()
        def decorated(self, a, b):
            return self.func(a, b)

        @run_on_executor
        def decorated_default(self, a, b):
            return self.func(a, b)

        @run_on_executor(executor="executor")
        def decorated_kwargs(self, a, b):
            return self.func(a, b)



# Generated at 2022-06-22 03:28:58.308316
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    f = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    # InvalidStateError would be raised here if it failed.

# Generated at 2022-06-22 03:29:08.035484
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def _test(future):
        try:
            raise Exception("foo")
        except Exception:
            future_set_exc_info(future, sys.exc_info())

    f = Future()
    _test(f)
    f.result()

# Generated at 2022-06-22 03:29:14.343371
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()  # type: Future[int]
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-22 03:29:16.006149
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent import futures

    e = DummyExecutor()

    f = e.submit(lambda : 'a')
    assert f is not None
    assert isinstance(f, futures.Future)
    assert f.result() == 'a'


# Generated at 2022-06-22 03:29:20.259477
# Unit test for function is_future
def test_is_future():
    assert is_future(Future()) == True
    assert is_future(futures.Future()) == True
    assert is_future(dummy_executor.submit(id, 1)) == True
    assert is_future(None) == False

# Generated at 2022-06-22 03:29:23.004939
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "value")
    assert f.cancelled()



# Generated at 2022-06-22 03:29:30.774664
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def test_future_error(exctype):
        future = Future()
        try:
            raise exctype()
        except Exception:
            future_set_exc_info(future, sys.exc_info())
        future_add_done_callback(future, lambda f: f.result())

    test_future_error(Exception)
    test_future_error(KeyboardInterrupt)
    test_future_error(GeneratorExit)



# Generated at 2022-06-22 03:29:38.844468
# Unit test for function run_on_executor
def test_run_on_executor():
    class Test(object):
        executor = dummy_executor

        @run_on_executor
        def test(self) -> int:
            # This is a synchronous method, but when called from
            # asynchronous code (e.g., in a coroutine) it will be run
            # on the thread pool.
            return 42

    test = Test()
    assert isinstance(test.test(), Future)
    assert test.test().result() == 42

run_on_executor.__test__ = False  # type: ignore

# Generated at 2022-06-22 03:29:40.993681
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)

# Generated at 2022-06-22 03:29:43.305703
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    de = DummyExecutor()
    future = de.submit(pow, 5, 2)
    print(future.result())


# Generated at 2022-06-22 03:29:55.749522
# Unit test for function run_on_executor
def test_run_on_executor():
    class FakeFuture(object):
        def __init__(self):
            self.done_callbacks = []
            self.exception = None

        def set_exception(self, exception):
            self.exception = exception

        def done(self):
            return self.exception is not None

        def result(self):
            return "result"

        def add_done_callback(self, callback):
            self.done_callbacks.append(callback)

    class FakeExecutor(object):
        def submit(self, fn, *args):
            return FakeFuture()

    class FakeClass(object):
        def __init__(self):
            self.executor = FakeExecutor()

        @run_on_executor(executor="executor")
        def func(self):
            raise Exception("exception")

    f

# Generated at 2022-06-22 03:32:15.117166
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def callback(f):
        # type: (Future) -> None
        pass

    f = Future()
    f2 = Future()
    chain_future(f, f2)

    exceptions = []  # type: typing.List[BaseException]
    try:
        raise ValueError()
    except ValueError as e:
        exceptions.append(e)

    test_futures = [f, f2]
    for _f in test_futures:
        g = Future()
        chain_future(_f, g)
        test_futures.append(g)

    future_add_done_callback(f, callback)
    f.set_result(None)

    for _f in test_futures:
        assert not _f.cancelled()
        assert _f

# Generated at 2022-06-22 03:32:25.321022
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda:0)
    assert future.result() == 0

    future = executor.submit(lambda x:x, 1)
    assert future.result() == 1

    future = executor.submit(lambda x, y:x+y, 1, 2)
    assert future.result() == 3

    future = executor.submit(lambda x, y, z:x+y+z, 1, 2, 3)
    assert future.result() == 6

# Generated at 2022-06-22 03:32:26.329501
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert True



# Generated at 2022-06-22 03:32:28.834087
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def hello():
        print('hello')
        return 2

    executor = DummyExecutor()
    f = executor.submit(hello)
    print(f.result())

# Generated at 2022-06-22 03:32:34.055844
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()

    # This should be a no-op
    future_set_exception_unless_cancelled(f, FutureCancelledError())


test_future_set_exception_unless_cancelled()



# Generated at 2022-06-22 03:32:39.915011
# Unit test for function is_future
def test_is_future():
    # type() is used instead of isinstance to avoid https://mypy.readthedocs.io/en/latest/common_issues.html#import-cycles
    assert type(concurrent.futures.Future()) is type(concurrent.futures.Future())
    assert type(asyncio.Future()) is type(asyncio.Future())
    assert type(concurrent.futures.Future()) is not type(asyncio.Future())

# Generated at 2022-06-22 03:32:46.796575
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
  # Test a normal case
  assert dummy_executor.submit(lambda : 1).result() == 1
  # Test an exception is raised
  assert dummy_executor.submit(lambda : 1/0).exception().__class__.__name__ ==\
      "ZeroDivisionError"


# Generated at 2022-06-22 03:32:50.234006
# Unit test for function is_future
def test_is_future():
    from unittest import mock
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(mock.Mock())

# Generated at 2022-06-22 03:32:53.517402
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f1 = Future()
    try:
        raise Exception("foo")
    except:
        future_set_exc_info(f1, sys.exc_info())
    f1.result()



# Generated at 2022-06-22 03:33:05.845310
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from asyncio import Future
    from concurrent.futures import Future as CFuture
    from tornado.util import DummyExecutor as DE
    from concurrent.futures import wait

    def test_normal(future: Future, fn: Callable[..., Any]) -> None:
        res = fn()
        future_set_result_unless_cancelled(future, res)

    def test_error(future: Future, fn: Callable[..., Any]) -> None:
        try:
            fn()
        except Exception:
            future_set_exc_info(future, sys.exc_info())

    def test_add(a: int, b: int) -> int:
        time.sleep(0.1)
        return a + b


# Generated at 2022-06-22 03:37:55.410376
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise RuntimeError
    except RuntimeError as e:
        exc_info = sys.exc_info()

    future = Future()
    future_set_exc_info(future, exc_info)

    assert future.exception() is e
    assert isinstance(future.exception(), RuntimeError)



# Generated at 2022-06-22 03:38:05.489677
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import pytest
    from app.test.util.test_util import util_test

    # Test with a function that returns normally
    future1 = dummy_executor.submit(util_test, "string")
    assert future1.result() == True

    # Test with a function that throws an exception
    future2 = dummy_executor.submit(util_test, 1)
    with pytest.raises(Exception):
        future2.result()

    # Validate returned future was created with no exception raised
    future3 = dummy_executor.submit(util_test, "string")
    assert future3.result() == True
    
    # Test with a function that throws an exception
    future4 = dummy_executor.submit(util_test, 1)
    with pytest.raises(Exception):
        future4.result()