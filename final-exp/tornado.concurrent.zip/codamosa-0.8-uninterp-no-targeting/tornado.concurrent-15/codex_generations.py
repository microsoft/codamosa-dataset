

# Generated at 2022-06-22 03:28:12.249601
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.ioloop
    executor = DummyExecutor()
    loop = tornado.ioloop.IOLoop.current()
    loop.run_sync(lambda: executor.submit(lambda: 1))

# Generated at 2022-06-22 03:28:14.210322
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    test_executor = DummyExecutor()
    test_executor.shutdown()
    pass

# Generated at 2022-06-22 03:28:15.274932
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("error")

# Generated at 2022-06-22 03:28:25.509793
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(None)
    assert f.done()
    assert g.done()

    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(Exception())
    assert f.done()
    assert g.done()

    f = Future()
    g = Future()
    chain_future(f, g)
    g.cancel()
    f.set_result(None)
    assert f.done()
    assert g.cancelled()

    f = Future()
    g = Future()
    chain_future(f, g)
    f.cancel()
    assert f.cancelled()
    assert not g.done()

# Generated at 2022-06-22 03:28:27.656726
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(futures.Future())
    assert not is_future(object())
    assert not is_future(1)

# Generated at 2022-06-22 03:28:38.624674
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()
    main_future = Future()  # type: Future[int]
    sub_future = Future()  # type: Future[int]

    def set_sub_future():
        sub_future.set_result(42)

    chain_future(sub_future, main_future)
    io_loop.add_callback(set_sub_future)
    io_loop.add_future(main_future, lambda f: io_loop.stop())
    io_loop.start()

    assert main_future.result() == 42
    assert not main_future.cancelled()
    assert sub_future.done()
    assert not sub_future.cancelled()



# Generated at 2022-06-22 03:28:45.519944
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import concurrent.futures
    import threading
    import time
    import tornado.concurrent
    def foo():
        return 'hello'
    def callback(f: concurrent.futures.Future):
        time.sleep(1)
        assert f.result() == 'hello'

    future: concurrent.futures.Future = dummy_executor.submit(foo)
    future.add_done_callback(callback)
    time.sleep(0.1)
    assert future.done()


# Generated at 2022-06-22 03:28:49.239942
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())  # type: ignore

# Generated at 2022-06-22 03:28:59.537771
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    called = []
    ioloop = IOLoop.current()

    def check_done(future: Future) -> None:
        called.append(True)
        ioloop.stop()

    future = Future()
    future_add_done_callback(future, check_done)
    future.set_result(42)
    ioloop.start()
    assert called == [True], called

    future = Future()
    future.set_result(42)
    future_add_done_callback(future, check_done)
    ioloop.start()
    assert called == [True, True], called

    future = futures.Future()
    future_add_done_callback(future, check_done)
    future.set_result(42)
    ioloop.start()

# Generated at 2022-06-22 03:29:01.656548
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Set the max_workers to 0 to disable threadpool.
    executor = futures.ThreadPoolExecutor(max_workers=0)
    pass



# Generated at 2022-06-22 03:29:05.899896
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-22 03:29:17.724804
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    @asyncio.coroutine
    def test_cancel_before_set_result():
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, 10)
        assert future.cancelled()
        assert future.result() is None

    @asyncio.coroutine
    def test_set_result_before_cancel():
        future = Future()
        future_set_result_unless_cancelled(future, 10)
        future.cancel()
        assert future.cancelled() is False
        assert future.result() == 10

    @asyncio.coroutine
    def test_cancel_after_set_result():
        future = Future()
        future_set_result_unless_cancelled(future, 10)
        assert future.result()

# Generated at 2022-06-22 03:29:30.819631
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    @asyncio.coroutine
    def check_future_set_result_unless_cancelled():
        future = asyncio.Future()
        future_set_result_unless_cancelled(future, 1)
        assert future.done()
        assert future.result() == 1

        future = asyncio.Future()
        future_set_result_unless_cancelled(future, 1)
        future.set_result(2)
        assert future.done()
        assert future.result() == 2

        future = asyncio.Future()
        future.cancel()
        future_set_result_unless_cancelled(future, 1)
        assert future.cancelled()

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete

# Generated at 2022-06-22 03:29:37.486665
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.done()
    assert f.cancelled()
    try:
        f.result()
        assert False, "we should have received an exception"
    except Exception:
        pass

# Generated at 2022-06-22 03:29:40.728642
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit(lambda: 1) is not None
    assert dummy_executor.submit(lambda: 1).result() == 1

# Generated at 2022-06-22 03:29:41.767205
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:29:54.326140
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.concurrent import return_future
    import unittest

    @return_future
    @run_on_executor
    def func(arg, future=None):
        future.set_result(arg)

    class ReturnFutureTest(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(2)

        def tearDown(self):
            self.executor.shutdown()

        def test_return_future(self):
            result = []

            @return_future
            def f(arg, callback):
                result.append(arg)
                callback()

            f(42)
            self.assertEqual(result, [42])

        def test_return_result_future(self):
            result = []


# Generated at 2022-06-22 03:30:01.148573
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()

    # No exception is raised when setting the exception of a non-cancelled
    # Future
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    # An exception *is* raised when setting the exception of a cancelled Future
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())



# Generated at 2022-06-22 03:30:03.176911
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda : 1)


# Generated at 2022-06-22 03:30:03.961370
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError('test')

# Generated at 2022-06-22 03:30:09.657326
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.concurrent import futures
    def myfunc(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(myfunc, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-22 03:30:13.929573
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert not future.cancelled()
    assert future.done()
    assert future.result() == "foo"
    future2 = Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2, "bar")
    assert future2.cancelled()
    assert not future2.done()

# Generated at 2022-06-22 03:30:16.702992
# Unit test for function is_future
def test_is_future():
    import types
    is_future(Future())
    # type: ignore
    is_future(futures.Future())  # type: ignore

# Generated at 2022-06-22 03:30:18.232416
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())



# Generated at 2022-06-22 03:30:22.064896
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore  # noqa
    try:
        raise ReturnValueIgnoredError('some message')
    except ReturnValueIgnoredError:
        pass
    else:
        raise Exception('ReturnValueIgnoredError() failed to raise exception')

# Generated at 2022-06-22 03:30:22.967454
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-22 03:30:34.709260
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # The most common case with arguments, for the common case of
    # exceptions.  If this test fails in a way that isn't caught by
    # other tests, we'd get a strange-looking error.
    exc_info = (Exception, Exception("message"), None)
    future = Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    assert str(future.exception()) == "message"

    # Just the exception class.
    exc_info = (Exception, None, None)
    future = Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None

    # No arguments.
    exc_info = (None, None, None)
    future = Future()

# Generated at 2022-06-22 03:30:40.383313
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    loop.run_until_complete(f2)
    assert f2.result() == 42

# Generated at 2022-06-22 03:30:41.633809
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummyexecutor = DummyExecutor()
    dummyexecutor.shutdown(wait=True)


# Generated at 2022-06-22 03:30:47.703224
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    if hasattr(asyncio, "Future"):
        def test_future(future):
            # type: (Future[_T]) -> None
            future_set_exc_info(future, (ValueError, ValueError("error"), None))
            assert future.exception() is not None
        future = asyncio.Future()  # type: Future[_T]
        test_future(future)

        future = futures.Future()
        test_future(future)

# Generated at 2022-06-22 03:30:54.190841
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda: 'Hello, world!')
    assert future.result() == 'Hello, world!'

# Generated at 2022-06-22 03:30:58.909359
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == 'foo'
    future_set_result_unless_cancelled(future, "bar") # Should not raise
    assert future.result() == 'foo'

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()

# Generated at 2022-06-22 03:31:06.735556
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    # test: set result for Future which is not cancelled
    future_set_result_unless_cancelled(f, True)
    assert f.done() and f.result() is True
    # test: don't set result for Future which is cancelled
    f = Future()
    f.set_result(True)
    f.cancel()
    future_set_result_unless_cancelled(f, False)
    assert f.done() and f.result() is True



# Generated at 2022-06-22 03:31:07.900681
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass


# Generated at 2022-06-22 03:31:14.500816
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

# Generated at 2022-06-22 03:31:24.134013
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import unittest.mock
    import concurrent.futures
    import functools

    from tornado.ioloop import IOLoop
    from tornado.concurrent import TracebackFuture

    class TestCase(unittest.TestCase):
        def setUp(self):
            super().setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(10)
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()
            self.executor.shutdown()
            super().tearDown()

    class TestObject(TestCase):
        @run_on_executor
        def decorated(self):
            pass


# Generated at 2022-06-22 03:31:28.102350
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async def coroutine():
        print('hello, world')
    for i in range(100):
        dummy_executor.submit(coroutine)


if __name__ == '__main__':
    test_DummyExecutor_submit()

# Generated at 2022-06-22 03:31:32.019826
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise ValueError
    except:
        exc_info = sys.exc_info()
    future = Future()
    future_set_exc_info(future, exc_info)
    exc = future.exception()
    assert exc is exc_info[1]

# Generated at 2022-06-22 03:31:38.753601
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = asyncio.Future()
    f2 = asyncio.Future()
    try:
        raise ValueError("x")
    except:
        try:
            exc_info = sys.exc_info()
            future_set_exc_info(f1, exc_info)
        finally:
            del exc_info
    future_set_exc_info(f2, sys.exc_info())
    assert isinstance(f1.exception(), ValueError)
    assert isinstance(f2.exception(), ValueError)
    f1.cancel()
    assert f1.cancelled()
    future_set_exc_info(f1, sys.exc_info())
    assert f1.cancelled()

# Generated at 2022-06-22 03:31:42.568507
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b, c=3):
        return a + b + c

    f = dummy_executor.submit(func, 1, 2)
    assert f.result() == 6
    f = dummy_executor.submit(func, 1, 2, c=10)
    assert f.result() == 13


# Generated at 2022-06-22 03:32:39.960875
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    assert isinstance(get_future_exception(""), Exception)
    assert isinstance(get_future_exception("asdf"), Exception)
    assert get_future_exception("asdf").args == ("asdf",)
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
        future = Future()
        future_set_exc_info(future, exc_info)
        assert exc_info[1].__class__ is future.exception().__class__
        assert exc_info[1].args == future.exception().args



# Generated at 2022-06-22 03:32:47.931958
# Unit test for function future_set_exc_info
def test_future_set_exc_info():

    # Test that exc_info is set as the result of a future
    future = Future()
    try:
        raise Exception()
    except Exception:
        exc_info = sys.exc_info()
        future_set_exc_info(future, exc_info)

    # Test that the future's result is the exc_info
    assert future.exception() == exc_info[1]

# Generated at 2022-06-22 03:32:52.605543
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)

    f.cancel()
    assert f.cancelled()

    future_set_result_unless_cancelled(f, 24)
    assert f.cancelled()

# Generated at 2022-06-22 03:33:01.227742
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    a = Future()
    b = Future()
    result1 = []
    result2 = []

    def _callback1(a):
        result1.append(a.result())
    future_add_done_callback(a, _callback1)

    def _callback2(b):
        result2.append(b.result())
    future_add_done_callback(b, _callback2)
    a.set_result(1)
    b.set_result(2)
    assert result1 == [1]
    assert result2 == [2]



# Generated at 2022-06-22 03:33:11.407029
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    ex = DummyExecutor()
    def foo(x: int, y: int) -> int:
        return x + y

    future = ex.submit(foo, 10, 20)
    assert future.done()
    assert future.result() == 30

    future = ex.submit(foo, 10, y=20)
    assert future.done()
    assert future.result() == 30

    def foo(x: int, h: int, *args: int, y: int, **kwargs: int) -> int:
        return x + y + h + sum(args) + sum(kwargs.values())
    future = ex.submit(foo, 10, 20, y=30)
    assert future.done()
    assert future.result() == 80

# Generated at 2022-06-22 03:33:21.009569
# Unit test for function run_on_executor
def test_run_on_executor():
    import time

    class Counter(object):
        def __init__(self):
            self.count = 0

        @run_on_executor
        def increment(self):
            # This would normally block the IOLoop, so run it on the
            # executor instead.
            time.sleep(0.01)
            self.count += 1

    counter = Counter()
    counter.increment()
    counter.increment()
    time.sleep(0.02)
    # Value should be 2, but not guaranteed to be written yet.
    assert counter.count < 4
    time.sleep(0.1)
    # Value should now be 2.
    assert counter.count == 2

# Generated at 2022-06-22 03:33:26.257836
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def check(future, value, callback_arg):
        assert isinstance(future, Future)
        future.set_result(1)
        assert callback_arg is future
        assert value == 1
    future = Future()
    future_add_done_callback(future, functools.partial(check, future, future.result()))



# Generated at 2022-06-22 03:33:27.181295
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    x = ReturnValueIgnoredError()

# Generated at 2022-06-22 03:33:30.829916
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future(object())
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-22 03:33:35.905217
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def fn(a, b):
        return a + b
    executor = DummyExecutor()
    future = executor.submit(fn, 5, 4)
    assert future.result() == 9

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-22 03:35:02.644070
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    e = DummyExecutor()
    assert e.__class__ == DummyExecutor

if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-22 03:35:05.026255
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    assert isinstance(d, DummyExecutor)
    assert isinstance(d, futures.Executor)

    assert d.submit(print, "hello")
    d.shutdown()

# Generated at 2022-06-22 03:35:11.296212
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest.mock import Mock

    future = asyncio.Future()
    exc: BaseException = Exception("Hello")
    future_set_exception_unless_cancelled(future, exc)
    mock_logger = Mock()
    app_log.error = mock_logger
    future_set_exception_unless_cancelled(future, exc)
    assert mock_logger.called
    assert future.exception() == exc

# Generated at 2022-06-22 03:35:18.613253
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(f, exc)
    assert f.exception() is exc

    f = Future()
    exc = Exception()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc)
    assert f.exception() is None



# Generated at 2022-06-22 03:35:24.659520
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def f():
        future = Future()
        future_set_exception_unless_cancelled(future, RuntimeError("test"))
        return future
    future = asyncio.ensure_future(f())
    assert future.exception() == RuntimeError("test")
    future = Future()
    assert not future.cancelled()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() == RuntimeError("test")
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is None

# Generated at 2022-06-22 03:35:27.084830
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())



# Generated at 2022-06-22 03:35:33.076206
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    chain = Future()
    f.add_done_callback(chain_future, chain)
    assert chain.done() and chain.result() is f.result()
    chain = Future()
    f = Future()
    future_add_done_callback(f, chain_future, chain)
    assert not chain.done()
    f.set_result(42)
    assert chain.result() == 42



# Generated at 2022-06-22 03:35:45.618057
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """Test future_set_exception_unless_cancelled effectively ignores
    exceptions on cancelled Futures."""
    import unittest
    from tornado.log import gen_log

    class FutureTest(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            # Clear the log to ensure that the test logs correctly.
            gen_log.handlers = []
            future = Future()
            future.cancel()
            future_set_exception_unless_cancelled(future, ValueError())
            self.assertTrue(len(gen_log.handlers) == 1)
            self.assertTrue(isinstance(gen_log.handlers[0].record.exc_info[1], ValueError))
    unittest.main()

# Generated at 2022-06-22 03:35:53.750349
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    IOLoop.clear_current()

    # example class
    class Foo:
        def __init__(self) -> None:
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()

        @run_on_executor
        def foo(self) -> int:
            return 42

    foo = Foo()
    f = foo.foo()
    assert f.result() == 42



# Generated at 2022-06-22 03:35:55.198992
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda : 1)
    dummy_executor.shutdown()