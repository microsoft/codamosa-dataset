

# Generated at 2022-06-22 03:28:07.817759
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: nocover
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:28:20.487160
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.concurrent import Future
    from concurrent import futures
    import unittest
    from unittest import mock

    class CallbackCounter(unittest.TestCase):
        def __init__(self):
            self.mock = mock.MagicMock()
            self.mockType = mock.MagicMock(return_value=self.mock)
            self.mock.callback = mock.Mock()

        def __call__(self, future):
            self.mockType(future=future)
            self.mock.callback(future)

    def _assert_future_callback(future):
        callbackCounter = CallbackCounter()
        future_add_done_callback(future, callbackCounter)
        self.assertEqual(callbackCounter.mockType.call_count, 1)
        self.assertEqual

# Generated at 2022-06-22 03:28:25.542203
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    asyncio_future = Future()  # type: Future[int]
    concurrent_future = futures.Future()  # type: futures.Future[int]

    chain_future(concurrent_future, asyncio_future)
    chain_future(asyncio_future, concurrent_future)
    asyncio_future.set_result(42)
    assert asyncio_future.result() == 42
    assert concurrent_future.result() == 42



# Generated at 2022-06-22 03:28:33.178206
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class Test(object):
        executor = dummy_executor

        @run_on_executor
        def run_test(self):
            return 'test'

    test = Test()
    result = unittest.mock.Mock()

    def assert_future(f):
        assert f.result() == 'test'
        result.assert_called_once_with(f)

    test.run_test().add_done_callback(result)
    assert_future(test.run_test())
    assert_future(test.run_test())
    assert_future(test.run_test())

# Generated at 2022-06-22 03:28:37.501236
# Unit test for function chain_future
def test_chain_future():
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut1.set_result(42)
    assert fut2.result() == 42



# Generated at 2022-06-22 03:28:40.779737
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception()
    except Exception:
        future_set_exc_info(f, sys.exc_info())

    assert f.exc_info() is not None

# Generated at 2022-06-22 03:28:47.919896
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = DummyExecutor()
    print(a)
    print(a.submit(functools.partial(int, base=8), '123'))
    print(a.submit(functools.partial(int, base=16), '123'))
    # print(a.map(functools.partial(int, base=2), ['1', '10', '111', '1111']))
    b = dummy_executor
    print(b)
    print(b.submit(functools.partial(int, base=8), '123'))
    print(b.submit(functools.partial(int, base=16), '123'))


# Generated at 2022-06-22 03:28:53.203282
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    def func(future: Future, arg: str) -> int:
        return len(arg)

    class MyClass(object):
        executor = futures.ThreadPoolExecutor(2)

    i = MyClass()
    i.run = run_on_executor(func)
    print(i.run("hello"))

# Generated at 2022-06-22 03:28:55.230025
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 5)
    assert f.result() == 5
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled()



# Generated at 2022-06-22 03:28:57.949389
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    @gen.coroutine
    def callback(future):
        pass
    f1 = Future()
    future_add_done_callback(f1, callback)
    f2 = Future()
    f2.set_result(1)
    future_add_done_callback(f2, callback)


# Generated at 2022-06-22 03:29:12.491208
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from concurrent.futures import Future

    # This is an example of handling future that is cancelled but may
    # still contain some meaningful result, for example the result
    # between the moment of the cancellation and the moment the
    # exception is raised.
    future = Future()
    exception = Exception()

    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is None
    assert future.cancelled() is False

    future.set_result(None)
    assert future.result() is None
    assert future.cancelled() is True

    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is exception
    assert future.cancelled() is True

# Generated at 2022-06-22 03:29:24.707901
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado import gen

    class MyTestCase(unittest.TestCase):
        def check_result(self, future, arg):
            self.assertEqual(future.result(), arg)

        def test(self):
            class MyFoo:
                executor = dummy_executor

                @run_on_executor
                def method1(self, arg):
                    return arg

                @run_on_executor(executor="executor")
                def method2(self, arg):
                    return arg

                @run_on_executor(executor="_thread_pool")
                def method3(self, arg):
                    return arg

            foo = MyFoo()
            foo._thread_pool = dummy_executor
            foo.method3.__doc__ = "method3 docstring"
           

# Generated at 2022-06-22 03:29:26.781574
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    d.shutdown()

# Generated at 2022-06-22 03:29:27.430317
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert True

# Generated at 2022-06-22 03:29:28.876917
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    l = []
    future_add_done_callback(f, lambda f: l.append(1))
    assert l == []
    f.set_result(None)
    assert l == [1]



# Generated at 2022-06-22 03:29:41.513982
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.platform.asyncio import to_asyncio_future

    f = asyncio.Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = asyncio.Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()

    f = to_asyncio_future(futures.Future())
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = to_asyncio_future(futures.Future())
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()

# Generated at 2022-06-22 03:29:44.752082
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def f():
        pass
    x = DummyExecutor()
    assert isinstance(x, futures.Executor)
    assert isinstance(x.submit(f), futures.Future)
    x.shutdown()

# Generated at 2022-06-22 03:29:55.074764
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Use Future here instead of asyncio.Future to avoid asyncio-specific
    # checks
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 2)
    assert future.cancelled()
    assert future.result() is None
    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 3)
    assert future.cancelled()
    assert future.result() is None

# Generated at 2022-06-22 03:30:03.643493
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def test_fn():
        raise Exception("test")
    # Test with asyncio.Future
    future = Future()
    try:
        test_fn()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    # Test with concurrent.futures.Future
    future = futures.Future()
    try:
        test_fn()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

# Generated at 2022-06-22 03:30:12.477303
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from concurrent.futures import Future
    from concurrent.futures.thread import ThreadPoolExecutor
    from tornado import gen
    import functools
    import time
    import tornado.ioloop


# Generated at 2022-06-22 03:30:21.405659
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-22 03:30:32.185758
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()

    def handle_future(future: Future) -> None:
        io_loop.stop()

    def set_result(future: Future, result: str) -> None:
        future.set_result(result)

    future = Future()
    chained_future = Future()
    chain_future(future, chained_future)
    assert (not chained_future.done())
    future_add_done_callback(chained_future, handle_future)
    io_loop.add_callback(functools.partial(set_result, future, "test"))
    io_loop.start()
    assert future.result() == "test"
    assert chained_future.result() == "test"



# Generated at 2022-06-22 03:30:44.749855
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    f = Future()  # type: Future
    future_set_exc_info(f, sys.exc_info())
    f2 = Future()  # type: Future
    f2.set_exception(Exception())
    future_set_exc_info(f2, sys.exc_info())


if hasattr(futures.Future, "get_loop"):
    future_get_loop = futures.Future.get_loop  # type: ignore
else:
    def future_get_loop(future: "Future") -> "asyncio.AbstractEventLoop":
        """Return the `.IOLoop` for a `.Future` object.

        This is a compatibility wrapper for ``asyncio.Future.get_loop``,
        which was added in Python 3.6.
        """
       

# Generated at 2022-06-22 03:30:52.236852
# Unit test for function run_on_executor
def test_run_on_executor():
    from concurrent.futures import ThreadPoolExecutor

    class MyThreadPoolExecutor(ThreadPoolExecutor):
        def submit(
            self, fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> futures.Future[_T]:
            future = super().submit(fn, *args, **kwargs)
            future.set_result("done")
            return future

    class Foo(object):
        def __init__(self):
            self._executor = MyThreadPoolExecutor()

        @run_on_executor
        def bar(self, arg):
            return arg

    foo = Foo()
    assert foo.bar(42).result() == "done"
    foo._executor.shutdown()

# Generated at 2022-06-22 03:30:52.885705
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-22 03:30:55.526064
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-22 03:30:59.817498
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        assert future.result() == 'result'
    future = Future()
    future_add_done_callback(future, callback)
    future.set_result('result')

test_future_add_done_callback()

# Generated at 2022-06-22 03:31:05.188057
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "value")
    assert future.result() == "value"
    future_set_result_unless_cancelled(future, "new value")
    assert future.result() == "value"

# Generated at 2022-06-22 03:31:10.697112
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    exc_info = (type(exc), exc, None)
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    future_set_exc_info(future, exc_info)
    assert future.exception() is exc
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert not future.cancelled()

# Generated at 2022-06-22 03:31:13.225846
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda x: x + 1, 3)
    dummy_executor.shutdown()

# Generated at 2022-06-22 03:31:36.296776
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test

    class TestFutureSetException(AsyncTestCase):

        @gen_test
        def test_future_set_exception(self):
            future = Future()
            future_set_exception_unless_cancelled(future, Exception('error'))

# Generated at 2022-06-22 03:31:41.298761
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    called = []

    def callback(f):
        called.append(f)
    future_add_done_callback(future, callback)
    assert not called
    future.set_result(42)
    assert called == [future]
    called[:] = []
    future = Future()
    future_add_done_callback(future, callback)
    assert called == [future]



# Generated at 2022-06-22 03:31:42.243567
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown(wait=True)

# Generated at 2022-06-22 03:31:43.928726
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def test():
        return 10
    assert dummy_executor.submit(test) == 10

# Generated at 2022-06-22 03:31:46.949362
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 100)
    assert f.cancelled()
    assert not f.done()
    assert not f.result()



# Generated at 2022-06-22 03:31:48.900591
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:  # pragma: no cover
        pass

# Generated at 2022-06-22 03:31:53.253580
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    dummy_e = DummyExecutor()
    assert isinstance(dummy_e, futures.Executor)
    assert not dummy_e.shutdown(wait=True)

# Generated at 2022-06-22 03:31:56.997410
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    future = Future()
    exc = RuntimeError()
    future_set_exc_info(future, (type(exc), exc, None))
    try:
        future.result()
        assert False, "should have raised exception"
    except RuntimeError:
        pass



# Generated at 2022-06-22 03:32:03.604364
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def raise_it():
        raise Exception("test")

    future = Future()
    try:
        raise_it()
    except Exception as e:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is e
    future = Future()
    try:
        raise_it()
    except Exception as e:
        future_set_exc_info(future, (None, e, None))
    assert future.exception() is e
    try:
        future_set_exc_info(future, (None, None, None))
    except Exception as e:
        assert isinstance(e, Exception)
    else:
        raise Exception("did not get expected exception")



# Generated at 2022-06-22 03:32:10.651767
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Instance of class DummyExecutor
    dummy_executor = DummyExecutor()
    # Function check
    def f(a, b):
        return a * b
    # Submit the function f with parameters 2 and 3
    future = dummy_executor.submit(f, 2, 3)
    assert isinstance(future, Future)
    assert future.result() == 6
    # Submit the function f with parameter 5 and 10
    future = dummy_executor.submit(f, 5, 10)
    assert future.result() == 50


# Generated at 2022-06-22 03:32:49.632369
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    future = Future()
    exc = RuntimeError()
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is exc
    future = Future()
    future.set_result(None)
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is exc

# Generated at 2022-06-22 03:32:59.330820
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest import mock

    class TestException(Exception):
        pass

    f = Future()
    future_set_exception_unless_cancelled(f, TestException('message'))
    assert isinstance(f.exception(), TestException)
    f = Future()
    f.cancel()
    with mock.patch('tornado.util.logging') as mock_logging:
        future_set_exception_unless_cancelled(f, TestException('message'))
    mock_logging.error.assert_called_with(
        'Exception after Future was cancelled',
        exc_info=mock.ANY,
    )

# Generated at 2022-06-22 03:33:09.983894
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    # exception raised if future is set_result without cancelled
    try:
        future_set_result_unless_cancelled(future, 2)
    except Exception as e:
        assert isinstance(e, asyncio.InvalidStateError)
    future.cancel()
    # exception raised if future is set_result with cancelled
    try:
        future_set_result_unless_cancelled(future, 2)
    except Exception as e:
        assert isinstance(e, asyncio.InvalidStateError)
    future2 = Future()
    try:
        future_set_result_unless_cancelled(future2, 2)
    except Exception as e:
        assert isinstance(e, asyncio.InvalidStateError)
    future

# Generated at 2022-06-22 03:33:21.644456
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    from tornado.log import gen_log

    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    future_set_result_unless_cancelled(future, "test")
    future.set_exception(Exception())

    assert future.done()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.done()
    assert len(gen_log.app_log.handlers) == 1
    assert isinstance(gen_log.app_log.handlers[0], unittest.mock.Mock)

# Generated at 2022-06-22 03:33:27.523166
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_exception_unless_cancelled(future, TypeError("foo"))
    assert future.result() is None
    assert future.exception() is None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, TypeError("foo"))
    assert future.done()

# Generated at 2022-06-22 03:33:35.190731
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test

    class Example(object):
        executor = dummy_executor

        @gen_test
        def test(self):
            future = self.foo()

# Generated at 2022-06-22 03:33:40.609814
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None

    def timer_callback(_: Any) -> None:
        future.set_exception(ValueError("value is not 42"))

    @gen.coroutine
    def test_loop() -> None:
        yield gen.sleep(0.01)
        global future
        future = Future()
        future.cancel()

    future = None
    io_loop = IOLoop()
    io_loop.add_callback(test_loop)
    io_loop.call_later(0.02, timer_callback, io_loop)
    io_loop.start()
    assert future.exception() is None

# Generated at 2022-06-22 03:33:52.175819
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class Future(asyncio.Future):
        def __init__(self, loop=None):
            (exctype, value, tb) = sys.exc_info()
            self.exc_info = (exctype, value, tb)
            asyncio.Future.__init__(self, loop=loop)

        def exc_info(self):
            return self.exc_info

    def yield_future(repeat=25):
        """Coroutine that yields a future,
        used for testing future completion
        in a synchronous manner.
        """
        for i in range(repeat):
            loop = asyncio.get_event_loop()
            future = Future(loop=loop)
            future_set_exc_info(future, sys.exc_info())
            yield future


# Generated at 2022-06-22 03:34:00.983222
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    # TODO: if this pattern is repeated elsewhere, it should be
    # factored into something like tornado.testing.mock_future.
    f = Future()
    assert not f.done()
    mock_callback = MockCallback()
    future_add_done_callback(f, mock_callback)
    assert mock_callback.call_count == 0
    f.set_result(42)
    assert mock_callback.call_count == 1
    assert mock_callback.args == (f,)
    assert mock_callback.kwargs == {}



# Generated at 2022-06-22 03:34:08.222176
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test error"))
    if future.cancelled():
        pass
    else:
        x = future.exception()
        assert isinstance(x, RuntimeError)
        assert x.args == ("test error",)
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test error"))

# Generated at 2022-06-22 03:35:08.425266
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor.shutdown()

# Generated at 2022-06-22 03:35:11.070138
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    assert executor.shutdown() == None


# Generated at 2022-06-22 03:35:22.551790
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def handle_exception(future: "Future", exc_info: Tuple[Any, BaseException, Any]):
        assert exc_info[1] is exception

    future = Future()
    exception = RuntimeError()
    future_set_exception_unless_cancelled(future, exception)
    assert isinstance(future.exception(), RuntimeError)

    future = Future()
    exception = RuntimeError()
    future.cancel()
    future_set_exception_unless_cancelled(future, exception)
    assert isinstance(future.exception(), RuntimeError)

    future = Future()
    exception = RuntimeError()
    future.cancel()
    future_add_done_callback(future, handle_exception)
    future_set_exception_unless_cancelled(future, exception)

# Generated at 2022-06-22 03:35:23.864600
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())
    assert is_future(futures.Future())

# Generated at 2022-06-22 03:35:34.319071
# Unit test for function run_on_executor
def test_run_on_executor():
    import functools
    import unittest

    from tornado.platform.asyncio import AsyncIOLoop
    from tornado.httpserver import HTTPServer
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port, ExpectLog
    from tornado import web

    class MyRequestHandler(web.RequestHandler):
        @run_on_executor
        def get(self):
            self.write('Hello, world')

    class MyTest(AsyncHTTPTestCase):
        def get_app(self):
            return web.Application(
                [
                    ('/', MyRequestHandler),
                ]
                # For tests to use run_on_executor, they must pass
                # in a custom executor
            )

    # Can't run this test under the IOLoopTestCase, because
    # it uses AsyncIOL

# Generated at 2022-06-22 03:35:46.999068
# Unit test for function run_on_executor
def test_run_on_executor():
    class Obj:
        executor = dummy_executor

        @run_on_executor
        def func(self):
            return 1

    obj = Obj()
    future = obj.func()
    assert future.result() == 1

    assert dummy_executor.submit.call_count == 1
    args, kwargs = dummy_executor.submit.call_args
    assert args == (obj.func, obj)
    assert kwargs == {}

    # keyword arguments
    class Obj:
        _thread_pool = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def func(self):
            return 1

    obj = Obj()
    future = obj.func()
    assert future.result() == 1
    assert dummy_executor.submit.call_count == 1
   

# Generated at 2022-06-22 03:35:52.802829
# Unit test for function is_future
def test_is_future():
    test_passed = True
    try:
        assert is_future(None) == False
        assert is_future(futures.Future()) == True
        assert is_future(Future()) == True
    except:
        test_passed = False
    if not test_passed:
        raise ValueError('test_is_future() failed')

# Generated at 2022-06-22 03:35:56.125602
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    try:
        raise ReturnValueIgnoredError('error')
    except ReturnValueIgnoredError as e:
        assert str(e) == 'error'

# Generated at 2022-06-22 03:35:59.970724
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("error"))



# Generated at 2022-06-22 03:36:10.773440
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import traceback
    try:
        # noinspection PyStatementEffect
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    future = Future()
    future_set_exc_info(future, exc_info)
    exc_info_tb = future.get_stack(as_string=True)
    exc_info_full = traceback.format_exception(*exc_info)
    assert exc_info_tb[: 4] == exc_info_full[: 4]
    assert "tornado/test/concurrent_test.py" in exc_info_tb[4]
    assert "tornado/util.py" in exc_info_tb[4]



# Generated at 2022-06-22 03:37:11.922150
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-22 03:37:13.914505
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    e = ReturnValueIgnoredError('foo')
    assert str(e) == 'foo'

# Generated at 2022-06-22 03:37:19.496425
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    with pytest.raises(Exception) as exc_info:
        future_set_exc_info(f, sys.exc_info())
    assert exc_info.type == Exception
    assert exc_info.value.args[0] == "future_set_exc_info called with no exception"
    f = Future()
    exc = ZeroDivisionError()
    future_set_exc_info(f, sys.exc_info())
    with pytest.raises(ZeroDivisionError) as exc_info:
        f.result()
    assert exc_info.type == ZeroDivisionError
    assert exc_info.value is exc



# Generated at 2022-06-22 03:37:20.943997
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()


# Generated at 2022-06-22 03:37:28.120973
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError("fail"))
    try:
        f2.result()
        raise Exception("expected a failure")
    except ValueError:
        pass

# Generated at 2022-06-22 03:37:35.329431
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    with pytest.raises(RuntimeError):
        f2.result()



# Generated at 2022-06-22 03:37:39.397228
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 10)
    assert f.cancelled()
    f = Future()
    future_set_result_unless_cancelled(f, 10)
    assert f.done()


# Generated at 2022-06-22 03:37:41.572984
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = DummyExecutor()
    b = a.submit(lambda x:x,2)
    assert b.result() == 2

# Generated at 2022-06-22 03:37:48.995978
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    l = []

    def callback(arg):
        l.append(arg)

    future_add_done_callback(future, callback)
    future_add_done_callback(future, lambda _: l.append(3))
    future_add_done_callback(future, lambda _: l.append(6))
    assert l == []
    future.set_result(None)
    assert l == [future, 3, 6]



# Generated at 2022-06-22 03:37:53.286735
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    future = DummyExecutor().submit(lambda x: x, 1)
    assert future.done()
    assert future.result() == 1
    assert future.done()
    assert future.result() == 1
    assert future.done()
    assert future.result() == 1
