

# Generated at 2022-06-26 07:49:01.440135
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    if f.cancelled():
        pass
    else:
        f.set_result("A")
    f.cancel()
    try:
        f.set_result("B")
    except asyncio.InvalidStateError:
        pass


# Generated at 2022-06-26 07:49:06.161831
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor(executor="dummy_executor_0")
    def foo():
        pass

    try:
        foo()
    except AttributeError:
        pass



# Generated at 2022-06-26 07:49:15.323393
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def foo(self):
        pass

    assert foo.__name__ == 'foo'

    class Bar(object):
        executor = dummy_executor
        @run_on_executor
        def foo(self):
            pass

    b = Bar()
    assert b.foo.__name__ == 'foo'

    class Baz(object):
        @run_on_executor(executor='_thread_pool')
        def foo(self):
            pass

    b = Baz()
    assert b.foo.__name__ == 'foo'



# Generated at 2022-06-26 07:49:27.996643
# Unit test for function run_on_executor
def test_run_on_executor():
    # Test 1: default case
    dummy_executor_1 = DummyExecutor()
    a = 3
    def foo(self): # type: ignore
        return self
    res = foo(a)
    assert res == a
    return res

    # Test 2: with callback
    def foo(self): # type: ignore
        pass
    callback = lambda: None
    assert foo(callback) == callback

    # Test 3: with args and kwargs
    a = 2
    b = 3
    dummy_executor_2 = DummyExecutor()
    def foo(self, w, x, y=4, z=None): # type: ignore
        pass
    foo(a, b, y=5, z=6)

    # Test 4: with different executor name
    executor_name = '_thread_pool'

# Generated at 2022-06-26 07:49:41.088463
# Unit test for function chain_future
def test_chain_future():
    dummy_future_0 = Future()
    dummy_future_1 = Future()

    chain_future(dummy_future_0, dummy_future_1)
    dummy_future_0.done()
    dummy_future_1.done()
    dummy_future_0.set_exception(None)
    dummy_future_1.set_exception(None)
    dummy_future_0.set_result(None)
    dummy_future_1.set_result(None)
    dummy_future_0.cancelled()
    dummy_future_1.cancelled()
    dummy_future_0.result()
    dummy_future_1.result()
    dummy_future_0.exception()
    dummy_future_1.exception()
    dummy_future_0.add_done_callback(None)


# Generated at 2022-06-26 07:49:46.778036
# Unit test for function chain_future
def test_chain_future():

    future = Future()
    assert future.done() == False

    future.set_result('TEST')

    assert future.done() == True
    assert future.result() == 'TEST'



# Generated at 2022-06-26 07:49:51.561820
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)
    return f2



# Generated at 2022-06-26 07:49:56.374665
# Unit test for function chain_future
def test_chain_future():
    def test_callback(future):
        assert future.result() == 1
        print("chain_future callback function test done")
    
    f = Future()
    dummy_executor = DummyExecutor()
    f2 = dummy_executor.submit(add_1, f)
    f.set_result(0)
    f2.add_done_callback(test_callback)


# Generated at 2022-06-26 07:50:02.854409
# Unit test for function chain_future
def test_chain_future():
    global future_set_result_unless_cancelled
    global chain_future
    dummy_executor_1 = DummyExecutor()
    future_set_result_unless_cancelled = test_chain_future.future_set_result_unless_cancelled
    chain_future = test_chain_future.chain_future
    dummy_executor_2 = DummyExecutor()
    future_set_result_unless_cancelled = test_chain_future.future_set_result_unless_cancelled
    chain_future = test_chain_future.chain_future


# Generated at 2022-06-26 07:50:04.290212
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    test_case_0()

# Generated at 2022-06-26 07:50:13.038831
# Unit test for function chain_future
def test_chain_future():
    def f():
        pass

    future = f()
    future_chain = f()
    chain_future(future, future_chain)


# Generated at 2022-06-26 07:50:15.720602
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future,ValueError())
    print(future._state)


# Generated at 2022-06-26 07:50:18.706804
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:50:30.542873
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import concurrent.futures
    import concurrent.futures

    # Callable[[..., Any], Any]
    # Callable[[..., Any], Any]
    # Callable[[..., Any], Any]
    # Callable[[..., Any], Any]
    # Callable[[..., Any], Any]
    # Optional[Callable[[..., Any], Any]]
    # Optional[Callable[[..., Any], Any]]
    # Optional[Callable[[..., Any], Any]]

    @run_on_executor()
    def simple_1(self):
        # type: (Any) -> Any
        pass

# Generated at 2022-06-26 07:50:36.738796
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    ioloop_0 = None
    dummy_executor_1 = DummyExecutor()
    # self.callback is deprecated, so we have to mock its presence
    class Foo:
        def __init__(
            self,
            ioloop,
            executor,
            callback=None,
        ) -> None:
            self.ioloop = ioloop
            self.executor = executor
            self.callback = callback
        @run_on_executor(executor="executor")
        def foo(self):
            pass
    foo_0 = Foo(ioloop=ioloop_0, executor=dummy_executor_1)
    foo_0.foo()

# Generated at 2022-06-26 07:50:48.700243
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # If the Future is already canceled, logs the exception instead. If
    # this logging is not desired, the caller should explicitly check
    # the state of the Future and call Future.set_exception instead of
    # this wrapper.
    import asyncio
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase

    class MyTestCase(AsyncTestCase):
        def test_future_set_exception_unless_cancelled(self):
            loop = IOLoop.current()
            future = loop.asyncio_loop.create_future()
            future.add_done_callback(self.stop)

# Generated at 2022-06-26 07:51:00.027812
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class Future1(asyncio.Future):
        def __init__(self):
            super().__init__()
            self.cancelled_ = False

        def cancel(self) -> bool:
            self.cancelled_ = True
            super().cancel()
            return True

        def cancelled(self) -> bool:
            return self.cancelled_

    future = Future1()
    try:
        raise RuntimeError("test_future_set_exception_unless_cancelled")
    except Exception as exc:
        future_set_exception_unless_cancelled(future, exc)
        assert future.exception() is exc
    future.cancel()
    try:
        raise RuntimeError("test_future_set_exception_unless_cancelled")
    except Exception as exc:
        future_

# Generated at 2022-06-26 07:51:08.240337
# Unit test for function chain_future
def test_chain_future():
    # # Issue #
    # https://github.com/tornadoweb/tornado/issues/2412
    # # Testing case
    # 1. f1 finishes
    # 2. f2 finishes

    f1 = Future()  # type: Future
    f2 = Future()  # type: Future

    chain_future(f1, f2)
    f1.set_result(None)
    f2.set_result(None)


# Generated at 2022-06-26 07:51:20.068969
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo():
        def __init__(self, x: int) -> None:
            self.x = x

        @classmethod
        @run_on_executor
        def self_classmethod(self, x: int) -> int:
            return x

        @classmethod
        @run_on_executor(executor="dummy_executor")
        def not_self_classmethod(cls, x: int) -> int:
            return x

        @classmethod
        @run_on_executor(executor="dummy_executor")
        def self_classmethod_error(self, x: int) -> None:
            raise Exception("hello")

        @run_on_executor
        def not_self_classmethod_error(cls, x: int) -> None:
            raise Exception("hello")



# Generated at 2022-06-26 07:51:22.818055
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    new_future = Future()
    future_set_exception_unless_cancelled(new_future, Exception())
    assert new_future.exception() is not None

# Generated at 2022-06-26 07:51:41.042056
# Unit test for function chain_future
def test_chain_future():
    # Test case 1
    _future0 = Future()
    _future1 = Future()
    _future1.set_result(None)
    chain_future(_future0, _future1)
    # Test case 2
    _future2 = Future()
    _future2.set_exception(Exception)
    _future3 = Future()
    chain_future(_future2, _future3)
    # Test case 3
    _future4 = Future()
    _future4.set_result(None)
    _future5 = Future()
    _future5.set_result(None)
    chain_future(_future4, _future5)
    # Test case 4
    _future6 = Future()
    _future7 = Future()
    chain_future(_future6, _future7)

# Generated at 2022-06-26 07:51:50.746213
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.platform.asyncio import to_asyncio_future

    def callable_0(arg_0: int) -> int:
        return arg_0 + 1

    assert 1 == callable_0(0)
    var_0: Future[int] = to_asyncio_future(
        dummy_executor.submit(callable_0, 1)
    )  # type: Future[int]
    assert var_0
    var_0.cancel()
    future_set_exception_unless_cancelled(var_0, ValueError())
    assert var_0.cancelled()
    assert var_0.exception() is None



# Generated at 2022-06-26 07:51:54.130013
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # -> Future = Future[str]
    # -> str
    res = future_set_exception_unless_cancelled(Future(), Exception('test_case'))
    assert isinstance(res, None)


# Generated at 2022-06-26 07:51:54.704152
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:51:58.113432
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    def fn():
        pass
    dummy_executor.submit(fn,"self","*args","**kwargs")


# Generated at 2022-06-26 07:52:03.295984
# Unit test for function chain_future
def test_chain_future():
    arg_0 = future_0 = Future()
    arg_1 = future_1 = Future()
    chain_future(arg_0, arg_1)
    future_0.set_result(None)
    future_1.set_result(None)


# Generated at 2022-06-26 07:52:17.879435
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_logger(name: str, level: int = logging.INFO) -> Any:
        log = logging.getLogger(name)
        old_level = log.level
        log.setLevel(level)
        try:
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            log.addHandler(handler)
            try:
                yield log, stream
            finally:
                log.removeHandler(handler)
        finally:
            log.setLevel(old_level)

    @contextmanager
    def captured_stderr() -> Any:
        stderr = sys.stderr

# Generated at 2022-06-26 07:52:24.769354
# Unit test for function chain_future
def test_chain_future():
    fut_0 = Future()
    other_fut_0 = Future()
    chain_future(fut_0, other_fut_0)
    fut_0.set_result(None)
    assert not other_fut_0.done()
    other_fut_0.set_result(None)
    assert fut_0.done()
    assert other_fut_0.done()



# Generated at 2022-06-26 07:52:28.761856
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    test_fut = Future()
    future_set_exception_unless_cancelled(test_fut, RuntimeError("Test exception"))
    assert test_fut.exception() is not None
    with pytest.raises(RuntimeError):
        test_fut.result()



# Generated at 2022-06-26 07:52:41.935525
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio
    from concurrent.futures._base import Future

    async def chain_future_async():
        # type: () -> None
        # Test asyncio.Future
        future_a = Future()
        future_b = asyncio.Future()
        chain_future(future_a, future_b)
        future_a.set_result(1)
        assert future_b.result() == 1

        # Test concurrent.futures.Future
        future_a = Future()
        future_b = Future()
        chain_future(future_a, future_b)
        future_a.set_result(2)
        assert future_b.result() == 2
        asyncio.get_event_loop().stop()

    asyncio.get_event_loop().run_until_

# Generated at 2022-06-26 07:52:56.486652
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = RuntimeError()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-26 07:53:04.315771
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    my_future = Future()
    my_exception = Exception("exception message")
    future_set_exception_unless_cancelled(my_future, my_exception)
    assert my_future.exception() == my_exception


if __name__ == "__main__":
    import pytest

    print(future_add_done_callback)
    pytest.main()

# Generated at 2022-06-26 07:53:11.540906
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(1)

    source = Future()
    target = Future()

    def set_source_result():
        source.set_result(None)

    loop.add_callback(set_source_result)

    def check_result():
        assert target.done()

    @run_on_executor(executor)
    def callback(t):
        assert t.done()
        check_result()

    # Ensure IOLoop.add_future is not called before the future is ready.
    chain_future(source, target)
    # Test the callback function
    chain_future(source, target)
    target.add_done_callback(callback)
    # Test the exc_info feature


# Generated at 2022-06-26 07:53:16.031712
# Unit test for function chain_future
def test_chain_future():
    def Foo(
        self: Any,
        a: "Future[_T]",
        b: "Future[_T]",
    ) -> Future:
        chain_future(a, b)
        return b

    def test():
        future_0 = Future()
        future_1 = Future()
        Foo(future_0, future_1)
        return future_1

    future_2 = test()
    return future_2


# Generated at 2022-06-26 07:53:19.922436
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    a = Future()
    future_set_result_unless_cancelled(a, "a test case")
    assert a.result() == "a test case", "The function future_set_result_unless_cancelled is broken"


# Generated at 2022-06-26 07:53:27.233030
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Callable
    callable_0 = future_set_result_unless_cancelled
    future_0 = Future()
    future_0.set_result('foo')
    callable_0(future_0, 'foo')
    future_1 = Future()
    future_1.set_result('foo')
    callable_0(future_1, 'foo')
    future_2 = Future()
    future_2.set_result('foo')
    callable_0(future_2, 'foo')
    future_3 = Future()
    future_3.set_result('foo')
    callable_0(future_3, 'foo')
    future_4 = Future()
    future_4.set_result('foo')
    callable_0(future_4, 'foo')
    future_5 = Future

# Generated at 2022-06-26 07:53:34.558643
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    def on_complete_0(future_0: Future) -> None:
        print("on_complete_0", future_0.result())

    future_1 = Future()
    chain_future(future_1, future_1)
    future_1.set_result(42)
    IOLoop.current().add_future(future_1, on_complete_0)
    IOLoop.current().start()



# Generated at 2022-06-26 07:53:40.032876
# Unit test for function chain_future
def test_chain_future(): 
    future = Future()
    future1 = Future()
    chain_future(future, future1)
    import tornado.ioloop
    ioloop = tornado.ioloop.IOLoop.instance()
    ioloop.stop()
    pass


# Generated at 2022-06-26 07:53:44.071979
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test case where Future is not cancelled, expects set_result to be called.
    future = Future()
    result = 42
    future_set_result_unless_cancelled(future, result)
    assert future.result() == result


# Generated at 2022-06-26 07:53:48.827342
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    async def async_fn():
        # type: () -> str
        return "example".upper()

    _ = async_fn()

    _ = run_on_executor()

    _ = dummy_executor

    _ = is_future(1)

    ReturnValueIgnoredError



# Generated at 2022-06-26 07:54:14.908055
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_0.set_result(None)
    chain_future(future_0, future_1)
    assert future_0.done()
    assert future_1.done()

# Generated at 2022-06-26 07:54:22.019725
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.concurrent import Future
    from concurrent.futures import Future as Future0

    fut0 = Future()
    fut1 = Future()
    chain_future(fut0, fut1)
    fut0.set_result(42)
    assert fut1.result() == 42

    fut0 = Future0()
    fut1 = Future()
    chain_future(fut0, fut1)
    fut0.set_result(42)
    assert fut1.result() == 42

    fut0 = Future()
    fut1 = Future0()
    chain_future(fut0, fut1)
    fut0.set_result(42)
    assert fut1.result() == 42

    fut0 = Future0()
    fut1 = Future0()

# Generated at 2022-06-26 07:54:23.965241
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # execute
    dummy_executor.submit(fn=test_case_0, args=None, kwargs=None)

# Generated at 2022-06-26 07:54:27.399912
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(1)
    assert b.done()
    assert b.result() == 1



# Generated at 2022-06-26 07:54:34.220315
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future_chain = Future()
    future.set_result("test result")
    chain_future(future, future_chain)
    assert future.result() == future_chain.result()


# Generated at 2022-06-26 07:54:48.663144
# Unit test for function chain_future
def test_chain_future():
    def fn_test(a: Future, b: Future) -> None:
        pass

    def fn_test_1(a: Future, b: Future) -> None:
        pass

    def fn_test_2(a: Future, b: Future) -> None:
        pass

    def fn_test_3(a: Future, b: Future) -> None:
        pass

    def fn_test_4(a: Future, b: Future) -> None:
        pass

    a1: Future
    a2: Future
    b1: Future
    b2: Future
    c1: Future
    c2: Future
    c3: Future
    d1: Future
    d2: Future
    d3: Future
    e1: Future
    e2: Future
    e3: Future
    f1: Future
    f

# Generated at 2022-06-26 07:54:51.319292
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    assert f is not f2
    assert f.done() == f2.done()



# Generated at 2022-06-26 07:54:53.940453
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def dummy_executor_submit_0(self):
        return self.submit(0)
    assert dummy_executor_submit_0(dummy_executor) == dummy_executor.submit(0)


# Generated at 2022-06-26 07:54:58.856492
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future

    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)

    future_1.set_result(1)

    assert future_2.result() == 1


# Generated at 2022-06-26 07:55:05.600156
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import gen_test

    @gen_test
    async def test():
        f = Future()
        f.cancel()
        try:
            future_set_exception_unless_cancelled(f, Exception())
        except Exception as e:
            assert False, f"future_set_exception_unless_cancelled raised {e}"

    test()



# Generated at 2022-06-26 07:55:59.812202
# Unit test for function chain_future
def test_chain_future():
    @chain_future(a, b)
    def copy(future):
        assert future is a
        if b.done():
            return
        if hasattr(a, "exc_info") and a.exc_info() is not None:  # type: ignore
            future_set_exc_info(b, a.exc_info())  # type: ignore
        elif a.exception() is not None:
            b.set_exception(a.exception())
        else:
            b.set_result(a.result())


# Generated at 2022-06-26 07:56:00.745949
# Unit test for function chain_future
def test_chain_future():
    FutureInstance = Future()
    FutureInstance.add_done_callback(chain_future(FutureInstance, FutureInstance))


# Generated at 2022-06-26 07:56:08.672380
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = futures.Future()
    future_set_exception_unless_cancelled(f, Exception('test'))
    assert f.exception() is not None
    f = futures.Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception('test'))

# Generated at 2022-06-26 07:56:17.826250
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from concurrent import futures

    loop = IOLoop()
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    asyncio_loop = asyncio.get_event_loop()
    executor = futures.ThreadPoolExecutor(max_workers=10)
    future_0: Future[int] = Future()
    future_1: futures.Future[int] = futures.Future()
    chain_future(future_0, future_1)
    future_0.set_result(0)
    assert future_1.result() == 0
    future_2: Future[int] = loop.run_in_executor(executor, lambda: 10)
    future_3: Future[int] = Future

# Generated at 2022-06-26 07:56:20.310855
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:56:27.345383
# Unit test for function chain_future
def test_chain_future():
    def test_chain_future_0(f: Future) -> None:
        assert f.result() is None
    # assert chain_future(Future(), Future()) is None



# Generated at 2022-06-26 07:56:35.472304
# Unit test for function run_on_executor
def test_run_on_executor():

    class ClassTest:
        def __init__(self) -> None:
            self.executor = dummy_executor

        @run_on_executor()
        def test(self, param_0, param_1):
            return param_0 + param_1

    class_test = ClassTest()

    # Test test(self, param_0, param_1)
    future_0 = class_test.test(1, 2)
    assert future_0.result() == 3

# Generated at 2022-06-26 07:56:37.808395
# Unit test for function run_on_executor
def test_run_on_executor():
    def callable_0(self: Any, **kwargs: Any) -> Any:
        pass

    run_on_executor(callable_0)



# Generated at 2022-06-26 07:56:43.076992
# Unit test for function chain_future
def test_chain_future():
    is_future_result = is_future(Future())
    assert is_future_result == True
    dummy_executor_result = dummy_executor.submit(lambda x: x, 1)
    assert dummy_executor_result.result() == 1



# Generated at 2022-06-26 07:56:45.444309
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def test_chain_future_func(a: Future, b: Future) -> None:
        chain_future(a, b)
    test_chain_future_func(Future(), Future())

# Generated at 2022-06-26 07:58:32.349704
# Unit test for function chain_future
def test_chain_future():
    class DummyFuture1(asyncio.Future):
        def __init__(self, exc_info: Tuple[Optional[type], Optional[BaseException], Optional[types.TracebackType]] = None):
            super(DummyFuture1, self).__init__()
            self.exc_info = exc_info
            self.exception = None
            self.result = None

        def done(self) -> bool: return self.exc_info is not None

        def set_exception(self, exception: BaseException) -> None:
            self.exception = exception

        def set_result(self, result: _T) -> None:
            self.result = result


# Generated at 2022-06-26 07:58:43.348679
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = asyncio.Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, None)
    future_set_exception_unless_cancelled(f, 1)
    future_set_exception_unless_cancelled(f, Exception())

    f = asyncio.Future()
    future_set_exception_unless_cancelled(f, None)
    future_set_exception_unless_cancelled(f, 1)
    future_set_exception_unless_cancelled(f, Exception())
