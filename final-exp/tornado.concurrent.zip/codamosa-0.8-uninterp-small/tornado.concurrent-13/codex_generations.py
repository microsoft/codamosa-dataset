

# Generated at 2022-06-26 07:49:09.403310
# Unit test for function chain_future
def test_chain_future():
    source_future = futures.Future()
    source_future.set_result("hello")
    sink_future = futures.Future()
    chain_future(source_future, sink_future)

    assert sink_future.result() == "hello"

# Generated at 2022-06-26 07:49:18.390918
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    def a(x):
        return x

    def b(y):
        return y

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(a(1))
    print(f1.result())

    f2.add_done_callback(b)
    print(f2.result())

    f1.result()
    f2.result()


# Generated at 2022-06-26 07:49:21.303256
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    future_set_result_unless_cancelled(future_0, 42)


# Generated at 2022-06-26 07:49:30.843526
# Unit test for function run_on_executor
def test_run_on_executor():
    callable_0: Callable = run_on_executor()
    callable_1: Callable = run_on_executor(executor="_thread_pool")
    # callable_2: Callable = run_on_executor(executor="_thread_pool", callback=None)
    callable_3: Callable = run_on_executor(executor="_thread_pool", timeout=15.0)
    # callable_4: Callable = run_on_executor(executor="_thread_pool", callback=None, timeout=15.0)
    callable_5: Callable = run_on_executor(timeout=15.0)
    # callable_6: Callable = run_on_executor(timeout=15.0, callback=None)

# Generated at 2022-06-26 07:49:43.003950
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def test_case_0():
        future = Future()  # type: Future[_T]
        future_set_result_unless_cancelled(future, 1)
        assert future.result() == 1
    test_case_0()

    def test_case_1():
        future = Future()  # type: Future[_T]
        future.cancel()
        assert future.result() is None
    test_case_1()

    def test_case_2():
        future = Future()  # type: Future[_T]
        future.set_result(1)
        future_set_result_unless_cancelled(future, 2)
        assert future.result() == 1
    test_case_2()



# Generated at 2022-06-26 07:49:49.201669
# Unit test for function chain_future
def test_chain_future():
    old_future = futures.Future()
    new_future = Future()
    chain_future(old_future, new_future)
    assert new_future.done() == False
    old_future.set_result("TEST CHAIN FUTURE")
    assert new_future.done() == True
    assert new_future.result() == "TEST CHAIN FUTURE"



# Generated at 2022-06-26 07:49:49.751838
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:49:53.144815
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        future_set_exception_unless_cancelled(None, None)
    except:  # noqa: E722
        pass


# Generated at 2022-06-26 07:50:00.276173
# Unit test for function chain_future
def test_chain_future():
    future = asyncio.Future()
    future2 = asyncio.Future()
    chain_future(future, future2)
    assert (not future2.done())

    future.set_result(None)
    assert future2.done()
    assert (future2.result() is None)

    future = asyncio.Future()
    future2 = asyncio.Future()
    future2.cancel()
    chain_future(future, future2)
    assert (not future2.cancelled())
    assert not future2.done()

    future.set_exception(Exception())
    assert future2.done()
    with pytest.raises(Exception):
        future2.cancel()



# Generated at 2022-06-26 07:50:09.058592
# Unit test for function chain_future
def test_chain_future():
    # Define a functin chain_future
    # fail_flag = False
    # try:
    chain_future(ReturnValueIgnoredError, DummyExecutor)
    chain_future(DummyExecutor, DummyExecutor)
    chain_future(ReturnValueIgnoredError, Future)
    chain_future(Future, Future)
    chain_future(ReturnValueIgnoredError, Future)
    chain_future(Future, Future)
    chain_future(Future, Future)
    chain_future(Future, Future)


# Generated at 2022-06-26 07:50:23.281590
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Create a future
    future = asyncio.Future()
    # Call future_set_exception_unless_cancelled with future, and a exception
    future_set_exception_unless_cancelled(future, Exception())
    # Check the result
    assert future.done()
    assert isinstance(future.exception(), Exception)

    # Create another future
    future = asyncio.Future()
    # Cancel the future
    future.cancel()
    # Call future_set_exception_unless_cancelled
    future_set_exception_unless_cancelled(future, Exception())
    # Check the result
    assert future.done()
    assert future.exception() is None



# Generated at 2022-06-26 07:50:26.538589
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)

test_case_0()
test_chain_future()

# Generated at 2022-06-26 07:50:29.664093
# Unit test for function run_on_executor
def test_run_on_executor():
    args = None
    kwargs = None
    fn = None
    self = None
    future = run_on_executor(args, kwargs, fn, self)
    pass

# Generated at 2022-06-26 07:50:34.238073
# Unit test for function run_on_executor
def test_run_on_executor():
    callable_0 = run_on_executor()
    callable_0 = run_on_executor(executor=str())
    callable_1 = run_on_executor()

    def hello() -> str:
        return str()

    callable_1(hello)
    assert callable_1.__name__ == callable_0.__name__
    assert callable_1.__name__ == hello.__name__



# Generated at 2022-06-26 07:50:36.876246
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    callable__0 = DummyExecutor().submit(lambda: None)
    callable__1 = DummyExecutor().submit(lambda: None, 1, 2)


# Generated at 2022-06-26 07:50:41.671457
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 'value')
    assert f.result() == 'value'
    f.cancel()
    future_set_result_unless_cancelled(f, 'value')
    assert f.result() == 'value'


# Generated at 2022-06-26 07:50:53.594813
# Unit test for function chain_future
def test_chain_future():
    def test_func_0(arg_0, arg_1):
        pass

    def test_func_1(arg_0, arg_1):
        pass
    # Test normal inputs
    chain_future(test_func_0('arg_0', 'arg_1'), test_func_1('arg_0', 'arg_1'))
    # Test empty chain_future
    chain_future(test_func_0(), test_func_1)
    # Test empty chain_future
    chain_future(test_func_0, test_func_1('arg_0', 'arg_1'))
    # Test default case
    chain_future(test_func_0, test_func_1)


# Generated at 2022-06-26 07:50:54.035499
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:50:57.000392
# Unit test for function chain_future
def test_chain_future():
    future = Future()  # type: Future[int]
    future_result = 1234
    future.set_result(future_result)
    future2 = Future()  # type: Future[int]
    chain_future(future, future2)
    assert future2.result() == future_result
    assert future2.done()



# Generated at 2022-06-26 07:51:02.157798
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(None)
    assert future2.done()
    assert future2.result() is None
    future1 = Future()
    future2 = Future()
    future1.set_exception(Exception())
    chain_future(future1, future2)
    assert future2.done()
    try:
        future2.result()
    except Exception:
        pass
    else:
        assert False


# Generated at 2022-06-26 07:51:17.316054
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)



# Generated at 2022-06-26 07:51:27.671674
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop
    ioloop = tornado.ioloop.IOLoop.current()
    executor = futures.ThreadPoolExecutor(4)

    class Obj:
        _executor = executor

        @run_on_executor
        def inc_self(self, value: int) -> int:
            return value + 1

    obj = Obj()
    future = obj.inc_self(1)
    ioloop.add_future(future, lambda f: ioloop.stop())
    ioloop.start()
    assert future.result() == 2

    future = obj.inc_self(1)
    ioloop.add_future(future, lambda f: ioloop.stop())
    ioloop.start()
    assert future.result() == 2

    future = obj.inc_self(1)

# Generated at 2022-06-26 07:51:30.526318
# Unit test for function chain_future
def test_chain_future():
    fut_one = Future()
    fut_two = Future()
    chain_future(fut_one, fut_two)

    fut_one.set_result(1)
    assert fut_two.result() == 1

    fut_one.set_exception(Exception("error"))
    assert fut_two.exception() == Exception("error")

# Generated at 2022-06-26 07:51:37.727006
# Unit test for function chain_future
def test_chain_future():
    table_0 = {}  # type: typing.MutableMapping[str, int]
    table_0['abc'] = 0
    table_0['abc'] += 1
    list_0 = []
    list_0.append(3)
    future_0 = Future() # type: Future[int]
    future_1 = Future() # type: Future[int]
    chain_future(future_0, future_1)
    future_0.set_result(1)

# Generated at 2022-06-26 07:51:48.813696
# Unit test for function chain_future
def test_chain_future():
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        # Create and complete the first future
        fut1 = concurrent.futures.Future()
        fut1.set_result('foo')

        # The second future is not done and will be chained to the first one
        fut2 = concurrent.futures.Future()
        assert not fut2.done()
        chain_future(fut1, fut2)

        assert fut2.done()
        assert fut2.result() == 'foo'

test_case_0()
test_chain_future()

# Generated at 2022-06-26 07:51:52.848211
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = futures.Future()
    try:
        future_set_result_unless_cancelled(future, 1)
    except Exception:
        print("Error in function future_set_result_unless_cancelled")


# Generated at 2022-06-26 07:51:55.182050
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async_future = asyncio.Future()
    # Test if run_on_executor returns a future
    assert isinstance(async_future, futures.Future)

# Generated at 2022-06-26 07:52:01.789953
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    a = Future()
    b = Future()
    chain_future(a, b)
    future_set_result_unless_cancelled(a, '1')
    b.cancel()
    future_set_result_unless_cancelled(a, "2")
    print(b.result())


# Generated at 2022-06-26 07:52:02.973473
# Unit test for function chain_future
def test_chain_future():
    callable_0 = chain_future


# Generated at 2022-06-26 07:52:07.535499
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    future.set_exception(AssertionError())
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())

# Generated at 2022-06-26 07:52:25.805678
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor(executor='_thread_pool')
    def foo(self,*arg):
        return 2

    class B(object):
        def __init__(self):
            self._thread_pool = B()

    b = B()
    f = foo(b,1)
    print(f)

if __name__ == '__main__':
    test_run_on_executor()

# Generated at 2022-06-26 07:52:27.428047
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    instance = DummyExecutor()
    dummy_executor.submit(run_on_executor)



# Generated at 2022-06-26 07:52:30.754721
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)

    a.set_result(1)
    assert b.result() == 1



# Generated at 2022-06-26 07:52:40.981849
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future: "Future[str]" = Future()
    exception: Exception = Exception("Exception e")

    future_set_exception_unless_cancelled(future, exception)
    assert str(future.exception()) == "Exception e"
    assert future.done()
    assert not future.cancelled()

    future: "Future[str]" = Future()
    future.cancel()

    future_set_exception_unless_cancelled(future, exception)
    assert str(future.exception()) == "Exception e"
    assert future.done()
    assert future.cancelled()



# Generated at 2022-06-26 07:52:46.098060
# Unit test for function chain_future
def test_chain_future():
    import os
    import sys

    def func_0():
        pass

    a = Future()
    b = Future()
    chain_future(a, b)
    b.result()
    chain_future(a, b)
    b.result()
    chain_future(a, b)
    b.result()


# Generated at 2022-06-26 07:52:53.233407
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.get_event_loop()
    fut_a = Future()
    fut_b = Future()
    chain_future(fut_a, fut_b)
    fut_a.set_result(True)

    def callback(future):
        # type: (Future[None]) -> None
        assert future.done()
        assert future.result()

    loop.run_until_complete(fut_b)
    future_add_done_callback(fut_b, callback)
    loop.close()


# Generated at 2022-06-26 07:53:01.996413
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def add_3(x):
        # type: (int) -> int
        return x + 3

    value_0 = 10
    future_0 = Future()
    future_0.set_result(value_0)
    future_1 = Future()
    chain_future(future_0, future_1)
    value_1 = future_1.result()
    value_2 = add_3(value_0)
    assert value_1 == value_2



# Generated at 2022-06-26 07:53:10.472375
# Unit test for function chain_future
def test_chain_future():
    future_0 : Future = Future()
    future_1 : Future = Future()
    chain_future(future_0, future_1)
    future_0.done()

    future_0 : Future = Future()
    future_1 : Future = Future()
    chain_future(future_0, future_1)
    future_0.result()

    future_0 : Future = Future()
    future_1 : Future = Future()
    chain_future(future_0, future_1)
    future_0.exception()

    future_0 : Future = Future()
    future_1 : Future = Future()
    chain_future(future_0, future_1)
    future_1.done()

    future_0 : Future = Future()
    future_1 : Future = Future()

# Generated at 2022-06-26 07:53:17.743967
# Unit test for function chain_future
def test_chain_future():
    # Check Future passed with Future passed
    # We should call set_exc_info once
    # We should call set_result twice
    future_0 = asyncio.Future()
    future_1 = asyncio.Future()
    future_0.set_result(True)

    chain_future(future_0, future_1)

    # Check Future passed with Asyncio Future passed
    # We should call set_result once
    future_0 = asyncio.Future()
    
    future_0.set_result(1)

    chain_future(Future, future_1)

    # Check Future passed with asyncio Future passed
    # We should call set_result once
    future_0 = asyncio.Future()
    future_1 = asyncio.Future()
    future_0.set_result(1)

# Generated at 2022-06-26 07:53:22.086243
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def func_0(self, arg0: str, arg1: int = 1) -> int:
        return len(arg0) + arg1
    assert isinstance(func_0, types.FunctionType)
    assert isinstance(func_0(None, ""), Future)



# Generated at 2022-06-26 07:53:52.032700
# Unit test for function chain_future
def test_chain_future():
    # prepare dummy objects
    dummy_0 = Future()
    dummy_1 = Future()
    dummy_2 = Future()
    dummy_3 = Future()
    
    # set the Future to some result
    dummy_0.set_result(dummy_1)
    dummy_2.set_result(dummy_3)
    
    # chain the future
    chain_future(dummy_0, dummy_2)
    # check the output
    assert dummy_2.result() == dummy_1


# Generated at 2022-06-26 07:54:03.368073
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(12)
    assert f2.result() == 12
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("12"))
    try:
        f2.result()
        raise Exception("shouldn't get here")
    except Exception as e:
        assert "12" in str(e)
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("12"))

# Generated at 2022-06-26 07:54:07.350256
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    test = Future()
    chain_future(f1, test)
    f1.set_result(1)
    assert test.result() == 1



# Generated at 2022-06-26 07:54:17.672109
# Unit test for function chain_future
def test_chain_future():
    def test_func(a):
        print("a = ", a)
        return a
    loop = asyncio.get_event_loop()
    future_0 = loop.create_future()
    future_1 = loop.create_future()

    def copy(future):
        assert future is future_0
        if future_1.done():
            return
        if hasattr(future_0, "exc_info"):
            future_set_exc_info(future_1, future_0.exc_info())
        elif future_0.exception() is not None:
            future_1.set_exception(future_0.exception())
        else:
            future_1.set_result(future_0.result())

    future_add_done_callback(future_0, copy)
    future_0.set

# Generated at 2022-06-26 07:54:18.308739
# Unit test for function run_on_executor
def test_run_on_executor():
    pass

# Generated at 2022-06-26 07:54:20.580840
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    async_future_0 = Future()
    chain_future(future_0, async_future_0)


# Generated at 2022-06-26 07:54:24.906769
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = RuntimeError("test future_set_exception_unless_cancelled")
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

# Generated at 2022-06-26 07:54:27.578413
# Unit test for function chain_future
def test_chain_future():
    # test for Future in current version
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    return



# Generated at 2022-06-26 07:54:37.831827
# Unit test for function chain_future
def test_chain_future():
    # Neither a nor b references the other
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1

    # a references b but not vice versa, then b finished correctly
    a = Future()
    b = Future()
    a.chain(b)
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1

    # b references a but not vice versa, then b finished correctly
    a = Future()
    b = Future()
    b.chain(a)
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1

    # a and b both reference the other, and both finish correctly
    a = Future()

# Generated at 2022-06-26 07:54:42.786415
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    # test for function
    def function_0(*args, **kwargs):
        pass
    result = executor.submit(function_0, *args, **kwargs)
    assert result is not None



# Generated at 2022-06-26 07:55:35.649300
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a,b)
    a.set_result(2)
    assert b.done() and b.result() == 2
    c = Future()
    chain_future(a, c)
    assert c.done() and c.result() == 2
    d = Future()
    chain_future(b,d)
    assert d.done() and d.result() == 2


# Generated at 2022-06-26 07:55:44.941849
# Unit test for function chain_future
def test_chain_future():
    f = futures.Future()  # type: futures.Future[int]
    f_a = asyncio.Future()  # type: Future[int]
    f_b = asyncio.Future()  # type: Future[int]
    chain_future(f_a, f_b)
    assert not f_b.done()
    f_a.set_exception(Exception())
    assert f_b.exception() is not None
    chain_future(f, f_b)
    assert not f_b.done()
    chain_future(f_a, f)
    assert f.done()

# Unit tests for run_on_executor

# Generated at 2022-06-26 07:55:48.246968
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    future_set_result_unless_cancelled(future_0, 0)


# Generated at 2022-06-26 07:55:55.250702
# Unit test for function chain_future
def test_chain_future():
    called = False
    future1 = Future()
    future2 = Future()

    def callback(future: Future) -> None:
        nonlocal called
        called = True

    chain_future(future1, future2)
    future_add_done_callback(future2, callback)
    future1.set_result(None)
    assert called is True



# Generated at 2022-06-26 07:55:57.536315
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, True)


# Generated at 2022-06-26 07:56:07.432136
# Unit test for function run_on_executor
def test_run_on_executor():
    _tst = test_case_0
    class test_case_1():
        executor = dummy_executor
        @run_on_executor()
        def foo(self):
            pass
    class test_case_2():
        executor = dummy_executor
        def foo(self):
            pass
        foo = run_on_executor()(foo)
    class test_case_3():
        _thread_pool = dummy_executor
        @run_on_executor(executor='_thread_pool')
        def foo(self):
            pass
    class test_case_4():
        _thread_pool = dummy_executor
        def foo(self):
            pass
        foo = run_on_executor(executor='_thread_pool')(foo)

# Generated at 2022-06-26 07:56:14.357249
# Unit test for function chain_future
def test_chain_future():
    def cb(a: Future) -> None:
        pass
    
    def cb1(b: Future) -> None:
        cb(b)

    def cb2(b: Future) -> None:
        cb1(b)
    
    @run_on_executor
    def foo(self: Any, *args: Any, **kwargs: Any) -> Future:
        b = Future()
        cb(b)
        cb1(b)
        cb2(b)
        return b

    @run_on_executor
    def foo1(self: Any, *args: Any, **kwargs: Any) -> Future:
        b = Future()
        cb(b)
        cb1(b)
        cb2(b)
        return b
        # Use b to

# Generated at 2022-06-26 07:56:14.870344
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    pass

# Generated at 2022-06-26 07:56:27.344881
# Unit test for function chain_future
def test_chain_future():
    def make_future(x: int) -> Future[int]:
        f = Future()
        f.set_result(x)
        return f

    f1 = make_future(1)
    f2 = make_future(2)
    chain_future(f1, f2)

    @chain_future
    def chain_future_decorator() -> Future[int]:
        f = make_future(1)
        return f
    f3 = chain_future_decorator()


if __name__ == '__main__':
    test_chain_future()
    test_case_0()

# Generated at 2022-06-26 07:56:40.685157
# Unit test for function chain_future
def test_chain_future():
    # Tests the correct result is returned after the second Future
    # is chained to the first and completed.
    first_future = Future()
    second_future = Future()

    chain_future(first_future, second_future)

    first_future.set_result(42)
    assert second_future.result() == 42

    # Tests that if the first Future is completed, but the second
    # is cancelled, the second Future stays cancelled.
    first_future = Future()
    second_future = Future()

    chain_future(first_future, second_future)

    first_future.set_exception(ValueError("oops"))
    second_future.cancel()
    assert second_future.cancelled() is True

    # Tests that an exception raised in the first Future gets
    # copied to the second.
    first_future = Future

# Generated at 2022-06-26 07:58:20.804021
# Unit test for function chain_future
def test_chain_future():
    from . import gen_test
    from .httpclient import AsyncHTTPClient

    async def do_fetch(client: AsyncHTTPClient, url: str) -> None:
        resp = await client.fetch(url)
        print(f"got response: {resp}")

    async def main():
        client = AsyncHTTPClient()
        url = "http://www.tornadoweb.org/en/stable/"
        print(f"fetching {url}")
        await do_fetch(client, url)

    ioloop = gen_test.make_test_ioloop()
    ioloop.run_sync(main)


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-26 07:58:33.015813
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(None)

# Generated at 2022-06-26 07:58:46.710471
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()

    callable_0 = dummy_executor_0.submit(fn_0=lambda : None)


if __name__ == '__main__':
    import sys
    import logging
    import unittest


    def fn_0() -> None:
        pass


    def setUpModule() -> None:
        logging.basicConfig(stream=sys.stderr)
        logging.getLogger().setLevel(logging.DEBUG)


    class AsyncIOMainLoopTestCase(unittest.TestCase):
        def test_case_0(self):
            callable_0 = run_on_executor()


    class DummyExecutorTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.dummy