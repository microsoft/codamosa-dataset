

# Generated at 2022-06-26 07:49:06.729125
# Unit test for function run_on_executor
def test_run_on_executor():
    class TestCase:
        def __init__(self):
            self.executor = DummyExecutor()
            self.call_count = 0
            self.status = 0

        @run_on_executor
        def func(self):
            self.call_count += 1

        @run_on_executor(executor='executor')
        def func0(self):
            self.status += 1

        @run_on_executor(executor='_thread_pool')
        def func1(self):
            self.status += 1

    t = TestCase()
    t.func()
    t.func0()
    t.func1()

    assert t.call_count == 1
    assert t.status == 2



# Generated at 2022-06-26 07:49:09.103447
# Unit test for function chain_future
def test_chain_future():
    future_0 = futures.Future()
    future_1 = futures.Future()
    try:
        chain_future(future_0, future_1)
    except:
        pass


# Generated at 2022-06-26 07:49:11.266194
# Unit test for function run_on_executor
def test_run_on_executor():
    def f(a, b):
        return a+b
    assert run_on_executor(f)(2, 3) == 5



# Generated at 2022-06-26 07:49:15.966092
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_helper():
        class DummyClassWithExecutor:
            executor = dummy_executor

            @run_on_executor
            def background_method(self):
                pass

        return DummyClassWithExecutor()

    test_helper()

# Generated at 2022-06-26 07:49:22.156989
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

    future = Future()
    exc = Exception()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)



# Generated at 2022-06-26 07:49:23.857696
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_1 = DummyExecutor()


# Generated at 2022-06-26 07:49:26.002665
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()


# Generated at 2022-06-26 07:49:28.849873
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1



# Generated at 2022-06-26 07:49:33.000825
# Unit test for function run_on_executor
def test_run_on_executor():
    class Test:
        executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

    test = Test()
    assert test.foo(1, 2) == 3



# Generated at 2022-06-26 07:49:42.415726
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Should not cause InvalidStateError
    future_set_exception_unless_cancelled(Future(), Exception())
    future_set_exception_unless_cancelled(Future(), None)
    future = Future()
    future.cancel()
    try:
        future_set_exception_unless_cancelled(future, Exception())
        future_set_exception_unless_cancelled(future, None)
    except asyncio.InvalidStateError:
        raise Exception("future_set_exception_unless_cancelled unexpected InvalidStateError")



# Generated at 2022-06-26 07:49:57.658049
# Unit test for function run_on_executor
def test_run_on_executor():
    async def foo(self, x: int) -> int:
        return x*2
    result = foo(None, 3)
    assert result == 6

    class TestClass:
        counter = 0
        def __init__(self):
            self.counter = TestClass.counter
            TestClass.counter += 1

        executor = dummy_executor_0
        @run_on_executor
        async def bar(self, x: int) -> int:
            return x/2

    tc = TestClass()
    assert tc.counter == 0
    result = await tc.bar(3)
    assert result == 1
    tc2 = TestClass()
    assert tc2.counter == 1


# Generated at 2022-06-26 07:50:03.046293
# Unit test for function chain_future
def test_chain_future():
    # Two Future objects
    f1 = Future()
    f2 = Future()
    assert f1.cancelled() == False
    assert f2.cancelled() == False

    # f1 success
    f1.set_result('value1')
    assert f2.cancelled() == False
    assert f2.result() == 'value1'



# Generated at 2022-06-26 07:50:10.505410
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()  # type: Future
    future_1 = Future()  # type: Future
    future_2 = Future()  # type: Future
    future_3 = Future()  # type: Future
    future_1.set_result(future_2)
    future_2.set_result(future_3)
    future_3.set_result(1)
    chain_future(future_0, future_1)
    assert(future_1.result() == 1)

# Generated at 2022-06-26 07:50:13.815604
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = asyncio.Future()
    future_set_result_unless_cancelled(f, 3)
    assert f.result() == 3


# Generated at 2022-06-26 07:50:25.956035
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_1 = DummyExecutor()
    dummy_executor_1.submit(lambda a: a, 1)
    dummy_executor_2 = DummyExecutor()
    dummy_executor_2.submit(lambda a, b: a + b, 5, 10)
    dummy_executor_3 = DummyExecutor()
    dummy_executor_3.submit(lambda a, b: a + b, "ab", "cd")
    dummy_executor_4 = DummyExecutor()
    dummy_executor_4.submit(lambda a, b: a + b, [1, 2], [3, 4])
    dummy_executor_5 = DummyExecutor()

# Generated at 2022-06-26 07:50:34.517598
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future

    future = Future()
    future_chain = Future()

    chain_future(future_chain, future)
    future_chain.set_result('test')
    assert future.done()
    assert future.result() == 'test'

    future_chain = Future()
    future = Future()

    chain_future(future_chain, future)
    future_chain.set_result('test')
    assert future.done()
    assert future.result() == 'test'

    future_chain = Future()
    future = Future()

    chain_future(future, future_chain)
    future.set_result('test')
    assert future_chain.done()
    assert future_chain.result() == 'test'



# Generated at 2022-06-26 07:50:46.358454
# Unit test for function chain_future
def test_chain_future():
    # Case 1 - Transferring a successful result from one future to the other
    future1 = Future()
    future2 = Future()
    future1.set_result(True)
    chain_future(future1, future2)
    assert(future2.result() == True)

    # Case 2 - Transferring an exception from one future to the other
    future1 = Future()
    future2 = Future()
    future1.set_exception(Exception())
    chain_future(future1, future2)
    assert(future2.exception() == future1.exception())

    # Case 3 - Transferring a result from one future to the other,
    # when the second future has already been marked completed
    future1 = Future()
    future2 = Future()
    future2.set_result(False)

# Generated at 2022-06-26 07:50:50.071523
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    @run_on_executor
    def f(self, i):
        # type: (int) -> int
        return i + 1



# Generated at 2022-06-26 07:50:53.120431
# Unit test for function chain_future
def test_chain_future():
    future_a_0 = Future()
    future_b_0 = Future()
    chain_future(future_a_0, future_b_0)

# Generated at 2022-06-26 07:50:58.416230
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    dummy_future = asyncio.Future()
    future_set_result_unless_cancelled(dummy_future, 5)
    assert dummy_future.result() == 5
    dummy_future = concurrent.futures.Future()
    future_set_result_unless_cancelled(dummy_future, 5)
    assert dummy_future.result(0) == 5



# Generated at 2022-06-26 07:51:19.677398
# Unit test for function run_on_executor
def test_run_on_executor():  # noqa: E302
    class Object_0(object):
        def method_0(self):
            pass

    def function_0():
        pass

    function_0_decorator = run_on_executor(function_0)
    assert isinstance(function_0_decorator, Callable)
    assert hasattr(function_0_decorator, "wrapped")

    class Object_0(object):
        def method_0(self):
            pass

    object_0 = Object_0()
    object_1 = Object_0()
    method_0_decorator = run_on_executor()
    assert isinstance(method_0_decorator, Callable) and (
        method_0_decorator.__name__ == "method_0"
    )


# Generated at 2022-06-26 07:51:28.421185
# Unit test for function chain_future
def test_chain_future():
    import requests

    class A:
        pass

    a = A()
    a.executor = dummy_executor

    @run_on_executor
    def f(url):
        return requests.get(url).content

    @a.executor.submit
    def g(url):
        return requests.get(url).content

    b = Future()
    c = Future()
    f('https://github.com').add_done_callback(lambda fut: fut.result())
    g('https://github.com').add_done_callback(lambda fut: fut.result())

    chain_future(a.executor.submit(f, 'https://github.com'), b)
    chain_future(a.executor.submit(g, 'https://github.com'), c)

# Generated at 2022-06-26 07:51:29.963093
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    # Call function chain_future
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:51:32.721732
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:51:42.765536
# Unit test for function chain_future
def test_chain_future():
    class A:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def foo(self, a, b, c=4, callback=None, **kwargs):
            callback(a + b + c)

        @run_on_executor(executor="executor")
        def bar(self, a, b, c=4, callback=None, **kwargs):
            callback(a + b + c)

        def baz(self, a, b, c=4, callback=None, **kwargs):
            self.executor.submit(callback, a + b + c)

    @run_on_executor
    def foo(a, b, c=4, callback=None, **kwargs):
        callback(a + b + c)

    a

# Generated at 2022-06-26 07:51:48.134679
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future:asyncio.Future = asyncio.Future()
    dummy_exc = Exception("")

    future_set_exception_unless_cancelled(test_future, dummy_exc)
    assert test_future.exception() == dummy_exc

    test_future.cancel()
    future_set_exception_unless_cancelled(test_future, dummy_exc)


# Generated at 2022-06-26 07:51:51.666356
# Unit test for function chain_future
def test_chain_future():
    """Sample pytest unit test function with the pytest fixture as an argument.
    """
    a = Future()
    b = Future()
    chain_future(a, b)


# Generated at 2022-06-26 07:51:54.833392
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    chain_future(b, c)
    a.set_result(42)
    assert c.result() == 42

# Generated at 2022-06-26 07:52:07.537775
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    with asyncio.get_event_loop():
        future = asyncio.Future()
        future_set_result_unless_cancelled(future, "hello")
        if "hello" != future.result():
            raise RuntimeError("1")
        future = asyncio.Future()
        future.cancel()
        future_set_result_unless_cancelled(future, "hello")
        if future.result() is not None:
            raise RuntimeError("2")
        future = asyncio.Future()
        future.cancel()
        future_set_result_unless_cancelled(future, None)
        if future.result() is not None:
            raise RuntimeError("3")


# Generated at 2022-06-26 07:52:11.246118
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = BaseException()
    future_set_exception_unless_cancelled(future, exc)
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)



# Generated at 2022-06-26 07:52:24.812445
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    assert (not b.done())
    result = "some_result"
    a.set_result(result)
    assert (a.done())
    chain_future(a, b)
    assert (b.result() == result)
    assert (b.done())

# Generated at 2022-06-26 07:52:30.173218
# Unit test for function chain_future
def test_chain_future():
    async_future = Future()  # type: Future
    conc_future = futures.Future()  # type: futures.Future

    def callback_0(future):
        future.set_result(1)
    conc_future.add_done_callback(callback_0)

    assert conc_future.done() == False

    chain_future(conc_future, async_future)

    assert conc_future.done() == True

    assert async_future.done() == True
    assert async_future.result() == 1




# Generated at 2022-06-26 07:52:36.748176
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    def fn(
        *args: Any, **kwargs: Any
    ) -> "Union[futures.Future[_T], Future[_T]]":
        return future_set_result_unless_cancelled(a, value)
    dummy_executor_0.submit(fn, *args, **kwargs)


# Generated at 2022-06-26 07:52:48.738573
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exception = Exception()
    # Case 0
    future = Future()
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() == exception

    # Case 1
    future = Future()
    future.set_result(0)
    future_set_exception_unless_cancelled(future, exception)
    assert future.result() == 0

    # Case 2
    future = Future()
    future.set_exception(exception)
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() == exception

    # Case 3
    future = Future()
    future.set_exception(None)
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is None

   

# Generated at 2022-06-26 07:52:54.118727
# Unit test for function chain_future
def test_chain_future():
    fut = Future()
    fut2 = Future()
    chain_future(fut2, fut)
    scheduler = asyncio.get_event_loop()
    scheduler.run_until_complete(fut)
    return


async def test_async_chain_future():
    fut = Future()
    fut2 = Future()
    chain_future(fut2, fut)
    await fut
    return



# Generated at 2022-06-26 07:53:01.885876
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f1.result() == f2.result()
    print(f1.result(), f2.result())


if __name__ == "__main__":
    test_chain_future()
    test_case_0()

# Generated at 2022-06-26 07:53:03.583139
# Unit test for function chain_future
def test_chain_future():
    IOLoop.current().sync(lambda: chain_future(a, b))



# Generated at 2022-06-26 07:53:07.394934
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    fn_0 = None
    args_0 = list()
    kwargs_0 = dict()
    future_0 = dummy_executor.submit(fn_0, *args_0, **kwargs_0)


# Generated at 2022-06-26 07:53:22.527540
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from typing import Type

    Future = typing.TypeVar("Future", bound="Future")
    aio_future = Future()
    # Test the function's output
    exc = None
    future_set_exception_unless_cancelled(aio_future, exc)
    assert aio_future.exception() == exc
    aio_future.cancel()
    exc = ValueError()
    future_set_exception_unless_cancelled(aio_future, exc)
    # Test the function's output type
    aio_future = Future()
    exc = None
    future_set_exception_unless_cancelled(aio_future, exc)
    assert aio_future.exception() == exc
    # Test the function's output type
    aio_future = Future()
    exc = ValueError()

# Generated at 2022-06-26 07:53:35.399795
# Unit test for function chain_future
def test_chain_future():
    # Test that chain_future chains correctly
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    expected = object()
    f1.set_result(expected)
    assert f2.result() is expected

    # Test that chain_future is a no-op when the "to" future is already done
    f3 = Future()
    expected = object()
    f3.set_result(expected)
    chain_future(f1, f3)
    assert f3.result() is expected

    # Test that chain_future propagates exceptions correctly
    f4 = Future()
    f5 = Future()
    chain_future(f4, f5)

    err = RuntimeError()
    f4.set_exception(err)
    assert f5.exception() is err



# Generated at 2022-06-26 07:53:58.218086
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 10)
    assert isinstance(future.result(), int)
    assert not future.cancelled()

    future2 = Future()
    assert not future2.cancelled()
    future_set_result_unless_cancelled(future2, 11)
    assert isinstance(future2.result(), int)
    future2.cancel()
    assert future2.cancelled()


# Generated at 2022-06-26 07:53:59.745792
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:54:00.824056
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:54:13.849450
# Unit test for function run_on_executor
def test_run_on_executor():
    from concurrent import futures
    import threading

    executor = futures.ThreadPoolExecutor(1)

    def callable_0(self, *args, **kwargs):
        return threading.current_thread().getName()

    # __wrapped__ property of a test_case_0 should return original callable_0
    assert test_case_0.__wrapped__ is callable_0
    # __wrapped__ property of a test_case_1 should return original callable_1
    assert test_case_1.__wrapped__ is callable_1
    # Thread name should be start with 'ThreadPoolExecutor'
    assert str(test_case_0.__wrapped__()).startswith('ThreadPoolExecutor')
    # Thread name should be start with 'ThreadPoolExecutor'

# Generated at 2022-06-26 07:54:19.272108
# Unit test for function chain_future
def test_chain_future():
    # The success-case is tested indirectly as part of the Future
    # testsuite.  The failure case is tested here.

    f1 = Future()
    f2 = Future()
    f1.set_exception(ZeroDivisionError())
    f2.set_result(5)
    chain_future(f1, f2)
    assert f2.exception() is not None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 07:54:26.737297
# Unit test for function run_on_executor
def test_run_on_executor():

    class TestCase0:

        def __init__(self, in_executor: str, in_callback: str) -> None:
            self.executor = in_executor
            self.callback = in_callback

        @run_on_executor("executor", "callback")
        def fn(self, arg: str) -> str:
            return arg

    test_case_0 = TestCase0("_thread_pool", "_executor_callback")
    test_case_0.fn("_arg")



# Generated at 2022-06-26 07:54:35.138436
# Unit test for function chain_future
def test_chain_future():
    a = Future()  # type: Future[int]
    b = Future()  # type: Future[int]
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1
    chain_future(a, b)
    a.set_exception(Exception())
    assert isinstance(b.exception(), Exception)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 07:54:48.745004
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    callable_0 = DummyExecutor()
    # Executor.submit()
    callable_1 = tuple()
    callable_0 = callable_0.submit(callable_0, callable_1)
    # future_add_done_callback()
    callable_1 = Future()
    callable_0 = callable_0.add_done_callback(callable_0, callable_1)
    # future_set_result_unless_cancelled()
    callable_1 = callable_0.result()
    callable_0 = future_set_result_unless_cancelled(callable_0, callable_1)
    # future_set_exception_unless_cancelled()
    callable_1 = callable_0.exception()
    callable_0 = future_set

# Generated at 2022-06-26 07:54:56.538341
# Unit test for function chain_future
def test_chain_future():
    def test_future():
        def inner_future():
            pass
        return inner_future


    def test_future_method_0():
        def inner_future_method_0():
            pass

        class test_class_0:
            test_inner_future_method_0 = inner_future_method_0
        return test_class_0

    def test_future_method_1():
        def inner_future_method_1():
            pass

        class test_class_1:
            test_inner_future_method_1 = inner_future_method_1
        return test_class_1

    def test_future_method_2():
        def inner_future_method_2():
            pass

        class test_class_2:
            test_inner_future_method_2 = inner_future_method_2


# Generated at 2022-06-26 07:55:01.525083
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0: Future
    future_set_exception_unless_cancelled(future_0, ValueError())
    future_1: Future
    future_set_exception_unless_cancelled(future_1, KeyError())
    future_2: Future
    future_set_exception_unless_cancelled(future_2, NameError())


# Generated at 2022-06-26 07:55:22.859125
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    assert not f1.done() is False
    assert not f2.done() is False
    chain_future(f1, f2)
    f1.set_result(None)
    assert f1.done() is True
    assert f2.done() is True


# Generated at 2022-06-26 07:55:33.977965
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = Exception()

    # Test 1: case where the future is not cancelled
    try:
        future_set_exception_unless_cancelled(future, exception)
        assert(future.exception() == exception)
    except:
        assert(False)
    finally:
        future.cancel()

    # Test 2: case where the future is cancelled
    future = Future()
    future.cancel()
    try:
        future_set_exception_unless_cancelled(future, exception)
    except:
        assert(False)
    finally:
        assert(future.exception() is None)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:55:34.658194
# Unit test for function chain_future
def test_chain_future():
    assert True



# Generated at 2022-06-26 07:55:38.912646
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    fn, *args = 0, 1, 2
    kwargs = {'a':'a', 'b':'b'}
    future = executor.submit(fn, *args, **kwargs)
    assert type(future) == futures.Future


# Generated at 2022-06-26 07:55:49.154687
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    test_future = Future()  # type: Future[_T]
    test_value = "test"  # type: _T
    future_set_result_unless_cancelled(test_future, test_value)
    assert test_future.result() == test_value
    test_future = Future()  # type: Future[_T]
    test_future.set_result(test_value)
    future_set_result_unless_cancelled(test_future, test_value)
    assert test_future.result() == test_value
    test_future = Future()  # type: Future[_T]
    test_future.set_exception(test_value)
    future_set_result_unless_cancelled(test_future, test_value)
    assert test_future.ex

# Generated at 2022-06-26 07:55:56.787805
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = Future()
    test_result = 1
    future_set_result_unless_cancelled(test_future, test_result)
    assert test_future.result() == test_result

    test_future.cancel()
    test_result = 2
    future_set_result_unless_cancelled(test_future, test_result)
    assert test_future.result() == None


# Generated at 2022-06-26 07:56:07.221558
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.gen

    class Foo:
        # Unit test for class Foo
        def __init__(self, *args, **kwargs):
            self._executor = None
            self._thread_pool = None

        def _initialize_executor(self):
            if self._executor is None:
                self._executor = dummy_executor

        def _initialize_thread_pool(self):
            if self._thread_pool is None:
                self._thread_pool = dummy_executor

        @tornado.gen.coroutine
        def test(self):
            yield run_on_executor()(self.func)

        @run_on_executor(executor="_thread_pool")
        def test_thread_pool(self):
            pass

        def func(self):
            pass

    # Unit test

# Generated at 2022-06-26 07:56:07.966727
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:56:12.942080
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)


if __name__ == "__main__":
    import tornado.testing

    tornado.testing.main()

# Generated at 2022-06-26 07:56:15.333045
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(3)
    assert future2.result() == 3


# Generated at 2022-06-26 07:56:45.342040
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test_case_0()

# Generated at 2022-06-26 07:56:47.876563
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda: 42)
    assert future.result() == 42

# Generated at 2022-06-26 07:56:49.089715
# Unit test for function run_on_executor
def test_run_on_executor():
    pass


# Generated at 2022-06-26 07:56:56.957058
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = futures.Future()
    f2 = futures.Future()
    f1.set_result(1)
    chain_future(f1, f2)
    assert f2.result() == 1

    f1 = futures.Future()
    f2 = futures.Future()
    f1.set_exception(ZeroDivisionError)
    chain_future(f1, f2)
    assert isinstance(f2.exception(), ZeroDivisionError)

    f1 = Future()
    f2 = Future()
    f1.set_result(1)
    chain_future(f1, f2)
    assert f2.result() == 1

    f1 = Future()
    f2 = Future()
    f1.set_exception(ZeroDivisionError)
    chain

# Generated at 2022-06-26 07:57:02.787896
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_1.begin()
    future_0.set_exception(None)
    future_1.done()
    chain_future(future_0, future_1)

# Generated at 2022-06-26 07:57:06.094527
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_exception(ValueError())
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())



# Generated at 2022-06-26 07:57:17.826829
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()

    chain_future(future_1, future_2)

    future_1.set_result(None)

    assert future_2.done()

    future_1 = Future()
    future_2 = Future()

    chain_future(future_1, future_2)

    future_1.set_exception(RuntimeError())

    assert future_2.done()

    future_1 = Future()
    future_2 = Future()

    chain_future(future_1, future_2)

    future_2.set_exception(RuntimeError())

    future_1.set_exception(RuntimeError())

    assert future_2.done()

    future_1 = Future()
    future_2 = Future()


# Generated at 2022-06-26 07:57:28.408955
# Unit test for function chain_future
def test_chain_future():
    f_a = Future()
    f_b = Future()
    chain_future(f_a, f_b)
    f_a.set_result(1)
    assert f_b.result() == 1
    f_a = Future()
    future_add_done_callback(f_a, lambda f: f.set_result(1))
    assert f_a.result() == 1


# Generated at 2022-06-26 07:57:38.314014
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    test_exc = Exception()

    assert(not test_future.cancelled())
    future_set_exception_unless_cancelled(test_future, test_exc)
    assert(not test_future.cancelled())
    assert(test_future.exception() == test_exc)

    test_future = Future()
    assert(not test_future.cancelled())
    test_future.cancel()
    future_set_exception_unless_cancelled(test_future, test_exc)
    assert(test_future.cancelled())

# Generated at 2022-06-26 07:57:39.409850
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = ValueError()
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is exception
