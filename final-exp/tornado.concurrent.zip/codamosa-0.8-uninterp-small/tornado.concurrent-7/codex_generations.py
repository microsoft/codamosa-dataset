

# Generated at 2022-06-26 07:48:49.460527
# Unit test for function chain_future
def test_chain_future():
    future_0 = module_1.Future()
    future = Future()

    future_1 = module_1.Future()
    future_1 = Future()

    chain_future(future, future)
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:48:59.191211
# Unit test for function run_on_executor
def test_run_on_executor():
    def handler(self, a, b):
        return a + b


    self = type('', (object,), {'io_loop': module_1.IOLoop.current(), 'executor': dummy_executor})()
    future = run_on_executor(handler)(self, 1, 2)
    assert future.result() == 3

    self = type('', (object,), {'io_loop': module_1.IOLoop.current(), '_executor': dummy_executor})()
    future = run_on_executor(executor='_executor')(handler)(self, 1, 2)
    assert future.result() == 3

    # The 'function' decorator doesn't allow the keywords to be passed to
    # the inner function, so we have to construct the wrapper ourselves

# Generated at 2022-06-26 07:49:02.096504
# Unit test for function chain_future
def test_chain_future():
    # Define input parameters
    a_0 = module_1.Future()
    b_0 = module_1.Future()
    # Call function
    chain_future(a_0, b_0)


# Generated at 2022-06-26 07:49:10.569413
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = module_1.Future()
    future_set_exception_unless_cancelled(future_0, Exception())
    future_1 = module_1.Future()
    future_1.set_exception(None)
    future_set_exception_unless_cancelled(future_1, Exception())

if __name__ == '__main__':
    test_case_0()
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-26 07:49:13.430780
# Unit test for function chain_future
def test_chain_future():
    future_1 = module_1.Future()
    future_0 = future_1
    chain_future(future_1, future_0)

# Generated at 2022-06-26 07:49:14.894984
# Unit test for function chain_future
def test_chain_future():
    module_1.Future()
    pass



# Generated at 2022-06-26 07:49:16.951787
# Unit test for function chain_future
def test_chain_future():
    assert next(module_1.Future()) == None


# Generated at 2022-06-26 07:49:19.768563
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    fn = functools.partial(print, 'Hello')
    print(dummy_executor.submit(fn, 'World'))


# Generated at 2022-06-26 07:49:28.106475
# Unit test for function chain_future
def test_chain_future():
    def unit_test(future: "Future", callback: Union[Callable, None], arg: Any) -> None:
        if arg and arg != "test":
            return
        try:
            if callback:
                callback(future)
            elif future.done():
                pass
            else:
                future.result()
            if future.done():
                pass
            else:
                future.result()
        except Exception as e:
            future.result()
        future.result()
    unit_test(False, None, "test")


# Generated at 2022-06-26 07:49:41.087747
# Unit test for function chain_future
def test_chain_future():
    exc_info_0 = sys.exc_info()
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    future_1.set_exception(exc_info_0)
    future_3 = Future()
    future_4 = Future()
    chain_future(future_3, future_4)
    future_3.set_exception(exc_info_0)
    future_5 = Future()
    future_6 = Future()
    chain_future(future_5, future_6)
    future_5.set_result('value')

## Unit test for function future_add_done_callback
#def test_future_add_done_callback():
#    def callback_0(future_0):
#        None
#    future_0 =

# Generated at 2022-06-26 07:49:53.382063
# Unit test for function run_on_executor
def test_run_on_executor():
    class A:
        @run_on_executor(executor='_thread_pool')
        def foo(arg1):
            for i in range(arg1):
                print(i)

    a = A()
    a.foo(10)

    # Unit test for function chain_future


# Generated at 2022-06-26 07:50:01.705763
# Unit test for function run_on_executor
def test_run_on_executor():
    import _asyncio as module_1

    def run_test():
        def sync_method(self):
            # type: (Future) -> None
            return None

        @module_1.run_on_executor
        def decorated(self):
            # type: (Future) -> None
            return None

        instance = Future()
        executor_attr = "_thread_pool"
        instance.executor = dummy_executor
        setattr(instance, executor_attr, dummy_executor)

        decorated(instance)
        decorated.__wrapped__(instance)
        Future.result(instance)

        @module_1.run_on_executor(executor=executor_attr)
        def decorated_with_attr(self):
            # type: (Future) -> None
            return None

        decorated_with_attr

# Generated at 2022-06-26 07:50:04.440266
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = module_0.Future()
    exception_0 = None
    future_set_exception_unless_cancelled(future_0, exception_0)


# Generated at 2022-06-26 07:50:11.134949
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future_0 = module_0.Future()
    future_1 = dummy_executor.submit(test_case_0)
    future_0.add_done_callback()
    future_1.set_result(3)
    future_2 = future_1
    assert(future_2.result() == 3)
    future_3 = future_1
    assert(future_3.result() == 3)

# Generated at 2022-06-26 07:50:14.784770
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    future_0 = dummy_executor_0.submit(lambda arg_0: arg_0, (3))
    future_0.result()


# Generated at 2022-06-26 07:50:26.986573
# Unit test for function chain_future
def test_chain_future():
    # Test with the Future object returned by asyncio.Future.
    future_1 = module_0.Future()
    future_2 = module_0.Future()
    chain_future(future_1, future_2)
    assert future_2.done()
    assert not future_2.cancelled()
    # Test with Future from concurrent.futures.
    futures_future_1 = futures.Future()
    futures_future_2 = futures.Future()
    chain_future(futures_future_1, futures_future_2)
    assert futures_future_2.done()
    assert not futures_future_2.cancelled()
    # Test with the Future object returned by asyncio.Future.
    future_3 = module_0.Future()
    future_4 = module_0.Future()
    future_4

# Generated at 2022-06-26 07:50:31.511047
# Unit test for function chain_future
def test_chain_future():

    print("Running test_chain_future")
    future_0 = module_0.Future()
    future_0_result = "Hello World"
    future_1 = module_0.Future()
    future_1_result = "Hello World"

    chain_future(future_0, future_1)
    future_0.set_result(future_0_result)
    future_1_result = future_1.result()

    # Do assert
    assert future_0_result == future_1_result


# Generated at 2022-06-26 07:50:36.133998
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = module_0.Future()
    future_set_exception_unless_cancelled(future_0, None)
    future_1 = module_0.Future()
    future_set_exc_info(future_1, ((), None, ()))


# Generated at 2022-06-26 07:50:37.842139
# Unit test for function run_on_executor
def test_run_on_executor():
    future_1 = module_0.Future()


# Generated at 2022-06-26 07:50:50.348695
# Unit test for function chain_future
def test_chain_future():
    import asyncio

    # This function suppresses warning messages while cancelling a
    # Future.  It restores the previous warning filters when it exits.
    def canceller():
        filters = warnings.filters[:]
        warnings.filterwarnings("ignore", category=asyncio.CancelledError)
        try:
            f.cancel()
        finally:
            warnings.filters = filters

    # This is used for normal FUTURES
    def check_normal_future(f):
        assert not f.cancelled()
        assert not f.done()
        if sys.version_info < (3,):
            assert isinstance(f.result(), int)
        else:
            assert isinstance(f.result(), str)
        assert f.exception() is None

    # This is used for asyncio FUTURES

# Generated at 2022-06-26 07:51:04.392600
# Unit test for function chain_future
def test_chain_future():
    fut_a, fut_b = Future(), Future()
    chain_future(fut_a, fut_b)
    assert not fut_b.done()
    fut_a.set_result(None)
    assert fut_b.done()
    assert fut_b.result() is None

    fut_a, fut_b = Future(), Future()
    chain_future(fut_a, fut_b)
    assert not fut_b.done()
    fut_a.set_exception(ValueError())
    assert fut_b.done()
    try:
        fut_b.result()
    except ValueError:
        pass
    else:
        assert False, "fut_a should have raised an exception and consequently fut_b should have raised too"

    fut_a, fut_b = Future(), Future()
    fut

# Generated at 2022-06-26 07:51:11.445067
# Unit test for function chain_future
def test_chain_future():
    fut   = Future()
    fut_1 = Future()
    res   = b"Hello"
    exp   = Exception("Exception")
    chain_future(fut, fut_1)
    # Success
    fut.set_result(res)
    assert fut_1.result() == res and fut_1.done() and not fut_1.cancelled()
    # Exception
    fut = Future()
    fut_1 = Future()
    chain_future(fut, fut_1)
    fut.set_exception(exp)
    assert fut_1.exception() == exp and fut_1.done() and not fut_1.cancelled()

# Generated at 2022-06-26 07:51:17.589620
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    future_set_exception_unless_cancelled(future_0, None)
    future_1 = Future()
    future_1.cancel()
    future_set_exception_unless_cancelled(future_1, None)
    assert True



# Generated at 2022-06-26 07:51:18.328878
# Unit test for function run_on_executor
def test_run_on_executor():
    pass

# Generated at 2022-06-26 07:51:19.899462
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:51:23.783340
# Unit test for function chain_future
def test_chain_future():
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    assert future_b.done() == False
    future_a.set_result(1)
    assert future_b.done() == True



# Generated at 2022-06-26 07:51:30.689757
# Unit test for function chain_future
def test_chain_future():
    @asyncio.coroutine
    def test_a():
        a = asyncio.Future()
        b = asyncio.Future()
        chain_future(a, b)
        a.set_result(5)
        return b
    @asyncio.coroutine
    def test_b():
        a = asyncio.Future()
        b = asyncio.Future()
        chain_future(b, a)
        b.set_result(5)
        return a
    @asyncio.coroutine
    def test_c():
        a = asyncio.Future()
        b = asyncio.Future()
        chain_future(a, b)
        a.set_exception(ZeroDivisionError())
        return b
    @asyncio.coroutine
    def test_d():
        a = asyncio

# Generated at 2022-06-26 07:51:31.115624
# Unit test for function chain_future
def test_chain_future():
    pass

# Generated at 2022-06-26 07:51:35.973565
# Unit test for function run_on_executor
def test_run_on_executor():
    # Test that decorator can be called with no arguments.
    callable_0 = run_on_executor()
    # Test that function can be called with no arguments.
    assert callable_0() is not None
    # Test that function's return value is a future.
    assert is_future(callable_0()) is True

# Generated at 2022-06-26 07:51:38.760692
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, Exception())
    with pytest.raises(Exception):
        f.result()



# Generated at 2022-06-26 07:51:51.326813
# Unit test for function chain_future
def test_chain_future():
    def run(executor):
        f1 = executor.submit(lambda: True)
        f2 = Future()
        chain_future(f1, f2)
        res = f2.result()
        assert res == True, res

    executor = futures.ThreadPoolExecutor(1)
    run(executor)
    executor.shutdown()



# Generated at 2022-06-26 07:51:55.182051
# Unit test for function run_on_executor
def test_run_on_executor():
    class TestRunOnExecutor:
        def __init__(self):
            self.executor = None

        @run_on_executor
        def test_fn(self):
            pass
    a = TestRunOnExecutor()
    assert isinstance(a.test_fn, types.MethodType)



# Generated at 2022-06-26 07:51:59.472734
# Unit test for function chain_future
def test_chain_future():
    e1 = Future()
    e2 = Future()
    chain_future(e1, e2)
    e1.set_result(None)
    assert e2.done()



# Generated at 2022-06-26 07:52:02.477937
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = future_set_result_unless_cancelled(Future, 0)
    assert future.result() == 0


# Generated at 2022-06-26 07:52:11.762015
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Create an asyncio.Future for testing
    future = Future()

    # Uncomment the line above and comment the line below to test with a concurrent.futures.Future
    # future = futures.Future()

    # No exception if not cancelled
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    # Exception is logged if future is cancelled
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-26 07:52:22.974183
# Unit test for function chain_future
def test_chain_future():
    def copy(a: Future) -> None:
        assert a is a
        assert b.done()
        assert a.result()
        assert not b.exc_info()
        assert a.exception() is None
        #assert not b.exception()

    dummy = Future()
    b = Future()
    a = dummy
    chain_future(a, b)
    #assert not a.done()
    #assert not b.done()
    a.set_result(True)
    assert a.done()
    assert b.done()


# Generated at 2022-06-26 07:52:28.206764
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_obj = Future()
    exc = Exception('raised exception')
    future_set_exception_unless_cancelled(future_obj, exc)
    assert future_obj.exception() == exc
    assert future_obj.done() == True
    assert future_obj.cancelled() == False
    assert future_obj.done() == True
    assert future_obj.result() == None


# Generated at 2022-06-26 07:52:41.303393
# Unit test for function run_on_executor
def test_run_on_executor():
    # TODO: Fix type stub
    #       https://github.com/python/mypy/issues/6175
    import typing
    from typing import Any, Callable, Optional, Tuple, Union

    _T = typing.TypeVar("_T")


# Generated at 2022-06-26 07:52:49.593670
# Unit test for function chain_future
def test_chain_future():
    future0 = Future()
    future1 = Future()
    future1.add_done_callback(lambda future: None)
    future2 = Future()
    future2.add_done_callback(lambda future: None)
    chain_future(future0, future1)
    chain_future(future1, future2)
    future0.set_result("YOLO")
    assert future1.result() is "YOLO"
    assert future2.result() is "YOLO"
    future1.cancel()
    assert future0.cancelled() is False
    assert future2.cancelled() is False

# Generated at 2022-06-26 07:52:54.812773
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future
    exc = Exception("Exception 0")  # type: BaseException
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    future = Future()  # type: Future
    future_set_exception_unless_cancelled(future, None)
    assert future.exception() is None



# Generated at 2022-06-26 07:53:13.615580
# Unit test for function chain_future
def test_chain_future():
    pass

# Generated at 2022-06-26 07:53:18.798766
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    def callback_0(future_0):
        exc_info = (None, None, None)
        future_set_exc_info(future_0, exc_info)
    callback = callback_0

    future_add_done_callback(future, callback)


# Generated at 2022-06-26 07:53:25.325603
# Unit test for function chain_future
def test_chain_future():
    future_0 = futures.Future()  # type: futures.Future
    future_1 = Future()  # type: Future
    future_2 = Future()  # type: Future
    future_3 = futures.Future()  # type: futures.Future

    chain_future(future_0, future_1)
    chain_future(future_2, future_3)
    future_0.set_result(1)
    future_2.set_exception(Exception())
    assert future_1.result() == 1
    assert isinstance(future_3.exception(), Exception)


# Generated at 2022-06-26 07:53:28.182230
# Unit test for function chain_future
def test_chain_future():
    def test_function_0(result: "Future[_T]") -> None:
        # type: (...) -> None
        return None



# Generated at 2022-06-26 07:53:29.978689
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.cancelled() == False


# Generated at 2022-06-26 07:53:35.551634
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    executor = futures.ThreadPoolExecutor(max_workers=2)
    f1 = Future()  # type: Future[int]
    f2 = executor.submit(lambda: 2)
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1
    executor.shutdown()



# Generated at 2022-06-26 07:53:39.488072
# Unit test for function chain_future
def test_chain_future():
    future_1, future_2 = Future(), Future()
    chain_future(future_1, future_2)
    return


# Generated at 2022-06-26 07:53:41.222872
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)



# Generated at 2022-06-26 07:53:48.261963
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """
    Examples:

    >>> import tornado.gen
    >>> f = tornado.gen.Future()
    >>> future_set_result_unless_cancelled(f, 42)
    >>> f.result()
    42
    >>> f = tornado.gen.Future()
    >>> f.cancel()
    >>> future_set_result_unless_cancelled(f, 42)
    >>> f.cancelled()
    True

    """
    pass

# Generated at 2022-06-26 07:53:51.924112
# Unit test for function chain_future
def test_chain_future():
    future: Future[int] = Future()
    another_future: Future[int] = Future()
    future.set_result(3)
    chain_future(future, another_future)
    assert another_future.result() == 3

# Generated at 2022-06-26 07:54:23.322471
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def set_exception_by_future(future):
        future_set_exception_unless_cancelled(future, Exception('exception'))

    def cancel_future():
        return future.cancel()

    def set_exception_with_thread(future):
        # This function will be run in another thread
        # If the future has been cancelled, the exception will not be set
        # In this case, the exception will be set
        future.exception()

    # Create and cancel future
    future = asyncio.Future()
    cancel_future()

    # Add done callback to the furture, which will set the exception
    # In this case, the exception will not be set
    future_add_done_callback(future, set_exception_by_future)

    # Set exception in another thread
    asyncio.ensure

# Generated at 2022-06-26 07:54:26.852627
# Unit test for function run_on_executor
def test_run_on_executor():
    def func_0(self):
        pass
    callable_0 = run_on_executor(func_0)
    callable_1 = run_on_executor(executor="_thread_pool")(func_0)


# Generated at 2022-06-26 07:54:37.525853
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures
    import unittest
    from unittest import mock
    from tornado.ioloop import IOLoop
    from tornado import testing

    class TestCase(testing.AsyncTestCase):
        def setUp(self) -> None:
            super().setUp()

            self._executor = concurrent.futures.ThreadPoolExecutor(2)
            self._thread_pool = concurrent.futures.ThreadPoolExecutor(2)
            self._loop = IOLoop()

        def tearDown(self) -> None:
            self._executor.shutdown()
            self._thread_pool.shutdown()
            super().tearDown()

        @run_on_executor()
        def slow_sum(self, a: int, b: int) -> int:
            self.slow()
            return a

# Generated at 2022-06-26 07:54:48.000661
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """
    This test case verifies that the future_set_exception_unless_cancelled()
    works properly. It checks the condition in which the future is not
    cancelled and the condition in which the future is cancelled.
    """
    from tornado import ioloop
    from tornado.concurrent import futures

    async_future = futures.Future()
    future_set_exception_unless_cancelled(async_future, Exception())
    assert async_future.exception() is not None

    async_future = futures.Future()
    async_future.cancel()
    future_set_exception_unless_cancelled(async_future, Exception())
    assert async_future.exception() is None

# Generated at 2022-06-26 07:54:55.650259
# Unit test for function chain_future
def test_chain_future():
    executor = futures.ThreadPoolExecutor(max_workers=1)
    io_loop = asyncio.new_event_loop()
    future_0 = Future()  # type: Future
    future_1 = executor.submit(lambda x: x, 0)  # type: futures.Future
    future_1.add_done_callback(lambda future: future_0.set_result(future.result()))
    future_2 = Future()  # type: Future
    future_3 = Future()  # type: Future
    # test case 0
    chain_future(future_0, future_2)
    future_0.set_result(0)
    # test case 1
    chain_future(future_1, future_3)



# Generated at 2022-06-26 07:55:04.093073
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert b.done() is False
    a.set_result(None)
    assert b.done() is True
    assert b.result() is None

    a = Future()
    b = Future()
    a.set_exception(ValueError)
    chain_future(a, b)
    assert b.done() is True
    assert isinstance(
        b.exception(), ValueError
    )  # Type-check to make sure exception is propagated.

    a = Future()
    b = Future()
    a.set_exception(ValueError)
    a.cancel()
    chain_future(a, b)
    assert b.done() is True

# Generated at 2022-06-26 07:55:15.319772
# Unit test for function chain_future
def test_chain_future():
    def foo():
        pass

    f1 = asyncio.Future()
    f2 = asyncio.Future()
    chain_future(f1, f2)

    f2.result()

    f1.set_result(1)
    assert f2.result() == 1

    f1.cancel()
    assert not f1.cancelled()
    assert not f2.cancelled()
    assert f2.result() == 1

    f1.set_exception(RuntimeError('test'))
    try:
        f2.result()
        assert False, 'should raise exception'
    except RuntimeError as e:
        assert e.args[0] == 'test'
    assert not f2.cancelled()

    f1.cancel()
    assert f1.cancelled()
    assert not f

# Generated at 2022-06-26 07:55:18.218584
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()  # type: Future[None]
    future_set_result_unless_cancelled(future_0, None)



# Generated at 2022-06-26 07:55:21.455672
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_set_exception_unless_cancelled(Future(), ValueError())


# Generated at 2022-06-26 07:55:28.006354
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1
    future.cancel()
    future2 = Future()
    future_set_result_unless_cancelled(future2, 3)
    assert future2.result() == 3


# Generated at 2022-06-26 07:56:31.704957
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    from tornado.log import app_log as log
    from unittest.mock import MagicMock

    def create_future():
        future = Future()
        future.cancelled.return_value = False
        future.exception.return_value = None
        return future

    class Callback():
        def __init__(self):
            self.called = False

        def __call__(self):
            self.called = True

    class FutureTestCase(unittest.TestCase):
        def setUp(self):
            log.error = MagicMock()

        def test_future_set_exception_unless_cancelled(self):
            future = create_future()
            exc = Exception()
            future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-26 07:56:38.676575
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    exc_info = (
        type(None),
        Exception("test_future_set_exception_unless_cancelled"),
        type(None),
    )
    future_set_exc_info(future_0, exc_info)

    future_1 = Future()
    future_1.cancel()
    future_set_exc_info(future_1, exc_info)

# Generated at 2022-06-26 07:56:43.680978
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    fn = lambda x: x*x
    dummy_executor.submit(fn, 2)
    assert dummy_executor.submit(fn, 2).result() == fn(2) \
        , "test_DummyExecutor_submit: actual != expected"


# Generated at 2022-06-26 07:56:50.107142
# Unit test for function run_on_executor
def test_run_on_executor():
    def callback(future: asyncio.Future) -> None:
        raise ReturnValueIgnoredError
    def test_case_1():
        callable_1 = run_on_executor()

    class GenFuture:
        def __next__(self):
            pass
        def __iter__(self):
            pass
        def send(self, val):
            pass
        def throw(self, typ, val=None, tb=None):
            pass
        def close(self):
            pass

# Generated at 2022-06-26 07:56:53.438521
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result('test')
    assert f2.result() == 'test'


# Generated at 2022-06-26 07:56:58.376081
# Unit test for function chain_future
def test_chain_future():
    asyncio.run(test_chain_future_async())

async def test_chain_future_async():
    future = Future()

    def set_true():
        return True

    def set_false():
        return False

    assert not future.done()

    chain_future(dummy_executor.submit(set_true), future)
    assert future.result()

    future = Future()

    chain_future(dummy_executor.submit(set_false), future)
    assert not future.result()

# Generated at 2022-06-26 07:57:04.601601
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, Exception())
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())



# Generated at 2022-06-26 07:57:08.465542
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    @run_on_executor
    def func_0():
        # type: () -> None
        pass
    func_0()
    dummy_executor.submit(func_0)
    @run_on_executor(executor=0)
    def func_1():
        # type: () -> None
        pass
    func_1()
    dummy_executor.submit(func_1)
    IOLoop_0 = IOLoop.current()
    future_0 = Future()  # type: Future[Any]
    future_1 = Future()  # type: Future[Any]
    conc_future_0 = futures.Future()  # type: futures.Future[Any]
    conc_future_0.set_result(None)

# Generated at 2022-06-26 07:57:21.263195
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    def test_fn_0(self):
        self.test_0_completed = True

    def test_fn_1(self):
        self.test_1_completed = True

    def test_fn_2(self):
        self.test_2_completed = True

    def async_test_fn_3(self):
        self.async_test_3_completed = True

    def async_test_fn_4(self):
        self.async_test_4_completed = True

    def async_test_fn_5(self):
        self.async_test_5_completed = True

    future_0 = future_set_result_unless_cancelled(async_test_fn_3(self), 3)
    future_1 = Future()

# Generated at 2022-06-26 07:57:25.122000
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception('hello')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

