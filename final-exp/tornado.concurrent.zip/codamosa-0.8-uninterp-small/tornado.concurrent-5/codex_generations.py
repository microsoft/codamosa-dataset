

# Generated at 2022-06-26 07:48:59.129492
# Unit test for function chain_future
def test_chain_future():
    num_tests = 3
    future1 = Future()
    future2 = Future()
    future3 = Future()
    future4 = Future()
    future5 = Future()
    future6 = Future()
    future11 = Future()
    future12 = Future()
    future13 = Future()
    future14 = Future()
    future15 = Future()
    future16 = Future()
    future21 = Future()
    future22 = Future()
    future23 = Future()
    future24 = Future()
    future25 = Future()
    future26 = Future()

    # test 1
    def test_exception(future):
        future1.set_exception(ValueError)

    def test_callback(future):
        assert future.exception() == ValueError
        future1.set_result(True)

    future11.set_ex

# Generated at 2022-06-26 07:49:01.697797
# Unit test for function chain_future
def test_chain_future():
    future_0 = future_0(future_0)
    future_add_done_callback(future_0, callback_0)
    future_1 = future_1()


# Generated at 2022-06-26 07:49:14.847938
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest.mock as mock

    # Case 0: Future is not cancelled
    future_0 = Future()
    exception_0: Optional[BaseException] = TypeError()
    future_set_exception_unless_cancelled(future_0, exception_0)
    future_0.result()

    # Case 1: Future is cancelled
    future_1 = Future()
    exception_1: Optional[BaseException] = TypeError()
    future_1.cancel()
    future_set_exception_unless_cancelled(future_1, exception_1)

    with mock.patch("tornado.concurrent.futures.log.error") as mock_error:
        future_set_exception_unless_cancelled(future_1, exception_1)

# Generated at 2022-06-26 07:49:27.785753
# Unit test for function chain_future
def test_chain_future():
    import time
    import threading

    class DummyThreadPoolExecutor(futures.Executor):
        def __init__(self):
            self.done = False

        def submit(self, fn, *args, **kwargs):
            ret = futures.Future()
            if self.done:
                raise Exception("called too late")

            def _call_fn():
                time.sleep(0.01)
                try:
                    ret.set_result(fn(*args, **kwargs))
                except Exception:
                    ret.set_exception(sys.exc_info())

            threading.Thread(target=_call_fn).start()
            return ret

    dummy_thread_pool_executor = DummyThreadPoolExecutor()
    d = {"executor": dummy_thread_pool_executor}


# Generated at 2022-06-26 07:49:39.895245
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # Verify that this function does not raise an exception in the simplest case
    future = Future() # noqa
    try:
        future.set_exception(Exception())
    except Exception:
        pass
    else:
        raise AssertionError('expected exception')
    # No scheduled callbacks
    future = Future()
    try:
        future.set_exception(Exception())
    except Exception:
        pass
    else:
        raise AssertionError('expected exception')
    # Called back after scheduled callbacks have been run
    future = Future()
    future.add_done_callback(lambda f: None)
    try:
        future.set_exception(Exception())
    except Exception:
        pass
    else:
        raise AssertionError('expected exception')

# Generated at 2022-06-26 07:49:50.444978
# Unit test for function run_on_executor
def test_run_on_executor():
    def function_0() -> None:
        pass

    def function_1() -> None:
        pass

    def function_2() -> None:
        pass

    def function_3() -> None:
        pass

    def function_4() -> None:
        pass

    callable_0 = run_on_executor()
    callable_1 = run_on_executor(executor="executor_1")
    callable_2 = run_on_executor(executor="executor_2")
    callable_3 = run_on_executor(executor="executor_3")
    callable_4 = run_on_executor(executor="executor_4")
    callable_5 = run_on_executor(executor="executor_5")
    callable_6 = run_on_

# Generated at 2022-06-26 07:49:54.638289
# Unit test for function chain_future
def test_chain_future():
    # Create the first future
    future_0 = Future()

    # Create the second future
    future_1 = Future()

    # Connect the two futures by chaining
    chain_future(future_0, future_1)

    # Assert that the two futures have the same result
    assert future_0.result() == future_1.result()

# Generated at 2022-06-26 07:49:56.460986
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future.set_result("Success!")
    chain_future(future, future)
    assert future.result() == "Success!"


# Generated at 2022-06-26 07:50:01.183595
# Unit test for function chain_future
def test_chain_future():
    # Tests a simple future -> future chaining
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    future_0.set_result(None)
    assert future_0.done()
    assert future_0.result() is None
    assert future_1.done()
    assert future_1.result() is None


# Generated at 2022-06-26 07:50:05.347584
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.concurrent import Future
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.done()

# Generated at 2022-06-26 07:50:21.572010
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future_chain = Future()
    chain_future(future, future_chain)
    assert not future_chain.done()
    
    future.set_result(1)
    assert future_chain.result() == 1
    future_chain.result()

    future2 = Future()
    future_chain2 = Future()
    chain_future(future2, future_chain2)
    future_chain2.cancel()
    assert future_chain2.cancelled()
    future2.set_result(5)
    assert future_chain2.cancelled()
    assert not future_chain2.done()


# Generated at 2022-06-26 07:50:25.385278
# Unit test for function run_on_executor
def test_run_on_executor():
    pass
    def f(x: int) -> int:
        return x + 1


    run_on_executor(f)
    run_on_executor("f")
    # run_on_executor("f", "")

# Generated at 2022-06-26 07:50:33.704904
# Unit test for function chain_future
def test_chain_future():
    import tornado
    import tornado.httpclient
    import tornado.testing
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()

    class TestCase(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            def handle_future(future):
                self.stop()
                self.assertTrue(future.done())
                self.assertEqual(future.result(), 42)

            tornado.httpclient.AsyncHTTPClient().fetch(
                "https://httpbin.org/get?show_env=1",
                handle_future
            )

            self.wait()


# Generated at 2022-06-26 07:50:36.462656
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    callable_0 = future_set_exception_unless_cancelled(future_set_exception_unless_cancelled)
    return callable_0

# Generated at 2022-06-26 07:50:39.401672
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    exec = DummyExecutor()
    # case 0
    value = exec.submit(lambda: 1, ())
    assert isinstance(value, futures.Future)


# Generated at 2022-06-26 07:50:52.643046
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    i = IOLoop()
    executor = ThreadPoolExecutor(2)

    class Foo(object):
        def __init__(self):
            self.executor = executor

        @run_on_executor
        def f(self, a, b, c=1, d=2, *args, **kwargs):
            return a + b + c

        @run_on_executor(executor="executor")
        def g(self, a, b, c=1, d=2, *args, **kwargs):
            return a + b + c

        @run_on_executor(executor="_executor")
        def h(self, a, b, c=1, d=2, *args, **kwargs):
            return a + b + c

# Generated at 2022-06-26 07:50:59.421348
# Unit test for function chain_future
def test_chain_future():
    # Code snippet implements the following logic:
    #
    # a = Future()
    # b = Future()
    # chain_future(a, b)
    # 
    # a.set_result(1)
    # assert a.result() == 1
    #
    # assert b.result() == 1
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(1)
    assert a.result() == 1
    assert b.result() == 1



# Generated at 2022-06-26 07:51:04.818513
# Unit test for function chain_future
def test_chain_future():
    future_0 = asyncio.get_event_loop()
    future_0.run_until_complete(chain_future)


# Generated at 2022-06-26 07:51:08.771483
# Unit test for function run_on_executor
def test_run_on_executor():
    test_case_0()


if __name__ == "__main__":
    import logging

    logging.basicConfig()
    # test_main()
    test_run_on_executor()

# Generated at 2022-06-26 07:51:20.480543
# Unit test for function chain_future
def test_chain_future():
    # Type warning
    def test_arguments_decorator(a: "Future[int]", b: "Future[int]"):
        pass

    test_arguments_decorator(
        futures.Future(), futures.Future()
    )  # OK
    test_arguments_decorator(
        futures.Future(), asyncio.Future()
    )  # OK
    test_arguments_decorator(
        asyncio.Future(), futures.Future()
    )  # OK
    test_arguments_decorator(
        asyncio.Future(), asyncio.Future()
    )  # OK
    test_arguments_decorator(
        a=futures.Future(),
        b=futures.Future(),
    )  # OK

# Generated at 2022-06-26 07:51:30.468696
# Unit test for function chain_future
def test_chain_future():

    first = Future()
    second = Future()

    def first_set_result():
        first.set_result(1)

    def second_set_result():
        second.set_result(2)

    def first_set_exception():
        first.set_exception(1)

    def second_set_exception():
        second.set_exception(2)

    def first_set_exc_info():
        first.set_exc_info(1)

    def second_set_exc_info():
        second.set_exc_info(2)

    def second_set_result_unless_cancelled():
        second.set_result(2)

    def second_set_exception_unless_cancelled():
        second.set_exception(2)

    chain_future(first, second)

# Generated at 2022-06-26 07:51:41.402936
# Unit test for function chain_future
def test_chain_future():
    def fn():
        return "result"

    def fn2(a: str, b: str = "str") -> bool:
        return True

    def fn3() -> int:
        return 1

    future: Future[str] = Future()
    future2: Future[bool] = Future()
    chain_future(future, future2)
    future.set_result('string')
    assert future2.result() == "result"

    future: Future[int] = Future()
    future2: Future[int] = Future()
    chain_future(future, future2)
    future.set_exception(Exception())
    try:
        future2.result()
        assert False
    except Exception:
        assert True


if __name__ == "__main__":
    test_case_0()
    test_chain_future

# Generated at 2022-06-26 07:51:45.550238
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    def somefunction_0(*args, **kwargs): return _NO_RESULT
    args_0 = []
    kwargs_0 = {
    }
    future_0 = dummy_executor.submit(somefunction_0, *args_0, **kwargs_0)

if __name__ == "__main__":
    test_case_0()
    test_DummyExecutor_submit()

# Generated at 2022-06-26 07:51:46.519276
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit()

# Generated at 2022-06-26 07:51:56.521171
# Unit test for function chain_future
def test_chain_future():
    set_result = None
    set_exception = None
    set_result_2 = None
    set_exception_2 = None
    def callback(future):
        nonlocal set_result, set_exception
        if future.exception() is not None:
            set_exception = future.exception()
        else:
            set_result = future.result()
    def callback_2(future):
        nonlocal set_result_2, set_exception_2
        if future.exception() is not None:
            set_exception_2 = future.exception()
        else:
            set_result_2 = future.result()
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.add_done_callback(callback)
    f2.add

# Generated at 2022-06-26 07:51:57.804928
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:52:11.075314
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()  # type: DummyExecutor
    # assert isinstance(executor, DummyExecutor), "Expected DummyExecutor, but got %r" % (executor,)
    funcs = [lambda : None, lambda x: x]  # type: List[Callable]
    args = [1, 2, 3]  # type: List[Any]
    kwargs = dict(foo='foo', bar='bar', baz='baz')  # type: Dict[Any, Any]
    for func in funcs:
        for arg in args:
            for key, val in kwargs.items():
                future = executor.submit(func, arg, **{key: val})  # type: Future

# Generated at 2022-06-26 07:52:18.827226
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    future_set_result_unless_cancelled(future, "Test")

    assert future.result() == "Test"

    future = Future()
    future.cancel()

    result = future_set_result_unless_cancelled(future, "Test")

    assert result == None
    assert future.result() == None



# Generated at 2022-06-26 07:52:24.285180
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result("foo")
    assert g.result() == "foo"
    # When g is cancelled, f should also be cancelled
    g.cancel()
    assert f.cancelled()



# Generated at 2022-06-26 07:52:27.165861
# Unit test for function run_on_executor
def test_run_on_executor():
    def test(self):
        pass

    test = run_on_executor()(test)

    # 'Callable[[Any], Future]' is a valid type
    test: Callable[[Any], Future]



# Generated at 2022-06-26 07:52:43.558728
# Unit test for function chain_future
def test_chain_future():
    # static type check
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)

    # type checks
    def run_on_executor_decorator(fn: Callable) -> Callable[..., Future]:
        executor = "executor"

        @functools.wraps(fn)
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> Future:
            async_future = Future()
            conc_future = getattr(self, executor).submit(fn, self, *args, **kwargs)
            chain_future(conc_future, async_future)
            return async_future

        return wrapper

    def test_case_1():
        callable_1 = run_on_executor_decorator(lambda: 1)



# Generated at 2022-06-26 07:52:49.396485
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    my_future = asyncio.Future()
    if (my_future.cancelled()):
        future_set_result_unless_cancelled(my_future, 'result')
    my_future = concurrent.futures.Future()
    if (my_future.cancelled()):
        future_set_result_unless_cancelled(my_future, 'result')


# Generated at 2022-06-26 07:52:50.677060
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()  # type: Future[int]
    future_1 = Future()  # type: Future[int]

    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:52:52.025087
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_set_exception_unless_cancelled(None, None)

# Generated at 2022-06-26 07:52:55.198935
# Unit test for function chain_future
def test_chain_future():
    class Object0:
        def __init__(self):
            self.async_future = Future()
            self.conc_future = Future()

    obj_0 = Object0()

    chain_future(obj_0.async_future, obj_0.conc_future)

# Generated at 2022-06-26 07:53:06.877224
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def exec_0_0():
        f = Future()
        f.cancel()
        future_set_exception_unless_cancelled(f, Exception())
    exec_0_0()

    def exec_0_1():
        f = ()

        def exec_1_0():
            future_set_exception_unless_cancelled(f, Exception())

        exec_1_0()
    exec_0_1()

    def exec_0_2():
        f = Exception()

        def exec_1_0():
            future_set_exception_unless_cancelled(f, BaseException())

        exec_1_0()
    exec_0_2()


# Generated at 2022-06-26 07:53:13.143326
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado.ioloop
    from concurrent.futures import Future
    from tornado.platform.asyncio import to_asyncio_future

    _ = tornado.ioloop.IOLoop()
    f = Future()
    f = to_asyncio_future(f)

    future_set_exception_unless_cancelled(f, Exception())
    future_set_exception_unless_cancelled(f, Exception())

    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())


if __name__ == "__main__":
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-26 07:53:20.491234
# Unit test for function chain_future
def test_chain_future():
    async def async_function() -> None:
        raise ValueError

    def sync_function() -> Future:
        return async_function()

    try:
        future_0 = Future()
        chain_future(sync_function(), future_0)

        # AssertionError: future_set_exc_info called with no exception
        future_set_exc_info(future_0, (None, ValueError, None))
    except AssertionError:
        pass


# Generated at 2022-06-26 07:53:21.208296
# Unit test for function chain_future
def test_chain_future():
    chain_future(Future(), Future())


# Generated at 2022-06-26 07:53:22.175938
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:53:34.390740
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    obj = DummyExecutor()
    fn = int
    var_args = ()
    var_kwargs = {}
    obj.submit(fn, *var_args, **var_kwargs)


# Unit tests for method run_on_executor of class functools.partial

# Generated at 2022-06-26 07:53:37.363076
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    run_on_executor()

    def test(self):
        pass



# Generated at 2022-06-26 07:53:49.675151
# Unit test for function chain_future
def test_chain_future():
    from concurrent.futures import Future, ThreadPoolExecutor, TimeoutError
    from tornado.ioloop import IOLoop

    ioloop = IOLoop.current()

    # type: ignore
    executor = ThreadPoolExecutor(1)

    def do_something(a: int, b: int) -> int:
        return a * b

    future_0 = Future()
    future_1 = Future()

    def handler_0(future_10):
        assert future_10 is future_0
        future_1.set_result(True)

    future_add_done_callback(future_0, handler_0)
    conc_future_0 = executor.submit(do_something, 2, 3)
    chain_future(conc_future_0, future_0)

# Generated at 2022-06-26 07:54:01.646518
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(0)
    assert b.done()
    assert b.result() == 0

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(ValueError())
    assert b.done()
    with pytest.raises(ValueError):
        b.result()

    a = Future()
    b = Future()
    a.set_exception(ValueError())
    chain_future(a, b)
    assert b.done()
    with pytest.raises(ValueError):
        b.result()

    a = Future()
    b = Future()
    b.set_exception(ValueError())
    chain_future(a, b)

# Generated at 2022-06-26 07:54:11.094739
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_2 = Future()
    def func_0():
        return None
    def func_1():
        return 1
    def func_2():
        return 2
    func_0()
    func_1()
    func_2()
    chain_future(future_1, future_2)
    future_2.set_result(None)
    future_1.set_result(1)
    future_0.set_result(2)



# Generated at 2022-06-26 07:54:16.270766
# Unit test for function run_on_executor
def test_run_on_executor():
    def test(x=1):
        pass

    @run_on_executor
    def test2(x=1):
        pass

    @run_on_executor(executor='_thread_pool')
    def test3(x=1):
        pass

    @run_on_executor(executor='_process_pool')
    def test4(x=1):
        pass

# Generated at 2022-06-26 07:54:18.422018
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut = Future()
    fut.set_result(None)
    future_set_result_unless_cancelled(fut, 1)


# Generated at 2022-06-26 07:54:31.504786
# Unit test for function chain_future
def test_chain_future():
    def test_chain_future_1():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        future1.set_result(None)
    def test_chain_future_2():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        future1.set_exception(Exception())
    def test_chain_future_3():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        future2.set_result(None)
        future1.set_result(None)
    def test_chain_future_4():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        future1.set_

# Generated at 2022-06-26 07:54:34.948132
# Unit test for function chain_future
def test_chain_future():
    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42



# Generated at 2022-06-26 07:54:40.942418
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future2 = Future()
    chain_future(future, future2)
    future.set_result(42)
    assert future2.result() == 42

# test from tornado.concurrent

# Generated at 2022-06-26 07:55:14.750444
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Create an asyncio Future and cancel it
    future = Future()
    future.cancel()
    assert future.cancelled() == True
    # The call to future_set_result_unless_cancelled should not change the state
    # of the future
    future_set_result_unless_cancelled(future, "helloworld!")
    assert future.cancelled() == True
    # Create another asyncio Future
    future = Future()
    assert future.done() == False
    # The call to future_set_result_unless_cancelled should set the result
    future_set_result_unless_cancelled(future, "helloworld!")
    assert future.done() == True
    assert future.result() == "helloworld!"


# Generated at 2022-06-26 07:55:17.007507
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    test_future.cancel()
    future_set_exception_unless_cancelled(test_future, Exception())

# Generated at 2022-06-26 07:55:19.795262
# Unit test for function chain_future
def test_chain_future():
    future_0: Future = Future()
    future_1: Future = Future()
    chain_future( future_0, future_1 )


# Generated at 2022-06-26 07:55:33.276707
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor_0 = DummyExecutor()
    callable_0 = lambda x: x
    args_0 = (callable_0,)
    # call the method
    future_0 = executor_0.submit(callable_0)
    assert isinstance(future_0, Future) == True
    bool_0 = future_0.done()
    assert bool_0 == True
    str_0 = future_0.result()
    assert isinstance(str_0, str) == True
    # call the method
    future_0 = executor_0.submit(callable_0, str)
    assert isinstance(future_0, Future) == True
    bool_0 = future_0.done()
    assert bool_0 == True
    str_0 = future_0.result()

# Generated at 2022-06-26 07:55:34.749428
# Unit test for function chain_future
def test_chain_future():
    # TODO(lw): write test cases
    pass



# Generated at 2022-06-26 07:55:38.999198
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    result = object()
    future_set_result_unless_cancelled(future, result)
    assert future.result() == result
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, result)
    assert future.cancelled()

# Generated at 2022-06-26 07:55:46.441256
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_0.cancel()
    future_1 = Future()
    assert future_0.done() is True
    assert future_1.done() is False
    return_value_0 = chain_future(future_0, future_1)
    assert future_1.done() is True
    assert future_1.cancelled() is True


# Generated at 2022-06-26 07:55:50.868903
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future_0 = Future()  # type: Future[int]
    future_1 = Future()  # type: Future[int]
    chain_future(future_0, future_1)
    future_0.set_result(0)
    future_1.set_result(1)


if __name__ == "__main__":
    import logging

    logging.basicConfig(level=logging.DEBUG)
    test_chain_future()

# Generated at 2022-06-26 07:55:55.631145
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    future_0.set_result(None)
    assert str(future_1) == ''


# Generated at 2022-06-26 07:55:56.697436
# Unit test for function chain_future
def test_chain_future():
    pass
