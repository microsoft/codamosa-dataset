

# Generated at 2022-06-26 07:48:57.595321
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:49:01.163404
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    exception_0 = KeyError()
    try:
        future_set_exception_unless_cancelled(future_0, exception_0)
    except Exception:
        pass


# Generated at 2022-06-26 07:49:09.162988
# Unit test for function run_on_executor
def test_run_on_executor():
    # Missing arguments
    # Type error
    with pytest.raises(TypeError):
        run_on_executor(1, 2)

    @run_on_executor
    def executor_decorator_wrapper(self):
        return "executor_decorator_wrapper"

    # Tuple is not callable
    with pytest.raises(TypeError):
        executor_decorator_wrapper()



# Generated at 2022-06-26 07:49:21.675418
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """Test for function future_set_exception_unless_cancelled"""

    # test for futures.Future
    future_0 = futures.Future()  # type: Union[futures.Future, Future]
    future_set_exception_unless_cancelled(
        future_0, return_value_ignored_error_0
    )

    # test for Future
    future_0 = Future()  # type: Union[futures.Future, Future]
    future_set_exception_unless_cancelled(
        future_0, return_value_ignored_error_0
    )

    # test for cancel
    future_0 = Future()  # type: Union[futures.Future, Future]
    future_0.cancel()

# Generated at 2022-06-26 07:49:27.322217
# Unit test for function chain_future
def test_chain_future():
    # Test for function chain_future
    try:
        print('Hello World!')
    except OSError as e:
        print('OSError:', e)
    except ValueError as e:
        print('ValueError:', e)
    except:
        print('Unexpected error:', sys.exc_info()[0])



# Generated at 2022-06-26 07:49:30.180666
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    result_0 = chain_future(future_0, future_1)
    assert result_0 is None


# Generated at 2022-06-26 07:49:36.543020
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_func_0(test_arg_0: bool) -> bool:
        return bool(test_arg_0)
    dummy_executor_0 = dummy_executor
    test_func_0 = run_on_executor(test_func_0, executor=dummy_executor_0)
    test_func_0(True)


# Generated at 2022-06-26 07:49:48.960822
# Unit test for function run_on_executor
def test_run_on_executor():
    # Define a function to wrap with @run_on_executor.
    def foo(self):
        return 42

    # This is an example of how @run_on_executor would be used in a class.
    class Test:
        executor = dummy_executor

        @run_on_executor
        def future_foo(self):
            return foo(self)

    # This is the same thing, but not part of a class.
    def non_member():
        return foo(None)

    @run_on_executor
    def future_non_member():
        return non_member()

    # Run the functions and make sure the results match.
    io_loop = asyncio.get_event_loop()
    assert 42 == io_loop.run_until_complete(Test().future_foo())

# Generated at 2022-06-26 07:49:50.569101
# Unit test for function chain_future
def test_chain_future():
    list_0 = None
    assert chain_future(list_0[0], list_0[1]) is None


# Generated at 2022-06-26 07:49:56.344175
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    future_set_result_unless_cancelled(future_0, None)
    test_case_0()
    test_case_0()
    future_set_result_unless_cancelled(future_0, None)


# Generated at 2022-06-26 07:50:11.317027
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # cannot use asyncio.gather(), since Future does not have a done attribute
    future_set_exception_unless_cancelled("Hello", 'Exception')


# Generated at 2022-06-26 07:50:23.957917
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_case_0():
        bool_0 = True
    def test_case_1():
        bool_0 = True
    def test_case_2():
        bool_0 = True
    def test_case_3():
        bool_0 = True
    def test_case_4():
        bool_0 = True
    def test_case_5():
        bool_0 = True
    def test_case_6():
        bool_0 = True
    def test_case_7():
        bool_0 = True
    def test_case_8():
        bool_0 = True
    def test_case_9():
        bool_0 = True 
    def test_case_10():
        bool_0 = True
    def test_case_11():
        bool_0 = True

# Generated at 2022-06-26 07:50:31.823811
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    bool_0 = True
    future_0 = None
    exc_0 = None

    future_0 = Future()
    future_set_result_unless_cancelled(future_0, False)
    future_0.cancel()
    exc_0 = TypeError("This is a TypeError exception")
    try:
        future_set_exception_unless_cancelled(future_0, exc_0)
    except Exception:
        pass
    else:
        bool_0 = False

    if not bool_0:
        assert False


# Generated at 2022-06-26 07:50:43.906363
# Unit test for function chain_future
def test_chain_future():
    # Test future-future chaining 
    def tst_future_future(main_loop: "IOLoop") -> None:
        fu1 = Future()
        fu2 = Future()
        chain_future(fu1, fu2)
        fu1.set_result(1)
        main_loop.add_future(fu2, lambda f: main_loop.stop())
        main_loop.start()
        assert fu2.result() == 1

    # Test future-concurrent.futures.Future chaining
    def tst_future_conc_future(main_loop: "IOLoop") -> None:
        fu1 = Future()
        fu2 = futures.Future()
        chain_future(fu1, fu2)
        fu1.set_result(1)

# Generated at 2022-06-26 07:50:55.482025
# Unit test for function chain_future
def test_chain_future():
    print("##### Unit test for function chain_future")
    bool_0 = True
    bool_1 = False
    async def async_func_0():
        future_1 = Future()
        chain_future(future_1, future_0)
        future_1.set_result(10)
    
    async def async_func_1():
        await async_func_0()
        bool_0 = future_0.result() == 10
    print(bool_0)
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(async_func_1())
    finally:
        loop.close()
    print(bool_0)


# Generated at 2022-06-26 07:51:02.967873
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import asyncio
    # Test case 1: future_set_exception_unless_cancelled(asyncio future) not cancelled
    # Input: asyncio.Future
    # Output: set_exception(value)
    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() == RuntimeError("test")
    assert future.exception() == future.exception()
    assert future.exception().args
    assert isinstance(future.exception(), BaseException)
    assert isinstance(future.exception(), RuntimeError)
    assert issubclass(RuntimeError, BaseException)
    assert isinstance(future.exception(), object)
    assert not future.cancelled()
    assert future.set_exception(future.exception())

# Generated at 2022-06-26 07:51:12.372886
# Unit test for function run_on_executor
def test_run_on_executor():
    executor = getattr(dummy_executor, 'executor')
    # Test that the executor is assigned
    # This test is expected to fail
    try:
        if executor.run_on_executor() == None:
            print('ERROR: executor not set')
            return
    except:
        pass
    print('SUCCESS: executor assigned')
    return
    # Test that the current ioloop is used
    ioloop = IOLoop.current()

    # Test that the future is compatible with await
    future = run_on_executor()
    if future == None:
        print('ERROR: IOLoop not used')
        return
    if future != Future:
        print('ERROR: Future not compatible with await')
        return

# Generated at 2022-06-26 07:51:20.239692
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Testing future_set_result_unless_cancelled with future returned from asyncio.Future
    future = asyncio.Future()
    result = 3.14
    future_set_result_unless_cancelled(future, result)
    test_case_0()
    # Testing future_set_result_unless_cancelled with future returned from concurrent_future.Future
    future = concurrent_future.Future()
    result = 3.14
    future_set_result_unless_cancelled(future, result)
    test_case_0()


# Generated at 2022-06-26 07:51:28.991057
# Unit test for function chain_future
def test_chain_future():
    lst_0 = []
    lst_1 = []
    
    def copy(future: "Future[_T]") -> None:
        assert future is a
        if b.done():
            return
        if hasattr(a, "exc_info") and a.exc_info() is not None:  # type: ignore
            future_set_exc_info(b, a.exc_info())  # type: ignore
        elif a.exception() is not None:
            b.set_exception(a.exception())
        else:
            b.set_result(a.result())
    a = Future()
    b = Future()
    chain_future(a, b)
    lst_0.append(a)
    lst_0.append(b)
    return lst_0, lst_

# Generated at 2022-06-26 07:51:34.575812
# Unit test for function chain_future
def test_chain_future():
    # create a future and set the result to 'result'
    a = asyncio.Future()
    a.set_result('result')
    # create another future to chain with a
    b = asyncio.Future()
    # chain a and b
    chain_future(a, b)
    # the result of b should be 'result', which is the result of a
    assert b.result() == 'result'
    bool_0 = bool(b.result() == 'result')
    bool_1 = bool(b.result() == 'result')
    bool_2 = bool(str(b.result()) == 'result')
    # return True if the assertion is correct
    return bool_2


# Generated at 2022-06-26 07:51:46.673007
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    loop: asyncio.AbstractEventLoop
    loop = asyncio.get_event_loop()
    future_a = asyncio.Future()
    future_b = asyncio.Future()
    chain_future(future_a, future_b)
    loop.run_until_complete(future_a)
    state = future_b.result()
    # future_a should be completed before future_b
    if state:
        return
    else:
        raise ValueError()

# Generated at 2022-06-26 07:51:50.567534
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result('foo')
    assert f2.result() == 'foo'



# Generated at 2022-06-26 07:51:54.953320
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    a = futures.Future()
    try:
        raise Exception("test")
    except Exception:
        future_set_exc_info(a, sys.exc_info())
    result = a.exception()
    if result == None:
        raise Exception("future_set_exception_unless_cancelled failed 1")



# Generated at 2022-06-26 07:52:03.298285
# Unit test for function chain_future
def test_chain_future():
    import asyncio

    def test_0():
        a = Future()
        b = Future()

        chain_future(a, b)

        a.set_result(1)
        b.result()

    def test_1():
        a = asyncio.Future()
        b = asyncio.Future()

        chain_future(a, b)

        a.set_result(1)
        b.result()

    test_0()
    test_1()



# Generated at 2022-06-26 07:52:09.210923
# Unit test for function chain_future
def test_chain_future():
    future_1: Future[int] = Future()
    future_2: Future[int] = Future()
    chain_future(future_1, future_2)
    future_1.set_result(42)
    assert future_1.result() == future_2.result()



# Generated at 2022-06-26 07:52:17.160888
# Unit test for function chain_future
def test_chain_future():
    def test_0():
        raise NotImplementedError
    def set_result_unless_cancelled(value):
        raise NotImplementedError
    def set_exception_unless_cancelled(exc):
        raise NotImplementedError
    def set_exc_info():
        raise NotImplementedError
    def add_done_callback(callback):
        raise NotImplementedError

# Generated at 2022-06-26 07:52:20.889294
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

# Generated at 2022-06-26 07:52:22.058064
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:52:30.574205
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    # f2 already canceled, chain_future should not do anything
    f2.cancel()
    chain_future(f1, f2)
    assert f2.cancelled()

    # f2 is not canceled
    f2 = Future()
    chain_future(f1, f2)

    # f1 not completed
    assert not f2.done()
    f1.set_result(None)
    assert f2.done()
    assert f2.result() is None

    # f1 finished with error
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(Exception())
    assert f2.done()

# Generated at 2022-06-26 07:52:33.976260
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    future_0.result()



# Generated at 2022-06-26 07:52:51.036979
# Unit test for function chain_future
def test_chain_future():
    import random
    import tornado.gen
    import tornado.platform.asyncio

    @tornado.gen.coroutine
    def chained_callback(value: int) -> None:
        assert value == 42
        raise tornado.gen.Return(value)

    # Unit test for function future_set_result_unless_cancelled
    def test_future_set_result_unless_cancelled() -> None:
        future: Future[int] = asyncio.get_event_loop().create_future()
        random.seed(0)
        for _ in range(100):
            value = random.randint(-1000, 1000)
            future_set_result_unless_cancelled(future, value)
            assert future.result() == value


# Generated at 2022-06-26 07:52:56.749768
# Unit test for function run_on_executor
def test_run_on_executor():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(3)
    assert b.result() == 3
    assert isinstance(b, Future)

    def is_even(x):
        return x % 2 == 0

    future_set_result_unless_cancelled(b, [0, 1, 2, 3])
    assert list(filter(is_even, b.result())) == [0, 2]

    # test_case_0 is another unit test for function run_on_executor
    test_case_0()

# Generated at 2022-06-26 07:53:01.377111
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    def fn(*args, **kwargs):
        return 1
    dummy_executor.submit(fn)


# Generated at 2022-06-26 07:53:05.503682
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.cancelled()
    assert future.exception() is None
    assert future.result() is None


# Generated at 2022-06-26 07:53:12.520840
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        future = Future()
        future_set_exception_unless_cancelled(future, ValueError)
        assert True
    except asyncio.InvalidStateError:
        assert False


if __name__ == "__main__":
    test_case_0()
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-26 07:53:20.490495
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled() is True

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() is None



# Generated at 2022-06-26 07:53:22.071045
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, TypeError("This is a test."))


# Generated at 2022-06-26 07:53:24.921118
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Setup
    future = asyncio.Future()
    future.cancel()
    exc = Exception()

    # Test
    future_set_exception_unless_cancelled(future, exc)
    # Teardown
    future.cancel()



# Generated at 2022-06-26 07:53:27.183403
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_case_0():
        callable_0 = run_on_executor()

# Generated at 2022-06-26 07:53:35.888163
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test for function future_set_result_unless_cancelled
    f = Future()
    future_set_result_unless_cancelled(f, 'foo')
    assert f.result() == 'foo'
    future_set_result_unless_cancelled(f, 'foo')
    assert f.result() == 'foo'
    f.cancel()
    assert f.cancelled()
    future_set_result_unless_cancelled(f, 'foo')
    assert f.cancelled()
    assert f.done()
    assert f.result() is None



# Generated at 2022-06-26 07:53:57.315531
# Unit test for function chain_future
def test_chain_future():
    #@type: Future
    future1 = Future()
    #@type: Future
    future2 = Future()
    chain_future(future1, future2)
    assert not future1.done()
    assert not future2.done()
    future1.set_result(5)
    assert future1.done()
    assert future2.done()
    assert future1.result() == 5
    assert future2.result() == 5

# Generated at 2022-06-26 07:53:59.092878
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    try:
        future_set_result_unless_cancelled(Future(), 1)
        future_set_result_unless_cancelled(futures.Future(), 2)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 07:54:05.134925
# Unit test for function chain_future
def test_chain_future():
    ioloop_0 = asyncio.get_event_loop()
    future_0 = ioloop_0.create_future()

    future_0.set_result(8)
    # ioloop_0.create_future()
    future_1 = ioloop_0.create_future()

    # future_0 = future_1
    chain_future(future_0, future_1)
    assert future_0.result() == 8
    assert future_1.result() == 8
    ioloop_0.stop()



# Generated at 2022-06-26 07:54:11.051259
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    def func():
        pass
    
    future = asyncio.Future()
    future.set_result("test call chain_future")
    future1 = loop.create_future()
    chain_future(future, future1)
    assert future1.done()


# Generated at 2022-06-26 07:54:12.263589
# Unit test for function run_on_executor
def test_run_on_executor():
    test_case_0()

# Generated at 2022-06-26 07:54:15.493883
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # test_future_set_exception_unless_cancelled_0
    future = Future()
    future_set_exception_unless_cancelled(future, ZeroDivisionError())
    assert future.exception() is not None
    assert isinstance(future.exception(), ZeroDivisionError)


# Generated at 2022-06-26 07:54:18.903034
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    # Invoking the callback
    assert future_1.set_result(None) is None
    # Checking whether future_2 is done
    assert future_2.done() is True


# Generated at 2022-06-26 07:54:20.949054
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:54:23.653247
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)



# Generated at 2022-06-26 07:54:26.785874
# Unit test for function run_on_executor
def test_run_on_executor():
    def some_function():
        pass

    assert run_on_executor(some_function)

    @run_on_executor()
    def some_function():
        pass

    assert some_function



# Generated at 2022-06-26 07:55:04.280948
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    future_0 = Future()
    future_1 = Future()
    future_0 = Future()
    future_1 = Future()
    future_2 = Future()
    future_1 = Future()
    future_2 = Future()
    future_2 = Future()
    future_3 = Future()
    future_3 = Future()
    future_1 = Future()
    future_2 = Future()
    future_3 = Future()
    future_3 = Future()
    future_4 = Future()
    future_4 = Future()
    future_2 = Future()
    future_3 = Future()
    future_4 = Future()
    future_4 = Future()
    future_5 = Future()
    future_5 = Future()
    future_3 = Future()
    future_4 = Future

# Generated at 2022-06-26 07:55:15.482243
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from concurrent.futures import Future as Future2
    from concurrent.futures import Executor
    import time

    loop = IOLoop.current()

    excutor = Executor()

    def callback_f(f):
        assert f.done()
        assert f.result() == 0

    def callback_f2(f):
        assert f.done()
        assert f.result() == 0

    def callback_f3(f):
        assert f.done()
        assert f.result() == 0

    def callback_f4(f):
        assert f.done()
        assert f.result() == 0

    def callback_f10(f):
        assert f.done()
        assert f.result() == 0


# Generated at 2022-06-26 07:55:16.391355
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = DummyExecutor().submit(lambda: None)
    assert future is not None

# Generated at 2022-06-26 07:55:27.131490
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        raise Exception("foo")
    except Exception as e:
        future_0 = Future() # type: Future[Any]
        if future_0.cancelled():
            future_0.set_exception(e)
        else:
            future_0.set_exception(e)
    future_1 = Future() # type: Future[Any]
    if future_1.cancelled():
        future_1.set_exception(e)
    else:
        future_1.set_exception(e)
    future_2 = Future() # type: Future[Any]
    future_2.set_exception(e)


# Generated at 2022-06-26 07:55:29.632339
# Unit test for function chain_future
def test_chain_future():
    try:
        #Test that chain_future raises an exception if function is not callable
        chain_future("invalid", "invalid")
        assert False
    except ValueError as e:
        pass
    #Test that chain_future raises an exception if funcion is not callable
    try:
        chain_future(Future(), Future())
        assert False
    except ValueError as e:
        pass

# Generated at 2022-06-26 07:55:33.712730
# Unit test for function run_on_executor
def test_run_on_executor():
    callable_0 = run_on_executor()
    callable_1 = run_on_executor(None)
    callable_2 = run_on_executor(None, 'executor')



# Generated at 2022-06-26 07:55:44.839024
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async_future, promise_future = (Future(), Future())
    assert not async_future.cancelled()
    assert not promise_future.cancelled()
    future_set_exception_unless_cancelled(async_future, TypeError())
    future_set_exception_unless_cancelled(promise_future, TypeError())
    assert not async_future.cancelled()
    assert not promise_future.cancelled()
    assert isinstance(async_future.exception(), TypeError)
    assert isinstance(promise_future.exception(), TypeError)
    async_future.cancel()
    promise_future.cancel()
    assert async_future.cancelled()
    assert promise_future.cancelled()
    assert async_future.exception() is None
    assert promise_

# Generated at 2022-06-26 07:55:55.302086
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    exc = Exception('test')
    future_set_exception_unless_cancelled(future, exc)
    assert not future.cancelled()
    assert future.done()
    assert future.exception() == exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.cancelled()


if __name__ == "__main__":
    import logging

    logging.basicConfig()
    test_case_0()

# Generated at 2022-06-26 07:55:56.402011
# Unit test for function chain_future
def test_chain_future():
    chain_future(Future(), Future())



# Generated at 2022-06-26 07:56:06.975298
# Unit test for function chain_future
def test_chain_future():
    # Create the two Futures
    future_0 = asyncio.Future()
    future_1 = asyncio.Future()

    # Chain the Futures
    chain_future(future_0, future_1)

    # Set the result of future_0
    future_0.set_result(42)

    # Assert that the result is correct
    assert future_1.result() == 42

    # Set the exception of future_0
    future_0.set_exception(RuntimeError())

    # Assert that the exception is correct
    try:
        future_1.result()
        assert False
    except RuntimeError:
        pass

    # Cancel furture_0, then chain it to future_1
    future_0.cancel()
    chain_future(future_0, future_1)

    # Check that future_

# Generated at 2022-06-26 07:56:43.680109
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    assert hasattr(future_0, '_result')
    assert not hasattr(future_0, 'exc_info')

    future_1 = asyncio.Future()
    assert hasattr(future_1, '_result')
    assert hasattr(future_1, 'exc_info')

    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:56:45.403525
# Unit test for function run_on_executor
def test_run_on_executor():
    assert callable_0 is not None

if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-26 07:56:50.420588
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    c = b
    d = asyncio.Future()
    e = d
    chain_future(a, b)
    assert(b == c)
    chain_future(d, e)
    assert(d == e)


# Generated at 2022-06-26 07:56:53.967290
# Unit test for function chain_future
def test_chain_future():
    def fn_0(a: Future, b: Future) -> None:
        chain_future(a, b)

    future_0 = Future()
    future_1 = Future()
    fn_0(future_0, future_1)



# Generated at 2022-06-26 07:57:09.185409
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    import asyncio

    callable_0 = run_on_executor()
    print('callable_0 = run_on_executor()')

    # Create a Future object.
    foo = Future()
    print('foo = Future()')
    foo.set_result(True)

    # Returns a future.
    async def test_func(bar):
        # Chain two futures together so that when one completes, so does the other.
        # The result (success or failure) of a will be copied to b, unless b
        # has already been completed or cancelled by the time a finishes.
        chain_future(foo, bar)
        print('chain_future(foo, bar)')

        # Set the given value as the Future's result, if not cancelled.
        # Avoids asyncio.InvalidState

# Generated at 2022-06-26 07:57:22.068642
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import threading
    import time
    import unittest

    def _test_all():
        result = [0]

        def my_callback(fut):
            if result[0] == 0:
                result[0] = 1
            else:
                result[0] = 2

        fut = Future()
        fut.add_done_callback(my_callback)
        fut.set_exception(Exception)
        time.sleep(1.0)
        assert result[0] == 1

        fut2 = Future()
        fut2.set_exception(Exception)
        time.sleep(1.0)
        assert result[0] == 1
        fut2.cancel()
        fut2.set_exception(Exception)
        time.sleep(1.0)
        assert result[0] == 1

        fut

# Generated at 2022-06-26 07:57:25.754852
# Unit test for function chain_future
def test_chain_future():
    def foo() -> Future:
        future = Future()
        return future
    future = foo()
    chain_future(future, future)
    future_set_result_unless_cancelled(future, 3)
    future_set_exc_info(future, sys.exc_info())
    future_add_done_callback(future, lambda a: a)



# Generated at 2022-06-26 07:57:38.313660
# Unit test for function chain_future
def test_chain_future():
    def copy(future):
        assert future is a
        if b.done():
            return
        if hasattr(a, 'exc_info') and a.exc_info() is not None:
            future_set_exc_info(b, a.exc_info())
        elif a.exception() is not None:
            b.set_exception(a.exception())
        else:
            b.set_result(a.result())

    with pytest.raises(AssertionError):
        a = None
        b = Future()
        chain_future(a, b)

    a = Future()
    b = Future()
    chain_future(a, b)

    with pytest.raises(AssertionError):
        a = Future()
        b = None
        chain_future(a, b)

# Generated at 2022-06-26 07:57:47.763307
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from concurrent.futures import Future

    def assign_a_result(a, result):
        # type: (Future, Any) -> None
        a.set_result(result)

    def assign_a_exception(a, exc):
        # type: (Future, BaseException) -> None
        a.set_exception(exc)

    def assign_a_exc_info(a, exc_info):
        # type: (Future, Tuple[type, BaseException, types.TracebackType]) -> None
        a.set_exc_info(exc_info)

    def copy_a_to_b(a, b):
        # type: (Future, Future) -> None
        assert a is future_b
        if b.done():
            return

# Generated at 2022-06-26 07:57:53.147250
# Unit test for function chain_future
def test_chain_future():
    test_future = Future()
    test_future.set_result('foo')
    new_future = Future()
    chain_future(test_future, new_future)
    assert new_future.done()
    assert new_future.result() == 'foo'
    assert new_future.exception() is None



# Generated at 2022-06-26 07:58:32.319179
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    f1.set_result(None)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 07:58:41.187238
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, None)
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    future.cancel()
    with pytest.raises(RuntimeError):
        future_set_result_unless_cancelled(future, RuntimeError("test"))
