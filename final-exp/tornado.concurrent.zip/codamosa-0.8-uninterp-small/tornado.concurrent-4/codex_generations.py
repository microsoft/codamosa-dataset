

# Generated at 2022-06-26 07:48:53.610809
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_0.set_result(None)
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:49:00.686193
# Unit test for function chain_future
def test_chain_future():
    f0 = Future()
    f1 = Future()
    chain_future(f0, f1)
    f0.set_result(100)
    assert f1.result() == 100
    f0 = Future()
    f1 = Future()
    chain_future(f1, f0)
    f0.set_exception(ZeroDivisionError())
    assert f1.exception() is f0.exception()
    f0 = Future()
    f1 = Future()
    chain_future(f1, f0)
    f0.set_cancelled()
    assert f1.cancelled() is f0.cancelled()



# Generated at 2022-06-26 07:49:10.858498
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # test when future is not cancelled
    test_future = Future()  # type: Future
    test_exc = Exception()
    future_set_exc_info(test_future, (None, test_exc, None))
    assert test_future.done()
    assert test_future.exception() is test_exc

    # test when future is cancelled
    test_future = Future()
    test_exc = Exception()
    test_future.cancel()
    future_set_exc_info(test_future, (None, test_exc, None))
    assert test_future.done()
    assert test_future.exception() is None

# Generated at 2022-06-26 07:49:14.896855
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # call_0 = functools.partial(run_on_executor, *(), **{})
    # executor = DummyExecutor()
    # future = executor.submit(call_0, *(), **{})
    
    pass

# Generated at 2022-06-26 07:49:16.253792
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit()

# Generated at 2022-06-26 07:49:17.730740
# Unit test for function run_on_executor
def test_run_on_executor():
    callable_0 = run_on_executor()

# Generated at 2022-06-26 07:49:28.721591
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    obj_0 = Future()
    obj_0.set_result(None)

    def func_0(exc_info):
        future_set_exception_unless_cancelled(
        obj_0, BaseException(exc_info))
        assert obj_0.done() == True
        return obj_0

    func_0(None)

    obj_1 = Future()
    obj_1.cancel()

    def func_1(exc_info):
        try:
            future_set_exception_unless_cancelled(obj_1, BaseException(exc_info))
            raise Exception("could not raise exc")
        finally:
            obj_1.cancel()

    func_1(None)


# Generated at 2022-06-26 07:49:31.155126
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:49:34.810692
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled() == True



# Generated at 2022-06-26 07:49:42.043993
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def callable_0(fn: Callable[..., _T], *args, **kwargs):
        future = futures.Future()
        try:
            future_set_result_unless_cancelled(future, fn(*args, **kwargs))
        except Exception:
            future_set_exc_info(future, sys.exc_info())
        return future

    dummy_executor.submit(callable_0)


# Generated at 2022-06-26 07:49:47.887742
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-26 07:49:48.863459
# Unit test for function chain_future
def test_chain_future():
    callable_0 = chain_future


# Generated at 2022-06-26 07:49:50.790915
# Unit test for function run_on_executor
def test_run_on_executor():
    def f():
        pass
    fn = run_on_executor(f)
    assert fn.__name__ == 'f'


# Generated at 2022-06-26 07:49:59.327612
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio
    import concurrent.futures
    from tornado.ioloop import IOLoop

    # type: Callable[[], Future]
    def make_future() -> Future:
        return Future()

    async_future = make_future()
    conc_future = concurrent.futures.Future()
    chain_future(conc_future, async_future)

    ioloop = IOLoop.current()

    async def check_conc_future() -> None:
        await asyncio.sleep(0.01)
        # type: ignore
        assert conc_future.done()
        assert not async_future.done()
        IOLoop.current().stop()

    ioloop.add_callback(check_conc_future)


# Generated at 2022-06-26 07:50:03.213978
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future0 = asyncio.Future()
    future_set_exception_unless_cancelled(future0, ValueError())
    assert future0.exception() is not None
    assert ValueError == future0.exception().__class__



# Generated at 2022-06-26 07:50:06.863154
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:50:21.023673
# Unit test for function chain_future
def test_chain_future():
    """
    Test that chain_future copies result and exc_info to b if b
    has not been completed or cancelled when a finishes.
    """

    class FakeFuture:
        def __init__(self, result: Any = _NO_RESULT) -> None:
            self.result = result
            self.exception = None
            self.exc_info = None

        def done(self) -> bool:
            return self.result is not _NO_RESULT

        def set_result(self, result: Any) -> None:
            self.result = result

        def set_exception(self, exc: BaseException) -> None:
            self.exception = exc

        def set_exc_info(self, exc_info: Tuple[Any, Any, Any]) -> None:
            self.exc_info = exc_info

    #

# Generated at 2022-06-26 07:50:23.175896
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_set_exception_unless_cancelled(None, None)


# Generated at 2022-06-26 07:50:25.964994
# Unit test for function chain_future
def test_chain_future():
    future_0 : Future[int] = Future()
    future_1 : Future[int] = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:50:31.379429
# Unit test for function chain_future
def test_chain_future():
    # Using asyncio.Future
    future_A = asyncio.Future()
    future_B = asyncio.Future()
    chain_future(future_A, future_B)

    # Using concurrent.futures.Future
    future_C = futures.Future()
    future_D = asyncio.Future()
    chain_future(future_C, future_D)



# Generated at 2022-06-26 07:50:45.809656
# Unit test for function run_on_executor
def test_run_on_executor():
    # Test for exception raised in `future.set_result()`
    future = Future()  # type: Future
    future_set_result_unless_cancelled(future, "hello")
    assert future.result() == "hello"


# Generated at 2022-06-26 07:50:53.170970
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future[int]
    future_set_result_unless_cancelled(future, 3)
    assert future.done() and future.result() == 3

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 7)
    assert not future.done() and future.cancelled()



# Generated at 2022-06-26 07:50:58.808288
# Unit test for function chain_future
def test_chain_future():
    try:
        a = asyncio.Future()
        b = asyncio.Future()
        chain_future(a, b)
        assert b.done()
    except:
        print("Exception in user code:")
        print("-" * 60)
        traceback.print_exc(file=sys.stdout)
        print("-" * 60)


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-26 07:51:11.566177
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def foo(self):
        pass

    class A(object):
        def __init__(self, value: int) -> None:
            self.value = value

        @run_on_executor
        def add(self, a: int, b: int) -> int:
            return a + b

    a = A(1)
    assert not a.add(2, 3).done()  # type: ignore
    assert a.add(2, 3).result() == 5  # type: ignore
    assert a.add.__name__ == "add"
    assert a.add.__doc__ == A.add.__doc__ == foo.__doc__



# Generated at 2022-06-26 07:51:16.536507
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1


# Generated at 2022-06-26 07:51:21.138551
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    future_set_exception_unless_cancelled(future_0, KeyError)
    future_0 = Future()
    future_set_exception_unless_cancelled(future_0, KeyError)



# Generated at 2022-06-26 07:51:24.392493
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    print(future_0.done())
    future_0.set_result(test_case_0())
    print(future_0.done())



# Generated at 2022-06-26 07:51:27.592656
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    test_case_0()
    loop = IOLoop()
    f = loop.run_in_executor(None, lambda: 3)
    assert is_future(f)
    return f


# Generated at 2022-06-26 07:51:33.871930
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    @run_on_executor()
    def func_0():
        pass

    future_0 = Future()
    future_1 = Future()
    future_set_result_unless_cancelled(future_0, func_0)
    future_set_result_unless_cancelled(future_1, func_0)

# Generated at 2022-06-26 07:51:43.606501
# Unit test for function chain_future
def test_chain_future():
    # Create two futures
    future_0 = Future()
    future_1 = Future()

    # Chain them
    chain_future(future_0, future_1)

    # Assert future_0 and future_1 both have no result, are not done and are not cancelled
    assert future_0.result() is None
    assert not future_0.done()
    assert not future_0.cancelled()
    assert future_1.result() is None
    assert not future_1.done()
    assert not future_1.cancelled()

    # Set the result of future_0 to be the result of future_1
    future_0.set_result('future_0_result')

    # Assert future_0 and future_1 have the same result, are done and are not cancelled
    assert future_0.result() == future_

# Generated at 2022-06-26 07:52:10.200828
# Unit test for function chain_future
def test_chain_future():
    # Note: the following test cases are manually written tests, but not
    #       exhaustive.

    # Test type-checking of parameters.
    # Note: this test is not needed in this file since types are checked in
    #       the calling functions.
    # chain_future(None, None)
    # chain_future(None, None, None)
    # chain_future(object(), None)
    # chain_future(None, object())

    # Test with both tornado.concurrent.Future and asyncio.Future.
    # Test with one chain of two futures, and two chains of one future.
    # Test with multiple chains of two futures.

    # Test with two chains of length two.
    import time

    async_future_0 = Future()
    async_future_1 = Future()
    async_future_2 = Future()

    chain_

# Generated at 2022-06-26 07:52:24.389691
# Unit test for function chain_future
def test_chain_future():
    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    assert(not b.done())
    a.set_result(None)
    assert(b.done())

    # Verify that our callback was invoked even though we were already done.
    a = asyncio.Future()
    a.set_result(None)
    b = asyncio.Future()
    chain_future(a, b)
    assert(b.done())

    # Cancellation
    b = asyncio.Future()
    a = asyncio.Future()
    a.cancel()
    chain_future(a, b)
    assert(not b.done())

    a = Future()
    b = Future()
    chain_future(a, b)
    assert(not b.done())
   

# Generated at 2022-06-26 07:52:28.776510
# Unit test for function chain_future
def test_chain_future():
    def foo(future: Future) -> None:
        future_set_result_unless_cancelled(future, 42)

    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    foo(future_a)
    assert future_b.result() == 42



# Generated at 2022-06-26 07:52:34.510503
# Unit test for function chain_future
def test_chain_future():
    dummy_future = Future()
    dummy_future.set_result(1)
    dummy_future_2 = Future()
    dummy_future_2.set_result(2)
    chain_future(dummy_future, dummy_future_2)
    assert dummy_future_2.result() == 1


# Generated at 2022-06-26 07:52:37.772180
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    # No exception raised


# Generated at 2022-06-26 07:52:48.878957
# Unit test for function chain_future
def test_chain_future():
    import asyncio

    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_result(True)
    assert b.result() == True

    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_exception(Exception("foo"))
    try:
      b.result()
    except Exception as e:
      assert str(e) == "foo"

    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    b.set_exception(Exception("bar"))
    try:
      a.result()
    except Exception as e:
      assert str(e) == "bar"

# Generated at 2022-06-26 07:52:51.796522
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor_object = dummy_executor
    fn = test_case_0
    obj_Future = executor_object.submit(fn)
    assert isinstance(obj_Future, Future)



# Generated at 2022-06-26 07:52:54.434794
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exception = Exception("Exception Description")
    future = Future()
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is exception


# Generated at 2022-06-26 07:53:07.479376
# Unit test for function chain_future
def test_chain_future():

    async def dummy_coro():
        pass

    def test_coroutine_future():
        fut0 = asyncio.Future()
        fut1 = asyncio.Future()

        chain_future(fut0, fut1)

        fut0.set_result(None)

    def test_asyncio_future():
        fut0 = futures.Future()
        fut1 = asyncio.Future()

        chain_future(fut0, fut1)

        fut0.set_result(None)

    def test_coroutine_coroutine():
        fut0 = asyncio.Future()
        fut1 = dummy_coro()

        chain_future(fut0, fut1)

        fut0.set_result(None)

    def test_asyncio_async():
        fut0 = futures.Future()
        fut1

# Generated at 2022-06-26 07:53:16.612980
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    a = Future()
    chain_future(f, a)
    assert not a.done()
    f.set_result(1)
    assert a.done()
    assert a.result() == 1

    # Check that the callback doesn't get called if the destination
    # Future has already been set or cancelled.
    f2 = Future()
    a2 = Future()
    a2.set_result(1)
    chain_future(f2, a2)
    # Callback should have no effect
    f2.set_result(0)
    assert a2.result() == 1
    f2 = Future()
    a2 = Future()
    a2.cancel()
    chain_future(f2, a2)
    assert f2.cancelled()
    f2.set_result

# Generated at 2022-06-26 07:53:53.981132
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test exceptions
    future_0 = asyncio.Future()
    future_1 = asyncio.Future()
    future_1.cancel()
    future_set_result_unless_cancelled(future_0, 1)

    try:
        future_set_result_unless_cancelled(future_1, 1)
    except asyncio.InvalidStateError:
        assert False

    future_2 = asyncio.Future()
    future_2.cancel()
    try:
        future_set_result_unless_cancelled(future_2, 1)
    except asyncio.InvalidStateError:
        assert False

    # Test return value
    future_3 = asyncio.Future()
    future_set_result_unless_cancelled(future_3, 1)
    assert future_3.result() == 1

# Generated at 2022-06-26 07:54:01.689807
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future[int]
    with pytest.raises(Exception, match="InvalidStateError"):
        future.set_exception(Exception())
    future.set_result(1)

    future = Future()
    future.set_exception(Exception())
    assert future.done()
    assert not future.cancelled()
    future.cancel()
    assert future.done()
    assert future.cancelled()



# Generated at 2022-06-26 07:54:03.750004
# Unit test for function chain_future
def test_chain_future():
    pass # TODO: Implement test_chain_future




# Generated at 2022-06-26 07:54:15.626376
# Unit test for function chain_future
def test_chain_future():
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    assert future_b.done() == False
    future_a.set_result("a")
    assert future_b.result() == "a"
    chain_future(future_a, future_b)
    assert future_b.done() == False
    assert future_b.result() == "a"
    future_c = Future()
    future_d = Future()
    future_e = Future()
    chain_future(future_c, future_d)
    chain_future(future_d, future_e)
    assert future_d.done() == False
    assert future_e.done() == False
    future_c.set_result("c")

# Generated at 2022-06-26 07:54:22.487031
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    assert False == f1.cancelled()
    assert False == f2.cancelled()
    chain_future(f1, f2)
    assert False == f1.cancelled()
    assert False == f2.cancelled()
    f1.set_result("test")
    assert True == f1.cancelled()
    assert False == f2.cancelled()
    assert "test" == f2.result()
    f1 = Future()
    f2 = Future()
    assert False == f1.cancelled()
    assert False == f2.cancelled()
    chain_future(f1, f2)
    assert False == f1.cancelled()
    assert False == f2.cancelled()

# Generated at 2022-06-26 07:54:35.113772
# Unit test for function run_on_executor
def test_run_on_executor():
    class Tmp(object):

        def __init__(self, io_loop, executor):
            self.io_loop = io_loop
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def mult_arg(self, x, y):
            import time
            time.sleep(0.01)
            return x * y

        @run_on_executor
        def call_on_io_loop(self, x, y):
            self.io_loop.add_callback(self.mult_arg, x, y)

        @run_on_executor()
        def handler(self, x, y):
            return x ** 2 + y ** 2


# Generated at 2022-06-26 07:54:39.589727
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)



# Generated at 2022-06-26 07:54:42.059105
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def f(self):
        return 1


test_run_on_executor()



# Generated at 2022-06-26 07:54:52.387621
# Unit test for function run_on_executor
def test_run_on_executor():
    def concurrent_function(self: Any, *args: Any, **kwargs: Any) -> Future:
        # type: (*Any, **Any) -> Future
        pass

    class TempClass:
        def method(self, *args: Any, **kwargs: Any) -> Future:
            # type: (*Any, **Any) -> Future
            pass

    temp_instance = TempClass()

    @run_on_executor()
    def method_0(self: Any) -> Future:
        # type: (Any) -> Future
        pass

    @run_on_executor(executor="executor")
    def method_1(self: Any) -> Future:
        # type: (Any) -> Future
        pass


# Generated at 2022-06-26 07:54:54.927465
# Unit test for function chain_future
def test_chain_future():
    a = Future() if hasattr(asyncio, 'Future') else futures.Future()
    b = Future() if hasattr(asyncio, 'Future') else futures.Future()

    chain_future(a, b)


# Generated at 2022-06-26 07:56:31.498311
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc


# Generated at 2022-06-26 07:56:43.455931
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()

    future_set_exception_unless_cancelled(future, exc)
    assert future.result() is None, "The future should not have a result when set"
    assert future.exception() == exc, "The future should contain the exception"
    assert not future.cancelled(), "The future should not be cancelled"

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.result() is None, "The future should not have a result when set"
    assert future.exception() == exc, "The future should contain the exception"
    assert not future.cancelled(), "The future should not be cancelled"


# Generated at 2022-06-26 07:56:49.142919
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("blah"))
    assert f2.exception() is not None



# Generated at 2022-06-26 07:56:51.288373
# Unit test for function chain_future
def test_chain_future():
    callable_0 = chain_future(dummy_executor, dummy_executor)


# Generated at 2022-06-26 07:56:54.768099
# Unit test for function chain_future
def test_chain_future():
    def fun(a: Future, b: Future):
        print(a.result())

    a = Future()
    b = Future()
    a.set_result(5)
    chain_future(a, b)
    b.add_done_callback(fun)



# Generated at 2022-06-26 07:57:09.649824
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()

    assert not future_1.done()
    assert not future_2.done()

    chain_future(future_1, future_2)
    assert not future_1.done()
    assert not future_2.done()

    future_1.set_result("!future_1.set_result")
    assert future_1.done()
    assert future_2.done()
    assert future_2.result() == "!future_1.set_result"

    future_1 = Future()
    future_2 = Future()

    assert not future_1.done()
    assert not future_2.done()

    chain_future(future_1, future_2)
    assert not future_1.done()
    assert not future_2.done()

    future

# Generated at 2022-06-26 07:57:22.563592
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class Callable:
        def __init__(self):
            self.calls = []  # type: List[Tuple[Future, bool, BaseException]]

        def __call__(
            self, future: "Future[_T]", was_cancelled: bool, exception: Exception
        ) -> None:
            self.calls.append((future, was_cancelled, exception))

    def check(f: Future, exception: BaseException) -> None:
        assert (
            len(callable.calls) == 1
        ), "Expect callable to be called only once with arguments (future, bool, Exception)"
        assert callable.calls[0][0] is f
        assert isinstance(callable.calls[0][1], bool)
        assert callable.calls[0][2] is exception

    future

# Generated at 2022-06-26 07:57:28.975570
# Unit test for function chain_future
def test_chain_future():
    u = asyncio.Future()
    v = asyncio.Future()

    chain_future(u, v)
    u.set_result(None)
    assert v.done()
    assert not v.cancelled()
    assert v.result() is None

    u = asyncio.Future()
    v = asyncio.Future()

    chain_future(u, v)
    u.set_exception(ValueError())
    assert v.done()
    assert not v.cancelled()
    try:
        v.result()
    except ValueError:
        pass
    else:
        assert False, "expected ValueError"

    u = asyncio.Future()
    v = asyncio.Future()
    v.set_result(None)

    chain_future(u, v)

# Generated at 2022-06-26 07:57:32.864662
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Create a future object
    x = Future()

    # Set result unless cancelled
    future_set_result_unless_cancelled(x, 'Result')

    # Check the result
    assert x.done() == True
    assert x.result() == 'Result'


# Generated at 2022-06-26 07:57:36.841079
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    # No exception raised
    future_1.set_result(None)