

# Generated at 2022-06-26 07:48:53.314310
# Unit test for function chain_future
def test_chain_future():
    import concurrent.futures
    f = concurrent.futures.Future
    f0 = f()
    f1 = f()
    chain_future(f0, f1)



# Generated at 2022-06-26 07:48:54.407240
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    pass


# Generated at 2022-06-26 07:48:57.794304
# Unit test for function chain_future
def test_chain_future():
    from concurrent import futures
    future_0 = futures.Future()
    future_1 = module_0.Future()
    chain_future(future_0, future_1)

if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-26 07:49:01.735226
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_1 = module_0.Future()
    future_0 = module_0.Future()
    future_1.cancel()
    future_0.set_result(future_1)
    future_set_result_unless_cancelled(future_1, future_0)


# Generated at 2022-06-26 07:49:14.894944
# Unit test for function chain_future
def test_chain_future():
    future_0 = module_0.Future()
    future_1 = module_0.Future()
    future_2 = module_0.Future()
    future_3 = module_0.Future()
    future_4 = module_0.Future()
    future_5 = module_0.Future()
    future_6 = module_0.Future()
    future_7 = module_0.Future()

    chain_future(future_0, future_2)
    chain_future(future_1, future_4)
    chain_future(future_2, future_4)
    chain_future(future_3, future_4)
    chain_future(future_4, future_6)
    chain_future(future_5, future_7)
    chain_future(future_6, future_7)

# Generated at 2022-06-26 07:49:15.927530
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = module_0.Future()
    future_set_exc_info(future_0, (None, None, None))


# Generated at 2022-06-26 07:49:27.109598
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_decorator(fn):
        def foo(self, *args, **kwargs):
            getattr(self, executor).submit(fn, self, *args, **kwargs)
        return foo
    
    args: list = [
        dummy_executor,
        ]
    kwargs = {
        'executor': '_thread_pool',
        }
    if args and kwargs:
        raise ValueError('cannot combine positional and keyword args')
    if len(args) != 1:
        raise ValueError('expected 1 argument, got %d', len(args))
    return test_decorator(args[0])


# Generated at 2022-06-26 07:49:33.000332
# Unit test for function run_on_executor
def test_run_on_executor():
    def dummy_function(a, b, c=None, **kwargs):
        return "dummy_function"
    class DummyClass:
        def __init__(self):
            self.executor = dummy_executor

    dummy_class = DummyClass()
    assert run_on_executor(dummy_function)(dummy_class) is not None


# Generated at 2022-06-26 07:49:38.489998
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_case_0()
    future_1 = module_0.Future()
    exception_0 = BaseException()

    future_set_exception_unless_cancelled(future_1, exception_0)
    future_1.cancel()
    future_set_exception_unless_cancelled(future_1, exception_0)

# Generated at 2022-06-26 07:49:39.952428
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_case_0()



# Generated at 2022-06-26 07:49:57.546676
# Unit test for function chain_future
def test_chain_future():
    def dummy_0(arg_0: Any) -> Any:
        return arg_0

    class Dummy_0:
        def __init__(self, arg_0: Any, arg_1: Any) -> None:
            self.arg_0 = arg_0
            self.arg_1 = arg_1

        def dummy_1(self, arg_0: Any) -> Any:
            return self.arg_0.submit(dummy_0, arg_0, arg_1=self.arg_1)

        def dummy_2(self) -> Any:
            return self.arg_0.submit(dummy_0, arg_0=self.arg_1)

    dummy_0 = Dummy_0(DummyExecutor(), "kMw")

# Generated at 2022-06-26 07:50:04.219005
# Unit test for function chain_future
def test_chain_future():
    # Test case from tornado/concurrent.py::chain_future
    dummy_executor_1 = DummyExecutor()
    float_1 = 761.3441
    future_1 = dummy_executor_1.submit(float_1)
    dummy_executor_2 = DummyExecutor()
    float_2 = 5.9
    future_2 = dummy_executor_2.submit(float_2)
    chain_future(future_1, future_2)


# Generated at 2022-06-26 07:50:12.943910
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test case: false
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)
    future_set_result_unless_cancelled(future_0, float_0)
    # Test case: true
    dummy_executor_1 = DummyExecutor()
    float_1 = 761.3441
    future_1 = dummy_executor_1.submit(float_1)
    future_1.cancel()
    future_set_result_unless_cancelled(future_1, float_1)

# Generated at 2022-06-26 07:50:19.643711
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_1 = DummyExecutor()
    float_1 = 761.3441
    future_1 = dummy_executor_1.submit(float_1)
    dummy_executor_2 = DummyExecutor()
    float_2 = 761.3441
    future_2 = dummy_executor_2.submit(float_2)
    chain_future(future_1, future_2)



# Generated at 2022-06-26 07:50:25.748476
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    def throwing_func(x: float) -> None:
        raise ValueError("oh no")

    future = Future()
    future_0 = future
    future_1 = dummy_executor.submit(throwing_func, float_0)
    future_2 = future_1
    future_set_exception_unless_cancelled(future_0, ValueError("oh no"))


# Generated at 2022-06-26 07:50:31.865447
# Unit test for function chain_future
def test_chain_future():
    async def coroutine_0(obj):
        print("Second")

    def dummy_fn_0():
        print("First")

    dummy_executor_0 = DummyExecutor()
    future_0 = dummy_executor_0.submit(dummy_fn_0)
    future_1 = Future()
    chain_future(future_0, future_1)
    print(future_1.result())


# Generated at 2022-06-26 07:50:36.132804
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    dummy_executor = DummyExecutor()
    float_ = 761.3441
    future = dummy_executor.submit(float)
    future_set_result_unless_cancelled(future, float_)


# Generated at 2022-06-26 07:50:48.057285
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado.ioloop
    import tornado.httpserver
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.concurrent

    test_case_0()
    class Handler(tornado.web.RequestHandler):
        def get_executor(self):
            return dummy_executor

        @tornado.web.asynchronous
        @tornado.gen.coroutine
        def get(self):
            try:
                yield dummy_executor.submit(int, "hello")
            except ValueError:
                self.write("OK")
            self.finish()

    class Application(tornado.web.Application):
        def __init__(self):
            future_0 = [None]
            def future_0(future_0):
                future_set_exception_unless_cance

# Generated at 2022-06-26 07:50:52.790464
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_1 = DummyExecutor()
    future_1 = Future()
    # Ensure that exceptions are copied, not thrown
    dummy_executor_1.submit(future_1)


# Generated at 2022-06-26 07:51:01.621512
# Unit test for function chain_future
def test_chain_future():
    # future_0, future_1 are two futures
    future_0 = Future()
    future_1 = Future()

    # Chain future_0 to future_1, so when future_0 is completed, future_1 will be completed too.
    chain_future(future_0, future_1)

    # future_0 complete with result
    future_0.set_result("result")

    # future_1 should be completed with result
    assert future_1.done()
    assert future_1.result() == "result"

    # future_0, future_1 are two futures
    future_0 = Future()
    future_1 = Future()

    # Chain future_0 to future_1, so when future_0 is completed, future_1 will be completed too.
    chain_future(future_0, future_1)

    # future

# Generated at 2022-06-26 07:51:11.051369
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)


# Generated at 2022-06-26 07:51:21.186907
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_case_0(self):
        """blah"""
        future_0 = Future()
        dummy_executor_0 = DummyExecutor()
        def test_case_0_test_0(  # noqa: F811
            self, future_0, dummy_executor_0
        ):
            future_0.set_result(dummy_executor_0.submit(self.test_case_0))
        dummy_executor_0.submit(test_case_0_test_0, self, future_0, dummy_executor_0)
        dummy_executor_0.shutdown(True)
        return future_0
    return test_case_0
    int_0 = 5.9193
    test_case_0().result()


# Generated at 2022-06-26 07:51:27.594187
# Unit test for function chain_future
def test_chain_future():
    # pass
    # Create a future instance
    exec_0 = False
    dummy_executor_0 = DummyExecutor()
    # Create a future instance
    dummy_executor_1 = DummyExecutor()
    future_0 = dummy_executor_0.submit(0.0)
    future_1 = dummy_executor_1.submit(0.0)
    chain_future(future_0, future_1)
    # Test if a future is completed
    # Test if a future has a result
    # Test if a future is cancelled


# Generated at 2022-06-26 07:51:32.128635
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)


# Generated at 2022-06-26 07:51:40.645951
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    from tornado.concurrent import chain_future

    # Test default decorator arguments.
    def chain_future_helper() -> None:
        future_0 = Future()
        future_1 = Future()
        chain_future(future_0, future_1)
        future_1.set_result(None)

    # Test default decorator arguments.
    def test_chain_future_helper() -> None:
        future_0 = Future()
        future_1 = Future()
        future_0.set_result(None)
        chain_future(future_0, future_1)



# Generated at 2022-06-26 07:51:43.178136
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        future_set_exception_unless_cancelled(0, 1)
        assert False
    except Exception as e:
        assert type(e) == TypeError


# Generated at 2022-06-26 07:51:47.585731
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)
    future_set_exception_unless_cancelled(future_0, AttributeError())


# Generated at 2022-06-26 07:51:50.620463
# Unit test for function chain_future
def test_chain_future():
    def chain_future_0(a: Future, b: Future) -> None:
        future_0 = Future()
        chain_future(a, future_0)


# Generated at 2022-06-26 07:51:57.987506
# Unit test for function chain_future
def test_chain_future():
    test_future_0 = Future()
    test_future_1 = Future()
    chain_future(test_future_0, test_future_1)
    assert test_future_0.done() == False
    assert test_future_1.done() == False
    test_future_0.set_result(True)
    assert test_future_0.result() == True
    assert test_future_1.result() == True
    assert test_future_0.done() == True
    assert test_future_1.done() == True
    test_future_2 = Future()
    test_future_3 = Future()
    chain_future(test_future_2, test_future_3)
    assert test_future_3.done() == False
    test_future_2.set_exception(Exception())
    assert test

# Generated at 2022-06-26 07:52:00.032195
# Unit test for function chain_future
def test_chain_future():
    chain_future(future_0, future_0)


# Generated at 2022-06-26 07:52:17.254580
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:52:18.731183
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)


# Generated at 2022-06-26 07:52:25.058502
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    fut1 = asyncio.Future(loop=loop)
    fut2 = asyncio.Future(loop=loop)
    fut1.set_result(float(2.2))
    chain_future(fut1, fut2)
    assert fut2.result() == float(2.2)



# Generated at 2022-06-26 07:52:26.481272
# Unit test for function run_on_executor
def test_run_on_executor():
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-26 07:52:34.177595
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_0 = DummyExecutor()
    float_0 = float_0 / float_0
    future_0 = dummy_executor_0.submit(float_0)
    future_add_done_callback(future_0, dummy_executor_0)
    future_1 = dummy_executor_0.submit(float_0)
    chain_future(future_0, future_1)
    assert future_0.result() == float_0


# Generated at 2022-06-26 07:52:40.626185
# Unit test for function chain_future
def test_chain_future():
    # Future.result() not used.  # noqa: F821
    # Future.exception() not used.  # noqa: F821
    # Future.done() not used.  # noqa: F821
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:52:51.269627
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future as to_future
    import asyncio
    import io
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.loop = AsyncIOMainLoop()
            self.loop.make_current()

        def tearDown(self):
            self.loop.clear_current()
            self.loop.close(all_fds=True)

        def test_return_future(self):
            class Foo(object):
                def __init__(self):
                    self.executor = dummy_executor

                @run_on_executor
                def bar(self):
                    # type: () -> float
                    return 761.344

# Generated at 2022-06-26 07:52:55.718293
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)
    future_1 = future_0
    assert isinstance(future_1, concurrent.futures.Future) or isinstance(future_1, asyncio.Future)
    assert future_1.done() == False


# Generated at 2022-06-26 07:53:08.256636
# Unit test for function run_on_executor
def test_run_on_executor():
    def run_on_executor_decorator_0(fn_0):
        def wrapper(self_0):
            async_future_0 = Future()
            conc_future_0 = getattr(self_0, "executor").submit(fn_0, self_0)
            chain_future(conc_future_0, async_future_0)
            return async_future_0
        return wrapper

    # Test for function run_on_executor
    def set_executor_function_0():
        dummy_executor_0 = DummyExecutor()
        future_0 = Future()
        dummy_executor_0.submit(set_executor, future_0)
        future_0.result()

    def set_executor_0(future_0):
        set_executor(future_0)




# Generated at 2022-06-26 07:53:11.060681
# Unit test for function chain_future
def test_chain_future():
    future_1 = futures.Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    pass


# Generated at 2022-06-26 07:53:39.851443
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)


# Generated at 2022-06-26 07:53:45.870069
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    async_future_0 = Future()
    dummy_executor_0.submit(chain_future, async_future_0, Future())
    async_future_0.result()


if __name__ == "__main__":
    test_case_0()
    test_run_on_executor()

# Generated at 2022-06-26 07:53:57.316336
# Unit test for function run_on_executor
def test_run_on_executor():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()

    class Foo_0():
        def func0(self):
            return float_0

        def func1(self):
            return float_1

    class Bar_0(Foo_0):
        def func2(self):
            return float_2

        def func3(self):
            return float_3

    class Baz_0(Bar_0):
        pass

    class Quix_0(Baz_0):
        pass

    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()

    class Fox_0():
        def func4(self):
            return float_4


# Generated at 2022-06-26 07:53:58.883105
# Unit test for function chain_future
def test_chain_future():
    # Test case 0
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)



# Generated at 2022-06-26 07:54:01.290241
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    dummy_executor_0.submit(float_0)


# Generated at 2022-06-26 07:54:08.123843
# Unit test for function chain_future
def test_chain_future():
    test_future_0 = asyncio.Future()
    test_future_1 = asyncio.Future()
    chain_future(test_future_0, test_future_1)
    chain_future(test_future_0, test_future_1)
    test_future_0.set_result(759)


# Generated at 2022-06-26 07:54:12.305843
# Unit test for function run_on_executor
def test_run_on_executor():
    future: Future[Any] = Future()
    future.set_result("return value")
    return future


# Generated at 2022-06-26 07:54:15.464214
# Unit test for function chain_future
def test_chain_future():
    # Create an asyncio.Future
    future_0 = Future()

    # Create a concurrent.futures.Future
    future_1 = futures.Future()

    # Chain together two futures using the two different types
    chain_future(future_0, future_1)
    chain_future(future_1, future_0)

# Generated at 2022-06-26 07:54:18.268969
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    float_0 = 761.3441
    future_0 = dummy_executor_0.submit(float_0)
    dummy_executor_0.shutdown()


# Generated at 2022-06-26 07:54:22.056665
# Unit test for function chain_future
def test_chain_future():
    from concurrent import futures
    from tornado.concurrent import Future

    async_future = Future()
    conc_future = futures.Future()
    chain_future(conc_future, async_future)



# Generated at 2022-06-26 07:55:14.067080
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    future_0 = dummy_executor_0.submit(dummy_executor_0)


# Generated at 2022-06-26 07:55:23.002907
# Unit test for function run_on_executor
def test_run_on_executor():
    # Unit test for function run_on_executor
    def test_run_on_executor_0():
        # Unit test for function run_on_executor
        def test_run_on_executor_0_0():
            def test_run_on_executor_0_0_0():
                return

            return test_run_on_executor_0_0_0()
        return test_run_on_executor_0_0()
    return test_run_on_executor_0()


# Generated at 2022-06-26 07:55:35.387181
# Unit test for function chain_future
def test_chain_future():
    # Augment repr() with an explicit type signature
    Future.__repr__ = lambda self : "%s[%s]" % (self.__repr__(), type(self).__name__)
    future_0 = Future()
    future_1 = Future()
    future_2 = Future()
    future_3 = Future()
    future_4 = Future()
    future_5 = Future()
    # Augment repr() with an explicit type signature
    Future.__repr__ = lambda self : "%s[%s]" % (self.__repr__(), type(self).__name__)
    Future.__repr__ = lambda self : "%s[%s]" % (self.__repr__(), type(self).__name__)

# Generated at 2022-06-26 07:55:43.872211
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    future_3 = Future()
    try:
        future_3.set_result(1)
    except asyncio.InvalidStateError:
        pass
    future_2.set_exception(Exception('test'))
    future_1.cancel()
    chain_future(future_1, future_2)
    chain_future(future_2, future_3)
    assert(future_3.cancelled())
    assert(future_3.exception() is None)


# Generated at 2022-06-26 07:55:48.199545
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    import concurrent.futures
    import sys

    @run_on_executor
    def callback(future: Future[int]) -> None:
        future.set_result(1)



# Generated at 2022-06-26 07:55:48.787269
# Unit test for function run_on_executor
def test_run_on_executor():
    pass



# Generated at 2022-06-26 07:55:51.833905
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:55:57.220696
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_0 = DummyExecutor()
    future_0 = dummy_executor_0.submit(dummy_executor_0)
    future_1 = dummy_executor_0.submit(dummy_executor_0)
    chain_future(future_0, future_1)

# Generated at 2022-06-26 07:56:04.281472
# Unit test for function chain_future
def test_chain_future():
    # Type stmt below is to make mypy happy
    future_0 = futures.Future()  # type: futures.Future[str]
    future_0.set_result('result_0')
    future_1 = futures.Future()  # type: futures.Future[str]
    chain_future(future_0, future_1)
    result_0 = future_1.result()


# Generated at 2022-06-26 07:56:08.301093
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()

    chain_future(future_1, future_2)
    future_1.set_result(1)

    assert future_2.result() == 1


# Generated at 2022-06-26 07:57:06.449520
# Unit test for function run_on_executor
def test_run_on_executor():
    class A(object):
        def __init__(self) -> None:
            self.executor = DummyExecutor()

    a = A()

    def f(a: A) -> None:
        pass
    assert f.__name__ == "f"
    f1 = run_on_executor(f)
    assert f1.__name__ == "f"
    f1(a)
    assert isinstance(a.executor, DummyExecutor)

    @run_on_executor
    def g(a: A) -> None:
        pass
    assert g.__name__ == "g"
    g(a)



# Generated at 2022-06-26 07:57:10.006065
# Unit test for function chain_future
def test_chain_future():
    asyncio.Future()
    futures.Future()
    dummy_executor_1 = DummyExecutor()
    future_1 = dummy_executor_1.submit(dummy_executor_1)
    chain_future(future_1)
    chain_future(future_1, future_1)


# Generated at 2022-06-26 07:57:17.162802
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_1 = DummyExecutor()
    future_1 = dummy_executor_1.submit(dummy_executor_1)
    dummy_executor_2 = DummyExecutor()
    future_2 = dummy_executor_2.submit(dummy_executor_2)
    chain_future(future_1, future_2)


# Generated at 2022-06-26 07:57:22.070744
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_0 = DummyExecutor()
    future_0 = dummy_executor_0.submit(dummy_executor_0)
    future_1 = dummy_executor_0.submit(dummy_executor_0)
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:57:24.964925
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()  # type: Future
    future_2 = Future()  # type: Future
    # ensure future_1 and future_2 are distinct objects
    assert future_1 is not future_2
    test_chain_future_0 = chain_future(future_1, future_2)
    # ensure the two futures are chained togther
    assert future_1 is not future_2
    del future_1
    del future_2


# Generated at 2022-06-26 07:57:26.765439
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:57:33.290319
# Unit test for function chain_future
def test_chain_future():
    class DummyClass(object):
        """dummy class"""

        def __init__(self, future1: Future[_T], future2: Future[_T]) -> None:
            self.future1 = future1
            self.future2 = future2

            chain_future(self.future1, self.future2)

    def test_case_0():
        dummy_class_0 = DummyClass(DummyExecutor().submit(isinstance), type)



# Generated at 2022-06-26 07:57:37.740076
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    future_0 = dummy_executor_0.submit(test_case_0)
    assert future_0.result() == None



# Generated at 2022-06-26 07:57:41.750098
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(None)
    assert b.done()



# Generated at 2022-06-26 07:57:46.023850
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    assert future_0 is not future_1
    chain_future(future_0, future_1)
    assert future_0 is not future_1
