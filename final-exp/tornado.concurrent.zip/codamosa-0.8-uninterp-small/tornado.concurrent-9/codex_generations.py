

# Generated at 2022-06-26 07:48:59.159563
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_2 = Future()
    future_3 = Future()

    def func_0():
        return 0

    def func_1(a, b, c):
        return a + b + c

    def func_2(d):
        return d

    def func_3():
        return 2

    def func_4():
        return 3

    # Chaining from a concurrent.futures.Future
    thread_pool = futures.ThreadPoolExecutor()
    future_0 = thread_pool.submit(func_0)
    future_1 = thread_pool.submit(func_1, 1, 2, 3)
    chain_future(future_0, future_2)
    chain_future(future_1, future_3)
    future_2 = future_

# Generated at 2022-06-26 07:49:06.693043
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    def fn_0(*args_0, **kwargs_0):
        res_0 = kwargs_0['x']
        return res_0
    fn_0_0 = functools.partial(fn_0, x=5)
    future_0 = dummy_executor_0.submit(fn_0_0)
    assert future_0.result() == 5

# Generated at 2022-06-26 07:49:11.411178
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0: "Future[int]" = Future()
    object_0: object = object()
    future_set_result_unless_cancelled(future_0, object_0)
    assert future_0.cancelled() is False
    assert future_0.done() is True


# Generated at 2022-06-26 07:49:24.490237
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    @typing.overload
    def future_set_exception_unless_cancelled(future: "Future[_T]", exc: BaseException):
        pass

    @typing.overload  # noqa: F811
    def future_set_exception_unless_cancelled(future: "futures.Future[_T]", exc: BaseException):
        pass

    def future_set_exception_unless_cancelled(
        future: "Union[Future[_T], futures.Future[_T]]", exc: BaseException
    ) -> None:
        pass

    create_future_0 = futures.Future()
    exc_0 = Exception()
    future_set_exception_unless_cancelled(create_future_0, exc_0)

# Generated at 2022-06-26 07:49:27.533076
# Unit test for function chain_future
def test_chain_future():
    g = Future()
    h = Future()
    chain_future(g,h)
    # Unit test for function future_set_result_unless_cancelled

# Generated at 2022-06-26 07:49:29.208050
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()



# Generated at 2022-06-26 07:49:31.617978
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    future_set_exception_unless_cancelled(future_0, Exception())


# Generated at 2022-06-26 07:49:36.649870
# Unit test for function chain_future
def test_chain_future():
    def fun_a():
        return 1

    future_a = DummyExecutor().submit(fun_a)
    future_b = Future()
    chain_future(future_a, future_b)
    assert future_b.result() == 1


# Generated at 2022-06-26 07:49:42.156764
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    class Callable1(object):
        def __call__(self, *args, **kwargs): pass
    
    try:
        chain_future(None, None)
    except TypeError as e:
        assert type(e) == TypeError
        

# Generated at 2022-06-26 07:49:52.654776
# Unit test for function run_on_executor
def test_run_on_executor():
    name = 'test_run_on_executor'
    executor = 'executor'
    
    def test_run_on_executor_decorator(fn):
        @functools.wraps(fn)
        def wrapper(self, *args, **kwargs):
            future = Future()
            try:
                future_set_result_unless_cancelled(future, fn(*args, **kwargs))
            except Exception:
                future_set_exc_info(future, sys.exc_info())
            return future
        return wrapper

    class Klass():
        executor = 'executor'
        
        def __init__(self, name):
            self.name = name
            self.executor = 'executor'
            

# Generated at 2022-06-26 07:49:59.216512
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """Checks that the exception is not set in a future that is cancelled"""
    future = Future()
    exception = Exception("Hello future")
    future.cancel()
    future_set_exception_unless_cancelled(future, exception)
    assert future.cancelled()



# Generated at 2022-06-26 07:50:08.894099
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def cb():
        pass
    f = Future()
    future_set_result_unless_cancelled(f, "hello")
    f.add_done_callback(cb)
    assert f.result() == "hello"
    assert f.done()
    try:
        future_set_result_unless_cancelled(f, "hello")
    except asyncio.InvalidStateError:
        pass
    else:
        raise Exception("expected InvalidStateError")

if __name__ == "__main__":
    test_future_set_result_unless_cancelled()

# Generated at 2022-06-26 07:50:15.727948
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    from concurrent.futures import ThreadPoolExecutor

    executor = ThreadPoolExecutor(max_workers=2)

    # This must be an old-style class in order to support instantiation
    # without calling __init__
    class OldStyle:
        pass

    class NewStyle(object):
        pass

    class Handler(NewStyle):
        executor = executor

    for cls in (OldStyle, NewStyle):
        obj = cls()
        obj.executor = executor
        f = asyncio.run_coroutine_threadsafe(obj.executor.submit(lambda: 1), loop=None)
        assert f.result() == 1

        @run_on_executor
        def f(self):
            return 1

        assert f(obj).result() == 1


# Generated at 2022-06-26 07:50:19.174657
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = asyncio.Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is not None



# Generated at 2022-06-26 07:50:20.234425
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:50:26.996843
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
  from asyncio import Future
  import sys

  def test_future_set_exception(exception: BaseException):
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, exception)
    assert f.cancelled()
    assert not f.done()

  test_future_set_exception(RuntimeError("foo"))
  test_future_set_exception(sys.exc_info())

# Generated at 2022-06-26 07:50:29.887904
# Unit test for function run_on_executor
def test_run_on_executor():
    # TODO fix return type
    def test_function(self):
        pass

    fn = run_on_executor(test_function)

    assert fn.__name__ == "test_function"

    class TestClass:
        executor = dummy_executor

    assert test_function.__name__ == fn(TestClass()).__name__



# Generated at 2022-06-26 07:50:38.509580
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent.futures import Future as Future_0
    from concurrent.futures import Future as Future_1
    from concurrent.futures import Future as Future_2

    # Test with positional argument(s)
    assert isinstance(dummy_executor.submit(lambda x: x * x, 4), Future)
    # Test with keyword argument(s)
    assert isinstance(dummy_executor.submit(lambda x: x * x, x=4), Future)
    # Test with no argument(s)
    assert isinstance(dummy_executor.submit(lambda: 16), Future)



# Generated at 2022-06-26 07:50:51.635274
# Unit test for function chain_future
def test_chain_future():
    initial_future = Future()
    chained_future = Future()
    chain_future(initial_future, chained_future)
    # Since initial_future is not done, chained_future should not
    # be done either.
    assert not chained_future.done()

    # Successfully complete initial_future.
    initial_future.set_result('abc')
    # Now chained_future should be completed with the same
    # result.
    assert chained_future.done()
    assert chained_future.result() == 'abc'

    # Now do an exception case.
    initial_future = Future()
    chained_future = Future()
    chain_future(initial_future, chained_future)
    # Since initial_future is not done, chained_future should not
    # be done either.
    assert not chained_future.done()

    #

# Generated at 2022-06-26 07:50:59.990834
# Unit test for function chain_future
def test_chain_future():
    async def async_func():
        a = Future()
        b = Future()

        chain_future(a, b)

        a.set_result(1)

        assert (await b) == 1

    async def async_func_exception():
        a = Future()
        b = Future()

        chain_future(a, b)

        a.set_exception(TypeError())

        with pytest.raises(TypeError):
            await b

    loop = asyncio.get_event_loop()
    loop.run_until_complete(async_func())
    loop.run_until_complete(async_func_exception())


# Generated at 2022-06-26 07:51:14.553451
# Unit test for function chain_future
def test_chain_future():
    future_0: Optional[futures.Future] = futures.Future()
    future_1: Optional[futures.Future] = futures.Future()
    future_2: Optional[futures.Future] = futures.Future()
    future_3: Optional[futures.Future] = futures.Future()
    future_4: Optional[futures.Future] = futures.Future()

    future_0.set_result(None)

    future_1.set_exception(Exception())

    future_2.set_result(None)
    future_2.set_exception(Exception())

    if future_3.cancelled():
        future_3.set_result(None)

    future_4 = None
    chain_future(future_0, future_1)

# Generated at 2022-06-26 07:51:16.367009
# Unit test for function chain_future
def test_chain_future():
    future0 = Future()
    future1 = Future()
    chain_future(future0, future1)

# Generated at 2022-06-26 07:51:19.605806
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)


# Generated at 2022-06-26 07:51:28.362395
# Unit test for function chain_future
def test_chain_future():
    def assert_result(future: Future[int]):
        assert future.result() == 10

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]

    chain_future(f1, f2)

    f1.set_result(10)
    assert not f2.done()
    f2.add_done_callback(assert_result)

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]

    chain_future(f1, f2)

    f1.set_result(20)
    f2.add_done_callback(assert_result)

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]

   

# Generated at 2022-06-26 07:51:31.566384
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    callable_0 = chain_future(a, b)



# Generated at 2022-06-26 07:51:36.280749
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    def set_f1_result() -> None:
        f1.set_result(None)

    f2.add_done_callback(set_f1_result)
    chain_future(f1, f2)


# Generated at 2022-06-26 07:51:45.007532
# Unit test for function run_on_executor
def test_run_on_executor():
    import functools
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    @functools.wraps(test_case_0)
    def test_case_1(self):
        class DummyContextManager(object):
            def __init__(self, value):
                self.value = value

            def __enter__(self):
                return self.value

            def __exit__(self, type, value, traceback):
                pass

        class DummyFuture(object):
            def __init__(self, value):
                self.value = value

            def result(self):
                return self.value


# Generated at 2022-06-26 07:51:55.030724
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.gen import coroutine, Future
    from tornado.ioloop import IOLoop

    @coroutine
    def test_chain_future_coroutine():
        future_a = Future()  # type: Future
        future_b = Future()  # type: Future
        future_c = Future()  # type: Future
        chain_future(future_a, future_b)
        chain_future(future_b, future_c)
        yield future_a
        assert future_c.done()

    ioloop = IOLoop()
    AsyncIOMainLoop().install()
    ioloop.run_sync(test_chain_future_coroutine)



# Generated at 2022-06-26 07:51:55.943997
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor.submit(test_case_0)

# Generated at 2022-06-26 07:52:10.157079
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    def f1(future: Future) -> None:
        future_set_result_unless_cancelled(future, 0)

    def f2(future: Future) -> None:
        future.cancel()
        future_set_result_unless_cancelled(future, 0)

    async def test_ok() -> None:
        future = Future()
        f1(future)
        assert await future == 0

    async def test_cancelled() -> None:
        future = Future()
        f2(future)
        try:
            await future
            assert False, "expected exception"
        except asyncio.CancelledError:
            pass

    import trio
    import tornado.ioloop

    # Set the current IOLoop to an instance of the IOLoop (the default,
    # initialized by the constructor) since there is

# Generated at 2022-06-26 07:52:25.898110
# Unit test for function chain_future
def test_chain_future():  # noqa
    from tornado import ioloop  # noqa

    loop = ioloop.IOLoop.current()

    def callback_0(future: "Future") -> None:
        future.set_result(None)

    f = Future()
    f.add_done_callback(callback_0)
    f.set_result(None)

    def callback_1() -> None:
        assert f.result() is None

    loop.add_future(f, callback_1)

    loop.start()
    loop.close()



# Generated at 2022-06-26 07:52:28.144172
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    future_set_exception_unless_cancelled(test_future, Exception())



# Generated at 2022-06-26 07:52:36.008095
# Unit test for function chain_future
def test_chain_future():
    import inspect
    import sys
    import types

    print(inspect.isclass(Future))
    print(inspect.isfunction(chain_future))

    print(chain_future.__module__)
    obj = object()
    future_0 = Future()

    f = Future()
    f.set_result(obj)
    chain_future(f, future_0)

    assert future_0.done()
    assert future_0.result() == obj



# Generated at 2022-06-26 07:52:39.315764
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    future_set_result_unless_cancelled(future_0, 1)


# Generated at 2022-06-26 07:52:42.182861
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

# Generated at 2022-06-26 07:52:52.578732
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    for _ in range(2):
        executor = DummyExecutor()
        from concurrent import futures
        def callable_0(*args, **kwargs):
            return str(args[0])
        fn = callable_0
        future = executor.submit(fn)
        assert isinstance(future, futures.Future) == True
        assert future._state == futures._PENDING
        assert future.cancelled() == False
        def callable_1(*args, **kwargs):
            return str(args[0])
        fn = callable_1
        future = executor.submit(fn, 'abc')
        assert isinstance(future, futures.Future) == True
        assert future._state == futures._PENDING
        assert future.cancelled() == False

# Generated at 2022-06-26 07:52:54.470924
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(None)
    assert b.done()


# Generated at 2022-06-26 07:53:07.489547
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_case_1():
        callable_0 = run_on_executor()
    def test_case_2():
        pass
    def test_case_3():
        return_value_0 = run_on_executor(test_case_2)
        pass
    def test_case_4():
        pass
    def test_case_5():
        pass
    def test_case_6():
        pass
    def test_case_7():
        pass
    def test_case_8():
        pass
    def test_case_9():
        pass
    def test_case_10():
        pass
    def test_case_11():
        pass
    def test_case_12():
        pass
    def test_case_13():
        pass
    def test_case_14():
        pass

# Generated at 2022-06-26 07:53:16.127165
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Tests using asyncio.Future
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    assert str(future.exception()) == "test"
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    # Tests using concurrent.futures.Future
    future = futures.Future()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    assert str(future.exception()) == "test"
    future = futures.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("test"))

# Generated at 2022-06-26 07:53:18.710649
# Unit test for function chain_future
def test_chain_future():
    # Test case 1: Run the method without arguments
    test_chain_future_1()


# Test case for chain_future(): Run the method without arguments

# Generated at 2022-06-26 07:53:40.348766
# Unit test for function chain_future
def test_chain_future():
    def test_chain_future_0(future, wrapper, args, kwargs):
        future.set_result(wrapper(*args, **kwargs))

    def test_chain_future_1(wrapper, args, kwargs):
        future = Future()
        chain_future(future, wrapper(*args, **kwargs))
        return future

    def test_chain_future_2(future, wrapper, args, kwargs):
        exc_info = sys.exc_info()
        if exc_info[1] is None:
            raise Exception("test_chain_future_2 called with no exception")
        future.set_exception(exc_info[1])

    def test_chain_future_3(wrapper, args, kwargs):
        future = Future()
        chain_future(future, wrapper(*args, **kwargs))

# Generated at 2022-06-26 07:53:46.066091
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1
    assert b.done()
    assert not b.cancelled()
    assert not b.exception()
    assert not b.running()



# Generated at 2022-06-26 07:53:49.184857
# Unit test for function chain_future
def test_chain_future():
    f1 : Future[int] = Future()
    f2 : Future[int] = Future()
    chain_future(f1, f2)
    assert f1.result(0) == 0



# Generated at 2022-06-26 07:54:01.290244
# Unit test for function chain_future
def test_chain_future():
    import asyncio

    async def f1(arg_0: asyncio.Future):
        arg_0.set_result(2)

    async def f2():
        arg_1: asyncio.Future = asyncio.Future()
        arg_2: asyncio.Future = asyncio.Future()
        await asyncio.wait([f1(arg_1), f1(arg_2)])
        arg_3: asyncio.Future = asyncio.Future()
        arg_3.set_result(25)
        arg_4: asyncio.Future = asyncio.Future()
        arg_5: asyncio.Future = asyncio.Future()
        arg_6: asyncio.Future = asyncio.Future()
        arg_4.set_result(22)
        arg_5.set_result(23)
        arg_6

# Generated at 2022-06-26 07:54:04.423134
# Unit test for function chain_future
def test_chain_future():
    f_0 = futures.Future()
    f_1 = Future()
    chain_future(f_0, f_1)



# Generated at 2022-06-26 07:54:14.870344
# Unit test for function chain_future
def test_chain_future():
    # tornado.concurrent.Future
    future_0: Future[int] = Future()
    future_1: Future[int] = Future()
    future_0.set_result(1)
    chain_future(future_0, future_1)
    # assert future_1.result() == 1
    # tornado.concurrent.Future
    future_2: Future[int] = Future()
    future_2.set_result(2)
    future_3: Future[int] = Future()
    future_3.set_result(2)
    chain_future(future_2, future_3)
    # assert future_3.result() == 2



# Generated at 2022-06-26 07:54:17.044324
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    fn = 'fn'
    result = executor.submit(fn)
    assert isinstance(result, futures.Future)


# Generated at 2022-06-26 07:54:24.569554
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    assert a is not b
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1
    a = Future()
    b = Future()
    assert a is not b
    chain_future(a, b)
    a.set_exception(Exception())
    assert isinstance(b.exception(), Exception)

if __name__ == '__main__':
    test_chain_future()

# Generated at 2022-06-26 07:54:32.248446
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = asyncio.Future()  # type: Future
    future_set_exception_unless_cancelled(f, Exception("test"))
    assert f.done()
    assert isinstance(f.exception(), Exception)
    assert f.exception().args == ("test",)

    # This should not raise even though it's a no-op
    future_set_exception_unless_cancelled(f, Exception("test"))



# Generated at 2022-06-26 07:54:38.277965
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Create a new future
    future = Future()

    # Cancel the future
    future.cancel()

    # Should not print an exception since the future is cancelled
    future_set_exc_info(future, (None, Exception(), None))

    # Should print an exception since the future is not cancelled
    future.cancel()
    future_set_exc_info(future, (Exception, Exception(), None))

    return test_case_0()

# Generated at 2022-06-26 07:55:12.154540
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    assert False == b.done()
    chain_future(a, b)
    a.set_result(True)
    assert True == b.done()

# Generated at 2022-06-26 07:55:17.232833
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    def fn(a: {}) -> int:
        return 1
    future = dummy_executor.submit(fn, {})
    assert future.result() == 1


# Generated at 2022-06-26 07:55:29.371201
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    import concurrent
    import tornado

    @run_on_executor
    def fn(self, a: int, b: str) -> str:
        return a * 2, b

    class X(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=10)

    x = X()
    async def async_fn(a: int, b: str) -> Tuple[int, str]:
        return await tornado.concurrent.futures.wrap_future(fn(x, a, b))

    assert (2, "foo") == asyncio.run(async_fn(1, "foo"), debug=True)


# Generated at 2022-06-26 07:55:35.126820
# Unit test for function chain_future
def test_chain_future():
    # Setup arguments
    future_1 = asyncio.Future()
    future_2 = asyncio.Future()
    return_value_3 = None
    # Call the function
    return_value_4 = chain_future(future_1, future_2)
    assert return_value_4 == return_value_3


# Generated at 2022-06-26 07:55:37.469891
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    a = Future()
    future_set_exception_unless_cancelled(a,'some exception')
    assert a.exception()


# Generated at 2022-06-26 07:55:39.943277
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_1, future_0)
    assert future_0 is not None


# Generated at 2022-06-26 07:55:47.521194
# Unit test for function run_on_executor
def test_run_on_executor():
    def _test_run_on_executor(self, *args, **kwargs):
        return 5

    test_run_on_executor = run_on_executor(_test_run_on_executor)
    test_run_on_executor(1)
    test_run_on_executor(1, executor="_thread_pool")
    test_run_on_executor(1, 2)
    test_run_on_executor(1, 2, executor="_thread_pool")
    test_run_on_executor(1, a=2)
    test_run_on_executor(1, a=2, executor="_thread_pool")
    test_run_on_executor(1, 2, a=3)

# Generated at 2022-06-26 07:55:56.090348
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Set the result of a future.
    future = Future()
    future_set_result_unless_cancelled(future, "my result")
    assert future.result() == "my result"
    # Cancel the future and attempt to set the result.
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "my result")
    # Check the future is still cancelled.
    assert future.cancelled()



# Generated at 2022-06-26 07:56:00.661245
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    future = loop.create_future()
    future2 = loop.create_future()
    chain_future(future, future2)
    future.set_result(1)
    assert loop.run_until_complete(future2) == 1

# Generated at 2022-06-26 07:56:02.516508
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test_decorator()
    test_case_0()


# Generated at 2022-06-26 07:57:05.884617
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    # test if future_1 has been chained with future_0
    assert(not future_1.done())
    future_0.set_result(True)
    assert(future_1.done())
    assert(future_1.result())


# Generated at 2022-06-26 07:57:12.133499
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    a = Future()
    b = Future()

    @gen.coroutine
    def f():
        chain_future(a, b)

    def callback(future):
        IOLoop.current().stop()

    future_add_done_callback(b, callback)
    IOLoop.current().add_callback(f)
    IOLoop.current().start()

    assert a.result() is None



# Generated at 2022-06-26 07:57:24.280070
# Unit test for function chain_future
def test_chain_future():
    def fail(future):
        future.set_exception(ReturnValueIgnoredError("should not be reached"))
        raise Exception("should not be reached")

    def success(future):
        future.set_result(None)
        raise Exception("should not be reached")

    def cancel(future):
        future.cancel()
        raise Exception("should not be reached")

    for make_future in (Future, futures.Future):
        # A -> B
        a = make_future()
        b = make_future()
        chain_future(a, b)
        a.set_result(None)
        assert b.done()
        assert not b.cancelled()
        assert b.exception() is None

        # A -> B -> C
        a = make_future()
        b = make_future()
        c = make

# Generated at 2022-06-26 07:57:31.922995
# Unit test for function chain_future
def test_chain_future():
    # Test asyncio.Future
    test_future_a = asyncio.Future()
    test_future_b = asyncio.Future()
    chain_future(test_future_a, test_future_b)
    assert test_future_b.done() is False
    test_future_a.set_result(1)
    assert test_future_b.done() is True
    assert test_future_b.result() is 1
    return
# test_chain_future()



# Generated at 2022-06-26 07:57:45.076051
# Unit test for function run_on_executor
def test_run_on_executor():
    a = 1
    b = 2
    c = 3
    class test_class:
        def __init__(self):
            self.a = a
            self.b = b
            self.c = c
            self.executor = dummy_executor
        @run_on_executor()
        def method_0(self, arg_0, arg_1, arg_2):
            self.assertEqual(self.a, arg_0)
            self.assertEqual(self.b, arg_1)
            self.assertEqual(self.c, arg_2)
        def method_1(self):
            self.method_0(self.a, self.b, self.c)
    test_class_0 = test_class()
    test_class_0.method_1()

# Unit test

# Generated at 2022-06-26 07:57:56.347972
# Unit test for function chain_future
def test_chain_future():
    future_first = Future()
    future_second = Future()
    chain_future(future_first, future_second)

    future_first.set_result(10)
    assert future_second.result() == 10

    # The following test checks that the callback does not copy the value
    # if the second future has been completed.
    future_second = Future()
    future_first = Future()
    chain_future(future_first, future_second)
    future_second.set_result(20)
    future_first.set_result(10)
    assert future_second.result() == 20

    # The following test checks that the callback does not copy anything if
    # the second future has been cancelled.
    future_second = Future()
    future_first = Future()
    chain_future(future_first, future_second)


# Generated at 2022-06-26 07:57:58.256481
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Args:
    #   future (Future):
    #   exc (Exception):
    # Returns: None
    pass

# Generated at 2022-06-26 07:58:00.512817
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

# Generated at 2022-06-26 07:58:10.604951
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future_1 = Future()  # type: Future[int]
    future_2 = Future()  # type: Future[int]

    def callback(future_3):
        # type: (Future[int]) -> None
        assert future_3 is future_1
        assert not future_3.cancelled()
        assert future_3.exception() == None
        assert future_3.result() == 1
        assert not future_2.cancelled()
        assert future_2.exception() == None
        assert future_2.result() == 1

    future_1.set_result(1)
    chain_future(future_1, future_2)
    future_add_done_callback(future_2, callback)

# Generated at 2022-06-26 07:58:21.699039
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    loop = IOLoop.current()

    class Mock:
        def __init__(self, rv: object) -> None:
            self.rv = rv

        def do(self: Mock) -> object:
            return self.rv

    async def chain_future_test():
        m = Mock("whale")  # type: Mock
        f = chain_future(dummy_executor.submit(m.do),
                         loop.create_future())  # type: Future
        assert await f == "whale"

        # do it again with a failure
        with pytest.raises(TypeError):
            chain_future(dummy_executor.submit(m.do),
                         loop.create_future())  # type: Future
            await f

    loop.run_