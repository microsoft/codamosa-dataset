

# Generated at 2022-06-26 07:48:54.377388
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 13)
    assert f.result() == 13

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 13)
    assert f.result() == 13

# Generated at 2022-06-26 07:48:56.375855
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_set_result_unless_cancelled(Future(), None)
    
    

# Generated at 2022-06-26 07:49:00.044631
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Test case : set exception normally
    future = Future()
    future_set_exception_unless_cancelled(future, None)
    assert future.exception() == None

    # Test case : set exception to future after cancelling
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, None)


# Generated at 2022-06-26 07:49:08.188555
# Unit test for function chain_future
def test_chain_future():
    def foo(a: int):
        return a + 1

    assert foo(1) == 2
if __name__ == "__main__":
    import unittest

    test_case_0()


    # Unit test
    class Test_run_on_executor(unittest.TestCase):
        def test_run_on_executor(self):
            callable_0 = run_on_executor()

    unittest.main(exit=False)

# Generated at 2022-06-26 07:49:10.189431
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)


# Generated at 2022-06-26 07:49:11.623767
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    asyncio.run(chain_future(future, future))

# Generated at 2022-06-26 07:49:14.012292
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_case_0():
        callable_0 = run_on_executor()



# Generated at 2022-06-26 07:49:24.019176
# Unit test for function chain_future
def test_chain_future():
    _future = Future()
    chain_future(_future, _future)
    assert not _future.done()
    assert type(_future) is Future

    _future.set_result(1)
    assert _future.done()

    _future = Future()
    chain_future(_future, _future)
    _future.set_exception(RuntimeError)
    assert _future.done()
    assert type(_future) is Future

    _future = Future()
    chain_future(_future, _future)
    _future.cancel()
    assert _future.done()
    assert type(_future) is Future



# Generated at 2022-06-26 07:49:28.277565
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future_obj = Future()
    future_set_result_unless_cancelled(test_future_obj, "hello")
    if test_future_obj.result() == "hello":
        return True
    else:
        return False


# Generated at 2022-06-26 07:49:29.010235
# Unit test for function run_on_executor
def test_run_on_executor():
    pass



# Generated at 2022-06-26 07:49:45.474090
# Unit test for function chain_future

# Generated at 2022-06-26 07:49:47.916837
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future1.set_result(None)
    chain_future(future1, future2)
    assert future2.done()
    assert future2.result() is None



# Generated at 2022-06-26 07:49:54.322874
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future() # type: ignore
    f.set_result(None)
    g = Future() # type: ignore
    chain_future(f, g)
    assert g.done() and g.result() is None

if __name__=="__main__":
    test_case_0()
    test_chain_future()

# Generated at 2022-06-26 07:49:59.028312
# Unit test for function run_on_executor
def test_run_on_executor():
    def callable(self, *args, **kwargs):
        pass

    executor = 'executor'
    wrapper = run_on_executor(executor='_thread_pool')(callable)
    print(wrapper)

    from tornado.gen import coroutine

    @coroutine
    def test():
        import time
        import random
        f = run_on_executor(time.sleep, 5)
        print('sleep 5 seconds')
        yield f
        print('sleep finished!')

    test()

# Generated at 2022-06-26 07:50:03.903932
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    assert isinstance(future_1, Future)
    future_2 = Future()
    assert isinstance(future_2, Future)
    chain_future(future_1, future_2)
    future_1.set_result(None)
    assert future_2.done()


# Generated at 2022-06-26 07:50:09.305807
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    # future is not cancelled
    future_set_exception_unless_cancelled(future, Exception())
    # future is cancelled
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())


# Generated at 2022-06-26 07:50:12.367142
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    future_set_exception_unless_cancelled(future_0, Exception())
    try:
        assert future_0.result() == None
        assert False
    except Exception as e:
        assert isinstance(e, Exception)

# Generated at 2022-06-26 07:50:22.849380
# Unit test for function chain_future
def test_chain_future():
    def callback_0(future: Future):
        print("call back 0")
        if future.exception() is not None:
            pass
        else:
            result_0 = future.result()
            assert result_0 == "example"

    future_0 = Future()
    future_1 = Future()
    future_0.set_result("example")
    assert future_0.done()
    chain_future(future_0, future_1)
    future_1.add_done_callback(callback_0)
    assert future_1.done()
    assert future_0.done()
    assert future_1.result() == "example"


# Generated at 2022-06-26 07:50:33.153706
# Unit test for function chain_future
def test_chain_future():
    # both futures are asyncio futures
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    future_0.set_result("result")
    assert future_1.result() == "result"

    # both futures are concurrent futures
    future_0 = futures.Future()
    future_1 = futures.Future()
    chain_future(future_0, future_1)
    future_0.set_result("result")
    assert future_1.result() == "result"

    # one future is an asyncio future, the other is a concurrent future
    future_0 = Future()
    future_1 = futures.Future()
    chain_future(future_0, future_1)
    future_0.set_result("result")
    assert future_1.result

# Generated at 2022-06-26 07:50:44.286609
# Unit test for function chain_future
def test_chain_future():
    pass
    # a = Future[Any]()
    # b = Future[Any]()
    # chain_future(a, b)
    # assert not b.done()
    # a.set_result(1)
    # assert b.done()
    # c = Future[Any]()
    # d = Future[Any]()
    # c.set_result(1)
    # chain_future(c, d)
    # assert d.done()
    # e = Future[Any]()
    # f = Future[Any]()
    # e.set_exception(Exception("exception from e"))
    # chain_future(e, f)
    # assert f.done()
    # assert f.exception()



# Generated at 2022-06-26 07:50:53.643160
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is ValueError()
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is None

# Generated at 2022-06-26 07:51:04.392338
# Unit test for function chain_future
def test_chain_future():
    concurrent_future = futures.Future()  # type: futures.Future
    async_future = Future()  # type: Future

    async_future_result = async_future.result()  # type: Future
    async_future_exception = async_future.exception()  # type: Future

    future_set_result_unless_cancelled(concurrent_future, 1)
    future_set_result_unless_cancelled(async_future, 1)

    future_set_exc_info(concurrent_future, sys.exc_info())
    conc_future_exc_info = concurrent_future.exc_info()
    future_set_exc_info(async_future, sys.exc_info())
    async_future_exc_info = async_future.exc_info()


# Generated at 2022-06-26 07:51:12.437113
# Unit test for function chain_future
def test_chain_future():
    # ensure that a synchronous function gets run on an executor
    def blocking_fn():
        x = 0
        while x < 10000000:
            x += 1

    f = Future()

    ioloop = IOLoop()
    executor = ThreadPoolExecutor(1)
    ioloop.spawn_callback(blocking_fn)
    ioloop.spawn_callback(blocking_fn)

    # f is already done, so chain_future should not block
    chain_future(f, Future())

    # f is not yet done, but f2 is already done, so chain_future should not block
    f2 = Future()
    f2.set_result(None)
    chain_future(f, f2)

    # f is not done and f2 is not done, so the result of f should get copied to f2
   

# Generated at 2022-06-26 07:51:21.733693
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.set_result(10)

    exc = Exception("This exception is set on future")
    future_set_exception_unless_cancelled(future, exc)

    assert future.exception() == exc

    exc_cancelled = Exception(
        "This exception is set on future after it has been cancelled"
    )
    future.cancel()
    future_set_exception_unless_cancelled(future, exc_cancelled)

    assert future.cancelled() == True
    assert future.exception() == exc


# Generated at 2022-06-26 07:51:29.722678
# Unit test for function chain_future
def test_chain_future():
    future_1 = asyncio.Future()
    future_2 = asyncio.Future()
    future_3 = concurrent.futures.Future()
    future_4 = concurrent.futures.Future()
    future_chain_future_0 = chain_future(
        future_1, future_2
    )
    future_chain_future_1 = chain_future(
        future_3, future_4
    )
    assert future_chain_future_0 is None
    assert future_chain_future_1 is None
    assert future_1.done() is False
    assert future_2.done() is False
    assert future_3.done() is False
    assert future_4.done() is False
    future_1.set_result(None)
    future_2.set_result(None)

# Generated at 2022-06-26 07:51:40.766316
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    import concurrent.futures
    import unittest

    class Server(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def f(self):
            return 1

    class Client(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(2)

        def chain_to_future(self, server):
            self_future = asyncio.Future()
            chain_future(server.f(), self_future)
            self_future.add_done_callback(self.callback)

        def callback(self, future):
            assert future.result() == 1


# Generated at 2022-06-26 07:51:45.756749
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    from tornado.concurrent import Future

    a_loop = asyncio.get_event_loop()
    a_loop.run_in_executor(None, lambda: None)

    from tornado.concurrent import Future

    a_loop = asyncio.get_event_loop()
    a_loop.run_in_executor(None, lambda: None)

    result = None
    a_future = Future()
    b_future = Future()
    result = chain_future(a_future, b_future)


# Generated at 2022-06-26 07:51:52.426853
# Unit test for function chain_future
def test_chain_future():
    value = False
    def assert_running(future: Future) -> None:
        nonlocal value
        assert value == False
        value = True
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)
    f1.add_done_callback(assert_running)
    f2.add_done_callback(assert_running)



# Generated at 2022-06-26 07:51:54.834032
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future[int]
    future_set_result_unless_cancelled(future, 4)
    assert future.result() == 4



# Generated at 2022-06-26 07:51:56.939771
# Unit test for function run_on_executor
def test_run_on_executor():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 07:52:16.080368
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    result = 42
    future_set_result_unless_cancelled(future, result)
    assert future.result() == result

    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, result)
    assert future.result() != result


# Generated at 2022-06-26 07:52:22.552656
# Unit test for function chain_future
def test_chain_future():
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    a.set_result(3)
    assert b.result() == 3
    # set_exception is not supported by the thread executor
    # a.set_exception(ZeroDivisionError())
    # assert b.exception() is ZeroDivisionError()



# Generated at 2022-06-26 07:52:26.568653
# Unit test for function chain_future
def test_chain_future():
    try:
        chain_future(None, None)
    except TypeError as e:
        assert str(e) == 'chain_future() takes 2 positional arguments but 3 were given'

if __name__ == '__main__':
    test_chain_future()

# Generated at 2022-06-26 07:52:31.065838
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:52:43.704409
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()
    exc = Exception("test")
    future_set_exception_unless_cancelled(f, exc)
    assert not f.done()
    assert f.exception() is exc
    assert f.result() is None
    assert f.cancelled() is False

    f.cancel()
    future_set_exception_unless_cancelled(f, exc)
    assert f.done()
    assert f.result() is None
    assert f.cancelled() is True

    f = Future()
    future_set_exception_unless_cancelled(f, None)
    assert not f.done()
    assert f.result() is None
    assert f.done()
    assert f.cancelled() is False



# Generated at 2022-06-26 07:52:53.953280
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def fn_0(future, result_or_exc, callback_0=None):
        # type: (Future, Any, Optional[Callable[[], None]]) -> None
        if callback_0 is not None:
            callback_0()
        if result_or_exc is _NO_RESULT:
            raise Exception()
        elif result_or_exc is None:
            future.set_result(None)
        else:
            future.set_exception(result_or_exc)

    def callback_0(future):
        # type: (Future) -> None
        raise Exception()

    def test_0(result_or_exc):
        # type: (Any) -> None
        future_0 = Future()
        future_1 = Future()

# Generated at 2022-06-26 07:53:06.839712
# Unit test for function chain_future
def test_chain_future():
    from concurrent import futures
    from asyncio import Future
    from tornado.log import app_log
    from tornado.platform.asyncio import to_asyncio_future
    import sys

    f1 = Future()
    f2 = Future()
    f3 = futures.Future()

    # When f1.result() is defined, f2.result() will be set to the same value
    def callback_1(future):
        assert future.result() == 'test'
        assert f2.result() == 'test'
        assert f3.result() == 'test'

    # When f1.result() is defined, f2.result() will be set to the same value
    def callback_2(future):
        assert future.result() == 'test'
        assert f1.result() == 'test'
        assert f3.result()

# Generated at 2022-06-26 07:53:13.777135
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    from tornado.concurrent import run_on_executor

    class DummyClass:
        def __init__(self):
            self.future = Future()
            self.future2 = Future()

        @run_on_executor
        def func(self):
            return 1

    obj = DummyClass()

    @chain_future(obj.future, obj.future2)
    def callback(future):
        pass

    @chain_future(obj.future, obj.future2)
    def callback(future):
        pass

    @run_on_executor
    def callback(future):
        pass

    @chain_future(obj.future, obj.future2)
    def callback(future):
        pass

if __name__ == "__main__":
    test_case_0

# Generated at 2022-06-26 07:53:16.676625
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    value = 1
    future_set_result_unless_cancelled(future, value)
    assert future.result() == 1

# Generated at 2022-06-26 07:53:22.734745
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda: None)
    assert future.done()
    future = dummy_executor.submit(lambda: None, 1)
    assert future.done()
    future = dummy_executor.submit(lambda: None, 1, 2, a=3)
    assert future.done()
    future = dummy_executor.submit(lambda a, b, c: None, 1, 2, 3)
    assert future.done()

# Generated at 2022-06-26 07:53:33.331406
# Unit test for function chain_future
def test_chain_future():
    import inspect
    import types
    
    assert inspect.getfullargspec(chain_future).args == ['a', 'b']
    assert inspect.isfunction(chain_future) == False
    assert inspect.ismethod(chain_future) == True


# Generated at 2022-06-26 07:53:33.966120
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    pass

# Generated at 2022-06-26 07:53:35.845491
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:53:40.652876
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert f2.done() == False
    f1.set_result(1)
    assert f2.result() == 1


# Generated at 2022-06-26 07:53:47.337876
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = asyncio.Future()  # type: Future
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = asyncio.Future()  # type: Future
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())  # Does not raise.



# Generated at 2022-06-26 07:53:51.282592
# Unit test for function chain_future
def test_chain_future():
    def func_0(self = None, *args, **kwargs):
        return True

    callable_0 = run_on_executor()
    func_0 = callable_0(func_0)
    f = Future()  # type: Future
    g = Future()  # type: Future
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42
    f.set_exception(ValueError())
    assert_future_exception(f, ValueError)



# Generated at 2022-06-26 07:53:54.029389
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    value = 1
    future_set_result_unless_cancelled(future, value)
    assert future.result() == value


# Generated at 2022-06-26 07:53:54.711437
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:53:57.268592
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-26 07:54:06.228671
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    from tornado.ioloop import IOLoop
    from concurrent.futures import Future
    from tornado.concurrent import Future as TornadoFuture

    async def main():
        f1 = Future()
        f2 = TornadoFuture()
        f3 = TornadoFuture()
        f4 = Future()
        f5 = TornadoFuture()
        f6 = TornadoFuture()

        chain_future(f1, f2)
        chain_future(f3, f4)
        chain_future(f5, f6)

        f1.set_exception(ZeroDivisionError())
        f3.set_result(42)
        f5.set_result(None)

        try:
            await f2
        except ZeroDivisionError:
            print('f2 is finished')

        await f4

# Generated at 2022-06-26 07:54:31.698698
# Unit test for function run_on_executor
def test_run_on_executor():
    import logging
    import sys
    import time

    from tornado import concurrent
    from tornado import gen
    from tornado import ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future

    AsyncIOMainLoop().install()
    logging.getLogger("tornado.access").disabled = True

    class CustomExecutor(concurrent.futures.ThreadPoolExecutor):
        pass

    @gen.coroutine
    def test_executor():
        class TestCase(object):
            executor = CustomExecutor()

            @run_on_executor
            def something(self, a, b):
                return a + b


# Generated at 2022-06-26 07:54:37.001424
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class TestException(Exception):
        pass

    e = TestException()

    f = Future()
    f.set_exception(e)
    future_set_exception_unless_cancelled(f, e) # Shouldn't raise
    f.set_exception(e)
    future_set_exception_unless_cancelled(f, e) # Shouldn't raise
    assert len(f.exception().__suppress_context__) == 2

# Generated at 2022-06-26 07:54:40.634743
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    result = 1
    future_set_result_unless_cancelled(future, result)
    assert future.result == result


# Generated at 2022-06-26 07:54:43.287303
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    callable_0 = DummyExecutor.submit
    executor = DummyExecutor()
    callable_0(executor)


# Generated at 2022-06-26 07:54:47.033589
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, None)
    future.cancel()
    future_set_exception_unless_cancelled(future, None)
    # test_case_0()

# Generated at 2022-06-26 07:54:55.457918
# Unit test for function chain_future
def test_chain_future():
    def copy(future):
        assert future is a

    def test_callback(future):
        test_future.set_result('ABC')

    import concurrent.futures
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    class WSHandler(tornado.websocket.WebSocketHandler):
        def open(self):
            self.write_message("Hello, world")
            self.close()

    def get_app():
        return tornado.web.Application([(r"/", MainHandler), (r"/ws", WSHandler)])

    def response_message(future_message):
        future_message.result()



# Generated at 2022-06-26 07:55:00.476733
# Unit test for function chain_future
def test_chain_future():
    future_a = futures.Future()  # type: futures.Future[int]
    future_b = futures.Future()  # type: futures.Future[int]
    chain_future(future_a, future_b)
    future_b.set_result(100)
    assert future_a.result() == 100



# Generated at 2022-06-26 07:55:06.300963
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    fn = lambda x: x
    args = (3,4)
    kwargs = {'f': 5}
    future = dummy_executor.submit(fn, *args, **kwargs)
    future.result()


# Generated at 2022-06-26 07:55:10.952941
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exception = Exception("invalid parameter")
    future = Future()

    def _test(future):
        future_set_exception_unless_cancelled(future, exception)
        assert future.exception() == exception

    _test(future)
    future = Future()
    future.cancel()
    _test(future)

# Generated at 2022-06-26 07:55:21.839954
# Unit test for function chain_future
def test_chain_future():
    fn = lambda : 42
    for a in [Future(), futures.Future()]:
        for b in [Future(), futures.Future()]:
            chain_future(a, b)
            if a.done():
                assert b.done()
            a.set_result(fn)
            if b.done():
                assert a.done()
            b.set_exception(RuntimeError())
            if a.done():
                assert b.done()
            a.set_exception(RuntimeError())
            if b.done():
                assert a.done()
