

# Generated at 2022-06-26 07:48:57.523407
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    assert not f.done()
    future_set_exception_unless_cancelled(f, Exception("a"))
    assert f.done()
    try:
        f.result()
    except Exception as e:
        assert e.args[0] == "a"
    else:
        raise AssertionError("should have raised")
    f = Future()
    f.cancel()
    assert f.done()
    future_set_exception_unless_cancelled(f, Exception("b"))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 07:49:09.861065
# Unit test for function chain_future
def test_chain_future():
    print('\nUnit test for function chain_future')
    import random
    import time
    import concurrent.futures as futures
    import asyncio
    from tornado.ioloop import IOLoop

    def task_A(time_to_sleep = 1):
        time.sleep(time_to_sleep)
        return random.random()
    def task_B(time_to_sleep = 1):
        time.sleep(time_to_sleep)
        return random.random()

    def test_case_1():
        loop = IOLoop.current()
        async_future_A = Future()  # type: Future
        async_future_B = Future()  # type: Future
        # Execute task A and chain the result to async_future_A
        task_A_executor.submit(task_A, 3).add

# Generated at 2022-06-26 07:49:19.019326
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class A(object):
        _executor = dummy_executor
        _thread_pool = dummy_executor

        def __init__(self, x):
            self.x = x

        @run_on_executor
        def foo(self):
            return self.x

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            return self.x

    a = A(42)
    assert a.foo().result() == 42
    assert a.bar().result() == 42



# Generated at 2022-06-26 07:49:22.539999
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    # Check if result is correct
    #### assert dummy_executor_0.submit(foo_0, 1) == 2


# Generated at 2022-06-26 07:49:31.320421
# Unit test for function chain_future
def test_chain_future():

    import asyncio

    class DummyExecutor(futures.Executor):
        def submit(
            self, fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "futures.Future[_T]":
            future = futures.Future()  # type: futures.Future[_T]
            try:
                future_set_result_unless_cancelled(future, fn(*args, **kwargs))
            except Exception:
                future_set_exc_info(future, sys.exc_info())
            return future

        def shutdown(self, wait: bool = True) -> None:
            pass

    dummy_executor = DummyExecutor()

    future_0 = Future()
    future_1 = futures.Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:49:42.468825
# Unit test for function chain_future
def test_chain_future():
    a = futures.Future()
    b = futures.Future()

    # a = b = Futures.
    chain_future(a, b)

    a.set_exception(ReturnValueIgnoredError())
    b.set_exception(ReturnValueIgnoredError())

    # a = completed, b = not completed.
    chain_future(a, b)

    a.set_exception(ReturnValueIgnoredError())
    b.set_exception(ReturnValueIgnoredError())

    # a = completed, b = completed.
    chain_future(a, b)

    # Run on the executor
    run_on_executor(dummy_executor, func)


# Generated at 2022-06-26 07:49:50.497586
# Unit test for function chain_future
def test_chain_future():
    f=Future()
    f.set_result(12)
    def cb(future):
        print(future.result())
    chain_future(f, f)
    chain_future(f, f)
    future_add_done_callback(f, lambda x:print(x.result()))
    future_add_done_callback(f, cb)
    future_add_done_callback(f, lambda x:print(x.result()))
    future_add_done_callback(f, cb)
    #print(f.result())


# Generated at 2022-06-26 07:49:54.322799
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_test: Union[Future[int], futures.Future[int]] = Future()
    future_set_result_unless_cancelled(future_test, 42)
    assert future_test.result() == 42


# Generated at 2022-06-26 07:49:57.988119
# Unit test for function chain_future
def test_chain_future():
    def _test_future_result(fut):
        assert 3 == fut.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(3)
    f2.add_done_callback(_test_future_result)



# Generated at 2022-06-26 07:50:09.686380
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # test_future_set_exception_unless_cancelled_case_0()  # TODO: enable this test after we fix https://github.com/python/mypy/issues/5374
    dummy_exc_0 = Exception()
    dummy_future_0 = Future()
    future_set_exception_unless_cancelled(dummy_future_0, dummy_exc_0)
    dummy_future_1 = Future()
    future_set_exception_unless_cancelled(dummy_future_1, dummy_exc_0)
    dummy_future_1.cancel()
    dummy_exc_1 = Exception()
    dummy_exc_1.args = (1, 2)
    dummy_exc_2 = Exception()
    dummy_exc_2.args = (2, 3)
    dummy_exc

# Generated at 2022-06-26 07:50:17.842583
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()
    res_6 = run_on_executor(executor=dummy_executor_0)
    def func_4(x: Any) -> None:
        pass
    res_5 = run_on_executor(func_4)



# Generated at 2022-06-26 07:50:21.175050
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f1 = Future()
    chain_future(f, f1)
    f.set_result(True)
    assert f1.result()

# Generated at 2022-06-26 07:50:30.764282
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future
    future.cancel()
    class AnError(BaseException):
        pass
    exception = AnError("fake exception")
    future_set_exception_unless_cancelled(future, exception)
    # exception not stored in future.exception
    assert(future.exception() == None)


if __name__ == "__main__":
    import unittest

    class Test(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(
            self,
        ):
            test_future_set_exception_unless_cancelled()

    unittest.main()

# Generated at 2022-06-26 07:50:34.999907
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    value_0 = ()
    # Verify that the following call doesn't raise an exception.
    future_set_result_unless_cancelled(future_0, value_0)


# Generated at 2022-06-26 07:50:38.309389
# Unit test for function chain_future
def test_chain_future():
    dummy_executor_1 = DummyExecutor()
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)


# Generated at 2022-06-26 07:50:43.374643
# Unit test for function run_on_executor
def test_run_on_executor():
    dummy_executor_0 = DummyExecutor()

    def dummy_executor_submit(fn, *args, **kwargs):
        async_future = Future()  # type: Future
        chain_future(fn(*args, **kwargs), async_future)
        return async_future

    dummy_executor_0.submit = dummy_executor_submit

# Generated at 2022-06-26 07:50:51.079606
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test Future is not cancelled
    future = Future()
    future_set_result_unless_cancelled(future, 0)
    assert future.result() == 0

    # Test Future is cancelled
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 0)
    assert future.result(timeout=0) == 0



# Generated at 2022-06-26 07:50:57.933772
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # TODO: refactor to not use globals
    dummy_executor_0 = DummyExecutor()
    dummy_fn_0 = lambda: None
    dummy_args_0 = ()
    dummy_kwargs_0 = {}
    res_0 = dummy_executor_0.submit(
        dummy_fn_0,
        *dummy_args_0,
        **dummy_kwargs_0
    )
    assert isinstance(res_0, futures.Future)


# Generated at 2022-06-26 07:51:05.527885
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyClass:
        def __init__(self) -> None:
            self.executor = dummy_executor_0

        @run_on_executor
        def method1(self, arg1, arg2) -> int:
            return arg1 + arg2

    obj = MyClass()
    future = obj.method1(1, 2)
    assert future.result() == 3



# Generated at 2022-06-26 07:51:13.506137
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut = Future()
    assert fut.done() is False
    future_set_result_unless_cancelled(fut, 1)
    assert fut.done() is True
    assert fut.result() == 1
    fut = Future()
    fut.cancel()
    assert fut.done() is True
    future_set_result_unless_cancelled(fut, 2)
    assert fut.done() is True  # 'result' not set
    assert fut.cancelled() is True


# Generated at 2022-06-26 07:51:23.197123
# Unit test for function chain_future
def test_chain_future():
    f1 = futures.Future()
    f2 = asyncio.Future()
    chain_future(f1, f2)
    assert f2.done()
    assert f2.cancelled() is False
    assert f2.exception() is None
    assert f2.result() is None



# Generated at 2022-06-26 07:51:27.604616
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    for var in range(1, 6):
        try:
            if var < 3:
                future.set_result(5)
                future_set_exception_unless_cancelled(future, BaseException())
            else:
                future.cancel()
                future_set_exception_unless_cancelled(future, BaseException())
        except Exception:
            pass

# Generated at 2022-06-26 07:51:31.542263
# Unit test for function chain_future
def test_chain_future():
    # Test with concurrent.futures.Future
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    a.set_result("test_chain_future")
    assert b.result() == b.result()
    # Test with asyncio.Future
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result("test_chain_future")
    assert b.result() == b.result()



# Generated at 2022-06-26 07:51:41.898640
# Unit test for function chain_future
def test_chain_future():
    f1 = futures.Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f1.done() is True
    assert f2.done() is True
    assert f2.result() == 1

    f1 = futures.Future()
    f2 = futures.Future()
    f2.set_result(2)
    chain_future(f1, f2)
    assert f1.done() is False
    assert f2.done() is True
    assert f2.result() == 2

    f1 = futures.Future()
    f2 = futures.Future()
    f1.set_result(3)
    f2.set_result(3)
    chain_future(f1, f2)

# Generated at 2022-06-26 07:51:45.451735
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f.set_result(1)
    g = Future()
    chain_future(f, g)
    assert g.result() == 1


# Generated at 2022-06-26 07:51:48.627585
# Unit test for function chain_future
def test_chain_future():

    # Create future a
    a = Future()

    # Create future b
    b = Future()

    # Can chain these!
    chain_future(a, b)



# Generated at 2022-06-26 07:51:57.267014
# Unit test for function chain_future
def test_chain_future():
    input0 = futures.Future()
    input1 = futures.Future()
    # call the function
    chain_future(input0, input1)
    # now it should be done
    assert input1.done()
    assert not input1.cancelled()
    assert input1.exception() is None
    if not input1.result() == None:
        raise ValueError('expected None, got %s' % input1.result())
    input2 = futures.Future()
    # call the function
    chain_future(input2, input1)
    # now it should be done
    assert input1.done()
    assert not input1.cancelled()
    assert input1.exception() is None

# Generated at 2022-06-26 07:52:07.275473
# Unit test for function chain_future
def test_chain_future():
    inner_future = Future()
    outer_future = Future()
    chain_future(inner_future, outer_future)
    inner_future.set_result(42)
    assert outer_future.result() == 42
    inner_future = Future()
    outer_future = Future()
    chain_future(inner_future, outer_future)
    inner_future.set_exception(RuntimeError)
    try:
        outer_future.result()
    except Exception:
        assert isinstance(outer_future.exception(), RuntimeError)


# Generated at 2022-06-26 07:52:12.204750
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 2)
    assert f.cancelled() is True


# Generated at 2022-06-26 07:52:26.350114
# Unit test for function run_on_executor
def test_run_on_executor():

    class MyClass:
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor()
        async def foo(self, arg1, arg2, arg3):
            pass

        @run_on_executor(executor='_thread_pool')
        def foo(self):
            pass

    foo = MyClass(dummy_executor)
    executor = foo.executor
    # test foo function
    foo.foo("arg1", "arg2", "arg3")
    foo._thread_pool("arg1", "arg2", "arg3")
    # test foo attributes
    assert isinstance(foo.foo("arg1", "arg2", "arg3"), Future)

# Generated at 2022-06-26 07:52:40.921662
# Unit test for function chain_future
def test_chain_future():
    future_0 = asyncio.Future()
    future_1 = asyncio.Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:52:51.540711
# Unit test for function chain_future
def test_chain_future():
    assert isinstance(dummy_executor, DummyExecutor)
    for _ in range(10):
        assert isinstance(run_on_executor, Callable)
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert f2.done()
    chain_future(f1, f2)
    assert f1.done()
    assert f2.done()
    future_add_done_callback(f1, chain_future)
    f1.set_result(1)
    f2.set_result(2)
    future_set_result_unless_cancelled(f1, 1)
    future_add_done_callback(f2, lambda x: print("f2 done: lambda"))

# Generated at 2022-06-26 07:52:58.153659
# Unit test for function chain_future
def test_chain_future():
    def test_chain_future_0(a: "Future[_T]", b: "Future[_T]") -> None:
        def copy(future: "Future[_T]") -> None:
            assert future is a
            if b.done():
                return 
            if hasattr(a, "exc_info") and a.exc_info() is not None:  # type: ignore
                future_set_exc_info(b, a.exc_info())  # type: ignore
            elif a.exception() is not None:
                b.set_exception(a.exception())
            else:
                b.set_result(a.result())

        if isinstance(a, Future):
            future_add_done_callback(a, copy)

# Generated at 2022-06-26 07:53:00.618275
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    dummy_executor_1 = DummyExecutor()



# Generated at 2022-06-26 07:53:04.935157
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    f1.set_result(1)
    f2.set_result(2)
    chain_future(f1, f2)
    assert f1.result() == 1
    assert f2.result() == 2

# Generated at 2022-06-26 07:53:12.056495
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from concurrent.futures import Future as Future_0
    future = Future_0()
    future.set_result("foo")
    try:
        future.set_result("bar")
    except asyncio.InvalidStateError:
        pass
    else:
        assert False
    future_set_result_unless_cancelled(future, "bar")
    assert future.result() == "foo"
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, "baz")
    assert future.cancelled()

# Generated at 2022-06-26 07:53:15.904772
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = DummyExecutor()
    fn_0: Callable[..., _T] = lambda: None
    args_0: Any = None
    kwargs_0: Any = None
    future_0: Callable[[], None] = dummy_executor_0.submit(fn_0, *args_0, **kwargs_0)


# Generated at 2022-06-26 07:53:23.414059
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def f(self, x: int, y: int) -> int:
        return x + y

    class Foo(object):
        def __init__(self, executor: Any) -> None:
            self.executor = executor

        def test(self, x: int, y: int) -> Future:
            return f(self, x, y)

    f = Foo(dummy_executor)

    r = f.test(1, 2)  # type: Future
    assert r.result() == 3



# Generated at 2022-06-26 07:53:27.164582
# Unit test for function chain_future
def test_chain_future():
    import concurrent.futures
    import asyncio
    future1 = concurrent.futures.Future()
    future2 = asyncio.Future()
    chain_future(future1, future2)
    pass

# Generated at 2022-06-26 07:53:40.653203
# Unit test for function chain_future
def test_chain_future():
    def assertTrue(x: Any) -> None:
        assert x == True

    def assertFalse(x: Any) -> None:
        assert x == False

    def assertEqual(a: Any, b: Any) -> None:
        assert a == b

    future = Future()
    chained_future = Future()
    long_future = Future()

    assertEqual(future.done(), False)
    chain_future(future, chained_future)
    assertEqual(chained_future.done(), False)
    future.set_result("foo")
    assertTrue(chained_future.done())
    assertEqual(chained_future.result(), "foo")

    future = Future()
    chained_future = Future()
    chain_future(future, chained_future)
    assertFalse(chained_future.done())


# Generated at 2022-06-26 07:53:57.874936
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    """Test the chain_future"""
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    future_1.set_result(True)
    future_2.result() == True



# Generated at 2022-06-26 07:54:04.291453
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    e = Exception("set_exception_unless_cancelled test")
    future_set_exception_unless_cancelled(f, e)
    f.add_done_callback(lambda f: f.result())
    f.cancel()
    future_set_exception_unless_cancelled(f, e)

if __name__ == "__main__":
    test_case_0()
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-26 07:54:08.998507
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    f1.set_result(2)
    chain_future(f1, f2)
    res = f2.result()
    assert(res == 2)


# Generated at 2022-06-26 07:54:15.343535
# Unit test for function run_on_executor
def test_run_on_executor():
    class Test:
        executor = dummy_executor
        @run_on_executor
        def foo(self):
            pass
        @run_on_executor(executor='_thread_pool')
        def bar(self):
            pass
    t = Test()
    t.foo() # should not error
    t.bar() # should not error
    t.executor.shutdown(wait=True)



# Generated at 2022-06-26 07:54:22.283591
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo:
        def __init__(self):
            self.executor = dummy_executor
            self.foo = None
            self.bar = None
            self.baz = None

        @run_on_executor
        def set_foo(self, arg):
            return arg

        @run_on_executor(executor="_thread_pool")
        def set_bar(self, arg):
            return arg

        @run_on_executor(executor="dummy_executor_0")
        def set_baz(self, arg):
            return arg

    foo = Foo()
    foo.set_foo(42)
    assert foo.foo is None
    foo.set_bar(43)
    assert foo.bar is None
    foo.set_baz(44)
    assert foo.b

# Generated at 2022-06-26 07:54:34.948514
# Unit test for function chain_future
def test_chain_future():
    def copy(future: Future[int]) -> None:
        assert future is a
        if b.done():
            return
        if hasattr(a, "exc_info") and a.exc_info() is not None:  # type: ignore
            future_set_exc_info(b, a.exc_info())  # type: ignore
        elif a.exception() is not None:
            b.set_exception(a.exception())
        else:
            b.set_result(a.result())

    a = Future()
    b = Future()
    chain_future(a, b)

    assert a.done() is False
    assert b.done() is False
    a.set_result(1)
    assert a.done() is True
    assert b.done() is True
    assert a.result()

# Generated at 2022-06-26 07:54:46.899333
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    f1.set_result(3)
    assert f2.result() == 3
    f3 = Future()
    f4 = Future()
    f3.set_exception(Exception('error'))
    try:
        f4.result()
        assert False
    except Exception as e:
        assert e.args[0] == 'error'
    f5 = Future()
    f6 = Future()
    f5.set_result(3)
    f6.set_result(7)
    assert f6.cancelled() == False
    assert f6.done() == True

# Generated at 2022-06-26 07:54:48.928770
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(5)



# Generated at 2022-06-26 07:54:56.638650
# Unit test for function chain_future
def test_chain_future():
    # Testing if chain_future chains the two futures
    future_a = Future()
    future_a.set_result("Success")
    future_b = Future()
    chain_future(future_a, future_b)
    assert future_b.result() == "Success"
    # Testing if chain_future works for concurrent.futures.Future
    future_c = futures.Future()
    future_c.set_result("Success")
    future_d = Future()
    chain_future(future_c, future_d)
    assert future_d.result() == "Success"
    # Testing if chain_future works for concurrent.futures.Future
    future_e = Future()
    future_e.set_result("Success")
    future_f = futures.Future()

# Generated at 2022-06-26 07:55:03.973956
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(10)
    assert b.result() == 10

    c = Future()
    d = Future()
    chain_future(c, d)
    c.set_exception(ValueError("Error"))
    assert d.exception().args == ('Error',)

    e = Future()
    f = Future()
    chain_future(e, f)
    f.set_exception(ValueError("Error"))
    assert e.exception().args == ('Error',)


if __name__ == "__main__":
    # test_case_0()
    test_chain_future()

# Generated at 2022-06-26 07:55:29.603147
# Unit test for function chain_future
def test_chain_future():
    try:
        import asyncio

        # Test future chaining with asyncio.Future.
        f = asyncio.Future()
        g = asyncio.Future()
        chain_future(f, g)
        f.set_result("f-result")
        assert g.result() == "f-result"

        # Test future chaining with concurrent.futures.Future.
        f = futures.Future()
        g = asyncio.Future()
        chain_future(f, g)
        f.set_result("f-result")
        assert g.result() == "f-result"
    except ImportError:
        # Can't test with the real Future because no tornado.platform.asyncio module.
        pass

    # Test future chaining with Tornado's Future.
    f = Future()
    g = Future()
    chain

# Generated at 2022-06-26 07:55:37.097972
# Unit test for function run_on_executor
def test_run_on_executor():
    class A:
        def __init__(self):
            self.executor = dummy_executor_0

        @run_on_executor
        def dummy_method_0(self, arg1):
            return "hello"

    a = A()

    result = a.dummy_method_0(4)  # type: Future
    assert isinstance(result, Future)
    result_0 = result.result()
    assert result_0 == "hello"


# Generated at 2022-06-26 07:55:39.897699
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(3)
    b.result()
    pass




# Generated at 2022-06-26 07:55:47.176437
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Check that `future_set_exception_unless_cancelled` logs exception when future was already cancelled.
    future = asyncio.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    with pytest.raises(ValueError):
        future_set_exception_unless_cancelled(future, ValueError())



# Generated at 2022-06-26 07:56:00.624566
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    import concurrent
    import tornado.testing
    import typing

    @typing.overload
    def chain_future(
        a: "Future[_T]", b: "Future[_T]"
    ) -> None:
        pass

    @typing.overload  # noqa: F811
    def chain_future(
        a: "concurrent.futures.Future[_T]", b: "Future[_T]"
    ) -> None:
        pass

    @typing.overload  # noqa: F811
    def chain_future(
        a: "concurrent.futures.Future[_T]", b: "concurrent.futures.Future[_T]"
    ) -> None:
        pass


# Generated at 2022-06-26 07:56:06.389506
# Unit test for function chain_future
def test_chain_future():
    def func_a(x: int) -> int:
        return x + 1

    def func_b(x: int) -> int:
        return func_a(x) + 1

    future_00 = dummy_executor.submit(func_a, 1)
    future_01 = Future()

    chain_future(future_00, future_01)

    assert future_01.done()
    assert future_01.result() == 2



# Generated at 2022-06-26 07:56:13.023377
# Unit test for function chain_future
def test_chain_future():

    def eq(a, b):
        return a == b

    def set_a_result(a, value):
        a.set_result(value)

    def set_a_exception(a, e):
        a.set_exception(e)

    def set_a_exc_info(a, info):
        a.set_exc_info(info)

    def set_b_result(b, value):
        b.set_result(value)

    def set_b_exception(b, e):
        b.set_exception(e)

    def set_b_exc_info(b, info):
        b.set_exc_info(info)

    def test(set_a_f, a_value, set_b_f, b_value):
        a = Future()

# Generated at 2022-06-26 07:56:15.683567
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def test(exception):
        future = Future()
        future_set_exception_unless_cancelled(future, exception)
        return future

    assert test(Exception()).exception() is not None
    assert test(None) is not None

# Generated at 2022-06-26 07:56:18.776364
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.set_exception(Exception())
    future_set_exception_unless_cancelled(future, Exception())


# Generated at 2022-06-26 07:56:29.580440
# Unit test for function chain_future
def test_chain_future():
    f0 = Future()
    f1 = Future()
    # a may not be done
    assert f1.done() == False
    chain_future(f0, f1)
    f0.set_result(3)
    assert f1.done() == True
    assert f1.result() == 3

    try:
        Future.result(f0, timeout=0)
    except asyncio.TimeoutError:
        return True
    return False


test_case_0()
assert test_chain_future() is True

# Generated at 2022-06-26 07:56:44.223614
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_set_result_unless_cancelled(Future(), 10)
    future_set_result_unless_cancelled(futures.Future(), 10)


# Generated at 2022-06-26 07:56:54.625467
# Unit test for function chain_future
def test_chain_future():
    def test_func(num):
        # type: (int) -> int
        return num

    future = asyncio.Future()
    future_num = asyncio.Future()
    chain_future(future, future_num)
    assert future_num.done() is True
    future.set_result(3)
    assert future_num.result() == 3
    future_num = asyncio.Future()
    future_num.set_result(4)
    chain_future(future, future_num)
    # chain_future does not change the result if the future is completed
    assert future_num.result() == 4
    future.set_exception(ValueError(1))
    future_num = asyncio.Future()
    chain_future(future, future_num)
    # chain_future does not change the result if the future

# Generated at 2022-06-26 07:57:03.456762
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut = Future()

    # This test tries to invoke a Future.set_result if the future is not cancelled.
    # The test should pass if no exception is thrown.
    try:
        future_set_result_unless_cancelled(fut, None)
    except Exception:
        assert False



# Generated at 2022-06-26 07:57:04.892619
# Unit test for function run_on_executor
def test_run_on_executor():
    callable_0 = run_on_executor(executor = "_thread_pool")

# Generated at 2022-06-26 07:57:07.386930
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-26 07:57:11.654812
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio

    loop = asyncio.get_event_loop()
    executor = futures.ThreadPoolExecutor(1)
    loop.run_until_complete(
        asyncio.gather(
            loop.run_in_executor(executor, lambda: 1),
            loop.run_in_executor(executor, lambda: 2),
            loop.run_in_executor(executor, lambda: 3),
        )
    )

# Generated at 2022-06-26 07:57:24.055749
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    assert f.done() == False
    chain_future(f, f)
    assert f.done() == False

    g = Future()
    g.set_result(None)
    assert g.done() == True
    chain_future(g, f)
    assert f.done() == True

    h = Future()
    h.cancel()
    assert h.done() == True
    chain_future(h, f)
    assert f.done() == True

    i = Future()
    i.set_exception(Exception())
    assert i.done() == True
    chain_future(i, f)
    assert f.done() == True
    assert f.exception() == i.exception()

    j = futures.Future()
    j.set_result(None)
    assert j

# Generated at 2022-06-26 07:57:25.785262
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    pass
    # TODO: Remove this once we have a test_future_set_result_unless_cancelled
    # test case.
    # assert False



# Generated at 2022-06-26 07:57:26.685491
# Unit test for function run_on_executor
def test_run_on_executor():
    isinstance(run_on_executor, types.FunctionType)



# Generated at 2022-06-26 07:57:29.630269
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(2)
    assert b.result() == 2


# Generated at 2022-06-26 07:57:53.351465
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)


# Generated at 2022-06-26 07:57:55.683710
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    # NOTE: Not quite sure how to test this. I think it may be a decorator type function?
    pass


# Generated at 2022-06-26 07:57:59.860646
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    async_future = Future()
    conc_future = futures.Future()
    chain_future(conc_future, async_future)
    conc_future.cancel()
    assert not async_future.cancelled()



# Generated at 2022-06-26 07:58:00.924603
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    pass


# Generated at 2022-06-26 07:58:11.370749
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    class _implicit_class_0:
        async def __aenter__(self):
            pass
        async def __aexit__(self, exc_type, exc, tb):
            pass
    class _implicit_class_1:
        async def __aenter__(self):
            pass
        async def __aexit__(self, exc_type, exc, tb):
            pass
    def _implicit_func_0(x: "Future[int]") -> None:
        pass
    def _implicit_func_1(x: "Future[int]") -> None:
        pass
    def _implicit_func_2(x: int) -> None:
        pass
    def _implicit_func_3(x: int) -> None:
        pass

# Generated at 2022-06-26 07:58:14.438930
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def function1(self):
        pass

    @run_on_executor(executor="some_other_field")
    def function2(self):
        pass

    class MyClass:
        executor = dummy_executor



# Generated at 2022-06-26 07:58:16.433773
# Unit test for function chain_future
def test_chain_future():
    future_0 = asyncio.Future()
    future_1 = asyncio.Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:58:25.741885
# Unit test for function chain_future
def test_chain_future():
    class Future1(Future):
        def set_exception(self, exception):
            self.exception = exception

        def set_result(self, result):
            self.result = result

        def exc_info(self):
            return (type(self.exception), self.exception)

        def exception(self):
            return self.exception

    class Future2(Future):
        def set_exception(self, exception):
            self.exception = exception

        def set_result(self, result):
            self.result = result

        def exc_info(self):
            return (type(self.exception), self.exception)

        def exception(self):
            return self.exception


# Generated at 2022-06-26 07:58:31.702135
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test a future that was cancelled.
    future = Future()
    future.set_exception(RuntimeError("foo"))
    future_set_result_unless_cancelled(future, "bar")

    # Test a future that wasn't cancelled.
    future = Future()
    future_set_result_unless_cancelled(future, "baz")
    assert future.result() == "baz"



# Generated at 2022-06-26 07:58:34.969036
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    callable_0 = future_set_exception_unless_cancelled
