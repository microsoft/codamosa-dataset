

# Generated at 2022-06-26 07:48:54.408027
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    fut_0: Future[str] = Future()
    fut_1: Future[str] = Future()
    chain_future(fut_0, fut_1)
    assert fut_1.done() == False
    fut_0.set_result("")
    assert fut_1.done() == True

# Generated at 2022-06-26 07:49:01.120835
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = asyncio.Future()
    future_set_exception_unless_cancelled(f1, ValueError("error"))
    assert f1.done()
    assert not f1.cancelled()
    assert f1.exception() is not None
    assert issubclass(type(f1.exception()), ValueError)
    assert f1.exception().args == ("error",)

    f2 = asyncio.Future()
    f2.cancel()
    future_set_exception_unless_cancelled(f2, ValueError("error"))
    assert f2.done()
    assert f2.cancelled()

# Generated at 2022-06-26 07:49:14.223305
# Unit test for function chain_future
def test_chain_future():
    def test_call(fn: Callable[..., _T], a: bool, b: bool, c: bool, d: bool):
        future_a = Future()  # type: Future[Any]
        future_b = Future()  # type: Future[Any]
        future_c = Future()  # type: Future[Any]
        future_d = Future()  # type: Future[Any]

        # Use this to keep track of which future has been set
        tracker = []  # type: List[str]

        def callback(future: Future) -> None:
            if future is future_a:
                tracker.append("a")
            elif future is future_b:
                tracker.append("b")
            elif future is future_c:
                tracker.append("c")

# Generated at 2022-06-26 07:49:16.650206
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    fn_0 = dummy_executor.submit()
    fn_0()


# Generated at 2022-06-26 07:49:18.390883
# Unit test for function run_on_executor
def test_run_on_executor():
    assert run_on_executor
    assert test_case_0



# Generated at 2022-06-26 07:49:25.129592
# Unit test for function chain_future
def test_chain_future():
    callable_0 = futures.Future()
    callable_1 = futures.Future()
    callable_2 = Future()
    chain_future(callable_0, callable_2)
    chain_future(callable_1, callable_2)
    chain_future(None, callable_2)
    chain_future(None, None)



# Generated at 2022-06-26 07:49:27.026851
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    

# Generated at 2022-06-26 07:49:34.580511
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test that set_result works on a non-cancelled future
    future = Future()
    future_set_result_unless_cancelled(future, 'success')
    assert future.result() == 'success'

    # Test that set_result is a no-op when called on a cancelled future
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'success')
    assert future.cancelled()


# Generated at 2022-06-26 07:49:36.595740
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)



# Generated at 2022-06-26 07:49:38.928582
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10



# Generated at 2022-06-26 07:49:47.218633
# Unit test for function chain_future
def test_chain_future():
    futureA = asyncio.Future()
    futureB = asyncio.Future()
    chain_future(futureA, futureB)
    assert not futureB.done()
    futureA.set_result(1)
    assert futureB.done()
    assert futureB.result() == 1


# Generated at 2022-06-26 07:49:51.337604
# Unit test for function chain_future
def test_chain_future():
    # test_chain_future() # Uncomment to skip test
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    assert not future_1.done()
    future_0.set_result(None)
    assert future_1.done()



# Generated at 2022-06-26 07:49:56.518261
# Unit test for function chain_future
def test_chain_future():
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    # future_a not done
    assert not future_b.done()
    future_a.set_result("succeeded")
    assert future_b.done()
    assert future_b.result() == "succeeded"
    assert not future_b.cancelled()


# Generated at 2022-06-26 07:50:04.154965
# Unit test for function run_on_executor
def test_run_on_executor():
    x = a()
    x.executor = dummy_executor
    @run_on_executor
    def func(self):
        return self.x

    f = func(x)
    assert f.result() == 1
    assert f.done()

    @run_on_executor()
    def func(self):
        return self.x

    f = func(x)
    assert f.result() == 1
    assert f.done()

    @run_on_executor(executor="executor")
    def func(self):
        return self.x

    f = func(x)
    assert f.result() == 1
    assert f.done()

    @run_on_executor(executor="_thread_pool")
    def func(self):
        return self.x


# Generated at 2022-06-26 07:50:13.977189
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_1.done()
    future_1.done()
    future_1.done()
    future_0.set_result(None)
    future_1.done()
    future_1.done()
    future_1.done()
    future_0.set_result(None)
    future_1.done()
    future_1.done()
    future_1.done()
    future_1.set_result(None)
    future_1.done()
    future_1.done()
    future_1.done()
    future_0.result()
    future_0.result()
    future_1.set_result(None)
    future_0.result()
    future_0.result()
    future_0.set_

# Generated at 2022-06-26 07:50:25.315788
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f0 = asyncio.Future()
    f1 = asyncio.Future()
    chain_future(f0, f1)
    f0.set_result(5)
    assert f1.done()
    assert f1.result() == 5

    f0 = futures.Future()
    f1 = futures.Future()
    chain_future(f0, f1)
    f0.set_result(5)
    assert f1.done()
    assert f1.result() == 5

    # Test for wrong types
    # f0 = Future()
    # f1 = Future()
    # with pytest.raises(AssertionError):
    #     chain_future(f0, f1)

# Generated at 2022-06-26 07:50:29.711674
# Unit test for function chain_future
def test_chain_future():
    io_loop = asyncio.get_event_loop()
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result('a')
    assert b.done()
    assert b.result() == 'a'


# Generated at 2022-06-26 07:50:34.629405
# Unit test for function chain_future
def test_chain_future():
    def copy(x: 'Future[int]') -> None:
        x.set_result(10)

    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    future_0.set_result(1)
    assert future_1.result() == 1



# Generated at 2022-06-26 07:50:36.875221
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    conc_future = concurrent.futures.Future()
    chain_future(conc_future, future)


# Generated at 2022-06-26 07:50:49.525278
# Unit test for function chain_future
def test_chain_future():
    import times

    async_future_0 = Future()
    conc_future_0 = futures.Future()
    chain_future(conc_future_0, async_future_0)
    # Test that the asynchronous future is completed when the
    # concurrent future is completed
    conc_future_0.set_result(42)
    assert async_future_0.done()
    assert async_future_0.result() == 42
    # Test that the asynchronous future is completed even if the
    # concurrent future is already completed
    async_future_1 = Future()
    async_future_1.set_result(None)
    conc_future_1 = futures.Future()
    conc_future_1.set_result(None)
    chain_future(conc_future_1, async_future_1)
    assert async_future_1

# Generated at 2022-06-26 07:51:01.194953
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    assert f.cancelled() == False
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.cancelled() == False
    assert isinstance(f.exception(), ValueError)
    f = Future()
    f.cancel()
    assert f.cancelled() == True
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.cancelled() == True


# Generated at 2022-06-26 07:51:08.393680
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.httputil import HTTPServerRequest
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPFile
    from tornado.httputil import HTTPFileValueError
    from tornado.httputil import _MAX_HEADERS
    from tornado.httputil import _HeaderTuple

    assert isinstance(callable_0, Callable)

# Generated at 2022-06-26 07:51:11.736493
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()  # type: Future[int]
    b = Future()  # type: Future[int]

    assert not a.done()
    assert not b.done()

    chain_future(a, b)

    assert a.done()
    assert b.done()



# Generated at 2022-06-26 07:51:15.763975
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    a = Future()
    if a.cancelled():
        future_set_result_unless_cancelled(a, 42)


# Generated at 2022-06-26 07:51:25.591924
# Unit test for function chain_future
def test_chain_future():
    # Generate a new future
    future_0 = Future()
    # Generate a new future
    future_1 = Future()
    # Future_0 and future_1 are chained
    chain_future(future_0,future_1)
    # Check if future_1 attributes are equal to future_0 attributes
    assert(future_0.done() == future_1.done())
    assert(future_0.cancelled() == future_1.cancelled())
    assert(future_0.exception() == future_1.exception())
    assert(future_0.result() == future_1.result())


# Generated at 2022-06-26 07:51:35.093691
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    exc = Exception("Test Exception")
    future_set_exception_unless_cancelled(test_future, exc)
    assert test_future.cancelled() == False
    assert test_future.exception() == exc

    test_future.cancel()
    future_set_exception_unless_cancelled(test_future, exc)
    assert test_future.cancelled() == True

# Generated at 2022-06-26 07:51:44.164309
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_1.set_result(37)
    future_2 = Future()
    chain_future(future_1, future_2)
    assert future_2.result() == 37
    future_1 = Future()
    future_1.set_exception(ValueError())
    future_2 = Future()
    chain_future(future_1, future_2)
    try:
        future_2.result()
        assert False
    except ValueError:
        pass

    future_1 = Future()
    future_2 = Future()
    future_2.set_result(42)
    chain_future(future_1, future_2)
    assert future_2.result() == 42



# Generated at 2022-06-26 07:51:48.727683
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    run_on_executor(args=1, kwargs=2)

    def copy(future):
        # type: (Future) -> None
        assert future is not None

    chain_future(Future(), Future())



# Generated at 2022-06-26 07:51:57.281608
# Unit test for function chain_future
def test_chain_future():
    class Dummy(object):
        pass
    b = Dummy()
    b.callback = None
    def callback(self):
        pass
    def callback2(self):
        pass
    a = Future()

    def copy(future):
        assert future is a
        if b.done():
            return
        if hasattr(a, "exc_info") and a.exc_info() is not None:  # type: ignore
            future_set_exc_info(b, a.exc_info())  # type: ignore
        elif a.exception() is not None:
            b.set_exception(a.exception())
        else:
            b.set_result(a.result())

    def copy2(future):
        assert future is a

    a.add_done_callback(copy)

# Generated at 2022-06-26 07:52:04.139844
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    class Tester:
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def func(self, a: int) -> int:
            return a

    tester = Tester(executor=dummy_executor)
    future = tester.func(1)
    assert future.result() == 1


# Generated at 2022-06-26 07:52:28.181887
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # testing with a futures.Future
    future = futures.Future()
    exc = Exception()

    future_set_exception_unless_cancelled(future, exc)

    assert future.exception() is exc

    future = futures.Future()
    exc = Exception()

    future.cancel()
    try:
        future_set_exception_unless_cancelled(future, exc)
    except asyncio.InvalidStateError:
        pass

    assert future.exception() is None

    # testing with an asyncio.Future
    future = Future()
    exc = Exception()

    future_set_exception_unless_cancelled(future, exc)

    assert future.exception() is exc

    future = Future()
    exc = Exception()

    future.cancel()

# Generated at 2022-06-26 07:52:30.928659
# Unit test for function chain_future
def test_chain_future():
    future_add_done_callback(Future(), lambda future: None)
    chain_future(Future(), Future())


# Generated at 2022-06-26 07:52:34.512720
# Unit test for function chain_future
def test_chain_future():
    pass
#     future_1 = Future()
#     future_2 = Future()
#     chain_future(future_1, future_2)



# Generated at 2022-06-26 07:52:36.497540
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception)



# Generated at 2022-06-26 07:52:39.881010
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = BaseException()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-26 07:52:40.922265
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit()


# Generated at 2022-06-26 07:52:46.439587
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    def success_callback(future):
        # type: (Future[int]) -> None
        future.result()

    def error_callback(future):
        # type: (Future[int]) -> None
        future.exception()

    def callback_exception_callback(future):
        # type: (Future[int]) -> None
        try:
            raise TypeError
        except TypeError:
            future_set_exc_info(future, sys.exc_info())

    class TestException(Exception):
        pass

    def set_exception_callback(future):
        # type: (Future[int]) -> None
        future.set_exception(TestException())


# Generated at 2022-06-26 07:52:52.118374
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Set up future and value
    future = Future()
    value = "value"

    # Set the result
    future_set_result_unless_cancelled(future, value)

    # Check that the result is indeed set
    assert future.result() == "value"

    # Cancel the future
    future.cancel()

    # Check that the result is unchanged
    assert future.result() == "value"



# Generated at 2022-06-26 07:52:56.941159
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = Future()
    f1.set_exception(Exception('test'))
    future_set_exception_unless_cancelled(f1, Exception('test2'))
    assert f1.exception() is not None

    f2 = Future()
    future_set_exception_unless_cancelled(f2, Exception('test3'))
    assert f2.exception() is not None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 07:53:01.028248
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f.set_result('main')
    chain_future(f, f)
    print(f.result())


# Generated at 2022-06-26 07:53:29.524167
# Unit test for function chain_future
def test_chain_future():
    @asyncio.coroutine
    def coro_0() -> None:
        pass
    coro_0()
    coro_1 = coro_0()


# Generated at 2022-06-26 07:53:38.606841
# Unit test for function chain_future
def test_chain_future():
    from concurrent import futures
    from tornado.ioloop import IOLoop
    import tornado.testing
    import tornado.gen

    async def test_chain(result: Any) -> None:
        f1 = Future()  # type: Future
        f2 = Future()  # type: Future
        chain_future(f1, f2)
        f1.set_result(result)
        assert (await f2) == result

        c1 = futures.Future()
        c2 = futures.Future()
        IOLoop.current().add_future(c1, lambda c1_: chain_future(c1_, c2))
        c1.set_result(result)
        assert c2.result() == result

    IOLoop.current().run_sync(lambda: test_chain("foo"))

# Generated at 2022-06-26 07:53:39.723497
# Unit test for function run_on_executor
def test_run_on_executor():
    pass

# Generated at 2022-06-26 07:53:51.189331
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = Future()
    test_result = 10
    test_exc = Exception("test")
    future_set_result_unless_cancelled(test_future, test_result)
    assert test_future.result() == test_result
    test_future = Future()
    test_future.cancel()
    future_set_result_unless_cancelled(test_future, test_result)
    assert test_future.cancelled()
    assert not test_future.done()
    try:
        test_future.result()
    except:
        assert test_future.cancelled()
    test_future = Future()
    test_future.cancel()
    future_set_exc_info(test_future, (Exception, test_exc, None))
    assert test_future.cancelled()
   

# Generated at 2022-06-26 07:54:02.779763
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is not None

    exc = Error()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is not None

    exc = "Error"
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is not None

    exc = (Exception, Error())
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is not None

    exc = (Exception(), Error())
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is not None


# Generated at 2022-06-26 07:54:05.604219
# Unit test for function run_on_executor
def test_run_on_executor():
    f = Future()
    f.set_result(1)
    callable_0 = run_on_executor()
    callable_0()

# Generated at 2022-06-26 07:54:10.465922
# Unit test for function chain_future
def test_chain_future():
    async_future = Future()  # type: Future[_T]
    def sync_fn():
        return "ok"
    conc_future = dummy_executor.submit(sync_fn)
    chain_future(conc_future, async_future)

# Generated at 2022-06-26 07:54:26.600572
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.web import RequestHandler
    import time

    class SomeHandler(RequestHandler):
        @run_on_executor
        def foo(self):
            return 20

    def wrapper(future: Future) -> None:
        future.set_result(10)

    async_future = Future()  # type: Future
    wrapper(async_future)
    assert async_future.result() == 10

    executor = futures.ThreadPoolExecutor(max_workers=2)
    conc_future = executor.submit(wrapper, None)
    chain_future(conc_future, async_future)
    assert async_future.result() == 10

    # case 2
    ioloop = IOLoop.current()

# Generated at 2022-06-26 07:54:32.706869
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    assert future_1 is not None
    assert future_2 is not None
    future_1.set_result(2)
    assert future_2.result() == 2


# Generated at 2022-06-26 07:54:48.662172
# Unit test for function chain_future
def test_chain_future():
    # Type of future a
    a: 'Future [_T]' = Future()
    # Type of future b
    b: 'Future [_T]' = Future()
    # Chain future a to future b
    chain_future(a, b)
    # b should equals to a
    assert b == a
    # The result should be the same
    assert b.result() == a.result()
    # The exception should be the same
    assert b.exception() == a.exception()
    # The result of future_set_result_unless_cancelled should be a
    assert future_set_result_unless_cancelled(a, "abc") == a
    # The result of future_set_exc_info should be a
    future_set_exc_info(a, (TypeError, TypeError("TypeError"), None))


# Generated at 2022-06-26 07:56:40.739155
# Unit test for function chain_future
def test_chain_future():
    def wrap_future(fn: Callable) -> Future:
        f = asyncio.Future()
        f.set_result(fn())
        return f

    def wrap_result(x: Any) -> Any:
        return x

    @gen.coroutine
    def test_1() -> None:
        f1 = wrap_future(lambda: 1)
        f2 = wrap_future(lambda: 2)
        f3 = wrap_future(lambda: 3)
        f4 = wrap_future(lambda: 4)
        chain_future(f1, f2)
        chain_future(f2, f3)
        chain_future(f3, f4)
        assert [f.result() for f in (f1, f2, f3, f4)] == [1, 1, 1, 1]
        f = wrap

# Generated at 2022-06-26 07:56:47.313089
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        assert False

    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.add_done_callback(callback)
    a.set_result(None)
    b.set_result(None)
    b.set_exception(None)
    a.cancel()
    b.cancel()
    # asyncio.InvalidStateError: set_exception() called while another exception was already set
    # b.set_exception(Exception())
    a.cancel()
    b.set_exception(Exception())
    a.cancel()
    b.add_done_callback(callback)
    b.cancel()
    b.set_result(None)


# Generated at 2022-06-26 07:56:51.517538
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    print(test_future_set_result_unless_cancelled.__doc__)
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, true)
    print(future.result())


# Generated at 2022-06-26 07:56:57.177086
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    f = asyncio.Future()
    fut1 = asyncio.Future()
    chain_future(f, fut1)
    assert fut1.done()
    assert fut1.cancelled()
    fut2 = asyncio.Future()
    chain_future(f, fut2)
    assert fut2.done()
    assert fut2.cancelled()



# Generated at 2022-06-26 07:57:04.531724
# Unit test for function chain_future
def test_chain_future():
    def future_chain_callback_0(future_0):
        future_0.set_result(None)
        return

    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)
    future_0.set_result(None)
    assert future_1.done()



# Generated at 2022-06-26 07:57:14.804008
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def foo(self: Any, bar: Any) -> Future:
        return bar
    if True:
        IOLoop = None
    else:
        class IOLoop:

            def current(cls) -> IOLoop:
                return IOLoop()

            def add_future(self, future: "Future[_T]", callback: Callable[..., None]) -> None:
                callback(future)

        class Future(object):
            pass
    if True:
        class DummyExecutor:
            def submit(
                self,
                fn: Callable[..., _T],
                *args: Any,
                **kwargs: Any,
            ) -> "Future[_T]":
                future = Future()  # type: Future[_T]

# Generated at 2022-06-26 07:57:19.047382
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """
    # Case 1:
    future = Future()
    future.cancel()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    """

# Generated at 2022-06-26 07:57:26.296685
# Unit test for function run_on_executor
def test_run_on_executor():
    # Test passing an argument
    @run_on_executor
    def test_function():
        pass

    # Test specifying the executor
    @run_on_executor(executor="test")
    def test_function_2():
        pass

    # Test passing a callable that is not a function
    @run_on_executor
    def test_function_3(self, x: int = 5) -> int:
        return 5

    # Test passing a function that is not a callable
    @run_on_executor
    def test_function_4(x: int) -> int:
        return x * 2



# Generated at 2022-06-26 07:57:30.665822
# Unit test for function chain_future
def test_chain_future():
    test_future = asyncio.Future()

    def test_func():
        test_future.set_exception(Exception("test exception"))

    test_func()
    chain_future(test_future, test_future)
    assert test_future.exception() is not None



# Generated at 2022-06-26 07:57:32.686263
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()  # type: Future
    future_set_exception_unless_cancelled(future_0, Exception())

