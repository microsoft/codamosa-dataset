

# Generated at 2022-06-26 07:48:59.883075
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio

    async def test_run_on_executor_0(executor: Any, func: Any, obj: Any) -> Any:
        temp = (executor, func, obj)
        return temp

    def test_run_on_executor_1(obj: Any, value: Any) -> Any:
        obj.value = value

    def test_run_on_executor_2(obj: Any, exc_info: Any) -> Any:
        obj.exc_info = exc_info

    def test_run_on_executor_3(obj: Any) -> Any:
        obj.called = True

    async def test_run_on_executor_4() -> Any:
        loop = asyncio.get_event_loop()

# Generated at 2022-06-26 07:49:05.340283
# Unit test for function chain_future
def test_chain_future():
    async def inner():
        future_one = Future()
        future_two = Future()
        chain_future(future_one, future_two)
        future_one.set_result(None)
        await future_two

    return inner()


# Generated at 2022-06-26 07:49:08.275598
# Unit test for function chain_future
def test_chain_future():
    a = Future()  # type: Future
    b = Future()  # type: Future

    chain_future(a, b)
    a.set_result(1)


# Generated at 2022-06-26 07:49:10.708809
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    # This raises an exception, but this function is an exception
    # handler so the return value is ignored
    future_set_exception_unless_cancelled(future, return_value_ignored_error_0)


# Generated at 2022-06-26 07:49:18.590501
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import subprocess
    import io
    import sys
    import unittest
    import subprocess
    import io
    import sys
    f1 = Future()
    f2 = Future()
    f1.set_result(3)
    chain_future(f1, f2)
    print(f2.result())


if __name__ == "__main__":
    test_case_0()
    test_chain_future()

# Generated at 2022-06-26 07:49:22.036279
# Unit test for function chain_future
def test_chain_future():
    # Arrange
    a = Future()
    b = Future()
    # Act
    chain_future(a, b)
    # Assert
    pass


# Generated at 2022-06-26 07:49:26.479166
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def test_0():
        future = Future()
        future_set_result_unless_cancelled(future, 10)
        return (future.result()) == 10
    if not test_0():
        raise AssertionError()



# Generated at 2022-06-26 07:49:28.738593
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "value")
    assert future.result() == "value"



# Generated at 2022-06-26 07:49:41.600015
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def run_on_executor_0(self):
            return_value_ignored_error_0

    foo_0 = Foo(dummy_executor)
    future_0 = foo_0.run_on_executor_0()
    return_value_0 = future_0.result()
    return_value_ignored_error_0
    return (foo_0, future_0, return_value_0)


if __name__ == "__main__":
    import logging

    logging.getLogger("").setLevel(logging.DEBUG)
    test_case_0()
    test_run_on_executor()

# Generated at 2022-06-26 07:49:46.814813
# Unit test for function chain_future
def test_chain_future():
    aFuture = Future()

    def foo():
        return 1

    assert not aFuture.done()
    chain_future(foo(), aFuture)
    assert not aFuture.done()



# Generated at 2022-06-26 07:49:57.188957
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    assert a is not b
    assert not a.done()
    assert not b.done()
    chain_future(a, b)
    a.set_result(0)
    assert a.done()
    assert b.done()
    assert b.result() == 0

if __name__ == "__main__":
    import doctest
    import unittest

    unittest.main(module=__name__, defaultTest='doctest.testmod')

# Generated at 2022-06-26 07:49:59.767562
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(3)
    assert b.done()
    assert b.result() == 3


# Generated at 2022-06-26 07:50:03.224396
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert(b.result() == 42)


# Generated at 2022-06-26 07:50:09.265527
# Unit test for function chain_future
def test_chain_future():
    target1 = Future()
    target2 = Future()
    assert target1.done() == False
    assert target2.done() == False
    chain_future(target1, target2)
    target1.set_result(1)
    assert target1.done() == True
    assert target2.done() == True


# Generated at 2022-06-26 07:50:13.088614
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    a = Future()
    a.cancel()

    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        exc_info = sys.exc_info()

    try:
        future_set_exc_info(a, exc_info)
    except InvalidStateError:
        pass  # asyncio.Future
    except Exception:
        pass

# Generated at 2022-06-26 07:50:18.944174
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future_a = Future()
    future_b = Future()

    chain_future(future_a, future_b)

    assert not future_a.done()
    assert not future_b.done()

    future_a.set_result(None)

    assert future_a.done()
    assert future_b.done()



# Generated at 2022-06-26 07:50:24.952482
# Unit test for function chain_future
def test_chain_future():
    async_future = Future()  # type: Future[_T]
    conc_future = futures.Future()  # type: futures.Future[_T]

    chain_future(conc_future, async_future)

    conc_future.set_result(0)

    assert async_future.result() == 0
    assert conc_future.result() == 0


# Generated at 2022-06-26 07:50:32.895279
# Unit test for function chain_future
def test_chain_future():
    # Scenario 1
    #   a and b are both Future, call result() on them
    a = Future()
    b = Future()
    a.set_result("a_result")
    assert b.result() == "a_result"

    # Scenario 2
    #   a and b are both Future, call exception() on them
    a = Future()
    b = Future()
    a.set_exception(RuntimeError("a_exception"))
    try:
        b.result()
    except RuntimeError as e:
        assert "a_exception" in str(e)



# Generated at 2022-06-26 07:50:43.033443
# Unit test for function chain_future
def test_chain_future():
    def test_func_1(arg: int) -> int:
        return arg
    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    chain_future(b, c)
    a.set_result(5)
    assert(c.result() == 5)
    d = Future()
    chain_future(b, d)
    assert(d.result() == 5)
    b.set_exception(ValueError(1))
    with pytest.raises(ValueError):
        c.result()
    with pytest.raises(ValueError):
        d.result()



# Generated at 2022-06-26 07:50:56.123305
# Unit test for function chain_future
def test_chain_future():
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    # Now that we have setup the chaining, test out the various methods
    # of completing a Future.
    future_a.set_result('future_a')
    assert future_b.result() == 'future_a'
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    future_a.set_exception(Exception())
    try:
        future_b.result()
        assert False
    except Exception:
        pass
    future_a = Future()
    future_b = Future()
    chain_future(future_a, future_b)
    future_a.cancel()
    assert future_b.cancelled

# Generated at 2022-06-26 07:51:11.442234
# Unit test for function chain_future
def test_chain_future():
    fut = asyncio.Future()
    fut2 = asyncio.Future()
    chain_future(fut, fut2)
    fut.set_result(1)
    assert fut2.done() and fut2.result() == 1



# Generated at 2022-06-26 07:51:18.535061
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f3 = Future()
    chain_future(f2, f3)
    f1.set_exception(ZeroDivisionError())
    try:
        f3.result()
    except ZeroDivisionError:
        pass
    else:
        raise RuntimeError("ValueError not propagated")



# Generated at 2022-06-26 07:51:20.921518
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future_set_exception_unless_cancelled(
        Future(), ReturnValueIgnoredError(),
    )

# Generated at 2022-06-26 07:51:22.775748
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)


# Generated at 2022-06-26 07:51:30.218108
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.gen
    import tornado.testing

    def test_method(self, arg):
        return arg.upper()

    class TestHandler(object):
        # type: ignore
        executor = dummy_executor

    handler = TestHandler()
    decorated = run_on_executor(test_method)
    future = decorated(handler, "message")
    tornado.testing.gen_test(handler.executor.submit)(future)
    assert tornado.gen.convert_yielded(future) == "MESSAGE"

    @run_on_executor(executor="_thread_pool")
    def test_method(self, value):
        return value ** 2

    class TestHandler(object):
        _thread_pool = dummy_executor

    handler = TestHandler()
    decorated = test_method

# Generated at 2022-06-26 07:51:37.882323
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a,b)
    a.set_result(1)
    assert b.result() == 1
    c = Future()
    chain_future(c,b)
    assert b.result() == 1
    d = Future()
    e = Future()
    chain_future(d,e)
    assert d.done() == 0
    assert e.done() == 0
    d.set_result(2)
    assert e.result() == 2

# Generated at 2022-06-26 07:51:40.605073
# Unit test for function run_on_executor
def test_run_on_executor():
    async_future = Future()
    conc_future = dummy_executor.submit(lambda a, b: a + b, 1, 2)
    chain_future(conc_future, async_future)

# Generated at 2022-06-26 07:51:54.477802
# Unit test for function chain_future
def test_chain_future():
    def _fail():
        raise Exception("should not be called")

    def _fail2():
        raise Exception("should not be called 2")

    a = Future()
    b = Future()
    c = Future()
    d = Future()
    for f in [a, b, c, d]:
        f.set_result(None)

    # d should be overwritten by a.
    # c should be overwritten by b.
    # c should not be overwritten by a (because its result has already been set).
    # b should not be overwritten by a (because its result has already been set).
    chain_future(a, d)
    chain_future(b, c)
    chain_future(a, c)
    chain_future(a, b)

    # Now, coverage check
    assert a.done()
   

# Generated at 2022-06-26 07:52:08.387677
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Test tornado.util.DummyExecutor.submit when exception occurs and exc_info is not None
    dummy_executor = DummyExecutor()

    def fn():
        raise ValueError('14')

    future = dummy_executor.submit(fn)
    assert isinstance(future, Future)
    assert future.done()
    assert future.exception() is not None
    assert type(future.exception()) == ValueError

    # Test tornado.util.DummyExecutor.submit when exception does not occur

    def fn_1() -> str:
        return '1'

    future = dummy_executor.submit(fn_1)
    assert isinstance(future, Future)
    assert future.done()
    assert future.result() == '1'

    # Test tornado.util.DummyExecutor.submit when future is cancelled


# Generated at 2022-06-26 07:52:15.038262
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        return future.result()

    async_future = Future()
    conc_future = Future()

    chain_future(async_future, conc_future)

    async_future.set_result(42)

    assert conc_future.result() == 42



# Generated at 2022-06-26 07:52:23.607587
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_set_exception_unless_cancelled(None, return_value_ignored_error_0)

# Generated at 2022-06-26 07:52:27.304121
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_obj = Future()
    future_obj.set_result(1)
    assert future_obj.done()
    future_set_result_unless_cancelled(future_obj, 2)
    assert future_obj.result() == 1



# Generated at 2022-06-26 07:52:32.889494
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    future1.set_result(42)
    chain_future(future1, future2)
    assert future2.result() == 42


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-26 07:52:40.474895
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    d = DummyExecutor()
    c = Coroutine(lambda: 1)
    assert c is not None
    f = d.submit(c)
    assert f is not None
    try:
        assert f.result() is not None
    except ReturnValueIgnoredError as exc:
        assert exc is return_value_ignored_error_0
    except Exception as exc:
        assert False, 'unexpected exception %r' % (exc,)



# Generated at 2022-06-26 07:52:43.180159
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(None)
    assert b.done()


# Generated at 2022-06-26 07:52:50.941864
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = None
    try:
        raise Exception('My exception')
    except Exception as e:
        exception = e
    future_set_exception_unless_cancelled(future, exception)
    assert future.done() == False and future.cancelled() == False
    future.cancel()
    assert future.done() == False and future.cancelled() == True
    future_set_exception_unless_cancelled(future, exception)
    assert future.done() == False and future.cancelled() == True


# Generated at 2022-06-26 07:52:55.232737
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    def fn(self, *args, **kwargs) -> Future:
        async_future = Future()  # type: Future
        conc_future = executor.submit(fn, self, *args, **kwargs)
        chain_future(conc_future, async_future)
        return async_future

    fn(1)



# Generated at 2022-06-26 07:53:08.106387
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_0.done()
    future_1.done()
    future_0.set_result(0)
    future_0.set_result(1)
    future_0.set_exception(Exception())
    future_0.set_exception(ReturnValueIgnoredError())
    future_1.set_result(0)
    future_1.set_result(1)
    future_1.set_exception(Exception())
    future_1.set_exception(ReturnValueIgnoredError())
    future_0.exception()
    future_1.exception()
    future_1.cancelled()
    future_1.cancelled()
    future_0.result()
    future_1.result()

# Generated at 2022-06-26 07:53:22.528148
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    f1 = asyncio.Future()
    f2 = asyncio.Future()

    # f2 should be equal to f1 after chain
    chain_future(f1, f2)

    # f2 should be equal to f1 after set_exception
    f1.set_exception(Exception())
    loop.run_until_complete(f2)

    assert f2.exception()

    # f2 should be equal to f1 after set_result
    f1 = asyncio.Future()
    f2 = asyncio.Future()
    chain_future(f1, f2)
    f1.set_result(None)
    loop.run_until_complete(f2)

    assert f2.result() == f1.result()



# Generated at 2022-06-26 07:53:31.504422
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1
    # When f2 has already been set,
    # set_result will not override the result.
    f1.set_result(2)
    assert f2.result() == 1
    f1.set_exception(Exception())
    assert f2.exception is Exception
    f1.set_exception(Exception())
    assert f2.exception is Exception



# Generated at 2022-06-26 07:53:41.375004
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    expected = 1
    dummy_executor_submit_executor_0 = dummy_executor.submit(lambda : 1)
    assert dummy_executor_submit_executor_0.result() == expected

# Generated at 2022-06-26 07:53:49.140390
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future_2 = Future()
    future_2_chain = Future()

    chain_future(future, future_2)
    future_2.set_result(1)

    assert future_2.result() == 1
    assert future_2.done() is True

    chain_future(future, future_2_chain)
    future.set_result(2)

    assert future_2_chain.result() == 2
    assert future_2_chain.done() is True



# Generated at 2022-06-26 07:53:59.488055
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future_set_result_unless_cancelled_future = futures.Future()  # type: futures.Future[int]
    # future_set_result_unless_cancelled_exc_info = ()  # type: Tuple[type, BaseException, types.TracebackType]
    # future_set_result_unless_cancelled_exc = None  # type: Optional[BaseException]

    result = 1
    future_set_result_unless_cancelled(future_set_result_unless_cancelled_future, result)
    assert future_set_result_unless_cancelled_future.result() == result

# Generated at 2022-06-26 07:54:06.890902
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test
    from tornado.gen import coroutine
    from concurrent.futures import Future

    @coroutine
    def coro1():
        yield Future()

    @coroutine
    def coro2():
        yield Future()

    class FutureContextManager(Future):
        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            return False

    @gen_test
    def test_future():
        r = yield coro1()
        assert r is None

    @gen_test
    def test_context_manager():
        async with FutureContextManager() as f:
            assert f is None

    @gen_test
    def test_chain_future():
        f1 = Future()
        f2 = Future()

# Generated at 2022-06-26 07:54:13.808447
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)

    future_0.set_result(None)
    assert future_1.done()



# Generated at 2022-06-26 07:54:19.485302
# Unit test for function chain_future
def test_chain_future():
    async_future = asyncio.Future()
    futures.Future()
    futures.Future().result() == 42
    futures.Future().exception()
    futures.Future().cancelled()
    futures.Future().add_done_callback(lambda future: "")
    futures.Future().remove_done_callback(lambda future: "")
    futures.Future().set_result(42)
    futures.Future().set_exception(Exception())
    futures.Future().result() == 42


test_chain_future()

# Generated at 2022-06-26 07:54:20.108714
# Unit test for function chain_future
def test_chain_future():
    pass

# Generated at 2022-06-26 07:54:31.869137
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import concurrent.futures
    future = concurrent.futures.Future()
    future_set_result_unless_cancelled(future, 1)
    if future.result() != 1:
        raise Exception(
            "future.result() != 1, future.result() = {}".format(
                future.result()
            )
        )
    future = concurrent.futures.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 2)
    if future.result() != 1:
        raise Exception(
            "future.result() != 1, future.result() = {}".format(
                future.result()
            )
        )



# Generated at 2022-06-26 07:54:37.573241
# Unit test for function chain_future
def test_chain_future():
    result = Future()
    result.set_result("This is good")
    assert result.done()
    assert result.result() == "This is good"
    result1 = Future()
    chain_future(result, result1)
    assert result1.result() == "This is good"


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-26 07:54:49.100433
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.ioloop import IOLoop
    future = asyncio.Future()
    IOLoop.current().add_callback(
        lambda: future_set_result_unless_cancelled(future, 42)
    )
    assert future.result() == 42
    future = asyncio.Future()
    IOLoop.current().add_callback(
        lambda: future_set_result_unless_cancelled(future, None)
    )
    assert future.result() is None
    future = asyncio.Future()
    IOLoop.current().add_callback(future.cancel)
    IOLoop.current().add_callback(
        lambda: future_set_result_unless_cancelled(future, 42)
    )
    # Future should not have been set
    assert future.cancelled()


# Unit

# Generated at 2022-06-26 07:55:00.946447
# Unit test for function chain_future
def test_chain_future():
    def test_future(self: object, result: int) -> int:
        import time
        time.sleep(10)
        return result

    test_future_object = test_future(object, 1)
    test_future_arg = Future()
    chain_future(test_future_object, test_future_arg)
    print(test_future_arg)



# Generated at 2022-06-26 07:55:12.061483
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    test_exception = Exception("Some error")

    future_set_exception_unless_cancelled(test_future, test_exception)
    assert test_future.exception() == test_exception

    test_future = Future()
    test_future.set_result("Success")
    test_exception = Exception("Some error")

    future_set_exception_unless_cancelled(test_future, test_exception)
    assert test_future.result() == "Success"

    test_future = Future()
    test_future.cancel()
    test_exception = Exception("Some error")

    future_set_exception_unless_cancelled(test_future, test_exception)
    assert test_future.exception() == test_exception



# Generated at 2022-06-26 07:55:17.641360
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    try:
        int("not a number")
    except:
        pass
    future_set_exception_unless_cancelled(future_0, sys.exc_info()[1])
    print(future_0.exception())


# Generated at 2022-06-26 07:55:22.646374
# Unit test for function chain_future
def test_chain_future():
    def test_method():
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        chain_future(future, future)

    test_case_0()
    test_method()



# Generated at 2022-06-26 07:55:35.023416
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future.set_result(1)
    future2 = Future()
    chain_future(future, future2)
    assert future2.result() == 1
    # test when future2 has been cancelled
    future = Future()
    future.set_result(1)
    future2 = Future()
    future2.cancel()
    chain_future(future, future2)
    # test when future.set_exception(e) called
    future = Future()
    future2 = Future()
    chain_future(future, future2)
    e = RuntimeError()
    future.set_exception(e)
    assert future2.exception() is e
    # test when future2 has been done
    future = Future()
    future2 = Future()
    future2.set_result(None)
   

# Generated at 2022-06-26 07:55:38.912939
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    called = [False]

    def check_called():
        assert called[0]

    def test():
        called[0] = True

    future = dummy_executor.submit(test)
    future.add_done_callback(check_called)


# Generated at 2022-06-26 07:55:43.212545
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(fn=None)


# Generated at 2022-06-26 07:55:46.330362
# Unit test for function chain_future
def test_chain_future():
    future_a = Future()
    future = Future()
    chain_future(future_a, future)
    future.result()



# Generated at 2022-06-26 07:55:53.942967
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test with valid arguments
    f0 = Future()
    future_set_result_unless_cancelled(f0, 42)

    f1 = Future()
    future_set_result_unless_cancelled(f1, "hello")

    f2 = Future()
    future_set_result_unless_cancelled(f2, [1, 2, 3])



# Generated at 2022-06-26 07:56:01.524266
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)
    assert future_2.done() is False
    future_1.set_result(True)
    assert future_2.done()
    assert future_2.result() is True


if __name__ == "__main__":
    import tornado
    import tornado.testing
    import tornado.platform.asyncio

    tornado.testing.AsyncTestCase().run()

# Generated at 2022-06-26 07:56:18.998249
# Unit test for function chain_future
def test_chain_future():
    # The callables defined below must be named differently than
    # one another, or else the test runners will assume they are the
    # same test and only run the first one.
    callable_0 = chain_future
    callable_1 = chain_future
    callable_2 = chain_future


# Generated at 2022-06-26 07:56:27.662170
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    fut = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(fut, exc)
    assert fut.exception() == exc
    fut.cancel()
    future_set_exception_unless_cancelled(fut, exc)



# Generated at 2022-06-26 07:56:33.931177
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    class DummyClass:
        @run_on_executor()
        def some_method(self, x):
            return x
    
    async def test_wrapper():
        instance = DummyClass()
        future_0 = instance.some_method(2)
        future_1 = instance.some_method(3)
        future_2 = instance.some_method(4)
        future_3 = instance.some_method(5)
        future_4 = instance.some_method(6)
        future_5 = instance.some_method(7)
        future_6 = instance.some_method(8)
        future_7 = instance.some_method(9)
        future_8 = instance.some_method(10)
        future_9 = instance.some_method(11)

# Generated at 2022-06-26 07:56:44.694233
# Unit test for function run_on_executor
def test_run_on_executor():
    async_future = Future()  # type: Future
    test_class_0 = TestClass(
        exec_func = [
            lambda x: x * 2,
            lambda x: x * 3,
        ],
        executor = dummy_executor)
    callable_result_0 = run_on_executor()(test_class_0.exec_func[0])
    callable_result_1 = run_on_executor()(test_class_0.exec_func[1])
    callable_result_0(
        test_class_0,
        test_class_0.result_callback_0,
        async_future)
    callable_result_1(
        test_class_0,
        test_class_0.result_callback_1,
        async_future)
    assert async_future

# Generated at 2022-06-26 07:56:47.876672
# Unit test for function chain_future
def test_chain_future():
    future_0: Future[Any]
    future_1: Future[Any]
    from tornado.ioloop import IOLoop

    # __main__
    IOLoop.current().stop()


# Generated at 2022-06-26 07:56:52.246703
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f1.set_result(1)
    assert f2.result() == 1, "f2 result is wrong"


# Generated at 2022-06-26 07:56:56.963720
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(ValueError)
    assert b.exception() is not None
    chain_future(a, b)
    assert b.exception() is not None
    a.cancel()
    chain_future(a, b)
    assert b.exception() is not None

# Generated at 2022-06-26 07:57:04.494329
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1



# Generated at 2022-06-26 07:57:10.005835
# Unit test for function chain_future
def test_chain_future():
    def callback_0(future_0: Future) -> None:
        ...  # type: ignore
        future_0.result()

    future_0 = Future()
    chain_future(future_0, future_0)
    chain_future(future_0, future_0)
    future_add_done_callback(future_0, callback_0)
    chain_future(future_0, future_0)
    chain_future(future_0, future_0)



# Generated at 2022-06-26 07:57:15.187755
# Unit test for function run_on_executor
def test_run_on_executor():
    """
    testcase_0: test if the arguments are in right format

    :return: return codes: 0 - OK; 1 - ERROR
    """
    report = True
    try:
        test_case_0()
    except:
        report = False
    if report:
        return 0
    else:
        return 1

# Generated at 2022-06-26 07:57:41.586594
# Unit test for function chain_future
def test_chain_future():
    futureA = Future()
    futureB = Future()
    chain_future(futureA, futureB)



# Generated at 2022-06-26 07:57:48.878022
# Unit test for function run_on_executor
def test_run_on_executor():  # noqa: F883
    import copyreg  # type: ignore
    import pickle  # type: ignore

    f = test_run_on_executor
    f_wrapped = run_on_executor(f)
    assert f_wrapped.__name__ == f.__name__

    class MyType(object):
        executor = dummy_executor

        @run_on_executor
        def a(self, x):
            return x + 1

        @run_on_executor(executor="b")
        def b(self, x):
            return x + 10

    obj = MyType()
    assert obj.a(20) == 21
    assert obj.b(20) == 30

    # Example of how to pickle a decorated method.

# Generated at 2022-06-26 07:57:54.620923
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def test_func_0():
        future = Future()
        with pytest.raises(asyncio.InvalidStateError):
            future_set_result_unless_cancelled(future, future)
        future_set_result_unless_cancelled(future, future)
        future_set_result_unless_cancelled(future, future)


# Generated at 2022-06-26 07:57:57.373385
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Fut.future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1


# Generated at 2022-06-26 07:58:07.201694
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.testing import AsyncTestCase
    from tornado.testing import gen_test


    class TestClass(AsyncTestCase):
        def test_1(self):
            future = self.create_future()
            yield future
            future2 = self.create_future()
            chain_future(future, future2)
            yield future2
            future.result()
            future2.result()

    def test_2():
        future = Future()
        future2 = Future()
        chain_future(future, future2)
        future.set_result(1)
        future2.result()



# Generated at 2022-06-26 07:58:07.798299
# Unit test for function run_on_executor
def test_run_on_executor():
    assert callable_0

# Generated at 2022-06-26 07:58:14.718271
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.concurrent import Future, run_on_executor, future_set_result_unless_cancelled
    AsyncIOMainLoop().install()
    executor = dummy_executor
    executoro = dummy_executor

    # test for AsyncIO.Future
    fut = Future()
    futo = Future()
    chain_future(fut, futo)
    assert not futo.done()
    future_set_result_unless_cancelled(fut, 1)
    assert futo.result() == 1

    # test for concurrent.futures.Future
    @run_on_executor(executor)
    def getnum():
        return 1
    fut = Future()
    futo = Future()
    chain_future

# Generated at 2022-06-26 07:58:24.682692
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    future_2 = Future()
    conc_future = futures.Future()
    chain_future(conc_future, future_0)
    chain_future(future_0, future_1)
    chain_future(future_1, future_2)
    chain_future(future_2, future_0)
    chain_future(future_0, future_0)
    assert future_0.done() == False
    future_1.set_result(None)
    assert future_0.done() == False
    future_2.set_result(None)
    assert future_1.done() == False
    future_0.set_exception(None)
    assert future_2.done() == False
    assert future_0.done() == False

# Generated at 2022-06-26 07:58:33.784548
# Unit test for function run_on_executor
def test_run_on_executor():
    # run_on_executor()

    # run_on_executor(fn: Callable) -> Callable
    callable_0 = run_on_executor()
    int_0 = callable_0()
    bool_0 = isinstance(int_0, int)
    bool_1 = True
    assert bool_0 == bool_1

    # run_on_executor(executor='_thread_pool')
    callable_1 = run_on_executor(executor='_thread_pool')
    int_1 = callable_1()
    bool_2 = isinstance(int_1, int)
    bool_3 = True
    assert bool_2 == bool_3



# Generated at 2022-06-26 07:58:35.238039
# Unit test for function chain_future
def test_chain_future():

    # Test for Future
    chain_future(Future(), Future())

