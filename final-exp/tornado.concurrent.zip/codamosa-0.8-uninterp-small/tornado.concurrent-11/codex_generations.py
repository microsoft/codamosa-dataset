

# Generated at 2022-06-26 07:48:54.312843
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test_dummyExecutor = DummyExecutor()
    test_fn = lambda: 0
    test_args = tuple()
    test_kwargs = dict()
    assert isinstance(test_dummyExecutor.submit(test_fn, *test_args, **test_kwargs), concurrent.futures.Future)


# Generated at 2022-06-26 07:49:01.947963
# Unit test for function chain_future
def test_chain_future():
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    assert not fut1.done()
    assert not fut2.done()
    fut1.set_result(1)
    assert fut1.done()
    assert fut2.done()
    assert fut2.result() == 1

    fut1 = Future()
    fut2 = Future()
    fut2.set_exception(Exception())
    assert not fut1.done()
    assert fut2.done()
    chain_future(fut1, fut2)
    assert fut1.done()

    fut1 = Future()
    fut2 = Future()
    fut2.cancel()
    assert not fut1.done()
    assert fut2.cancelled()
    fut1.set_result(1)
   

# Generated at 2022-06-26 07:49:09.668943
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async_future: Future
    # Verify that set_result throws when the Future is cancelled
    async_future = Future()
    try:
        async_future.cancel()
        future_set_result_unless_cancelled(async_future, None)
    except asyncio.InvalidStateError:
        pass
    else:
        assert False, "InvalidStateError not raised"



# Generated at 2022-06-26 07:49:17.235535
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def async_main():
        future1 = Future()
        future2 = Future()
        future3 = Future()
        future_set_exc_info(future1, (None, Exception("Test exception"), None))
        future_set_exception_unless_cancelled(future2, Exception("Test exception"))
        future_set_exception_unless_cancelled(future3, Exception("Test exception"))
        future3.cancel()
    asyncio.run(async_main())

# Generated at 2022-06-26 07:49:21.571000
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    err_future = Future()
    err_future.exception()
    err_future.traceback()
    err_future.exc_info()
    future_set_exc_info(err_future, None)



# Generated at 2022-06-26 07:49:26.573106
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = Future()
    test_future.set_result('Test_set_result_unless_cancelled')
    future_set_result_unless_cancelled(test_future, 'Test_set_result_unless_cancelled')


# Generated at 2022-06-26 07:49:38.400421
# Unit test for function chain_future
def test_chain_future():
    executor = ThreadPoolExecutor(max_workers=2)
    @run_on_executor(executor)
    def foo(x: int) -> int:
        assert 0 < x
        return 123
    future_0 = foo(1)
    assert is_future(future_0) == True # Should succeed
    future_0.add_done_callback(lambda x: x)
    f0_0 = future_0.result() == 123
    assert f0_0 == True # Should succeed
    tup0 = (1, 2, 3)
    f0_0 = future_add_done_callback(future_0, lambda a: a)
    assert is_future(future_0) == True # Should succeed
    future_0.add_done_callback(lambda x: x)
    f0_1 = future_

# Generated at 2022-06-26 07:49:48.381731
# Unit test for function chain_future
def test_chain_future():
    print(chain_future.__doc__)
    loop = asyncio.get_event_loop()
    future_0 = loop.run_until_complete(asyncio.Future())
    future_1 = run_on_executor()(lambda self, *args, **kwargs : future_0)(object(), None)
    future_2 = run_on_executor()(lambda self, *args, **kwargs : future_1)(object(), None)
    assert future_2.done() == False
    future_0.set_result(True)
    assert future_2.done() == True


# Generated at 2022-06-26 07:49:55.013878
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    future = Future()  # type: Future

    def async_callback(future):  # type: ignore
        result = future.result()
        future.cancel()

    future.add_done_callback(async_callback)
    exc = None
    try:
        raise Exception("Test")
    except Exception as e:
        exc = e

    try:
        future_set_exc_info(future, exc_info=(type(exc), exc, exc.__traceback__))
    except Exception as e:
        print(e)

# Generated at 2022-06-26 07:49:59.216282
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    future = asyncio.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-26 07:50:12.776508
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result("chain_future_test")
    assert future2.result() == "chain_future_test"

# Generated at 2022-06-26 07:50:15.809185
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = Future()
    test_value = 1
    future_set_result_unless_cancelled(test_future, test_value)
    assert test_future.result() == test_value


# Generated at 2022-06-26 07:50:24.192081
# Unit test for function chain_future
def test_chain_future():
    # Type warning
    chain_future("a", "b")

    test1 = Future()
    test2 = Future()

    chain_future(test1, test2)
    test1.set_result("test")
    assert test2.result() == "test"

    test3 = Future()
    test4 = Future()
    chain_future(test3, test4)
    test3.set_exception("test")
    assert test4.exception() == "test"



# Generated at 2022-06-26 07:50:30.322487
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_a = asyncio.Future()
    future_b = asyncio.Future()
    future_a.cancel()
    future_set_result_unless_cancelled(future_a, "a")
    future_set_result_unless_cancelled(future_b, "b")
    assert future_a.cancelled()
    assert future_b.result() == "b"


# Generated at 2022-06-26 07:50:40.838763
# Unit test for function run_on_executor
def test_run_on_executor():
    def caller():
        pass

    # Creates a Future object and returns it
    # Returns:
    #   Future:
    #     - A Future object returned by asyncio.Future.
    #     - Callback is a callable object
    #     - Result is set to None by default
    #     - Cancel is False by default
    # Error:
    #   TypeError, TypeError

    test_run_on_executor_0 = run_on_executor(caller)
    # test_run_on_executor_0 returns
    #   Caller -> Caller
    #   AttributeError
    #   TypeError
    # test_run_on_executor_0(None, None)
    #   ValueError
    return

# Generated at 2022-06-26 07:50:43.854013
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None

    future = Future()
    future_set_exception_unless_cancelled(future, Exception())



# Generated at 2022-06-26 07:50:46.515949
# Unit test for function chain_future
def test_chain_future():
    _f = futures.Future()
    _f1 = Future()
    chain_future(_f, _f1)



# Generated at 2022-06-26 07:50:51.128299
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = futures.Future()
    exc = RuntimeError('future failed')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc


# Generated at 2022-06-26 07:51:00.731002
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio

    async def test_case_0():
        future_0 = asyncio.Future()  # type: asyncio.Future
        future_1 = Future()  # type: Future
        chain_future(future_0, future_1)

    async def test_case_1():
        future_0 = Future()  # type: Future
        future_1 = Future()  # type: Future
        future_2 = Future()  # type: Future
        chain_future(future_0, future_1)
        chain_future(future_0, future_2)

    async def test_case_2():
        future_0 = concurrent.futures.Future()  # type: concurrent.futures.Future
        future_1 = Future()  # type: Future

# Generated at 2022-06-26 07:51:04.429453
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    assert not f2.done()
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.done()


# Generated at 2022-06-26 07:51:14.164355
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:51:19.917963
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(1)
    assert b.result() == 1
    a = Future()
    b = Future()
    a.set_result(1)
    chain_future(a, b)
    assert b.result() == 1

test_case_0()
test_chain_future()

# Generated at 2022-06-26 07:51:28.562822
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from asyncio import Future
    future = Future()
    value = 1

    def cancel():
        future.cancel()
        assert future.result() is None
        assert future.exception() is None
        assert future.cancelled() == True

    def set_result():
        future_set_result_unless_cancelled(future, value)
        assert future.result() == value
        assert future.exception() is None
        assert future.cancelled() == False

    def verify():
        assert future.result() == value
        assert future.exception() is None
        assert future.cancelled() == False

    future.add_done_callback(cancel)
    future.add_done_callback(set_result)
    future.add_done_callback(verify)
    future.set_result(value)

# Generated at 2022-06-26 07:51:29.379158
# Unit test for function chain_future
def test_chain_future():
    def inner():
        pass
    if chain_future(Future(), Future()):
        pass

# Generated at 2022-06-26 07:51:31.575564
# Unit test for function chain_future
def test_chain_future():

    future_a = Future()  # type: Future
    future_b = Future()  # type: Future

    chain_future(future_a, future_b)

    future_a.set_result(10)

    assert future_b.result() == 10



# Generated at 2022-06-26 07:51:37.395374
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Set the exception of a future that has been cancelled
    future_1 = Future() # type: Future[None]
    future_1.cancel()
    future_set_exception_unless_cancelled(future_1, Exception("1"))
    # Set the exception of a future that has not been cancelled
    future_2 = Future() # type: Future[None]
    future_set_exception_unless_cancelled(future_2, Exception("2"))
    # Get the results of the two futures
    assert future_1.exception() is None
    assert str(future_2.exception()) == "2"

# Generated at 2022-06-26 07:51:40.191081
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    f1.set_result("1")
    chain_future(f1, f2)
    assert f2.result() == "1"

# Generated at 2022-06-26 07:51:45.722027
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    future_set_result_unless_cancelled(future_0, 0)


# Generated at 2022-06-26 07:51:48.015601
# Unit test for function chain_future
def test_chain_future():
    # case 1
    f = Future()

    chain_future(f, f)


# Generated at 2022-06-26 07:51:55.145909
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Testing concurrent.futures.Future
    fut0 = futures.Future()

    fut1 = Future()
    chain_future(fut0, fut1)
    fut0.set_result(None)
    assert fut1.done()

    # Testing asyncio.Future
    fut2 = Future()
    chain_future(fut1, fut2)
    assert fut2.done()

    # Testing return type
    assert isinstance(run_on_executor()(lambda: None), Future)

# Generated at 2022-06-26 07:52:09.312225
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def method_0(arg_0, arg_1):
        return arg_0, arg_1

    obj_0 = dummy_executor
    obj_1 = obj_0.submit(method_0, 1, "ABC")
    assert (obj_1.result() == (1, "ABC"))
    '''AssertionError: assert (obj_1.result() == (1, 'ABC'))
- (1, 'ABC')
+ None
'''


# Generated at 2022-06-26 07:52:16.742798
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = Future()
    class_0 = type('', (), {})()
    setattr(class_0, 'future', future_0)
    future_set_result_unless_cancelled(getattr(class_0, 'future'), getattr(class_0, 'future'))
    assert(getattr(future_0, 'result', None) is not None)

# Generated at 2022-06-26 07:52:28.014090
# Unit test for function chain_future
def test_chain_future():
    async def async_function(result: bool) -> str:
        return "a" if result else "b"

    def sync_function(result: bool) -> str:
        return "c" if result else "d"

    sync_future1 = futures.Future()
    sync_future2 = futures.Future()
    async_future1 = asyncio.Future()
    async_future2 = asyncio.Future()

    chain_future(sync_future1, async_future1)
    chain_future(async_future1, async_future2)
    chain_future(sync_future2, async_future2)

    sync_future1.set_result(True)
    sync_future2.set_result(True)

    assert async_future2.result() == "c"

# Generated at 2022-06-26 07:52:33.510895
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    res = ""
    f2.add_done_callback(lambda fut: res + fut.result())
    f1.set_result("12345")
    assert res == "12345"

# Generated at 2022-06-26 07:52:41.077279
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    async def nop():
        pass
    a = loop.run_until_complete(nop())
    b = loop.run_until_complete(nop())
    chain_future(a,b)
    # a.chain(b)
    loop.close()

if __name__ == "__main__":
    test_case_0()
    test_chain_future()

# Generated at 2022-06-26 07:52:46.200927
# Unit test for function chain_future
def test_chain_future():
    future0 = Future()
    future1 = Future()

    chain_future(future0, future1)

    future0.set_result(1)
    assert(Future().done() == False)
    assert(future0.done() == True)
    assert(future1.done() == True)
    assert(future1.result() == 1)


# Generated at 2022-06-26 07:52:55.505482
# Unit test for function chain_future
def test_chain_future():
    def run(g: Future, h: Future) -> Future:
        g.set_result(1)
        return h

    def test(g: Future, h: Future) -> Future:
        chain_future(g, h)
        return h

    async def async_test(g: Future, h: Future) -> Future:
        # type: ignore
        chain_future(g, h)
        return h

    async def async_run(g: Future, h: Future) -> Future:
        g.set_result(2)
        return h

    def test_chain_future_1(g: Future):
        g.set_result(1)
        return g

    def test_chain_future_2(g: Future):
        g.set_result(2)
        return g


# Generated at 2022-06-26 07:53:05.968995
# Unit test for function chain_future
def test_chain_future():
    class TestClass:
        def __init__(self):
            self.executor = dummy_executor
        @run_on_executor
        def test_method1(self):
            return 1

        def test_method2(self):
            return 2

        def test_method3(self, x: int) -> int:
            return x + 3

    test_instance = TestClass()
    test_func = test_instance.test_method3
    assert test_func(5) == 8
    assert test_instance.test_method2() == 2
    assert test_instance.test_method1() == 1

# Generated at 2022-06-26 07:53:12.055237
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class DummyException(Exception):
        """Dummy exception for testing"""
        pass

    def raise_dummy_exception():
        raise DummyException()

    # test_future_set_exception_unless_cancelled_1
    future = asyncio.Future()
    try:
        future_set_exception_unless_cancelled(future, DummyException())
    except Exception as exc:
        app_log.error("Exception: %s", exc)
    assert future.result() is None

    # test_future_set_exception_unless_cancelled_2
    future = asyncio.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, DummyException())
    assert future.result() is None



# Generated at 2022-06-26 07:53:17.509454
# Unit test for function chain_future
def test_chain_future():
    def my_func(x):
        pass
    def my_callback(future):
        pass
    conc_future = futures.Future()
    async_future = asyncio.Future()
    chain_future(conc_future, async_future)
    chain_future(async_future, conc_future)
    chain_future(conc_future, conc_future)
    chain_future(async_future, async_future)
    future_add_done_callback(conc_future, my_callback)
    future_add_done_callback(async_future, my_callback)


# Generated at 2022-06-26 07:53:37.197029
# Unit test for function chain_future
def test_chain_future():
    io_loop = asyncio.get_event_loop()
    coro = io_loop.create_future()
    fut = io_loop.create_future()
    chain_future(coro, fut)
    def callback(f: Future):
        assert f is fut
        assert coro.done()
        assert fut.done()
        assert coro.exception() is None
        assert fut.exception() is None
        assert coro.result() is fut.result()
    fut.add_done_callback(callback)
    coro.set_result(1)

if __name__ == "__main__":
    test_case_0()
    test_chain_future()

# Generated at 2022-06-26 07:53:49.630604
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    import asyncio
    import concurrent
    import logging

    def f():
        pass

    class TestFutureSetExceptionUnlessCancelled(unittest.TestCase):
        def test(self):
            async_future = asyncio.Future()
            conc_future = concurrent.futures.Future()

            try:
                raise ValueError

            except ValueError:
                async_future.set_exception(sys.exc_info())
                conc_future.set_exception(sys.exc_info())

            future_set_exception_unless_cancelled(async_future, sys.exc_info())
            future_set_exception_unless_cancelled(conc_future, sys.exc_info())


# Generated at 2022-06-26 07:53:59.485250
# Unit test for function chain_future
def test_chain_future():
    # Create two new futures
    future_0 = Future()
    future_1 = Future()

    # Chain future_0 to future_1
    chain_future(future_0, future_1)

    # Set future_0 to be completed
    future_0.set_result(None)

    # Verify that future_1 is completed
    assert future_1.done()

    # Create another future
    future_2 = Future()

    # Chain future_0 to future_2
    chain_future(future_0, future_2)

    # Verify that future_2 is completed
    assert future_2.done()


# Generated at 2022-06-26 07:54:02.031104
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception("test exception")
    future_set_exception_unless_cancelled(future, exc)
    future.set_exception(exc)
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-26 07:54:05.271986
# Unit test for function chain_future
def test_chain_future():
    global a
    a = Future()
    global b
    b = Future()
    chain_future(a, b)


# Generated at 2022-06-26 07:54:08.357717
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future.set_result()
    chain_future(future, future)
    assert future.done() is True

# Generated at 2022-06-26 07:54:18.309762
# Unit test for function chain_future
def test_chain_future():
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    a.set_result(3)
    assert b.result() == 3

    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_result(3)
    assert b.result() == 3

    a = futures.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_result(3)
    assert b.result() == 3


if typing.TYPE_CHECKING:
    def test_run_on_executor() -> None:
        from tornado.ioloop import IOLoop

        class Foo:
            executor = dummy_executor


# Generated at 2022-06-26 07:54:20.186488
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    dummy_executor.submit(lambda: 1)



# Generated at 2022-06-26 07:54:24.860237
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    res = executor.submit(lambda a: a ** a, 2)
    assert res.result() == 4
    res = executor.submit(lambda a: a ** a, 2)
    assert res.result() == 4


# Generated at 2022-06-26 07:54:26.839125
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    future_0 = Future()

    future_set_exception_unless_cancelled(future_0, Exception())


# Generated at 2022-06-26 07:55:03.338105
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    def make_future() -> Future:
        return Future()

    def set_future(future: Future, value: int) -> None:
        future.set_result(value)

    def set_exc_info(future: Future, exc_info: Tuple[
        Optional[type], Optional[BaseException], Optional[types.TracebackType]
    ]) -> None:
        future_set_exc_info(future, exc_info)

    def set_exc(future: Future, value: int) -> None:
        future.set_exception(Exception(value))

    def make_and_chain(value: int) -> Future:
        future = make_future()
        chain_future(future, chain_future(future, make_future()))


# Generated at 2022-06-26 07:55:09.719519
# Unit test for function chain_future
def test_chain_future():
    new_future_0 = Future()
    new_future_1 = Future()
    new_future_0.done()
    new_future_0.cancel()
    new_future_0.result()
    if new_future_0.done():
        new_future_0.exception()



# Generated at 2022-06-26 07:55:13.380236
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    @run_on_executor
    def foo(self):
        return 5

    assert foo("") == 5

# Generated at 2022-06-26 07:55:18.645856
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(2)
    assert f2.result() == 2


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 07:55:22.539159
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    callable_0 = DummyExecutor()
    fn = (lambda: True)
    future = callable_0.submit(fn)
    assert future.result()


# Generated at 2022-06-26 07:55:25.717867
# Unit test for function chain_future
def test_chain_future():
    future_0 = object
    future_1 = None
    chain_future(future_0, future_1)

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-26 07:55:28.475964
# Unit test for function chain_future
def test_chain_future():
    future1 = asyncio.Future()
    future2 = asyncio.Future()
    chain_future(future1, future2)



# Generated at 2022-06-26 07:55:36.948372
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async_future = asyncio.Future()
    future_concrete = futures.Future()
    future_set_result_unless_cancelled(async_future, 10)
    future_set_result_unless_cancelled(future_concrete, 11)
    assert async_future.result() == 10
    assert future_concrete.result() == 11
    async_future.cancel()
    future_concrete.cancel()
    assert async_future.result() == 10
    assert future_concrete.result() == 11

# Generated at 2022-06-26 07:55:39.093185
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:55:49.288580
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import concurrent.futures
    import tornado.gen
    from tornado.testing import AsyncTestCase, gen_test

    def fail_fn(ex: BaseException) -> None:
        raise ex

    class MyTestCase(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            future_a = tornado.gen.Future()
            future_b = concurrent.futures.Future()
            chain_future(future_a, future_b)
            future_a.set_result(5)
            self.assertEqual(5, future_b.result())

        @gen_test
        def test_chain_future_exception(self):
            # type: () -> None
            future_a = tornado.gen.Future()