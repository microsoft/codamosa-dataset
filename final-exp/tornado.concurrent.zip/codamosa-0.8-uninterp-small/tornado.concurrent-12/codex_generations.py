

# Generated at 2022-06-26 07:48:58.899741
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None

    class Test_run_on_executor(object):
        # type: () -> None
        def __init__(self):
            # type: () -> None
            pass

        executor = dummy_executor

        @run_on_executor
        def return_5(self):
            # type: () -> int
            return 5

        @run_on_executor(executor="executor")
        def return_6(self):
            # type: () -> int
            return 6

    test_object = Test_run_on_executor()
    assert test_object.return_5() == 5
    assert test_object.return_6() == 6

if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-26 07:49:11.310651
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = tornado.concurrent.Future()
    exc = ValueError("test")
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    future = tornado.concurrent.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    future = tornado.concurrent.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, StopIteration("test"))
    future.cancel()
    future_set_exception_unless_cancelled(future, TypeError("test"))
    future.cancel()
    future_set

# Generated at 2022-06-26 07:49:14.171062
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = asyncio.Future()
    future_set_exception_unless_cancelled(future_0,Exception())


# Generated at 2022-06-26 07:49:27.197405
# Unit test for function run_on_executor
def test_run_on_executor():

    def a_decorator(async_future: Future, callback: Callable) -> None:
        def copy(future: Future) -> None:
            assert future is a
            if async_future.done():
                return
            if hasattr(a, "exc_info") and a.exc_info() is not None:
                future_set_exc_info(async_future, a.exc_info())
            elif a.exception() is not None:
                async_future.set_exception(a.exception())
            else:
                async_future.set_result(a.result())

        if isinstance(a, Future):
            future_add_done_callback(a, copy)
        else:
            from tornado.ioloop import IOLoop


# Generated at 2022-06-26 07:49:36.595821
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class Dummy():
        def __init__(self):
            self.executor = dummy_executor
        def fn(self, a, b=3):
            return a + b

    dummy = Dummy()
    assert dummy.fn(1, 2) == 3
    assert dummy.fn(2) == 5

    dummy.fn = run_on_executor()(dummy.fn)
    future = dummy.fn(1, 2)
    future.result() == 3
    future = dummy.fn(2)
    future.result() == 5



# Generated at 2022-06-26 07:49:48.991493
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio
    import concurrent.futures
    import functools
    import logging
    import tornado.ioloop

    logging.getLogger("tornado.access").setLevel(logging.CRITICAL)
    logging.getLogger("tornado.application").setLevel(logging.CRITICAL)
    logging.getLogger("tornado.general").setLevel(logging.CRITICAL)

    io = tornado.ioloop.IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)

    async def async_return(x: int) -> int:
        await asyncio.sleep(0.2)
        return x


# Generated at 2022-06-26 07:49:54.919398
# Unit test for function chain_future
def test_chain_future():
    async def async_func_0():
        return
    async_future_0 = async_func_0()
    async_future_1 = async_func_0()
    conc_future_0 = futures.Future()
    conc_future_1 = futures.Future()
    chain_future(async_future_0, async_future_1)
    chain_future(async_future_0, conc_future_0)
    chain_future(conc_future_0, conc_future_1)


# Generated at 2022-06-26 07:49:56.824417
# Unit test for function chain_future
def test_chain_future():
    @chain_future
    def test_chain_future_0(self):
        return self
    test_chain_future_0()



# Generated at 2022-06-26 07:50:01.217996
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exc = BaseException("exception_value")
    def f():
        future = Future()
        future_set_exception_unless_cancelled(future, exc)
        assert future.exception() is exc

    f()
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)



# Generated at 2022-06-26 07:50:12.335277
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()
    future4 = Future()

    # Test 1: Nothing set in future2 before future1 completes
    chain_future(future1, future2)

    # Test 2: No effect when future2 has been set before future1 completes
    future2.set_result(True)
    chain_future(future1, future3)
    future1.set_result(True)

    # Test 3: future4 completes after future3 completes
    chain_future(future3, future4)
    future3.set_result(True)

    # Test 4: future3 completes after future4 completes
    chain_future(future4, future3)
    future4.set_result(True)

    # Test 5: Both futures already completed.

# Generated at 2022-06-26 07:50:24.582688
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop, IOLoop
    res = None

    @run_on_executor
    def callback():
        return "hello"

    def test_chain_future_inner():
        future = Future()
        chain_future(callback(), future)
        return future

    future = test_chain_future_inner()
    assert future.done() is True
    res = future.result()
    assert res == "hello"


if __name__ == "__main__":
    import logging

    logging.basicConfig()
    test_chain_future()

# Generated at 2022-06-26 07:50:28.681603
# Unit test for function chain_future
def test_chain_future():
    a = future_from_callable(lambda : 1)
    b = future_from_callable(lambda : 1)
    chain_future(a, b)
    assert a._callbacks != None
    assert b._callbacks == None


# Generated at 2022-06-26 07:50:31.235282
# Unit test for function chain_future
def test_chain_future():
    gen_0 = (x for x in range(10))
    async_future = Future()
    conc_future = futures.Future()
    chain_future(conc_future, async_future)


# Generated at 2022-06-26 07:50:32.741138
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, Exception())



# Generated at 2022-06-26 07:50:38.902019
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    arg_0: Callable[..., _T] = None
    arg_1: Any = None
    arg_2: Any = None
    conc_future: futures.Future[_T] = dummy_executor.submit(arg_0, arg_1, arg_2)
    assert isinstance(conc_future, futures.Future)

# Generated at 2022-06-26 07:50:52.083848
# Unit test for function chain_future
def test_chain_future():
    done1 = False
    done2 = False
    done3 = False
    done4 = False
    done5 = False
    future1 = Future()
    future2 = Future()
    future3 = Future()
    future4 = Future()
    future5 = Future()
    future6 = Future()
    future_list = [future1, future2, future3, future4, future5, future6]

    def copy(future):
        assert future is future1
        if future1.done():
            future2.set_result(future1.result())
        elif future1.exception() is not None:
            future2.set_exception(future1.exception())
        else:
            future2.set_result(future1.result())
        done2 = True


# Generated at 2022-06-26 07:50:56.257667
# Unit test for function run_on_executor
def test_run_on_executor():
    def foo(self) -> str:
        return "foo"

    class Dict(object):
        pass

    d = Dict()
    d.executor = dummy_executor
    f = run_on_executor()(foo)
    assert f(d) == "foo"

# Generated at 2022-06-26 07:50:59.312493
# Unit test for function run_on_executor
def test_run_on_executor():

    @run_on_executor
    def some_method(self, a, b, c=None, d=3, e=4, *args, **kwargs):
        return d

    some_method(1, b=2)

# Generated at 2022-06-26 07:51:04.819855
# Unit test for function chain_future
def test_chain_future():
    first_future = Future()
    second_future = Future()
    chain_future(first_future, second_future)



# Generated at 2022-06-26 07:51:11.756189
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    value = "value"
    future_set_result_unless_cancelled(future, value)
    assert future.done()
    assert future.result() == value

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, value)



# Generated at 2022-06-26 07:51:27.150062
# Unit test for function run_on_executor
def test_run_on_executor():
    async def async_func(self, x: int, y: int) -> int:
        return x + y

    @run_on_executor
    def run_on_executor(self, x: int, y: int) -> "futures.Future[int]":
        return x + y

    class MyClass:
        def __init__(self) -> None:
            self.executor = dummy_executor

        @run_on_executor
        def run_on_executor_with_executor_attr(self, x: int, y: int) -> "futures.Future[int]":
            return x + y


# Generated at 2022-06-26 07:51:32.848535
# Unit test for function chain_future
def test_chain_future():
    a = Future()  # type: Future[int]
    b = Future()  # type: Future[int]
    chain_future(a, b)
    a.set_result(1)
    assert b.done()
    assert b.result() == 1



# Generated at 2022-06-26 07:51:33.658534
# Unit test for function chain_future
def test_chain_future():
    pass



# Generated at 2022-06-26 07:51:39.120706
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a,b)

# Then we check what is the type of result.
    assert type(b.result()) is int

# Since the result should be 2, this test case will pass
    assert b.result() == 2

# This is a test case for future_set_result_unless_cancelled

# Generated at 2022-06-26 07:51:44.329953
# Unit test for function chain_future
def test_chain_future():
    pass


# Generated at 2022-06-26 07:51:46.656737
# Unit test for function chain_future
def test_chain_future():
    pass
    # a = Future()
    # b = Future()
    # chain_future(a, b)


# Generated at 2022-06-26 07:51:56.631712
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def f1(future, exc):
        # type: (futures.Future, BaseException) -> None
        raise exc

    def f2(future):
        # type: (futures.Future) -> None
        pass

    future1 = futures.Future()  # type: futures.Future[bool]
    future2 = futures.Future()  # type: futures.Future[bool]
    chain_future(future1, future2)

    future1.set_exception(RuntimeError())
    assert future2.exception() is RuntimeError()

    future1 = futures.Future()  # type: futures.Future[bool]
    future2 = futures.Future()  # type: futures.Future[bool]
    chain_future(future1, future2)


# Generated at 2022-06-26 07:51:58.942182
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)


# Generated at 2022-06-26 07:52:11.085271
# Unit test for function run_on_executor
def test_run_on_executor():
    class TestClass:
        executor = dummy_executor
        lock = asyncio.Lock()

        @run_on_executor
        def test_run_on_executor_method_0(self):
            print('test_run_on_executor_method_0()')

    testClass = TestClass()

    future_0 = testClass.test_run_on_executor_method_0()
    future_0.add_done_callback(lambda future: print(future.result()))
    # future_0.set_result('test_run_on_executor_method_0()')


if __name__ == "__main__":
    test_case_0()
    test_run_on_executor()

# Generated at 2022-06-26 07:52:14.171534
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    future_set_exception_unless_cancelled(future_0, NameError())
    future_0.cancel()
    future_1 = Future()
    future_set_exception_unless_cancelled(future_1, SystemError())

if __name__ == '__main__':
    test_case_0()
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-26 07:52:28.506196
# Unit test for function chain_future
def test_chain_future():
    # For an asyncio.Future, test_chain_future tests the following:
    #
    #   * that the target future completes with the same exception as
    #     the source future (if the source future completes with an
    #     exception).
    #
    #   * that the target future completes with the same result as the
    #     source future (if the source future completes without an
    #     exception).
    #
    #   * the target future does not complete if the source future is
    #     cancelled.
    #
    #   * that the target future doesn't complete if it is cancelled
    #     after the source future completes, but before the target
    #     future completes.

    # Test that the target future completes with the same exception as
    # the source future (if the source future completes with an
    # exception).
    source = Future

# Generated at 2022-06-26 07:52:29.674402
# Unit test for function run_on_executor
def test_run_on_executor():
    pass



# Generated at 2022-06-26 07:52:31.126835
# Unit test for function run_on_executor
def test_run_on_executor():
    test_case_0()

# Generated at 2022-06-26 07:52:34.691729
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    e = Exception()
    future_set_exception_unless_cancelled(f, e)
    assert f.exception() == e


# Generated at 2022-06-26 07:52:46.776605
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado import gen
    from tornado import ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from concurrent import futures
    from concurrent import futures
    import functools
    from tornado.concurrent import Future

    class DummyExecutor(futures.Executor):
        def submit(
            self, fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "futures.Future[_T]":
            future = futures.Future()  # type: futures.Future[_T]
            try:
                future_set_result_unless_cancelled(future, fn(*args, **kwargs))
            except Exception:
                future_set_exc_info(future, sys.exc_info())
            return future


# Generated at 2022-06-26 07:52:48.594250
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()  # type: Future[int]
    future_1 = Future()  # type: Future[int]
    chain_future(future_0, future_1)
    future_0.set_result(0)



# Generated at 2022-06-26 07:52:49.244211
# Unit test for function run_on_executor
def test_run_on_executor():
    assert run_on_executor(executor='_thread_pool')

# Generated at 2022-06-26 07:52:57.208916
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Create instance of class DummyExecutor
    obj = DummyExecutor()

    # Call method submit of class DummyExecutor
    # Type warning
    obj.submit(callable_0)

    # Call method submit of class DummyExecutor
    # Type warning
    obj.submit(callable_0, 1)

    # Call method submit of class DummyExecutor
    # Type warning
    obj.submit(callable_0, 1, 2)

    # Call method submit of class DummyExecutor
    # Type warning
    obj.submit(callable_0, 1, 2, 3)

    # Call method submit of class DummyExecutor
    # Type warning
    obj.submit(callable_0, 1, 2, 3, 4)

    # Call method submit of class DummyExecutor
    # Type warning
    obj

# Generated at 2022-06-26 07:53:06.091039
# Unit test for function chain_future
def test_chain_future():
    dummy_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(dummy_loop)
    async_future = asyncio.Future()
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    chain_future(async_future, b)
    assert a is not b
    a.set_result(None)
    assert b.done()
    async_future.set_result(None)
    assert b.done()


# Generated at 2022-06-26 07:53:09.803874
# Unit test for function chain_future
def test_chain_future():
    import unittest
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result("result")
    assert b.result() == "result"



# Generated at 2022-06-26 07:53:18.580672
# Unit test for function chain_future
def test_chain_future():

    async def foo():
        pass

    future = foo()
    future2 = foo()
    chain_future(future, future2)

# Generated at 2022-06-26 07:53:20.445182
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    pass
    # SUT
    dummy_executor.submit(fn, *args, **kwargs)

# Generated at 2022-06-26 07:53:21.071513
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    pass

# Generated at 2022-06-26 07:53:23.061457
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-26 07:53:30.548061
# Unit test for function chain_future
def test_chain_future():
    from . import ioloop

    def function_0():
        pass

    def function_1():
        pass

    def function_2(x: "Future[None]", y: "Future[None]") -> None:
        chain_future(x, y)

    def function_3(x: "Future[None]", y: "Future[None]") -> None:
        chain_future(x, y)



# Generated at 2022-06-26 07:53:33.144194
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0: Future[int] = Future()
    future_set_result_unless_cancelled(future_0, 1)


# Generated at 2022-06-26 07:53:40.372873
# Unit test for function chain_future
def test_chain_future():
    # Create an asyncio.Future 'afuture' and pass it to a function 'cfuture'
    # that changes it to a concurrent.futures.Future.
    afuture = Future()
    bfuture = Future()
    cfuture = Future()
    dfuture = Future()
    afuture.add_done_callback(lambda future: chain_future(future, bfuture))
    bfuture.add_done_callback(lambda future: chain_future(future, cfuture))
    cfuture.add_done_callback(lambda future: chain_future(future, dfuture))
    dfuture.add_done_callback(lambda future: future.set_result('done'))
    afuture.set_result('done')
    bfuture.set_result('done')

    assert(afuture.done())
    assert(bfuture.done())


# Generated at 2022-06-26 07:53:50.668747
# Unit test for function chain_future
def test_chain_future():
    def run_on_executor(fn):
        def wrapper(*args):
            future = Future()
            result = Future()
            def callback():
                future_set_result_unless_cancelled(future, fn(*args))
            result.set_result(callback())
            chain_future(result, future)
            return future
        return wrapper
    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def test1(self, a, b):
            return a + b

    t = Test()
    f = t.test1(1, 2)
    assert f.result() == 3



# Generated at 2022-06-26 07:53:53.885402
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(0)
    assert g.done()
    assert g.result() == 0

# Generated at 2022-06-26 07:54:04.717896
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_future = asyncio.Future()
    future_future.set_result(True)
    future_future = asyncio.Future()
    future_future.cancel()
    future_future = asyncio.Future()
    future_set_result_unless_cancelled(future_future, True)
    future_future.cancel()
    future_future = concurrent.futures.Future()
    future_future.set_result(True)
    future_future = concurrent.futures.Future()
    future_set_result_unless_cancelled(future_future, True)
    future_future = concurrent.futures.Future()
    future_future.set_exception(Exception('test'))
    future_future.cancel()
    future_future = concurrent.futures.Future()
    future_

# Generated at 2022-06-26 07:54:18.788148
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future_0 = Future()  # type: Future[Any]
    future_1 = Future()  # type: Future[Any]
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:54:31.704193
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    import concurrent
    import functools
    import sys
    import types
    
    
    import tornado.gen
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.websocket
    
    
    # unit test for function chain_future
    # test decorators
    @run_on_executor()
    def test_case_0(cls: Any, a: Any, *b: Any, **c: Any) -> Any:
        pass
    
    
    # test_chain_future
    def test_case_1(a: "Future[_T]", b: "Future[_T]") -> None:
        pass
    
    

# Generated at 2022-06-26 07:54:34.444809
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_exception(Exception())
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-26 07:54:48.662746
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    def _test_callback(future: Future):
        assert not future.cancelled()
        assert future.exception()
        assert future.done()
        assert future.result() is None

    class TestFutureSetExceptionUnlessCancelled(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = Future()
            future_set_exception_unless_cancelled(future, ValueError())
            future_add_done_callback(future, _test_callback)

        def test_future_set_exception_unless_cancelled_with_cancelled_future(self):
            future = Future()
            future.cancel()
            future_set_exception_unless_cancelled(future, ValueError())

    unittest

# Generated at 2022-06-26 07:54:54.862188
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future1.set_result("A")
    assert future1.result() == "A"
    assert future2.result() == "A"

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future1.set_exception("B")
    assert future1.exception() == "B"
    assert future2.exception() == "B"



# Generated at 2022-06-26 07:54:57.180178
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future2 = Future()
    chain_future(future, future2)


# Generated at 2022-06-26 07:54:59.111244
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def dummy():
        pass
    dummy_executor.submit(dummy)


# Generated at 2022-06-26 07:55:02.104053
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 0)
    assert future.result() == 0

# Generated at 2022-06-26 07:55:14.121495
# Unit test for function chain_future
def test_chain_future():
    x = Future()
    y = Future()
    chain_future(x, y)
    assert not y.done()

    x.set_result("foo")
    assert y.done()
    assert y.result() == "foo"

    x = Future()
    y = Future()
    x.set_exception(Exception("foo"))
    chain_future(x, y)
    assert y.exception() is not None
    assert y.exception().args == ("foo",)

    x = Future()
    y = Future()
    y.set_result("bar")
    chain_future(x, y)
    assert y.result() == "bar"
    x.set_exception(Exception("baz"))
    assert y.result() == "bar"



# Generated at 2022-06-26 07:55:26.019698
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future_1 = Future()  # type: Future
    assert not future_1.done()
    future_2 = Future()  # type: Future
    future_2_done = False

    def callback(future: Future) -> None:
        nonlocal future_2_done
        assert future_2.done()
        future_2_done = True

    future_add_done_callback(future_2, callback)
    chain_future(future_1, future_2)
    assert not future_2.done()
    future_1.set_exception(ValueError)
    assert future_2.done()
    assert future_2_done
    try:
        future_2.result()
        assert False
    except ValueError:
        pass



# Generated at 2022-06-26 07:55:53.310121
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor()
    def dummy_func():
        return

    future = Future()
    chain_future(future, dummy_func)
    return future


# Generated at 2022-06-26 07:55:55.772946
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_case_0():
        callable_0 = run_on_executor()
        assert callable_0 is not None


# Generated at 2022-06-26 07:56:02.396042
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    a = Future()
    b: Future[int] = Future()
    a.cancel()
    future_set_result_unless_cancelled(b, 5)
    assert a.cancelled()
    assert b.result() == 5

if __name__ == '__main__':
    test_case_0()
    test_future_set_result_unless_cancelled()

# Generated at 2022-06-26 07:56:12.186889
# Unit test for function chain_future
def test_chain_future():
    async_future = Future()
    conc_future = futures.Future()
    chain_future(conc_future, async_future)
    assert(async_future.cancelled() == False)
    assert(conc_future.cancelled() == False)



# Generated at 2022-06-26 07:56:17.073684
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import asyncio
    future = asyncio.Future()
    exc = asyncio.InvalidStateError()
    future.cancel()
    try:
        future_set_result_unless_cancelled(future, "result")
    except:
        pass
    else:
        raise Exception("future_set_result_unless_cancelled should throw an exception when given a cancelled future")
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, "result")


# Generated at 2022-06-26 07:56:29.718326
# Unit test for function chain_future
def test_chain_future():
    async_future = Future()  # type: Future[int]
    conc_future = futures.Future()  # type: futures.Future[int]
    chain_future(conc_future, async_future)
    conc_future.set_result(5)
    assert async_future.result() == 5
    async_future = Future()  # type: Future[int]
    conc_future = futures.Future()  # type: futures.Future[int]
    chain_future(async_future, conc_future)
    async_future.set_result(5)
    assert conc_future.result() == 5


# Generated at 2022-06-26 07:56:37.029819
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.get_event_loop()
    future = asyncio.Future(loop=loop)
    future.cancel()
    future_set_result_unless_cancelled(future, 5)
    assert future.cancelled()
    future = asyncio.Future(loop=loop)
    future_set_result_unless_cancelled(future, 5)
    assert future.done()
    assert future.result() == 5


# Generated at 2022-06-26 07:56:42.318672
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    
    # Create future that is in done state
    future = Future()
    future.set_result(1)

    # Test
    future_set_result_unless_cancelled(future, 2)
    assert future.done() and future.result() == 1

# Generated at 2022-06-26 07:56:45.203845
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc_1 = Exception("raising 1")
    future_set_exception_unless_cancelled(future, exc_1)
    assert future.done()
    assert future.exception() == exc_1


# Generated at 2022-06-26 07:56:51.382220
# Unit test for function chain_future
def test_chain_future():
    main_future = Future()
    chained_future = Future()

    chain_future(chained_future, main_future)

    assert main_future.done() == False
    assert chained_future.done() == False

    chained_future.set_result(3)

    assert main_future.done() == True
    assert chained_future.done() == True

    assert main_future.result() == 3



# Generated at 2022-06-26 07:57:56.871712
# Unit test for function chain_future
def test_chain_future():
    def test_func(a1, a2):
        return a1 + a2

    futu = Future()
    futu.set_result(5)

    futu2 = Future()
    chain_future(futu, futu2)
    assert futu2.result() == 5
    assert futu2.done()
    assert not futu2.cancelled()
    assert not futu2.running()

    futu3 = Future()
    chain_future(futu, futu3)
    assert futu3.result() == 5
    assert futu3.done()
    assert not futu3.cancelled()
    assert not futu3.running()

    futu4 = Future()
    futu.set_exception(Exception())

# Generated at 2022-06-26 07:58:08.459582
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import asyncio
    from concurrent.futures import Future
    from tornado.concurrent import Future as Future_Tornado

    test_future = Future()
    future_set_result_unless_cancelled(test_future, "test")
    assert test_future.result() == "test"

    test_future = Future_Tornado()
    future_set_result_unless_cancelled(test_future, "test")
    assert test_future.result() == "test"

    asyncio_future = asyncio.Future()
    future_set_result_unless_cancelled(asyncio_future, "test")
    assert asyncio_future.result() == "test"

    asyncio_future.cancel()
    future_set_result_unless_cancelled(asyncio_future, "test")

# Generated at 2022-06-26 07:58:09.974840
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    assert 0 == 0 # We arent testing this function


# Generated at 2022-06-26 07:58:12.855137
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor_0 = dummy_executor
    callable_0 = test_case_0
    future_0 = dummy_executor_0.submit(callable_0)
    future_0.result()


# Generated at 2022-06-26 07:58:21.309785
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = ValueError()
    future_set_exception_unless_cancelled(future, exc)
    future.cancel()
    assert future.cancelled()
    assert not future.done()
    future_set_exception_unless_cancelled(future, exc)
    assert future.cancelled()
    assert not future.done()

if __name__ == "__main__":
    test_future_set_exception_unless_cancelled()

# Generated at 2022-06-26 07:58:29.724011
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    assert not future_0.done()
    assert not future_1.done()
    chain_future(future_0, future_1)
    future_1.set_result(None)
    assert future_0.done()
    assert future_0.result() is None
    future_0.set_result(None)
    assert future_1.done()
    assert future_1.result() is None


# Generated at 2022-06-26 07:58:32.058606
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.done() and future.result() == 5



# Generated at 2022-06-26 07:58:36.547946
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()  # type: Future[Any]
    future_1 = Future()  # type: Future[Any]
    future_1.cancel()
    chain_future(future_0, future_1)
    future_0.set_result(None)

# Generated at 2022-06-26 07:58:41.584689
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
    future.cancel()
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
