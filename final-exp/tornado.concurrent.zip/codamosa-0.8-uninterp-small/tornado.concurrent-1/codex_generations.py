

# Generated at 2022-06-26 07:49:11.666926
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_1(self, a, b):
        return self, a, b
    wrapped_1 = run_on_executor(test_1)
    class A:
        pass
    a = A()
    a.executor = dummy_executor
    assert wrapped_1(a, 10, 20) == (a, 10, 20)
    def test_2(self, a, b):
        raise RuntimeError
    wrapped_2 = run_on_executor(test_2)
    assert isinstance(wrapped_2(a, 10, 20), Future)
    try:
        future_result(wrapped_2(a, 10, 20))
        assert False
    except RuntimeError:
        pass



# Generated at 2022-06-26 07:49:16.718174
# Unit test for function run_on_executor
def test_run_on_executor():
    def callback(self):
        pass

    def func(self):
        pass

    x = run_on_executor(callback, executor="executor")
    y = run_on_executor(executor="executor")(func)


# Generated at 2022-06-26 07:49:28.721766
# Unit test for function run_on_executor
def test_run_on_executor():

    class TestLoop:
        def __init__(self):
            self.tasks = []
        
        def add_future(self, future, callback):
            self.tasks.append((future, callback))

    class TestClass:
        def __init__(self):
            self.executor = dummy_executor
            self.result = 0

        @run_on_executor(executor="executor")
        def add_value(self, value):
            self.result += value
            return self.result

    mock_loop = TestLoop()
    assert len(mock_loop.tasks) == 0

    test = TestClass()

    future_1 = test.add_value(1)
    future_2 = test.add_value(2)

    assert future_1 != future_2

# Generated at 2022-06-26 07:49:30.228696
# Unit test for function chain_future
def test_chain_future():

    test_case_0()


import _asyncio as module_0


# Generated at 2022-06-26 07:49:34.821425
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda _, one, two, three=None: one, 1, 2)
    dummy_executor.submit(lambda _, one, two, three=None: one, 1, 2, three=3)


# Generated at 2022-06-26 07:49:37.293126
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    future_0 = asyncio.Future()
    chain_future(future_0, future_0)


# Generated at 2022-06-26 07:49:41.440794
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_exception = Future()
    future_set_exc_info(future_exception, sys.exc_info())
    assert future_exception.exception() == Exception


# Generated at 2022-06-26 07:49:48.691336
# Unit test for function chain_future
def test_chain_future():

    def callback(self, *args):
        pass

    class Future_0(object):
        def __init__(self):
            self.awaitable = False

        def done(self) -> bool:
            return self.awaitable

        def add_done_callback(self, callback) -> None:
            if self.awaitable:
                callback(self)

    future_0 = Future_0()

    chain_future(future_0, future_0)


# Generated at 2022-06-26 07:49:57.697147
# Unit test for function run_on_executor
def test_run_on_executor():

    def test_decorator(*args, **kwargs):
        return run_on_executor(*args, **kwargs)

    def run_on_executor_decorator(fn):
        def wrapper(fn, self, *args, **kwargs):
            async_future = Future()
            conc_future = getattr(self, "executor").submit(fn, self, *args, **kwargs)
            chain_future(conc_future, async_future)
            return async_future

        fn = types.MethodType(fn, object)
        return wrapper(fn, object(), 1, 2, 3)

    def run_on_executor_decorator_test_attribute_1(fn):
        def wrapper(fn, self, *args, **kwargs):
            async_future = Future()

# Generated at 2022-06-26 07:50:02.691132
# Unit test for function chain_future
def test_chain_future():
    future_0 = module_0.Future()
    future_1 = module_0.Future()
    chain_future(future_0, future_1)
    try:
        future_0.set_result(1)
        assert future_1.result() == 1
    except module_0.InvalidStateError:
        pass


# Generated at 2022-06-26 07:50:19.590914
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = None
    future_0 = module_0.Future()
    future_set_exception_unless_cancelled(future_0, KeyError())
    future_0.cancel()


# Generated at 2022-06-26 07:50:22.634874
# Unit test for function chain_future
def test_chain_future():
    future_1 = module_0.Future()
    future_2 = module_0.Future()
    chain_future(future_1, future_2)

# Generated at 2022-06-26 07:50:24.951226
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_0 = module_0.Future()
    test_case_0()
    future_0.set_result(None)


# Generated at 2022-06-26 07:50:26.971106
# Unit test for function chain_future
def test_chain_future():
    future_0 = module_0.Future()
    future_1 = module_0.Future()
    chain_future(future_0, future_1)


# Generated at 2022-06-26 07:50:34.084829
# Unit test for function chain_future
def test_chain_future():
    future_1 = module_0.Future()
    future_2 = module_0.Future()
    assert future_1.done() is False
    assert future_1.result() is None
    future_1.set_result('foo')
    assert future_1.result() == 'foo'
    assert future_2.done() is False
    assert future_2.result() is None
    chain_future(future_1, future_2)
    assert future_1.result() == 'foo'
    assert future_2.done() is True
    assert future_2.result() == 'foo'


# Generated at 2022-06-26 07:50:40.194784
# Unit test for function run_on_executor
def test_run_on_executor():
    self_0 = ""
    args_0 = {'executor':'executor'}
    
    class Test_0():
        def __init__(self):
            self.executor = None

    obj_0 = Test_0()
    def func_0(self_0, *args_0, **args_1):
        pass
    run_on_executor(func_0)(self_0, **args_0)

# Generated at 2022-06-26 07:50:45.657045
# Unit test for function chain_future
def test_chain_future():
    # Make sure the following code runs without exception.
    future_0 = module_0.Future()
    future_1 = module_0.Future()
    chain_future(future_0, future_1)
    future_1 = futures.Future()
    chain_future(future_1, future_1)


# Generated at 2022-06-26 07:50:57.056765
# Unit test for function run_on_executor
def test_run_on_executor():
    # Set up attributes
    class Class:
        def __init__(self):
            self.executor = module_0.get_event_loop()
        def method(self):
            pass

    @run_on_executor
    def func(self):
        return self

    @run_on_executor(executor="other")
    def func2(self):
        return self

    # Test function
    assert callable(run_on_executor)
    assert callable(run_on_executor(lambda: None))

    # Test return value is a coroutine
    assert isinstance(func(Class()), module_0.Future)
    assert isinstance(func2(Class()), module_0.Future)


# Generated at 2022-06-26 07:51:03.788800
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import unittest.mock
    import concurrent.futures

    class Object(object):
        pass

    class Test(unittest.TestCase):
        @unittest.mock.patch("tornado.concurrent.run_on_executor")
        def test_executor_callable(self, mock_run):
            """Run ``run_on_executor`` as a function on callable objects."""
            executor = concurrent.futures.ThreadPoolExecutor(1)
            obj = Object()
            obj.executor = executor

            @tornado.concurrent.run_on_executor
            def fn(self):
                return 42

            fn(obj)
            mock_run.assert_called_once_with(obj.executor, fn, obj)


# Generated at 2022-06-26 07:51:15.855578
# Unit test for function run_on_executor
def test_run_on_executor():
    # Test 0
    future = module_0.Future()
    def wrapper(self):
        future.set_result(None)
    def run_on_executor_decorator(fn):
        @functools.wraps(fn)
        def wrapper(self, *args, **kwargs):
            future.set_result(None)
        return wrapper
    def run_on_executor(*args, **kwargs):
        # Fully type-checking decorators is tricky, and this one is
        # discouraged anyway so it doesn't have all the generic magic.
        def run_on_executor_decorator(fn):
            @functools.wraps(fn)
            def wrapper(self, *args, **kwargs):
                future.set_result(None)
            return wrapper

# Generated at 2022-06-26 07:51:40.438846
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    def fn(future_3):
        assert future_3 is future_1
        if future_2.done():
            return
        if future_1.exception() is not None:
            future_2.set_exception(future_1.exception())
        else:
            future_2.set_result(future_1.result())

    chain_future(future_1, future_2)
    future_1.add_done_callback(fn)


# Generated at 2022-06-26 07:51:47.724476
# Unit test for function chain_future
def test_chain_future():
    # chain_future(a, b) cases:
    # - a and b are both asyncio.futures
    # - a is a asyncio.futures and b is a concurrent.futures.Future
    # - a is a concurrent.futures.Future and b is a asyncio.futures
    # - a and b are both concurrent.futures.Future
    print('test_chain_future')
    test_case_0()


# Generated at 2022-06-26 07:51:53.492955
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_1 = None # type: Optional[Any]
    try:
        future_1 = test_case_0()
    except Exception:
        future_set_exc_info(future_1, sys.exc_info())
    exc_info_1 = (None, None, None)
    future_set_exception_unless_cancelled(future_1, exc_info_1[1])




# Generated at 2022-06-26 07:51:54.216679
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    raise RuntimeError


# Generated at 2022-06-26 07:51:58.451414
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fun(*args, **kwargs):
        pass
    exe = DummyExecutor()
    future = exe.submit(fun)
    expected = None
    actual = future.result()
    assert actual == expected


# Generated at 2022-06-26 07:52:03.900630
# Unit test for function chain_future
def test_chain_future():
    future_1 = module_0.Future()
    future_2 = module_0.Future()
    chain_future(future_1, future_2)
    # assert future_1._state == 'FINISHED'
    # assert future_2._state == 'PENDING'


# Generated at 2022-06-26 07:52:08.948177
# Unit test for function chain_future
def test_chain_future():
    future_0 = module_0.Future()
    future_0.set_result(42)
    future_1 = Future()
    chain_future(future_0, future_1)
    assert future_1.result() == 42

# Generated at 2022-06-26 07:52:11.349426
# Unit test for function chain_future
def test_chain_future():
    assert 0 == (
        0
    )  # TODO: appear to be no way to check whether a future or a coroutine has been activated



# Generated at 2022-06-26 07:52:24.388683
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = module_0.Future()
    exc_info_0 = ()
    future_set_exc_info(future_0, exc_info_0)
    exc_info_0 = ()
    future_set_exc_info(future_0, exc_info_0)
    
if __name__ == "__main__":
    import __main__
    namespaces = [vars(__main__), vars(module_0)]
    test_cases = [test_case_0]
    for (index, test_case) in enumerate(test_cases):
        print("%d. %s" % (index + 1, test_case.__name__))
        test_case()

# Generated at 2022-06-26 07:52:27.208003
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = module_0.Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.done()
    assert future.result() == "result"



# Generated at 2022-06-26 07:52:55.560443
# Unit test for function chain_future
def test_chain_future():
    class MainClass:
        def __init__(self):
            self.executor = dummy_executor
            self.future = Future()
        def get_future(self) -> Future:
            return self.future
        # Test for function run_on_executor
        @run_on_executor()
        def test_function(self, i: int) -> int:
            print(i)
            return i
        # Test for function is_future
        def test_is_future(self):
            assert is_future(self.future)
        # Test for function dummy_executor
        def test_dummy_executor(self):
            assert isinstance(dummy_executor, DummyExecutor)
        # Test for function future_set_exc_info

# Generated at 2022-06-26 07:53:08.194003
# Unit test for function chain_future
def test_chain_future():
    def fn(self, *args, **kwargs):
        pass
    fn2 = run_on_executor(fn, executor='_thread_pool')
    
    class Test:
        def __init__(self):
            self._thread_pool = dummy_executor
            self.executor = dummy_executor
    
        @run_on_executor
        def test(self):
            self.executor.submit(lambda :None)
            raise NotImplementedError
    
        @run_on_executor
        def test2(self):
            self.executor.submit(lambda :None)
    
        @run_on_executor
        def test3(self):
            self.executor.submit(lambda :None)
    

# Generated at 2022-06-26 07:53:16.725299
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio

    async def f():
        # type: () -> None
        return 3

    loop = asyncio.get_event_loop()

    f1 = f()
    f2 = asyncio.Future()  # type: Future[int]
    f3 = futures.Future()

    chain_future(f1, f2)
    chain_future(f1, f3)
    assert loop.run_until_complete(f2) == 3
    assert f3.result() == 3

    chain_future(f2, f3)  # f2 result should be ignored
    assert f3.result() == 3

    # ensure race conditions with concurrent modifications don't occur
    chain_future(f2, f2)
    assert f2.result() == 3


# Generated at 2022-06-26 07:53:22.777648
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.done() and future.exception() is exc
    # reset future
    future = Future()
    exc = Exception()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.done() and future.exception() is None



# Generated at 2022-06-26 07:53:27.973080
# Unit test for function chain_future
def test_chain_future():
    future_1 = Future()
    future_2 = Future()
    chain_future(future_1, future_2)



# Generated at 2022-06-26 07:53:30.786981
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor(executor="_thread_pool")
    def xtest_chain_future(self, future: Future):
        raise Exception("ERROR")

    future = Future()
    chain_future(xtest_chain_future, future)
    try:
        future.result()
        assert False
    except Exception:
        pass



# Generated at 2022-06-26 07:53:33.620373
# Unit test for function chain_future
def test_chain_future():
    future_0 = Future()
    future_1 = Future()
    chain_future(future_0, future_1)



# Generated at 2022-06-26 07:53:40.338835
# Unit test for function chain_future
def test_chain_future():
    test_future_0 = Future()
    test_future_1 = Future()
    chain_future(test_future_0, test_future_1)
    test_future_0.set_result(10)
    assert test_future_1.result() == 10



# Generated at 2022-06-26 07:53:44.020797
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1



# Generated at 2022-06-26 07:53:47.279890
# Unit test for function run_on_executor
def test_run_on_executor():
    # Add your test here
    callable_0: Callable = run_on_executor()
    method_0: _IO = callable_0


# Generated at 2022-06-26 07:54:35.580961
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def success(s: str) -> str:
        return s

    def failed(s: str) -> str:
        return s

    def error_handler(future: Future) -> None:
        pass

    future = Future()  # type: Future[str]
    chain_future(success("example"), future)
    assert future.result() == "example"
    future = Future()
    chain_future(failed("example"), future)
    future.add_done_callback(error_handler)
    assert future.exception() is None



# Generated at 2022-06-26 07:54:38.278392
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(None)
    assert b.done()

# Test for deprecated function run_on_executor

# Generated at 2022-06-26 07:54:49.570575
# Unit test for function chain_future
def test_chain_future():
    from unittest import mock

    mock1 = mock.Mock()
    mock2 = mock.Mock()
    mock3 = mock.Mock()
    async_future = Future()
    conc_future = Future()

    async_future.set_result(1)
    chain_future(async_future, conc_future)
    assert conc_future.result() == 1

    # exc_info is an attribute only on older versions of Tornado
    if hasattr(async_future, "exc_info"):
        async_future.set_exception(Exception("foo"))
        chain_future(async_future, conc_future)
        with pytest.raises(Exception):
            conc_future.result()

    async_future.set_exception(Exception("foo"))

# Generated at 2022-06-26 07:54:54.490181
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from concurrent.futures import Future

    f = Future()
    future_set_exception_unless_cancelled(f, Exception("Test exception"))
    assert f.exception() is not None
    assert "Test exception" == f.exception().args[0]
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("Test exception"))



# Generated at 2022-06-26 07:55:00.518460
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    ioloop = IOLoop.current()
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42



# Generated at 2022-06-26 07:55:11.875089
# Unit test for function run_on_executor
def test_run_on_executor():
    # test 0
    # unit test for test_case_0
    def __func0(self, *args, **kwargs):
        pass
    # use decorator
    __func0 = run_on_executor(__func0)
    # no assertion

    # test 1
    # unit test for test_case_1
    def __func1(self, *args, **kwargs):
        pass
    __func1 = run_on_executor(executor="thread_pool")(__func1)
    # no assertion

    # test 2
    # unit test for test_case_2
    def __func2(self, *args, **kwargs):
        pass
    __func2 = run_on_executor(executor="thread_pool", callback=None)(__func2)
    # no assertion

    # test

# Generated at 2022-06-26 07:55:19.113010
# Unit test for function chain_future
def test_chain_future():
    # Test if the function works when given two valid Future
    fut1, fut2 = Future(), Future()
    assert fut1.done() == False
    assert fut2.done() == False
    chain_future(fut1, fut2)
    fut1.set_result('future')
    assert fut1.done() == True
    assert fut2.done() == True


# Generated at 2022-06-26 07:55:24.757607
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def f(fut: Future[str]) -> None:
        fut.set_result("y")
    fut = Future()  # type: Future[str]
    chain_future(fut, fut)
    fut.add_done_callback(lambda fut: fut.result)

# Generated at 2022-06-26 07:55:29.372957
# Unit test for function chain_future
def test_chain_future():
    def hello():
        pass

    def goodbye():
        pass

    future = Future()
    fn = lambda: 'hello'

    chain_future(future, fn)
    chain_future(fn, hello)
    chain_future(future, goodbye)


# Generated at 2022-06-26 07:55:38.776421
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Step 1
    future = Future()
    future.set_result(42)
    assert future.result() == 42
    future_set_result_unless_cancelled(future, 666)
    assert future.result() == 42
    # Step 2
    future_2 = Future()
    future_2.cancel()
    future_set_result_unless_cancelled(future_2, 666)
    assert future_2.cancelled() == True


if __name__ == "__main__":
    test_case_0()
    # Unit test
    test_future_set_result_unless_cancelled()

# Generated at 2022-06-26 07:57:05.356450
# Unit test for function chain_future
def test_chain_future():
    from concurrent.futures import Future as Future_0
    from asyncio import Future as Future_1
    
    f_0 = Future_0()
    f_1 = Future_1()
    chain_future(f_0, f_1)


# Generated at 2022-06-26 07:57:07.196386
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    loop = asyncio.get_event_loop()
    future = Future()
    chain_future(future, future)


# Generated at 2022-06-26 07:57:10.036109
# Unit test for function chain_future
def test_chain_future():
    async_future = None  # type: Future[str]
    conc_future = None  # type: Future[str]
    chain_future(async_future, conc_future)



# Generated at 2022-06-26 07:57:22.998448
# Unit test for function run_on_executor
def test_run_on_executor():
    def x():
        pass

    @run_on_executor
    def y(self, arg1: int, arg2: str = 'x') -> None:
        pass

    @run_on_executor(executor='_thread_pool')
    def z(self, arg1: int, arg2: str = 'x') -> None:
        pass

    @run_on_executor(executor='_thread_pool')
    def t(self, arg1: int, arg2: str = 'x') -> None:
        pass

    class Foo(object):
        executor = dummy_executor
        _thread_pool = dummy_executor
        x = x
        y = y
        z = z
        t = t

    foo = Foo()
    # check that the decorator didn't mess with the original function


# Generated at 2022-06-26 07:57:27.471773
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_0 = Future()
    exc_info_0 = (None, None, None)
    future_set_exc_info(future_0, exc_info_0)


# Generated at 2022-06-26 07:57:29.635564
# Unit test for function chain_future
def test_chain_future():
    t1 = Future
    t2 = Future
    chain_future(t1, t2)


# Generated at 2022-06-26 07:57:42.226767
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio
    import concurrent.futures

    @asyncio.coroutine
    def test_chain_future1():
        # type: () -> None
        async_future = asyncio.Future()  # type: Future
        conc_future = concurrent.futures.Future()  # type: futures.Future
        chain_future(conc_future, async_future)
        conc_future.set_result(1)
        result = yield async_future
        assert result == 1

        async_future = Future()  # type: Future
        conc_future = concurrent.futures.Future()  # type: futures.Future
        chain_future(conc_future, async_future)
        conc_future.set_result(1)
        result = yield async_future

# Generated at 2022-06-26 07:57:45.142173
# Unit test for function chain_future
def test_chain_future():
    my_future = Future()
    my_concurrent_future = futures.Future()
    chain_future(my_concurrent_future, my_future)

# Generated at 2022-06-26 07:57:52.513004
# Unit test for function chain_future
def test_chain_future():
    test_future = Future()
    test_conc_future = futures.Future()

    # Test if chain_future is able to chain two futures together
    # Test if chain_future is able to chain Future and ThreadpoolExecutor.Future together
    chain_future(test_future, test_conc_future)

    test_future.set_result("Hello World")

    assert "Hello World" == test_conc_future.result()

# Generated at 2022-06-26 07:57:54.705633
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    my_future = Future()
    my_future.set_result(42)
    future_set_result_unless_cancelled(my_future, 42)