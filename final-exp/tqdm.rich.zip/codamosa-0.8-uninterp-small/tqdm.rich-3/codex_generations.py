

# Generated at 2022-06-26 09:59:23.622932
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    tqdm_rich_0 = tqdm.rich.tqdm_rich(desc='test_tqdm_rich_reset')
    for i in tqdm_rich_0:
        tqdm_rich_0.reset(10)
        tqdm_rich_0.reset()
        tqdm_rich_0.reset(10)
        tqdm_rich_0.reset()
    tqdm_rich_0.close()
    tqdm_rich_0.reset(total=10)
    tqdm_rich_0.reset()


# Generated at 2022-06-26 09:59:29.642188
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    # Exception if task is not computable
    try:
        tqdm_rich_0.clear()
    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 09:59:33.753349
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test method clear of class tqdm_rich.
    """
    tqdm_rich_1 = tqdm_rich()
    # Test if clear can be called with no params
    tqdm_rich_1.clear()


# Generated at 2022-06-26 09:59:36.406789
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render()


# Generated at 2022-06-26 09:59:43.082919
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    additional_parameter_1 = ""
    additional_parameter_2 = False
    additional_parameter_3 = 1000
    obj = RateColumn(additional_parameter_1, additional_parameter_2, additional_parameter_3)
    ret = obj.render(additional_parameter_3)


# Generated at 2022-06-26 09:59:47.784450
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(None) == Text(f"? /s", style="progress.data.speed")


# Generated at 2022-06-26 09:59:51.341285
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t0 = tqdm_rich()
    if t0.disable:
        return
    t0.display()


# Generated at 2022-06-26 09:59:54.479023
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn(unit_scale=False, unit_divisor=1000)
    fraction_column_0.render()


# Generated at 2022-06-26 09:59:58.192035
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()



# Generated at 2022-06-26 09:59:59.608248
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()


# Generated at 2022-06-26 10:00:14.443925
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    tqdm_rich_0 = tqdm_rich()



# Generated at 2022-06-26 10:00:16.189409
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render({"task": {"completed": 0, "total": 2}}) == "0.0/2.0"


# Generated at 2022-06-26 10:00:17.962507
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    obj = tqdm_rich()
    obj.clear()


# Generated at 2022-06-26 10:00:21.269859
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:00:26.105915
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:00:27.946037
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    with FractionColumn() as _:
        pass


# Generated at 2022-06-26 10:00:36.368543
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.total = 100
    tqdm_rich_0.n = 50
    text = Text("0.5/2.3 G", style="progress.download")
    assert FractionColumn().render(tqdm_rich_0) == text


# Generated at 2022-06-26 10:00:40.515630
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:00:44.311512
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()



# Generated at 2022-06-26 10:00:46.372118
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Conditional branch exercise: if hasattr(self, '_prog'):
    # Conditional branch exercise: if not hasattr(self, '_prog'):
    pass


# Generated at 2022-06-26 10:01:03.710267
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import BarColumn, TimeElapsedColumn
    from .utils import format_dict
    tqdm_rich_0 = tqdm_rich(bar_width = 10,disable = True,format = "[{bar}] {percentage:.0f}% {description} Elapsed: {elapsed}, Remaining: {remaining}")
    tqdm_rich_0._console = Console()
    tqdm_rich_0._task_id = tqdm_rich_0._console.progress.add_task(description = "",bar_width = tqdm_rich_0.bar_width,bar_template = tqdm_rich_0.bar_format,total = None)
    tqdm_rich_0.n = 10
    tqdm_rich_0._dynamic

# Generated at 2022-06-26 10:01:08.852264
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_1 = FractionColumn()

    assert fraction_column_1.render(fraction_column_0) == None


# Generated at 2022-06-26 10:01:12.711425
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc0 = RateColumn()
    print(rc0.render(task=None))


test_case_0()
test_RateColumn_render()

# Generated at 2022-06-26 10:01:18.265678
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        tqdm_rich_0 = tqdm_rich()
        tqdm_rich_0.close()
    except TypeError:
        assert False, "Failure: tqdm_rich.clear() raises TypeError"


# Generated at 2022-06-26 10:01:23.567157
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc_1 = RateColumn(
        unit="", unit_scale=False, unit_divisor=1000)
    try:
        from rich import task
    except ImportError:
        warn("unable to test RateColumn.render, missing rich.task", TqdmExperimentalWarning)
        return
    task_1 = task.Task(description="", total=1, task_id=1, completed=0)
    text = rc_1.render(task_1)
    assert text in ("", "?")


# Generated at 2022-06-26 10:01:29.361131
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    # Test with argument value 0.0
    fraction_column_0.render()
    # Test with argument value 0.0
    fraction_column_0.render()


# Generated at 2022-06-26 10:01:32.887967
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test the method reset of class tqdm_rich.
    """
    for _ in tqdm_rich(total=10):
        pass
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()

# Generated at 2022-06-26 10:01:37.470924
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn()
    assert rateColumn.unit == ""
    assert rateColumn.unit_scale is False
    assert rateColumn.unit_divisor == 1000


# Generated at 2022-06-26 10:01:39.345466
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test case for method render of class FractionColumn
    """
    FractionColumn_instance_0 = FractionColumn()
    FractionColumn_instance_0.render(FractionColumn_instance_0)



# Generated at 2022-06-26 10:01:50.538178
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Initialization
    kwargs_0 = {}
    obj = RateColumn(**kwargs_0)
    # Case
    # 1 unit
    # 1.1 speed = 2
    args_1 = (2,)
    kwargs_1 = {}
    # Return
    assert obj.render(*args_1, **kwargs_1) == Text("2.0 /s", style="progress.data.speed")
    # 2 unit, unit_scale
    # 2.1 speed = 2
    args_2 = (2,)
    kwargs_2 = {"unit": "", "unit_scale": True}
    # Return
    assert obj.render(*args_2, **kwargs_2) == Text("2.0 /s", style="progress.data.speed")
    # 3 unit, unit_scale, unit_divis

# Generated at 2022-06-26 10:02:17.868084
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:02:20.647351
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn_render_0 = RateColumn()
    ratecolumn_render_0.render()


# Generated at 2022-06-26 10:02:22.743707
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:02:29.273975
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import track

    def test_case():
        tqdm_rich_0 = tqdm_rich(total=3, leave=True)
        tqdm_rich_0.reset()
        for x in range(1):
            sleep(1)
        tqdm_rich_0.reset(total=5)
        for x in range(1):
            sleep(1)
    # test
    with track(test_case) as task:
        task.expected = 5
        task.unit = 's'

# Generated at 2022-06-26 10:02:31.141683
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_instance = RateColumn()
    task_instance = ''
    rate_column_instance.render(task_instance)


# Generated at 2022-06-26 10:02:36.421705
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import _tqdm_rich as _instance
    tqdm_rich_1 = _instance.tqdm_rich
    assert isinstance(tqdm_rich_1, _instance.tqdm_rich)
    tqdm_rich_1.reset(total=int())


# Generated at 2022-06-26 10:02:44.247993
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from io import StringIO
    from unittest import TestCase


    class TestTqdmRichDisplay(TestCase):
        """Test: method display of class tqdm_rich."""
        # Pickling tests
        def test_pickle(self):
            """Test: Pickling support."""
            self.pickle_ok(tqdm_rich(total=100))
            self.pickle_ok(tqdm_rich(total=100), protocol=2)
            self.pickle_fail(tqdm_rich())  # total=None not supported (for now)


        # __init__ tests
        def test_constructor_defaults(self):
            """Test: tqdm_rich() with defaults."""
            disp = tqdm_rich()

# Generated at 2022-06-26 10:02:50.167409
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    unit_scale = 'Y'
    unit_divisor = 100
    completed = 'Y'
    total = 'Y'
    FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
    Text(f"{completed}/{total} {suffix}", style="progress.download")


# Generated at 2022-06-26 10:02:55.294060
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    if tqdm_rich_1.disable == False:
        assert tqdm_rich_1.display() == None
    else:
        return



# Generated at 2022-06-26 10:03:01.664334
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1._task = type('_task', (object,), {'completed': 1, 'total': 1})
    tqdm_rich_1._task.completed = 1
    tqdm_rich_1._task.total = 1
    tqdm_rich_1.render(tqdm_rich_1._task)


# Generated at 2022-06-26 10:03:29.211740
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    for i in tqdm_rich(range(10)):
        pass


# Generated at 2022-06-26 10:03:31.484354
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    total = 10
    for i in tqdm_rich(total=total):
        assert(i < total)



# Generated at 2022-06-26 10:03:42.087458
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    total = 3
    unit = "B"
    unit_scale = False
    unit_divisor = 1000
    speed = 2
    rateColumn_obj = RateColumn(unit,unit_scale,unit_divisor)
    task = std_tqdm(range(3), unit_scale=False, unit_divisor=1000, leave=False)
    task.update(total=total, n=speed)
    assert rateColumn_obj.render(task) == Text("2.0 B/s", style="progress.data.speed")

if __name__ == "__main__":
    test_case_0()
    test_RateColumn_render()

# Generated at 2022-06-26 10:03:46.617137
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress

    fc0 = FractionColumn()
    p0 = Progress()
    p0.total = 1
    p0.completed = 1
    assert fc0.render(p0) == Text('1.0/1.0 ', style='progress.download')

    fc1 = FractionColumn(unit_scale=True)
    p1 = Progress()
    p1.total = 1
    p1.completed = 0
    assert fc1.render(p1) == Text('0.0/1.0 ', style='progress.download')

    fc2 = FractionColumn(unit_scale=True, unit_divisor=1000)
    p2 = Progress()
    p2.total = 1000000000
    p2.completed = 1000000

# Generated at 2022-06-26 10:03:54.601439
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import random
    for size in [random.randint(0, 1000) for _ in range(100)]:
        total = random.randint(0, 1000)
        with tqdm_rich(total=total) as t:
            assert t.total == total
            t.reset(total=size)
            assert t.total == size



# Generated at 2022-06-26 10:03:58.046089
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_1 = tqdm_rich()
    f = FractionColumn()
    f.render(tqdm_rich_1)


# Generated at 2022-06-26 10:04:00.057337
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:04:01.661932
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    obj = tqdm_rich()
    obj.clear()


# Generated at 2022-06-26 10:04:03.822224
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:04:05.899941
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    task = None
    assert rate_column.render(task)


# Generated at 2022-06-26 10:05:00.089355
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_instance = RateColumn()
    RateColumn_instance.render()


if __name__ == "__main__":
    test_case_0()
    test_RateColumn_render()

# Generated at 2022-06-26 10:05:07.250391
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.total = 1000
    tqdm_rich_0.n = 500
    tqdm_rich_0.last_print_n = 0
    tqdm_rich_0.dynamic_ncols = False
    tqdm_rich_0.miniters = 1
    tqdm_rich_0.avg_time = 1.0
    tqdm_rich_0.last_print_t = 2.0
    tqdm_rich_0.avg_size = 100
    tqdm_rich_0.dynamic_miniters = False
    tqdm_rich_0.mininterval = 0.0
    tqdm_rich_0.maxinterval = 20.0
    t

# Generated at 2022-06-26 10:05:09.763865
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn()
    fraction_column.render('task')


# Generated at 2022-06-26 10:05:12.374322
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm._tqdm import trange

    tr = trange(10000, disable=True, gui=True)
    for i in tr:
        tr.display()



# Generated at 2022-06-26 10:05:15.062166
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    def test_display_function_0():
        tqdm_rich_0.display()
    test_display_function_0()


# Generated at 2022-06-26 10:05:16.533749
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    reset_0 = tqdm_rich.reset()
    reset_1 = tqdm_rich.reset(total=1)


# Generated at 2022-06-26 10:05:27.881809
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich()
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_2.display()
    tqdm_rich_3 = tqdm_rich()
    tqdm_rich_3.display()
    tqdm_rich_4 = tqdm_rich()
    tqdm_rich_4.display()
    tqdm_rich_5 = tqdm_rich()
    tqdm_rich_5.display()
    tqdm_rich_6 = tqdm_rich()
    tqdm_rich_

# Generated at 2022-06-26 10:05:29.381426
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r_column = RateColumn()
    r_column.render(20)


# Generated at 2022-06-26 10:05:39.368664
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    with tqdm_rich_1:
        try:
            tqdm_rich_1.display()
        except AttributeError as e:
            pass
        tqdm_rich_1.disable = True
        try:
            tqdm_rich_1.display()
        except AttributeError as e:
            pass
        tqdm_rich_1.disable = False
        tqdm_rich_1.desc = 'a'
        try:
            tqdm_rich_1.display()
        except AttributeError as e:
            pass
        tqdm_rich_1.disable = True
        try:
            tqdm_rich_1.display()
        except AttributeError as e:
            pass
        tqdm_rich

# Generated at 2022-06-26 10:05:41.822441
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_display_0 = tqdm_rich()
    tqdm_rich_display_0.display()


# Generated at 2022-06-26 10:07:39.684583
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:07:40.195408
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    assert True


# Generated at 2022-06-26 10:07:41.321392
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(range(10))
    t.display()


# Generated at 2022-06-26 10:07:43.633220
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn_0 = RateColumn()
    ratecolumn_0.render()



# Generated at 2022-06-26 10:07:44.318353
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    assert tqdm_rich().display


# Generated at 2022-06-26 10:07:48.910232
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.disable = False
    tqdm_rich_1.desc = "N/A"
    tqdm_rich_1.dynamic_miniters = False
    tqdm_rich_1.gui = True
    tqdm_rich_1.leave = False
    tqdm_rich_1.miniters = 1
    tqdm_rich_1.mininterval = 0
    tqdm_rich_1.maxinterval = 10
    tqdm_rich_1.mininterval = 0
    tqdm_rich_1.maxinterval = 10
    tqdm_rich_1.n = 0
    tqdm_rich_1.total = None
    tqdm_rich_1

# Generated at 2022-06-26 10:07:50.223429
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    d = dict()
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:07:51.942465
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()

# Generated at 2022-06-26 10:07:55.703803
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():

    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_2 = tqdm_rich()
    
    tqdm_rich_1.display()
    tqdm_rich_2.display()
    

# Generated at 2022-06-26 10:07:57.678229
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn = FractionColumn()
    # *args, **kwargs
    # self.render(task)
    raise Exception("Test not implemented!")
