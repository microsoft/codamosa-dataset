

# Generated at 2022-06-26 09:59:23.362778
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    print("testing display")
    test_case_1()


# Generated at 2022-06-26 09:59:35.637894
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render("") == Text("? ", style="progress.data.speed")
    assert RateColumn("").render("") == Text("? /s", style="progress.data.speed")
    assert RateColumn("", False).render("") == Text("? /s", style="progress.data.speed")
    assert RateColumn("", True).render("") == Text("? ", style="progress.data.speed")
    assert RateColumn("", False, 1000).render("") == Text("? /s", style="progress.data.speed")
    assert RateColumn("", True, 1000).render("") == Text("? ", style="progress.data.speed")
    assert RateColumn("", False, 1024).render("") == Text("? /s", style="progress.data.speed")
    assert RateColumn("", True, 1024).render("") == Text

# Generated at 2022-06-26 09:59:40.180123
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = ...  # type: Optional[int]
    tqdm_rich_0.reset(total=total)


# Generated at 2022-06-26 09:59:42.786848
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich() as n:
        n.reset(total=1)


# Generated at 2022-06-26 09:59:45.929232
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.clear()


# Generated at 2022-06-26 09:59:52.818074
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Initialise tqdm_rich instance
    tqdm_rich_instance = tqdm_rich()
    # Run tqdm_rich method reset
    tqdm_rich_instance.reset()


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-26 09:59:54.562263
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render()



# Generated at 2022-06-26 09:59:57.710940
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():

    fC = FractionColumn()
    fC.render()
    print(fC.render())


# Generated at 2022-06-26 10:00:01.491399
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:00:03.015327
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_class = FractionColumn()
    task = Progress(completed=1.0, total=1.0)
    test_class.render(task=task)


# Generated at 2022-06-26 10:00:10.984770
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    global tqdm_rich_0; tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:00:13.647347
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm_rich([0, 1]) :
        pass
    for i in tqdm_rich([0, 1]) :
        pass
    for i in tqdm_rich([0, 1]) :
        pass
    for i in tqdm_rich([0, 1]) :
        pass


# Generated at 2022-06-26 10:00:15.494135
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    fc.render(task=None)


# Generated at 2022-06-26 10:00:28.357141
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Test case where `self.disable` is False, attribute `_task_id` exists and
    # method `update` of instance `self._prog` is called.
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = False
    tqdm_rich_0._task_id = "posx_vtx_pf"
    tqdm_rich_0._task_id = "[progress.description]{task.description}"
    tqdm_rich_0.n = 630
    tqdm_rich_0.desc = ";k[ph"
    tqdm_rich_0._prog.update(tqdm_rich_0._task_id, 630, tqdm_rich_0.desc)
    assert tqdm_rich_0.disable

# Generated at 2022-06-26 10:00:39.808229
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress, FilesizeColumn, TimeRemainingColumn, \
        TimeElapsedColumn
    from rich.console import Console
    from rich.progress import Progress, TimeRemainingColumn, TimeElapsedColumn
    from rich.table import Table
    from rich.text import Text
    from rich.progress import (
        BarColumn, Column, ColumnSet, Progress, TextColumn, TimeRemainingColumn,
        TimeElapsedColumn,
    )
    from rich.progress import (
        BarColumn, Column, ColumnSet, Progress, TextColumn, TimeRemainingColumn,
        TimeElapsedColumn,
    )
    console = Console(highlight=False)
    console.print('Starting...')

# Generated at 2022-06-26 10:00:44.294227
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert tqdm_rich_0.display() is not NotImplementedError


# Generated at 2022-06-26 10:00:46.955822
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:00:49.517107
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    r.render()


# Generated at 2022-06-26 10:00:55.098624
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r_3 = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    try:
        r_4 = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    except TypeError:
        pass
    r_5 = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    r_2 = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    r_1 = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    r_3.render(r_1)
    r_3.render(r_2)
    r_3.render(r_3)
    r_3.render(r_4)

# Generated at 2022-06-26 10:00:59.549517
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_unit_test = tqdm_rich()
    fraction_column = FractionColumn()
    render_result = fraction_column.render(tqdm_rich_unit_test)
    print("Result of class FractionColumn method render:", render_result)


# Generated at 2022-06-26 10:01:09.739729
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    task = Progress(fmt="{task.completed}/{task.total}")
    task._completed = 1
    task._total = 2
    assert fc.render(task) == Text("1/2", style="progress.download")


# Generated at 2022-06-26 10:01:14.698239
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()

    # Unit test for method close of class tqdm_rich


# Generated at 2022-06-26 10:01:19.679680
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    f"{RateColumn_0.render(None):{None}}"
    '? '
    f"{RateColumn_0.render(None):{None}}"
    '? '


# Generated at 2022-06-26 10:01:22.370655
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print("RateColumn.render")
    column = RateColumn()
    print(column.render(None))


# Generated at 2022-06-26 10:01:29.973155
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_tqdm_rich = tqdm_rich()
    total = 10
    tqdm_rich_tqdm_rich.reset(total=total)
    assert tqdm_rich_tqdm_rich.n == 0
    assert tqdm_rich_tqdm_rich.total == 10


# Generated at 2022-06-26 10:01:31.990657
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.clear()


# Generated at 2022-06-26 10:01:36.311580
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:01:39.700781
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display(_=0)


# Generated at 2022-06-26 10:01:46.358807
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    # Code in init of tqdm_rich.
    # Code in init of tqdm.
    # Code in init of tqdm_gui.
    # Code in init of tqdm.
    # Code in init of tqdm_gui.
    tqdm_rich_1._prog = Progress(*None, transient=not tqdm_rich_1.leave)
    tqdm_rich_1._prog.__enter__()
    tqdm_rich_1._task_id = tqdm_rich_1._prog.add_task(tqdm_rich_1.desc or "", format_dict=tqdm_rich_1.format_dict)
    # Code in close of tqdm_rich.
    # Code in close

# Generated at 2022-06-26 10:01:49.373844
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich(disable=True)
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:02:03.110841
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Print error message if FractionColumn.render(task) fails
    try:
        FractionColumn().render(1)
    except Exception as e:
        print('FractionColumn.render() raised: ' + str(e))
        raise e
    try:
        FractionColumn(0).render(1)
    except Exception as e:
        print('FractionColumn.render() raised: ' + str(e))
        raise e


# Generated at 2022-06-26 10:02:06.115572
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich(total=4)
    assert tqdm_rich_0.display() is None


# Generated at 2022-06-26 10:02:08.755971
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich
    tqdm_rich_0.display()
    # This test case passes



# Generated at 2022-06-26 10:02:22.032128
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_inst = tqdm_rich()
    tqdm_rich_inst.desc = None
    tqdm_rich_inst.unit = ""
    tqdm_rich_inst.unit_scale = False
    tqdm_rich_inst.unit_divisor = 1000
    tqdm_rich_inst.postfix = None
    tqdm_rich_inst.total = None
    tqdm_rich_inst.leave = True
    tqdm_rich_inst.disable = False
    tqdm_rich_inst.gui = True
    tqdm_rich_inst.mininterval = 0.1
    tqdm_rich_inst.miniters = None
    tqdm_rich_inst.dynamic_ncols = False

# Generated at 2022-06-26 10:02:30.530209
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import re
    import textwrap
    import io
    import sys
    import unittest
    import inspect
    import logging

    class TqdmRichTester(unittest.TestCase):
        """
        This class defines the test cases for the `display` method of class `tqdm_rich`.
        """
        @classmethod
        def setUpClass(cls):
            print('setUpClass')
        @classmethod
        def tearDownClass(cls):
            print('tearDownClass')
        def setUp(self):
            print('setUp')
        def tearDown(self):
            print('tearDown')
        def test_display_method(self):
            self.assertTrue(inspect.isfunction(tqdm_rich.display), msg='`display` should be a function')


# Generated at 2022-06-26 10:02:37.243710
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = True
    
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.disable = False
    assert tqdm_rich_1._prog.__enter__() == None
    tqdm_rich_1._prog.__exit__(None, None, None)
    


# Generated at 2022-06-26 10:02:40.782022
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fractioncolumn_0 = FractionColumn()
    task = 0
    try:
        fractioncolumn_0.render(task)
    except Exception:
        pass


# Generated at 2022-06-26 10:02:53.753821
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # initialization
    bar_column_1 = BarColumn(bar_width=None)
    text_2 = Text('[progress.description]{task.description}', '[progress.percentage]{task.percentage:>4.0f}%',
                  BarColumn(bar_width=None), '', '', '', '', '')
    progress_column_3 = ProgressColumn()
    progress_column_4 = ProgressColumn()
    text_5 = Text('[progress.description]{task.description}', '[progress.percentage]{task.percentage:>4.0f}%',
                  BarColumn(bar_width=None), '', '', '', '', '')
    progress_column_6 = ProgressColumn()
    progress_column_7 = ProgressColumn()

# Generated at 2022-06-26 10:02:55.941670
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:03:06.658474
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # tqdm_rich_0 = tqdm_rich()
    assert isinstance(tqdm_rich_0, tqdm_rich)
    f = lambda self, total=None: None
    tqdm_rich_0.reset = f
    f = tqdm_rich_0.reset
    assert callable(f)
    assert isinstance(f, type(lambda: None))
    assert f() is None
    try:
        tqdm_rich_0.reset(total=10)
    except TypeError:
        pass  # expected


# Generated at 2022-06-26 10:03:27.970648
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys

    try:
        t = tqdm_rich(range(42), file=sys.stdout, leave=True,
                      desc='testing display')
        for i in t:
            pass
    except Exception as e:
        return False
    return True



# Generated at 2022-06-26 10:03:39.005722
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_1 = tqdm_rich()
    assert(tqdm_rich_1.total == 0)
    assert(tqdm_rich_1.n == 0)
    tqdm_rich_1.n = 2
    tqdm_rich_1.total = 4
    r = tqdm_rich_1.n / tqdm_rich_1.total
    r2 = tqdm_rich_1._formatter(tqdm_rich_1.n)
    r3 = tqdm_rich_1._formatter(tqdm_rich_1.total)
    assert(r == 0.5)
    assert(r2 == '2')
    assert(r3 == '4')
    

# Generated at 2022-06-26 10:03:42.823174
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn_instance = FractionColumn()
    FractionColumn_instance.render(task=None)


# Generated at 2022-06-26 10:03:45.897293
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_column_0 = FractionColumn()
    str_0 = Text()
    task_0 = BarColumn()
    str_1 = progress_column_0.render(task_0)
    assert str_0 == str_1


# Generated at 2022-06-26 10:03:47.789920
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
  tqdm_rich_0 = tqdm_rich()




# Generated at 2022-06-26 10:03:52.624353
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    p = tqdm_rich()
    fc = FractionColumn()
    fc.render(p)



# Generated at 2022-06-26 10:03:54.852842
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn()
    task = None
    rateColumn.render(task)


# Generated at 2022-06-26 10:03:57.159739
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    print(FractionColumn().render(task = None))


# Generated at 2022-06-26 10:03:59.245509
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:04:00.560934
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest import mock
    tqdm_rich_0 = tqdm_rich()
    with mock.patch('builtins.print'):
        total = None
        tqdm_rich_0.reset(total)


# Generated at 2022-06-26 10:05:18.777526
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in tqdm_rich_0.reset():
        pass


# Generated at 2022-06-26 10:05:23.115853
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    try:
        tqdm_rich_1.display()
    except tqdm_rich_1.disable:
        assert True
    else:
        assert False


# Generated at 2022-06-26 10:05:24.701754
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_display_0 = tqdm_rich()
    tqdm_rich_display_0.display()


# Generated at 2022-06-26 10:05:27.598311
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # TODO: does not verify output
    FractionColumn_render = FractionColumn().render(task=None)


# Generated at 2022-06-26 10:05:29.488628
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    assert rate_column_0.render() == Text('? /s', style='progress.data.speed')


# Generated at 2022-06-26 10:05:36.429659
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from rich.progress import TaskState

    rateColumn_0 = RateColumn("", False, 1000)
    taskState_0 = TaskState("", 0, 0, 0, 0, None, None)
    taskID_0 = TaskID(taskState_0)
    rateColumn_0.render(taskID_0)

# Generated at 2022-06-26 10:05:42.607018
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Initialize a new object of class
    tqdm_rich_0 = tqdm_rich()
    # Call method render of object tqdm_rich_0
    tqdm_rich_0.FractionColumn.render()


# Generated at 2022-06-26 10:05:50.859318
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert not tqdm_rich_0.disable
    assert tqdm_rich_0.dynamic_miniters
    assert not tqdm_rich_0.ascii
    assert not tqdm_rich_0.unit_scale
    assert tqdm_rich_0.unit_divisor == 1000
    assert tqdm_rich_0.gui
    assert not tqdm_rich_0.leave
    assert tqdm_rich_0.mininterval == 0.1
    assert tqdm_rich_0.maxinterval == 10.0
    assert tqdm_rich_0.miniters == 0
    assert tqdm_rich_0.ascii

# Generated at 2022-06-26 10:05:52.242464
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    count = 0
    for _ in trange_1:
        count += 1
    assert count == 2


# Generated at 2022-06-26 10:05:54.152064
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn = RateColumn('unit')
    task = None # type: ignore
    ratecolumn.render(task)


# Generated at 2022-06-26 10:06:55.768547
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    '''Test for method FractionColumn.render of class FractionColumn'''
    class tqdm_rich_1(tqdm_rich):
        '''
        dummy class, made for testing purposes
        '''
        def __init__(self, *args, **kwargs):
            self.disable = bool(kwargs.get('disable', False))
            self.total = kwargs.pop('total', None)
            super(tqdm_rich_1, self).__init__(*args, **kwargs)

        def __enter__(self, *args, **kwargs):
            return self

        def __exit__(self, *args, **kwargs):
            pass


# Generated at 2022-06-26 10:06:57.565182
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    current_instance = RateColumn()
    current_instance.render(None)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:06:58.943278
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render()


# Generated at 2022-06-26 10:07:03.152210
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    obj_RateColumn = RateColumn()
    obj_task_0 = object()
    obj_task_0.speed = None
    ret_result_0 = obj_RateColumn.render(obj_task_0)
    assert ret_result_0 is not None
    obj_task_1 = object()
    obj_task_1.speed = None
    ret_result_1 = obj_RateColumn.render(obj_task_1)
    assert ret_result_1 is not None
    obj_task_2 = object()
    obj_task_2.speed = None
    ret_result_2 = obj_RateColumn.render(obj_task_2)
    assert ret_result_2 is not None


# Generated at 2022-06-26 10:07:04.271997
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn.render(0)


# Generated at 2022-06-26 10:07:11.907336
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Tests that the speed is rendered correctly."""

    rc = RateColumn(unit="b", unit_scale=False, unit_divisor=1000)

    assert rc.render(task=object()) == Text("0 b/s", style="progress.data.speed")
    assert rc.render(task=object()) == Text("0 b/s", style="progress.data.speed")

# Generated at 2022-06-26 10:07:14.062547
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()

# Generated at 2022-06-26 10:07:17.374714
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.n = 3
    tqdm_rich_1.desc = "xyz"
    tqdm_rich_1.display()

# Generated at 2022-06-26 10:07:25.382040
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_0 = tqdm_rich()
    task_0 = object()
    tqdm_rich_0.unit_scale = int(False)
    tqdm_rich_0.unit_divisor = int(1000)
    tqdm_rich_1 = tqdm_rich()
    task_1 = object()
    tqdm_rich_1.unit_scale = int(True)
    tqdm_rich_1.unit_divisor = int(1000)
    tqdm_rich_2 = tqdm_rich()
    task_2 = object()
    tqdm_rich_2.unit_scale = int(False)
    tqdm_rich_2.unit_divisor = int(1024)
    tqdm_rich_3 = tqdm_

# Generated at 2022-06-26 10:07:28.576633
# Unit test for method render of class RateColumn
def test_RateColumn_render():
  rate_column = RateColumn()
  class Mock:
    speed = None
  mock = Mock()
  assert rate_column.render(mock) == Text(f"? {rate_column.unit}/s", style="progress.data.speed")

