

# Generated at 2022-06-26 09:59:25.657970
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm = tqdm_rich()


# Generated at 2022-06-26 09:59:35.367069
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from copy import copy
    desc = "test_tqdm_rich_reset"
    with Progress('test_tqdm_rich_reset') as progress:
        progress.add_task(desc, total=10)
        progress.update(desc, completed=5)
        # Will create a new tqdm with the same already-completed state
        tqdm_rich(list("abcde"), total=10, desc=desc).close()
        tqdm_rich(list("abcde"), desc=desc).close()
        progress.update(desc, completed=10)
        progress.update(desc, completed=0)


# Generated at 2022-06-26 09:59:38.136795
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    instance = tqdm_rich(range(10))
    instance.display()


# Generated at 2022-06-26 09:59:41.547449
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_1 = FractionColumn()
    test_task = ProgressColumn.ProgressTask()
    test_task.completed = 5
    test_task.total = 15
    text_formatted = Text(
        "0.3/1.0 ",
        style="progress.download")
    assert fraction_column_1.render(test_task) == text_formatted



# Generated at 2022-06-26 09:59:48.898095
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(unit='test')
    assert t.disable
    t.disable = False
    t.desc = 'test'
    t.n = 4
    t.total = 9
    assert t.desc == 'test'
    assert t.n == 4
    assert t.total == 9
    t.display()
    t.close()
    t.disable = True
    t.clear()
    t.close()



# Generated at 2022-06-26 09:59:53.570046
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_test = tqdm_rich()
    tqdm_test.n = 0
    tqdm_test.desc = 'dummy'
    tqdm_test.display()


# Generated at 2022-06-26 09:59:59.267287
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    prompt = "? "
    input_ = "0.5/2.3 G"
    expected = "0.5/2.3 G"
    actual = FractionColumn().render(input_)
    assert expected == actual


# Generated at 2022-06-26 10:00:06.307193
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    task_0 = Progress(
        BarColumn(),
        FractionColumn(),
        "[",
        TimeElapsedColumn(),
        "<",
        TimeRemainingColumn(),
        ",",
        RateColumn(),
        "]"
    )
    task_0.start()
    json_output = {}
    assert type(fraction_column_0.render(task_0)) == Text



# Generated at 2022-06-26 10:00:10.434363
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich([1,2,3])
    assert isinstance(t, tqdm_rich)
    t.clear()
    t.close()


# Generated at 2022-06-26 10:00:19.303941
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm
    from .utils import _range
    from .std import TqdmTypeError, TqdmExperimentalWarning
    from .std import is_interactive

    tqdm_obj = tqdm(total=1000)
    with tqdm(total=1000) as t:
        assert t._total == 1000
        assert t.n == 0

    with tqdm(total=0, mininterval=1) as t:
        t.update(1)
        assert t.n == 1
        assert t.last_print_n == t.n

    with tqdm( total=0) as t:
        assert t.unit_scale == False
        t.update(1)
        assert t.n == 1
        assert t.last_print_n == t.n


# Generated at 2022-06-26 10:00:25.808008
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render(task=None)


# Generated at 2022-06-26 10:00:28.781645
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn.render(fraction_column_0, {}) is None

# test_case_0()

test_FractionColumn_render()

# Generated at 2022-06-26 10:00:37.451088
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Description
    # Method to update the GUI display
    # Method signature
    # def display(self, *_, **__):
    # Example
    # t = tqdm(range(100))
    # for i in t:
    #     # update GUI display
    #     t.display()
    #     sleep(0.1)
    # t.close()

    pass # test implemented in test_rich.py

# Generated at 2022-06-26 10:00:47.117411
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Total equal to total of task should reset progress bar
    progress_test = tqdm_rich(total=8)
    progress_test.reset(total=8)
    assert progress_test.n == 0
    progress_test.update(8)

    # Total less than total of task should reset progress bar, but with new total
    progress_test.reset(total=4)
    assert progress_test.n == 0
    progress_test.update(4)


# Generated at 2022-06-26 10:00:49.775517
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(10)
    t.reset()


# Generated at 2022-06-26 10:00:53.038556
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_1 = RateColumn(unit='b/s')
    rate_column_2 = RateColumn(unit=' MB/s')
    rate_column_3 = RateColumn(unit=' MB/s', unit_scale=False)


# Generated at 2022-06-26 10:00:57.220663
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_transfer_speed_0 = RateColumn()


if __name__ == "__main__":
    from pytest import main
    main([__file__])

# Generated at 2022-06-26 10:01:00.238049
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render() == Text('0 /s', style='progress.data.speed')

# Generated at 2022-06-26 10:01:02.124969
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert True

# Generated at 2022-06-26 10:01:04.726992
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn('1/s')
    rate_column_0.render(0)

# Generated at 2022-06-26 10:01:15.315259
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_1 = FractionColumn()
    # task = ProgressTask()
    # assertEqual(fraction_column_1.render(task), '0.0/0.0 ')
    print(fraction_column_1.render(task))



# Generated at 2022-06-26 10:01:16.981878
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_case_0()

    fraction_column_0 = FractionColumn()

    task = None

    # Call to render
    result = fraction_column_0.render(task)


# Generated at 2022-06-26 10:01:19.879007
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    test_range = tqdm_rich(total=100)
    test_range.reset()
    assert test_range.total == 100

# Generated at 2022-06-26 10:01:22.006424
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    test_tqdm_rich_display_0()


# Generated at 2022-06-26 10:01:28.965153
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    tqd = tqdm_rich(total=5, desc="Fetching data")
    for i in range(5):
        tqd.update(1)


if __name__ == "__main__":
    for i in trange(5):
        print(i)

# Generated at 2022-06-26 10:01:31.472355
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render('None')
    rate_column_0 = RateColumn()



# Generated at 2022-06-26 10:01:39.027818
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    fraction_column_0 = FractionColumn()
    kwargs = {}
    kwargs['unit_scale'] = False
    kwargs['unit_divisor'] = 1000
    tqdm_rich_0 = tqdm_rich(**kwargs)
    tqdm_rich_0.reset()

# Generated at 2022-06-26 10:01:40.321399
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    obj = tqdm_rich()
    obj.display()

# Generated at 2022-06-26 10:01:44.440268
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit='unit_0', unit_scale=True)
    rate_column_0.render()


if __name__ == "__main__":
    test_RateColumn_render()
    test_case_0()

# Generated at 2022-06-26 10:01:50.275147
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    text_0 = Text("? B/s", style="progress.data.speed")
    rate_column_0 = RateColumn("S")
    with Progress() as progress_0:
        task_0 = progress_0.add_task("Task 0", total=10)
    output_0 = rate_column_0.render(task_0)
    assert output_0 == text_0

# Generated at 2022-06-26 10:02:09.030618
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import rich
    import rich.progress

    global tqdm_rich

    progress = progress_0 = rich.progress.Progress("[progress.description]{task.description}",
                                                     "[progress.percentage]{task.percentage:>4.0f}%",
                                                     rich.progress.BarColumn(bar_width=None),
                                                     rich.progress.FractionColumn(unit_scale=False,
                                                     unit_divisor=1000),
                                                     "[", rich.progress.TimeElapsedColumn(),
                                                     "<", rich.progress.TimeRemainingColumn(),
                                                     ",",
                                                     rich.progress.RateColumn(unit="B",
                                                                              unit_scale=False,
                                                                              unit_divisor=1000), "]")
    tqdm

# Generated at 2022-06-26 10:02:11.072585
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:02:13.122056
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_obj = tqdm_rich(total=10)
    tqdm_obj.reset(None)



# Generated at 2022-06-26 10:02:18.178365
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    task = {'completed': 0.0, 'total': 1.0}
    fraction_column_0.render(task)

# Generated at 2022-06-26 10:02:23.432092
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(100, disable=True) as t:
        t.display()
        t.display(0.5)
        t.display(1)
        t.display(1.51515)
        t.display(2.0)
        t.display(2.5)


# Generated at 2022-06-26 10:02:28.467395
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=10)
    t.update(0)
    t.update(9)
    t.update(10)
    t.update(11, bar_format='{n}')
    t.update(-9)
    t.update(-11, bar_format='{n}')
    t.close()


# Generated at 2022-06-26 10:02:40.340360
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # examples of input values for method display of class tqdm_rich
    example_values = [('string',), ('string',), ('string',), ('string',), ('string',), ('string',), ('string',), ('string',), ('string',), ('string',)]
    # prepare the input arguments
    arg_input = [('value', example_values[0]), ('value', example_values[1]), ('value', example_values[2]), ('value', example_values[3]), ('value', example_values[4]), ('value', example_values[5]), ('value', example_values[6]), ('value', example_values[7]), ('value', example_values[8]), ('value', example_values[9])]

# Generated at 2022-06-26 10:02:50.168033
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # instantiate class
    fraction_column_1 = FractionColumn()
    rate_column_0 = RateColumn()
    time_elapsed_column_0 = TimeElapsedColumn()
    time_remaining_column_0 = TimeRemainingColumn()
    task_1 = fraction_column_1.render(rate_column_0)
    tqdm_rich_2 = tqdm_rich(time_elapsed_column_0)
    task_2 = fraction_column_1.render(time_remaining_column_0)

    # call method
    tqdm_rich_2.reset(total=task_1)
    tqdm_rich_2.reset(total=task_2)


# Generated at 2022-06-26 10:02:52.759195
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit='1/s', unit_scale=False, unit_divisor=1000)
    tm_0 = rate_column_0.render(Progress.task)  # noqa: F841


# Generated at 2022-06-26 10:02:56.751121
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    obj = tqdm_rich(total=1)
    obj.disable = True
    obj.close()
    obj.disable = False
    obj.close()
    if hasattr(obj, '_prog'):
        obj.reset()
        obj.reset(total=100)

# Generated at 2022-06-26 10:03:16.632084
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    text_0 = rc.render(arg0=None)
    text_1 = str(text_0)
    assert text_1 == "? /s"


# Generated at 2022-06-26 10:03:22.364337
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    a = tqdm_rich('a')
    a.reset(total=100)
    a.close()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:03:24.564686
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    x = tqdm_rich(total=1)
    x.display()
    x.close()

# Generated at 2022-06-26 10:03:37.630139
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        bar_column,
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), ",",
        RateColumn(), "]",
        transient=True
    )
    progress.__enter__()
    task_id = progress.add_task("", total=10, unit="B", unit_scale=True, ncols=100)
    for i in range(10):
        progress.update(task_id, completed=float(i + 1))
        sleep(0.5)
    progress.__exit__(None, None, None)
    pass


if __name__ == "__main__":
    from time import sleep
   

# Generated at 2022-06-26 10:03:41.593775
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render()


# Generated at 2022-06-26 10:03:44.199268
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    fraction_column_0 = FractionColumn()
    traceback_0 = FractionColumn()
    assert fraction_column_0 == traceback_0

# Generated at 2022-06-26 10:03:44.970323
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn()
    fraction_column.render()


# Generated at 2022-06-26 10:04:00.015735
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Instantiating a tqdm_rich object without total
    try:
        t = tqdm_rich(["a", "b"], position=0, leave=True)
        assert True
    except Exception:
        assert False
    t._task_id = 1.0

    # Instantiating a Progress object to display
    try:
        new_prog = Progress("[size=30][progress.description]{task.description}"
                            "[progress.percentage]{task.percentage:>27.0f}%",
                            BarColumn(bar_width=None),
                            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
                            transient=True)
        assert True
    except Exception:
        assert False

    # Checking signature of display method

# Generated at 2022-06-26 10:04:04.298649
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Initialization
    # tqdm_rich_0 is of type tqdm_rich with argument 
    tqdm_rich_0 = tqdm_rich()
    # Output of method display of tqdm_rich_0
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:04:07.328924
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    x = tqdm_rich(total = 2, desc = "Test 1")
    x.disable = True
    x.display()
    x.disable = False
    x.display()


# Generated at 2022-06-26 10:04:49.922200
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm.reset(total=10)


if __name__ == "__main__":
    for i in trange(10):
        pass
    for i in trange(10, desc="Step %d" % i):
        pass
    for i in trange(10, mininterval=.6, miniters=3):
        pass
    for i in trange(10, position=5, total=100, desc="Step %d" % i):
        pass
    for i in trange(10, leave=False):
        pass
    for i in trange(10, disable=True):
        pass
    for i in trange(10, bar_format="$desc $bar: $percentage"):
        pass

    # disable

# Generated at 2022-06-26 10:05:00.398192
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # test for display of class tqdm_rich
    # test without disable = True and without iterable
    TQDMR0 = tqdm_rich(disable = False)
    TQDMR0.display()
    assert TQDMR0._prog.__exit__ is None
    # test without disable = False and with iterable
    TQDMR1 = tqdm_rich(disable = False, iterable = range(5))
    TQDMR1.display()
    assert TQDMR1._prog.__exit__ is not None
    # test disable = True
    TQDMR2 = tqdm_rich(disable = True)
    TQDMR2.display()
    assert TQDMR2._prog.add_task is None
    assert TQDMR2.display is not None

# Generated at 2022-06-26 10:05:03.703700
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    stdout = __import__('sys').stdout
    if stdout:
        t_display = tqdm_rich(total=1, file=stdout)
        t_display.display(True, True)

test_tqdm_rich_display()

# Generated at 2022-06-26 10:05:06.670822
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    obj = tqdm_rich()
    obj.disable = False
    obj._prog = ""
    obj._task_id = ""
    obj.clear()
    obj.display()
    assert hasattr(obj, '_prog') == True
    obj.disable = True
    obj.display()
    return



# Generated at 2022-06-26 10:05:16.271261
# Unit test for method display of class tqdm_rich

# Generated at 2022-06-26 10:05:20.936316
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Initialize the class object
    tqdm_rich_object0 = tqdm_rich(total=None)

    # Call method display of class tqdm_rich
    tqdm_rich_object0.display()

# Generated at 2022-06-26 10:05:23.446043
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=5) as tbar:
        tbar.reset(total=10)
        for _ in range(5):
            tbar.update(1)

# Generated at 2022-06-26 10:05:24.982789
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render(ProgressTask(0, 1, 0, 0))



# Generated at 2022-06-26 10:05:27.666341
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render()


# Generated at 2022-06-26 10:05:36.288703
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import Progress
    except ImportError:  # pragma: no cover
        pass
    else:
        screen = Progress(
            "[progress.description]{task.description}",
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
        )
        screen.__enter__()
        task_id = screen.add_task("Task 1", total=100)
        screen.update(task_id, completed=12)



# Generated at 2022-06-26 10:06:52.324441
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # New instantiation
    obj = tqdm_rich(total=2)
    # Test the attribute display
    obj.display()


# Generated at 2022-06-26 10:07:02.442831
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    fraction_column_0 = FractionColumn()

# Generated at 2022-06-26 10:07:04.433431
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_column_1 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    progress_column_1.render(None)

# Generated at 2022-06-26 10:07:09.827850
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn("G", True, 1000)
    description = "Batch size"
    custom_style = "progress.data.eta"
    task = Progress()

if __name__ == "__main__":
    test_case_0()
    test_RateColumn_render()

# Generated at 2022-06-26 10:07:13.312551
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    t = tqdm(total=10)
    t.reset()


# Generated at 2022-06-26 10:07:15.549949
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render(task=Progress(0, 0))

# Generated at 2022-06-26 10:07:17.030602
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    total = 100
    assert tqdm_rich(total=total).display(0) == None



# Generated at 2022-06-26 10:07:18.768394
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    task_0 = Progress()
    assert fraction_column_0.render(task_0)
    return


# Generated at 2022-06-26 10:07:27.182813
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    from rich.progress import Task
    task_instance = Task()
    task_instance.completed = 1
    task_instance.total = 2

    # test when unit_scale is True
    fraction_column_0.unit_scale = True
    fraction_column_0.unit_divisor = 1000

    result = fraction_column_0.render(task_instance)
    assert result.text == "1.0/2.0 "

    # test when unit_scale is False
    fraction_column_0.unit_scale = False
    fraction_column_0.unit_divisor = 1000

    result = fraction_column_0.render(task_instance)
    assert result.text == "1.0/2.0 "

# Generated at 2022-06-26 10:07:30.289856
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    fraction_column_0 = FractionColumn()
    tqdm_rich_instance_0 = tqdm_rich('', progress=(fraction_column_0,))
    tqdm_rich_instance_0.reset(total=1)

if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich_reset()