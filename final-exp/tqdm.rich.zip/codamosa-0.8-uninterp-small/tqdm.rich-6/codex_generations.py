

# Generated at 2022-06-26 09:59:30.510848
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = True
    tqdm_rich_0.display()


# Generated at 2022-06-26 09:59:32.242863
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    display_0 = tqdm_rich_0.display



# Generated at 2022-06-26 09:59:41.326651
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Assert if method render of class RateColumn works as intended.
    column1 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    column1.render(task=None)
    # Assert if method render of class RateColumn works as intended.
    column2 = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    column2.render(task=None)


# Generated at 2022-06-26 09:59:43.084097
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    print(rc.render(None))

# Generated at 2022-06-26 09:59:56.431611
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_column_0 = RateColumn()
    progress_0 = Progress(
        "[progress.description]{task.description}",
    )
    progress_1 = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
    )
    progress_2 = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True
        ),
    )
    progress_3 = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True
        ),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
    )

# Generated at 2022-06-26 10:00:00.409755
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset(total = 5)


# Generated at 2022-06-26 10:00:03.146204
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:00:05.419546
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:00:07.840130
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    rc.render(task=None)


# Generated at 2022-06-26 10:00:17.495541
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_1 = tqdm_rich(total=3914)
    tqdm_rich_1.n = 13
    tqdm_rich_1.avg_time = 0.01
    tqdm_rich_1.min_time = 0.01
    tqdm_rich_1.max_time = 0.01
    tqdm_rich_1.times = [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01]

    assert tqdm_rich_1.rate == 130.0


# Generated at 2022-06-26 10:00:26.338299
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    tqdm_rich_0 = tqdm_rich()


# Generated at 2022-06-26 10:00:30.312096
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset(total=None)

# Generated at 2022-06-26 10:00:31.820511
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    instance = FractionColumn()


# Generated at 2022-06-26 10:00:34.395064
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:00:40.004643
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc_0 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    print(rc_0)


# Generated at 2022-06-26 10:00:44.917642
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=1) as pbar:
        pbar.reset(total=2)
        assert pbar.total == 2


# Generated at 2022-06-26 10:00:48.118778
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_case = lambda: None
    test_case.completed = 1
    test_case.total = 1
    fraction_column = FractionColumn(True, 1000)
    assert fraction_column.render(test_case) == Text("1/1 ")



# Generated at 2022-06-26 10:00:51.062363
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:01:01.261134
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_2 = tqdm_rich()
    # Test total is assigned to the property
    tqdm_rich_2.reset(total=100)
    assert tqdm_rich_2.total == 100
    # Test increment works when reset
    tqdm_rich_2.reset(total=200)
    tqdm_rich_2.n = tqdm_rich_2.n + 1
    assert tqdm_rich_2.n == 1
    assert tqdm_rich_2.total == 200
    # Test n is reset when total is not passed
    tqdm_rich_2.reset()
    assert tqdm_rich_2.n == 0


# Generated at 2022-06-26 10:01:03.760138
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn_0 = FractionColumn()
    FractionColumn_0.render({})


# Generated at 2022-06-26 10:01:14.929506
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:01:20.391215
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert hasattr(tqdm_rich_0, '_prog')

    tqdm_rich_0 = tqdm_rich(disable=True)
    assert tqdm_rich_0.disable


# Generated at 2022-06-26 10:01:23.681424
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column_0 = FractionColumn()
    task_0 = None
    column_0.render(task_0)
    return


# Generated at 2022-06-26 10:01:30.919043
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import BarColumn, TimeElapsedColumn, TimeRemainingColumn
    prog = Progress(BarColumn(), TimeElapsedColumn(), TimeRemainingColumn())
    prog.__enter__()
    task = prog.add_task("Download", total=100)
    task(completed=50)
    prog.__exit__(None, None, None)

# Generated at 2022-06-26 10:01:35.597763
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert isinstance(tqdm_rich_0.display(), None)

# Generated at 2022-06-26 10:01:37.815195
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    r.render(0)


# Generated at 2022-06-26 10:01:45.352295
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    iterable = range(8)

    task = tqdm_rich(iterable, leave=True)
    assert type(task) == tqdm_rich

    # testing iterators
    task = tqdm_rich(iterable, leave=True, total=len(iterable))
    assert type(task) == tqdm_rich


if __name__ == "__main__":  # pragma: no cover
    with tqdm_rich(total=100, unit="B", unit_scale=True, unit_divisor=1024,
                   desc="Rich is awesome!", leave=True) as task:
        for i in range(100):
            # Update task
            task.update()
            # Do stuff
            pass

# Generated at 2022-06-26 10:01:48.411459
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:01:49.001282
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass


# Generated at 2022-06-26 10:01:50.276039
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    for _ in range(2):
        assert FractionColumn().render()


# Generated at 2022-06-26 10:02:01.656117
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:02:02.981331
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_1 = RateColumn()


# Generated at 2022-06-26 10:02:09.436624
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_obj = RateColumn()
    # test_case_0
    RateColumn_obj._RateColumn__unit = ""
    RateColumn_obj._RateColumn__unit_scale = False
    RateColumn_obj._RateColumn__unit_divisor = 1000
    task_0 = task_obj
    assert RateColumn_obj.render(task_0) == Text("16789 k/s", style="progress.data.speed")


# Generated at 2022-06-26 10:02:18.909006
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm as std_tqdm
    import rich.progress
    fraction_column_0 = FractionColumn()
    tqdm_rich_0 = tqdm_rich()
    task_0 = rich.progress.Task()
    task_0.completed = 0
    task_0.total = 0
    text_0 = fraction_column_0.render(task_0)
    assert text_0.text == '0.0/0.0 '
    tqdm_rich_0.close()


# Generated at 2022-06-26 10:02:22.207877
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert (r.render(0) is None)


# Generated at 2022-06-26 10:02:27.619968
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.n = 0
    tqdm_rich_0.total = 0
    tqdm_rich_0._prog.update('test',
                               completed=tqdm_rich_0.n,
                               total=tqdm_rich_0.total)


# Generated at 2022-06-26 10:02:30.455975
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:02:36.419926
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Init
    unit = "B"
    unit_scale = None
    unit_divisor = None
    rate_column = RateColumn(unit, unit_scale, unit_divisor)
    task = tqdm_rich()
    # Execute
    rate_column.render(task)
    # Post
    # TODO: assert

# Generated at 2022-06-26 10:02:40.338848
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Declare test parameter
    tqdm_rich_0 = tqdm_rich()
    # Test method with defined parameters
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:02:42.517081
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn_0 = FractionColumn()
    FractionColumn_0.render()


# Generated at 2022-06-26 10:02:55.106367
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    pass

# Generated at 2022-06-26 10:02:59.302619
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Set up test object
    tqdm_rich_0 = tqdm_rich()

    # Invoke method

    tqdm_rich_0.reset()
    # AssertionError: Expected no exceptions to be raised.


# Generated at 2022-06-26 10:03:01.745664
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # tqdm_rich::clear
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:03:10.251402
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = None
    total = tqdm_rich_0.reset(total)
    assert total is None
    total = None
    total = tqdm_rich_0.reset(total)
    assert total is None
    total = None
    total = tqdm_rich_0.reset(total)
    assert total is None

# Generated at 2022-06-26 10:03:17.097759
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()

# Generated at 2022-06-26 10:03:21.620983
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.clear()


# Generated at 2022-06-26 10:03:25.621651
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_rate_column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    test_task = ProgressColumn()
    test_task.speed = None
    test_rate_column.render(test_task)


# Generated at 2022-06-26 10:03:28.498757
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_1 = RateColumn()
    rate_column_1.render(task = None)


# Generated at 2022-06-26 10:03:40.760556
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Tests whether updating the progress bar works.
    """
    with tqdm_rich(desc='test_tqdm_rich', total=100, disable=False) as tqdm_rich_1:
        assert(tqdm_rich_1._prog.__exit__(None, None, None))
    with tqdm_rich(desc='test_tqdm_rich', total=100, disable=False) as tqdm_rich_2:
        assert(tqdm_rich_2._prog.__exit__(None, None, None))

    # Test that display correctly updates the progress bar.
    # Count up to 100, with a step size of 1.

# Generated at 2022-06-26 10:03:43.926420
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:04:26.329271
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    data_set_0 = [
    (
        (
        ),
        'None',
    ),
    ]
    for args_0 in data_set_0:
        if hasattr(args_0, '__iter__') and not isinstance(args_0, dict):
            args_0 = list(args_0)
        tqdm_rich_0 = tqdm_rich(
            args_0[0],
        )
        tqdm_rich_0.clear()
        reply_1 = str(tqdm_rich_0)
        assert reply_1 == args_0[1], args_0[1]


# Generated at 2022-06-26 10:04:27.246353
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # TODO
    pass


# Generated at 2022-06-26 10:04:29.141388
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Init an instance of class
    tqdm_rich_3 = tqdm_rich()

    # Call method
    tqdm_rich_3.clear()


# Generated at 2022-06-26 10:04:31.275267
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_display_0 = tqdm_rich()
    tqdm_rich_display_1 = tqdm_rich()
    tqdm_rich_display_2 = tqdm_rich()


# Generated at 2022-06-26 10:04:34.573329
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    rate_column.render("task")


# Generated at 2022-06-26 10:04:40.398709
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn_0 = RateColumn()
    with rateColumn_0._process_manager(total=10, ncols=110, miniters=10,
                                       leave=False, gui=True) as rateColumn_0:
        for rateColumn_1_ in rateColumn_0:
            rateColumn_0.update(rateColumn_1_ + 1)


# Generated at 2022-06-26 10:04:43.719464
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    return tqdm_rich_1.display()


# Generated at 2022-06-26 10:04:45.875587
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    total = 1
    tqdm_rich_1.reset(total)



# Generated at 2022-06-26 10:04:56.957010
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.progress import FractionColumn
    from rich.panel import PanelStyle
    from rich.progress import BarColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.panel import PanelStyle
    from rich.progress import filesize
    import rich.console
    from rich.console import Console
    from rich.progress import RateColumn
    import types


# Generated at 2022-06-26 10:05:00.694471
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    # Test 0: No arguments
    assert tqdm_rich_0.clear() is None, "Returned value is not None"
    # Test 1: *a
    # Test 2: *a, **kw
    # Test 3: a, **kw


# Generated at 2022-06-26 10:06:28.987878
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert tqdm_rich_0.display() is None


# Generated at 2022-06-26 10:06:31.410087
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # initialization
    with tqdm_rich() as t:
        # test
        t.reset()



# Generated at 2022-06-26 10:06:38.024690
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    print("Method: display()")
    test_cases = [
        {
            "name": "Test 01",
            "tqdm_rich_obj": tqdm_rich(),
            "expect": None
        }
    ]
    for case in test_cases:
        if case["expect"] is None:
            assert case["tqdm_rich_obj"].display()
        else:
            assert case["tqdm_rich_obj"].display() == case["expect"], case["name"]



# Generated at 2022-06-26 10:06:40.169148
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:06:49.952333
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in trange(10, desc='Test tqdm_rich.reset():'):
        pass
    for _ in trange(10, desc='Test tqdm_rich.reset(total=None):'):
        pass
    for _ in trange(10, desc='Test tqdm_rich.reset(total=100):'):
        pass
    for _ in trange(10, desc='Test tqdm_rich.reset(total=100, unit="iterations"):'):
        pass

if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:06:55.856843
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Unit tests for method render of class RateColumn
    # A unit test for method render of class RateColumn.
    # Parameter is a trange instance
    __RateColumn = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    __trange_1 = trange(10)
    __RateColumn.render(__trange_1)

# Generated at 2022-06-26 10:06:57.388882
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():

    for _ in tqdm_rich(range(10), total=10):
        pass



# Generated at 2022-06-26 10:06:58.710652
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()

# Generated at 2022-06-26 10:07:02.096292
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich()
    task.disable = True
    RateColumn_0 = RateColumn()
    ratecolumn_render_0 = RateColumn_0.render(task)



# Generated at 2022-06-26 10:07:04.683307
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = 100
    tqdm_rich_0.reset(total=total)
    tqdm_rich_0.reset(total=total)
