

# Generated at 2022-06-26 09:59:27.635151
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich(0, 5)
    tqdm_rich_0.reset()


# Generated at 2022-06-26 09:59:31.097462
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()



# Generated at 2022-06-26 09:59:34.941124
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in range(4):
        tqdm_rich_0 = tqdm_rich()
        tqdm_rich_0.reset()
        tqdm_rich_0.reset(total=1)
        tqdm_rich_0.reset(total=1)
        tqdm_rich_0.reset()


# Generated at 2022-06-26 09:59:40.110188
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fractionColumn_0 = FractionColumn(unit_scale=False, unit_divisor=1000)
    try:
        fractionColumn_0.render(task=2.5)
    except Exception:
        pass


# Generated at 2022-06-26 09:59:42.741510
# Unit test for method render of class RateColumn
def test_RateColumn_render():
  assert RateColumn().render(Progress()).style == "progress.data.speed"


# Generated at 2022-06-26 09:59:46.007102
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()



# Generated at 2022-06-26 09:59:51.017851
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_1 = FractionColumn()
    fraction_column_2 = FractionColumn()
    fraction_column_3 = FractionColumn()


# Generated at 2022-06-26 09:59:53.275950
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    assert True



# Generated at 2022-06-26 09:59:56.715290
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Task
    a_tqdm_rich_obj = tqdm_rich()
    a_RateColumn_obj = RateColumn()
    a_Task_obj = Task(None)
    a_RateColumn_obj.render(a_Task_obj)


# Generated at 2022-06-26 10:00:08.328494
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # no exceptions raised
    FractionColumn().render(None)
    FractionColumn(unit_scale=False).render(None)
    FractionColumn(unit_scale=True).render(None)
    FractionColumn(unit_scale=True, unit_divisor=1000).render(None)
    FractionColumn(unit_scale=True, unit_divisor=100).render(None)
    FractionColumn(unit_scale=True, unit_divisor=10).render(None)
    FractionColumn(unit_scale=True, unit_divisor=1).render(None)
    FractionColumn(unit_scale=True, unit_divisor=0.1).render(None)
    FractionColumn(unit_scale=True, unit_divisor=0.01).render(None)

# Unit

# Generated at 2022-06-26 10:00:17.613874
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column_0 = RateColumn()


# Generated at 2022-06-26 10:00:20.913920
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:00:27.303018
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print("Test method render of class RateColumn")

    # Test with task.speed is None
    # Test with unit_scale is False
    # Test with unit_scale is True
    # Test with unit is not empty
    # Test with unit is empty
    # Test with precision is not 0
    # Test with precision is 0



# Generated at 2022-06-26 10:00:39.490016
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=1) as t:
        t.reset()
        _ = t.n
        t.n = 2
        _ = t.total
        t.total = 3
        _ = t.last_print_n
        t.last_print_n = 4
        _ = t.dynamic_ncols
        t.dynamic_ncols = False
        _ = t.position
        t.position = 5
        _ = t.bar_format
        t.bar_format = ""
        _ = t.bar_prefix
        t.bar_prefix = ""
        _ = t.bar_suffix
        t.bar_suffix = ""
        _ = t.miniters
        t.miniters = 6
        _ = t.maxinterval
        t.maxinterval

# Generated at 2022-06-26 10:00:43.026723
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest
    tqdm_rich_0 = tqdm_rich()
    print(tqdm_rich_0.reset())

# Generated at 2022-06-26 10:00:46.848677
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    for _ in tqdm_rich_0:
        tqdm_rich_0.clear() # Should execute without error


# Generated at 2022-06-26 10:00:52.400120
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    param_0 = RateColumn()
    assert str(param_0.render(param_0.task)) == None

    param_0 = RateColumn(param_0.unit, param_0.unit_scale, param_0.unit_divisor)
    assert str(param_0.render(param_0.task)) == None


# Generated at 2022-06-26 10:00:56.801991
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    rate_column.render(task)


# Generated at 2022-06-26 10:01:04.164913
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        tqdm_rich_1 = tqdm_rich()
        tqdm_rich_1.reset(total=None)
    except Exception as e:
        print(e)
        assert False


if __name__ == "__main__":
    total = 10000

    with tqdm_rich(total=total, desc="iterating...", unit="B",
                   unit_scale=True) as trange_:
        for i in trange_:
            pass

    with trange(total=total, desc="iterating...", unit="B",
                unit_scale=True) as trange_:
        for i in trange_:
            pass

    with tqdm_rich(total=total, desc="iterating...") as trange_:
        for i in trange_:
            pass



# Generated at 2022-06-26 10:01:09.101671
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test of FractionColumn.render()
    """
    # setup
    self = FractionColumn()

    # test
    result = self.render()

    # assert
    assert result is None


# Generated at 2022-06-26 10:01:33.615248
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.total = 10
    tqdm_rich_0.n = 2
    tqdm_rich_0.unit_scale = False
    tqdm_rich_0.unit_divisor = 1000
    fraction_column_0 = FractionColumn(unit_scale=tqdm_rich_0.unit_scale,
                                       unit_divisor=tqdm_rich_0.unit_divisor)
    fraction_column_0.render(tqdm_rich_0)


# Generated at 2022-06-26 10:01:36.311863
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()

# Generated at 2022-06-26 10:01:42.569205
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn(False, 1000)
    fraction_column_0.render(None)
    fraction_column_1 = FractionColumn(False, 1000)
    fraction_column_1.render(None)
    fraction_column_2 = FractionColumn(False, 1000)
    fraction_column_2.render(None)


# Generated at 2022-06-26 10:01:45.313019
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    x = tqdm_rich()
    x.update(1)
    x.reset()
    x.display()


# Generated at 2022-06-26 10:01:49.510682
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich(total=2)
    tqdm_rich_1.reset()
    tqdm_rich_1.update(2)
    tqdm_rich_1.close()


# Generated at 2022-06-26 10:01:51.169713
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    for _ in tqdm_rich(range(10)):
        pass


# Generated at 2022-06-26 10:01:55.538976
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from builtins import str
    from builtins import chr
    from builtins import ord
    speed = 10
    unit = ""
    unit_scale = False
    unit_divisor = 1000
    test = RateColumn(unit, unit_scale, unit_divisor)
    test.render(speed)


# Generated at 2022-06-26 10:01:59.581833
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = False
    tqdm_rich_0.n = 20
    tqdm_rich_0.desc = "test description"
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:02:10.591129
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in trange(2, desc="1st loop"):
        for _ in trange(3, desc="2nd loop"):
            for _ in trange(4, desc="3rd loop"):
                pass
        trange(5).reset()
        for _ in trange(6, desc="4th loop"):
            pass


if __name__ == "__main__":  # pragma: no cover
    with tqdm_rich(total=10, desc="Testing") as progress:
        progress.update(2)
        progress.update(3)
    import time

    with tqdm_rich(total=10, desc="Testing", unit_scale=True) as progress:
        progress.update(2)
        progress.update(3)

# Generated at 2022-06-26 10:02:17.326370
# Unit test for method render of class RateColumn
def test_RateColumn_render():

    ratecolumn_0 = RateColumn()
    ratecolumn_0.unit = ""
    ratecolumn_0.unit_scale = True
    ratecolumn_0.unit_divisor = 1000
    ratecolumn_0.style_fmt_map['progress.data.speed']
    task = None
    ratecolumn_0.render(task)


# Generated at 2022-06-26 10:02:43.603521
# Unit test for method reset of class tqdm_rich

# Generated at 2022-06-26 10:02:46.188675
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    task = None
    fraction_column_0.render(task)


# Generated at 2022-06-26 10:02:52.607283
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Setup
    tqdm_rich_1 = tqdm_rich()

    # Testing method clear
    try:
        tqdm_rich_1.clear
    except NotImplementedError:
        pass
    else:  # pragma: no cover
        raise AssertionError("unexpected exception")


# Generated at 2022-06-26 10:02:54.792336
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Arrange
    FractionColumn_obj = FractionColumn()

    # Act
    # Assert



# Generated at 2022-06-26 10:02:59.390457
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    _task = object()
    _self = FractionColumn()

    _task.completed = 1.0
    _task.total = 2.0
    _self.unit_scale = False

    _return = _self.render(_task)


# Generated at 2022-06-26 10:03:00.859663
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_obj = RateColumn()
    rate_column_obj.render()

# Generated at 2022-06-26 10:03:07.192769
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Instantiating a tqdm_rich object
    tqdm_rich_1 = tqdm_rich()
    # Calling method reset of tqdm_rich object tqdm_rich_1
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:03:08.443590
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()


# Generated at 2022-06-26 10:03:10.389526
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    assert 0


# Generated at 2022-06-26 10:03:12.563720
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:03:39.442333
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    obj = RateColumn()
    assert obj.render(obj) is None

# Generated at 2022-06-26 10:03:43.217288
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()



# Generated at 2022-06-26 10:03:45.268531
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # failed case
    rateColumn_obj = RateColumn()
    assert type(rateColumn_obj.render(100)) != Text


# Generated at 2022-06-26 10:03:48.370843
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:03:52.999060
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:03:54.116424
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render()


# Generated at 2022-06-26 10:03:58.047391
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich()
    fraction_column = FractionColumn()
    fraction_column.render(task)
    task.close()
    # assert type(output) == str


# Generated at 2022-06-26 10:04:01.411485
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        tqdm_rich_1 = tqdm_rich()
        tqdm_rich_1.clear()
        tqdm_rich_1.clear()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:04:11.280253
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    with_unit_scale = FractionColumn(unit_scale=True)
    without_unit_scale = FractionColumn(unit_scale=False)

    # case 1
    render0 = without_unit_scale.render(completed=10, total=20)
    render1 = with_unit_scale.render(completed=10, total=20)
    assert (render0 == "10/20 ")
    assert (render1 == "10.0/20.0 ")

    # case 2
    render2 = without_unit_scale.render(completed=100, total=200)
    render3 = with_unit_scale.render(completed=100, total=200)
    assert (render2 == "100/200 ")
    assert (render3 == "100.0/200.0 K")

    # case 3


# Generated at 2022-06-26 10:04:13.523097
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    assert tqdm_rich_1.disable == False
    tqdm_rich_1.clear()


# Generated at 2022-06-26 10:05:44.977351
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_1 = tqdm_rich()
    rc = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    rc.render = tqdm_rich_1.render


# Generated at 2022-06-26 10:05:46.781057
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich(0, 0)
    assert tqdm_rich_0.display() is None

# Generated at 2022-06-26 10:05:49.032094
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    task = None
    text = rate_column_0.render(task)
    assert (text == "? /s")



# Generated at 2022-06-26 10:05:50.785097
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:05:56.481422
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.rich import bar
    from rich.progress import Progress
    from rich.progress import Text, BarColumn
    from rich.progress import ProgressColumn, TimeElapsedColumn
    from rich.progress import TimeRemainingColumn, RateColumn
    from rich.progress import filesize
    # TODO: write unit test for tqdm.rich.tqdm_rich.display()
    tqdm_rich_0 = tqdm_rich(desc,total)
    tqdm_rich_0.display(self,total)


# Generated at 2022-06-26 10:05:57.043748
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    pass

# Generated at 2022-06-26 10:05:59.064512
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0_display_ret = tqdm_rich_0.display()


# Generated at 2022-06-26 10:06:00.451184
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    result = column.render(task=None)
    assert True


# Generated at 2022-06-26 10:06:02.104473
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    dummy_tqdm_rich_0 = tqdm_rich()
    dummy_tqdm_rich_0.clear()


# Generated at 2022-06-26 10:06:04.742543
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    for i in range(0, 10):
        tqdm_rich_1.clear()


# Generated at 2022-06-26 10:08:02.689997
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_0.clear()
    tqdm_rich_1.clear(tqdm_rich_2)
    tqdm_rich_0.clear(tqdm_rich_0, tqdm_rich_1)


# Generated at 2022-06-26 10:08:04.897762
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()
    assert tqdm_rich_0.disable == 0, "tqdm_rich_0.disable == 0"


# Generated at 2022-06-26 10:08:06.278645
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    # Test if method render works
    assert rate_column_0.render(task=None)


# Generated at 2022-06-26 10:08:07.405453
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()

# Generated at 2022-06-26 10:08:08.653721
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    print(rate_column_0.render(None))


# Generated at 2022-06-26 10:08:12.098733
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_display_0 = tqdm_rich()
    tqdm_rich_display_0.clear()
    tqdm_rich_display_0.close()
    tqdm_rich_display_0.display()
    tqdm_rich_display_0.reset()
    tqdm_rich_display_0.update()


# Generated at 2022-06-26 10:08:16.632113
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_clear_0 = tqdm_rich(disable=None, position=None)
    tqdm_rich_clear_0.clear()
    tqdm_rich_clear_1 = tqdm_rich(disable=None, position=None)
    tqdm_rich_clear_1.clear()
    tqdm_rich_clear_2 = tqdm_rich(disable=None, position=None)
    tqdm_rich_clear_2.clear()


# Generated at 2022-06-26 10:08:18.217629
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()


# Generated at 2022-06-26 10:08:20.609498
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_reset_0 = tqdm_rich()
    tqdm_rich_reset_0.reset()


# Generated at 2022-06-26 10:08:22.149963
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()

