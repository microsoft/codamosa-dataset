

# Generated at 2022-06-26 09:59:25.230380
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class_under_test = FractionColumn()
    class_under_test.render


# Generated at 2022-06-26 09:59:28.231140
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich_1 = tqdm_rich()


# Generated at 2022-06-26 09:59:33.002618
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Case 0
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()
    assert tqdm_rich_0.total == 0
    assert tqdm_rich_0.n == 0


# Generated at 2022-06-26 09:59:37.526583
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    for _ in tqdm_rich_0:
        pass
    tqdm_rich_0.reset()


# Generated at 2022-06-26 09:59:38.954846
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t0 = tqdm_rich(total=10)
    for i in t0:
        pass
    t0.close()


# Generated at 2022-06-26 09:59:49.290093
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import math
    import time
    import sys
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Make sure bar is displayed optimally (100%)
    with patch('sys.stderr', new_callable=lambda: sys.stdout):
        with tqdm_rich(total=10, bar_format='{l_bar}{bar}|') as t:
            for i in range(10):
                t.update()
                time.sleep(.1)

    # Unit test to check if in notebook runtime

# Generated at 2022-06-26 09:59:57.377711
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import unittest
    import io
    import sys
    sys.stdout = io.StringIO()
    tqdm_rich_0 = tqdm_rich(initial=1, total=0)
    tqdm_rich_0.n = 1
    tqdm_rich_0.display()
    tqdm_rich_0.disable = False
    tqdm_rich_0.display()
    tqdm_rich_0.leave = False
    tqdm_rich_0.display()
    assert sys.stdout.getvalue() == ''
    return True


# Generated at 2022-06-26 09:59:59.809900
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()


# Generated at 2022-06-26 10:00:00.784346
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render()

# Generated at 2022-06-26 10:00:08.268346
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    capfd = None
    tqdm_rich_0 = tqdm_rich()
    task_0 = tqdm_rich_0
    FractionColumn_0 = FractionColumn()
    FractionColumn_0.render(task_0)
    out, err = capfd.readouterr()
    assert out == '0/0 \n'
    # Unit test for method render of class RateColumn
    RateColumn_0 = RateColumn()
    RateColumn_0.render(task_0)
    out, err = capfd.readouterr()
    assert out == '? /s'


# Generated at 2022-06-26 10:00:19.333531
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import Progress
    tqdm_rich_0 = tqdm_rich()
    progress = Progress("[progress.description]{task.description}"
                        "[progress.percentage]{task.percentage:>4.0f}%",
                        BarColumn(bar_width=None),
                        FractionColumn(),
                        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
                        ",", RateColumn(), "]")
    tqdm_rich_0._prog = progress
    tqdm_rich_0._task_id = progress.add_task("", total=10)
    progress.update(tqdm_rich_0._task_id, completed=5)
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:00:24.084234
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    assert FractionColumn().render(None) == '0/0  '


# Generated at 2022-06-26 10:00:26.876973
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    total = 100
    progress = tqdm_rich(total=total)
    progress.reset(total=total + 1)
    progress.reset(total=total - 1)


# Generated at 2022-06-26 10:00:28.851410
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_0 = FractionColumn()


# Generated at 2022-06-26 10:00:33.171937
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    task = None
    rate_column_0.render(task)


# Generated at 2022-06-26 10:00:38.459493
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:00:41.350500
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:00:45.194574
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()

# Generated at 2022-06-26 10:00:47.350751
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm(total=100) as t:
        for i in range(10):
            t.update()


# Generated at 2022-06-26 10:00:50.885235
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:00:57.666806
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_render_0 = RateColumn()
    RateColumn_render_0.render(task=None)

# Generated at 2022-06-26 10:01:00.896100
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()


# Generated at 2022-06-26 10:01:05.186501
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich(unit='B')
    tqdm_rich_0.close()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:01:13.192752
# Unit test for method display of class tqdm_rich

# Generated at 2022-06-26 10:01:16.902018
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich(total=True)
    tqdm_rich_0.display()



# Generated at 2022-06-26 10:01:23.969761
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Create instance of class tqdm_rich
    tqdm_rich_0 = tqdm_rich()
    # Create instance of class RichText for attribute '_prog' of class tqdm_rich
    rich_text_0 = RichText()
    # Set value of attribute '_prog' of class tqdm_rich
    tqdm_rich_0._prog = rich_text_0
    # Call method 'clear' of class tqdm_rich with argument '*_' and '**__'
    tqdm_rich_0.clear(*_, **__)


# Generated at 2022-06-26 10:01:29.206332
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    for i in range(10):
        frac=FractionColumn()
        frac.render()

if __name__ == '__main__':
    test_case_0()
    test_FractionColumn_render()

# Generated at 2022-06-26 10:01:32.842888
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    # disp is a VariableName
    disp = ""
    tqdm_rich_0.display(disp)
    tqdm_rich_0.display(disp, "a", a=0)


# Generated at 2022-06-26 10:01:35.523758
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich"""


# Generated at 2022-06-26 10:01:40.786809
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from inspect import signature
    from rich.progress import Progress
    from rich.console import Console
    console_0 = Console(file=None, force_terminal=False, force_wrap=False, width=None, color_system="truecolor", legacy_windows=True)
    progress_0 = Progress(console=console_0, transient=False, description_length=None, control_length=None, progress_length=None, completed_length=None, total_length=None, bar_width=None, bar_type="line", throttle=0.0)
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()
    tqdm_rich_0.set_lock(None)
    tqdm_rich_0.close()
    tqdm_rich_0.clear()
   

# Generated at 2022-06-26 10:01:52.561934
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0._prog = Progress()
    tqdm_rich_0._task_id = 2
    tqdm_rich_0._prog.update(2, completed=0, speed=100)
    tqdm_rich_0.format_dict = {'unit': 'B', 'unit_scale': True, 'unit_divisor': 1000}
    tqdm_rich_0.render()


# Generated at 2022-06-26 10:01:54.827053
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert tqdm_rich_0.display() is None


# Generated at 2022-06-26 10:01:58.526100
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqd_0 = tqdm_rich()
    try:
        tqd_0.display()
    except Exception as err:
        tqd_0.close()
        raise err
    tqd_0.close()


# Generated at 2022-06-26 10:02:05.985564
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():

    with tqdm_rich(unit='B', unit_scale=True, unit_divisor=1024, miniters=1,
                   desc='rich.progress test') as t:
        for i in t:  # keep this as top-level loop for picklability
            t.set_description('Iteration %i' % i)
            t.update(i + 1)

    tqdm_rich_1 = tqdm_rich()
    assert(tqdm_rich_1.disable is True)



# Generated at 2022-06-26 10:02:08.666218
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset(total=None)


# Generated at 2022-06-26 10:02:18.347669
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t0 = tqdm_rich()
    t0.reset(total=123)
    t0.close()
    # Total is an integer
    t1 = tqdm_rich()
    t1.reset(total=123)
    t1.close()
    # Total is not an integer
    t2 = tqdm_rich()
    t2.reset(total=123.456)
    t2.close()
if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-26 10:02:23.147708
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(
        unit="",
        unit_scale=False,
        unit_divisor=1000,
    )
    # test_RateColumn_render_0
    task = 1
    rate_column.render(task)



# Generated at 2022-06-26 10:02:26.020475
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_clear = tqdm_rich()
    assert tqdm_rich_clear.disable is False
    tqdm_rich_clear.clear()


# Generated at 2022-06-26 10:02:29.865305
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()
    tqdm_rich_0.reset(total=None)


# Generated at 2022-06-26 10:02:35.235265
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    unit_scale = False
    unit_divisor = 1000
    Column = FractionColumn(unit_scale, unit_divisor)
    completed = 20
    total = 100
    task = []
    task.completed = completed
    task.total = total
    Column.render(task)
    # TODO: verify the result


# Generated at 2022-06-26 10:02:56.109646
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:03:00.425489
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = 100
    tqdm_rich_0.reset(total=total)
    assert tqdm_rich_0.total == total


# Generated at 2022-06-26 10:03:07.192535
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    task = rate_column._task
    task.speed = None
    result = rate_column.render(task)
    assert result == Text(f"? /s", style="progress.data.speed")

# Generated at 2022-06-26 10:03:09.822051
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    instance_RateColumn = RateColumn()
    assert instance_RateColumn.render(task) == '? /s'


# Generated at 2022-06-26 10:03:12.050668
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    
    # Unit test for method close of class tqdm_rich
    def test_tqdm_rich_close():
        pass


# Generated at 2022-06-26 10:03:17.222878
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich(disable=True)
    tqdm_rich_0.total = 1000
    tqdm_rich_0.n = 1000
    tqdm_rich_0.close()
    tqdm_rich_0.reset()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:03:30.906249
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():

    # Four lines for coverage, check no syntax error.
    # No error when calling display with different kind of arguments.
    from tqdm.rich import tqdm_rich
    import sys

    with tqdm_rich(total=1, file=sys.stderr) as t:
        t.display()
        t.display(1)
        t.display('1')
        t.display('1', 1)
        t.display(total=3)
        t.display(1, '2')
        t.display(1, 2)
        t.display(1, 2, 3)
        t.display(1, 2, 3, 4)

    # No error when calling display without any arguments
    with tqdm_rich(total=1, file=sys.stderr) as t:
        t.display()


# Generated at 2022-06-26 10:03:36.774869
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    global tqdm_rich_0
    if tqdm_rich_0 is None:
        tqdm_rich_0 = tqdm_rich()
    # Call method clear
    tqdm_rich_0.close()
    return True


# Generated at 2022-06-26 10:03:42.771084
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    global tqdm_rich_0
    assert tqdm_rich_0.disable == False
    tqdm_rich_0.disable = True
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:03:44.957677
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=None) as t1:
        t1.reset(total=None)


# Generated at 2022-06-26 10:03:54.601387
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn = RateColumn()

# Generated at 2022-06-26 10:03:57.673079
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()
    return tqdm_rich_0

# Generated at 2022-06-26 10:03:59.728692
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_2.reset()


# Generated at 2022-06-26 10:04:03.254627
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_reset = tqdm_rich()
    tqdm_rich_reset.total = None
    tqdm_rich_reset._prog = Progress()
    tqdm_rich_reset.reset()


# Generated at 2022-06-26 10:04:05.738250
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    task_0 = None
    RateColumn_0.render(task_0)


# Generated at 2022-06-26 10:04:07.557064
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:04:10.381165
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Instances
    try:
        tqdm_rich_ = tqdm_rich()
        tqdm_rich_.clear()
    except:
        pass


# Generated at 2022-06-26 10:04:13.367293
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    std_tqdm_0 = tqdm()
    std_tqdm_0.close()
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()


# Generated at 2022-06-26 10:04:15.996872
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:04:19.730497
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test case for method clear of class tqdm_rich."""
    tqdm_rich_0 = tqdm_rich()
    try:
        tqdm_rich_0.clear()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:04:29.701610
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_instance = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    rate_column_instance.render(None)


# Generated at 2022-06-26 10:04:35.287800
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset(total=100)
    tqdm_rich_1.update(10)
    tqdm_rich_1.update(50)
    tqdm_rich_1.update(99)
    tqdm_rich_1.update(101)


# Generated at 2022-06-26 10:04:36.934626
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    RateColumn_0.render(None)


# Generated at 2022-06-26 10:04:44.034725
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test case for method render of class RateColumn
    # TODO: Test the case where unit equals '', unit_scale equals False, unit_divisor equals 1000
    try:
        RateColumn('', False, 1000)
    except TypeError as e:
        print('Method render of class RateColumn not tested')
    else:
        print('Method render of class RateColumn tested')


# Generated at 2022-06-26 10:04:44.883321
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    pass



# Generated at 2022-06-26 10:04:50.548231
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Test with positional arguments
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset(total=None)
    assert tqdm_rich_0.total == None
    # Test with named arguments
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset(total=None)
    assert tqdm_rich_1.total == None
    # Test with positional and named arguments
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_2.reset(None)
    assert tqdm_rich_2.total == None
    # Test with maximum number of arguments
    tqdm_rich_3 = tqdm_rich()
    tqdm_rich_3.reset(total=None)

# Generated at 2022-06-26 10:04:52.184169
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    assert column.render(ProgressColumn) is None

# Generated at 2022-06-26 10:04:55.173991
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_column2 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    progress_column2.render()


# Generated at 2022-06-26 10:04:57.372283
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()

    assert 1 == 1


# Generated at 2022-06-26 10:04:59.463992
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    try:
        tqdm_rich_1.display()
    except:
        pass


# Generated at 2022-06-26 10:05:23.150095
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    # Test that display is properly called without any arguments
    # and that no other methods are called on the object
    with mock.patch.object(tqdm_rich_0, 'clear') as mock_clear:
        def check_display():
            try:
                tqdm_rich_0.display()
            except:
                return True
            return False
        assert not mock_clear.called
        assert check_display()
        assert not mock_clear.called

# This class represents the “old-style” class of class tqdm_rich.

# Generated at 2022-06-26 10:05:32.376380
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Constructor without arguments
    tqdm_rich_0 = tqdm_rich()
    
    # Constructor with arguments
    tqdm_rich_1 = tqdm_rich(100)
    tqdm_rich_2 = tqdm_rich(self, *args, **kwargs)
    tqdm_rich_3 = tqdm_rich(desc=str)
    tqdm_rich_4 = tqdm_rich(miniters=int)
    tqdm_rich_5 = tqdm_rich(dynamic_ncols=bool)
    tqdm_rich_6 = tqdm_rich(smoothing=float)

# Generated at 2022-06-26 10:05:38.077294
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    test_case_0()
    for _i in trange(5):
        pass
    tqdm_rich_0.reset()
    for _i in trange(5):
        pass

if __name__ == '__main__':
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:05:42.174659
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    # Reset to 0 iterations for repeated use.
    total = None
    tqdm_rich_0.reset(total=total)


# Generated at 2022-06-26 10:05:43.803671
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total = 2)
    t.reset()
    pass


# Generated at 2022-06-26 10:05:50.349456
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_3 = tqdm_rich()
    # test for case when rate is None
    assert '? /s' == tqdm_rich_3.rate_column.render(None)
    # test for default case
    assert '2.7 M/s' == tqdm_rich_3.rate_column.render(2700000)
    # test for when unit_scale is set
    tqdm_rich_4 = tqdm_rich(unit_scale=True)
    assert '2.7 M/s' == tqdm_rich_4.rate_column.render(2700000)


# Generated at 2022-06-26 10:05:53.539495
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich_0:
        for i in trange(10):
            pass
    tqdm_rich_0 = tqdm_rich()
    with tqdm_rich_0:
        for i in trange(10):
            pass
            

# Generated at 2022-06-26 10:05:54.330316
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pass


# Generated at 2022-06-26 10:05:57.183585
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.rich import tqdm_rich as td
    tdr = td(range(10))
    with tdr as tdr2:
        for i in tdr2:
            tdr2.display()


# Generated at 2022-06-26 10:05:59.818563
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    class Task:
        complete = 0
        total = 1
        speed = None
    assert r.render(Task()) == Text("? /s", style="progress.data.speed")



# Generated at 2022-06-26 10:06:34.602940
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    total = 1
    tqdm_rich(total=total)
    tqdm_rich(total=total)

# Generated at 2022-06-26 10:06:37.446792
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0_0 = tqdm_rich()
    tqdm_rich_0_0.reset(total=None)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 10:06:39.166437
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()


# Generated at 2022-06-26 10:06:40.761674
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:06:43.714929
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset(total=None)


# Generated at 2022-06-26 10:06:45.395906
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich(disable=True)
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:06:58.106788
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    console = Console()
    progress = Progress(console)
    progress.__enter__()
    tqdm_rich_1 = tqdm_rich(progress, total=100)
    tqdm_rich_1.disable = False
    tqdm_rich_1.leave = False
    tqdm_rich_1.desc = ''
    assert tqdm_rich_1.total == 100
    assert tqdm_rich_1.disable == False
    assert tqdm_rich_1.leave == False
    assert tqdm_rich_1.desc == ''
    tqdm_rich_1._prog = progress
    tqdm_rich_1._prog.__enter__()

# Generated at 2022-06-26 10:07:06.357009
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress, ProgressColumn

    progress = Progress()
    progress_column = ProgressColumn(progress)
    task = progress_column.task
    task.total = 100
    task.completed = 10
    rate_column = RateColumn()
    assert rate_column.render(task) == Text('? /s', style='progress.data.speed')

    rate_column = RateColumn('s')
    assert rate_column.render(task) == Text('? s/s', style='progress.data.speed')

    rate_column = RateColumn(unit_divisor=2)
    assert rate_column.render(task) == Text('? /s', style='progress.data.speed')

    rate_column = RateColumn(unit_scale=True)

# Generated at 2022-06-26 10:07:14.190285
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    with tqdm_rich_1:
        tqdm_rich_1.total = 10
        for _ in tqdm_rich_1:
            pass


# Generated at 2022-06-26 10:07:16.579175
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0_obj = tqdm_rich()
    tqdm_rich_0_obj.reset()


# Generated at 2022-06-26 10:08:48.276805
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset(total=None)


# Generated at 2022-06-26 10:08:55.517542
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.rich import tqdm_rich
    from unittest.mock import Mock
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.n = Mock(return_value=2)
    tqdm_rich_0.desc = Mock(return_value="")
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:09:01.634733
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = None
    func = tqdm_rich_0.reset(total=total)

if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:09:03.987462
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()

# Generated at 2022-06-26 10:09:08.140513
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    if hasattr(tqdm_rich_0, '_prog'):
        tqdm_rich_0.display()


# Generated at 2022-06-26 10:09:11.921376
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:09:14.149478
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn(unit="/s")
    task = r.render(r)
    assert task is not None


# Generated at 2022-06-26 10:09:21.989825
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_RateColumn_obj = RateColumn()
    test_RateColumn_obj.render(task=Progress())
    test_RateColumn_obj = RateColumn(unit='%')
    test_RateColumn_obj.render(task=Progress())
    test_RateColumn_obj = RateColumn(unit='%', unit_scale=True)
    test_RateColumn_obj.render(task=Progress())
    test_RateColumn_obj = RateColumn(unit='%', unit_divisor=5000)
    test_RateColumn_obj.render(task=Progress())
    test_RateColumn_obj = RateColumn(unit_scale=True)
    test_RateColumn_obj.render(task=Progress())
    test_RateColumn_obj = RateColumn(unit_divisor=5000)