

# Generated at 2022-06-26 09:59:36.107584
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():

    # Test with leave=False and disable=True
    tqdm_rich_1 = tqdm_rich(leave=False, disable=True)
    tqdm_rich_1.total = 100
    tqdm_rich_1.display()

# Generated at 2022-06-26 09:59:38.431341
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # create tqdm_rich object
    tqdm_rich_obj = tqdm_rich(total = 10, disable = False)
    # call clear method
    tqdm_rich_obj.clear()


# Generated at 2022-06-26 09:59:43.768018
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich(disable=True)
    total_0 = None
    tqdm_rich_0.reset(total=total_0)

if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich_reset()

# Generated at 2022-06-26 09:59:46.543001
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_1 = RateColumn()
    rate_column_1.render("test_string")


# Generated at 2022-06-26 09:59:53.380363
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    print("\nUnit test for method clear of class tqdm_rich")
    # Create a new instance of tqdm_rich
    tqdm_rich_obj = tqdm_rich(['a'])
    # Test
    tqdm_rich_obj.clear()


# Generated at 2022-06-26 09:59:58.038662
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm(range(50), gui=True)
    t._task_id = '1234'
    t.disable = True
    for i in t:
        t.clear()
    t.clos

# Generated at 2022-06-26 10:00:01.163619
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_0 = tqdm_rich()
    tqdm_0.clear()



# Generated at 2022-06-26 10:00:11.069969
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    n = 36
    rate_column_0.task.completed = n
    rate_column_0.task.total = n
    rate_column_0.task.speed = 0.0
    rate_column_0.render(rate_column_0.task)
    rate_column_0.task.speed = 0.01
    rate_column_0.render(rate_column_0.task)
    rate_column_0.task.speed = 0.1
    rate_column_0.render(rate_column_0.task)
    rate_column_0.task.speed = 1.0
    rate_column_0.render(rate_column_0.task)
    rate_column_0.task.speed = 10.0

# Generated at 2022-06-26 10:00:13.063320
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    print('*** TESTING tqdm_rich.reset() ***')
    tqdm_rich_0 = tqdm_rich(total=1)
    tqdm_rich_0.reset(total=1000)


# Generated at 2022-06-26 10:00:21.253598
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import _supports_unicode
    desc = "Progress"
    total = 100
    rate = None
    leave = True
    dynamic_ncols = True

    # create an instance of tqdm_rich
    t = tqdm_rich(total=total, rate=rate, desc=desc, leave=leave, dynamic_ncols=dynamic_ncols)
    t.n = t.total  # to force the `display()` to be executed
    # execute display method
    t.display()

    if _supports_unicode and not t.disable:
        # check if description is same as expected
        assert t._prog._tasks[t._task_id].description == desc
        # check if completed is same as expected
        assert t._prog._tasks[t._task_id].com

# Generated at 2022-06-26 10:00:48.024612
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Testing case 0
    rate_column_0 = RateColumn()
    Rich_Progress_0 = Progress()
    Rich_Progress_0.__enter__()
    Rich_Progress_0.add_task("qwerty", total=100)
    rate_column_0.render(Rich_Progress_0._tasks[0])
    Rich_Progress_0.__exit__(None, None, None)

    # Testing case 1
    rate_column_1 = RateColumn()
    Rich_Progress_1 = Progress()
    Rich_Progress_1.__enter__()
    Rich_Progress_1.add_task("qwerty", total=1)
    rate_column_1.render(Rich_Progress_1._tasks[0])
    Rich_Progress_1.__exit__(None, None, None)

# Unit

# Generated at 2022-06-26 10:00:53.564836
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Create an instance of tqdm_rich
    instance = tqdm_rich(
        total = 100,
        desc = "Downloading file",
        unit = "B",
        unit_scale = True,
        unit_divisor = 1024,
        leave = True,
        miniters = 1,
        mininterval = 0.1,
        ascii = True,
        disable = False
    )
    # call the method
    instance.display()

test_tqdm_rich_display()

# Generated at 2022-06-26 10:01:03.410766
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Function to check if two items are within 1 of each other
    def assert_not_equal_within_one(item1, item2):
        assert item1 <= item2 + 1, \
            "Expected  {} <= {} + 1, but got {} and {}".format(item1, item2, item1, item2)
        assert item2 <= item1 + 1, \
            "Expected  {} <= {} + 1, but got {} and {}".format(item2, item1, item2, item1)

    for _ in tqdm_rich(range(5)):
        pass

    # Check that total is set to 0
    assert tqdm_rich._prog._tasks[0]['total'] == 0
    # Check that elapsed time is non-zero

# Generated at 2022-06-26 10:01:08.682239
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_obj = tqdm_rich(['a', 'b'])
    tqdm_rich_obj.display()
# End of test_tqdm_rich_display()


# Generated at 2022-06-26 10:01:18.413478
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(iterable = [1, 2], desc = "Progress", smoothing = 0, bar_format = "[progress.description]{task.description}[progress.percentage]{task.percentage:>4.0f}%", disable = False) as tqdm0:
        for i in tqdm0:
            tqdm0.display()
            assert(type(tqdm0.display()) == None)


# Generated at 2022-06-26 10:01:21.230587
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Instantiating tqdm_rich
    tqdm_rich_0 = tqdm_rich()

    # Calling display with no arguments
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:01:23.823166
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    rate = RateColumn()
    assert not hasattr(rate, '_prog')



# Generated at 2022-06-26 10:01:35.001249
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    rate_column_0 = RateColumn()
    progress_0 = Progress()

# Generated at 2022-06-26 10:01:36.033004
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(1, unit="it") as t:
        t.update()

# Generated at 2022-06-26 10:01:40.592443
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Random arguments
    task = None

    # Call the method
    test_FractionColumn_render_object = FractionColumn()
    test_FractionColumn_render_object.render(task)



# Generated at 2022-06-26 10:01:58.933684
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import _range

    total = 1000
    for _ in tqdm(_range(total), desc='initial:', leave=True):
        pass
    for _ in tqdm(_range(total), reset=True):
        pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:02:00.976191
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column_0 = RateColumn(1/1000, "", False, 1000)
    column_0.render()



# Generated at 2022-06-26 10:02:11.023584
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    for unit_scale in [False, True]:
        for unit_divisor in [1000]:
            fractioncolumn_0 = FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
    # See https://stackoverflow.com/questions/2390827/how-to-properly-subclass-mock-object
    class MockTask:
        pass
    task_0 = MockTask()
    task_0.completed = float('inf')
    task_0.total = float('inf')
    try:
        fractioncolumn_0.render(task_0)
    except ZeroDivisionError as err:
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-26 10:02:12.769339
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    task = Progress
    RateColumn_0.render(task)


# Generated at 2022-06-26 10:02:18.178176
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn_1 = RateColumn()
    try:
        ratecolumn_1.render(None)
    except Exception as e:
        print(e)
    assert ratecolumn_1 is not None


# Generated at 2022-06-26 10:02:20.971591
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn_render_0 = FractionColumn()
    FractionColumn_render_0.render()


# Generated at 2022-06-26 10:02:22.696090
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render()


# Generated at 2022-06-26 10:02:23.526780
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    pass



# Generated at 2022-06-26 10:02:31.030697
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.desc = 'tqdm_rich_1'
    tqdm_rich_1.n = 0
    tqdm_rich_1.total = 100
    tqdm_rich_1.nmin = 0
    tqdm_rich_1.nmax = 100
    tqdm_rich_1.niterable = None
    tqdm_rich_1.unit_scale = False
    tqdm_rich_1.unit = 'it'
    tqdm_rich_1.smoothing = 0
    tqdm_rich_1.dynamic_ncols = True
    tqdm_rich_1.mininterval = 1
    tqdm_rich_1.maxinterval = 6


# Generated at 2022-06-26 10:02:32.216754
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_case_FractionColumn_render_0()


# Generated at 2022-06-26 10:02:48.165703
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich = tqdm_rich()
    tqdm_rich.format_dict['total'] = 100
    tqdm_rich.format_dict['n'] = 50
    render_test_0 = FractionColumn()



# Generated at 2022-06-26 10:02:52.905941
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    with tqdm_rich() as t:
        for _ in t:
            pass
    t._prog.render(pytest.config.cache)


# Generated at 2022-06-26 10:02:56.934919
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Ensure that a renderable object is returned.
    """
    FractionColumn_0 = FractionColumn()
    # Ensure that a renderable object is returned.
    assert hasattr(FractionColumn_0.render(None), '__rich_measure__')



# Generated at 2022-06-26 10:02:59.075171
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    # assert <something>


# Generated at 2022-06-26 10:03:00.861046
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    column.render(Progress(total=10))


# Generated at 2022-06-26 10:03:06.857686
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    x = RateColumn()
    info = [None]
    if x.render(info) != Text('?', style='progress.data.speed'):
        raise Exception(
            "Unit test for method render of class RateColumn")


# Generated at 2022-06-26 10:03:10.195678
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Changing progress.total
    FractionColumn_instance_0 = FractionColumn()
    assert FractionColumn_instance_0.render(task={'total': 1}) is None



# Generated at 2022-06-26 10:03:13.016596
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Define arguments
    task = None
    # Obtain the class to test
    fractioncolumn = FractionColumn()
    # Invoke the method to test
    fractioncolumn.render(task)


# Generated at 2022-06-26 10:03:22.317789
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert rate_column_0.render(task=None) == Text("? /s",
                                                  style="progress.data.speed")
    rate_column_1 = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    assert rate_column_1.render(task=None) == Text("? /s",
                                                  style="progress.data.speed")



# Generated at 2022-06-26 10:03:24.896843
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    assert tqdm_rich_1.display() == None


# Generated at 2022-06-26 10:03:52.675027
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    obj = FractionColumn()
    param0 = None
    try:
        obj.render(param0)
    except TypeError:
        return True
    return False


# Generated at 2022-06-26 10:03:54.497140
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn(unit="")


# Generated at 2022-06-26 10:03:58.312754
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r_c = RateColumn(unit="",unit_scale=False,unit_divisor=1000)
    task = object()
    r_c.render(task="hello")


# Generated at 2022-06-26 10:04:00.304160
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_display = tqdm_rich()
    tqdm_rich_display.display()


# Generated at 2022-06-26 10:04:02.262173
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_object_0 = RateColumn('/s', True, 1000)
    test_object_0.render(None)

# Generated at 2022-06-26 10:04:12.142664
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Arrange
    from rich.progress import Task
    task = Task([0, 0, 0])
    test_cases = [
        [0, 0, 0],
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
        [1, 0, 1],
        [1, 1, 0],
        [1, 1, 1],
        [6, 10, 1],
        [1, 6, 10],
        [6, 10, 100],
        [6, 10, 1000],
        [6, 10, 10000],
    ]

# Generated at 2022-06-26 10:04:13.365996
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    _ = RateColumn()
    _.render(task=None)


# Generated at 2022-06-26 10:04:21.950077
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    r"""
    >>> from tqdm import tqdm as tqdm

    >>> for i in tqdm([1, 2, 3, 4, 5],
    ...               bar_format="[{l_bar}{bar}{r_bar}] {n_fmt}/{total_fmt} [{remaining}]"):
    ...     pass
    [#####                               ] 1/5 [4 remaining]
    [#########                           ] 2/5 [3 remaining]
    [#############                       ] 3/5 [2 remaining]
    [##################                  ] 4/5 [1 remaining]
    [#######################             ] 5/5 [0 remaining]
    """


# Generated at 2022-06-26 10:04:30.781890
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    #         expected_value =
    test_cases_0 = [None]
    test_cases_0_args = []
    test_cases_1 = [None]
    test_cases_1_kwargs = []
    for test_case_0, test_case_0_args, test_case_1, test_case_1_kwargs in zip(test_cases_0,test_cases_0_args,test_cases_1,test_cases_1_kwargs):
        test_case_tqdm_rich = tqdm_rich(
            disable=None, unit='it', unit_scale=None, unit_divisor=None)
        actual_value = test_case_tqdm_rich.display(*test_case_0_args, **test_case_1_kwargs)
        assert actual_value

# Generated at 2022-06-26 10:04:34.611571
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=2) as pbar:
        pbar.reset(total=4)
        for x in range(4):
            pbar.update()



# Generated at 2022-06-26 10:05:29.113639
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Initialize tqdm_rich, for now only for testing purposes
    tqdm_rich0 = tqdm_rich()
    # Get an instance of the class FractionColumn, for now only for testing
    # purposes
    fractioncolumn0 = FractionColumn(unit_scale=False, unit_divisor=1000)
    # Call method render of class FractionColumn, for now only for testing
    # purposes
    fractioncolumn0.render(tqdm_rich0)


# Generated at 2022-06-26 10:05:31.172540
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    test_case_0()

if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-26 10:05:37.781431
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from sys import stdout
    with tqdm_rich(total=100, file=stdout) as pbar:
        for i in range(10):
            pbar.update(10)
            pbar.reset(total=50)
            pbar.update(5)
            pbar.reset(total=100)

if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:05:42.174408
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_ = tqdm_rich()
    args = []
    kwargs = {}
    tqdm_rich_.display(*args, **kwargs)


# Generated at 2022-06-26 10:05:43.803563
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich(disable=False)


# Generated at 2022-06-26 10:05:51.797232
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    columns = [RateColumn(unit="", unit_scale=False, unit_divisor=1000)]
    options = {
        'desc': '',
        'unit': '',
        'unit_scale': False,
        'unit_divisor': 1000,
        'disable': False,
        'mininterval': 0.5,
        'miniters': 1,
        'dynamic_ncols': False,
        'smoothing': None,
        'bar_format': None,
        'initial': 0,
        'position': None,
        'leave': True,
        'maxinterval': 10.0,
        'maxiters': None,
        'ascii': None,
        'dynamic_miniters': False,
    }
    total = 10

# Generated at 2022-06-26 10:05:58.167929
# Unit test for method render of class RateColumn
def test_RateColumn_render():
#    task = Progress.task
    f = RateColumn(unit_scale=False, unit_divisor=1000, __dict__ = {'unit': 'unit', 'unit_scale': False, 'unit_divisor': 1000, '_ProgressColumn__dynamic_total': False, '_ProgressColumn__dynamic_dividend': False, '_ProgressColumn__dynamic_start': False})
#    assert f.render(task) == Text(f"{task.speed/unit:,.{precision}f} {suffix}{self.unit}/s", style="progress.data.speed")


# Generated at 2022-06-26 10:06:00.172819
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = None
    obj = RateColumn()
    assert obj.render(task) == Text("? /s", style="progress.data.speed")



# Generated at 2022-06-26 10:06:01.533806
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Placeholder
    tqdm_rich_0 = tqdm_rich()


# Generated at 2022-06-26 10:06:12.726721
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from random import random

    progress = Progress()

    with progress:
        bar = progress.add_task(
            "Task 1",
            percentage=0,
            total=100,
            start=True,
            description='Task 1',
        )

        for i in range(100):
            time.sleep(0.08 * random())
            progress.update(bar, percentage=i)

        # reset the bar
        progress.reset(total=50)
        time.sleep(0.25)

        bar = progress.add_task(
            "Task 2",
            percentage=100,
            total=100,
            start=True,
        )

        for i in range(100):
            time.sleep(0.08 * random())
            progress.update(bar, percentage=i)



# Generated at 2022-06-26 10:09:12.874357
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit = "", unit_scale = False, unit_divisor = 1000)
    task = trrange(100)
    rate_column_0.render(task)


# Generated at 2022-06-26 10:09:14.232559
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()


# Generated at 2022-06-26 10:09:15.804878
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()
