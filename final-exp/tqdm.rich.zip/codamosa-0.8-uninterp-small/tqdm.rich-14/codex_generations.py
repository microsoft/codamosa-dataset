

# Generated at 2022-06-26 09:59:24.547846
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    try:
        with Progress(
            "Downloading [progress.description]{task.description}",
            BarColumn(bar_width=None),
            FractionColumn(unit_scale=False, unit_divisor=1000),
            "[", TimeElapsedColumn(), ">", TimeRemainingColumn(), ",",
            RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]",
            transient=True) as prog:
            task_id = prog.add_task(
                "Case 0",
                total=1,
                completed=12,
                unit=None,
                unit_scale=False,
                unit_divisor=1000)
            prog.update(task_id, completed=12, description="Unit Test Case 0")
    except KeyboardInterrupt:
        pass

# Unit test

# Generated at 2022-06-26 09:59:34.940987
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich.progress as rich
    def __init__(self, *args, **kwargs):
        kwargs = kwargs.copy()
        kwargs['gui'] = True
        kwargs['disable'] = bool(kwargs.get('disable', False))
        progress = kwargs.pop('progress', None)
        tqdm_rich(*args, **kwargs)
        self._prog = rich.Progress(*progress, transient=not self.leave)
        self._prog.__enter__()
        self._task_id = self._prog.add_task(self.desc or "", **d)
    
    


# Generated at 2022-06-26 09:59:36.908448
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    prog = tqdm_rich('', file=None)
    assert prog.display()

# Generated at 2022-06-26 09:59:40.251292
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    assert fraction_column_0.render(100,100) == "100/100"


# Generated at 2022-06-26 09:59:44.306784
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        for i in trange(5, leave=True):
            pass
    except:
        raise AssertionError
    try:
        for i in trange(5, leave=False):
            pass
    except:
        raise AssertionError


# Generated at 2022-06-26 09:59:56.994720
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = td.default_task_obj
    task.completed = 12
    task.total = 13
    task.speed = None
    fc = FractionColumn(unit_scale=False)
    fc.render(task)
    fc = FractionColumn(unit_scale=True)
    fc.render(task)
    task.completed = 1443
    task.total = 1443
    fc = FractionColumn(unit_scale=True)
    fc.render(task)
    task.completed = 1443
    task.total = 14435
    fc = FractionColumn(unit_scale=True)
    fc.render(task)
    task.completed = 144359
    task.total = 144359
    fc = FractionColumn(unit_scale=True)

# Generated at 2022-06-26 10:00:01.415014
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    task = object()
    task.speed = int()
    assert type(rate_column_0.render(task)) == rich.text.Text

# Generated at 2022-06-26 10:00:11.160229
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    self = std_tqdm()
    self.n = 0
    self.last_print_n = 0
    self.total = float("nan")
    self.start_t = time.monotonic()
    self.avg_time = 0
    self.last_print_t = self.start_t
    self.last_print_n = 0
    self.smoothing = 0.3
    self._time = time.time
    with unittest.mock.patch('time.time', return_value=0, create=True):
        rate_column_0.render(self)
    with unittest.mock.patch('time.time', return_value=0.001, create=True):
        rate_column_0.render(self)

#

# Generated at 2022-06-26 10:00:19.435940
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = Progress()
    pbar.update(0, completed=20)
    assert pbar._tasks[0].completed == 20
    pbar.reset()
    assert pbar._tasks[0].completed == 0
    pbar.update(0, completed=20)
    assert pbar._tasks[0].completed == 20
    pbar.reset(30)
    assert pbar._tasks[0].completed == 0
    pbar.update(0, completed=20)
    assert pbar._tasks[0].completed == 20
    pbar.update(0, total=30)
    assert pbar._tasks[0].completed == 20
    pbar.reset()
    assert pbar._tasks[0].completed == 0

# Generated at 2022-06-26 10:00:30.012623
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm._tqdm_util_tests import TestCase
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm._tqdm import StatusPrinter
    class Test_tqdm_rich(TestCase):
        def test_reset(self):
            total = 10
            t = tqdm_rich(total=total)
            t.update(1)
            t.reset()
            self.assertEqual(t.n, 0)
            self.assertEqual(t.total, total)
            t.reset(total=20)
            self.assertEqual(t.n, 0)
            self.assertEqual(t.total, 20)

        def test_reset_leave(self):
            total = 10

# Generated at 2022-06-26 10:00:39.897645
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich(total=2)
    tqdm_rich_1.reset()

# Generated at 2022-06-26 10:00:44.842911
# Unit test for method render of class RateColumn
def test_RateColumn_render():

    column = RateColumn()

    column.render(300) == "300 B/s"
    column.render(30) == "30.0 B/s"


# Generated at 2022-06-26 10:00:47.231860
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    #tqdm_rich_0.display()
    tqdm_rich_0.display(self=tqdm_rich_0)


# Generated at 2022-06-26 10:00:51.149320
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    console = Console()
    console.print(tqdm_rich())

#Test update() method of tqdm_rich class

# Generated at 2022-06-26 10:00:53.132003
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    pass


# Generated at 2022-06-26 10:00:59.270373
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_column_0 = FractionColumn()
    class object:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    task = object(completed, total)
    succeeded_conditions = [task.completed == task.total]
    assert succeeded_conditions[0] and True


# Generated at 2022-06-26 10:01:08.910826
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from unittest import TestCase

    class TestClear(TestCase):

        def test_clear(self):
            tqdm_rich_0 = tqdm_rich()
            tqdm_rich_0.close()
            tqdm_rich_0.disable = True
            tqdm_rich_0.close()
            tqdm_rich_0.close()
            tqdm_rich_0.close()
            tqdm_rich_0.disable = False
            tqdm_rich_0.clear()
            tqdm_rich_0.disable = False
            tqdm_rich_0.clear()
            tqdm_rich_0.close()
            tqdm_rich_0.close()
            tqdm_rich_0.disable = True
            tqdm_rich_0

# Generated at 2022-06-26 10:01:10.760044
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pass


# Generated at 2022-06-26 10:01:14.619057
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t = RateColumn()
    t.render(None)
    t.render(None)
    assert t.render(None)


# Generated at 2022-06-26 10:01:16.166427
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pass  # TODO


# Generated at 2022-06-26 10:01:29.283506
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Initialize a rate column without arguments
    rate_column_0 = RateColumn()
    # Assert that RateColumn.render() does not raise any exceptions
    rate_column_0.render(None)


# Generated at 2022-06-26 10:01:30.224474
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-26 10:01:34.410613
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    assert hasattr(tqdm_rich_1, '_prog')
    tqdm_rich_1.disable = True
    tqdm_rich_1.display()
    tqdm_rich_1.disable = False
    tqdm_rich_1.init()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:01:39.028381
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Unit test for method reset of class tqdm_rich
    tqdm_rich_0 = tqdm_rich()
    total = 10
    tqdm_rich_0.reset(total)


# Generated at 2022-06-26 10:01:43.711820
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        for i in tqdm_rich(range(10), ncols=50):
            time.sleep(0.05)
    except TypeError as e:
        print("Test: raise TypeError")
        raise e
    except (KeyboardInterrupt, SystemExit):
        pass


# Generated at 2022-06-26 10:01:46.076490
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()



# Generated at 2022-06-26 10:01:51.209955
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        tqdm_rich_1 = tqdm_rich()

        # check if display correctly display progress bar
        tqdm_rich_1.display()
        tqdm_rich_1.close()

    except Exception as e:
        print("tqdm_rich.display(): ", e)

    return


# Generated at 2022-06-26 10:02:01.749935
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print("Method render called.")
    print("Task ID 0:")
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0._task_id = 0
    tqdm_rich_0.speed = 748
    print("Task ID 1:")
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1._task_id = 1
    tqdm_rich_1.speed = 514
    print("Task ID 2:")
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_2._task_id = 2
    tqdm_rich_2.speed = 1408
    print("Task ID 3:")
    tqdm_rich_3 = tqdm_rich()
    tqdm

# Generated at 2022-06-26 10:02:03.153472
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_fraction_column_render_0 = FractionColumn()


# Generated at 2022-06-26 10:02:05.730088
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:02:27.577014
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    prog = ProgressColumn()
    prog = RateColumn()
    prog = RateColumn(unit="")
    prog = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    prog = RateColumn(unit="unit", unit_scale=True, unit_divisor=1024)
    prog.render(task=None)


# Generated at 2022-06-26 10:02:30.785910
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    test_case_0()
    test_case_0()


if __name__ == '__main__':
    # Test Code
    test_tqdm_rich()

# Generated at 2022-06-26 10:02:36.032785
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    rc = RateColumn()
    rc_1 = rc.render(task=None)
    rc_2 = rc.render(task=1)
    rc_3 = rc.render(task='')
    rc_4 = rc.render(task=3.14)


# Generated at 2022-06-26 10:02:37.450523
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_case = FractionColumn()
    test_case.render()


# Generated at 2022-06-26 10:02:40.616485
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    task = None
    rate_column_0.render(task)


# Generated at 2022-06-26 10:02:44.334641
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Instanciate class
    rate_column_0 = RateColumn("unit")
    # Create a new task
    task_0 = object()
    # Call method
    result_0 = rate_column_0.render(task_0)
    # Assert result


# Generated at 2022-06-26 10:02:52.139783
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Setup an instance of RateColumn
    ratecolumn = RateColumn(
        unit="",
        unit_scale=False,
        unit_divisor=1000
    )

    for i in range(100):
        # Update with a new task
        task = {}
        
        # Call the method render
        ratecolumn.render(task)

        # Check that the returned value is correct
        assert True



# Generated at 2022-06-26 10:02:54.741721
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column_0 = FractionColumn(False, 1000)
    task_0 = column_0.render()
    assert task_0 is not None


# Generated at 2022-06-26 10:02:57.250334
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:03:10.975838
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # For 0 values
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = None
    tqdm_rich_0.desc = None
    tqdm_rich_0.format_dict = {}
    tqdm_rich_0.leave = None
    tqdm_rich_0.moveto = None
    tqdm_rich_0.maxinterval = None
    tqdm_rich_0.mininterval = None
    tqdm_rich_0.miniters = None
    tqdm_rich_0.n = None
    tqdm_rich_0.ncols = None
    tqdm_rich_0.nmin = None
    tqdm_rich_0.nmax = None
    tqdm_rich_0

# Generated at 2022-06-26 10:03:54.488773
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import TaskID
    # Test for initialisation of class
    tqdm_rich_1 = tqdm_rich('description', disable=False)
    assert tqdm_rich_1.total == 0, 'total parameter not equal to 0'
    assert tqdm_rich_1.smoothing == 0.3, 'smoothing parameter not equal to 0.3'
    assert tqdm_rich_1.format_dict['leave'] == True, 'leave parameter not equal to True'
    assert tqdm_rich_1.format_dict['desc'] == 'description', 'description not equal to description'
    assert tqdm_rich_1.disable == False, 'disable parameter not equal to False'

# Generated at 2022-06-26 10:03:55.891595
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich()
    t.clear()


# Generated at 2022-06-26 10:04:00.434474
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_render_0 = RateColumn()
    rate_column_render_1 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    rate_column_render_2 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-26 10:04:02.769910
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == None


# Generated at 2022-06-26 10:04:06.637863
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_1 = tqdm_rich()
    test_task = tqdm_rich_1.task_obj
    tqdm_rich_2 = FractionColumn()
    tqdm_rich_2.render(test_task)


# Generated at 2022-06-26 10:04:07.803707
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()


# Generated at 2022-06-26 10:04:10.302829
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:04:11.984101
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fractionColumn_0 = FractionColumn()
    fractionColumn_0.render(['task'])
    return


# Generated at 2022-06-26 10:04:15.007474
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_render = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    tqdm_rich_render.render(task="task")

# Generated at 2022-06-26 10:04:17.314856
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class_0 = RateColumn()
    class_0.render()

if __name__ == '__main__':
    test_case_0()
    test_RateColumn_render()

# Generated at 2022-06-26 10:05:41.783665
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    test_case_0()
    timeout = 30
    sleep(timeout)

if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:05:43.803821
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()



# Generated at 2022-06-26 10:05:45.963809
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total: int = 1
    tqdm_rich_0.reset(total=total)



# Generated at 2022-06-26 10:05:47.072388
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn().render(task = "")


# Generated at 2022-06-26 10:05:52.155586
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    reset_arg_names = ['total']
    reset_args = [
        None,
    ]
    for arg_name, arg in zip(reset_arg_names, reset_args):
        if arg_name in ['total']:
            assert arg is None or type(arg) in [
                int, float
            ], '''The type of argument {0} of method reset of class tqdm_rich should be one of [int, float]'''.format(
                arg_name)



# Generated at 2022-06-26 10:05:55.961578
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    def tqdm_rich_display(self, *_, **__):
        if not hasattr(self, '_prog'):
            return
        self._prog.update(self._task_id, completed=self.n, description=self.desc)

    tqdm_rich_0 = tqdm_rich()

# Generated at 2022-06-26 10:05:57.747756
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()


# Generated at 2022-06-26 10:06:01.190481
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Test case with no args
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()

    # Test case with args
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_2.reset(total=None)


# Generated at 2022-06-26 10:06:06.131557
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    # Total to use for the new bar
    total_1 = 7.47
    tqdm_rich_0.reset(total=total_1)
    # Total to use for the new bar
    total_2 = 3.06
    tqdm_rich_0.reset(total=total_2)


# Generated at 2022-06-26 10:06:08.659972
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:08:07.436605
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.clear()


# Generated at 2022-06-26 10:08:08.914398
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:08:10.628759
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:08:17.371592
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.colors import Color
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1._prog = Progress('test')
    tqdm_rich_1._task_id = 0
    tqdm_rich_1._prog = Progress('test')
    tqdm_rich_1._prog.default_format = 'test'
    tqdm_rich_1._prog.__enter__()
    tqdm_rich_1._prog.add_task('test', total=None, completed=0)
    tqdm_rich_1.reset(total=None)
    assert tqdm_rich_1._prog.default_format is 'test'

# Generated at 2022-06-26 10:08:20.229131
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:08:25.965961
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich import progress

    progress_0 = progress.Progress()
    progress_0.__enter__()
    task_id_0 = progress_0.add_task("task_desc_0", unit="unit_0", total=1000,
                                     position=0)
    tqdm_rich_0 = tqdm_rich(desc="desc_1")
    tqdm_rich_0._prog = progress_0
    tqdm_rich_0._task_id = task_id_0
    assert tqdm_rich_0.reset(total=1000) == None

# Generated at 2022-06-26 10:08:27.056240
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None)!=None

# Generated at 2022-06-26 10:08:29.629918
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    task_0 = None
    try:
        RateColumn_0.render(task_0)
    except:
        raise

# Generated at 2022-06-26 10:08:31.000992
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn_0 = RateColumn()
    ratecolumn_0.render()


# Generated at 2022-06-26 10:08:32.259020
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()