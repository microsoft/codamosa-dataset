

# Generated at 2022-06-26 09:59:21.287988
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10) as progress:
        for i in range(10):
            progress.update()
            time.sleep(0.1)



# Generated at 2022-06-26 09:59:25.085314
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich('abcdefghijklm')
    tqdm_rich_1.reset(total=123)


# Generated at 2022-06-26 09:59:29.332739
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset(total=123)

# Generated at 2022-06-26 09:59:37.439827
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t0 = TimeElapsedColumn()
    t1 = TimeRemainingColumn()
    t2 = RateColumn(unit="YB")
    t3 = RateColumn(unit="KB", unit_scale=True)
    t4 = RateColumn(unit="KB", unit_scale=True, unit_divisor=100)
    t5 = RateColumn(unit="KB", unit_scale=True, unit_divisor=1000)
    t6 = RateColumn(unit="KB", unit_scale=True, unit_divisor=10000)
    t7 = RateColumn(unit="KB", unit_scale=True, unit_divisor=100000)
    t8 = RateColumn(unit="KB", unit_scale=True, unit_divisor=10000000)

# Generated at 2022-06-26 09:59:40.616139
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn(unit_scale = False, unit_divisor = 1000)
    fraction_column.render()


# Generated at 2022-06-26 09:59:43.041835
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render(task=None)


# Generated at 2022-06-26 09:59:46.313280
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Default arguments
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 09:59:54.644100
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest
    from rich.progress import Progress

    class TestRateColumnRender(unittest.TestCase):
        def test_rate_column_basics(self):
            rate_column = RateColumn()

            task = Progress.Task("", total=10)
            task.update(5)
            task.update(6)

            rate_column.render(task)

            self.assertEqual(task.speed, 6)



# Generated at 2022-06-26 10:00:01.961319
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()

    # Call method reset of tqdm_rich_0
    # <class 'NoneType'>: None
    print(type(tqdm_rich_0.reset()), tqdm_rich_0.reset())


# Generated at 2022-06-26 10:00:11.408966
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=100, position=0, mininterval=0, maxinterval=10, miniters=1,
                   ascii=None, disable=False, unit='it', unit_scale=False, unit_divisor=1000,
                   dynamic_ncols=False, smoothing=0.3, bar_format=None, initial=0,
                   position_factor=None, gui=True, desc=None, leave=False, file=None,
                   ncols=None, mininterval_hr=None) as pbar:
        # Unit test for __init__() of class tqdm_rich
        assert pbar.total == 100
        assert pbar.position == 0
        assert pbar.miniters == 1
        assert pbar.ascii is False
        assert pbar.disable

# Generated at 2022-06-26 10:00:17.920225
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.clear()


# Generated at 2022-06-26 10:00:21.193976
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(desc='test_tqdm_rich_display') as t:
        t.display()



# Generated at 2022-06-26 10:00:25.352490
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render()


# Generated at 2022-06-26 10:00:37.833888
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Setup
    tqdm_rich_1 = tqdm_rich()
    rate_column_0 = RateColumn(unit = "", unit_scale = False, unit_divisor = 1000)
    rate_column_0.task = tqdm_rich_1
    # Target: <class 'rich.text.Text'>
    rate_column_0.task.speed = 'tqdm_rich_1.speed'
    # Target: 'tqdm_rich_1.speed / 1000 <class 'float'> 0 1'
    actual = rate_column_0.render(rate_column_0.task)
    # Teardown
    tqdm_rich_1.close()

# Generated at 2022-06-26 10:00:44.079985
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    task = tqdm_rich()
    task.speed = None
    assert column.render(task) == Text(f"? /s", style="progress.data.speed")



# Generated at 2022-06-26 10:00:50.391587
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .utils import Identity
    rate_column_0 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    rate_column_0.render(Identity(task="task", description="description", completed=None, total=None, ncols=None, ncols_fraction=None, unit="unit", ascii=False, bar_format="bar_format", postfix=None, unit_scale=None, unit_divisor=None, miniters=None, mininterval=None, maxinterval=None, mininterval_to_use=None, file=None, dynamic_ncols=None, leave=False, miniters_to_use=None, **kwargs))


# Generated at 2022-06-26 10:00:52.191003
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = False



# Generated at 2022-06-26 10:00:56.633212
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    value = None
    assert tqdm_rich_0.reset(value) == None


# Generated at 2022-06-26 10:00:58.684593
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:01:03.845174
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    unit_scale = False
    unit_divisor = 1000
    task = Progress()
    fractioncolumn_0 = FractionColumn(unit_scale, unit_divisor)
    fractioncolumn_1 = fractioncolumn_0.render(task)


# Generated at 2022-06-26 10:01:16.013856
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn_0 = RateColumn()
    task_0 = 0
    print(ratecolumn_0.render(task_0))


# Generated at 2022-06-26 10:01:19.388400
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:01:21.777947
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    for _i in range(4):
        RateColumn().render()


# Generated at 2022-06-26 10:01:25.349941
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_0 = RateColumn()
    task_0 = None
    assert RateColumn_0.render(task_0) is None

# Generated at 2022-06-26 10:01:31.346259
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()
    tqdm_rich_0.reset(total=None)
    tqdm_rich_0.display(*())
    tqdm_rich_0.clear(*())


# Generated at 2022-06-26 10:01:42.192142
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Unit test for method __init__ of class RateColumn
    r = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    r.render(task={'speed': 1234})  # should raise exception and print "False" on next line
    # Unit test for method __init__ of class RateColumn
    r = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    r.render(task={'speed': 1234})  # should raise exception and print "False" on next line



# Generated at 2022-06-26 10:01:44.830968
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:01:55.631138
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from tqdm.rich import FractionColumn
    from tqdm.std import tqdm

    test_tqdm_0 = tqdm()
    # Test parameters
    fraction_column_test_params_0 = dict({'unit_scale': False})

    fraction_column_0 = FractionColumn(**fraction_column_test_params_0)
    # Test calling with progress

# Generated at 2022-06-26 10:01:56.802577
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pass


# Generated at 2022-06-26 10:01:58.842967
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:02:10.366035
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = None
    tqdm_rich_0.reset(total)


# Generated at 2022-06-26 10:02:12.139759
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn()
    assert fraction_column.render() == None


# Generated at 2022-06-26 10:02:17.867919
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    lst = [int(i) for i in range(int(1e6))]
    for i in tqdm_rich(lst):
        i = i * i
    assert tqdm_rich(range(int(1e6)))

# Generated at 2022-06-26 10:02:19.542737
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    test_case_0()


# Generated at 2022-06-26 10:02:21.190883
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    instance = RateColumn()
    instance.render(None)


# Generated at 2022-06-26 10:02:22.117280
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_case_0()


# Generated at 2022-06-26 10:02:28.163777
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Set up context for the test
    progress = Progress("[progress.description]{task.description}")
    test_case_RateColumn_render_0 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)

    # Call the method
    # We do not do any assertions because the method is a pass-through
    test_case_RateColumn_render_0.render(progress)


# Generated at 2022-06-26 10:02:30.624945
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:02:33.208564
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:02:37.244491
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = None
    tqdm_rich_0.reset(total=total)


if __name__ == "__main__":
    for i in trange(10):
        ...

# Generated at 2022-06-26 10:02:56.694471
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()
    tqdm_rich_0.disable = True
    tqdm_rich_0.disable = False


# Generated at 2022-06-26 10:02:59.698984
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:03:12.686685
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_2 = tqdm_rich()
    tqdm_rich_2.total = 1e+3
    tqdm_rich_2.n = 1e+3
    tqdm_rich_2.nmin = 1e+3
    tqdm_rich_2.last_print_n = 1e+3
    tqdm_rich_2.last_print_t = 1e+3
    tqdm_rich_2.desc = "test_tqdm_rich_reset"
    tqdm_rich_2.close()
    assert tqdm_rich_2.total == 1e+3
    assert tqdm_rich_2.n == 1e+3
    assert tqdm_rich_2.nmin == 1e+3
    assert tqdm_rich

# Generated at 2022-06-26 10:03:24.647975
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Setup
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1._prog = Progress("[progress.description]{task.description}", BarColumn(bar_width=None), "")
    tqdm_rich_1._task_id = 2
    tqdm_rich_1._prog.add_task("", percent=0.0, completed=0, total=1, ncols=80, leave=False, unit="it",
                               unit_scale=False, desc=None)
    tqdm_rich_1.desc = ""
    tqdm_rich_1.n = 0
    # Test and verify
    tqdm_rich_1.display()

# Generated at 2022-06-26 10:03:30.775077
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn_0 = RateColumn()
    assert rateColumn_0._unit == ""
    assert rateColumn_0.unit == ""
    assert not rateColumn_0._unit_scale
    assert not rateColumn_0.unit_scale
    assert rateColumn_0._unit_divisor == 1000
    assert rateColumn_0.unit_divisor == 1000


# Generated at 2022-06-26 10:03:33.608060
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    args = [None, None]
    tqdm_rich_1.display(*args)


# Generated at 2022-06-26 10:03:38.983422
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 0
    unit = ""
    unit_scale = False
    unit_divisor = 1000
    obj = RateColumn(unit,unit_scale,unit_divisor)
    assert obj.render(speed) == Text("0.0 /s", style="progress.data.speed")


# Generated at 2022-06-26 10:03:42.473869
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn_0 = FractionColumn()


# Generated at 2022-06-26 10:03:44.721176
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=100) as t:
        for i in range(100):
            t.update(1)


# Generated at 2022-06-26 10:03:48.250971
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()
    return True

# Generated at 2022-06-26 10:04:48.650898
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import copy
    tqdm_rich_0 = tqdm_rich()
    # Test with and without a provided total value.
    for i in (None,42):
      tqdm_rich_0.reset = copy.deepcopy(i)
      assert tqdm_rich_0.reset == i, "tqdm_rich_0.reset == i failed"


# Generated at 2022-06-26 10:04:57.293821
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich_0 = tqdm_rich()
    task = tqdm_rich_0
    unit_scale = "fZBwH2G3LTPBCgso4D4m4Y7K4b4p4J"
    unit_divisor = "wVuBKtQ2FSVuLCiP"
    FractionColumn_ret_0 = FractionColumn.render(task, unit_scale=unit_scale, unit_divisor=unit_divisor)
    return FractionColumn_ret_0


# Generated at 2022-06-26 10:05:01.406397
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Initializations
    ang = FractionColumn(unit_scale=False, unit_divisor=1000)
    
    # Test
    assert ang.render(task) == Text(f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}",style="progress.download")
    
    

# Generated at 2022-06-26 10:05:03.400462
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert tqdm_rich_0.display() is None


# Generated at 2022-06-26 10:05:04.543418
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:05:05.741874
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    # pass


# Generated at 2022-06-26 10:05:11.673661
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    _progress = Progress(BarColumn(), TimeElapsedColumn())
    _progress.__enter__()
    _task_id = _progress.add_task('', total=100, completed=0)
    _progress_update = _progress.update(_task_id, completed=10, description='testing')
    _progress.__exit__(None, None, None)


# Generated at 2022-06-26 10:05:13.514005
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rh0 = RateColumn()
    rh0.render()


# Generated at 2022-06-26 10:05:15.212655
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()


# Aliases
tqdm = tqdm_rich
trange = trrange



# Generated at 2022-06-26 10:05:16.174243
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()


# Generated at 2022-06-26 10:06:26.443430
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress=RateColumn(unit='o')
    progress.render(ProgressColumn(unit='o'))


# Generated at 2022-06-26 10:06:29.043230
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    assert tqdm_rich_0.display() == None
    assert tqdm_rich_0.display(total=1) == None


# Generated at 2022-06-26 10:06:33.152624
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    task_0 = None
    result_0 = rate_column_0.render(task_0)



# Generated at 2022-06-26 10:06:36.111513
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn().render(task=None)
    RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(task=None)


# Generated at 2022-06-26 10:06:38.630588
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()

# Generated at 2022-06-26 10:06:39.836409
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn(  ).render(None)


# Generated at 2022-06-26 10:06:41.792071
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:06:44.167931
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Instantiate the class
    obj = FractionColumn()
    # Test the render method
    pass


# Generated at 2022-06-26 10:06:45.688790
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Init tqdm_rich instance
    tqdm_rich_instance = tqdm_rich()

    # Call display method
    tqdm_rich_instance.display()

# Generated at 2022-06-26 10:06:51.337146
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test = RateColumn()
    test.render(None)
    assert test.unit == ""
    assert test.unit_scale == False
    assert test.unit_divisor == 1000
