

# Generated at 2022-06-26 09:59:25.371097
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    var_0 = tqdm_rich()
    var_0.close()


# Generated at 2022-06-26 09:59:28.396633
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in range(1000):
        test_case_0()

# Generated at 2022-06-26 09:59:32.766492
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from types import GeneratorType
    var_0 = tqdm_rich()
    assert isinstance(var_0, GeneratorType)
    var_1 = test_case_0()
    assert isinstance(var_1, GeneratorType)

# Generated at 2022-06-26 09:59:37.456695
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # The constructor for the tqdm rich GUI progress bar
    progress_bar = RateColumn()
    assert progress_bar.render(2) == '2.00 B/s'


# Generated at 2022-06-26 09:59:42.428186
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    var_1 = tqdm_rich()
    # TODO: add more unit tests
    return var_1

if __name__ == '__main__':
    test_case_0()
    var_1 = test_tqdm_rich()

# Generated at 2022-06-26 09:59:43.209155
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_1 = RateColumn()


# Generated at 2022-06-26 09:59:45.930062
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_1 = trrange()
    var_1.reset(total=None)


# Generated at 2022-06-26 09:59:48.818794
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_0 = FractionColumn()
    var_1 = var_0.render(None)


# Generated at 2022-06-26 09:59:57.202087
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn()
    var_1 = Text(f"? {var_0.unit}/s", style="progress.data.speed")
    var_2 = Text(f"? {var_0.unit}/s", style="progress.data.speed")
    var_3 = Text(f"3.1k {var_0.unit}/s", style="progress.data.speed")
    var_4 = Text(f"3.1M {var_0.unit}/s", style="progress.data.speed")
    var_5 = var_0.render(task)


# Generated at 2022-06-26 10:00:01.640293
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    _range_0 = trange(10)
    # Display and/or update the progressbar.
    _range_0.display()
    return


# Generated at 2022-06-26 10:00:18.272431
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_00 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    var_01 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    var_02 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    var_03 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    var_04 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    var_05 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    var_06 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-26 10:00:26.590662
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)

    # Test that methods and attributes have been correctly initialized.
    assert (column.unit_scale == False
            and  column.unit_divisor == 1000
            and  column.header is None
            and  column.align == "left"
            and  isinstance(column.render(None), Text))


# Generated at 2022-06-26 10:00:35.209018
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Create tqdm_rich object with total=1 and a description
    t = tqdm_rich(total=1, desc="Example")

    # Assert that it has its default name
    assert t.desc == "Example"

    # Reset its total to 5
    t.reset(total=5)

    # Assert that it has its default name
    assert t.desc == "Example"


# Generated at 2022-06-26 10:00:39.617343
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich()
    return


# Generated at 2022-06-26 10:00:44.426769
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Initializing variables
    var_1 = RateColumn()
    # Test Case
    try:
        var_1.render()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 10:00:49.740272
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test for method render of class RateColumn
    rate_column_0 = RateColumn()
    # Test for attribute speed of class Progress
    # Test for attribute completed of class Progress
    # Test for attribute total of class Progress
    # Test for attribute speed of class Progress
    progress_0 = Progress()
    progress_0.update(0, speed=0.0)
    # Test for attribute speed of class Progress
    # Test for attribute completed of class Progress
    # Test for attribute total of class Progress
    # Test for attribute speed of class Progress
    progress_0.update(0, speed=0.0)
    rate_column_0.render(progress_0)
    # Test for attribute speed of class Progress
    progress_1 = Progress()
    progress_1.update(0, speed=0.0)

# Generated at 2022-06-26 10:00:51.309266
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn = RateColumn()
    RateColumn.render()


# Generated at 2022-06-26 10:01:02.750712
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import random
    import time
    from .utils import _range

    # Testing the tqdm_rich
    for _i in tqdm_rich(_range(0, 100), desc="test_reset"):
        time.sleep(0.01)

    for _i in tqdm_rich(_range(0, 100), desc="test_reset"):
        time.sleep(0.01)

    for _i in tqdm_rich(_range(0, 100), desc="test_reset"):
        time.sleep(0.01)

    with tqdm_rich(_range(0, random.randint(1, 20)),
                   desc="test_reset") as _pbar:
        for _j in _pbar:
            time.sleep(0.01)
            if _j % 5 == 0:
                _p

# Generated at 2022-06-26 10:01:08.016581
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Test the constructor of class tqdm_rich.

    """
    from .utils import _range

    var_0 = tqdm_rich(_range(2))


# Generated at 2022-06-26 10:01:09.141602
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_1 = RateColumn()


# Generated at 2022-06-26 10:01:16.824918
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t0 = tqdm_rich()
    t0._task_id = None
    t0.desc = None
    t0.n = None
    t0.display()



# Generated at 2022-06-26 10:01:19.474006
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_0 = FractionColumn(unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-26 10:01:21.779808
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    pass  # TODO

# Generated at 2022-06-26 10:01:23.822852
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn().render(task=None)


# Generated at 2022-06-26 10:01:25.677620
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_1 = RateColumn()


# Generated at 2022-06-26 10:01:27.763289
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    var_0 = trrange()
    var_0.display()


# Generated at 2022-06-26 10:01:29.590630
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn()


# Generated at 2022-06-26 10:01:30.786394
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = trange()


# Generated at 2022-06-26 10:01:35.804669
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn()
    var_1 = RateColumn("", True, 1000)
    var_2 = RateColumn("", False, 1)


# Generated at 2022-06-26 10:01:38.048145
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_0 = trrange()
    var_0.reset()


# Generated at 2022-06-26 10:01:41.932230
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    var_0 = trrange()
    var_0.close()


# Generated at 2022-06-26 10:01:44.005459
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_0 = tqdm()
    var_0.reset(total=0)


# Generated at 2022-06-26 10:01:46.029506
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_0 = trrange(total=100)
    var_0.reset(total=50)


# Generated at 2022-06-26 10:01:48.682493
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Test case 1
    var_1 = FractionColumn()
    pass


# Generated at 2022-06-26 10:01:50.363085
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn()
    var_1 = var_0.render()


# Generated at 2022-06-26 10:01:52.003103
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    assert column.render(1, 1) == column.render(1)


# Generated at 2022-06-26 10:01:53.155744
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_0 = FractionColumn()


# Generated at 2022-06-26 10:01:55.397051
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_0 = FractionColumn(unit_scale=False, unit_divisor=1000)
    return


# Generated at 2022-06-26 10:01:57.962474
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    instance_RateColumn = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    instance_RateColumn.render(task=None)
    pass

# Generated at 2022-06-26 10:02:08.895949
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Instance of class FractionColumn
    var_1 = FractionColumn()
    var_2 = var_1.render(0)
    var_3 = var_1.render(0)
    var_4 = var_1.render(0)
    var_5 = var_1.render(0)
    var_6 = var_1.render(0)
    var_7 = var_1.render(0)
    var_8 = var_1.render(0)
    var_9 = var_1.render(0)
    var_10 = var_1.render(0)
    var_11 = var_1.render(1)
    var_12 = var_1.render(0)
    var_13 = var_1.render(0)

# Generated at 2022-06-26 10:02:17.974505
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from rich.text import Text
    from rich.console import Console
    var_4 = TaskID(Console(), description='', total=None, completed=None)
    text = Text('Test', style=None)
    RateColumn.render(text, var_4)

# Generated at 2022-06-26 10:02:20.364673
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_3 = trrange()
    var_3.reset()


# Generated at 2022-06-26 10:02:22.073539
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_0 = tqdm_rich()
    var_0.reset()


# Generated at 2022-06-26 10:02:23.727195
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    var_1 = tqdm_rich()
    var_1.display()


# Generated at 2022-06-26 10:02:27.017742
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from .tqdm import tqdm
    with Progress() as progress:
        for i in tqdm(range(10), leave = True):
            print(i)


# Generated at 2022-06-26 10:02:29.604231
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    obj = RateColumn(unit_scale=True)
    obj.render(None)


# Generated at 2022-06-26 10:02:31.142425
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    trange_instance_0 = trrange()
    trange_instance_0.display()



# Generated at 2022-06-26 10:02:32.060731
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_0 = FractionColumn()


# Generated at 2022-06-26 10:02:37.157572
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # initial values
    var_0 = tqdm_rich(desc='test_tqdm_rich_reset')
    var_0.reset()
    var_0.n = 10
    var_0.reset(total=var_0.n)



# Generated at 2022-06-26 10:02:40.973865
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_1 = RateColumn(unit_divisor=1000)
    assert var_1.render(task=tqdm_rich()) == Text('? /s', style='progress.data.speed')


# Generated at 2022-06-26 10:02:45.247724
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_1 = FractionColumn()
    pass


# Generated at 2022-06-26 10:02:47.501949
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    with tqdm_rich(desc='RateColumn render', total=1) as var_1:
        var_1.update(1)



# Generated at 2022-06-26 10:02:49.486709
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn()
    var_0.render()


# Generated at 2022-06-26 10:03:01.993075
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():

    '''
    Reset to 0 iterations for repeated use.

    Parameters
    ----------
    total  : int or float, optional. Total to use for the new bar.

    
    '''

    print("\nCASE: tqdm_rich : reset")
    # __init__(...)
    # _prog.__enter__()
    # _task_id = _prog.add_task(self.desc or "", **d)
    # display(...)
    # clear(...)
    # _prog.update(self._task_id, completed=self.n, description=self.desc)
    # close()
    # _prog.__exit__(None, None, None)

    # Variable declaration
    tr_0 = trrange(10)
    tr_0.reset()



# Generated at 2022-06-26 10:03:07.725970
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    var_0 = trrange()
    var_0.reset()
    pass

if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:03:08.652283
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_0 = FractionColumn()



# Generated at 2022-06-26 10:03:14.506607
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import rich.console
    import sys
    import time
    import unittest

    class TestTqdmRich(unittest.TestCase):
        """Class to test tqdm_rich"""
        def test_tqdm_rich(self):
            """Test method tqdm_rich"""
            expected_0 = False
            var_0 = tqdm_rich
            self.assertEqual(expected_0, var_0)

    unittest.main()


# Generated at 2022-06-26 10:03:27.716384
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    var_0 = RateColumn()
    var_1 = RateColumn()
    var_2 = RateColumn()
    var_3 = RateColumn()
    var_4 = RateColumn()
    var_5 = RateColumn()
    var_6 = RateColumn()
    var_7 = RateColumn()
    var_8 = RateColumn()
    var_9 = RateColumn()
    var_10 = RateColumn()
    var_11 = RateColumn()
    var_12 = RateColumn()
    var_13 = RateColumn()
    var_14 = RateColumn()
    var_15 = RateColumn()
    var_16 = RateColumn()
    var_17 = RateColumn()
    var_18 = RateColumn()
    var_19 = RateColumn()
    var_20 = RateColumn()
    var_21 = RateColumn()
   

# Generated at 2022-06-26 10:03:29.690882
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    var_100 = FractionColumn(unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-26 10:03:30.905733
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert True


# Generated at 2022-06-26 10:03:36.899116
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import SimpleProgress

    rate_column_0 = RateColumn()


# Generated at 2022-06-26 10:03:42.874306
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Unit test for method render of class RateColumn
    # 
    # Initialise RateColumn with arguments
    from rich.progress import TimeRemainingColumn
    rate_column_0 = RateColumn()


# Generated at 2022-06-26 10:03:49.566874
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )
    d = {
        'total': int(5),
        'unit': 'it',
        'unit_scale': True,
        'unit_divisor': 1000,
        'leave': False
    }
    d2 = {
        'total': int(4),
        'unit': 'it',
        'unit_scale': True,
        'unit_divisor': 1000,
        'leave': False
    }

# Generated at 2022-06-26 10:03:54.163395
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    d = dict()
    d.update({
        'task':tqdm_rich,
        'total':None,
        'n':None,
        'desc':None,
        'unit':'bytes',
        'unit_scale':False,
        'unit_divisor':1000
    })
    r = RateColumn(**d)
    r._task = tqdm_rich
    r.render(tqdm_rich)


# Generated at 2022-06-26 10:03:57.673089
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render('task')
    rate_column_0.render('task', nolock=True)

# Generated at 2022-06-26 10:04:05.940907
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Text
    from tqdm.autonotebook import tqdm_gui
    import time
    for i in tqdm_gui(range(10), desc="test_RateColumn_render"):
        time.sleep(0.1)
    # assert tqdm_gui(range(10), desc="test_RateColumn_render").get_task().speed == 1
    # assert tqdm_gui(range(10), desc="test_RateColumn_render").get_task().speed is None


if __name__ == "__main__":
    from random import randint

    test_RateColumn_render()

# Generated at 2022-06-26 10:04:10.616857
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tr = tqdm_rich(desc="Test case 0", total=1000)
    for val in range(1000):
        tr.clear()
        tr.display()
        tr.update(1)
    tr.close()
    assert False


if __name__ == "__main__":
    test_case_0()
    # test_tqdm_rich_display()

# Generated at 2022-06-26 10:04:16.032948
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    unit_scale_0 = False
    unit_scale_1 = True
    unit_divisor_0 = 10
    unit_divisor_1 = 100
    RateColumn(unit_scale=unit_scale_0, unit_divisor=unit_divisor_0)
    RateColumn(unit_scale=unit_scale_1, unit_divisor=unit_divisor_1)

# Generated at 2022-06-26 10:04:18.052164
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit='', unit_scale=False, unit_divisor=1000).render(None) is None


# Generated at 2022-06-26 10:04:20.996597
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()

if __name__ == "__main__":
    test_case_0()
    test_RateColumn_render()

# Generated at 2022-06-26 10:04:28.194832
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t = RateColumn()
    t.render(None)


# Generated at 2022-06-26 10:04:33.732847
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()

    class Task:
        def __init__(self, unit):
            self.unit = unit
            self.total = None
            self.completed = None
            self.index = 0

    task = Task(1)
    task.total = 10
    task.completed = 4

    fc_result = fc.render(task)
    assert fc_result.text == "4.0/10 "


# Generated at 2022-06-26 10:04:36.192218
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    rate_column_0.render(task=None)



# Generated at 2022-06-26 10:04:39.402762
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn(total=2, completed=1, unit="K", unit_scale=True, unit_divisor=1000).render()

# Generated at 2022-06-26 10:04:44.737473
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    p = Progress()
    p.__enter__()
    with tqdm_rich() as t:
        for i in range(10):
            t.update(i+1)
    p.__exit__(None, None, None)


if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-26 10:04:46.618199
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit="B")
    rate_column_0.render({"speed": 1})

# Generated at 2022-06-26 10:04:49.130468
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Instantiate tqdm_rich object
    tqdm_rich_0 = tqdm_rich(0, 0)

    tqdm_rich_0.display()



# Generated at 2022-06-26 10:04:51.650386
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(range(10))
    t.display()


# Generated at 2022-06-26 10:04:54.728375
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()


if __name__ == '__main__':
    test_case_0()
    test_RateColumn_render()

# Generated at 2022-06-26 10:04:55.900068
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()


# Generated at 2022-06-26 10:05:16.477712
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    This function tests if render method of RateColumn returns a `rich.text.Text` object with
    correct string when speed provided.
    """
    def mock_task(completed, total, speed):
        """
        Mocks the class Task
        """
        class MockTask():
            """
            Mocks the class Task
            """
            def __init__(self):
                self.completed = completed
                self.total = total
                self.speed = speed

        return MockTask()

    task = mock_task(completed=10, total=100, speed=10)
    rate_column_0 = RateColumn()
    rate_column_1 = rate_column_0.render(task)
    assert str(rate_column_1) == "10.00 B/s"

# Generated at 2022-06-26 10:05:20.811214
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn(unit_scale=False, unit_divisor=1000)
    rate_column_0.render(None)



# Generated at 2022-06-26 10:05:23.906376
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_1 = FractionColumn()
    if __name__ == "__main__":
        print(fraction_column_1.render(fraction_column_0))


# Generated at 2022-06-26 10:05:31.009138
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=1, leave=True, unit_scale=False, desc="starting...") as pbar:
        pbar.reset(total=2)
        message = \
            "[progress.description]starting...[progress.percentage]  50%[progress.bar]"
        assert pbar.format_dict['desc'] == message
        pbar.reset(total=2, desc="..test")
        message = "[progress.description]..test[progress.percentage]  50%[progress.bar]"
        assert pbar.format_dict['desc'] == message

# Generated at 2022-06-26 10:05:39.243196
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Unit test tqdm_rich.display()

    """
    # All test cases here
    test_cases = [
        (0, )
    ]

    # Execute the tests
    with open('tqdm_rich.log', 'w') as f:
        for i, test_case in enumerate(test_cases):
            print('Test Case ' + str(i) +  ': ', end='')
            # Set up
            tqdm_rich_obj = tqdm_rich()

            # Execute
            tqdm_rich_obj.display(*test_case)

            # Verify
            f.write('\n')


# Generated at 2022-06-26 10:05:48.405703
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    def test1():
        rate_instance = RateColumn()
        assert rate_instance.render(Task(speed = 0.0)) == Text('0.0  /s', style = 'progress.data.speed')
    test1()

    def test2():
        rate_instance = RateColumn()
        assert rate_instance.render(Task(speed = None)) == Text('?  /s', style = 'progress.data.speed')
    test2()

    def test3():
        rate_instance = RateColumn()
        assert rate_instance.render(Task(speed = 5)) == Text('5.0  /s', style = 'progress.data.speed')
    test3()
    rate_instance = RateColumn(unit = 'B')

# Generated at 2022-06-26 10:05:50.785932
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    task_0 = rate_column_0.render(1)
    assert task_0 == Text('0.0 /s', style='progress.data.speed')

# Generated at 2022-06-26 10:05:52.241935
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.render(task=Progress())



# Generated at 2022-06-26 10:06:00.385117
# Unit test for method reset of class tqdm_rich

# Generated at 2022-06-26 10:06:02.312895
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress.Task('foo', completed=1, total=2)
    assert fraction_column_0.render(task) == '0.5/1.0 '


# Generated at 2022-06-26 10:06:38.938196
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    reset = tqdm_rich.reset
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__
    #  __init__

# Generated at 2022-06-26 10:06:44.847222
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = 40 / 100
    assert fraction_column_0.render(task) == Text("0.4/1.0", style="progress.download")
    task = 25 / 100
    assert fraction_column_0.render(task) == Text("0.2/1.0", style="progress.download")
    task = 100 / 100
    assert fraction_column_0.render(task) == Text("1.0/1.0", style="progress.download")


# Generated at 2022-06-26 10:06:55.947145
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        for _ in t:
            pass
    with tqdm_rich(total=10) as t:
        for _ in t:
            pass
    with tqdm_rich(total=10) as t:
        for _ in t:
            pass
    with tqdm_rich(total=10) as t:
        for _ in t:
            t.reset()


if __name__ == '__main__':
    from tqdm.auto import trange
    for i in trange(10):
        for j in trange(10):
            pass

# Generated at 2022-06-26 10:06:58.580966
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render("task") == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render("task") == Text("? B/s", style="progress.data.speed")


# Generated at 2022-06-26 10:07:02.060122
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    r = tqdm_rich(range(128))
    r.reset()
    assert r.n == 0
    r.reset(total=10)
    assert r.total == 10



# Generated at 2022-06-26 10:07:02.840019
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_case_0()


# Generated at 2022-06-26 10:07:15.862306
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Instantiate tqdm_rich with total = None
    with tqdm_rich(total = None, desc ="", ascii = True, unit ="", disable = False, bar_format = "") as total_none:
        pass
    # Instantiate tqdm_rich with total = 0
    with tqdm_rich(total = 0, desc ="", ascii = True, unit ="", disable = False, bar_format = "") as total_zero:
        pass
    # Instantiate tqdm_rich with total = 10
    with tqdm_rich(total = 10, desc ="", ascii = True, unit ="", disable = False, bar_format = "") as total_ten:
        pass
    # Instantiate tqdm_rich with total = 10.0

# Generated at 2022-06-26 10:07:16.993889
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Init
    fraction_column_0 = FractionColumn()


# Generated at 2022-06-26 10:07:18.474537
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=None) as c:
        c.reset()
        c.reset(total=10)

# Generated at 2022-06-26 10:07:27.119784
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    tests that the reset method of tqdm_rich works as expected by checking reset
    for boundary conditions
    """
    fraction_column_0 = FractionColumn()
    progresscolumn_0 = ProgressColumn()
    text_0 = Text('5.5/5.5 G', style='progress.download')
    assert(fraction_column_0.render(progresscolumn_0) == text_0)
    progresscolumn_1 = ProgressColumn()
    progresscolumn_1.completed = 0
    progresscolumn_1.total = 10
    text_1 = Text('0/10 ', style='progress.download')
    assert(fraction_column_0.render(progresscolumn_1) == text_1)
    progresscolumn_2 = ProgressColumn()
    progresscolumn_2.completed = 10

# Generated at 2022-06-26 10:08:27.279003
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(unit_scale=True, total=2) as t:
        assert t.total == 2
        t.update(2)
        assert t._n == 2
        t.reset(total=3)
        assert t.total == 3
        assert t._n == 0

if __name__ == "__main__":
    a = test_case_0()
    a = test_tqdm_rich_reset()

# Generated at 2022-06-26 10:08:29.593513
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Test for method display without argument
    for _ in tqdm(range(0, 9)):
        pass

# Generated at 2022-06-26 10:08:31.186538
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render(1)
    rate_column_0.render(2)


# Generated at 2022-06-26 10:08:32.467138
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_fraction_column = FractionColumn()
    test_fraction_column.render()

# Generated at 2022-06-26 10:08:35.202529
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()
    rate_column_0.render(task=None)


# Generated at 2022-06-26 10:08:41.949008
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(desc="test")
    task.completed = 0.5
    task.total = 2.3
    assert (FractionColumn().render(task) == Text("0.5/2.3", style="progress.download"))
    assert (FractionColumn(unit_scale=True).render(task) == Text("500.0/2.3 K", style="progress.download"))
    assert (FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/2.3 K", style="progress.download"))
    assert (FractionColumn(unit_scale=True, unit_divisor=12).render(task) == Text("41.7/2.3 K", style="progress.download"))

# Generated at 2022-06-26 10:08:44.705678
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=5) as pbar:
        for i in range(5):
            pbar.update()
    pbar.reset(total=9)
    for i in range(9):
        pbar.update()

# Generated at 2022-06-26 10:08:50.034298
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        cls = tqdm_rich
    except NameError:
        raise ValueError('Cannot find class "tqdm_rich"')

    def _test_tqdm_rich_reset():
        import sys
        try:
            cls.reset(total=1)
        except:
            pass
    _test_tqdm_rich_reset()

# Generated at 2022-06-26 10:08:59.567202
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-26 10:09:00.968282
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    result = RateColumn.render(tqdm_rich, )
    assert result is not None
