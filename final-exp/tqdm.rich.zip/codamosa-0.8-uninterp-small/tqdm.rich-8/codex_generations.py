

# Generated at 2022-06-26 09:59:33.117659
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    def __init__(self):
        self.bar_format = "[{l_bar}{bar}{r_bar}] {rate_noinv_fmt} {n_fmt}/{total_fmt} {desc}"
        self.total = 10
        self.desc = "test"
        self.n = 5
    tqdm_rich_display = tqdm_rich()
    tqdm_rich_display.__init__ = __init__
    tqdm_rich_display.display()


# Generated at 2022-06-26 09:59:35.749097
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn_object_0 = FractionColumn()
    FractionColumn_object_0.render()


# Generated at 2022-06-26 09:59:39.674166
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich_close = tqdm_rich()
    tqdm_rich_close_close = tqdm_rich_close.close()


# Generated at 2022-06-26 09:59:41.626989
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    percentage = 0.5
    FractionColumn().render(Task(percentage))

# Generated at 2022-06-26 09:59:42.471141
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_render_0 = RateColumn()


# Generated at 2022-06-26 09:59:45.064673
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 09:59:48.740411
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich_close = tqdm_rich()
    tqdm_rich_close.close()


# Generated at 2022-06-26 09:59:55.799258
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_test_Renderer_0 = RateColumn()
    tqdm_test_ProgressTask_0 = ProgressTask(
        amount=0.0, completed=0.0, total=0.0, description='', speed=0.0)
    tqdm_test_Text_0 = tqdm_test_Renderer_0.render(tqdm_test_ProgressTask_0)


# Generated at 2022-06-26 09:59:57.405618
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # TODO: Test
    pass


# Generated at 2022-06-26 10:00:00.565199
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column_0 = FractionColumn()
    fraction_column_0.__init__()


# Generated at 2022-06-26 10:00:13.045910
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():

    f = tqdm_rich()
    f.reset(12)
    assert f._prog.total == 12
    f.reset(100)
    assert f._prog.total == 100

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:00:15.458469
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.reset()


# Generated at 2022-06-26 10:00:18.165538
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:00:29.543953
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    tc = TimeElapsedColumn()
    task = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", tc, "<", TimeRemainingColumn(), ",", rc, "]"
    )
    task_instance = task.add_task("hello", total=10)
    rc.render(task.add_task("hello", total=10))
    tc_res = tc.render(task.add_task("hello", total=10))
    assert isinstance(tc_res, Text)
    assert isinstance(rc.render(task.add_task("hello", total=10)), Text)


# Generated at 2022-06-26 10:00:31.826819
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    test_case_0()
    obj_tqdm_rich_0 = tqdm_rich_0.reset()

if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:00:34.476873
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()
    return


# Generated at 2022-06-26 10:00:40.006278
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # call method clear of class tqdm_rich
    test_case_0().clear()
    # return None


# Generated at 2022-06-26 10:00:47.350161
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    object_0 = FractionColumn()
    object_1 = Progress()
    object_2 = object_1.add_task("")
    object_3 = object_1.update(object_2, "", "", "", "", "", "")
    object_4 = object_0.render(object_3)
    return object_4.style


# Generated at 2022-06-26 10:00:52.158840
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    # Test with positional argument
    tqdm_rich_0.reset(8)
    # Test with named argument
    tqdm_rich_0.reset(total=int())



# Generated at 2022-06-26 10:00:56.633678
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.close()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:01:05.414003
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()



# Generated at 2022-06-26 10:01:09.101636
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:01:14.544127
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()
    tqdm_rich_0.clear(None, None)


# Generated at 2022-06-26 10:01:18.566029
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():

    def tqdm_rich_display(self):
        if self.disable:
            return

    for i in tqdm_rich([]):
        pass


# Generated at 2022-06-26 10:01:19.721987
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass



# Generated at 2022-06-26 10:01:23.527896
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    expected = tqdm_rich()
    expected.reset(None)
    test = tqdm_rich()
    test.reset(None)
    assert expected == test


# Generated at 2022-06-26 10:01:25.996202
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()


# Generated at 2022-06-26 10:01:29.666427
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:01:31.175078
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()



# Generated at 2022-06-26 10:01:35.668806
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_1 = tqdm_rich(total=1)
    tqdm_rich_1.display()


# Generated at 2022-06-26 10:01:50.915036
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Init a tqdm_rich object
    tqdm_rich_0 = tqdm_rich()

    # Assert method works as expected
    tqdm_rich_0.reset()
    tqdm_rich_0.reset(total=65)

# Generated at 2022-06-26 10:02:01.387107
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm_notebook, tqdm_pandas, tqdm_gui, tqdm_gui_dummy

    # args
    tqdm_rich(1)
    tqdm_rich(1, disable=True)
    tqdm_rich(1, disable=False)
    tqdm_rich(1, disable=None)  # disable = None is None
    tqdm_rich(1, total=1)
    tqdm_rich(1, position=1)

    # kwargs
    tqdm_rich(total=1)
    tqdm_rich(position=1)
    tqdm_rich(desc=None)
    tqdm_rich(mininterval=0.1)
    tqdm_rich(miniters=0)
   

# Generated at 2022-06-26 10:02:12.223808
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Assign global variables
    global progress
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=d['unit_scale'], unit_divisor=d['unit_divisor']),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit=d['unit'], unit_scale=d['unit_scale'],
                        unit_divisor=d['unit_divisor']), "]"
    )
    global d
    d = self.format_dict
    global self
    self = tqdm_rich_0

# Generated at 2022-06-26 10:02:17.974719
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Create instance of class RateColumn
    rate_column_0 = RateColumn()
    # Call method render of rate_column_0 and save result to variable result_0
    result_0 = rate_column_0.render()



# Generated at 2022-06-26 10:02:21.147674
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:02:30.074904
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from contextlib import contextmanager
    from io import StringIO
    from sys import stdout
    from textwrap import dedent
    from traceback import format_exc
    import unittest

    #############setup and utility functions##############
    @contextmanager
    def nostderr():
        """
        contextmanager to redirect stderr to null.
        """
        orig_stderr = stdout.fileno()
        devnull = open(os.devnull, 'wb')
        stdout.flush()
        os.dup2(devnull.fileno(), orig_stderr)
        try:
            yield
        finally:
            # terminate devnull (unnecessary here)
            devnull.close()
            # restore original stderr
            stdout = os.fdopen(orig_stderr, 'wb')


# Generated at 2022-06-26 10:02:31.262481
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) is None

# Generated at 2022-06-26 10:02:34.283765
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with trange(1) as pbar:
        pbar.display()


# Generated at 2022-06-26 10:02:41.349913
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = False
    tqdm_rich_0.leave = False
    tqdm_rich_0.desc = "tqdm_rich_0.desc"
    tqdm_rich_0.n = 0
    tqdm_rich_0._prog = Progress()
    tqdm_rich_0._task_id = 0
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:02:43.698036
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear(1, 2)

# Generated at 2022-06-26 10:03:09.907477
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich_0 as tqdm_rich_0:
        tqdm_rich_0.close()
        tqdm_rich_0.clear()


# Generated at 2022-06-26 10:03:16.088642
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Initializing tqdm with range 0 to 4
    tqdm_rich_0 = tqdm_rich(total=4)
    # Updating tqdm_rich with a range of values
    for i in range(4):
        pass
    # Asserting the result with boolean value True
    assert tqdm_rich_0.n == 4
    # Resetting the attribute n of tqdm_rich_0 with zero
    tqdm_rich_0.reset()
    # Asserting the result with the boolean value True 
    assert tqdm_rich_0.n == 0

# Generated at 2022-06-26 10:03:21.782787
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import rich.progress
    import rich.console
    assert isinstance(rich.progress.Progress(), rich.console.Console)
    assert isinstance(rate_column_0, rich.progress.ProgressColumn)
    rate_column_0.render


# Generated at 2022-06-26 10:03:25.001402
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    assert tqdm_rich_1.clear() == None
    assert tqdm_rich_1.clear(True) == None


# Generated at 2022-06-26 10:03:31.785417
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest
    from .docs import _inst
    from .utils import _range

    with pytest.raises(TypeError):
        list(tqdm_rich(_range(10), total=10))
    list(tqdm_rich(_range(10)))

    t = _inst(total=10)
    assert t.n == 0
    t.reset(total=100)
    assert t.n == 0
    assert t.total == 100

# Generated at 2022-06-26 10:03:35.995906
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()



# Generated at 2022-06-26 10:03:41.895003
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()  # should pass & not raise an exception


# Generated at 2022-06-26 10:03:46.008478
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest
    task = None
    speed = None
    unit = ""
    unit_scale = False
    unit_divisor = 1000
    rate_column = RateColumn(unit, unit_scale, unit_divisor)
    rate_column.render(task)


# Generated at 2022-06-26 10:03:48.642858
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()  # Input: no parameter
    tqdm_rich_0.reset(total=4)  # Input: total=4



# Generated at 2022-06-26 10:03:52.938063
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column_0 = RateColumn()



# Generated at 2022-06-26 10:04:49.899027
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_render_0 = RateColumn()
    try:
        RateColumn_render_0.render()
    except NotImplementedError:
        pass
    else:
        raise AssertionError('NotImplementedError not raised')


# Generated at 2022-06-26 10:04:53.923684
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_0 = tqdm_rich()
    total = 2.4
    # result - None
    tqdm_rich_0.reset(total=total)


# Generated at 2022-06-26 10:04:57.445672
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich(disable=False)

    # TEST CASE:
    # Should return True

    # TEST CASE:
    # Should return True

    # TEST CASE:
    # Should return True



# Generated at 2022-06-26 10:04:59.200758
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.clear()


# Generated at 2022-06-26 10:05:05.593410
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Test for method reset of class tqdm_rich
    import random
    import time

    with tqdm_rich(total=10, desc='Testing tqdm_rich.reset()') as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(random.random())
        pbar.reset(total=20)
        for i in range(20):
            pbar.update(1)
            time.sleep(random.random())


if __name__ == "__main__":  # pragma: no cover
    test_case_0()
    test_tqdm_rich_reset()

# Generated at 2022-06-26 10:05:07.046348
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:05:09.391918
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    assert hasattr(tqdm_rich_0.reset, '__call__')

# Generated at 2022-06-26 10:05:10.991414
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    :return:
    """
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()

# Generated at 2022-06-26 10:05:13.641807
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.clear()


# Generated at 2022-06-26 10:05:16.084502
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_ = tqdm_rich()
    # No output in .travis.yml
    tqdm_rich_.display()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich_display()

# Generated at 2022-06-26 10:06:57.354525
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()


# Generated at 2022-06-26 10:07:03.127563
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.disable = True
    tqdm_rich_0.display()
    tqdm_rich_0.disable = False
    tqdm_rich_0.close()
    tqdm_rich_0._task_id = 'ycQXFCW'
    tqdm_rich_0._prog = Progress()
	# unit test for method display of class tqdm_rich ends


# Generated at 2022-06-26 10:07:05.453930
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Create an instance of tqdm_rich
    tqdm_rich_1 = tqdm_rich()
    # Reset the instance
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:07:06.421061
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    testing_RateCOlumn_render = RateColumn()


# Generated at 2022-06-26 10:07:16.238448
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    tqdm_rich_0 = tqdm_rich()
    if isinstance(tqdm_rich_0, tqdm_rich):
        # Check if the constructor returned an instance of type tqdm_rich
        assert True
    else:
        raise AssertionError


if __name__ == "__main__":
    test_case_0()
    test_tqdm_rich()

# Generated at 2022-06-26 10:07:21.607958
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.unit = "unit"
    tqdm_rich_0.unit_scale = False
    tqdm_rich_0.unit_divisor = 1000
    RateColumn_0 = RateColumn(unit=tqdm_rich_0.unit, unit_scale=tqdm_rich_0.unit_scale, unit_divisor=tqdm_rich_0.unit_divisor)
    RateColumn_0.render(task=tqdm_rich_0)


# Generated at 2022-06-26 10:07:23.242085
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_0 = tqdm_rich()
    tqdm_rich_0.display()

# Generated at 2022-06-26 10:07:25.315432
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_RateColumn = RateColumn()
    test_RateColumn.render()


# Generated at 2022-06-26 10:07:27.424111
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich_1 = tqdm_rich()
    tqdm_rich_1.reset()


# Generated at 2022-06-26 10:07:30.030627
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    tqdm_rich_2 = tqdm_rich(disable=False)

    tqdm_rich_2.disable = True

    tqdm_rich_2.disable = False

    tqdm_rich_2.disable = True
    tqdm_rich_2.disable = False