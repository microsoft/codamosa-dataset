

# Generated at 2022-06-22 15:53:24.627732
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(123, 4567).text == "123/4.6 K"


# Generated at 2022-06-22 15:53:25.296791
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich(total=1).close()

# Generated at 2022-06-22 15:53:29.285581
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_column = RateColumn()
    task1 = Progress(total=100)
    task2 = Progress(total=100, speed=100)
    task3 = Progress(total=100, speed=1000000)
    task4 = Progress(total=100, speed=10000000000)
    task5 = Progress(total=100, speed=1000000000000000)
    task6 = Progress(total=100, speed=100000000000000000000)
    task7 = Progress(total=100, speed=1000000000000000000000000)
    assert progress_column.render(task1) == Text(f"? /s", style="progress.data.speed")
    assert progress_column.render(task2) == Text(f"1 /s", style="progress.data.speed")

# Generated at 2022-06-22 15:53:34.587411
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich.reset()."""
    with tqdm_rich(0) as bar:
        bar.reset(5)
        assert bar.total == 5, 'Problem in tqdm_rich.reset().'
        bar.reset()
        assert bar.total == 0, 'Problem in tqdm_rich.reset().'



# Generated at 2022-06-22 15:53:36.424796
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    for i in tqdm_rich(range(9)):
        sleep(0.5)

# Generated at 2022-06-22 15:53:42.247809
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from rich.progress import TaskID
    from unittest.mock import create_autospec, call
    bar = create_autospec(Progress())
    bar.add_task = lambda d, **kw: TaskID(1)
    bar.update = lambda i, c, **kw: None
    t = tqdm_rich(total=10, bar=bar)
    t.display()
    bar.update.assert_has_calls([call(TaskID(1), c=0)])
    t.reset()
    t.display()
    bar.update.assert_has_calls([call(TaskID(1), c=0)])

# Generated at 2022-06-22 15:53:43.480032
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(5))
    t.clear()
    t.close()

# Generated at 2022-06-22 15:53:49.202196
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Smoke test
    f = tqdm_rich(range(10))
    f.reset()
    f.close()

    # Test resetting
    f = tqdm_rich(range(10))
    f.update(1)
    f.reset()
    f.update(3)
    f.close()
    assert f.n == 3

    # Test changing total
    f = tqdm_rich(range(10))
    f.reset(20)
    f.update(3)
    f.close()
    assert f.n == 3

# Generated at 2022-06-22 15:53:50.676080
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(10)
    t.close()
    assert True  # if no exceptions, then ok


# Generated at 2022-06-22 15:53:55.221660
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test for tqdm_rich close method"""
    try:
        with tqdm_rich(total=10) as t:
            for _ in range(10):
                t.set_description("sample")
                t.update()
    except Exception as ex:
        raise ex



# Generated at 2022-06-22 15:54:07.593409
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = std_tqdm(total=1000)
    task.n = 0

    fc = FractionColumn()
    str0 = fc.render(task)

    task.n = 123
    str123 = fc.render(task)

    task.n = 456
    str456 = fc.render(task)

    task.n = 1000
    str1000 = fc.render(task)

    assert str0 == "0/1 k"
    assert str123 == "0.1/1 k"
    assert str456 == "0.5/1 k"
    assert str1000 == "1.0/1 k"

# Generated at 2022-06-22 15:54:11.332434
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    import time
    for i in tqdm(range(1, 5), desc='test_tqdm_rich', position=0, leave=True):
        time.sleep(0.3)
        if i == 2:
            tqdm.reset()
    tqdm.close()

# Generated at 2022-06-22 15:54:23.362764
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress, ProgressColumn
    from rich.progress import BarColumn, Text, TimeElapsedColumn, TimeRemainingColumn, filesize

    class FractionColumn(ProgressColumn):
        """Renders completed/total progress, e.g. '0.5/2.3 G'."""
        def __init__(self, unit_scale=False, unit_divisor=1000):
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super().__init__()

        def render(self, task):
            completed = int(task.completed)
            total = int(task.total)

# Generated at 2022-06-22 15:54:28.104904
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time

    total = 100
    with tqdm(total=total) as _tqdm:
        for _ in range(total):
            _tqdm.set_description("Test")
            _tqdm.update()
            time.sleep(0.2)

# Generated at 2022-06-22 15:54:32.237967
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm._tqdm import tqdm_gui
    t = tqdm_rich(iterable=[1, 2, 3], total=3)
    t.__class__ = tqdm_gui
    assert t._prog is not None
    t.close()
    assert t._prog is None


# Generated at 2022-06-22 15:54:43.221190
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.console import Console
    console = Console()

# Generated at 2022-06-22 15:54:54.401307
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from unittest.mock import Mock
    import pytest
    task = Mock()
    task.completed = 1.12
    task.total = 1.23
    task.description = "description"
    task.percent = 1.23
    task.percentage = 1.23
    task.remaining = 1.23
    task.speed = 1.23
    test_case_list = [
        [FractionColumn(), Text("1.1/1.2 ")],
        [FractionColumn(unit_scale=True, unit_divisor=1000), Text("0.00/0.00 ")],
        [FractionColumn(unit_scale=True, unit_divisor=1024), Text("0.00/0.00 ")],
    ]

# Generated at 2022-06-22 15:55:02.231362
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .utils import format_sizeof, remove_unicode
    from .utils import tokenize, format_interval
    from .utils import _unicode

    n = 100
    timerange = 15
    title = "test_tqdm_rich_display"
    bar_format_str = title
    bar_format_str += ": {n_fmt}/{total_fmt} [{elapsed}<{remaining}{postfix}]"
    postfix = """[{rate_noinv_fmt}{postfix} {unit_scale}/s]"""
    bar_format_str += postfix

    # Tests repeated use of tqdm
    with tqdm_rich(total=n, bar_format=bar_format_str) as t:
        for _ in range(n):
            t.set_postfix

# Generated at 2022-06-22 15:55:08.237405
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    TestCase for the method render of class FractionColumn
    """
    from rich.progress import TaskID
    task_id = TaskID()
    task_id.total = 10
    task_id.completed = 1
    fraction_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    fraction_column.render(task_id)

# Generated at 2022-06-22 15:55:15.475240
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = object()
    task.total = 10
    task.completed = 2
    task.speed = 0.5
    unit_divisor = 1000
    unit_scale = True
    col = RateColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
    assert col.render(task) == Text(f"500.0  /s", style="progress.data.speed")


# Generated at 2022-06-22 15:55:35.023058
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # TODO: this test is probably not correct, but currently it is not possible to
    #  properly test the reset method because we don't have a way to test behavior when
    #  the Progress object is not attached to the terminal
    import random
    import time

    random.seed(0)
    iterations = 1
    foo_ref = 1
    for _ in range(0, iterations):
        t = tqdm_rich(total=10)
        for _ in trange(iterations):
            foo_cur = random.random()
            t.reset(total=int(10 * foo_cur))
            if foo_cur < foo_ref:
                foo_ref = foo_cur
            time.sleep(0.1)
            t.update(1)
        t.close()

# Generated at 2022-06-22 15:55:41.721482
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    for bar in [False, True, None]:
        for leave in [False, True, None]:
            for disable in [False, True, None, 0]:
                with tqdm_rich(disable=disable, bar=bar, leave=leave) as t:
                    t.update(1)
                    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich()

# Generated at 2022-06-22 15:55:45.152151
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test `tqdm_rich.display()`."""
    from tests_tqdm._utils import TestTqdm
    TestTqdm(tqdm_rich).test_display()



# Generated at 2022-06-22 15:55:56.156541
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method `reset` of class `tqdm.rich.tqdm_rich`."""
    import sys

    with tqdm_rich(total=100) as progress:
        progress.status = "TEST"
        progress.reset(total=500)
        for _ in range(500):
            progress.update()
            if progress.n >= 450:
                progress.reset(total=600)
            if progress.n >= 550:
                progress.reset(total=0)
                progress.reset(total=700)
            if progress.n >= 650:
                sys.stderr.write("This is a test error.\n")

if __name__ == '__main__':
    test_tqdm_rich_reset()

# Generated at 2022-06-22 15:56:01.585098
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_ratecolumn = RateColumn(unit_scale=True, unit_divisor=1000)
    rates = 0, 1000, 1000*1000, 1000*1000*1000, 1000*1000*1000*1000
    results = ["0 ", "1 K ", "1 M ", "1 G ", "1 T "]
    for rate, result in zip(rates, results):
        res = tqdm_ratecolumn.render(rate)
        assert res == result, 'error of rate:{}'.format(rate)


# Generated at 2022-06-22 15:56:11.664099
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn(unit_scale=True, unit_divisor=1024)
    progress = {'completed': 1028, 'total': 1048576}
    assert f.render(progress) == Text(
        "0.0/1.0 K", style="progress.download")
    progress = {'completed': 1, 'total': 1024}
    assert f.render(progress) == Text(
        "0.0/1.0 K", style="progress.download")
    progress = {'completed': 512, 'total': 1024}
    assert f.render(progress) == Text(
        "0.5/1.0 K", style="progress.download")
    progress = {'completed': 1025, 'total': 1024}

# Generated at 2022-06-22 15:56:23.013962
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # common case
    rc = RateColumn()
    assert rc.render(Progress(total=100)) == Text('? /s', style='progress.data.speed')
    # specific case
    rc = RateColumn()
    assert rc.render(Progress(total=100, completed=1)) == Text('100.0 /s', style='progress.data.speed')
    # specific case
    rc = RateColumn()
    assert rc.render(Progress(total=None)) == Text('? /s', style='progress.data.speed')
    # specific case
    rc = RateColumn()
    assert rc.render(Progress(total=None, completed=1)) == Text('1.0 /s', style='progress.data.speed')



# Generated at 2022-06-22 15:56:31.882969
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=100, desc="Test") as _t:
        for _ in _t:
            pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

    from tqdm import trange  # NOQA
    import time

    with tqdm(total=100) as pbar:
        for i in trange(10, desc='1st loop', leave=False):
            for j in trange(5, desc='2nd loop', leave=True):
                for k in trange(50, desc='3nd loop'):
                    pbar.update()  # can also use pbar.update(1)
                    time.sleep(0.01)


# Generated at 2022-06-22 15:56:43.913766
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    import pytest
    FractionColumn_inst = FractionColumn()
    class task_mock:
        completed = 0
        total = 0
    task_inst = task_mock()
    # Test case 1
    task_inst.completed = 0
    task_inst.total = 0
    assert (FractionColumn_inst.render(task_inst).content == '0.0/0.0')
    # Test case 2
    task_inst.completed = 0
    task_inst.total = 1
    assert (FractionColumn_inst.render(task_inst).content == '0.0/1.0')
    # Test case 3
    task_inst.completed = 3
    task_inst.total = 5

# Generated at 2022-06-22 15:56:46.313742
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render(ProgressColumn('task')) == '0/0'



# Generated at 2022-06-22 15:56:56.768399
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from .utils import _range
    from .auto import trange

    for _ in trange(5):
        sleep(0.5)
    for i in trange(_range(5)):
        sleep(0.5)

# Generated at 2022-06-22 15:57:02.729902
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from io import StringIO
    import sys
    from unittest import TestCase
    from .std import tqdm

    class Test(TestCase):
        @classmethod
        def setUpClass(cls):
            cls.stdout = sys.stdout

        @classmethod
        def tearDownClass(cls):
            sys.stdout = cls.stdout

        def setUp(self):
            super(Test, self).setUp()
            self.file = StringIO()
            sys.stdout = self.file

        def tearDown(self):
            sys.stdout = self.stdout
            self.file.close()
            super(Test, self).tearDown()

        def test_clear(self):
            """Test that `clear()` doesn't fail."""

# Generated at 2022-06-22 15:57:14.312901
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render("task") == Text("? /s", style="progress.data.speed")
    rate_column.unit = "k"
    assert rate_column.render("task") == Text("? k/s", style="progress.data.speed")
    rate_column.unit = "K"
    assert rate_column.render("task") == Text("? K/s", style="progress.data.speed")
    rate_column.unit = "M"
    assert rate_column.render("task") == Text("? M/s", style="progress.data.speed")
    rate_column.unit = "G"
    assert rate_column.render("task") == Text("? G/s", style="progress.data.speed")
    rate_column.unit = "T"
   

# Generated at 2022-06-22 15:57:16.395440
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    p = tqdm(range(3))
    p.display()
    p.close()

# Generated at 2022-06-22 15:57:25.780809
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    import shutil

    # Case 1
    with Progress() as progress:
        task = progress.add_task(
            "Task", total=0, complete=False, start=False)
        with tqdm(total=10, desc='Task', leave=True,
                  bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]") \
                as pbar:
            for i in range(10):
                sleep(0.01)
                pbar.update()
                progress.update(task, total=10)

    # Case 2
    with Progress() as progress:
        task = progress.add_task(
            "Task", total=0, complete=False, start=False)

# Generated at 2022-06-22 15:57:32.575327
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    test_bar = tqdm_rich(5,desc='test')
    test_bar.update(2)
    test_bar.clear()
    test_bar.close()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich_clear()

# Generated at 2022-06-22 15:57:41.162006
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep as time_sleep
    from unittest import TestCase
    from tqdm.auto import trange
    from .utils import capfd

    class TestTqdmRichDisplay(TestCase):

        def test_tqdm_rich_display(self, **kwargs):
            with capfd() as capfd_fd:
                for _ in trange(10, **kwargs):
                    time_sleep(0.01)
            out, err = capfd_fd.read()
            self.assertEqual(err, '')

    for i in (100, 100.0, '100', None):
        TestTqdmRichDisplay().test_tqdm_rich_display(total=i)


if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-22 15:57:43.438295
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(100)) == Text(
        f"?/s", style="progress.data.speed")

# Generated at 2022-06-22 15:57:48.296637
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import Progress

    objs = [Progress(), Progress(columns=(ProgressColumn(),))]
    for i in range(2):
        objs[i].__enter__()
        objs[i].__exit__(None, None, None)

# Generated at 2022-06-22 15:57:54.154756
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task()
    task.completed = '1'
    task.total = '2'
    column = FractionColumn()
    assert column.render(task) == Text(f"{float('1')/float('2'):,.0f}/{float('1')/float('2'):,.0f} ", style="progress.download")

# Generated at 2022-06-22 15:58:20.029595
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test class FractionColumn method render."""
    import unittest
    import unittest.mock as mock
    from rich.progress import Task

    class MyTestCase(unittest.TestCase):
        """Test class FractionColumn method render."""
        def setUp(self):
            """Setup test."""
            self.task = Task("task_description")
            self.task.completed = 0
            self.task.total = 1000
            self.column = FractionColumn()

        def test_render1(self):
            """Test case 1: completed and total are integer."""
            self.task.completed = 0
            self.task.total = 1000
            expected = Text("0.0/1.0 ", style="progress.download")
            actual = self.column.render(self.task)

# Generated at 2022-06-22 15:58:32.095544
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Unit test for method render of class FractionColumn
    """
    from rich.progress import BarColumn
    import unittest
    class Test(unittest.TestCase):
        def test_render(self):
            task = BarColumn()
            task.completed = 26.0
            task.total = 30.0
            task.description = 'example_description'
            task.percentage = 86.66666666666667
            self.assertEqual(task.description, 'example_description')
            self.assertEqual(task.percentage, 86.66666666666667)
            self.assertEqual(len(task.render(task).text), 40)
            task.completed = 30.0
            task.total = 30.0
            self.assertEqual(task.percentage, 100.0)

# Generated at 2022-06-22 15:58:34.467054
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import pytest

    # Method clear is pass-through, so this test will pass.
    t = tqdm_rich(total = 10)
    t.clear()
    del t
    # Method clear is pass-through, so this test will fail.
    t = tqdm_rich(total = 10)
    with pytest.raises(AttributeError):
        t.clear()
        del t

# Generated at 2022-06-22 15:58:37.432971
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import re
    task = ProgressColumn()
    task.completed = 1000
    task.total = 10000
    task.speed = 100
    print(task.speed)
    RateColumn()


# Generated at 2022-06-22 15:58:39.443296
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Tests tqdm_rich display output."""
    tqdm_rich().display()

# Generated at 2022-06-22 15:58:41.994750
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=0)
    t.reset()

# Generated at 2022-06-22 15:58:51.785976
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import TestCase, mock
    from io import StringIO

    def check_tqdm_rich_display(self, ncols, nrows):
        # ncols, nrows = get_terminal_size()
        with StringIO() as out, mock.patch.dict(
                'os.environ',
                {'COLUMNS': str(ncols), 'LINES': str(nrows)}):
            loop_calls = 100

# Generated at 2022-06-22 15:59:00.691243
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from rich.console import Console
    from rich.progress import TaskID
    from rich.table import Table
    from unittest.mock import MagicMock, patch
    console = Console()
    task_id = TaskID(123)
    table = MagicMock(spec=Table)
    table.__enter__ = MagicMock(return_value=table)
    table.__exit__ = MagicMock(return_value=None)
    table.add_column = MagicMock()
    table.add_row = MagicMock()
    table.remove_row = MagicMock()
    table.update = MagicMock()
    table.render = MagicMock(return_value=None)
    progress = MagicMock(spec=Progress)

# Generated at 2022-06-22 15:59:07.780011
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich import progress
    from rich.progress import Progress
    progress = progress.Progress(
        FractionColumn(unit_scale=False, unit_divisor=1000),
        TimeElapsedColumn()
    )
    progress.__enter__()
    task_id = progress.add_task("task1", total = 100)
    for i in trange(100):
        progress.update(task_id, completed = i)
    progress.__exit__(None, None, None)



# Generated at 2022-06-22 15:59:12.532436
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.1)
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.5)
if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-22 15:59:56.287015
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    import time

    with Progress() as progress:
        task = progress.add_task("test_RateColumn_render", total=100)
        Rate1 = RateColumn()
        Rate2 = RateColumn(unit_scale=False, unit_divisor=1000)
        Rate3 = RateColumn(unit_scale=True, unit_divisor=1000)
        Rate4 = RateColumn(unit_scale=True, unit_divisor=1024)
        Rate5 = RateColumn(unit="B")
        print(Rate1.render(task), end="")
        print(Rate2.render(task), end="")
        print(Rate3.render(task), end="")
        print(Rate4.render(task), end="")
        print(Rate5.render(task), end="")
        time

# Generated at 2022-06-22 16:00:02.737083
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = Progress()
    progress.add_task("task1", total=10, completed=5, speed=12345)
    progress.add_task("task2", total=22, completed=10, speed=9999.99)
    progress.add_task("task3", total=25, completed=25, speed=None)
    progress.add_task("task4", total=33, completed=33, speed=1000)

    progress.add_column(RateColumn(unit="B", unit_scale=True, unit_divisor=1000))

# Generated at 2022-06-22 16:00:14.011182
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from .utils import format_sizeof

    # int
    with tqdm_rich(total=5, unit_scale=True) as t:
        for i in range(5):
            sleep(0.25)
            t.update()
    with tqdm_rich(total=5, unit_scale=True) as t:
        t.reset(total=10)
        for i in range(10):
            sleep(0.25)
            t.update()

    # float
    with tqdm_rich(total=5, unit_scale=False) as t:
        for i in range(5):
            sleep(0.25)
            t.update()
    with tqdm_rich(total=5, unit='B', unit_scale=False) as t:
        t.reset

# Generated at 2022-06-22 16:00:16.222042
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=80) as pbar:
        for i in _range(80):
            pbar.display()



# Generated at 2022-06-22 16:00:21.484401
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress = Progress()
    task = progress.add_task("test_fraction_column", total=2)
    fraction_column = FractionColumn()
    print(fraction_column.render(task))
    task.update(1)
    print(fraction_column.render(task))

# Generated at 2022-06-22 16:00:23.959731
# Unit test for method render of class RateColumn
def test_RateColumn_render():
	f = FractionColumn(unit_scale=False)
	test_dict = {
		'completed': 1000,
		'total': 10000
		}
	res = f.render(test_dict)
	assert_string = "100.0/1000 "
	assert(res == assert_string)

# Generated at 2022-06-22 16:00:29.067576
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        with tqdm(total=None) as t:
            t.update(10)
    except TypeError:  # pragma: no cover
        warn("rich is experimental/alpha", TqdmExperimentalWarning, stacklevel=3)
    else:  # pragma: no cover
        raise RuntimeError("Should have resulted in TypeError")

# Generated at 2022-06-22 16:00:39.613529
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit tests for method reset of class tqdm_rich.
    """
    # 1. Test all use cases
    # 1.1, raise TypeError if invalid total
    with(tqdm() as progress):
        progress.reset()
        progress.reset(1)
        progress.reset('1')
        progress.reset(int('4'))
        progress.reset(float('4'))

    # 1.2, Add a new task if total is None
    progress = tqdm()
    # Test if progress._task_id is None
    assert progress._task_id is None
    progress.reset()
    # Test if progress._task_id is set
    assert progress._task_id is not None
    progress.reset(total=None)
    # Test if progress._task_id is set
    assert progress._task

# Generated at 2022-06-22 16:00:43.715575
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(1, 2, 1)) == Text("1.00 /s",
        style="progress.data.speed")
    assert RateColumn().render(Progress(1, 2, None)) == Text("? /s",
        style="progress.data.speed")
    assert RateColumn(unit="B").render(
        Progress(1, 2, 1)) == Text("1.00 B/s", style="progress.data.speed")

# Generated at 2022-06-22 16:00:45.339791
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    assert True

# Generated at 2022-06-22 16:01:50.076073
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .utils import _supports_unicode
    import sys
    import re

    class MockFile:
        """
        A fake file like object that can be used as stdout/err
        Note: the `write()` method ignores the string argument
        """
        def __init__(self):
            self.reset()

        def write(self, string):
            pass

        def flush(self):  # pragma: no cover
            pass

        def reset(self):
            self.content = []

        def getvalue(self):
            return ''.join(self.content)

        def __getattr__(self, attr):
            # print('getattr: %r' % attr)
            return getattr(sys.__stdout__, attr)

    # Initialize

# Generated at 2022-06-22 16:01:59.301819
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """RateColumn rendering test"""
    col = RateColumn('%', unit_scale=True, unit_divisor=1024)
    assert col.render({'speed': None}) == Text('? %/s', style='progress.data.speed')

    assert col.render({'speed': 0}) == Text('0.00 %/s', style='progress.data.speed')
    assert col.render({'speed': 999.5}) == Text('0.98 %/s', style='progress.data.speed')
    assert col.render({'speed': 1000}) == Text('0.98 Ki%/s', style='progress.data.speed')
    assert col.render({'speed': 1001}) == Text('0.99 Ki%/s', style='progress.data.speed')

# Generated at 2022-06-22 16:02:07.001581
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(10) == Text(f"10/s", style="progress.data.speed")
    assert RateColumn().render(0.5) == Text(f"0.5/s", style="progress.data.speed")
    assert RateColumn().render(2000) == Text(f"2.0 K/s", style="progress.data.speed")
    assert RateColumn().render(None) == Text(f"? /s", style="progress.data.speed")
    assert RateColumn(unit="b").render(10) == Text(f"10 b/s", style="progress.data.speed")
    assert RateColumn(unit="b").render(None) == Text(f"? b/s", style="progress.data.speed")

# Generated at 2022-06-22 16:02:17.788571
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm()
    task.speed = None
    assert '? /s' == RateColumn().render(task).text
    task.speed = 0
    assert '0.0 /s' == RateColumn().render(task).text
    task.speed = 1
    assert '1.0 /s' == RateColumn().render(task).text
    task.speed = 10
    assert '10.0 /s' == RateColumn().render(task).text
    task.speed = 100
    assert '100.0 /s' == RateColumn().render(task).text
    task.speed = 999
    assert '999.0 /s' == RateColumn().render(task).text
    task.speed = 1000
    assert '1.0 K/s' == RateColumn().render(task).text
    task.speed = 1001


# Generated at 2022-06-22 16:02:23.996879
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = object()
    task.speed = 1000
    assert RateColumn().render(task) == Text("1.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True).render(task) == Text("1.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(task) == Text("1.0 kB/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1024).render(task) == Text("1.0 B/s", style="progress.data.speed")



# Generated at 2022-06-22 16:02:29.297149
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress = tqdm_rich(total=100, desc="test", desc_filled="test", desc_unfilled="test", bar_format="test")
    assert progress._prog.total == 100
    progress.reset(total=200)
    assert progress._prog.total == 200
    progress.reset()
    assert progress._prog.total == 200

# Generated at 2022-06-22 16:02:34.803047
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(0, 1, 1, 0)
    assert RateColumn().render(task) == Text('0.00 B/s', style='progress.data.speed')
    task.speed = 10
    assert RateColumn().render(task) == Text('10.00 B/s', style='progress.data.speed')
    assert RateColumn(unit='B').render(task) == Text('10.00 B/s', style='progress.data.speed')
    assert RateColumn(unit='/s').render(task) == Text('10.00 B/s', style='progress.data.speed')
    assert RateColumn(unit='/second').render(task) == Text('10.00 B/s', style='progress.data.speed')

# Generated at 2022-06-22 16:02:40.885948
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method reset of class tqdm_rich"""

    total = 1000

    with tqdm_rich(total=total) as t:
        assert t.total == total

        # Test reset with same value
        t.reset(total=total)
        assert t.total == total

        # Test reset with new value
        total = 500
        t.reset(total=total)
        assert t.total == total

# Generated at 2022-06-22 16:02:51.750922
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for `rich.progress.RateColumn.render()`."""
    import sys
    import unittest
    from rich.progress import (
        BarColumn, Progress, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    )
    from unittest.mock import MagicMock, patch

    class TestRateColumn(unittest.TestCase):
        """Unit test for class `tqdm.rich.RateColumn`."""

        @classmethod
        def setUpClass(cls):
            """
            Unit test `rich.progress.RateColumn.render` takes a task,
            and returns a string
            """

            cls.task = MagicMock(total=100, completed=50, speed=10)
            cls.task.__enter__.return_value = cls.task



# Generated at 2022-06-22 16:02:55.669758
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Emulate data which is not available in unit test
    tqdm.n = 10
    tqdm.desc = 'test_tqdm'
    tqdm._prog = object()
    tqdm._prog.update = lambda *_: None
    tqdm._task_id = 123
    tqdm.display()