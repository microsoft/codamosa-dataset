

# Generated at 2022-06-22 15:53:43.536235
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn()
    assert f.render({'completed': 16, 'total': 32}) == Text('0.5/1.0 ', style='progress.download')

# Generated at 2022-06-22 15:53:51.052842
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ## Test for parameter speed is None
    f = RateColumn()
    test_RateColumn_render_data = [{"Speed:": None, "Expected Result": "? /s"},
                                   {"Speed:": "100.0", "Expected Result": "100.0 /s"}]
    for param_data in test_RateColumn_render_data:
        speed = param_data["Speed:"]
        expected_result = param_data["Expected Result"]
        assert f.render(speed) == expected_result


if __name__ == "__main__":
    try:
        for i in trange(16, unit_scale=True, unit="B"):
            ...
    except (KeyboardInterrupt, SystemExit):
        pass

# Generated at 2022-06-22 15:53:53.913966
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    t = tqdm_rich(total=2)
    t.update()
    t.update()
    t.close()



# Generated at 2022-06-22 15:54:01.880091
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    prog = tqdm_rich(total=3, unit='MiB', unit_scale=True, unit_divisor=1024)
    prog.desc = 'Downloading'
    prog.update(2)
    assert 'Downloading' in prog.__dict__['_prog'].__dict__['_tasks'][0]
    assert '0.001/0.003 MiB' in prog.__dict__['_prog'].__dict__['_tasks'][0]



# Generated at 2022-06-22 15:54:10.376862
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(transient=False)
    progress.__enter__()
    task_id = progress.add_task("Hello", total=100)
    console.print(progress)
    progress.update(task_id, 1)
    console.print(progress)
    progress.update(task_id, 1)
    console.print(progress)
    progress.update(task_id, completed=10, description="T1")
    console.print(progress)
    progress.clear()
    console.print(progress)

# Generated at 2022-06-22 15:54:17.671073
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm as _tqdm
    import random
    import time
    try:
        from rich.progress import Progress
    except ImportError as e:
        return
    with Progress() as progress:
        for i in progress.track(_tqdm(range(1, 100))):
            time.sleep(random.random() * 0.001)

# Generated at 2022-06-22 15:54:22.764691
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(total=10)) == "0/10 "
    assert FractionColumn(unit_divisor=1024).render(Progress(total=1500)) == "0/1.5 K"
    assert FractionColumn(unit_divisor=1024, unit_scale=True).render(Progress(total=1500)) == "0/1.5 K"

# Generated at 2022-06-22 15:54:29.874429
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn = RateColumn()
    assert ratecolumn.render(6.) == "6.00 /s"
    assert ratecolumn.render(0.) == "0.00 /s"
    assert ratecolumn.render(-6.) == "-6.00 /s"
    assert ratecolumn.render(float("inf")) == "? /s"
    assert ratecolumn.render(float("NaN")) == "? /s"
    assert ratecolumn.render(None) == "? /s"

# Generated at 2022-06-22 15:54:34.172887
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn()
    task = Progress.Task('', 0, 10)
    task.completed = 0
    assert f.render(task) == Text("0.0/10.0 ", style="progress.download")
    task.completed = 10
    assert f.render(task) == Text("10.0/10.0 ", style="progress.download")


# Generated at 2022-06-22 15:54:45.487977
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Unit test for method `render` of class `RateColumn`.
    """
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    task = Progress()
    task.speed = 1024
    assert rate_column.render(task).text == "1.00 KB/s"
    task.speed = 1024 * 1024
    assert rate_column.render(task).text == "1.00 MB/s"
    task.speed = 1024 * 1024 * 1024
    assert rate_column.render(task).text == "1.00 GB/s"
    task.speed = 1024 * 1024 * 1024 * 1024
    assert rate_column.render(task).text == "1.00 TB/s"
    task.speed = 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-22 15:54:53.412374
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = { 'completed': 17, 'total': 23, 'speed': None }
    bar_column = FractionColumn()
    assert bar_column.render(task) == Text("0.7/1.0 ")

# Generated at 2022-06-22 15:54:54.517390
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=100)
    t.display()
    assert hasattr(t, '_prog')
    t.close()


# Generated at 2022-06-22 15:54:56.121068
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    t = ProgressColumn()
    task = FractionColumn()
    t.render(task)

# Generated at 2022-06-22 15:55:03.006305
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time

    with tqdm_rich(100, unit='B', unit_scale=True, miniters=1) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()

    assert t.n == 100
    assert t.desc == None
    assert t.leave == False
    assert t.unit == 'B'
    assert t.unit_scale == True
    assert t.miniters == 1
    assert t.ascii == False
    assert t.disable == False
    assert t.ncols == None
    assert t.mininterval == 0.1
    assert t.miniters == 1
    assert t.postfix == {}

# Generated at 2022-06-22 15:55:15.737622
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import os
    import subprocess
    import sys
    import tempfile
    from time import sleep

    with tempfile.TemporaryDirectory() as tmp_dir:
        # Create a file for testing
        with open(os.path.join(tmp_dir, "testfile.txt"), 'w') as f:
            f.write(os.urandom(1024 * 1024 * 20))

        # Start the test
        with tqdm_rich(
            unit='B', unit_scale=True, unit_divisor=1024,
            desc='testfile.txt',
            total=os.path.getsize(os.path.join(tmp_dir, "testfile.txt"))
        ) as pbar:
            pbar.write('Testing…')
            pbar.write('Testing…from the other side')

# Generated at 2022-06-22 15:55:19.632132
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    with tqdm_rich(total=10, desc="Test") as t:
        for i in _range(10):
            t.n = i
            t.display()

# Generated at 2022-06-22 15:55:27.219961
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich"""
    desc = "Test demo"
    total = 20
    t = tqdm_rich(total=total, desc=desc, leave=False)
    assert t._prog.total == total
    assert t._prog.description == desc
    # Test reset
    new_total = 10
    t.reset(new_total)
    assert t._prog.total == new_total
    assert t._prog.description == desc

# Generated at 2022-06-22 15:55:38.654378
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test the method close."""
    close = tqdm_rich.close
    with open('test_tqdm_rich_close.passthrough', 'w', newline='\n') as f:
        try:
            close('test_tqdm_rich_close', file=f, total=10)
        except TypeError as e:
            assert "unexpected keyword argument 'total'" in str(e) # should not be accepted, as we are disable
        else:
            assert False, "Should have raised"
    with open('test_tqdm_rich_close.passthrough', 'w', newline='\n') as f:
        close('test_tqdm_rich_close', file=f) # should not raise

# Generated at 2022-06-22 15:55:41.084980
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(range(10)) as t:
        for i in t:
            t.update()
        t.close()

# Generated at 2022-06-22 15:55:44.590745
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = object()
    task.completed = 0
    task.total = 1
    fc = FractionColumn()
    assert fc.render(task) == Text("0.0/1.0", style="progress.download")

# Generated at 2022-06-22 15:55:59.193577
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.columns import Columns
    from rich.console import Console
    from rich.progress import Progress
    from rich.theme import Theme

    console = Console(width=40, file=None)
    progress = Progress(
        "[progress.description]{task.description}: ",
        Text(f"{progress.current_value}/{progress.total}",
             justify="right"),
        BarColumn(bar_width=None),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
    )
    console.print(Columns([progress]))
    progress.add_task("Task 1", done=10, total=100, start=False)
    progress.add_task("Task 2", done=10, total=50, start=False)

# Generated at 2022-06-22 15:56:01.688692
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    r = tqdm_rich(total=10)
    r.reset(total=20)
    assert r.total == 20

# Generated at 2022-06-22 15:56:04.793641
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import gc
    t = tqdm_rich(total=1)
    t.close()
    assert t._prog.tasks == {}


# Generated at 2022-06-22 15:56:09.404272
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test the method render of the class FractionColumn
    """
    test_task = {'completed': 5, 'total': 15}
    test_obj = FractionColumn()
    result = test_obj.render(test_task)    
    assert (result == "5.0/15.0 ")

# Generated at 2022-06-22 15:56:15.690236
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    for task in [Progress.TASK_DUMMY, Progress.TASK_TOTAL_DUMMY]:
        assert RateColumn(unit_divisor=1000).render(task) == \
            Text("? ", style="progress.data.speed")
    # speed = 1.345
    task = Progress.TASK_DUMMY._replace(speed=1.345, total=3.454, completed=1.345)
    assert RateColumn(unit_divisor=1000).render(task) == \
        Text("1.3 B/s", style="progress.data.speed")
    task = Progress.TASK_DUMMY._replace(speed=1345, total=3454, completed=1345)

# Generated at 2022-06-22 15:56:24.739121
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm.contrib import nested_tqdm
    from tqdm.rich import tqdm, tqdm_rich
    from tqdm.std import tqdm
    for tq in (tqdm, tqdm_rich, nested_tqdm):
        tq = tq(range(10), desc='tq')
        assert tq.disable is False
        assert tq.desc == 'tq'
        assert hasattr(tq, '_prog')
        tq.close()
        assert tq.disable is False
        assert tq.desc == 'tq'
        assert not hasattr(tq, '_prog')

# Generated at 2022-06-22 15:56:33.368946
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_input = ["0/0", "0/1", "1/1", "1/10", "10/10"]
    test_output = ["0.0/0", "0.0/1", "1.0/1", "0.1/1", "1.0/1"]
    for i in range(len(test_input)):
        assert FractionColumn().render(test_input[i]) == test_output[i]


# Generated at 2022-06-22 15:56:42.514074
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert column.render(Progress(completed=3, total=5)) == Text(
        '3.0/5.0 ', style='progress.download')
    assert column.render(Progress(completed=1, total=5)) == Text(
        '0.2/5.0 ', style='progress.download')
    assert column.render(Progress(completed=1, total=9999999999999)) == Text(
        '0.0/0.0 ', style='progress.download')



# Generated at 2022-06-22 15:56:53.264507
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from os.path import realpath, dirname
    from unittest import TestCase as _TestCase

    class TestCase(_TestCase):
        def setUp(self):
            self.__TEST_FILE = realpath(__file__)
            self.__TEST_DIR = dirname(self.__TEST_FILE)
            self.__STATIC_DIR = dirname(self.__TEST_DIR)

        @property
        def TEST_FILE(self):
            return self.__TEST_FILE

        @property
        def TEST_DIR(self):
            return self.__TEST_DIR

        @property
        def STATIC_DIR(self):
            return self.__STATIC_DIR

    testcase = TestCase()
    testcase.setUp()

    import re
    import subprocess
    import time

# Generated at 2022-06-22 15:57:02.711466
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # rate column displays the unit of data transfer speed
    from rich.progress import Task
    t = Task('example task')
    t.speed = 1000
    t.total = 2000
    task = tqdm_rich('test', total = 100)  # task = tqdm obj
    assert RateColumn().render(task) == '1.0 K/s'
    assert RateColumn(unit='B').render(task) == '1.0 KB/s'
    assert RateColumn(unit_scale=True).render(task) == '1.0 K/s'
    assert RateColumn(unit_divisor=1000000).render(task) == '0.001/s'
    task.speed = None
    assert RateColumn().render(task) == '? /s'
    task.speed = 0

# Generated at 2022-06-22 15:57:28.390288
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_task = Progress()
    progress_task.total = 100
    progress_task.completed = 50
    fraction_column = FractionColumn(unit_scale=False)
    assert fraction_column.render(progress_task) == Text(
        "50/100", style="progress.download")
    fraction_column1 = FractionColumn(unit_scale=True)
    assert fraction_column1.render(progress_task) == Text(
        "50/100", style="progress.download")
    progress_task.total = 1000
    assert fraction_column.render(progress_task) == Text(
        "50/1,000", style="progress.download")
    assert fraction_column1.render(progress_task) == Text(
        "0.05/1.00 K", style="progress.download")

# Generated at 2022-06-22 15:57:29.711046
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress_bar = tqdm_rich(range(5), ascii=True)
    progress_bar.reset(total=10)
    progress_bar.close()

# Generated at 2022-06-22 15:57:39.713307
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from contextlib import ExitStack
    from unittest import mock
    from unittest.mock import call

    with ExitStack() as stack:
        stack.enter_context(mock.patch('tqdm.rich.tqdm_rich.time'))
        stack.enter_context(mock.patch('tqdm.rich.tqdm_rich.sleep'))
        stack.enter_context(mock.patch('tqdm.rich.tqdm_rich.stdout'))
        stack.enter_context(mock.patch('tqdm.rich.tqdm_rich.stderr'))
        stack.enter_context(mock.patch('tqdm.rich.tqdm_rich.get_lock'))

# Generated at 2022-06-22 15:57:49.552956
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test tqdm_rich: clear() method."""
    try:
        from unittest import mock
    except ImportError:
        from unittest.mock import Mock as mock

    mocked_progress = mock.MagicMock()
    mocked_update = mock.MagicMock()
    mocked_progress.update = mocked_update

    mocked_task = mock.MagicMock()
    mocked_task._prog = mocked_progress
    mocked_task.disable = False
    mocked_task.clear()

    assert mocked_update.call_count == 0

# Generated at 2022-06-22 15:57:54.238037
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(total=100)
    task.update(10)

    task.bar_format = "[progress.description][{}]".format(FractionColumn(unit_scale=True, unit_divisor=1000))

    task.display()
    assert task.desc == "10.0/100.0 B"

    task.bar_format = "[progress.description][{}]".format(FractionColumn(unit_scale=True, unit_divisor=1024))
    task.display()
    assert task.desc == "10.0/100.0 B"

    task.bar_format = "[progress.description][{}]".format(FractionColumn(unit_scale=True, unit_divisor=1000))
    task.reset(total=10000)
    task.update(10)
    task

# Generated at 2022-06-22 15:58:04.880868
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    col = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert col.render({'completed': 234, 'total': 498}) == Text('234.0/498.0', style='progress.download')
    col = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert col.render({'completed': 234, 'total': 498}) == Text('234.0/498.0', style='progress.download')
    assert col.render({'completed': 234, 'total': 498}) == Text('234.0/498.0', style='progress.download')
    assert col.render({'completed': 234, 'total': 1998}) == Text('234.0/1.998 K', style='progress.download')

# Generated at 2022-06-22 15:58:10.355442
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    col = FractionColumn()
    class FakeTask(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    task = FakeTask(completed=12, total=123)
    result = col.render(task)
    assert str(result) == '12/123'

# Generated at 2022-06-22 15:58:12.847990
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .tests import test_FractionColumn_render
    test_FractionColumn_render(FractionColumn)



# Generated at 2022-06-22 15:58:21.764625
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    # Check for text output for example "1/5" instead of 1.0/5.0
    import sys
    from io import StringIO
    try:
        # Python 3.x
        from io import TextIOWrapper
    except ImportError:
        # Python 2.x
        from io import BytesIO as TextIOWrapper
    try:
        fout = sys.stdout
        sys.stdout = StringIO()
        # Python 2.x
        TextIOWrapper(sys.stdout, encoding="utf-8")
    finally:
        sys.stdout = fout

    with tqdm_rich(total=1) as t:
        t.display()
        assert t.format_dict['elapsed'] is not None

# Generated at 2022-06-22 15:58:30.051498
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task = std_tqdm()
    test_task.update(10)
    test_task.total = 100
    percent = '\033[0m{task.percentage:>4.0f}%'
    completed = '10'
    total = '100'
    expect = percent + '\033[0m\n[\033[32m' + completed + '/' + total + '\033[0m]'
    assert(str(FractionColumn().render(test_task)) == expect)


# Generated at 2022-06-22 15:58:47.102327
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import tqdm
    import time
    td = tqdm(['a', 'b', 'c', 'd'], position=0, leave=True)
    for x in td:
        time.sleep(0.3)
        td.set_postfix(
            RateColumn=RateColumn(unit='/s', unit_scale=True, unit_divisor=1000).render(td).text)
    td.close()

# Generated at 2022-06-22 15:58:53.947396
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # 1st case: unit_scale = False and unit_divisor = 1000
    frac_col = FractionColumn(unit_scale = False, unit_divisor = 1000)
    # 1st test: completed = total
    expected = '0.0/0.0 '
    task = std_tqdm(total = 0)
    task.update(0)
    result = frac_col.render(task)
    assert result.text == expected
    # 2nd test: completed < total
    expected = '1.0/10.0 '
    task = std_tqdm(total = 10)
    task.update(1)
    result = frac_col.render(task)
    assert result.text == expected
    # 3rd test: completed = 0 and total > 1

# Generated at 2022-06-22 15:58:55.627227
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    assert std_tqdm.write == tqdm_rich.write

# Generated at 2022-06-22 15:59:05.715673
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .utils import _range
    if __name__ == "__main__":
        test_rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
        items = _range(5)
        for _ in tqdm(items, desc="test_RateColumn_render()", unit="B", unit_scale=True,
                      unit_divisor=1024):
            text = test_rate_column.render(items)
            test_rate_column.render(items)
            assert text == "0.0 B/s"
        # Test unit conversion
        test_rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
        items = _range(1048576)

# Generated at 2022-06-22 15:59:14.014716
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit_divisor=1000, unit_scale=True)
    assert rate_column.render(Progress(total=100, completed=100, speed=100)) == Text('100 B/s', style='progress.data.speed')
    assert rate_column.render(Progress(total=1000, completed=1000, speed=1000)) == Text('1 K/s', style='progress.data.speed')
    assert rate_column.render(Progress(total=1000000, completed=1000000, speed=1000000)) == Text('1 M/s', style='progress.data.speed')
    assert rate_column.render(Progress(total=1000000, completed=1000000, speed=1000)) == Text('1.0 M/s', style='progress.data.speed')

# Generated at 2022-06-22 15:59:15.806025
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(disable=True)
    assert t.disable == True
    t.clear()

# Generated at 2022-06-22 15:59:26.956978
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn"""
    fraction_column = FractionColumn()
    assert fraction_column.render(23, 100) == "0.2/1.8 G"
    assert fraction_column.render(1234, 5678) == "1/5 K"
    assert fraction_column.render(1, 2) == "0.5/2"
    assert fraction_column.render(4, 8) == "0.5/1 K"
    assert fraction_column.render(4, 10) == "0.4/1 K"
    assert fraction_column.render(100, 102) == "100/102"
    assert fraction_column.render(102, 100) == "102/100"
    assert fraction_column.render(0.12345, 1) == "0.1/1.2 M"

# Generated at 2022-06-22 15:59:29.744293
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method 'reset' in class tqdm_rich. """
    inst = tqdm_rich(disable=False)
    inst.reset()
    inst.disable = True

# Generated at 2022-06-22 15:59:39.944267
# Unit test for method reset of class tqdm_rich

# Generated at 2022-06-22 15:59:48.241933
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import os
    import re
    import tempfile
    from platform import python_implementation
    from .std import tqdm
    from .utils import _range

    def check_tqdm(l, gui=False):
        if gui:
            out = tqdm_rich(l, gui=True, leave=True, disable=False)
        else:
            out = tqdm(l)
        assert '\r' not in repr(out), \
            "not compatible with '\r' in progress bar display"
        return out

    # Test normal operation
    check_tqdm(list(range(0, 10)))
    check_tqdm(list(range(0, 10)), gui=True)

    # Test file-like object
    with tempfile.TemporaryFile() as file:
        check

# Generated at 2022-06-22 16:00:08.490784
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method `FractionColumn.render()`."""
    dummy_task = type('DummyTask', (object, ),
                       {'completed': 3, 'total': 10})()
    assert FractionColumn().render(dummy_task) == '0.3/1.0'
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(dummy_task) == '0.3/1.0'
    assert FractionColumn(unit_scale=True).render(dummy_task) == '0.3/0.0 K'
    assert FractionColumn(unit_scale=False, unit_divisor=1024).render(dummy_task) == '0.3/1.0'

# Generated at 2022-06-22 16:00:10.901122
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in tqdm([0, 1, 2], leave=True, desc="test_desc"):
        pass

# Generated at 2022-06-22 16:00:22.554613
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    taskID = TaskID(1,1)
    assert RateColumn().render(taskID) == 'None B/s'
    assert RateColumn(unit_scale=True, unit='B/s').render(taskID) == 'None B/s'
    assert RateColumn(unit_scale=True, unit='B/s').render(taskID.set_speed(1)) == '1.0 B/s'
    assert RateColumn(unit_scale=True, unit='B/s').render(taskID.set_speed(1000)) == '1.0 KB/s'
    assert RateColumn(unit_scale=True, unit='B/s').render(taskID.set_speed(1000000)) == '1.0 MB/s'

# Generated at 2022-06-22 16:00:28.177070
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    rate_column.render(10)
    rate_column.render(10*1000)
    rate_column.render(10*1000*1000)
    rate_column.render(10*1000*1000*1000)
    rate_column.render(10*1000*1000*1000*1000)
    rate_column.render(10*1000*1000*1000*1000*1000)
    rate_column.render(10*1000*1000*1000*1000*1000*1000)
    rate_column.render(10*1000*1000*1000*1000*1000*1000*1000)
    rate_column.render(10*1000*1000*1000*1000*1000*1000*1000*1000)
    rate_column.render(10*1000*1000*1000*1000*1000*1000*1000*1000*1000)



# Generated at 2022-06-22 16:00:37.958865
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import rich.console
    console = rich.console.Console()
    fc = FractionColumn()
    assert fc.render(Progress(total=1000)) == Text(
        "0/1 K", style="progress.download")
    assert fc.render(Progress(completed=1000, total=1000)) == Text(
        "1/1 K", style="progress.download")
    assert fc.render(Progress(completed=1024, total=1024)) == Text(
        "1/1 K", style="progress.download")
    assert fc.render(Progress(completed=1000, total=1024)) == Text(
        "0.977/1 K", style="progress.download")


# Generated at 2022-06-22 16:00:40.435624
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Coverage test for method display of class tqdm_rich.
    """
    bar = tqdm_rich(total=10)
    bar.display()
    bar.close()

# Generated at 2022-06-22 16:00:45.162983
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        t = tqdm_rich(total=10)
        t.display()
        t.close()
    except Exception as e:  # pragma: nocover
        raise type(e)("{0} Uncaught Exception: {1}".format(type(e).__name__, e))

# Generated at 2022-06-22 16:00:55.345182
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn = RateColumn(unit = "Mb", unit_scale = True, unit_divisor = 1000)
    assert ratecolumn.render(total = 20, completed = 1) == Text("1.0 Mb/s", style = "progress.data.speed")
    assert ratecolumn.render(total = 20, completed = 10) == Text("10.0 Mb/s", style = "progress.data.speed")
    assert ratecolumn.render(total = 20, completed = 20) == Text("20.0 Mb/s", style = "progress.data.speed")
    assert ratecolumn.render(total = 20, completed = 21) == Text("20.5 Mb/s", style = "progress.data.speed")


# Generated at 2022-06-22 16:01:00.236800
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    class Task():
        def __init__(self):
            self.completed = 1000
            self.total = 1024
    task = Task()
    assert fc.render(task) == Text('0.98/1 G', style='progress.download')

# Generated at 2022-06-22 16:01:02.787066
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # https://gitlab.com/tqdm/tqdm/issues/1183
    with tqdm(total=10) as t:
        t.write('Testing...')

# Generated at 2022-06-22 16:01:35.018942
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)
    assert rate_column.render(Progress()) == Text('0.0 /s', style='progress.data.speed')
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(Progress()) == Text('0.0 /s', style='progress.data.speed')
    rate_column = RateColumn(unit_scale=False, unit_divisor=1000)
    assert rate_column.render(Progress()) == Text('0.0 /s', style='progress.data.speed')
    rate_column = RateColumn(unit_scale=False, unit_divisor=1024)

# Generated at 2022-06-22 16:01:44.300433
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test FractionColumn.render()."""
    from rich.progress import Task
    tc = FractionColumn()
    t = Task()
    assert tc.render(t) == Text('0/0 ', style='progress.download')
    t.completed = 15
    t.total = 5
    assert tc.render(t) == Text('3.0/1.0 ', style='progress.download')
    t.total = 3

# Generated at 2022-06-22 16:01:46.008470
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=1)
    t.total = 42
    t.desc = "Test"
    t.display()

# Generated at 2022-06-22 16:01:56.539725
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    """Test method clear of class tqdm_rich"""
    import re
    from types import MethodType

    def _reset_tqdm_rich():
        tqdm_rich.clear = MethodType(tqdm_rich_clear, tqdm_rich)

    def tqdm_rich_clear(self, silent=False, nolock=False):
        pass

    tqdm_rich.clear = MethodType(tqdm_rich_clear, tqdm_rich)
    t = tqdm_rich(total=16)
    t.update(4)
    t.update_to(8)
    t.update(2)
    t.update_to(10)
    t.close()

# Generated at 2022-06-22 16:02:06.884702
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = {'speed': None}
    assert RateColumn(unit='/s').render(task) == Text(f"? /s", style="progress.data.speed")

    task = {'speed': 1024}
    assert RateColumn(unit='/s', unit_scale=True).render(task) == Text(f"1.0 KB/s", style="progress.data.speed")
    assert RateColumn(unit='/s', unit_scale=True, unit_divisor=1024).render(task) == Text(f"1.0 KiB/s", style="progress.data.speed")
    assert RateColumn(unit='/s', unit_scale=False).render(task) == Text(f"1.0 /s", style="progress.data.speed")

# Generated at 2022-06-22 16:02:10.105730
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test method tqdm_rich.clear.
    """
    with tqdm_rich(total=10) as bar:
        bar.clear()

# Generated at 2022-06-22 16:02:17.672614
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from time import sleep
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for __ in trange(10, desc='3rd loop', position=1):
                sleep(0.01)
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for __ in trange(10, desc='3rd loop', position=1):
                sleep(0.01)

# Generated at 2022-06-22 16:02:24.092911
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import os
    from .utils import total_seconds
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console

    console = Console()

    total = 5
    with Progress(transient=True) as progress:
        task = progress.add_task("[red]Foo", start=0, total=total)
        for idx in range(total):
            sleep(1)
            progress.update(task, advance=1)
    console.print("The end:", task.completed)

    with Progress(transient=True) as progress:
        task = progress.add_task("[red]Bar", start=0, total=total)
        for idx in range(total):
            sleep(1)
            progress.update(task, advance=1)

# Generated at 2022-06-22 16:02:29.296684
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=2, disable=not getattr(tqdm_rich, 'and', True),
                   ascii=getattr(tqdm_rich, '_unicode', False) and
                         not getattr(tqdm_rich, '_supports_unicode', True)) as pbar:
        pbar.update()



# Generated at 2022-06-22 16:02:31.415153
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10 + 1) as t:
        t.reset(total=1 + 1)
        assert t.total == 1 + 1
        assert t.n == 0



# Generated at 2022-06-22 16:03:37.393536
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=20)
    for _ in t:
        pass