

# Generated at 2022-06-22 15:53:39.920507
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress.Task(description= 'description', completed= 10, total= 20)) == Text('0.5/1.0 ', style='progress.download')



# Generated at 2022-06-22 15:53:42.549749
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from random import random
    with tqdm(total=13) as pbar:
        for i in range(12):
            time.sleep(random())
            pbar.update()
        pbar.reset(total=5)
        for i in range(4):
            time.sleep(random())
            pbar.update()


if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-22 15:53:50.183915
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_bar = tqdm_rich(total=10)
    progress_bar._prog.add_task('Testing render of class FractionColumn', **progress_bar.format_dict)
    progress_bar._task_id = 1
    f = FractionColumn()
    est1 = f.render(progress_bar)
    f.unit_divisor = 0.5
    est2 = f.render(progress_bar)
    f.unit_scale=True
    est3 = f.render(progress_bar)
    if __name__ == "__main__":
        print(est1)
        print(est2)
        print(est3)
    return est1

# Generated at 2022-06-22 15:53:56.603514
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_bar = Progress()
    progress_bar.__enter__()
    task_id = progress_bar.add_task("my_task", total=5)
    progress_bar.update(task_id, completed=2.3)
    fraction_column_style = FractionColumn()
    fraction_column_style.render(progress_bar.tasks[task_id])
    progress_bar.__exit__(None, None, None)

# Generated at 2022-06-22 15:54:07.464319
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    from io import BytesIO

    old_stdout = sys.stdout
    sys.stdout = BytesIO()

    try:
        with tqdm_rich(unit='B', unit_scale=True, unit_divisor=1024,
                       total=None, bar_format='{l_bar}{bar}| ') as t:
            while t.n < 10:
                t.update()
            t.reset()
            while t.n < 20:
                t.update()
    finally:
        for line in sys.stdout.getvalue().splitlines():
            print(line.decode())
        sys.stdout.close()
        sys.stdout = old_stdout

# Generated at 2022-06-22 15:54:09.521006
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(100))
    assert t._prog.tasks

# Generated at 2022-06-22 15:54:12.279628
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # TODO: fix the unit test.
    #t = tqdm_rich(total=10)
    #t.clear()
    pass

# Generated at 2022-06-22 15:54:19.365872
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import platform
    if platform.system() == 'Windows':
        return

    def f():
        with tqdm_rich(total=100) as pbar:
            pass
    assert pbar._prog.running

    def f():
        with tqdm_rich(total=100) as pbar:
            pass
        assert pbar._prog.running

# Generated at 2022-06-22 15:54:24.475822
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(std_tqdm(total=1)) == "[0/1 ]"
    assert FractionColumn().render(std_tqdm(total=10,unit="B")) == "[0.0/10.0 B]"


# Generated at 2022-06-22 15:54:29.828653
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Calculate common unit for completed and total."""
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    class Task:
        completed = 1250
        total = 10000
    assert fraction_column.render(Task) == Text(
            "1.3/10.0 K",
            style="progress.download")

# Generated at 2022-06-22 15:54:41.748232
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich.traceback

    with rich.traceback.install(_raise=False):
        with tqdm_rich(2, total=10, desc="reset test") as t:
            t.reset(total=20)
            for i in t:
                pass

# Generated at 2022-06-22 15:54:47.912201
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    column = FractionColumn()
    task = Task("test", completed=10, total=100)
    task.completed = 10
    assert f'{column.render(task)}' == '0.1/1.0'
    task.completed = 101
    assert f'{column.render(task)}' == '1.0/1.0'
    task.completed = 10241024
    assert f'{column.render(task)}' == '1.0/1.0'
    assert f'{column.render(task)}' == '1.0/1.0'


# Generated at 2022-06-22 15:54:58.684029
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    t = tqdm(range(10), disable=False)
    try:
        with open(sys.argv[0]) as i:  # pragma: no cover
            for line in t:
                pass
            t.clear()
    finally:
        t.close()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    from contextlib import contextmanager

    @contextmanager
    def decorated_gen():
        with tqdm(total=10, desc="Rich Progress", leave=True) as pbar:
            for i in range(10):
                pbar.set_description_str(f"I am beautiful {i}")
                yield i
                sleep(.1)
        pbar.close()


# Generated at 2022-06-22 15:55:10.668089
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit tests for `tqdm.rich.tqdm_rich.display()`."""
    import sys
    import os

    t = tqdm(total=10)
    t.update_to(3)
    assert not hasattr(t, '_prog')  # not opened yet
    t.display()
    assert hasattr(t, '_prog')
    t.update_to(5)
    assert t.n == 5

    # test for nested tqdms
    with open(os.devnull, 'w') as f:
        sys.stdout = f
        for i in tqdm(tqdm(tqdm(tqdm(_range(8))))):
            pass

# Generated at 2022-06-22 15:55:15.430219
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pbar = tqdm_rich(total=10)
    pbar.clear()


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in trrange(10):
        sleep(.1)

# Generated at 2022-06-22 15:55:27.862128
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from unittest import TestCase, main
    from unittest.mock import patch, Mock
    from .std import tqdm
    from .utils import _range

    class TqdmRichDisplayTest(TestCase):
        @patch('tqdm.tqdm.tqdm_rich.Progress')
        def test_display(self, m_progress):
            m_task = Mock()
            m_task.update = Mock()
            m_progress.return_value.add_task.return_value = m_task
            m_task.description = "description"
            tqdm_rich(total=1)
            self.assertEqual(m_progress.return_value.add_task.call_count, 1)
            m_progress.reset_mock()


# Generated at 2022-06-22 15:55:39.342284
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column.render(None) == Text('0.0/0.0 ', style='progress.download')
    assert column.render(Progress.Task(total=0)) == Text('0.0/0.0 ', style='progress.download')
    assert column.render(Progress.Task(total=10)) == Text('0.0/10.0 ', style='progress.download')
    assert column.render(Progress.Task(total=100)) == Text('0.0/100.0 ', style='progress.download')
    assert column.render(Progress.Task(total=1000)) == Text('0.0/1.0 K', style='progress.download')

# Generated at 2022-06-22 15:55:50.737882
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for FractionColumn.render method."""
    from .std import FakeTqdmFile
    from .utils import FormatSSum, _range as range_func

    # initialise a tqdm object with total and n as given arguments
    t = tqdm(range_func(0, 100), total=100)
    # initialise a "file" attribute for the object t
    t.file = FakeTqdmFile()
    # initialise a tqdm_metrics object with
    # total and n as given arguments
    t_metrics = t._instantiate_metric(100, 100)
    # initialise a tqdm_gui object and pass the
    # tqdm_metrics object and other arguments as given
    t_gui = t._instantiate_gui(t_metrics)
    # initial

# Generated at 2022-06-22 15:55:52.433595
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for i in tqdm_rich(_range(10)):
        pass

# Generated at 2022-06-22 15:55:55.155903
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm([0, 0, 0]):
        pass
    for _ in tqdm_rich([0, 0, 0], position=0):
        pass

# Generated at 2022-06-22 15:56:08.457004
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for RateColumn.render()."""
    progress = Progress()
    progress.add_task(
        "Downloading...",
        columns=["",
                 FractionColumn(unit_scale=True, unit_divisor=1000),
                 "[",
                 TimeElapsedColumn(),
                 ",",
                 RateColumn(unit="iB", unit_scale=True,
                            unit_divisor=1024),
                 "]"])
    for i in range(1, 500):
        progress.update(i)
    progress.__exit__(None, None, None)


if __name__ == "__main__":
    test_RateColumn_render()

# Generated at 2022-06-22 15:56:20.845563
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(100, 100)) == Text('1/1 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(4000, 5000)) == Text('4.0/5.0 K', style='progress.download')
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(100, 1000)) == Text('0.1/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(4000, 5000000)) == Text('4.0/5.0 M', style='progress.download')


# Generated at 2022-06-22 15:56:30.532293
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=1) as pbar:
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.display()

# Generated at 2022-06-22 15:56:34.472716
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    fc = FractionColumn()
    task = Task()
    task.completed = 2.3
    task.total = 10.4
    assert fc.render(task) == Text("2.3/10.4", style="progress.download")


# Generated at 2022-06-22 15:56:46.652483
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import tqdm
    from .utils import TypeError

    with tqdm(leave=True, total=1, unit="b") as task:
        test = FractionColumn()
        if test.render(task) != Text("0.0/1.0 b", style="progress.download"):
            raise AssertionError
    with tqdm(leave=True, total=1, unit="B", unit_scale=True) as task:
        test = FractionColumn(unit_scale=True)
        if test.render(task) != Text("0.0/0.0 ", style="progress.download"):
            raise AssertionError

# Generated at 2022-06-22 15:56:55.110676
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task = std_tqdm.tqdm()
    test_task.total = 25000
    test_task.completed = 6.54
    test_task.start_t = 1.54
    test_task.n = 0
    test_task.format_dict = {"unit": "B", "unit_scale": False, "unit_divisor": 1024}
    test_task.update = lambda: None
    test_task.SMOOTH_WINDOW = 200

    frac_col = FractionColumn(unit_scale=False)
    frac_text = frac_col.render(test_task)
    assert frac_text.text == "0.0/25.0 ", "Test FractionColumn::render() with default values"


# Generated at 2022-06-22 15:57:05.480222
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import types
    def assert_is_closable(bar):
        assert hasattr(bar, 'close')
        assert hasattr(bar, 'closable')
        assert isinstance(bar.close, types.MethodType)
        assert bar.closable

    # Without total
    bar = tqdm_rich()
    assert_is_closable(bar)
    bar.close()
    assert (bar.n, bar.total, bar._prog.total) == (0, None, None)
    # With total
    bar = tqdm_rich(total=666)
    assert_is_closable(bar)
    bar.close()
    assert (bar.n, bar.total, bar._prog.total) == (0, 666, 666)


# Generated at 2022-06-22 15:57:16.922540
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.utils import _term_move_up
    from tqdm.contrib.concurrent import thread_map
    t = tqdm_rich(total=4)
    #tqdm.tqdm_rich.write()
    # Check that display is non-blocking
    try:
        thread_map(
            lambda _: t.display(),
            [None] * 5,
            max_workers=5,
            desc="rich.progress",
            leave=True)
    except ValueError:
        pass
    else:
        raise Exception("display should be non-blocking")
    # Check that display is able to update the bar multiple times
    # simultaneously

# Generated at 2022-06-22 15:57:26.166197
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn"""
    from rich.progress import TaskID
    import pandas as pd
    df = pd.DataFrame(columns=["test case", "completed", "total", "expected"])
    df.loc[1] = ["test 1", 100, 100, "100/100"]
    df.loc[2] = ["test 2", 50, 100, "50/100"]
    df.loc[3] = ["test 3", 29, 77, "29/77"]
    df.loc[4] = ["test 4", 2000, 9000, "2/9 K"]
    df.loc[5] = ["test 5", 300000, 1000000, "0.3/1 M"]
    df.loc[6] = ["test 6", 60000, 1000000, "0.1/1 M"]

# Generated at 2022-06-22 15:57:30.293017
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10) as t:
        for _ in range(10):
            pass



# Generated at 2022-06-22 15:57:50.485922
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from contextlib import ExitStack
    from rich.progress import Progress, TaskID
    from rich.console import Console
    from rich.emoji import Emoji
    from rich.progress import BarColumn
    from rich.text import Text

    class ProgressMock(Progress):
        """
        A mock of rich.progress.Progress() class.
        """
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._progress_bar = None
            self._console = None
            self._stack = None

        def __enter__(self):
            """
            Initialize the console and stack.
            """
            self._console = Console(width=25, file=None, force_terminal=True)
            self._stack = ExitStack()

# Generated at 2022-06-22 15:58:00.617826
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    states = [{'completed': 3000, 'total': 10000},
              {'completed': 100000, 'total': 5000000},
              {'completed': 600000, 'total': 5000000},
              {'completed': 100000, 'total': 1000000},
              {'completed': 100000, 'total': 2400000},
              {'completed': 100000, 'total': 2500000},
              {'completed': 100000, 'total': 1500000},
              {'completed': 100000, 'total': 2500100},
              {'completed': 100000, 'total': 2000000},
              {'completed': 100000, 'total': 1500000}
              ]

# Generated at 2022-06-22 15:58:05.376350
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm with rich backend"""
    info = [1, 2, 3, 4, 5]
    for i in tqdm_rich(info):
        assert i in info


if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-22 15:58:17.240239
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn()
    print(rateColumn.render(None))
    print(rateColumn.render(1))
    print(rateColumn.render(1000000))
    print(rateColumn.render(99999999))
    print(rateColumn.render(1000000000))
    print(rateColumn.render(9999999999))
    print(rateColumn.render(1000000000000))
    print(rateColumn.render(99999999999999))
    print(rateColumn.render(1000000000000000))
    print(rateColumn.render(99999999999999999))
    print(rateColumn.render(1000000000000000000))
    print(rateColumn.render(999999999999999999999))
    print(rateColumn.render(1000000000000000000000))
    print(rateColumn.render(999999999999999999999999))

# Generated at 2022-06-22 15:58:19.696787
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .utils import _range

# Generated at 2022-06-22 15:58:21.875795
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    d = {"completed": 20, "total": 1000}
    s = FractionColumn(unit_scale=True, unit_divisor=1000).render(d)
    assert s == "0.0K/1.0K"



# Generated at 2022-06-22 15:58:28.166293
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    The method reset() of class tqdm_rich should modify the `total` attribute of the bar.
    """
    t = tqdm_rich(range(3), total=3)
    t.update(3)
    total = t.total
    t.reset(100)
    assert t.total != total
    assert t.total == 100

# Generated at 2022-06-22 15:58:33.364234
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 0
    unit, suffix = filesize.pick_unit_and_suffix(speed, [""], 1)
    precision = 0 if unit == 1 else 1
    assert RateColumn().render(speed) == f"{speed/unit:,.{precision}f} {suffix}/s"
    speed = 1000
    unit, suffix = filesize.pick_unit_and_suffix(speed, ["", "K"], 1000)
    precision = 0 if unit == 1 else 1
    assert RateColumn().render(speed) == f"{speed/unit:,.{precision}f} {suffix}/s"
    speed = 123.4

# Generated at 2022-06-22 15:58:44.726118
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Unit test for method render of class RateColumn
    import re

    number_string = re.compile(r'\d+\.?\d*')

    def float_range(float_min, float_max, float_step):
        """Range for floating numbers."""
        while float_min < float_max:
            yield float_min
            float_min += float_step

    for value in float_range(0, 1000, 0.1):
        rate_column_instance = RateColumn()
        assert rate_column_instance.render(value) != ""
        assert number_string.search(rate_column_instance.render(value)) is not None
        assert "B/s" in rate_column_instance.render(value)

# Generated at 2022-06-22 15:58:53.023473
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test RateColumn.render returns expected."""
    rate_column = RateColumn(unit="/s")

    # Test case when speed is None
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")

    # Test case when speed is zero
    assert rate_column.render(0) == Text("0 B/s", style="progress.data.speed")

    # Test case when speed is rounded to zero
    assert rate_column.render(10**(-6)) == Text("0 B/s", style="progress.data.speed")

    # Test case when speed is one
    assert rate_column.render(1) == Text("1 B/s", style="progress.data.speed")

    # Test case when speed is one thousand

# Generated at 2022-06-22 15:59:13.700276
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method `render` of class FractionColumn"""
    class DummyTask:
        """Dummy implementation of `rich.progress.Task`"""
        __slots__ = ['completed', 'total']
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    completed, total = 100, 1000
    task = DummyTask(completed, total)
    fraction_column = FractionColumn()
    actual = fraction_column.render(task)
    expected = '0.1/1.0 '
    assert actual == expected



# Generated at 2022-06-22 15:59:23.315257
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(task=None) == Text(f"? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="bps")
    assert rate_column.render(task=None) == Text(f"? bps/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task=None) == Text(f"? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(task=None) == Text(f"? B/s", style="progress.data.speed")

# Generated at 2022-06-22 15:59:33.729136
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class TestTask:
        def __init__(self, speed):
            self.speed = speed
    task = TestTask(0)
    tc1 = RateColumn()
    assert tc1.render(task) == Text("0.00 /s", style="progress.data.speed")
    task = TestTask(1.5)
    assert tc1.render(task) == Text("1.50 /s", style="progress.data.speed")
    task = TestTask(1.5e4)
    assert tc1.render(task) == Text("15.0 K/s", style="progress.data.speed")
    task = TestTask(1.5e6)
    assert tc1.render(task) == Text("1.50 M/s", style="progress.data.speed")

# Generated at 2022-06-22 15:59:38.756030
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(total=10)
    assert pbar.n == 0
    pbar.update(1)
    assert pbar.n == 1
    pbar.reset()
    assert pbar.n == 0
    assert pbar.total == 10
    pbar.reset(total=5)
    assert pbar.total == 5
    pbar.close()

# Generated at 2022-06-22 15:59:44.700161
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = {"completed": 12345,
            "total": 9876,
            "speed": 123}
    print((RateColumn(unit="B",
                      unit_scale=False,
                      unit_divisor=1000).render(task)))
    task = {"completed": 123455,
            "total": 9876,
            "speed": 123000}
    print((RateColumn(unit="B",
                      unit_scale=True,
                      unit_divisor=1000).render(task)))

# Generated at 2022-06-22 15:59:45.959094
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for i in tqdm_rich(range(10)):
        pass

# Generated at 2022-06-22 15:59:50.250605
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    bar = FractionColumn()
    completed = int(1)
    total = int(3)
    assert bar.render(completed, total) == Text(
        f"{completed/1:,.0f}/{total/1:,.0f} ", style="progress.download")

# Generated at 2022-06-22 15:59:59.282602
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    assert column.render(None) == Text("? /s", style="progress.data.speed")
    column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert column.render(None) == Text("? B/s", style="progress.data.speed")
    column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert column.render(None) == Text("? /s", style="progress.data.speed")

    column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    task = (True, 1000, 1000, 1, 1, None, "")

# Generated at 2022-06-22 16:00:10.600880
# Unit test for method render of class RateColumn
def test_RateColumn_render():
	assert RateColumn().render(10) == Text(f"10 B/s", style="progress.data.speed")
	assert RateColumn(unit="B").render(10) == Text(f"10 B/s", style="progress.data.speed")
	assert RateColumn().render(100) == Text(f"100 B/s", style="progress.data.speed")
	assert RateColumn(unit="B").render(100) == Text(f"100 B/s", style="progress.data.speed")
	assert RateColumn().render(1000) == Text(f"1.0 K/s", style="progress.data.speed")
	assert RateColumn(unit="B").render(1000) == Text(f"1.0 K/s", style="progress.data.speed")

# Generated at 2022-06-22 16:00:18.249950
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch
    from .std import tqdm
    with patch('tqdm.rich.tqdm_rich.Progress.update') as p_update:
        with patch('tqdm.rich.tqdm_rich.Progress.reset') as p_reset:
            with tqdm(disable=False, unit='B', unit_scale=True, unit_divisor=2) as t:
                t.display()
                t.update()
                assert p_update.called
            assert p_reset.called
        assert p_update.called

# Generated at 2022-06-22 16:01:30.355094
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from tqdm.contrib.concurrent import thread_map
    total = 50
    with tqdm_rich(total=total) as bar:
        for _ in thread_map(sleep, range(total)):
            bar.update(1)
        bar.reset(total=60)
        for _ in thread_map(sleep, range(60)):
            bar.update(1)

# Generated at 2022-06-22 16:01:33.183634
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(reset=True) as progress:
        progress.reset(total=10)
        for _ in range(10):
            progress.update()

# Generated at 2022-06-22 16:01:37.860628
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    bar = tqdm_rich(range(20))
    assert bar.n == 0
    assert bar._prog.total == 20
    bar.reset(10)
    assert bar.n == 0
    assert bar._prog.total == 10

# Generated at 2022-06-22 16:01:41.992698
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import inspect
    # Function `rich.progress.Progress.add_task` has been deprecated.
    assert inspect.isclass(tqdm_rich._prog)
    assert tqdm_rich._task_id is None

# Generated at 2022-06-22 16:01:48.601690
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tqdm
    import time
    import sys
    pbar = tqdm(total=100)
    for i in range(20):
        time.sleep(0.1)
        pbar.update(5)
    pbar.reset(total=None)
    pbar.reset()
    pbar.reset(10)
    pbar.reset(10)
    for i in range(5):
        time.sleep(0.1)
        pbar.update()
    pbar.reset()
    with tqdm(total=10, ncols=50) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()

# Generated at 2022-06-22 16:01:53.042237
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    total = 1234567890
    with tqdm(total=total) as t:
        t.reset(total=1)
        assert t.total == 1
        t.reset()
        assert t.total == 0

# Generated at 2022-06-22 16:01:55.990624
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        with tqdm_rich(disable=False) as t:
            t.desc = "description"
            t.n = 20
            t.display()
    except Exception as e:
        assert False, e


# Generated at 2022-06-22 16:02:06.738033
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from time import sleep

    with Progress() as p:
        task_id = p.add_task(description="Training", total=0)
        for i in range(10):  # noqa
            sleep(0.1)
            p.update(task_id, total=i)
            p.update(task_id, completed=i)
            p.update(task_id, description="Training")

    with Progress() as p:
        task_id = p.add_task(description="Training", total=0)
        for i in range(10):  # noqa
            sleep(0.1)
            p.update(task_id, total=i)
            p.update(task_id, completed=i)
            p.update(task_id, description="Training")

# Generated at 2022-06-22 16:02:17.788343
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import _environ_cols_wrapper
    from .gui import _term_move_up
    from .gui import _range as _tqdm_range
    t = tqdm(total=3)
    with _environ_cols_wrapper():
        t.display()
        assert repr(t.format_dict['desc']) == repr('\r')
        t.display()
        assert repr(t.format_dict['desc']) == repr(_term_move_up())
        t = tqdm(_tqdm_range(3), desc="foo")
        t.display()
        assert repr(t.format_dict['desc']) == repr('\rfoo')
        t.display()
        assert repr(t.format_dict['desc']) == repr(_term_move_up())

# Generated at 2022-06-22 16:02:20.218973
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Auxiliary method to test that the tqdm_rich class works properly.
    """
    return tqdm_rich(total=1000, desc="test_progress1").display()

# Generated at 2022-06-22 16:03:28.309630
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress()) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(1000)) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(1000, 10)) == Text("10.00 B/s", style="progress.data.speed")
    assert RateColumn().render(Progress(1000, 10, 1)) == Text("10.00 B/s", style="progress.data.speed")
    assert RateColumn().render(Progress(1000, 10, 1, 1)) == Text("10.00 B/s", style="progress.data.speed")

# Generated at 2022-06-22 16:03:37.926526
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm import trange

    # create a progressbar with a total of 20 iterations
    # and a description using `desc` keyword argument
    with tqdm(total=20, desc='Test: ') as pbar:
        # loop over the 20 iterations
        for i in range(20):
            # sleep for 0.1 second
            sleep(0.1)
            # update the progress bar with the iteration number
            pbar.update(1)

    # create a progressbar with a total of 20 iterations
    # and a description using `desc` keyword argument
    pbar = tqdm(total=20, desc='Test: ')
    # loop over the 20 iterations
    for i in range(20):
        # sleep for 0.1 second
        sleep