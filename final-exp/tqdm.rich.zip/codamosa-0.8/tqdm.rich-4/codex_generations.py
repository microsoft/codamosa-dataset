

# Generated at 2022-06-22 15:53:38.359846
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B")
    task = None
    assert rate_column.render(task) == Text(f"? B/s", style="progress.data.speed")

# Generated at 2022-06-22 15:53:42.774816
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Task
    from rich.console import Console
    console = Console()
    task = Task(text="text")
    task.speed = None
    assert RateColumn().render(task) == Text('? /s', 'progress.data.speed')
    task.speed = 10
    assert RateColumn().render(task) == Text('10.0 /s', 'progress.data.speed')
    task.speed = 15000
    assert RateColumn().render(task) == Text('15.0 K/s', 'progress.data.speed')
    task.speed = 25000000
    assert RateColumn().render(task) == Text('25.0 M/s', 'progress.data.speed')
    task.speed = 2500000000

# Generated at 2022-06-22 15:53:45.271006
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=100, bar_format='{desc}{n_fmt}')
    rate_column = RateColumn()
    assert rate_column.render(task) == '0.00  /s'
    assert rate_column.render(task) == '0.00  /s'

# Generated at 2022-06-22 15:53:51.515574
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm.contrib.concurrent import thread_map
    import time
    import rich
    import rich.progress
    import threading
    a = tqdm(thread_map(int, range(150), desc='Processing event', total=150), leave=False)
    def print_number():
        for i in range(3):
            time.sleep(0.5)
            print(i)
    threading.Thread(target=print_number).start()
    for i in a:
        time.sleep(1)
        a.set_description("Event %i processed" % (i,))
    a.close()
    print("Code after close")

# Generated at 2022-06-22 15:53:54.879148
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test for clear method of tqdm_rich"""
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 15:53:57.675673
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(total=100)
    pbar.reset(total=200)
    assert pbar._total == 200

# Generated at 2022-06-22 15:54:00.985919
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display."""
    t = tqdm_rich(range(5), leave=False)
    for i in t:
        t.display()

# Generated at 2022-06-22 15:54:07.569497
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Tests that tqdm_rich can be reset with a custom total.
    """
    range_tqdm = tqdm(range(10))
    assert range_tqdm.total == 10, ("Cannot reset tqdm_rich with default total")
    range_tqdm.reset(total=20)
    assert range_tqdm.total == 20, ("Cannot reset tqdm_rich with custom total")

# Generated at 2022-06-22 15:54:15.925824
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    desc = "description"
    n = 2
    with tqdm(total=n) as _tqdm:
        _tqdm.reset()
        assert _tqdm.total == n
        assert _tqdm.desc == desc

        _tqdm.reset(total=n)
        assert _tqdm.total == n
        assert _tqdm.desc == desc

        new_n = n + 2
        _tqdm.reset(total=new_n)
        assert _tqdm.total == new_n
        assert _tqdm.desc == desc

# Generated at 2022-06-22 15:54:25.772262
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=100, desc="Download", disable=False)
    task.start()
    task.display()

    unit = "B"
    unit_scale = False
    unit_divisor = 1000

    row = RateColumn(unit, unit_scale, unit_divisor)
    row.render(task)

    rate_column = row.render(task).text
    rate = rate_column.split()[0]
    rate_unit = rate_column.split()[1]

    assert rate == '0.0'
    assert rate_unit == 'B/s'

    for i in range(100):
        task.update(i)
        task.display()

    assert task.n == task.total
    assert task.total == 100
    assert (task.desc == 'Download')



# Generated at 2022-06-22 15:54:32.804948
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10) as pbar:
        pbar.n = 5
        assert pbar.n == 5
        pbar.clear()
        assert pbar.n == 0

# Generated at 2022-06-22 15:54:35.355238
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    sys.stderr = open('/dev/null', 'w')
    tqdm_rich().close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:54:36.947133
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich('test tqdm_rich clear').clear()

# Generated at 2022-06-22 15:54:42.273861
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import time
    with trange(10, desc='Desc', bar_format='{desc}: {bar}', ncols=None) as t:
        for i in t:
            time.sleep(0.01)
            if i % 3 == 0:
                t.reset(50)

# Generated at 2022-06-22 15:54:49.069274
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import difflib
    import io
    import sys
    import unittest
    from .cols import RateColumn

    class TestRateColumn(unittest.TestCase):
        def test_render(self):
            rate_collumn = RateColumn()
            out = io.StringIO()
            sys.stdout = out
            rate_collumn.render({'task':{'speed':None}, 'completed':None, 'total':None})
            output = out.getvalue().strip()
            expected_output = "? /s"
            if output != expected_output:
                print("\n====== Expected Output ======\n")
                print(expected_output)
                print("\n======= Actual Output =======\n")
                print(output)
                print("=============================\n")
                print("Diff:\n")

# Generated at 2022-06-22 15:54:50.682944
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich().clear()

# Generated at 2022-06-22 15:54:55.559750
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from rich.progress import Progress
    prog = Progress(transient=True)
    t = tqdm_rich(range(10), miniters=0, gui=True)
    assert isinstance(t._prog, Progress)
    t.display()
    t.close()

# Generated at 2022-06-22 15:54:59.098083
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    bar = tqdm_rich(total=3, ncols=50, disable=True)
    bar.display()
    bar.n = 1
    bar.display()
    bar.n = 2
    bar.display()
    bar.n = 3
    bar.display()

# Generated at 2022-06-22 15:55:03.201671
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm_rich(total=10):
        ...
        if i == 5:
            i = tqdm_rich().reset()
        ...

# Mock out GUI rendering

# Generated at 2022-06-22 15:55:12.701633
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        with tqdm_rich(range(3), clear=False) as pbar:
            pbar.clear()
    except Exception:
        raise AssertionError("Exception is unexpectedly raised")


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in tqdm(range(8), desc="1st loop"):
        for j in tqdm(range(100), desc="2nd loop", leave=False, total=100):
            sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-22 15:55:28.308754
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    fc = FractionColumn()
    assert fc.render({"completed": "1", "total": "2"}) == "0.5/1.0 "
    fc = FractionColumn(
        unit_scale=True,
        unit_divisor=1000,
    )
    assert fc.render({"completed": "1000", "total": "1000"}) == "1.0/1.0 "
    fc = FractionColumn(
        unit_scale=True,
        unit_divisor=1024,
    )
    assert fc.render({"completed": "1048576", "total": "2097152"}) == "0.5/1.0 M"



# Generated at 2022-06-22 15:55:36.839459
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import tnrange, tqdm_gui
    from .std import tqdm as tqdm_std
    from .std import tnrange as tnrange_std
    for t in tqdm_rich, tqdm_gui, tqdm_std, tnrange, tnrange_std:
        with t(total=1, disable=True) as i:
            # display must work both before and after iteration
            i.display()
            i.__next__()
            i.display()
            assert i.dynamic_ncols == i.ncols

# Generated at 2022-06-22 15:55:41.429978
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=1000)
    task.set_description('test')
    task.update(500)
    task.update(500, new_total=1024)
    task.update(512)
    task.update(512, new_total=1024)



# Generated at 2022-06-22 15:55:53.420728
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID

    class FakeTask():
        def __init__(self, total=0, completed=0, desc="", ncols=0, **_kwargs):
            self.total = total
            self.description = desc
            self.completed = completed
            self.percentage = 0
            self.ncols = ncols
            self.remaining = 0
            self.speed = 0
            return

    class FakeProgress():
        def __init__(self, *_args, **_kwargs):
            self.console = Console(width=80)
            self.rows = []
            self.columns = []
            self.current_row = 0
            self.transient = False
            self.next_task_id = 0
            return


# Generated at 2022-06-22 15:56:02.158684
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import TaskID

    task_id = TaskID()
    std_tqdm.write = lambda *_: None

    class TqdmRichSilent(tqdm_rich):
        def clear(self, nolock=False):
            pass

    tr = TqdmRichSilent()
    assert tr.disable is True
    tr = TqdmRichSilent(disable=False)
    assert tr.disable is False
    with tqdm_rich(disable=True) as tr:
        assert tr.disable is True
    with tqdm_rich(disable=False) as tr:
        assert tr.disable is False
    tr = TqdmRichSilent(disable=False)
    tr._prog = None
    tr.display()
    tr._prog = True
    tr.display()
   

# Generated at 2022-06-22 15:56:06.166311
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import time

    with tqdm_rich(total=10, desc='desc') as pbar:
        for i in range(150):
            pbar.update(1)
    time.sleep(0.1)
    pbar.reset(total=20)
    assert pbar.total == 20
    with pbar:
        for i in range(30):
            pbar.update(1)

# Generated at 2022-06-22 15:56:11.805174
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.text import Text
    column = FractionColumn()
    task = Task(description=Text(Markdown('Testing'), style=Style(color='blue')),
                completed=500, total=2300)
    assert column.render(task) == Text('500/2,300', style='progress.download')
    assert column.render(task).style.color == 'blue'

# Generated at 2022-06-22 15:56:23.895768
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert (FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(0, 0)) ==
            "0/0 ")
    assert (FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(1, 0)) ==
            "1/0 ")
    assert (FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(1, 2)) ==
            "1/2 ")
    assert (FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(1, 3)) ==
            "1/3 ")
    assert (FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(1, 5)) ==
            "1/5 ")

# Generated at 2022-06-22 15:56:31.117125
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=9, mininterval=0.1) as t:
        t.set_description('Test clear()')
        assert t.disable == False

        t.update()
        t.clear()

        t.update()
        t.close()

# Generated at 2022-06-22 15:56:37.929366
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecolumn = RateColumn(unit_scale=False)
    assert ratecolumn.render(task=None) == Text(f"? /s", style="progress.data.speed")
    assert ratecolumn.render(task=type('', (object,), {'speed': None})) == Text(f"? /s", style="progress.data.speed")

    ratecolumn = RateColumn(unit_scale=True, unit_divisor=1000)
    assert ratecolumn.render(task=type('', (object,), {'speed': None})) == Text(f"? /s", style="progress.data.speed")

# Generated at 2022-06-22 15:56:44.403555
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test method clear of class tqdm_rich by calling it.
    """
    tqdm_rich(range(1)).clear()

# Generated at 2022-06-22 15:56:51.063072
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich display."""
    test_tqdm_rich_display.called = False

    def display():
        """Mocked display."""
        test_tqdm_rich_display.called = True

    class TestTqdmRich(tqdm_rich):
        """Test class for tqdm_rich."""
        display = display

    TestTqdmRich().display()
    assert test_tqdm_rich_display.called

# Generated at 2022-06-22 15:56:53.304303
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test for tqdm_rich.clear()"""
    for _ in tqdm_rich(iterable=range(10)):
        break

# Generated at 2022-06-22 15:56:55.301977
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # No exception expected, see github issue #485
    tqdm_rich(range(3), disable=True).clear()


# Unit tests for class tqdm_rich

# Generated at 2022-06-22 15:57:05.786589
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    FractionColumn.render(task) function test
    """
    #
    # class Progress:
    # def __init__(self, description, total, **kwargs) -> None:
    # self.description = description
    # self.total = total
    # self.completed = 0  # type: int
    # self.text = ""  # type: str
    # self.status = None  # type: str
    # self.data = None  # type: Mapping[str, Any]
    # return
    # class FractionColumn(ProgressColumn):
    # def __init__(self, unit_scale=False, unit_divisor=1000) -> None:
    # self.unit_scale = unit_scale
    # self.unit_divisor = unit_divisor
    # super().__init

# Generated at 2022-06-22 15:57:12.780564
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(total=10)
    pbar.reset(total=20)
    assert pbar.total == 20, "Total not reset correctly"
    assert type(pbar).__name__ == "tqdm_rich", "tqdm_rich is not a class"
    assert str(type(pbar)) == "<class 'tqdm.rich.tqdm_rich'>", "tqdm_rich not a named class"


# Generated at 2022-06-22 15:57:15.832804
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm(range(10)):
        if i == 5:
            tqdm.reset(total=12)
        tqdm.update()

# Generated at 2022-06-22 15:57:22.540034
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time

    with tqdm(total = 100, bar_width = 15, bar_symbol = '-', bar_fill = '*', desc = "Downloading", leave = True,
              miniters = 1, mininterval = 0.1) as pbar:
        for i in range(100):
            time.sleep(0.1)
            pbar.update(1)
            if i == 50:
                pbar.reset(total = 80)
            if i == 80:
                pbar.reset(total = 100)

# Generated at 2022-06-22 15:57:34.433540
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest
    with pytest.raises(AttributeError, match=r"Failed to guess unit_scale parameter"):
        columns = RateColumn(unit="")
    columns = RateColumn(unit="", unit_scale=False)
    assert columns.render(task=tqdm(total=1e5)) == Text("0.0 /s", style="progress.data.speed")
    columns = RateColumn(unit="", unit_scale=True)
    assert columns.render(task=tqdm(total=1e5)) == Text("0.0 /s", style="progress.data.speed")
    columns = RateColumn(unit="", unit_divisor=1024, unit_scale=True)

# Generated at 2022-06-22 15:57:37.627068
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Initialize an instance of class tqdm_rich
    t = tqdm(total=1)
    assert t._task_id == '0'
    t.close()

# Generated at 2022-06-22 15:57:54.111929
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich import print
    from rich.theme import Theme

    theme = Theme({
        "progress.download": "dim green",
    }, force=True)

    print(FractionColumn().render({
        "completed": 0,
        "total": 0,
    }))
    print(FractionColumn(unit_scale=True).render({
        "completed": 0,
        "total": 0,
    }))
    print(FractionColumn(unit_scale=True).render({
        "completed": 1024,
        "total": 1024,
    }))
    print(FractionColumn(unit_scale=True, unit_divisor=1024).render({
        "completed": 1024,
        "total": 1024,
    }))

# Generated at 2022-06-22 15:57:57.489336
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    t = tqdm_rich()
    t.total = 100
    t.reset(100)
    assert t.total == 100

# Generated at 2022-06-22 15:57:59.607927
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    task = object()
    task.speed = None
    assert column.render(task) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-22 15:58:06.045449
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    test of method reset of class tqdm_rich
    """
    import rich.progress

    assert isinstance(trange(100)._prog, rich.progress.Progress)
    assert trange(100)._task_id is not None
    assert isinstance(trange(100)._prog.add_task('test'), rich.progress.ProgressTask)
    assert trange(100).reset()._task_id

# Generated at 2022-06-22 15:58:10.757803
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Ensure tqdm_rich resetting is working as expected."""
    it = tqdm_rich(0, 100)
    for i in range(5):
        it.reset(3 * i)
        assert it.total == 3 * i



# Generated at 2022-06-22 15:58:16.568866
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm with rich GUI."""
    from time import sleep
    with tqdm_rich(int(1e2), leave=True) as t:
        for i in t:
            sleep(.01)
            t.set_description("Description at " + str(i))


if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-22 15:58:20.791261
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # mock out a few methods, so we don't actually show the progress bar
    def clear(_): pass
    def display(*_): pass
    t = tqdm_rich(disable=True, desc="FOO")
    t._prog = None
    t.display = display
    t.clear = clear

    try:
        t.display()
    finally:
        t.close()

# Generated at 2022-06-22 15:58:32.690234
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test RateColumn.render()
    """
    rate_column = RateColumn(unit="/s", unit_scale=True, unit_divisor=1000)
    # Test with unit_scale=True
    assert rate_column.render({"speed": 125450, "total": 1000000000}) == Text("125.45 M/s", style="progress.data.speed")
    assert rate_column.render({"speed": 46789, "total": 1000000000}) == Text("46.79 K/s", style="progress.data.speed")
    assert rate_column.render({"speed": 1254, "total": 1000000000}) == Text("1.25 K/s", style="progress.data.speed")

# Generated at 2022-06-22 15:58:42.758451
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress).expected_width == len("? /s")
    assert RateColumn("B").render(Progress).expected_width == len("? B/s")
    assert RateColumn("iB").render(Progress).expected_width == len("? iB/s")
    assert RateColumn("B", unit_scale=True).render(Progress).expected_width == len("? B/s")
    assert RateColumn("B", unit_scale=True).render(Progress(total=2)).expected_width == len("1.00 B/s")
    assert RateColumn("iB", unit_scale=True).render(Progress(total=2)).expected_width == len("1.00 iB/s")


# Generated at 2022-06-22 15:58:52.070779
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True, unit_divisor=1024),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit='B', unit_scale=True,
                        unit_divisor=1024), "]"
    )
    with tqdm_rich(total=11, progress=progress) as pbar:
        for _ in range(10):
            pbar.update()
            pbar.reset(total=10)
            for _ in range(10):
                pbar.update()

# Generated at 2022-06-22 15:59:09.575587
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test the method render of class RateColumn."""
    import math
    try:
        import pytest
        from tqdm.rich import RateColumn
    except ImportError:
        return
    rate_column = RateColumn()
    for speed in range(1, 19):
        suffix, precision = rate_column.render(speed).value.split(' ')
        # pylint: disable=unsubscriptable-object
        assert math.isclose(int(suffix[:-1]) * 1000**(len(suffix) - 1), speed,
                            rel_tol=precision)
    for speed in range(20, 12000, 1000):
        suffix, precision = rate_column.render(speed).value.split(' ')

# Generated at 2022-06-22 15:59:12.224466
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(0)
    t.display()


if __name__ == "__main__":
    from time import sleep
    with trange(100) as t:
        for x in t:
            sleep(.01)

# Generated at 2022-06-22 15:59:15.367552
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    progress = tqdm_rich(range(10), 'TestProgress')
    progress.reset()
    progress.reset(total=10)
    progress.reset(total=5)
    assert progress.total == 5

# Generated at 2022-06-22 15:59:23.632874
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    if rc.render(Progress) not in (Text("10.00 B/s", style="progress.data.speed"), Text("10.00  B/s", style="progress.data.speed")):  # pragma: no cover
        raise Exception("RateColumn - wrong answer")
    rc = RateColumn(unit="sample")
    if rc.render(Progress) not in (Text("10.00 sample/s", style="progress.data.speed"), Text("10.00  sample/s", style="progress.data.speed")):  # pragma: no cover
        raise Exception("RateColumn - wrong answer")

# Generated at 2022-06-22 15:59:31.768590
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        import colorama
    except ImportError:
        pass
    else:
        colorama.init()
    import rich.console
    import sys

    console = rich.console.Console()

    with tqdm_rich(total=10, desc='Testing',
                  unit_scale=True, unit_divisor=1024) as prog:
        for i in range(prog.total):
            prog.display()
            sys.stdout.flush()


if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-22 15:59:38.246242
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import BarColumn, Progress, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn  # noqa

        def tqdm_rich_display_test():
            value = 0
            t = tqdm_rich(total=100)
            for i in range(100):
                value += 1
                t.update(value)
            t.close()

        tqdm_rich_display_test()

    except (ImportError, AttributeError):
        pass

# Generated at 2022-06-22 15:59:47.219026
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test the `tqdm_rich.reset()` method."""
    import sys

    with tqdm_rich(total=1000) as bar:
        for i in range(1000):
            bar.update()

    with tqdm_rich(total=1000) as bar:
        for i in range(1000):
            bar.update()
            if i == 500:
                bar.reset(total=0)
                # When total is 0, calculation of percentage is not possible.
                # So, it will be "nan%".
                assert bar.format_dict["percentage"] == float(
                    "nan"), "percentage should be nan"
                assert bar.format_dict["bar_format"] == "nan%", \
                    "bar_format should be nan%"
            if i == 900:
                bar.reset()
                #

# Generated at 2022-06-22 15:59:54.206328
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    import os
    with tqdm_rich(range(100), ascii=True) as pbar:
      for i in pbar:
        time.sleep(0.01)
    os.system("clear")
    with tqdm_rich(range(100), ascii=True) as pbar:
      for i in pbar:
        time.sleep(0.01)
        if i == 50:
          pbar.reset(total=200)


# Generated at 2022-06-22 16:00:01.368987
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test render method for FractionColumn class.

    Test whether render method for FractionColumn class is working properly.
    """
    class task:
        completed = 10
        total = 100
        description = "Test description"
        percentage = 100

    test1 = FractionColumn().render(task)
    assert test1 == "10/100 "

    test2 = FractionColumn(unit_scale=True).render(task)
    assert test2 == "10/100  "

    test3 = FractionColumn(unit_scale=True, unit_divisor=1024).render(task)
    assert test3 == "10/100  "

    task.completed += 1
    task.total += 1

    test4 = FractionColumn().render(task)
    assert test4 == "1.0/1.1 "


# Generated at 2022-06-22 16:00:12.610855
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the words displayed in the rate column of tqdm.
    """
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)

    # Approach 1: Speed is None
    assert "? B/s" == rate_column.render(std_tqdm(total=100, unit='B'))

    # Approach 2: Speed is 1
    assert "1.0 B/s" == rate_column.render(std_tqdm(total=100, unit='B', unit_scale=True, unit_divisor=1000))

    # Approach 3: Speed is 10
    assert "10.0 B/s" == rate_column.render(std_tqdm(total=100, unit='B', unit_scale=True, unit_divisor=1000))

    # Approach 4:

# Generated at 2022-06-22 16:00:31.283344
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # method render
    progress = Progress()
    rate_column = RateColumn()
    task = progress.add_task("", total=1)
    rate_column.render(task)

# Generated at 2022-06-22 16:00:41.306686
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Check that tqdm_rich object can be reset()
    """
    progress = trange(1, desc='bar', leave=True, unit='it')
    progress.reset(10)
    assert progress.total == 10
    assert progress.n == 0
    progress.reset()
    assert progress.total == 10
    assert progress.n == 0
    progress.reset(50)
    assert progress.total == 50
    assert progress.n == 0
    progress.reset(total=30)
    assert progress.total == 30
    assert progress.n == 0
    progress.reset(total=10)
    assert progress.total == 10
    assert progress.n == 0
    progress.reset(50, total=10)
    assert progress.total == 10
    assert progress.n == 0

# Generated at 2022-06-22 16:00:43.031416
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in tqdm([1, 2, 3], disable=True):
        pass

# Generated at 2022-06-22 16:00:54.998205
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import rich.progress
    import tqdm

    # 创建进度条

# Generated at 2022-06-22 16:01:00.708062
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # print("test_tqdm_rich()")
    t = [0]
    with tqdm_rich(total=10, desc="testing") as pbar:
        for x in pbar:
            t[0] += 1
            pbar.set_description("testing... %d" % t[0])
    assert t[0] == 10



# Generated at 2022-06-22 16:01:06.421278
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(rate_num_format='{n:,.{f}f}')
    task._RateColumn__trigger = True
    # assert task._RateColumn__trigger
    # assert not task._RateColumn__trigger
    assert task._RateColumn__make_tuple() == (
        "unknown",
        0,
        1
    )
    assert task._RateColumn__render() == '? /s'
    assert task._RateColumn__render(speed=12.2) == '12.2 /s'
    assert task._RateColumn__render(speed=32) == '32.0 /s'

# Generated at 2022-06-22 16:01:08.989409
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        for i in tqdm_rich(range(100)):
            pass
    except:  # pragma: no cover
        return False
    else:
        return True

# Generated at 2022-06-22 16:01:16.691258
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
  from unittest import TestCase
  from unittest import main as twain
  from rich.progress import Progress
  from rich.console import Console
  from rich.theme import Theme
  from rich.style import Style, StyleGroup
  from rich.text import Text

  class TestFractionColumnRender(TestCase):
    def test_true(self):
      test_obj = Progress()
      test_obj.set_total(1000)

      obj = FractionColumn(unit_scale=True, unit_divisor=1000)

      assert obj.render(test_obj) == \
        Text('0.0/0.0 ', style='progress.download')

  twain()


# Generated at 2022-06-22 16:01:20.930395
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    """
    Unit test for method reset of class tqdm_rich.
    """
    from rich.console import Console
    t = tqdm_rich(total=10, console=Console())
    assert t._prog.total == 10

    t.reset(total=100)
    assert t._prog.total == 100

# Generated at 2022-06-22 16:01:23.651318
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():  # pragma: no cover
    """Test method render of class FractionColumn."""
    progressColumn = FractionColumn()
    type(progressColumn).render = ProgressColumn.render
    output = progressColumn.render(
        "task"
        )
    assert(output == "0.0/0.0")

# Generated at 2022-06-22 16:02:19.009448
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tc = RateColumn()
    assert tc.render({'speed': None}) == Text(f"? /s", style="progress.data.speed")
    assert tc.render({'speed': 150}) == Text(f"150 /s", style="progress.data.speed")
    tc = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert tc.render({'speed': None}) == Text(f"? B/s", style="progress.data.speed")
    assert tc.render({'speed': 150}) == Text(f"150 B/s", style="progress.data.speed")
    assert tc.render({'speed': 1500}) == Text(f"1.5 KB/s", style="progress.data.speed")

# Generated at 2022-06-22 16:02:24.842907
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.markdown import Markdown
    from rich.box import HEAVY_HEAD
    from rich.table import Column, Table
    from rich.console import Console
    from rich import box
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.progress import Progress

    """Test the result of the function FractionColumn's render()"""
    console = Console(color_system='windows')
    # create a table
    table = Table(show_header=True, header_style='bold magenta')
    # add a column
    table.add_column("Title", style="cyan", justify="center")
    table.add_column("Case", justify="center")
    table.add_column("Time", justify="center")
    table.add_column("Remarks", justify="center")
    # add a row

# Generated at 2022-06-22 16:02:32.337929
# Unit test for method render of class RateColumn
def test_RateColumn_render():
  rate_column = RateColumn()
  task = Progress(
    description="description",
    completed=2,
    total=100,
    speed=100,
    start_time=0,
    total_time=0,
  )
  assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")
  rate_column = RateColumn("b")
  task = Progress(
    description="description",
    completed=2,
    total=100,
    speed=100,
    start_time=0,
    total_time=0,
  )
  assert rate_column.render(task) == Text("100.0 b/s", style="progress.data.speed")

# Generated at 2022-06-22 16:02:34.977165
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=4)
    for i in t:
        t.display()
    t.close()

# Generated at 2022-06-22 16:02:46.071116
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit_scale=True).render(tqdm_rich(total=2)) == Text("? B/s", style="progress.data.speed")
    assert RateColumn().render(tqdm_rich(total=2)) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True).render(tqdm_rich(total=2, desc="test")) == Text("? B/s", style="progress.data.speed")
    assert RateColumn().render(tqdm_rich(total=2, desc="test")) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-22 16:02:55.954124
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import render_screen
    from rich.syntax import Syntax

    progress = Progress(
        Text("[bold yellow]{task.description}"),
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=False, unit_divisor=1000), "]"
    )
    task_id = progress.add_task("test", total=1024, completed=512)

# Generated at 2022-06-22 16:03:05.209943
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B").render("") == "? B/s"
    assert RateColumn(unit="B").render("", speed=1) == "1 B/s"
    assert RateColumn(unit="B").render("", speed=1024) == "1.00 KB/s"
    assert RateColumn(unit="B").render("", speed=1002400) == "1.00 MB/s"
    assert RateColumn(unit="B").render("",
                      speed=1002400, unit_scale=True) == "0.98 MB/s"


# Generated at 2022-06-22 16:03:13.798803
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm.auto import tqdm as tqdm_auto
    from rich import print

    for _ in tqdm_auto(range(10)):
        pass
    print("Reset[0]")
    tqdm_rich.reset()

    for _ in tqdm_auto(range(10)):
        pass
    print("Reset[20]")
    tqdm_rich.reset(20)

    for _ in tqdm_auto(range(10)):
        pass

# Generated at 2022-06-22 16:03:24.314457
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert(FractionColumn.render(FractionColumn(), Progress(total=1000)) == Text(
        "0/1 K", style="progress.download"))
    assert(FractionColumn.render(FractionColumn(unit_scale=True, unit_divisor=1024), Progress(total=1024)) == Text(
        "0/1 K", style="progress.download"))
    assert(FractionColumn.render(FractionColumn(unit_scale=True, unit_divisor=1024), Progress(total=10)) == Text(
        "0/10 ", style="progress.download"))
    assert(FractionColumn.render(FractionColumn(), Progress(total=1023)) == Text(
        "0/1023 ", style="progress.download"))

# Generated at 2022-06-22 16:03:34.399569
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from pprint import pformat

    for leave in [True, False]:
        for i in tqdm(range(1), leave=leave):
            t = tqdm(range(10), leave=leave)
            assert t.total == 10
            t.reset(total=20)
            assert t.total == 20
            t.reset()
            assert t.total == 10
            t.reset(total=22)
            assert t.total == 22
            t.reset(total=None)
            assert t.total == 10
            t.reset(total=None)
            assert t.total == 10
            # test raise
            try:
                t.reset(total=False)
                raise Exception()  # pragma: no cover
            except TypeError:
                pass