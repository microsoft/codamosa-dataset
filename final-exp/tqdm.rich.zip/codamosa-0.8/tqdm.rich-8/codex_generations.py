

# Generated at 2022-06-22 15:53:40.354718
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pbar = tqdm_rich("some string")
    assert hasattr(pbar, 'clear')
    pbar.close()

# Generated at 2022-06-22 15:53:43.798415
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    progress = (
        "[progress.description]{task.description}",
        "[progress.bar:progress.percentage]{task.percentage:>4.0f}%",
        "[progress.info] {task.info}")
    with tqdm_rich(range(10), total=10, progress=progress) as bar:
        bar.set_postfix(info="%s%%" % "100")
        bar.display()

# Generated at 2022-06-22 15:53:44.500573
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-22 15:53:51.852308
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_cases = [
        (1, "1/s"), (123, "123/s"),
        (1230, "1.2K/s"), (12300, "12.3K/s"),
        (123000, "123K/s"), (1234000, "1.2M/s"),
        (12345000, "12.3M/s"), (123456000, "123M/s"),
        (1234567000, "1.2G/s"), (12345678000, "12.3G/s"),
        (123456789000, "123G/s"), (1234567890000, "1.2T/s"),
        (12345678900000, "12.3T/s"), (123456789000000, "123T/s")
    ]
    rc = Rate

# Generated at 2022-06-22 15:53:56.203964
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich import print
    pc = Progress(BarColumn(bar_width=None),FractionColumn())
    with pc as p:
        task = p.add_task('FractionColumn',total=10000)
        p.update(task,completed=5000)

# Generated at 2022-06-22 15:54:00.116971
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time

    t = tqdm_rich(total=100, desc="Task")
    for i in range(100):
        time.sleep(0.01)
        t.update(1)

# Generated at 2022-06-22 15:54:06.336365
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    import pytest

    with tqdm_rich(total=2) as t:
        assert t.total == 2
        t.display()
        time.sleep(0.1)
        t.update(1)
        assert t.n == 1
        t.display()
        time.sleep(0.1)
        t.update(1)
        assert t.n == 2

# Generated at 2022-06-22 15:54:18.869550
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich import print
    import unittest
    import sys

    class Test_tqdm_rich_display(unittest.TestCase):
        """Unit test for method display of class tqdm_rich"""
        def test_tqdm_rich_display(self):
            """Unit test for method display of class tqdm_rich"""
            progress = (
                "[progress.description]{task.description}"
                "[progress.percentage]{task.percentage:>4.0f}%",
                BarColumn(bar_width=None),
                FractionColumn(),
                "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
                ",", RateColumn(), "]"
            )
            task_id = 0
            with Progress(*progress, transient=True) as prog:
                task_id = prog.add_task

# Generated at 2022-06-22 15:54:20.986036
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    bar = tqdm_rich(range(10))
    bar.close()
    assert True

# Generated at 2022-06-22 15:54:25.986176
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print(RateColumn().render(None))
    print(RateColumn(unit="B").render(None))
    print(RateColumn(unit="MiB").render(None))
    print(RateColumn(unit_scale=True).render(None))

# Generated at 2022-06-22 15:54:36.684664
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .tests import test_clear
    test_clear(tqdm)

# Generated at 2022-06-22 15:54:39.081578
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test render method of RateColumn class.
    """
    RateColumn().render(None)

# Generated at 2022-06-22 15:54:45.414240
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import rich
    import rich.progress as progress
    import sys
    rich.trace.install()
    try:
        with tqdm_rich(total=10) as t:
            t.display(1)
            assert t.disable == False
            t.close()
            t.disable = True
            t.display(2)
            assert t.disable == True
            t.close()
    except:
        sys.stderr.write(rich.trace.format_exc())

# Generated at 2022-06-22 15:54:57.042910
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test for method render of class RateColumn."""
    expected_result_1 = Text("976.6 M/s", style="progress.data.speed")
    expected_result_2 = Text("1.0 M/s", style="progress.data.speed")
    result_1 = RateColumn(unit='b', unit_scale=True, unit_divisor=1000).render(
        std_tqdm.tqdm(total=0, unit='b', unit_scale=True, unit_divisor=1000,
                      ncols=100, miniters=1, postfix={'speed': 976_560}))

# Generated at 2022-06-22 15:55:02.382898
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from unittest.mock import patch
    console = Console()
    progress = Progress()
    a = RateColumn()
    with patch('rich.progress.ProgressColumn.__init__', lambda x: None):
        a.render(progress)

# Generated at 2022-06-22 15:55:06.196749
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=1, ncols=80, position=0, bar_format="{l_bar}{bar}{r_bar}")
    t.clear()
    t.close()
    return

# Generated at 2022-06-22 15:55:11.239992
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    >>> from tqdm.rich import trange, tqdm
    >>> for i in trange(10):
    ...     ...
    """
    # Create an instance of class FractionColumn
    fractioncolumn_instance = FractionColumn()
    fractioncolumn_instance.unit_scale = False
    fractioncolumn_instance.unit_divisor = 1000
    # Create an instance of class ProgressColumn
    progresscolumn_instance = ProgressColumn()
    # Create an instance of class Progress
    progress_instance = Progress()
    # Create an instance of class tqdm_rich
    tqdmrich_instance = tqdm_rich()
    # Calls the method add_task in Progress

# Generated at 2022-06-22 15:55:15.825354
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=42, leave=True) as pbar:
        assert pbar.n == 0
        pbar.update(1)
        assert pbar.n == 1
        pbar.reset()
        assert pbar.n == 0



# Generated at 2022-06-22 15:55:23.783321
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(0, 3, smoothing=0)
    task.n = 2
    task.smoothed_speed = None
    task.format_interval = None
    task.total = None
    task.unit_scale = False
    task.unit = 'b'
    task.unit_divisor = 1000
    r = RateColumn().render(task)
    assert r.text == 'inf b/s'
    assert r.style == 'progress.data.speed'

# Generated at 2022-06-22 15:55:24.901957
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-22 15:55:34.359911
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(1, total=1) as pbar:
        pbar.reset(100)
        assert pbar.total == 100

# Generated at 2022-06-22 15:55:44.177115
# Unit test for method render of class FractionColumn

# Generated at 2022-06-22 15:55:56.302656
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import time

    with trange(100, bar_format="{task.description}") as t:
        for i in t:
            t.set_description(f"Hey {i}")
            time.sleep(0.01)

    with trange(100, bar_format="{task.description}") as t:
        for i in t:
            t.set_description_str(f"Hey {i}")
            time.sleep(0.01)

    with trange(100, bar_format="{task.description}") as t:
        for i in t:
            t.set_description(f"Hey {i}")
            time.sleep(0.01)
            t.set_description_str(f"Cya {i}")
            time.sleep(0.01)


# Generated at 2022-06-22 15:56:04.560590
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    msg = "It's not necessary to use total= after reset(), "
    msg += "you can change the total on the fly."
    with tqdm(total=5) as pbar:
        assert pbar.total == 5, "pbar.total=5 failed" + msg
        pbar.reset()
        pbar.reset(total=7)
        assert pbar.total == 7, "pbar.total=7 failed" + msg
        for i in pbar:
            pass

# Generated at 2022-06-22 15:56:13.360530
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress('')
    task.update(completed=1, total=3)
    task.total = 3
    task.start_time = 0
    task.last_print_n = 0
    task.last_print_t = 0
    task.desc = 'test'
    task.speed = 123
    task.completed = 1
    # except: rate column render 
    except_rate_column_render = Text(f"123.0 /s", style="progress.data.speed")
    # actual: rate column render
    actual_rate_column_render = RateColumn(unit="", unit_scale=False, unit_divisor=1)
    actual_rate_column_render.render(task)
    # compare: rate column render
    assert except_rate_column_render == actual_rate_column_render

# Generated at 2022-06-22 15:56:18.456253
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm(total=100)
    task.update(10)
    tt = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert tt.render(task) == "10/100"


# Generated at 2022-06-22 15:56:22.728406
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Return value should be Text()
    assert isinstance(FractionColumn().render(None), Text)

    # Return value should be Text('0/0', style=...),
    #             when task.completed is 0 and
    #                  task.total is 0.
    assert str(FractionColumn().render(type('', (), {
        'completed': 0,
        'total': 0
    }))) == '0/0'

    # Return value should be Text('1/1.01', style=...),
    #             when task.completed is 1 and
    #                  task.total is 1.01
    #                  unit_scale is False
    assert str(FractionColumn().render(type('', (), {
        'completed': 1,
        'total': 1.01
    }))) == '1/1.0'



# Generated at 2022-06-22 15:56:31.647411
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [None, 2]:
        for n in [None, 0, 1, 2]:
            try:
                with tqdm(total=total, n=n) as pbar:
                    d = pbar.format_dict.copy()
                    pbar.reset(total=total)
            except Exception as e:
                raise type(e)("for n={}, total={}".format(n, total))


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    # rich.console.Console().print("[cyan]Rich[/cyan]")
    # iterable = range(5)
    # for _ in tqdm_rich(iterable, desc="foo"):
    #     sleep(1)
    #

# Generated at 2022-06-22 15:56:43.744955
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    unit_scale = True
    task = std_tqdm(total=1000000, unit_scale=unit_scale)
    completed = int(task.completed)
    total = int(task.total)
    if unit_scale:
        unit, suffix = filesize.pick_unit_and_suffix(
            total,
            ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
            1000,
        )
    else:
        unit, suffix = filesize.pick_unit_and_suffix(total, [""], 1)
    precision = 0 if unit == 1 else 1

# Generated at 2022-06-22 15:56:47.171847
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # pylint: disable=unused-argument
    with tqdm_rich(total=100) as t:
        t.update()
        t.clear()
        t.update(1)



# Generated at 2022-06-22 15:57:04.426818
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm rich display"""
    with tqdm_rich(total=10) as t:
        t.update(5)

# Generated at 2022-06-22 15:57:08.149823
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm_rich(desc='testing...', total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.n = i + 1
            pbar.update()

# Generated at 2022-06-22 15:57:14.568975
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = type("task", (object,), {'completed':5, 'total':10})()
    column = FractionColumn()
    assert column.render(task) == Text("0.5/1.0 ", style="progress.download")
    column = FractionColumn(unit_scale=True)
    assert column.render(task) == Text("5/10", style="progress.download")


# Generated at 2022-06-22 15:57:22.917387
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich import print
    from time import sleep

    # test with total
    for i in tqdm(range(10), total=10):
        sleep(0.1)
    print("\n")

    # test without total but with desc
    for i in tqdm(range(10), desc='testing'):
        sleep(0.1)
        if i == 5:
            tqdm.reset(total=10)
    print("\n")

    # test without total nor desc
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.reset(total=10)

# Generated at 2022-06-22 15:57:35.167851
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = type("Task", (), {
        "speed": None
    })

    # speed is None
    rate_column = RateColumn()
    assert rate_column.render(task) == Text("? /s", style="progress.data.speed")

    # speed = 1000
    task.speed = 1000
    assert rate_column.render(task) == Text("1.0 K/s", style="progress.data.speed")

    # speed = 10**6
    task.speed = 10**6
    assert rate_column.render(task) == Text("1.0 M/s", style="progress.data.speed")

    # speed = 10**30
    task.speed = 10**30
    assert rate_column.render(task) == Text("1.0 Y/s", style="progress.data.speed")
    
    # speed

# Generated at 2022-06-22 15:57:38.760757
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    """
    Unit test for method display of class tqdm_rich.
    """
    with tqdm_rich(total=10) as t:
        for i in t:
            t.display()
            time.sleep(0.01)

# Generated at 2022-06-22 15:57:42.951690
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pb = ProgressColumn()
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fc.render(pb) == fc.render(pb)

# Generated at 2022-06-22 15:57:55.455233
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    class DummyAttributes:
        def __init__(self):
            self.disable = False
            self.n = 0
            self.desc = "test"

    class DummyProgress:
        def update(self, *args, **kwargs):
            pass

    class DummyTqdmRich(tqdm_rich):
        def __init__(self):
            self.n = 0
            self.desc = "test"

# Generated at 2022-06-22 15:57:58.881974
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    n=2
    total=2.3
    task = ProgressColumn()
    task.completed = n
    task.total = total

    fraction_column = FractionColumn()

    assert(fraction_column.render(task) == "2/2.3 ")



# Generated at 2022-06-22 15:58:02.852339
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    console = Console()
    with tqdm_rich(total=10) as bar:
        bar.reset(total=20)
        for _ in range(5):
            bar.update()
    console.print(bar._prog)

# Generated at 2022-06-22 15:58:52.851269
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress = tqdm_rich(total=10, unit_scale=False, unit_divisor=None)
    progress.n = 0
    assert FractionColumn().render(progress) == Text("0.0/10.0 ", style="progress.download")
    progress.n = 1
    assert FractionColumn().render(progress) == Text("1.0/10.0 ", style="progress.download")
    progress.n = 10
    assert FractionColumn().render(progress) == Text("10.0/10.0 ", style="progress.download")
    progress = tqdm_rich(total=20, unit_scale=False, unit_divisor=None)
    progress.n = 10
    assert FractionColumn().render(progress) == Text("10.0/20.0 ", style="progress.download")

# Generated at 2022-06-22 15:59:02.742613
# Unit test for method render of class RateColumn

# Generated at 2022-06-22 15:59:05.840591
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test if a "no attribute _prog" error is raised
    when the method display is called.
    """
    testobj = tqdm_rich()
    testobj.display()

# Generated at 2022-06-22 15:59:07.495967
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for iterable, total in ((range(4), 4), ([], 0), ([1], 1)):
        rich_progress = tqdm(iterable, leave=False)
        rich_progress.reset(total=total)
        assert rich_progress.total == total

# Generated at 2022-06-22 15:59:15.399079
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test if tqdm_rich.reset raises an exception"""
    import unittest

    class TestTrange(unittest.TestCase):

        """Unit test of trange and trrange methods"""

        def test_trange_reset(self):
            """Test trange reset method"""
            with trange(5) as t:
                self.assertEqual(t.total, 5)
                t.reset(total=10)
                self.assertEqual(t.total, 10)

        def test_trrange_reset(self):
            """Test trrange reset method"""
            with trrange(5) as t:
                self.assertEqual(t.total, 5)
                t.reset(total=10)
                self.assertEqual(t.total, 10)
    unittest.main()

# Generated at 2022-06-22 15:59:17.292851
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t = TimeElapsedColumn()
    t.render_now = lambda task: 0.3
    t.task = Progress()
    t.render()

# Generated at 2022-06-22 15:59:21.491470
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import random
    random.seed(1)
    for i in tqdm(range(20)):
        time.sleep(0.1)
        progress.update(i)



# Generated at 2022-06-22 15:59:32.289202
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Unit test for main API class `tqdm_rich`.
    """
    import sys
    task = tqdm_rich(total=10)
    assert task.total == 10
    task.total = 15
    assert task.total == 15
    assert task.n == 0
    assert task.last_print_n == 0
    assert task.smoothing == 0.3
    assert task.dynamic_ncols
    assert not task.leave
    assert not task.miniters
    assert task.desc == ""
    assert task.unit == ""
    assert not task.disable
    assert not task.disable_tqdm
    assert not task.gui
    assert task.mininterval == 0.1
    assert task.maxinterval == 10.
    assert task.unit_scale

# Generated at 2022-06-22 15:59:34.240954
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    _test_RateColumn_render(RateColumn, filesize.pick_unit_and_suffix)


# Generated at 2022-06-22 15:59:39.986502
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .tqdm_pandas import tqdm_pandas
    from .notebook import tqdm_notebook
    for cls in [tqdm, tqdm_pandas, tqdm_notebook]:
        with cls(total=123456789, unit='B', unit_scale=True, unit_divisor=1024) as bar:
            bar.n = 1000000
            bar.refresh()

# Generated at 2022-06-22 16:00:39.165099
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Initialize tqdm_rich with range() and check if 'reset' works as expected.
    """
    b = tqdm_rich(range(10))
    for _ in b:
        pass

    b.reset(total=100)
    assert b.n == 0
    assert b.total == 100

    for _ in b:
        pass



# Generated at 2022-06-22 16:00:41.894138
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    tqdm_rich.reset() method must work with total=None
    """
    t = tqdm_rich(total=10)
    t.reset(None)
    assert t.total is None

# Generated at 2022-06-22 16:00:45.120257
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """See #418 for details."""
    with trange(10, leave=True) as t:
        t.display()
        t.display()

# Generated at 2022-06-22 16:00:53.587065
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich.console
    console = rich.console.Console()
    for i in tqdm(range(10), console=console):
        pass
    t = tqdm(range(10), console=console)
    t.reset(total=None)
    for i in t:
        pass
    t = tqdm(range(10), console=console)
    t.reset()
    for i in t:
        pass
    t = tqdm(range(10), console=console)
    t.reset(total=20)
    for i in t:
        pass

# Generated at 2022-06-22 16:00:57.155882
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from time import sleep
    from random import shuffle
    from rich.console import Console
    console = Console()
    with console.progress() as progress:
        tasks = [progress.add_task("Task " + str(i), total=100) for i in range(100)]
        for i in range(100):
            shuffle(tasks)
            for task in tasks:
                progress.update(task, advance=1)
                sleep(0.03)
            progress.reset()

# Generated at 2022-06-22 16:01:05.892538
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich
    import random
    import string
    import sys

    # random string to be used
    random_str = ''.join(random.choice(string.ascii_letters) for _ in range(4))
    # random numer to be used
    random_num = random.randrange(100)

    # create a progress object
    progress = Progress(
        "[progress.description]{task.description}",
    )

    # add a task to progress object and get task id
    task_id = progress.add_task('Test progress')
    progress.__enter__()

    # create tqdm_rich object
    for i in tqdm_rich(total=10):
        # get empty line to update task
        sys.stderr.write('\r')
        # update tqdm_rich object to update task


# Generated at 2022-06-22 16:01:15.128358
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn("")
    assert r.render(None) == Text("? /s", style="progress.data.speed")

    r = RateColumn("", unit_scale=True, unit_divisor=1000)
    assert r.render(None) == Text("? /s", style="progress.data.speed")

    r = RateColumn("", unit_scale=False, unit_divisor=1000)
    assert r.render(None) == Text("? /s", style="progress.data.speed")

    r = RateColumn("K")
    assert r.render(None) == Text("? K/s", style="progress.data.speed")

    r = RateColumn("K", unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-22 16:01:23.170069
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(std_tqdm(total=10)) == Text(u'? /s', style='progress.data.speed')
    assert RateColumn(unit='b').render(std_tqdm(total=10)) == Text(u'? b/s', style='progress.data.speed')
    assert RateColumn(unit_scale=True).render(std_tqdm(total=1000)) == Text(u'1.0 K/s', style='progress.data.speed')
    assert RateColumn(unit_scale=True, unit='b').render(
        std_tqdm(total=1000)) == Text(u'1.0 Kb/s', style='progress.data.speed')

# Generated at 2022-06-22 16:01:28.157389
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import tqdm
    t = tqdm(total=10, unit='B', unit_scale=True, unit_divisor=1024)
    for i in t:
        pass
    assert t.format_dict.get('rate') == 'K'

# Generated at 2022-06-22 16:01:36.180852
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from .utils import _range
    with patch('rich.progress.Progress.reset') as _reset:
        with tqdm(_range(0)) as bar:
                bar.reset(200)
        _reset.assert_called_once_with(total=200)
    with patch('rich.progress.Progress.reset') as _reset:
        with tqdm(_range(0)) as bar:
                bar.reset()
        assert not _reset.called

# Generated at 2022-06-22 16:03:22.207299
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=10) as t:
        for _ in range(5):
            t.update(1)
        t.reset(total=13)
        for _ in range(13):
            t.update(1)

# Generated at 2022-06-22 16:03:28.347826
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    RateColumn renders human readable transfer speed.
    """
    assert str(RateColumn().render(1)) == "1 B/s"
    assert str(RateColumn().render(0.5)) == "0.5 B/s"
    assert str(RateColumn().render(2000)) == "2 K/s"
    assert str(RateColumn().render(2000**3)) == "2 G/s"
    assert str(RateColumn().render(2000.8)) == "2.0 K/s"

# Generated at 2022-06-22 16:03:32.889103
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    n = 100
    for _ in range(2):
        test = tqdm_rich(total=n)
        for _ in range(n):
            test.display()
        test.reset(total=n * 2)
        for _ in range(n):
            test.display()
        test.close()

# Generated at 2022-06-22 16:03:39.025940
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for bar_total in [None, 10, 20]:
        for bar_n in [0, 5]:
            pb = tqdm_rich()
            #  simulated progress bar
            pb.reset(bar_total)
            pb.update(bar_n)
            assert pb.n == bar_n
            assert pb.total == bar_total
            assert pb._prog.get_task(pb._task_id).total == bar_total
            assert pb._prog.get_task(pb._task_id).completed == bar_n