

# Generated at 2022-06-22 15:53:41.896668
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1, disable=True) as bar:
        bar.display()
        bar.clear()  # Does nothing


if __name__ == '__main__':
    from .__main__ import main as _main
    _main()

# Generated at 2022-06-22 15:53:46.940988
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    line = "[progress.percentage]{task.percentage:>4.0f}%[progress.bar]{task.progressbar_1}{task.bar_2}[progress.data]{task.completed:>20.1f}/{task.total:>20.1f} {task.suffix}[progress.data]{task.data_speed:>16.1f} {task.unit_per_second}/s[progress.data]{task.remaining_time}/{task.elapsed_time}"
    progress = Progress(line)
    task = progress.add_task(description="description")
    assert type(FractionColumn(False).render(task)) == Text
    assert type(FractionColumn(True).render(task)) == Text

# Generated at 2022-06-22 15:53:53.513419
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # When self._unit = ""
    # Use self.render directly
    rate_column = RateColumn()
    assert rate_column.render(int(100)) == "100 /s"
    # Use tqdm_rich and set _number_format to None
    t = tqdm_rich([], leave=True, disable=True)
    t.format_dict['number_format'] = None
    assert t.format_dict["number_format"] == None
    t.close()
    # Use tqdm_rich and set _number_format to ""
    t = tqdm_rich([], leave=True, disable=True)
    t.format_dict['number_format'] = ""
    assert t.format_dict["number_format"] == ""
    t.close()

    # When self._unit = "B"
   

# Generated at 2022-06-22 15:54:01.287322
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os
    from io import StringIO
    from rich.console import Console

    output = StringIO()
    console = Console(output=output)
    pbar = tqdm_rich(desc="testing", console=console)
    pbar.n = 2
    pbar.total = 4
    pbar.display()
    assert str(pbar) == "testing:  50%|███████                                 | 2/4 [00:00<?, ?it/s, 50 B/s]"

    pbar.n = 4
    pbar.display()
    assert str(pbar) == "testing: 100%|███████████████| 4/4 [00:00<?, ?it/s, 50 B/s]"

    pbar.n = 1
    pbar.total = None
    pbar.display()
    assert str

# Generated at 2022-06-22 15:54:11.674131
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10) as pbar:
        for i in pbar:
            pass
    with tqdm_rich(total=10, mininterval=0) as pbar:
        for i in pbar:
            pbar.set_description_str("POS: {}".format(i))
    with tqdm_rich(total=10, mininterval=0) as pbar:
        for i in pbar:
            pbar.set_postfix(OrderedDict(pos=i))
    with tqdm_rich(total=10, mininterval=0) as pbar:
        for i in pbar:
            pbar.set_postfix_str("POS: {}".format(i))

# Generated at 2022-06-22 15:54:23.555432
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test human readable transfer speed."""
    rate_column = RateColumn(unit="%", unit_scale=True)
    actual = rate_column.render(Progress(completed=0, total=0, speed=None))
    assert actual == Text("? %/s", style="progress.data.speed")
    actual = rate_column.render(Progress(completed=0, total=0, speed=1000))
    assert actual == Text("1.0 K%/s", style="progress.data.speed")
    actual = rate_column.render(Progress(completed=0, total=0, speed=1024))
    assert actual == Text("1.0 K%/s", style="progress.data.speed")
    actual = rate_column.render(Progress(completed=0, total=0, speed=1025))
    assert actual

# Generated at 2022-06-22 15:54:27.826143
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    bar = tqdm_rich(total=3, unit="B")
    bar.display()
    assert bar.n == 0
    bar.update(2)
    bar.display()
    assert bar.n == 2
    bar.close()

# Generated at 2022-06-22 15:54:35.937378
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import trange
    from .utils import format_size
    from .std import format_interval
    from .std import format_meter
    for suffix, divisor in [("B", 1), ("KiB", 1024), ("MiB", 1024**2), ("GiB", 1024**3)]:
        with trange(1, 6, desc="Download") as t:
            for i in t:
                t.total = 100 * 10**i
                t.total_size = t.total
                t.n = t.total // 2
                t.refresh()

                # Unit conversions:
                speed = t.total / t.n
                byte_speed = speed

# Generated at 2022-06-22 15:54:40.822984
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = 1000
    bar_column = RateColumn(unit_scale=False, unit_divisor=1000)
    assert bar_column.render(task).text == "1.0 /s"

# Generated at 2022-06-22 15:54:42.686590
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .tests_tqdm import _test_RateColumn_render
    _test_RateColumn_render(RateColumn)

# Generated at 2022-06-22 15:54:57.411626
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rcol = RateColumn(unit="bps", unit_scale=False, unit_divisor=1000)
    # the numbers below need to be in ascending order to
    # test our multiplier selection

# Generated at 2022-06-22 15:55:00.517898
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    print(rate.render(10))
    rate = RateColumn("B", True, 1024)
    print(rate.render(10*1024*1024))
    rate = RateColumn("B", False, 1024)
    print(rate.render(10*1024*1024))



# Generated at 2022-06-22 15:55:08.950477
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Text, Progress
    from rich.console import Console
    from .std import tqdm

    progress_column = FractionColumn()
    task_id = Progress.current_task.__enter__()

    for n in tqdm(range(100)):
        Progress.current_task.update(n)
        fraction_column_render = progress_column.render(Progress.current_task)
        console = Console(width=3)
        console.print(fraction_column_render)



# Generated at 2022-06-22 15:55:13.237718
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test method display of class tqdm_rich."""
    def display(self):
        return
    tqdm_rich.display = display
    with tqdm_rich(total=1) as pbar:
        pbar.update()

# Generated at 2022-06-22 15:55:17.681290
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    progress = tqdm_rich(range(10), total=20)
    assert progress.n == 10
    progress.reset(total=30)  # reset also total
    assert progress.total == 30

# Generated at 2022-06-22 15:55:20.179329
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    assert r.render(123) == Text("123 /s", style="progress.data.speed")


# Generated at 2022-06-22 15:55:32.624405
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from io import StringIO
    from rich.console import Console

    console = Console()
    # 1 unit/second
    rate = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    with console.location(), StringIO() as stream:
        rate.render(100000, 0, 1, None)
        assert stream.getvalue() == "100,000 1/s"
    # 100 kilobytes/second
    rate = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    with console.location(), StringIO() as stream:
        rate.render(100000, 0, 1, None)
        assert stream.getvalue() == "100KB/s"
    # 100 kilobytes/second

# Generated at 2022-06-22 15:55:40.452371
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich([0], total=10)
    pbar.update()
    pbar.reset(total=None)
    assert pbar.total == 10
    pbar.reset(total=5)
    assert pbar.total == 5
    # Check that reset clears the bar (setting `n` == 0)
    assert not pbar.n
    pbar.update(4)
    assert (pbar.n == None)
    pbar.reset()
    assert not pbar.n
    pbar.close()

# Generated at 2022-06-22 15:55:42.754698
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Test for interior code
    with tqdm.trange(0, 0) as t:
        t.clear()



# Generated at 2022-06-22 15:55:49.269081
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = std_tqdm()
    task.total = 20000
    task.completed = 15000
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    expected_fraction_column = Text("15.0/20.0 K", style="progress.download")
    assert fraction_column.render(task) == expected_fraction_column

# Generated at 2022-06-22 15:55:56.707286
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(unit="B", unit_scale=True) as t:
        for i in t:
            t.reset(10)
            t.update()
            if i >= 10:
                break


# Generated at 2022-06-22 15:56:04.492078
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    c = RateColumn()
    p = lambda speed, unit, suffix: f"{speed/unit:,.{1}f} {suffix}{c.unit}/s"

# Generated at 2022-06-22 15:56:13.303713
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=100)
    t.reset(total=100)
    t.close()
    t.update(0)
    t = tqdm_rich(total=100)
    t.desc = "DEFAULT"
    t.update(25)
    t.desc = "TEST"
    t.reset(total=100)
    t.close()
    t = tqdm_rich(total=100)
    t.desc = "DEFAULT"
    t.reset(total=101)
    t.update(25)
    t.close()
    t.reset()
    t.close()
    t = tqdm_rich(total=100)
    t.reset(total=100)
    t.update_to(100)
    t.close()

# Generated at 2022-06-22 15:56:20.598931
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from cStringIO import StringIO
    output = StringIO()
    t = tqdm_rich(iterable=range(3), file=output)
    t.update()
    assert t.get_lock().acquire()
    t.close()
    if not t.gui:
        assert output.getvalue().strip() == '1/3:  33%|█\r2/3:  67%|██\r'

# Generated at 2022-06-22 15:56:28.948886
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress, FractionColumn, BarColumn, Text

    p = Progress()
    p.__enter__()
    p.add_task(desc='Test', total=5)
    p.update(0, completed=2)
    p.update(0, completed=5)
    p.update(0, completed=3)

    out = p.render(tuple(p.tasks))
    assert out == (
        "[progress.description]Test        ",
        "[progress.percentage] 40%",
        BarColumn(bar_width=2),
        Text(style="progress.fraction", text="0.4/1.0"),
        ""
    )


# Generated at 2022-06-22 15:56:32.661181
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    column = FractionColumn(unit_scale=False)
    assert column.render(None) == Text("0/0 ")

    column = FractionColumn(unit_scale=True)
    assert column.render(None) == Text("0.0/0.0 ")


# Generated at 2022-06-22 15:56:44.849189
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from datetime import datetime
    from rich.text import Text
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(), 0.5) == Text("0.5 B/s", style="progress.data.speed")
    assert rate_column.render(object(), 0.5) == Text("0.5 B/s", style="progress.data.speed")
    assert rate_column.render(object(), 0.5) == Text("0.5 B/s", style="progress.data.speed")
    assert rate_column.render(object(), 0.5) == Text("0.5 B/s", style="progress.data.speed")
   

# Generated at 2022-06-22 15:56:55.062776
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():  # pragma: no cover
    from rich.console import Console
    from rich.progress import Task
    from tqdm import tqdm
    console = Console()

    for _ in range(10):
        with Progress() as progress_bar:
            for item in tqdm(range(1000000)):
                task = Task(description='description')
                task.completed = item
                task.total = 1000000
                console.print(FractionColumn().render(task))
    console.print()
    console.print()

    for _ in range(10):
        with Progress() as progress_bar:
            for item in tqdm(range(10000)):
                task = Task(description='description')
                task.completed = item
                task.total = 10000

# Generated at 2022-06-22 15:57:05.532008
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pb = tqdm_rich((i for i in range(10)), total=10, unit="B", bar_format="{l_bar}{bar}|")
    pb.render_progress(FractionColumn, Text("[B]"))
    pb.close()
    pb = tqdm_rich((i for i in range(10)), total=10, unit="B", unit_scale=True,
                   bar_format="{l_bar}{bar}|")
    pb.render_progress(FractionColumn, Text("[B]"))
    pb.close()
    pb = tqdm_rich((i for i in range(10)), total=10, unit="B", unit_scale=True,
                   bar_format="{l_bar}{bar}|", unit_divisor=1024)
    pb

# Generated at 2022-06-22 15:57:10.676948
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Verify that reset(total) resets the progress bar.
    """
    progress = tqdm(total=20, desc="Process A: ")
    for i in range(5):
        progress.update()
    progress.reset(100)
    for i in range(100):
        progress.update()

# Generated at 2022-06-22 15:58:18.414774
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test `tqdm_rich.display` method."""
    t = tqdm_rich(4, total=4, leave=False)
    for i in range(4):
        t.display()
        t.update()
    t.close()

# Generated at 2022-06-22 15:58:34.005742
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    >>> from tqdm.rich import trange
    >>> for i in trange(10):
    ...     pass
    """
    from rich.progress import TaskID

    task = TaskID(0, "", total=10, completed=5)
    fraction_column = FractionColumn(unit_scale=False)
    print(fraction_column.render(task))
    fraction_column = FractionColumn(unit_scale=True)
    print(fraction_column.render(task))

# Generated at 2022-06-22 15:58:53.523001
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich."""
    import sys
    import builtins
    from unittest import TestCase

    class UnitTest(TestCase):
        # pylint: disable=missing-docstring
        def test_nothing(self):  # pragma: no cover
            self.assertEqual(self.test, True)

    builtins.__dict__.update({
        "unit_test_output": [],
        "_": lambda x: unit_test_output.append(x),
    })

    with trange(10) as t_bar:
        unit_test_output = []
        t_bar.display()
        sys.stdout = sys.__stdout__
        sys.__stdout__.flush()
        print(unit_test_output[0])
        t_bar

# Generated at 2022-06-22 15:59:03.378259
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm as std_tqdm
    with std_tqdm(total=10) as t1:
        d = {'desc':'','total':10,'n':0,'unit':'it','unit_scale':False,\
            'unit_divisor':1000,'dynamic_ncols':False,'smoothing':0.3,\
            'bar_format':None,'initial':0,'position':0,'postfix':{},\
            'leave':False,'disable':False,'mininterval':0.1,\
            'maxinterval':10.0,'miniters':None,'ascii':None,\
            'gui':False,'ncols':80,'mininterval':0.1,'miniters':1,\
            'gui':True}

# Generated at 2022-06-22 15:59:17.843560
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress()) == Text('0.0/0.0 ')
    assert FractionColumn().render(Progress(total=None, completed=50)) == Text('50.0/0.0 ')
    assert FractionColumn().render(Progress(total=100, completed=50)) == Text('50.0/100.0 ')
    assert FractionColumn(unit_scale=True).render(Progress(total=100, completed=50)) == Text('50.0/100.0 ')
    assert FractionColumn(unit_scale=True).render(Progress(total=1500, completed=50)) == Text('0.1/1.5 K')
    assert FractionColumn(unit_scale=True).render(Progress(total=1500000, completed=500)) == Text('0.1/1.5 M')

# Generated at 2022-06-22 15:59:24.016739
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    with tqdm(total=10, desc='My desc') as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    t.reset(total=5)
    for i in range(5):
        time.sleep(0.1)
        t.update()

# Generated at 2022-06-22 15:59:29.818778
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm
    t = tqdm(list(range(4)), total=4)
    t.__enter__()
    for i in t:
        pass
    t.__exit__()
    try:
        t.total = None
    except TypeError:
        pass
    else:
        raise ValueError("Equal of total with None works!")

# Generated at 2022-06-22 15:59:33.427975
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn."""
    import rich.progress
    task = rich.progress.Task(1000, 2000)
    column = FractionColumn()
    column.render(task)

# Generated at 2022-06-22 15:59:49.704641
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = {'speed': None}
    assert(RateColumn().render(task) == Text(f"? /s", style="progress.data.speed"))
    task = {'speed': 10}
    assert(RateColumn().render(task) == Text(f"10 /s", style="progress.data.speed"))
    task = {'speed': 1000}
    assert(RateColumn().render(task) == Text(f"1.0 K/s", style="progress.data.speed"))
    task = {'speed': 10**9}
    assert(RateColumn().render(task) == Text(f"1.0 G/s", style="progress.data.speed"))
    task = {'speed': 10**15}

# Generated at 2022-06-22 15:59:56.669419
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    assert column.render({"speed": 1000}) == Text("1.0 /s", style="progress.data.speed")
    assert column.render({"speed": 1000000}) == Text("1.0 M/s", style="progress.data.speed")
    assert column.render({"speed": 9999999}) == Text("10.0 M/s", style="progress.data.speed")
    assert column.render({"speed": None}) == Text("? /s", style="progress.data.speed")



# Generated at 2022-06-22 16:01:04.944919
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    from rich import print
    from rich.console import Console
    from rich.progress import BarColumn, ItemCountColumn

    class Task:
        description = ""
        completed = 0
        total = 10

    with Console() as console:
        progress = Progress(
            "[progress.description]{task.description}",
            BarColumn(),
            "[", ItemCountColumn(), "]",
            transient=False,
            console=console,
        )
        with progress:
            task = progress.add_task(description="Downloading...")

            for _ in range(10):
                progress.update(task, completed=task.completed + 1)



# Generated at 2022-06-22 16:01:30.207955
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test for method reset of class tqdm_rich"""
    from time import sleep
    for i in tqdm_rich(range(10), total=10, desc='test1'):
        sleep(0.1)
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            sleep(0.1)
            pbar.update()
    for i in tqdm_rich(range(10), total=10, desc='test2'):
        sleep(0.1)
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-22 16:01:33.073533
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.reset()
            pbar.update()

# Generated at 2022-06-22 16:01:38.185496
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tgrange
    from .std import trange
    with tgrange(5, desc='tgrange') as t:
        for x in trange(10, desc='trange'):
            t.reset(2)
            t.reset(3)

# Generated at 2022-06-22 16:01:47.899639
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn().render(10) == "10 B/s"
    RateColumn(unit="B/fps").render(10) == "10 B/fps"
    RateColumn(unit="").render(10) == "10 /s"
    RateColumn(unit_scale=True).render(10) == "10 B/s"
    RateColumn(unit="B/fps", unit_scale=True).render(10) == "10 B/fps"
    RateColumn(unit="", unit_scale=True).render(10) == "10 /s"
    RateColumn(unit_divisor=1024).render(10) == "9.8 KiB/s"
    RateColumn(unit="B/fps", unit_scale=True, unit_divisor=1024).render(10) == "9.8 KiB/fps"
    RateColumn

# Generated at 2022-06-22 16:01:54.277416
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm
    pbar = tqdm()
    pbar.total = 1024
    pbar.update(512)
    
    fc = FractionColumn()
    assert fc.render(pbar) == Text('0.5/2.0 K', style='progress.download')


# Generated at 2022-06-22 16:01:56.758573
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn(unit="GB", unit_scale=True, unit_divisor=1000)
    assert rc.render(rc) == Text("? GB/s", style="progress.data.speed")

# Generated at 2022-06-22 16:02:02.055218
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from time import sleep
    tq = tqdm_rich(range(10), desc='task')
    for i in tq:
        sleep(0.1)
        tq.reset()
        sleep(0.1)
    tq.close()

# Generated at 2022-06-22 16:02:08.906609
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tests_tqdm import pretest_posttest
    @pretest_posttest
    def _main():
        from random import randint
        from time import sleep

        for i in tqdm_rich(range(10), total=10, desc='initialization phase'):
            sleep(0.2)
        sleep(0.2)
        for i in tqdm_rich(range(10), total=10, desc='main phase #1'):
            sleep(0.3)
        sleep(0.2)
        for i in tqdm_rich(range(10), total=10, desc='main phase #2'):
            sleep(0.4)
        sleep(0.2)

# Generated at 2022-06-22 16:02:42.867945
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.text import Text
    from rich.style import Style
    from unittest import TestCase

    class TestRateColumn(TestCase):
        def test_default_RateColumn(self):
            progress = Progress()
            task = progress.add_task("test", total=100)
            task.update(completed=10)
            column = RateColumn(unit="KB")
            result = Text("1,000.0 KB/s", style="progress.data.speed")
            self.assertEqual(column.render(task)._text, result._text)
            self.assertEqual(column.render(task)._style, result._style)
            progress.__exit__(None, None, None)
        def test_unit_divisor_RateColumn(self):
            progress = Progress()

# Generated at 2022-06-22 16:03:32.656638
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class dummy_task:
        completed, total = 2, 4
    column = FractionColumn()
    assert column.render(dummy_task) == Text(u'0.5/2.0 ', style='progress.download')



# Generated at 2022-06-22 16:03:35.135887
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    with tqdm_rich(total=100, file=sys.stdout) as pbar:
        for i in range(100):
            pbar.update()