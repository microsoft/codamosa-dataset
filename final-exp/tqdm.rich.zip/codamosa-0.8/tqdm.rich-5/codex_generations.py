

# Generated at 2022-06-22 15:53:44.573860
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = ProgressColumn()
    task.total = 5000
    task.completed = 4999
    task_str = FractionColumn()
    expected = "4.9/5.0 "
    actual = task_str.render(task)
    assert actual == expected

# Generated at 2022-06-22 15:53:48.092443
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """reset tqdm_rich"""
    with tqdm_rich(total=100) as pbar:
        for i in range(10):
            pbar.reset(total=1000)
            for j in range(100):
                pbar.update()
                pbar.reset(total=i + j)

# Generated at 2022-06-22 15:53:53.155231
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm(total=100)
    task.update(50)
    task.n = 50
    task.total = 100
    rate_column = RateColumn(unit_scale=False, unit_divisor=1000)
    result = rate_column.render(task)
    assert result.text == '50 b/s'

# Generated at 2022-06-22 15:53:58.350738
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    from rich.progress import ProgressColumn
    for n in trange(3, desc='Rich Progress'):
        assert len(ProgressColumn.singleton) == 1
        sys.stdout.flush()
        assert 'Rich Progress' == ProgressColumn.singleton.tasks[0].description
    assert len(ProgressColumn.singleton) == 0

# Generated at 2022-06-22 15:54:01.663785
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    # Simple test
    with tqdm(total=100) as t:
        for i in range(100):
            t.update()

# Generated at 2022-06-22 15:54:05.039752
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
	task = {'completed': '1', 'total': '10'}
	assert FractionColumn().render(task) == Text('0.1/1.0 ')


# Generated at 2022-06-22 15:54:07.593824
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as t:
        t.clear()


# Generated at 2022-06-22 15:54:10.777828
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [None, 5]:
        t = tqdm_rich(total=total)
        t.refresh()
        t.reset(total=total)
        t.refresh()
        t.update()
        del(t)

# Generated at 2022-06-22 15:54:12.703150
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm([1], ascii=True):
        pass

# Generated at 2022-06-22 15:54:20.185922
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    expected_rate_column_str = '10.0 K/s'
    rate_column = RateColumn(unit='', unit_scale=True, unit_divisor=1000)
    rate_column_str = rate_column.render(task=None)
    assert rate_column_str == expected_rate_column_str

if __name__ == '__main__':
    test_RateColumn_render()

# Generated at 2022-06-22 15:54:32.011935
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import rich.progress
    progress = rich.progress.Progress()
    rich.progress.install(progress)
    class TqdmRich(tqdm_rich):
        def __init__(self, *args, **kwargs):
            super(TqdmRich, self).__init__(*args, **kwargs)

        def clear(self):
            self.clear_called = True

        def display(self):
            self.display_called = True

    tr1 = TqdmRich(10, desc="Display 1")
    tr1.display()
    assert tr1.display_called
    tr1.close()
    tr2 = TqdmRich(10, desc="Display 2")
    tr2.display()
    assert tr2.display_called
    tr2.close()

# Generated at 2022-06-22 15:54:41.650255
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    assert r.render(None) == Text('? /s', style='progress.data.speed')
    r = RateColumn(unit='B')
    assert r.render(None) == Text('? B/s', style='progress.data.speed')
    r = RateColumn(unit_scale=False, unit_divisor=1000)
    assert r.render(None) == Text('? /s', style='progress.data.speed')
    r = RateColumn(unit_scale=True, unit_divisor=1000)
    assert r.render(None) == Text('? /s', style='progress.data.speed')

# Generated at 2022-06-22 15:54:46.557142
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        import rich
    except ImportError:
        return

    with tqdm_rich(range(3), desc="test", disable=False) as t:
        t.update(1)
        t.update(3)
        t.update(2)
        t.update(1)
        assert t.n == 7, "t.n is not '7'."
    assert t.disable is False, "t.disable is not 'False'."

# Generated at 2022-06-22 15:54:57.490355
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Task(completed=12345, total=25678)) == "1.2/2.6 K"
    assert FractionColumn().render(Task(completed=123456, total=25678)) == "123.5/2.6 K"
    assert FractionColumn().render(Task(completed=1234567890, total=2567890)) == "12.3/2.6 M"
    assert FractionColumn().render(Task(completed=1234567890, total=2567890)) == "12.3/2.6 M"
    assert FractionColumn().render(Task(completed=1234567890, total=2.56789e10)) == "12.3/2.6 G"

# Generated at 2022-06-22 15:55:09.854530
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.markdown import Markdown
    from rich import print
    from rich.text import Text
    from rich.box import BOX_BORDER
    from rich.panel import Panel

    class RichMock(object):
        def __init__(self, width_to_left, width_to_right, count, color=None,
                     console=None):
            self.width_to_left = width_to_left
            self.width_to_right = width_to_right
            self.console = console

# Generated at 2022-06-22 15:55:12.579220
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in trange(1, desc="1", total=1): pass
    for _ in trange(1, desc="2", total=1): pass

# Generated at 2022-06-22 15:55:25.043808
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Test class "tqdm_rich" constructor
    """
    import time
    import sys
    import os
    import tempfile

    def _test_tqdm_rich(**kwargs):
        # Test that running with tqdm_rich(*args, **kwargs)
        # "behaves" the same as running with tqdm(*args, **kwargs)
        kwargs["miniters"] = 1
        kwargs['smoothing'] = 0 if 'smoothing' not in kwargs else kwargs['smoothing']
        kwargs['disable'] = False if 'disable' not in kwargs else kwargs['disable']

# Generated at 2022-06-22 15:55:27.993840
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=100, smoothing=0) as pbar:
        for i in range(len(pbar)):
            pbar.display()

# Generated at 2022-06-22 15:55:33.363131
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit_scale=True).render(Progress).text == "0.0 B/s"
    assert RateColumn(unit_scale=True).render(Progress(100)).text == "100.0 B/s"
    assert RateColumn(unit_scale=True).render(Progress(1024)).text == "1.0 KB/s"


# Generated at 2022-06-22 15:55:35.022066
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1) as n:
        n.clear()

# Generated at 2022-06-22 15:55:50.093789
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm_gui
    first_total = 10
    second_total = 5
    iteration_count = 100
    inner_iterator = tqdm_rich(total=first_total, leave=True)
    outer_iterator = tqdm_gui(iteration_count, leave=True)
    for _ in outer_iterator:
        for _ in inner_iterator:
            pass
        inner_iterator.reset(total=second_total)
    outer_iterator.close()
    inner_iterator.close()

# Generated at 2022-06-22 15:56:00.219362
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import TestCase, main
    from time import sleep
    from rich.console import Console

    class ConsoleTestCase(TestCase):
        def setUp(self):
            self.console = Console()

    class TestProgress(ConsoleTestCase):
        def test_progress(self):
            with self.console.progress() as progress:
                self.task_id = progress.add_task("Fetching data", start=True)
                for i in range(10):
                    sleep(0.1)
                    progress.update(self.task_id, completed=i + 1)
                self.assertEqual(progress.status, "done")


# Generated at 2022-06-22 15:56:01.878816
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == '? /s'

# Generated at 2022-06-22 15:56:08.363719
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    tgr = trrange(10, desc='Downloading', ascii=True, unit='B',
                  unit_scale=True, unit_divisor=1024)
    for i in tgr:
        tgr.set_postfix(test=i)
        tgr.set_postfix_str(test=i)
        sleep(0.1)
    tgr.close()
    assert tgr.n == 10

# Generated at 2022-06-22 15:56:15.210114
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Set up the tasks, add descriptions and display."""
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )

    with Progress(*progress, transient=True) as progress:
        task1 = progress.add_task("task1", total=10)
        for i in trange(10):
            progress.update(task1, completed=i)
            time.sleep(0.1)
        task2 = progress.add_task("task2")

# Generated at 2022-06-22 15:56:18.455568
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    prog = tqdm_rich(range(10))
    prog.display()
    prog.clear()
    prog.display()
    prog.close()

# Generated at 2022-06-22 15:56:20.384633
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=1)
    t.display()
    t.close()

# Generated at 2022-06-22 15:56:23.457148
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10) as t:
        t.write("hello world!")
    t.reset(2)
    with trange(2) as t:
        t.write("hello world!")

# Generated at 2022-06-22 15:56:24.695085
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    pass

# Generated at 2022-06-22 15:56:28.732140
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    x = tqdm(range(5))
    x.clear()
    x.close()

# Generated at 2022-06-22 15:56:43.320207
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-22 15:56:49.036088
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Reset method of class tqdm_rich should work.
    """
    from tqdm.auto import trange
    import time
    total = 10
    tr = trange(total)

    for i in tr:
        tr.reset(total=total)
        time.sleep(0.01)
        if i == 5:
            total = 7
            tr.update(0)

# Generated at 2022-06-22 15:56:52.563342
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Test for `tqdm.rich.tqdm_rich`.
    """
    for i in trange(10):
        pass


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-22 15:56:54.704985
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        for i in t:
            assert (t.n <= t.total)
            t.clear()



# Generated at 2022-06-22 15:56:56.644470
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for _ in tqdm_rich(range(4)):
        pass
    for _ in trange(4):
        pass

# Generated at 2022-06-22 15:56:57.997271
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    t = tqdm_rich(total=10)
    t.clear()

# Generated at 2022-06-22 15:57:03.051870
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    try:
        from rich.console import Console
        Console(width=100, force_terminal=True)
        x = tqdm_rich(list(range(10)))
        # clear should not crash
        x.clear()
    except ImportError:
        # Do nothing
        pass

# Generated at 2022-06-22 15:57:13.753737
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    task_1 = Progress(0, 1, description="")
    task_2 = Progress(0, 1, description="")
    task_3 = Progress(0, 1, description="")

    speed = 1000000000
    task_1.speed = speed
    task_2.speed = speed / 1000
    task_3.speed = speed / 1000000

    assert column.render(task_1) == Text(f"1.0 G/s", style="progress.data.speed")
    assert column.render(task_2) == Text(f"1.0 M/s", style="progress.data.speed")
    assert column.render(task_3) == Text(f"1.0 K/s", style="progress.data.speed")

# Generated at 2022-06-22 15:57:17.743094
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    t = tqdm_rich(total=100)
    assert t.disable is False
    assert t.gui is True
    assert t._prog.transient is True
    assert t._prog.border_left is None
    assert t._prog.border_right is None

# Generated at 2022-06-22 15:57:21.394442
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn(unit_scale = True)
    task = std_tqdm(range(10), total=1000)
    text = column.render(task)
    assert text.text == '0.0/1.0 K'


# Generated at 2022-06-22 15:57:50.242837
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    return

# Generated at 2022-06-22 15:58:00.101392
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from unittest import TestCase, main
    from rich import Progress
    from .utils import StringIO

    def check(x, y):
        with StringIO() as f:
            p = Progress()
            p.logger = f
            p.add_task(x.speed)
            # print(f.getvalue(), end='')
        assert (f.getvalue() == y)

    class Tests(TestCase):
        """
        For example:
            >>> t = trange(5)
            >>> t.rate_limiter.rate.check(t.rate_limiter.rate.value)
            >>> t.update()
            >>> t.rate_limiter.rate.check(t.rate_limiter.rate.value)

        """

# Generated at 2022-06-22 15:58:12.377064
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Function for unit testing of the display method of class tqdm_rich.
    """
    tqdm_rich_display_instance = tqdm_rich(["one", "two", "three", "four",
                                            "five", "six", "seven", "eight"],
                                           desc="testing display method")

    tqdm_rich_display_instance.reset(total=8)
    assert tqdm_rich_display_instance.n == 0
    assert tqdm_rich_display_instance.total == 8
    assert tqdm_rich_display_instance.pbar == [
        "\n",
        "testing display method:   0%|          | 0/8 [00:00<?, ?it/s]",
        "\n",
    ]


# Generated at 2022-06-22 15:58:18.236537
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=0, leave=False) as pbar:
        pass
    pbar.reset(total=3)
    for _ in range(3):
        pbar.update()
# noinspection PyUnresolvedReferences
assert pbar.n == 3
# noinspection PyUnresolvedReferences
assert pbar.n == pbar.total

# Generated at 2022-06-22 15:58:30.310739
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test render function of FractionColumn class."""
    class Task:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    task = Task(completed=0.5, total=2.3)
    assert FractionColumn().render(task) == Text('0.5/2.3', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.5/2.3', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text('0.5/2.3 K', style='progress.download')

# Generated at 2022-06-22 15:58:33.274037
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich import progress
        progress.install()
    except ImportError:
        raise unittest.SkipTest("rich not installed")


# Unit tests for compatibility with rich.progress

# Generated at 2022-06-22 15:58:39.563792
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = 128750
    task.completed = 100
    task.total = 120
    unit_divisor = 1000
    unit_scale = True
    unit = "B"
    rateColumn = RateColumn(unit, unit_scale, unit_divisor)
    RateColumn.render(rateColumn, task)
    assert RateColumn.render(rateColumn, task) == Text("128.8 KB/s", style = "progress.data.speed")

# Generated at 2022-06-22 15:58:50.826830
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Text
    import re
    pbar = tqdm_rich(total=100, desc='test', postfix='total:100')
    pbar.update(50)
    assert pbar._prog.tasks[pbar._task_id].completed == 50

    pbar.reset(total=50, desc='new')
    total_txt = str(Text(content='total:50', style="progress.postfix"))
    assert pbar._prog.tasks[pbar._task_id].completed == 0
    assert pbar._prog.tasks[pbar._task_id].total == 50
    assert pbar._prog.tasks[pbar._task_id].description == 'new'
    assert re.findall(total_txt, str(pbar._prog))

# Generated at 2022-06-22 15:58:59.545121
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test unit for class FractionColumn."""
    fc = FractionColumn()
    assert fc.render({'completed': 0, 'total': 1}) == Text('0.0/1.0', style='progress.download')
    assert fc.render({'completed': 1234, 'total': 2345}) == Text('1.2/2.3', style='progress.download')
    assert fc.render({'completed': 12345, 'total': 23456}) == Text('12.3/23.5', style='progress.download')
    assert fc.render({'completed': 1234567, 'total': 2345678}) == Text('1.2/2.3 M', style='progress.download')
    assert fc.render({'completed': 12345678, 'total': 23456789}) == Text

# Generated at 2022-06-22 15:59:01.067297
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    x = tqdm_rich(4)
    x.clear()

# Generated at 2022-06-22 16:00:04.076366
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test for method render of class RateColumn."""
    column_obj = RateColumn()
    task_obj = {'speed': '1'}
    assert column_obj.render(task_obj) == '1 B/s'
    assert type(column_obj.render(task_obj)) == Text
    assert column_obj.render(task_obj).value == '1 B/s'

# Generated at 2022-06-22 16:00:14.685058
# Unit test for method render of class FractionColumn

# Generated at 2022-06-22 16:00:26.876232
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    task = std_tqdm(total=10, smoothing=0)
    task.update(1)
    task.update(2)
    task.update(3)
    task.update(4)
    assert(rate_column.render(task) == "10.00  /s")
    rate_column = RateColumn(unit="B")
    task.refresh()
    assert(rate_column.render(task) == "10.00 B/s")
    rate_column = RateColumn(unit_scale=True)
    task.refresh()
    assert(rate_column.render(task) == "10.00  /s")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    task.refresh()

# Generated at 2022-06-22 16:00:30.352777
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # TODO: assert this function doesn't throw an error
    with tqdm_rich(total=2, desc="testing") as progressbar:
        progressbar.update()
        progressbar.update()

# Generated at 2022-06-22 16:00:34.769475
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich.reset()"""
    iterable = _range(100)
    progress = tqdm_rich(iterable)
    progress.reset(total=50)
    progress.reset()  # reset without total, should not change value of 'total'

# Generated at 2022-06-22 16:00:43.257854
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.console import Console
    from rich.panel import Panel
    console = Console()

    def _test_RateColumn_render(task_speed, unit, unit_scale, unit_divisor, output):
        console.print(Panel(RateColumn(unit=unit,
                                       unit_scale=unit_scale,
                                       unit_divisor=unit_divisor)
                           .render(task_speed = task_speed)))
        assert str(console) == output

    class _Task:
        def __init__(self):
            self.speed = None

    class _Task1:
        def __init__(self):
            self.speed = 10

    class _Task2:
        def __init__(self):
            self.speed = 10000


# Generated at 2022-06-22 16:00:48.241876
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.console import Console
    console = Console()
    progress = Progress(FractionColumn())
    progress.__enter__()
    task = progress.add_task("99/100")
    progress.update(task, 99, 100)
    console.print(progress, "99/100")


# Generated at 2022-06-22 16:00:50.910924
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-22 16:00:53.329054
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.update(1)

# Generated at 2022-06-22 16:01:03.373741
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import _has_module
    if not _has_module('rich'):
        return
    import tempfile
    try:  # pragma: no cover
        file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    except TypeError:
        file = tempfile.NamedTemporaryFile(mode='w')
    # file.write('012345678901234567890123456789')
    file.close()
    with open(file.name) as f:
        with tqdm_rich(total=30, desc='Loading... ', unit='B', unit_scale=True,
                       disable=True) as pbar:
            for line in f:  # pragma: no cover
                pbar.update(len(line))

# Generated at 2022-06-22 16:03:21.700187
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(range(10), leave=False) as t:
        for _ in t:
            t.clear()

# Generated at 2022-06-22 16:03:24.615723
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm(range(5)):
        pass


if __name__ == '__main__':  # pragma: no cover
    from .main import main
    main(desc='tqdm_rich')

# Generated at 2022-06-22 16:03:29.588638
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys

    try:
        text_trap = io.StringIO()
        sys.stdout = text_trap
        with tqdm(total=10) as t:
            for _ in range(10):
                t.clear()
                t.update()
        sys.stdout.getvalue()
    finally:
        sys.stdout = sys.__stdout__
    assert True

# Generated at 2022-06-22 16:03:38.688433
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from tqdm.rich import Progress, ProgressColumn, trange, tqdm
    from tqdm._utils import StatusPrinter

    class FractionColumn(ProgressColumn):
        def render(self, task):
            return "%.2f/%.2f" % (task.completed, task.total)

    pbar = tqdm(total=100, unit_scale=False,
                bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}")
    p = Progress("{task.completed}/{task.total} [{bar}] {percentage:.0f}%")
    p.__enter__()
    task_id = p.add_task("Test", columns=[FractionColumn()])
    sp = StatusPrinter(pbar).__enter__()
   