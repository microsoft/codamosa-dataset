

# Generated at 2022-06-22 15:53:50.058865
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # test with value of different unit
    rate_column1 = RateColumn()
    rate_column2 = RateColumn(unit="B")
    rate_column3 = RateColumn(unit="B", unit_scale=True)

    # test with value of different unit_scale and unit_divisor
    rate_column4 = RateColumn(unit_scale=True, unit_divisor=1024)
    rate_column5 = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)

    # test with negative value
    rate_column6 = RateColumn()
    rate_column7 = RateColumn(unit="B")
    rate_column8 = RateColumn(unit="B", unit_scale=True)
    rate_column9 = RateColumn(unit_scale=True, unit_divisor=1024)
    rate

# Generated at 2022-06-22 15:53:54.174269
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test for method display of class tqdm_rich."""
    try:
        from rich.progress import TaskID
    except ImportError:
        return
    t = tqdm_rich(range(10))
    assert isinstance(t._task_id, TaskID)

# Generated at 2022-06-22 15:54:02.994869
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.panel import Panel

    progress = Progress()
    progress.__enter__()
    task = progress.add_task("title")
    task.completed = 1
    task.total = 2

    result = FractionColumn().render(task)
    
    expected = Panel("0.5/2.0", style="progress")
    assert result.__rich_measure__() == expected.__rich_measure__()
    assert result.__rich_console__() == expected.__rich_console__()

# Generated at 2022-06-22 15:54:06.250836
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as pbar:
        for i in range(1, 4):
            pbar.reset(total=15)
            pbar.update(i)


# Generated at 2022-06-22 15:54:10.563491
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test that the clear() method doesn't raise exception.
    """
    from .gui import tqdm_notebook
    for cls in (tqdm_rich, tqdm_notebook):
        with cls(total=4) as pbar:
            pbar.clear()

# Generated at 2022-06-22 15:54:14.209307
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    """Test reset method of class tqdm_rich."""
    assert tqdm_rich(range(5)).reset(10).total == 10

# Generated at 2022-06-22 15:54:20.569534
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import rich.progress
    progress = Progress()
    progress.add_task("task")
    progress._update(0, description="task", completed=1, total=2)
    progress.update()
    assert progress.console.fetch_lines()[-1] == "[progress.description]task [progress.percentage] 50% 0.5/2"

# Generated at 2022-06-22 15:54:27.121129
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn("bytes", True, 1024).render(std_tqdm(10, desc="1")) == Text("1.0 Kbytes/s", style="progress.data.speed")
    assert RateColumn("bytes", False, 1000).render(std_tqdm(10, desc="1")) == Text("1.0 bytes/s", style="progress.data.speed")



# Generated at 2022-06-22 15:54:30.773836
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=10, dynamic_ncols=True) as pbar:
        for i in range(10):
            pbar.display(i+1, 10, 1)
            assert pbar.n == i+1


# Generated at 2022-06-22 15:54:35.481983
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import random
    import pandas as pd
    task = {}
    task["completed"] = random.random()
    task["total"] = random.random()
    t1 = FractionColumn.render(FractionColumn(), task)
    t2 = pd.DataFrame(data={
        'completed': task['completed'],
        'total': task['total']
    })
    t2 = t2.applymap(lambda s: "{:.0f}/{:.0f}".format(s['completed'], s['total']))
    t2 = t2.to_string(index=False, header=False)
    assert (t1 == t2)

# Generated at 2022-06-22 15:54:47.911866
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time

    # Test tqdm_rich
    t = tqdm(total=100)
    n = 0
    while n < 100:
        n += 1
        t.update(n)
        time.sleep(0.5)
    t.close()

    # Test tqdm_rich.reset()
    t = tqdm(total=100)
    n = 0
    while n < 100:
        n += 1
        t.update(n)
        time.sleep(0.5)
    t.reset(total=100)
    n = 0
    while n < 100:
        n += 1
        t.update(n)
        time.sleep(0.5)
    t.close()

    # Test tqdm_rich.reset() without parameter

# Generated at 2022-06-22 15:54:53.362589
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit tests for method reset of class tqdm_rich"""
    with tqdm_rich(total=10) as prog:
        assert prog.total == 10
        prog.reset(total=20)
        assert prog.total == 20
        prog.reset()
        assert prog.total == 20

# Generated at 2022-06-22 15:54:55.058500
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for i in tqdm_rich(range(100), leave=True):
        pass

# Generated at 2022-06-22 15:55:02.389431
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.columns import Columns
    from rich.progress import Progress
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=200),
    )
    progress.__enter__()
    task_id = progress.add_task("")
    with Columns(2, fill=True) as columns:
        columns.write("This is test for method render of class FractionColumn.")
    progress.update(task_id, completed=1024, total=2048)
    progress.update(task_id, completed=2048, total=2048)
    progress.update(task_id, completed=2048, total=3000)

# Generated at 2022-06-22 15:55:08.997701
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        import rich.progress
        assert issubclass(tqdm_rich, std_tqdm)
        assert tqdm_rich(disable=True) is not None
        assert tqdm_rich(0) is not None
    except ImportError:
        pass


if __name__ == '__main__':
    from .tests import test_tqdm_rich
    test_tqdm_rich()

# Generated at 2022-06-22 15:55:10.803712
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    task = MockTask()
    task.speed = 500e3
    assert rate_column.render(task) == "[progress.data.speed]500 K/s"


# Generated at 2022-06-22 15:55:15.519134
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    for reset_value in [-100, 0, 0.5, None, 100, 1e3]:
        with tqdm(total=0, leave=False) as t:
            t.reset(total=reset_value)
            assert t.total == reset_value

# Generated at 2022-06-22 15:55:20.493483
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich import traceback
    from rich.progress import Task

    task = Task(0, 100)
    column = FractionColumn()
    try:
        assert column.render(task) == '0.0/100.0 '
    except:
        traceback.print_exc()
        raise


# Generated at 2022-06-22 15:55:24.992100
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from tqdm import _tqdm_gui

    t = tqdm_rich(_range(100), leave=False, disable=False)
    assert isinstance(t, _tqdm_gui)
    t.close()

# Generated at 2022-06-22 15:55:26.543284
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.clear()

# Generated at 2022-06-22 15:55:41.258039
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm()
    task.speed = None
    assert str(RateColumn().render(task)) == "? /s"
    task.speed = 100
    assert str(RateColumn().render(task)) == "100 /s"
    assert str(
        RateColumn(
            unit="B",
            unit_scale=True,
            unit_divisor=1024).render(task)) == "97.66KB/s"
    assert str(
        RateColumn(
            unit="B",
            unit_scale=False,
            unit_divisor=1000).render(task)) == "100.00B/s"
    assert str(
        RateColumn(
            unit="B").render(task)) == "100.00B/s"


# Generated at 2022-06-22 15:55:48.084697
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_col = RateColumn()
    percent_col = FractionColumn()
    task = {'name': 'example', 'completed': 1, 'total': 2, 'speed': 2}
    assert rate_col.render(task) == Text("2.0 /s", style="progress.data.speed")
    assert percent_col.render(task) == Text("0.5/2 ", style="progress.download")

# Generated at 2022-06-22 15:55:58.822718
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    #  no desc, leave=False, disable=False
    progress = tqdm(total=10)
    progress.reset(total=10)
    assert progress.n == 0 and progress.total == 10 and progress.dynamic_messages == {}
    assert progress._prog.completed == 0 and progress._prog.total == 10 and progress._prog.get_task(progress._task_id).completed == 0 and progress._prog.get_task(progress._task_id).total == 10
    progress.reset()
    assert progress.n == 0 and progress.total == 10 and progress.dynamic_messages == {}
    assert progress._prog.completed == 0 and progress._prog.total == 10 and progress._prog.get_task(progress._task_id).completed == 0 and progress._prog.get_task

# Generated at 2022-06-22 15:56:03.729935
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task = Progress()
    test_task.completed = 2000
    test_task.total = 1000000
    p = FractionColumn()
    result = p.render(test_task)
    expected = Text("2.0/1000.0 ", style="progress.download")
    assert result == expected


# Generated at 2022-06-22 15:56:12.359872
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import mock
    import sys

    sys.modules['rich.progress'] = mock.Mock()
    from .rich import tqdm
    mock.patch('rich.progress.Progress.update').start()
    mock.patch('rich.progress.Progress.add_task').start()
    mock.patch('rich.progress.Progress.__enter__').start()
    mock.patch('rich.progress.Progress.__exit__').start()
    mock.patch('rich.progress.Progress.reset').start()
    mock.patch('tqdm.std.tqdm.tqdm._decr_instances').start()
    t = tqdm('test')
    t.n = 1
    t.display()
    t.close()

# Generated at 2022-06-22 15:56:15.869383
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm_rich(total=1, mininterval=0.001) as t:
        t.update()

# Generated at 2022-06-22 15:56:25.839405
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=10, desc='test')
    assert t.total == 10
    t.update(2)
    assert t.n == 2
    assert t.total == 10
    pbar = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
    )
    pbar.start()
    t._prog = pbar
    t._task_id = t._prog.add_task(t.desc or "", **t.format_dict)
    t.reset(total=20)
    assert t.total == 20
    assert t.n == 0
    t.update(2)
    assert t.n == 2
    assert t.total

# Generated at 2022-06-22 15:56:35.089574
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn(unit="B")
    text = r.render(Progress(total=0))
    assert text.text == "? B/s"
    text = r.render(Progress(total=1))
    assert text.text == "0.0 B/s"
    text = r.render(Progress(total=1, completed=1, speed=1))
    assert text.text == "1.0 B/s"
    text = r.render(Progress(total=2, completed=1, speed=1))
    assert text.text == "0.5 B/s"



# Generated at 2022-06-22 15:56:37.107907
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm(range(1000))
    for _ in t:
        pass
    print("")

# Generated at 2022-06-22 15:56:49.390307
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    from inspect import getfullargspec

    for func in [tqdm_rich, trange]:
        assert func.__doc__ == tqdm_rich.__doc__

        sig = getfullargspec(tqdm_rich.__init__)
        del sig.args[0]  # self
        assert getfullargspec(func.__init__) == sig

        assert getfullargspec(func.close) == getfullargspec(tqdm.close)
        assert getfullargspec(func.clear) == getfullargspec(tqdm.clear)
        assert getfullargspec(func.display) == getfullargspec(tqdm.display)
        assert getfullargspec(func.reset) == getfullargspec(tqdm_rich.reset)


# Generated at 2022-06-22 15:56:59.997512
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch
    t = tqdm_rich(total=100)
    t.display()
    with patch('tqdm.rich.tqdm_rich.ProgressColumn.render', return_value=Text('abc')) as mock:
        t.display()
        mock.assert_called_once()

# Generated at 2022-06-22 15:57:12.037063
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    with patch('time.time', return_value=1500000000):
        with tqdm(total=10) as pb:
            assert pb.n == 0
            assert pb.last_print_n == 0
            assert pb.start_t == 1500000000
            assert pb.last_print_t == 0
            assert pb.dynamic_ncols
            assert pb.leave
            assert pb.desc == None
            assert pb.postfix == {}
            assert pb.miniters == 1
            assert pb.mininterval == 0
            assert pb.maxinterval == 10
            assert pb.file == None

# Generated at 2022-06-22 15:57:17.330043
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from os import devnull
    with open(devnull, 'w') as fd:
        # Set position to 100 to check that the bar is correctly reset to 0
        pbar = tqdm_rich(total=10, file=fd, position=100)
        pbar.update()
        pbar.reset(total=20)
        pbar.update()
        pbar.close()

# Generated at 2022-06-22 15:57:26.449362
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from random import randrange, randint
    from time import sleep
    from .utils import SimpleProgress

    # Setting b=None/int and desc=None/str
    for b, desc in zip((None, 2), (None, "")):
        progress = tqdm_rich(range(b), desc=desc)
        assert progress.format_dict['total'] == b
        assert progress.format_dict['desc'] == desc
        progress.close()

    # Setting format and bar_format
    format_string = "{time_spent} {n_fmt}/{total_fmt} [{rate_noinv_fmt}]"
    progress = tqdm_rich(range(10), format_string, unit='B', ascii=True)
    assert progress.format_dict['format'] == format_string
    assert progress

# Generated at 2022-06-22 15:57:38.906570
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for `tqdm.rich.tqdm.reset()` method.
    """
    from .tests import format_dict
    from .std import tqdm as s_tqdm


# Generated at 2022-06-22 15:57:50.537166
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import progress_method
    from contextlib import contextmanager
    from unittest.mock import Mock
    assert progress_method('reset') is not None

    @contextmanager
    def timer_mock(*args):
        yield Mock()

    progress_method('reset', timer_mock)
    with trange(3, desc='Rich', total=5) as t:
        for i in t:
            # test that resetting the loop can be done,
            # and is functional, with a mock timer
            if i == 1:
                t.reset(total=10)
            sleep(0.01)
    t.close()

# Generated at 2022-06-22 15:57:54.404037
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as pbar:
        for i in range(5):
            pbar.update()
        pbar.reset(total=5)
        for i in range(5):
            pbar.update()

# Generated at 2022-06-22 15:58:05.162721
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        import shutil
        columns, lines, _ = shutil.get_terminal_size()
    except (AttributeError, TypeError, ImportError):
        columns = 80
        lines = 24

    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage] {task.percentage:>4.1f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"
    )


# Generated at 2022-06-22 15:58:14.712160
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_instance = tqdm_rich([1, 2, 3, 4, 5], desc='test')
    progress_instance.clear(nolock=True)
    progress_instance.total = 5
    progress_instance.update(n=1, desc=None, lock_args=(True,))
    progress_instance.update(n=4, desc=None, lock_args=(True,))
    rate_column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(progress_instance) == Text("41.0 /s", style="progress.data.speed")



# Generated at 2022-06-22 15:58:23.071239
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .gui import tgrange
    from .std import tqdm
    from .utils import format_sizeof
    import time

    kwargs = dict(total=5, desc='Test')
    # Setup
    tqdm.set_lock(False)
    tqdm.reset(**kwargs)
    tqdm.clear()

    # Test 1
    tqdm.display(**kwargs)
    tqdm.set_lock(True)

    # Test 2
    kwargs['leave'] = True
    tqdm_rich.set_lock(False)
    tqdm_rich.reset(**kwargs)
    tqdm_rich.clear()
    tqdm_rich.display(**kwargs)

# Generated at 2022-06-22 15:58:42.508566
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Check no error for all possible units."""
    for unit, _ in filesize.units.items():
        RateColumn(unit=unit).render(None)

# Generated at 2022-06-22 15:58:50.403266
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import datetime
    task = tqdm([1], leave=False, unit_scale=True)
    total = task.total
    task.__enter__()
    task.update(total - 1)
    task.last_print_t = datetime.datetime.now() - datetime.timedelta(seconds=1)
    task.update(1)
    task.__exit__(None, None, None)
    rate = RateColumn(unit="B", unit_scale=True)
    assert rate.render(task) == Text(f"1.00 KIB/s", style="progress.data.speed")

# Generated at 2022-06-22 15:58:53.180491
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from io import BytesIO
    from math import inf
    from time import sleep
    from tqdm.auto import tnrange
    from unittest import TestCase, main

    from .std import tqdm as std_tqdm
    from .std import trange as std_tran

# Generated at 2022-06-22 15:58:56.037021
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    def test_func():
        test_var = 1
        with trange(10) as t:
            for i in range(10):
                test_var += i
                t.update()
        return test_var
    test_func()
    return True

# Generated at 2022-06-22 15:59:06.288248
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    """Unit test for method reset of class tqdm_rich."""
    from .std import TqdmKeyError

    def test_error(tqdm_instance, method_name):
        """Tests to ensure errors are thrown."""
        with tqdm_instance as t:
            try:
                getattr(t, method_name)()
            except TqdmKeyError:
                pass
            else:
                assert False

    def test_correct(tqdm_instance, method_name):
        """Tests to ensure warnings are not thrown."""
        with tqdm_instance as t:
            try:
                getattr(t, method_name)()
            except TqdmKeyError:
                assert False


# Generated at 2022-06-22 15:59:14.189292
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Tests method FractionColumn.render"""
    column = FractionColumn()
    task = Progress(title="title", description="description", total=100)
    task.completed = 50
    text = column.render(task)
    assert text == Text("0.5/1.0 ", style="progress.download")
    task.total = 1000
    task.completed = 500
    text = column.render(task)
    assert text == Text("0.5/1.0 ", style="progress.download")
    task.total = 10000
    task.completed = 5000
    text = column.render(task)
    assert text == Text("0.5/10.0 ", style="progress.download")
    task.total = 100000
    task.completed = 50000
    text = column.render(task)
    assert text

# Generated at 2022-06-22 15:59:17.136798
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from sys import stderr
    _tqdm = tqdm_rich(file=stderr, total=10)
    _tqdm.reset(total=20)
    assert _tqdm.max_iter == 20

# Generated at 2022-06-22 15:59:21.403047
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn("B", unit_scale = True, unit_divisor = 1024)
    assert(rate_column.render({'speed' : 1024}) == Text("1.0 K/s", style = "progress.data.speed"))

# Generated at 2022-06-22 15:59:32.170129
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B")
    for rate in range(0, 1001, 10):
        # Check for rate < 1 Kibibyte
        task = Progress.Task(rate=rate)
        assert rate_column.render(task).text == f"{rate}B/s"
        # Check for rate > 1 Kibibyte
        task = Progress.Task(rate=rate*1000)
        assert rate_column.render(task).text == f"{rate:,.0f}KiB/s"
        # Check for rate > 1 Mebibyte
        task = Progress.Task(rate=rate*1000*1000)
        assert rate_column.render(task).text == f"{rate:,.0f}MiB/s"
        # Check for rate > 1 Gibibyte
        task

# Generated at 2022-06-22 15:59:39.043197
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_instance = FractionColumn()
    task = std_tqdm()
    task.total = 123
    task.completed = 12
    test_instance.render(task)
    assert test_instance.unit_divisor == 1000
    assert test_instance.unit_scale == False

    task.total = 12345
    task.completed = 1234
    test_instance.render(task)
    assert test_instance.unit_divisor == 1000
    assert test_instance.unit_scale == True

# Generated at 2022-06-22 16:00:15.044772
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich reset."""
    # A new progress bar
    a = tqdm_rich(total=90, desc='test_tqdm_rich_reset')
    a.__enter__()
    a.reset(total=100)
    assert a.total == 100
    a.__exit__(None, None, None)

    # A new progress bar
    b = tqdm_rich(total=100, desc='test_tqdm_rich_reset')
    b.__enter__()
    b.reset()
    assert b.total == 0
    b.__exit__(None, None, None)

# Generated at 2022-06-22 16:00:27.508438
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import pytest

    f = FractionColumn()
    task = Progress({'completed': 1, 'total': 2})
    assert f.render(task) == Text('0.5/1.0', style='progress.download')
    task['completed'] = 1024
    assert f.render(task) == Text('1.0/1.0 K', style='progress.download')
    f = FractionColumn(unit_scale=True)
    task['completed'] = 2048
    assert f.render(task) == Text('2.0/1.0 K', style='progress.download')
    f = FractionColumn(unit_scale=True, unit_divisor=1024)
    task['completed'] = 2048
    assert f.render(task) == Text('2.0/1.0 K', style='progress.download')

# Generated at 2022-06-22 16:00:30.264469
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm(total=90) as t:
        t.reset(total=80)
        assert t.total == 80

# Generated at 2022-06-22 16:00:40.592971
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import TASKS, Progress
    for total in [10, 20]:
        for reset in [True, False]:
            t = tqdm(total=total, desc='Test', reset=reset)
            t.update(2)
            assert t._prog.__enter__()[0].completed == 2
            t.reset(total=total)
            assert t._prog.__enter__()[0].completed == 0
            t.reset(total=20)
            assert t._prog.__enter__()[0].completed == 0
    t = tqdm(total=20, desc='Test', reset=True)
    t.update(2)
    t.reset(total=30)
    assert t._prog.__enter__()[0].completed == 0
    assert t._pro

# Generated at 2022-06-22 16:00:52.524750
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.rich.utils import mock_input, mock_output
    from tqdm import ASCII

    # Initialize tqdm
    with mock_input() as stdin, mock_output(process=False) as stdout:  # mock stdin, stdout
        x = tqdm(range(30), dynamic_ncols=True, smoothing=None, ascii=True,
                 bar_format=None, write_double_newline=False)
    if x._prog.is_finished:
        raise RuntimeError("Is finished")
    # Expected output of display
    out = "[{desc}{bar}] {n_fmt}/{total_fmt} [{percentage}%]{postfix}"
    # Check display

# Generated at 2022-06-22 16:01:03.018204
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit tests for method reset of class tqdm_rich
    """
    kwargs = {
        'desc': 'Downloading',
        'unit': 'B',
        'unit_scale': True,
        'unit_divisor': 1024,
        'total': 100
    }

    # tqdm_rich linear
    tqdm_rich_linear = tqdm_rich(**kwargs)

    for i in _range(10):
        tqdm_rich_linear.update()

    tqdm_rich_linear.reset(total=200)

    for i in _range(10):
        tqdm_rich_linear.update()

    assert tqdm_rich_linear.n == 10
    assert tqdm_rich_linear.total == 200

    # tqdm_rich with min

# Generated at 2022-06-22 16:01:08.362141
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test for method render of class RateColumn."""
    # Test the following cases:
    #
    # 1. unit=None, unit_scale=False, unit_divisor=1000;
    # 2. unit='b', unit_scale=False, unit_divisor=1000;
    # 3. unit='b', unit_scale=True, unit_divisor=1000;
    # 4. unit='b', unit_scale=False, unit_divisor=1024;
    # 5. unit='b', unit_scale=True, unit_divisor=1024;

# Generated at 2022-06-22 16:01:11.989716
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    t = tqdm_rich(5, unit_scale=False)
    for i in t:
        if (i==1):
            t.reset(5)
            break

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 16:01:17.654890
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        with tqdm_rich(range(10), desc='test', miniters=0, mininterval=0) as t:
            pass
    except:
        raise
    assert t.disable is False, "Failed to set disable flag."
    assert t._task_id is not None, "Failed to set _task_id."
    assert t._prog is not None, "Failed to set _prog."



# Generated at 2022-06-22 16:01:24.616519
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test RateColumn.render method."""
    import tqdm
    from tqdm.rich.progress import RateColumn

    def iterate(tqdm_obj, task_id, rate_column, unit, unit_scale, unit_divisor):
        total = 100
        for _ in tqdm_obj:
            tqdm_obj.n += 1
            speed = tqdm_obj.n
            rate_column.render(tqdm_obj.tqdm_gui._prog.tasks[task_id])
            if unit_scale:
                unit, suffix = filesize.pick_unit_and_suffix(
                    speed,
                    ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
                    unit_divisor,
                )
           

# Generated at 2022-06-22 16:02:34.188600
# Unit test for method render of class RateColumn

# Generated at 2022-06-22 16:02:39.195783
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep

    for i in tqdm(range(4)):
        # do something
        sleep(0.1)

    # reset tqdm
    tqdm.reset(total=10)
    for i in range(10):
        # do something
        sleep(0.1)
        tqdm.update(1)

# Generated at 2022-06-22 16:02:48.702297
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest.mock import patch
    from .utils import format_dict
    with patch('tqdm.rich.tqdm.trange') as mock:
        t = tqdm_rich(total=10, miniters=0)
        t.reset(total=20)
        mock.assert_called_with(20, miniters=0, **format_dict())
    #
    with patch('tqdm.rich.tqdm.trange') as mock:
        t = tqdm_rich(total=10, miniters=0)
        t.reset(total=20, miniters=10)
        mock.assert_called_with(20, miniters=10, **format_dict())

# Generated at 2022-06-22 16:02:53.090552
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_column=RateColumn(unit="B",unit_scale=True,unit_divisor=1000)
    task={'completed':10,'total':100,'speed':100000}
    s=progress_column.render(task)
    assert str(s)=="100.0 KB/s"


# Generated at 2022-06-22 16:02:57.362119
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    t = tqdm_rich(total=100, progress=None)
    for i in range(100):
        time.sleep(0.1)
        t.update(1)
    t.reset()
    for i in range(50):
        time.sleep(0.1)
        t.update(1)
    t.close()

# Generated at 2022-06-22 16:03:02.092715
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [None, 100, 1000]:
        with tqdm_rich(total=total) as t:
            t.reset(total=total)
            assert t.total == total

# Generated at 2022-06-22 16:03:05.749612
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Unit test for method render of class FractionColumn
    assert FractionColumn().render(5, 10) == (5, 10)
    assert FractionColumn(unit_scale=True).render(5, 10) == ((5 * 1000), (10 * 1000))

# Generated at 2022-06-22 16:03:14.276915
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    with mock.patch.object(tqdm_rich, 'display') as mock_display:
        with mock.patch.object(tqdm_rich, 'n', 10):
            mock_display.return_value = None
            tqdm_rich.reset()
            mock_display.assert_called_once()
            assert tqdm_rich.n == 0


# Generated at 2022-06-22 16:03:17.587207
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    progress = tqdm_rich('test', total=100)
    progress.reset()
    progress.reset(200)
    progress.reset(200)
    progress.reset(100)


# Generated at 2022-06-22 16:03:22.721516
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Fail if display is not called for a valid, non-disabled tqdm_rich
    with tqdm_rich(10) as t:
        assert hasattr(t, '_prog'), \
            "'_prog' attribute should exist for a valid, non-disabled tqdm_rich"