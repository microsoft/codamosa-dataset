

# Generated at 2022-06-22 15:53:38.394981
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    from unittest import TestCase
    from unittest.mock import MagicMock

    class TaskMock(object):
        """Mock simple rich.task."""
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
            self.speed = None

    class Test(TestCase):
        """Unit test for class FractionColumn."""
        def test_render(self):
            """Display completed/total in appropriate filesize unit."""
            task = TaskMock(12345, 34567)
            col = FractionColumn()
            col.render(task)

            task = TaskMock(12345678, 34567890)
            col = FractionColumn(unit_scale=True)
            col.render

# Generated at 2022-06-22 15:53:40.132101
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    return rc.render({'speed': 100})
    # assert rc.render({'speed': 100}) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-22 15:53:43.893990
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    assert tqdm_rich.clear is not std_tqdm.clear

# Generated at 2022-06-22 15:53:45.976913
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(5) as t:
        assert t.n == 0
        t.update(1)
        assert t.n == 1

# Generated at 2022-06-22 15:53:48.499219
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress()).text == '0.0/0.0'

# Generated at 2022-06-22 15:54:00.365088
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from math import nan
    from unittest import TestCase, main

    class FractionColumnTest(TestCase):
        def test_1(self):
            self.assertEqual(
                FractionColumn().render({"total": nan, "completed": nan}),
                Text("0.0/nan")
            )

        def test_2(self):
            self.assertEqual(
                FractionColumn().render({"total": nan, "completed": 0}),
                Text("0.0/nan")
            )

        def test_3(self):
            self.assertEqual(
                FractionColumn().render({"total": nan, "completed": 1e-6}),
                Text("0.0/nan")
            )


# Generated at 2022-06-22 15:54:01.442112
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in trange(2):
        pass

# Generated at 2022-06-22 15:54:11.732431
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import trange
    from .std import tqdm
    a = trange(2, desc="test")
    a.reset(total=5)
    a.reset(total=10)
    a.close()

    b = tqdm(2, desc="test")
    b.reset(total=5)
    b.reset(total=10)
    b.close()

    a = trange(5, desc="test")
    a.reset(total=5)
    a.reset(total=None)
    a.close()

    b = tqdm(5, desc="test")
    b.reset(total=5)
    b.reset(total=None)
    b.close()

    a = trange(10, desc="test")
    a.reset(total=5)
   

# Generated at 2022-06-22 15:54:13.601014
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    bar = tqdm_rich(total=200)
    bar.reset(total=3)
    assert bar.total == 3

# Generated at 2022-06-22 15:54:20.760215
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Unit test for method close of class tqdm_rich.
    """
    _ = tqdm_rich(bar_format='{l_bar}{bar}|', total=5, disable=True)
    _.close()
    _ = tqdm_rich(bar_format='{l_bar}{bar}|', total=5, disable=False)
    _.close()
    
    

# Generated at 2022-06-22 15:54:29.855408
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    total = 10
    progress = tqdm_rich(total=total)
    for _ in progress:
        pass
    assert (progress.n == total), 'The looop has not been completed'
    progress.reset(total=total)
    for _ in progress:
        pass
    assert (progress.n == total), 'The looop has not been completed'

# Generated at 2022-06-22 15:54:35.328756
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import BarColumn, TimeRemainingColumn
    test_progress = Progress((
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[", TimeRemainingColumn(), "]"), transient=True)
    test_progress.__enter__()
    test_tqdm_rich = tqdm_rich(range(3), desc="test desc")
    test_tqdm_rich.display()
    test_tqdm_rich._prog.__exit__(None, None, None)

# Generated at 2022-06-22 15:54:41.461154
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm(total=11, unit='MiB')
    task.update(5)
    assert '5.71 MiB/s' == RateColumn(unit=task.unit,
                                      unit_scale=task.unit_scale,
                                      unit_divisor=task.unit_divisor).render(task)

# Generated at 2022-06-22 15:54:42.640320
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn()
    pass

# Generated at 2022-06-22 15:54:49.187177
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test the four possible outcomes of the function.
    #  1. Rate is None, speed is None
    #  2. Rate is None, speed is something
    #  3. Rate is something, speed is None
    #  4. Rate is something, speed is something
    # Test case 1
    # TODO: This test fails.
    #  A: It is unclear what the expected output should be.
    #  The exact output should be discussed.
    # task = tqdm(total=50, leave=False)
    task = std_tqdm(total=50, leave=False)
    col = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert(col.render(task) == "? /s")
    task.close()
    # Test case 2
    task = std_

# Generated at 2022-06-22 15:54:50.428533
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pass

# Generated at 2022-06-22 15:54:56.381769
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    progress = Progress('bar')
    progress.start()
    task = progress.add_task('task_1')
    progress.update(task, progress=50)
    progress.stop()

    progress = Progress(BarColumn())
    progress.start()
    task = progress.add_task('task_1')
    progress.update(task, progress=50)
    progress.stop()

# Generated at 2022-06-22 15:55:03.221469
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    from rich.progress import Task
    task = Task("")
    task.speed = 0.5

    task.speed = None
    assert RateColumn(unit="").render(task) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="D").render(task) == Text("? D/s", style="progress.data.speed")

    task.speed = 500
    assert RateColumn(unit="", unit_scale=True).render(task) == Text("500 /s", style="progress.data.speed")
    assert RateColumn(unit="D", unit_scale=True).render(task) == Text("500 D/s", style="progress.data.speed")
    assert RateColumn(unit="", unit_scale=True, unit_divisor=1024).render(task)

# Generated at 2022-06-22 15:55:09.508354
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import _range
    from .std import _environ

    if 'CI' not in _environ:
        t = tqdm_rich(_range(10))
        assert t.n == 0
        t.reset(total=50)
        assert t.total == 50
        assert t.n == 50

# Generated at 2022-06-22 15:55:21.563262
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Unit test for method display of class tqdm_rich
    """
    class TqdmRichMock(tqdm_rich):
        def __init__(self, *args, **kwargs):
            #pylint: disable=super-init-not-called
            self.n = 3
            self.iterable = range(10)
            self.total = len(self.iterable)
            self.disable = False
            self.miniters = 1
            self.desc = None
            self.unit = 'it'
            self.unit_scale = False
            self.unit_divisor = 1000
            self.mininterval = 0
            self.maxinterval = 0
            self.ascii = True
            self.dynamic_ncols = True
            self.leave = True
            self

# Generated at 2022-06-22 15:55:28.242661
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress()
    task_id = progress.add_task("Test", total=10)
    for i in range(11):
        progress.update(task_id, completed=i)
        console.print(progress)

# Generated at 2022-06-22 15:55:40.048345
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import json
    rich_obj = tqdm(range(5))
    out = rich_obj.display()
    assert out == None

# Generated at 2022-06-22 15:55:51.614604
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import datetime
    start_time = datetime.datetime.now()
    for i in tqdm_rich(total=2, position=0, mininterval=0.2, leave=True):
        assert i == 0
        if (datetime.datetime.now()-start_time).seconds >= 5:
            break
    for i in tqdm_rich(total=2, position=0, mininterval=0.2, leave=True):
        assert i == 1
        if (datetime.datetime.now()-start_time).seconds >= 5:
            break
    for i in tqdm_rich(total=2, position=0, mininterval=0.2, leave=True):
        assert i == 0

# Generated at 2022-06-22 15:56:00.894859
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import math
    rate_column = RateColumn()
    fake_task = type("FakeTask", (object,), {"speed": None})()
    assert rate_column.render(fake_task) == Text("? /s", style="progress.data.speed")
    fake_task = type("FakeTask", (object,), {"speed": math.pow(10, 9)})()
    assert rate_column.render(fake_task) == Text("1.0 G/s", style="progress.data.speed")
    fake_task = type("FakeTask", (object,), {"speed": math.pow(1000, 5)})()
    assert rate_column.render(fake_task) == Text("1.0 P/s", style="progress.data.speed")

# Generated at 2022-06-22 15:56:08.831957
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for i in tqdm(range(4)):
        if i == 1:
            time.sleep(0.2)
        if i == 2:
            tqdm.write("Test clear()")
            tqdm.clear()
        if i == 3:
            tqdm.write("Test close()")
            tqdm.close()
    tqdm.write("Test")
    tqdm.close()


if __name__ == "__main__":
    import time
    test_tqdm_rich()

# Generated at 2022-06-22 15:56:20.795509
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import tqdm.rich.progress as progress  # pragma: no cover
    t = progress.RateColumn('B/s', unit_scale=True, unit_divisor=1000)
    assert t.render(
        progress.ProgressTask(
            'test',
            completed=1,
            total=2,
            speed=3
        )
    ).string == '3.0 B/s'

    t = progress.RateColumn('B/s', unit_scale=True, unit_divisor=1024)
    assert t.render(
        progress.ProgressTask(
            'test',
            completed=1,
            total=2,
            speed=3*1024
        )
    ).string == '3.0 KiB/s'

# Generated at 2022-06-22 15:56:25.406351
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from random import randint
    import time
    import sys

    with tqdm(total=100) as bar:
        for i in range(100):
            time.sleep(0.5)
            bar.update(randint(0, 10))


if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-22 15:56:36.407187
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert str(FractionColumn().render(Progress(total=100))) == "0/100 "
    assert str(FractionColumn().render(Progress(total=1024))) == "0/1 K"
    assert str(FractionColumn(unit_scale=False).render(Progress(total=1024))) == "0/1024"
    assert str(FractionColumn(unit_scale=True).render(Progress(total=1024))) == \
        "0/1,000 "
    assert str(FractionColumn().render(Progress(completed=1, total=100))) == \
        "0.0/100 "
    assert str(FractionColumn().render(Progress(completed=1, total=1024))) \
        == "0.0/1 K"

# Generated at 2022-06-22 15:56:45.741952
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # total is not provided
    with tqdm_rich('hello', total=10) as bar1:
        bar1.reset()
        assert bar1.n == 0
        assert bar1.total == 10
        bar1.update(10)
    # total is provided, should update the task with the new value
    with tqdm_rich('hello', total=10) as bar2:
        bar2.reset(total=20)
        assert bar2.n == 0
        assert bar2.total == 20
        bar2.update(20)

# Generated at 2022-06-22 15:56:53.674536
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.panel import Panel
    from rich.console import Console
    from rich.padding import Padding
    console = Console()

    for t in tqdm(range(10)):
        sleep(0.1)
    t.reset(total=100)
    for t in tqdm(range(100)):
        sleep(0.1)

    console.print(Panel('tqdm.rich.tqdm', style='green'))
    padding = Padding(text=t._prog, align='left', width=console.width)
    console.print(padding)

# Generated at 2022-06-22 15:57:06.797921
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        import rich
    except ImportError:
        return
    # test with total=None
    with tqdm(total=10) as progress:
        progress.reset()
    # test with total=100
    with tqdm(total=10) as progress:
        progress.reset(100)

# Generated at 2022-06-22 15:57:12.272578
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Test case 1:
    with tqdm_rich(total=100) as t:
        assert t.n == 0
    # Test case 2:   
    t = tqdm_rich(total=100)
    assert t.n == 0
    t.reset(total=200)
    assert t.n == 0 and t.total == 200

# Generated at 2022-06-22 15:57:15.263873
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm(desc='Bar', leave=True) as bar:
        for i in _range(10):
            bar.display(n=i)
            sleep(0.01)

# Generated at 2022-06-22 15:57:17.779493
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test method render of class RateColumn"""
    column = RateColumn()
    assert column.render(123) == Text("123 /s", style="progress.data.speed")

# Generated at 2022-06-22 15:57:26.757907
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Ensure reset() works correctly (issue #63)."""
    from .tests import pretest_def
    with pretest_def():
        import time
        import gc
        try:
            from rich.progress import TaskID
        except ImportError:
            return
        p = Progress()
        p_id = p.add_task("test")
        t = tqdm_rich(total=100, desc="test", leave=True,
                      disable=False, unit="B", unit_scale=True)
        assert t._prog is p
        assert t._task_id is p_id
        t.reset(0)
        assert t._prog is p
        assert t._task_id is p_id
        t.update(1)
        time.sleep(.01)
        assert t._prog.get_task

# Generated at 2022-06-22 15:57:38.551452
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich"""
    from io import StringIO
    import sys

    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    with tqdm_rich(ascii=True, total=10) as t:
        for i in range(10):
            t.set_description("Foo Bar")
            t.set_postfix(loss=0.1)
            t.update()

    sys.stdout = old_stdout

    mystdout.seek(0)
    assert mystdout.read() == ('Foo Bar: 100%|##########| 10/10 [00:00<00:00, 379.42it/s, loss=0.1]\n')

# Generated at 2022-06-22 15:57:48.030417
# Unit test for method render of class RateColumn
def test_RateColumn_render():

    # Unit test on open range: 0 to 10
    for i in range(0,10):
        assert round(RateColumn().render(i,10),2) == round(i,2)

    # Unit test with varying duration time (1 sec to 10 sec)
    import time
    for i in range(1,10):
        start = time.time()
        time.sleep(i)
        end = time.time()
        assert round(RateColumn().render(i,10,end-start),2) == round(i,2)

# Generated at 2022-06-22 15:57:58.881760
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .utils import cached_property

    class FakeTask(object):
        """Fake task."""
        def __init__(self, speed: float):
            """Fake task."""
            self.speed = speed

        @cached_property
        def total(self) -> float:
            """Fake totoal."""
            return 10.

        @cached_property
        def completed(self) -> float:
            """Fake completed."""
            return 5.

    r = RateColumn(unit="B", unit_scale=False)
    assert r.render(FakeTask(speed = 0.0)) == Text(f"0.0 B/s", style="progress.data.speed")
    assert r.render(FakeTask(speed = 0.9)) == Text(f"0.9 B/s", style="progress.data.speed")

# Generated at 2022-06-22 15:58:07.503938
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    assert column.render(Progress(0, 1, speed=1)) == "1.0  /s"
    assert column.render(Progress(0, 1, speed=2)) == "2.0  /s"
    assert column.render(Progress(0, 1, speed=1234)) == "1.2 K/s"
    assert column.render(Progress(0, 1, speed=12345)) == "12.3 K/s"
    assert column.render(Progress(0, 1)) == "?  /s"


# Generated at 2022-06-22 15:58:19.073662
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tp = FractionColumn()

    # test default
    assert ("0.0/0.0 " == tp.render(task=object()))

    # test with unit_divisor = 1000 and unit_scale = True
    assert ("0.0/0.0 " == tp.render(task=object()))

    # test with unit_divisor = 1024 and unit_scale = True
    tp.unit_divisor = 1024
    assert ("0.0/0.0 " == tp.render(task=object()))

    # test with completed = 0
    tp.unit_divisor = 1000
    assert ("0.0/0.0 " == tp.render(task=object()))

    # test with completed = 1
    tp.unit_divisor = 1000
    tp.unit

# Generated at 2022-06-22 15:58:44.427216
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn(unit_scale = True)
    assert f.render(2, 3) == "2.0/3.0"

# Generated at 2022-06-22 15:58:52.828939
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:  # prevent global tqdm instance to be used
        del tqdm.instances[0]
    except IndexError:
        pass
    for index in range(5):
        for total in [None, index, index+1]:
            with tqdm(10, initial=0, total=total) as pbar:
                pbar.reset(index)
                assert pbar.n == index
                assert pbar.total == index+1 if pbar.total is None else pbar.total
                pbar.reset(total=pbar.total)  # no-op
                assert pbar.n == index
                assert pbar.total == index+1 if pbar.total is None else pbar.total
                if index == 0:
                    pbar.reset(total=1)  # no-op
                    assert pbar

# Generated at 2022-06-22 15:59:02.285254
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # call the method with speed set to None
    task = tqdm_rich(total=3.5, unit_scale=False)
    task._number_format = "."
    task.n = 1.5
    task.start_t = 2
    task.last_print_t = 5
    rate_col = RateColumn(unit="K", unit_scale=False, unit_divisor=1000)
    assert rate_col.render(task) == Text("? K/s", style="progress.data.speed")
    # call the method with speed set to not None
    task.start_t = 2
    task.last_print_t = 5
    rate_col = RateColumn(unit="K", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-22 15:59:06.988814
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fraction_column.render(Progress(total=4000)).text == "0/4"
    assert fraction_column.render(Progress(completed=500, total=10500)).text == "0.5/10.5"

# Generated at 2022-06-22 15:59:08.983624
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=10)
    t.reset(total=11)
    t.reset()
    t.reset()

# Generated at 2022-06-22 15:59:13.165509
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from contextlib import closing
    from time import sleep
    from tqdm.std import tqdm
    from tqdm.auto import tqdm
    total = 1000
    with closing(tqdm_rich(total=total)) as pbar:
        for i in tqdm(range(total)):
            sleep(0.01)
            pbar.update(1)
    assert i == total - 1

# Generated at 2022-06-22 15:59:15.917833
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from tqdm import trange

    for i in trange(2, leave=True):
        for j in trange(5, leave=True):
            time.sleep(0.1)

# Generated at 2022-06-22 15:59:27.044379
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task as ProgressTask
    from tqdm.rich import FractionColumn

    task = ProgressTask()
    task.total = 23300
    task.completed = 11722

    fraction_column = FractionColumn(unit_scale=True)
    assert fraction_column.render(task) == Text("11.7/23.3 K",
                                                style="progress.download")

    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fraction_column.render(task) == Text("11.3/22.6 K",
                                                style="progress.download")

    task.total = 11722
    task.completed = 11722


# Generated at 2022-06-22 15:59:31.685008
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as pbar:
        for _ in _range(3):
            pbar.reset(total=5)

        for _ in _range(5):
            pass

        for _ in _range(2):
            pbar.reset(total=2)

        pbar.reset()

# Generated at 2022-06-22 15:59:42.077773
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    from contextlib import contextmanager
    from unittest import TestCase

    from .std import tqdm

    class StubWriter:
        """Stub stdout writer"""
        def __init__(self):
            self.output = None

        def write(self, msg):
            self.output = msg

        def flush(self):
            pass

    @contextmanager
    def stub_stdout(writer):
        """Stub stdout writer"""
        orig = sys.stdout
        sys.stdout = writer
        try:
            yield writer
        finally:
            sys.stdout = orig

    class TqdmTests(TestCase):
        """Unit tests for `tqdm_rich`"""


# Generated at 2022-06-22 16:00:55.346008
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from rich.text import Text
    from rich.style import Style
    from .utils import rate_column_style

    rc = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    task = TaskID(0)
    task.speed = None
    text = rc.render(task)
    assert(text.__repr__() == Text('? B/s', style=rate_column_style).__repr__())

    task.speed = -1
    text = rc.render(task)
    assert(text.__repr__() == Text('-1.0 B/s', style=rate_column_style).__repr__())

    task.speed = 0
    text = rc.render(task)

# Generated at 2022-06-22 16:01:05.191285
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm_stdout
    import sys
    from .utils import format_as_text, format_meter
    try:
        tqdm_stdout(desc="test", bar_format="{l_bar}", file=sys.stdout).close()
    except Exception:
        print(">>> %s error 1: `tqdm_stdout` is inaccessible." % __name__)
    else:
        print(">>> %s access 1: `tqdm_stdout` is accessible." % __name__)
    try:
        tqdm_stdout(bar_format="{l_bar}", file=sys.stdout).close()
    except Exception:
        print(">>> %s error 2: `tqdm_stdout` is inaccessible." % __name__)

# Generated at 2022-06-22 16:01:09.817178
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import pytest

    @pytest.mark.parametrize("total", range(0, 10))
    def test_tqdm_rich_display(total):
        t = tqdm_rich(total=total)
        t.update()
        t.close()
    test_tqdm_rich_display()

# Generated at 2022-06-22 16:01:13.989445
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    with std_tqdm(total=10) as pbar1:
        with tqdm_rich(total=10) as pbar2:
            for _ in std_trange(10):
                pbar2.update()

# Generated at 2022-06-22 16:01:21.059365
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    This unit test is to ensure method `tqdm_rich.reset` is not broken.
    """
    from .std import tqdm as tqdm_std

    for cls in [tqdm_rich, tqdm_std]:
        with cls(total=1) as pbar:
            assert pbar.n == 0, "The bar is not properly initialized."
            pbar.reset(total=5)
            assert pbar.n == 0, "The bar is not properly reset."
            assert pbar.total == 5, "The bar is not properly reset."

# Generated at 2022-06-22 16:01:25.598844
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    import sys
    # In this method, we use class tqdm_rich to use RateColumn
    with tqdm_rich(total=100, desc="Downloading", unit_scale=True, unit_divisor=1024,
                   smoothing=0.3, unit="B", bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} "
                                                       "{rate_fmt}{postfix}"
                   ) as t:
        for i in range(100):
            t.update()
            sys.stdout.flush()

if __name__ == "__main__":
    test_RateColumn_render()

# Generated at 2022-06-22 16:01:37.358304
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich."""
    import sys

    def _test():
        import time
        progress = (
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
            ",", RateColumn(unit=''), "]"
        )

# Generated at 2022-06-22 16:01:39.543732
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        tqdm_rich.display()
    except ValueError:
        pass
    except:
        assert False, "tqdm_rich.display() should raise 'ValueError'"

# Generated at 2022-06-22 16:01:45.366664
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    from rich.progress import Task
    task = Task(description='Unit test for method render of'
                ' class RateColumn',
                completed=1,
                total=10000,
                speed=500)
    assert column.render(task) == Text('500.0 /s',
                                       style='progress.data.speed')

# Generated at 2022-06-22 16:01:54.886695
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in ['', '0', 0]:
        with tqdm(total = total) as pbar:
            count = pbar.n
            pbar.n = total
            pbar.refresh()
            assert pbar.n == count

    for start in ['', '0', 0]:
        for total in ['', '0', 0]:
            for position in ['', '0', 0]:
                with tqdm(start = start, total = total) as pbar:
                    pbar.refresh(position)
                    count = pbar.n
                    pbar.n = total
                    pbar.refresh(position)
                    assert pbar.n == count

# Generated at 2022-06-22 16:02:46.605202
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=10, desc="testing rich display by calling directly")
    t.display()
    t.close()

# Generated at 2022-06-22 16:02:56.176742
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    def has_attr(attr_name):
        return hasattr(reset_obj, attr_name)

    reset_obj = tqdm_rich(total=20)
    reset_obj.reset(total=40)

    assert reset_obj.n == 0
    assert reset_obj.total == 40
    assert reset_obj.dynamic_ncols == True
    assert reset_obj.miniters is None
    assert reset_obj.desc == ''
    assert reset_obj.ascii is None
    assert reset_obj.unit_scale == False
    assert reset_obj.unit_divisor == 1000
    assert reset_obj.unit == ''
    assert reset_obj.gui is True
    assert has_attr('_prog')
    assert has_attr('_task_id')
    assert reset_obj.sm

# Generated at 2022-06-22 16:03:04.964748
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # rate = 1
    print(RateColumn().render(object()))
    # rate = None
    print(RateColumn().render(object()))
    # rate is not None
    print(RateColumn().render(object()))
    # rate = 1000
    print(RateColumn().render(object()))
    # rate is not None
    print(RateColumn().render(object()))
    # rate = 1024
    print(RateColumn().render(object()))
    # rate == 1
    print(RateColumn().render(object()))



# Generated at 2022-06-22 16:03:16.912995
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Tests display method of class tqdm_rich
    from os import devnull

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('os.isatty', return_value=False):
        # isatty = false | disable = true
        with patch('sys.stderr'):
            with patch('tqdm.tqdm.tqdm_rich.Progress',
                       return_value=None) as mock_progress:
                pbar = tqdm_rich(total=1000)
                assert not hasattr(pbar, '_prog')
                pbar.display()  # should not raise an error

        # isatty = false | disable = false

# Generated at 2022-06-22 16:03:27.387981
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import (
        BarColumn,
        Progress,
        ProgressColumn,
        Text,
        TimeElapsedColumn,
        TimeRemainingColumn
    )
    d = {'total': 100, 'unit': 'it', 'unit_scale': True, 'unit_divisor': 1000}
    progress = (
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            "",
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"
        )
    _prog = Progress(*progress, transient=False)
    _prog.__enter__()
    _task_id = _prog.add_task("Test", **d)

    _prog.update