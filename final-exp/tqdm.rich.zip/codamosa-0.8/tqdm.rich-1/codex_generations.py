

# Generated at 2022-06-22 15:53:26.519690
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    prog = Progress(BarColumn(bar_width=None), transient=False, console=console)
    prog.__enter__()
    p = prog.add_task("", total=50)
    prog.update(p, completed=10)
    prog.update(p, completed=20)
    prog.__exit__()
    assert console.buffer == ""

# Generated at 2022-06-22 15:53:31.294233
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=2) as pbar:
        pbar.display()
        pbar.n = 1
        pbar.display()
        pbar.n = 2

# Generated at 2022-06-22 15:53:33.189787
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=3) as t:
        t.clear()

# Generated at 2022-06-22 15:53:36.505706
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B").render(
        std_tqdm(total=100, position=20, unit_scale=True,
                 unit_divisor=1000, unit="B")) == "23.6 KB/s"



# Generated at 2022-06-22 15:53:42.397814
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(0, 100, bar_format='{n_fmt}/{total_fmt} [{elapsed_s}<{remaining_s}, {rate_fmt}{postfix}]')  # NOQA
    # t = tqdm_rich(0, 100, bar_format='{n_fmt}/{total_fmt}')  # NOQA
    for i in t:  # pragma: no cover
        t.set_description('exp: {i}'.format(i=i))
        t.set_postfix(exp=i)
        t.update_to(i + 1)
    t.close()

# Generated at 2022-06-22 15:53:44.224857
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import time
    t = tqdm_rich(100)
    for i in t:
        time.sleep(.01)
        t.reset(total=5)
        t.reset()

# Generated at 2022-06-22 15:53:51.761144
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    '''
    Test the rendering of RateColumn (human readable transfer speed).
    '''
    a = RateColumn('', False, 1000)
    assert a.render(1) == '[progress.data.speed]       1.00 /s'
    assert a.render(990) == '[progress.data.speed]     990.00 /s'
    assert a.render(1000) == '[progress.data.speed]       1.00 K/s'
    assert a.render(990000) == '[progress.data.speed]     990.00 K/s'
    assert a.render(999000) == '[progress.data.speed]       1.00 M/s'

    b = RateColumn('B', False, 1000)
    assert b.render(1) == '[progress.data.speed]       1.00 B/s'


# Generated at 2022-06-22 15:53:59.020131
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Testing default arguments of __init__ function
    with tqdm_rich(total=100) as t:
        pass
    assert t.n == 100
    assert t.last_print_n == 0
    assert t.last_print_t == t.start_t
    assert t.dynamic_ncols

    with tqdm_rich(iterable=list(range(100))) as t:
        pass
    assert t.dynamic_ncols
    assert t.total == 100

    with tqdm_rich(xrange(20)) as t:
        assert t.dynamic_ncols
    assert t.total == 20

    # Testing with custom arguments

# Generated at 2022-06-22 15:54:10.418309
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch

    from .std import tqdm_gui

    t = tqdm_gui(
        total=10,
        unit_scale=True,
        miniters=10,
        **{
            # "file": sys.stderr,
            "mininterval": 0.1,
            "mininterval": 0.1,
            "unit": "B",
            "unit_scale": True,
            "unit_divisor": 1000,
            "leave": True,
            "disable": False,
        })

# Generated at 2022-06-22 15:54:14.931187
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    t = tqdm_rich(total=100, desc='one')
    t = tqdm_rich(total=None, desc='one')
    t = tqdm_rich(100, desc='one')

# Generated at 2022-06-22 15:54:25.881825
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Test reset() method of class tqdm_rich
    with tqdm_rich(total=10) as pbar:
        for i in range(5):
            pbar.update()
        pbar.reset(total=100)
        for i in range(100):
            pbar.update()

# Generated at 2022-06-22 15:54:28.479047
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

# Generated at 2022-06-22 15:54:36.306341
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    _time_spent_bytes = [4.90, 0.40, 0.40]
    stdio_line = '0.00%|                                                  | 0/5 [00:00<?, ?it/s]'
    assert stdio_line == '{0}%|{1}| [{2}/{3} {4} {5}]'.format(
        0, ' ' * (43), 0, 5, '00:00<?, ?it/s', 0)

    stdio_line = '20.00%|############----                                 | 1/5 [00:00<00:00,  4.90it/s]'

# Generated at 2022-06-22 15:54:46.799277
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test the RateColumn.render method."""
    task = std_tqdm(total=1000, unit="B", unit_scale=True)
    column = RateColumn(unit="B", unit_scale=True)
    columns = []
    # speed by default is None
    render = column.render(task)
    columns.append(render)
    task.update(1000)
    # speed=0
    column = RateColumn(unit="B", unit_scale=True)
    render = column.render(task)
    columns.append(render)
    task.update(1000)
    # speed=1024
    column = RateColumn(unit="B", unit_scale=True)
    render = column.render(task)
    columns.append(render)
    task.update(1000)
    # speed=146561
   

# Generated at 2022-06-22 15:54:57.886684
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from multiprocessing import Process, Queue
    from time import sleep
    from traceback import print_exc
    from sys import __stdout__
    from sys import stderr

    # To prevent nbconvert from failing
    if __stdout__.isatty():
        class ShutUp(object):
            """stop rich's logging"""
            def write(self, _):
                pass
        stderr = ShutUp()

# Generated at 2022-06-22 15:55:05.514582
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    n = 20000
    for i in range(n):
        # avoid i/n == 1
        if i == n:
            i -= 1
        f = FractionColumn()
        t = Progress(total=n)
        task_id = t.add_task(description="task")
        t.update(task_id, completed=i)
        text = f.render(t._tasks[task_id])
        assert type(text) is Text

# Generated at 2022-06-22 15:55:15.975476
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    p = Progress()
    total = 100
    t = tqdm_rich(range(total), progress=(
        "Loading [progress.description]{task.description}",
        BarColumn(),
        "[progress.percentage]{task.percentage:>4.0f}%",
        TimeElapsedColumn(format="{elapsed}"),
        TimeRemainingColumn(format="{remaining}"),
    ), total=total)
    t.set_description('Installing ')
    for i in range(total):
        t.update()
    t.reset()
    for i in range(total):
        t.upda

# Generated at 2022-06-22 15:55:19.968694
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import mock
    try:
        with mock.patch("tqdm.gui._tqdm_notebook") as tqdm_notebook:
            from tqdm.gui import tqdm_notebook as tqdm
            # test that clear method is called
            t = tqdm(total=100)
            t.n = 50
            t.refresh()
            t.clear()
            assert t.position == 0
            # test that bar is created again
            t.display()
            t.display()
            assert t.bar_created == 2
    except ImportError:
        # NOP: tqdm_notebook is not installed
        pass

# Generated at 2022-06-22 15:55:29.221128
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import random
    import time

    with tqdm_rich(total=10, ascii=True, unit_scale=1) as bar:
        for i in range(10):
            time.sleep(0.1)
            bar.update(1)

    with tqdm_rich(total=10, ascii=True, unit_scale=1, initial=5) as bar:
        for i in range(5, 10):
            time.sleep(0.1)
            bar.update(1)

if __name__ == '__main__':
    test_tqdm_rich_display()

# Generated at 2022-06-22 15:55:40.945268
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Test_Completed_Total:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
            self.speed = None

    # Test for case long_size = True and unit_divisor = 1000
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    task = Test_Completed_Total(0, 0)
    assert(str(column.render(task)) == "0.0/0.0 ")
    task = Test_Completed_Total(123, 0)
    assert(str(column.render(task)) == "123.0/0.0 ")
    task = Test_Completed_Total(123, 456)
    assert(str(column.render(task)) == "0.1/0.5 ")
    task

# Generated at 2022-06-22 15:55:56.707921
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from tqdm.autonotebook import tnrange
    from tqdm.auto import trange
    from random import randint
    from time import sleep

    T = 10
    for _ in trange(T):
        for t in trange(T, total=T, desc='Inner loop'):
            for i in tnrange(t, desc='Inner inner loop'):
                sleep(randint(0, 1))
    for _ in trange(T):
        t = randint(1, T-1)
        for t in trange(t, total=T, desc='Inner loop'):
            for i in tnrange(T, desc='Inner inner loop'):
                sleep(randint(0, 1))

# Generated at 2022-06-22 15:56:02.806293
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    from rich.progress import Progress

    @tqdm_rich(progress=(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=True, unit_divisor=1024),
        "[", TimeElapsedColumn(), "]",
    ))
    def test_write_loop():
        for _ in range(10):
            yield

    test_write_loop()
    assert len(Progress.instances) == 0

# Generated at 2022-06-22 15:56:07.672702
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    import io
    import sys

    if hasattr(sys, '__unittest'):  # pragma: no cover
        return
    # Hide deprecation warnings when running the test
    stderr = sys.stderr
    sys.stderr = io.StringIO()
    tqdm_rich.write = tqdm.write
    try:
        with tqdm_rich(0) as x:
            assert x.n == 0
            x.display()
            assert x.n == 0
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 15:56:10.715165
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn()
    task = Progress()
    task.speed = None
    print('testing render of class RateColumn:')
    print('expect: ? /s, result: %s' % rateColumn.render(task))

# Generated at 2022-06-22 15:56:22.970956
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .utils import FormatCustomText, FormatReplaceError
    from .std import tqdm as std_tqdm

    def _test_tqdm_rich_display_helper(tqdm, *args, **kwargs):
        progress = kwargs.pop('progress', None)
        kwargs['bar_format'] = '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'
        kwargs['disable'] = False
        with tqdm(*args, **kwargs) as trange:
            trange.n = 1
            trange.last_print_n = 1
            trange.last_print_t = 123
            trange.dynamic_ncols = 10
            trange

# Generated at 2022-06-22 15:56:25.073719
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        t.reset(total=20)
        for _ in range(20):
            t.update()

# Generated at 2022-06-22 15:56:32.523713
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm.auto import trange  # required to display time remaining
    from time import sleep

    with trange(10) as t:
        for i in t:
            sleep(0.1)

    t.reset(total=15)

    with trange(15) as t2:
        for i in t2:
            sleep(0.1)

    assert t is t2

# Generated at 2022-06-22 15:56:35.839407
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test display method of tqdm_rich class"""
    x = tqdm_rich(total=10)
    for i in x:
        assert i == x.n
    x.close()

# Generated at 2022-06-22 15:56:37.935076
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.tests import tests
    tests.test_tqdm_display(tqdm_rich)

# Generated at 2022-06-22 15:56:50.040030
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
    )
    progress.__enter__()
    task_id = progress.add_task("File Download", unit="B", unit_scale=True)
    progress.update(task_id, total=53_236_960)
    rate = RateColumn(unit="B", unit_scale=True)
    assert rate.render(progress.tasks[task_id]) == Text("0.0 B/s", style="progress.data.speed")
    progress.update(task_id, completed=16_000)

# Generated at 2022-06-22 15:57:08.819445
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    for total in [1, 50, 100]:
        with tqdm(total=total) as tr:
            for i in range(total):
                tr.update()
            # force a reset with the same total
            tr.reset(total=total)
            for i in range(total):
                tr.update()
            # force a reset with a different total
            tr.reset(total=total * 2)
            for i in range(2 * total):
                tr.update()
            # force a reset with no total
            tr.reset()
            for i in range(2 * total):
                tr.update()
            # force a reset with no total
            tr.reset(total=None)
            for i in range(2 * total):
                tr.update()

# Generated at 2022-06-22 15:57:13.142181
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test method reset in tqdm_rich.
    """
    progress = tqdm_rich(total=10)
    progress.reset(total=20)
    assert progress.total == 20
    progress.reset(total=50)
    assert progress.total == 50

# Generated at 2022-06-22 15:57:18.022359
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .tests import test_tqdm_rich_reset
    test_tqdm_rich_reset()

if __name__ == '__main__':
    from ._version import __version__
    from .tests import show_doc as _show_doc
    _show_doc(__name__.split('.')[-1], __version__)

# Generated at 2022-06-22 15:57:21.348451
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    d = _range(100)
    for _ in tqdm_rich(d, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{rate}]'):
        pass

# Generated at 2022-06-22 15:57:28.719931
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit = "", unit_scale = False, unit_divisor = 1000)
    speed = 1000
    assert rate_column.render("task") == "1.0 K/s"
    speed = 2000
    assert rate_column.render("task") == "2.0 K/s"
    unit = "B"
    assert rate_column.render("task") == "2.0 KB/s"
    rate_column = RateColumn(unit = "byte", unit_scale = False, unit_divisor = 1000)
    speed = 1000
    assert rate_column.render("task") == "1.0 Kbyte/s"
    speed = 2000
    assert rate_column.render("task") == "2.0 Kbyte/s"

# Generated at 2022-06-22 15:57:33.274353
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm_rich(total=100, desc="Example", unit='b', unit_scale=False) as pbar:
        for x in range(0, 100):
            time.sleep(0.01)
            pbar.update(1)

# Generated at 2022-06-22 15:57:38.337213
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [None, 10]:
        with tqdm_rich(total=total) as pbar:
            if total is None:
                assert pbar.total is None
            else:
                assert pbar.total == total
            pbar.reset(total=total)
            if total is None:
                assert pbar.total is None
            else:
                assert pbar.total == total

# Generated at 2022-06-22 15:57:43.296800
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=100) as t:
        for i in _range(10):
            assert t.total == 100
            t.update()
        t.reset(total=1000)
        for i in _range(10):
            assert t.total == 1000
            t.update()

# Generated at 2022-06-22 15:57:51.000713
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rateColumn.render(None) == Text("8.0 K", style="progress.data.speed")
    rateColumn = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rateColumn.render(None) == Text("8.0 B/s", style="progress.data.speed")


# Generated at 2022-06-22 15:57:54.487124
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    test reset() method for 2 iterations.
    """
    with trange(2) as it:
        for _ in it:
            pass
        it.reset()
        for _ in it:
            pass

# Generated at 2022-06-22 15:58:19.481482
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import re
    import types
    from .ti import RateColumn
    t = RateColumn()
    assert t.render.__doc__ == "Show data transfer speed."
    assert t.render(None) == '0.0  /s'
    assert t.render(types.SimpleNamespace(speed=None)) == '?  /s'
    assert re.match(t.render(types.SimpleNamespace(speed=int(1e12))),
                    r'9.2\d \d/.\d  /s')
    assert re.match(t.render(types.SimpleNamespace(speed=int(1e12))),
                    r'9.2\d \d/.\d  /s')

# Generated at 2022-06-22 15:58:24.853078
# Unit test for method render of class RateColumn

# Generated at 2022-06-22 15:58:35.405483
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for n, desc in zip(
        [0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10],
        ["", "", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"]):
        tqdm_rich(0, total=10, desc=desc).set_postfix(n=n)
    with tqdm_rich(total=3) as prog:
        assert prog.total == 3
        prog.reset(total=1)
        assert prog.total == 1
    assert tqdm_rich(0, total=10).n == 0
    for n in tqdm_rich(0, total=10):
        assert n == 0

# Generated at 2022-06-22 15:58:38.962734
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert(FractionColumn.render(FractionColumn(False), Task(100,100)) == Text("1.0/1.0 "))
    assert(FractionColumn.render(FractionColumn(True, 1000), Task(1000, 1030)) == Text("1.0/1.0 K"))

# Generated at 2022-06-22 15:58:44.773606
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    console = Console()
    console.print("")
    console.print("")

    tp = tqdm_rich(total=100)
    for i in range(100):
        tp.update(1)

    tp.close()

# Generated at 2022-06-22 15:58:47.157374
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    with tqdm_rich(total=10) as progress:
        for _ in progress:
            progress.display()

# Generated at 2022-06-22 15:58:52.352804
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tqdm  # needed for the disable option
    with tqdm(total=100, disable=False) as pbar:
        pbar.reset(total=None)
        assert pbar.total is None  # total shouldn't change
        assert pbar.n == 0  # bar should be reset to 0
        pbar.reset(total=10)
        assert pbar.total == 10  # total should change
        assert pbar.n == 0  # bar should be reset to 0

# Generated at 2022-06-22 15:59:01.407733
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rc.render(std_tqdm(total=1, unit="bytes", unit_scale=False)) == \
        Text(u"1.00 B/s", style="progress.data.speed")

    rc = RateColumn(unit="B", unit_scale=False, unit_divisor=1024)
    assert rc.render(std_tqdm(total=1, unit="bytes", unit_scale=True)) == \
        Text(u"1.00 B/s", style="progress.data.speed")

    rc = RateColumn(unit="iB", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 15:59:07.993851
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = type('Task', (), {'description': 'description', 'completed': 1, 'total': 2, 'speed': 1234.0})()
    task.completed = 1
    task.total = 2
    fractionColumn = FractionColumn(unit_scale=False, unit_divisor=1000)
    task.total = 2.3
    assert fractionColumn.render(task) == Text("0.5/2.3 ", style="progress.download")


# Generated at 2022-06-22 15:59:13.451354
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Method display of class `tqdm_rich`."""
    from rich.progress import Progress
    progress = Progress()
    progress.add_task("Test")
    prog = Progress("{task.completed}/{task.total}")
    task_id = prog.add_task("test")
    trange(3).display()
    tqdm(range(3), desc="test").display()
    progress.update(task_id, completed=3)
    prog.update(task_id, completed=3, total=5)

# Generated at 2022-06-22 15:59:55.671826
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .std import tqdm
    from .utils import FakeTqdmFile

    with tqdm(total=3) as bar:
        bar.display()
        bar.display()
        bar.update(1)
        bar.display()
        bar.update(1)
        bar.display()
        bar.update(1)
        bar.display()
    assert bar.n == 3
    assert bar.disable is False

    with tqdm(total=3, file=FakeTqdmFile()) as bar:
        bar.display()
        bar.display()
        bar.update(1)
        bar.display()
        bar.update(1)
        bar.display()
        bar.update(1)
        bar.display()
    assert bar.n == 3

# Generated at 2022-06-22 16:00:05.232687
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    # Test for filesize.pick_unit_and_suffix(total, [""], 1)
    class task0:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total


# Generated at 2022-06-22 16:00:09.121451
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress.Task("", total=2048., completed=1024.)
    test = FractionColumn()
    test.render(task) == Text("1.0/2.0 K", style="progress.download")

# Generated at 2022-06-22 16:00:15.997613
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(range(10)) as t:
        assert t.total == 10, "Expected `t.total` is 10, got {}".format(t.total)
        assert t.n == 0, "Expected `t.n` is 0, got {}".format(t.n)
        t.reset(total=5)
        assert t.total == 5, "Expected `t.total` is 5, got {}".format(t.total)
        assert t.n == 0, "Expected `t.n` is 0, got {}".format(t.n)

# Generated at 2022-06-22 16:00:28.184385
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from datetime import datetime
    from .utils import _bar
    from .std import ProgressBar
    class tqdm_fake1(ProgressBar):
        def __init__(self, *args, **kwargs):
            super(tqdm_fake1, self).__init__(*args, **kwargs)
            self.n = 10
            self.total = 14
            self._dynamic_display = None
            self.start_t = datetime.now()
            self._bar = _bar(self, self.total)

    class tqdm_fake2(ProgressBar):
        def __init__(self, *args, **kwargs):
            super(tqdm_fake2, self).__init__(*args, **kwargs)
            self.n = 14
            self.total = 14
            self._dynamic

# Generated at 2022-06-22 16:00:32.773934
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pass
    # TODO:
    # 1. add mock, assert_called_with
    # 2. add progress.bar.ascii.fraction.estimator ->
    #     to verify/test output/format


if __name__ == "__main__":
    pass

# Generated at 2022-06-22 16:00:36.952323
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=100) as t:
        for i in t:
            pass
    t.reset(total=1000)
    for i in t:
        pass
    assert t.n == 1000
    t.reset()
    for i in t:
        pass
    assert t.n == 0

# Generated at 2022-06-22 16:00:44.367021
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress = Progress(Text("percentage: {task.percentage:>4.0f}%",
                             justify="right"),
                        BarColumn(bar_width=None),
                        Text("completed: {task.completed:"
                             ">14,.0f}/{task.total:<14,.0f}",
                             justify="right"),
                        transient=True,
                        reload=True)
    with progress:
        for task_id, total in enumerate([10, 20, 30]):
            task = progress.add_task("Task #{}".format(task_id), total=total)
            for i in _range(total):
                progress.update(task, completed=i + 1)
                # Simulate a call to time.sleep()
                progress.reload()

# Generated at 2022-06-22 16:00:52.989528
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")
    assert RateColumn().render(object) == Text("? /s")


# Generated at 2022-06-22 16:00:57.633752
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test if reset of tqdm_rich works.
    """
    tpr = tqdm_rich(total=100, desc='one')
    tpr.reset(total=200)
    assert tpr.total == 200

# Generated at 2022-06-22 16:02:20.546875
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    #test with unit scale and no unit_divisor
    fc = FractionColumn(unit_scale=True)
    class Task:pass
    task = Task()
    task.completed=10
    task.total=1000
    assert fc.render(task) == Text("0.0/1.0 K", style="progress.download")
    task.completed=10000
    task.total=100000
    assert fc.render(task) == Text("0.1/1.0 K", style="progress.download")
    task.completed=1000000
    task.total=10000000
    assert fc.render(task) == Text("1.0/10.0 K", style="progress.download")
    task.completed=10000000
    task.total=100000000
    assert fc.render(task)

# Generated at 2022-06-22 16:02:28.172164
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest
    @tqdm(reset=True)
    def my_test(iterable, total=None):
        for i in iterable:
            yield i
        pytest.fail("Test failed !")
    
    with pytest.raises(Exception):
        my_test([1, 2, 3])
    assert True, "Test passed !"

# Generated at 2022-06-22 16:02:30.484271
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [100, 100.0, "100"]:
        tqdm_rich(total=total, desc="testing", unit="tests").reset(total=total)

# Generated at 2022-06-22 16:02:38.048759
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():

    task = {'completed': 100, 'total': 1000}
    assert FractionColumn(unit_scale=False).render(task) == '0.1/1.0'
    assert FractionColumn(unit_scale=True).render(task) == '0.1/1.0'
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == '0.1/1.0'

# Generated at 2022-06-22 16:02:48.155783
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from collections import defaultdict
    import time
    import random

    changes = defaultdict(lambda: defaultdict(int))
    for i in tqdm_rich(range(10000), miniters=0, mininterval=0.000005):
        time.sleep(random.random() / 100)
        for _ in range(random.randrange(2)):
            changes[random.randint(0, 10000)]['completed'] += 1
        for _ in range(random.randrange(2)):
            changes[random.randint(0, 10000)]['total'] += 1
        for _ in range(random.randrange(2)):
            changes[random.randint(0, 10000)]['description'] = 'foo'

    for values in changes.values():
        assert values['description'] <= values['completed']



# Generated at 2022-06-22 16:02:57.459988
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import re
    import unittest
    from rich import Progress
    from tqdm.rich import FractionColumn
    from tqdm.rich.progress import _split_formats
    class TestFractionColumn(unittest.TestCase):
        def test(self):
            '''
            test FractionColumn.render
            '''
            progress = Progress(FractionColumn())
            progress.add_task(description='description', completed=2, total=10)
            progress.add_task(description='description', completed=12, total=10)
            progress.add_task(description='description', completed=2, total=3)
            test_str = progress.render()
            # Test for a whitespace character

# Generated at 2022-06-22 16:03:08.123978
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.traceback import install
    install()


# Generated at 2022-06-22 16:03:14.122885
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class TestTask(object):
        def __init__(self):
            self.completed = 1
            self.total = 2
    testtask = TestTask()
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(testtask) == Text('0.001/0.002 ', style='progress.download')



# Generated at 2022-06-22 16:03:22.958709
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import mock

    mock_progress_update = mock.MagicMock()
    tqdm_rich.update = mock_progress_update

    tqdm_rich("hello world", desc="desc 1")
    assert mock_progress_update.call_args[0] == (0, )
    assert mock_progress_update.call_args[1] == {'desc': 'desc 1'}

    tqdm_rich("hello world", desc="desc 2")
    assert mock_progress_update.call_args[0] == (1, )
    assert mock_progress_update.call_args[1] == {'desc': 'desc 2'}