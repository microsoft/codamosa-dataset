

# Generated at 2022-06-22 15:53:36.777632
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import os
    import shutil
    __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
    
    rate = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    with tqdm(total=10, unit_scale=False, unit_divisor=1000) as progress:
        for i in range(10):
            progress.update(1)
            assert rate.render(progress) == "100.0 /s"

if __name__ == "__main__":
    test_RateColumn_render()

# Generated at 2022-06-22 15:53:43.437535
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from .tests_tqdm import pretest_posttest
    from .utils import FormatStub as F
    from .utils import StringIO

    def check(**kwargs):
        args = []
        kwargs['file'] = f = StringIO()
        kwargs['gui'] = True
        kwargs['disable'] = False
        kwargs['unit'] = 'it'
        t = tqdm(*args, **kwargs)
        t.reset(total=100)
        t.reset(total=100)
        t.reset(total=100)
        t.reset()
        t.close()
        if not t.leave:
            f.seek(0)
            got = f.read()

# Generated at 2022-06-22 15:53:48.522365
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest.mock import patch
    import sys
    from .std import tqdm
    try:
        from rich.progress import Progress
    except ImportError:
        return
    mock = patch.object(Progress, '__exit__')
    with mock as m:
        with tqdm(disable=False) as t:
            t.close()
        assert m.called
        assert m.call_count == 1



# Generated at 2022-06-22 15:53:49.956446
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn(unit='B')
    print(column.render(1.0))

# Generated at 2022-06-22 15:53:54.530320
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .tests_tqdm import StringIO
    s = StringIO()
    tasks = tqdm_rich(total=2, file=s, desc="")
    try:
        tasks.update(1)
        tasks.close()
    except Exception:
        raise
    finally:
        tasks.close()
    return

# Generated at 2022-06-22 15:54:02.025125
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = {'completed':12, 'total':34}
    task = type('', (object,), task)
    assert FractionColumn().render(task) == '0.0/0.0'
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == '0.0/0.0'
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == '0.0/0.0'
    task.total = 392
    assert FractionColumn().render(task) == '0.0/0.0'
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == '0.0/0.0'

# Generated at 2022-06-22 15:54:11.982522
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # test render for speed = None
    ratecolumn = RateColumn()
    assert str(ratecolumn.render('null')) == '? /s'
    assert str(ratecolumn.render('null', unit="b")) == '? b/s'
    assert str(ratecolumn.render('null', unit="byte")) == '? byte/s'
    assert str(ratecolumn.render('null', unit="bytes")) == '? bytes/s'

    # test render for speed != None
    ratecolumn = RateColumn(unit_scale=False)
    assert str(ratecolumn.render('0.0025', unit="b")) == '0.00 /s'
    assert str(ratecolumn.render('0.0125', unit="b")) == '0.01 /s'

# Generated at 2022-06-22 15:54:13.255582
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=0) as pbar:
        pass
    pbar.close()

# Generated at 2022-06-22 15:54:16.020303
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    from tqdm.utils import _term_move_up
    with tqdm_rich(range(2)) as t:
        t.update()
        t.close()
    time.sleep(1)
    try:
        _term_move_up()
    except:
        pass

# Generated at 2022-06-22 15:54:20.237557
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _x in tqdm_rich(range(10)):
        pass

if __name__ == "__main__":
    test_tqdm_rich_clear()

# Generated at 2022-06-22 15:54:26.141200
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=10)
    t.close()

# Generated at 2022-06-22 15:54:32.342250
# Unit test for method render of class RateColumn

# Generated at 2022-06-22 15:54:43.559579
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import rich.console
    import unittest
    console = rich.console.Console()
    def render(self, task):
        console.print(self.render(task))
    render(FractionColumn(), Progress(total=0))
    unittest.TestCase().assertEqual(render(FractionColumn(), Progress(total=0)).__repr__(), "0.0/0.0")
    unittest.TestCase().assertEqual(render(FractionColumn(unit_scale=True), Progress(total=2)).__repr__(), "0.0/2.0")
    unittest.TestCase().assertEqual(render(FractionColumn(unit_scale=True), Progress(total=1024)).__repr__(), "0.0/1.0 K")

# Generated at 2022-06-22 15:54:52.096754
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = dict()
    task["speed"] = 1000.0
    task["unit"] = "M"
    #
    r = RateColumn()
    s = r.render(task)
    assert s.text == "1,000.0 M/s"
    assert s.style == "progress.data.speed"
    #
    r = RateColumn(unit="b")
    s = r.render(task)
    assert s.text == "1,000.0 Mb/s"
    assert s.style == "progress.data.speed"

# Generated at 2022-06-22 15:54:57.149926
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import _supports_unicode
    from .utils import _range
    from .utils import format_sizeof
    from .utils import human_size
    from rich.progress import Console
    from rich.text import Text
    from rich.console import ConsoleOptions
    import math as _math
    # Progress instances
    console = Console(console_options=ConsoleOptions(legacy_windows=True))
    progress_unit1 = Progress(
        Text("[progress.description]{task.description}", justify='right'),
        "[progress.percentage]{task.percentage:3.0f}%",
        "",
        FractionColumn(unit_scale=False, unit_divisor=1000),
        BarColumn(bar_width=None),
        "",
        TimeRemainingColumn(),
    )
    progress_unit2

# Generated at 2022-06-22 15:55:07.280887
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit='B', unit_scale=True).render(Progress(total=1000, completed=2000)) == Text('2.0 MB/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True, unit_divisor=1024).render(Progress(total=1000, completed=2000)) == Text('2.0 MiB/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=False).render(Progress(total=1000, completed=2000)) == Text('2.0 B/s', style='progress.data.speed')



# Generated at 2022-06-22 15:55:20.002085
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        from rich.progress import BarColumn, Progress, TimeElapsedColumn, TimeRemainingColumn

    except ImportError:
        return

    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"
    )

# Generated at 2022-06-22 15:55:26.780214
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import os
    t = tqdm_rich(total=1000, desc="Expected: 1001|1002", leave=False,
                  bar_format="{desc}{percentage:>4.0f}%")
    for i in t:
        a = os.getppid()
        if i == 1001:
            raise KeyboardInterrupt()
    t.close()

# Generated at 2022-06-22 15:55:29.028400
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.clear()

# Generated at 2022-06-22 15:55:40.714991
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    r.render(Task(speed=1024, completed=None, total=None, desc=None))
    assert r.render(Task(speed=1024, completed=None, total=None, desc=None)).text == "1.0 K/s"
    assert r.render(Task(speed=1024, completed=None, total=None, desc=None)).style == "progress.data.speed"
    r.render(Task(speed=1, completed=None, total=None, desc=None))
    assert r.render(Task(speed=1, completed=None, total=None, desc=None)).text == "1.0 /s"

# Generated at 2022-06-22 15:55:59.614528
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecol = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    text = ratecol.render(object)
    assert text == Text("0.0 /s", style="progress.data.speed")

    ratecol = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    text = ratecol.render(object)
    assert text == Text("0.0 /s", style="progress.data.speed")

    class object:
        def __init__(self):
            self.speed = 1000

    ratecol = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    text = ratecol.render(object())
    assert text == Text("1.0 /s", style="progress.data.speed")


# Generated at 2022-06-22 15:56:09.573555
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from tqdm.rich.progress import EmptyProgress
    from tqdm.auto import trange
    progress = EmptyProgress()
    for i in trange(10):
        progress.add_task("progress", remaining=i)
        completed = 10 - i
        for j in range(1, 100):
            total = i + j
            task = progress.get_task("progress")
            task.completed = completed
            task.total = total
            fc = FractionColumn()
            actual = fc.render(task)
            expected = f'{completed/total:.1%}'
            assert actual.text == expected, f'{actual.text} != {expected}'

# Generated at 2022-06-22 15:56:21.909328
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm as _tqdm
    from .std import trange as _trange
    with _tqdm(total=100) as bar:
        for i in _range(100):
            bar.update()
        bar.reset(total=10)
        for i in _range(10):
            bar.update()
    with _trange(10) as bar:
        for i in _range(10):
            bar.update()
        bar.reset(total=100)
        for i in _range(100):
            bar.update()
    with _tqdm(total=100) as bar:
        for i in _range(100):
            bar.update()
        bar.reset()
        for i in _range(100):
            bar.update()

# Generated at 2022-06-22 15:56:34.039390
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    d = std_tqdm(total=100)
    fc = FractionColumn()
    assert fc.render(d) == Text("0.0/1.0", style="progress.download")
    d.update(50)
    assert fc.render(d) == Text("0.5/1.0", style="progress.download")
    d.update(0)
    assert fc.render(d) == Text("0.5/1.0", style="progress.download")
    d.update(5)
    assert fc.render(d) == Text("0.5/1.1", style="progress.download")
    d.update(5)
    assert fc.render(d) == Text("1.0/1.1", style="progress.download")
    d.update(999)
   

# Generated at 2022-06-22 15:56:46.591048
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress = FractionColumn()
    assert progress.render({"completed": 300, "total" : 1000}) == Text(
        "300.0/1000 0")
    assert progress.render({"completed": 300, "total" : 2000}) == Text(
        "150.0/2000 0K")
    assert progress.render({"completed": 300, "total" : 3000}) == Text(
        "0.3/3.0 0M")
    assert progress.render({"completed": 300, "total" : 4000}) == Text(
        "0.3/4.0 0M")
    assert progress.render({"completed": 301, "total" : 4000}) == Text(
        "0.3/4.0 0M")
    assert progress.render({"completed": 3010, "total" : 4000}) == Text

# Generated at 2022-06-22 15:56:51.839915
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .tqdm import trange
    with trange(99) as t:
        for i in t:
            if i == 10:
                t.reset()
                t.reset(total=3)
            elif i == 15:
                t.reset()
                t.reset(total=100)
                t.reset(total=None)
            elif i == 20:
                t.reset(total=300)

# Generated at 2022-06-22 15:56:54.743293
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import sys
    try:
        tqdm_rich(file=sys.stdout)
    except AttributeError:
        pass
    else:
        raise AssertionError("should not happen")

# Generated at 2022-06-22 15:56:56.207719
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm(total=2)
    t.clear()

# Generated at 2022-06-22 15:57:02.398008
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test that the method tqdm.rich.tqdm.reset() works.

    See issue: https://github.com/tqdm/tqdm/issues/1258
    """
    # To remove the task (and thus the progress bar) at the end
    with tqdm_rich(total=10) as pbar:
        task = pbar._task_id
        # To test the reset works at the beginning
        pbar.reset(total=20)
        for _ in pbar:
            # When reached 50% of the progress bar, reset the total to 20
            # to have a new progress bar with the same current progress
            if pbar.n >= 10:
                pbar.reset(total=20)
        pbar._prog.remove_task(task)
        # To test the reset works at the end

# Generated at 2022-06-22 15:57:13.927706
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    import gc
    from rich.console import Console

    console = Console()
    # First init and close
    with tqdm_rich(total = 2) as pbar1:
        pbar1.update()
        time.sleep(0.2)
        pbar1.update()
    assert bool(pbar1._prog) == True
    # Next init, but don't use dispose
    with tqdm_rich(total = 2) as pbar2:
        pbar2.update()
        time.sleep(0.2)
        pbar2.update()
    assert bool(pbar2._prog) == True
    # Next init, but dispose
    with tqdm_rich(total = 2) as pbar3:
        pbar3.update()

# Generated at 2022-06-22 15:57:34.112034
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """"""
    tqdm_rich = tqdm_rich(['a','b','c','d','e','f','g'])
    tqdm_rich.miniters = 1
    task = tqdm_rich.__enter__()
    tqdm_rich.n = 1000000
    task.n = 1000000
    tqdm_rich.total = 1000000
    task.total = 1000000
    tqdm_rich.start_t = 1580404052.333782
    tqdm_rich.last_print_t = 1580404052.333782
    tqdm_rich.miniters = 1
    task.miniters = 1
    tqdm_rich.update()


# Generated at 2022-06-22 15:57:41.991168
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .std import trange
    from .std import _range
    # Reset based on total
    my_tqdm_obj = tqdm(range(5))
    my_tqdm_obj.reset(total=100)
    assert my_tqdm_obj.total == 100
    assert my_tqdm_obj._last_print_n == 0
    assert my_tqdm_obj._n == 0
    assert my_tqdm_obj._n_iter is None
    # Reset based on n
    my_tqdm_obj = tqdm(range(5))
    my_tqdm_obj.reset(n=100)
    assert my_tqdm_obj.total == 105

# Generated at 2022-06-22 15:57:52.507048
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        import rich

        def _test_tqdm_rich_display():
            bar = tqdm_rich(total=2)
            bar.display()
            bar.n = 1
            bar.display()
            bar.close()

        if rich.__version__ >= '1.0.0':  # pragma: no cover
            _test_tqdm_rich_display()
        else:  # pragma: no cover
            # rich<1.0.0 does not have a ProgressColumn base
            raise ImportError()
    except ImportError:  # pragma: no cover
        from unittest.case import SkipTest
        raise SkipTest('rich is not installed')

# Generated at 2022-06-22 15:57:55.372045
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    rate = rate_column.render(0)
    assert rate == "? B/s"

# Generated at 2022-06-22 15:58:05.968932
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit='G').render(tqdm(total=100, unit='B',
                                     unit_scale=True, unit_divisor=1024)) == Text('0.0 G/s', style='progress.data.speed')
    assert RateColumn(unit='G').render(tqdm(total=100, unit='B',
                                     unit_scale=True, unit_divisor=1000)) == Text('0.0 G/s', style='progress.data.speed')
    assert RateColumn(unit='G').render(tqdm(total=100, unit='B',
                                     unit_scale=False, unit_divisor=1000)) == Text('0.0 G/s', style='progress.data.speed')

# Generated at 2022-06-22 15:58:08.813368
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(10)
    for _ in t:
        t.display()

# Generated at 2022-06-22 15:58:19.695481
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich.progress
    import test_tqdm

    is_pypy = hasattr(test_tqdm, 'is_pypy') and test_tqdm.is_pypy
    unit_scale = not is_pypy
    with tqdm(total=100, unit_scale=unit_scale) as t:
        for i in range(100):
            t.update()
        first_bar = t.format_dict
        t.reset(total=200)
        for i in range(200):
            t.update()
        second_bar = t.format_dict
    assert first_bar['n'] == 100
    assert first_bar['total'] == 100
    assert first_bar['n_fmt'] == '100'
    assert second_bar['n'] == 200
    assert second_

# Generated at 2022-06-22 15:58:21.308450
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=100) as t:
        t.reset(total=200)
        assert t.total == 200

# Generated at 2022-06-22 15:58:32.985175
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm_rich(range(10000)):
        pass
    tqdm_rich.reset(total=1000000)
    for i in tqdm_rich(range(1000000)):
        pass


if __name__ == '__main__':
    """
    Examples

    >>> from tqdm.rich import trange
    >>> for i in trange(20, desc='1st loop'):
    ...     for j in trange(10, desc='2nd loop', leave=False):
    ...         for k in trange(100, desc='3nd loop', leave=False):
    ...             pass
    """

# Generated at 2022-06-22 15:58:36.608777
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress as RichProgress
    import pytest

    with pytest.raises(AttributeError):
        tqdm_rich(range(100))

    with pytest.raises(AttributeError):
        tqdm_rich(range(100)).clear()

    with pytest.raises(AttributeError):
        tqdm_rich(range(100)).close()

    with pytest.raises(AttributeError):
        tqdm_rich(range(100)).reset()

    t = tqdm_rich(range(100))
    t.display()
    assert isinstance(t._prog, RichProgress)



# Generated at 2022-06-22 15:58:57.768624
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .utils import tgrange

    # Unittest for tqdm_rich.display()
    for _ in tqdm(tgrange(100, display=False), desc="testing display"):
        pass
    assert tqdm.gui.n == 100
    assert tqdm.gui.desc == "testing display"

# Generated at 2022-06-22 15:58:59.584327
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn("B")
    rate_column.render("Task", rate_column)



# Generated at 2022-06-22 15:59:02.648720
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=100, desc='Test_tqdm_rich_display') as pbar:
        for i in _range(100):
            pbar.display()
            pbar.n = i

# Generated at 2022-06-22 15:59:12.103472
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B").render(None) == Text(f"? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=100).render(None) == Text(f"? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(None) == Text(f"? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(None) == Text(f"? B/s", style="progress.data.speed")

# Generated at 2022-06-22 15:59:22.403031
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .utils import _range
    from .std import tqdm
    from .rich.progress import Progress
    from .rich.console import Console
    
    class RateColumn(ProgressColumn):
        def __init__(self, unit="", unit_scale=False, unit_divisor=1000):
            self.unit = unit
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super().__init__()
        def render(self, task):
            """Show data transfer speed."""
            speed = task.speed
            if speed is None:
                return Text(f"? {self.unit}/s", style="progress.data.speed")

# Generated at 2022-06-22 15:59:27.523604
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Minimalist test to ensure that display() doesn't crash, rather
    # than trying to test the _prog's output.
    t = tqdm_rich(total=10)
    t.n = 5
    t.refresh()
    t.n = 6
    t.refresh()
    t.close()
    assert t.n == 6



# Generated at 2022-06-22 15:59:37.686290
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    import pytest
    from rich.progress import Progress
    from rich.text import Text

    #initial value when total = None
    with pytest.raises(TypeError):
        progress_bar = Progress(
            Text('Loading...', style='progress.label'),
            BarColumn(bar_width=None),
            Text(style='progress.time'),
        )
        progress_bar.add_task('test1', total=None)
        time.sleep(3)

    #reset total value
    with pytest.raises(TypeError):
        progress_bar = Progress(
            Text('Loading...', style='progress.label'),
            BarColumn(bar_width=None),
            Text(style='progress.time'),
        )
        progress_bar.add_task('test1', total=100)

# Generated at 2022-06-22 15:59:41.307941
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm(range(100), desc="foo", unit="b", unit_scale=True,
              leave=True, dynamic_ncols=True) as t:
        pass

# Generated at 2022-06-22 15:59:45.534278
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm import trange, tqdm_gui  # noqa
    import random
    random.seed(0)
    total = 100
    with trange(total) as pbar:
        for _ in pbar:
            # There will be a half chance of resetting the progress bar
            if random.random() > 0.5:
                pbar.reset(total=total)

# Generated at 2022-06-22 15:59:47.670010
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm_rich constructor."""
    assert tqdm(total=2)

# Generated at 2022-06-22 16:00:26.168718
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    >>> rate1 = 100000
    >>> RateColumn(unit='/s').render(rate1)
    '100.0 K/s'
    >>> RateColumn(unit='/s', unit_scale=True).render(rate1)
    '100.0 K/s'
    >>> rate2 = 100000000
    >>> RateColumn(unit='/s').render(rate2)
    '100.0 M/s'
    >>> RateColumn(unit='/s', unit_scale=True).render(rate2)
    '100.0 M/s'
    """

# Generated at 2022-06-22 16:00:28.260467
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    t = tqdm(total=9)
    t.n = 11
    t.display()

# Generated at 2022-06-22 16:00:30.747264
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=2, unit="it")
    with t:
        t.display()
        t.update(1)

# Generated at 2022-06-22 16:00:40.935548
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(8, 8)) == Text(
        '1.0/1.0 ', style='progress.download')
    assert FractionColumn(unit_divisor=1024).render(Progress(4000, 8000)) == Text(
        '3.9/7.8 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(
        Progress(4000, 8000)) == Text('3.9/7.8 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(
        Progress(30000, 80000)) == Text(
            '30.0/80.0 M', style='progress.download')

# Generated at 2022-06-22 16:00:45.027202
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    j = 0
    for i in range(10):
        j += 1
        s = rc.render(j)
        assert s == "1.0 /s"

# Generated at 2022-06-22 16:00:56.633485
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    progress = (
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        RateColumn(unit="B", unit_scale=False, unit_divisor=1000),
    )

# Generated at 2022-06-22 16:00:57.555942
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pass


# Generated at 2022-06-22 16:01:06.029901
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress.Task(
        title="Loading",
        completed=20.0,
        total=100.0,
        start_time=1557137519.424839,
        end_time=None,
        description="Loading...",
        children=[
            Progress.Task(
                title="Loading",
                completed=10.0,
                total=50.0,
                start_time=1557137519.4253418,
                end_time=None,
                description="Loading...",
                children=[]
            )
        ]
    )
    # without unit_scale
    column = FractionColumn()
    result = column.render(task)
    assert result.text == '20.0/100.0 '
    # with unit_scale
    column = FractionColumn(unit_scale=True)

# Generated at 2022-06-22 16:01:14.917039
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pandas as pd
    import pandas._testing as pt
    from datetime import timedelta

    start_time = pd.Timestamp('2 days ago').to_pydatetime()
    end_time = pd.Timestamp('now').to_pydatetime()
    duration = end_time - start_time

    rate_column = RateColumn()

    speed = rate_column.render(std_tqdm.__dict__['FormatCustomTextBase']
                               .__dict__['_get_speed']
                               (timedelta(minutes=duration.total_seconds()),
                                1000000)).text
    expected_speed = '1.0 M/s'
    pt.assert_equal(speed,expected_speed)


# Generated at 2022-06-22 16:01:19.400504
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    with tqdm(total=2.3*1000, unit_scale=True, unit_divisor=1000) as t:
        for i in range(2300):
            t.update(1)
            if i == 2300:
                t.close()
                break



# Generated at 2022-06-22 16:03:32.204787
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit_scale=True).render(tqdm_rich(total=10, unit='b')) == Text(f"0    B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True).render(tqdm_rich(total=100, unit='b')) == Text(f"0    B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True).render(tqdm_rich(total=1000, unit='b')) == Text(f"0    B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True).render(tqdm_rich(total=10000, unit='b')) == Text(f"0    B/s", style="progress.data.speed")