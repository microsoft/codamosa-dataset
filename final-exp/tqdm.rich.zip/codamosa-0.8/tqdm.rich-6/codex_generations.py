

# Generated at 2022-06-22 15:53:49.401284
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import re
    import rich.progress
    import rich.table
    
    class _Task(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
        def __repr__(self):
            return repr((self.completed, self.total))
        def __str__(self):
            return str((self.completed, self.total))
    
    task = _Task(0.1, 0.2)
    f = rich.progress.ProgressColumn()
    result = re.sub(r'\s+', '', str(f.render(task)))
    assert result == '0.1/0.2', \
        f'not equal: \n expected: 0.1/0.2\n actual: {result}'
    

# Generated at 2022-06-22 15:54:01.282226
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(
        std_tqdm(total=None, unit_scale=False, unit_divisor=1000, disable=True)).text == "? /s"
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(
        std_tqdm(total=1024, unit_scale=False, unit_divisor=1000, disable=True)).text == "1.0 KB/s"
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(
        std_tqdm(total=1025, unit_scale=False, unit_divisor=1000, disable=True)).text == "1.0 KB/s"
    assert RateColumn

# Generated at 2022-06-22 15:54:03.155684
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(range(1,11))
    t.close()

# Generated at 2022-06-22 15:54:10.408440
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.console import Console
    console = Console(isatty=True)
    with console.progress() as progress:
        task = progress.add_task(description='abc')
    progress.update(task, completed=0, description='def')
    progress.update(task, completed=0)
    progress.update(task, description='ghi')
    progress.remove_task(task)
    progress.add_task(description='jkl')
    progress.update(task, completed=0)



# Generated at 2022-06-22 15:54:13.680313
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    for _ in tqdm_rich(["a", "b", "c"], desc="Foo"):
        pass

# Generated at 2022-06-22 15:54:19.627802
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    tqdm_rich should close the progress bar and all its tasks when
    tqdm_rich.close() is called.
    """
    tqdm_instance = tqdm_rich(total=10)
    tqdm_instance.close()
    assert tqdm_instance._prog._closed

# Generated at 2022-06-22 15:54:24.343064
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import io
    import sys
    out = io.StringIO()
    ttr = tqdm_rich(
        ['1', '2', '3'],
        file=out,
        dynamic_ncols=True,
        disable=False
    )
    ttr.__enter__()

    # just in case
    ttr.clear()
    ttr.clear()

    ttr.close()
    out.close()

# Generated at 2022-06-22 15:54:31.116557
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time

    with tqdm_rich(total=10) as t:
        t.reset()
        t.reset(5)
        for i in range(5):
            time.sleep(0.2)
            t.update()
            if i == 4:
                assert t.n == 5
        t.reset(3)
        for i in range(3):
            time.sleep(0.2)
            t.update()
            if i == 2:
                assert t.n == 3

# Generated at 2022-06-22 15:54:32.899560
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """ Test method close of class tqdm_rich """
    t = tqdm_rich(total=100)
    t.disable = True
    t.close()
    assert t.disable == True


# Generated at 2022-06-22 15:54:36.691475
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(10) as t:
        t.close()
    with tqdm_rich(10) as t:
        t.disable = True
        t.close()

if __name__ == '__main__':
    test_tqdm_rich_close()

# Generated at 2022-06-22 15:54:48.416866
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [default for default in range(10,20)]:
        unit_scale = True
        unit_divisor = 1000
        scale_factor = 1000

        task = tqdm_rich(total=total, unit_scale=unit_scale, unit_divisor=unit_divisor)
        task_scale = task.format_dict['unit_scale']
        task_divisor = task.format_dict['unit_divisor']
        task_unit = task.format_dict['unit']
        task_prefix = task.format_dict['unit_divisor']

        assert(total/task_scale == task.total)
        assert(task_scale == scale_factor)

        description = 'Testing'
        title = 'Test'

# Generated at 2022-06-22 15:54:50.577562
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress()).text == "0 /0 "

# Generated at 2022-06-22 15:54:58.456941
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn(unit_scale=False, unit_divisor=1000)
    import unittest
    from rich.progress import Task

    class MockedTask(Task):
        def __init__(self):
            self._completed = 2
            self._total = 3
    t = MockedTask()

    class test_FractionColumn_render(unittest.TestCase):
        def test_FractionColumn_render(self):
            self.assertEqual(f"{f.render(t)}", "1/1.5 ")

    unittest.main()


# Generated at 2022-06-22 15:55:00.112614
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich.close()
    assert tqdm_rich.close()


# Generated at 2022-06-22 15:55:02.512068
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm(total=1)
    t.close()

# Generated at 2022-06-22 15:55:08.645378
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    p = Progress("Rich Progress", transient=False)
    p.__enter__()
    task_id = p.add_task("Test Task", total=99)
    p.update(task_id, completed=42, description="Rich Progress")

    p.update(task_id, completed=85, description="Rich Progress")

    p.__exit__(None, None, None)

# Generated at 2022-06-22 15:55:11.059336
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(0)):
        pass


# Generated at 2022-06-22 15:55:15.338925
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    rich_progress = tqdm(total=4, ascii=True, desc='testing')
    for i in range(4):
        rich_progress.display(i, 4, 'testing')
    rich_progress.close()

# Generated at 2022-06-22 15:55:20.723703
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    tr = trange(5)
    tr.reset(total=10)
    assert tr.total == 10
    tr.reset(10)
    assert tr.total == 10
    tr.reset()
    assert tr.total is None
    for i in tr: pass

# Generated at 2022-06-22 15:55:23.186019
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    pbar = tqdm_rich(total=2)
    pbar.close()



# Generated at 2022-06-22 15:55:29.755266
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .utils import _range as range

    with tqdm(total=10000) as t:
        for i in range(10000):
            if i > 9000:
                t.total = 100000
            t.update()

# Generated at 2022-06-22 15:55:34.906342
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    task = _range(10)
    assert column.render(task) == Text("? /s", style="progress.data.speed")
    task.update(5)
    assert column.render(task) == Text("5.0 /s", style="progress.data.speed")

# Generated at 2022-06-22 15:55:40.620523
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from rich.progress import Progress
    from rich.console import Console
    from rich.traceback import install
    install()
    progress = Progress()
    progress.start()
    task_id = progress.add_task("Init", start=0, total=100)
    task_id2 = progress.add_task("Init2", start=0, total=100)
    progress.update(task_id, description="Init OK!")
    progress.update(task_id, completed=50)
    progress.update(task_id, completed=100)
    progress.update(task_id2, completed=100)
    progress.stop()
    console = Console()
    console.print("1111")
    console.print("2222")
    console.print("3333")

# Generated at 2022-06-22 15:55:47.718858
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import random

    total = 100
    with tqdm_rich(total=total) as t:
        for i in range(total):
            if random.uniform(0, 1) < 0.1:
                old_total = t.total
                t.reset(random.uniform(0, 100))
                assert(t.total == old_total)
                t.reset()
            t.update()

# Generated at 2022-06-22 15:55:55.505327
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print('test_RateColumn_render:')
    unitstr = 'B'
    speed = 100*1024
    u, suffix = filesize.pick_unit_and_suffix(speed, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], 1000)
    prec = 0
    if u == 1:
        prec = 1
    print(f"{speed/u:,.{prec}f} {suffix}{unitstr}/s")
    return


# Generated at 2022-06-22 15:56:03.602623
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rcl = RateColumn("B")
    assert rcl.render(None).ansi() == "300.0 B/s"
    assert rcl.render("a").ansi() is None
    rcl = RateColumn("B", unit_scale=True)
    assert rcl.render(None).ansi() == "0.3 KB/s"
    rcl = RateColumn("B", unit_scale=True, unit_divisor=1024)
    assert rcl.render(None).ansi() == "293.0 B/s"
    rcl = RateColumn("", unit_scale=True, unit_divisor=1024)
    assert rcl.render(None).ansi() == "0.3 K/s"
    rcl = RateColumn("s", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 15:56:12.883910
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(total=1024)
    col = FractionColumn()
    # check if unit_scale=False
    assert col.render(task) == Text('0/1 K', style='progress.download')
    task.update(512)
    assert col.render(task) == Text('0.5/1 K', style='progress.download')
    task.close()
    task = tqdm_rich(total=1024, unit_scale=True)
    # check if unit_scale=True
    assert col.render(task) == Text('0/1 K', style='progress.download')
    task.update(512)
    assert col.render(task) == Text('0.5/1 K', style='progress.download')
    task.close()

# Generated at 2022-06-22 15:56:18.266572
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    l = [1, 2, 3, 4, 5]
    # 1) First run
    for x in tqdm_rich(l):
        x ** 2

    # 2) Second run: reset was called
    for x in tqdm_rich(l):
        x ** 2

# Generated at 2022-06-22 15:56:22.289079
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        for i in range(5):
            t.update()
        t.reset(total=5)
        for i in range(5):
            t.update()
    assert t.n == 5

# Generated at 2022-06-22 15:56:28.841695
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    progress = tqdm_rich(range(30))
    progress.reset(total=10)
    progress.reset(total=100)
    progress.reset(total=None)
    progress.reset(total=100)
    progress.reset(total=200)
    progress.reset(total=10)
    progress.reset(total=100)
    progress.reset(total=100)
    progress.reset(total=None)

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_rich_reset()

# Generated at 2022-06-22 15:56:50.879545
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Setup and call default tqdm
    _ = tqdm(total=2, disable=True)
    _ = tqdm(total=2, disable=True, gui=True)

    # Setup and call tqdm with gui and custom progress bar
    _ = tqdm(total=2, disable=True, gui=True,
             progress=(
                 "[progress.description]{task.description}"
                 "[progress.percentage]{task.percentage:>4.0f}%",
                 BarColumn(bar_width=None),
                 FractionColumn(
                     unit_scale=False, unit_divisor=1000),
                 "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
                 ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
             ))
   

# Generated at 2022-06-22 15:56:58.887348
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm as std_tqdm
    from .gui import tqdm as gui_tqdm

    n = 23450
    n_iters = 4
    progress_bar = tqdm_rich(total=n, desc='testing')
    progress_bar.reset(total=n * n_iters)
    for i in range(n_iters):
        for _ in progress_bar:
            pass
        progress_bar.reset()
    progress_bar.close()

    n = 23450
    n_iters = 4
    progress_bar = std_tqdm(total=n, desc='testing')
    progress_bar.reset(total=n * n_iters)
    for i in range(n_iters):
        for _ in progress_bar:
            pass
        progress_

# Generated at 2022-06-22 15:57:04.722817
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    d = {'task': {'completed': 200, 'total': 300}}
    c = FractionColumn()
    c.render(d['task']) == "200/300"
    c = FractionColumn(unit_scale=True, unit_divisor=1000)
    c.render(d['task']) == "0.2/0.3"

# Generated at 2022-06-22 15:57:10.357647
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    t = tqdm_rich(range(10))
    for i in t:
        time.sleep(0.001)
    t.close()
    for i in trange(10):
        pass

if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-22 15:57:15.833412
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Tests tqdm_rich constructor"""
    import time
    import random
    time.sleep(1)
    t = tqdm(list(range(100)), desc="Example")
    for i in t:
        time.sleep(0.1)
        t.set_postfix(foo=random.randint(0, 10), bar=random.randint(0, 10))

# Generated at 2022-06-22 15:57:18.651724
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm_rich(total=10) as pbar:
        pass
    pbar.reset()
    pbar.reset(total=1e6)

# Generated at 2022-06-22 15:57:25.233293
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import TqdmTypeError
    from .utils import format_sizeof
    from .utils import format_interval
    from rich.progress import BarColumn
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from tqdm.rich import tqdm
    from tqdm.rich import tqdm_rich
    with tqdm_rich(total=100, desc='Testing', position=0) as pbar:
        assert (pbar.pos == 0)
        assert (isinstance(pbar, tqdm_rich))
        assert (isinstance(pbar.bar_format, Progress))

# Generated at 2022-06-22 15:57:34.018463
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Dummy progress bar
    try:
        with tqdm_rich(total=100, disable=False) as pbar:
            # Reset the progress bar to a total of 1000
            pbar.reset(1000)
            # Reset the progress bar to a total of 10000
            pbar.reset(10000)
            # Check whether the progress bar is still running
            assert pbar.disable is False
    except:
        print("Test failed!")
        raise


# Generated at 2022-06-22 15:57:36.576380
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=10) as t:
        assert t.total == 10
        t.reset(total=20)
        assert t.total == 20

# Generated at 2022-06-22 15:57:41.863429
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tc = RateColumn()
    assert tc.render(0) == Text("? /s", style="progress.data.speed")
    tc = RateColumn(unit="h")
    assert tc.render(0) == Text("? h/s", style="progress.data.speed")
    tc = RateColumn(unit_scale=True)
    assert tc.render(1000**3) == Text("1.0 G/s", style="progress.data.speed")
    assert tc.render(1000**4) == Text("1.0 T/s", style="progress.data.speed")


# Generated at 2022-06-22 15:58:01.366659
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(0, 100)
    task.completed = 0
    result = RateColumn().render(task)
    assert result.text == "0.0 /s"
    task.completed = 10
    result = RateColumn().render(task)
    assert result.text == "10.0 /s"
    task.completed = 100
    result = RateColumn().render(task)
    assert result.text == "100.0 /s"
    task.completed = 1000
    result = RateColumn().render(task)
    assert result.text == "1000.0 /s"
    task.completed = 100000
    result = RateColumn().render(task)
    assert result.text == "100.0 K/s"
    task.completed = 1000000
    result = RateColumn().render(task)

# Generated at 2022-06-22 15:58:14.001813
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(task=None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(task=None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1024).render(task=None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(task=None) == Text("? B/s", style="progress.data.speed")


# Generated at 2022-06-22 15:58:22.562312
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    column = FractionColumn()
    task = Task(20, 100)
    assert column.render(task) == Text('0.2/1 G', style='progress.download')
    task = Task(20, 1234)
    assert column.render(task) == Text('0.0/1.2 K', style='progress.download')
    task = Task(20, 1.234)
    assert column.render(task) == Text('20.0/1.2 ', style='progress.download')
    task = Task(0, 1234567)
    assert column.render(task) == Text('0.0/1.2 M', style='progress.download')


# Generated at 2022-06-22 15:58:33.723428
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Unit tests for `tqdm.rich.tqdm_rich()`."""
    from time import sleep
    # test positional arguments
    ret = tqdm_rich(['a', 'b', 'c'])
    ret.__enter__()
    assert hasattr(ret, '_prog')
    assert getattr(ret, '_prog') is not None
    assert ret._task_id == 0  # task id
    sleep(0.2)  # let progressbar render
    assert ret.n == 0  # counter
    assert ret.total == 3  # total
    ret.update()
    ret.update()
    ret.update()
    ret.close()
    assert ret.n == 3  # counter
    # test keyword arguments: disable=True
    ret = tqdm

# Generated at 2022-06-22 15:58:45.999257
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from .pandas import tqdm_pandas
    print("tqdm_rich:")
    # with tqdm_rich(total=100) as pbar:
    #     for i in pbar:
    #         time.sleep(0.01)
    for _ in tqdm_rich(total=100):
        time.sleep(0.01)
    # with tqdm_rich(total=100, position=0) as pbar:
    #     for i in pbar:
    #         time.sleep(0.01)
    #     pbar.set_description("Processing")
    #     for i in range(100, 200):
    #         time.sleep(0.01)
    #         pbar.update(1)
    #     pbar.set_description("

# Generated at 2022-06-22 15:58:52.195750
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=100) as pbar:
        for i in range(100):
            pbar.update(1)
    pbar.reset()
    assert pbar.n == 0
    assert pbar.total == 100
    pbar.reset(5)
    assert pbar.total == 5
    assert pbar.n == 0
    pbar.reset(total=6)
    assert pbar.total == 6
    assert pbar.n == 0
    pbar.reset(0)
    assert pbar.total == 0
    assert pbar.n == 0

# Generated at 2022-06-22 15:58:57.100171
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    unit_scale = True
    unit_divisor = 1000
    column = FractionColumn(unit_scale, unit_divisor)
    column.render(Progress.Task(completed=1234567890, total=9876543210))
    column.render(Progress.Task(completed=1234567890, total=0))
    column.render(Progress.Task(completed=1234567890, total=1234567890))

# Generated at 2022-06-22 15:59:07.675100
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from doctest import ELLIPSIS
    from rich.progress import Progress
    from .utils import TestTqdm, temp_file
    progress = Progress()
    progress.__enter__()
    task = progress.add_task('Test', total=100, completed=50)
    col = FractionColumn()
    result = col.render(task)
    assert result == Text('50/100', style='progress.download')
    with temp_file() as f:
        f.write(b'X' * 1000000)
        f.flush()
        task = progress.add_task('Test', total=100, completed=50)
        result = col.render(task)
        assert result == Text('50/100 ', style='progress.download')

# Generated at 2022-06-22 15:59:09.013357
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    at = RateColumn(unit="b")
    assert at.render(1) == "1.0 b/s"

# Generated at 2022-06-22 15:59:13.755342
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich's display method"""
    # This function was automatically added by bbtqdm_rich.
    # It is not expected to be modified by end-users

    # Imports
    import numpy as np

    # Init the widget
    widget = tqdm_rich()
    widget.reset(total=10)

    # Fake loop
    for i in range(10):
        widget.update(n=i+1)

    # Test that display() does nothing
    widget.display()

# Generated at 2022-06-22 15:59:45.213124
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        iterator = tqdm_rich(range(10))
        assert iterator.disable is False
        assert iterator.n is 0
        iterator.display()

    finally:
        iterator.close()

# Generated at 2022-06-22 15:59:51.768893
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os
    import curses

    with tqdm(total=1, disable=True) as t:
        t.update(1)
        assert os.getenv('TERM') == 'dumb'

    with tqdm(total=1, disable=False) as t:
        t.update(1)
        assert os.getenv('TERM') != 'dumb'
        assert curses.is_term_resized() == 0

# Generated at 2022-06-22 16:00:00.161881
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm_stdout_redirected
    from .utils import func_name
    from tqdm.auto import tqdm

    with tqdm_stdout_redirected():
        for i in tqdm(range(5)):
            pass

    with tqdm_stdout_redirected():
        for i in tqdm(range(5), ascii=True):
            pass

    tqdm([1, 2, 3], desc=func_name(), total=3, ascii=True, bar_format="abc")
    tqdm([1, 2, 3], desc=func_name(), total=3, ascii=True, bar_format="abc{percentage:3.0f}%")

# Generated at 2022-06-22 16:00:06.796059
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm.contrib.tests._test_tqdm import progressbar

    progressbar.reset(total=100)
    progressbar.set_description('test')
    for i in progressbar:
        time.sleep(0.02)
    progressbar.set_description('test 2')
    progressbar.reset(total=100)
    for i in progressbar:
        time.sleep(0.02)

# Generated at 2022-06-22 16:00:10.754276
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Clear display
    progress = tqdm_rich(total=100, desc="Test tqdm_rich display")
    progress.refresh()

    # Display progress bar
    progress.refresh()

    # Finish progress bar
    progress.close()

# Generated at 2022-06-22 16:00:22.419789
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from unittest import TestCase
    from random import randint
    from rich.progress import Progress
    from rich.progress import StepCount
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn
    from rich.text import Text

    def fun(data):
        out = str(data)
        while len(out) < 6:
            out = " " + out
        return out[:6]

    class Test_FractionColumn(TestCase):
        def test_render(self):
            task = Progress.create_task(
                description="Test",
                total=100,
                completed=randint(0, 101)
            )
            fraction

# Generated at 2022-06-22 16:00:27.968629
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    obj = RateColumn()
    assert obj.render(None) == Text("? /s", style="progress.data.speed")
    assert obj.render(None) != Text("? K/s", style="progress.data.speed")
    assert obj.render(None) != Text("? M/s", style="progress.data.speed")
    assert obj.render(None) != Text("? G/s", style="progress.data.speed")
    assert obj.render(None) != Text("? T/s", style="progress.data.speed")
    assert obj.render(None) != Text("? P/s", style="progress.data.speed")
    assert obj.render(None) != Text("? E/s", style="progress.data.speed")

# Generated at 2022-06-22 16:00:39.205268
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.text import Text
    import copy
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        rate_column = RateColumn()
        rate_column_unit = RateColumn(unit="/m")
        task = std_tqdm(total=1)
        task.set_postfix_str("speed: 5 Mb/s")
        task.set_description("Task description")
        task.n = 1
        task.refresh()
        expected = Text("5.0 MB/s", style="progress.data.speed")
        assert rate_column.render(task) == expected
        assert copy.copy(rate_column).render(task) == expected
        assert copy.deepcopy(rate_column).render(task) == expected

# Generated at 2022-06-22 16:00:50.529275
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm_gui  # pragma: no cover
    from .utils import FormatTransferSize
    iterable = ['1', '2', '3', '4', '5']

    d = dict()
    for unit_scale in [True, False]:
        for unit_divisor in [1000, 1024]:
            for unit in ['/s', 'B/s']:
                for bar_format in [None, '{l_bar}{bar}{r_bar}{bar_desc}']:
                    d["unit_scale"] = unit_scale
                    d["unit_divisor"] = unit_divisor
                    d["unit"] = unit
                    d["bar_format"] = bar_format
                    d["total"] = len(iterable)
                    d["bar_format"] = bar_format
                    d["desc"]

# Generated at 2022-06-22 16:01:01.543464
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Unit test for method display of class tqdm_rich

    """
    # import libraries
    import inspect
    import unittest

    # set variables
    num_of_args_in_display_of_tqdm_rich_class = len(inspect.signature(tqdm_rich.display).parameters)

    # create class
    class TestTqdmRichDisplay(unittest.TestCase):
        """
        Class to test the method `display` of class `tqdm_rich` in the `tqdm` package.

        """
        def setUp(self):
            """
            Set up test fixture for `test_num_of_args_in_display_of_tqdm_rich_class`

            """
            return


# Generated at 2022-06-22 16:02:32.927539
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console

    console = Console()
    progress = Progress(console=console)
    task = progress.add_task(total=1000)

    for _ in range(10):
        progress.update(task, completed=10)
        fraction_column = FractionColumn()
        fraction_column.render(task)

    for _ in range(100):
        progress.update(task, completed=100)
        fraction_column = FractionColumn(unit_divisor=1000)
        fraction_column.render(task)

    for _ in range(1000):
        progress.update(task, completed=1000)
        fraction_column = FractionColumn(unit_divisor=100)
        fraction_column.render(task)


# Generated at 2022-06-22 16:02:40.964149
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=0)) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000)) == Text("1.00 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000000)) == Text("1,000.00 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000000000)) == Text("1,000,000.00 /s", style="progress.data.speed")


# Generated at 2022-06-22 16:02:52.068828
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich display method"""
    from .test_tqdm import pretest_posttest

    def test_main():
        """Main test function"""
        from .test_tqdm import closing, TqdmDeprecationWarning

        @closing
        def inner(*args, **kwargs):
            """Inner test function"""
            progress_rich = tqdm_rich(total=42, miniters=5,
                                      mininterval=0.2,
                                      desc="desc",
                                      leave=True)
            try:
                progress_rich.display()
            except Exception as exc:
                raise Exception(
                    "Custom display failed because of an unknown failure: "
                    "{0}".format(str(exc)))

        inner()


# Generated at 2022-06-22 16:03:02.359179
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # test invalid speed
    progress_obj = tqdm(total=100)
    ratecolumn = RateColumn()
    assert ratecolumn.render(progress_obj) == "? /s"
    progress_obj.close()

    # test zero speed
    progress_obj = tqdm(total=100, desc='download')
    ratecolumn = RateColumn()
    assert ratecolumn.render(progress_obj) == "0.0  /s"
    progress_obj.close()

    # test valid speed
    progress_obj = tqdm(total=100, desc='download')
    ratecolumn = RateColumn()
    progress_obj.update(1)
    assert ratecolumn.render(progress_obj) == "100.0  /s"
    progress_obj.close()

# Generated at 2022-06-22 16:03:05.587261
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    tc = Text("0.0/0.0")
    assert fc.render(tc) == fc.column



# Generated at 2022-06-22 16:03:12.908718
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test reset method of class tqdm_rich"""
    with tqdm_rich(total=100) as t:
        t.update(100)
        assert t.n == 100
        t.reset()
        assert t.n == 0
    with tqdm_rich(total=100) as t:
        t.reset(50)
        assert t.n == 0
        assert t.total == 50

# Generated at 2022-06-22 16:03:23.044518
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    from .std import tnrange, tqdm_notebook

    for t in trange(2):
        for desc, T in zip(
                ['foo', 'bar'], [tnrange, tqdm_notebook]):
            with T(10, desc=desc) as t:
                for _ in t:
                    # Reset the total
                    if t.n == 5:
                        t.reset(total=20)
                    # Reset the description
                    if t.n == 15:
                        t.reset(
                            total=30, desc='foobar',
                            dynamic_ncols=True, smoothing=1.0)
                        # Reset the smoothing
                        t.reset(smoothing=0.7)

# Generated at 2022-06-22 16:03:32.999623
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_cases = [
        (1, 1, None, "1.0/1.0  ", "progress.download"),
        (2, 3, None, "2.0/3.0  ", "progress.download"),
        (2, 3, True, "2.0/3.0  ", "progress.download"),
        (2048.0, 20000000, True, "2.0/20.0M", "progress.download"),
        (2048.0, 2097152, True, "2.0/2.1M  ", "progress.download"),
    ]
    for completed, total, unit_scale, expected_text, expected_style in test_cases:
        column = FractionColumn(unit_scale=unit_scale)
        task = Progress(total=total)

# Generated at 2022-06-22 16:03:36.247039
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    progress = Progress()
    progress.__enter__()
    task_id = progress.add_task("", total=1000, position=0)
    progress.update(task_id, completed=1000, description="")
    progress.__exit__(None, None, None)

# Generated at 2022-06-22 16:03:44.432571
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task = Progress()
    test_task._completed = 2
    test_task.total = 4
    column = FractionColumn()
    assert column.render(test_task) == Text(
        "0.5/1.0",
        style=None
    )
    column.unit_scale = True
    assert column.render(test_task) == Text(
        "0.5/1.0 ",
        style="progress.download"
    )
    test_task.total = 2000
    assert column.render(test_task) == Text(
        "0.5/2.0 K",
        style="progress.download"
    )
    test_task.total = 1000000000000