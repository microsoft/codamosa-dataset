

# Generated at 2022-06-22 15:53:35.319070
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test of method `reset` of class `tqdm_rich`.
    """
    import math

    _range_ = _range(100)

    with tqdm_rich(_range_, total=100) as t:
        assert t.total == len(_range_) == 100

        t.reset()
        assert t.total == len(_range_) == 100

        t.reset(total=50)
        assert t.total == 50



# Generated at 2022-06-22 15:53:38.429866
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    obj = tqdm_rich(total=100)
    obj.clear()
    obj.display()
    for i in range(10):
        obj.update(10)
        time.sleep(0.1)
    obj.close()

# Generated at 2022-06-22 15:53:42.910321
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.console import Console
    from rich.progress import TaskID
    # TqdmTestCase's progress is done!
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]")
    console = Console()
    tqdm_rich_task_id = TaskID('[progress.description]{task.description}[progress.percentage]{task.percentage:>4.0f}%',
                               BarColumn(bar_width=None), FractionColumn(),
                               '[', TimeElapsedColumn(), '<', TimeRemainingColumn(), ']')
    tqdm_

# Generated at 2022-06-22 15:53:50.332922
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import unittest
    from io import StringIO
    from os import sys
    class TestTqdmRichDisplay(unittest.TestCase):
        def test_display_not_called_on_falseish_add(self):
            with self.mock_stdout() as mock_stdout:
                with tqdm_rich(total=0) as t:
                    t.display = self.fail()
                    t.update(0)
                    t.update(total=0)
            self.assertEqual(mock_stdout.getvalue(), '')

        def test_display_called_on_truthy_add(self):
            with self.mock_stdout() as mock_stdout:
                with tqdm_rich(total=0) as t:
                    t.display = self.assertTrue
                    t

# Generated at 2022-06-22 15:53:53.778848
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    col = FractionColumn()
    task = ProgressColumn.Task(1, 1)
    assert col.render(task) == Text('1/1 ', style='progress.download')


# Generated at 2022-06-22 15:54:05.997269
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import TaskID

    console = Console()
    progress = Progress()
    progress.__enter__()
    task_id = progress.add_task("My Task")

    def descriptor(task: TaskID):
        assert task is not None and task.description == "My Task"

    progress.add_renderable(FractionColumn(), descriptor)
    progress.update(task_id, completed=5)

    tqdm_rich(total=5, initial=5)
    tqdm_rich(total=5, initial=5, disable=False)
    tqdm_rich(total=5, initial=5, disable=True)
    tqdm_rich(total=5, initial=5, disable=False, unit_scale=True, unit_divisor=1000)
    t

# Generated at 2022-06-22 15:54:11.552907
# Unit test for method render of class RateColumn
def test_RateColumn_render():
	print("Unit test for method render of class RateColumn in tqdm_rich.py")
	print(RateColumn(unit='bytes/s').render(Progress()))
	print(RateColumn(unit='bytes/s', unit_scale=True).render(Progress()))
	print(RateColumn(unit='bytes/s', unit_scale=True, unit_divisor=1024).render(Progress()))
	print("***")


# Generated at 2022-06-22 15:54:15.087018
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(10) as t:
        for _ in t:
            pass
    with tqdm_rich(10) as t:
        t.update()



# Generated at 2022-06-22 15:54:19.780521
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from types import MethodType
    tr = tqdm_rich(total=10, desc="Loading...", leave=True)
    assert tr.display == MethodType(tqdm_rich.display, tr)

# Generated at 2022-06-22 15:54:31.499979
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import rich.console
    from .utils import _decode_preferred_encoding
    from .pandas import tqdm_pandas as tqdm
    console = rich.console.Console()
    if 'stdout' not in console.get_console_handles():  # pragma: no cover
        console.print(_decode_preferred_encoding(
            "\n".join(["Note: pyarrow was not installed. No parallel",
                       "      computation will be available for pandas",
                       "      or dask."])))
    with console.progress() as progress:
        progress.add_task("Test tqdm_rich")
        try:
            for i in tqdm(range(10)):
                assert i
        except BaseException:
            pass
        progress.update(1)

# Generated at 2022-06-22 15:54:48.655949
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    with tqdm(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(1)
    with tqdm(total=100) as pbar:
        for i in range(50):
            sleep(0.1)
            pbar.update(1)
        pbar.reset(total=200)
        for i in range(100):
            sleep(0.1)
            pbar.update(1)
        pbar.reset(total=200)
        for i in range(100):
            sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-22 15:54:54.577904
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # method coverage
    p = FractionColumn()
    task_1 = Progress(total=0)
    p.render(task_1)

    task_2 = Progress(total=10)
    p.render(task_2)
    task_2.completed = 5
    p.render(task_2)


# Generated at 2022-06-22 15:54:56.138732
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    assert(rate.render(Progress(total=100)) == Text(
        "0.0 /s", style="progress.data.speed"))

# Generated at 2022-06-22 15:54:59.026885
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    progress = tqdm(_range(10), gui=True)
    progress.display()
    del progress
    progress = tqdm(_range(10), gui=True)
    progress.display()
    del progress

# Generated at 2022-06-22 15:55:04.703310
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = rich.progress.ProgressTestTask()
    task.completed = 1024
    task.total = 2097152
    task.speed = 1
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert column.render(task) == '[progress.download]0.000/2.097 K'
    column = FractionColumn(unit_scale=False, unit_divisor=1024)
    assert column.render(task) == '[progress.download]0.000/2.000 KB'
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column.render(task) == '[progress.download]0.000/2.097 K'
    column = FractionColumn(unit_scale=True, unit_divisor=1024)
   

# Generated at 2022-06-22 15:55:17.818469
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task_1 = Progress(None, 50, 100, speed=100)
    task_2 = Progress(None, 50, 100, speed=1000)
    task_3 = Progress(None, 50, 100, speed=1000000)
    task_4 = Progress(None, 50, 100, speed=1000000000)
    task_5 = Progress(None, 50, 100, speed=1000000000000)
    task_6 = Progress(None, 50, 100, speed=1000000000000000)
    task_7 = Progress(None, 50, 100, speed=1000000000000000000)
    task_8 = Progress(None, 50, 100, speed=None)
    task_9 = Progress(None, 0, 100, speed=1000000)


# Generated at 2022-06-22 15:55:25.757753
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    """
    Unit test for method reset of class tqdm_rich.
    """
    from .gui import tnrange
    rng = tnrange(5, desc='test')
    assert rng._prog.completed == 0
    assert rng._prog.total == 5
    rng.reset(total=10)
    assert rng._prog.completed == 0
    assert rng._prog.total == 10

# Generated at 2022-06-22 15:55:37.038263
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(total=123456)).text \
        == "0.0/123.5 K"
    assert FractionColumn(unit_scale=False).render(Progress(total=123456)).text \
        == "0.0/123456.0 "
    assert FractionColumn(unit_scale=True).render(Progress(total=1234)).text \
        == "0.0/1.2 K"
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(
            Progress(total=1024)).text == "0.0/1.0 K"
    assert FractionColumn(unit_scale=False, unit_divisor=1024).render(
            Progress(total=1024)).text == "0.0/1024.0 "

# Generated at 2022-06-22 15:55:41.762700
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    assert rc.render(None).text == "? /s"
    assert rc.render(None).style == "progress.data.speed"
    assert rc.render(object).text == "? /s"
    assert rc.render(object).style == "progress.data.speed"

# Generated at 2022-06-22 15:55:53.873797
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import pytest
    from rich.progress import Progress, Text
    from rich.console import Console
    console = Console()
    progress = Progress(Text("", style="progress.value"), transient=True)
    task_id = progress.add_task("Test")
    with progress:
        tq = tqdm_rich.__init__(total=100, desc="Test", _prog=progress, _task_id=task_id, console=console)
        for i in _range(20):
            tqdm_rich.display(n=i)
        progress.update(task_id, completed=20, description="OtherTest")
        for i in _range(20, 40):
            tqdm_rich.display(n=i)
        progress.update(task_id, completed=40, description="")
        tqrm

# Generated at 2022-06-22 15:56:22.334249
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .std import tqdm_gui as std_tqdm_gui
    from .std import tgrange as std_tgrange
    from .utils import test_python_kwargs_nested_inner, test_python_kwargs_nested_outter

    _test_python_kwargs_inner = {
        'bar_format': '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
    }
    _test_python_kwargs_inner.update(test_python_kwargs_nested_inner)


# Generated at 2022-06-22 15:56:34.077315
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=100)
    task.update(1)
    rc = RateColumn(unit="Mb")
    assert rc.render(task) == Text(f"{1.0:,.0f} Mb/s", style="progress.data.speed")
    task.update(10)
    assert rc.render(task) == Text(f"{10.0/1000:,.1f} Kb/s", style="progress.data.speed")
    # On Python 2, we cannot set speed to 0.
    if not hasattr(__builtins__, 'xrange'):
        task.update(0)
        assert rc.render(task) == Text(f"0 Mb/s", style="progress.data.speed")
    task.close()

# Generated at 2022-06-22 15:56:46.479132
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from .std import tqdm
    from .utils import string_type
    from .utils import _environ_cols_wrapper

    with tqdm(total=10) as pbar, _environ_cols_wrapper():
        for i in range(10):
            time.sleep(1)
            pbar.update()

        assert pbar.total == 10
        assert pbar.last_print_n != pbar.n
        assert len(pbar.format_dict) == 3
        assert pbar.format_dict['rate'] == '?'
        assert isinstance(pbar.format_interval, string_type)
        assert pbar.format_dict['desc'] == ''
        assert pbar.format_dict['rate_noinv'] == ''

# Generated at 2022-06-22 15:56:48.314688
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=2) as pbar:
        pbar.clear()

# Generated at 2022-06-22 15:56:56.882969
# Unit test for method render of class FractionColumn

# Generated at 2022-06-22 15:57:01.068832
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.console import Console
    console = Console()
    with console.redirect_stdout():
        rt = tqdm_rich([], console=console, bar_format='{bar}')
        rt.update()
        rt.close()
        assert rt.disable is True

        rt = tqdm_rich(range(10), console=console, bar_format='{bar}')
        rt.update()
        rt.close()
        assert rt.disable is True

# Generated at 2022-06-22 15:57:13.140936
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.console import Console
    console = Console()
    column = FractionColumn()
    # test unit_scale = False
    assert column.render(column.task_class(0, 100)) == \
        "[progress.download]0/100"
    assert column.render(column.task_class(100, 100)) == \
        "[progress.download]1/1"
    assert column.render(column.task_class(1000, 100)) == \
        "[progress.download]10/1"
    # test unit_scale = True, unit_divisor = 1000
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column.render(column.task_class(0, 100)) == \
        "[progress.download]0/100"

# Generated at 2022-06-22 15:57:19.015239
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Returns
    -------
    None.

    """
    t = tqdm(total = 1000, unit = "b", unit_scale = True, unit_divisor = 1000, leave = False)
    for i in range(1000):
        t.update()

    t = tqdm(total = 1000, leave = False)
    for i in range(1000):
        t.update()



# Generated at 2022-06-22 15:57:25.309414
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test render method of class RateColumn."""
    # Test function RateColumn.render(self, task)
    # Initialize task and RateColumn
    task = std_tqdm()
    task.speed = None
    RateColumn()
    RateColumn(unit="/s")
    RateColumn(unit="/s", unit_scale=True)
    RateColumn(unit="/s", unit_scale=True, unit_divisor=1024)
    RateColumn(unit_scale=True, unit_divisor=1024)
    return



# Generated at 2022-06-22 15:57:30.029077
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=1)
    try:
        t.clear()
    except Exception:
        assert False
    finally:
        t.close()