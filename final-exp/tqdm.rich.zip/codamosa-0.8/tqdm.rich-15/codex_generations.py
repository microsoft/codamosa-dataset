

# Generated at 2022-06-22 15:53:49.832902
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    import rich
    import rich.progress
    import rich.table

    rich.progress._fix_table()


# Generated at 2022-06-22 15:53:54.395417
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests import _test_tqdm_rich_deprecated_kwarg
    _test_tqdm_rich_deprecated_kwarg(tqdm_rich)
    from .tests import _test_tqdm_rich
    _test_tqdm_rich(tqdm_rich)

# Generated at 2022-06-22 15:54:06.667588
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Check that FractionColumn render method works
    with unit_scale = False and unit_scale = True.
    """
    task = Progress(total=1000)
    frac = FractionColumn()
    fr = frac.render(task)
    assert (fr.text == '0.0/1.0 '), "FractionColumn render method must \
                                     return '0.0/1.0 ' in unit_scale = False"
    frac = FractionColumn(unit_scale=True)
    fr = frac.render(task)
    assert (fr.text == '0.0/1.0 '), "FractionColumn render method must \
                                     return '0.0/1.0 ' in unit_scale = True"
    task = Progress(total=1000)
    frac = FractionColumn()

# Generated at 2022-06-22 15:54:13.142303
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tqdm
    from .standard import tqdm as std_tqdm

    for t in [tqdm, std_tqdm]:
        for total in [None, 200, 1000, 100000]:
            for leave in [True, False]:
                pbar = t(total=total, leave=leave)
                for i in pbar:
                    break
                pbar.reset(total=total)
                pbar.reset(total=total//2)
                pbar.reset()
                pbar.reset(total=total)
                pbar.reset(total=None)
                pbar.close()

# Generated at 2022-06-22 15:54:23.365167
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method `render` of class `RateColumn`.
    """
    # arg1: speed, arg2: unit
    # Expects that the unit followed by a slash and an "s".
    units = ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB", "YiB"]
    for i, unit in enumerate(units):
        speed = pow(2, i)
        rate_column = RateColumn(unit=unit,
                                 unit_scale=True,
                                 unit_divisor=1024)
        assert (rate_column.render(speed) == f"{speed} {unit}/s")

# Generated at 2022-06-22 15:54:28.529008
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import RateColumn
    from rich.progress import Task

    rateColumn = RateColumn()
    task = Task("test_task")
    task.speed = 3
    assert rateColumn.render(task) == "[progress.data.speed]3.0 B/s"


# Generated at 2022-06-22 15:54:36.334847
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    for unit_scale in [True, False]:
        for unit_divisor in [100, 1000]:
            f = FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)

# Generated at 2022-06-22 15:54:46.828768
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from os import linesep

    for __ in tqdm([1], desc="ttt"):
        pass

    for __ in tqdm([1], desc="ttt", bar_format="{desc}{bar}"):
        pass

    for __ in tqdm([1], desc="ttt", bar_format="{desc}{bar}",
                   postfix={"desc": "aaa"}):
        pass

    for __ in tqdm([1], desc="ttt", bar_format="{desc}{bar}",
                   postfix=[{"desc": "aaa"}]):
        pass

    for __ in tqdm([1], bar_format="{desc}{bar}{percentage}{r_bar}",
                   bar_template='{desc}{bar}{postfix}',
                   postfix=[{"data": "aaa"}]):
        pass

   

# Generated at 2022-06-22 15:54:57.042888
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import os
    assert os.environ.get('TEST_TQDM_RICH_RESET', '').lower() == 'true'
    from .std import tqdm as std_tqdm  # will use the correct tqdm
    from .gui import tqdm_gui as tqdm_gui  # will use the correct tqdm
    for t in [std_tqdm, tqdm_gui]:
        r = t.trange(10, desc='outer')
        r.reset(total=5)
        r.reset(total=10)
        with r:
            for i in t.trange(10, desc='inner'):
                r.reset(total=20)
                r.reset(total=10)

# Generated at 2022-06-22 15:55:00.229722
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test tqdm.rich.tqdm_rich.clear() doesn't raise AttributeError.
    """
    t = tqdm_rich(total=2)
    t.close()

# Generated at 2022-06-22 15:55:17.186540
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """This test compares the results of the method render of class FractionColumn."""
    class MockedTask:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    task = MockedTask(completed=3.14, total=1.59)
    out = FractionColumn().render(task)
    assert out.content == '3.14/1.59 '

    task = MockedTask(completed=16384, total=8192)
    out = FractionColumn(unit_scale=True, unit_divisor=1000).render(task)
    assert out.content == '16.384/8.192 K'

    task = MockedTask(completed=10000000, total=1000000)

# Generated at 2022-06-22 15:55:22.978959
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Initialize a tqdm_rich object and call reset method with no argument.
    Check whether the initial value of the tqdm_rich object is equal to the
    end value.
    """
    with tqdm(total=100) as t:
        for i in range(100):
            t.update()
        t.reset()
        assert t.n == 0

# Generated at 2022-06-22 15:55:34.971925
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import tqdm.rich as tqdmrich
    from unittest.case import TestCase

    class Test_FractionColumn_render(TestCase):
        def test_basic(self):
            total = 100
            column = tqdmrich.FractionColumn(unit_scale=False)
            task = tqdmrich.Progress()
            task.total = total
            for i in range(total):
                task.completed = i + 1
                rendered_str = column.render(task)
                self.assertEqual(rendered_str.text, f"{i + 1}/{total}")

        def test_unitscale_unitdivisor1000(self):
            total = 10100
            column = tqdmrich.FractionColumn(unit_scale=True, unit_divisor=1000)
            task = t

# Generated at 2022-06-22 15:55:44.542401
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.table import Column, Table

    console = Console()
    task = TaskID()
    task.total = 123456789
    task.completed = 123456
    task.start()
    # print fraction with unit
    fraction_unit_scale_true = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fraction_unit_scale_true.render(task) == console.render(Text(
        "117.6/117.5K"))
    fraction_unit_2digit_scale_true = FractionColumn(unit_scale=True, unit_divisor=1000)
    task.total = 123456789
    task.completed = 61728
    assert fraction_unit_2digit_scale_true.render

# Generated at 2022-06-22 15:55:54.057868
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display by setting/incrementing n and getting/checking value"""
    pbar = tqdm_rich(0)
    assert not hasattr(pbar, '_prog')

    pbar = tqdm_rich(1)
    assert hasattr(pbar, '_prog')

    pbar.n = 0
    pbar.display()
    assert pbar._prog.completed(pbar._task_id) == 0

    pbar.n = 1
    pbar.display()
    assert pbar._prog.completed(pbar._task_id) == 1

# Generated at 2022-06-22 15:56:02.711683
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = tqdm.RateColumn(unit_divisor=1000, unit_scale=True)
    assert progress.render(12345) == Text('12.3 K/s', style='progress.data.speed')
    assert progress.render(12345670000) == Text('12.3 G/s', style='progress.data.speed')
    assert progress.render(123456700000000) == Text('12.3 T/s', style='progress.data.speed')
    assert progress.render(123456700000000000) == Text('12.3 P/s', style='progress.data.speed')
    assert progress.render(123456700000000000000) == Text('12.3 E/s', style='progress.data.speed')

# Generated at 2022-06-22 15:56:07.067342
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm import trange

    for i in trange(1):
        pass

    for _ in trange(3, desc='Test 1'):  # Constructor with initial total
        pass

    t = trange(3, desc='Test 2')  # Constructor without initial total
    for _ in t:
        pass

    for _ in trange(5, desc='Test 3'):  # reset with "total"
        pass

    trange(7, desc='Test 4')  # reset without "total"

# Generated at 2022-06-22 15:56:12.505306
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    total = 10
    my_tqdm = tqdm_rich(total=total)
    for j in my_tqdm:
        my_tqdm.reset(total=total)
        my_tqdm.n = total
        my_tqdm.update()
        my_tqdm.reset(total=total)
        my_tqdm.reset()
        my_tqdm.n = total
        my_tqdm.update()

# Generated at 2022-06-22 15:56:24.325264
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import TaskID
    from rich.console import Console
    from io import StringIO
    import sys
    out = StringIO()
    console = Console(file=out)
    task = TaskID("test", console, total=100)
    task.completed = 10
    fracCol = FractionColumn()
    assert fracCol.render(task) == "10.0/100.0 "
    task = TaskID("test", console, total=999)
    task.completed = 10
    assert fracCol.render(task) == "10.0/999.0 "
    task = TaskID("test", console, total=1000)
    task.completed = 10
    assert fracCol.render(task) == "10.0/1.0 K"

# Generated at 2022-06-22 15:56:30.388329
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    n = 100
    with tqdm(total=n) as pbar:
        for i in _range(n):
            pbar.display()
            assert pbar.n == i + 1
            pbar.clear()

# Generated at 2022-06-22 15:56:45.606397
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task1 = Progress()
    task1.completed = 10
    task1.total = 100
    task2 = Progress()
    task2.completed = 2000000
    task2.total = 100
    fraction_column = FractionColumn()
    assert fraction_column.render(task1).text == '0.1/1.0'
    assert fraction_column.render(task2).text == '2.0/100.0 K'



# Generated at 2022-06-22 15:56:46.933372
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich.clear()

# Generated at 2022-06-22 15:56:50.069922
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10) as t:
        t.clear()

if __name__ == '__main__':
    test_tqdm_rich_clear()

# Generated at 2022-06-22 15:56:58.279900
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    assert rate.render(23) == Text("23.0 /s", style="progress.data.speed")
    rate = RateColumn(unit_scale=True)
    assert rate.render(23) == Text("23.0 /s", style="progress.data.speed")
    rate = RateColumn(unit_scale=True, unit="bit")
    assert rate.render(23) == Text("23.0 /s", style="progress.data.speed")
    rate = RateColumn(unit_scale=False, unit="bit")
    assert rate.render(23) == Text("23.0 bit/s", style="progress.data.speed")

    class Task:
        completed = 0
        total = 256
        speed = 128

    rate = RateColumn(unit_scale=True)

# Generated at 2022-06-22 15:57:10.260480
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from rich import box

    task_id = TaskID('foo', completed=1, total=7)
    progress = Progress(
        '[progress.description]{task.description}',
        '[progress.percentage]{task.percentage:>4.0f}%',
        BarColumn(bar_width=None), '[', TimeElapsedColumn(), ',',
        RateColumn(unit='/s', unit_scale=True, unit_divisor=1), ']',
        transient=True)
    progress.__enter__()
    task_id = progress.add_task('foo', completed=1, total=7)
    value = RateColumn(unit='/s', unit_scale=True, unit_divisor=1).render(
        progress.tasks[task_id])

# Generated at 2022-06-22 15:57:12.686853
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100, leave=True) as pbar:
        for _ in range(100):
            pbar.update(1)

# Generated at 2022-06-22 15:57:22.839331
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich import progress
    # Case 1: unit_scale = False, unit_divisor = 1000
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    task = progress.Task(progress=None, completed=50, total=200)
    assert column.render(task) == Text("0.2/0.5", style="progress.download")
    task = progress.Task(progress=None, completed=500, total=2000)
    assert column.render(task) == Text("0.2/0.5", style="progress.download")
    task = progress.Task(progress=None, completed=50, total=2000)
    assert column.render(task) == Text("0.025/0.5", style="progress.download")

# Generated at 2022-06-22 15:57:26.713492
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    a = RateColumn()
    assert a.render(tqdm_rich(total=5)) == Text("? /s", style="progress.data.speed")
    assert a.render(tqdm_rich(total=5, unit='x')) == Text("? x/s", style="progress.data.speed")

# Generated at 2022-06-22 15:57:38.907521
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.markdown import Markdown
    import time

    console = Console()
    progress = Progress(Markdown("# My Progress"), transient=False, console=console)
    task_id = progress.add_task("My Task", start=0, total=100)
    progress.__enter__()
    progress.update(task_id, completed=20)

    time.sleep(1)
    progress.update(task_id, description="My Task (with percentage)", completed=40)
    time.sleep(1)
    progress.update(task_id, completed=60)
    time.sleep(1)
    progress.update(task_id, completed=80)
    time.sleep(1)
    progress.update(task_id, completed=100)

   

# Generated at 2022-06-22 15:57:52.037499
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
      from rich.progress import BarColumn, Progress, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn, filesize
      from .std import TqdmExperimentalWarning, tqdm as std_tqdm
      from .utils import _range
      from .import tqdm_rich, trrange, tqdm, trange
      __author__ = {"github.com/": ["casperdcl"]}
      from .std import TqdmExperimentalWarning, tqdm as std_tqdm
      from .utils import _range
      from .import tqdm_rich, trrange, tqdm, trange
      __author__ = {"github.com/": ["casperdcl"]}
      def close(self):
        if self.disable:
          return
        super(tqdm_rich, self).close()
       

# Generated at 2022-06-22 15:58:15.451734
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import rich.console
    console = rich.console.Console()
    task = Progress.create_task("task")
    task.speed=200
    task.completed=200
    task.total=200
    task._invalidated=True
    task._columns=None
    col = RateColumn(unit="GiB")
    console.print(col.render(task))


# Generated at 2022-06-22 15:58:18.772287
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    x = tqdm_rich()
    x.clear()
    x.close()
    y = tqdm_rich(disable=True)
    y.clear()
    y.close()

# Generated at 2022-06-22 15:58:20.866063
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1) as progressbar:
        progressbar.clear()

# Generated at 2022-06-22 15:58:32.734935
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .std import tqdm, PY2
    from .utils import _range, format_interval, format_meter
    from .std import unicode

    d = tqdm(["a", "b", "c", "d"])
    if PY2:  # Python 2 needs __repr__ (not __str__)
        assert str(d) == repr(d)
    else:
        assert unicode(d) == repr(d)
    assert str(d)

    format_interval(5.505050001)
    format_meter(5.505050001, 5)

    d = tqdm(total=1)
    assert len(d) == 1

    d = tqdm(total=1)
    d.clear()
    assert len(d) == 0

    d = tq

# Generated at 2022-06-22 15:58:35.322089
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    x = tqdm(range(10))
    for i in range(10):
        x.display(n=i)
        assert x.n == i

# Generated at 2022-06-22 15:58:36.934599
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(10) as t:
        for _ in t:
            t.clear()
            pass

# Generated at 2022-06-22 15:58:45.004641
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = trange(15, desc="Downloading")
    task.update(3)
    assert isinstance(task._prog.task_columns[-1][-1], RateColumn)
    method_render = task._prog.task_columns[-1][-1].render(task)
    assert isinstance(method_render.text, str)
    assert isinstance(method_render.style, str)
    task.close()


# Generated at 2022-06-22 15:58:46.602666
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as _:
        pass

# Generated at 2022-06-22 15:58:47.862208
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(10) as bar:
        for i in bar:
            bar.reset(total=5)
            for j in bar:
                bar.reset()
                for k in bar:
                    pass

# Generated at 2022-06-22 15:58:54.203808
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=100, unit='B', unit_scale=False, unit_divisor=1000)
    task.update(50)
    rate = RateColumn()
    assert rate.render(task) == Text("50.0 B/s", style="progress.data.speed")
    rate = RateColumn(unit="B", unit_scale=False)
    assert rate.render(task) == Text("50.0 B/s", style="progress.data.speed")
    task.total = 1000
    assert rate.render(task) == Text("50.0 KB/s", style="progress.data.speed")
    task.n = 500
    task.total = 5000
    rate = RateColumn(unit_scale=False, unit_divisor=1024)

# Generated at 2022-06-22 15:59:26.688146
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    """
    >>> tqdm.write = lambda x: x
    >>> with trange(10) as t:
    ...     for i in t:
    ...         t.display()
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-22 15:59:30.540695
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=10)
    t.reset(total=20)
    t.update(10)
    assert t.n == 10
    assert t.total == 20
    t.update()
    assert t.n == 11

# Generated at 2022-06-22 15:59:36.766677
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich('test', total=1)
    task.update(0)
    rate = RateColumn(unit_scale=False)
    assert rate.render(task) == Text("? /s", style="progress.data.speed")
    task.update(1)
    rate = RateColumn(unit_scale=False)
    assert rate.render(task) == Text("1.00 /s", style="progress.data.speed")
    task.close()


# Generated at 2022-06-22 15:59:42.898930
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    # Example of the method
    rateColumn = RateColumn()
    # Return an instance of rich.Progress
    class task_(object):
        """docstring for ClassName"""
        completed = 10
        total = 1000
        speed = 200
    progress = task_()
    assert rateColumn.render(progress) == Text("200.0 /s", style="progress.data.speed")

# Generated at 2022-06-22 15:59:49.054861
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    # create a tqdm_rich object with total 2
    progress_bar = tqdm_rich(total=2)
    # update it by 1
    progress_bar.update(1)
    # starts to show up till now
    time.sleep(2)
    # reset it to total=1
    progress_bar.reset(total=1)
    # update it by 1
    progress_bar.update(1)
    # reset it to total=3
    progress_bar.reset(total=3)
    # update it by 1
    progress_bar.update(1)
    # close the progress bar to show up till here
    progress_bar.close()

# Generated at 2022-06-22 15:59:54.619884
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress.current_task
    assert RateColumn(unit="B").render(task).text == "? B/s"


if __name__ == '__main__':  # pragma: no cover
    # Unit test for method render of class FractionColumn
    test_RateColumn_render()
    # Doctest
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 16:00:01.575541
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_col = RateColumn(unit='i')
    task = std_tqdm(total=10)
    task.set_description("Test")
    task.update(1)

    task.clear()
    task.display()
    assert rate_col.render(task) == Text("0 i/s", style="progress.data.speed")

    task.clear()
    task.display()
    assert rate_col.render(task) == Text("0 i/s", style="progress.data.speed")

    task.clear()
    task.display()
    assert rate_col.render(task) == Text("0 i/s", style="progress.data.speed")

    task.set_postfix_str("foo", refresh=True)

# Generated at 2022-06-22 16:00:06.625051
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    try:
        import rich
    except ImportError:
        return
    else:
        for i in tqdm(range(3)):
            for j in tqdm(range(5), nested=True):
                pass

# Generated at 2022-06-22 16:00:08.361456
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    a = tqdm_rich(range(10))
    a.display()

# Generated at 2022-06-22 16:00:19.366760
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pandas as pd
    df_rate = pd.DataFrame(columns=['n', 'speed', 'n_expected', 'speed_expected'])
    df_rate.n = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]

# Generated at 2022-06-22 16:01:33.609940
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from io import BytesIO
    from re import search

    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]")
    file_handler = BytesIO()

    # reset without total
    with tqdm_rich(desc="1st iteration", progress=progress, file=file_handler) as i:
        i.reset()
        i.update(1)
        i.reset()
        i.update(0)
        i.update()

    file_handler.seek(0)
    contents = file_handler.read

# Generated at 2022-06-22 16:01:39.556411
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn(unit="b/s", unit_scale=True)
    assert rate.render(42) == "42.0 b/s"
    assert rate.render(1234) == "1.2 Kb/s"
    assert rate.render(1234567) == "1.2 Mb/s"
    assert rate.render(1234567890) == "1.2 Gb/s"
    assert rate.render(1234567890123) == "1.2 Tb/s"
    assert rate.render(1234567890123456) == "1.2 Pb/s"
    assert rate.render(1234567890123456789) == "1.2 Eb/s"

# Generated at 2022-06-22 16:01:48.746017
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=1, desc="describe test") as progress:
        progress.display()
        progress.update(0)
        progress.update(1)

    with tqdm_rich(leave=False, total=1, desc="describe test") as progress:
        progress.display()
        progress.update(0)
        progress.update(1)

    # disable not equal False
    with tqdm_rich(total=1, desc="describe test", disable=True) as progress:
        progress.display()
        progress.update(0)
        progress.update(1)

    with tqdm_rich(total=1, desc="describe test", disable=False) as progress:
        progress.display()
        progress.update(0)
        progress.update(1)

# Generated at 2022-06-22 16:01:53.713179
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from six.moves import range as xrange
    from rich.traceback import install

    install()
    for obj in [tqdm([1, 2]), tqdm(xrange(1))]:
        obj.reset(total=100)
        obj.close()


# Generated at 2022-06-22 16:02:01.205901
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    _tqdm_t = tqdm_rich(total=10)

# Generated at 2022-06-22 16:02:02.729990
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich display method."""
    raise NotImplementedError

# Generated at 2022-06-22 16:02:06.950766
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from .tests import pretest_posttest
    with pretest_posttest() as (out, _):
        t = tqdm_rich(range(5), total=5)
        t.reset(total=9)
        for i in t:
            pass
        t.close()
    assert out.getvalue().split('\r')[-2].strip() == "[100%] Done...\n"



# Generated at 2022-06-22 16:02:08.779916
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in range(2):
        with trange(10) as t:
            for i in t:
                t.set_description(f"{i+1}")
                t.reset(total=10+i)
                t.update()

# Generated at 2022-06-22 16:02:13.905295
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import warnings
    warnings.simplefilter('ignore', TqdmExperimentalWarning)
    with tqdm_rich(10, unit_scale=True, unit='B') as t:
        for i in t:
            if i == 5:
                t.reset(total=100)
            t.update()

# Generated at 2022-06-22 16:02:15.802223
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress()) == Text("? ", style="progress.data.speed")



# Generated at 2022-06-22 16:03:20.967992
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():

    # setup
    desc1, desc2 = "first", "second"
    total = 100
    sleep, sleep_unit = .01, "s"
    try:
        from time import monotonic as time
    except ImportError:  # pragma: no cover
        from time import time
    _time = time()

    # test
    with tqdm(total=100, desc=desc1, unit_scale=True) as pbar:
        for i in range(total):
            pbar.set_description(desc2)
            # pbar.display()  # wont work, see comment in display() method
            while time() - _time < sleep:  # synchronize with time display
                pass
            _time += sleep


test_tqdm_rich_display()

# Generated at 2022-06-22 16:03:23.374874
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(['a', 'b']) as t:
        t.update(1)
        t.update(1)

# Generated at 2022-06-22 16:03:24.925470
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm(total=1) as pbar:
        pbar.update()
        pbar.display()

# Generated at 2022-06-22 16:03:27.387728
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")



# Generated at 2022-06-22 16:03:37.673725
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for method reset of class tqdm_rich

    """
    from tqdm._tqdm import trange
    # Test numeric total
    with trange(10) as t:
        t.reset(100)
        assert int(t.total) == 100
    with trange(10) as t:
        t.reset(2)
        assert int(t.total) == 2
    # Test float total
    with trange(10) as t:
        t.reset(1.0)
        assert float(t.total) == 1.0
    with trange(10) as t:
        t.reset(0.2)
        assert float(t.total) == 0.2
    # Test string total
    with trange(10) as t:
        t.reset('20')
       