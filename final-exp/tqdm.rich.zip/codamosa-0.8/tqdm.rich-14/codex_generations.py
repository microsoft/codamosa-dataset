

# Generated at 2022-06-22 15:53:42.714406
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    import sys
    import io

    test_stdout = io.StringIO()
    test_stderr = io.StringIO()
    sys.stdout = test_stdout
    sys.stderr = test_stderr
    with tqdm_rich(range(10)) as pbar:
        for i in pbar:
            pass
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    assert(str(pbar)) == "0it [00:00, ?it/s]"
    assert(isinstance(pbar._prog, Progress))
    assert(repr(pbar._prog)) == '<Progress bar: (10 of 10)>'

# Generated at 2022-06-22 15:53:45.090312
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Method display of the class tqdm_rich
    t = tqdm_rich(total=1000, desc="testing rich")
    for _ in t:
        pass
    t = tqdm_rich(total=1000, desc="testing rich")
    for _ in t:
        t.display()

# Generated at 2022-06-22 15:53:47.917670
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        tqdm_bar = tqdm_rich(total=10)
        tqdm_bar.reset(total=20)
        assert tqdm_bar.total == 20
    finally:
        tqdm_bar.close()

# Generated at 2022-06-22 15:53:59.536875
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Tests for rich.progress tqdm."""
    from rich.progress import Progress

    for kwargs in ({}, dict(unit_scale=True)):
        with tqdm_rich(total=10, **kwargs) as pbar:
            assert isinstance(pbar._prog, Progress)
            assert pbar._prog.task_count == 1
            assert pbar.unit == 'it'

    with tqdm_rich(total=10, unit='foos') as pbar:
        assert isinstance(pbar._prog, Progress)
        assert pbar._prog.task_count == 1
        assert pbar.unit == 'foos'


# Generated at 2022-06-22 15:54:04.801836
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test that tqdm_rich.close() closes its progress bar.
    (i.e. it's not an alias).
    """
    p = tqdm_rich([])
    assert not p.disable  # otherwise the test is meaningless
    p.close()
    assert p.disable

# Generated at 2022-06-22 15:54:08.926265
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    sys.modules['time'] = __import__('tqdm.utils').time
    with tqdm(range(2), disable=True) as t:
        t.clear()
        assert t.total == 0

# Generated at 2022-06-22 15:54:16.100532
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    bar = tqdm_rich(total=100)
    for i in range(10):
        sleep(0.01)
        bar.update()
    bar.reset(total=200)
    for i in range(20):
        sleep(0.01)
        bar.update()

    assert bar.total == 200, "tqdm_rich resets total improperly"
    assert bar.n == 20, "tqdm_rich resets n improperly"

# Generated at 2022-06-22 15:54:23.522671
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.auto import trange
    import time
    import sys
    if sys.version_info >= (3, 3):  # pragma: no cover
        from contextlib import ExitStack
    else:  # pragma: no cover
        from contextlib2 import ExitStack

    # Ensure tqdm displays without error
    with ExitStack() as stack:
        stack.enter_context(tqdm_rich.context)
        for i in trange(2):
            time.sleep(0.0000000001)

# Generated at 2022-06-22 15:54:33.791409
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    assert  FractionColumn().render(Task(0, 0)) == '0.0/0.0'
    assert  FractionColumn().render(Task(2, 3)) == '2.0/3.0'
    assert  FractionColumn().render(Task(1234, 1234)) == '1234/1234'
    assert  FractionColumn().render(Task(1234, 5432)) == '1.2/5.4'
    assert  FractionColumn().render(Task(1, 2)) == '1.0/2.0'
    assert  FractionColumn().render(Task(10, 20)) == '1.0/2.0'
    assert  FractionColumn

# Generated at 2022-06-22 15:54:45.228200
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    x = tqdm_rich(range(10), disable=False)
    assert x.n == 0
    assert len(str(x)) >= 6
    assert len(str(x)) <= 8
    x.update()
    assert x.n == 1
    assert len(str(x)) >= 6
    assert len(str(x)) <= 8
    x.update(2)
    assert x.n == 3
    assert len(str(x)) >= 6
    assert len(str(x)) <= 8
    # Test that repeated calls to display are idempotent
    x.display()
    assert x.n == 3
    assert len(str(x)) >= 6
    assert len(str(x)) <= 8
    x.n = 1
    x.display()
    assert x.n == 1

# Generated at 2022-06-22 15:54:55.109847
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        tqdm_rich(total=1, desc="Test").display()
    except AttributeError:  # pragma: no cover
        # pylint: disable=unused-variable
        pass

# Generated at 2022-06-22 15:55:03.828607
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from random import randint
    class DummyTqdmRich(tqdm_rich):
        def __init__(self, *args, **kwargs):
            # Patch super class to work with `dummy` object
            super(DummyTqdmRich, self).__init__(*args, **kwargs)

        def display(self, *_, **__):
            self._prog.update(1, completed=randint(start=0, stop=self.total))

    dummy = DummyTqdmRich(total=100)
    assert dummy.disable is False
    dummy.display()
    assert dummy.disable is False
    dummy.close()
    assert dummy.disable is True



# Generated at 2022-06-22 15:55:06.547543
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in trange(0):
        pass

# Unit tests for method close of class tqdm_rich

# Generated at 2022-06-22 15:55:18.887503
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from unittest import mock
    except ImportError:
        try:
            import mock
        except ImportError:
            raise ImportError(
                "This test requires the mock module.")
    from .std import tqdm
    import six

    # Make the progress bar  from tqdm_rich class above

# Generated at 2022-06-22 15:55:22.100220
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Regression test for `tqdm.rich.tqdm.display()`."""
    with tqdm_rich(total=2) as pbar:
        pbar.display(1)

# Generated at 2022-06-22 15:55:27.712622
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with Progress('Resetting progress') as progress:
        task = progress.add_task('task', start=0, total=100)
        for i in range(100):
            progress.update(task, completed=i)
        progress.reset()
        assert progress.complete == 0
        assert progress.total == 100

# Generated at 2022-06-22 15:55:34.759422
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import unittest
    class ClearTest(unittest.TestCase):
        """ Class for testing method clear of tqdm_rich """
        # tqdm_rich.clear() to pass
        def test_clear_pass(self):
            """ If method tqdm.clear() is called, no Exception is raised """
            test_tqdm = tqdm_rich(range(10))
            test_tqdm.clear()

    unittest.main()

# Generated at 2022-06-22 15:55:44.381013
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .utils import format_interval
    with tqdm(total=10) as t:
        assert t.dynamic_messages['elapsed'] == format_interval(0)
        assert t.dynamic_messages['remaining'] == format_interval(0)
        assert t.dynamic_messages['rate'] == "0"
        assert t.format_dict['desc'] == None

        t.reset(total=12)
        assert t.dynamic_messages['elapsed'] == format_interval(0)
        assert t.dynamic_messages['remaining'] == format_interval(0)
        assert t.dynamic_messages['rate'] == "0"
        assert t.format_dict['desc'] == None

        t.update()

# Generated at 2022-06-22 15:55:56.442049
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm([0, 1], 'desc',
                  ascii=True, miniters=1, mininterval=0, total=2, unit='it',
                  unit_scale=False, unit_divisor=1000, dynamic_ncols=False,
                  smoothing=0.3, bar_format='{l_bar}{bar}|', initial=0,
                  position=0, postfix=None, disable=False, unit_mode=False,
                  leave=False):
        _  # make pyflakes happy


if __name__ == '__main__':  # pragma: no cover
    from atexit import register
    from time import sleep

    @register
    def _atexit():
        print("exit!")


# Generated at 2022-06-22 15:55:58.863234
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test for method clear of class tqdm_rich
    """
    with tqdm_rich(1) as t:
        t.clear(force=False)

# Generated at 2022-06-22 15:56:09.614739
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .std import tqdm
    try:
        from rich.progress import __version__
    except ImportError:
        return
    for disable in [False, True]:
        t = tqdm(disable=disable)
        t.close()
        t.clear()


if __name__ == "__main__":
    from ._tqdm import _test as test_module
    test_module(tqdm, tqdm_gui, tqdm_notebook, tqdm_pandas)  # pragma: no cover

# Generated at 2022-06-22 15:56:14.372758
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as pbar:
        for i in range(5):
            pbar.update(1)
        pbar.reset(total=5)
        for i in range(5):
            pbar.update(1)

# Generated at 2022-06-22 15:56:25.073752
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == '? /s'

    rate_column = RateColumn(unit_divisor=2)
    assert rate_column.render(None) == '? /s'

    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == '? '

    rate_column = RateColumn(unit='Kb')
    assert rate_column.render(None) == '? Kb/s'

    rate_column = RateColumn(unit='Kb', unit_scale=True)
    assert rate_column.render(None) == '? Kb'

    rate_column = RateColumn(unit='Kb', unit_scale=True, unit_divisor=2)

# Generated at 2022-06-22 15:56:32.836769
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress = (
        "[progress.description]{task.description}",
        FractionColumn(unit_scale=False))
    with tqdm_rich(total=10, desc='Initial', progress=progress) as pbar:
        for i in range(10):
            pbar.display()
            if i == 5:
                pbar.reset(total=8)
            if i == 6:
                pbar.reset()

# Generated at 2022-06-22 15:56:40.288231
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import trange
    from threading import Event
    stop_thread = Event()
    try:
        with tqdm_rich(total=100, mininterval=1.2, smoothing=0) as pbar:
            for i in trange(pbar.total):
                if i >= 20:
                    pbar.reset(total=400 + i)
                if stop_thread.wait(0.001):
                    break
    finally:
        stop_thread.set()

# Generated at 2022-06-22 15:56:51.469430
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .rich_utils import _mock_task
    unit_scale = False
    unit_divisor = 1000
    suffix = '' if unit_scale else 'K'

    for speed in [10, 100, 1000, 10000, 1000000]:
        task = _mock_task(speed=speed)
        for unit_scale in [False, True]:
            unit, suffix = filesize.pick_unit_and_suffix(
                speed,
                ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
                unit_divisor,
            )
            precision = 0 if unit == 1 else 1
            suffix = suffix if unit_scale else ''
            ans = f"{speed/unit:,.{precision}f} {suffix}B/s"
            r = RateColumn

# Generated at 2022-06-22 15:56:56.748769
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    col = RateColumn()
    assert col.render(col) == '? /s'
    col = RateColumn(unit='B')
    assert col.render(col) == '? B/s'
    col = RateColumn(unit='B', unit_scale=True)
    assert col.render(col) == '? /s'
    col = RateColumn(unit='B', unit_scale=True, unit_divisor=1024)
    assert col.render(col) == '? /s'
    

# Generated at 2022-06-22 15:57:02.710815
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    task = type('', (), {'speed': None})()
    assert(rate_column.render(task) == Text('? /s', style='progress.data.speed'))
    rate_column = RateColumn()
    task = type('', (), {'speed': 1})()
    assert(rate_column.render(task) == Text('1.0 /s', style='progress.data.speed'))
    rate_column = RateColumn()
    task = type('', (), {'speed': 1.1})()
    assert(rate_column.render(task) == Text('1.1 /s', style='progress.data.speed'))
    rate_column = RateColumn()
    task = type('', (), {'speed': 100})()

# Generated at 2022-06-22 15:57:05.732411
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich"""
    for obj in [tqdm_rich(), std_tqdm()]:
        obj.clear()

# Generated at 2022-06-22 15:57:07.727945
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm(total=100) as bar:
        for i in range(100):
            bar.reset(total=None)

# Generated at 2022-06-22 15:57:20.476003
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    import random
    from .std import tqdm
    # Create a random numbers generator
    data = iter((random.randint(1, 10) for _ in range(100)))
    # Create a tqdm_rich instance to iterate
    for _ in tqdm_rich(data, total=100):
        time.sleep(random.random())

    # Check if the reset is working well.
    for _ in tqdm_rich(data, total=100):
        time.sleep(random.random())

# Generated at 2022-06-22 15:57:22.541180
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10, desc = "Testing", unit = "B") as pbar:
        pbar.clear()
    return

# Generated at 2022-06-22 15:57:34.392097
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = None
    task.unit = "Byte"
    task.unit_scale = False
    task.unit_divisor = 1
    rate_column = RateColumn(unit=task.unit, unit_scale=task.unit_scale, unit_divisor=task.unit_divisor)
    assert rate_column.render(task) == Text(f"? Byte/s", style="progress.data.speed")
    task.speed = 1024
    assert rate_column.render(task) == Text(f"1.00 Byte/s", style="progress.data.speed")
    task.speed = 10442
    assert rate_column.render(task) == Text(f"10.2 Byte/s", style="progress.data.speed")
    task.speed = 11259.7
    assert rate

# Generated at 2022-06-22 15:57:37.626560
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    r = RateColumn()
    assert r.render(None) == Text("? /s", style="progress.data.speed")


# Generated at 2022-06-22 15:57:37.985363
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-22 15:57:39.503897
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(10) as pbar:
        assert pbar.clear is not None

# Generated at 2022-06-22 15:57:45.210503
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in (None, 1, 2):
        with tqdm(total=total) as t:
            for _ in t:
                pass
            for _ in t:
                break
        t.reset(total=total)
        for i in t:
            assert i == 0
            break

test_tqdm_rich_reset()

# Generated at 2022-06-22 15:57:47.384630
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in tqdm(range(3)):
        pass

# Generated at 2022-06-22 15:57:48.943960
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test if clear method works as intended."""
    pass

# Generated at 2022-06-22 15:57:59.356145
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    sys.stdin = sys.stdout = sys.stderr = open(sys.devnull, "w")
    from rich.progress import Progress
    from rich.text import Text
    progress = Progress(Text("", style="progress.percentage"),
                        Text("", style="progress.data.rate"),
                        Text("", style="progress.data.elapsed"),
                        Text("", style="progress.data.remaining"),
                        Text("", style="progress.bar"))

    def update(task, completed, total, description):
        task.update(completed=completed, total=total, description=description)

    def assert_display(desc, completed, total, expected_desc, expected_percent):
        t = tqdm_rich(disable=True, total=total, desc=desc)

# Generated at 2022-06-22 15:58:15.790158
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    import gc
    try:
        from rich.progress import Progress
    except ImportError:
        pass

    def func():
        for x in tqdm_rich.write(range(10)):
            time.sleep(.1)
            pass
        gc.collect()
        Progress.clear()

    func()

# Generated at 2022-06-22 15:58:22.866665
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Reset the progress bar and its attributes.
    """
    bar = tqdm(_range(2), ascii=True, desc='tqdm_rich')
    bar.set_postfix(ordered_dict={'bar': 'last'})
    assert bar.total == 2
    assert bar.last_print_n == 0
    bar.reset(total=3)
    assert bar.total == 3
    assert bar.last_print_n == 0
    bar.update()
    bar.update()
    assert bar.total == 3
    assert bar.last_print_n == 2
    bar.reset(total=4, refresh=True)
    assert bar.total == 4
    assert bar.last_print_n == 0

# Generated at 2022-06-22 15:58:33.822922
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    import time

    @tqdm_rich(total=100, progress=(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn()), unit="it")
    def test_tqdm_rich_gen():
        for _ in range(100):
            time.sleep(0.01)
            yield


# Generated at 2022-06-22 15:58:45.954826
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pylint: disable=dangerous-default-value
    """Test _tqdm_rich"""

# Generated at 2022-06-22 15:58:53.474952
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    """
    Test for method `display` of class `tqdm_rich`.
    """
    from .tqdm import tqdm

    display = tqdm.display
    display._instances = set()

# Generated at 2022-06-22 15:58:55.667595
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=7) as pbar:
        for i in range(7):
            pbar.clear()
            pbar.update()

# Generated at 2022-06-22 15:59:05.757708
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest
    r = RateColumn("B", False)
    assert r.render("abc") == Text("? B/s", style="progress.data.speed")
    r = RateColumn("B", True)
    assert r.render("abc") == Text("? /s", style="progress.data.speed")
    r = RateColumn("B", True, 2)
    assert r.render("abc") == Text("? /s", style="progress.data.speed")
    r = RateColumn("", True)
    assert r.render("abc") == Text("? /s", style="progress.data.speed")
    r = RateColumn("", False)
    assert r.render("abc") == Text("? /s", style="progress.data.speed")
    r = RateColumn("", True, 2)

# Generated at 2022-06-22 15:59:08.165063
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test that display clears screen."""
    t = tqdm_rich(total=0)
    t.close()
    t.display()

# Generated at 2022-06-22 15:59:11.952917
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    console = Console()
    console.print("\n" * 5)
    with tqdm(desc="Testing progress bar", total=100) as progress:
        for i in range(100):
            progress.update(1)


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-22 15:59:13.781953
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Create a dummy tqdm_rich object
    tqdm_rich_obj = tqdm_rich()
    tqdm_rich_obj.clear()

# Generated at 2022-06-22 15:59:41.433888
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from io import StringIO
    from contextlib import redirect_stdout

    stdout = StringIO()
    with redirect_stdout(stdout):
        progress = tqdm_rich(range(0, 10), desc='Initializing')
        progress.display()
        progress.update(5)
        progress.display()
        progress.update(5)
        progress.display()
    assert stdout.getvalue() == ""

# Generated at 2022-06-22 15:59:48.051136
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit_scale=False).render(None) == '0.0 /s'
    assert RateColumn(unit_scale=False).render(type('task', (object,),
                                                  {'speed': None})) == '? /s'
    assert RateColumn(unit_scale=True, unit_divisor=1000).render(type('task',
                (object,), {'speed': 1000})) == '1.0 K/s'
    assert RateColumn(unit_scale=True, unit_divisor=1024).render(type('task',
                (object,), {'speed': 1024})) == '1.0 KiB/s'



# Generated at 2022-06-22 15:59:50.042032
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    p = tqdm_rich(total=100)
    p.display()



# Generated at 2022-06-22 15:59:56.287098
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn(unit="B", unit_scale=True)
    print(rate.render(Progress(0,0)))
    print(rate.render(Progress(1,1)))
    print(rate.render(Progress(0,5,5)))
    print(rate.render(Progress(0,5000,5)))
    print(rate.render(Progress(0,5000000,5)))
    print(rate.render(Progress(0,5000000000,5)))

# Generated at 2022-06-22 15:59:58.364790
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Testing the method display of class tqdm_rich."""
    rich_instance = tqdm_rich()
    assert rich_instance.display()

# Generated at 2022-06-22 16:00:09.894341
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import Progress, BarColumn, TextColumn
        from rich.style import Style
    except ImportError:
        return None

    # Test default values of progress
    progress = Progress()
    progress.__enter__()
    task_id = progress.add_task("A task", total=100)
    for i in range(100):
        progress.update(task_id, completed=i)
    progress.__exit__(None, None, None)

    # Test customized class
    with Progress("[progress.percentage]{task.percentage:>4.0f}%") as progress:
        task_id = progress.add_task("A task", total=100)
        for i in range(100):
            progress.update(task_id, completed=i)

    # Test customized class

# Generated at 2022-06-22 16:00:21.064748
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test method display of class tqdm_rich."""
    from .std import _range
    from .std import _term_move_up
    from .std import _term_clear_eol
    from .std import _unicode

    with tqdm(_range(0, 5)) as t:
        assert t.disable is False
        assert isinstance(t._prog, Progress)
        t.display()
        assert isinstance(t._prog, Progress)
        t.clear()
        assert isinstance(t._prog, Progress)
        t.update(2)
        assert isinstance(t._prog, Progress)
        t.display()
        assert isinstance(t._prog, Progress)
        t.display()
        assert isinstance(t._prog, Progress)
        t.display()

# Generated at 2022-06-22 16:00:25.731380
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=100) as t:
        for i in range(10):
            t.reset(total=100)
            for j in range(10):
                pass


if __name__ == '__main__':
    test_tqdm_rich_reset()

# Generated at 2022-06-22 16:00:28.298957
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test method display of the class tqdm_rich."""
    t = tqdm_rich(total=10)
    t.display()
    t.close()

# Generated at 2022-06-22 16:00:31.766170
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1) as progress:
        progress.clear()
        progress.clear(nolock=True)
        progress.clear(nolock=False)
        progress.close()

# Generated at 2022-06-22 16:01:21.202472
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    pbar = tqdm_rich(total=100, position=0)
    for i in _range(10):
        time.sleep(0.01)
        pbar.update(10)
    pbar.reset()
    for i in _range(10):
        time.sleep(0.01)
        pbar.update(10)
    pbar.close()

# Generated at 2022-06-22 16:01:28.033456
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    x = RateColumn(unit="MB", unit_scale=True, unit_divisor=1024)
    assert "MB/s" == x.render(1)[0]

if __name__ == "__main__":  # pragma: no cover
    from rich.console import Console
    c = Console()
    for i in tqdm(c.range, total=100):
        c.print(i)
    from rich.progress import Progress

# Generated at 2022-06-22 16:01:36.032327
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = tqdm_rich(total=100, smoothing=0)
    progress.clear()
    progress.update(0)
    progress.render_progress()
    with progress:
        for x in range(100):
            progress.update(1)
            progress.render_progress()
    print(progress)
    for x in range(100):
        progress.update(1)
        progress.render_progress()
    print(progress)
    for x in range(100):
        progress.update(1)
        progress.render_progress()
    print(progress)

# Generated at 2022-06-22 16:01:46.910956
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100000, completed=100000)) == Text("1000 K/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000000, completed=1000000)) == Text("1000 K/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000000000, completed=1000000000)) == Text("1000 K/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000000000000, completed=1000000000000)) == Text("1000 K/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1000000000000000, completed=1000000000000000)) == Text("1000 K/s", style="progress.data.speed")

# Generated at 2022-06-22 16:01:57.606156
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from itertools import chain
    # check that reset works for newly constructed tqdm_rich
    bar = tqdm_rich()
    bar.reset()
    bar.reset(total=1)

    # check that reset works for reused tqdm_rich
    bar = tqdm_rich()
    for _ in bar:
        bar.reset(total=bar.total + 3)
    for _ in bar:
        bar.reset(total=bar.total + 4)
    for _ in bar:
        bar.reset(total=bar.total + 5)
    assert isinstance(bar.total, int)
    # test with total=None
    bar.reset(total=None)
    bar.reset()
    bar.reset()
    bar.reset()

    # check that iterating works
    bar = tqdm_

# Generated at 2022-06-22 16:02:00.333216
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=1) as t:
        t.display()
        assert t.n == 0
        t.n += 1
        t.display()

# Generated at 2022-06-22 16:02:07.903904
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    result1 = column.render({
        'description': 'Task 1',
        'completed': 20,
        'total': 80,
        'speed': None,
    })
    assert result1 == Text('? /s', style="progress.data.speed")
    result2 = column.render({
        'description': 'Task 1',
        'completed': 20,
        'total': 80,
        'speed': 20,
    })
    assert result2 == Text('20.0 /s', style="progress.data.speed")
    result3 = column.render({
        'description': 'Task 1',
        'completed': 20,
        'total': 80,
        'speed': 200,
    })
    assert result3 == Text('200.0 /s', style="progress.data.speed")

# Generated at 2022-06-22 16:02:14.340651
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test render of RateColumn with and without unit_scale."""
    rate_column = RateColumn()
    assert rate_column.render(object) == Text('? B/s', style='progress.data.speed')
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(object) == Text('? B/s', style='progress.data.speed')

# Generated at 2022-06-22 16:02:21.858377
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tqdm_gui

    from unittest import TestCase

    class TqdmRichTest(TestCase):
        """Test for method reset"""
        def test_tqdm_rich_reset(self):
            """Test for method reset of class tqdm_rich"""
            with tqdm_gui(total=5, leave=True) as t:
                t.reset(total=9)
                self.assertEqual(t.total, 9)
                t.n = 7
                t.reset(total=9)
                self.assertEqual(t.total, 9)
                self.assertEqual(t.n, 7)

    return TqdmRichTest("test_tqdm_rich_reset").test_tqdm_rich_reset()

# Generated at 2022-06-22 16:02:25.793502
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    x = tqdm_rich(['a', 'b', 'c'])
    x.clear()