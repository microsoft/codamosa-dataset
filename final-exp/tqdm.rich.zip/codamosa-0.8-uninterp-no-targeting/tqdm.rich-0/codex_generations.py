

# Generated at 2022-06-22 05:33:11.388093
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress_bar = Progress(
        Text("[progress.description]{task.description}"),
    )
    progress_bar.__enter__()
    try:
        progress_bar.add_task("", total=10000)
    finally:
        progress_bar.__exit__(None, None, None)

if __name__ == "__main__":
    test_FractionColumn()

# Generated at 2022-06-22 05:33:23.493379
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for method reset of class `tqdm.rich.tqdm_rich()`.
    When the parameter `total` is omitted, the total number of iterations is
    unchanged, and the number of displayed iterations is reset to 0.
    When the parameter `total` is provided, the total number of iterations
    is changed, and the number of displayed iterations is reset to 0.
    """
    with tqdm_rich(total=10) as t:
        # 10 iterations, 0 displayed
        assert t.total == 10 and t.n == 0
        # 1 iteration
        for _ in t:
            pass
        assert t.total == 10 and t.n == 1

        # reset to 0 displayed, total unchanged
        t.reset()
        assert t.total == 10 and t.n == 0

        # 1 iteration

# Generated at 2022-06-22 05:33:24.950694
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for _ in tqdm_rich(range(4)):
        pass

# Generated at 2022-06-22 05:33:33.391940
# Unit test for constructor of class RateColumn
def test_RateColumn():
    t1 = RateColumn()
    assert t1._text == "? "
    t2 = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert t2._text == "? B"
    t3 = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert t3._text == "? B"
    t4 = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert t4._text == "? B"

# Generated at 2022-06-22 05:33:36.002783
# Unit test for function trange
def test_trange():
    """Tests `trange` function."""
    from tqdm.auto import trange

    for _ in trange(5, desc="hello world"):
        pass

# Generated at 2022-06-22 05:33:42.296250
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert type(fc) is FractionColumn
    assert fc.unit_scale == False
    assert fc.unit_divisor == 1000
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert type(fc) is FractionColumn
    assert fc.unit_scale == True
    assert fc.unit_divisor == 1024

# Generated at 2022-06-22 05:33:44.693603
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(leave=True) as pbar:
        pbar.clear()



# Generated at 2022-06-22 05:33:46.456171
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    FractionColumn(unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-22 05:33:56.777036
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for constructor of class `RateColumn`."""
    assert RateColumn(unit='bytes', unit_scale=False).render({'speed': 100}) == \
        '100 bytes/s'
    assert RateColumn(unit='bytes', unit_scale=True).render({'speed': 100}) == \
        '100 B/s'
    assert RateColumn(unit='bytes', unit_scale=True).render({'speed': 1200}) == \
        '1.2 Kbytes/s'
    assert RateColumn(unit='bytes', unit_scale=True).render({'speed': 1200000}) == \
        '1.2 Mbytes/s'
    assert RateColumn(unit='bytes', unit_scale=True).render({'speed': 1200000000}) == \
        '1.2 Gbytes/s'

# Generated at 2022-06-22 05:34:08.334388
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    """
    Test that `tqdm.rich` can be reset and restarted.
    """
    import time
    count = 5
    with tqdm(total=count, desc='test', unit_scale=True) as pbar:
        for i in range(count):
            time.sleep(0.1)
            pbar.update()
    # Test that resetting to a smaller number of iterations works.
    new_count = 3
    with tqdm(total=new_count, desc='test', unit_scale=True) as pbar:
        for i in range(new_count):
            time.sleep(0.1)
            pbar.update()
    # Test that resetting to a larger number of iterations works.
    new_count = 10

# Generated at 2022-06-22 05:34:14.434213
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(10) as t:
        for i in range(10):
            t.update()


# Generated at 2022-06-22 05:34:22.760747
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm().__enter__()
    task.speed = None
    assert RateColumn().render(task) == Text('? ', style="progress.data.speed")
    task.speed = 1000
    assert RateColumn().render(task) == Text('1.0 K/s', style="progress.data.speed")
    task.speed = 1100
    assert RateColumn().render(task) == Text('1.1 K/s', style="progress.data.speed")
    task.speed = 10000
    assert RateColumn().render(task) == Text('1.0 K/s', style="progress.data.speed")
    task.speed = 100000
    assert RateColumn().render(task) == Text('1.0 M/s', style="progress.data.speed")
    task.speed = 1000000
    assert RateColumn().render

# Generated at 2022-06-22 05:34:33.143258
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task1 = FractionColumn()
    task2 = FractionColumn(unit_scale=True)
    assert task1.render(FractionColumn(unit_scale=True)) == Text(
        '0.0/0.0 ', style='progress.download')
    assert task1.render(FractionColumn(unit_scale=True, unit_divisor=1024)) == Text(
        '0.0/0.0 ', style='progress.download')
    assert task1.render(FractionColumn(unit_divisor=1024)) == Text(
        '0.0/0.0 ', style='progress.download')
    assert task1.render(
        FractionColumn(completed=234, total=1024)) == Text(
            '234.0/1,024.0 ', style='progress.download')
    assert task1.render

# Generated at 2022-06-22 05:34:44.828189
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="/s")
    assert rate_column.render({"speed": None}) == Text(f"? /s", style="progress.data.speed")
    assert rate_column.render({"speed": 100}) == Text(f"100 /s/s", style="progress.data.speed")
    assert rate_column.render({"speed": 9999999999}) == Text(f"9,999.999999 Y/s/s", style="progress.data.speed")
    assert rate_column.render({"speed": 5.555}) == Text(f"5.6 /s/s", style="progress.data.speed")
    assert rate_column.render({"speed": 9.999}) == Text(f"10 /s/s", style="progress.data.speed")

# Generated at 2022-06-22 05:34:54.843501
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    column.__init__(unit_scale=True, unit_divisor=1024)
    column = FractionColumn(unit_scale=True, unit_divisor=10)
    # Test for non-fractional numbers
    assert column.render({'total': 100, 'completed': 50}) == Text(
        '50.0/100.0 ', style='progress.download')
    # Test for fractional numbers
    assert column.render({'total': 100.5, 'completed': 50}) == Text(
        '50.0/100.0 ', style='progress.download')
    assert column.render({'total': 102.5, 'completed': 50}) == Text(
        '48.8/102.5 ', style='progress.download')
    # Test for large numbers

# Generated at 2022-06-22 05:34:58.295253
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for method reset of class tqdm_rich
    """
    with trange(10, 100) as t:
        t.reset(1000)
        t.reset(total=2000)

# Generated at 2022-06-22 05:35:11.133001
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from sys import version
    from time import sleep

    try:
        import rich
    except ImportError:
        msg = "rich is not installed and is not an optional dependency"
        raise TqdmExperimentalWarning(msg)

    if rich.__version__ < '7.0.0':
        raise TqdmExperimentalWarning("rich<7.0.0")

    # construct with no parameters
    with tqdm_rich(total=3) as T:
        if T.total != 3:
            raise ValueError("total")
        if T.desc is not None:
            raise ValueError("desc")
        if T.unit != 'it':
            raise ValueError("unit")
        if T.bar_format != "[{desc}{bar}]":
            raise ValueError("bar_format")

# Generated at 2022-06-22 05:35:14.269815
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        with tqdm_rich(desc="test") as t:
            t.update(20)
    except:
        pass
    assert t.desc is not None
    assert t.total is not None

# Generated at 2022-06-22 05:35:16.221533
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    for i in tqdm(range(10)):
        time.sleep(1)

# Generated at 2022-06-22 05:35:24.529328
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # pylint: disable=no-member
    n = 100
    t = tqdm_rich(total=n)
    for i in range(n):
        assert t._pos == i
        t.update()
    assert t._pos == n
    t.reset(total=2 * n)
    for i in range(n, 2 * n):
        assert t._pos == i
        t.update()
    assert t._pos == 2 * n
    t.reset(total=n // 2)
    for i in range(n // 2):
        assert t._pos == i
        t.update()
    assert t._pos == n // 2
    t.reset()
    for i in range(n):
        assert t._pos == i
        t.update()
    assert t._pos == n

# Generated at 2022-06-22 05:35:43.879770
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    with trange(10) as t:
        assert t.miniters == 1
        assert t.desc == ""
        # raise
        try:
            for _ in t:
                raise ValueError("Error!")
        except ValueError:
            pass
    with trange(10) as t:
        assert t.miniters == 1
        assert t.desc == ""
        for _ in t:
            break
    with trange(10) as t:
        assert t.miniters == 1
        assert t.desc == ""
        for _ in t:
            t.set_description("Foo Bar %s" % _)
            t.update()
            if _ == 5:
                return

# Generated at 2022-06-22 05:35:47.882425
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    for i in tqdm(range(1000)):
        assert tqdm._task_id == tqdm.last_print_n
    assert i == 999, i
    try:
        tqdm.close()
    except AttributeError:
        pass



# Generated at 2022-06-22 05:35:57.636721
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    >>> rate1 = RateColumn()
    >>> rate1.render(Progress())
    [' ? /s']
    >>> rate2 = RateColumn(unit=' KiB')
    >>> rate2.render(Progress(speed=111))
    [' 111.0 KiB/s']
    >>> rate2.render(Progress(speed=1023))
    [' 1.0 KiB/s']
    >>> rate3 = RateColumn(unit=' KiB', unit_scale=True, unit_divisor=2)
    >>> rate3.render(Progress(speed=1023))
    [' 1023.0 KiB/s']
    """
    pass

# Generated at 2022-06-22 05:36:02.153341
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        for _ in tqdm(range(100)) :
            pass
    except NotImplementedError as e:
        print("Method clear of class tqdm_rich not implemented\n")
        print(e)

test_tqdm_rich_clear()

# Generated at 2022-06-22 05:36:05.113238
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn('bytes', unit_scale=False, unit_divisor=1000).render(42) == "42 bytes/s"

# Generated at 2022-06-22 05:36:09.941949
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .std import tqdm
    from .utils import _range

    sum = 0
    with tqdm_rich(total=100) as t:
        for i in _range(100):
            sum += i
            t.display()
    assert sum == 4950

# Generated at 2022-06-22 05:36:11.490401
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    print(column.render(None))

# Generated at 2022-06-22 05:36:18.846940
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.render({'completed': 100, 'total': 500}) == '100/500'  # test precision
    assert fc.render({'completed': 1, 'total': 3}) == '1.0/3.0'  # test precision
    assert fc.render({'completed': 1, 'total': 2}) == '0.5/2.0'  # test precision
    assert fc.render({'completed': 10000, 'total': 2000}) == '1/0.2'  # test unit_scaling
    assert fc.render({'completed': 10000, 'total': 2000, 'unit_scale': True}) == '0.01/0.002 K'  # test unit_scaling

# Generated at 2022-06-22 05:36:30.001535
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    This is a method for unit testing the method render of class RateColumn
    """
    from rich.progress import Task
    from rich.console import Console
    console = Console()

    task = Task(console, total=100)

    # test case 1
    column = RateColumn(task)
    assert isinstance(column.render(task), Text)

    # test case 2
    column = RateColumn(unit="b")
    assert isinstance(column.render(task), Text)

    # test case 3
    column = RateColumn(unit_scale=True, unit_divisor=1000)
    assert isinstance(column.render(task), Text)

    # test case 4
    column = RateColumn(unit_scale=False, unit_divisor=1024)
    assert isinstance(column.render(task), Text)

   

# Generated at 2022-06-22 05:36:33.291574
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .gui import tgrange
    import time
    try:
        for _ in tgrange(10):
            time.sleep(0.01)
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-22 05:36:59.413373
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t = 1
    TimeColumn = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert TimeColumn.render(t) == Text(
        f"1,000 B/s", style="progress.data.speed"), \
        "This test should be failed"
    TimeColumn = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert TimeColumn.render(t) == Text(f"1000 B/s", style="progress.data.speed"), \
        "This test should be failed"
    TimeColumn = RateColumn(unit="", unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-22 05:37:09.722111
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(tqdm_rich(0, 0)) == Text("? bytes/s", style="progress.data.speed")
    assert RateColumn().render(tqdm_rich(1, 0)) == Text("n/a bytes/s", style="progress.data.speed")
    assert RateColumn().render(tqdm_rich(0, 1, unit="", unit_scale=False, unit_divisor=1)) == Text("0.0 bytes/s", style="progress.data.speed")
    assert RateColumn().render(tqdm_rich(1, 1, unit="", unit_scale=False, unit_divisor=1)) == Text("1.0 bytes/s", style="progress.data.speed")

# Generated at 2022-06-22 05:37:17.555098
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    from rich.progress import Progress, TaskID, ProgressColumn
    class TestFractionColumn(unittest.TestCase):
        def setUp(self):
            self.prog = Progress()
            self.task_id = TaskID()

        def test_FractionColumn(self):
            prog = Progress()
            task_id = self.prog.add_task("Downloading", start=0, total=1e6, unit="B")
            col = FractionColumn(unit_scale=False)
            result_1 = col.render(self.prog.get_task(self.task_id))
            self.assertEqual(result_1, Text("0/1,000,000 B", style="progress.download"))
            self.prog.update(self.task_id, completed = 1545)

# Generated at 2022-06-22 05:37:29.269995
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm
    from .utils import format_interval
    from rich.progress import TaskID
    from rich.text import Text

    try:
        from rich.console import Console  # type: ignore
        from rich.panel import Panel  # type: ignore
    except ImportError:  # pragma: no cover
        raise unittest.SkipTest(
            "rich package not installed, skipping tqdm_rich test")

    console = Console()

# Generated at 2022-06-22 05:37:33.809232
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm.utils import _term_move_up
    it = tqdm_rich(range(5))
    assert hasattr(it, '_prog'), 'progress has no attribute _prog'
    it.close()
    assert it._prog.is_finished, 'progress not finished'



# Generated at 2022-06-22 05:37:35.713804
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    bar_col = FractionColumn()
    task_id = bar_col.render()



# Generated at 2022-06-22 05:37:37.827796
# Unit test for function trange
def test_trange():
    """Test trange."""
    with trange(10) as t:
        for i in t:
            assert i == t.n - 1

# Generated at 2022-06-22 05:37:45.866283
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.

    Test input :
    speed = 10
    unit = 'B'
    unit_scale = False
    unit_divisor = 1000

    Test output :
    speed = 10 B/s
    """
    task = tqdm_rich(total=100)
    task.n = 10
    task.desc = 'test'
    task.speed = task.n/task.total*100
    test_rate_column = RateColumn(unit = 'B', unit_scale = False, unit_divisor = 1000)
    assert test_rate_column.render(task) == Text('10 B/s', style='progress.data.speed')


# Generated at 2022-06-22 05:37:56.788413
# Unit test for function trange
def test_trange():
    """Test function trange."""
    # python2
    assert std_tqdm(xrange(10)).__next__() == 0
    assert tqdm(xrange(10)).__next__() == 0
    assert trange(10).__next__() == 0
    # python3
    assert std_tqdm(range(10)).__next__() == 0
    assert tqdm(range(10)).__next__() == 0
    assert trange(10).__next__() == 0
    # python2 + python3
    assert std_tqdm(xrange(10)).__next__() == 1
    assert tqdm(xrange(10)).__next__() == 1
    assert trange(10).__next__() == 1

# Generated at 2022-06-22 05:38:06.828278
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(dict(completed=0, total=0)) == Text('0/0', style='progress.download')
    assert FractionColumn().render(dict(completed=100, total=100)) == Text('1/1', style='progress.download')
    assert FractionColumn().render(dict(completed=100000, total=100000)) == Text('100/100', style='progress.download')
    assert FractionColumn().render(dict(completed=1e2, total=1e2)) == Text('100/100', style='progress.download')
    assert FractionColumn().render(dict(completed=1e6, total=1e6)) == Text('1.0/1.0 M', style='progress.download')

# Generated at 2022-06-22 05:38:23.515211
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for i in trange(4):
        pass

# Generated at 2022-06-22 05:38:30.774175
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import _range
    for i in tqdm(_range(1, 11), total=10):
        if i == 5:
            tqdm.reset(total=50)
        tqdm.update()

# Override tqdm as tqdm_rich for the rich module
tqdm = tqdm_rich

# Keep a copy of the original tqdm for use in the rich module
tqdm_rich.std_tqdm = std_tqdm

# Generated at 2022-06-22 05:38:38.997373
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task1 = tqdm_rich(total=1)
    fc1 = FractionColumn()
    assert(fc1.render(task1) == Text("1.0/1.0", style="progress.download"))
    task2 = tqdm_rich(total=231, unit_scale=True)
    fc2 = FractionColumn(unit_scale=True)
    assert(fc2.render(task2) == Text("231.0/231.0", style="progress.download"))
    task3 = tqdm_rich(total=231, unit_scale=True, unit_divisor=1024)
    fc3 = FractionColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:38:40.693191
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests import tests
    tests.test_class_tqdm_rich()

# Generated at 2022-06-22 05:38:44.778872
# Unit test for constructor of class RateColumn
def test_RateColumn():
    try:  # for Python3.3 and above
        assert str(RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(None)) == ""
    except AssertionError:
        pass

# Generated at 2022-06-22 05:38:46.361067
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .gui import tgrange
    for _ in tgrange(3): pass

# Generated at 2022-06-22 05:38:57.647038
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for constructor of class RateColumn"""
    ratecolumn = RateColumn(unit="")
    assert ratecolumn.unit == ""


if __name__ == "__main__":  # pragma: no cover
    from rich.console import Console
    console = Console()

    console.print("File download")
    for i in trange(120):
        console.print(f"Downloading... {i*10}%", justify="right", style="progress.download")
        sleep(0.1)

    console.print("\nFolder copy...")
    for i in trange(120):
        console.print(f"Copying... {i*10}%", justify="right", style="progress.copy")
        sleep(0.1)

    console.print("\nConnecting to server...")

# Generated at 2022-06-22 05:39:05.170793
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000)(None) == "? B/s"
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024)(None) == "? B/s"
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000)(None) == "? B/s"
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1024)(None) == "? B/s"


# Generated at 2022-06-22 05:39:09.951151
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
  task_id = 1
  with Progress() as prog:
    task_id = prog.add_task("Test Task")
  tq = tqdm_rich("Test Task")
  tq.close()
  assert tq._prog is None
  assert task_id == tq._task_id

# Generated at 2022-06-22 05:39:16.642179
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    class FakeTask:
        completed = '3.5'
        total = '2.5'
    fake_task = FakeTask()
    assert fc.render(fake_task) == Text('3.5/2.5 ', style='progress.download')


# Generated at 2022-06-22 05:39:56.857441
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console  # noqa: F401

    for unit_scale in (0, 1):
        for unit_divisor in (0, 1000, 1024):
            w = tqdm_rich(
                total=2,
                unit_scale=unit_scale,
                unit_divisor=unit_divisor,
                leave=True,
                disable=None,
                ascii=True,
                mininterval=0.1,
                miniters=1,
                desc='Test',
                bar_format='{desc}{percentage}{bar}{r_bar}{n_fmt}/{total_fmt}',
            )
            next(w)
            assert w.n == 1
            next(w)
            assert w.n == 2

# Generated at 2022-06-22 05:40:08.513384
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress()) == Text("0/0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress()) == Text("0/0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress()) == Text("0/0", style="progress.download")
    assert FractionColumn().render(Progress(total=0.5)) == Text("0/0.5", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=0.5)) == Text("0/0", style="progress.download")

# Generated at 2022-06-22 05:40:17.025703
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import TaskID
    import os

    task = TaskID(completed=20, total=100)
    task_unit = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert(task_unit.render(task) == Text("20.0/100.0 ",  style="progress.download"))
    task.total = 1000
    assert(task_unit.render(task) == Text("20.0/1.0 K", style="progress.download"))

# Generated at 2022-06-22 05:40:19.067947
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Unit test for tqdm_rich constructor."""
    t = tqdm_rich(total=100)
    t.close()

# Generated at 2022-06-22 05:40:27.499657
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    import os

    with open(os.devnull, 'w') as fd:
        t = tqdm(fd, 100, unit='B', unit_scale=True)
        t.reset(total=200)
        assert t.total == 200
        t.reset(total=200, unit='iB', unit_scale=False)
        assert t.total == 200
        assert t.unit == 'iB'
        assert not t.unit_scale
        t.reset(total=200, unit='iB', unit_scale=True)
        assert t.total == 200
        assert t.unit == 'iB'
        assert t.unit_scale

# Generated at 2022-06-22 05:40:38.745426
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    def get_array_value_at(arr, index):
        return list(arr)[index]

    with tqdm_rich(total=100) as progress:
        text = get_array_value_at(progress.format_dict.values(), 4)
        assert text.startswith("0/") and text.endswith(" 100")
        for i in range(101):
            progress.update(i)
            text = get_array_value_at(progress.format_dict.values(), 4)
            assert text.startswith(str(i)+"/") and text.endswith(" 100")
        progress.reset(total=0)
        text = get_array_value_at(progress.format_dict.values(), 4)
        assert text.startswith("0/") and text.endswith(" 0")

# Generated at 2022-06-22 05:40:41.691190
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=100) as t:
        t.reset(total=200)
        assert t.total == 200

        t.reset(total=0)
        assert t.total == 0

# Generated at 2022-06-22 05:40:45.126074
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update(1)
            assert(t.n == i+1)
            t.clear()
            assert(t.n == i+1)

# Generated at 2022-06-22 05:40:54.357101
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from collections import namedtuple
    task = namedtuple("task", "completed total")
    f = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert f.render(task(completed=500, total=2300)) == Text(
        f"0.5/2.3 K", style="progress.download")
    f = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert f.render(task(completed=500, total=2300)) == Text(
        f"500.0/2300.0 ", style="progress.download")
    assert FractionColumn().render(task(completed=500, total=2300)) == Text(
        f"500.0/2300.0 ", style="progress.download")


# Generated at 2022-06-22 05:40:55.382978
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(0).clear()

# Generated at 2022-06-22 05:42:37.997400
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    render_column = FractionColumn()
    task = render_column._task(completed=50, total=100)
    assert render_column.render(task) == Text('0.5/1 ', style='progress.download')

    render_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    task = render_column._task(completed=50, total=100)
    assert render_column.render(task) == Text('0.1/0.1 K', style='progress.download')

# Generated at 2022-06-22 05:42:44.216138
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = std_tqdm(total = 10)
    column = FractionColumn(unit_scale=True, unit_divisor=1000)

    assert column.render(task) == "0.0/10.0"
    task.update(1)
    assert column.render(task) == "0.0/10.0"
    task.update(2)
    assert column.render(task) == "1.0/10.0"

# Generated at 2022-06-22 05:42:45.464225
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    _progress = ProgressColumn.render(task)
    return _progress


# Generated at 2022-06-22 05:42:46.561744
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    F = FractionColumn()
    F.render(2, 3)

# Generated at 2022-06-22 05:42:56.678483
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    import rich
    class task(object):
        completed = 0.5
        total = 2.3
    task1 = task()
    task2 = task()
    task2.completed = 9
    task2.total = 9.5
    task3 = task()
    task3.completed = 1.5
    task3.total = 1.5
    task4 = task()
    task4.completed = 0.5
    task4.total = 2.5
    task5 = task()
    task5.completed = 9
    task5.total = 9.5
    from .utils import _range
    for ini,fin in zip(_range(0,3),_range(3,6)):
        task5.total = task5.total*10**ini
        task5.completed