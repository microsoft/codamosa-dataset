

# Generated at 2022-06-22 05:33:06.744499
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    class FractionColumn_test(FractionColumn):
        def __init__(self, unit_scale, unit_divisor):
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super().__init__()

    print(FractionColumn_test(unit_scale=False, unit_divisor=1000).render(None))
    print(FractionColumn_test(unit_scale=True, unit_divisor=1000).render(None))
    print(FractionColumn_test(unit_scale=False, unit_divisor=1024).render(None))
    print(FractionColumn_test(unit_scale=True, unit_divisor=1024).render(None))


# Generated at 2022-06-22 05:33:18.845923
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    #test for case with close()
    with tqdm(total=10, leave=True) as pbar:
        for i in range(10):
            #pbar.write("test")
            pbar.update(1)

    #test for case with __exit__
    with tqdm(total=10, leave=True) as pbar:
        for i in range(10):
            #pbar.write("test")
            pbar.update(1)

    #test for case without __exit__
    with tqdm(total=10, leave=False) as pbar:
        for i in range(10):
            #pbar.write("test")
            pbar.update(1)

    #test for case without leave

# Generated at 2022-06-22 05:33:26.164562
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import pandas as pd
    import pandas.util.testing as tm
    tm.N, tm.K = 1000, 10
    with tqdm(pd.concat([tm.makeTimeDataFrame() for _ in range(tm.N//tm.K)],
                          ignore_index=True)) as pbar:
        for _ in range(tm.K):
            pbar.update(1)
            if pbar.n == 90:
                pbar.clear()

# Generated at 2022-06-22 05:33:37.034339
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from .utils import format_sizeof
    size = 100
    for n, l, g in [(10, 100, 1000),
                    (10.1, 100.2, 1000.3),
                    (10**10, 10**20, 10**30),
                    (0, 1, 10),
                    (1, 1, 10),
                    (0, 0, 10),
                    (-1, 10, 0),
                    (-1, -10, -1)]:
        for i in trange(n, total=l, miniters=g):
            pass
        if n == l:
            assert i == n - 1
        else:
            assert i == n


# Generated at 2022-06-22 05:33:41.871194
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import _TestTMonitor
    a = tqdm_rich(total=3, disable=True)
    a.display()
    b = tqdm_rich(total=3)
    b._tmonitor = _TestTMonitor()
    b.display()
    b.display(False)

# Generated at 2022-06-22 05:33:47.281976
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    """
    Test
    """
    tqdm_rich_close = tqdm_rich()
    tqdm_rich_close._prog = Progress(
        "[progress.description]{task.description}",
    )
    tqdm_rich_close.disable = False
    tqdm_rich_close.close()



# Generated at 2022-06-22 05:33:51.278813
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(0, 0, dynamic_ncols=True) as t:
        pass
    t.display()

if __name__ == "__main__":
    from doctest import testmod
    testmod(name="progress", optionflags=+doctest.ELLIPSIS)

# Generated at 2022-06-22 05:33:57.718853
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    completed, total = 10, 98
    class Task():
        def __init__(self):
            self.completed, self.total = completed, total
    assert progress_column.render(Task()) == Text("10.0/98.0 ", style="progress.download")


# Generated at 2022-06-22 05:34:09.339659
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r1 = RateColumn(unit='', unit_scale=False, unit_divisor=1)
    r2 = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    r3 = RateColumn(unit='', unit_scale=False, unit_divisor=1024)
    r4 = RateColumn(unit='', unit_scale=True, unit_divisor=1000)
    r5 = RateColumn(unit='', unit_scale=True, unit_divisor=1024)
    r6 = RateColumn(unit='B', unit_scale=True, unit_divisor=1000)
    r7 = RateColumn(unit='B', unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:34:12.243692
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    tqdm_rich.overwrite_to_stdout = False
    t = tqdm_rich(range(10))
    t.reset()
    assert t.n == 0
    t.close()
    tqdm_rich.overwrite_to_stdout = True

# Generated at 2022-06-22 05:34:36.218746
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn()
    assert rc.render(None) == Text('?/s', style='progress.data.speed')
    rc = RateColumn(unit='B')
    assert rc.render(None) == Text('?B/s', style='progress.data.speed')
    rc = RateColumn(unit='B', unit_scale=True)
    assert rc.render(None) == Text('?B/s', style='progress.data.speed')
    rc = RateColumn(unit='', unit_scale=True)
    assert rc.render(None) == Text('?/s', style='progress.data.speed')
    rc.unit_divisor = 1024
    rc.unit_scale = False
    assert rc.render(None) == Text('?/s', style='progress.data.speed')
    rc.unit_scale

# Generated at 2022-06-22 05:34:42.036789
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    unit, suffix = filesize.pick_unit_and_suffix(100, [""], 1)
    assert unit == 1
    assert suffix == ""
    rate_column = RateColumn(unit="sec", unit_scale=500, unit_divisor=1000)
    assert (rate_column.render(SpeedTest(speed=None)).text == '? sec/s')
    assert (rate_column.render(SpeedTest(speed=600)).text == '600 sec/s')
    unit, suffix = filesize.pick_unit_and_suffix(600, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], 500)
    assert unit == 1
    assert suffix == ""
    assert (rate_column.render(SpeedTest(speed=600)).text == '600 sec/s')
   

# Generated at 2022-06-22 05:34:52.415472
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        with tqdm(total=5) as pbar:
            pbar.clear()
            pbar.display()
    except Exception as e:
        assert False, e
    try:
        with tqdm(total=5) as pbar:
            pbar.clear()
            for i in range(5):
                pbar.update()
            pbar.clear()
    except Exception as e:
        assert False, e
    try:
        with tqdm(total=5) as pbar:
            pbar.clear()
            for i in range(5):
                pbar.update()
    except Exception as e:
        assert False, e



# Generated at 2022-06-22 05:34:55.092578
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # test call to display method of class tqdm_rich
    t = std_tqdm(0, 10, 1)
    t.display()



# Generated at 2022-06-22 05:35:07.932104
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test speed is less than 1024
    column = RateColumn(unit="MB", unit_scale=False, unit_divisor=1000)
    assert column.render(100) == Text("100 MB/s", style="progress.data.speed")
    assert column.render(100.123) == Text("100 MB/s", style="progress.data.speed")
    assert column.render(100.1234) == Text("100.1 MB/s", style="progress.data.speed")
    assert column.render(None) == Text("? MB/s", style="progress.data.speed")

    # Test speed is more than 1024
    column = RateColumn(unit="MB", unit_scale=False, unit_divisor=1000)
    assert column.render(2000) == Text("2 MB/s", style="progress.data.speed")

# Generated at 2022-06-22 05:35:11.296741
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    assert tqdm_rich(total=2, leave=False).display() is None
    assert tqdm_rich(total=2, leave=False, disable=None).display() is None

# Generated at 2022-06-22 05:35:12.382318
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-22 05:35:19.405930
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    assert tqdm_rich(desc="foo", total=1, bar_format="{desc}{bar}").format_dict == {'desc': 'foo', 'bar_format': '{desc}{bar}', 'total': 1, 'unit': 'it', 'unit_scale': False, 'unit_divisor': 1000, 'gui': True, 'leave': True, 'postfix': None, 'miniters': 0, 'mininterval': 0.1, 'dynamic_ncols': True}


# Generated at 2022-06-22 05:35:31.654951
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    segmented_bar = FractionColumn()
    assert segmented_bar.render(0) == "0/0"
    assert segmented_bar.render(1) == "1/1"
    assert segmented_bar.render(10) == "10/10"
    assert segmented_bar.render(100) == "100/100"
    assert segmented_bar.render(1001) == "1,001/1,001"
    assert segmented_bar.render(1234) == "1,234/1,234"
    assert segmented_bar.render(1234567) == "1,234,567/1,234,567"
    assert segmented_bar.render(12345678) == "12,345,678/12,345,678"

# Generated at 2022-06-22 05:35:43.673537
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest

    class TestFractionColumn(unittest.TestCase):

        def test_render(self):
            from rich.progress import Progress
            from rich.progress import ProgressColumn
            from rich.text import Text

            class TestProgressColumn(ProgressColumn):
                def render(self, task):
                    return Text("Test Progress Column")

            progress = Progress("Fraction Test")
            progress.add_task("Test Task", total=100, completed=50)
            fraction_column = FractionColumn()
            test_column = TestProgressColumn()

            # Test that the render method of FractionColumn returns a Text object
            render_result = fraction_column.render(progress.tasks[0])
            self.assertIsInstance(render_result, Text)

            # Test that the render method of FractionColumn returns a different Text object than the

# Generated at 2022-06-22 05:35:56.725262
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import copy
    import sys

    # create tqdm object
    pbar = tqdm_rich(0, 0)

    # Test when the total is equal to 0
    pbar_copy_1 = copy.copy(pbar)
    pbar.total = None
    pbar_1 = pbar.reset(total=0)
    try:
        assert pbar._prog == pbar._prog
        assert pbar_1 == pbar_copy_1
    except AssertionError:
        # print appropriate error message
        print('The method reset is not working properly to reset the '
              'iteration count')
        sys.exit(1)

    # Test when the total is positive
    pbar.n = 2
    pbar_copy_2 = copy.copy(pbar)
    pbar.n = None

# Generated at 2022-06-22 05:36:01.229074
# Unit test for function trange
def test_trange():
    for _ in trange(4, desc='Cooling down...', leave=True):
        pass
    for _ in trange(4, desc='Loading...', bar_width=30, leave=True,
                    show_percent=True, show_pos=True, unit_scale=True,
                    unit='B'):
        pass

# Generated at 2022-06-22 05:36:05.226156
# Unit test for constructor of class RateColumn
def test_RateColumn():
    task = tqdm(total=100)
    task.update(1)
    progress = RateColumn()
    progress.render(task)


if __name__ == '__main__':
    test_RateColumn()

# Generated at 2022-06-22 05:36:11.755882
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import io
    import sys
    capture = io.StringIO()
    sys.stdout = capture
    try:
        with trange(10, desc='test') as bar:
            for i in bar:
                pass
    finally:
        sys.stdout = sys.__stdout__
    bar_content = capture.getvalue()
    assert 'test' in bar_content
    assert '100%|################' in bar_content

# Generated at 2022-06-22 05:36:14.478647
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    iterator = tqdm_rich(['1', '2', '3'], ascii=True)
    for char in iterator:
        pass
    iterator.close()

# Generated at 2022-06-22 05:36:17.077113
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        tqdm_rich.clear()
    except AttributeError:
        pass
    else:
        raise Exception("AttributeError not raised")

# Generated at 2022-06-22 05:36:21.911784
# Unit test for function trange
def test_trange():  # pragma: no cover
    with trange(5) as t:
        for i in t:
            assert i < 5
            assert i >= 0
            assert isinstance(t.display, tqdm.display)
            t.display()

# Generated at 2022-06-22 05:36:30.324742
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm  # noqa
    from .std import tnrange  # noqa

    with tqdm(total=10, ascii=True) as pbar:
        pbar.update(1); pbar.update(1)
        assert pbar.n == 2
        pbar.n = 5
        assert pbar.n == 5
        pbar.update(1); pbar.update(2)
        with tnrange(1) as nested_widget:
            nested_widget.update()
    assert pbar.n == 10
    assert pbar.total == 10

# Generated at 2022-06-22 05:36:34.551100
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    # Disable is True
    with tqdm_rich(total=100, disable=True) as t:
        assert t.disable

    # Disable is False
    with tqdm_rich(total=100) as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:36:47.099521
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress, TimeRemainingColumn
    from rich.console import Console
    from rich.markdown import Markdown

    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        TimeRemainingColumn(),
    )
    progress.__enter__()

    rich_console = Console()
    markdown = Markdown(
        "## Testing the method `display` of class `tqdm_rich`",
        rich_console=rich_console,
    )
    markdown.render()
    rich_console.line()

    rich_console.print("The following output should contain only two times the task")

# Generated at 2022-06-22 05:37:09.131308
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(1, disable=True) as t:
        t.total = 10
        assert t.n == 1
        assert t.total == 10
    with tqdm_rich(1) as t:
        t.reset(total=10)
        assert t.n == 0
        assert t.total == 10

# Generated at 2022-06-22 05:37:13.636755
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm(total=100, desc="test") as p:
        assert isinstance(p, tqdm_rich)
        assert p.total == 100
        assert p.desc == "test"
        p.update()
        p.close()

if __name__ == '__main__':
    # Unit test for constructor of class tqdm_rich
    test_tqdm_rich()

# Generated at 2022-06-22 05:37:15.946394
# Unit test for function trange
def test_trange():
    iterable = trange(10)
    assert iterable.__iter__()



# Generated at 2022-06-22 05:37:18.674619
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with trange(8) as t:
        for i in t:
            assert i == t.n - 1



# Generated at 2022-06-22 05:37:23.832207
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Test for constructor of class RateColumn
    """
    progress_column = RateColumn()
    assert progress_column.unit == ""
    assert progress_column.unit_scale == False
    assert progress_column.unit_divisor == 1000
    assert progress_column.task == None


# Generated at 2022-06-22 05:37:33.276448
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.progress import BarColumn, FractionColumn
    from .utils import NoOpMonitorMixin

    # Mock Progress class
    _progress = Progress()
    _progress.__len__ = lambda self: 1
    _progress._tasks = {0: (1, 1, "")}
    _progress.detach = lambda *args, **kwargs: None
    _progress.attach = lambda *args, **kwargs: None
    _progress.console = Console()

    # Mock BarColumn class
    class _bar_column(NoOpMonitorMixin):
        def __len__(self):
            return 1

        def render(self, task):
            return "|50%|"

        def __eq__(self, other):
            return True

    # Mock Fraction

# Generated at 2022-06-22 05:37:44.655315
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich import print
    from .utils import _test_reset_pos, _test_postfix_exception
    from .utils import _test_leave
    from .gui import _test_gui_environment

    _test_gui_environment()
    _test_reset_pos()
    _test_postfix_exception()
    _test_leave()

    # Test normal case
    total = 10
    with tqdm_rich(total=total) as bar:
        for n in range(total):
            bar.update()

    # Test reset total
    total = 100
    with tqdm_rich(total=total) as bar:
        for n in range(total):
            bar.update()
            if n == 50:
                bar.reset(total=200)

    # Test reset total and position
    total = 100


# Generated at 2022-06-22 05:37:56.398812
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import Text

    progress = (Text("[progress.description]{task.description}"),
                BarColumn(bar_width=None),
                Text("{task.completed}"),
                Text("/"),
                Text("{task.total}"),
                Text("["),
                TimeElapsedColumn(),
                Text("<"),
                TimeRemainingColumn(),
                Text("]")
                )

    with Progress(*progress, transient=True) as prog:
        task_id = prog.add_task("Estimating")

        # Test the initial values of the task
        assert prog.tasks[task_id].completed == 0
        assert prog.tasks

# Generated at 2022-06-22 05:38:01.694936
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10000, unit="unit", desc="desc", leave=True, position=3,
                   bar_format="bar_format", dynamic_ncols=True, miniters=10, mininterval=0.5,
                   maxinterval=2, file=sys.stderr) as iterable:
        for _ in iterable:
            pass

# Generated at 2022-06-22 05:38:03.233300
# Unit test for constructor of class RateColumn
def test_RateColumn():
    a = RateColumn("bit")
    print(a)

# Generated at 2022-06-22 05:38:44.226077
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="b", unit_scale=True, unit_divisor=1024).render(
        # Mock object to make it runnable
        type("", (), {'speed': None, 'total': 4, "completed": 2})()) == "[progress.data.speed]? b/s"
    assert RateColumn(unit="b", unit_scale=True, unit_divisor=1024).render(
        type("", (), {'speed': 8 * 1024 * 1024 * 1024 * 1024 ** 2, 'total': 4, "completed": 2})()) == \
        "[progress.data.speed]8.0 Tb/s"

# Generated at 2022-06-22 05:38:49.549813
# Unit test for constructor of class RateColumn
def test_RateColumn():
    test = RateColumn(unit_divisor=1000)
    assert test.unit_divisor == 1000
    test = RateColumn(unit_scale=True)
    assert test.unit_scale == True
    test = RateColumn(unit="B")
    assert test.unit == "B"
    # test

# Generated at 2022-06-22 05:38:57.208407
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    >>> import random
    >>> random.seed(123)
    >>> task1 = tqdm(total=1e8, unit_scale=True, unit_divisor=1024)
    >>> task2 = tqdm(total=1e8, unit_scale=False)
    >>> for i in range(1000000):
    ...     task1.update(random.randrange(10, 100))
    ...     task2.update(random.randrange(10, 100))
    """
    pass

# Generated at 2022-06-22 05:39:05.170575
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<"
    )
    with tqdm_rich(range(10), progress=progress) as pbar:
        for i in pbar:
            if i == 5:
                pbar.reset(total=3)
                pbar.set_description("Reset!")
            time.sleep(.5)

# Generated at 2022-06-22 05:39:10.650807
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .gui import _prog_render
    with tqdm_rich(ascii=True, desc='test', miniters=1) as t:
        for i in t:
            if i >= 5:
                break
    assert _prog_render() == 'test\n  5/5 [####################] 100%\n'



# Generated at 2022-06-22 05:39:17.910241
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn. This method gets the transfer speed
    as input, and returns the human readable transfer speed with the right unit,
    and style.
    """
    c = RateColumn()
    task = type('', (), {'speed': 100})()
    assert c.render(task) == Text("100 B/s", style="progress.data.speed")

    c = RateColumn(unit='B')
    assert c.render(task) == Text("100 BB/s", style="progress.data.speed")
    c = RateColumn(unit='test')
    assert c.render(task) == Text("100 testB/s", style="progress.data.speed")

    c = RateColumn(unit_scale=True)

# Generated at 2022-06-22 05:39:22.570668
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # unit testing
    # create a task with a completed and total
    task = type('Task', (object,), {"completed": 50, "total": 100})()
    
    # test with a unit_scale = False, unit_divisor = 1
    test_column = FractionColumn(unit_scale=False, unit_divisor=1)
    assert test_column.render(task) == Text(
            f"{int(task.completed)/1:,.0f}/{int(task.total)/1:,.0f}",
            style="progress.download")
    
    # test with a unit_scale = False, unit_divisor = 1000
    test_column = FractionColumn(unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-22 05:39:31.112512
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test method reset of class tqdm_rich
    """
    import os
    import random
    import time

    bar = tqdm(total=100)
    for i in range(random.randint(1, 100)):
        bar.update(1)
        time.sleep(0.1)

    bar.reset(total=50)
    for i in range(random.randint(1, 50)):
        bar.update(1)
        time.sleep(0.1)

    bar.reset()
    for i in range(random.randint(1, 100)):
        bar.update(1)
        time.sleep(0.1)

# Generated at 2022-06-22 05:39:34.728197
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=10) as t:
        assert t.total == 10
        t.reset()
        assert t.total == 10
        t.reset(20)
        assert t.total == 20


# Generated at 2022-06-22 05:39:40.803375
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import os
    import sys
    # save old stdout
    old_stdout = sys.stdout
    # redirect to a file
    fd = open(os.devnull,'w')
    sys.stdout = fd
    frac_col = FractionColumn()
    frac_col.render()
    # close file
    fd.close()
    sys.stdout = old_stdout
    return 0

# Generated at 2022-06-22 05:40:13.949144
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Test `rich.progress.RateColumn.__init__()`"""
    column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024,
                        style="progress.data.rate")
    assert str(column) == '[progress.data.rate]? B/s'

# Generated at 2022-06-22 05:40:18.191011
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # If a rich progress instance is active
    # then method close must be callable
    # and not produce an error.
    rich_tqdm = tqdm_rich(total=100)
    assert rich_tqdm.disable is False
    rich_tqdm.close()


# Generated at 2022-06-22 05:40:27.918689
# Unit test for function trange
def test_trange():
    """Test trange with various durations."""
    test_cases = (1e-6, 1e-5, 1e-4)

# Generated at 2022-06-22 05:40:31.966136
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import time
    from .gui import tgui
    from .utils import _range

    with tgui(leave=True):
        for i in trange(5):
            time.sleep(1)


# Generated at 2022-06-22 05:40:35.898853
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Check type of FractionColumn's object."""
    assert type(FractionColumn(unit_scale=False, unit_divisor=1000)) == FractionColumn

# Generated at 2022-06-22 05:40:37.301662
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="bits", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:40:47.548109
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.text import Text
    from rich.panel import Panel
    from rich.markup import Markup
    import time
    import numpy as np

    n = 100
    text_color = "white"
    progress_bar_bg_color = "magenta"
    progress_bar_text_color = "black"
    progress_bar_color = "white"
    style = f"""
    option {{
        text: {text_color} {{
        }}
        bar: {{
            bg: {progress_bar_bg_color}
            text: {progress_bar_text_color}
            bar: {progress_bar_color}
        }}
    }}
    """

# Generated at 2022-06-22 05:40:49.542928
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = 'T'
    columns = RateColumn('bps')
    columns.render(task)
    assert True

# Generated at 2022-06-22 05:41:00.229590
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = lambda completed, total, description="text_task", total_postfix="" : type('', (), {
        'completed': completed,
        'total': total,
        'description': description,
        'total_postfix': total_postfix})()

    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(task(20, 30)) == Text('20/30', style='progress.download')
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(task(20, 30, 'label')) == Text('20/30', style='progress.download')
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(task(20, 30, 'label', 'postfix')) == Text('20/30', style='progress.download')

# Generated at 2022-06-22 05:41:06.819524
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task(object):
        completed: int = 0
        total: int = 0
    task = Task()
    frac = FractionColumn()
    task.completed = 110
    task.total = 222
    assert frac.render(task) == '0.5/1.0 '
    task.completed = 1100
    task.total = 2222
    assert frac.render(task) == '0.5/1.0 K'
    task.completed = 1100000
    task.total = 2222000
    assert frac.render(task) == '1.1/2.2 M'
    task.completed = 1100000000
    task.total = 2222000000
    assert frac.render(task) == '1.1/2.2 G'
    task.completed = 1100000000000
    task.total

# Generated at 2022-06-22 05:42:04.500199
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=5) as bar:
        bar.reset(total=10)
        for i in range(10):
            bar.update()
        assert bar.total == 10
        assert bar.n == 10

# Generated at 2022-06-22 05:42:08.164499
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import warnings

    warnings.filterwarnings('ignore', category=TqdmExperimentalWarning)
    with tqdm(total=2) as t:
        for _ in range(2):
            t.update(1)

if __name__ == '__main__':
    test_tqdm_rich_close()

# Generated at 2022-06-22 05:42:10.989247
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm(total=2) as pbar:
        pbar.set_description("testing")
        for i in range(2):
            pbar.update()

# Generated at 2022-06-22 05:42:19.468460
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(Progress.Task(25, 125)) == \
        Text('0.2/1.2 K', style='progress.download')
    assert column.render(Progress.Task(250, 1250)) == \
        Text('0.2/1.3 K', style='progress.download')
    assert column.render(Progress.Task(250, 1250, unit_scale=False)) == \
        Text('250.0/1250.0 ', style='progress.download')
    assert column.render(Progress.Task(250, 1250, unit_divisor=1000)) == \
        Text('0.2/1.2 K', style='progress.download')


# Generated at 2022-06-22 05:42:22.591727
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    def f():
        for _ in tqdm(range(5), desc='test', leave=False):
            pass
    f()


# Generated at 2022-06-22 05:42:33.126924
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn(unit_scale=True).render(
        Progress(total=2000, completed=1000)) == Text(
            f"1.0/2.0 K",
            style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(
        Progress(total=2000, completed=1000)) == Text(
            f"1.0/2.0 Ki",
            style="progress.download")
    assert FractionColumn(unit_scale=False, unit_divisor=1024).render(
        Progress(total=2000, completed=1000)) == Text(
            f"1/2",
            style="progress.download")

# Generated at 2022-06-22 05:42:43.844490
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import FractionColumn, Text, BarColumn
    from rich.style import Style
    from rich.text import Text as RichText
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    from tqdm import trange

    progress_bar = trange(10, desc='bar', leave=False)
    progress_bar._prog.reset = MagicMock(name='reset')
    reset_call_count = progress_bar._prog.reset.call_count
    progress_bar.reset()
    assert reset_call_count + 1 == progress_bar._prog.reset.call_count

# Generated at 2022-06-22 05:42:53.237022
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.gui import tqdm as tqdm_gui
    for cls in (tqdm_rich, tqdm_auto, tqdm_gui):
        progress = cls(range(10))
        progress.update(5)
        progress.display()
        try:
            progress.close()
        except:  # noqa
            pass
        progress.unfinished = True
        progress.display()
        progress.leave = True
        progress.display()
        progress.close()
        progress.display()

        progress = cls(range(10), total=20)
        progress.update(5)
        progress.display()