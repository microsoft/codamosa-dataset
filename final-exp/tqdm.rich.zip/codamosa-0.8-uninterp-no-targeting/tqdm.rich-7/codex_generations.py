

# Generated at 2022-06-22 05:33:07.754548
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.console import Console
    from rich.progress import TaskID

    console = Console()
    progress = Progress(bar_width=None, transient=False)
    description = "Rich is Cool"
    _task_id = TaskID()

    t = tqdm(disable=False, desc=description, leave=False, console=console,
             total=100, ascii=True, unit='B', unit_scale=False, unit_divisor=1000,
             miniters=1, mininterval=0.1, maxinterval=10.0, file=None, smooth=False)

    assert(t.desc == description)

    t._prog = progress
    t._task_id = _task_id
    task = progress.get_task(_task_id)
    assert(task.description == description)

   

# Generated at 2022-06-22 05:33:16.337732
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    pbar = tqdm_rich(total=100)

    for i in _range(100):
        assert int(pbar) == i
        pbar.update()

    pbar.close()

    assert pbar.n == 100
    assert pbar.total == 100
    assert pbar.last_print_n == 100
    assert pbar.last_print_t == pbar.n
    assert pbar.last_print_refresh_t == pbar.last_print_t
    assert pbar.n == 100

# Generated at 2022-06-22 05:33:18.495028
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in trange(19):
        pass
    # print(tqdm_rich.clear)

# Generated at 2022-06-22 05:33:21.404493
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    pbar = tqdm_rich(100)
    assert isinstance(pbar, tqdm_rich)
    assert isinstance(pbar._prog, Progress)

# Generated at 2022-06-22 05:33:32.049497
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import os
    import random
    import tempfile

    ## construct test function
    def test_function(delay = 0.1, disable = False):
        try:
            total = random.randint(1, 100)
            with tqdm_rich(total = total,
                           disable = disable,
                           file = sys.stderr,
                           leave = True,
                           unit = 'B',
                           unit_scale = True) as pbar:
                for i in range(total):
                    pbar.update(1)
            return 1
        except Exception as e:
            return 0

    ## testing test function
    success = 0
    for i in range(100):
        success += test_function(random.random(),
                                 disable = random.choice([True, False]))

# Generated at 2022-06-22 05:33:43.757297
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1), "]"
    )
    task_id = progress.add_task('Downloading File', total=100, completed=0)
    i = 0
    while i < 100:
        i += 1
        progress.update(task_id, completed=i)
    progress.__enter__()
    progress.__exit__()

# Generated at 2022-06-22 05:33:49.521417
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    bar = FractionColumn()
    task = Task(description='description', total=12)
    task.add_done(4)
    assert bar.render(task) == Text('0.3/1.0 K', style='progress.download')
    task.add_done(8)
    assert bar.render(task) == Text('1.0/1.0 K', style='progress.download')


# Generated at 2022-06-22 05:33:52.779200
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with trange(10) as pbar:
        for i in pbar:
            pass

# Generated at 2022-06-22 05:33:55.192353
# Unit test for function trange
def test_trange():
    """Test for trange"""
    with trange(4) as t:
        for i in t:
            assert t.n == i + 1

# Generated at 2022-06-22 05:34:02.383636
# Unit test for function trange
def test_trange():
    """Test trange wrapper"""
    rich_tqdm = trange(10)
    try:
        standard_tqdm = std_tqdm(range(10))
        for x in rich_tqdm:
            next(standard_tqdm)
    finally:
        rich_tqdm.close()
        standard_tqdm.close()
    assert all(x == y for x, y in zip(rich_tqdm.format_dict, standard_tqdm.format_dict))

# Generated at 2022-06-22 05:34:15.313577
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    fc.render(ProgressColumn)


if __name__ == '__main__':  # pragma: no cover
    import time

    # Tests
    pbar = tqdm(total=100)
    for i in range(0, 100):
        pbar.update(1)
        time.sleep(0.02)
    pbar.close()
    pbar = tqdm(total=100)
    for i in range(0, 100):
        pbar.update(1)
        time.sleep(0.02)
    pbar.close()
    tr = tqdm(total=100)
    for i in trrange(100):
        time.sleep(0.02)
    tr.close()
   

# Generated at 2022-06-22 05:34:17.323226
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .tests import test_FractionColumn_render
    test_FractionColumn_render(FractionColumn)

# Generated at 2022-06-22 05:34:21.512233
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    assert tqdm_rich(total=10, desc="bar", mininterval=0.1, miniters=0).miniters == 0

# Generated at 2022-06-22 05:34:24.350567
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for RateColumn"""
    column = RateColumn()
    assert column.render(object()) == '0 B/s'

# Generated at 2022-06-22 05:34:36.058600
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from textwrap import dedent
    from time import sleep

    def check_render(text):
        assert len(dedent(text.strip("\n")).splitlines()) <= 5
        assert '\n' in text
        assert text.endswith('\n')


# Generated at 2022-06-22 05:34:38.019767
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    fraction = column.render("")
    assert fraction == "0/0 "

# Generated at 2022-06-22 05:34:45.317786
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = BarColumn()
    task.completed = 52
    task.total = 255
    percent = 52/255
    task.speed = percent*255
    tc = RateColumn()
    tc.render(task)

    assert tc.render(task) == Text("2.0 B/s", style="progress.data.speed")

# Generated at 2022-06-22 05:34:49.280508
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.unit_scale == False
    assert fc.unit_divisor == 1000

if __name__ == '__main__':
    test_FractionColumn()

# Generated at 2022-06-22 05:34:53.047310
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import console
    console.get_console().print("")
    test_tqdm_rich = tqdm_rich(range(10))
    test_tqdm_rich.display()
    test_tqdm_rich.close()

# Generated at 2022-06-22 05:34:58.189922
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich

    with rich.console.Console() as console:
        with tqdm(total=10) as t:
            for i in range(4):
                t.display()
                console.print(t)
            t.reset(total=20)
            for i in range(20):
                t.display()
                console.print(t)

# Generated at 2022-06-22 05:35:08.382344
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(10))
    t.clear()
    t.close()

# Generated at 2022-06-22 05:35:18.873079
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    assert tqdm_rich(1).total == 1
    assert tqdm_rich(2, 3).total == 2
    assert tqdm_rich(3, 4).total == 3

    assert tqdm_rich(0, 30).total == 30
    assert tqdm_rich(1, 30).total == 30
    assert tqdm_rich(10, 30).total == 30
    assert tqdm_rich(30, 30).total == 30

    assert tqdm_rich("a", "30").total == 0
    assert tqdm_rich("a", "30", 1).total == 0
    assert tqdm_rich("a", "30", "1").total == 1
    assert tqdm_rich("a", "30", "10").total == 10
    assert tqdm_

# Generated at 2022-06-22 05:35:22.069225
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as pbar:
        pbar.clear()
        pbar.clear()
        return pbar

# Generated at 2022-06-22 05:35:29.692831
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    # On Python2, the following pytest skips the test because of unicode issues.
    # To check the unit test manually on Python2, disable the below pytest skip.
    for _ in trange(10):
        pass


if __name__ == '__main__':
    # On Python2, the following pytest skips the test because of unicode issues.
    # To check the unit test manually on Python2, disable the below pytest skip.
    test_trange()

# Generated at 2022-06-22 05:35:41.802578
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID

    class MyProgress:
        def __init__(self):
            self.started = False
            self.tasks = {}
            self.total = None
            self.completed = None

        def __enter__(self):
            self.started = True
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.started = False

        def add_task(self, description, **kwargs):
            task_id = TaskID()
            self.tasks[task_id] = {
                'description': description,
                'completed': kwargs['completed'],
                'total': kwargs['total'],
            }
            return task_id


# Generated at 2022-06-22 05:35:51.587904
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from tqdm._utils import _term_move_up as term_move_up
    l = list(trange(10))
    assert l == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for _ in trange(4, 4, 2):
        term_move_up()
    with trange(10, bar_format="{l_bar} {bar} {n_fmt}/{total_fmt} [{rate_fmt}{postfix}]") as t:
        for i in t:
            pass
    with trange(10, desc="default", leave=True) as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:35:55.170674
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .std import tqdm
    assert not hasattr(tqdm, '_prog')

    with tqdm(total = 32) as t:
        assert hasattr(t, '_prog')

    assert not hasattr(t, '_prog')

# Generated at 2022-06-22 05:36:00.958961
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import default_task_id  # type: ignore
    except ImportError:
        pass  # Missing rich
    else:
        from mock import patch
        with patch('rich.progress.Progress.update') as update_mock:
            tqdm([1, 2]).display()
            update_mock.assert_called_with(
                default_task_id, completed=2, description=None)

# Generated at 2022-06-22 05:36:13.064315
# Unit test for function trange
def test_trange():
    ints = trrange(3, 0, -1)
    assert ints._task_id is not None
    assert ints.format_dict['ncols'] == 76
    assert ints.format_dict['desc'] == '<unknown>'
    assert ints.format_dict['ascii'] is False
    assert ints.format_dict['unit'] == 'it'
    assert ints.format_dict['unit_scale'] is False
    assert ints.format_dict['unit_divisor'] == 1000
    assert ints.format_dict['miniters'] == 0
    assert ints.format_dict['mininterval'] == 0.1
    assert ints.format_dict['smoothing'] == 0.3
    assert ints.format_dict['dynamic_ncols'] is True
   

# Generated at 2022-06-22 05:36:16.943240
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import _tqdm
    t = tqdm_rich(total=2)
    stderr = sys.stderr
    sys.stderr = sys.__stderr__
    try:
        t.write("writing")
        t.display()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 05:36:38.824166
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render("task") == ('task', '', '')
    rate_column = RateColumn(unit='b', unit_scale=(False, 1000))
    assert rate_column.render("task") == ('task', '', '')
    rate_column = RateColumn(unit='b')
    assert rate_column.render("task") == ('task', '', '')
    rate_column = RateColumn(unit='b', unit_scale=(False, 1024))
    assert rate_column.render("task") == ('task', '', '')
    rate_column = RateColumn(unit='b', unit_scale=(True, 1000))
    assert rate_column.render("task") == ('task', '', '')

# Generated at 2022-06-22 05:36:41.370080
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(desc="test", total=1) as pb:
        pass
    assert pb.total == 1

# Generated at 2022-06-22 05:36:47.257338
# Unit test for function trange
def test_trange():
    for i in trange(4, desc='test'):
        pass
    assert isinstance(i, int)
    for i in trange(4, desc='test', unit_scale=True, unit_divisor=1024):
        pass
    assert isinstance(i, int)
    for i in trange(4, desc='test', unit='iB', unit_scale=True, unit_divisor=1024):
        pass
    assert isinstance(i, int)

# Generated at 2022-06-22 05:36:56.133078
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import TestCase
    from .utils import _range

    class TestTqdm(tqdm_rich):
        def __init__(self, *args, **kwargs):
            super(TestTqdm, self).__init__(*args, **kwargs)
            self.format_dict = self.format_dict.copy()
            # self.format_dict['unit'] = ''
            self.format_dict['unit_scale'] = False
            self.format_dict['unit_divisor'] = 1

    with TestCase(TestTqdm) as Test:
        with Test('test_FractionColumn_render'):
            def test_FractionColumn_render():
                list(_range(10, desc='FOO'))
                assert Test._inst.format_dict['unit_scale'] == False
                assert Test

# Generated at 2022-06-22 05:36:58.354828
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test constructor of class tqdm_rich."""
    try:
        import asyncio
    except ImportError:
        asyncio = None

    with trange(5) as bar:
        for i in bar:
            pass

# Generated at 2022-06-22 05:37:00.512332
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich(desc='test', total=10).close()



# Generated at 2022-06-22 05:37:02.441013
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10, disable=True) as a:
        a.clear()

# Generated at 2022-06-22 05:37:04.326350
# Unit test for function trange
def test_trange():
    """test for trange"""
    for _ in trange(4, leave=True):
        pass

# Generated at 2022-06-22 05:37:09.689488
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    unit_scale = False
    unit_divisor = 1000
    c = FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
    assert c.unit_scale == unit_scale
    assert c.unit_divisor == unit_divisor
    assert c.task == None



# Generated at 2022-06-22 05:37:14.952252
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    t = tqdm_rich(total=10, desc="test")
    for i in range(10):
        time.sleep(0.1)
        t.update(1)
    t.reset(total=100)
    for i in range(100):
        time.sleep(0.1)
        t.update(1)
