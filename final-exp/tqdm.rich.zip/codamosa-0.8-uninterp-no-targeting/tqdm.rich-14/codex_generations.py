

# Generated at 2022-06-22 05:33:13.638789
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from time import sleep
    for _ in tqdm_rich(range(100), desc='Testing', leave=False):
        sleep(0.1)
    with tqdm_rich(range(100), desc='Testing', leave=True) as pbar:
        for i in pbar:
            sleep(0.1)



# Generated at 2022-06-22 05:33:24.900761
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tests._tqdm_test import tqdm_factory
    from .tests._tqdm_test import NewTqdmTypeError
    from warnings import catch_warnings
    with catch_warnings(record=True) as warnings_list:
        t = tqdm_factory(tqdm_cls=tqdm_rich)
        assert t.disable
        t.update(2)
        with tqdm(total=2, disable=False) as t:
            t.update(1)
            assert t._instant_t.n == 1
            t.update(1)
            assert t._instant_t.n == 2
        with tqdm(disable=False) as t:
            with t:
                t.update(1)
            assert t._instant_t.n == 1

# Generated at 2022-06-22 05:33:36.504843
# Unit test for function trange
def test_trange():
    """tests if trange works in Jupyter notebook as well as
    in a shell environment (different progress bars)"""
    try:  # pragma: no branch
        from IPython import get_ipython
        if get_ipython() is None:
            raise ImportError
        from ipywidgets import IntProgress
        from IPython.display import display
    except ImportError:
        from tqdm.auto import tqdm
        for _ in trange(10):
            pass
        for _ in tqdm(range(10), miniters=0):
            pass
    else:
        progress = IntProgress()
        display(progress)
        progress.min = 0
        progress.max = 10
        progress.value = 0
        for _ in trange(10, bar=progress):
            pass

# Generated at 2022-06-22 05:33:41.161391
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=1000, desc="Downloading", unit="B") as pbar:
        for _ in range(1000):
            pbar.update(1)

if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-22 05:33:43.658538
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import Progress

    with Progress() as progress:
        with tqdm_rich(range(3), desc='test') as pbar:
            pass

# Generated at 2022-06-22 05:33:52.308096
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Step 1: create an instance of RateColumn
    rate_column = RateColumn()

    # Step 2: create a dummy object
    class MockTask:
        def __init__(self, speed):
            self.speed = speed
    task = MockTask(100)

    # Step 3: invoke method render
    result = rate_column.render(task)
    assert result.text == '100.0 /s'
    assert result.style.name == 'progress.data.speed'

if __name__ == "__main__":
    with tqdm_rich(total=int(1e6),
                   desc="Downloading",
                   unit="B",
                   miniters=1,
                   unit_scale=True) as progress:
        for byte in progress(range(int(1e6))):
            progress.update(1)

# Generated at 2022-06-22 05:34:03.965461
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .std import tqdm as _tqdm
    from .std import tnrange as _trange
    from .std import tqdm_notebook as _tqdm_notebook
    from .std import tnrange as _tnrange
    tqdm_rich(total=100).close()
    tqdm_rich(total=100, disable=True).close()

# Generated at 2022-06-22 05:34:09.970412
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import time
    import sys
    with tqdm(range(2), position=0, leave=True) as t:
        for i in t:
            time.sleep(0.1)
    sys.stderr.write('\n')
    with tqdm(range(2), position=1, leave=True) as t:
        for i in t:
            time.sleep(0.1)
    sys.stderr.write('\n')
    with tqdm(range(2), position=0, leave=False) as t:
        for i in t:
            time.sleep(0.1)
    sys.stderr.write('\n')

# Generated at 2022-06-22 05:34:12.219898
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for i in trange(5):
        i
        # no AttributeError
        tqdm_rich.clear()

# Generated at 2022-06-22 05:34:20.717281
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    from time import sleep

    # test 1
    with tqdm(total=5) as bar:
        for i in range(5):
            sleep(1)
            bar.reset(total=5)
            bar.update()

    # test 2
    with tqdm(total=5) as bar:
        for i in range(5):
            sleep(1)
            bar.reset(total=10)
            bar.update()
    print()  # add a new line


if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-22 05:34:30.857220
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from unittest.mock import patch
        patch.object = patch.object
    except ImportError:
        from mock import patch  # type: ignore
    with patch.object(tqdm_rich, 'display') as m:
        list(tqdm_rich(range(3)))
        list(tqdm_rich(open(__file__), 'rb', total=20))
        assert m.call_count == 2

# Generated at 2022-06-22 05:34:40.078565
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import os
    import sys
    import time
    from itertools import islice

    from .utils import TestCase, pretest_posttest, TestCaseNoQt, no_prev_cwd

    @pretest_posttest
    @no_prev_cwd
    class TestTqdmRichReset(TestCaseNoQt):
        def runTest(self):
            def reset_test():
                with tqdm(total=(sys.maxsize if os.name == 'nt' else 10**6),
                          unit='B', unit_scale=True, miniters=1,
                          gui=True, mininterval=0.1, disable=None) as t:
                    for _ in t:
                        time.sleep(0.1)

# Generated at 2022-06-22 05:34:49.375767
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # TODO: should this rate be "1.6k" rather than "1.6 K" ?
    d = {'unit': 'B', 'unit_divisor': 1000, 'unit_scale': True}
    assert RateColumn(unit=d['unit'], unit_scale=d['unit_scale'],
                      unit_divisor=d['unit_divisor']).render(None) == '0.0 K/s'

# Generated at 2022-06-22 05:35:00.430605
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn
    with Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    ) as progress:
        task_id = progress.add_task("Reset")
        progress.update(task_id, completed=1, total=10)

# Generated at 2022-06-22 05:35:02.621437
# Unit test for function trange
def test_trange():
    for n in trange(10):
        pass

# Generated at 2022-06-22 05:35:03.736377
# Unit test for function trange
def test_trange():
    # TODO: write unit test
    pass

# Generated at 2022-06-22 05:35:06.675422
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    progress = tqdm_rich(total=9)
    for i in range(9):
        progress.update(1)
    progress.close()

# Generated at 2022-06-22 05:35:09.216647
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    The method render in RateColumn class calculates 
    the speed of data transfer.

    Parameters
    ----------
    """
    pass

# Generated at 2022-06-22 05:35:16.422921
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress, Text
    progress = Progress(Text("{task.completed}/{task.total}"))
    task = progress.add_task("task")
    assert task.completed == 0
    assert task.total == 1
    assert task.render() == "0/1"
    assert task.completed == 0
    assert task.total == 2
    assert task.render() == "0/2"
    assert task.completed == 1
    assert task.total == 2
    assert task.render() == "1/2"

# Generated at 2022-06-22 05:35:20.211929
# Unit test for function trange
def test_trange():
    """a simple unit-test for function trange"""
    trange(1)
    trange(1, 10)
    trange(1, 100, 7)
    trange(10, 0, -1)
    trange(100, 0, -7)
    trange(0, -100, -7)


# Generated at 2022-06-22 05:35:30.785908
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    @tqdm_rich
    def f():
        for i in range(10):
            pass
    f()

# Generated at 2022-06-22 05:35:34.349740
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich
    except (ImportError, ModuleNotFoundError):
        return
    progress = tqdm_rich(['a', 'b', 'c'])
    progress.clear()
    progress.clear()

# Generated at 2022-06-22 05:35:45.027450
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Simple unit test for class tqdm_rich."""
    from time import sleep
    with tqdm_rich(total=2, desc="Simple") as pbar:
        sleep(1)
        pbar.update()
        sleep(1)
    with tqdm_rich(total=2, desc="Dynamic") as pbar:
        sleep(1)
        pbar.update(desc="Almost done")
        sleep(1)
        pbar.update(desc="Done")


if __name__ == "__main__":  # pragma: no cover
    try:
        import rich
    except ImportError:
        raise ImportError("tqdm.rich requires 'rich' library to be installed")
    test_tqdm_rich()

# Generated at 2022-06-22 05:35:49.005610
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    r_col = RateColumn()
    c_col = FractionColumn()
    print(c_col.unit_scale)
    #print(r_col.unit)
    print(r_col.unit_scale)
    #print(r_col.unit_divisor)

# Generated at 2022-06-22 05:35:55.057485
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import io

    with io.StringIO() as our_file, tqdm_rich(total=2, file=our_file) as t:
        assert t.disable is False
        t.update()
        t.clear()
        assert bool(our_file.getvalue()) is False
        t.update()
        assert bool(our_file.getvalue())

# Generated at 2022-06-22 05:36:07.442669
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(
        {'task': {'completed': 1234, 'total': 12346}}) == Text('1.2K/12.3K', style="progress.download")
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(
        {'task': {'completed': 12346, 'total': 1234}}) == Text('12.3K/1.2K', style="progress.download")
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(
        {'task': {'completed': 123456, 'total': 1234567}}) == Text('123.5K/1.2M', style="progress.download")

# Generated at 2022-06-22 05:36:13.456345
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Class constructor test."""
    RateColumn(unit_scale=True)
    RateColumn(unit_scale=True, unit='bytes', unit_divisor=1024)
    RateColumn(unit_scale=False, unit='bits', unit_divisor=1000)
    RateColumn(unit_scale=False, unit='', unit_divisor=1)

# Generated at 2022-06-22 05:36:23.796383
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.progress import RateColumn, ProgressColumn
    assert issubclass(RateColumn, ProgressColumn)
    assert RateColumn("").render(None).content == "? /s"
    assert RateColumn("/s").render(None).content == "? /s"
    assert RateColumn("/s", unit_scale=True).render(None).content == "? /s"
    assert RateColumn("/s", unit_scale=False).render(None).content == "? /s"
    assert RateColumn("/s", unit_scale=False, unit_divisor=1000).render(None).content == "? /s"
    assert RateColumn("/s", unit_scale=True, unit_divisor=1000).render(None).content == "? /s"
    

# Generated at 2022-06-22 05:36:34.492958
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Generate a string for transfer speed."""
    assert RateColumn().render(
        Progress(total=100, step=1, speed=1)) == "1.0 B/s"
    assert RateColumn().render(
        Progress(total=100, step=10, speed=100)) == "100.0 B/s"
    assert RateColumn().render(
        Progress(total=100, step=100, speed=100000)) == "100.0 KB/s"
    assert RateColumn().render(
        Progress(total=100, step=1000, speed=100000000)) == "100.0 MB/s"
    assert RateColumn().render(
        Progress(total=100, step=10000, speed=10000000000)) == "100.0 GB/s"

# Generated at 2022-06-22 05:36:42.189840
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.progress import Text
    from .utils import fmt_bytes

    unit_scale = True
    unit = ' bytes'
    unit_divisor = 1000
    completed = 1543
    total = 2543
    column = FractionColumn(unit_scale, unit_divisor)
    task = Progress()
    task.completed = completed
    task.total = total
    task.unit_scale = unit_scale
    task.unit = unit
    task.unit_divisor = unit_divisor
    assert type(column.render(task)) == Text
    assert column.render(task).text == f"{fmt_bytes(completed, unit='')}/{fmt_bytes(total, unit='')} {unit}"
    # Test for change [unit] option
    unit

# Generated at 2022-06-22 05:37:09.299521
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress._Tasks[0]) == '0/0'
    assert FractionColumn().render(Progress._Tasks[1]) == '0/0'
    assert FractionColumn().render(Progress._Tasks[2]) == '0/0'
    assert FractionColumn().render(Progress._Tasks[3]) == '0/0'
    assert FractionColumn().render(Progress._Tasks[4]) == '0/1'
    assert FractionColumn().render(Progress._Tasks[5]) == '0/2'
    assert FractionColumn().render(Progress._Tasks[6]) == '0/0.0'
    assert FractionColumn().render(Progress._Tasks[7]) == '0/1.0'

# Generated at 2022-06-22 05:37:17.271170
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class Task:
        def __init__(self, speed):
           self.speed = speed
    t1 = Task(1000)
    t2 = Task(1050)
    t3 = Task(1050.5)
    t4 = Task(1000.0)
    t5 = Task(100000)
    t6 = Task(100100)
    t7 = Task(100100.5)
    t8 = Task(100000.0)
    t9 = Task(100050)
    t10 = Task(100050.0)
    r1 = RateColumn()
    assert r1.render(t1) == Text("1 ,000.0 /s", style="progress.data.speed")
    assert r1.render(t2) == Text("1 ,050.0 /s", style="progress.data.speed")


# Generated at 2022-06-22 05:37:23.712659
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate=RateColumn()
    assert rate._self.unit == ""
    rate=RateColumn(unit_scale=True)
    assert rate._self.unit_scale == True
    rate=RateColumn(unit_divisor=2000)
    assert rate._self.unit_divisor == 2000
    return rate


# Generated at 2022-06-22 05:37:28.078041
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(5) as progress_bar:
        progress_bar.reset()
        for i in range(5):
            progress_bar.update()



# Generated at 2022-06-22 05:37:39.110634
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    import time
    n = 10
    with tqdm_rich(total=10, initial=0, dynamic_ncols=True) as pbar:
        for i in range(n):
            time.sleep(0.1)
            pbar.update()
    print()
    # Test reset
    with tqdm_rich(total=10, initial=0, dynamic_ncols=True) as pbar:
        for i in range(n):
            time.sleep(0.1)
            pbar.update()
        pbar.reset(total=100)
        for i in range(100):
            time.sleep(0.1)
            pbar.update()
    print()
    # Test progress

# Generated at 2022-06-22 05:37:42.981851
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render({"completed": 1.2, "total": 3.4}) == Text("1.2/3.4")



# Generated at 2022-06-22 05:37:51.302996
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=9, desc="test_tqdm_rich", unit="B", bar_format="{desc}:{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]") as pbar:
        for i in range(9):
            pbar.update(i+1)


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-22 05:37:52.195585
# Unit test for method render of class FractionColumn
def test_FractionColumn_render(): return FractionColumn().render(object)

# Generated at 2022-06-22 05:37:59.452580
# Unit test for constructor of class RateColumn

# Generated at 2022-06-22 05:38:05.638853
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest import TestCase, main
    from .utils import selftest, format_dict

    class Test(TestCase):
        def test_close(self):
            def int_iterator():
                for i in tqdm_rich(_range(5), total=5, bar_format="{bar}"):
                    yield i

            self.assertRaises(StopIteration, next, int_iterator())

    selftest(tqdm_rich, format_dict, Test)



# Generated at 2022-06-22 05:38:52.119064
# Unit test for function trange
def test_trange():
    from random import random
    from time import sleep
    from sys import platform
    from os import geteuid

    with trange(28, desc='Rich trange test') as t:
        for _ in t:
            t.set_description("Test: %i" % _)
            t.update()
            sleep(random() / 3)
        t.set_description("Done")

    # Verify that update is not required for desc updation
    for i in trange(4, desc='trange test'):
        sleep(random() / 3)
        desc = "Test: {}".format(i)
        trange.set_description(desc)

    # Verify dynamic total
    total = 10
    r = trange(total, desc='bar')
    for x in r:
        r.total = total = total + 1
        r

# Generated at 2022-06-22 05:39:03.720621
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    bar = tqdm_rich(total=100)
    assert bar.n == 0
    bar.reset(total=None)
    assert bar.n == 0
    bar.reset(total=50)
    assert bar.n == 0
    bar.reset(total=60)
    assert bar.n == 0
    bar.reset(total=50)
    assert bar.n == 0
    bar.reset(total=60)
    assert bar.n == 0
    bar.reset(total=50)
    assert bar.n == 0
    bar.reset(total=None)
    assert bar.n == 0
    bar.reset(total=60)
    assert bar.n == 0
    bar.reset(total=50)
    assert bar.n == 0


# Generated at 2022-06-22 05:39:13.408555
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_instance = tqdm_rich(total=100)
    task = tqdm_instance._prog[0]
    task.set_total(100)
    task.set_completed(100)
    task.set_description("description")
    task.set_speed(1)
    column = RateColumn()
    assert column.render(task) == Text('1 B/s', style='progress.data.speed')
    task.set_speed(3000)
    assert column.render(task) == Text('3 K/s', style='progress.data.speed')
    task.set_speed(2000)
    assert column.render(task) == Text('2 K/s', style='progress.data.speed')
    task.set_speed(1456)

# Generated at 2022-06-22 05:39:26.043479
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(
        'Downloading',
        total=1000,
        unit_scale=True,
        unit_divisor=1024,
        unit='iB',
        bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}{postfix}] {n:3.0f}%'
    )
    task.update(n=100)
    assert str(RateColumn(
        unit='iB',
        unit_scale=True,
        unit_divisor=1024
    ).render(task)) == '39.1 KiB/s'
    task.update(n=512)

# Generated at 2022-06-22 05:39:32.511245
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    for i in tqdm(range(1, 10)):
        interval = 0.2
        if i == 5:
            tqdm.reset(20, unit="B")
            interval = 1
        time.sleep(interval)

# Generated at 2022-06-22 05:39:40.749929
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    import io
    import contextlib
    f = io.StringIO()
    try:
        with contextlib.redirect_stdout(f):
            with tqdm_rich(total=1, desc='checking clear method from tqdm_rich') as pbar:
                pbar.clear()
    except Exception as e:
        assert str(e) == "clear() not supported within a rich context", \
        "Method `clear()` of class `tqdm_rich` is not working as expected. Exception:\n{}".format(e)

# Generated at 2022-06-22 05:39:45.809538
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    task={'completed': 0.5, 'total': 2.3}
    fc.render(task)

if __name__ == '__main__':
    test_FractionColumn_render()

# Generated at 2022-06-22 05:39:54.944154
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from io import StringIO
    import sys
    import os
    import traceback
    from time import time as time_
    from uuid import uuid4
    from tqdm.utils import _term_move_up
    from tqdm.tests.utils import silence, closing
    from tqdm.contrib.concurrent import process_map
    from tqdm import tnrange
    from tqdm.auto import tqdm as auto_tqdm

    # Setup
    save_stdout = sys.stdout
    sys.stdout = tqdm_stdout = StringIO()

    # Testing

# Generated at 2022-06-22 05:39:57.211595
# Unit test for function trange
def test_trange():
    from .utils import FormatStdout as _FormatStdout
    with _FormatStdout():  # Suppress prints
        trange(3)

# Generated at 2022-06-22 05:40:01.909219
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn()
    assert rc.unit == ""
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1000



# Generated at 2022-06-22 05:41:57.777036
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.theme import Theme
    console = Console(record=True)
    theme = Theme({"progress.download": "dim green"})
    console.theme = theme
    progress = Progress(FractionColumn())
    task = progress.add_task("Task 1", start=0, total=3)
    console.print(progress.render())
    progress.update(task, completed=1)
    console.print(progress.render())
    progress.update(task, completed=2)
    console.print(progress.render())
    progress.update(task, completed=3)
    console.print(progress.render())
    progress.update(task, completed=4)
    console.print(progress.render())

    # Output
   

# Generated at 2022-06-22 05:42:06.966335
# Unit test for function trange
def test_trange():
    import time
    import numpy as np
    t = trange(10)
    # Simple test of trange iterator
    for i in t:
        time.sleep(0.1)
    assert i + 1 == 10
    # Test of the optional `leave` argument
    t = trange(10, leave=True)
    for i in t:
        time.sleep(0.1)
    assert i + 1 == 10
    # Test of the `miniters` argument
    t = trange(10, miniters=5)
    for i in t:
        time.sleep(0.1)
    assert i + 1 == 10
    # Test `desc` argument
    t = trange(10, desc='foobar')
    for i in t:
        time.sleep(0.1)

# Generated at 2022-06-22 05:42:11.675304
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from time import sleep
    for i in tqdm_rich(range(3), desc='1st loop'):
        sleep(.1)
    for i in tqdm_rich(range(3), desc='2nd loop'):
        sleep(.1)
    for i in tqdm_rich(range(3), desc='3rd loop'):
        sleep(.1)

# Generated at 2022-06-22 05:42:14.638702
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test tqdm_rich constructor"""
    try:
        tqdm_rich()
    except TypeError:
        return True
    except Exception:
        return False
    return False



# Generated at 2022-06-22 05:42:18.119092
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm(total=100) as pbar:
        pbar.reset(total=2)
        assert pbar.total == 2
        pbar.reset(total=1)
        assert pbar.total == 1


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-22 05:42:23.285674
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    try:
        import rich
    except ImportError:
        return

    try:
        rich.traceback.install()
        total = 1000
        with tqdm(total=total) as progress_bar:
            for i in range(total + 1):
                progress_bar.update(1)
                if i == 500:
                    progress_bar.set_description("test_tqdm_rich")
    finally:
        rich.traceback.uninstall()


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in trange(5):
        sleep(0.5)

# Generated at 2022-06-22 05:42:24.627415
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with trange(10) as t:
        for i in t:
            pass


if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-22 05:42:32.865194
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from tqdm import trange
    import sys

    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=True),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), ",",
        RateColumn(unit="B", unit_scale=True), "]"
    )
    for i in trange(100, desc='test', progress=progress, unit_scale=True,
                    unit="B"):
        sys.stdout.flush()


# Generated at 2022-06-22 05:42:44.291077
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from tqdm.auto import tqdm as auto_tqdm
    import sys
    with tqdm_rich(["a", "b", "c", "d"]) as t:
        for i in t:
            t.set_postfix(i=i, refresh=False)
            t.update()
            t.set_postfix(i=i)
            t.update()
    t = tqdm_rich(["a", "b", "c", "d"], total=None)
    for i in t:
        t.set_postfix(i=i, refresh=False)
        t.update()
        t.set_postfix(i=i)
        t.update()

# Generated at 2022-06-22 05:42:49.472836
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import subprocess
    import sys

    with subprocess.Popen(
            [sys.executable, __file__],
            stdout=subprocess.PIPE,
            universal_newlines=True) as p:
        for line in p.stdout:
            if 'TypeError' in line:
                raise TypeError
        if p.wait() != 0:
            raise RuntimeError