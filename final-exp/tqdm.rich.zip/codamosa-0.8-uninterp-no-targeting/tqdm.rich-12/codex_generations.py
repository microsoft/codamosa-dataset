

# Generated at 2022-06-22 05:33:03.808706
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import format_interval

    # Test method render of class RateColumn
    r = RateColumn(unit_scale=False, unit_divisor=1000)
    t = ProgressColumn()
    n = time()
    print(t.render(t))
    for i in range(100):
        print(r.render(t))
        t.update(1)
    print('Time Elapsed: {}'.format(format_interval(time() - n)))


# Generated at 2022-06-22 05:33:12.460927
# Unit test for constructor of class RateColumn
def test_RateColumn():
    col = RateColumn()
    assert col.unit == ""
    assert col.unit_scale == False
    assert col.unit_divisor == 1000
    assert str(col.__init__(unit="KB", unit_scale=True, unit_divisor=1000)) == "None"
    col = RateColumn("KB", True, 1000)
    assert col.unit == "KB"
    assert col.unit_scale == True
    assert col.unit_divisor == 1000
    assert col.render("") == "None"


# Generated at 2022-06-22 05:33:17.262542
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    # total=1023, completed=512
    assert fc.render(Progress(total=1023, completed=512)) == Text('0.5/1.0 K', style='progress.download')

# Generated at 2022-06-22 05:33:20.754725
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import pytest
    x = tqdm_rich(1)
    assert x.disable is False
    x.clear()
    x.close()
    with pytest.raises(AttributeError):
        x.clear()

# Generated at 2022-06-22 05:33:23.943570
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass



# Generated at 2022-06-22 05:33:32.347840
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import TaskID
    from unittest.mock import Mock
    from unittest import TestCase

    class test_class(TestCase):

        def test_tqdm_rich_display(self):
            _prog = Mock(spec=Progress)
            _prog.add_task.return_value = TaskID("my_task")
            obj = tqdm_rich()
            obj._prog = _prog
            obj._task_id = TaskID("my_task")
            obj.n = 2
            obj.desc = "Testing"
            obj.display()
            _prog.update.assert_called_once_with(
                TaskID("my_task"), completed=2, description="Testing")

# Generated at 2022-06-22 05:33:43.378927
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-22 05:33:53.173841
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest import TestCase
    class T(TestCase):
        def test_method_reset(self):
            self.assertEqual(tqdm(range(1), total=1)._prog.total, 1)
            self.assertEqual(tqdm(range(1), total=2)._prog.total, 2)
            self.assertEqual(tqdm(range(1), total=3)._prog.total, 3)
            self.assertEqual(tqdm(range(1), total=4)._prog.total, 4)

        def test_method_reset_argument(self):
            _tqdm = tqdm(range(1), total=1)
            for _ in range(4):
                _tqdm._prog.total += 1
                _tqdm

# Generated at 2022-06-22 05:33:55.075542
# Unit test for function trange
def test_trange():
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-22 05:34:00.440173
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=3) as pbar:
        pbar.display()
        pbar.display()
        pbar.n = 2
        pbar.display()
        pbar.n = 3
        pbar.display()


test_tqdm_rich_display()

# Generated at 2022-06-22 05:34:09.911903
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import pytest

# Generated at 2022-06-22 05:34:20.807482
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich."""
    import time
    import os
    import sys
    import subprocess

    command_list = [sys.executable, '-m', 'tqdm._tqdm',
                    '-n', '5', '--total', '10', 'position', '--leave']
    # Hide stdin, stdout, stderr to avoid issues on some platforms,
    # e.g. https://github.com/tqdm/tqdm/issues/811

# Generated at 2022-06-22 05:34:25.971966
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test of the method render.
    """
    text1 = FractionColumn(unit_scale=False, unit_divisor=1000).render(ProgressColumn)
    assert text1 == Text('0.0/0.0', style='progress.download')

# Generated at 2022-06-22 05:34:31.589799
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    expected_values = [0, 5, 10, 20, 40, 80, 160, 320, 420]
    for i, val in enumerate(tqdm_rich(total=420)):
        if i == 9:  # 9 = len(expected_values)
            break
        assert val == expected_values[i]
        if i < 3:  # 3 = len(expected_values) - 2
            # No reset
            continue
        tqdm_rich.reset(total=expected_values[i+1])

# Generated at 2022-06-22 05:34:40.433309
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.table import Table
    from rich.progress import Progress
    from .utils import b

    # Unit test for method render of class FractionColumn
    table = Table(show_header=True, header_style="bold magenta")

    task = Progress.add_task(description="Test", total=100, completed=10)
    table.add_column(FractionColumn(unit_scale=True, unit_divisor=2), width=20)

    table.add_row(task.get_progress())

# Generated at 2022-06-22 05:34:44.955239
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    r = tqdm_rich(total=10)
    r.display()
    r.close()
test_tqdm_rich_display()

# Generated at 2022-06-22 05:34:51.134851
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # test without _prog attribute
    t = tqdm_rich()
    t.disable = True
    t.close()
    t.disable = False
    t.close()

    # test with _prog attribute
    t = tqdm_rich()
    t._prog = None
    t.close()

    t = tqdm_rich()
    t._prog = 0
    t.close()

# Generated at 2022-06-22 05:34:57.339048
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm import trange
    a = trange(10, desc='1st loop')
    for i in a:
        time.sleep(0.1)
    b = trange(100, desc='2nd loop')
    for i in b:
        time.sleep(0.01)
    b.reset(total=1000)
    for i in b:
        time.sleep(0.001)

# Generated at 2022-06-22 05:35:00.571458
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=5, mininterval=0.5)
    for i in range(5):
        t.update(n=1)
        t.set_description("test")

# Generated at 2022-06-22 05:35:13.313371
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # modified method render of class FractionColumn to use
    # a string in place of Text
    def r_test(task):
        completed = int(task.completed)
        total = int(task.total)
        if task.unit_scale:
            unit, suffix = filesize.pick_unit_and_suffix(
                total,
                ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
                task.unit_divisor,
            )
        else:
            unit, suffix = filesize.pick_unit_and_suffix(total, [""], 1)
        precision = 0 if unit == 1 else 1
        return f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}"

   

# Generated at 2022-06-22 05:35:25.189086
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tqdm_gui import tqdm_gui
    with tqdm_gui(total=11, miniters=0) as pbar:
        for i in _range(11):
            pbar.update()

# Generated at 2022-06-22 05:35:37.212696
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import os
    import tempfile

    def cleanup(file):
        try:
            os.remove(file)
        except (IOError, OSError):
            pass

    # Test 1 - Test closing the ProgressBar
    # Test that closing the ProgressBar works

# Generated at 2022-06-22 05:35:47.876837
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    import os
    import sys
    import tempfile

    if os.getenv("TERM") is None:
        # Don't even try to run tests on pure pipes
        return

    with tempfile.TemporaryFile('r+t') as fout, tempfile.TemporaryFile() as fin:
        # Initial display is written to fout
        # Important: do not use rich.progress.Progress() here
        with Progress(file=fout, transient=True) as prog:
            tid = prog.add_task("test", total=1337)
            prog.update(tid, completed=0)
        fout.seek(0)
        print(fout.read(), file=fin)
        # Subsequent updates are written to fin

# Generated at 2022-06-22 05:35:58.981829
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn()) == "? B/s"
    assert str(RateColumn(unit = "B")) == "? B/s"
    assert str(RateColumn(unit = "iB")) == "? iB/s"
    assert str(RateColumn(unit = "B", unit_scale = True)) == "? B/s"
    assert str(RateColumn(unit = "iB", unit_scale = True)) == "? iB/s"
    assert str(RateColumn(unit = "B", unit_scale = True, unit_divisor = 1024)) == "? B/s"
    assert str(RateColumn(unit = "iB", unit_scale = True, unit_divisor = 1024)) == "? iB/s"

# Generated at 2022-06-22 05:36:01.538322
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    from .tests import dummy
    with trange(8) as t:
        for i in t:
            dummy(i)

# Generated at 2022-06-22 05:36:07.833358
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import gc
    # test that closing a tqdm_rich bar instance
    # does not render the bar unusable
    for _ in range(2):
        t = tqdm_rich(range(3))
        for i in t:
            pass
        t.close()
        for i in t:
            pass
        gc.collect()


# Generated at 2022-06-22 05:36:09.546140
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rateColumn = RateColumn("B")
    assert rateColumn.unit == "B"
    assert rateColumn.unit_scale is False
    assert rateColumn.unit_divisor is 1000

# Generated at 2022-06-22 05:36:14.782238
# Unit test for function trange
def test_trange():
    """Tests tqdm.rich.trange()"""
    import time
    with trange(10) as t:
        for i in t:
            if i == 0:
                pass  # First iteration is slow
            time.sleep(0.1)


if __name__ == '__main__':  # pragma: no cover
    test_trange()

# Generated at 2022-06-22 05:36:22.461767
# Unit test for function trange
def test_trange():
    from rich.progress import Progress as _Progress
    from rich.progress import TaskID as _TaskID
    from rich.console import Console as _Console

    console = _Console()

    progress_kwargs = {'console': console}
    progress = _Progress(**progress_kwargs)

    task_kwargs = {'total': 5, 'description': 'Description'}
    task_id = _TaskID(progress, **task_kwargs)

    progress.update(task_id, completed=3)
    progress.__exit__(None, None, None)
    progress.__enter__()
    progress.__exit__(None, None, None)
    progress.update(task_id, completed=4)

# Generated at 2022-06-22 05:36:27.430441
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich display method"""
    #_s = tqdm_rich(["a","b","c"])
    _s = tqdm_rich(["a","b","c"], unit = "", gui = True, total = 3, dynamic_ncols = True)
    # TODO: how to make sure the display method is called
    assert True

# Generated at 2022-06-22 05:36:46.327042
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn("") == '?'
    assert RateColumn("/s") == '? /s'

if __name__ == "__main__":  # pragma: no cover
    try:
        from sys import platform as _platform
        if _platform == "win32":  # pragma: no cover
            print("Cannot test on Windows")
    except ImportError:  # pragma: no cover
        print("Skipped platform check")
    else:
        import pytest
        pytest.main([__file__])

# Generated at 2022-06-22 05:36:54.228854
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.render(None) == Text("0.0/0.0", style="progress.download")
    fc = FractionColumn(unit_scale=False)
    assert fc.render(None) == Text("0.0/0.0", style="progress.download")
    fc = FractionColumn(unit_scale=True)
    assert fc.render(None) == Text("0.0/0.0", style="progress.download")

if __name__ == '__main__':
    test_FractionColumn()

# Generated at 2022-06-22 05:36:59.834985
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.text import Text
    console = Console()
    rateColumn = RateColumn("/s", False, 1000)
    text = Markdown("# A Simple Markdown Document")
    console.print(text)
    console.print(rateColumn)

# Generated at 2022-06-22 05:37:03.876732
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tqdm  # noqa
    from .gui import trange  # noqa
    assert tqdm.reset(0)
    assert tqdm.reset(10)
    assert trange.reset(0)
    assert trange.reset(10)

# Generated at 2022-06-22 05:37:14.022954
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    d = dict(completed=10, total=100)
    assert FractionColumn().render(**d) == Text(
        "10.0/100.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(**d) == Text(
        "10.0/100.0", style="progress.download")
    assert FractionColumn(unit_divisor=1024).render(**d) == Text(
        "10.0/100.0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(**d) == Text(
        "9.8/97.7 K", style="progress.download")

# Generated at 2022-06-22 05:37:26.840223
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import TaskID
    task_id = TaskID()
    task_id.completed = 10
    task_id.total = 1000
    object1 = FractionColumn()
    object2 = FractionColumn(unit_scale=True)
    object3 = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert object1.render(task_id) == Text(
        '10.0/1000 0', style='progress.download')
    assert object2.render(task_id) == Text(
        '0.0/0.9 K', style='progress.download')
    assert object3.render(task_id) == Text(
        '0.0/0.9 KiB', style='progress.download')


# Generated at 2022-06-22 05:37:37.180497
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1024)
    assert rate_column.render({'speed': 1000}) == Text("1.00 KB/s", style="progress.data.speed")
    assert rate_column.render({'speed': 1000 * 1024}) == Text("1.00 MB/s", style="progress.data.speed")
    assert rate_column.render({'speed': 1000 * 1024 * 1024}) == Text("1.00 GB/s", style="progress.data.speed")
    assert rate_column.render({'speed': 1000 * 1024 * 1024 * 1024}) == Text("1.00 TB/s", style="progress.data.speed")

# Generated at 2022-06-22 05:37:42.180538
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn(unit='b', unit_scale=True, unit_divisor=1024)


# Unit test to make sure long ints do not cause over-indexing in unit suffix list.
# See https://github.com/tqdm/tqdm/issues/489

# Generated at 2022-06-22 05:37:47.200330
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=3)
    t.display()
    t.update(2)
    t.display()
    t.close()

# Generated at 2022-06-22 05:37:53.502322
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Test for FractionColumn in rich.progress
    """
    unit_scale = True
    unit_divisor = 1000
    task = {'completed': 5000, 'total': 10000}
    fraction_column = FractionColumn(unit_scale, unit_divisor)
    fraction_column.render(task)
    assert fraction_column.render(task) == Text(
        f"5.0/10.0 K",
        style="progress.download")



# Generated at 2022-06-22 05:38:27.826639
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(total=100)).text == '0.0/100 '
    assert FractionColumn().render(Progress(total=100, completed=50)).text == '0.5/100 '
    assert FractionColumn().render(Progress(total=1000)).text == '0.0/1 K'
    assert FractionColumn().render(Progress(total=1000, completed=500)).text == '0.5/1 K'
    assert FractionColumn().render(Progress(total=1000)).text == '0.0/1 K'
    assert FractionColumn().render(Progress(total=1000, completed=500)).text == '0.5/1 K'

    assert FractionColumn().render(Progress(total=1000000)).text == '0.0/1 M'

# Generated at 2022-06-22 05:38:38.679822
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import time
    from tqdm.rich import tqdm_rich
    from tqdm.gui import tqdm
    for i in tqdm_rich(iterable=range(1, 10), bar_format="{desc} {percentage:>4.0f}%|{bar}|"):
        time.sleep(.1)
    for i in tqdm(iterable=range(1, 10), gui=True, bar_format="{desc} {percentage:>4.0f}%|{bar}|"):
        time.sleep(.1)
    for i in tqdm_rich(iterable=range(1, 10), bar_format="{desc} {percentage:>4.0f}%|{bar}|"):
        time.sleep(.1)

# Generated at 2022-06-22 05:38:43.335066
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()
    RateColumn(unit="B")
    RateColumn(unit="B", unit_scale=True)
    RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    RateColumn(unit="B", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:38:54.664687
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-22 05:39:00.704479
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn()
    assert column.unit == ""
    assert column.unit_divisor == 1000
    assert column.unit_scale == False
    column = RateColumn(unit="a", unit_divisor=10, unit_scale=True)
    assert column.unit == "a"
    assert column.unit_divisor == 10
    assert column.unit_scale == True


# Generated at 2022-06-22 05:39:02.196880
# Unit test for function trange
def test_trange():
    for _ in trange(0):
        pass


# Generated at 2022-06-22 05:39:07.423466
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(Progress.ExampleTask1(5)) == Text("0.0/0.0 ", style="progress.download")
    assert column.render(Progress.ExampleTask2(5, 10)) == Text("0.2/0.0 ", style="progress.download")


# Generated at 2022-06-22 05:39:16.744749
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(3)):
        pass
    for _ in tqdm_rich(range(3)):
        break
    for _ in tqdm_rich(range(3)):
        break
    for _ in tqdm_rich(range(3)):
        pass
    for _ in tqdm_rich(range(3)):
        break
    for _ in tqdm_rich(range(3)):
        break
    for _ in tqdm_rich(range(3)):
        pass

# Generated at 2022-06-22 05:39:25.130000
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(RichTask('test_description', 500, 2000)) == Text(f'0.5/2 K', style='progress.download')

if __name__ == "__main__":  # pragma: no cover
    with tqdm(
            total=10
    ) as pbar:
        for i in pbar:
            pbar.set_description(f"Processing {i}")
            pbar.update(1)

# Generated at 2022-06-22 05:39:31.247325
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Instantiate
    tqdm_rich()
    tqdm_rich(disable=True)
    tqdm_rich(disable=False)
    with tqdm_rich(disable=False) as t:
        t.update(5)
        x = t
    x.n = x.n + 1  # Test properties

    return