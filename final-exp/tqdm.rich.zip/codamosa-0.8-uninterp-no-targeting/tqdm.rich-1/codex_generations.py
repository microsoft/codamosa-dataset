

# Generated at 2022-06-22 05:33:01.859039
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=3) as t:
        pass
    t.close()

test_tqdm_rich_close()

# Generated at 2022-06-22 05:33:10.574543
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert FractionColumn(True, 1000).unit_scale == True
    assert FractionColumn(True, 1000).unit_divisor == 1000
    assert FractionColumn(False, 1000).unit_scale == False
    assert FractionColumn(False, 1000).unit_divisor == 1000
    assert FractionColumn(True, 1024).unit_scale == True
    assert FractionColumn(True, 1024).unit_divisor == 1024
    assert FractionColumn(False, 1024).unit_scale == False
    assert FractionColumn(False, 1024).unit_divisor == 1024
test_RateColumn()

# Generated at 2022-06-22 05:33:15.523254
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm(total=1) as bar:
        bar.reset(total=2)
        bar.update(1)
        bar.reset(total=3)
        bar.update(2)
        bar.reset()
        bar.update(3)

# Generated at 2022-06-22 05:33:21.307282
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    assert r.render(RateColumn.make_fake_task(speed=None)) == "? /s"
    assert r.render(RateColumn.make_fake_task(speed=0)) == "0.0 /s"
    assert r.render(RateColumn.make_fake_task(speed=10)) == "10.0 /s"

# Generated at 2022-06-22 05:33:28.949670
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    class task:
        completed = 2.34
        total = 3
    assert fc.render(task) == Text(
            "2.3/3.0  ",
            style="progress.download")
    class task:
        completed = 2.34
        total = 3000
    assert fc.render(task) == Text(
            "2.3/3.0 K",
            style="progress.download")

# Generated at 2022-06-22 05:33:31.840637
# Unit test for function trange
def test_trange():
    """Test trange"""
    with trange(10) as t:
        for _ in t:
            pass
        t.reset(5)
        for _ in t:
            pass

# Generated at 2022-06-22 05:33:43.640742
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from distutils.version import LooseVersion as V
    from rich import __version__ as rich_version

    try:
        from rich.progress import Progress
    except ImportError:
        from nose.plugins import SkipTest
        raise SkipTest("rich is not installed. `pip install tqdm[rich]`")

    p = Progress(title="Title", transient=False, console=None)
    with p:
        p.add_task("Foo", start=True, total=20)

    t1 = tqdm_rich(total=20, bar_format='{n}', progress=(p,))
    assert t1._prog.running, "progress is not running"
    t1.display()
    assert t1.n_fmt == '0', "n_fmt is not 0"

# Generated at 2022-06-22 05:33:50.318191
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    class DummyTask:
        """Dummy class that mimics Progress.tasks[task_id]."""
        completed = 40
        total = 100
    assert FractionColumn().render(DummyTask()) == Text(
        "0.4/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(DummyTask()) == Text(
        "400.0/1000.0", style="progress.download")

# Generated at 2022-06-22 05:33:56.794185
# Unit test for constructor of class RateColumn
def test_RateColumn():
  column = RateColumn()
  assert column.unit == ""
  assert column.unit_scale == False
  assert column.unit_divisor == 1000
  assert column.render({'speed': 1000, '_total_time': 1.0}) == Text(f"1.0 /s", style="progress.data.speed")

# Generated at 2022-06-22 05:34:00.118532
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn()
    class Object(object):
        completed = 1
        total = 2
    task = Object()
    assert fraction.render(task) is not None

# Generated at 2022-06-22 05:34:10.973696
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    with tqdm(total=1) as t:
        assert hasattr(t, '_prog')
        t.close()
    assert not hasattr(t, '_prog')


# Generated at 2022-06-22 05:34:14.642744
# Unit test for function trange
def test_trange():
    """Test trange()."""
    # Test trange:
    with trange(4) as t:
        for i in t:
            pass
    assert t.n == 4



# Generated at 2022-06-22 05:34:16.144251
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn().render(Progress()).text == "? /s"

# Generated at 2022-06-22 05:34:16.588769
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-22 05:34:23.617095
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest
    from tqdm.rich import tqdm_rich

    # reset a bar with total = total of bar + 1
    obj_tqdm = tqdm_rich(range(10))
    obj_tqdm.reset(11)
    assert obj_tqdm.n == 0
    assert obj_tqdm.total == 11

    # reset a bar with total = 1
    obj_tqdm = tqdm_rich(range(10))
    obj_tqdm.reset(1)
    assert obj_tqdm.n == 0
    assert obj_tqdm.total == 1

    # reset a bar with total = -1, raises TypeError
    obj_tqdm = tqdm_rich(range(10))
    with pytest.raises(TypeError):
        obj_

# Generated at 2022-06-22 05:34:33.828663
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import os
    import contextlib
    import rich.progress

    @contextlib.contextmanager
    def patch_progress(progress):
        old_progress = rich.progress.Progress
        try:
            rich.progress.Progress = progress
            yield
        finally:
            rich.progress.Progress = old_progress

    class FakeTask:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
            self.start_time = 0
            self.time_elapsed = 0
            self.speed = None

    with patch_progress(lambda *args, **kwargs: FakeTask(100, 1000)):
        assert str(RateColumn()).strip() == "100 B/s"
        assert str(RateColumn(unit_scale=True)).strip() == "0.1 KB/s"

# Generated at 2022-06-22 05:34:39.087607
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    t = tqdm_rich(["a", "b", "c", "d"], dynamic_ncols=True)
    t.update(2)
    t.set_postfix(aaa=1)
    t.close()

# Generated at 2022-06-22 05:34:44.628530
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass


if __name__ == '__main__':
    from .tests import common_main
    common_main(__file__, __doc__, False)

# Generated at 2022-06-22 05:34:52.164922
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(10, total=10)
    for i in range(5):  # pylint: disable=unused-variable
        t.display()
    t.close()


if __name__ == '__main__':  # pragma: no cover
    from random import randrange
    from time import sleep

    for i in trange(100):
        sleep(0.1)
        tqdm.write(str(i))
        if randrange(100) == 50:
            raise RuntimeError("random error")

# Generated at 2022-06-22 05:34:53.709255
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="", unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-22 05:35:04.360164
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    test_tqdm = tqdm_rich()
    assert test_tqdm is not None
    test_tqdm.close()

# Generated at 2022-06-22 05:35:06.399012
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich([], total=1)
    t.close()

# Generated at 2022-06-22 05:35:15.270386
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Tests for RateColumn.
    """
    t_kwargs = {'unit': 'B', 'unit_scale': False, 'unit_divisor': 1000}
    r_kwargs = {'unit': 'B', 'unit_scale': True, 'unit_divisor': 1000}
    unit_test = RateColumn(**r_kwargs)
    std_test = RateColumn(**t_kwargs)
    assert unit_test._unit == std_test._unit
    assert unit_test._unit_scale == std_test._unit_scale
    assert unit_test._unit_divisor == std_test._unit_divisor

# Generated at 2022-06-22 05:35:20.704632
# Unit test for function trange
def test_trange():
    from .auto import trange, tqdm_gui
    from .gui import tnrange
    try:
        from .gui import trange as tqdm_gui
    except ImportError:
        from .auto import tqdm_gui
    assert list(trange(10)) == list(tqdm_gui(range(10)))
    assert list(trange(10)) == list(tqdm_gui(range(10)))
    assert list(trange(10)) == list(tnrange(10))

# Generated at 2022-06-22 05:35:21.960290
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    a = FractionColumn()

# Generated at 2022-06-22 05:35:33.891268
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm_gui


# Generated at 2022-06-22 05:35:37.797070
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    if not hasattr(Progress, 'test'):  # pragma: no cover
        return
    with tqdm(total=2) as t:
        t.update(1)
        Progress.test()

# Generated at 2022-06-22 05:35:42.315266
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    l = trange(10, desc="Loading", unit="B", unit_scale=True, unit_divisor=1024)
    for _ in l:
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 05:35:51.276401
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # prepare example progress
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
    )
    # create instance and check that all ways to access its data work
    inst = tqdm_rich(range(100), total=100, **{'progress': progress})
    assert inst._task_id == inst._prog._tasks[0]._id
    assert inst._prog._tasks[0].completed == inst

# Generated at 2022-06-22 05:36:01.044650
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Test rich version of tqdm().
    """
    # Test rich version of constructor
    with tqdm(total=10, desc="Hi", position=0, leave=True,
              bar_format='{bar} {postfix[0]} {postfix[1]}') as t:
        assert hasattr(t, '_prog')
        assert len(t._prog.columns) == 4
        assert t.total == 10
        assert t.desc == "Hi"
        assert t.position == 0
        assert t.leave == True
        assert t.bar_format == '{bar} {postfix[0]} {postfix[1]}'

    with tqdm(total=10, desc="Hi") as t:
        assert hasattr(t, '_prog')
       

# Generated at 2022-06-22 05:36:19.742356
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    display = tqdm_rich().display

# Generated at 2022-06-22 05:36:30.521018
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    from .utils import FormatMixin, format_meter
    from .std import format_interval
    try:
        from tqdm import _version
    except ImportError:
        from ._version import __version__ as _version
    with format_meter(format="  {bar} | {n_fmt}/{total_fmt} [{elapsed}]",
                      unit_scale=False, unit="it") as fm:
        t = trange(10, bar_format=fm.format, ncols=90)
        for _ in t:
            assert format_interval(t.last_print_t - t.start_t,
                                   always=False) in repr(t)
            assert t.n_fmt in repr(t)
            assert str(t.total)

# Generated at 2022-06-22 05:36:39.743495
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render({'completed': 0, 'total': 0}) == Text('0/0', style='progress.download')
    assert FractionColumn().render({'completed': 100, 'total': 100}) == Text('1/1', style='progress.download')
    assert FractionColumn().render({'completed': 10, 'total': 10}) == Text('1/1', style='progress.download')
    assert FractionColumn().render({'completed': 1000, 'total': 1000}) == Text('1/1', style='progress.download')
    assert FractionColumn().render({'completed': 1, 'total': 1000}) == Text('0/1', style='progress.download')
    assert FractionColumn().render({'completed': 1000, 'total': 1}) == Text('1/0', style='progress.download')
   

# Generated at 2022-06-22 05:36:48.796647
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Unit test for method render of class FractionColumn.

    Parameters
    ----------
    task: rich.progress.ProgressTask
        task required to execute the method.

    Returns
    -------
    Text:
        Summary of completed/total:
        f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}"
    """
    # Mock
    task = Progress("[progress.description]{task.description}",
                    "[progress.percentage]{task.percentage:>4.0f}%",
                    BarColumn(bar_width=None),
                    FractionColumn())
    task.add_task("PROGRESS")
    task.update(0, completed=1, total=2)

# Generated at 2022-06-22 05:36:55.820213
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        import rich.progress
        import sys
        from io import StringIO

        # Capture standard output
        out = StringIO()
        sys.stdout = out

        tqdm_rich(range(5))

        # Recover standard output
        sys.stdout = sys.__stdout__

        # Check if the task had been removed from Progress.tasks
        assert out.getvalue()[-3:-1] == '@'
    except ImportError:
        pass



# Generated at 2022-06-22 05:36:58.356634
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10):
        pass
    for _ in trange(5, 10):
        pass
    for _ in trange(1, 10, 2):
        pass
    for _ in trange(10, 1, -2):
        pass

# Generated at 2022-06-22 05:37:08.908356
# Unit test for constructor of class RateColumn
def test_RateColumn():
    class Mock(object):
        def __init__(self,completed,total):
            self.completed = completed
            self.total = total
            self.speed = 10
            self.start_t = 1
            self.last_print_t = 1
            self.dynamic_ncols = False
    class MockProgress(object):
        def __init__(self,total):
            self.total = total
        def update(self,*args,**kwargs):
            pass
    class Mock_rate(object):
        def __init__(self,expected):
            self.expected = expected
        def __eq__(self, other):
            return self.expected == other.expected
    progress = MockProgress(10)
    task = Mock(10,10)
    rate = "B"
    unit = "B"


# Generated at 2022-06-22 05:37:16.888822
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Unit test for class tqdm_rich."""
    from .std import tqdm as std_tqdm
    from unittest import TestCase

    class Dummy:
        def __init__(self, disable):
            self.disable = disable

    class TqdmRichTests(TestCase):
        def test_init_kwargs(self):  # @UnusedVariable
            """Test constructor of rich.progress decorator."""
            with self.assertRaises(TypeError) as e:
                # missing total
                tqdm_rich()
            self.assertTrue("not enough arguments" in str(e.exception))
            # missing file
            with self.assertRaises(TypeError) as e:
                tqdm_rich(total=1)

# Generated at 2022-06-22 05:37:23.792590
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Tests for `RateColumn()`"""
    rate = RateColumn(unit='B', unit_scale=True, unit_divisor=1000)
    assert rate.render({'speed': 5}) == "5.0 B/s"
    assert rate.render({'speed': 500}) == "500.0 B/s"
    assert rate.render({'speed': 5000}) == "5.0 KB/s"

# Generated at 2022-06-22 05:37:33.278659
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import os
    import sys
    import tempfile
    import time


# Generated at 2022-06-22 05:38:50.404513
# Unit test for constructor of class RateColumn
def test_RateColumn():
    c = RateColumn()
    d = dict(unit='', unit_scale=False, unit_divisor=1000)
    assert c.unit == d['unit']
    assert c.unit_scale == d['unit_scale']
    assert c.unit_divisor == d['unit_divisor']

# Generated at 2022-06-22 05:38:52.766087
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm(total=2) as t:
        t.update()
        t.update()
        t.set_description('testtqdm')
        t.n = 1
        t.refresh()
        t.close()

# Generated at 2022-06-22 05:38:56.189222
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    class Task(object):
        completed = 2
        total = 3
    FractionColumn().render(Task())
    FractionColumn(unit_scale=True).render(Task())


# Generated at 2022-06-22 05:39:01.841580
# Unit test for constructor of class RateColumn
def test_RateColumn():
    default = RateColumn()
    args = RateColumn("MiB", True, 1024)
    assert default.render(std_tqdm(total=1024, unit='B')).text == '0.0 B/s'
    assert args.render(std_tqdm(total=1024*1024)).text == '0.0 MiB/s'

# Generated at 2022-06-22 05:39:04.688817
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    tqdm_rich.display()

# Generated at 2022-06-22 05:39:12.155620
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Constructor of class RateColumn"""
    # Default
    column = RateColumn()
    assert column.unit == ""
    assert column.unit_scale is False
    assert column.unit_divisor == 1000

    # Custom
    column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert column.unit == "B"
    assert column.unit_scale is True
    assert column.unit_divisor == 1024



# Generated at 2022-06-22 05:39:15.741473
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=2)
    assert t.n == 0
    t.update(1)
    assert t.n == 1
    t.close()
    assert t.n == 2

# Generated at 2022-06-22 05:39:19.933675
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=None)
    t.display()
    assert t.disable is True
    t.close()
    with tqdm(total=10) as t:
        t.display()
        assert t.disable is False
        t.close()

# Generated at 2022-06-22 05:39:23.255083
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10):
        pass
    assert True

# Generated at 2022-06-22 05:39:32.739086
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    import sys
    import warnings
    import unittest
    global std_tqdm
    # save std_tqdm
    saved_std_tqdm = std_tqdm

    class tqdm_rich_unittest(tqdm_rich):
        def __init__(self, *args, **kwargs):
            self.called_clear = False
            super(tqdm_rich_unittest, self).__init__(*args, **kwargs)

        def clear(self, *_, **__):
            self.called_clear = True

    # override std_tqdm and trigger method clear of class tqdm_rich
    std_tqdm = tqdm_rich_unittest

# Generated at 2022-06-22 05:40:35.668485
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress("Filesize", "total")
    data = filesize.pick_unit_and_suffix(
        1024,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        1000,
    )
    assert data == (1, "K")
    data = filesize.pick_unit_and_suffix(
        1024,
        ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB", "YiB"],
        1024,
    )
    assert data == (1, "KiB")

# Generated at 2022-06-22 05:40:37.442724
# Unit test for function trange
def test_trange():
    """ Test trange """
    from .gui import test_gui
    test_gui(trange)



# Generated at 2022-06-22 05:40:39.432666
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    text = RateColumn().render(object)
    assert text == Text("? /s", style="progress.data.speed")



# Generated at 2022-06-22 05:40:47.466302
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.panel import Panel
    import sys
    import io
    capture_stdout = io.StringIO()
    sys.stdout = capture_stdout
    progress = Progress(
        "FractionColumnTest",
        FractionColumn(),
        transient=True,
    )
    progress.__enter__()
    progress.add_task("FractionColumnTest", unit="B", total=1000, description="File transfer")
    progress.update(0, completed=100)
    progress.update(0, completed=200)
    progress.update(0, completed=300)
    progress.update(0, completed=500)
    progress.update(0, completed=800)
    progress.update(0, completed=1000)
    progress.__exit__(None, None, None)

# Generated at 2022-06-22 05:40:48.948837
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-22 05:40:51.596300
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass



# Generated at 2022-06-22 05:40:55.525337
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich.__dict__["TqdmDefaultWrite"](total=100, desc="test")
    task.speed = 1024
    assert RateColumn().render(task) == Text("1.00 B/s", style="progress.data.speed")

# Generated at 2022-06-22 05:41:00.418015
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from time import sleep
    try:
        from builtins import input as get_input
    except ImportError:
        from __builtin__ import raw_input as get_input
    for i in tqdm_rich(range(10)):
        sleep(0.5)  # XXX: Is this really the way to test?
    get_input("Press any key to exit this example...")

# Generated at 2022-06-22 05:41:06.031813
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Test RateColumn.__init__() function."""
    assert RateColumn(unit="").unit == ""
    assert RateColumn(unit="/s").unit == "/s"
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1).unit_scale is False
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1).unit_divisor == 1
    assert RateColumn(unit="", unit_scale=True, unit_divisor=1000).unit_scale is True
    assert RateColumn(unit="", unit_scale=True, unit_divisor=1000).unit_divisor == 1000



# Generated at 2022-06-22 05:41:12.474690
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import random
    import time
    with tqdm(total=100) as t:
        for i in range(100):
            # Change total at the middle of computation
            if i == 50:
                # New total is a random number between 100 and 200
                t.reset(total=random.randint(100, 200))
            time.sleep(.1)
            t.update(1)

