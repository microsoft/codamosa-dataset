

# Generated at 2022-06-22 05:33:03.208138
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich"""
    tqdm_rich(total=10).display()

# Generated at 2022-06-22 05:33:11.545018
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(total=10, desc="test reset")
    assert pbar.total == 10
    pbar.reset(total=2)
    assert pbar.total == 2
    pbar.close()
    pbar = tqdm_rich(total=10, desc="test reset")
    assert pbar.total == 10
    pbar.update(5)
    assert pbar.n == 5
    pbar.reset(total=2)
    assert pbar.total == 2
    pbar.close()

# Generated at 2022-06-22 05:33:19.950238
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.style import Style
    from rich.syntax.syntax import Syntax
    from rich.theme import Theme
    from rich.console import Console

    style = Style.from_dict({"progress.download": "bold red"})
    console = Console(
        width=80, theme=Theme({}, default_style=style))

    # Catch `unit_scale` case
    fc = FractionColumn()
    task = Progress(completed=0.5, total=2.3)
    assert fc.render(task).render(console) == "\x1b[31m\x1b[1m0.5/2.3   \x1b[m"


# Generated at 2022-06-22 05:33:22.931941
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        pass

# Generated at 2022-06-22 05:33:26.121315
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit='B', unit_scale=False, unit_divisor=1000).render(Progress(completed=1, speed=1)) == Text(f"1 B/s", style="progress.data.speed")

# Generated at 2022-06-22 05:33:34.396972
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest
    from time import sleep
    with tqdm_rich(total=100) as bar:
        for x in bar:
            bar.reset(total=200)
            sleep(0.01)
            bar.reset(total=500)
            sleep(0.01)
            bar.reset(total=1000)
            sleep(0.01)
        bar.reset(total=200)
        bar.reset(total=500)
        bar.reset(total=1000)
    with pytest.raises(ValueError):
        bar = tqdm_rich()
        bar.reset(total=1000)

# Generated at 2022-06-22 05:33:39.570277
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=100)
    assert t.n == 0
    t.update(50)
    assert t.n == 50
    t.reset(total=200)
    assert t._prog.total == 200
    assert t._prog.completed == 0
    assert t.n == 0
    t.close()

# Generated at 2022-06-22 05:33:42.577069
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    bar = tqdm_rich(total=10, desc="Before reset")
    bar.update(4)
    bar.reset()
    bar.update(4)
    assert not bar.n

# Generated at 2022-06-22 05:33:52.180182
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn by checking the output.
    """
    from .rich.progress import Progress
    from .rich.progress import ProgressColumn
    from .rich.progress import Task
    from .rich.progress import Text
    from .rich.progress import filesize
    # Create a FractionColumn object.
    fraction_column = FractionColumn()
    # Create a Progress object.
    progress = Progress()
    # Create a Task object.
    task = Task(description='description', completed=0, total=1)
    # Get the result of method render.
    fraction_column_output = fraction_column.render(task)
    # Check the result.
    assert fraction_column_output == Text('0.0/1 ', style='progress.download')


# Generated at 2022-06-22 05:33:59.282603
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    obj = FractionColumn(unit_scale=True)
    assert obj.render({'completed': 100, 'total': 1000}) == Text(
        '0.1/1.0 K', style='progress.download')
    obj = FractionColumn(unit_scale=False)
    assert obj.render({'completed': 100, 'total': 1000}) == Text(
        '0.1/1.0 ', style='progress.download')



# Generated at 2022-06-22 05:34:09.388975
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    x = FractionColumn()
    assert repr(x) == repr(eval(repr(x)))
    assert repr(x) == "FractionColumn(unit_scale=False, unit_divisor=1000)"


# Generated at 2022-06-22 05:34:15.959298
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test to check if reset works correctly.

    """

    from rich.progress import Progress
    from rich.theme import Theme
    from rich.console import Console


# Generated at 2022-06-22 05:34:17.869836
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(10) as f:
        assert f.total == 10
    f.reset(3)
    assert f.total == 3



# Generated at 2022-06-22 05:34:29.808375
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.progress import Columns, Console
    from rich.progress import Progress, TextColumn

    with Console() as console:
        with Progress(console, "We are testing",
                      BarColumn(), "[", TextColumn(), "]") as progress:
            task_id = progress.add_task("foo", total=100, start=False)
            progress.update(task_id, progress.ProgressTask(
                "foo",
                task_id,
                0,
                100,
                0,
                0,
                None,
                None,
            ))
            progress.update(task_id, progress.ProgressTask(
                "foo",
                task_id,
                0,
                100,
                20,
                0,
                None,
                None,
            ))

# Generated at 2022-06-22 05:34:41.620200
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn()) == '? /s'

if __name__ == "__main__":  # pragma: no cover
    import time
    import sys
    with tqdm(range(4)) as bar:
        for i in bar:
            time.sleep(1)
            bar.set_description(f"L{i+1}")
    print("")
    with trange(4) as bar:
        for i in bar:
            time.sleep(1)
            bar.set_description(f"L{i+1}")
    with tqdm(range(4), bar_format="{desc} {percentage:>4.0f}%") as bar:
        for i in bar:
            time.sleep(1)
            bar.set_description(f"L{i+1}")

# Generated at 2022-06-22 05:34:45.523984
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.markdown import Markdown
    column = FractionColumn()
    assert column.render(Progress(100,100,100)) == Markdown('100/100 ')

# Generated at 2022-06-22 05:34:55.281666
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # pylint: disable=unused-variable
    # This method is automatically called whenever display() is called
    # by an instance of the class tqdm_rich.

    # Initialise the test iterator
    iter = tqdm_rich(range(10), gui=False)

    # Simulate the display method
    iter.n = 1

    # The real function only gets called if iter.n > 0
    # Next simulate iter.n > 0
    iter.n = 1
    if not iter.disable:
        if iter.total:
            elapsed = iter.miniters * iter.avg_time
            frac = float(iter.n) / iter.total
            eta = elapsed / (frac+1e-5) * (1.0 - min(frac, 1.0))
            iter.format_dict['_eta']

# Generated at 2022-06-22 05:35:07.235114
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Tests for trange"""
    from time import sleep
    from random import random

    with trange(10, desc='tqdm(trange) 10 iterations') as t:
        for i in t:
            sleep(0.1 * random())
            t.set_postfix(i=i)
    assert t.n == 10
    assert t.last_print_n == 10

    with trange(10, desc='tqdm(trange) 10 iterations (leave off)', leave=False) as t:
        for i in t:
            sleep(0.1 * random())
            t.set_postfix(i=i)
    assert t.n == 10
    assert t.last_print_n == 10

# Generated at 2022-06-22 05:35:12.174720
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import tgrange
    import os
    import tempfile
    import time

    _, test_file_path = tempfile.mkstemp()
    try:
        with tgrange(1000) as display:
            for i in display:
                time.sleep(0.01)
        with tgrange(1000) as display:
            for i in display:
                with open(test_file_path, "w") as f:
                    f.write("test")
                time.sleep(0.01)
        with tgrange(1000) as display:
            for i in display:
                with open(test_file_path, "r") as f:
                    f.read()
                time.sleep(0.01)
    finally:
        os.remove(test_file_path)

# Generated at 2022-06-22 05:35:14.980396
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn("B")) == "RateColumn()"

# Generated at 2022-06-22 05:35:27.982293
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn()
    d = {'index': '0.50', 'index_total': '2.30', 'unit': 'G', 'unit_scale': True, 'unit_divisor': 1000}
    assert f.render(d) == Text('0.5/2.3 G', style='progress.download')

# Generated at 2022-06-22 05:35:32.021458
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10) as bar:
        assert bar.total == 10
    with trange(10) as bar:
        assert bar.total == 10
        bar.reset(20)
        assert bar.total == 20

# Generated at 2022-06-22 05:35:35.823462
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=100) as bar:
        for i in range(20):
            bar.n = 10 * i
            bar.refresh()
            sleep(0.2)

# Generated at 2022-06-22 05:35:38.904348
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest

    with pytest.raises(ValueError):
        tqdm_rich(range(10), total=-1).reset()

    with pytest.raises(ValueError):
        tqdm_rich(range(10), desc='foo').reset()

# Generated at 2022-06-22 05:35:39.649255
# Unit test for function trange
def test_trange():
    trange(3)

# Generated at 2022-06-22 05:35:43.315508
# Unit test for function trange
def test_trange():
    for _ in trange(lrange, 1, 6):
        ...



# Generated at 2022-06-22 05:35:52.187289
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .utils import format_interval

    for _ in trange(4, desc='tqdm_rich', smooth=True, bar_format='{desc}: {percentage:3.0f}% |{bar}| {n_fmt}/{total_fmt} - {n_fmt}<{rate_fmt}'):
        time.sleep(0.1)
    time.sleep(0.5)

    # test reset with total
    t = trange(10, desc='tqdm_rich', total=20)
    for _ in t:
        time.sleep(0.1)
    t.reset(total=50)
    for _ in t:
        time.sleep(0.1)
    t.reset(total=100)

# Generated at 2022-06-22 05:35:53.984493
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10, desc="test"):
        pass

# Generated at 2022-06-22 05:36:00.778645
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .utils import _range
    import shutil
    from .std import trange
    with tqdm(_range(1000), unit='B', unit_scale=True, unit_divisor=1024) as t:
        for _ in t:
            pass
    assert shutil.get_terminal_size().columns >= len(
        t.format_dict['bar_format']) + len(t.format_dict['postfix'])
    t.close()

# Generated at 2022-06-22 05:36:12.595473
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import rich.progress
    import rich.text

    unit = 'MB'
    unit_scale = False
    unit_divisor = 1000
    speed = 100.0
    rc = RateColumn(unit, unit_scale, unit_divisor)
    rc.render = rich.progress.ProgressColumn.render
    progress = rich.progress.Progress(
                    "[progress.description]{task.description}",
                    RateColumn(unit, unit_scale, unit_divisor),
                    transient=True,
                    newline_on_complete=False,
                    )
    task = rich.progress.ProgressTask(progress, speed=speed, description='')
    rate_column = rc.render(task)
    assert(rate_column.text == '100.0 MB/s')


# Generated at 2022-06-22 05:36:38.266051
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    value = RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(
        {"speed": 2345.6789012345, "total": None, "completed": None, "leave": False})
    assert str(value) == "2.3 KiB/s"
    value = RateColumn(unit="", unit_scale=True, unit_divisor=1024).render(
        {"speed": 2345.6789012345, "total": None, "completed": None, "leave": False})
    assert str(value) == "2.3 K/s"

# Generated at 2022-06-22 05:36:48.026597
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import sys
    import time
    from .std import tqdm_gui, tgrange
    for _tqdm in [tqdm_rich, tgrange, tqdm_gui]:
        _tqdm(range(10), disable=True)  # test disable
        with _tqdm(range(10), ascii=True, desc='test1', leave=True) as t:
            assert t.gui
            t.total = 50
            time.sleep(0.01)
            t.pos = 10
        with _tqdm(range(10), ascii=False, desc='test2', leave=True) as t:
            time.sleep(0.01)
            t.pos = t.total

# Generated at 2022-06-22 05:36:50.019009
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with trange(3) as t:
        for x in t:
            pass
    t.close()

# Generated at 2022-06-22 05:36:54.545662
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=2) as t:
        t.update()
        assert t.n == 1

        t.reset(total=3)
        t.update()
        assert t.n == 1

        t.reset()
        t.update()
        assert t.n == 1

# Generated at 2022-06-22 05:36:55.901410
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-22 05:36:58.709199
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="B", unit_scale=True)
    assert r.unit == "B"
    assert r.unit_scale
    r = RateColumn(unit_scale=True)
    assert r.unit == ""
    assert not r.unit_scale

# Generated at 2022-06-22 05:37:00.564744
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    rate.render(2)
    pass

# Generated at 2022-06-22 05:37:03.321410
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Tests
    -----
    - method display of class tqdm_rich
    """
    t = tqdm_rich(total=10)
    t.display()
    return

# Generated at 2022-06-22 05:37:13.992794
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os
    import subprocess
    import time

    # other code
    from .utils import _unwrap_handle, _supports_unicode, _range

    def _suppress_stdout():
        if os.name != 'nt':
            return open(os.devnull, 'w')
        else:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
            return None

    class _TqdmSubprocess(object):
        def __init__(self, *args, **kwargs):
            self._kwargs = kwargs
            self._args = args
            self._child = None
            self._name = kwargs.get('name', 'tqdm')
            self._total = None
           

# Generated at 2022-06-22 05:37:25.832946
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .utils import FormatMixin

    class _tqdm(FormatMixin, tqdm):
        def format_dict_get(self):
            return self.format_dict

    for i in _tqdm(trange(1, 10), unit="foo", unit_scale=True):
        pass
    assert i == 9

# Generated at 2022-06-22 05:38:01.552498
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """ Unit test for method clear of class tqdm_rich"""
    with tqdm_rich(total=10) as progress:
        progress.clear()

# Generated at 2022-06-22 05:38:13.118556
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    progress = (RateColumn(unit="b"),)
    prog = Progress(*progress)
    prog.__enter__()
    task_id = prog.add_task("", speed=0.0)
    prog.__exit__(None, None, None)
    assert f"0 b/s" == str(prog.tasks[task_id].progress.columns[0])

    progress = (RateColumn(unit="B", unit_scale=True, unit_divisor=1024),)
    prog = Progress(*progress)
    prog.__enter__()
    task_id = prog.add_task("", speed=0.0)
    prog.__exit__(None, None, None)

# Generated at 2022-06-22 05:38:24.980313
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="")
    assert r.unit == ""
    assert r.unit_scale == False
    assert r.unit_divisor == 1000

    r = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert r.unit == ""
    assert r.unit_scale == False
    assert r.unit_divisor == 1000

    r = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    assert r.unit == ""
    assert r.unit_scale == True
    assert r.unit_divisor == 1000

    r = RateColumn(unit="", unit_scale=True, unit_divisor=1024)
    assert r.unit == ""
    assert r.unit_scale == True
    assert r.unit_divisor

# Generated at 2022-06-22 05:38:31.646301
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test tqdm_rich_clear.

    This is an empty method, therefore it's only necessary to check that it
    doesn't throw any exception.
    """
    tqdm_rich.clear()
    tqdm_rich.clear(1)
    tqdm_rich.clear(1, 2)
    tqdm_rich.clear(1, 2, 3)
    tqdm_rich.clear(1, 2, 3, 4)

# Generated at 2022-06-22 05:38:34.291576
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_rich.close()
    tqdm_rich.display()
    tqdm_rich.clear()
    tqdm_rich.reset()

# Generated at 2022-06-22 05:38:40.981971
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test the constructor of class tqdm_rich"""
    from time import sleep

    for i in tqdm_rich(range(10), desc="foobar", unit="B", ascii=True,
                       miniters=1, mininterval=0.2):
        sleep(0.01)

# Generated at 2022-06-22 05:38:42.039311
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich.close()



# Generated at 2022-06-22 05:38:49.010206
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from warnings import catch_warnings
    from tqdm import tqdm_rich

    with catch_warnings(record=True) as w:
        t = tqdm_rich(total=100)
        t.reset()
        assert t._prog.total == 100

    with catch_warnings(record=True) as w:
        t = tqdm_rich(total=100)
        t.reset(total=200)
        assert t._prog.total == 200

# Generated at 2022-06-22 05:38:58.017196
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn(unit_scale=False, unit_divisor=1000)
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1000
    rc2 = RateColumn(unit_scale=False)
    assert rc2.unit_scale == False
    assert rc2.unit_divisor == 1000
    rc3 = RateColumn(unit_scale=True)
    assert rc3.unit_scale == True
    assert rc3.unit_divisor == 1000
    rc4 = RateColumn(unit='')
    assert rc4.unit == ''



# Generated at 2022-06-22 05:39:01.917705
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm(total=100)
    assert t.format_dict['total'] == 100
    t.reset(total=50)
    assert t.format_dict['total'] == 50

# Generated at 2022-06-22 05:39:50.842697
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test the function trange"""
    from pytest import approx
    import time

    # Simple test
    a = trange(10)
    assert a.n == 0

    # Test with start, stop and step
    a = trange(2, 10, 2)
    assert a.n == 2

    # Test with start, stop, step and position
    a = trange(0, 10, 1, 5)
    assert a.n == 5

    # Test with start, stop and position
    a = trange(2, 10, 4)
    assert a.n == 4

    # Test with start and stop
    a = trange(10, 20)
    assert a.n == 10

    # Test with stop
    a = trange(10)
    assert a.n == 0

    # Test

# Generated at 2022-06-22 05:39:58.086040
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.console import Console
    from rich.progress import Progress
    console = Console(file=None)
    progress = Progress(console=console)
    task = progress.add_task("test")
    prog = tqdm_rich(total=100, console=console)
    assert (progress.tasks[task].description == "test")
    assert (progress.tasks[task].completed == 0)
    prog.close()
    assert (progress.tasks[task].completed == 100)
    assert (progress.tasks[task].description == "test")


# Generated at 2022-06-22 05:40:04.347527
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    ''' Unit test for method reset of class tqdm_rich '''
    with tqdm_rich(total=4) as bar:
        for _ in range(4):
            bar.update()
        bar.reset()
        for _ in range(4):
            bar.update()

# Generated at 2022-06-22 05:40:12.217702
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn()
    assert rc.unit == ""
    assert rc.unit_scale is False
    assert rc.unit_divisor == 1000
    rc = RateColumn(unit="GB")
    assert rc.unit == "GB"
    assert rc.unit_scale is False
    assert rc.unit_divisor == 1000
    rc = RateColumn(unit="GB", unit_scale=True)
    assert rc.unit == "GB"
    assert rc.unit_scale is True
    assert rc.unit_divisor == 1000
    rc = RateColumn(unit="GB", unit_scale=False)
    assert rc.unit == "GB"
    assert rc.unit_scale is False
    assert rc.unit_divisor == 1000

# Generated at 2022-06-22 05:40:22.740877
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(task=None) == (
        Text('0.0/0.0 ', style='progress.download'))
    assert FractionColumn().render(task=None) == (
        Text('0.0/0.0 ', style='progress.download'))
    assert FractionColumn(unit_scale=True).render(task=None) == (
        Text('0.0/0.0 ', style='progress.download'))
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task=None) == (
        Text('0.0/0.0 ', style='progress.download'))

    class Task:
        completed = 2.0
        total = 3.0


# Generated at 2022-06-22 05:40:34.556314
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert(RateColumn().render(ProgressBar()).plain == '? B/s')
    assert(RateColumn().render(ProgressBar(speed=0)).plain == '0 B/s')
    assert(RateColumn(unit="B").render(ProgressBar()).plain == '? B/s')
    assert(RateColumn(unit="B").render(ProgressBar(speed=0)).plain == '0 B/s')
    assert(RateColumn(unit="B").render(ProgressBar(speed=1)).plain == '1 B/s')
    assert(RateColumn(unit="B").render(ProgressBar(speed=1000)).plain == '1000 B/s')
    assert(RateColumn(unit="B", unit_scale=True, unit_divisor=1).render(ProgressBar(speed=1000)).plain == '1 KB/s')

# Generated at 2022-06-22 05:40:38.263796
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test for tqdm_rich."""
    t = tqdm_rich(total=10)
    t.update()
    t.update(2)
    t.update(3)
    t.update(3)
    t.close()

# Generated at 2022-06-22 05:40:43.773669
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import warnings
    warnings.filters.add(TqdmExperimentalWarning)

    with tqdm_rich(100, desc='test1') as t:
        t.reset(9999)
        assert t.total == 9999
        assert t.n == 0

        t.reset(total=8888)
        assert t.total == 8888
        assert t.n == 0

        t.reset()
        assert t.total == 100
        assert t.n == 0



# Generated at 2022-06-22 05:40:46.742891
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test that all unit ranges display correctly."""
    import time

    for unit in [1, 10, 1e5, 1e9]:
        for i in trange(20, unit=unit):
            time.sleep(0.01)

# Generated at 2022-06-22 05:40:55.330660
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = {'completed': 10, 'total': 20, 'speed': None}
    column = RateColumn()
    assert column.render(task) == Text(f"? /s", style="progress.data.speed")
    task['speed'] = 1025
    assert column.render(task) == Text(f"1.0 K/s", style="progress.data.speed")
    column = RateColumn(unit="bit")
    assert column.render(task) == Text(f"1.0 kbit/s", style="progress.data.speed")
    column = RateColumn(unit="", unit_scale=True)
    assert column.render(task) == Text(f"1.0 K/s", style="progress.data.speed")
    column = RateColumn(unit="bit", unit_scale=True)
    assert column.render

# Generated at 2022-06-22 05:42:05.872084
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # setup
    t = tqdm_rich(total=2)
    t.update(1)
    t.n = 1
    t.total = 2

    # test
    t.display()

    # teardown
    t.close()

# Generated at 2022-06-22 05:42:16.185809
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Test tqdm_rich constructor.
    """
    import time
    import sys
    import os
    with trange(10) as t:
        for i in t:
            t.set_description("testing")
            print("")
            time.sleep(0.1)
        assert i == 9
    assert t.n == 10
    assert t.total == 10
    assert t.desc == "testing"
    assert t.n == t.last_print_n == 10
    # Test reset
    t.reset()
    assert t.n == t.last_print_n == 0
    assert t.total == 10
    with trange(10) as t:
        for i in t:
            print("")
            time.sleep(0.1)
            t.update()

# Generated at 2022-06-22 05:42:20.654815
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.unit == "B"
    assert rate_column.unit_scale == True
    assert rate_column.unit_divisor == 1000

# Generated at 2022-06-22 05:42:31.799365
# Unit test for function trange
def test_trange():
    from .utils import _range
    from .std import tqdm as std_tqdm
    for i in trange(3):
        assert i in _range(3)
    for i in std_tqdm(trange(3)):
        assert i in _range(3)
    for i in trange(3, 5):
        assert i in _range(3, 5)
    for i in trange(0, 5, 2):
        assert i in _range(0, 5, 2)
    for i in trange(0, 5, 2, desc='foobar'):
        assert i in _range(0, 5, 2)
    for i in trange(0, 5, 2, desc='foobar', leave=True):
        assert i in _range(0, 5, 2)

# Generated at 2022-06-22 05:42:33.300035
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    assert rate_column._text == None


# Generated at 2022-06-22 05:42:39.237286
# Unit test for method clear of class tqdm_rich

# Generated at 2022-06-22 05:42:41.927934
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    assert rate.render(None) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-22 05:42:43.512657
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(0)
    t.close()


# Test alias trange

# Generated at 2022-06-22 05:42:49.762969
# Unit test for method render of class RateColumn
def test_RateColumn_render():

    # Test with transfer speed equal to 1024 bytes per second
    speed = 1024
    task = type('task', (object,), {})()
    task.speed = speed

    # Test with bytes per second as unit and do not scale
    unit = 'b'
    rate_column = RateColumn(unit=unit, unit_scale=False)
    rate_column_output = rate_column.render(task)
    assert rate_column_output == Text('1.000 b/s', style='progress.data.speed')

    # Test with bytes per second as unit and scale
    unit = 'b'
    rate_column = RateColumn(unit=unit, unit_scale=True)
    rate_column_output = rate_column.render(task)

# Generated at 2022-06-22 05:42:51.378974
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=None) as p:
        assert p.disable == False