

# Generated at 2022-06-22 05:32:55.780023
# Unit test for function trange
def test_trange():
    "Test trange()"
    with trange(10) as t:
        for i in t:
            assert i == t.n
        assert t.n == 10

# Generated at 2022-06-22 05:33:07.388782
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.console import Console
    from rich.table import Table
    console = Console(record=True)

    #  class FractionColumn(ProgressColumn):
    #       """Renders completed/total, e.g. '0.5/2.3 G'."""

    # case 1:
    #       progress = (
    #           "[progress.description]{task.description}"
    #           "[progress.percentage]{task.percentage:>4.0f}%",
    #           BarColumn(bar_width=None),
    #           FractionColumn(
    #               unit_scale=d['unit_scale'], unit_divisor=d['unit_divisor']),
    #           "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
    #           ",", RateColumn(unit=d['unit'

# Generated at 2022-06-22 05:33:09.412694
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.column_width == 10


# Generated at 2022-06-22 05:33:16.567364
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Render completed/total, e.g. '0.5/2.3 G'."""
    # GIVEN
    # WHEN
    unit, suffix = filesize.pick_unit_and_suffix(
        1200,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        1000,
    )
    # THEN
    assert unit == 1
    assert suffix == "K"

# Generated at 2022-06-22 05:33:20.485863
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    """Ensures the method display of class tqdm_rich is functioning correctly."""
    pbar = tqdm_rich(total=10)
    pbar.display()
    pbar.close()

# Generated at 2022-06-22 05:33:29.510552
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = std_tqdm()
    task.completed = 100
    task.total = 1000
    f = filesize.pick_unit_and_suffix(1000, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], 1000)
    a = FractionColumn()
    b = a.render(task)
    c = f'0.1{f[1]}/1.0{f[1]}'
    assert b.markup == c

# Generated at 2022-06-22 05:33:31.031131
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    assert tqdm_rich.close()


# Generated at 2022-06-22 05:33:31.928269
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=100) as pbar:
        pass

# Generated at 2022-06-22 05:33:36.087211
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    with trange(4) as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:33:46.789283
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    
    result = column.render(Progress(total=300).add_task())
    assert result.text == '0.0/3.0', \
        "Error in FractionColumn.render():\n" + \
        "Wrong text returned (expected 0.0/3.0, got: " + result.text + ")"
    assert result.style == 'progress.download', \
        "Error in FractionColumn.render():\n" + \
        "Wrong style returned (expected progress.download, got: " + result.style + ")"
    
    task = Progress(total=0).add_task(description="A task")
    result = column.render(task)

# Generated at 2022-06-22 05:33:56.793885
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    x = FractionColumn(unit_scale=True, unit_divisor=2)
    assert x.unit_scale == True
    assert x.unit_divisor == 2
    

# Generated at 2022-06-22 05:34:02.383490
# Unit test for function trange
def test_trange():  # pragma: no cover
    with trange(7, desc="Downloading") as t:
        for _ in t:
            pass


if __name__ == '__main__':  # pragma: no cover
    import time
    with trange(5, desc="Downloading") as t:
        for _ in t:
            time.sleep(0.5)
    # test_trange()

# Generated at 2022-06-22 05:34:06.004418
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit = "B", unit_scale=False, unit_divisor=1).render("task") == '0.0 B/s'
    assert RateColumn(unit = "B", unit_scale=False, unit_divisor=1000).render("task") == '0.0 B/s'
    assert RateColumn(unit = "B", unit_scale=False, unit_divisor=1000).render("task") != '0.0 B/s'
    assert RateColumn(unit = "B", unit_scale=True, unit_divisor=1000).render("task") == '0.0 B/s'
    assert RateColumn(unit = "", unit_scale=False, unit_divisor=1).render("task") == '0.0 /s'

# Generated at 2022-06-22 05:34:07.177233
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    frac = FractionColumn()
    assert frac.render(None) is None


# Generated at 2022-06-22 05:34:12.319482
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Default
    rate = RateColumn()
    assert rate.unit == ""
    assert rate.unit_scale == False
    assert rate.unit_divisor == 1000
    # Customized
    rate = RateColumn("e", True, 1)
    assert rate.unit == "e"
    assert rate.unit_scale == True
    assert rate.unit_divisor == 1

# Generated at 2022-06-22 05:34:19.744540
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    columns = FractionColumn(unit_scale=False, unit_divisor=10)
    task = Progress()
    task.completed = 9
    assert columns.render(task) == Text("1.0/1.0", style="progress.download")

    task.completed = 10
    assert columns.render(task) == Text("1.1/1.0", style="progress.download")

    task.completed = 0
    assert columns.render(task) == Text("0.0/1.0", style="progress.download")



# Generated at 2022-06-22 05:34:27.968804
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():   # pragma: no cover
    with tqdm_rich(total=2) as t:
        assert isinstance(t._prog, Progress)
        assert t._task_id == t._prog.add_task("", total=2)
        assert not t._prog.transient
        t.update()
        assert t._prog.completed == 1
        assert t._prog.description == ""
        t.set_description("testing")
        assert t._prog.description == "testing"
        t.update()
        assert t._prog.completed == 2

# Generated at 2022-06-22 05:34:30.638699
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    for i in tqdm_rich(range(10)):
        sleep(0.1)
        tqdm_rich.reset(total=10)

# Generated at 2022-06-22 05:34:31.982923
# Unit test for constructor of class RateColumn
def test_RateColumn():
    pass
if __name__ == "__main__":
    test_RateColumn()

# Generated at 2022-06-22 05:34:40.456488
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Use the latest, greatest methods for now, but if/when we move
    # to Python 3.9, some/all of these should be updated to use
    # the separate `unit_scale` and `unit_divisor` parameters.
    assert FractionColumn(unit_scale=False, unit_divisor=1).render(
        Progress.Mock(total=10, completed=3)) == Text(
        "3.0/10 ", style="progress.download")
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(
        Progress.Mock(total=1000, completed=333)) == Text(
        "333/1,000 ", style="progress.download")

# Generated at 2022-06-22 05:34:49.526762
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm(5)
    t.reset()

# Generated at 2022-06-22 05:35:00.571701
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    # with disable=False
    progress_bar = tqdm_rich(total=10, disable=False)
    progress_bar.reset()  # clear method called with no arguments
    progress_bar.reset()  # clear method called with no arguments


# Generated at 2022-06-22 05:35:10.298467
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress = tqdm_rich(total=100, unit_scale=False)
    frac_column = FractionColumn(unit_scale=False)
    result_case_1 = frac_column.render(task=progress)
    expected_1 = "0/100 "
    progress.update(5)
    result_case_2 = frac_column.render(task=progress)
    expected_2 = "5/100 "
    progress.close()
    assert result_case_1 == expected_1
    assert result_case_2 == expected_2


# Generated at 2022-06-22 05:35:21.084292
# Unit test for constructor of class FractionColumn

# Generated at 2022-06-22 05:35:27.819951
# Unit test for constructor of class RateColumn
def test_RateColumn():
    '''
    Unit test for contructor of class RateColumn
    '''

    test_object = RateColumn(unit="G", unit_scale=True, unit_divisor=1000)
    assert test_object.__repr__() is not None
    assert test_object.__str__() is not None

    # should return a text
    assert isinstance(test_object.render(1), Text)


# Generated at 2022-06-22 05:35:30.787164
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test FractionColumn constructor"""
    progress_bar = FractionColumn()
    assert progress_bar.unit_divisor == 1000
    assert progress_bar.unit_scale == False

# Generated at 2022-06-22 05:35:34.003700
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest.mock import patch

    with patch('rich.progress.Progress.__exit__') as __exit__:
        with tqdm_rich(total=0, disable=False) as bar:
            bar.close()
            bar.close()

    assert __exit__.call_count == 1

# Generated at 2022-06-22 05:35:45.432476
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    import copy
    from .utils import _term_move_up

    # Without this ``disable``, when a user runs the tests with
    # ``python3 -m tqdm``, a progressbar will be displayed on
    # ``stderr`` which interferes with the test output checking.
    # This will not affect users running the tests through
    # ``python3 setup.py test``.
    tr = tqdm_rich(range(8), mininterval=0, file=sys.stdout, disable=True)
    assert tr.disable  # Test ``disable``
    tr.close()  # Test ``close``

    # Test ``clear``
    tr = tqdm_rich(range(8), mininterval=0, file=sys.stdout, disable=True)
    desc = tr.desc
   

# Generated at 2022-06-22 05:35:47.421459
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(10) as t:
        t.close()



# Generated at 2022-06-22 05:35:56.188930
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import Progress
    progress = Progress(FractionColumn())
    progress.add_task("name", total=23)
    progress.update(0, completed=11)
    progress.__exit__(None, None, None)


if __name__ == "__main__":
    from time import sleep
    for i in trange(5):
        sleep(0.5)
    with tqdm(total=3) as pbar:
        for i in range(3):
            pbar.update()
            sleep(0.2)
    test_FractionColumn()

# Generated at 2022-06-22 05:36:12.072381
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import sys
    import time
    for _ in tqdm_rich(range(4), file=sys.stderr, desc="1st loop"):
        for _ in tqdm_rich(range(5), file=sys.stderr, desc="2nd loop", leave=True):
            for _ in tqdm_rich(range(50), file=sys.stderr, desc="3rd loop"):
                time.sleep(0.01)


# Generated at 2022-06-22 05:36:16.658767
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test tqdm_rich close method"""
    with tqdm_rich(total=10, unit="", disable=False) as pbar:
        for i in _range(10):
            pbar.update()
    # Add a test for the close function
    assert pbar._prog.__exit__(None, None, None) == None



# Generated at 2022-06-22 05:36:21.487414
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        tqdm_rich(range(3)).close()  # no exceptions
    except:
        raise RuntimeError("Failed tqdm_rich constructor test")
test_tqdm_rich()

# Generated at 2022-06-22 05:36:31.884478
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Test total greater than 1
    col = FractionColumn()
    model = Progress()
    task_id = model.add_task(total=10, completed=5)
    task = model.get_task(task_id)
    assert col.render(task) == Text(
        f"5.0/10.0",
        style="progress.download")
    # Test total equal to 0.9
    model.reset(total=0.9)
    task_id = model.add_task(total=0.9, completed=0.5)
    task = model.get_task(task_id)
    assert col.render(task) == Text(
        f"0.5/0.9",
        style="progress.download")



# Generated at 2022-06-22 05:36:35.897501
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=100) as t:
        for _ in t:
            t.update(1)
    t = tqdm_rich(total=100)
    t.clear()
    t.close()
    t.reset(total=100)
    with trange(10) as t:
        for _ in t:
            t.update(1)

# Generated at 2022-06-22 05:36:42.595109
# Unit test for function trange
def test_trange():
    """Test function trange."""
    a = trange(10)
    assert isinstance(a, tqdm_rich)
    assert len(a.format_dict) == 8
    assert trange(10)._prog.__str__() == "_prog<tasks=1, completed=0>"



# Generated at 2022-06-22 05:36:54.703964
# Unit test for function trange
def test_trange():
    """Test that the function trange behaves like tqdm."""
    from .tests_tqdm import comparisons


# Generated at 2022-06-22 05:36:56.335123
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate = RateColumn()
    assert rate.unit == ""
    assert rate.unit_scale == False
    assert rate.unit_divisor == 1000

# Generated at 2022-06-22 05:36:58.750363
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=10)
    assert t._task_id is not None
    t.close()
    assert t._task_id is None
    assert t._prog is None



# Generated at 2022-06-22 05:37:09.648139
# Unit test for constructor of class RateColumn
def test_RateColumn():
    class TestRateColumn(RateColumn): pass
    assert str(TestRateColumn()) == '? B/s'
    assert str(TestRateColumn(unit='/bytes')) == '? B/bytes/s'
    with std_tqdm(total=1, smoothing=1) as t:
        t.update(total=1000)
        assert str(TestRateColumn(unit='/bytes', unit_scale=True)) == '0.0/bytes/s'
        t.update(total=1000000)
        assert str(TestRateColumn(unit='/bytes', unit_scale=True)) == '0.0/bytes/s'
        t.update(total=1000000000)
        assert str(TestRateColumn(unit='/bytes', unit_scale=True)) == '0.0/bytes/s'
        t.update

# Generated at 2022-06-22 05:37:36.619453
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="Downloading", completed=0, total=1024*1024*1024)
    fraction = FractionColumn()
    fraction_render = fraction.render(task)
    assert str(fraction_render) == '0.0/1024.0 M', "Error in rendering the fraction"

if __name__ == "__main__":
    with tqdm(total=10) as t:
        for _ in range(10):
            t.update()
            sleep(0.1)
    try:
        from rich.console import Console
        console = Console()
        console.print("Hello World!")
    except ImportError:
        pass

# Generated at 2022-06-22 05:37:39.401771
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    desc = "Test tqdm_rich"
    for _ in tqdm_rich(_range(50), desc=desc):
        pass

# Generated at 2022-06-22 05:37:44.346974
# Unit test for function trange
def test_trange():
    # pylint: disable=unsubscriptable-object
    for _ in trange(10, desc="testing"):
        pass


if __name__ == "__main__":
    # pylint: disable=wrong-import-position
    from .main import main
    main(__doc__)

# Generated at 2022-06-22 05:37:52.703554
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column  = FractionColumn()
    task = column.task

    task.completed = 10
    task.total = 100
    assert column.render(task) == "0.1/1.0 "
    
    task.completed = 50
    task.total = 100
    assert column.render(task) == "0.5/1.0 "

    task.completed = 10
    task.total = 1025
    assert column.render(task) == "0.0/1.0 K"

    task.completed = 25
    task.total = 100
    assert column.render(task) == "0.2/1.0 "

# Generated at 2022-06-22 05:37:58.943197
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import rich
    try:
        tqdm_rich.display(self)
    except:
        assert False, ("method display of class tqdm_rich doesn't work" +
                       "as expected.\n")
    else:
        assert True, ("method display of class tqdm_rich works" +
                      "as expected.\n")

# Generated at 2022-06-22 05:38:07.665021
# Unit test for constructor of class RateColumn
def test_RateColumn():
    c = RateColumn(unit_scale=True, unit_divisor=1000)
    assert c.render(Progress(total=0, completed=0, speed=0)) == '0.0 /s'
    assert c.render(Progress(total=0, completed=0, speed=1)) == '0.0 /s'
    assert c.render(Progress(total=0, completed=0, speed=600)) == '600.0 /s'
    assert c.render(Progress(total=0, completed=0, speed=1000)) == '0.9 K/s'
    assert c.render(Progress(total=0, completed=0, speed=10**6)) == '976.6 K/s'

# Generated at 2022-06-22 05:38:09.805800
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column_instance = RateColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:38:15.487594
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from rich.progress import Progress as ProgressBar
    with tqdm_rich(total=2, desc="Reset counter") as pb:
        time.sleep(0.01)
        pb.reset(total=4)
        for _ in pb:
            time.sleep(0.01)
    assert isinstance(pb._prog, ProgressBar)

# Generated at 2022-06-22 05:38:20.985548
# Unit test for function trange
def test_trange():
    """Test function trange."""
    list(trange(2))
    list(trange(2, 3))
    list(trange(2, 3, 1))
    list(trange(2, 3, 1, False))
    list(trange(2, 3, 1, True))

# Generated at 2022-06-22 05:38:25.327576
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm(total=100) as t:
        for i in range(100):
            t.update()
            time.sleep(0.01)


# Generated at 2022-06-22 05:39:06.845665
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    obj = RateColumn('B')
    task = Progress(task_id=1, total=10, completed=5)
    obj.render(task)

# Generated at 2022-06-22 05:39:10.544221
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render({
        "description": None,
        "completed": 2.7,
        "total": 100}) == Text("2.7/100 ", style="progress.download")


# Generated at 2022-06-22 05:39:18.083848
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Test execution of class tqdm_rich
    with tqdm(total=100) as t:
        for _ in range(100):
            t.display()
            t.update()
    # Test output of class tqdm_rich
    t = tqdm(total=100, leave=False)
    for _ in range(100):
        t.display()
        t.update()
    t.display()
    t.close()

# Generated at 2022-06-22 05:39:29.157440
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import sys
    import six
    if six.PY2:
        reload(sys)
        sys.setdefaultencoding('utf8')
    test_task = Progress()
    test_task.completed = 110488500
    test_task.total = 110496900
    test_task.start_time = 1563132717.582372
    test_task.last_update_time = 1563132721.9746032
    test_task.speed = 0
    test_task.description = 'Downloading'
    test_task.percentage = 100.0
    test_task.displayed = True

    assert FractionColumn().render(test_task) == Text('110.49/110.50 M', style="progress.download")

# Generated at 2022-06-22 05:39:33.777342
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for tqdm_rich.reset()
    """
    with tqdm_rich(desc="test", total=5) as bar:
        bar.reset()
        for _ in range(5):
            bar.update(1)
    assert bar.n == 5

# Generated at 2022-06-22 05:39:45.085844
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .std import tqdm
    from .utils import format_sizeof
    from .cls2 import _range_ex  # pylint: disable=unused-variable
    import time

    try:
        import rich
    except ImportError:
        raise unittest.SkipTest("Requires package rich")

    bar_format = "[{bar:}] {desc} {percentage:3.0f}%\n{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}/s]"

    # Test on tqdm_rich

# Generated at 2022-06-22 05:39:50.162320
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.render(Progress(3000.0, 3000.0)) == Text("1.0/1.0 G", style="progress.download")


# Generated at 2022-06-22 05:39:54.458874
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Calling display() after __init__ should not raise any error.
    import time
    with tqdm_rich(total=3) as t:
        t.display()
        t.update()
        time.sleep(1)
        t.update(2)
        time.sleep(1)

# Generated at 2022-06-22 05:39:58.040753
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    rate = 0
    _, s = filesize.pick_unit_and_suffix(rate, [""], 1)
    assert r.render(rate) == Text(f"0 {s}/s", style="progress.data.speed")

# Generated at 2022-06-22 05:40:04.252272
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # setup class
    t = tqdm_rich(total=42)
    # call method
    t.close()
    # assert calls
    # noinspection PyProtectedMember
    assert t.disable is False and t._prog.total == 42

# Generated at 2022-06-22 05:41:44.659253
# Unit test for function trange
def test_trange():  # pragma: no cover
    from pytest import raises  # type: ignore
    from .std import trange as std_trange
    for n, nstd in zip((0, 1, 100), (0, 1, 100)):
        with tqdm(total=n) as t:
            assert len(t) == nstd  # len() == n
            t.update()  # manually update
            assert t.n == 1  # n == 1
            assert t.n == t.last_print_n  # last print == this print
            t.update(nstd - 1)  # manually update
            assert t.n == nstd
            t.update()  # manually update again
            assert t.n == nstd  # hasn't changed
            assert t.n == t.last_print_n  # last print == this print

# Generated at 2022-06-22 05:41:49.322469
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=3) as t:
        assert t.total == 3
        t.reset(5)
        assert t.total == 5
        t.reset(1)
        assert t.total == 1

# Generated at 2022-06-22 05:41:51.382258
# Unit test for constructor of class RateColumn
def test_RateColumn():
    x = RateColumn(unit_scale=True, unit_divisor=2)
    assert x.unit_scale == True

# Generated at 2022-06-22 05:42:01.462572
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method `tqdm_rich.reset()`."""
    # Testing with a trange object (instantiated with total=None)
    if hasattr(trange(10), 'reset'):
        t = trange(10)
        t.n = 2
        t.reset(total=None)
        assert t.n == 0
        assert t.total == 10
        t.n = 2
        t.reset()
        assert t.n == 0
        assert t.total == 10
        t.n = 2
        t.reset(total=5)
        assert t.n == 0
        assert t.total == 5
    # Testing with a trange object (instantiated with total=5)
    if hasattr(trange(10), 'reset'):
        t = trange(5)

# Generated at 2022-06-22 05:42:07.728098
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests_tqdm import pretest_posttest_print as _test_tqdm_rich

    def _test_tqdm_rich_gui(n):
        with tqdm(total=n, desc='test_tqdm_rich_gui',
                  unit='i', unit_scale=True) as t:
            for i in _range(n):
                t.update()
    _test_tqdm_rich(_test_tqdm_rich_gui)



# Generated at 2022-06-22 05:42:17.276981
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import sys
    from io import StringIO
    from rich.table import Table
    from rich.progress import Task

    class TaskStub(Task):
        def __init__(self):
            self.completed = 0
            self.total = 100

    progress_column = FractionColumn()
    task = TaskStub()
    task.completed = 100
    task.total = 100
    task.description = "completed/total"
    stdout = sys.stdout
    sys.stdout = StringIO()
    table = Table("description", progress_column)
    table.add_row(task.description, progress_column.render(task))
    table.print()
    output = sys.stdout.getvalue().strip()

    sys.stdout = stdout

    assert output == "completed/total  100/100"

# Generated at 2022-06-22 05:42:20.528117
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert not (fc.unit_scale and fc.unit_divisor == 1024)
    assert fc.unit_scale and fc.unit_divisor == 1000


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-22 05:42:26.781966
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from collections import namedtuple
    task = namedtuple('task', ['completed', 'total', 'speed'])(9, 30, None)
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    result = column.render(task)
    assert result.text == '9/30 '
    assert result.style == 'progress.download'


# Generated at 2022-06-22 05:42:27.908164
# Unit test for function trange
def test_trange():
    """Test function trrange()"""
    assert tuple(trrange(3)) == tuple(range(3))

# Generated at 2022-06-22 05:42:36.133015
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    try:
        import rich
    except ImportError:
        return