

# Generated at 2022-06-22 05:33:03.961938
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .test_tqdm import TestTqdmIO

    with TestTqdmIO(tqdm_rich) as io:
        from .std import tqdm as tqdm

        t = tqdm(total=100, smoothing=0, leave=False)
        for i in range(100):
            t.update()
            t.set_description("Loop %d" % t.n)
        t.close()
        assert '\n' not in io.stdout

if __name__ == "__main__":  # pragma: no cover
    from .std import tqdm as tqdm

    with tqdm.trange(1000, leave=False) as t:
        while True:
            t.set_description(str(t.n))
            t.update()

# Generated at 2022-06-22 05:33:13.130183
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Test `FractionColumn.__init__`.
    """
    try:
        FractionColumn(unit_scale=True, unit_divisor=1000)
        FractionColumn(unit_scale=False, unit_divisor=1)
        FractionColumn(unit_scale="test", unit_divisor=1000)
        FractionColumn(unit_scale=True, unit_divisor="test")
    except TypeError:
        raise TypeError("FractionColumn constructor accepts parameter: unit_scale:"
                        "True/False and unit_divisor:1000/1 only.")

# Generated at 2022-06-22 05:33:22.800650
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for cls in (tqdm, trange):
        with cls(total=1000, disable=True) as pbar:
            pbar.reset()
            assert pbar.total == 0

        with cls(total=1000, disable=False) as pbar:
            pbar.reset()
            assert pbar.total == 0

        with cls(total=1000, disable=True) as pbar:
            pbar.reset(total=2000)
            assert pbar.total == 0

        with cls(total=1000, disable=False) as pbar:
            pbar.reset(total=2000)
            assert pbar.total == 2000

# Generated at 2022-06-22 05:33:32.296779
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Unit test for rich.progress method clear of class tqdm_rich

    Raises
    ------
    AssertionError
        If the method clear of class tqdm_rich does not allow one
        assertion to pass.
    """
    from unittest import TestCase
    from unittest.mock import Mock

    class tqdm_rich_TestCase(TestCase):
        def test_clear(self):
            test = tqdm_rich(disable=True)
            test.clear()
            self.assertEqual(test.n, 0)

            test = tqdm_rich(disable=True)
            test.clear(nolock=True)
            self.assertEqual(test.n, 0)

            test = tqdm_rich()
            test.clear()
            self.assertEqual

# Generated at 2022-06-22 05:33:37.240309
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        tqdm_rich.clear()
    except:  # pragma: no cover
        raise AssertionError("method clear of class tqdm_rich failed")

# Generated at 2022-06-22 05:33:43.846408
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest

    speed = 100
    unit = "M"
    unit_divisor = 1000
    unit_scale = True
    obj = RateColumn(unit=unit, unit_divisor=unit_divisor, unit_scale=unit_scale)
    expected = Text(f"{speed:,.0f} {unit}/s", style="progress.data.speed")
    actual = obj.render(speed=speed)
    assert expected == actual



# Generated at 2022-06-22 05:33:52.383365
# Unit test for constructor of class RateColumn
def test_RateColumn():
    progress_column = RateColumn()
    assert progress_column.unit == ""
    assert progress_column.unit_scale == False
    assert progress_column.unit_divisor == 1000

    progress_column = RateColumn(unit="K")
    assert progress_column.unit == "K"
    assert progress_column.unit_scale == False
    assert progress_column.unit_divisor == 1000

    progress_column = RateColumn(unit_scale=True)
    assert progress_column.unit == ""
    assert progress_column.unit_scale == True
    assert progress_column.unit_divisor == 1000

    progress_column = RateColumn(unit_divisor=1000)
    assert progress_column.unit == ""
    assert progress_column.unit_scale == False
    assert progress_column.unit_divisor == 1000

# Generated at 2022-06-22 05:33:57.194252
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # type: () -> None
    t = tqdm_rich(total=100)
    t.update(10)
    t.close()
    rc = RateColumn()
    assert "10.0 " == rc.render(t).render(BASIC_FORMATTING)



# Generated at 2022-06-22 05:34:00.123690
# Unit test for function trange
def test_trange():
    """
    Simple test of main functionality.
    """
    with trange(10) as t:
        for _ in t:
            pass

# Generated at 2022-06-22 05:34:04.587821
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        import rich
        from tqdm.rich import trange
        with trange(10) as t:
            for i in t:
                if i > 5:
                    break
    except Exception:
        # In case of ImportError, KeyboardInterrupt, or other exception
        # (more likely)
        pass

# Generated at 2022-06-22 05:34:11.238523
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich import print
    with tqdm_rich("""
    this text is for long description
    for the task.
    """, total=3) as pbar:
        for _ in range(3):
            pbar.update(1)

# Generated at 2022-06-22 05:34:17.017833
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=1000)
    task.n = 100
    task.start_t = 0
    task.last_print_n = 100
    task.avg_time = 0
    task.speed = None
    task.last_print_t = 0.0001
    assert RateColumn().render(task) == Text(
        "inf ?/s", style="progress.data.speed")
    task.speed = 10
    assert RateColumn().render(task) == Text("10 ?/s", style="progress.data.speed")
    assert RateColumn("b").render(task) == Text("10 b/s", style="progress.data.speed")
    assert RateColumn("b", unit_scale=True).render(task) == Text(
        "10.0 ?/s", style="progress.data.speed")

# Generated at 2022-06-22 05:34:21.720292
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=100)
    t.close()
    assert t._prog.tasks == {}
    assert t._prog.__exit__.called

# Generated at 2022-06-22 05:34:23.998179
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert repr(FractionColumn()) == repr(FractionColumn(unit_scale=False, unit_divisor=1000))

# Generated at 2022-06-22 05:34:34.331618
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import time
    from rich.progress import TaskID, Progress

    total = 100
    with tqdm(total=total) as pbar, Progress() as progress:
        time.sleep(0.3)

        # Get the task_id from pbar
        task_id = pbar._task_id

        # Get progress_obj from pbar
        progress_obj = pbar._prog

        # Remove the pbar
        progress_obj.remove_task(task_id)
        pbar.close()

        # Create a new progress obj
        progress.__enter__()

        # Add the task to the new progress obj
        new_task_id = progress.add_task(description=" ", total=total)

        # Set pbar's progress to the new progress obj
        pbar._prog = progress



# Generated at 2022-06-22 05:34:38.429125
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .gui import tgrange
    for i in tgrange(4, desc='rich'):
        sleep(0.1)

# Generated at 2022-06-22 05:34:44.652931
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task = Progress()
    test_task.completed = 35000
    test_task.total = 50000
    test_obj = FractionColumn()
    size_str = test_obj.render(test_task)
    assert size_str.text == '35.0/50.0'
    test_obj = FractionColumn(unit_scale=True)
    size_str = test_obj.render(test_task)
    assert size_str.text == '35.0/50.0 K'

# Generated at 2022-06-22 05:34:50.163439
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import TaskID

    first_total = 10
    second_total = 20

    td = tqdm(total=first_total)
    td.reset(second_total)

    assert td.total == second_total
    assert td._prog._tasks[TaskID(0)]['total'] == second_total

# Generated at 2022-06-22 05:34:54.070558
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    if tqdm:
        with tqdm(total=10) as bar:
            bar.reset(total=3)
            assert bar.total == 3
            assert bar.n == 0
            bar.update()
            assert bar.n == 1
            assert bar.total == 3

# Generated at 2022-06-22 05:35:04.568694
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import rich
    import os

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock  # type: ignore

    with patch.object(rich.progress.Progress, '__getattr__', MagicMock(side_effect=AttributeError)):
        bar = tqdm_rich(5)
        bar.clear()
        bar.close()
        bar = tqdm_rich(5, file=os.devnull)
        bar.clear()
        bar.close()

# Generated at 2022-06-22 05:35:13.142793
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich().close()

# Generated at 2022-06-22 05:35:17.158665
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    expected = [
        '',
        '                                                                              ',
    ]

    with tqdm_rich(total=1) as progress_bar:
        progress_bar.clear()



# Generated at 2022-06-22 05:35:19.553980
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=10, gui=True)
    for _ in t:
        t.display()



# Generated at 2022-06-22 05:35:22.790195
# Unit test for constructor of class FractionColumn
def test_FractionColumn(): # pragma: no cover
    assert FractionColumn(unit_scale=False, unit_divisor=1000).unit_divisor == 1000



# Generated at 2022-06-22 05:35:25.572800
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rtc = RateColumn()
    assert rtc.render(None) == Text("?  /s", style="progress.data.speed")

# Generated at 2022-06-22 05:35:34.910522
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test the constructor of the class tqdm_rich."""
    for n in tqdm([], disable=False):
        pass
    for n in tqdm([], disable=None):
        pass
    for n in tqdm([], disable=True):
        pass
    for n in tqdm([], disable=True, leave=True):
        pass
    try:
        for n in tqdm([], gui=True):
            pass
    except TypeError:
        pass
    for n in trange(5):
        pass
    for n in trange(5, leave=True):
        pass

# Generated at 2022-06-22 05:35:46.190184
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(1, 2) == Text('1.00 B/s', style='progress.data.speed')
    assert RateColumn().render(1024, 2) == Text('1.00 KiB/s', style='progress.data.speed')
    assert RateColumn().render(1048576, 2) == Text('1.00 MiB/s', style='progress.data.speed')
    assert RateColumn().render(1073741824, 2) == Text('1.00 GiB/s', style='progress.data.speed')
    assert RateColumn().render(1099511627776, 2) == Text('1.00 TiB/s', style='progress.data.speed')
    assert RateColumn().render(1125899906842624, 2) == Text('1.00 PiB/s', style='progress.data.speed')

# Generated at 2022-06-22 05:35:52.014774
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    task = Progress()

    fraction_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    task.completed = 5
    task.total = 7
    task_str = fraction_column.render(task)
    assert task_str.text == "5/7"

# Generated at 2022-06-22 05:35:53.572818
# Unit test for function trange
def test_trange():
    t = trange(10)
    assert isinstance(t, tqdm_rich)
    for i in t:
        pass
    t.close()


# Generated at 2022-06-22 05:35:58.216464
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():

    import time
    import random

    with tqdm(total=100) as pbar:
        for i in range(100):
            pbar.update(1)
            time.sleep(random.random() / 3)
            if i == 50:
                pbar.reset(total=None)

# Generated at 2022-06-22 05:36:14.719425
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import time
    t = trange(10, file=sys.stdout)
    for _ in t:
        time.sleep(0.1)
    t.close()


# Generated at 2022-06-22 05:36:18.254385
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [100, 100.1, None]:
        pbar = tqdm_rich(total=total)
        pbar.update(50)
        pbar.reset(total=None)
        pbar.update(25)
        pbar.close()

# Generated at 2022-06-22 05:36:29.943864
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test case for method display."""
    import sys
    import shutil
    from io import StringIO

    captured_output = StringIO()  # Capture stdout
    sys.stdout = captured_output

    from .rich import _tqdm
    from .utils import _screen_shape

    # Test 1: simple test for display()
    with _tqdm(_range(10), miniters=1, ascii=True,
               desc="foo") as t:
        for i in t:
            assert t.n == i + 1, "n != i+1"
            assert t.n <= t.total, "n > total"
            t.display()
            assert t.n == i + 1, "n != i+1"
            assert t.n <= t.total, "n > total"

# Generated at 2022-06-22 05:36:37.404186
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import unittest
    from .gui import tqdm as _tqdm

    class TestTqdmRichDisplay(unittest.TestCase):
        def test_display(self):
            try:
                with tqdm_rich(range(10), miniters=1, mininterval=0.01) as t:
                    for i in t:
                        t.display()
            except _tqdm.TclError:
                # If tcl/tk isn't properly installed then t.display() will
                # fail due to a bug in rich
                pass

# Generated at 2022-06-22 05:36:45.588989
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test the method `reset`.
    """
    bar0 = tqdm_rich(total=10, leave=True)
    # See issue #835
    bar0.reset(total=20)
    for i in range(10):
        bar0.update()
    bar0.close()
    bar1 = tqdm_rich(total=10, leave=False)
    bar1.reset(total=20)
    for i in range(10):
        bar1.update()
    bar1.close()

# Generated at 2022-06-22 05:36:53.970355
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    trange(3)


if __name__ == '__main__':  # pragma: no cover
    import time
    t = trange(10, desc="Cool", bar_style="danger",
               progress=(
                   "[{task.description}]",
                   "[{task.percentage:>2.2f}%]"
               ))
    # Add more information to the progress bar
    for _ in t:
        time.sleep(0.01)
        t.set_postfix(dict(
            lulz='lol',
            flex='yes',
        ))

# Generated at 2022-06-22 05:36:55.236620
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(2) as pbar:
        pbar.reset(5)
        pbar.update()

# Generated at 2022-06-22 05:36:57.419883
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    rc = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rc.render(Progress()).value == "? B/s"

# Generated at 2022-06-22 05:37:07.439624
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    from rich.progress import TaskID
    from rich.console import Console
    with Console() as console:
        task = TaskID(description='Unit Test', i=0, completed=0, total=None)
        column = RateColumn(unit='B', unit_scale=True, unit_divisor=1000)
        rate = column.render(task)
        assert rate.text.endswith('B/s')
        column = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
        rate = column.render(task)
        assert rate.text.endswith('/s')

# Generated at 2022-06-22 05:37:18.721232
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Initialize a RateColumn object
    rateColumn1 = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    rateColumn2 = RateColumn(unit="KB", unit_scale=True, unit_divisor=1000)
    rateColumn3 = RateColumn(unit="KB", unit_scale=True, unit_divisor=1024)
    # Test results
    assert rateColumn1.render(99) == Text("99 B/s", style="progress.data.speed")
    assert rateColumn2.render(99) == Text("0.099 KB/s", style="progress.data.speed")
    assert rateColumn3.render(99) == Text("0.097 KB/s", style="progress.data.speed")

# Generated at 2022-06-22 05:37:52.754377
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit="b")
    assert rate_column.unit         == "b"
    assert rate_column.unit_scale   == False
    assert rate_column.unit_divisor == 1000

test_RateColumn()

# Generated at 2022-06-22 05:37:57.863313
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit tests for the RateColumn class."""
    _ = RateColumn()  # noqa: F841
    _ = RateColumn(unit="/s")  # noqa: F841
    _ = RateColumn(unit_divisor=1024)  # noqa: F841
    _ = RateColumn(unit_scale=False)  # noqa: F841
    _ = RateColumn(unit="/s", unit_scale=False)  # noqa: F841


if __name__ == '__main__':
    test_RateColumn()

# Generated at 2022-06-22 05:38:07.297791
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import time
    with tqdm(total=10) as pbar:
        for i in pbar:
            time.sleep(0.01)
    assert pbar.n == 10
    # Test fix of issue #369
    with tqdm(total=None, desc="Foo") as pbar:
        assert pbar.total is None
        assert pbar.unit_scale is False
        pbar.total = 10
        assert pbar.total == 10
        for i in pbar:
            time.sleep(0.01)
            if i == 5:
                pbar.reset()
    assert pbar.n == 5
    # Test fix of issue #494
    with tqdm(total=10) as pbar:
        for i in pbar:
            if i == 5:
                break

# Generated at 2022-06-22 05:38:15.135202
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    # Test for expected behavior
    with tqdm_rich(total=10) as t:
        for i in range(5):
            time.sleep(0.2)
            t.update(2)
    assert t.n == 10
    # Test for unexpected behavior
    with tqdm_rich(total=10) as t:
        for i in range(5):
            time.sleep(0.2)
            t.update(2)
    assert t.n != 10



# Generated at 2022-06-22 05:38:18.942187
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    This method tests the class RateColumn and their method render.
    """
    rate_column = RateColumn()
    task = 1.0
    if rate_column.render(task) != '1.0 /s':
        raise ValueError("Value not expected")

# Generated at 2022-06-22 05:38:21.590838
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=1) as t:
        assert t.reset(total=2) is None
        assert t.total == 2


if __name__ == "__main__":
    from .main import _test
    _test()

# Generated at 2022-06-22 05:38:33.207111
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    This function tests that:
        1. RateColumn.render() returns a string
        2. RateColumn.render() returns a string which respects the display
           options of the method

    """
    from rich.progress import Task

    rate_column_1 = RateColumn(unit="s")
    rate_column_2 = RateColumn(unit="s", unit_scale=True, unit_divisor=1000)
    rate_column_3 = RateColumn(unit="s", unit_scale=True, unit_divisor=1024)

    task = Task('test')
    # set attributes to render test
    task.speed = 1
    task.total = 2

    # Test render expected result with a unit 's'
    # The expected result is: "1 s/s"

# Generated at 2022-06-22 05:38:40.315685
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    class TestMethod(unittest.TestCase):
        def test_render(self):
            task = DummyTask()
            task.completed = 2/3
            task.total = 10
            test_Column = FractionColumn(unit_scale=True)
            test_Column.render(task)
            self.assertEqual(test_Column.text, "\u001b[37m0.7/10.0 \u001b[0m")
            task.completed = 4/10
            task.total = 2/5
            test_Column = FractionColumn(unit_scale=False)
            test_Column.render(task)
            self.assertEqual(test_Column.text, "\u001b[37m20.0/40.0 \u001b[0m")

# Generated at 2022-06-22 05:38:48.264069
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():

    # init
    tqdm_o = tqdm_rich(total=1)
    tqdm_o.disable = False

    tqdm_o.close()
    # _prog.__exit__(None, None, None) ==> _exit
    assert hasattr(tqdm_o, '_exit')

    tqdm_o.close()
    # _prog.__exit__(None, None, None) ==> _exit
    assert hasattr(tqdm_o, '_exit')


# Generated at 2022-06-22 05:38:51.380495
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Given
    object_RateColumn = RateColumn(unit_scale=True, unit_divisor=1000)
    # When
    object_RateColumn.render(object_RateColumn)
    # Then
    assert True

# Generated at 2022-06-22 05:41:15.496440
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    rate_column.render(40)
    #rate_column.render(1)
    #rate_column.render(0.5)

# Generated at 2022-06-22 05:41:26.482742
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task_dict = {"total": 2, "completed": 0, "speed": None, "description": "FractionColumn"}
    # Test normal case
    task_dict["completed"] = 1.5
    task_dict["total"] = 10.5
    fc1 = FractionColumn()
    assert fc1.render(task_dict) == "1.5/10.5"
    # Test for unit_scale = True
    task_dict["completed"] = 1500
    fc2 = FractionColumn(unit_scale=True)
    assert fc2.render(task_dict) == "1.5/10.5 K"
    # Test for unit_scale = True, unit_divisor = 1024
    fc3 = FractionColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:41:30.798800
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    unit_scale = False
    unit_divisor = 1000
    column = FractionColumn(unit_scale, unit_divisor)
    assert(column.unit_scale == unit_scale)
    assert(column.unit_divisor == unit_divisor)

# Generated at 2022-06-22 05:41:39.603961
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test `display` method of `tqdm_rich` class."""
    from rich.console import Console
    from rich.progress import TaskID

    console = Console()

    t = tqdm_rich(0, 5, leave=True, total=5)
    assert t._prog == Progress(*[
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"])
    assert t._prog.console == console
    assert t._task_id == TaskID(0)
    t.display()
    t.close()

    # leave=True: transient=False, _prog.is_

# Generated at 2022-06-22 05:41:43.211967
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
    assert pbar.disable == True

# Generated at 2022-06-22 05:41:54.958802
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from io import StringIO as sio
    for total in (6, 15, 30):
        buf = sio()
        with tqdm_rich(total=total, file=buf, position=0) as t:
            assert t._prog.total == total
        with tqdm_rich(total=total, file=buf, position=0) as t:
            assert t._prog.total == total
            t.reset(total=total/3)
            assert t._prog.total == total/3
        with tqdm_rich(total=total, file=buf, position=0) as t:
            assert t._prog.total == total
        with tqdm_rich(total=total, file=buf, position=0) as t:
            assert t._prog.total == total

# Generated at 2022-06-22 05:42:00.727753
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = object()
    task.completed = 200
    task.total = 300
    res = filesize.pick_unit_and_suffix(300, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], 1000)
    assert res == (300, "")
    fcol = FractionColumn(False, 1000)
    assert fcol.render(task).value == "200.0/300.0"

# Generated at 2022-06-22 05:42:04.473208
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # test when completed/total >1 and completed/total <1
    assert FractionColumn().render(Progress.Task(0.5, 2.3)) == Text(
        "0.5/2.3 ", style="progress.download")

# Generated at 2022-06-22 05:42:13.677801
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import pytest
    # Test 1: If the _prog attribute is not present, reset returns without any
    #         exception
    tqdm_rich_obj = tqdm_rich(total=10, desc='Test 1')
    del tqdm_rich_obj._prog
    tqdm_rich_obj.reset()
    assert tqdm_rich_obj.desc == 'Test 1'

    # Test 2: If the _prog attribute is present, reset calls reset of Progress
    #         object, and preserves desc
    tqdm_rich_obj = tqdm_rich(total=10, desc='Test 2')
    tqdm_rich_obj.reset()
    assert tqdm_rich_obj.desc == 'Test 2'

    # Test 3: If the _prog attribute is present, reset raises exception when total

# Generated at 2022-06-22 05:42:16.086250
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(range(5)) as t:
        for _ in t:
            continue
