

# Generated at 2022-06-22 05:33:05.959539
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=1, desc="test")
    t.update()
    t.close()

# Generated at 2022-06-22 05:33:11.780757
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test FractionColumn:render()
    """
    a = tqdm_rich(range(20), desc="FractionColumn", unit_scale=True)
    a.render()
    a.close()


# Generated at 2022-06-22 05:33:20.374359
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    FractionColumn().render(Progress(0, 2)) == Text("0.0/2.0", style="progress.download")
    FractionColumn().render(Progress(1, 2)) == Text("1.0/2.0", style="progress.download")
    FractionColumn().render(Progress(0, 1)) == Text("0.0/1.0", style="progress.download")
    FractionColumn().render(Progress(1, 1)) == Text("1.0/1.0", style="progress.download")


# Generated at 2022-06-22 05:33:23.289495
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(range(3))
    t.close()
    assert t._prog.__exit__(None, None, None) == None 


# Generated at 2022-06-22 05:33:25.949110
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    d = tqdm_rich(total=4)
    for i in range(4):
        d.update(1)
    d.close()



# Generated at 2022-06-22 05:33:28.759870
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pbar = tqdm_rich(total=100)
    assert pbar.total == 100
    pbar.clear()
    assert pbar.total == 100

# Generated at 2022-06-22 05:33:40.226078
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.std import tqdm as tqdm_std
    from tqdm.std import trange as trange_std
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.auto import trange as trange_auto

    def func(tqdm_class):
        check_name(tqdm_class)
        # Test display function
        with tqdm_class(total=10) as bar:
            bar.display()
            bar.display()

    def check_name(tqdm_class):
        name = tqdm_class.__name__
        name = name.replace("_", "-")

# Generated at 2022-06-22 05:33:43.896345
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = Progress()
    progress.add_task("A task", completed=0, total=10)
    progress.add_column(FractionColumn())
    progress.update(0, description="")
    assert progress.format() == "A task 0/10 "


# Generated at 2022-06-22 05:33:46.489851
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import pytest
    with pytest.raises(UnboundLocalError):
        t = tqdm_rich(range(10), disable = False)
        t.close()
        _prog = t._prog

# Generated at 2022-06-22 05:33:54.130057
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    For the value of 'speed', the function returns a value:
        <speed / unit> <suffix><unit> / s
    where the default values ​​for' unit 'and' suffix 'are:
        * unit = ' '
        * suffix = ""
    If the method is called with the 'unit_scale' parameter set to True,
    the speed is converted to the most appropriate SI unit,
    and the 'suffix' value is set to the appropriate SI prefix:
        * for speed = 2000: <speed / unit> <suffix><unit> / s = 2 K / s
    """
    speed = 2000
    unit = ""
    suffix = ""
    rate_column = RateColumn(unit)

# Generated at 2022-06-22 05:34:09.242350
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    # RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    # RateColumn(unit="", unit_scale=False, unit_divisor=1024)
    # RateColumn(unit="", unit_scale=True, unit_divisor=1024)
    l_rate_column = [
        RateColumn(unit="", unit_scale=False, unit_divisor=1000),
        RateColumn(unit="", unit_scale=True, unit_divisor=1000),
        RateColumn(unit="", unit_scale=False, unit_divisor=1024),
        RateColumn(unit="", unit_scale=True, unit_divisor=1024),
    ]

# Generated at 2022-06-22 05:34:11.489892
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fixture = FractionColumn()
    result = fixture.render({"completed": 0, "total": 10})
    expected = Text("0.0/10.0", style="progress.download")
    assert result == expected

# Generated at 2022-06-22 05:34:14.483280
# Unit test for function trange
def test_trange():

    with trange(10) as t:
        for i in t:
            assert i == t.n
            t.set_description("foo")
            t.refresh()

# Generated at 2022-06-22 05:34:16.916976
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=None, bar_format='{l_bar}') as t:
        t.clear()



# Generated at 2022-06-22 05:34:23.754730
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit='s', unit_scale=False, unit_divisor=1000)
    # Test that the rate column is updated correctly when the speed updates
    assert rate_column.render(std_tqdm()) == Text('? s/s', style='progress.data.speed')
    assert rate_column.render(std_tqdm(total=None)) == Text('? s/s', style='progress.data.speed')

    # Test that the rate column is updated correctly when the speed is not None
    progress_bar = std_tqdm(total=None)
    progress_bar.n = 0
    progress_bar.last_print_n = 0
    progress_bar.start_t = None
    progress_bar.last_print_t = None
    progress_bar.total = None
    progress_

# Generated at 2022-06-22 05:34:26.169162
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pbar = tqdm_rich(total=3)
    assert(not pbar.disable)
    pbar.close()

# Generated at 2022-06-22 05:34:29.201812
# Unit test for function trange
def test_trange():  # pragma: no cover
    warn("rich is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    with trange(10) as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:34:39.570031
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    temp_task = Progress.Task()
    temp_task.completed = 1234.567
    temp_task.total = 23456.789
    assert FractionColumn().render(temp_task) == Text(
        '0.52/23.46 K', style='progress.download')
    assert FractionColumn(unit_scale=True).render(temp_task) == Text(
        '0.52/23.46 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(temp_task) == Text(
        '0.49/22.29 K', style='progress.download')

# Generated at 2022-06-22 05:34:42.613133
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fc.render('a') == Text("0.0/0.0", style="progress.download")

# Generated at 2022-06-22 05:34:53.598665
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import BarColumn
    from rich.progress import Progress
    from rich.progress import RateColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize

    def pick_unit_and_suffix(total, suffixes, divisor):
        unit, suffix = filesize.pick_unit_and_suffix(
            total, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], divisor,
        )

        return unit, suffix

    setattr(filesize, 'pick_unit_and_suffix', pick_unit_and_suffix)

    task = tqdm_rich(total=1000, unit_scale=False, unit_divisor=1000)
    task.set_

# Generated at 2022-06-22 05:35:13.211734
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    _test_RateColumn_render_helper(
        completed=1, total=1, speed=1,
        unit="", unit_scale=False, unit_divisor=1000,
        output="1.0 /s"
    )
    _test_RateColumn_render_helper(
        completed=0.1, total=1, speed=1,
        unit="", unit_scale=False, unit_divisor=1000,
        output="1.0 /s"
    )
    _test_RateColumn_render_helper(
        completed=1, total=1, speed=10,
        unit="", unit_scale=False, unit_divisor=1000,
        output="10.0 /s"
    )

# Generated at 2022-06-22 05:35:22.121214
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for constructor of class RateColumn."""
    column = RateColumn()
    column.unit = 'k'
    column.unit_scale = False
    column.unit_divisor = 1000
    task = tqdm_rich(total=4, desc='Download', unit_scale=True, unit_divisor=1000)
    task.n = 1
    task.update(n=1)
    task.n = 2
    task.update(n=2)
    task.n = 3
    task.update(n=3)
    task.n = 4
    task.update(n=4)
    task.close()

# Generated at 2022-06-22 05:35:30.359485
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import BarColumn, TimeRemainingColumn
    from rich.progress import TimeElapsedColumn

    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]")

    with progress:
        task = progress.add_task("Task", total=100)
        for count in _range(0, 100):
            progress.update(task, completed=count)
            progress.reset(total=100)

# Generated at 2022-06-22 05:35:32.327046
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test the constructor of the FractionColumn class."""
    column = FractionColumn()


# Generated at 2022-06-22 05:35:38.867245
# Unit test for constructor of class RateColumn
def test_RateColumn():
    unit = 'Mb'
    unit_scale = True
    unit_divisor = 1024
    speed = 500
    expected_output = "0 Mb/s"
    output = RateColumn(unit=unit, unit_scale=unit_scale,
                        unit_divisor=unit_divisor).render(speed=speed)
    assert output == expected_output

# Generated at 2022-06-22 05:35:49.645481
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Example: tqdm_rich(total=100, desc="Loading", ascii=True,
                        progress=(
                        '[progress.description]{task.description}'
                        '[progress.percentage]{task.percentage:>4.0f}%',
                        BarColumn(bar_width=None),
                        FractionColumn(unit_scale=False, unit_divisor=1000),
                        '[', TimeElapsedColumn(), '<', TimeRemainingColumn(),
                        ',', RateColumn(unit='B', unit_scale=False, unit_divisor=1000), ']'
                        )); cf. https://github.com/casperdcl/rich/blob/master/rich/progress_test.py"""
    # tqdm_rich(total=100, desc="Loading", ascii=True,
    #           progress=(


# Generated at 2022-06-22 05:35:51.426956
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with trange(10) as pbar:
        for _ in pbar:
            pass

# Generated at 2022-06-22 05:35:56.803779
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm as std_tqdm
    from .utils import _range


# Generated at 2022-06-22 05:35:59.324631
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for constructor of `RateColumn`"""
    rate_column = RateColumn()


# Generated at 2022-06-22 05:36:00.881702
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn()
    assert r.render(std_tqdm(total=10)) == "? /s"

# Generated at 2022-06-22 05:36:23.975954
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .utils import _supports_unicode
    _supports_unicode()

    # Test with default args
    with tqdm(total=10) as t:
        assert t.total == 10

    # Test with manual args
    with tqdm(total=10, desc="desc", initial=5) as t:
        assert t.total == 10
        assert t.n == 5
        assert t.desc == "desc"
        assert "'desc':" in repr(t)

    # Test with time unit conversion
    with tqdm(total=10, unit="s") as t:
        assert t.total == 10
        assert t.unit == "s"
        assert "'unit': 's'" in repr(t)

# Generated at 2022-06-22 05:36:35.158616
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from tqdm.auto import tqdm as auto_tqdm
    from tqdm.gui import tqdm as gui_tqdm
    # Instantiate any tqdm decorator
    tqdm_decor = tqdm
    for kwargs in [dict(), dict(disable=True)]:
        try:
            tqdm_decor(**kwargs).clear()
        except Exception:
            raise
        else:
            # Only work with tqdm_rich
            if not isinstance(tqdm_decor, tqdm_rich):
                continue
            # Only check if disable is True
            if kwargs.get('disable', False) is False:
                continue
            # Check if return code of clear() is the same for auto and gui

# Generated at 2022-06-22 05:36:39.259314
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import pdb
    with pdb.set_trace():
        for i in tqdm_rich(range(100)):
            pass

# Generated at 2022-06-22 05:36:46.504155
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn()
    assert column.render(1) == Text("1 /s", style="progress.data.speed")
    column = RateColumn(unit="/s")
    assert column.render(1) == Text("1 /s/s", style="progress.data.speed")
    column = RateColumn(unit_scale=True)
    _, suffix = filesize.pick_unit_and_suffix(1000)
    assert column.render(1000) == Text(f"1.00 {suffix}/s", style="progress.data.speed")

# Generated at 2022-06-22 05:36:47.564974
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="B")

# Generated at 2022-06-22 05:36:49.244187
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    a = tqdm(total=50)
    for i in range(10):
        a.update(2)
    a.close()

# Generated at 2022-06-22 05:36:50.683132
# Unit test for function trange
def test_trange():
    """Test function trange."""
    sum_ = 0
    for _ in trange(10):
        sum_ += 1
    assert sum_ == 10

# Generated at 2022-06-22 05:37:02.491334
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from .gui import tgrange

# Generated at 2022-06-22 05:37:11.407205
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import sys
    import time
    with tqdm(total=5, leave=False) as pbar:
        for i in range(5):
            pbar.update()
            time.sleep(1)
    print("\n")
    with tqdm(total=5, leave=False, unit='B') as pbar:
        for i in range(5):
            pbar.update()
            time.sleep(1)


if __name__ == '__main__':
    test_tqdm_rich_display()

# Generated at 2022-06-22 05:37:20.478855
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test of class tqdm_rich"""
    with tqdm_rich(total=10) as pbar:  # total=10 is optional
        assert pbar.total == 10
        assert pbar.n == 0
        assert not pbar.disable
        assert pbar.desc == ""
        pbar.set_description("Testing...")
        assert pbar.desc == "Testing..."

        for _ in pbar:
            pbar.update()
            assert pbar.n == 1

# Generated at 2022-06-22 05:37:37.866488
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Unit test for class tqdm_rich."""
    with tqdm_rich(total=10) as pbar:
        for _ in pbar:
            pbar.update()

# Generated at 2022-06-22 05:37:41.939633
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    rng = tqdm_rich(total=100)
    for i in _range(100):
        rng.update(1)
    rng.clear()
    rng.close()

# Generated at 2022-06-22 05:37:45.616434
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys; sys.modules['rich'] = None
    try:
        tqdm.display()
    except TypeError:
        # trying to call display() of class tqdm_rich when rich is missing
        pass
    else:
        # found the rich module
        raise
    del sys.modules['rich']
    with tqdm.display() as progress:
        progress.update(1)

# Generated at 2022-06-22 05:37:51.501887
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Unit test for constructor of class RateColumn
    mock_task = dict()
    mock_task['speed'] = 10
    ratecolumn = RateColumn(unit="M", unit_scale=True, unit_divisor=1024)
    ratecolumn.render(mock_task)

    mock_task['speed'] = None
    ratecolumn.render(mock_task)


if __name__ == '__main__':
    test_RateColumn()

# Generated at 2022-06-22 05:37:57.161260
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import TimeRemainingColumn
    from random import random

    class MyProgress(Progress):
        columns = [
                "[progress.description]{task.description}",
                BarColumn(bar_width=None),
                "[", TimeRemainingColumn(), "]"
        ]
    prog = MyProgress()
    with prog:
        task_id = prog.add_task("Task1", total=5)
        prog.update(task_id, completed=2)
        prog.reset(task_id, total=10)
        prog.update(task_id, completed=random()*10)

# Generated at 2022-06-22 05:38:00.033114
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    '''
    >>> f = FractionColumn()
    >>> f.render(ProgressColumn(total = 3, completed = 1))
    '0.3/3'
    '''
    pass

# Generated at 2022-06-22 05:38:03.355275
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test render function of class RateColumn
    """
    class Task:
        speed = 123456789
    rc = RateColumn()
    assert rc.render(Task()) == Text("117.7 MB/s", style="progress.data.speed")

# Generated at 2022-06-22 05:38:10.706950
# Unit test for function trange
def test_trange():
    from itertools import permutations

    for _ in trange(7, desc='1st loop'):
        for _ in trange(5, desc='2nd loop', leave=True):
            for _ in trrange(3, desc='3nd loop'):
                for _ in trange(2, desc='4th loop'):
                    for _ in trange(1, desc='5th loop'):
                        pass
    for _ in trange(sum(len(p) for p in permutations('123'))):
        pass

# Generated at 2022-06-22 05:38:11.592110
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-22 05:38:13.917848
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test = RateColumn()
    val = test.render(None)
    assert val == Text('? /s', style='progress.data.speed')

# Generated at 2022-06-22 05:38:45.257487
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-22 05:38:46.715353
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn()
    assert r


# Generated at 2022-06-22 05:38:49.787942
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest.mock import patch
    with patch('rich.progress.Progress.__exit__') as mock:
        tqdm_rich(range(0)).close()
    assert mock.called

# Generated at 2022-06-22 05:39:01.598967
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    task = MagicMock()
    a = tqdm_rich(total=10)
    a._prog = Progress('[progress.description]{task.description}{task.percentage:>4.0f}%')
    a._task_id = a._prog.add_task(a.desc or "", **a.format_dict)
    a._prog.update = MagicMock(wraps=a._prog.update)
    a.display()
    assert a._prog.update.call_count == 0

    a._prog.update = MagicMock(wraps=a._prog.update)
    a.desc = "a"


# Generated at 2022-06-22 05:39:03.236793
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="GB")

# Generated at 2022-06-22 05:39:10.082816
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    with Progress() as p:
        b = p.add_task("A", total=100)
        c = p.add_task("B", total=100)
        p.update(b, completed=20)
        p.update(c, completed=20)
        p.reset(b)
        p.reset(c)
        assert p.tasks[b].completed == 0, "Reset completed"
        assert p.tasks[c].completed == 0, "Reset completed"

# Generated at 2022-06-22 05:39:12.203813
# Unit test for constructor of class RateColumn
def test_RateColumn():
    pass

# Unit test of function trange

# Generated at 2022-06-22 05:39:14.344742
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn(unit="Mb")
    r.render(Progress(completed=3, total=5))

# Generated at 2022-06-22 05:39:26.664665
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from .tqdm import tqdm
    from rich.progress import TaskID
    from .tqdm_gui import tgrange

    # Test unit = 1 
    with tqdm(range(1000), desc='test 1000 elements', unit='B', unit_scale=False) as t:
        taskid = TaskID(t._task_id)
        f = FractionColumn()
        f._progress = t._prog
        f.render(taskid)

    # Test unit = 8
    with tqdm(range(1000), desc='test 1000 elements', unit='B', unit_scale=True) as t:
        taskid = TaskID(t._task_id)
        f = FractionColumn()
        f._progress = t._prog
        f.render(taskid)

    # Test unit = 300

# Generated at 2022-06-22 05:39:30.026002
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=2) as pbar:
        pbar.clear()

# Generated at 2022-06-22 05:41:33.884093
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn() # test case 1
    assert(fc.unit_scale==False)
    assert(fc.unit_divisor==1000)
    fc = FractionColumn(True, 1024) # test case 2
    assert(fc.unit_scale==True)
    assert(fc.unit_divisor==1024)


# Generated at 2022-06-22 05:41:43.553295
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    for total in [100, 1000, 10000]:
        for unit_scale in [False, True]:
            for unit_divisor in [1, 1000]:
                with tqdm_rich(total=total, unit_scale=unit_scale,
                               unit_divisor=unit_divisor) as progress_bar:
                    progress_bar.reset(total=total*2)
                    for _ in progress_bar:
                        pass
                    sys.stdout.write("\n")

# Generated at 2022-06-22 05:41:52.833090
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn
    """
    column = RateColumn(unit="K", unit_scale=True, unit_divisor=1000)
    task = column.render(100)
    assert task.text == "? K/s"
    task = column.render(1000)
    assert task.text == "1.0 K/s"
    task = column.render(10000)
    assert task.text == "10.0 K/s"
    task = column.render(12345)
    assert task.text == "12.3 K/s"


# Generated at 2022-06-22 05:42:02.728643
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    RateColumn.render()

    unit_scale取值为False时，如下：
    >>> RateColumn(unit_scale=False, unit_divisor=1000).render(task)
    '40000 B/s'

    unit_scale取值为True时
    >>> RateColumn(unit_scale=True, unit_divisor=1000).render(task)
    '39.1 K/s'
    """
    task = type('task', (), {'speed': 40000})()
    # 这个方法的返回值是text
    assert RateColumn(unit_scale=False, unit_divisor=1000).render(task) == '40000 B/s'

# Generated at 2022-06-22 05:42:09.754796
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(Progress.Task(completed=3, total=2)) == \
           Text("3.0/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(Progress.Task(completed=3, total=1000000)) == \
           Text("0.0/1.0 M", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress.Task(completed=3, total=1000000)) == \
           Text("0.0/0.976 M", style="progress.download")



# Generated at 2022-06-22 05:42:14.553653
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn(unit="b", unit_scale=True)
    total = int(1)
    unit, suffix = filesize.pick_unit_and_suffix(
                total,
                ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
                1024,
            )
    assert(suffix == "")

test_RateColumn()

# Generated at 2022-06-22 05:42:25.984028
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Unit tests for the `FractionColumn.render()` method.
    """
    fraction_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fraction_column.render({"task": {"completed": 2, "total": 5}}) == "2/5"
    assert fraction_column.render({"task": {"completed": 0, "total": 0}}) == "0/0"
    assert fraction_column.render({"task": {"completed": 0.01, "total": 0.11}}) == "0.0/0.1"
    assert fraction_column.render({"task": {"completed": 29.9, "total": 29.9}}) == "29.9/29.9"

# Generated at 2022-06-22 05:42:30.852674
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=10) as pbar:
        pbar.update(4)
        pbar.reset(total=5)
        pbar.update(1)
        pbar.reset()
        pbar.update(1)
        assert pbar.n == 1  # pbar.n == pbar.total == 1

# Generated at 2022-06-22 05:42:32.545478
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # FIXME: Find a way to test rich output
    tqdm_rich()

# Generated at 2022-06-22 05:42:35.615318
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # pass
    x = tqdm_rich(iterable=range(100))
    x.clear()
