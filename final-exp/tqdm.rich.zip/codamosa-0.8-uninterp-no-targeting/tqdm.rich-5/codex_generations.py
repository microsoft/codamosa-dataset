

# Generated at 2022-06-22 05:33:03.844637
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.display()
            time.sleep(0.05)

# Generated at 2022-06-22 05:33:09.199732
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(total=10)
    pbar.reset()

    pbar.reset(total=20)
    for i in range(20):
        pbar.update()

    pbar.reset(total=5)
    for i in range(5):
        pbar.update()

# Generated at 2022-06-22 05:33:10.269792
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    FractionColumn(True, 1000)



# Generated at 2022-06-22 05:33:22.392139
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_cases = [
        (None, "? b/s"),
        (0, "0 b/s"),
        (1, "1 b/s"),
        (1000, "1K b/s"),
        (1000000, "1M b/s"),
        (1000000000, "1G b/s"),
        (1000000000000, "1T b/s"),
        (1000000000000000, "1P b/s"),
        (1000000000000000000, "1E b/s"),
        (1000000000000000000000, "1Z b/s"),
        (1000000000000000000000000, "1Y b/s"),
    ]
    for test_case, result_string in test_cases:
        result = RateColumn.render(ProgressColumn, test_case)
        assert result.text == result_string



# Generated at 2022-06-22 05:33:32.164973
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(
        object()
    ) == Text(value="? /s", style="progress.data.speed")
    assert RateColumn().render(
        object()
    ) == Text(value="? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(
        object()
    ) == Text(value="? B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True, unit_divisor=1000).render(
        object()
    ) == Text(value="? /s", style="progress.data.speed")
    assert RateColumn(unit_scale=True, unit_divisor=1024).render(
        object()
    ) == Text(value="? /s", style="progress.data.speed")



# Generated at 2022-06-22 05:33:36.837868
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    a = FractionColumn()
    assert a.render(Progress(total=10)) == Text('0.0/10.0 ', style='progress.download')

# Generated at 2022-06-22 05:33:40.527557
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(std_tqdm(desc='foo', total=2**30)) == Text('8K/2G ')

# Generated at 2022-06-22 05:33:41.968753
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich.clear(_)


# Generated at 2022-06-22 05:33:44.777798
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():

    t = tqdm(range(100), desc='bar')
    for _ in range(100):
        t.update()
    t.close()

# Generated at 2022-06-22 05:33:46.933068
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.unit_scale is False
    assert fc.unit_divisor == 1000


# Generated at 2022-06-22 05:34:02.824987
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn"""
    import pytest
    task = ProgressColumn()
    task.completed = 1
    task.total = 2
    column = FractionColumn()
    result = column.render(task)
    assert result.text == "0.5/2.0 "

    column = FractionColumn(unit_scale=True)
    result = column.render(task)
    assert result.text == "0.5/2.0 K"

    column = FractionColumn(unit_scale=True, unit_divisor=1024)
    result = column.render(task)
    assert result.text == "0.4/1.9 K"

    column = FractionColumn(unit_scale=False, unit_divisor=1024)
    result = column.render(task)

# Generated at 2022-06-22 05:34:09.106186
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display method."""
    # Setup tqdm object
    t = tqdm_rich(0, 50, disable=False,
                  leave=False,
                  desc='Test',
                  dynamic_ncols=False)
    t.display()
    # Setup return values for mock_task.update
    progress = t._prog._tasks[t._task_id]
    progress.completed = []
    progress.description = []
    # Start testing tqdm_rich.display
    for i in range(50):
        t.update(1)
        t.display()
        # Test if tqdm_rich.display updates the correct value
        assert progress.completed[i] == i + 1
        assert progress.description[i] == 'Test'
    # Cleanup

# Generated at 2022-06-22 05:34:15.776183
# Unit test for constructor of class RateColumn
def test_RateColumn():
    test_column = RateColumn()
    assert test_column.unit == ''
    assert test_column.unit_scale == False
    assert test_column.unit_divisor == 1000
    assert test_column.precision == 2

    test_column2 = RateColumn(unit='B')
    assert test_column2.unit == 'B'
    assert test_column2.unit_scale == False
    assert test_column2.unit_divisor == 1000
    assert test_column2.precision == 2

    test_column3 = RateColumn(unit='Bytes', unit_scale=True, unit_divisor=1024)
    assert test_column3.unit == 'Bytes'
    assert test_column3.unit_scale == True
    assert test_column3.unit_divisor == 1024

# Generated at 2022-06-22 05:34:18.968756
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    progress = ('a {task.description} b', 'c', 'd', 'e')
    t = tqdm_rich(iterable=xrange(3), progress=progress)
    assert t._prog is not None

# Generated at 2022-06-22 05:34:22.605717
# Unit test for function trange
def test_trange():
    from time import sleep
    for i in trange(3):
        sleep(1/10)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 05:34:27.209211
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    tests tqdm_rich.close()
    """
    t = tqdm_rich(_range(0, 10), desc="tqdm_rich_close")
    assert t.disable == False
    for _ in t:
        pass
    t.close()
    assert t.disable == True

# Generated at 2022-06-22 05:34:38.934067
# Unit test for function trange
def test_trange():  # pragma: no cover
    from re import search
    from time import sleep
    from unittest import TestCase

    class TestTrange(TestCase):
        def testFormat(self):
            with trange(10) as trange_inst:
                for i in trange_inst:
                    sleep(1e-5)
            self.assertEqual(trange_inst.last_print_n, 10)

        def testPosition(self):
            with trange(5, 5) as t:
                for i in t:
                    t.set_description("test")
                    sleep(1e-3)
            self.assertTrue(search('test', t.last_print_str))
            self.assertEqual(t.last_print_n, 5)

    TestTrange().testFormat()
    TestTrange().test

# Generated at 2022-06-22 05:34:46.176714
# Unit test for function trange
def test_trange():
    """Run `trange` and perform unit test on it."""
    from .std import format_sizeof
    trange(10)
    trange(10, desc="test_trange")
    pbar = tqdm_rich(ascii=True)
    for i in trange(10, desc="test_trange(loop)", ascii=True):
        pbar.update()
    trange(10, desc="test_trange(inner)", ascii=True, position=0)
    trange(10, desc="test_trange(outer)", ascii=True, position=1)

# Generated at 2022-06-22 05:34:51.426321
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for method in [tqdm, trange]:
        with method(5) as t:        # default tqdm
            assert t.n == 0
            t.clear()
            assert t.n == 0
        with method(5, disable=True):
            assert t.n == 0
            t.clear()
            assert t.n == 0

# Generated at 2022-06-22 05:34:52.731369
# Unit test for function trange
def test_trange():
    try:
        import rich
    except ImportError:
        pass

# Generated at 2022-06-22 05:34:59.334836
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10) as t:
        for i in t:
            if i == 5:
                t.reset(total=20)
            t.update()

# Generated at 2022-06-22 05:35:09.612016
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """This function is used for testing method render"""
    # set up initial
    progress = tqdm_rich(total=10)
    progress.update(completed=5)
    progress.total=10
    # test for render
    col0 = FractionColumn(unit_scale=False)
    assert col0.render(progress) == Text(
        "5.0/10  ", style="progress.download")
    col1 = FractionColumn(unit_scale=True)
    assert col1.render(progress) == Text(
        "5.0/10  ", style="progress.download")


# Generated at 2022-06-22 05:35:11.804589
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    p = tqdm_rich(10)
    p.display()

# Generated at 2022-06-22 05:35:21.864788
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Unit test for `tqdm_rich.__init__()`

    Tested on Python 3.5 and 3.5-dev
    """
    # Tested parameters on [0, 4]

# Generated at 2022-06-22 05:35:33.485682
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    This is a unit test for method render of class RateColumn,
    With different kinds of parameters, we can see that its
    output is correct.
    """
    column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert column.render("task") == "? /s"

    column = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    assert column.render("task") == "? /s"

    column = RateColumn(unit="", unit_scale=True, unit_divisor=1024)
    assert column.render("task") == "? /s"

    column = RateColumn(unit="kB ", unit_scale=True, unit_divisor=1000)
    assert column.render("task") == "? kB /s"



# Generated at 2022-06-22 05:35:45.122911
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for FractionColumn.render()."""
    completed = int(100)
    total = int(145)
    unit, suffix = filesize.pick_unit_and_suffix(
        total,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        1000,
    )
    precision = 0 if unit == 1 else 1
    assert (
        FractionColumn(
            unit_scale=True, unit_divisor=1000
        ).render(
            completed=100, total=145
        )
        == Text(
            f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}",
            style="progress.download")
    )



# Generated at 2022-06-22 05:35:47.290120
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    fc.render(tqdm(total=1, desc="test_FractionColumn"))

# Generated at 2022-06-22 05:35:51.381526
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm._utils import _term_move_up
    from tqdm._monitor import _fp_write
    with _term_move_up():
        with _fp_write(desc="test", leave=False):
            tqdm_test = tqdm_rich(total=10)
            for i in tqdm_test:
                tqdm_test.display()

# Generated at 2022-06-22 05:36:03.484767
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests_tqdm import pretest_posttest  # NOQA
    from .tests_tqdm import _io as io  # NOQA

    with pretest_posttest(suppress_stdout=False):
        for total in [10, 100, 1024, 8192]:
            for unit in ["", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi", "Yi"]:
                with tqdm_rich(unit=unit, unit_scale=True, total=total,
                               file=io.StringIO()) as progress:
                    assert progress.unit_scale == True
                    assert progress.unit_divisor == 1024
                    assert progress.unit == unit
                    assert progress.total == int(total)
                    while progress.n < progress.total:
                        progress.update

# Generated at 2022-06-22 05:36:06.305778
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn()
    assert "? ?/s" == column.render(std_tqdm())
    return column



# Generated at 2022-06-22 05:36:24.156006
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import time
    import sys
    try:
        import pytest
    except ImportError:
        return pytest.skip("pytest required for this test.")

    from .utils import FormatMixin  # noqa, pylint: disable=import-outside-toplevel
    from .std import tqdm as std_tqdm  # noqa, pylint: disable=import-outside-toplevel
    from .std import tqdm_gui  # noqa, pylint: disable=import-outside-toplevel

    for cls in [tqdm, tqdm_rich]:
        class Test(FormatMixin):
            """Same tests as for tqdm_gui, but different output."""
            # pylint: disable=arguments-differ,too-many-ancestors

# Generated at 2022-06-22 05:36:30.994826
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Check if tqdm_rich.reset() updates the progress"""
    from tqdm.auto import trange
    from time import sleep

    for _ in tqdm_rich(range(10)):
        sleep(0.01)

    for _ in trange(10, desc='1st loop'):
        sleep(0.01)

    for _ in trange(10, desc='2nd loop'):
        sleep(0.01)



# Generated at 2022-06-22 05:36:40.126829
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.progress import DEFAULT_BAR_STYLES
    # do not show progress
    with tqdm() as t:
        t.update(2)
    # create with progress
    with tqdm(total=100, desc="example") as t:
        t.update(2)
    # format backslash n
    with tqdm(desc="test\n") as t:
        assert t.format_dict['desc'] == "test"
    # format backslash n
    with tqdm(desc="test\n\n") as t:
        assert t.format_dict['desc'] == "test"
        assert t.format_dict['desc2'] == ""
    # format backslash n

# Generated at 2022-06-22 05:36:48.867317
# Unit test for constructor of class FractionColumn

# Generated at 2022-06-22 05:36:57.388396
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from io import StringIO
    from rich.console import Console
    from rich.padding import Padding, pad_left
    from rich.table import Table, TableOptions
    import rich.progress as rich
    from tqdm.rich import RateColumn

    table = Table(show_header=False, show_edge=True, title="Title")
    table.add_column("Column #1", style="class:table.column.header")
    table.add_column("Column #2", style="class:table.column.header")

    table.add_row("First cell", "Second Cell")
    table.add_row("First cell", "Second Cell")

    # Use default table options
    table.options = TableOptions()

    # Change table options
    table.options.padding_left = 0
    table.options.padding_right = 0
   

# Generated at 2022-06-22 05:37:06.685617
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = type('task', (), {'completed': 1000, 'total': 2000})()
    assert FractionColumn().render(task) == Text(
        '1.0/2.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text(
        '1.0/2.0 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text(
        '0.9/1.9 Ki', style='progress.download')



# Generated at 2022-06-22 05:37:07.444276
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-22 05:37:10.592574
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn()
    assert r.unit == ""
    assert r.unit_scale is False
    assert r.unit_divisor == 1000


# Generated at 2022-06-22 05:37:11.933192
# Unit test for function trange
def test_trange():
    list(trange(10))  # pragma: no cover

# Generated at 2022-06-22 05:37:15.859850
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as progress_bar:
        for i in progress_bar:
            progress_bar.update(i)


if __name__ == "__main__":
    test_tqdm_rich_close()

# Generated at 2022-06-22 05:37:37.700978
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    fake_task = type('task', (object,), {'speed': 1337.4, 'total': 0})()
    assert RateColumn(unit='kb', unit_scale=True).render(fake_task) == '1.3 Mkb/s'

    fake_task = type('task', (object,), {'speed': 1337.4, 'total': 0})()
    assert RateColumn(unit='kb', unit_scale=False).render(fake_task) == '1337.4 kb/s'

# Generated at 2022-06-22 05:37:45.455354
# Unit test for constructor of class RateColumn
def test_RateColumn():
    c = RateColumn()
    assert c.unit == "", "default unit must be empty"
    assert c.unit_scale is False, "default unit_scale must be False"
    assert c.unit_divisor == 1000, "default unit_divisor must be 1000"
    c = RateColumn(unit="/s", unit_scale=True, unit_divisor=1024)
    assert c.unit == "/s", "unit must be /s"
    assert c.unit_scale is True, "unit_scale must be True"
    assert c.unit_divisor == 1024, "unit_divisor must be 1024"

# Generated at 2022-06-22 05:37:53.281415
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # happy path
    assert str(FractionColumn()) == '0/0'
    assert str(FractionColumn(unit_scale=True, unit_divisor=1000)) == '0/0'
    assert str(FractionColumn(unit_scale=True)) == '0.0/0.0'
    assert str(FractionColumn(unit_divisor=1000)) == '0/0'

    # unhappy path
    try:
        FractionColumn(unit_scale=True, unit_divisor=0)
        assert False
    except ZeroDivisionError:
        pass


# Generated at 2022-06-22 05:37:59.370268
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress as _Progress
    d = tqdm_rich(total=10)
    d._prog = _Progress()
    d._prog.add_task = lambda *args, **kwargs: ...  # noqa: E731
    d.display()
test_tqdm_rich_display()

# Generated at 2022-06-22 05:38:04.831198
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import gc
    t = tqdm_rich(total=100)
    t.close()
    del t
    gc.collect()


test_tqdm_rich_display()

# Generated at 2022-06-22 05:38:15.126527
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn().render(Progress._Task("", 0, 0)) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="bit").render(Progress._Task("", 0, 0)) == Text("? bit/s", style="progress.data.speed")
    assert RateColumn(unit="bit", unit_scale = True, unit_divisor = 1024).render(Progress._Task("", 0, 0)) == Text("? bit/s", style="progress.data.speed")
    assert RateColumn().render(Progress._Task("", 0, 1)) == Text("0.0 /s", style="progress.data.speed")
    assert RateColumn(unit="bit").render(Progress._Task("", 0, 1)) == Text("0.0 bit/s", style="progress.data.speed")
    task = Progress._Task

# Generated at 2022-06-22 05:38:17.858672
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    assert tqdm_rich().disable


# Generated at 2022-06-22 05:38:21.876586
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    for i in tqdm_rich(range(2)):
        pass
    for i in tqdm_rich(range(4)):
        pass
    for i in tqdm_rich(range(5)):
        pass
    for i in tqdm_rich(range(8)):
        pass

# Generated at 2022-06-22 05:38:30.357062
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(total=123456789, completed=1)).width == 14
    assert FractionColumn().render(Progress(total=123456789, completed=1)).content == "0.0/123.5 M"
    assert FractionColumn().render(Progress(total=123456789, completed=12)).width == 14
    assert FractionColumn().render(Progress(total=123456789, completed=12)).content == "0.0/123.5 M"
    assert FractionColumn().render(Progress(total=123456789, completed=123)).content == "0.1/123.5 M"
    assert FractionColumn().render(Progress(total=123456789, completed=1234)).content == "1.2/123.5 M"

# Generated at 2022-06-22 05:38:36.184769
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    _console = Console()
    tqdm_rich(
        range(5),
        progress=(
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"),
        console=_console,
    )

# Generated at 2022-06-22 05:39:10.650465
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for _ in tqdm_rich(range(2)):
        pass


# Generated at 2022-06-22 05:39:19.833034
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import time
    import gc
    # test default constructor
    with tqdm(total=10) as t:
        assert len(t) == 10
        for i in range(10):
            time.sleep(0.01)
            t.update()
    assert t.n == 10
    assert t.total == 10
    assert not t.disable
    assert not t.leave
    # test close
    t.close()
    t.disable = True
    t.close()
    assert t.disable
    assert t.n == t.total



# Generated at 2022-06-22 05:39:31.276843
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(std_tqdm(found_expected_files=0, total=3,
                                        unit='files', unit_scale=True,
                                        unit_divisor=1024)).value == "0.0 files/s"
    assert RateColumn().render(std_tqdm(found_expected_files=1, total=3,
                                        unit='files', unit_scale=True,
                                        unit_divisor=1024)).value == "0.0 files/s"
    assert RateColumn().render(std_tqdm(found_expected_files=2, total=3,
                                        unit='files', unit_scale=True,
                                        unit_divisor=1024)).value == "0.0 files/s"

# Generated at 2022-06-22 05:39:32.359581
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    >>> t1 = tqdm_rich(["red", "blue", "green"])
    >>> display(t1)
    """
    pass

# Generated at 2022-06-22 05:39:41.475202
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import copy
    import inspect
    import collections
    import unittest

    TestCase = unittest.TestCase

    def closure(tqdm_func, *args, **kwargs):
        """
        A helper function to test the tqdm_rich display method
        in different contexts
        """
        unit = kwargs.get('unit', '')
        total = kwargs.get('total', 10)
        # Expected output
        # 'desc: 1/10 unit (10%) |####                             | Elapsed: 0:00:00 Left: 0:00:01, 0.01 unit/s'
        expected_header_str = 'desc: 1/{} {} (10%) |####                             | Elapsed: 0:00:00 Left: 0:00:01, 0.01 {}/s'.format

# Generated at 2022-06-22 05:39:48.448771
# Unit test for function trange
def test_trange():
    from time import sleep

    widget = trange(10)
    for i in widget:
        assert isinstance(widget.format_dict['n'], int)
        assert isinstance(widget.format_dict['total'], int)
        assert widget.format_dict['n'] <= widget.format_dict['total']
        sleep(0.01)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 05:39:55.667897
# Unit test for function trange
def test_trange():
    """Test `trange` function."""
    # Ensure that tqdm and trange are aliases
    assert tqdm is tqdm_rich
    assert trange is trrange

    # Check that trange gives the same output as range
    assert list(trange(5)) == list(range(5))

    with trange(5) as t:
        for i in t:
            t.set_postfix(ordered_dict='is a test', string='string')
            # Do something slow
            [i ** i for i in range(100)]

# Generated at 2022-06-22 05:39:58.819856
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .tests import pretest_empty
    with tqdm(unit="B", unit_scale=True, miniters=1,
              file=pretest_empty) as t:
        t.update()
        t.close()

# Generated at 2022-06-22 05:40:01.160640
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from math import ceil
    from random import random
    import time

    total = 10000
    with tqdm_rich(total=total) as t:
        for i in range(total):
            time.sleep(random() / 100)
            t.reset()
            t.n = ceil(random() * total)

# Generated at 2022-06-22 05:40:05.836359
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich.


    This test is to check that the method clear of class tqdm_rich
    does not raise any exception.
    """

    with tqdm_rich(total=10) as t:
        t.clear()

# Generated at 2022-06-22 05:41:38.931018
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    class tqdm_rich_mock(tqdm_rich):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.cleared = 0
        def clear(self, *_, **__):
            self.cleared = self.cleared + 1

# Generated at 2022-06-22 05:41:44.551771
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    total = 10
    unit = "G"
    suffix = "M"

    frac_col = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert frac_col.unit_scale == False
    assert frac_col.unit_divisor == 1000

    frac_col = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert frac_col.unit_scale == True
    assert frac_col.unit_divisor == 1000


# Generated at 2022-06-22 05:41:49.473583
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10, 0, -1) as t:
        for i in t:
            assert i == t.n
            t.reset(total=1)
            assert t.total == 1
    assert t.total == 1

# Generated at 2022-06-22 05:41:59.954181
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Testing tqdm_rich class constructor."""
    from io import StringIO

# Generated at 2022-06-22 05:42:04.664460
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """return the data rate."""
    t = tqdm_rich(0, unit_scale=True, unit_divisor=1000)
    t.reset()
    r = RateColumn("byte")
    assert r.render(t) == "\u001b[38;5;239m? byte/s\u001b[0m"

# Generated at 2022-06-22 05:42:07.827304
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from itertools import count
    for _ in tqdm_rich(count()):
        tqdm_rich.reset(total=10)
        for _ in tqdm_rich(count(), total=10):
            tqdm_rich.reset()
        break

# Generated at 2022-06-22 05:42:10.889553
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        # Test that no exception is raised
        tqdm_rich(range(10)).close()
    except Exception:
        raise AssertionError("Test failed. Exception raised.")


# Generated at 2022-06-22 05:42:17.698580
# Unit test for constructor of class RateColumn
def test_RateColumn():
    c = RateColumn("B")
    assert (c.unit, c.unit_scale, c.unit_divisor) == ("B", False, 1000)
    c = RateColumn("B", unit_scale=True)
    assert (c.unit, c.unit_scale, c.unit_divisor) == ("B", True, 1000)
    c = RateColumn("B", unit_scale=True, unit_divisor=1024)
    assert (c.unit, c.unit_scale, c.unit_divisor) == ("B", True, 1024)



# Generated at 2022-06-22 05:42:19.725593
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = 0
    unit = ""
    unit_scale = False
    unit_divisor = 1000
    RateColumn(unit, unit_scale, unit_divisor).render(task)

# Generated at 2022-06-22 05:42:22.255071
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    for _ in trange(4):
        pass

