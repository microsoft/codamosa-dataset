

# Generated at 2022-06-22 05:33:08.170790
# Unit test for function trange
def test_trange():
    try:
        range
    except NameError:  # pragma: no cover
        from tqdm.tests.py26 import range

    for i in trange(1000, desc='foo', gui=False, mininterval=0.05,
                    smoothing=1, unit_scale=True, unit_divisor=1024):
        assert len(list(range(i))) == i
        if i >= 500:
            break

# Generated at 2022-06-22 05:33:18.553919
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """ Test tqdm_rich.clear - currently a no-op """
    import time
    with tqdm_rich(total=10) as pbar:
        for i in range(5):
            pbar.update(1)
            time.sleep(0.1)
        pbar.clear()
        for i in range(5):
            pbar.update(1)
            time.sleep(0.1)
        pbar.clear()
        pbar.close()
        pbar.display()
        pbar.reset(total=5)
        for i in range(5):
            pbar.update(1)
            time.sleep(0.1)

# Generated at 2022-06-22 05:33:25.302448
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=2) as t:
        assert t.n == 0
        t.update(1)
        assert t.n == 1
        t.reset()
        assert t.n == 0
        t.reset(total=4)
        assert t.total == 4

    t.reset()
    assert t.n == 0
    t.reset(total=4)
    assert t.total == 4
    with tqdm_rich(total=4) as t:
        assert t.total == 4

# Generated at 2022-06-22 05:33:33.443064
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # Silence tqdm_rich display
    import sys
    import os
    fd = os.open(os.devnull, os.O_WRONLY)
    old_stdout = os.dup(sys.stdout.fileno())
    os.dup2(fd, sys.stdout.fileno())
    for i in tqdm_rich(range(10)):
        pass
    os.dup2(old_stdout, 1)
    os.close(fd)
    os.close(old_stdout)

# Generated at 2022-06-22 05:33:42.801680
# Unit test for function trange
def test_trange():
    from .tests import _test_empty, _test_iterable

    # Test with trange
    _test_empty(tqdm_rich, posargs=())
    _test_iterable(tqdm_rich)
    _test_iterable(tqdm_rich, posargs=(1,))
    with tqdm_rich(total=10) as t:
        assert len(t) == 10
        t.update()  # NOQA
        t.close()  # NOQA

    # Test with trange + wrapper()
    _test_iterable(tqdm_rich, posargs=(), kwargs={'wrapper_class': lambda x: x})

# Generated at 2022-06-22 05:33:46.107076
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        for i in tqdm_rich(range(5)):
            pass
    except Exception as e:
        print(e)
    assert isinstance(tqdm_rich(range(5), disable=True), std_tqdm)

# Generated at 2022-06-22 05:33:49.029755
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for constructor of class RateColumn"""
    rate_column = RateColumn('unit', True)
    assert rate_column.unit == 'unit'
    assert rate_column.unit_scale == True


# Generated at 2022-06-22 05:33:54.475838
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import pytest
    with tqdm_rich(100, desc='Test tqdm_rich_display', unit='B',
                   unit_scale=True) as progress:
        progress.display()



# Generated at 2022-06-22 05:34:00.064906
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    x = tqdm_rich("abc", total=10, file=sys.stdout)
    assert hasattr(x, '_prog')
    assert x._prog.started is True
    assert len(x._prog.tasks) == 1
    assert x._task_id == 0



# Generated at 2022-06-22 05:34:01.142150
# Unit test for function trange
def test_trange():
    list(trange(100))

# Generated at 2022-06-22 05:34:17.324708
# Unit test for function trange
def test_trange():
    for _ in trange(4, leave=True):
        pass


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    from .std import get_current_tqdm

    class dummy(tqdm_rich):
        """Dummy class to allow testing of private functions."""
        pass

    get_current_tqdm = dummy()

    # Test set_lock
    try:
        get_current_tqdm.set_lock()
    except NotImplementedError:
        pass
    else:
        raise RuntimeError("Should not be able to set lock for tqdm_rich")

    # Test update()
    for _ in trange(4, leave=True):
        sleep(0.01)
        get_current_tqdm.update()

    # Test

# Generated at 2022-06-22 05:34:18.325099
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-22 05:34:28.127463
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import TaskID
    pbar = tqdm_rich(range(10), description="test1")
    assert TaskID(pbar._task_id) in pbar._prog._tasks
    assert pbar._prog._tasks[TaskID(pbar._task_id)].description == "test1"
    pbar.clear()
    assert TaskID(pbar._task_id) in pbar._prog._tasks
    assert pbar._prog._tasks[TaskID(pbar._task_id)].description == "test1"
    pbar.close()



# Generated at 2022-06-22 05:34:28.666177
# Unit test for constructor of class RateColumn
def test_RateColumn(): assert RateColumn()

# Generated at 2022-06-22 05:34:31.271245
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(_range(10)).clear()
    tqdm_rich(_range(10), disable=True).clear()
    tqdm_rich(_range(10), disable=False).clear()
    tqdm_rich(_range(10), disable=None).clear()

# Generated at 2022-06-22 05:34:33.374400
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10) as t:
        for i in t:
            t.reset(total=i)
            assert t.total == i

# Generated at 2022-06-22 05:34:35.155527
# Unit test for constructor of class RateColumn
def test_RateColumn():
    bar = RateColumn("b")
    assert bar.unit == "b"


# Generated at 2022-06-22 05:34:39.202852
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import time

    def display_func(n):
        with tqdm_rich(total=n) as pbar:
            for i in range(n):
                pbar.update(1)
                time.sleep(0.1)

    try:
        display_func(10)
    except KeyboardInterrupt:
        sys.exit(0)

# Generated at 2022-06-22 05:34:41.420305
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .gui import tgrange
    for i in tgrange(4):
        for _ in tgrange(10**i):
            pass

# Generated at 2022-06-22 05:34:45.056980
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(range(5)) as t:
        for i in t:
            pass
            t.clear()

# Generated at 2022-06-22 05:34:56.051206
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich."""
    from .std import tqdm  # noqa: F811
    from .std import _range
    with tqdm_rich(_range(10), leave=True) as t:
        assert t.n == 0
        t.update()
        t.n = 1
        t.display()
        t.update()
        t.n = 2
        t.display()

# Generated at 2022-06-22 05:35:01.186989
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn()) == "0/0"
    progress = FractionColumn()
    progress.completed = 1000
    progress.total = 2000
    assert str(progress) == "1.0/2.0"
    progress.unit_scale = True
    assert str(progress) == "1.0/2.0"

# Generated at 2022-06-22 05:35:10.026453
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn(unit="B")
    assert column.unit == "B"

if __name__ == "__main__":
    import sys

    def f(it, *a, **kw):
        if it:
            for _ in f(it - 1, *a, **kw):  # pragma: no branch
                yield _

    with trange(10, desc="parent") as t:
        for i in t:
            with trange(10, desc="child {}".format(i), leave=True) as t2:
                for _ in t2:
                    pass

        for _ in f(4):  # nested
            for _ in tqdm(range(10), desc="nested test"):  # pragma: no cover
                pass

    # test autonotebook

# Generated at 2022-06-22 05:35:15.220179
# Unit test for function trange
def test_trange():

    @tqdm_rich.register_instance()
    def foo(x, y=1):
        with trange(x, desc="foo") as t:
            for i in t:
                with trange(y, desc="bar") as t:
                    for j in t:
                        time.sleep(1)
                time.sleep(0.5)
    foo(3, 2)

# Generated at 2022-06-22 05:35:23.294670
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    reload_tqdm = False
    if sys.version_info[0] >= 3:
        import rich
        import rich.progress
        if not hasattr(rich.progress.ProgressColumn, 'render'):
            reload_tqdm = True
    else:
        reload_tqdm = True

    if reload_tqdm:
        from tqdm import tqdm as reloaded_tqdm
        reload(reloaded_tqdm)
        from tqdm import tqdm as reloaded_tqdm
        from tqdm.rich import tqdm as reloaded_tqdm_rich
    else:
        from tqdm.rich import tqdm as reloaded_tqdm_rich

    reloaded_tqdm_rich(total=10)

# Generated at 2022-06-22 05:35:26.953693
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    from tqdm.rich import tqdm_rich
    with tqdm_rich(total=1, file=sys.stderr, leave=False) as t:
        assert t.disable is False

# Generated at 2022-06-22 05:35:39.035130
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    class Task:
        def __init__(self, completed, total, desc, speed=None):
            self.completed = completed
            self.total = total
            self.description = desc
            self.speed = speed
    task = Task(completed=0.5, total=2.3, desc='test_desc')
    column_a = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert column_a.render(task) == Text(
            f"0.5/2.3 ",
            style="progress.download")
    column_b = FractionColumn(unit_scale=False, unit_divisor=1024)
    assert column_b.render(task) == Text(
            f"0.5/2.3 ",
            style="progress.download")

# Generated at 2022-06-22 05:35:41.796454
# Unit test for constructor of class RateColumn
def test_RateColumn():
    print(RateColumn(unit="M", unit_scale=True, unit_divisor=1000))

if __name__ == "__main__":
    test_RateColumn()

# Generated at 2022-06-22 05:35:52.868856
# Unit test for function trange
def test_trange():
    from .std import tqdm
    from .utils import _range
    for _ in trange(9, -1, -1):
        pass
    # check that wrap=False kwarg works
    for _ in trange(9, -1, -1, bar_format="{n}/{total} [{bar}]",
                    wrap=False, dynamic_ncols=True):
        pass
    # check that desc + leave kwargs work
    for _ in trange(9, -1, -1, bar_format="{n}/{total} [{bar}]",
                    desc="test", leave=True, dynamic_ncols=True):
        pass
    # check that unit/unit_scale/unit_divisor kwargs work

# Generated at 2022-06-22 05:36:01.451147
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import mock
    from .contrib.console import TqdmFile

    with mock.patch(
            'tqdm.contrib.concurrent.process_map',
            return_value=[]):
        f = TqdmFile(open(__file__, 'r'))
        g = tqdm_rich(f, total=10)
        g.display()
        f.seek(0)
        g.write('x')
        g.display()
        f.seek(0)
        g.write('y')
        g.display()

# Generated at 2022-06-22 05:36:18.422409
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Basic tests."""
    import time
    import sys
    from tqdm.auto import tqdm

    with tqdm(total=100, desc='msg1', unit='B', unit_scale=True,
              leave=True, mininterval=0.1) as bar:
        for i in _range(10):
            bar.update()
            time.sleep(.1)

    with tqdm(total=100, desc='msg2', unit='B', unit_scale=True,
              leave=False, mininterval=0.01) as bar:
        for i in _range(10):
            bar.update()
            time.sleep(.1)


# Generated at 2022-06-22 05:36:27.489415
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class DummyTask:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    assert str(FractionColumn().render(DummyTask(1, 2))) == '0.5/2.0'
    assert str(FractionColumn().render(DummyTask(52345, 99999))) == '52.3/99.9'
    assert str(FractionColumn().render(DummyTask(52345, 9999999))) == '0.1/10.0'
    assert str(FractionColumn().render(DummyTask(52345, 9999999999))) == '0.0/10.0'


# Generated at 2022-06-22 05:36:33.770133
# Unit test for function trange
def test_trange():
    """Test for trange"""
    with trange(3) as t:
        assert t.miniters == 1
        assert t.unit_scale is False
        assert t.unit_divisor is 1000
        t.update()
        assert t.n == 1
        t.set_description('test')
        t.n = 2
        t.refresh()
        t.close()
        t.reset()

# Generated at 2022-06-22 05:36:41.160222
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Unit test for constructor of class RateColumn.
    """
    assert str(RateColumn(unit="By", unit_scale=True, unit_divisor=1000)) == \
    "RateColumn(unit=\'By\', unit_scale=True, unit_divisor=1000)"


# Generated at 2022-06-22 05:36:49.251868
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test for RateColumn class with different kind of input parameters to speed."""
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(-1) == Text("-1 B/s", style="progress.data.speed")
    assert rate_column.render(0) == Text("0 B/s", style="progress.data.speed")
    assert rate_column.render(1) == Text("1 B/s", style="progress.data.speed")
    assert rate_column.render(9) == Text("9 B/s", style="progress.data.speed")
    assert rate_column.render(10) == Text("9.8 KB/s", style="progress.data.speed")


# Generated at 2022-06-22 05:36:54.177754
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(Progress(total=30000)) == Text(
        f"0.0/30.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(Progress(total=30000)) == Text(
        f"0.0/30.0 K", style="progress.download")


# Generated at 2022-06-22 05:37:05.789276
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale = False, unit_divisor = 1000)
    assert fc.render(1, 1).render() == '1/1'
    assert fc.render(1000, 1000).render() == '1,000/1,000'
    fc = FractionColumn(unit_scale = True, unit_divisor = 1000)
    assert fc.render(1000, 1000).render() == '1.0/1.0 K'
    assert fc.render(10**6, 10**6).render() == '1.0/1.0 M'
    assert fc.render(10**9, 10**9).render() == '1.0/1.0 G'

# Generated at 2022-06-22 05:37:08.807738
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for ``trange``"""
    for _ in trange(4):
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:37:13.676138
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(total=10)
    assert pbar._prog.total == 10
    pbar.reset(total=20)
    assert pbar._prog.total == 20
    # Test progress bar without total
    pbar = tqdm_rich(total=None)
    assert pbar._prog.total == None
    pbar.reset()
    assert pbar._prog.total == None

# Generated at 2022-06-22 05:37:15.910846
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pbar = tqdm_rich(total=100)
    for i in range(100):
        pbar.update()
    pbar.clear()

# Generated at 2022-06-22 05:37:38.205110
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="it")
    assert r.render(None).text == "? it/s"
    import time
    time.sleep(0.1)
    r = RateColumn(unit="it")
    assert r.render(None).text == "? it/s"


# Generated at 2022-06-22 05:37:40.936144
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
        with tqdm(range(5)) as pbar:
            for i in pbar:
                pbar.display()

# Generated at 2022-06-22 05:37:50.757810
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm
    from .utils import FreezableIter
    from .tests_tqdm import pretest_posttest_print
    from functools import partial

    # Test
    with pretest_posttest_print(False):
        for i in tqdm_rich(FreezableIter(range(10)),
                           desc='Test',
                           total=10,
                           leave=True):
            assert i == tqdm(FreezableIter(range(10)),
                             desc='Test',
                             total=10,
                             leave=True).__next__()

        for i in trange(10):
            pass

    with pretest_posttest_print(False):
        tnrange = partial(tqdm, leave=True)

# Generated at 2022-06-22 05:37:52.509191
# Unit test for constructor of class RateColumn
def test_RateColumn():
    columns = RateColumn(unit="B")
    columns.render(task="task")

# Generated at 2022-06-22 05:37:53.676607
# Unit test for constructor of class RateColumn
def test_RateColumn():
    col = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    print(col.render(None))

# Generated at 2022-06-22 05:37:59.563681
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    import sys
    import os
    import subprocess

    # run pytest for this file
    errno = subprocess.call([sys.executable,
                             '-m',
                             'pytest',
                             os.path.realpath(__file__)])
    raise SystemExit(errno)

# Generated at 2022-06-22 05:38:08.252399
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Method `render(task)` of class `RateColumn` works as intended."""
    column = RateColumn()

    class MockTask():
        """Mock task adds `speed` attribute."""
        # pylint: disable=too-few-public-methods
        def __init__(self, speed):
            self.speed = speed

    assert str(column.render(MockTask(speed=0))) == "0.0 B/s"
    assert str(column.render(MockTask(speed=1))) == "1.0 B/s"
    assert str(column.render(MockTask(speed=10))) == "10.0 B/s"
    assert str(column.render(MockTask(speed=100))) == "100.0 B/s"

# Generated at 2022-06-22 05:38:16.286974
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [float(10**i) for i in range(7)]:
        with tqdm_rich(total=total, unit='B',
                       unit_scale=True, unit_divisor=1024) as t:
            t.reset(total=total/2)
            assert t.total == t.final_total == total/2, (
                f"{type(t).__name__}.reset(total={total:.3g}): "
                f"set total={t.total:.3g}, final_total={t.final_total:.3g}")

# Generated at 2022-06-22 05:38:21.013175
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import sys
        import io
        output = io.StringIO()
        sys.stderr = output
        tqdm_rich(range(1), disable=False).clear()
        sys.stderr = sys.__stderr__
    except Exception:
        pass

# Generated at 2022-06-22 05:38:32.902271
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.render({'completed': 10, 'total': 1000}) == Text("0.0/1.0", style="progress.download")
    assert fc.render({'completed': 100.0, 'total': 100.0}) == Text("1.0/1.0", style="progress.download")
    assert fc.render({'completed': "100.0", 'total': "100.0"}) == Text("1.0/1.0", style="progress.download")
    assert fc.render({'completed': "100.0", 'total': "1000.1"}) == Text("0.1/1.0", style="progress.download")

# Generated at 2022-06-22 05:39:38.003279
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .tests import _test_close
    _test_close(lambda: tqdm_rich(total=5, leave=False))


# Generated at 2022-06-22 05:39:39.333933
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(10) as pbar:
        pass
    pbar.clear()

# Generated at 2022-06-22 05:39:41.487265
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Unit test for constructor of class RateColumn.
    """
    
    def test_constructor():
        """ Creates RateColumn object """
        assert RateColumn()

    test_constructor()

# Generated at 2022-06-22 05:39:53.519873
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.render({'completed': 2, 'total': 3}) == Text("2/3", style="progress.download")
    fc = FractionColumn(unit_scale=True)
    assert fc.render({'completed': 2000, 'total': 3000}) == Text("2.0/3.0 K", style="progress.download")
    assert fc.render({'completed': 2, 'total': 1}) == Text("2/1", style="progress.download")
    fc = FractionColumn(unit_scale=True, unit_divisor=2)
    assert fc.render({'completed': 2000, 'total': 3000}) == Text("1.0/1.5 K", style="progress.download")

# Generated at 2022-06-22 05:40:01.180544
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(total=1000)
    task.n = 500
    task.update()
    task.unit = 'G'
    task.unit_scale = False
    task.update()
    uc_fraction = FractionColumn()
    fraction = uc_fraction.render(task)
    assert fraction == Text('500.0/1000.0 ', style='progress.download')
    task.unit_scale = True
    task.unit_divisor = 1024
    task.update()
    uc_fraction = FractionColumn(unit_scale=True, unit_divisor=1024)
    fraction = uc_fraction.render(task)
    assert fraction == Text('0.5/1.0 M', style='progress.download')



# Generated at 2022-06-22 05:40:10.733155
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test when speed/unit < 1
    assert RateColumn(unit='666', unit_scale=True, unit_divisor=1000).render(
        std_tqdm(total=10.0, desc="test", unit="666", initial=0.0,
                 unit_scale=True, unit_divisor=1000)) == Text("0.0 666/s", style="progress.data.speed")
    # Test when speed/unit = 0.9
    assert RateColumn(unit='666', unit_scale=True, unit_divisor=1000).render(
        std_tqdm(total=10.0, desc="test", unit="666", initial=0.9,
                 unit_scale=True, unit_divisor=1000)) == Text("0.9 666/s", style="progress.data.speed")
   

# Generated at 2022-06-22 05:40:18.150626
# Unit test for function trange
def test_trange():
    """Test function trange."""
    assert list(trange(10)) == list(range(10))
    assert list(trange(1, 10)) == list(range(1, 10))
    assert list(trange(1, 10, 3)) == list(range(1, 10, 3))
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))
    assert list(trange(0)) == list(range(0))



# Generated at 2022-06-22 05:40:20.305922
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.console import Console
    console = Console()
    for i in tqdm(range(10)):
        pass
    console.print("Tests complete")

# Generated at 2022-06-22 05:40:22.854285
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10) as progressbar:
        progressbar.clear() # Should not raise an error

# Generated at 2022-06-22 05:40:29.214824
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="iB", unit_scale=True, unit_divisor=1000)
    speed = 1000
    unit = 1
    suffix = "iB"
    precision = 0

    result = rate_column.render(speed)

    assert result.text == f"{speed/unit:,.{precision}f} {suffix}/s"
    assert result.style == "progress.data.speed"

# Generated at 2022-06-22 05:41:35.678302
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """ Test that tqdm_rich.reset works correctly """
    x = tqdm_rich(_range(0,0))
    x.reset()
    assert x.total == 0
    x.reset(10)
    assert x.total == 10

    y = tqdm_rich(_range(0,0))
    y.reset()
    assert y.total == 0
    y.reset(10)
    assert y.total == 10

# Generated at 2022-06-22 05:41:36.588955
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich().close()

# Generated at 2022-06-22 05:41:44.768336
# Unit test for function trange
def test_trange():  # pragma: no cover
    try:
        from unittest.mock import patch
        from itertools import chain
    except ImportError:
        from mock import patch
        from itertools import chain
    from tqdm.auto import tqdm as auto_tqdm


# Generated at 2022-06-22 05:41:50.640750
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .utils import _range
    from .std import tqdm

    for _ in _range(2):
        for _ in tqdm_rich(_range(2), desc="foobar", dynamic_ncols=True):
            tqdm.write("bla bla")
        tqdm.write("\n")

# Generated at 2022-06-22 05:41:56.010917
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep

    for i in tqdm_rich(range(10), total=10):
        sleep(0.1)

    for _ in tqdm_rich(range(10), total=10):
        sleep(0.1)

    for _ in tqdm_rich(range(10), total=10, leave=True):
        sleep(0.1)

# Generated at 2022-06-22 05:41:56.639550
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-22 05:42:03.201613
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    print("\n" + "*" * 50 + "Constructor" + "*" * 50)
    print("Test constructor of class FractionColumn.")
    print("Test __init__()")
    col = FractionColumn()
    print("Col:", col)
    assert col.unit_scale == False
    assert col.unit_divisor == 1000

    col = FractionColumn(unit_scale=True, unit_divisor=1024)
    print("Col:", col)
    assert col.unit_scale == True
    assert col.unit_divisor == 1024

# Generated at 2022-06-22 05:42:05.871699
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # pylint: disable=protected-access
    t = tqdm_rich(total=100)
    t.n = 50
    t.display()
    assert t.n == t._prog.completed

# Generated at 2022-06-22 05:42:09.185566
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn.__doc__ == "Renders completed/total, e.g. '0.5/2.3 G'."


# Generated at 2022-06-22 05:42:10.111093
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass
