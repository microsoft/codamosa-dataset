

# Generated at 2022-06-22 05:33:12.236894
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from tqdm.rich import trange
    for i in trange(4):
        pass

if __name__ == "__main__":  # pragma: no cover
    # Unit test
    # test_FractionColumn_render()
    with tqdm(total=10) as pbar:
        for i in trange(10, desc="Downloading", leave=True):
            pbar.update()

# Generated at 2022-06-22 05:33:23.592937
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import time
    import logging
    import sys
    import pytest

    def log_loop(loops, format="_%(levelname)s_%(message)s", delay=0.1):
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)
        logger.addHandler(logging.StreamHandler(sys.stdout))
        for _ in trange(loops, unit="it", desc="logging {}".format(format)):
            logger.debug(format, extra={"bar_format": "testing"})
            time.sleep(delay)

    with pytest.raises(AttributeError):
        log_loop(3)
    with pytest.raises(AttributeError):
        log_loop(3, "%(asctime)s")

# Generated at 2022-06-22 05:33:30.394643
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Test that the argument of unit_scale must be bool value.
    with pytest.raises(TypeError):
        RateColumn(unit_scale='true')

    # Test that the argument of unit_divisor must be int/float value.
    with pytest.raises(TypeError):
        RateColumn(unit_divisor='1000')

    # Test that the argument of unit must be string.
    with pytest.raises(TypeError):
        RateColumn(unit=1)


# Generated at 2022-06-22 05:33:41.686856
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    console = Console()
    progress = Progress("[progress.description]",
                        "[progress.percentage]{task.percentage:>4.0f}%",
                        BarColumn(bar_width=None),
                        FractionColumn(),
                        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
                        ",", RateColumn(), "]",
                        transient=False, console=console)
    task_id = progress.add_task("Downloading", total=10)
    progress.start()
    sleep(0.3)
    progress.reset(total=15)

# Generated at 2022-06-22 05:33:51.658563
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    d = {
        'task.completed': 0,
        'task.total': 2.3,
    }
    assert FractionColumn().render(d) == Text("0.0/2.3", style="progress.download")
    assert FractionColumn().render(d) != Text("0.0/2.3", style="progress.data.speed")
    d = {
        'task.completed': 0,
        'task.total': 2300,
    }
    assert FractionColumn(True).render(d) == Text("0.0/2.3 K", style="progress.download")
    d = {
        'task.completed': 0,
        'task.total': 2300,
    }

# Generated at 2022-06-22 05:34:03.393146
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich
    except ImportError:
        from nose.exc import SkipTest
        raise SkipTest()
    import io
    import sys
    from collections import defaultdict
    from contextlib import contextmanager

    @contextmanager
    def nostdout():
        # Save the original stdout
        save_stdout = sys.stdout

        # Open new null device and set stdout to it
        devnull = open(os.devnull, 'w')
        sys.stdout = devnull

        # Yield to caller
        yield

        # Restore the original stdout
        sys.stdout = save_stdout

        # Close null device
        devnull.close()

    # Initialize the output
    out = io.StringIO()

    # Set out as the default output

# Generated at 2022-06-22 05:34:11.799496
# Unit test for function trange
def test_trange():  # pragma: no cover
    from trange import trange
    from tqdm.utils import _term_move_up
    # Test trange terminal escape sequences
    with trange(10, leave=False) as t:
        for i in range(5):
            t.update()
        t.write("hello")
        _term_move_up()  # In case it printed escape sequences
        t.write("world")
        _term_move_up()
        t.write("bye")
        t.close()
        _term_move_up()
        t.write("nope")

# Generated at 2022-06-22 05:34:21.662318
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method FractionColumn.render."""
    class Task:
        def __init__(self):
            self.completed = 42
            self.total = 42
    task = Task()
    f = FractionColumn()
    assert f.render(task) == Text("42.0/42.0", style="progress.download")
    task.completed, task.total = 453.3, 765.8
    unit, suffix = filesize.pick_unit_and_suffix(task.total, ["K", "M"], 1000)
    assert f.render(task) == Text("0.5/1.2 M", style="progress.download")
    f = FractionColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:34:25.721061
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    progress = Progress()
    progress.total = 15000
    progress.completed = 3600
    progress.speed = 0.7
    progress_column = FractionColumn()
    progress_column.render(progress)

# Generated at 2022-06-22 05:34:27.950880
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    assert hasattr(tqdm_rich, 'clear')
    assert isinstance(tqdm_rich.clear, type(tqdm.close))

# Generated at 2022-06-22 05:34:33.810392
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Check that tqdm_rich.clear does not fail with AssertionError.
    """
    for _ in tqdm_rich(range(10), desc="Test"):
        pass

# Generated at 2022-06-22 05:34:39.710395
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        for i in range(5):
            t.reset(5)
            t.update(1)
        for i in range(5):
            t.reset(5)
            t.update(1)
        t.reset(0)

# Generated at 2022-06-22 05:34:52.977653
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    # Test disable
    with tqdm_rich(disable=True) as t:
        t.update(1)
    t = tqdm_rich(disable=False)
    t.setup(0, 0, 1)

    # Test progress
    with tqdm_rich(total=10, progress=[]) as t:
        for i in t:
            pass
    with tqdm_rich(total=10, progress=(BarColumn(),)) as t:
        for i in t:
            pass

    # Test format_dict
    with tqdm_rich(total=10, unit='t') as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:34:55.879195
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    frac_col = FractionColumn()
    assert frac_col.render(0, 1) == "0.0/1.0"



# Generated at 2022-06-22 05:35:00.369759
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import call
    import io
    from .tests_tqdm import discourages_delayed_expr_eval, range_type

    def foo():
        tqdm.display(1, 2, a=3)

    log_capture_string = io.StringIO()
    wi

# Generated at 2022-06-22 05:35:13.262610
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import time
    with tqdm_rich(ascii=True, total=10, desc='test') as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    assert len(t._prog._tasks) == 1
    assert t.n == t.total
    assert 'test' in t.desc
    assert t.leave is False
    assert t._prog.transient is True


if __name__ == '__main__':  # pragma: no cover
    # Unit tests:
    # test_tqdm_rich()
    # check for errors
    iterable = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for i in tqdm_rich(iterable, desc='test'):
        time

# Generated at 2022-06-22 05:35:19.047142
# Unit test for function trange
def test_trange():
    from pytest import approx
    from time import sleep
    from .utils import FormatStdout

    items = trange(10, desc='Loading ...',
                   unit='files', unit_scale=True,
                   unit_divisor=1024, dynamic_ncols=True)
    for _ in items:
        sleep(0.1)
    items.reset(total=15)
    for _ in items:
        sleep(0.2)

    with FormatStdout():
        with tqdm_rich(total=10,
                       unit='B', unit_scale=True, unit_divisor=1000) as t:
            for i in _range(10):
                sleep(0.01)
                t.update()
        assert t.n == 10

# Generated at 2022-06-22 05:35:27.872248
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=30.5)
    task.completed = 13.2
    task.total = 30.5
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert '13.2/30.5 K' == column.render(task)
    task = Progress(total=3000.5)
    task.completed = 1300.2
    task.total = 3000.5
    assert '1.1/2.7 M' == column.render(task)


# Generated at 2022-06-22 05:35:29.850001
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    rate_column = RateColumn()
    rate_column.render(None)



# Generated at 2022-06-22 05:35:34.011399
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time

    for _ in tqdm_rich(total=3):
        time.sleep(0.01)
    tqdm.reset()


if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-22 05:35:43.827123
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    from .tests_tqdm import pretest_posttest_run
    pretest_posttest_run(trange)

# Generated at 2022-06-22 05:35:52.578730
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit='', unit_scale=True, unit_divisor=1000)
    r = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    r = RateColumn(unit='', unit_scale=False, unit_divisor=1024)
    r = RateColumn(unit='', unit_scale=False, unit_divisor=1000 ** 10)
    r = RateColumn(unit='', unit_scale=False, unit_divisor=1024 ** 20)
    r = RateColumn(unit='', unit_scale=True, unit_divisor=1024 ** 20)
    r = RateColumn(unit='', unit_scale=True, unit_divisor=1000 ** 10)
    r = RateColumn(unit='', unit_scale=False, unit_divisor=100)

# Generated at 2022-06-22 05:36:00.668129
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import time
    import os
    try:
        with tqdm_rich(total=10) as pbar:
            for step in range(10):
                time.sleep(0.1)
                pbar.update()
            # assert step == 11
    finally:
        os.system("rm /tmp/rich.log*")


# python -m tqdm.rich 'test_tqdm_rich()'
if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-22 05:36:12.911521
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000)(
        {"total": 0, "completed": 0, "speed": None}) == Text(
        f"? ",
        style="progress.data.speed")
    assert RateColumn(unit="", unit_scale=True, unit_divisor=1000)(
        {"total": 0, "completed": 0, "speed": None}) == Text(
        f"? ",
        style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000)(
        {"total": 0, "completed": 0, "speed": 1}) == Text(
        f"1 B/s",
        style="progress.data.speed")

# Generated at 2022-06-22 05:36:23.721832
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        "[",
        TimeElapsedColumn(),
        "<",
        TimeRemainingColumn(),
        ",",
        RateColumn(unit='B', unit_scale=True, unit_divisor=1000),
        "]"
    )
    task_id = progress.add_task(
        "Downloading",
        **{'total': 100, 'unit': 'B', 'unit_scale': True, 'unit_divisor': 1000}
    )
    progress.update(task_id, completed=0, speed=123456789)

# Generated at 2022-06-22 05:36:25.510217
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=50) as progress_bar:
        progress_bar.reset()


# Generated at 2022-06-22 05:36:36.554804
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-22 05:36:42.897797
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=1000, desc='testing', ncols=100,
                  mininterval=1e-7, miniters=1,
                  disable=False, unit='iB', unit_scale=True,
                  unit_divisor=1024, ascii=False)
    t.close()
    return t

# Generated at 2022-06-22 05:36:46.364867
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    c = FractionColumn(
            unit_scale=True,
            unit_divisor=1000
        )
    c.render(10, 23)

# Generated at 2022-06-22 05:36:57.135809
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn

    class TestTQDM(tqdm_rich):
        def __init__(self):
            super(TestTQDM, self).__init__(range(10))

        def clear(self, *_, **__):
            pass

        def display(self, *_, **__):
            if not hasattr(self, '_prog'):
                return
            self._prog.update(self._task_id, completed=self.n, description=self.desc)

    test_tqdm = TestTQDM()
    test_tqdm.disable = True
    test_tqdm.close()

   

# Generated at 2022-06-22 05:37:16.565817
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    c = FractionColumn()
    p = Progress(c)
    p.add_task("test", total=1.23)
    p.update(0, completed=0.45)
    assert p.render() == '[bold]0.0/1.2 [/bold]'



# Generated at 2022-06-22 05:37:18.067313
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    assert tqdm_rich(range(2)).reset().total == 2

# Generated at 2022-06-22 05:37:29.382243
# Unit test for method close of class tqdm_rich

# Generated at 2022-06-22 05:37:32.240114
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich"""
    tqdm_rich(total=10).clear()
    tqdm(total=10).clear()

# Generated at 2022-06-22 05:37:35.790532
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-22 05:37:40.807405
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(["a", "b", "c"])
    assert pbar.total == 3
    # pbar.reset()
    # assert pbar.total is None
    pbar.reset(total=5)
    assert pbar.total == 5
    pbar.reset(total=7)
    assert pbar.total == 7
    pbar.reset(total=2)
    assert pbar.total == 2
    pbar.close()

# Generated at 2022-06-22 05:37:47.175737
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Check if a FractionColumn is constructed correctly
    column = FractionColumn()
    assert column.unit_scale is False
    assert column.unit_divisor is 1000

    # Check if FractionColumn is rendered correctly
    task = Progress.TASK_CLASS("", 100, 0, 0)
    assert column.render(task) == "\x1b[38;5;202m0.0/1.0 \x1b[0;38;2;195;195;195m\x1b[0m"

    task = Progress.TASK_CLASS("", 10000, 0, 0)
    assert column.render(task) == "\x1b[38;5;202m0.0/10.0 \x1b[0;38;2;195;195;195mK\x1b[0m"

   

# Generated at 2022-06-22 05:37:58.996128
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Unit test for method render of class `RateColumn`.
    """
    from .tests_tqdm import discretize, UnicodeIO, FakeTqdmFile
    from .std import test_enumerate, test_wrap_nested

    fake = FakeTqdmFile(discretize(test_enumerate(test_wrap_nested(
        UnicodeIO(u"\n\n\n\n\n\n\n\n\n\n").readlines()),
        total=100)))
    for i in trange(100, file=fake, miniters=1, unit_scale=False, desc="testing",
                    bar_format='{l_bar}{bar}{r_bar}'):
        pass

    # test without unit_scale

# Generated at 2022-06-22 05:38:07.734575
# Unit test for function trange
def test_trange():
    r = trange(10)
    for i in r:
        assert isinstance(i, int)
    # with desc
    r = trange(10, desc="desc")
    for i in r:
        assert isinstance(i, int)
    # total
    r = trange(10, total=100)
    for i in r:
        assert isinstance(i, int)
    # postfix
    r = trange(10, postfix="postfix")
    for i in r:
        assert isinstance(i, int)
    # unit
    r = trange(10, unit="unit")
    for i in r:
        assert isinstance(i, int)
    # unit_scale
    r = trange(10, unit_scale=True)

# Generated at 2022-06-22 05:38:16.755893
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    assert isinstance(tqdm_rich(0), tqdm_rich)
    assert tqdm_rich(0).disable
    assert tqdm_rich(0).is_active()
    assert tqdm_rich(0).is_enabled()
    tqdm_rich(0).disable = False
    assert tqdm_rich(0).disable is False
    assert tqdm_rich(0).is_enabled() is False
    assert tqdm_rich(0, disable=False).is_active() is False
    assert tqdm_rich(0, disable=None).is_enabled() is False
    assert tqdm_rich(0, disable=None).is_active() is False
    assert tqdm_rich(0, disable=False).is_enabled() is False

# Generated at 2022-06-22 05:38:55.930769
# Unit test for function trange
def test_trange():
    from tqdm import trange
    for _ in trange(10):
        pass
    from tqdm.utils import _term_move_up
    print('    ', 10 * _term_move_up())


if __name__ == '__main__':
    rng = trange(10)
    for _ in rng:
        pass

# Generated at 2022-06-22 05:39:01.234527
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(3) as t:
        assert t._prog.total == 3
        assert t._prog.completed == 0
        t.update(1)
        assert t._prog.completed == 1
        t.reset(8)
        assert t._prog.total == 8
        assert t._prog.completed == 0

# Generated at 2022-06-22 05:39:09.440420
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for method reset of class tqdm_rich
    """
    task_1 = tqdm_rich(total=5)
    for i in task_1:
        if i == 3:
            task_1.reset()
    task_1.close()

    task_2 = tqdm_rich(total=5)
    for i in task_2:
        if i == 3:
            task_2.reset(total=10)
    task_2.close()


# Unit teat for method clear of class tqdm_rich

# Generated at 2022-06-22 05:39:12.532025
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    _fraction = FractionColumn()
    assert _fraction.render("0.5/2.3 G") == Text("0.5/2.3 G", style="progress.download")

# Generated at 2022-06-22 05:39:15.727945
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    p = tqdm_rich(range(10))
    p.close()
    assert p._prog.__exit__ is not None
    assert p._prog.__exit__ is not None
    assert p._prog.__exit__ is not None


# Generated at 2022-06-22 05:39:19.049519
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import PY3
    from .utils import _range

    with tqdm_rich(total=10) as t:
        for _ in t:
            assert t.gui
            assert t.disable == False

    if not PY3:
        with tqdm(_range(10), gui=True) as t:
            for _ in t:
                assert t.gui
                assert t.disable == False

# Generated at 2022-06-22 05:39:25.213157
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import shutil
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .utils import _range

    try:
        from rich.progress import Progress

        with TemporaryDirectory() as tmp_dir:
            Path(tmp_dir, 'tst').mkdir(parents=True, exist_ok=True)
            prog = Progress()
            with prog:
                for _ in tqdm(iterable=_range(2), desc=str(tmp_dir), unit_scale=True,
                              unit_divisor=1024):
                    shutil.copytree(str(Path('tst')), str(Path(tmp_dir, 'tst')))
    except ImportError:  # pragma:no cover
        pass  # require `rich` for this test

# Generated at 2022-06-22 05:39:30.843355
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    col = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert col.render(Progress.Task(completed=0, total=0, description="test", percentage=0)) == Text(
        "0.0/0.0 ", style="progress.download")

# Generated at 2022-06-22 05:39:35.364685
# Unit test for function trange
def test_trange():  # pragma: no cover
    with trange(10, desc='trange', bar_format="{percentage:3.0f}%"
                                               "{bar}|{n_fmt}/{total_fmt}"
                                               "{remaining} {elapsed}") as t:
        for i in t:
            pass



# Generated at 2022-06-22 05:39:41.137313
# Unit test for function trange
def test_trange():
    from .tests import unittest
    from .tests.common import closing

    with closing(
            unittest.mock.patch(
                'sys.stderr', new_callable=unittest.mock.StringIO)) as stderr:
        with trange(10) as t:
            for _ in t:
                if t.n == 5:
                    break
        assert stderr.getvalue().count("\r") == 5

# Generated at 2022-06-22 05:42:24.748643
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="B/s")
    RateColumn(unit="B/s", unit_scale=True)
    RateColumn(unit="B/s", unit_scale=True, unit_divisor=1024)
    RateColumn(unit="B/s", unit_divisor=1024)

# Generated at 2022-06-22 05:42:34.407171
# Unit test for constructor of class RateColumn

# Generated at 2022-06-22 05:42:38.754717
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Tests function trange"""
    # TODO: check if ProgressColumn bar is working correctly
    if __name__ == '__main__':
        with trange(10) as t:
            for i in t:
                pass


# Generated at 2022-06-22 05:42:42.716309
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(range(3)).clear()
    tqdm_rich(range(3)).close()
    tqdm_rich(range(3)).clear()
    tqdm_rich(range(3)).close()


# Generated at 2022-06-22 05:42:49.571143
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test to render the completed/total, e.g. '0.5/2.3 G'."""
    from .std import tqdm as std_tqdm
    tqdm_experimental = tqdm_rich
    for tqdm in [std_tqdm, tqdm_experimental]:
        for total, completed in [(1, 1), (1, 1.23), (5, 54.5),
                                 (100, 5), (100, 50), (100, 5000)]:
            bar, barcolon = tqdm(total=total, miniters=completed)
            bar.close()
            if not isinstance(bar, tqdm_rich):
                continue
            result = FractionColumn(unit_scale=True).render(bar)

# Generated at 2022-06-22 05:42:51.829014
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import unittest.mock
    assert hasattr(unittest.mock.Mock(spec=tqdm_rich).clear, "__call__")

# Generated at 2022-06-22 05:42:58.287547
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="bps").render(1.323) == Text("1.3 bps", style="progress.data.speed")
    assert RateColumn(unit="Gbps", unit_scale=True).render(1.323) == Text("1.3 Gbps", style="progress.data.speed")
    assert RateColumn(unit="bps", unit_scale=True).render(1.323) == Text("1.3 bps", style="progress.data.speed")

test_RateColumn_render()