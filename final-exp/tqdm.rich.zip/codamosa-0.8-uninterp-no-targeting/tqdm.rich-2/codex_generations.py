

# Generated at 2022-06-22 05:33:12.660508
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests import pretest_posttest
    with pretest_posttest(disable=False, ncols=80, leave=True, unit_scale=True,
                          miniters=0, mininterval=0, mininterval_fraction=0.1) as (
            pretest, posttest):
        # Test tqdm_rich
        for _ in tqdm_rich(range(4)):
            pass
        for _ in tqdm_rich(range(4), total=10):
            pass
        for _ in tqdm_rich(range(4), total=10, leave=True):
            pass
        for _ in tqdm_rich(range(4), total=10, posttest=posttest):
            pass

# Generated at 2022-06-22 05:33:19.763995
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
        from rich.console import Console
        from rich.progress import Progress
        from rich.traceback import Traceback
        with Console() as console:
            with Progress() as progress:
                task = progress.add_task("Task", total=100, start=False)
                for i in range(100):
                    task.update(i)
                try:
                    0 / 0
                except ZeroDivisionError:
                    Traceback().print(file=console)

# Generated at 2022-06-22 05:33:24.405900
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(unit_scale=True, unit_divisor=1024) as t:
        for x in t:
            t.update(x)
            t.clear()
            if x == 1000:
                break

# Generated at 2022-06-22 05:33:32.962400
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import types
    from .tqdm import TqdmTypeError, _range, tgrange
    # Check that .close() noclobbers
    for cls in (tqdm_rich, tgrange):
        pbar = cls(_range(3), disable=False)
        old_stdout = sys.stdout
        sys.stdout = None
        try:
            pbar.close()
            assert old_stdout == sys.stdout
        finally:
            sys.stdout = old_stdout
        # Check that calling .write() raises
        try:
            pbar.write('')
            raise RuntimeError
        except (AttributeError, TqdmTypeError):
            pass
        # Check that calling .update() raises

# Generated at 2022-06-22 05:33:39.045109
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Test and demonstrate the constructor of the RateColumn class.
    """
    _ = RateColumn(unit="B")

    _ = RateColumn(unit="B", unit_scale=True)

    _ = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-22 05:33:49.215683
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = std_tqdm()
    task.total = 100
    task.n = 50
    fraction = FractionColumn()
    assert fraction.render(task) == Text("0.5/1.0", style="progress.download")
    task.total = 1000
    task.n = 500
    assert fraction.render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 10000
    task.n = 5000
    assert fraction.render(task) == Text("0.5/1.0  ", style="progress.download")
    task.total = 10000
    task.n = 5000
    fraction = FractionColumn(unit_scale=True)
    assert fraction.render(task) == Text("0.5/1.0 k", style="progress.download")

# Generated at 2022-06-22 05:33:53.177734
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        tqdm_rich(total=10).close()
    except:
        return False
    return True

# Generated at 2022-06-22 05:34:04.044724
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    sample_speed = 823.12
    sample_unit_divisor = 1000
    sample_scale = ["", "K", "M", "G", "T", "P", "E", "Z", "Y"]
    sample_unit_1000, sample_suffix_1000 = filesize.pick_unit_and_suffix(
        sample_speed, sample_scale, sample_unit_divisor)
    sample_rate_1000 = f"{sample_speed / sample_unit_1000:,.2f} {sample_suffix_1000}/s"
    sample_unit_1, sample_suffix_1 = filesize.pick_unit_and_suffix(
        sample_speed, [""], 1)

# Generated at 2022-06-22 05:34:15.555694
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="")() == '? B/s'
    assert RateColumn(unit="Kb")() == '? Kb/s'
    assert RateColumn(unit="KiB")() == '? KiB/s'
    assert RateColumn(unit="")(speed=15) == '15 B/s'
    assert RateColumn(unit="Kb")(speed=15) == '15 Kb/s'
    assert RateColumn(unit="KiB")(speed=15) == '15 KiB/s'
    assert RateColumn(unit="")(speed=15, unit_scale=True) == '15 B/s'
    assert RateColumn(unit="Kb")(speed=15, unit_scale=True) == '15 Kb/s'

# Generated at 2022-06-22 05:34:20.275066
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class Task:
        """Mock class with attributes needed by RateColumn.render."""
        def __init__(self, speed):
            self.speed = speed
    rate = RateColumn()
    task = Task(100)
    assert rate.render(task) == Text("100 /s", style="progress.data.speed")


# Generated at 2022-06-22 05:34:27.161931
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm(range(10)):
        pass
    tqdm.reset(total=10)
    for i in tqdm(range(10)):
        pass

# Generated at 2022-06-22 05:34:30.523338
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    progress = Progress()
    prog_col = FractionColumn() 
    progress.add_task("task", total=100)
    assert prog_col.render(progress.tasks[0]).text == "0/100 "

# Generated at 2022-06-22 05:34:36.709812
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(desc="tqdm") as t:
        for i in t:
            t.close()
            break
    assert t.n == 1
    try:
        t.display()
        assert False, "Should not be able to display a closed tqdm progress bar"
    except Exception:
        pass



# Generated at 2022-06-22 05:34:39.373258
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    unit = FractionColumn()
    number = '0.5 / 2.3'
    assert unit.render(number) == '0.5 / 2.3'



# Generated at 2022-06-22 05:34:44.519069
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm_rich(total=10) as t:
        assert t.total == 10
        t.close()



# Generated at 2022-06-22 05:34:48.011211
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich(1,1,1,1).close()
    #tqdm_rich(1,1,1,1).close()
    pass

# Generated at 2022-06-22 05:34:56.259249
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich."""
    from .std import tqdm as std_tqdm
    from rich.progress import Progress
    with Progress() as progress:
        task_id = progress.add_task(
            "Counting!", total=100, description="start")
        assert progress.update(task_id, description="started")

# Generated at 2022-06-22 05:34:58.659058
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    key = FractionColumn()
    assert key.unit_scale == False
    assert key.unit_divisor == 1000


# Generated at 2022-06-22 05:35:02.961777
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    from time import sleep
    with trange(8, desc="Rich Range") as t:
        for _ in t:
            sleep(0.1)

# Generated at 2022-06-22 05:35:09.038203
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.unit_scale == False
    assert fc.unit_divisor == 1000

    fc = FractionColumn(unit_scale=True)
    assert fc.unit_scale == True

    fc = FractionColumn(unit_divisor=999)
    assert fc.unit_divisor == 999


# Generated at 2022-06-22 05:35:19.290092
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.completed = 100
    task.total = 200
    task.speed = 400
    assert str(RateColumn().render(task)) == '400 B/s'
    assert str(RateColumn(unit_scale=True).render(task)) == '400 B/s'
    assert str(RateColumn(unit='m').render(task)) == '400 mB/s'
    assert str(RateColumn(unit='m', unit_scale=True).render(task)) == '400 mB/s'

# Generated at 2022-06-22 05:35:24.745925
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import pytest
    with tqdm_rich(total=5, disable=False) as t:
        for _ in range(5):
            t.set_description('Test')
            t.update()
    with pytest.raises(SystemExit):
        raise RuntimeError("Test completed")

# Generated at 2022-06-22 05:35:29.719782
# Unit test for constructor of class RateColumn
def test_RateColumn():
    class task:
        pass

    t = task()
    t.speed = 2 * (1024**1)
    task.completed = 1
    task.total = 1
    r1 = RateColumn(unit_scale=True).render(task)

    t.speed = 2 * (1024**2)
    r2 = RateColumn(unit_scale=True).render(task)

    t.speed = 2 * (1024**3)
    r3 = RateColumn(unit_scale=True).render(task)

    assert r1 == Text("2.0 K/s", style="progress.data.speed")
    assert r2 == Text("2.0 M/s", style="progress.data.speed")
    assert r3 == Text("2.0 G/s", style="progress.data.speed")

# Generated at 2022-06-22 05:35:31.040542
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm_rich.close()

# Generated at 2022-06-22 05:35:35.129439
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():   # pragma: no cover
    from unittest.mock import patch

    with patch('tqdm.rich.Progress.update') as mock_update:
        tqdm_rich('').display()
        mock_update.assert_called_once()

# Generated at 2022-06-22 05:35:44.743767
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from tqdm import tqdm_rich
    pbar = tqdm_rich(total=100, desc='Download:')
    assert isinstance(pbar._prog, Progress)
    assert pbar._prog._task_id != []
    pbar.update(10)
    sleep(0.01)
    assert pbar._prog._task_id != []
    pbar.close()
    pbar.reset(total=50)
    assert pbar._prog._task_id != []
    assert pbar._prog._task_id[0].total == 50

# Generated at 2022-06-22 05:35:50.172374
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    class Foo(tqdm_rich):  # pragma: no cover
        def __init__(self, *args, **kwargs):
            super(Foo, self).__init__(*args, **kwargs)
            self.cleared = False

        def clear(self, *_, **__):
            super().clear(*_, **__)
            self.cleared = True
    foo = Foo()
    foo.clear()
    assert foo.cleared

# Generated at 2022-06-22 05:36:02.264638
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fraction.render({'completed': 5, 'total': 50}) == Text('0.1/0.5 ', style="progress.download")
    assert fraction.render({'completed': 500, 'total': 5000}) == Text('0.1/0.5 ', style="progress.download")
    assert fraction.render({'completed': 5000, 'total': 50000}) == Text('0.1/0.5 ', style="progress.download")
    assert fraction.render({'completed': 50000, 'total': 500000}) == Text('0.1/0.5 ', style="progress.download")

# Generated at 2022-06-22 05:36:07.612888
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    col = FractionColumn()
    col.render(Progress.Task('task_name', completed=0, total=1))
    col = FractionColumn(unit_scale=True, unit_divisor=10)
    col.render(Progress.Task('task_name', completed=0, total=1))



# Generated at 2022-06-22 05:36:11.029810
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    iterable = _range(10)
    actual = [i for i in tqdm(iterable)]
    expected = [i for i in iterable]
    assert actual == expected


# Generated at 2022-06-22 05:36:21.385301
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test trange"""
    lst = range(1024)
    for _ in trange(len(lst), unit="B", unit_scale=True):
        pass

# Generated at 2022-06-22 05:36:32.125653
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test to ensure that method reset() of class tqdm_rich works as specified.
    """
    # Iteration over list:
    for __ in tqdm_rich(['a', 'b', 'c'], total=2):
        pass
    assert 'a' in tqdm_rich.format_dict['desc']
    tqdm_rich.reset(total=3)
    assert 'a' not in tqdm_rich.format_dict['desc']
    # Iteration over single value:
    for __ in tqdm_rich(4, total=2):
        pass
    assert '4' in tqdm_rich.format_dict['desc']
    tqdm_rich.reset(total=3)
    assert '4' not in tqdm_rich.format_dict['desc']

# Generated at 2022-06-22 05:36:35.700954
# Unit test for function trange
def test_trange():
    """Test trange wrapper"""

    def check(it, n):
        """Check trange gives correct stdout"""
        out = []

        @tqdm(it)
        def unit_iter(it):
            for i in it:
                out.append(i)
                yield

        list(unit_iter(it))

        try:
            assert out == list(range(n))
        except AssertionError as e:
            e.args += (out, )
            raise

    for n in [8, 33, 100, 1333]:
        yield check, range(n), n

# Generated at 2022-06-22 05:36:46.429187
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import BarColumn, Progress
    from rich.console import Console
    from rich.text import Text
    console = Console()
    progress = Progress(BarColumn(bar_width=None), FractionColumn())
    with progress:
        task_id = progress.add_task(
            "task", total=300, start=True, description="0/300")
        progress.update(task_id, completed=100)
        progress.update(task_id, completed=200)
    assert progress.render(console) == Text(
        "[progress.description][progress.percentage]0/300 33% ┃██████████▊┃  0.3/3.0 G",
        style="progress.description"
    )

# Generated at 2022-06-22 05:36:57.286453
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    import time
    from .std import format_sizeof

    # Use StringIO as a file descriptor that has a .flush()
    file = StringIO()

    # Force disable of tqdm()
    obj = tqdm_rich(desc='Testing rich tqdm()',
                    total=10, file=file, disable=True,
                    bar_format='{l_bar}')
    assert isinstance(obj, tqdm_rich)
    file.flush()

    # Instantiation and manual update
    obj = tqdm_rich(desc='Testing rich tqdm()',
                    total=10, file=file,
                    bar_format='{l_bar}')

# Generated at 2022-06-22 05:37:00.408721
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for obj in [tqdm_rich(), trange(2)]:
        obj.reset(total=1000)

# Generated at 2022-06-22 05:37:02.340208
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    tqdm(range(10)).close()
    tqdm(range(10)).close()

# Generated at 2022-06-22 05:37:11.690379
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')

    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')

    rate_column = RateColumn(unit_scale=False, unit_divisor=1024)
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')

    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')

    rate_column = RateColumn(unit='/s')
    assert rate_column.render

# Generated at 2022-06-22 05:37:15.403480
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test constructor of class FractionColumn."""
    a = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert a.unit_divisor == 1000
    assert a.unit_scale == False

# Generated at 2022-06-22 05:37:18.066693
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn()
    print(column.__class__.__name__)
    assert(column.__class__.__name__ == "RateColumn")


# Generated at 2022-06-22 05:37:30.840871
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test the clear method of the tqdm_rich class.

    Returns
    -------
    Test results.
    """
    try:
        with tqdm_rich(total=10) as pbar:
            pass
    except NotImplementedError:
        pass
    except BaseException as e:
        raise e
    return True

# Generated at 2022-06-22 05:37:36.056364
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import time
    import traceback

    try:
        bar = tqdm_rich(["a", "b", "c", "d"], leave=False)
        for char in bar:
            time.sleep(0.1)
            bar.display()
    except Exception:
        traceback.print_exc(file=sys.stdout)



# Generated at 2022-06-22 05:37:37.605872
# Unit test for function trange
def test_trange():
    import sys
    for _ in trange(4, file=sys.stdout):
        pass

# Generated at 2022-06-22 05:37:42.776378
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    col = FractionColumn()
    assert col.unit_scale == False
    assert col.unit_divisor == 1000
    col = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert col.unit_scale == True
    assert col.unit_divisor == 1000


# Generated at 2022-06-22 05:37:54.501631
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests_tqdm import pretest

    for _ in tqdm_rich(range(5)):
        pass

    for _ in tqdm_rich(range(5), leave=True):
        pass

    for _ in trange(5):
        pass

    for _ in trange(5, leave=True):
        pass

    with tqdm_rich(range(5)) as t:
        assert t.n == 0
    assert t.n == 5

    with tqdm_rich(range(5), leave=True) as t:
        assert t.n == 0
    assert t.n == 0

    # Test with and without `disable=True`.
    for _ in tqdm_rich(range(5), disable=False):
        pass

# Generated at 2022-06-22 05:38:00.286268
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # test for filesize
    result = RateColumn().render(std_tqdm(100))
    assert result.text == '0.0 /s'

    # test for time
    result1 = RateColumn(unit='it').render(std_tqdm(100))
    assert result1.text == '0.0 it/s'



# Generated at 2022-06-22 05:38:07.240967
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = ProgressColumn()
    task.speed = 1000
    rate = RateColumn()
    assert rate.render(task) == Text('1.00 kB/s', style='progress.data.speed')
    rate = RateColumn(unit='byte')
    assert rate.render(task) == Text('1.00 kbyte/s', style='progress.data.speed')

# Generated at 2022-06-22 05:38:11.388430
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    task = object
    task.completed = 120000
    task.total = 4000000
    assert FractionColumn().render(task) == Text("120.0/4.0 K", style="progress.download")

# Generated at 2022-06-22 05:38:22.856585
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .utils import PretendVisible, ColorfulString
    with PretendVisible():
        t = tqdm_rich(total=0, file=None, leave=True)
        assert ColorfulString(t.format_dict['bar_format'].format(
            **t.format_dict)) == ColorfulString(
                '[{bar}] {n_fmt}/{total_fmt} {rate_fmt}{postfix}')
        assert t._trange_miniters == 0.01
        assert t.smoothing == 1

# Generated at 2022-06-22 05:38:33.978066
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = type("", (), {})()

    task.completed = 10.
    task.total = 20.

    assert FractionColumn().render(task) == Text("0.5/1.0", style="progress.download")

    task.total = 123456789
    assert FractionColumn(
        unit_scale=True,
        unit_divisor=1000
    ).render(task) == Text("0.0/123.5 M", style="progress.download")

    task.total = 123456789
    assert FractionColumn(
        unit_scale=True,
        unit_divisor=1024
    ).render(task) == Text("0.0/120.1 M", style="progress.download")

    task.total = 1234567890123456

# Generated at 2022-06-22 05:40:46.784656
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t = TimeElapsedColumn()
    a = RateColumn(unit="b", unit_scale=True, unit_divisor=1024)
    b = RateColumn(unit="b", unit_scale=False, unit_divisor=1024)
    c = RateColumn(unit="", unit_scale=True, unit_divisor=1024)
    d = RateColumn(unit="", unit_scale=False, unit_divisor=1024)
    assert a.render(t=t) == Text("? b/s", style="progress.data.speed")
    assert b.render(t=t) == Text("? b/s", style="progress.data.speed")
    assert c.render(t=t) == Text("? /s", style="progress.data.speed")
    assert d.render(t=t) == Text

# Generated at 2022-06-22 05:40:58.447330
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.total = 100
    task.completed = 50
    assert FractionColumn().render(task) == Text(
        "50.0/100 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text(
        "49.2/97.7 Ki", style="progress.download")
    task.total = 1000
    task.completed = 500
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text(
        "488.3/488.3 K", style="progress.download")
    task.total = 1000000
    task.completed = 500000

# Generated at 2022-06-22 05:41:18.109075
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():

    from .tests_tqdm import pretest_posttest  # Test-wide fixtures
    from .tests_tqdm import TestCase, closing, closing_if_open, skip_if_pypy

    # N.B.: this is a copy/paste of tqdm/tests/test_tqdm.py
    def _test_tqdm_rich(autonotebook=False, unit_scale=False,
                        gui=False, **kwargs):
        """
        Tests basic functionality of tqdm_rich().
        """
        # Positionals
        with closing(tqdm_rich(1, 2, 3, **kwargs)) as t:
            assert t.n == 0
            t.update()
            t.update()
            # This one should go over the total size
            t.update()

# Generated at 2022-06-22 05:41:19.970427
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print(RateColumn(unit="MB", unit_scale=True, unit_divisor=1024).render(None))

# Generated at 2022-06-22 05:41:23.269767
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    done = 1
    total = 2
    expect = '1.0/2.0 '
    actual = FractionColumn(unit_scale=False, unit_divisor=1000).render(done, total)
    assert expect == actual


# Generated at 2022-06-22 05:41:25.918790
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert repr(column) == "FractionColumn()"
    assert column.unit_scale == False
    assert column.unit_divisor == 1000
    assert str(column) == "FractionColumn()"


# Generated at 2022-06-22 05:41:30.057466
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    for i in trange(2):
        time.sleep(0.02)
    try:
        for i in trange(2):
            time.sleep(0.02)
    except TqdmExperimentalWarning:
        pass

# Generated at 2022-06-22 05:41:33.784319
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=3) as r:
        r.reset(total=6)
        r.reset()


if __name__ == '__main__':
    test_tqdm_rich_reset()

# Generated at 2022-06-22 05:41:56.012212
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    with tqdm_rich(total=5) as pbar:
        pbar.display(1)
        pbar.display(3)
        pbar.display(5)
    assert pbar.n == 5
    assert pbar.last_print_n == 5
    assert pbar._sp(pbar.n) == pbar._sp(5)
    pbar.reset()
    assert pbar.n == 0
    assert pbar.last_print_n == 0
    assert pbar._sp(pbar.n) == pbar._sp(0)

# Generated at 2022-06-22 05:41:59.861823
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    progress = trange(2)
    assert progress._prog is not None
    progress.clear()
    assert progress._prog is not None
    progress.clear(nolock=True)
    assert progress._prog is not None