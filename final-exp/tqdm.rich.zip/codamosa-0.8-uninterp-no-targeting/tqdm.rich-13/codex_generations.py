

# Generated at 2022-06-22 05:33:01.085634
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(task={'completed': 1000, 'total': 2000}) == Text('0.5/2.0', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task={'completed': 1000, 'total': 2000}) == Text('0.5/2.0 K', style='progress.download')
    assert FractionColumn(unit_divisor=1024).render(task={'completed': 1000, 'total': 2000}) == Text('0.5/2.0 Ki', style='progress.download')


# Generated at 2022-06-22 05:33:04.621715
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=10)
    assert t._prog.total == 10
    t.reset(total=20)
    assert t._prog.total == 20
    t.reset()
    assert t._prog.total == 20



# Generated at 2022-06-22 05:33:11.905708
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tests_tqdm import pretest_posttest as t
    from .tests_tqdm import StringIO

    @t
    def test_tqdm_rich_display(sio, func):
        for _ in tqdm_rich("abcdefghijklmnopqrstuvwxyz", bar_format="{desc}: {n_fmt}",
                           unit=" letters", file=sio, desc=func.__name__):
            pass

    test_tqdm_rich_display()


# Generated at 2022-06-22 05:33:20.938931
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Unit test for method render of class RateColumn.
    """
    column = RateColumn()
    task = tqdm_rich._trange_new_task(total=None, description=None,
                                      unit_scale=False, unit_divisor=1)
    task._speed = None
    assert column.render(task) == Text(f"? B/s", style="progress.data.speed")
    task._speed = 1024
    assert column.render(task) == Text(f"1.00 KB/s", style="progress.data.speed")
    task._speed = 1024 ** 2
    assert column.render(task) == Text(f"1.00 MB/s", style="progress.data.speed")
    task._speed = 1024 ** 3

# Generated at 2022-06-22 05:33:26.591182
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(total=100, unit="B")
    task.update(0)
    task._task_id = 0
    column = FractionColumn(unit_scale=False)
    assert column.render(task) == Text("0.0/100 B", style="progress.download")

# Generated at 2022-06-22 05:33:34.095600
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    myTask = type('', (), {})()
    myTask.completed = 123
    myTask.total = 1234

    fc = FractionColumn()
    assert fc.render(myTask) == Text(
        '123/1,234', style='progress.download')

    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.render(myTask) == Text(
        '0.1/1.2 K', style='progress.download')


# Generated at 2022-06-22 05:33:37.646782
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(10) as t:
        assert t.n == 0
        t.clear()
        t.update(2)
        assert t.n == 2


# Generated at 2022-06-22 05:33:41.674767
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Tests `tqdm.rich.tqdm_rich`.
    """
    from time import sleep
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            sleep(0.02)
            pbar.update(1)

# Generated at 2022-06-22 05:33:51.136908
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import tqdm
    from .utils import FormatWidget
    import time

    queued = []
    _inst = tqdm(total=20, dynamic_ncols=True, unit='B', unit_scale=True,
                 unit_divisor=1024, bar_format='{l_bar}{bar}|',
                 miniters=1, mininterval=0, ascii=True)
    _inst._prog = FormatWidget()
    _inst._task_id = _inst._prog.add_task(_inst.desc, **_inst.format_dict)
    _inst.display()
    time.sleep(0.01)
    queued.append(_inst.format_dict)



# Generated at 2022-06-22 05:33:53.919390
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(10) as t:
        t.clear()
        t.close()

# Generated at 2022-06-22 05:34:02.377325
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
  from tqdm.rich import tqdm_rich
  from tqdm.utils import _range

  with tqdm_rich(_range(3)) as t:
    # Test tqdm_rich_close
    assert t.disable == False
    t.close()
    assert t.disable == True


# Generated at 2022-06-22 05:34:04.018438
# Unit test for function trange
def test_trange():  # pragma: no cover
    with trange(10) as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:34:15.502195
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Unit test for constructor of class RateColumn.
    """
    speed = 2
    RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    RateColumn(unit="B", unit_scale=False, unit_divisor=1024)
    RateColumn(unit="B", unit_scale=True, unit_divisor=1)
    RateColumn(unit="B", unit_scale=False, unit_divisor=1)
    RateColumn(unit="B", unit_scale=True, unit_divisor=0)

# Generated at 2022-06-22 05:34:19.836855
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn('/s').unit == '/s'
    assert RateColumn('/s', unit_scale=True, unit_divisor=1000).unit_scale == True
    assert RateColumn('/s', unit_scale=True, unit_divisor=1000).unit_divisor == 1000



# Generated at 2022-06-22 05:34:22.104445
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test function `trange`."""
    for _ in trrange(10):
        pass

# Generated at 2022-06-22 05:34:32.627499
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm
    from .std import trange as std_trange


# Generated at 2022-06-22 05:34:36.409982
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import Progress, TaskID
    console = Console()
    progress = Progress()
    task = progress.add_task("Downloading...")
    progress.update(task, completed=50)
    print(progress.render(console))

# Generated at 2022-06-22 05:34:42.138429
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .utils import DiscreteMeter
    from .utils import _range

    def test_class(tqdm_class):
        total = 10
        vals = [0, 1, 6, 8, 10]
        for val in vals:
            with tqdm_class(total=total) as t:
                t.total = total
                t.n = val
            assert t.n == val

        with tqdm_class(total=total, **std_tqdm.format_dict) as t:
            t.total = total
            t.n = total - 1
            t.close()


# Generated at 2022-06-22 05:34:53.393951
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import format_interval, _range

    iterable = _range(10)
    with tqdm_rich(iterable) as t:
        for i in iterable:
            t.reset(total=i + 1)
            t.update()

    with tqdm_rich(total=10) as t:
        for i in _range(10):
            t.reset(total=i + 1)
            t.update()

    with tqdm(total=10) as t:
        for i in _range(10):
            t.reset(total=i + 1)
            t.update()

    # Avoid overflowed value forn total=2**32

# Generated at 2022-06-22 05:34:55.360437
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    t = std_tqdm(total=10)
    t.close()

# Generated at 2022-06-22 05:35:11.462595
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    rate_column = RateColumn()
    assert rate_column.render(Progress(total=1000, completed=100, speed=None)) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(Progress(total=1000, completed=100, speed=1000)) == Text("1.0 /s", style="progress.data.speed")
    assert rate_column.render(Progress(total=1000, completed=100, speed=100000)) == Text("100.0 /s", style="progress.data.speed")

# Generated at 2022-06-22 05:35:17.665549
# Unit test for function trange
def test_trange():
    """
    trange unit test. Verifies that the `.format_dict` attribute is working
    (since this test is sharing code with the standard `tqdm`).
    """
    for _ in trange(4, desc='Testing...', unit='B', unit_scale=True,
                    miniters=None):
        pass

# Generated at 2022-06-22 05:35:23.379442
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    import time
    with tqdm(total=10) as t:
        for i in range(10):
            time.sleep(0.3)
            t.update()
    expected_output = "[progress.description][progress.percentage]100%\n"
    assert t.format_dict['output'] == expected_output

# Generated at 2022-06-22 05:35:27.005480
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    r=tqdm_rich(range(10))
    assert r.disable == False

    r.close()
    # r.__exit__(None, None, None)
    assert r.disable == False

# Generated at 2022-06-22 05:35:33.311981
# Unit test for constructor of class RateColumn
def test_RateColumn():
    default_column = RateColumn()
    assert default_column.unit == ''
    assert default_column.unit_scale == False
    assert default_column.unit_divisor == 1000

    expected_column = TimeElapsedColumn()
    column = RateColumn(unit='ms', unit_scale=True, unit_divisor=1000)
    assert column.render(expected_column) == Text('0.0 ms/s', style='progress.data.speed')

# Generated at 2022-06-22 05:35:40.183617
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task=None
    # Speed is None
    col = RateColumn()
    assert col.render(task) == Text(f"? /s", style="progress.data.speed")
    # Speed is not None
    col = RateColumn(unit_scale=True)
    task.speed=1024
    assert col.render(task) == Text(f"1.0 K/s", style="progress.data.speed")

# Generated at 2022-06-22 05:35:51.067519
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import pytest

    task = ProgressColumn()
    task.completed = 6250
    task.total = 12500

    # Testcase 1: unit scale is False
    column = FractionColumn()
    result = column.render(task)
    assert result.text == "6250/12500"

    # Testcase 2: unit scale is True
    # unit is 0, suffix is ""
    # result should be: 6250/12500
    column = FractionColumn(unit_scale=True)
    result = column.render(task)
    assert result.text == "6250/12500"

    # Testcase 3: unit is 1, suffix is "K"
    # result should be: 6.3/12.5 K
    task.total = 13000
    result = column.render(task)

# Generated at 2022-06-22 05:36:03.198392
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    # Test with speed = None
    assert(rate_column.render({
        "task": None,
        "completed": 0,
        "total": 0,
        "speed": None
        })
        == Text("? /s", style="progress.data.speed")
    )
    # Test with speed = 0 and unit = ""
    assert(rate_column.render({
        "task": None,
        "completed": 0,
        "total": 0,
        "speed": 0
        })
        == Text("0 /s", style="progress.data.speed")
    )
    # Test with speed = 0 and unit = "K"
    rate_column.unit = "K"

# Generated at 2022-06-22 05:36:08.917361
# Unit test for function trange
def test_trange():  # pragma: no cover
    """ Unit test for function trange """
    # Test `total` parameter
    list(trange(2))
    list(trrange(2))
    # Test `total` parameter (numerical input)
    list(trange(2, total=2))
    list(trrange(2, total=2))

# Generated at 2022-06-22 05:36:17.882990
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import io
    from rich.console import Console
    from rich.table import Table
    console = Console(file=io.StringIO(), force_terminal=True)
    table = Table("Progress")
    progress = Progress("[progress.description]{task.description}",
                        BarColumn(bar_width=None),
                        "[progress.percentage]{task.percentage:>4.0f}%",
                        transient=True)
    progress.console = console
    progress.table = table
    column_id = progress.append_column(FractionColumn(unit_scale=False, unit_divisor=1))
    progress.__enter__()
    task_id = progress.add_task("ProgressTask")
    progress.update(task_id, completed=10, total=100)

# Generated at 2022-06-22 05:36:37.061367
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display()."""
    import os
    import sys
    import time
    import threading
    from random import randint
    from rich.progress import Console

    console = Console()
    # threading.Thread(target=console.watch_pipe, daemon=True).start()
    task = console.progress(Text("Hello world"), transient=True)

    for _ in range(20):
        task.update(Text("Task " + str(randint(1, 10))))
        time.sleep(0.1)

    time.sleep(1)

# Generated at 2022-06-22 05:36:43.325787
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 1
    unit = 1000
    unit_scale = 'False'
    unit_divisor = 1000
    suffix = 'K'
    precision = 0
    test_data = [speed, unit, unit_scale, unit_divisor, suffix, precision]
    expected = '1.0 K/s'
    assert(RateColumn.render(test_data) == expected)

# Generated at 2022-06-22 05:36:49.131195
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    >>> from tqdm.rich import RateColumn
    >>> rate_column = RateColumn(unit="")
    >>> task = {"speed": None}
    >>> _ = rate_column.render(task)
    >>> task = {"speed": 100}
    >>> _ = rate_column.render(task)
    """


# Generated at 2022-06-22 05:37:00.966853
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # pylint: disable=protected-access
    tqdm_1 = tqdm_rich(1)
    tqdm_1._task_id = 'task_id_1'
    tqdm_1.format_dict = {'width': 1, 'block': '#', 'unit': 'B', 'unit_scale': False, 'unit_divisor': None}
    tqdm_1.n = 1
    tqdm_1.desc = 'desc'
    tqdm_1._prog = Progress('[progress.description]{task.description}', '[', TimeElapsedColumn(), ']')
    tqdm_1._prog.tasks['task_id_1'] = Progress.Task('desc', total=1, completed=1, start_time=0.0)
    tqdm_

# Generated at 2022-06-22 05:37:03.270004
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # test for method clear
    with trange(10) as t:
        for i in t:
            pass



# Generated at 2022-06-22 05:37:05.882038
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # Check that progress bar is removed from console window
    # Issue #841
    with tqdm(total=3) as bar:
        bar.update(2)
        bar.close()

# Generated at 2022-06-22 05:37:16.948580
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test the method render of class FractionColumn."""
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(None) == Text("0.0/0.0", style="progress.download")
    assert fc.render(type('', (), {'completed': 0, 'total': 0})()) == Text(
        "0.0/0.0", style="progress.download"
    )
    assert fc.render(type('', (), {'completed': 0, 'total': 1})()) == Text(
        "0.0/0.0", style="progress.download"
    )

# Generated at 2022-06-22 05:37:28.041007
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit='B/s')
    assert rate_column.render(None).text == '? B/s'
    assert rate_column.render({'speed': 1}).text == '1.0 B/s'
    assert rate_column.render({'speed': 1024}).text == '1.0 KB/s'
    assert rate_column.render({'speed': 1048576}).text == '1.0 MB/s'
    assert rate_column.render({'speed': 1073741824}).text == '1.0 GB/s'
    assert rate_column.render({'speed': 1099511627776}).text == '1.0 TB/s'

# Generated at 2022-06-22 05:37:29.637282
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert str(fc) == f'{fc.render(Progress.test_task)}'

# Generated at 2022-06-22 05:37:34.941052
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test unit test for method reset of class tqdm_rich.
    """
    from rich.console import Console
    msg = 'Hello, world!'
    for i in tqdm_rich(range(10), desc=msg):
        pass
    tqdm_rich(range(0), desc=msg).reset(total=0)
    return Console()

# Generated at 2022-06-22 05:38:06.869595
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Ensure method clear of class tqdm_rich is properly defined.
    """
    try:
        tqdm_rich().clear()
    except NotImplementedError:
        pass

# Generated at 2022-06-22 05:38:17.203673
# Unit test for constructor of class RateColumn
def test_RateColumn():
    prog = Progress(
        "[progress.description]{task.description} ",
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), ",",
        RateColumn(unit="B", unit_scale=True, unit_divisor=1000),
    )
    with prog:
        id = prog.add_task(
            "Test",
            start=0,
            total=1000,
            **{'unit': "B", 'unit_scale': True, 'unit_divisor': 1000})
        for i in range(1,1001,100):
            prog.update(id, completed=i)

if __name__ == '__main__':
    test_RateColumn()

# Generated at 2022-06-22 05:38:27.254579
# Unit test for function trange
def test_trange():
    from .utils import _unset_child

    trange(3, desc="", file=None, miniters=0, leave=True, position=None, bar_format=None,
           ascii=False, disable=False, unit_scale=False, unit=None,
           dynamic_ncols=True, smoothing=0.3, bar_template=None,
           initial=0, mininterval=0.1, maxinterval=10.0, miniters=0,
           postfix=None, unit_name=None, gui=True, unit_divisor=1000,
           **kwargs)
    _unset_child()

# Generated at 2022-06-22 05:38:30.098032
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for i in tqdm(range(3), total=3):
        pass
    for i in tqdm(range(3), total=3):
        pass


# Generated at 2022-06-22 05:38:33.550942
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Unit test for method display of class tqdm_rich.
    """
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.update()



# Generated at 2022-06-22 05:38:36.315171
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Tests the `tqdm_rich.reset` classmethod.
    """
    with tqdm(total=0) as bar:
        bar.reset(total=10)
        assert bar.total == 10
        assert bar.n == 0

# Generated at 2022-06-22 05:38:43.760028
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    prog_obj = tqdm_rich(total=10)._prog
    assert(prog_obj.__enter__() == None)
    assert(prog_obj.__exit__(None, None, None) == None)
    assert(prog_obj.add_task("", **dict()) == None)
    assert(prog_obj.reset(total=None) == None)
    assert(prog_obj.update(None, completed=None, description=None) == None)

# Generated at 2022-06-22 05:38:55.173715
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        for _ in trange(10):
            for _ in trange(10):
                pass
    for _ in trange(10, desc="foo"):
        pass
    for _ in trange(10, bar_format="{l_bar} {bar} {r_bar}"):
        pass
    for _ in trange(10, mininterval=0.2):
        pass
    for _ in trange(10, miniters=1):
        pass
    for _ in trange(10, mininterval=0.2, miniters=1):
        pass
    for _ in trange(10, mininterval=0.2, miniters=1, ascii=True):
        pass

# Generated at 2022-06-22 05:38:57.115178
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    for _ in trange(4):
        pass

# Generated at 2022-06-22 05:38:59.507428
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(["a", "b"]):
        pass
    # TODO: how to test clear?

# Generated at 2022-06-22 05:41:45.913344
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """ Test the display of tqdm_rich by checking if the attribute
    `_prog.tasks` is a dict before and after the implementation of display.
    """
    import time
    import types
    import unittest

    class TestTqdm_rich(unittest.TestCase):
        """ Test class for tqdm_rich """

        def test_display(self):
            """ Test display method """
            # Create an instance of tqdm_rich
            test = tqdm_rich(range(10), desc="Test")
            # Check if _prog.tasks is a dict
            self.assertIsInstance(test._prog.tasks, dict)
            # Call display
            test.display()
            # Check if _prog.tasks is still a dict

# Generated at 2022-06-22 05:41:57.682798
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # pylint: disable=protected-access
    assert RateColumn()._render(1, 1, None) == Text("? /s", style="progress.data.speed")
    assert RateColumn()._render(1, 1, 0) == Text("0.0 /s", style="progress.data.speed")
    assert RateColumn()._render(1, 1, .5) == Text("0.5 /s", style="progress.data.speed")
    assert RateColumn()._render(1, 1, 1) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn()._render(1, 1, 10) == Text("10.0 /s", style="progress.data.speed")

# Generated at 2022-06-22 05:42:06.863594
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm import trange
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm

    with tqdm(total=10, leave=False, disable=False) as t:
        for i in range(10):
            t.update()
            t.display()
        assert t.total is 10
        t.display()

    it = iter(range(10))
    with tqdm(it, leave=False, disable=False) as t:
        try:
            while True:
                t.update()
                t.display()
                next(it)
        except StopIteration:
            pass
        assert t.total is 10
        t.display()


# Generated at 2022-06-22 05:42:16.735838
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    old_tqdm = tqdm_rich(desc="old task", total=5)

# Generated at 2022-06-22 05:42:20.699241
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    out = StringIO()
    try:
        # Method clear() is not defined in tqdm
        std_tqdm(range(10), file=out).clear()
    except AttributeError:
        pass
    tqdm(range(10), file=out).clear()
    assert out.getvalue() == ''

# Generated at 2022-06-22 05:42:21.647583
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pass

# Generated at 2022-06-22 05:42:24.356084
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert (FractionColumn().render(Progress.dummy_task)) == Text(
        "0.0/0.0 ",
        style="progress.download")

# Generated at 2022-06-22 05:42:33.944587
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # Converted from `tqdm.tests.test_tqdm`

    # Ensure correct exceptions types
    with trange(10) as t:
        assert isinstance(t, tqdm_rich)
    try:
        with trange(10) as _:
            pass
    except TypeError as e:
        assert "__enter__" in str(e)
    else:
        assert False  # pragma: no cover
    # Ensure correct exceptions types
    try:
        with trange(10) as _:
            raise KeyboardInterrupt
    except KeyboardInterrupt:
        pass
    else:
        assert False  # pragma: no cover
    try:
        with trange(10) as _:
            raise Exception
    except Exception:
        pass
    else:
        assert False

# Generated at 2022-06-22 05:42:42.256224
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().unit_scale == False
    assert FractionColumn().unit_divisor == 1000
    assert FractionColumn(True).unit_scale == True
    assert FractionColumn(True).unit_divisor == 1000
    assert FractionColumn(True, 1024).unit_scale == True
    assert FractionColumn(True, 1024).unit_divisor == 1024
    assert FractionColumn(False, 1024).unit_scale == False
    assert FractionColumn(False, 1024).unit_divisor == 1024


# Generated at 2022-06-22 05:42:51.020879
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)