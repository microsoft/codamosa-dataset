

# Generated at 2022-06-22 05:33:08.696152
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from tqdm import tqdm, format_interval
    import sys
    import functools

    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    from tqdm.rich.progress_format import FractionColumn

    # Unit test for constructor of class FractionColumn
    format = (
        "[progress.description]{task.description}",
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"
    )

    console = Console()

    with console.progress(*format) as progress:

        with tqdm(total=200, file=sys.stderr) as _tqdm:  # pylint: disable=unused-variable

            for _ in range(100):
                progress.update(50)

# Generated at 2022-06-22 05:33:18.612607
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(range(10), disable=True)
    task.total = 10.21
    task.n = 5.8946
    assert FractionColumn().render(task) == Text(
        "5.9/10.2 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text(
        "5.9/10.2 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text(
        "0.00/0.01 K", style="progress.download")


# Generated at 2022-06-22 05:33:30.247902
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Test unit=''
    rate_column = RateColumn()
    assert rate_column.unit == ''
    # Test unit_scale=False
    rate_column = RateColumn(unit='b')
    assert rate_column.unit_scale == False
    assert rate_column.unit_divisor == 1000
    # Test unit_scale=True
    rate_column = RateColumn(unit='b', unit_scale=True)
    assert rate_column.unit_scale == True
    assert rate_column.unit_divisor == 1000
    # Test unit_divisor=1024
    rate_column = RateColumn(unit='b', unit_scale=True, unit_divisor=1024)
    assert rate_column.unit_scale == True
    assert rate_column.unit_divisor == 1024
    # Test rate_column.

# Generated at 2022-06-22 05:33:39.565155
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import re
    rate = RateColumn()
    rate.width = 10
    test = rate.render(tqdm_rich(total=10))
    assert test.style == "progress.data.speed"
    assert re.sub(r'[0-9]', '#', test.text) == '#.# ##/s'

    rate.width = 15
    test = rate.render(tqdm_rich(total=10))
    assert test.style == "progress.data.speed"
    assert re.sub(r'[0-9]', '#', test.text) == '#.# ###/s'


# Generated at 2022-06-22 05:33:43.740539
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    #
    # Test tqdm_rich.clear on its own
    #
    a = tqdm_rich()
    a.clear()
    #
    # Test tqdm_rich.clear in a tqdm
    #
    for _ in tqdm(range(100)):
        a.clear()
        tqdm.write(' ')


# Generated at 2022-06-22 05:33:46.174591
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=1) as t:
        t.close()
    assert t.n == 1


# Generated at 2022-06-22 05:33:50.981922
# Unit test for function trange
def test_trange():  # pragma: no cover
    for i in trange(4):
        assert i == 0
        break
    for _ in trange(1, 4):
        pass
    for _ in trange(0):
        pass  # pragma: no cover
    for _ in trange(0, 1):
        pass  # pragma: no cover



# Generated at 2022-06-22 05:33:53.869786
# Unit test for function trange
def test_trange():
    for _ in trange(10, desc="Hello World"):
        pass


# Generated at 2022-06-22 05:34:05.394170
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import math
    task = object()
    task.completed = 20
    task.total = 100
    fc = FractionColumn()
    style = fc.render(task)
    assert style == Text("20.0/100.0", style="progress.download")

    task.completed = 2000
    task.total = 100
    fc = FractionColumn()
    style = fc.render(task)
    assert style == Text("2,000.0/100.0", style="progress.download")

    task.completed = 2000000
    task.total = 100000
    fc = FractionColumn()
    style = fc.render(task)
    assert style == Text("20.0/10.0 K", style="progress.download")


# Generated at 2022-06-22 05:34:17.117990
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(Progress(rate=1)).text == "1 B/s"
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1024).render(Progress(rate=1)).text == "1.00 B/s"
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1024).render(Progress(rate=1024)).text == "1.00 K/s"
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1024).render(Progress(rate=10240)).text == "10.00 K/s"

# Generated at 2022-06-22 05:34:25.973140
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(0) as pbar:
        assert pbar.disable is True
        assert pbar.leave is False
        assert pbar.clear() is None
        pbar.disable = False
        assert pbar.disable is False
        assert pbar.clear() is None

# Generated at 2022-06-22 05:34:37.664636
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from .std import tqdm
    from .std import trange
    from .std import tqdm_pandas
    from .std import tqdm_gui
    from .std import tgrange
    from .std import tnrange
    from .std import tqdm_notebook
    import pandas as pd
    import numpy as np
    import time
    import warnings

    with warnings.catch_warnings():
        # https://docs.python.org/3.6/library/warnings.html#testing-warnings
        warnings.simplefilter("ignore", ResourceWarning)
        # https://github.com/tqdm/tqdm/issues/484
        tqdm.monitor_interval = 0

        # tqdm

# Generated at 2022-06-22 05:34:42.550718
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    assert rate_column.get_width(None) == 7
    assert rate_column.render(None).text == "? s/s"


# Generated at 2022-06-22 05:34:53.608815
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import FormatCustomText

    # Test human readable transfer speed 1
    custom = FormatCustomText(fmt=dict(
        rate="{rate:.2f} {unit}/s", unit="bytes", unit_scale=False, unit_divisor=1024))
    rate_column = RateColumn(unit=custom.unit, unit_scale=custom.unit_scale, unit_divisor=custom.unit_divisor)
    assert rate_column.render({'speed': 1024}) == Text("1.00 bytes/s", style="progress.data.speed")

    # Test human readable transfer speed 2
    custom = FormatCustomText(fmt=dict(
        rate="{rate:.2f} {unit}/s", unit="bytes", unit_scale=False, unit_divisor=1000))

# Generated at 2022-06-22 05:34:56.016032
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Perform unit test for method close of class tqdm_rich
    """
    with tqdm_rich(total=5) as bar:
        for i in range(5):
            bar.update(1)
    assert True

# Generated at 2022-06-22 05:35:00.072969
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="x", unit_scale=True, unit_divisor=1024)
    assert r.unit == "x"
    assert r.unit_scale == True
    assert r.unit_divisor == 1024
    # TODO: Test on render

# Generated at 2022-06-22 05:35:02.678260
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    bar = tqdm_rich(disable=True)
    bar.clear()

# Generated at 2022-06-22 05:35:06.561097
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test raising exception in tqdm_rich.clear()."""
    with tqdm_rich(total=3) as t:
        t.clear()
        assert True

# Generated at 2022-06-22 05:35:17.109187
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tests import pretest_posttest
    import copy
    from .std import tqdm as std_tqdm

    def tqdm_rich_display_test(__test, __tqdm):
        for n in reversed(__test.xnums):
            __tqdm.update(n - __tqdm.n)  # Test update(delta=n)
            __tqdm.update()  # Test update(delta=1)
        __tqdm.update(__test.total - __tqdm.n)  # Test update(delta=total)
        return __tqdm.n

    # Test Set 1

# Generated at 2022-06-22 05:35:29.284130
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # RateColumn.render is tested through tqdm_rich

    # Asserting the results gives the same behavior of filesize.pick_unit_and_suffix
    test_cases = [
        (1, [""], 1, (1, "")),
        (1000, ["", "K"], 1000, (1, "K")),
        (1024, ["", "K"], 1000, (1024, "K")),
        (1000, ["", "K"], 1024, (1, "K")),
        (1024, ["", "K"], 1024, (1, "K")),
    ]
    for test_case in test_cases:
        assert filesize.pick_unit_and_suffix(test_case[0], test_case[1], test_case[2]) == test_case[3]



# Generated at 2022-06-22 05:35:37.852763
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich([1, 2, 3, 4], total=10)
    del t

# Generated at 2022-06-22 05:35:43.204581
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .std import tqdm as std_tqdm
    with std_tqdm(total=10, gui=True) as t:
        for i in range(10):
            t.set_description(f"description {i}")
            t.set_postfix(f"postfix {i}")
            t.update()
    assert t.disable is False



# Generated at 2022-06-22 05:35:45.770146
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pbar = tqdm_rich(10)
    for _ in pbar:
        pbar.display()
        pbar.update()
    pbar.close()
    assert str(pbar)

# Generated at 2022-06-22 05:35:55.491359
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    import gc
    collect_objects = tqdm_rich._instances.copy()

    t = tqdm_rich(total=1,unit_scale=True)
    assert t.desc == ""
    assert t.unit_scale is True
    assert t.unit_divisor is 1000
    t.update(0)
    assert t.format_dict["total"] == 1
    t.update(1)
    assert t.format_dict["total"] == 1
    t.close()
    assert collect_objects.issubset(tqdm_rich._instances)
    assert gc.collect() == 0


# Generated at 2022-06-22 05:36:07.888613
# Unit test for method render of class FractionColumn

# Generated at 2022-06-22 05:36:10.156364
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class _Task(object):
        def __init__(self, total, completed):
            self.total = total
            self.completed = completed

    task = _Task(100, 10)
    fc = FractionColumn()
    fc.render(task) == '0.1/1.0'

# Generated at 2022-06-22 05:36:12.961737
# Unit test for function trange
def test_trange():
    """Test trange."""
    from .std import tqdm
    for _ in tqdm(trange(4)):
        pass



# Generated at 2022-06-22 05:36:21.979668
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test for method close of class tqdm_rich
    """
    from .utils import _supports_unicode
    assert _supports_unicode()
    from .utils import _range
    from rich.progress import Progress
    from shutil import get_terminal_size
    ts = get_terminal_size()

# Generated at 2022-06-22 05:36:26.801721
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Tests the constructor of class RateColumn."""
    c = RateColumn()
    # c.unit
    assert c.unit == "", "unit attribute not default empty, got {}".format(c.unit)
    c = RateColumn(unit="ps")
    # c.unit
    assert c.unit == "ps", "unit attribute not overwritten, got {}".format(c.unit)

# Generated at 2022-06-22 05:36:29.099589
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Disable tqdm_gui
    tqdm_rich(total=100)

# Generated at 2022-06-22 05:36:44.259800
# Unit test for function trange
def test_trange():
    from tqdm.contrib.test_utils import closing
    from .gui import tgrange, tqrange  # noqa
    with closing(tgrange(4)) as t:
        for i in t:
            for j in range(4):
                for k in t:
                    for l in tqrange(4):
                        for m in tgrange(4):
                            for n in tqrange(4):
                                pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 05:36:45.542803
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn()) == ''

# Generated at 2022-06-22 05:36:56.326907
# Unit test for function trange
def test_trange():
    """Test for trange()."""
    import logging
    from .utils import _test_closing
    from .utils import _test_iterable_over_slice
    from .utils import _test_reset_leave
    from .utils import _test_total_when_finalizing
    from .utils import _test_postfix
    from .utils import _test_write

    with _test_closing():
        for _ in trange(4, leave=True):
            pass

    with _test_closing():
        for _ in trange(0, 4, leave=True):
            pass

    with _test_closing():
        for _ in trange(1, leave=True):
            pass

    with _test_closing():
        for _ in trange(1, 2, 3, leave=True):
            pass

   

# Generated at 2022-06-22 05:36:58.884331
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Tests tqdm_rich GUI"""
    try:
        list(tqdm_rich(range(10)))
    except Exception as e:
        raise TqdmExperimentalWarning(
            "tqdm_rich() raised an exception.\n{}".format(e))

# Generated at 2022-06-22 05:37:09.076980
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=100, ncols=400, mininterval=0.0)
    task.update(25)
    _speed = RateColumn().render(task)
    speed = _speed.text
    assert speed == "0.0 /s"
    task.update(50)
    _speed = RateColumn().render(task)
    speed = _speed.text
    assert speed == "1.0 /s"
    task.update(75)
    _speed = RateColumn().render(task)
    speed = _speed.text
    assert speed == "1.0 /s"
    task.update(100)
    _speed = RateColumn().render(task)
    speed = _speed.text
    assert speed == "1.0 /s"

# Generated at 2022-06-22 05:37:13.207602
# Unit test for function trange
def test_trange():
    from .std import format_interval

    with trrange(4) as t:
        for i in t:
            sleep_time = format_interval(1. / (i + 2))
            t.set_description(f"ETA: {format_interval(t.eta)}")
            time.sleep(sleep_time)

# Generated at 2022-06-22 05:37:22.557526
# Unit test for function trange
def test_trange():
    """
    Tests that trange and tqdm_rich function correctly.
    """
    sum1, sum2 = 0, 0
    with trange(10) as _t:
        for i in _t:
            sum1 += i
            if i % 2:
                sum2 += i
                _t.set_description('odd %i' % i)  # test set_description
            else:
                _t.set_description('even')  # test set_description('')
            _t.set_postfix(i=i, refresh=False)  # test set_postfix

    assert sum1 == sum([i for i in range(0, 10)])
    assert sum2 == sum([i for i in range(0, 10, 2)])

# Generated at 2022-06-22 05:37:30.400965
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    >>> from rich import print
    >>> from tqdm.rich.progress import Progress
    >>> progress = Progress()
    >>> progress.add_task("test", total=10)
    >>> RateColumn(unit="B").render(progress)
    <Progress.data.speed: 0.00 B/s>
    """
    pass

# Generated at 2022-06-22 05:37:40.119339
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    import sys
    import time

    with tqdm(total=100) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(10)
    assert hasattr(pbar, '_task_id')

    pbar = tqdm(total=10)
    pbar.update()
    pbar.close()
    assert not hasattr(pbar, '_task_id')

    pbar = tqdm(total=10, file=sys.stdout)
    pbar.update()
    pbar.close()
    assert not hasattr(pbar, '_task_id')

    pbar = tqdm(total=10)
    pbar.update(5)
    pbar.close()
    assert not has

# Generated at 2022-06-22 05:37:41.818862
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for _ in tqdm([1, 2]):
        pass



# Generated at 2022-06-22 05:37:52.654763
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Tests the display method of tqdm_rich."""
    with tqdm_rich(total=1, miniters=1,
                   desc='rich.progress test') as t:
        t.display()
        t.update()
        t.update(1)

# Generated at 2022-06-22 05:37:57.135704
# Unit test for function trange
def test_trange():
    """Test trange"""
    progress = tqdm.trange(10)
    assert isinstance(progress, tqdm_rich)


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:38:06.209852
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from .gui import tgrange

    for _range_, max_, unit in ((tgrange, 2000, ''), (trange, 2000, ''),
                                (xrange, 2000, 'x')):
        res = sum(tqdm_rich(_range_(max_, unit=unit), unit=unit, unit_scale=True,
                            leave=True, dynamic_ncols=True))
        assert res == max_ * (max_ - 1) / 2
        res = sum(tqdm_rich(_range_(max_), unit=unit, unit_scale=True,
                            leave=True, dynamic_ncols=True))
        assert res == max_ * (max_ - 1) / 2

# Generated at 2022-06-22 05:38:10.143528
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich"""
    from time import sleep
    for _ in tqdm_rich(range(10), desc='test_tqdm_rich_display'):
        sleep(0.2)

# Generated at 2022-06-22 05:38:13.818691
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit='', unit_scale=False, unit_divisor=1000)
    assert rate_column.render(None) == Text('? /s', style='progress.data.speed')

# Generated at 2022-06-22 05:38:25.719627
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Define a task
    task = {'speed': 100, 'completed': 10, 'total': 50}
    # Define a tuple of RateColumn
    rate_column_list = (
        RateColumn(unit_scale=True, unit_divisor=1000),
        RateColumn(unit_scale=True, unit_divisor=1000, unit="/s"),
        RateColumn(unit_scale=False, unit_divisor=1000),
        RateColumn(unit_scale=False, unit_divisor=1000, unit="/s"),
    )
    # Calculate and compare the result
    rate_column_results = (
        "100.0  /s",
        "100.0 K/s",
        "100   ",
        "100 K"
    )

# Generated at 2022-06-22 05:38:29.742160
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit='M', unit_scale=False, unit_divisor=1000)
    class FakeTaskClass:
        completed = 5
        total = 100
        speed = 50000
    
    rate_column.render(FakeTaskClass)

# Generated at 2022-06-22 05:38:31.894528
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in trange(10, desc="test", leave=True, unit_scale=True, unit_divisor=1000):
        pass
    tqdm_rich.reset(total=12, desc="new test", unit='B')
    for i in trange(10, desc="test", leave=True, unit_scale=True, unit_divisor=1000):
        pass

# Generated at 2022-06-22 05:38:38.968458
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time

    # HACK: expectedly raise Exception if we cannot
    #  delete the attribute display. This is because
    #  we are not yet in the main thread, so Rich
    #  will raise an Exception
    t = tqdm_rich(range(2), leave=True)
    try:
        del t.display
    except AttributeError:
        pass
    else:
        raise

    # sleep for a bit to let Rich finish processing
    time.sleep(0.5)

    try:
        del t.display
    except Exception:
        pass
    else:
        raise AttributeError("tqdm_rich.display method will not be deleted!"
                             " Please suppress this Exception in Rich!")

# Generated at 2022-06-22 05:38:39.588514
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn()

# Generated at 2022-06-22 05:39:04.244047
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import shutil
    cols, _ = shutil.get_terminal_size()
    progress = (
        "",
        BarColumn(bar_width=None, show_time_left=False),
        Text(' '),
        Text('{task.description}', style="dim"),
        Text(' '),
        FractionColumn(unit_scale=True, unit_divisor=1000),
        Text(' '),
        RateColumn(unit='B', unit_scale=True, unit_divisor=1000),
    )
    with Progress(*progress, transient=True,
                  console=get_console(width=cols),
                  width=cols) as prog:
        for _ in trange(10, desc='🎉', total=10, progress=prog):
            pass



# Generated at 2022-06-22 05:39:13.151378
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    progress = Progress("{task.description:<40}",
                        BarColumn(bar_width=None),
                        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
                        ",", RateColumn(unit="B", unit_scale=True), "]")
    progress.__enter__()
    task_id = progress.add_task("downloading...", total=12345678)
    progress.update(task_id, completed=1234, speed=12345678)
    progress.__exit__(None, None, None)

# Generated at 2022-06-22 05:39:15.346210
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(10):
        pass



# Generated at 2022-06-22 05:39:18.240716
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    assert rate_column.unit == ''
    assert rate_column.unit_scale == False
    assert rate_column.unit_divisor == 1000

# Generated at 2022-06-22 05:39:19.903521
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t1 = tqdm(range(3))
    t1.clear()
    t2 = tqdm(range(3), disable=True)
    t2.clear()



# Generated at 2022-06-22 05:39:31.356375
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    # Default argument test
    expected_result = {
        'desc': '',
        'total': 100,
        'unit': 'it',
        'unit_scale': False,
        'unit_divisor': 1000,
        'dynamic_ncols': True,
        'leave': False,
        'miniters': None,
        'mininterval': 1.0
    }

    # Assertion for default argument
    assert (tqdm_rich().format_dict == expected_result)
    # Assertion for reset argument
    assert (tqdm_rich().reset().format_dict == expected_result)

    # Assertion for argument with dynamic_ncols = False
    expected_result['dynamic_ncols'] = False

# Generated at 2022-06-22 05:39:40.356560
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich.console
        rich.console.Console(record=True)
        console = rich.console.Console()
    except ImportError:
        raise ImportError("rich is not installed.")

    for i in tqdm_rich(range(10)):
        if i > 5:
            for i in range(10):
                print("")
            tqdm_rich.clear()
            console.clear()
            for i in range(10):
                print("")
            tqdm_rich.clear()
            console.clear()
            print("")
            tqdm_rich.clear()
            console.clear()

# Generated at 2022-06-22 05:39:42.689134
# Unit test for function trange
def test_trange():
    for _ in trange(4, leave=False, desc="Test"):
        pass



# Generated at 2022-06-22 05:39:52.056572
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    with trange(3) as t:
        for i in t:
            assert i == t.n - 1  # -1 because tqdm counts from 1
        assert t.n == 3


if __name__ == "__main__":
    from time import sleep

    with trange(10, desc='test') as t:
        for i in t:
            assert i == t.n - 1  # -1 because tqdm counts from 1
            sleep(0.1)
        assert t.n == 10

# Generated at 2022-06-22 05:39:54.999921
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert column.unit_scale == False
    assert column.unit_divisor == 1000

# Generated at 2022-06-22 05:40:59.942487
# Unit test for function trange
def test_trange():
    """Test function tqdm_rich(range(...))."""
    list(tqdm_rich(range(3)))

# Generated at 2022-06-22 05:41:10.888250
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from contextlib import contextmanager
    from io import StringIO

    try:
        from rich.console import Console
    except ImportError:
        Console = None

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (new_out, new_err):
        pbar = tqdm_rich(total=1000)
        for i in range(3):
            pbar.update(i)
            p

# Generated at 2022-06-22 05:41:19.326088
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from pytest import raises

    t = tqdm_rich(total=2)
    assert t.unit_scale == False
    t.n = 1
    t.close()
    with raises(TqdmExperimentalWarning):
        t = tqdm_rich(total=2, disable=False)
    t.close()
    with raises(TypeError):
        tqdm_rich(total=2, disable=None)
    t.close()
    t = tqdm_rich(total=2, disable=True)
    t.n = 1
    t.close()
    t = tqdm_rich(total=2, mininterval=0, leave=False)
    t.n = 1
    t.close()

# Generated at 2022-06-22 05:41:29.154544
# Unit test for function trange
def test_trange():
    """test tqdm.rich.trange with and without rich.progress GUI"""
    import sys
    import time
    from .gui import tgrange
    from .std import tnrange

    d = tgrange(10, 0)
    assert d._prog is not None

    d = tnrange(10, 0)
    assert d._prog is None

    d = tgrange(10, 0, leave=True)
    assert not d._prog.transient

    d = tgrange(10, 1)
    time.sleep(0.01)
    assert d._prog.is_alive()
    d.close()
    assert not d._prog.is_alive()

    d = tgrange(10)
    sys.stderr.flush()
    assert not d.disable

# Generated at 2022-06-22 05:41:32.895044
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    print(fraction_column.render(task=None))
    print(fraction_column.render(task=100))

# Generated at 2022-06-22 05:41:34.681537
# Unit test for function trange
def test_trange():
    """Test trange"""
    with trange(1, 3) as t:
        assert len(t) == 2

# Generated at 2022-06-22 05:41:36.242212
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich([])
    t.close()
    return t


# Generated at 2022-06-22 05:41:41.220022
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    a = FractionColumn()
    print(a)
    b = FractionColumn(unit_scale=False)
    print(b)
    c = FractionColumn(unit_divisor=1024)
    print(c)
    d = FractionColumn(unit_scale=False, unit_divisor=1024)
    print(d)


# Generated at 2022-06-22 05:41:52.974122
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test RateColumn with no unit
    start = 4.0
    end = 6.0
    value = 1.0
    total = 2.0
    unit = ""
    unit_scale = False
    unit_divisor = 1

    rc = RateColumn(unit = unit, unit_scale = unit_scale, unit_divisor = unit_divisor)
    task = rc.Task(start, end, value, total)

    assert rc.render(task).text == "0.5 B/s"

    # Test RateColumn with unit K
    start = 4000000.0
    end = 6000000.0
    value = 1000000.0
    total = 2000000.0
    unit = "K"
    unit_scale = False
    unit_divisor = 1


# Generated at 2022-06-22 05:41:55.669790
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [None, 1, 10]:
        with tqdm(total=total) as bar:
            bar.reset(total=total)