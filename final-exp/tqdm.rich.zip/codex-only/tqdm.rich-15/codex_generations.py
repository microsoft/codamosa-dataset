

# Generated at 2022-06-24 10:25:31.210678
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from os import get_terminal_size
    t = tqdm_rich(10)
    assert t.n == 0
    assert t.total == 10
    assert t._prog.task_count == 1

    t.reset(5)
    assert t.n == 0
    assert t.total == 5
    assert t._prog.task_count == 1

    t.reset()
    assert t.n == 0
    assert t.total == 5
    assert t._prog.task_count == 1

    ts = get_terminal_size()

# Generated at 2022-06-24 10:25:41.125762
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(0) == Text("0.0/0.0 ", style="progress.download")

    column = FractionColumn(10, True)
    assert column.render(0) == Text("0.0/0.0 ", style="progress.download")

    column = FractionColumn(1000, True)
    assert column.render(0) == Text("0.0/0.0 ", style="progress.download")

    column = FractionColumn(10, False)
    assert column.render(0) == Text("0.0/0.0 ", style="progress.download")

    column = FractionColumn(1000, False)
    assert column.render(0) == Text("0/0 ", style="progress.download")

    column = FractionColumn(unit_scale=True)
    assert column

# Generated at 2022-06-24 10:25:47.119542
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    completed = 150
    total = 2300
    unit, suffix = filesize.pick_unit_and_suffix(
        total,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        fc.unit_divisor,
    )
    assert fc.render({'completed': completed, 'total': total}) == Text(
        f"{completed/unit:,.{0}f}/{total/unit:,.{0}f} {suffix}",
        style="progress.download")
    

# Generated at 2022-06-24 10:25:51.830458
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich import progress
    progress.use_debug = True
    progress.log_level = 'TRACE'
    import time
    import numpy as np
    for i in tqdm_rich(np.arange(0,10), ascii=True, bar_char='█',
                       bar_width=2, desc="new line testing", leave=True):
        time.sleep(1)

# Generated at 2022-06-24 10:25:54.955600
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    with tqdm_rich(total=10) as t:
        for i in _range(10):
            t.update()
            t.clear()



# Generated at 2022-06-24 10:26:04.304852
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import re
    import random
    from .utils import _range

    random.seed(1)
    for speed in _range(10) + [random.randint(0, 10**5) for _ in range(10)]:
        # speed = 0
        rate_column = RateColumn()
        if speed == 0:
            assert re.match('^\? [a-zA-Z0-9]*/s$', rate_column.render("0")), f"RateColumn.render() with speed = {speed}"
        # speed = 1
        rate_column = RateColumn()
        if speed == 1:
            assert re.match('^1 [a-zA-Z0-9]*/s$', rate_column.render("1")), f"RateColumn.render() with speed = {speed}"
        # speed = 999
       

# Generated at 2022-06-24 10:26:05.371756
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(0)
    t.display()

# Generated at 2022-06-24 10:26:12.366159
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for `tqdm.rich.tqdm_rich.clear` method."""
    try:
        std_tqdm.write = print
        tqdm_rich.write = print
        with tqdm_rich(total=5) as t:  # pragma: no cover
            for i in t:
                t.clear()
                print(i)
                t.refresh()
    finally:
        delattr(std_tqdm, 'write')
        delattr(tqdm_rich, 'write')

# Generated at 2022-06-24 10:26:16.765751
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(
        description="lorem",
        completed=123,
        total=456
    )
    assert FractionColumn(unit_scale=True).render(task).text == "123.0/456 K"
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task).text == "0.1/0.4 M"
    assert FractionColumn(unit_scale=False).render(task).text == "123/456"

# Generated at 2022-06-24 10:26:28.428755
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from decimal import Decimal
    import datetime as dt

    # data structure
    task = {
        "completed": "0",
        "total": "0",
        "speed":  0,
        "elapsed": None,
        "eta": None,
        "description": None,
        "dynamic_ncols": None,
        "position": 0,
    }

    # general
    progress = Progress(
        "[progress.description]{task.description}", BarColumn(),
        RateColumn(unit="B", unit_scale=False, unit_divisor=1000),
    )
    task['description'] = "updating files"
    with progress:
        task_id = progress.add_task(**task)
        progress.update(task_id, speed=100)
    assert progress._get_task

# Generated at 2022-06-24 10:26:33.290837
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraccol = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fraccol.unit_scale == True
    assert fraccol.unit_divisor == 1000
    fraccol = FractionColumn()
    assert fraccol.unit_scale == False
    assert fraccol.unit_divisor == 1000

# Generated at 2022-06-24 10:26:35.101640
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .gui import tgrange
    l = list(tgrange(20))
    assert l == list(range(20))


if __name__ == "__main__":
    # import doctest
    # doctest.testmod()
    test_tqdm_rich_clear()

# Generated at 2022-06-24 10:26:39.766776
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test function for method display of class tqdm_rich.
    """
    import sys
    import time
    sys.stdout = open('/dev/null', 'w')
    try:
        with tqdm_rich(10) as t:
            for __ in range(10):
                t.display()
                time.sleep(1)
    finally:
        sys.stdout.close()
        sys.stdout = sys.__stdout__

# Generated at 2022-06-24 10:26:46.007194
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tgrange
    from .std import trange

    for t in (tgrange, trange):
        for i in t(4):
            assert (i == 0 or i == 1 or i == 2 or i == 3)


if __name__ == '__main__':
    from .gui import tgrange
    from .std import trange

    for t in (tgrange, trange):
        for i in t(4):
            print(i)

# Generated at 2022-06-24 10:26:47.242379
# Unit test for function trange
def test_trange():
    with trange(1) as t:
        assert t.disable is False

# Generated at 2022-06-24 10:26:57.398193
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    with tqdm(total=100) as t:
        t.reset(total=200)
        for i in range(20):
            time.sleep(0.1)
        t.reset()

    print(t)
    assert t.total == 100

    with tqdm_rich(total=100) as t:
        t.reset(total=200)
        for i in range(20):
            time.sleep(0.1)
        t.reset()

    print(t)
    assert t.total == 100

    with trange(100) as t:
        t.reset(total=200)
        for i in range(20):
            time.sleep(0.1)
        t.reset()

    print(t)
    assert t.total == 100

# Generated at 2022-06-24 10:27:06.552867
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test to check constructor of `RateColumn`."""
    r = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert r.unit_scale == True
    assert r.unit_divisor == 1000
    assert r.unit == "B"
    assert r.__doc__ == "Renders human readable transfer speed."
    assert r.__str__() == "<RateColumn>"
    assert r.__class__ == RateColumn
    assert r.__module__ == "tqdm.rich"
    assert r.__name__ == "RateColumn"
    assert r.__bases__ == (ProgressColumn, )


# Generated at 2022-06-24 10:27:08.120681
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    _ = RateColumn()

# Generated at 2022-06-24 10:27:18.493081
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Testing when speed is None
    column = RateColumn(unit="B")
    assert column.render(None) == "? B/s"
    # Testing when the unit is the unit of bytes
    column = RateColumn(unit_scale=False)
    assert column.render(100) == "100 B/s"
    # Testing when the unit is the unit of bytes
    column = RateColumn(unit_scale=False, unit="B")
    assert column.render(100) == "100 B/s"
    # Testing when the unit is the unit of bytes
    column = RateColumn(unit_scale=False, unit_divisor=1024)
    assert column.render(1000) == "976.56 B/s"
    # Testing when the unit is the unit of kilobytes

# Generated at 2022-06-24 10:27:23.742878
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from tqdm.rich import tqdm
    from math import inf
    import time
    import random
    t = tqdm(total=20, unit_scale=True, unit_divisor=1024)
    for _ in range(20):
        time.sleep(random.random() * 0.01)
        t.update(1)
    t.close()

# Generated at 2022-06-24 10:27:32.970167
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn.
    """
    # Empty not None
    assert RateColumn().render(0) == Text("? ", style="progress.data.speed")
    assert RateColumn().render(100) == Text("100 ", style="progress.data.speed")

    # Unit is B
    assert RateColumn().render(100) == Text("100 B/s", style="progress.data.speed")
    assert RateColumn().render(2000) == Text("2,000 B/s", style="progress.data.speed")
    assert RateColumn().render(2000000) == Text("2.00 M/s", style="progress.data.speed")
    assert RateColumn().render(2000000000) == Text("2.00 G/s", style="progress.data.speed")
    assert RateColumn().render(2000000000000) == Text

# Generated at 2022-06-24 10:27:35.832404
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        tqdm_rich([1,2,3]).clear()
    except NotImplementedError:
        pass

# Generated at 2022-06-24 10:27:41.515519
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    task = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", column, "]")
    task.__enter__()
    task_id = task.add_task("", smoothing=0.1, total=10)
    for i in range(0, 10):
        task.update(task_id, completed=i)

# Generated at 2022-06-24 10:27:44.393123
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=10, disable=False) as pbar:
        for i in pbar:
            pbar.display()
            pbar.update()
            time.sleep(0.01)

# Generated at 2022-06-24 10:27:53.593819
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class dummyClass(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    a = FractionColumn()
    b = a.render(dummyClass(0, 200))
    c = a.render(dummyClass(500, 3000))
    d = a.render(dummyClass(800000000, 900000000))
    assert b == Text('0/200 ', style='progress.download')
    assert c == Text('0.2/3.0 ', style='progress.download')
    assert d == Text('0.9/1.0 G', style='progress.download')


# Generated at 2022-06-24 10:27:56.689766
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    def f():
        for i in tqdm_rich(range(1000000)):
            pass
        return i
    i = f()
    assert i == 999999, i

# Generated at 2022-06-24 10:28:00.864292
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = progress_bar_1 = RateColumn(unit='B', unit_scale=True, unit_divisor=1000)

    assert "[" in progress_bar_1.render(task=None)


if __name__ == '__main__':
    test_RateColumn_render()

# Generated at 2022-06-24 10:28:09.330873
# Unit test for function trange
def test_trange():
    """Test for tqdm.rich.trange"""
    from rich.console import Console
    from rich.progress import Progress

    # Test simple case
    for _ in trange(3):
        pass

    # Test empty case
    for _ in trange(0):
        pass

    # Test manual iterations
    for i in trange(4, 0):
        if i == 2:
            break

    # Test manual leave
    for i in trange(4):
        if i == 2:
            break
    # and without leave
    for i in trange(4, leave=False):
        if i == 2:
            break

    # Test console
    console = Console()

    @tqdm_rich(total=10, console=console)
    def my_func(a, b):
        return a + b

    my

# Generated at 2022-06-24 10:28:13.701765
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    inline_bench_object = tqdm_rich(total=10, desc="inline_bench")
    inline_bench_object.reset()  # reset to iteration 0
    assert inline_bench_object.n == 0
    assert inline_bench_object.total == 10

# Generated at 2022-06-24 10:28:16.160782
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    progress = (f"[progress.description]{'desc'}",)
    with tqdm_rich(progress=progress) as tr:
        tr.reset(total=1)
        tr.update(1)

# Generated at 2022-06-24 10:28:20.683939
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm(total=10) as pbar:  # pylint: disable=unused-variable
        assert pbar.__next__() == 0
    pbar = tqdm(total=10)
    assert pbar.__next__() == 0
    pbar.close()

# Generated at 2022-06-24 10:28:30.230649
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn(unit_scale=True)
    assert (rc.render(object()) == Text("? B/s", style="progress.data.speed"))
    rc = RateColumn(unit="B", unit_scale=True)
    assert (rc.render(object()) == Text("? B/s", style="progress.data.speed"))
    rc = RateColumn(unit_scale=False)
    assert (rc.render(object()) == Text("? 1/s", style="progress.data.speed"))
    rc = RateColumn(unit="B", unit_scale=False)
    assert (rc.render(object()) == Text("? 1B/s", style="progress.data.speed"))


# Generated at 2022-06-24 10:28:31.753314
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(list(range(3))).clear()

# Generated at 2022-06-24 10:28:39.725809
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress = Progress()
    progress.update(completed=0, total=500, speed=500)
    progress.update(completed=500, total=2000, speed=1000)
    progress.update(completed=1000, total=3000, speed=3000)
    progress.update(completed=2000, total=5000, speed=5000)
    progress.update(completed=4000, total=10000, speed=10000)
    progress.update(completed=10000, total=50000, speed=50000)

# Generated at 2022-06-24 10:28:43.678371
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for n in trange(3):
        for n in tqdm(range(3)):
            for n in tqdm(range(3), desc='my bar'):
                for n in tqdm(range(3), desc='my bar',
                              unit_scale=False, unit_divisor=1):
                    for n in tqdm(range(3), desc='my bar',
                                  unit_scale=True, unit_divisor=1000):
                        pass

# Generated at 2022-06-24 10:28:44.523608
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    __test_tqdm_rich_reset(tqdm_rich)


# Generated at 2022-06-24 10:28:49.485906
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    with tqdm_rich(unit='B', unit_scale=True) as t:
        for i in range(3):
            t.display()
            t.update(i + 1)
            time.sleep(0.1)

    # clear bar and wait 1 second
    time.sleep(1)

    # reset and expect new bar with range [0, 5)
    t.reset(5)
    for i in range(3):
        t.display()
        t.update(i + 1)
        time.sleep(0.1)

# Generated at 2022-06-24 10:28:54.344296
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
  class A:
    def __init__(self, desc):
      self.n = 0
      self.desc = desc

    def update(self, *_, **__):
      self.n += 1

  with tqdm_rich(A("test"), desc="test") as t:
    t.display()
    t.clear()
    assert t.n == 1

# Generated at 2022-06-24 10:28:59.135790
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    n = 1000000
    with trange(n) as t:
        while t.n < n:
            t.update()


if __name__ == '__main__':  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:29:00.549031
# Unit test for function trange
def test_trange():  # pragma: no cover
    list(trange(10))



# Generated at 2022-06-24 10:29:05.534576
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    kwargs_list = [
        {'unit_scale': True, 'unit_divisor': 1000, 'expected': '4,000.0/4,000.0 '},
        {'unit_scale': True, 'unit_divisor': 1024, 'expected': '3.891/3.891 K'},
        {'unit_scale': False, 'unit_divisor': 1, 'expected': '3,891/3,891 '},
    ]
    for kwargs in kwargs_list:
        col = FractionColumn(**kwargs)
        task = col.render(mock_task)
        assert str(task) == kwargs['expected']



# Generated at 2022-06-24 10:29:09.204280
# Unit test for function trange
def test_trange():
    assert isinstance(trange(10), tqdm)
    assert isinstance(trange(100, 50, -1), tqdm)
    assert list(trange(0)) == []  # Used to throw `ValueError`



# Generated at 2022-06-24 10:29:17.292246
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Test constructor of class FractionColumn
    progress_progresscol = BarColumn(bar_width=None)
    progress_progresscol1 = FractionColumn()
    progress_progresscol2 = FractionColumn(unit_scale=False)
    progress_progresscol3 = FractionColumn(unit_scale=True)
    progress_progresscol4 = FractionColumn(unit_scale=False, unit_divisor=1000)
    progress_progresscol5 = FractionColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-24 10:29:21.898141
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    unit_scale = False
    unit_divisor = 1000
    task = Task(42, 1023)
    assert FractionColumn(unit_scale, unit_divisor).render(task).text == "42/1,023 "
    task = Task(42, 1024)
    assert FractionColumn(unit_scale, unit_divisor).render(task).text == "42/1,024 "
    task = Task(42, 1500)
    assert FractionColumn(unit_scale, unit_divisor).render(task).text == "42/1.5 K"
    task = Task(42, 1500000)

# Generated at 2022-06-24 10:29:24.842120
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test for trange close."""
    with trange(10) as t:
        for i in t:
            pass
    assert t.leave



# Generated at 2022-06-24 10:29:26.467536
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import _range
    for i in trange(3):
        assert i in _range(3)

# Generated at 2022-06-24 10:29:31.522445
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=4) as pbar:
        assert pbar.disable is False
        pbar.n = 2
        pbar.clear()
        assert pbar.disable is False
        pbar.n = 3
    assert pbar.disable is True

# Generated at 2022-06-24 10:29:33.044730
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="B") == "? B/s"

# Generated at 2022-06-24 10:29:38.467443
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    frac_col = FractionColumn()
    assert frac_col.unit_scale == False
    assert frac_col.unit_divisor == 1000
    frac_col = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert frac_col.unit_scale == True
    assert frac_col.unit_divisor == 1024


# Generated at 2022-06-24 10:29:41.033822
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from tqdm.auto import trange  # pragma: no cover
    list(trange(10))

# Generated at 2022-06-24 10:29:47.820437
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn(unit="B")
    rc = r.render
    assert rc(Progress({})) == "\x1b[38;5;46m? B/s\x1b[0m"
    assert rc(Progress({"speed": 0.0})) == "\x1b[38;5;46m0.0 B/s\x1b[0m"
    assert rc(Progress({"speed": 0.1})) == "\x1b[38;5;46m0.1 B/s\x1b[0m"
    assert rc(Progress({"speed": 1})) == "\x1b[38;5;46m1.0 B/s\x1b[0m"

# Generated at 2022-06-24 10:29:52.188863
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import sys

    with tqdm_rich(total=10, file=sys.stdout) as t:
        for i in range(10):
            t.n = i + 1
            t.refresh()

# Generated at 2022-06-24 10:29:57.102522
# Unit test for function trange
def test_trange():  # pragma: no cover
    import time

    total = 1000
    with trange(total) as t:
        for i in t:
            t.set_description("A description ça fait boum")
            t.set_postfix(a=5, b=5.5, c='long message', d=None)
            time.sleep(0.1)

# Generated at 2022-06-24 10:30:01.963120
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=2, desc="test", unit_scale=True) as pbar:
        assert isinstance(pbar, tqdm_rich)
        assert pbar.total == 2
        assert pbar.desc == "test"
        assert pbar.unit_scale is True

# Generated at 2022-06-24 10:30:05.733061
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import _range

    progress = tqdm_rich(_range(1, 5))
    for i in progress:
        progress.reset(total = 5)
        progress.reset()
    progress.close()

# Generated at 2022-06-24 10:30:08.165867
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn.render(tqdm_rich(2, 3)) == Text('0.0/0.0', style='progress.download')

# Generated at 2022-06-24 10:30:11.366687
# Unit test for constructor of class RateColumn
def test_RateColumn():
    col = RateColumn(unit_scale=True, unit_divisor=1000)
    task = getattr(Progress, 'task')
    for i in range(1000):
        setattr(task, 'speed', i)
        assert col.render(task)

# Generated at 2022-06-24 10:30:18.250220
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys, io

    def test_close_method():
        # Create a range
        r = tqdm(range(1000))
        # Get the output from the range
        output = io.StringIO()
        sys.stdout = output
        # Close the range
        r.close()
        # Check for output
        assert "1000" in output.getvalue()

    test_close_method()

# Generated at 2022-06-24 10:30:20.157358
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total = 100) as t:
        t.write_text('Test')


# Generated at 2022-06-24 10:30:26.625930
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    r"""Test tqdm_rich.display."""
    from random import randint
    import time
    n = 10
    with tqdm(total=n) as pbar:
        for i in range(n):
            time.sleep(randint(0, 100) / 1000)
            pbar.update(1)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:30:30.674343
# Unit test for constructor of class RateColumn
def test_RateColumn():
    bar = RateColumn(unit_scale=True, unit_divisor=1000)
    output = bar.render(None)
    assert (output == Text('? ', style='progress.data.speed')), "Failed value == ?"
    assert (output.style == 'progress.data.speed'), "Failed style"



# Generated at 2022-06-24 10:30:36.454320
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test reset total is working."""
    with tqdm(total=10, unit='B', unit_scale=True) as pbar:
        assert pbar.total == 10
        pbar.reset(total=42)
        assert pbar.total == 42

# Generated at 2022-06-24 10:30:43.660036
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.auto import trange
    from time import sleep
    import sys

    for i in trange(10, desc="my bar!", position=0, ncols=80):
        sleep(0.3)
        sys.stdout.write("\r\x1b[K")  # clear line

if __name__ == "__main__":  # pragma: no cover
    # Run test on module import
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:30:45.688812
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test for the method clear of class tqdm_rich."""
    tqdm_rich(1).clear()



# Generated at 2022-06-24 10:30:48.636752
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    import random
    t = tqdm_rich()
    t.n = random.randint(1, 100)
    t.total = random.randint(t.n, 100)
    t.display()
    time.sleep(0.5)

# Generated at 2022-06-24 10:30:51.706056
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t_list = [3, 2, 1]
    t = tqdm_rich(t_list)
    t.clear()
    t.close()

# Generated at 2022-06-24 10:31:00.403308
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.console import Console

    def _get_row_text(console, row):
        """Return text of row from console object.

        Args:
            console: Console object
            row: row in string
        """
        return Markdown(str(console._get_buffer()[row])).render(Panel.DOUBLE)

    console = Console()
    progress = Progress(FractionColumn())
    task = progress.add_task("Task 1", total=100)
    task.update(50)
    progress.render(console=console)
    assert "50/100" in _get_row_text(console, 1)


# Generated at 2022-06-24 10:31:06.398943
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .gui import _supports_unicode
    from .std import tqdm, format_interval
    from time import sleep

    with tqdm(total=10, leave=True,
              bar_format="{l_bar}{bar}{r_bar} ETA: {remaining}"
              "[{elapsed}, {rate_fmt}{postfix}]") as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

    with tqdm(total=10, leave=True, ncols=100) as pbar:
        for i in range(10):
            pbar.set_description("Test")
            sleep(0.1)
            pbar.update(1)


# Generated at 2022-06-24 10:31:10.792091
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    assert column.render(None) == Text("? /s", style="progress.data.speed")
    assert column.render(None) == Text("? /s", style="progress.data.speed")
    # TODO: test the other cases

# Generated at 2022-06-24 10:31:21.641976
# Unit test for constructor of class RateColumn
def test_RateColumn():
    print("Testing class RateColumn...")

    # Create column with specified unit and all unit options False
    assert str(RateColumn(unit="B")) == '? B/s'
    # Create column with specified unit and all unit options True
    assert str(RateColumn(unit="B", unit_scale=True, unit_divisor=2)) == '? B/s'
    # Create column with no unit and all unit options False
    assert str(RateColumn(unit="")) == '? /s'
    # Create column with no unit and all unit options True
    assert str(RateColumn(unit="", unit_scale=True, unit_divisor=2)) == '? /s'

if __name__ == "__main__":
    test_RateColumn()

# Generated at 2022-06-24 10:31:26.920066
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    total = 20000
    unit="KB"
    task = std_tqdm(range(total), total=total, unit=unit, unit_scale=False)
    
    Speed = RateColumn(unit=unit, unit_scale=False)
    for i in range(total):
        task.update(1)
        if i == 2000 or i == 10000 or i == 15000:
            print(Speed.render(task))

# Generated at 2022-06-24 10:31:33.029317
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="unit", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(std_tqdm.tqdm(total=1000, ncols=80)) == "[progress.data.speed]" \
                                                                     "999.0 unit/s"



# Generated at 2022-06-24 10:31:36.793853
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for i in tqdm_rich(range(10)):
        continue
    for i in tqdm_rich(range(10)):
        continue


# Generated at 2022-06-24 10:31:38.462220
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as pbar:
        pbar.clear()
        pbar.update(1)
        pbar.display()

# Generated at 2022-06-24 10:31:43.861903
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn()
    t = type('', (), {'completed': 1, 'total': 4})()
    assert f.render(t) == Text('0.2/0.4 ', style='progress.download')
    t = type('', (), {'completed': 1, 'total': 0})()
    assert f.render(t) == Text('1.0/0.0 ', style='progress.download')

# Generated at 2022-06-24 10:31:47.286468
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=5, desc="test desc") as t:
        t.__enter__()
        t.__exit__(None, None, None)

# Generated at 2022-06-24 10:31:58.961228
# Unit test for function trange
def test_trange():
    """From tqdm/tests/test_tqdm.py"""
    from sys import version_info
    # assert version_info[:2] == (2, 7)
    from time import sleep
    from re import match
    from threading import Thread
    from utils import FormatTracker

    # Test
    for i in trange(4, desc='1st loop', leave=True):
        sleep(0.1)
        for j in trange(5, desc='2nd loop', leave=True, mininterval=100):
            sleep(0.1)
        if i < 1:
            continue
        for j in trange(30, desc='3nd loop'):
            sleep(0.01)

    # Leave Cursor

# Generated at 2022-06-24 10:32:03.582319
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: nocover
    """Test RateColumn class constructor"""
    rate_column = RateColumn(unit="bit", unit_scale=True, unit_divisor=1000)
    assert rate_column.unit == "bit"
    assert rate_column.unit_scale is True
    assert rate_column.unit_divisor == 1000

# Generated at 2022-06-24 10:32:14.595704
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """ Test the method reset of class tqdm_rich """
    import os
    import sys
    import colorama
    import unittest
    import tempfile
    import shutil

    class TqdmRichTestCase(unittest.TestCase):
        def setUp(self):
            self.mydir = tempfile.mkdtemp(prefix="tqdm_rich_test-")
            self.test_file1 = os.path.join(self.mydir, "file1")
            self.test_file2 = os.path.join(self.mydir, "file2")

        def tearDown(self):
            shutil.rmtree(self.mydir)

        def test_reset(self):
            """ Test the method reset of class tqdm_rich """

# Generated at 2022-06-24 10:32:24.326301
# Unit test for function trange
def test_trange():  # pragma: no cover
    import sys
    import time
    with trange(10, ascii=True) as t:
        for i in t:
            t.set_description("Tick %d" % i)
            time.sleep(0.1)
            if i == 2:
                t.set_postfix(a=1, b=2, c=3)
            elif i == 6:
                t.update(4)
            elif i == 8:
                t.close()
                t.update(2)

    with trange(10, desc="foo", ascii=True) as t:
        for i in t:
            t.set_description("Tick %d" % i)
            time.sleep(0.1)
            if i == 2:
                t.set_postfix

# Generated at 2022-06-24 10:32:28.603710
# Unit test for constructor of class RateColumn
def test_RateColumn():
    for unit in ("s", "Ks", "Ms", "Gs", "Ts", "Ps", "Es", "Zs", "Ys"):
        c = RateColumn(unit=unit)
        # print(c.render(None))

if __name__ == "__main__":
    test_RateColumn()

# Generated at 2022-06-24 10:32:29.868746
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="bytes").render(std_tqdm(unit="bytes", disable=True, total=0)).text == "0 bytes/s"

# Generated at 2022-06-24 10:32:32.865885
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest import TestCase, main

    class TestTqdmRichReset(TestCase):
        def test_reset_raises_error(self):
            """Raises error if reset is called before the progressbar can be created."""
            progress = tqdm_rich(disable=True)
            with self.assertRaises(Exception):
                progress.reset(total=10)

    main()

# Generated at 2022-06-24 10:32:39.158342
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch

    with patch('tqdm.rich.display') as mock_display:
        mock_display.update(1, 2, 3)
        assert mock_display.call_count == 1
        mock_display.reset_mock()
        mock_display.update(1)
        mock_display.update(2, 3)
        mock_display.update(1, 2, 3)
        assert mock_display.call_count == 3
        mock_display.reset_mock()
        mock_display.update(kwargx=1)
        assert mock_display.call_count == 0
        mock_display.reset_mock()
        mock_display.update(kwargx=1, kwargy=2)
        assert mock_display.call_count == 0
        mock_display

# Generated at 2022-06-24 10:32:47.599712
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        with Progress(
                "[progress.description]{task.description}"
                "[progress.percentage]{task.percentage:>4.0f}%",
                BarColumn(bar_width=None),
                FractionColumn()) as progress:
            for i in tqdm(range(100), progress=progress, desc="tqdm"):
                pass
    except:
        raise AssertionError


# Generated at 2022-06-24 10:32:53.932935
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    t_1 = tqdm_rich(0)
    t_2 = tqdm_rich(0, disable=True)
    t_3 = tqdm_rich(0, disable=None)
    assert hasattr(t_1, '_prog')
    assert not hasattr(t_2, '_prog')
    assert hasattr(t_3, '_prog')


if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-24 10:33:03.251747
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test case for method render of class FractionColumn.
    """


# Generated at 2022-06-24 10:33:07.331067
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(1)
    t.display(total=1)


if __name__ == "__main__":
    from unittest import TestCase, main

    class TestTqdmRich(TestCase):
        def test_tqdm_rich_display(self):
            t = tqdm_rich(1)
            t.display(total=1)

    main()

# Generated at 2022-06-24 10:33:17.837443
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm import trange
    from tqdm.auto import tqdm

    # Case 1: Disable
    for _tqdm in [tqdm, trange]:
        with _tqdm(disable=True, total=2) as t:
            t.display()
            assert hasattr(t, "_prog") is False

    # Case 2: Leave
    for _tqdm in [tqdm, trange]:
        with _tqdm(total=2, leave=True) as t:
            t.display()
            assert hasattr(t, "_prog") is True

    # Case 3: Not leave
    for _tqdm in [tqdm, trange]:
        with _tqdm(total=2, leave=False) as t:
            t.display()

# Generated at 2022-06-24 10:33:26.686665
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm_rich."""
    import sys
    import tqdm.rich as rich
    from tqdm.utils import _environ_cols_wrapper
    if sys.version_info[0] == 2:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    # disable progressbar for test
    rich._instances.clear()
    with _environ_cols_wrapper(50):
        r = rich.tqdm_rich(range(2),
                           bar_format="{l_bar}{bar} {n_fmt}/{total_fmt}")
        try:
            assert sys.stderr.isatty()
        except AttributeError:
            pass
        ncols = rich.get_term_width()
        assert ncols

# Generated at 2022-06-24 10:33:37.136856
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Observer(object):
        completed = None
        total = None
    observer = Observer()
    class Task(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    task0 = Task(observer.completed, observer.total)

    fraction_column = FractionColumn()
    column_0 = fraction_column.render(task0).text

    observer.completed = 5
    observer.total = 7
    task1 = Task(observer.completed, observer.total)

    column_1 = fraction_column.render(task1).text

    assert column_0 == '0.0/0.0 '
    assert column_1 == '5.0/7.0 '



# Generated at 2022-06-24 10:33:39.837285
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=1) as t:
        assert t._prog.__enter__ is not None
        assert t._task_id is not None
    t.close()
    assert t._prog.__exit__ is not None

# Generated at 2022-06-24 10:33:51.196631
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style

    with Console(handle=True) as console:
        progress = Progress(
            RateColumn(unit="B", unit_scale=True, unit_divisor=1000),
            transient=True,
            auto_refresh=False,
            console=console)
        progress.add_task("Task 1", total=100)
        progress.update(completed=50)

        progress = Progress(
            RateColumn(unit="B", unit_scale=False, unit_divisor=1000),
            transient=True,
            auto_refresh=False,
            console=console)
        progress.add_task("Task 2", total=100)
        progress.update(completed=50)

# Generated at 2022-06-24 10:34:00.405266
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from tqdm._tqdm import _SupportsAbsolute, TqdmSynchronisationWarning
    try:
        from tqdm.auto import trange
    except ImportError:  # pragma: no cover
        from tqdm import trange
    from tqdm.contrib import DummyTqdmFile

    with DummyTqdmFile(mode='w') as f:
        # As fileobj
        # exercise `mininterval` logic
        with tqdm(total=10, file=f) as pbar:
            pbar.update(10)
            pbar.clear()
            pbar.update(10)
            pbar.clear()
            pbar.update(10)
            pbar.close()

        # As context manager

# Generated at 2022-06-24 10:34:04.165028
# Unit test for function trange
def test_trange():
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 3, 2)) == [1]

# Generated at 2022-06-24 10:34:09.620030
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm_rich(range(4)):
        pass
    for i in tqdm_rich([], total=0):
        pass
    t = tqdm_rich(range(4))
    t.reset(total=6)
    for i in t:
        pass
    t = tqdm_rich([], total=0)
    t.reset(total=5)
    for i in t:
        pass

# Generated at 2022-06-24 10:34:13.468798
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in tqdm_rich(range(5), total=10):
        pass
    # reset of total
    for _ in tqdm_rich(range(5), total=10):
        pass
    # reset as a function
    tqdm_rich(range(5), total=10).reset(total=20)

# Generated at 2022-06-24 10:34:17.499404
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 3000
    unit = "B"
    unit_scale = True
    unit_divisor = 1000
    rate_column = RateColumn(unit, unit_scale, unit_divisor)

    rate_column.render(speed)
    output = rate_column.render(speed)
    assert output == 3.0

# Generated at 2022-06-24 10:34:20.448838
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    p = tqdm_rich(range(0, 10))
    p.display()
    p.close()
    assert True

# Generated at 2022-06-24 10:34:23.646222
# Unit test for function trange
def test_trange():
    with trange(2) as t:
        assert not t.disable
        t.update()
        assert t.n == 1
        t.update()
        assert t.n == 2
        t.close()

# Generated at 2022-06-24 10:34:39.810930
# Unit test for function trange
def test_trange():
    """Functional test for trange"""
    # test bar exact iterations, disable
    with trange(9) as t:
        for i in t:
            assert i == t.n
    with trange(9, disable=True) as t:
        for i in t:
            assert i == t.n
    with trange(9) as t:
        for i in t:
            assert i == t.n
            if i > 5:
                break
    # test bar exact iterations, miniters
    with trange(9, miniters=3) as t:
        for i in t:
            assert i == t.n
            if i > 5:
                break
    with trange(9, miniters=2) as t:
        for i in t:
            assert i == t.n

# Generated at 2022-06-24 10:34:48.116148
# Unit test for method render of class RateColumn

# Generated at 2022-06-24 10:34:58.098882
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .gui import tqdm_gui

    t = tqdm_rich(xrange(1, 10), desc="Test", smoothing=0, position=0,
                  leave=True, mininterval=0.1, miniters=1, dynamic_ncols=False)
    t.close()

    t = tqdm_rich(xrange(1, 10), desc="Test", disable=True)
    t.close()

    t = tqdm_rich(xrange(1, 10), desc="Test")
    t.close()

    t = tqdm_gui(xrange(1, 10), desc="Test")
    t.close()

    # Exception: miniters > total

# Generated at 2022-06-24 10:35:06.833685
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert f.render(Progress(total=2048, completed=1024)) == Text("0.5/2 K", style="progress.download")
    assert f.render(Progress(total=2048, completed=2048)) == Text("2/2 K", style="progress.download")
    assert f.render(Progress(total=1024, completed=512)) == Text("0.5/1 K", style="progress.download")
    assert f.render(Progress(total=1048576, completed=512)) == Text("0.5/1 M", style="progress.download")


# Generated at 2022-06-24 10:35:13.022976
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # assert instantiation and closing
    x = tqdm_rich(100, disable=True)
    assert x.disable
    assert x.n == 100
    x.close()
    assert not x.disable
    assert x.n == 100
    x.close()
    assert x.disable
    x.close()
    assert x.disable



# Generated at 2022-06-24 10:35:22.496521
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test that the render method is correct."""
    rate_col = RateColumn()
    assert rate_col.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_col.render(6.7) == Text("6.7 B/s", style="progress.data.speed")
    rate_col = RateColumn(unit='iB', unit_scale=True)
    assert rate_col.render(None) == Text("? iB/s", style="progress.data.speed")
    assert rate_col.render(6.7) == Text("6.7 iB/s", style="progress.data.speed")
    rate_col = RateColumn(unit='iB', unit_scale=True, unit_divisor=1024)
    assert rate_col.render(None) == Text

# Generated at 2022-06-24 10:35:25.446007
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(disable=True, total=None) as pbar:
        pbar.clear()

# Generated at 2022-06-24 10:35:26.470758
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    pass
