

# Generated at 2022-06-24 10:25:31.533914
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = None
    _FractionColumn = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert _FractionColumn.render(task) == None

    task = ""
    _FractionColumn = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert _FractionColumn.render(task) == ""

    

# Generated at 2022-06-24 10:25:34.300924
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn()
    task = None
    fraction.render(task)
    assert True

# Generated at 2022-06-24 10:25:36.261855
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .tests.test_tqdm_gui import test_tqdm_rich_reset
    test_tqdm_rich_reset()

# Generated at 2022-06-24 10:25:37.052602
# Unit test for constructor of class RateColumn
def test_RateColumn():
    ProgressColumn()
    RateColumn()

# Generated at 2022-06-24 10:25:40.890774
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test for the constructor of class FractionColumn"""
    f_col1 = FractionColumn()
    f_col2 = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert (f_col1.unit_scale == False)
    assert (f_col1.unit_divisor == 1000)
    assert (f_col2.unit_scale == True)
    assert (f_col2.unit_divisor == 1024)


# Generated at 2022-06-24 10:25:43.654866
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    assert rate_column.unit == ""
    assert rate_column.unit_scale == False
    assert rate_column.unit_divisor == 1000
    assert rate_column._render_delay == 0.5

# Generated at 2022-06-24 10:25:53.975942
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import datetime
    from os import getpid
    from random import randint
    from threading import Thread
    from time import sleep

    # Test 1
    progress = tqdm_rich(
        "test",
        total=1,
        smoothing=0,
        leave=False,
        disable=False,
        unit_scale=True,
        initial=0,
        dynamic_ncols=True)
    progress.dynamic_ncols = False
    task = progress._prog.get_task(progress._task_id)
    column = RateColumn()
    column.render(task)

    # Test 2

# Generated at 2022-06-24 10:25:56.197029
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    c = tqdm(total=10)
    c.close()
    assert type(c.close()) == None



# Generated at 2022-06-24 10:26:01.277094
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Unit test for method render of class FractionColumn.
    """
    from rich.progress import ProgressTask
    test_task1 = ProgressTask("Test task 1 with completed=100 and total=100")
    test_task1.completed=100
    test_task1.total=100
    test_task2 = ProgressTask("Test task 2 with completed=123 and total=987")
    test_task2.completed=123
    test_task2.total=987
    test_task3 = ProgressTask("Test task 3 with completed=6543 and total=12000")
    test_task3.completed=6543
    test_task3.total=12000


# Generated at 2022-06-24 10:26:07.474329
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import io
    import sys
    try:
        from unittest.mock import patch
    except ImportError:  # pragma: no cover
        # Python 2.7
        from mock import patch

    @patch('sys.argv', ['tqdm_rich'])
    @patch('sys.stdout', new_callable=io.StringIO)
    def test_tqdm_rich_with(stdout):
        for _ in tqdm_rich([]):
            pass
        return stdout.getvalue()

    test_tqdm_rich_with()

# Generated at 2022-06-24 10:26:11.311681
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    pbar = tqdm_rich(["a", "b", "c", "d"])
    assert not pbar.disable
    pbar.update(2)
    pbar.close()
    assert pbar.disable



# Generated at 2022-06-24 10:26:18.831516
# Unit test for method render of class RateColumn

# Generated at 2022-06-24 10:26:31.163022
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task_percentage = Progress(description='test', total=10)
    test_task_percentage.completed = 5
    assert FractionColumn().render(test_task_percentage)== Text('0.5/1.0 G', style='progress.download')
    test_task_numerator = Progress(description='test', total=10)
    test_task_numerator.completed = 0.5
    assert FractionColumn().render(test_task_numerator)== Text('0.000/1.0 G', style='progress.download')
    test_task_denominator = Progress(description='test', total=1)
    test_task_denominator.completed = 0.5

# Generated at 2022-06-24 10:26:33.315372
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        import rich.progress
    except ImportError:
        import warnings
        warnings.warn("'rich' not installed, skipping tests.", ImportWarning)

    from .tests_tqdm import pretest_posttest  # NOQA

    pretest_posttest(tqdm_rich)

# Generated at 2022-06-24 10:26:34.171670
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(disable=False) as progress_bar:
        progress_bar.close()


# Generated at 2022-06-24 10:26:39.729777
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm
    bar = tqdm(range(100), disable=True)
    bar.total = 1000
    bar.n = 500
    fraction = FractionColumn()
    assert fraction.render(bar) == Text("500.0/1,000", style="progress.download")

    bar.total = 100 * 1024 * 1024 * 1024  # 100GB
    bar.n = 50 * 1024 * 1024 * 1024  # 50GB
    fraction = FractionColumn(unit_scale=True)
    assert fraction.render(bar) == Text("50.0G/100G", style="progress.download")



# Generated at 2022-06-24 10:26:41.380306
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    list_ = [1, 2, 3]
    for i in tqdm_rich(list_):
        a = 1



# Generated at 2022-06-24 10:26:43.342564
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(5)):
        pass


# Generated at 2022-06-24 10:26:46.625966
# Unit test for constructor of class RateColumn
def test_RateColumn():
    co = RateColumn()
    assert co.unit == ''
    co = RateColumn(unit='b')
    assert co.unit == 'b'
    co = RateColumn(unit='/s')
    assert co.unit == '/s'

# Generated at 2022-06-24 10:26:49.339571
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    x = tqdm_rich(range(10000))
    x.close()
    assert 'close' not in str(x)


# Generated at 2022-06-24 10:26:53.418253
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich display method"""
    iterable = range(5)
    tr = tqdm_rich(iterable)
    tr.display()
    assert tr._prog.tasks[0].completed == 0



# Generated at 2022-06-24 10:26:55.429339
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rateColumn = RateColumn(unit=" bytes", unit_scale=False, unit_divisor=1000)
    assert rateColumn.unit == " bytes"

# Generated at 2022-06-24 10:27:02.742126
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    all_tests = [
        tqdm_rich(range(1), desc="test", total=1, leave=False, disable=False,
                  unit="unit_test", unit_scale=True, unit_divisor=500),
        tqdm_rich(range(1), desc="test", total=1, leave=True, disable=True,
                  unit="unit_test", unit_scale=True, unit_divisor=500),
    ]
    for test in all_tests:
        assert test._task_id == 1  # pylint: disable=protected-access
        assert test.format_dict['unit'] == "unit_test"
        assert test.format_dict['unit_scale'] == True
        assert test.format_dict['unit_divisor'] == 500
        assert test.desc == "test"


# Generated at 2022-06-24 10:27:05.460578
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from time import sleep

    with trange(5, desc='Cool', unit_scale=False, unit='B') as t:
        for i in t:
            sleep(0.01)

# Generated at 2022-06-24 10:27:16.992153
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import time
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    import unittest

    class TestRateColumn(unittest.TestCase):
        """class for testing RateColumn"""
        def test_construct(self):
            """test the constructor of RateColumn"""
            column = RateColumn()
            column = RateColumn('', True, 1000)
            column = RateColumn('MB/s', False, 1024)
            self.assertRaises(TypeError, RateColumn, 'MB/s', 1, 1024)
            self.assertRaises(TypeError, RateColumn, 'MB/s', False, 1024, 'test')
            self.assertRaises(TypeError, RateColumn, 'MB/s', 1024, 1024)

# Generated at 2022-06-24 10:27:23.429535
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    unit_scale = False
    unit_divisor = 1000
    completed = int(5.5)
    total = int(12.5)
    unit, suffix = filesize.pick_unit_and_suffix(total, [""], 1)
    precision = 0 if unit == 1 else 1
    fraction = f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}"
    
    assert FractionColumn.render(None, None) == Text(fraction, style="progress.download"), f"Error in {FractionColumn.render}"

# Generated at 2022-06-24 10:27:26.789250
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn(unit_scale = True, unit_divisor = 1024)
    assert fraction.render(None) == Text(
        f"0.0/0.0 ",
        style="progress.download")


# Generated at 2022-06-24 10:27:27.986893
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    for i in tqdm(list(range(10))):
        sleep(0.1)

# Generated at 2022-06-24 10:27:30.649527
# Unit test for function trange
def test_trange():
    """Test trange."""
    # Test __doc__
    assert "trange(3)" in trange.__doc__

    # Test basic
    assert list(trange(3)) == [0, 1, 2]



# Generated at 2022-06-24 10:27:42.010106
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest import TestCase, main
    from shutil import rmtree
    from tempfile import mkdtemp
    from os import path, makedirs, listdir
    from datetime import datetime
    import time
    import random

    class TestTrangeReset(TestCase):
        def setUp(self):
            self.orig_dir = mkdtemp()
            self.target_dir = path.join(self.orig_dir, 'target-dir')
            makedirs(self.target_dir)
            self.progress = tqdm_rich(desc='Files moved: ')
            self.progress.reset()
            time.sleep(2)

        def tearDown(self):
            rmtree(self.orig_dir)

        def test_reset(self):
            files = self.generate_files()

# Generated at 2022-06-24 10:27:45.065081
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .main import _main
    from .std import _supports_unicode
    _supports_unicode = False
    try:
        _main()
    except (OSError, IOError):
        pass


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:27:48.175164
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    instance = tqdm_rich(1, desc='test')
    assert isinstance(instance, tqdm_rich)


# Generated at 2022-06-24 10:27:50.397583
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # test total = None
    t = tqdm_rich(total=10)
    t.reset()
    assert not t._prog.finished
    # test total = value
    t.reset(total=10)
    assert not t._prog.finished

# Generated at 2022-06-24 10:27:53.199876
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10, disable=False) as task:
        task.close()
        assert task.disable is False
    assert task.disable is True


# Generated at 2022-06-24 10:27:55.984329
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10, desc="test_tqdm") as pbar:
        for i in range(10):
            pbar.update(1)

# Generated at 2022-06-24 10:28:06.394612
# Unit test for constructor of class RateColumn
def test_RateColumn():
    for d in ('B', 'c'):
        r = RateColumn(unit=d)
        assert r.unit == d
        assert r.unit_divisor == 1000
        r = RateColumn(unit=d, unit_scale=True)
        assert r.unit == d
        assert r.unit_divisor == 1000
        r = RateColumn(unit=d, unit_scale=False)
        assert r.unit == d
        assert r.unit_divisor == 1
        r = RateColumn(unit=d, unit_scale=True, unit_divisor=1024)
        assert r.unit == d
        assert r.unit_divisor == 1024
        r = RateColumn(unit=d, unit_scale=False, unit_divisor=1024)
        assert r.unit == d

# Generated at 2022-06-24 10:28:10.725714
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        iterable = [1 for _ in tqdm_rich(range(100), leave=False)]
        for i in iterable:
            pass
    except ValueError:
        pass

test_tqdm_rich_close.test_tqdm_rich_close = True

# Generated at 2022-06-24 10:28:12.613492
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(4, desc="Test"):
        pass



# Generated at 2022-06-24 10:28:15.562672
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    T = tqdm_rich(range(50))
    T.close()
    def test():
        T.close()
    assert test() is None


# Generated at 2022-06-24 10:28:27.006839
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from tqdm.std import trange
    from tqdm.auto import tqdm

    with tqdm(total=20, desc='test', disable=True) as t:
        t.update(20)

    with tqdm(total=20, desc='test', disable=False) as t:
        t.update(20)

    assert t.gui

    with tqdm(total=20, desc='test', disable=False, ascii=True) as t:
        assert t.disable
        assert not t.gui
        t.update(20)

    with Progress(
            "[progress.description]{task.description}") as prog:
        assert not prog.transient

# Generated at 2022-06-24 10:28:29.165490
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass



# Generated at 2022-06-24 10:28:39.717854
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    col = RateColumn(unit="B")
    task = tqdm_rich()

    # Test case with no speed
    task.rate = None
    assert col.render(task) == Text(f"? B/s", style="progress.data.speed")

    # Test case with speed = 1
    task.rate = 1
    assert col.render(task) == Text(f"1 B/s", style="progress.data.speed")

    # Test case with speed = 10
    task.rate = 10
    assert col.render(task) == Text(f"10 B/s", style="progress.data.speed")

    # Test case with speed = 1000
    task.rate = 1000
    assert col.render(task) == Text(f"1.0 KB/s", style="progress.data.speed")

    # Test case with

# Generated at 2022-06-24 10:28:43.370929
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm_rich() constructor."""
    t = tqdm_rich(0)
    assert t.disable is True
    t = tqdm_rich(0, disable=False)
    assert t.disable is False
    with tqdm_rich(0) as t:
        assert t.disable is True
    with tqdm_rich(0, disable=False) as t:
        assert t.disable is False



# Generated at 2022-06-24 10:28:48.540645
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(
        "MyTask",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
    ).add_task("Test", total=1, completed=1)
    assert "1.0/1.0" in str(task)
    task = Progress(
        "MyTask",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
    ).add_task("Test", total=1.5, completed=0.5)
    assert "0.5/1.5" in str(task)

# Generated at 2022-06-24 10:28:51.493888
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    my_column = FractionColumn()
    assert my_column.render(1, 1) == Text("1.0/1.0", style="progress.download")
    assert my_column.render(0.5, 2.3) == Text("0.5/2.3", style="progress.download")

# Generated at 2022-06-24 10:28:57.863616
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    progress = Progress()
    progress.__enter__()

    console = Console()
    console.print(progress.render(interactive=True))

    table = Table(box=None)
    table.add_column()

    text = Text()
    text.start_group()
    text.append("Hello world!")
    text.end_group()

    progress.add_task('task_0', total=100, completed=0)
    progress.add_task('task_1', total=100, completed=0)
    progress.update(1, completed=50)

    console.print(progress.render(interactive=True))
    progress.remove_task(1)

# Generated at 2022-06-24 10:29:00.154892
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    g = FractionColumn()
    assert g.render(Progress.current_task) is not None


# Generated at 2022-06-24 10:29:09.510651
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from unittest import TestCase
    from unittest.mock import Mock

    class MockMega(Mock):
        def __init__(self):
            self.total = 1000000
            self.completed = 500000
        def get(self):
            return {'total': self.total, 'completed': self.completed}

    class MockKilo(Mock):
        def __init__(self):
            self.total = 1000
            self.completed = 500
        def get(self):
            return {'total': self.total, 'completed': self.completed}

    class MockMegaFloor(Mock):
        def __init__(self):
            self.total = 1000000
            self.completed = 499999

# Generated at 2022-06-24 10:29:20.552409
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn()
    assert rc.unit == ""
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1000
    assert str(rc.render(None)) == "? /s"

    rc = RateColumn(unit="B/s")
    assert rc.unit == "B/s"
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1000
    assert str(rc.render(None)) == "? B/s"

    rc = RateColumn(unit="B/s", unit_scale=True, unit_divisor=1000)
    assert rc.unit == "B/s"
    assert rc.unit_scale == True
    assert rc.unit_divisor == 1000
    assert str(rc.render(None)) == "? B/s"

   

# Generated at 2022-06-24 10:29:27.954670
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.console import Console
    c = Console()
    task = c.new_task()
    a = RateColumn(unit="B/s")
    print(a.render(None))

# Generated at 2022-06-24 10:29:31.568419
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_FractionColumn = FractionColumn(True, 1000)
    result = test_FractionColumn.render(std_tqdm(total=10))
    assert isinstance(result, Text)


# Generated at 2022-06-24 10:29:40.935048
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    with tqdm_rich(total=100, leave=True, desc='tqdm_rich', ncols=10,
                   unit_scale=True, unit_divisor=1000, unit="iB") as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)
    # test reset()
    with tqdm_rich(total=500, desc='tqdm_rich', ncols=10, unit_scale=True,
                   unit_divisor=1000, unit="iB") as pbar:
        for i in range(50):
            pbar.update(10)
            sleep(0.1)
        pbar.reset(total=100)

# Generated at 2022-06-24 10:29:49.895355
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render(task=None) == Text('0.0/0.0 ', style='progress.download')
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fc.render(task=None) == Text('0.0/0.0 ', style='progress.download')
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(task=None) == Text('0.0/0.0 ', style='progress.download')
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.render(task=None) == Text('0.0/0.0 ', style='progress.download')
    fc = F

# Generated at 2022-06-24 10:29:55.296348
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    with tqdm_rich(range(1000)) as t:
        for i in t:
            time.sleep(0.01)
    assert str(t) == '1000it [00:10, 95.43it/s]', \
        'result: {}\n{}'.format(t, str(t))


# Generated at 2022-06-24 10:29:58.280408
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render({"completed": 1, "total": 200}) == Text('0.01/2.00 ')


# Generated at 2022-06-24 10:30:01.418703
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    bar_column = FractionColumn()
    assert bar_column.render(Progress.get_task(0)) == "\u001b[38;2;14;114;255m0/0 \u001b[0m"

# Generated at 2022-06-24 10:30:03.735292
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(1) as t:
        display = t.display
        assert display is not None

# Generated at 2022-06-24 10:30:09.830418
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    # Test when speed = None
    assert rate.render(None) == Text("? /s", style="progress.data.speed")
    # Test when speed = 0
    assert rate.render(0) == Text("0 /s", style="progress.data.speed")
    # Test when speed > 0
    assert rate.render(512) == Text("0.5 K/s", style="progress.data.speed")


# Generated at 2022-06-24 10:30:12.989735
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for i in tqdm_rich(["a", "b", "c", "d"]):
        pass
    for i in tqdm_rich(["a", "b", "c", "d"], total=5):
        pass

# Generated at 2022-06-24 10:30:23.262569
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    def text_equal(a, b):
        assert a.text == b

    rate_column = RateColumn()
    text_equal(rate_column.render({'speed': None}), '? /s')
    text_equal(rate_column.render({'speed': 0}), '0 /s')
    text_equal(rate_column.render({'speed': 1}), '1 /s')
    text_equal(rate_column.render({'speed': 1000}), '1K /s')
    text_equal(rate_column.render({'speed': 1001}), '1.0K /s')
    text_equal(rate_column.render({'speed': 1000000}), '1M /s')

# Generated at 2022-06-24 10:30:33.473654
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=unused-variable
    from unittest import TestCase, TestSuite, TextTestRunner
    class TrangeTest(TestCase):
        """Test for trange"""
        def test_trange(self):
            """Test trange"""
            tr = trange(2, 3, 10)
            self.assertTrue(hasattr(tr, 'gui'))
            self.assertTrue(hasattr(tr, '_prog'))
            self.assertEqual(tr.format_dict['desc'], '  0%|          | 0/10 [00:00<?, ?it/s]')

# Generated at 2022-06-24 10:30:38.724643
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=1000000)
    task.completed = 100000
    test = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert test.render(task) == '100.0/1000 K'
    test = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert test.render(task) == '100.0/1000 K'
    task.completed = 800000
    test = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert test.render(task) == '800/1000 K'
    test = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert test.render(task) == '800/1000 K'
    task.completed = 1000000
    test = Fraction

# Generated at 2022-06-24 10:30:43.378924
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10, disable=True)
    try:
        t.clear()
    except Exception:
        raise RuntimeError("tqdm.rich.tqdm.clear() raised Exception unexpectedly!")
    finally:
        t.close()

# Generated at 2022-06-24 10:30:47.563603
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn(unit='bytes', unit_scale=True, unit_divisor=1000)
    assert rc.unit == 'bytes'
    assert rc.unit_scale is True
    assert rc.unit_divisor == 1000

# Generated at 2022-06-24 10:30:57.786023
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Unit tests for method clear of class tqdm_rich.
    """
    iterator = tqdm_rich(range(10), desc='tqdm_rich_clear')
    iterator.reset()
    iterator.clear()

if __name__ == '__main__':
    # tqdm_rich_clear
    iterator = tqdm_rich(range(10), desc='tqdm_rich_clear')
    iterator.reset()
    iterator.clear()

    # tqdm_rich_clear_with_positional_and_keyword_args
    iterator = tqdm_rich(range(10), desc='tqdm_rich_clear_with_positional_and_keyword_args')
    iterator.reset(total=20)
    iterator.clear(total=30, desc='new_desc')

# Generated at 2022-06-24 10:31:04.772268
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm_rich constructor"""
    # Test default format
    pbar = tqdm_rich(total=3)
    assert pbar.format_dict['total'] == 3

    # Test custom format
    pbar = tqdm_rich(total=3, format='{desc}')
    assert pbar.format_dict['total'] == 3
    assert pbar.format_dict['desc'] is not None

    # Test settings
    pbar = tqdm_rich(total=3, mininterval=0.1)
    assert pbar.miniters == 1
    assert pbar.mininterval == 0.1

    # Test settings
    pbar = tqdm_rich(total=3, miniters=1)
    assert pbar.miniters == 1
    assert pbar.mininterval

# Generated at 2022-06-24 10:31:05.656195
# Unit test for function trange
def test_trange():
    """Test function trange."""
    for _ in trange(4):
        pass

# Generated at 2022-06-24 10:31:15.001535
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from os import getpid
    from rich.progress import find_task_by_id
    from tqdm.contrib import DummyTqdmFile
    with tqdm(total=10, desc=f"PID: {getpid()}") as t:
        task_id = t._task_id
        # Reset tqdm_rich.reset()
        t.reset(total=42)
        assert task_id == t._task_id
        assert find_task_by_id(task_id).total == 42
        # Reset tqdm_rich.update()
        t.update(5)
        t.update(5)
        assert task_id == t._task_id
        assert find_task_by_id(task_id).completed == 10
        # Reset tqdm_rich.close()
       

# Generated at 2022-06-24 10:31:22.827722
# Unit test for function trange
def test_trange():
    """Functional test for function trange."""
    from .utils import FormatWarningsFilter
    import warnings
    with FormatWarningsFilter():
        with warnings.catch_warnings(record=True) as warns:
            warnings.simplefilter('always')
            for _ in trange(4):
                pass
    assert len(warns) == 1
    assert issubclass(warns[-1].category, TqdmExperimentalWarning)
    assert str(warns[-1].message).startswith("rich is experimental/alpha")

# Generated at 2022-06-24 10:31:34.497712
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    class TestClass:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    test = FractionColumn()
    assert test.render(TestClass(100, 1000)) == Text("0.1/1.0 ")
    assert test.render(TestClass(1, 1000)) == Text("0.0/1.0 K")
    assert test.render(TestClass(1, 10000)) == Text("0.0/10.0 K")
    assert test.render(TestClass(1, 100000)) == Text("0.0/100.0 K")
    assert test.render(TestClass(1, 1000000)) == Text("0.0/1.0 M")

# Generated at 2022-06-24 10:31:38.628587
# Unit test for constructor of class RateColumn
def test_RateColumn():
    __doc__ = RateColumn.render.__doc__
    expected = Text("3.4 M/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True) == expected

# Generated at 2022-06-24 10:31:41.065282
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(total=10)
    assert t._prog.total == 10
    t.reset(total=20)
    assert t._prog.total == 20

# Generated at 2022-06-24 10:31:48.789794
# Unit test for function trange
def test_trange():
    for i in trange(4, desc='for loop'):
        for j in trange(100, desc='inner loop'):
            pass
        pass

    with trange(4, desc='with loop') as t:
        for i in t:
            for j in trange(100, desc='inner loop'):
                pass
            pass

    assert t.n == 4

    from time import sleep
    for i in trange(3, desc='for loop'):
        sleep(0.1)
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:31:51.993917
# Unit test for function trange
def test_trange():
    assert list(trange(10, desc="text")) == list(_range(10))
    assert list(trange(10, 20, 2)) == list(_range(10, 20, 2))

# Generated at 2022-06-24 10:31:57.993894
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Mock the class ProgressTask, use to test method render of class FractionColumn."""
    task = lambda completed, total: {'completed': completed, 'total': total}

    assert FractionColumn().render(task(100, 100)) == Text('100.0/100.0 ', style='progress.download')
    assert FractionColumn().render(task(100, 1000)) == Text('0.1/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task(10000000000, 10000000000)) == Text('1.0/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task(10000000000, 10000000000000000000000)) == Text('0.1/1.0 T', style='progress.download')

# Generated at 2022-06-24 10:32:02.489059
# Unit test for function trange
def test_trange():
    func = trange

    # Test range
    list(func(5))
    list(func(5, 2))
    list(func(5, -1))
    list(func(5, 2, -1))
    list(func(5, 2, -1, 3))


if __name__ == "__main__":
    trange(5)

# Generated at 2022-06-24 10:32:06.599379
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time

    with tqdm_rich(total=1, desc="test") as t:
        time.sleep(0.5)
        t.close()

# Generated at 2022-06-24 10:32:08.777457
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(1) == Text('1/1', style='progress.download')

# Generated at 2022-06-24 10:32:17.055429
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import gc
    from rich.console import Console
    with Console():
        with trange(1, 5) as pbar:
            for i in pbar:
                assert (i == pbar.n)
            pbar.write("foobar")
        with tqdm(1, 5) as pbar:
            for i in pbar:
                assert (i == pbar.n)
            pbar.write("foobar")
        x = trange(1, 5)
        x.write("foobar")
        assert (x.disable == False)
        x.disable = True
        assert (x.disable == True)
        x.close()
        assert (x.disable == True)
        x = tqdm(1, 5)
        assert (x.disable == False)
        x

# Generated at 2022-06-24 10:32:26.486416
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=999, disable=True)
    # calculate unit, precision, suffix by speed
    task.n = 0
    task.last_print_n = 0
    task.last_print_t = time.time()
    task.speed = None
    ratecolumn = RateColumn(unit='K', unit_scale=True, unit_divisor=1000)
    ratecolumn.render(task) == Text("? K/s", style="progress.data.speed")
    ratecolumn.unit_scale = False
    ratecolumn.render(task) == Text("? K/s", style="progress.data.speed")

    task.last_print_n = 100
    task.n = 500
    ratecolumn.unit_scale = False

# Generated at 2022-06-24 10:32:30.021413
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm(unit='blocks', unit_scale=True, unit_divisor=1024) as t:
        for i in range(100):
            t.update()


if __name__ == "__main__":  # pragma: no cover
    from .main import _main
    _main(__doc__)

# Generated at 2022-06-24 10:32:31.866986
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.update()
    t.close()
    t.clear()

# Generated at 2022-06-24 10:32:33.591772
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for _ in tqdm_rich(range(3)):
        pass



# Generated at 2022-06-24 10:32:37.869731
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import pytest
    from rich.progress import Task
    task = Task("")
    task.completed = 50
    task.total = 100
    fraction_column = FractionColumn()
    fraction_column.render(task)

# Generated at 2022-06-24 10:32:45.448069
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.logging import RichHandler
    from contextlib import contextmanager

    import logging
    log = logging.getLogger(__name__)
    log.addHandler(RichHandler())

    @contextmanager
    def tmp_log_context(level):
        _ = log.level
        log.setLevel(level)
        yield
        log.setLevel(_)

    # method clear of class tqdm_rich should not raise an AttributeError
    # even if debug level messages are enabled in log module.
    with tmp_log_context(logging.DEBUG):
        t = tqdm_rich("test")
        t.clear()

# Generated at 2022-06-24 10:32:47.037241
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    fc.render(object())

# Generated at 2022-06-24 10:32:55.132277
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    try:
        from rich.progress import Progress
    except ImportError:
        return
    t = tqdm_rich(
        progress=(
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(),
            "[", TimeRemainingColumn(), ",", RateColumn(), "]"
        ),
        total=10,
        desc="Test",
        disable=True)
    assert isinstance(t, Progress)
    t.close()

# Generated at 2022-06-24 10:32:58.078868
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    # Test trange
    trange(2)
    trange(2, 3)
    trange(2, 3, 5)

# Generated at 2022-06-24 10:33:02.484483
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.panel import Panel
    from rich.progress import Progress
    p = Progress(BarColumn(), FractionColumn(), transient=True)
    p.__enter__()
    for n in range(11):
        p.update(n, total=10)
    p.__exit__(None, None, None)



# Generated at 2022-06-24 10:33:03.852554
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=100)
    t.display()

# Generated at 2022-06-24 10:33:08.061223
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from .tests import pretest_posttest
    with pretest_posttest(reset=lambda x: x.reset(total=42)):
        trange(10).reset(total=42)



# Generated at 2022-06-24 10:33:10.493113
# Unit test for constructor of class RateColumn
def test_RateColumn():
    progressColumn = RateColumn()
    if progressColumn is not None:
        pass
    else:
        raise Exception('Class RateColumn has not been defined')

# Generated at 2022-06-24 10:33:14.329416
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test function for function trange"""
    with tqdm(total=100) as t:
        for i in trange(100):
            t.update()
            assert t.n == i + 1

# Generated at 2022-06-24 10:33:22.289045
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Testing function of tqdm.rich.tqdm_rich.close()
    """
    import sys
    with tqdm_rich(total=5, file=sys.stdout) as pbar:
        for i in range(5):
            pbar.update()
        pbar.close()

        # If rich is installed, rich.progress.Progress() will be used and
        # rich.progress.Progress.__exit__() will be called. And the returned
        # value of super().close() will be None.
        assert pbar.close() is None


# Generated at 2022-06-24 10:33:29.876991
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Create progress bar with fraction column.
    """
    progress = (
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(
                unit_scale=False, unit_divisor=1),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]")
    pbar = Progress(*progress)
    pbar.__enter__()
    task_id = pbar.add_task("", total=1)
    pbar.update(task_id, completed=0)
    pbar.update(task_id, completed=1)
    pbar.__exit__(None, None, None)


# Generated at 2022-06-24 10:33:32.183810
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert (fc.unit_scale == False)
    assert (fc.unit_divisor == 1000)


# Generated at 2022-06-24 10:33:36.687778
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import time
    import unittest

    class Tests(unittest.TestCase):
        def test_tqdm_rich(self):
            with tqdm_rich(total=10) as pbar:
                for _ in range(5):
                    time.sleep(0.1)
                    pbar.update()

    unittest.main(verbosity=2)

# Generated at 2022-06-24 10:33:37.934274
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate = RateColumn(unit="B")
    rate.render(None)

# Generated at 2022-06-24 10:33:41.500285
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    kwargs = dict()
    kwargs['total'] = 10
    kwargs['unit_scale'] = True
    with tqdm_rich(total=10, unit_scale=True) as t_bar:
        t_bar.clear()
        t_bar.display()

# Generated at 2022-06-24 10:33:52.729816
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert filesize.pick_unit_and_suffix(1, ["E", "Z", "Y"], 1000) == (1, "E")
    assert filesize.pick_unit_and_suffix(10, ["E", "Z", "Y"], 1000) == (10, "E")
    assert filesize.pick_unit_and_suffix(100, ["E", "Z", "Y"], 1000) == (100, "E")
    assert filesize.pick_unit_and_suffix(1000, ["E", "Z", "Y"], 1000) == (1, "Z")
    assert filesize.pick_unit_and_suffix(10000, ["E", "Z", "Y"], 1000) == (10, "Z")

# Generated at 2022-06-24 10:34:01.597574
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm
    pbar = tqdm(total=1000, smoothing=0.)
    fc = FractionColumn()
    assert fc.render(pbar) == Text('0.0/1000 ', style='progress.download')
    pbar.update(200)
    assert fc.render(pbar) == Text('200/1000 ', style='progress.download')
    pbar.close()

    pbar = tqdm(total=1000000000, smoothing=0.)
    assert fc.render(pbar) == Text('0.0/1.0 G', style='progress.download')
    pbar.update(100000000)
    assert fc.render(pbar) == Text('100.0/1.0 G', style='progress.download')
    pbar.close()

    p

# Generated at 2022-06-24 10:34:11.125241
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm
    import sys
    import time

    for _ in tqdm_rich(range(10), desc='Test', ncols=80,
                       unit_scale=True, unit_divisor=1024, unit='iB'):
        time.sleep(0.1)
    assert sys.stderr.getvalue() == ''
    sys.stderr.truncate(0)
    for _ in tqdm(range(10), desc='Test', ncols=80,
                  unit_scale=True, unit_divisor=1024, unit='iB'):
        time.sleep(0.1)
    assert sys.stderr.getvalue() != ''



# Generated at 2022-06-24 10:34:15.174136
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    progress = Progress("[progress.description]{task.description}", BarColumn())
    progress.add_task("Sample task")
    progress.reset(total=15)
    progress.update(0, completed=5)
    progress.update(0, completed=10)
    progress.update(0, completed=15)

# Generated at 2022-06-24 10:34:21.058610
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test the method reset of class tqdm_rich."""
    # Initialize a tqdm_rich object
    tqdm_rich_obj = tqdm_rich(total=100)
    assert(tqdm_rich_obj._prog.total == 100)

    # Test the method reset with total=None
    tqdm_rich_obj.reset()
    assert(tqdm_rich_obj._prog.total == 100)
    assert(tqdm_rich_obj.total == 100)

    # Test the method reset with total=200
    tqdm_rich_obj.reset(total=200)
    assert(tqdm_rich_obj._prog.total == 200)
    assert(tqdm_rich_obj.total == 200)

# Generated at 2022-06-24 10:34:39.784449
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from datetime import datetime
    from .std import tqdm_notebook
    from .std import tqdm as tqdm_base

# Generated at 2022-06-24 10:34:43.004926
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # check if method clear raises an error by resetting tqdm_rich bar with
    # total = 1 and complete=1
    try:
        tqdm_rich(total=1).update(1)
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:34:50.150731
# Unit test for constructor of class RateColumn
def test_RateColumn():

    rate = RateColumn("B", unit_scale=True)
    # Test:
    # unit_divisor == 1000
    assert rate.render(task=None) == Text("? B/s", style="progress.data.speed")

    rate = RateColumn("B", unit_scale=True, unit_divisor=1024)
    assert rate.render(task=None) == Text("? B/s", style="progress.data.speed")

    rate = RateColumn("B", unit_scale=True, unit_divisor=1000)
    assert rate.render(task=None) == Text("? B/s", style="progress.data.speed")

    rate = RateColumn("B", unit_scale=True, unit_divisor=1)

# Generated at 2022-06-24 10:34:53.605168
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = type('foo', (object,), {'completed': 1, 'total': 3})()
    fc = FractionColumn()
    assert fc.render(task) == Text('1/3', style='progress.download')

# Generated at 2022-06-24 10:34:57.437890
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=None, desc="haha") as pbar:
        assert pbar.total is None
        pbar.update(33)
        assert pbar.total is None
        assert pbar.n == 33
        pbar.reset(total=100)
        assert pbar.total == 100

# Generated at 2022-06-24 10:35:07.486748
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(FractionColumn.task) == Text('0.0/0.0', style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(FractionColumn.task) == Text('0.0/0.0', style="progress.download")
    try:
        assert FractionColumn(unit_scale=True, unit_divisor="a").render(FractionColumn.task) == Text('0.0/0.0', style="progress.download")
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:35:10.422673
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        for _ in t:
            pass
    assert t.n == 10

# Generated at 2022-06-24 10:35:20.541296
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(total=2.2)) == "1.0/2.2 "
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=2.2)) == "1.0/2.2 "
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(total=2.2)) == "1.0/2.2 k"
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(total=2.2*1000)) == "1.0/2.2 "
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(total=2.2*1000*10)) == "1.0/2.2 k"


# Generated at 2022-06-24 10:35:24.193634
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    console = Console()
    d = tqdm_rich(total=2, desc='uploading')
    d.update()
    d.display()
    d.update()
    d.display()
    d.close()

# Generated at 2022-06-24 10:35:30.472214
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Test if constructor of tqdm_rich class accepts all arguments of tqdm
    class.
    """
    def tqdm_rich_default(iterable):
        return tqdm_rich(iterable, mininterval=0.01)

    def tqdm_default(iterable):
        return tqdm(iterable, mininterval=0.01)
    assert tqdm_rich_default(range(3)) == tqdm_default(range(3))