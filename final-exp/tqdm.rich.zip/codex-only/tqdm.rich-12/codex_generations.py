

# Generated at 2022-06-24 10:25:37.310555
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Assert that the render method returns the expected string."""

    # Given that I have a RateColumn instance
    column = RateColumn()

    # When I try to call the render method with null speed
    # Then I see that the render method returns a string equal to '? B/s'
    assert column.render(None) == '? B/s'

    # When I try to call the render method with a speed of 1024
    # Then I see that the render method returns a string equal to '1 KB/s'
    assert column.render(1024) == '1 KB/s'

    # When I try to call the render method with a speed of 4000
    # Then I see that the render method returns a string equal to '4 KB/s'
    assert column.render(4000) == '4 KB/s'

    # When I try to call the render

# Generated at 2022-06-24 10:25:41.800063
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    import rich.console
    console = rich.console.Console()
    progress = Progress('Downloading...',
                        BarColumn(),
                        " ",
                        TextColumn('[bold green]{task.completed:>6}/{task.total:6}', justify='right'),
                        TimeRemainingColumn(),
                        " ",
                        TimeElapsedColumn(),
                        transient=True,
                        console=console,
                        )
    with progress:
        for i in range(0, 100):
            progress.update(i)
            time.sleep(0.01)
    console.print()

# Generated at 2022-06-24 10:25:43.208512
# Unit test for function trange
def test_trange():
    with trange(4) as t:
        for i in t:
            assert i in [0, 1, 2, 3]

# Generated at 2022-06-24 10:25:44.858478
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # unit == 1 MB
    RateColumn(unit=1, unit_scale=False, unit_divisor=1)


# Generated at 2022-06-24 10:25:54.402930
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress(total=12345678901234.567)) == \
           Text("12,345,678,901,234.6/12,345,678,901,234.6 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(total=12345678901234.567)) == \
           Text("11.8/11.8 T", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress(total=12345678.901234567)) == \
           Text("11.8/11.8 T", style="progress.download")

# Generated at 2022-06-24 10:26:04.008551
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Disable all tqdm_rich's output, it will be enabled on the first creation
    tqdm_rich.disable = True
    # Create an instance and check if it's disabled
    with tqdm_rich(unit='B', unit_scale=True, unit_divisor=1024, desc='test') as t:
        assert t.disable
    # Enable tqdm_rich's output again
    tqdm_rich.disable = False
    # Create another instance and check if it's enabled
    with tqdm_rich(unit='B', unit_scale=True, unit_divisor=1024, desc='test') as t:
        assert not t.disable
        # Check the format string
        assert t.format_dict['unit'] == 'B'
        assert t.format_dict['unit_scale'] == True

# Generated at 2022-06-24 10:26:12.109792
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(total=1)
    task.add_task('test', completed=0.0, speed=611.8)
    assert RateColumn(unit_scale=False).render(task).text == '611.8/s'
    assert RateColumn(unit='b', unit_scale=False).render(task).text == '611.8b/s'
    assert RateColumn(unit_scale=True).render(task).text == '0.6/s'
    assert RateColumn(unit='b', unit_scale=True).render(task).text == '0.6b/s'



# Generated at 2022-06-24 10:26:13.799621
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit='b', unit_scale=True).unit == 'b'



# Generated at 2022-06-24 10:26:20.284624
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from time import sleep
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)

    with tqdm_rich(total=100, bar_width=12) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)

    with tqdm_rich(total=100, bar="█") as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)


# Generated at 2022-06-24 10:26:22.252864
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = std_tqdm(total=100)
    t.n = 50
    t.refresh()
    assert t._last_print_n == 50
    t.clear()
    assert t._last_print_n == None
    t.close()

# Generated at 2022-06-24 10:26:26.902702
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=100)
    task.n = None
    task.speed = None
    task.dynamic_ncols = False
    task.refresh()
    task.close()

if __name__ == "__main__":
    test_RateColumn_render()

# Generated at 2022-06-24 10:26:36.984389
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import rich.progress
    import datetime
    from .utils import format_dict
    from .utils import display_bytes
    from .utils import is_ascii
    # test for RateColumn class
    format_dict['unit'] = "B"
    format_dict['unit_scale'] = True
    format_dict['unit_divisor'] = 1000
    format_dict['unit_separator'] = ""
    format_dict['total_time_known'] = True
    format_dict['total'] = 5
    format_dict['n_fmt'] = "{n:2.0f}"
    format_dict['miniters'] = format_dict['n_fmt']
    format_dict['desc'] = 'Downloading '
    format_dict['leave'] = False

# Generated at 2022-06-24 10:26:41.047234
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test if tqdm_rich.display() raises no exception"""
    from .tqdm import trange
    from .std import time
    from .utils import format_sizeof

    for _ in trange(5, unit='GB'):
        time.sleep(0)
        for _ in trange(10, desc='tqdm_rich_display', unit='MB'):
            time.sleep(0.1)
        # reset unit
        format_sizeof.units = None

# Generated at 2022-06-24 10:26:47.323152
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(_range(1000), progress=(
        "[progress.description]{task.description}[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )) as t:
        for i in t:
            t.set_description("Downloading some files")
            t.set_postfix(file=f"{i}.mp4")

# Generated at 2022-06-24 10:26:49.454915
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    # We execute the method to use tqdm_rich.
    x = tqdm(total=5)
    x.display()
    x.close()

# Generated at 2022-06-24 10:26:53.810406
# Unit test for function trange
def test_trange():
    assert not tqdm_rich.disable
    for _ in trange(9):
        pass
    assert not tqdm_rich.disable
    tqdm_rich.disable = True
    for _ in trange(9):
        pass
    assert tqdm_rich.disable

# Generated at 2022-06-24 10:26:56.832310
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test constructor of class FractionColumn."""
    progress_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    fraction_column_result = progress_column.render(None)



# Generated at 2022-06-24 10:27:02.046311
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    col = FractionColumn()
    col._task = col._task.__class__(description='a', position=None, total=20)
    assert col.render(col._task) == Text("0.0/20.0 ", style="progress.download")
    col._task.completed = 1
    assert col.render(col._task) == Text("0.0/20.0 ", style="progress.download")

# Generated at 2022-06-24 10:27:03.025328
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    assert tqdm_rich(range(1))

# Generated at 2022-06-24 10:27:08.150785
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    progress = Progress()
    progress.__enter__()
    task = progress.add_task("Test" , total=10)
    task.update(5)
    assert FractionColumn().render(task) == Text("0.5/1.0", style="progress.download")

    task.update(2)
    assert FractionColumn().render(task) == Text("0.2/1.0", style="progress.download")

# Generated at 2022-06-24 10:27:11.804471
# Unit test for function trange
def test_trange():
    """Test trange()."""
    list(trange(10))
    list(trange(10, leave=True))
    list(trange(10, total=9))
    list(trange(10, total=10))

# Generated at 2022-06-24 10:27:21.659439
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Text
    rate = RateColumn('B')
    for speed in [None, 500, 999999, 1000.0, 1000000.0, 0]:
        if speed is None:
            text = rate.render(None)
            assert isinstance(text, Text)
            assert text.text == '? B/s'
        elif speed >= 1000000:
            text = rate.render(None)
            assert isinstance(text, Text)
            assert text.text == '1.0 MB/s'
        elif speed >= 1000:
            text = rate.render(None)
            assert isinstance(text, Text)
            assert text.text == '1.0 KB/s'
        else:
            text = rate.render(None)
            assert isinstance(text, Text)

# Generated at 2022-06-24 10:27:23.833755
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm_rich(100)
    t.reset()
    t.reset(100)

# Generated at 2022-06-24 10:27:33.007251
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm(total=5, desc='Total', dynamic_ncols=True) as pbar:
        for i in _range(5):
            pbar.set_description(f"Desc #{i}")
            pbar.n = i
        pbar.update()
        pbar.close()
        pbar.clear()
        pbar.display()


if __name__ == '__main__':  # pragma: no cover
    try:
        from tqdm.auto import trange
    except ImportError:
        pass
    else:
        raise RuntimeError("tqdm.auto.trange should be disabled here.")


# Generated at 2022-06-24 10:27:43.721622
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """ test__tqdm_rich(): tests tqdm_rich constructor """
    from .gui import TqdmTypeError
    from .std import tqdm_test_close
    from .std import tqdm_test_closed
    from .std import tqdm_test_desc
    from .std import tqdm_test_gui
    from .std import tqdm_test_leave
    from .std import tqdm_test_miniters_and_ascii
    from .std import tqdm_test_mininterval
    from .std import tqdm_test_mininterval_and_dynamic_miniters
    from .std import tqdm_test_mininterval_and_gui
    from .std import tqdm_test_miniters
    from .std import tqdm_test

# Generated at 2022-06-24 10:27:53.946853
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # FractionColumn(unit_scale=False, unit_divisor=1000)
    # unit_scale=False
    task = tqdm_rich(total=10000, unit_scale=False)
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fc.render(task) == Text('10,000/10,000', style='progress.download')

    # unit_scale=True
    task = tqdm_rich(total=11000, unit_scale=True)
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(task) == Text('11/11 k', style='progress.download')


# Generated at 2022-06-24 10:28:05.099070
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test tqdm rich constructor."""
    def tqdm_progress(func, *args, **kwargs):
        """Emulate tqdm behaviour."""
        kwargs['desc'] = kwargs.pop('desc', '')
        kwargs['disable'] = kwargs.pop('disable', False)
        kwargs['bar_format'] = kwargs.pop('bar_format', None)
        kwargs['bar_format'] = kwargs.pop('bar_format', None)
        kwargs['bar_format'] = kwargs.pop('bar_format', None)
        kwargs['bar_format'] = kwargs.pop('bar_format', None)
        kwargs['bar_format'] = kwargs.pop('bar_format', None)

# Generated at 2022-06-24 10:28:15.128539
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    dummy_total = 9001
    # Calling reset with default arguments should set the task's total to the
    # bar's total, which is returned by __enter__
    with Progress() as p:
        task_id = p.add_task("dummy", total=dummy_total)
        p.update(task_id, completed=42)
        task_total = next(t.total for t in p.tasks if t.id == task_id)
        assert task_total == dummy_total


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    import sys

# Generated at 2022-06-24 10:28:26.657021
# Unit test for function trange
def test_trange():
    """Test tqdm.rich.trange."""
    with trange(10) as t:
        assert isinstance(t, tqdm_rich)
        for _ in t:
            pass
    with trange(10) as t:
        assert isinstance(t, tqdm_rich)
        for _ in t:
            pass
    with trange(10, desc="Test", mininterval=2) as t:
        assert isinstance(t, tqdm_rich)
        for _ in t:
            pass
    with trange(10, desc="Test", mininterval=2, disable=True) as t:
        assert isinstance(t, tqdm_rich)
        for _ in t:
            pass
    assert type(next(t)) is int

# Generated at 2022-06-24 10:28:28.844457
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    total = None
    completed = None
    fc = FractionColumn()
    fc.render(task=None)

# Generated at 2022-06-24 10:28:32.301563
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class DummyTask:
        completed = 4
        total = 5
    fc = FractionColumn()
    r = fc.render(DummyTask())
    assert r.text == "0.8/1.0 "
    assert r.style == "progress.download"


# Generated at 2022-06-24 10:28:39.833345
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(range(3)).clear()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    # TODO: add `--progress` option for `rich_tqdm`
    # TODO: add `--trange` option for `rich_tqdm`
    with tqdm(total=100) as pbar:
        for i in pbar:
            pbar.set_description('Step %i' % i)
            sleep(0.08)

# Generated at 2022-06-24 10:28:42.895902
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    assert f.unit_scale == False
    assert f.unit_divisor == 1000
    f = FractionColumn(unit_scale=True)
    assert f.unit_scale == True
    f = FractionColumn(unit_divisor=1024)
    assert f.unit_divisor == 1024

# Generated at 2022-06-24 10:28:45.169365
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    assert isinstance(tqdm_rich.display, Progress.display)

# Generated at 2022-06-24 10:28:47.798102
# Unit test for function trange
def test_trange():
    """Basic test for trange"""
    from .trange import trange
    l = []
    for _ in trange(10):
        l.append(1)
    assert l == [1] * 10

# Generated at 2022-06-24 10:28:57.694061
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    x = tqdm_rich(range(10000), mininterval=0.1)
    next(x)  # should do nothing
    assert x.desc == "ETA:"
    assert x.n == 1


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    try:
        import rich.console
        rich.console.Console(line_length=65)
    except ImportError:
        pass
    x = tqdm_rich(range(10000), mininterval=1)
    for n in x:
        x.set_description("Progress: %i" % n)
        sleep(0.01)

# Generated at 2022-06-24 10:28:58.937291
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn.__name__ == 'RateColumn'

# Generated at 2022-06-24 10:28:59.584050
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-24 10:29:00.932686
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pbar = tqdm_rich(total=1)

    pbar.display()

# Generated at 2022-06-24 10:29:06.815964
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from shutil import get_terminal_size
    from time import sleep

    with tqdm(total=50, desc='Downloading', leave=True,  # test leave
              unit_scale=True, unit='B', unit_divisor=1024) as pbar:
        for i in range(50):
            sleep(.1)
            pbar.update(1)
        assert get_terminal_size().columns == pbar.dynamic_mess

# Generated at 2022-06-24 10:29:10.278032
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    t = tqdm_rich(total=10)
    for i in _range(10):
        t.update()
        sleep(1)
    t.reset(total=5)
    for i in _range(5):
        t.update()
        sleep(1)

# Generated at 2022-06-24 10:29:12.111974
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass



# Generated at 2022-06-24 10:29:22.059007
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == Text('? ', style='progress.data.speed')
    assert RateColumn(unit_scale=True).render(None) == Text('? ', style='progress.data.speed')
    assert RateColumn(unit_scale=False).render(None) == Text('? ', style='progress.data.speed')

    assert RateColumn('/s').render(None) == Text('? /s', style='progress.data.speed')
    assert RateColumn('/s', unit_scale=True).render(None) == Text('? /s', style='progress.data.speed')
    assert RateColumn('/s', unit_scale=False).render(None) == Text('? /s', style='progress.data.speed')


# Generated at 2022-06-24 10:29:33.540452
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = {'total': 110, 'completed': 55}
    assert FractionColumn().render(task) == Text(
        f"{55/1:,.0f}/{110/1:,.0f} ",
        style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text(
        f"{55/1:,.0f}/{110/1:,.0f} ",
        style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=10).render(task) == Text(
        f"{55/100:,.2f}/{110/100:,.2f} ",
        style="progress.download")


# Generated at 2022-06-24 10:29:37.849981
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(1), bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]"):
        pass

if __name__ == '__main__':
    test_tqdm_rich_clear()

# Generated at 2022-06-24 10:29:48.145081
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest
    class RateColumn_test(unittest.TestCase):
        def test_RateColumn_render(self):
            rc = RateColumn()
            self.assertEqual(rc.render({'speed': None}),
                             Text(f"? ", style="progress.data.speed")) # case 1
            self.assertEqual(rc.render({'speed': 10}),
                             Text(f"10  B/s", style="progress.data.speed")) # case 2
            self.assertEqual(RateColumn(unit_scale=True, unit_divisor=1024).render({'speed': 5}),
                             Text(f"4.88  B/s", style="progress.data.speed")) # case 3

# Generated at 2022-06-24 10:29:57.103194
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from datetime import datetime
    from time import sleep

    # Test method display of class tqdm_rich
    with tqdm(total=11) as pbar:
        for i in range(22):
            if i == 0:
                pbar.write('Test progress bar display 0 %')
            elif i == 5:
                pbar.write('Test progress bar display 45 %')
            elif i == 9:
                pbar.write('Test progress bar display 90 %')
            elif i == 11:
                pbar.write('Test progress bar display 100 %')
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-24 10:29:58.756086
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test = FractionColumn()
    test._render({"task": {}})

# Generated at 2022-06-24 10:30:09.162874
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm(_range(20))
    task.update(5)

    assert(FractionColumn(unit_scale=True).render(task) ==
           Text("2.0/20.0 ", style="progress.download"))
    assert(FractionColumn(unit_scale=False).render(task) ==
           Text("5/20 ", style="progress.download"))
    task.update(15)
    assert(FractionColumn(unit_scale=True).render(task) ==
           Text("2.0/20.0 K", style="progress.download"))
    task.update(20)
    assert(FractionColumn(unit_scale=True).render(task) ==
           Text("20.0/20.0 ", style="progress.download"))

# Generated at 2022-06-24 10:30:12.200377
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    "Tests"
    t = tqdm_rich(total=10)
    t.close()
    t = tqdm_rich(total=10, desc="test", disable=True)
    t.close()

# Generated at 2022-06-24 10:30:15.277840
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        bar = tqdm_rich(['a', 'b', 'c', 'd'], position=1, leave=True)
        for char in bar:
            pass
    except RuntimeError:  # pragma: no cover
        pass
    finally:
        bar.close()

# Generated at 2022-06-24 10:30:19.855022
# Unit test for function trange
def test_trange():  # pragma: no cover
    with trange(10) as t:
        for i in t:
            assert isinstance(i, int)
    with trange(10, desc='tqdm_rich: ', leave=True) as t:
        for i in t:
            assert isinstance(i, int)

# Generated at 2022-06-24 10:30:24.640938
# Unit test for constructor of class RateColumn
def test_RateColumn():
    ratecolumn = RateColumn(unit="B")
    task = Progress(total=2)
    task.update(completed=1, speed=1)
    assert ratecolumn.render(task) == Text("1.0 B/s", style="progress.data.speed")

# Generated at 2022-06-24 10:30:27.477355
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import assert_equal_iterables
    from .tests import TestTqdm
    TestTqdm._test_iterable(trange, assert_equal_iterables)

# Generated at 2022-06-24 10:30:30.973086
# Unit test for constructor of class RateColumn
def test_RateColumn():
    unit = "u"
    unit_scale = False
    unit_divisor = 500
    rc = RateColumn(unit, unit_scale, unit_divisor)
    assert str(rc) == '<rich.text.Text object at 0x105a2e910>'

# Generated at 2022-06-24 10:30:34.185271
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    FractionColumn(unit_scale=True, unit_divisor=1000)


# Generated at 2022-06-24 10:30:44.835016
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit_scale=True)
    task = lambda: None
    task.speed = 5
    task.unit = "K"
    assert rate_column.render(task) == Text(f"{5/1000:.0f} K/s", style="progress.data.speed")

    task.speed = 5
    task.unit = "M"
    assert rate_column.render(task) == Text(f"{5/1000:.0f} M/s", style="progress.data.speed")

    task.speed = 5
    task.unit = "G"
    assert rate_column.render(task) == Text(f"{5/1000:.0f} G/s", style="progress.data.speed")

# Generated at 2022-06-24 10:30:46.171457
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    render = column.render(Progress(total=10))
    assert '0/10' in render.text

# Generated at 2022-06-24 10:30:46.613713
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
	pass

# Generated at 2022-06-24 10:30:55.591282
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    total = 2734
    completed = 1297

    unit, suffix = filesize.pick_unit_and_suffix(
        total,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        1000,
    )
    precision = 0 if unit == 1 else 1
    assert column.render(completed=completed, total=total) == Text(
        f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}",
        style="progress.download")

# Generated at 2022-06-24 10:31:00.294017
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.progress import Tasks, TimeRemainingColumn, DurationColumn
    from time import sleep

    console = Console()
    # table = Table(show_header=True, header_style="bold yellow")
    table = Markdown()
    table.add_column("Item 1", style="cyan")
    table.add_column("Item 2", style="green")

    table.add_row("A thing", "Another thing")
    table.add_row("A thing", "Another thing")
    table.add_row("A thing", "Another thing")

    @console.progress
    def long_op(tasks):
        """Perform long operation."""
        for task in tasks:
            progress = task.progress
            progress

# Generated at 2022-06-24 10:31:02.456275
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(100), disable=True)
    t.close()
    assert not t.disable

# Generated at 2022-06-24 10:31:12.969125
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm as std_tqdm
    import sys
    import time
    with std_tqdm(total=100, desc='Files', unit='B', unit_scale=True, unit_divisor=1024) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update((i + 1) * 10)
    if sys.version_info[0] < 3:
        return
    import io
    import unittest
    from contextlib import contextmanager
    from unittest import mock

    IS_WIN = sys.platform.startswith('win')

    @contextmanager
    def captured_stdout():
        """This function is a context manager that allows to capture the content of stdout."""
        new_out, new_err = io.String

# Generated at 2022-06-24 10:31:14.003530
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-24 10:31:16.533027
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn().render(task=tqdm_rich(total=0))

# Generated at 2022-06-24 10:31:26.428884
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(
        SimpleTask(speed=0)).string == "0.0 B/s"
    assert RateColumn().render(
        SimpleTask(speed=1000)).string == "1.0 KB/s"
    assert RateColumn().render(
        SimpleTask(speed=1000000)).string == "1.0 MB/s"
    assert RateColumn().render(
        SimpleTask(speed=1000000000)).string == "1.0 GB/s"
    assert RateColumn().render(
        SimpleTask(speed=1000000000000)).string == "1.0 TB/s"
    assert RateColumn().render(
        SimpleTask(speed=1000000000000000)).string == "1.0 PB/s"
    assert RateColumn().render(
        SimpleTask(speed=1000000000000000000)).string == "1.0 EB/s"
   

# Generated at 2022-06-24 10:31:39.229272
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress.task('title', 0, 0)) \
        == '[progress.data.speed]? /s'
    assert RateColumn('B').render(Progress.task('title', 0, 0)) \
        == '[progress.data.speed]? B/s'
    assert RateColumn().render(Progress.task('title', 0, 1)) \
        == '[progress.data.speed]0.0 /s'
    assert RateColumn('B').render(Progress.task('title', 0, 1)) \
        == '[progress.data.speed]0.0 B/s'
    assert RateColumn().render(Progress.task('title', 0, 1024)) \
        == '[progress.data.speed]0.0 K/s'

# Generated at 2022-06-24 10:31:49.115279
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    class Fake_tqdm_rich(tqdm_rich):
        def __init__(self):
            self.close_called = 0
        def close(self):
            self.close_called += 1

    for p in [4, None]:
        fake_tqdm_rich = Fake_tqdm_rich()
        fake_tqdm_rich.close_called = 0
        with trange(1000, desc="testing tqdm_rich close", postfix={'p': p},
                    dynamic_ncols=True) as t:
            assert t.close_called == 0
            for i in t:
                assert t.close_called == 0
                break
            assert t.close_called == 1

# Generated at 2022-06-24 10:31:51.943068
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1, leave=False) as pbar:
        pbar.clear()
        assert pbar.total == 1

# Generated at 2022-06-24 10:32:02.943477
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit tests for method reset of class tqdm_rich."""
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange

# Generated at 2022-06-24 10:32:09.918542
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(Progress(100,100)) == Text("100.0/100.0", style="progress.download")
    assert column.render(Progress(100,200)) == Text("100.0/200.0", style="progress.download")
    assert column.render(Progress(100,1)) == Text("100.0/1.0", style="progress.download")
    assert column.render(Progress(1000,1000)) == Text("1.0/1.0", style="progress.download")
    assert column.render(Progress(1000,2000)) == Text("1.0/2.0", style="progress.download")
    assert column.render(Progress(1000,1)) == Text("1.0/0.0", style="progress.download")


# Generated at 2022-06-24 10:32:21.030098
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.progress import Progress
    from rich.style import Style
    from rich.text import Text

    for _ in tqdm_rich(total=4):
        pass

    for _ in tqdm_rich(total=4, progress=(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
    )):
        pass


# Generated at 2022-06-24 10:32:29.717126
# Unit test for constructor of class RateColumn
def test_RateColumn():
    progress = Progress(
       Text("[progress.description]{task.description}"),
       BarColumn(bar_width=None),
       FractionColumn(unit_scale=True, unit_divisor=1000),
       "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
       ",", RateColumn(unit="B", unit_scale=True, unit_divisor=1000), "]"
    )
    task = progress.add_task("Speed test")
    progress.update(task, total=100, completed=0, speed=12000)
    progress._draw_task(task)



# Generated at 2022-06-24 10:32:32.284332
# Unit test for function trange
def test_trange():
    import time
    total = 10**7  # faster than 10**6 for benchmark
    for i in trange(total):
        time.sleep(1e-6)

# Generated at 2022-06-24 10:32:33.738020
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(range(10))
    t.display()
    t.close()

# Generated at 2022-06-24 10:32:44.727392
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Checks if the FractionColumn class renders the correct fraction.
    """
    d = dict()
    fc = FractionColumn(unit_scale=True)
    assert fc.render(d) == '0.0/0.0'
    d['completed'] = 0
    d['total'] = 0
    assert fc.render(d) == '0.0/0.0'

    d['completed'] = 0.5
    d['total'] = 1
    assert fc.render(d) == '0.5/1.0'

    d['completed'] = 0.5
    d['total'] = 2.3
    assert fc.render(d) == '0.5/2.3'

    d['completed'] = 1024
    d['total'] = 1024
    assert fc

# Generated at 2022-06-24 10:32:47.170036
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="g", unit_scale=True, unit_divisor=1000)
    assert r.unit == "g"
    assert r.unit_scale is True
    assert r.unit_divisor == 1000

# Generated at 2022-06-24 10:32:56.168563
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Unit test for method tqdm_rich.close"""
    from rich.progress import Progress
    from io import StringIO
    from os import remove
    from os.path import exists
    file = StringIO()
    with tqdm_rich(total=10, file=file, dynamic_ncols=True) as pbar:
        pbar.desc = "Desc"
    assert file.getvalue().strip() == "", "tqdm_rich.close(): file not empty"
    if hasattr(Progress, '__del__'):
        remove('progress.log')
    assert not exists('progress.log'), "tqdm_rich.close(): log file not deleted"

# Generated at 2022-06-24 10:33:05.437719
# Unit test for function trange
def test_trange():
    import re
    from rich.console import Console
    from rich.table import Table

    try:
        console = Console()
    except TypeError:
        try:
            console = Console(width=79, force_terminal=True)
        except Exception:
            raise AssertionError("Console init failed. Use with_stdout=False")

    console.print("Testing trange function")
    table = Table(show_header=True, header_style="bold magenta")

    table.add_column("N", style="dim", justify="right")
    table.add_column("output")
    table.add_column("pass/fail", style="green", width=10, justify="center")

# Generated at 2022-06-24 10:33:08.288679
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pbar = tqdm_rich(range(10))
    pbar.reset()
    pbar.reset(total=9)
    pbar.close()


# Generated at 2022-06-24 10:33:18.692551
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    class MockRichProgress(object):
        def __init__(self):
            self._task = dict()

        def add_task(self, task_id):
            self._task[task_id] = 0

        def update(self, task_id, completed):
            self._task[task_id] = completed

        def __enter__(self):
            pass

        def __exit__(self, *args):
            pass
    with tqdm(total=10) as progress:
        progress._prog = MockRichProgress()
        progress._task_id = 0
        progress.display()
        assert progress._prog._task[progress._task_id] == progress.n
        progress.n += 1
        progress.display()
        assert progress._prog._task[progress._task_id] == progress.n

# Generated at 2022-06-24 10:33:27.354608
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn(unit_scale=True, unit_divisor=1000).unit_scale is True
    assert FractionColumn(unit_scale=True, unit_divisor=1000).unit_divisor == 1000

    # Test: Render completed/total, e.g. '0.5/2.3 G'
    completed = int(1234)
    total = int(4321)
    unit, suffix = filesize.pick_unit_and_suffix(
        total,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        1000,
    )
    precision = 0 if unit == 1 else 1


# Generated at 2022-06-24 10:33:32.009114
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit_scale=True).render({'speed': 123456789, 'total': None, 'completed': None}) == Text(
        '117.7 M', style='progress.data.speed')



# Generated at 2022-06-24 10:33:37.539639
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = std_tqdm._trange(10)
    assert task.total == 10
    assert task.completed == 0
    task.__enter__()
    fc = FractionColumn()
    assert str(fc.render(task)) == '0/10'
    task.update(5)
    assert str(fc.render(task)) == '0.5/10'
    task.close()
    task.__exit__(None, None, None)



# Generated at 2022-06-24 10:33:48.564776
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Simple test
    with tqdm(total=42) as t:
        assert t.total == 42
        t.reset()
        assert t.total == 0
    with tqdm(total=42, position=10) as t:
        assert t.total == 42
        assert t.position == 10
        t.reset(total=43)
        assert t.total == 43
        assert t.position == 10

    # Test with nested bars
    with tqdm(total=42) as t1:
        assert t1.total == 42
        assert len(t1.bars) == 1
        with tqdm(total=43) as t2:
            assert t2.total == 43
            assert len(t2.bars) == 1
            t2.reset(total=44)
            assert t2.total == 44

# Generated at 2022-06-24 10:33:52.552454
# Unit test for function trange
def test_trange():
    """Test trange"""
    # Test without gui
    with trange(10, gui=False, leave=True) as pbar:
        for i in range(10):
            pbar.set_description("Current")
            assert pbar.n == i, "n should be i: %d" % i


# Generated at 2022-06-24 10:33:55.616157
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Instantiate the class
    rc = RateColumn()
    # Test the method
    assert rc.render(123) == "123.0 /s", "Failed in test_RateColumn_render()"

# Generated at 2022-06-24 10:34:03.371852
# Unit test for constructor of class RateColumn
def test_RateColumn():
    pos_data = {
        "unit": "B",
        "unit_scale": False,
        "unit_divisor": 1000,
    }
    exp_data = {
        "unit": "B",
        "unit_scale": True,
        "unit_divisor": 1000,
    }
    neg_data = {
        "unit": "GB",
        "unit_scale": False,
        "unit_divisor": 1,
    }
    null_data = {
        "unit": None,
        "unit_scale": False,
        "unit_divisor": None,
    }

    pos_unit_column = RateColumn(**pos_data)
    pos_unit_column.render(**pos_data)

    exp_unit_column = RateColumn(**exp_data)
   

# Generated at 2022-06-24 10:34:05.283275
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import pytest
    with tqdm_rich(total=10) as t:
        t.clear()

# Generated at 2022-06-24 10:34:10.986449
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # import time
    with tqdm_rich(["foo", "bar"], total=2) as t:
        #time.sleep(0.01)
        t.set_postfix_str("P=M")
        #time.sleep(1)
        next(t)
        #time.sleep(0.01)
        t.set_postfix_str("P=S")
        #time.sleep(1)
        next(t)


# Generated at 2022-06-24 10:34:12.176001
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(10, disable=True) as t:
        t.display()

# Generated at 2022-06-24 10:34:14.507374
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(10000), total=10000):
        pass
    for _ in tqdm_rich(range(10000), total=10000):
        pass

# Generated at 2022-06-24 10:34:15.637476
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with trange(50) as progress:
        progress.clear()

# Generated at 2022-06-24 10:34:24.883201
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .utils import _range
    from .std import format_dict
    from .utils import format_sizeof
    format_dict["unit"] = format_sizeof
    from .std import __version__ as tqdm_version
    if tqdm_version < '4.32':
        with tqdm_rich(total=10) as t:
            for i in _range(10):
                t.clear()
                t.update()
    else:
        with tqdm_rich(total=10) as t:
            for i in _range(10):
                t.clear()
                t.update()

# Generated at 2022-06-24 10:34:30.967104
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from pytest import raises
    with raises(AttributeError):
        with tqdm_rich(
            desc="testing tqdm_rich",
            total=100,
            disable=True,
            ncols=100,
        ) as t:
            t.display()
    with tqdm_rich(
        desc="testing tqdm_rich",
        total=100,
        disable=False,
        ncols=100,
    ) as t:
        t.display()
        t.display()

# Generated at 2022-06-24 10:34:39.473584
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display() and tqdm.reset()"""
    # TODO: write unittest.
    print(std_tqdm.format_dict)
    for i in tqdm(range(10)):
        for j in tqdm(range(10), total=10, leave=False):
            pass
        pass
    tqdm.reset()
    for i in tqdm(range(10)):
        for j in tqdm(range(10), total=10, leave=False):
            pass
        pass


if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:34:47.927888
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Tests miniters default value.
    """
    # Test that setting miniters=None overrides default of 10000
    a = tqdm(total=100, miniters=None)
    assert a.miniters == 1

    # Test that default mininter of 10000 is set
    b = tqdm(total=100)
    assert b.miniters == 10000


if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    test_tqdm_rich()

    trange(3)


# Generated at 2022-06-24 10:34:58.062799
# Unit test for function trange
def test_trange():
    """Check that trange is equivalent to tqdm.rich.tqdm"""
    for tup1 in [(False, ""), (True, ""),
                 (False, None), (False, ""),
                 (False, ""), (True, ""),
                 (True, ""), (True, "\n"),
                 (True, "\r"), (True, "\r\n")]:
        for tup2 in [(True, "\r"), (False, "\r"),
                     (True, "\r\n"), (False, "\r\n")]:
            kwargs = dict()
            if tup1[0]:
                kwargs['leave'] = True
            if tup2[0]:
                kwargs['miniters'] = 1

# Generated at 2022-06-24 10:35:01.751154
# Unit test for constructor of class RateColumn
def test_RateColumn():
    col = RateColumn(unit="b", unit_scale=True, unit_divisor=1000)
    assert col.unit == "b"
    assert col.unit_scale == True
    assert col.unit_divisor == 1000

# Generated at 2022-06-24 10:35:10.136478
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import unittest
    class TestRateColumn(unittest.TestCase):
        @staticmethod
        def test_RateColumn():
            d = FractionColumn()
            test_data = [
                ([(file_size, None)], "0.0/1.0 "),
                ([(file_size * 1024 * 1024, None)], "0.0/1.0 M"),
                ([(file_size * 1024 * 1024 * 1024, None)], "0.0/1.0 G"),
                ([(file_size * 1024 * 1024 * 1024 * 1024, None)], "0.0/1.0 T"),
            ]
            for (test_pair, expected_result) in test_data:
                with self.subTest(test_pair=test_pair, expected_result=expected_result):
                    self.assertE

# Generated at 2022-06-24 10:35:14.697528
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction_column = FractionColumn()
    assert fraction_column.render({'completed': 10, 'total': 100}) == Text('0.1/1.0 ', style='progress.download')
    print('Test of method __init__ in class FractionColumn done.')


# Generated at 2022-06-24 10:35:18.927836
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    assert '_prog' in vars(tqdm_rich())
    assert '_task_id' in vars(tqdm_rich())
    tqdm_rich().close()
    tqdm_rich().display()
    assert hasattr(tqdm_rich().reset(), "__getitem__")

# Generated at 2022-06-24 10:35:21.013960
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    obj = tqdm(disable=True)

    # test no error occurs when calling clear
    obj.clear()

# Generated at 2022-06-24 10:35:23.562149
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1, desc='tqdm_rich_clear') as pbar:
        pbar.close()
        pbar.clear()
        pbar.display()

# Generated at 2022-06-24 10:35:33.417023
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class FractionColumn(ProgressColumn):
        """Renders completed/total, e.g. '0.5/2.3 G'."""
        def __init__(self, unit_scale=False, unit_divisor=1000):
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super().__init__()

        def render(self, task):
            """Calculate common unit for completed and total."""
            completed = int(task.completed)
            total = int(task.total)