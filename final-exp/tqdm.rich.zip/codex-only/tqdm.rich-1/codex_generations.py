

# Generated at 2022-06-24 10:25:41.206110
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display() method."""
    _tqdm = tqdm_rich.__init__
    _tqdm_rich = tqdm_rich
    tqdm_rich.__init__ = lambda *args, **kwargs: _tqdm_rich.__init__(
        *args, disable=True, **kwargs)
    try:
        with tqdm_rich(total=10) as pbar:
            pbar.display()
    finally:
        tqdm_rich.__init__ = _tqdm
    try:
        with tqdm_rich(total=10) as pbar:
            pbar.display()
    finally:
        tqdm_rich.__init__ = _tqdm

# Generated at 2022-06-24 10:25:45.040813
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich."""
    with tqdm(total=2) as pbar:
        pbar.clear()
        pbar.update()
        pbar.clear(nolock=False)
        pbar.update()
        pbar.clear(nolock=True)
        pbar.update(1)

# Generated at 2022-06-24 10:25:51.161499
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from io import StringIO
    from contextlib import redirect_stdout
    from rich.console import Console

    f = StringIO()
    with redirect_stdout(f):
        with tqdm_rich(total=10, file=f, desc="test") as pbar:
            for i in range(10):
                pbar.update(i)

    with Console(file=f) as console:
        console.print(f)

# Generated at 2022-06-24 10:25:52.881088
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(13))
    t.clear()
    t.close()

# Generated at 2022-06-24 10:26:02.344199
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    progress = tqdm_rich(range(0, 5), desc="foo", leave=True)

    progress.display(0, 4, 0)
    assert progress._prog.find_task(progress._task_id).completed == 0
    assert progress._prog.find_task(progress._task_id).description == "foo"

    # without description
    progress.display(1, 4, 100)
    assert progress._prog.find_task(progress._task_id).completed == 1
    assert progress._prog.find_task(progress._task_id).description is None

    # with description
    progress.display(2, 4, 200, "bar")
    assert progress._prog.find_task(progress._task_id).completed == 2

# Generated at 2022-06-24 10:26:05.877714
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with trange(10) as ttr:
        assert ttr.total == 10
        ttr.reset(total=5)
        assert ttr.total == 5

# Generated at 2022-06-24 10:26:11.793103
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Create an instance of class RateColumn
    rc = RateColumn(unit="byte")
    # Test when task.speed is None
    rc.render(std_tqdm)
    # Test when unit_scale == False
    rc.unit_scale = False
    rc.render(std_tqdm)
    # Test when unit_scale == True
    rc.unit_scale = True
    rc.render(std_tqdm)

# Generated at 2022-06-24 10:26:19.095131
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    c = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert c.render({'completed': 3000, 'total': 3000000}) == Text(
        '3.000/3,000.000 K', style='progress.download')
    assert c.render({'completed': 1, 'total': 1}) == Text(
        '1.000/1.000 ', style='progress.download')
    assert c.render({'completed': 0, 'total': 0}) == Text(
        '0.000/0.000 ', style='progress.download')
    assert c.render({'completed': 1000, 'total': 1}) == Text(
        '1.000/1.000 ', style='progress.download')

# Generated at 2022-06-24 10:26:23.867749
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn("b", unit_scale=True, unit_divisor=1000)
    assert rate_column.unit == "b"
    assert rate_column.unit_scale is True
    assert rate_column.unit_divisor == 1000


# Generated at 2022-06-24 10:26:34.781112
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test for new method tqdm.rich.clear()
    """
    # Usage of standard library unittest is not allowed here as it is not
    # installed with python2
    import sys
    import traceback
    try:
        import builtins
        builtins.tqdm = tqdm
        __all__ = ['tqdm_gui', 'tgrange']
    except NameError:
        import __builtin__ as builtins
        builtins.tqdm = tqdm
        __all__ = ['tqdm_gui', 'tgrange']

    sys.argv = ['']  # python2 compatibility for unittest
    # Imports for unittest
    import unittest

# Generated at 2022-06-24 10:26:38.363126
# Unit test for constructor of class RateColumn
def test_RateColumn():
    bar = BarColumn()
    bar.render()
    time_elapsed = TimeElapsedColumn()
    time_elapsed.render()
    time_remaining = TimeRemainingColumn()
    time_remaining.render()
    rate = RateColumn()
    rate.render()
    fraction = FractionColumn()
    fraction.render()

# Generated at 2022-06-24 10:26:40.846539
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = 1
    unit_scale = False
    unit_divisor = 1000
    assert FractionColumn(unit_scale,unit_divisor).render(task) == Text('1.0/1.0 ', style="progress.download")


# Generated at 2022-06-24 10:26:49.613512
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=10)
    task.start()
    task.update(0)
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(task) == Text('0 B/s', style="progress.data.speed")
    task.update(10)
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(task) == Text('1 B/s', style="progress.data.speed")
    task.update(100)
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(task) == Text('10 B/s', style="progress.data.speed")
    task.update(1000)

# Generated at 2022-06-24 10:26:56.942324
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    bar = tqdm_rich(total=100)
    bar.update(50)
    assert bar._prog.tasks[bar._task_id].completed == 50
    assert bar._prog.tasks[bar._task_id].total == 100
    bar.close()
    assert bar._prog.tasks[bar._task_id].completed == 100
    assert bar._prog.tasks[bar._task_id].total == 100
    bar.reset(total=200)
    assert bar._prog.tasks[bar._task_id].completed == 0
    assert bar._prog.tasks[bar._task_id].total == 200
    bar.close()

# Generated at 2022-06-24 10:27:00.438399
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn(unit="byte")
    d = {
        'unit': 'byte',
        'unit_scale': False,
        'unit_divisor': 1000
    }
    assert rc.unit == d['unit']
    assert rc.unit_scale == d['unit_scale']
    assert rc.unit_divisor == d['unit_divisor']

# Generated at 2022-06-24 10:27:09.379714
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit='B')
    assert r.render({'speed': None}) == Text('? B/s', style='progress.data.speed')
    r = RateColumn(unit='B', unit_divisor=1024)
    assert r.render({'speed': None}) == Text('? B/s', style='progress.data.speed')
    r = RateColumn(unit_scale=True, unit_divisor=1000)
    assert r.render({'speed': 3 * 10**12}) == Text('3 T/s', style='progress.data.speed')
    r = RateColumn(unit_scale=True, unit_divisor=1024)
    assert r.render({'speed': 3 * 10**12}) == Text('2.7 Ti/s', style='progress.data.speed')
    r = RateColumn

# Generated at 2022-06-24 10:27:17.604377
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress = Progress(
        Text("[progress.description]{task.description}"),
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
    )
    task = tqdm_rich(total=1000, mininterval=0.01, unit='B', unit_scale=True)
    while task.n < task.total:
        # update task
        task.update()
        # render
        progress.update(task.n, task.total, task.desc, bar_style="success")
    print()

# Generated at 2022-06-24 10:27:22.216848
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    try:
        # Find width of terminal
        from shutil import get_terminal_size
        get_terminal_size().columns
        with tqdm(total=100) as prog:
            assert prog() == prog  # __call__ available
            for i in _range(100):
                sleep(0.001)
                prog.update()
    except:
        pass

# Generated at 2022-06-24 10:27:28.102331
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    from .utils import format_sizeof
    with tqdm_rich(unit='B', unit_scale=True, unit_divisor=1024, miniters=1,
                   desc="Downloading", total=4*10**6) as t:
        for i in t:
            t.set_description("Downloaded %s" % format_sizeof(i))
            sys.stdout.flush()



# Generated at 2022-06-24 10:27:29.781822
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4):
        pass
    for _ in trange(4, 0, -1):
        pass

# Generated at 2022-06-24 10:27:36.244046
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Overriding implementation of the method reset of class tqdm_rich. This implementation sets the minimum
    value to the initial total number of iterations, so that the tqdm bar dispalys the percentage of 
    completion from 100% to 0%.
    """
    from .std import tqdm_gui as tqdm

    for i in tqdm(range(4), total=4, desc='Test', unit='i'):
        if i == 1:
            tqdm.reset(total=1)
        elif i == 2:
            tqdm.reset(total=2)
        elif i == 3:
            tqdm.reset()

# Generated at 2022-06-24 10:27:39.336037
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=1)
    t.close()
    assert t.disable is True
    assert t.n == 0
    assert t.last_print_n == 0

# Generated at 2022-06-24 10:27:47.824506
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B")
    task = type("", (object,), {"speed": None})()
    assert rate_column.render(task) == Text(f"? B/s", style="progress.data.speed")
    task.speed = 0.01
    assert rate_column.render(task) == Text(f"0.0 B/s", style="progress.data.speed")
    task.speed = 1000
    assert rate_column.render(task) == Text(f"1.0 KB/s", style="progress.data.speed")
    task.speed = 1000_000
    assert rate_column.render(task) == Text(f"1.0 MB/s", style="progress.data.speed")
    task.speed = 10_000_000
    assert rate_column.render(task) == Text

# Generated at 2022-06-24 10:27:53.670878
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(object) == Text('? B/s', style='progress.data.speed')
    assert RateColumn().render(object) != Text('? /s', style='progress.data.speed')
    assert RateColumn(unit='B').render(object) == Text('? B/s', style='progress.data.speed')
    assert RateColumn(unit='B').render(object) != Text('? /s', style='progress.data.speed')
    assert RateColumn(unit='s').render(object) == Text('? s/s', style='progress.data.speed')
    assert RateColumn(unit='s').render(object) != Text('? /s', style='progress.data.speed')
    assert RateColumn(unit='?').render(object) == Text('? ?/s', style='progress.data.speed')


# Generated at 2022-06-24 10:28:04.959762
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .utils import FormatCustomText, FormatCustomTextTwo
    from .test_tqdm import pretest_posttest

    with pretest_posttest() as (presys, postsys):
        with tqdm_rich(
                total=1000,
                desc='Downloading',
                leave=True,
                unit_scale=True,
                unit_divisor=1024,
                unit='B',
                ascii=True,
                unit_scale=True,
                postfix={'foo': 'bar'},
                miniters=1, mininterval=1,
                bar_format=FormatCustomText
        ) as t:
            # update with postfix kwarg
            t.postfix = {'foo': 'baz'}
            t.update(200)
            assert 'incomplete' in t.format

# Generated at 2022-06-24 10:28:15.092208
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test = FractionColumn()
    assert test.render({'completed': 12345, 'total': 23456}) == Text('1.2/2.3 K')
    assert test.render({'completed': 12345, 'total': 2345}) == Text('1.2/2.3 K')
    assert test.render({'completed': 12345, 'total': 234500}) == Text('12.0/234.5 K')
    assert test.render({'completed': 12345, 'total': 2345000}) == Text('123.0/2,345.0 K')
    assert test.render({'completed': 12345, 'total': 23450000}) == Text('1,234.0/23,450.0 K')
    assert test.render({'completed': 12345, 'total': 234500000}) == Text

# Generated at 2022-06-24 10:28:18.899802
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(range(10)) as t:
        for i in t:
            t.clear()


if __name__ == "__main__":
    from ._main import main
    main()

# Generated at 2022-06-24 10:28:29.125587
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(task=_range(10000)) == "[0.0/1.0 ]"
    assert FractionColumn(unit_scale=True).render(task=_range(10)) == "[0.0/1.0  ]"
    assert FractionColumn(unit_scale=True).render(task=_range(10000)) == "[0.0/1.0 K]"
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task=_range(10)) == "[0.0/1.0  ]"
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task=_range(10000)) == "[0.0/1.0 K]"

# Generated at 2022-06-24 10:28:34.619559
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm_rich(disable=True) as _:
        pass
    with tqdm_rich(0) as _:
        pass
    with tqdm_rich(total=0) as _:
        pass
    with tqdm_rich(total=0, disable=True) as _:
        pass
    with tqdm_rich(desc="") as _:
        pass

# Generated at 2022-06-24 10:28:45.209866
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from os import devnull, remove
    from shutil import rmtree
    from tempfile import mkdtemp
    from sys import _getframe, stdout

    def silence_tqdm(): return open(devnull, 'w')

    for f in range(2):  # test stdout and file-like
        mkdtemp()  # trigger unicode error early
        with silence_tqdm() as fout:
            fd = fout if f else stdout
            # test tqdm_notebook

# Generated at 2022-06-24 10:28:46.763874
# Unit test for function trange
def test_trange():  # noqa
    list(tqdm_rich(_range(1000)))
    list(trange(1000))

# Generated at 2022-06-24 10:28:52.575581
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import Progress
    from rich.console import Console
    console = Console(color_system="truecolor")
    p = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "",
    )
    p.__enter__()
    with p.task("hello"):
        pass
    p(console, clear=True)

# Generated at 2022-06-24 10:28:59.680024
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    __test__ = {}
    from warnings import catch_warnings
    from tqdm.auto import tqdm
    with catch_warnings(record=True) as cw:
        x = tqdm(range(10), desc='desc', ascii=True, guitqdm_cls=tqdm_rich)
        for i in x:
            x.set_description('d: {:d}'.format(i))
    assert len(cw) == 1

# Generated at 2022-06-24 10:29:09.150416
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit tests for tqdm_rich reset."""
    from pytest import approx, raises
    from time import sleep
    from tqdm import trange
    with tqdm(total=100) as t:
        assert t.total == 100
        t.reset(total=200)
        assert t.total == 200
    with tqdm(total=100) as t:
        assert t.total == 100
        try:
            t.reset(50)
        except TypeError:
            pass
        else:
            raise ValueError("must be TypeError")
        assert t.total == 100
    with tqdm() as t:
        t.reset(total=50)
        assert t.total == 50

    # test with cli mode

# Generated at 2022-06-24 10:29:15.597922
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test :
        tqdm_rich class reset method
    """
    from tqdm.rich.tests.test_tqdm_rich import tqdm_rich_progress

    progress = tqdm_rich_progress(unit='b', unit_scale=True)
    progress.reset(total=5)
    assert progress.total == 5



# Generated at 2022-06-24 10:29:19.621374
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import doctest
    doctest.run_docstring_examples(tqdm_rich.clear, globals())

if __name__ == '__main__': # pragma: no cover
    test_tqdm_rich_clear()

# Generated at 2022-06-24 10:29:23.836847
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn(unit="B", unit_scale=True)
    assert str(rc.render(None)) == "? B/s"
    # Assert non-unit units
    assert str(RateColumn(unit="s").render(None)) == "? s/s"
    # Assert non-unit unit prefixes
    assert str(RateColumn(unit="KB").render(None)) == "? KB/s"



# Generated at 2022-06-24 10:29:24.798396
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pass


# Generated at 2022-06-24 10:29:26.655465
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Tests that FractionColumn is as expected."""
    assert FractionColumn().render(Progress.current_task) == Text('0/0 ')

# Generated at 2022-06-24 10:29:30.034779
# Unit test for function trange
def test_trange():
    import time
    total = 6
    for _ in trange(total, desc='desc', miniters=1):
        time.sleep(0.1)

# Generated at 2022-06-24 10:29:39.946059
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # explicit unit
    column = RateColumn(unit='test/s', unit_scale=False, unit_divisor=1000)
    assert column.render({'speed': None}) == Text(f"? test/s", style="progress.data.speed")
    assert column.render({'speed': 888}) == Text(f"888 test/s", style="progress.data.speed")
    assert column.render({'speed': 8888}) == Text(f"8,888 test/s", style="progress.data.speed")
    # implicit unit
    column = RateColumn(unit_scale=False, unit_divisor=1000)
    assert column.render({'speed': None}) == Text(f"? /s", style="progress.data.speed")

# Generated at 2022-06-24 10:29:41.905429
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    tqdm_rich(0, file=sys.stderr).write("\rTesting tqdm_rich")

# Generated at 2022-06-24 10:29:42.639278
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    _ = FractionColumn()

# Generated at 2022-06-24 10:29:49.626219
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert isinstance(RateColumn(), RateColumn)
    assert isinstance(RateColumn(unit_scale=True, unit_divisor=1000), RateColumn)
    assert isinstance(RateColumn(unit_scale=True, unit_divisor=1024), RateColumn)
    assert isinstance(RateColumn(unit="B", unit_scale=True, unit_divisor=1000), RateColumn)
    assert isinstance(RateColumn(unit="B", unit_scale=True, unit_divisor=1024), RateColumn)
    assert isinstance(RateColumn(unit="B", unit_scale=False, unit_divisor=1000),
                      RateColumn)
    assert isinstance(RateColumn(unit="B", unit_scale=False, unit_divisor=1024),
                      RateColumn)

# Generated at 2022-06-24 10:29:53.227864
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    with tqdm(total=5, disable=True) as t:
        for i in range(5):
            t.update()

# Generated at 2022-06-24 10:30:02.030517
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    from io import StringIO

    stream = StringIO()
    old_stdout, sys.stdout = sys.stdout, stream

# Generated at 2022-06-24 10:30:03.871978
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    This function unit tests the constructor for class FractionColumn.
    """
    # modify to test other constructors
    column = FractionColumn()

    # assert all attributes are correctly initialized
    assert(isinstance(column, ProgressColumn))


# Generated at 2022-06-24 10:30:13.734551
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test method display of class tqdm_rich."""
    import rich

    # NOTE: Added by jerry.li
    rich.trace.install()

    class TestTqdmRich(tqdm_rich):

        def display(self, *_, **__):
            if not hasattr(self, '_prog'):
                return

            # NOTE: Added by jerry.li
            # To handle the case that self.desc is None.
            if getattr(self, 'desc', None) is None:
                setattr(self, 'desc', '')

            self._prog.update(self._task_id, completed=self.n, description=self.desc)


# Generated at 2022-06-24 10:30:15.980444
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.clear(3)
    t.close()

# Generated at 2022-06-24 10:30:18.550063
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:30:20.784862
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in range(3):
        for i in tqdm(iterable=range(3), leave=False):
            pass

# Generated at 2022-06-24 10:30:31.211106
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    assert f.render(Progress(total=1, completed=1)) == Text("1.0/1.0 ", style="progress.download")
    assert f.render(Progress(total=10, completed=5)) == Text("0.5/1.0 ", style="progress.download")
    assert f.render(Progress(total=None, completed=1)) == Text("1.0/?:.0 ", style="progress.download")
    assert f.render(Progress(total=1, completed=None)) == Text("?:.0/?:.0 ", style="progress.download")

    f = FractionColumn(unit_scale=True)
    assert f.render(Progress(total=1, completed=1)) == Text("1.0/1.0 ", style="progress.download")

# Generated at 2022-06-24 10:30:39.641088
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test FractionColumn.render: no decimal precision of fraction if unit is 1."""
    task = None
    obj_FractionColumn = FractionColumn(unit_scale=False, unit_divisor=1000)
    result = obj_FractionColumn.render(task)
    assert result is None
    result = obj_FractionColumn.render(task=Progress(total=100))
    assert isinstance(result, Text)
    assert result.text == "0/100 "
    assert result.style == "progress.download"

# Generated at 2022-06-24 10:30:49.130428
# Unit test for method render of class FractionColumn

# Generated at 2022-06-24 10:30:52.104178
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from types import GeneratorType
    t = tqdm_rich(range(10))
    assert isinstance(t, GeneratorType)

# Generated at 2022-06-24 10:30:56.059073
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn(unit='bps')
    assert rate.render(Progress(total=7)) == Text("0.0 bps/s", style="progress.data.speed")
    assert rate.render(Progress(total=7, speed=11)) == Text("11.0 bps/s", style="progress.data.speed")



# Generated at 2022-06-24 10:31:07.671750
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render(Progress(total=10)) == Text('0.0/0.0 ', style='progress.download')
    assert fc.render(Progress(total=42, completed=42)) == Text('0.0/0.0 ', style='progress.download')

    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(Progress(total=1024)) == Text('0.0/0.0 K', style='progress.download')
    assert fc.render(Progress(total=1048576)) == Text('0.0/0.0 M', style='progress.download')
    assert fc.render(Progress(total=1073741824)) == Text('0.0/0.0 G', style='progress.download')


# Generated at 2022-06-24 10:31:11.842568
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn(unit_scale=True)
    rc.render(None)
    rc = RateColumn(unit_scale=True, unit_divisor=10)
    rc.render(None)

# Generated at 2022-06-24 10:31:15.846496
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest import mock

    with mock.patch('rich.progress.Progress.__exit__') as _:
        with tqdm_rich(disable=True) as t:
            t.close()

# Generated at 2022-06-24 10:31:19.589093
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm import tqdm
    from time import sleep
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    for i in tqdm(range(4)):
        sleep(1)
    console = Console()
    prog = Progress(Text("test"), transient=True)
    task_id = prog.add_task("test", total=4)
    prog.__enter__()
    prog.update(task_id, completed=2)
    prog.__exit__(None, None, None)

test_tqdm_rich_display()

# Generated at 2022-06-24 10:31:24.234130
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test basic functionality."""
    with tqdm(total=100) as t:
        for i in _range(1, 101, 1):
            t.set_description(f"{i}%")
            t.set_postfix({"i": i})
            t.display()
            t.update()

# Generated at 2022-06-24 10:31:27.134573
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as progress:
        progress.reset(total=100)
        for i in range(100):
            progress.update(1)

# Generated at 2022-06-24 10:31:33.216879
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == Text('? /s', style='progress.data.speed')
    assert RateColumn().render(type('', (), {'speed': None})) == Text('? /s', style='progress.data.speed')
    assert RateColumn().render(type('', (), {'speed': 1.23})) == Text('1.23 /s', style='progress.data.speed')
    assert RateColumn().render(type('', (), {'speed': 123.4567})) == Text('123.46 /s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True).render(type('', (), {'speed': 0})) == Text('0 B/s', style='progress.data.speed')

# Generated at 2022-06-24 10:31:38.367675
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    column = FractionColumn(unit_scale=True)
    column = FractionColumn(unit_scale=True, unit_divisor=1024)
    column = FractionColumn(unit_scale=False, unit_divisor=1)


# Generated at 2022-06-24 10:31:43.711833
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test that tqdm_rich.reset() works with staticly created instances"""
    tqdm_var = tqdm_rich(total=10, desc="foo")
    assert tqdm_var.total == 10

    tqdm_var.reset(total=20)
    assert tqdm_var.total == 20

    tqdm_var.reset()
    assert tqdm_var.total == 0

# Generated at 2022-06-24 10:31:46.649617
# Unit test for function trange
def test_trange():  # pragma: no cover
    from time import sleep
    for i in trange(10, desc="test"):
        sleep(0.1)

# Generated at 2022-06-24 10:31:49.118826
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=100)
    t.display()
    t.update()
    t.display()
    t.update()

# Generated at 2022-06-24 10:31:59.120454
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test that tqdm_rich.clear does not raise any exceptions."""
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    with StringIO() as f:
        with tqdm(file=f) as bar:
            # clear() should do nothing for tqdm
            bar.clear()
        try:
            with tqdm(file=None) as bar:
                # clear() should do nothing for tqdm
                bar.clear()
        except TypeError:
            # if no file is specified, tqdm will try to use sys.stderr,
            # which is not defined in context of this test
            pass

# Generated at 2022-06-24 10:32:07.662442
# Unit test for function trange
def test_trange():
    from .tests import _test_tqdm_max_width, _test_trange_iterable, \
        _test_trange_total, _test_trange_leave, _test_trange_miniters, \
        _test_trange_smoothing, _test_trange_dynamic_miniters

    _test_trange_iterable(tqdm, trange)
    _test_trange_total(tqdm, trange)
    _test_trange_leave(tqdm, trange)
    _test_trange_miniters(tqdm, trange)
    _test_trange_smoothing(tqdm, trange)
    _test_trange_dynamic_miniters(tqdm, trange)
    _test_tqdm

# Generated at 2022-06-24 10:32:16.596294
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.table import Table
    from rich.text import Text

# Generated at 2022-06-24 10:32:25.982494
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .gui import tqdm
    for _ in tqdm_rich([0, 1, 2], bar_format="{l_bar}{bar}|",
                       progress=(Text("[progress.description]{task.description}"),
                                 Text("[progress.percentage]{task.percentage:>2}%"),)):
        assert isinstance(tqdm._prog, Progress)
        assert isinstance(tqdm._prog.layout.columns[1], ProgressColumn)
        assert isinstance(tqdm._prog.layout.columns[0], Text)
        assert isinstance(tqdm._prog.layout.columns[2], BarColumn)
        assert tqdm._prog.layout.columns[2].bar_width is None
        # Test reset()

# Generated at 2022-06-24 10:32:33.290366
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from types import ModuleType
    from io import StringIO
    from unittest import TestCase


    class _Test(TestCase):
        def test_tqdm_rich_clear(self):
            # test tqdm_rich method clear that is expected to do nothing
            with tqdm(total=2) as pbar:
                # This is the function that uses the method tqdm_rich.clear
                # The function is a method of class tqdm_rich
                pbar.clear()

            f = StringIO()
            with tqdm(total=2, file=f) as pbar:
                pbar.clear()
                self.assertEqual(f.getvalue(), '')


        # test tqdm_rich method clear with redirection of stream to module

# Generated at 2022-06-24 10:32:38.440726
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    ufc = FractionColumn()
    assert ufc.render(1) is not None
    assert ufc.render(1.5) is not None
    assert ufc.render(2.555) is not None
    assert ufc.render(1000000) is not None



# Generated at 2022-06-24 10:32:42.146174
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_obj = FractionColumn()
    assert test_obj.unit_scale == False
    assert test_obj.unit_divisor == 1000

    assert test_obj.render(Progress()) == Text("0.0/0.0 ", style="progress.download")


# Generated at 2022-06-24 10:32:46.163195
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .tqdm import tqdm
    from .gui import tqdm_gui
    # test tqdm_rich constructor
    with tqdm_gui(range(3)) as t:
        t.close()
    with tqdm(range(3)) as t:
        t.close()

# Generated at 2022-06-24 10:32:52.801700
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm()
    task.speed = 100000
    rate = RateColumn()
    assert rate.render(task).text == "100.0 /s"

    task = std_tqdm()
    task.speed = 1.25
    rate = RateColumn()
    assert rate.render(task).text == "1.3 /s"

    task = std_tqdm()
    task.speed = 1000
    rate = RateColumn(unit="B")
    assert rate.render(task).text == "1000.0 B/s"

    task = std_tqdm()
    task.speed = 100
    rate = RateColumn(unit="B")
    assert rate.render(task).text == "100.0 B/s"

    task = std_tqdm()
    task.speed = 0.25

# Generated at 2022-06-24 10:32:57.953720
# Unit test for constructor of class RateColumn
def test_RateColumn():
    length = 100
    for unit in ['KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB']:
        rate = RateColumn(unit, unit_scale=False, unit_divisor=1000)
        assert rate.render(length) == f'100.0 {unit}/s'


# Generated at 2022-06-24 10:33:00.516076
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=1) as pbar:
        assert pbar.disable == False
        pbar.close()
        assert pbar.disable == True



# Generated at 2022-06-24 10:33:08.191926
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test display method of tqdm_rich."""
    from os import extsep
    from tempfile import gettempdir
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    bar = BarColumn(bar_width=10)
    fraction = FractionColumn()
    count_file = console = None

# Generated at 2022-06-24 10:33:13.295807
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import datetime
    rate_column = RateColumn()
    task = Progress.Task(now=datetime.datetime(1999, 1, 1),
                         total=1000, completed=100, speed=100)
    assert rate_column.render(task).string == "100.0 /s", \
        "RateColumn.render(task) failed"

# Generated at 2022-06-24 10:33:19.190817
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        # This should create a new instance of the tqdm_rich class
        # and then exit the GUI
        with tqdm(total=100) as t:
            for _ in range(100):
                t.update()
    except Exception as e:
        assert False, e


if __name__ == "__main__":  # pragma: no cover
    with tqdm(total=100) as t:
        for _ in range(100):
            t.update()

# Generated at 2022-06-24 10:33:22.598867
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test whether method close of class tqdm_rich is working correctly."""
    try:
        it = tqdm_rich([1,2,3,4,5])
        it.close()
    except Exception:
        assert False
    assert True



# Generated at 2022-06-24 10:33:25.560720
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn()) == "0/0"
    assert str(FractionColumn(True)) in ("0/0 B", "0/0 KB", "0/0 MB", "0/0 GB", "0/0 TB")

# Generated at 2022-06-24 10:33:29.144518
# Unit test for function trange
def test_trange():
    from time import sleep

    bar1 = trange(100, desc="bar1", leave=False)
    # bar2 = trange(200, desc="bar2", leave=True)
    bar3 = trange(300, desc="bar3")
    for i in bar1:
        sleep(.01)
    for i in bar3:
        sleep(.03)

# Generated at 2022-06-24 10:33:37.460127
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():

    # Test case without total argument (total remains unchanged)
    tqdm_test_1 = tqdm_rich(total=5)
    assert tqdm_test_1.total == 5
    tqdm_test_1.reset()
    assert tqdm_test_1.total == 5

    # Test case with total argument (total is reset)
    tqdm_test_2 = tqdm_rich(total=10)
    assert tqdm_test_2.total == 10
    tqdm_test_2.reset(total=5)
    assert tqdm_test_2.total == 5

# Generated at 2022-06-24 10:33:43.586681
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        t = tqdm_rich(
            [1, 2, 3],
            progress=(
                "[progress.description]{task.description}",
                "[progress.percentage]{task.percentage:>4.0f}%",
                BarColumn(bar_width=None))
        )
        for x in t:
            pass
        t.display()
        t.close()
    except BaseException:
        tqdm.write("tqdm_rich method display encountered"
                   " an issue; please report")
        raise


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    from tqdm import tqdm
    from .std import tnrange

    # Test

# Generated at 2022-06-24 10:33:45.858262
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in tqdm(range(0, 10)):
        pass

# Generated at 2022-06-24 10:33:48.286861
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=1)
    t.close()
    assert not t._prog.is_active

# Generated at 2022-06-24 10:33:52.547073
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="/s", unit_scale=False).render(Progress(0, 0)) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="/s", unit_scale=True).render(Progress(0, 0)) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-24 10:33:57.132491
# Unit test for constructor of class RateColumn
def test_RateColumn():
    d = {'unit': '', 'unit_divisor': 1000, 'unit_scale': False}
    progress = RateColumn('', False, 1000)
    assert progress.unit == d['unit']
    assert progress.unit_scale == d['unit_scale']
    assert progress.unit_divisor == d['unit_divisor']

# Generated at 2022-06-24 10:33:58.373760
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm(total=4) as t:
        t.display()

# Generated at 2022-06-24 10:34:04.883592
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    """Unit test for method reset of class tqdm_rich."""
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    progress = Mock()
    progress.__enter__ = Mock(return_value=0)
    progress.__exit__ = Mock(return_value=0)
    progress.add_task = Mock(return_value=1)
    progress.update = Mock(return_value=0)
    progress.reset = Mock(return_value=0)

    # Setup testing environment
    bar = tqdm_rich(desc='Test', total=10, progress=progress)
    bar.reset(total=20)

    # Check that reset was called
    assert progress.reset.call_count == 1

# Generated at 2022-06-24 10:34:06.762903
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .tests import test_range
    test_range(trange)

# Generated at 2022-06-24 10:34:13.759131
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from sys import stdout

    with tqdm_rich(unit='B', unit_scale=True, unit_divisor=1024, miniters=1,
                   desc='Rich progress', total=1000, mininterval=1/6,
                   disable=False, ascii=False, file=stdout, leave=True,
                   ncols=None, mininterval=0.1, miniters=1) as t:
        for i in t:
            t.update(1)
            if i > 500:
                break

# Generated at 2022-06-24 10:34:18.738065
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    try:
        import rich
    except ImportError:
        return

    pbar = tqdm_rich(total=10)
    pbar.reset(10)
    pbar.update(2)
    pbar.clear(1, 1)
    pbar.clear(1)
    pbar.display()
    pbar.close()

# Generated at 2022-06-24 10:34:25.137034
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .std import tqdm_msg_deprecate
    with tqdm_msg_deprecate('"tqdm_rich" is deprecated; use "tqdm" with gui=True', fp_write=lambda _: None):
        tqdm_rich(total=1)
        tqdm(total=1, gui=True)


# Generated at 2022-06-24 10:34:30.802628
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = FractionColumn()

if __name__ == '__main__':  # pragma: no cover
    import atexit
    import time
    with tqdm(total=200, leave=True) as pbar:
        for i in range(200):
            time.sleep(0.01)
            pbar.update(1)
    atexit.register(lambda: pbar.clear())
    print("Done")
    input("Press Enter to continue...")

# Generated at 2022-06-24 10:34:41.127338
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # pylint: disable=protected-access
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress("Test", transient=False, console=console)

# Generated at 2022-06-24 10:34:44.151166
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Tests that progress bar can be restarted."""
    # Recreate a temporary progress bar
    from time import sleep

    pbar = tqdm_rich(total=100)
    for _ in pbar:
        sleep(.01)
    pbar.reset(total=50)
    for _ in pbar:
        sleep(.01)

# Generated at 2022-06-24 10:34:55.642255
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import pytest
    from rich.progress import Task
    output = FractionColumn().render(Task(completed=12, total=64))
    assert output.text == '0.2/0.6 K'
    output = FractionColumn().render(Task(completed=1000000, total=6400000))
    precision = 1 if output.text.split('/')[0].count('.') > 0 else 0
    assert output.text == '0.2/0.6 M'
    output = FractionColumn().render(Task(completed=1000000, total=64000))
    precision = 1 if output.text.split('/')[0].count('.') > 0 else 0
    assert output.text == '1,000.0/6,400.0 K'

# Generated at 2022-06-24 10:35:03.209877
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test display method of class tqdm_rich."""
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    progress_mock = MagicMock()
    task_mock = MagicMock()
    progress_mock.add_task.return_value = 1
    progress_mock.tasks = [task_mock]

# Generated at 2022-06-24 10:35:05.633431
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Unit test constructor of class FractionColumn."""
    column = FractionColumn(False)
    assert isinstance(column, ProgressColumn)

# Generated at 2022-06-24 10:35:06.981164
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with trange(5) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:35:11.928901
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    FractionColumn()
    FractionColumn(unit_scale=True)
    FractionColumn(unit_scale=False)
    FractionColumn(unit_divisor=1024)
    FractionColumn(unit_scale=True, unit_divisor=1024)



# Generated at 2022-06-24 10:35:18.170796
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    assert rate.render(30) == Text('30.0 B/s', style='progress.data.speed')


if __name__ == "__main__":  # pragma: no cover
    from time import sleep

    pbar = tqdm_rich(total=100)
    for i in range(100):
        sleep(0.1)
        pbar.update()
    pbar.close()

# Generated at 2022-06-24 10:35:28.778082
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column1 = FractionColumn()
    column2 = FractionColumn(unit_scale=True, unit_divisor=1000)
    column3 = FractionColumn(unit_scale=True, unit_divisor=1024)
    column4 = FractionColumn(unit_scale=False, unit_divisor=1024)

    assert(column1.render(Progress(total=1000)) == Text("1.0/1.0 ", style="progress.download"))
    assert(column1.render(Progress(total=1002)) == Text("1.0/1.0 ", style="progress.download"))
    assert(column1.render(Progress(total=10023)) == Text("10.0/10.0 ", style="progress.download"))

# Generated at 2022-06-24 10:35:35.197073
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # tqdm_rich.reset()
    with tqdm_rich(total=10) as pbar:
        assert pbar.unit == 'it'
        assert pbar.unit_scale == False
        assert pbar.unit_divisor == 1000
        assert pbar.total == 10
        assert pbar.leave == False
        assert pbar.gui == True
        assert pbar.desc == None

    # tqdm_rich.reset(total=10000)
    with tqdm_rich(total=10) as pbar:
        pbar.reset(total=10000)
        assert pbar.total == 10000
