

# Generated at 2022-06-24 10:25:35.294804
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test for method `tqdm_rich.close`
    """
    range_ = range(1)
    with tqdm_rich(range_) as t:
        t.update(1)
        assert t.n == 1
        t.close()
        assert t.n == 1

# Generated at 2022-06-24 10:25:36.176061
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    _ = FractionColumn()(Progress)

# Generated at 2022-06-24 10:25:39.125176
# Unit test for function trange
def test_trange():
    """Run: `test/test_rich.py tqdm.tqdm.rich.trange`"""
    from .tests import _test_sanity
    for i in trange(3):
        _test_sanity(i)

# Generated at 2022-06-24 10:25:46.555961
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    ft_column = FractionColumn(unit_scale=True)
    assert ft_column.unit_scale
    assert ft_column.unit_divisor == 1000
    assert ft_column.render(task=None) == Text("0.0/0.0", style="progress.download")
    assert ft_column.render(task=
        type('', (object,), {'total': 1000, 'completed': 500})()) == Text("0.5/1.0 K", style="progress.download")
    assert ft_column.render(task=
        type('', (object,), {'total': 10000, 'completed': 5000})()) == Text("5.0/10.0 K", style="progress.download")

    assert ft_column.unit_scale == True
    assert ft_column.unit_divisor == 1000
   

# Generated at 2022-06-24 10:25:49.046228
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    test_task = ProgressColumn()
    test_task.completed = 123
    test_task.total = 4567

    test_instance = FractionColumn()
    assert test_instance.render(test_task) == Text(
        '0.1/4.6 ',
        style='progress.download')



# Generated at 2022-06-24 10:25:59.170338
# Unit test for constructor of class RateColumn
def test_RateColumn():
    base_kwargs = dict(unit="", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-24 10:26:01.110974
# Unit test for function trange
def test_trange():
    from time import sleep
    from tqdm import trange
    for i in trange(4, leave=True):
        sleep(0.5)

# Generated at 2022-06-24 10:26:10.062705
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.theme import Theme

    theme = Theme({
        "description": "dim magenta",
        "progress": "dim white",
        "progress.percentage": "magenta",
        "progress.bar.completed": "dim white",
        "progress.bar.remaining": "dim white",
        "progress.data.speed": "green",
        "progress.data": "white",
        "progress.download": "dim green",
        "progress.upload": "dim green",
        "progress.time": "white",
    })


# Generated at 2022-06-24 10:26:13.878994
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    tqdm_rich.reset(total=5) should update the total value of the progress bar.
    """
    progress = tqdm_rich(total=10, ncols=100)
    assert progress.total == 10
    progress.reset(total=5)
    assert progress.total == 5

# Generated at 2022-06-24 10:26:19.587278
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method `render` of class `RateColumn`
    """
    from rich.progress import Task
    from rich import text
    from rich.traceback import Traceback

    def test(task, expect, unit, unit_scale, unit_divisor):
        """
        Function to test `render` with various combinations of arguments
        """
        rate_column = RateColumn(unit=unit, unit_scale=unit_scale, unit_divisor=unit_divisor)
        try:
            got = str(rate_column.render(task))
        except Exception as ex:
            got = Traceback(ex).plaintext
        assert got == expect, Traceback(f"Expect: ({expect})\nGot: ({got})")

    # Test `Render` of class `RateColumn`

# Generated at 2022-06-24 10:26:24.619977
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os, sys
    import time
    from math import sqrt
    from os.path import join

    from tqdm.rich import tqdm_rich
    from tqdm.auto import tqdm

    for __ in tqdm_rich(range(100), position=0):
        for ___ in tqdm(range(100), position=1, leave=True):
            for ____ in tqdm(range(100), position=2, leave=True):
                for _____ in tqdm(range(100), position=3, leave=True):
                    time.sleep(1e-2)


# Generated at 2022-06-24 10:26:28.993095
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Create a RichProgressBar object and test its constructor
    """
    bar = RateColumn()
    bar.render({'task': {'completed': '32.3', 'total': '123'},
                'speed': '123', 'desc': 'Downloading'})


# Generated at 2022-06-24 10:26:30.070839
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update(1)

# Generated at 2022-06-24 10:26:31.991227
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich

    Test case to check if method reset call super class method
    """
    tiq = tqdm_rich(10)
    assert tiq.n == 0
    tiq.reset(total=20)
    assert tiq.total == 20

# Generated at 2022-06-24 10:26:36.747420
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import time
    for i in tqdm_rich(range(100), desc="test", leave=True):
        time.sleep(.01)
    for i in trange(100, desc="test", leave=True):
        time.sleep(.01)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich()

# Generated at 2022-06-24 10:26:43.405214
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(ProgressColumn.TestTask(speed=None, total=None)).text == "? B/s"
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(ProgressColumn.TestTask(speed=1033, total=None)).text == "1.0 KB/s"
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(ProgressColumn.TestTask(speed=1033, total=None)).text == "1.0 KB/s"


# Generated at 2022-06-24 10:26:53.245036
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import tqdm
    from .std import trange

    with tqdm(total=30) as t:
        for i in trange(30):
            t.update(1)
            t.set_description("1.12M/s", refresh=True)
            t.set_description("12.2M/s", refresh=True)
            t.set_description("123M/s", refresh=True)
            t.set_description("1.23G/s", refresh=True)
            t.set_description("10.2G/s", refresh=True)
            t.set_description("100.1G/s", refresh=True)
            t.set_description("1.00T/s", refresh=True)
            t.set_description("10.0T/s", refresh=True)


# Generated at 2022-06-24 10:26:54.872425
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(3)):
        _.clear(3, 5)



# Generated at 2022-06-24 10:26:59.633707
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Unit test.
    """
    fc = FractionColumn()
    gc = FractionColumn(unit_scale=True, unit_divisor=1000)
    print(fc.render(task=None))
    print(gc.render(task=None))



# Generated at 2022-06-24 10:27:01.583494
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn()
    column.render(Progress(""))

# Generated at 2022-06-24 10:27:09.929496
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import unittest
    class TestRateColumnMethods(unittest.TestCase):
        def test_RateColumn(self):
            self.assertTrue(RateColumn(unit="B").render({'speed': 1024}) == Text("1.0 KB/s", style="progress.data.speed"))
            self.assertTrue(RateColumn(unit="B", unit_scale = True, unit_divisor = 1024).render({'speed': 1024}) == Text("1.0 B/s", style="progress.data.speed"))
            self.assertTrue(RateColumn(unit="B", unit_scale = True).render({'speed': 1024}) == Text("1.0 KB/s", style="progress.data.speed"))

# Generated at 2022-06-24 10:27:15.766562
# Unit test for function trange
def test_trange():
    def check(k, n):
        """Checks the output and final state of trange"""
        with trange(n, desc=str(k)) as t:
            assert t.total == n
            assert not t.disable
            for i in t:
                assert i == t.n
                assert i <= t.total
            assert t.total == t.n
            assert t.n == n

    for k in [0, 1, 5, 10, 100]:
        check(k, k)
        check(k, k+1)


if __name__ == '__main__':  # pragma: no cover
    from .main import _test_functionality
    _test_functionality(tqdm_rich)

# Generated at 2022-06-24 10:27:24.168970
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render(Progress.create_task(description="", total=100)) == Text("100.0/100.0 ", style="progress.download")
    assert fc.render(Progress.create_task(description="", total=1000)) == Text("1.0/1.0 K", style="progress.download")
    assert fc.render(Progress.create_task(description="", total=12345678)) == Text("12.3/12.3 M", style="progress.download")
    assert fc.render(Progress.create_task(description="", total=1234567890)) == Text("1.2/1.2 G", style="progress.download")

# Generated at 2022-06-24 10:27:25.758230
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-24 10:27:34.357667
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(100)==Text(f"100 /s", style="progress.data.speed")
    assert rate_column.render(200)==Text(f"200 /s", style="progress.data.speed")
    assert rate_column.render(None)==Text(f"? /s", style="progress.data.speed")
    rate_column.unit='kB'
    assert rate_column.render(None)==Text(f"? kB/s", style="progress.data.speed")
    assert rate_column.render(100)==Text(f"100 kB/s", style="progress.data.speed")
    assert rate_column.render(200)==Text(f"200 kB/s", style="progress.data.speed")
    rate_column.unit_scale

# Generated at 2022-06-24 10:27:40.874647
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Functional test of tqdm.trange/tqdm_rich."""
    from time import sleep
    for _ in trange(4, desc='1st loop'):
        for _ in trange(5, desc='2nd loop'):
            for _ in trange(50, desc='3nd loop', leave=True):
                sleep(0.01)
                pass
            pass
        pass

# Generated at 2022-06-24 10:27:44.695165
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method reset of class tqdm_rich."""
    with tqdm_rich(10, unit_scale=True, unit_divisor=1024) as t:
        for i in t:
            t.reset(50)
        assert t._prog.total == 50
        assert t.total == 50

# Generated at 2022-06-24 10:27:47.778089
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()



# Generated at 2022-06-24 10:27:48.650758
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn()) == '0.00/? '


# Generated at 2022-06-24 10:27:52.315576
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=20) as t:
        for i in range(20):
            t.clear()
            t.update()
            assert not t.n  # noqa: WPS421 (falsy)

# Generated at 2022-06-24 10:27:57.579045
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test close() method of class tqdm_rich
    """
    try:
        with tqdm_rich(total=2, bar_format="{l_bar}{bar}{r_bar}", leave = False) as t:
            t.update()
            t.update()
    except Exception as e:
        raise AssertionError("This function should not throw an exception") from e

# Generated at 2022-06-24 10:28:01.220856
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test for method close of class tqdm_rich."""
    pr = tqdm_rich(rng)
    pr.close()
    # pr._prog.__exit__(None, None, None)



# Generated at 2022-06-24 10:28:10.292576
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.progress import Progress
    from rich.console import Console, ConsoleOptions
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.markup import Markup
    from rich.text import Text
    from rich.table import Table

    # Setup terminal
    console = Console(console_options=ConsoleOptions(force_terminal=True))
    progress = Progress.renderer(os=os, sys=sys, console=console)
    progress.clear_screen = True

    # Test stuff
    with progress:
        task1 = progress.add_task("fizz", total=100,
                                  postfix=[("var1", 10), ("var2", 20)])
        task2 = progress.add_task("buzz", total=100)

# Generated at 2022-06-24 10:28:14.787296
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    #pylint: disable=unused-argument
    rate = 1
    unit = "B"
    unit_scale = True
    unit_divisor = 1000
    rate_column = RateColumn(unit, unit_scale, unit_divisor)
    assert rate_column.render(rate) == "1 B/s"

# Generated at 2022-06-24 10:28:21.824441
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.unit_scale == False
    assert column.unit_divisor == 1000
    column = FractionColumn(unit_scale=True)
    assert column.unit_scale == True
    assert column.unit_divisor == 1000
    column = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert column.unit_scale == True
    assert column.unit_divisor == 1024

# Generated at 2022-06-24 10:28:23.829096
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(10))
    t.clear()
    t.close()

# Generated at 2022-06-24 10:28:30.104652
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    >>> r = RateColumn()
    >>> r.render(object)
    Text("None B/s", style="progress.data.speed")
    >>> r.unit = 'B'
    >>> r.render(object)
    Text("None B/s", style="progress.data.speed")
    >>> r.unit = ''
    >>> r.render(object)
    Text("None /s", style="progress.data.speed")
    >>> r.render(object)
    Text("None /s", style="progress.data.speed")
    """
    pass

# Generated at 2022-06-24 10:28:39.939618
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import rich
    import rich.progress
    import time
    import os
    import sys

    progress = Progress(TimeElapsedColumn(), "<", TimeRemainingColumn(),
                        ",", RateColumn(unit="b"), "]")
    progress.__enter__()
    task = progress.add_task("dummy_task", start=time.time(), total=100, completed=0)

    # assert before render
    task.completed = 50
    task.speed = 100
    assert task._state.completed == 50
    assert task._state.speed == 100

    # put render
    progress.render(task)

    # assert after render
    assert task._state.completed == 50
    assert task._state.speed == "100b/s"

# Generated at 2022-06-24 10:28:43.239505
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test that resets work properly."""
    with tqdm(10) as bar:
        bar.reset(total=20)
        bar.reset(total=None)
        bar.reset(total=30)



# Generated at 2022-06-24 10:28:44.104768
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit='B', unit_scale=True) != None

# Generated at 2022-06-24 10:28:50.919744
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test case 1
    # If speed is None, format is '? unit/s'
    task = lambda: None
    task.completed = None
    task.total = None
    task.speed = None
    task.dynamic_ncols = lambda: None
    rate_column = RateColumn('MB')
    assert rate_column.render(task) == Text('? MB/s')

    # Test case 2
    # If unit = 1, format is 'speed unit/s'
    task = lambda: None
    task.completed = None
    task.total = None
    task.speed = 1
    task.dynamic_ncols = lambda: None
    rate_column = RateColumn('MB')
    assert rate_column.render(task) == Text('1 MB/s')

    # Test case 3
    # If

# Generated at 2022-06-24 10:28:55.065733
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(desc='id', total=10) as progress:
        progress.close()
    with tqdm_rich(desc='id', total=20) as progress:
        progress.close()
    with tqdm_rich(desc='id', total=30) as progress:
        progress.close()

# Generated at 2022-06-24 10:29:01.540148
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Run traitlets tqdm_rich.display method with mocked object."""
    with tqdm_rich(total=2, desc='Test description') as prog:
        prog._prog = mock.MagicMock()
        prog._prog.add_task = mock.MagicMock()
        prog.display()
        prog._prog.update.assert_called_with(prog._task_id, completed=0, description='Test description')

# Generated at 2022-06-24 10:29:05.628556
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # test if the constructor is completed
    fraction = FractionColumn()
    assert fraction is not None
    assert fraction._number_formatter is None
    # test if the constructor can accept parameters
    fraction = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fraction is not None


# Generated at 2022-06-24 10:29:13.062904
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import unittest
    from .std import tqdm

    class TestTqdmReset(unittest.TestCase):
        def test_reset_to_zero(self):
            for total in [None, 1000, 2000]:
                t = tqdm(total=total)
                for i in range(100):
                    t.update()
                t.reset()  # reset to 0
                for i in range(100):
                    t.update()
                self.assertEqual(t.n, 100)
                self.assertEqual(t.n, t.total)

        def test_reset_to_positive(self):
            for total in [1000, 2000]:
                t = tqdm(total=2000)
                for i in range(100):
                    t.update()
                t

# Generated at 2022-06-24 10:29:19.126895
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest

    class TestRateColumn(unittest.TestCase):
        def test_render(self):
            task = mock.MagicMock()
            task.speed = 1000
            rateColumn = RateColumn(unit="")
            self.assertEqual(rateColumn.render(task),
                             Text(f"1.0 K/s", style="progress.data.speed"))

    unittest.main()


# Generated at 2022-06-24 10:29:25.375931
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm.auto import tqdm as tqdm_auto

    for cls in [tqdm_rich, tqdm_auto]:
        for total in [None, 10, 20, 0]:
            name = "{:>12} {}".format(cls.__name__, total)
            with cls(
                    total=10,
                    file=None,
                    leave=True,
                    dynamic_ncols=True,
                    disable=False,
            ) as pbar:
                assert pbar.total == 10, f"{name} failed: {pbar.total}"
                pbar.reset(total)
                assert pbar.total == total, f"{name} failed: {pbar.total}"

# Generated at 2022-06-24 10:29:32.987694
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # tqdm_rich cls and its instance (with callable argument)
    tqdm_rich_cls, tqdm_rich_inst = tqdm_rich(iter(range(5)),
                                              desc='test_tqdm_rich',
                                              disable=1)
    # Testing the method clear of class tqdm_rich
    try:
        tqdm_rich_inst.clear()
    except NotImplementedError:
        pass

# Generated at 2022-06-24 10:29:35.433455
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total = 2)
    t.update()
    t.clear()
    t.update()


# Generated at 2022-06-24 10:29:44.103480
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tgrange
    import random
    random.seed(0)
    for _ in tgrange(4, desc='trange', unit='it', mininterval=1.0,
                     leave=True,
                     bar_format='{desc}: {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'):
        n = random.randint(3, 99)
        for _ in trange(n,
                        desc='inner loop',
                        mininterval=.5,
                        leave=True,
                        ascii=True):
            pass

# Generated at 2022-06-24 10:29:51.981172
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    >>> r = RateColumn()
    >>> task = Progress(total=1)
    >>> r.render(task)
    Text('0  /s', style='progress.data.speed')
    """


if __name__ == '__main__':
    # Unit test for method render of class FractionColumn
    # Unit test of class tqdm_rich
    dh = Progress(total=300)
    dh.__enter__()
    dh_id = dh.add_task(
        'Uploading...',
        total=300,
        bar_width=None,
        progress_symbol='=',
        empty_char=' ',
        info_sep=' ',
        style='progress.upload',
    )

# Generated at 2022-06-24 10:30:01.334289
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    import os
    import time

    # set stream to non-blocking
    if hasattr(sys.stdout, 'fileno'):
        from fcntl import fcntl, F_GETFL, F_SETFL
        flags = fcntl(sys.stdout, F_GETFL)  # get current p.stdout flags
        fcntl(sys.stdout, F_SETFL, flags | os.O_NONBLOCK)

# Generated at 2022-06-24 10:30:12.071494
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="", unit_scale=True, unit_divisor=1000
                      ).render(
                          BarColumn(bar_width=None)).markup == "[progress.data.speed]? B/s"
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000
                      ).render(
                          BarColumn(bar_width=None)).markup == "[progress.data.speed]? B/s"
    assert RateColumn(unit="", unit_scale=True, unit_divisor=1024
                      ).render(
                          BarColumn(bar_width=None)).markup == "[progress.data.speed]? B/s"

# Generated at 2022-06-24 10:30:15.930528
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import tqdm
    from .utils import format_sizeof

    with tqdm(total=1000) as t:
        for i in range(1000):
            t.update()

# Generated at 2022-06-24 10:30:24.675010
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import TaskID

    expected_init_total = 10
    expected_reset_total = 20

    pb = tqdm(total=expected_init_total, ascii=True, desc='Downloading files...')
    pb.update(5)
    task_id = pb._task_id
    pb.reset(total=expected_reset_total)
    assert pb.total == expected_reset_total
    assert pb.n == 0
    assert isinstance(pb._task_id, TaskID)
    assert pb._task_id == task_id
    assert pb._prog._task_id_to_data[task_id]['total'] == expected_reset_total
    assert pb.n == 0
    pb.close()

# Generated at 2022-06-24 10:30:26.570410
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit_scale = True, unit_divisor = None)
    rate = rate_column.render(Task())
    print(rate)


# Generated at 2022-06-24 10:30:35.503144
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # test if the method render will return the expected string
    # test case 1
    completed = 100
    total = 100
    unit_scale = False
    unit_divisor = 1000
    column = FractionColumn(unit_scale, unit_divisor)
    expect = Text("100/100", style="progress.download")
    assert column.render(task=Task(completed=completed, total=total)) == expect
    # test case 2
    completed = 10042
    total = 10042
    unit_scale = True
    unit_divisor = 1000
    column = FractionColumn(unit_scale, unit_divisor)
    expect = Text("10.0/10.0 K", style="progress.download")
    assert column.render(task=Task(completed=completed, total=total)) == expect
   

# Generated at 2022-06-24 10:30:38.745989
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    column = RateColumn()
    # task.speed is None
    assert column.render(object()) == Text(f"? /s", style="progress.data.speed")

# Generated at 2022-06-24 10:30:42.183785
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress, BarColumn, TextColumn
    progress = Progress(
        BarColumn(bar_width=None),
        TextColumn("[progress.description]{task.description}"),
        transient=False,
        no_output=True)
    t = tqdm_rich(iterable=range(10), total=10, progress=progress)
    t.close()
    del t
    progress.__exit__(None, None, None)
    del progress



# Generated at 2022-06-24 10:30:45.688570
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    p = tqdm_rich(total=1, leave=False)
    assert p.n == 0
    assert p.total == 1
    p.update()
    assert p.n == 1
    assert p.total == 1
    p.close()

# Generated at 2022-06-24 10:30:48.982807
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)
    rate_column.render(task=36)
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    rate_column.render(task=36)

# Generated at 2022-06-24 10:30:53.716925
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for i in tqdm(range(10)):
        assert i == 0
    for i in tqdm(range(10)):
        assert i == 1
    for i in trange(10):
        assert i == 2
    for i in trange(10):
        assert i == 3

# Generated at 2022-06-24 10:30:55.591384
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10, desc="test", leave=False) as progress_:
        for _ in progress_:
            pass



# Generated at 2022-06-24 10:31:00.249884
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        # raises the Exception if import fails
        from rich.progress import ProgressTest as Progress
    except ImportError:  # pragma: no cover
        pass
    else:
        # mock Progress class
        with Progress.mock(_enter_=lambda *args, **kwargs: None,
                           _exit_=lambda *args, **kwargs: None,
                           __exit__=lambda *args, **kwargs: None) as progress:
            with tqdm_rich(total=1) as t:
                # mock Progress.__exit__
                progress._exit_ = lambda: None
                t.close()
            # check if Progress.__exit__ is called
            assert progress._exit_ is not None

# Generated at 2022-06-24 10:31:08.428972
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import os
    import sys
    t = tqdm_rich(10)
    t.update(5)
    d = t.format_dict
    assert d['n'] == 5
    assert d['total'] == 10
    t.close()
    temp = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    t = tqdm_rich(10)
    t.update(5)
    d = t.format_dict
    assert d['n'] == 5
    assert d['total'] == 10
    t.close()
    sys.stdout = temp

# Generated at 2022-06-24 10:31:16.507725
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .__main__ import _test
    import time

    try:
        r_bar = tqdm_rich(range(10))
        for r_i in r_bar:
            time.sleep(0.01)
            r_bar.display()
            time.sleep(0.01)
        r_bar.close()
    except:
        raise AssertionError("Test failed")

    try:
        r_bar = tqdm_rich(range(10), leave=True)
        for r_i in r_bar:
            time.sleep(0.01)
            r_bar.display()
            time.sleep(0.01)
        r_bar.close()
    except:
        raise AssertionError("Test failed")

    _test()



# Generated at 2022-06-24 10:31:24.717996
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Method display of class tqdm_rich."""
    import random
    import time
    random.seed(6)
    with tqdm_rich(total=10) as pbar:
        for _ in pbar:
            pbar.set_description("pbar")
            pbar.display()
            time.sleep(0.1)
    random.seed(4)
    with tqdm_rich(total=10) as pbar:
        for _ in pbar:
            pbar.display()
            pbar.set_description("bar")
            time.sleep(0.1)



# Generated at 2022-06-24 10:31:37.295009
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test case 1:
    Test if FractionColumn.render(task) return value is correct when completed <= 1 000
    and total <= 1 000 (integer).
    """
    task = Progress(description='description', total=1000)
    task.completed = 100
    assert FractionColumn().render(task).__str__() == "100.0/1,000"
    """
    Test case 2:
    Test if FractionColumn.render(task) return value is correct when completed > 1 000
    and total > 1 000 (integer).
    """
    task = Progress(description='description', total=10000)
    task.completed = 1000
    assert FractionColumn().render(task).__str__() == "1.0/10.0 K"

# Generated at 2022-06-24 10:31:40.360674
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    old = tqdm_rich(total=50, leave=False)
    old.reset(total=100)
    old.reset(total=150)
    old.reset()
    old.reset()
    old.close()

# Generated at 2022-06-24 10:31:41.429283
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit_scale=True)
    assert RateColumn(unit_scale=False)

# Generated at 2022-06-24 10:31:45.647692
# Unit test for function trange
def test_trange():
    with trange(3) as t:
        assert t.format_dict
        assert t.format_dict['0'] == '{0}'
        for _ in t:
            pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:31:50.522671
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    progress_column.render_task(0, 100) == Text("0.0/100.0", style="progress.download")
    progress_column.unit_scale = True
    progress_column.render_task(0, 100) == Text("0/100", style="progress.download")



# Generated at 2022-06-24 10:32:02.308353
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # ------------------------
    # Test of basic usage
    # ------------------------
    f = FractionColumn()

    fragment = f.render(None)

    assert fragment == Text("0.0/0.0", style="progress.download")

    # ------------------------
    # Test of scale

    # with scale
    f = FractionColumn(unit_scale=True)

    # when total is less than 1000
    fragment = f.render(Progress.Task(completed=0, total=999))

    assert fragment == Text("0.0/0.0", style="progress.download")

    # when total is more than 1000
    fragment = f.render(Progress.Task(completed=0, total=1001))

    assert fragment == Text("0.0/0.0 K", style="progress.download")

    # without scale
    f = Fraction

# Generated at 2022-06-24 10:32:07.994480
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class FakeProgress:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    test = FractionColumn()
    assert test.render(FakeProgress(2, 3)) == Text('0.7/1.0 ', style='progress.download')

# Generated at 2022-06-24 10:32:10.504573
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    inst = tqdm_rich(["1", "2", "3"], desc='desc')
    inst.clear()
    inst.close()

# Generated at 2022-06-24 10:32:13.743093
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column.unit_scale == True
    assert column.unit_divisor == 1000


# Generated at 2022-06-24 10:32:15.604309
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=5) as pbar:
        pbar.clear(None, None)

# Generated at 2022-06-24 10:32:16.510315
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(1))
    t.clear()

# Generated at 2022-06-24 10:32:21.599802
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test tqdm_rich.clear(self)"""
    # Test 1
    with tqdm_rich(range(0, 100), miniters=1) as t:
        t.clear()

    # Test 2
    with tqdm_rich(range(0, 100), miniters=1) as t:
        for x in t:
            t.clear()


# Generated at 2022-06-24 10:32:32.056151
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    from unittest.mock import patch, MagicMock
    import time
    import tempfile

    tempdir = tempfile.TemporaryDirectory()


# Generated at 2022-06-24 10:32:33.948832
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .gui import tgrange
    from time import sleep
    for i in tgrange(100):
        sleep(0.1)

# Generated at 2022-06-24 10:32:43.376770
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from io import StringIO
    from unittest import mock

    # Create a StringIO object
    f = StringIO()

    #Create a tqdm_rich object
    pbar = tqdm_rich(iterable=[1, 2, 3], file=f, total=4, unit='iB', unit_scale=True, unit_divisor=1024)

    assert pbar.disable is False

    # Check if the progress bar is displayed in the StringIO object
    assert 'iB/s' in f.getvalue()

    # Clear the progress bar
    pbar.clear()

    # check if the progress bar is cleared
    assert 'iB/s' not in f.getvalue()

# Generated at 2022-06-24 10:32:44.925105
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Reset tqdm progress bar
    tqdm_rich(total=10).reset(total=5)

# Generated at 2022-06-24 10:32:50.719819
# Unit test for function trange
def test_trange():
    """Tests that tqdm_rich and trange are linked"""
    f = tqdm(range(10))
    f.close()


if __name__ == "__main__":  # pragma: no cover
    # test tqdm_rich and trange
    test_trange()
    # test rich.progress
    progress = Progress()
    # add a task with a description
    task = progress.add_task("Processing file", start=0, total=10)

    for _ in range(10):
        progress.update(task, advance=1)

    # update the task with a new description
    progress.update(task, description="Done!")

# Generated at 2022-06-24 10:32:53.652623
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.progress import Console
    console = Console()
    t = tqdm(total=9, leave=True, desc="test", console=console)
    t.clear()
    t.close()
    assert True

# Generated at 2022-06-24 10:32:56.135454
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm_rich(0, 2):
        assert i == 0
        break
    for i in tqdm_rich(0, 2):
        assert i == 1

# Generated at 2022-06-24 10:33:01.668194
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    This test will run tqdm_rich and get some outputs to inspect
    """
    try:
        with tqdm_rich(total=10, desc="Testing...") as bar:
            for i in bar:
                bar.display()
    except Exception as e:
        print(str(e) + '\n')
        print("Please check if you are running in Jupyter Notebook")

# Generated at 2022-06-24 10:33:12.436588
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test the __init__ method of tqdm_rich."""
    assert isinstance(tqdm_rich(total=10)._prog, Progress)
    assert isinstance(tqdm_rich(total=10)._prog._columns[1], BarColumn)
    assert isinstance(tqdm_rich(total=10)._prog._columns[2],
                      FractionColumn)
    assert isinstance(tqdm_rich(total=10)._prog._columns[3],
                      TimeElapsedColumn)
    assert isinstance(tqdm_rich(total=10)._prog._columns[4],
                      TimeRemainingColumn)
    assert isinstance(tqdm_rich(total=10)._prog._columns[5],
                      RateColumn)


# Generated at 2022-06-24 10:33:14.896136
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Method clear should not raise any Exception."""
    with tqdm(total=42, leave=False) as bar:
        bar.clear()

# Generated at 2022-06-24 10:33:22.599110
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = type('', (), {'completed' : 1.0, 'total' : 3.0})()
    total = int(task.total)
    completed = int(task.completed)
    unit, suffix = filesize.pick_unit_and_suffix(
        completed,
        ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        1,
    )
    precision = 0 if unit == 1 else 1
    assert f"{completed/unit:,.{precision}f}/{total/unit:,.{precision}f} {suffix}" == "1.0/3.0 "


# Generated at 2022-06-24 10:33:24.470082
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pbar = tqdm_rich(total=10)
    pbar.display()

# Generated at 2022-06-24 10:33:25.756565
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn()
    assert column == RateColumn()



# Generated at 2022-06-24 10:33:32.937892
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(range(10), progress=(
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
            ",", RateColumn(), "]"), unit='B') as rich_tqdm:
        rich_tqdm.close()

# Generated at 2022-06-24 10:33:33.683859
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    f = tqdm_rich()
    f.close()

# Generated at 2022-06-24 10:33:37.261102
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time

    with tqdm_rich(total=100, unit='B', unit_scale=True, unit_divisor=1024) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update(10)
        t.reset()
    assert t.n == 0

# Generated at 2022-06-24 10:33:40.604948
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    bar = tqdm_rich(total=3)
    bar.update()
    assert bar.n == 1
    bar.update()
    assert bar.n == 2
    bar.reset(total=4)
    assert bar.n == 0
    assert bar.total == 4
    bar.update()
    assert bar.n == 1

# Generated at 2022-06-24 10:33:42.634550
# Unit test for constructor of class RateColumn
def test_RateColumn():
    i = RateColumn()
    j = RateColumn()
    assert i == j

# Generated at 2022-06-24 10:33:53.354163
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        import rich
    except ImportError:
        return
    from .std import tqdm_gui
    from .utils import _supports_unicode
    t = tqdm_rich(range(3), desc="tqdm_rich")
    for i in t:
        if i >= 1:
            t.close()
    t = tqdm_gui(range(3), desc="tqdm_gui")
    for i in t:
        if i >= 1:
            t.close()
    t = tqdm_rich(range(3), desc="", unit=('B', 'K') if _supports_unicode() else 'BK')
    for i in t:
        if i >= 1:
            t.close()

# Generated at 2022-06-24 10:33:57.752793
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import random
    unit = "iB"
    unit_scale = True
    unit_divisor = 1024
    speed = random.randint(1, 10000)
    task = RateColumn(unit, unit_scale, unit_divisor)
    text = task.render(speed)
    assert text.startswith("5.5")

# Generated at 2022-06-24 10:33:58.826575
# Unit test for function trange
def test_trange():
    """Test tqdm function for no unit."""
    for _ in trange(4, 0, -1):
        pass

# Generated at 2022-06-24 10:34:05.129343
# Unit test for constructor of class RateColumn
def test_RateColumn():
    s = RateColumn("B")
    assert str(s.render("task")) == "? B/s"
    s = RateColumn("B", unit_scale=True)
    assert str(s.render("task")) == "? /s"
    s = RateColumn("B", unit_divisor=1024)
    assert str(s.render("task")) == "? B/s"

# Generated at 2022-06-24 10:34:13.035626
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    import unittest
    class test(unittest.TestCase):
        def test_constructor(self):
            class TaskTest:
                def __init__(self, total=None, completed=None):
                    self.total = total
                    self.completed = completed
                
                def __call__(self, *args, **kwargs):
                    return TaskTest(*args, **kwargs)

            tqdm_task = TaskTest(total=999, completed=666)
            F = FractionColumn()
            res = F.render(tqdm_task)
            self.assertEqual(res.text, '0.667/0.999')

    unittest.main()

if __name__ == "__main__":
    test_FractionColumn()

# Generated at 2022-06-24 10:34:23.733001
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from io import StringIO
    from rich.console import Console
    from rich.panel import Panel
    column_instance = RateColumn(unit="K")
    task_instance = type("", (), {"speed": None})()
    column_instance.render(task_instance)
    assert(column_instance.render(task_instance) == Text("? K/s", style="progress.data.speed"))
    task_instance = type("", (), {"speed": int(15000)})()
    assert(column_instance.render(task_instance) == Text("15.0 K/s", style="progress.data.speed"))
    task_instance = type("", (), {"speed": int(1200000)})()
    assert(column_instance.render(task_instance) == Text("1.2 M/s", style="progress.data.speed"))
   

# Generated at 2022-06-24 10:34:32.964618
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Test constructor of class FractionColumn.
    """
    from tests._utils import _Counter
    from rich.progress import Task

    task = Task(description="test description", total=100)

    # Case 1: default parameters
    col1 = FractionColumn()
    s = col1.render(task)
    assert s == Text('0.0/100.0', style='progress.download')

    # Case 2: set unit_scale=True
    col2 = FractionColumn(unit_scale=True)
    s = col2.render(task)
    assert s == Text('0/100 K', style='progress.download')

    # Case 3: set unit_divisor=2000
    col3 = FractionColumn(unit_divisor=2000)
    s = col3.render(task)

# Generated at 2022-06-24 10:34:35.578382
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from unittest.mock import patch
    with patch('tqdm.rich.std.tqdm.clear') as mock_clear:
        trange(100).clear()
        assert mock_clear.called

# Generated at 2022-06-24 10:34:45.309727
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    RateColumn converts the data transfer speed to human readable format.
    """
    import rich.progress  # noqa
    progress = Progress(
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",",
        RateColumn(unit="B", unit_scale=False, unit_divisor=1000),
        "]"
    )

    # Test that infinity speed is shown as '? B/s'
    task = progress.add_task("Downloading", total=100, start=0)
    progress.update(task, completed=10)

# Generated at 2022-06-24 10:34:47.646600
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    return

if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-24 10:34:57.872983
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    col = FractionColumn()
    class _task(object):
        """Mock of rich.progress.Task"""
        def __init__(self):
            self.completed = 1
            self.total = 3

    assert col.render(_task()) == Text('1/3 ', style='progress.download')

    col = FractionColumn(True)
    assert col.render(_task()) == Text('0.3/1.0 K', style='progress.download')

    col = FractionColumn(True, 10)
    assert col.render(_task()) == Text('0.3/1.0 K', style='progress.download')

    col = FractionColumn(True, 100)
    assert col.render(_task()) == Text('0.3/1.0 K', style='progress.download')


# Generated at 2022-06-24 10:35:00.505206
# Unit test for function trange
def test_trange():
    """Test trange()"""
    for _ in tqdm(trange(10), total=10, ncols=80):
        pass

# Generated at 2022-06-24 10:35:06.353933
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(Progress.from_values(1, 1 << 30)).text.strip() == "1.0/1.0 "
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(Progress.from_values(1, 1 << 30)).text.strip() == "1.0/1.0 K"


# Generated at 2022-06-24 10:35:09.128994
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm(total=10)
    for i in range(10):
        t.update()

    t.reset()
    for i in range(10):
        t.update()

    t.close()

# Generated at 2022-06-24 10:35:20.432942
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from unittest import mock
    except ImportError:  # pragma: no cover
        from unittest.mock import mock

    # Creating a mock object of class Progress, for testing
    mock_progress = mock.MagicMock()

    # Creating mock objects for the following methods:
    # 1) add_task()
    # 2) update()
    # 3) reset()
    mock_progress.add_task.return_value = 100
    mock_progress.update = mock.MagicMock()
    mock_progress.reset = mock.MagicMock()

    # Creating a mock object of the class tqdm_rich, for testing
    mock_tqdm = mock.MagicMock(spec=tqdm_rich)

    # Setting the following attributes, so that the class tqdm_rich
    # will run

# Generated at 2022-06-24 10:35:22.399943
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    with tqdm(disable=True) as bar:
        bar.display()  # should not crash

# Generated at 2022-06-24 10:35:25.177897
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:35:32.756416
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test the method reset of class tqdm_rich"""
    from rich.progress import TaskID
    progress_bar = tqdm_rich(total=9)
    progress_bar._prog.update(TaskID(1), completed=0, total=9)
    progress_bar.n = 9
    progress_bar.close()
    progress_bar.reset()
    assert(progress_bar.n == 0)
    assert(progress_bar.total == 9)
    assert(progress_bar._prog.get(TaskID(1)).total == 9)
    assert(progress_bar._prog.get(TaskID(1)).completed == 0)

