

# Generated at 2022-06-24 10:25:27.949038
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for `trange`.
    """
    assert list(trange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-24 10:25:32.833956
# Unit test for function trange
def test_trange():
    from .utils import FormatStdout, SimpleTextIOWrapper
    from io import BytesIO

    stream = BytesIO()
    with FormatStdout(stream) as fs:
        foo = tqdm(range(100), desc='foo', ascii=True, ncols=80)
        for x in foo:
            pass
        foo.close()
    assert 'foo     ' in SimpleTextIOWrapper(stream).read()

# Generated at 2022-06-24 10:25:35.699309
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        import rich
    except ImportError:
        return
    try:
        progress = tqdm_rich(total=10)
        progress.close()
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:25:38.993760
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        import rich
        import rich.progress
    except ImportError:
        return
    pbar = tqdm_rich(total=10, desc='test_display')
    for _ in pbar:
        pass
    assert pbar.n == pbar.total

# Generated at 2022-06-24 10:25:44.795620
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import pytest
    with pytest.raises(SystemExit):
        tqdm_rich(unit_scale=True, unit_divisor=1000,
                  desc="testing tqdm_rich close function",
                  unit="B", miniters=1, mininterval=0.1,
                  disable=False).close()

# Generated at 2022-06-24 10:25:52.160375
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich"""
    # Create a tqdm_rich instance for testing.
    t = tqdm_rich(total=100)
    t.reset(total=200)
    assert t.total == 200
    assert t._prog.__enter__().total == 200
    t.reset()
    assert t.total == 100
    assert t._prog.__enter__().total == 100
    t.reset(80)
    assert t.total == 80
    assert t._prog.__enter__().total == 80

# Generated at 2022-06-24 10:25:55.319915
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest.mock import patch
    import rich.progress

    tqdminstance = tqdm_rich(range(20), gui=True)
    with patch.object(rich.progress.Progress, '__exit__') as exitmock:
        tqdminstance.close()
        assert exitmock.called
        assert tqdminstance.disable == True


# Generated at 2022-06-24 10:25:59.143911
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import time
    import numpy as np

    n = 100
    sleep = 0.01
    with tqdm_rich(total=n, unit='B', unit_scale=True, 
                   unit_divisor=1024, miniters=1, mininterval=1) as t:
        t.set_description('Downloading')
        for _ in trange(n):
            time.sleep(sleep)
            t.update()


if __name__ == "__main__":
    test_RateColumn()

# Generated at 2022-06-24 10:26:07.508554
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.console import Console
    from rich.progress import TaskID
    from rich.style import Style
    from rich.text import Text

    console = Console()
    task_id = TaskID(1)
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None, style="progress.bar"),
        " [", TimeElapsedColumn(), " <", TimeRemainingColumn(), "]",
        transient=False)

    with progress:
        task = progress.add_task("A long job", total=100)

# Generated at 2022-06-24 10:26:14.457548
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method reset of class tqdm_rich"""
    import time
    from random import random

    # from tqdm.rich import tqdm_rich
    # from tqdm.tests import _range, pretest_posttest

    for _ in tqdm_rich(_range(10), total=10, desc="test_tqdm_rich_reset"):
        time.sleep(random() / 5)
    for _ in tqdm_rich(_range(10), total=10, desc="test_tqdm_rich_reset"):
        time.sleep(random() / 5)

# Generated at 2022-06-24 10:26:15.275418
# Unit test for constructor of class RateColumn
def test_RateColumn():
    m = RateColumn()

# Generated at 2022-06-24 10:26:27.612525
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest
    import rich.progress
    import tqdm.rich
    import tqdm.utils

    class RateColumnTest(unittest.TestCase):
        def test_render(self):
            task = rich.progress.ProgressTask(
                description="RateColumnTest", total=100)
            task.completed = 1
            task.speed = 2
            test_object = tqdm.rich.RateColumn()
            actual_output = test_object.render(task)
            expected_output = (
                'tqdm.rich.Text(string="2.00 b/s", '
                'layout="progress.data.speed")')
            self.assertEqual(
                tqdm.utils.repr_(actual_output), expected_output)

# Generated at 2022-06-24 10:26:29.724833
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    with tqdm_rich(total=10) as t:
        t.clear()

# Generated at 2022-06-24 10:26:30.961486
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-24 10:26:35.901754
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    t = tqdm(iterable=[], total=0, unit="B", unit_scale=True, unit_divisor=1024)
    t.set_postfix(file=27, speed=20)
    t.update(0)
    assert RateColumn().render(t) == Text(f"{20/1000:,.0f} KB/s", style="progress.data.speed")



# Generated at 2022-06-24 10:26:37.664245
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    assert f.unit_scale == False
    assert f.unit_divisor == 1000


# Generated at 2022-06-24 10:26:43.814281
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    try:
        import rich
    except ModuleNotFoundError:
        raise SkipTest("Rich is needed for the test")
    import unittest
    import sys
    import io

    class Test_Tqdm_rich(unittest.TestCase):
        """Test for the tqdm_rich method display()."""
        def setUp(self):
            self.orig = sys.stdout
            self.s = io.StringIO()
            sys.stdout = self.s

        def test_display(self):
            """Test the tqdm_rich method display()."""
            # Test case 1
            total = 5
            t = tqdm_rich(total=total)
            for i in range(total):
                t.update(1)
            t.close()

# Generated at 2022-06-24 10:26:46.893759
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Unit test for method clear of class tqdm_rich
    """
    with tqdm.tqdm_rich(desc='Some description', total=5, disable=True) as progress_bar:
        for index, item in enumerate(range(5)):
            progress_bar.update(n=1)
            progress_bar.set_description(f'item {item}')
            progress_bar.display()
            progress_bar.clear()

# Generated at 2022-06-24 10:26:50.426491
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1) as t:
        assert t.__dict__["n"] == 0
        t.clear()
        assert t.__dict__["n"] == 0

# Generated at 2022-06-24 10:26:52.715597
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(True, 1024)
    assert column.unit_scale == True
    assert column.unit_divisor == 1024


# Generated at 2022-06-24 10:27:00.621237
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    def real_tqdm_rich_close(t):
        return t.disable or t.leave or \
            t.miniters > t.dynamic_miniters or t.dynamic_miniters < t.miniters
    # Test all possible values of real_tqdm_rich_close
    test_matrix = [[False] * 4, [False] * 4, [False] * 4, [False] * 4]
    for i in range(4):
        test_matrix[0][i] = True
        for j in range(4):
            test_matrix[1][j] = True
            for k in range(4):
                test_matrix[2][k] = True

# Generated at 2022-06-24 10:27:03.185125
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Unit test for constructor of class tqdm_rich
    """
    from .tests import experimental_tqdm_main
    # pylint: disable=too-many-function-args
    experimental_tqdm_main(tqdm_rich)

# Generated at 2022-06-24 10:27:05.116094
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Testing for total argument in tqdm_rich.reset
    with tqdm_rich(100) as bar:
        bar.reset(total=100)

# Generated at 2022-06-24 10:27:07.208257
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    t = tqdm(total=10)
    assert t.total == 10
    t.reset(total=20)
    assert t.total == 20

# Generated at 2022-06-24 10:27:10.625871
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from time import sleep
    with tqdm(total=10, desc="test_tqdm_rich_clear") as pbar:
        sleep(1)
        pbar.clear()
        sleep(1)


# Generated at 2022-06-24 10:27:18.949060
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich.display method."""
    from tqdm import tqdm
    for i in tqdm(range(10)):
        pass
    assert hasattr(tqdm, '_prog')
    assert hasattr(tqdm, '_task_id')
    tqdm.display()
    assert tqdm.disable is None
    tqdm.disable = False
    tqdm.display()
    assert tqdm.disable is False
    tqdm.disable = None
    tqdm.disable = True
    tqdm.display()
    assert tqdm.disable is True



# Generated at 2022-06-24 10:27:28.912434
# Unit test for constructor of class RateColumn
def test_RateColumn():
    expected = "10.0 KB/s"
    rate_column = RateColumn(unit="B")
    assert(rate_column.render(Progress()).content == expected)
    expected = "10.0 KB/s"
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert(rate_column.render(Progress()).content == expected)
    expected = "10.0 KB/s"
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert(rate_column.render(Progress()).content == expected)
    expected = "10.0 KB/s"
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-24 10:27:36.515137
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    print("Testing RateColumn.render:")
    print("[1] no speed")
    rate_column = RateColumn()
    print("[2] with speed")
    rate_column = RateColumn(speed=10)
    print("[3] with speed unit")
    rate_column = RateColumn(speed=10, unit="B")
    print("[4] with unit_scale")
    rate_column = RateColumn(speed=10, unit_scale=True)
    print("[5] with unit_divisor")
    rate_column = RateColumn(speed=10, unit_scale=True, unit_divisor=1024)
    print("one more...")
    rate_column = RateColumn(speed=10, unit=" B")
    print("Done\n")


# Generated at 2022-06-24 10:27:37.819574
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich()

# Generated at 2022-06-24 10:27:42.096555
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich"""
    t = tqdm_rich(10)
    t.reset(total=20)
    assert t.total == 20
    t.reset()
    assert t.total == 20
    t.reset(total=30)
    assert t.total == 30

# Generated at 2022-06-24 10:27:45.958424
# Unit test for function trange
def test_trange():
    from itertools import islice

    list(tqdm_rich(["0", "1", "2"], desc="Testing"))
    assert (list(islice(trange(4), 1, 3)) == [1, 2])
    assert (list(islice(trange(4), 1, 3)) == [1, 2])
    assert (list(islice(trange(4), 1, 3)) == [1, 2])



# Generated at 2022-06-24 10:27:56.504453
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import SimpleTextIOWrapper
    import io
    from .utils import _environ_cols_wrapper
    from .std import _environ_cols_wrapper as std_environ_cols_wrapper

    with _environ_cols_wrapper(80):
        for unit_scale in [False, True]:
            for unit_divisor in [1000, 1024]:
                for completed, total in [[1000, 2000], [9.942, 16.50], [1024, 2048]]:
                    fc = FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
                    text = fc.render(std_tqdm(total=total, unit_scale=unit_scale,
                                              unit_divisor=unit_divisor))
                    text = fc

# Generated at 2022-06-24 10:27:57.633044
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    FractionColumn()


# Generated at 2022-06-24 10:28:00.317459
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep

    with tqdm_rich(total=4) as pbar:
        for i in range(4):
            sleep(0.1)
            pbar.update()


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-24 10:28:03.449260
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(ProgressColumn)
    assert FractionColumn(unit_scale=False).render(ProgressColumn)
    assert FractionColumn(unit_divisor=1000).render(ProgressColumn)

# Generated at 2022-06-24 10:28:09.822158
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        with tqdm(total=3) as pbar:
            assert pbar.total == 3
            assert pbar.n == 0
            pbar.reset(total=2)
            assert pbar.total == 2
            assert pbar.n == 0
            assert pbar.dynamic_messages == {}
            pbar.reset()
            assert pbar.total == None
            assert pbar.n == 0
            assert pbar.dynamic_messages == {}
            pbar.reset(total=1)
            assert pbar.total == 1
            assert pbar.n == 0
            assert pbar.dynamic_messages == {}
    except Exception:
        raise

# Generated at 2022-06-24 10:28:14.394109
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=5,miniters=5) as pbar:
        pbar.reset(total=10)
        assert pbar.total == 10
        assert pbar.n == 0
        assert pbar.nmin == 10
        assert pbar.last_print_n == 0



# Generated at 2022-06-24 10:28:17.527700
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=100) as t:
        for i in tqdm(_range(100)):
            t.update()
    assert t.n == 100

# Generated at 2022-06-24 10:28:25.080523
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():

    t = tqdm_rich(total=1000)
    t.update(10)
    assert t.n != 0
    assert t.n != 1000

    t.reset()
    assert t.n == 0
    t.update(10)
    assert t.n != 0
    assert t.n != 1000

    t.reset(total=2000)
    assert t.n == 0
    assert t.total == 2000
    t.update(20)
    assert t.n != 0
    assert t.n != 2000

# Generated at 2022-06-24 10:28:33.460923
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Tests rich.progress display method of class tqdm_rich."""
    import rich.progress
    original_update = rich.progress.Progress.update
    try:
        p = tqdm_rich(2, desc="foobar", leave=True, unit='B', unit_scale=True,
                      unit_divisor=1024, mininterval=0.5)
        p.display()
        rich.progress.Progress.update = lambda *args, **kwargs: None
        p.display()
    finally:
        rich.progress.Progress.update = original_update
    # Test reset method of class tqdm_rich
    test_tqdm_rich_reset()



# Generated at 2022-06-24 10:28:39.224488
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn('bps')._suffix_divisor == 8
    assert RateColumn('bps', unit_scale=True)._suffix_divisor == 1000
    assert RateColumn('bps', unit_divisor=1024)._suffix_divisor == 1024


# Generated at 2022-06-24 10:28:44.227235
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Arrange
    args = [100]
    kwargs = {'bar_format': '[{l_bar}{bar}{r_bar}]'}
    tqdm_rich_object = tqdm_rich(*args, **kwargs)

    # Act
    tqdm_rich_object.clear()

    # Assert
    # (nothing to assert since there is no return)
    return

# Generated at 2022-06-24 10:28:51.109212
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test the method FractionColumn.render()
    """
    class FakeProgress:
        """
        Fake class to replace rich.progress.Progress()
        """
        def __init__(self, *_, **__):
            self.completed = None
            self.total = None

        def add_task(self, description, *_, **__):
            self.description = description
            self.completed = 2
            self.total = 15
            return self.completed/self.total

        def reset(self, *_, **__):
            self.completed = 3
            self.total = 16

        def update(self, id, *_, **__):
            self.id = id

    class FakeTask:
        """
        Fake class to replace rich.progress.Task()
        """

# Generated at 2022-06-24 10:28:56.740984
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    from rich.traceback import install

    install()
    prog = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None)
    )
    prog.__enter__()
    task_id = prog.add_task("Download", total=10)
    for _ in range(10):
        prog.update(task_id, completed=_)
    prog.__exit__()


if __name__ == "__main__":
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:29:02.742892
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Check if the method close works properly in the class tqdm_rich."""
    assert hasattr(tqdm_rich, 'close')
    assert callable(tqdm_rich.close)
    # Check if closing works
    with tqdm(total=10) as t:
        for i in _range(10):
            t.update()
    assert t.n == 10
    t.close()


# Generated at 2022-06-24 10:29:09.190500
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Test cases for constructor of class RateColumn.
    """
    rate_column = RateColumn();
    assert rate_column.unit == "";
    assert rate_column.unit_scale == False;
    assert rate_column.unit_divisor == 1000;

    rate_column = RateColumn(unit="o", unit_scale=True, unit_divisor=250);
    assert rate_column.unit == "o";
    assert rate_column.unit_scale == True;
    assert rate_column.unit_divisor == 250;


# Generated at 2022-06-24 10:29:10.600184
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test FractionColumn constructor."""
    assert FractionColumn()

# Generated at 2022-06-24 10:29:16.681503
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    tqdm_rich(0, leave=True, desc="test")
    for n in tqdm_rich(range(10), desc="test1"):
        sleep(0.1)
    for n in tqdm_rich(range(10), desc="test2", disable=True):
        sleep(0.1)

# Generated at 2022-06-24 10:29:18.410867
# Unit test for function trange
def test_trange():
    from .gui import _test_new_tqdm
    _test_new_tqdm(trange)

# Generated at 2022-06-24 10:29:19.471112
# Unit test for function trange
def test_trange():  # pragma: no cover
    try:
        sum(trange(int(1e6)))
    except ImportError:
        pass



# Generated at 2022-06-24 10:29:24.485295
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    import rich.progress as progress

    class FakeTask(progress.Task):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    unit_scale = False
    unit_divisor = 1000
    obj = FractionColumn(unit_scale, unit_divisor)
    total = 100
    completed = 50
    task = FakeTask(completed, total)
    assert obj.render(task) == Text(f"{completed}/{total}", style="progress.download")

# Generated at 2022-06-24 10:29:25.245881
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    rate.render(None)

# Generated at 2022-06-24 10:29:37.234904
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class Task(object):
        speed = None
        completed = 0
        total = 100
    assert RateColumn("B", unit_scale=False, unit_divisor=1).render(Task) == Text("? B/s", style="progress.data.speed")
    Task.speed = 999
    assert RateColumn("B", unit_scale=False, unit_divisor=1).render(Task) == Text("999 B/s", style="progress.data.speed")
    Task.speed = 1000
    assert RateColumn("B", unit_scale=False, unit_divisor=1).render(Task) == Text("1.0 KB/s", style="progress.data.speed")
    Task.speed = 1000000
    assert RateColumn("B", unit_scale=False, unit_divisor=1).render(Task) == Text

# Generated at 2022-06-24 10:29:41.420243
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    test if method display has been executed.
    """
    t = tqdm_rich(total=1000000)
    t._display = False
    t.update()
    assert t._display is True

# Generated at 2022-06-24 10:29:50.248646
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Initialization of a FractionColumn for testing."""
    task = tqdm_rich(total=10)
    total = task.total
    completed = task.n
    unit = float(total)
    f = FractionColumn(unit_scale=False, unit_divisor=1)
    assert f.render(task) == Text(f"{completed/unit:,.0f}/{total/unit:,.0f}",
                                  style="progress.download")
    task.update(1)
    completed = task.n
    unit = float(total)
    assert f.render(task) == Text(f"{completed/unit:,.0f}/{total/unit:,.0f}",
                                  style="progress.download")
    task.update(1)
    completed = task.n
   

# Generated at 2022-06-24 10:29:55.297793
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    #print(vars(f))
    assert vars(f) == {'task': None, 'width': None, 'alignment': None, 'compact': False, 'unit_scale': False, 'unit_divisor': 1000, 'min_width': None}
    assert f.unit_scale == False

# Generated at 2022-06-24 10:29:56.319827
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-24 10:29:58.799626
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    t = tqdm_rich(0, desc='Clear test')
    t.clear()
    t.display()

# Generated at 2022-06-24 10:30:09.958632
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    task = tqdm_rich(1,1)

    # Default
    temp = FractionColumn()
    # completed set to 0.
    task.n = 0
    # total set to 100
    task.total = 100
    # check the class function
    assert temp.render(task).text == "0.0/0.1"

    # unit_scale = True
    temp = FractionColumn(unit_scale=True)
    # completed set to 100
    task.n = 100
    # check the class function
    assert temp.render(task).text == "0.1/0.1"

    # unit_scale = True, unit_divisor = 1024
    temp = FractionColumn(unit_scale=True, unit_divisor=1024)
    # check the class function
    assert temp.render(task).text

# Generated at 2022-06-24 10:30:17.756144
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    # startup
    with tqdm_rich(total=10) as tr:
        assert tr.total == 10
        tr.set_description("desc")

    # no startup
    tr = tqdm_rich()
    tr.total = 10
    assert tr.total == 10
    assert tr.last_print_n == 0
    tr.update(2)
    assert tr.n == 2
    assert tr.last_print_n == 2
    tr.update(3)
    assert tr.n == 5
    assert tr.last_print_n == 5
    tr.n = 6
    assert tr.n == 6
    assert tr.last_print_n == 6
    assert tr.format_dict["n_fmt"] == "{n:.0f}"
    tr.close()
   

# Generated at 2022-06-24 10:30:23.118556
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from .std import tqdm as std_tqdm

    pbar = std_tqdm(total=100, unit='B', miniters=0, unit_scale=True)

    for i in pbar:
        if i == 100:
            break
        pbar.update()
    pbar.close()
    pbar.clear()

# Generated at 2022-06-24 10:30:25.443095
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    p = FractionColumn()
    assert callable(p)
    assert p.render is not None


# Generated at 2022-06-24 10:30:30.750192
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    assert f.render({'completed': 2, 'total': 6}) == Text('0.3/2.0 ', style="progress.download")
    assert f.render({'completed': 0, 'total': 0}) == Text('0/0 ', style="progress.download")
    assert f.render({'completed': 4000, 'total': 6000}) == Text('0.6/2.0 K', style="progress.download")
    assert f.render({'completed': 4e+6, 'total': 6e+6}) == Text('0.6/2.0 M', style="progress.download")
    assert f.render({'completed': 4e+9, 'total': 6e+9}) == Text('0.6/2.0 G', style="progress.download")
    assert f.render

# Generated at 2022-06-24 10:30:34.108483
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Ensure RateColumn can be initialized properly."""
    # Ensure initialization without arguments can be done without error
    RateColumn()
    # Ensure initialization with arguments can be done without error
    RateColumn(unit="", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-24 10:30:45.438330
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from .utils import bytes
    from rich.progress import clear
    from collections import namedtuple

    task = namedtuple(
        'task', ['completed', 'total', 'speed'])(completed=100, total=100, speed=100)
    clear()
    FractionColumn()(task)
    FractionColumn(unit_scale=True)(task)
    FractionColumn(unit_scale=True, unit_divisor=1024)(task)
    FractionColumn(unit_scale=False, unit_divisor=1024)(task)
    FractionColumn(unit_scale=False, unit_divisor=1024)(task)
    try:
        FractionColumn(unit_scale=False, unit_divisor=1024)(task)
    except ValueError:
        pass

# Generated at 2022-06-24 10:30:47.924135
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from time import sleep
    for _ in tqdm_rich(range(4), "test"):
        sleep(0.01)

# Generated at 2022-06-24 10:30:53.330790
# Unit test for function trange
def test_trange():
    from .utils import _test_range
    _test_range(trange)

    with trange(12, unit_scale=True) as prg:
        for _ in prg:
            pass

    with trrange(12, unit_scale=True) as prg:
        for _ in prg:
            pass


# Generated at 2022-06-24 10:30:55.312619
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in trange(3, desc="test"):
        pass

# Generated at 2022-06-24 10:30:56.538214
# Unit test for function trange
def test_trange():  # pragma: no cover
    from time import sleep

    for i in trange(5):
        sleep(0.3)

# Generated at 2022-06-24 10:31:02.170069
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn(unit_scale=True, unit_divisor=1000)
    assert FractionColumn(unit_scale=False, unit_divisor=1000)
    assert FractionColumn(unit_scale=True)
    assert FractionColumn()

test_FractionColumn()

# Generated at 2022-06-24 10:31:04.328611
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # Initialize instance of tqdm_rich with a fixed max value
    tq = tqdm_rich(total=10, leave=True)

    # Execute the close method of the instance
    tq.close()



# Generated at 2022-06-24 10:31:14.205399
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    total = 100000
    task = next(tqdm_rich(range(100000), total=total, ncols=100))
    task.speed = total
    assert (RateColumn(unit='', unit_scale=True, unit_divisor=1000).render(task)).format == \
        '100.0 K/s'
    assert (RateColumn(unit='/s', unit_scale=True, unit_divisor=1000).render(task)).format == \
        '100.0 K/s'
    assert (RateColumn(unit='/s', unit_scale=True, unit_divisor=1000).render(task)).format == \
        '100.0 K/s'
    total = 10000
    task = next(tqdm_rich(range(10000), total=total, ncols=100))
   

# Generated at 2022-06-24 10:31:25.431150
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Task
    from rich.progress import Progress  # noqa

    class fake_tqdm(tqdm_rich):
        def __init__(self, *args, **kwargs):
            super(fake_tqdm, self).__init__(*args, **kwargs)
            self.n = 1
            self.total = 100
            self.format_dict = {"unit_scale": False, "unit": "", "desc": "test"}

        def display(self, *_, **__):
            super(fake_tqdm, self).display(_, __)

    with Progress(Task(description='foo', total=10)) as progress:
        t = foo = fake_tqdm(range(10), progress=progress)
        bar = FooBar()
        bar.bar()


# Generated at 2022-06-24 10:31:37.785357
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import pandas as pd
    import numpy as np
    # Importing the dataset
    dataset = pd.read_csv('Churn_Modelling.csv')
    X = dataset.iloc[:, 3:13].values
    y = dataset.iloc[:, 13].values
    # Encoding categorical data
    from sklearn.preprocessing import LabelEncoder, OneHotEncoder
    labelencoder_X_1 = LabelEncoder()
    labelencoder_X_2 = LabelEncoder()
    X[:, 1] = labelencoder_X_1.fit_transform(X[:, 1])
    X[:, 2] = labelencoder_X_2.fit_transform(X[:, 2])
    onehotencoder = OneHotEncoder(categorical_features = [1])
    X = onehotenc

# Generated at 2022-06-24 10:31:48.171064
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from unittest import TestCase
    from . import trange

    class Tqdm_richTest(TestCase):
        """Test class for testing the constructor of class tqdm_rich."""
        def test_constructor(self):
            """Test tqdm rich constructor with multiple parameter combinations."""
            self.assertEqual(len(list(trange(10))), 10)
            self.assertEqual(len(list(trange(3, 10))), 7)
            self.assertEqual(len(list(trange(3, 10, 2))), 4)
            self.assertEqual(len(list(trange(3, 8, 4))), 2)
            self.assertEqual(len(list(trange(10, 0, -1))), 10)
            self.assertE

# Generated at 2022-06-24 10:31:53.410880
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    print(FractionColumn(unit_scale=True, unit_divisor=1000).render({'completed': 100, 'total': 225}))
    print(FractionColumn(unit_scale=False, unit_divisor=1000).render({'completed': 100, 'total': 225}))


# Generated at 2022-06-24 10:32:04.147588
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    class tqdm_rich_test(tqdm_rich):
        def __init__(self, *args, **kwargs):
            super(tqdm_rich_test, self).__init__(*args, **kwargs)

        @property
        def format_dict(self):
            return {"n": self.n, "total": self.total}

    def no_kwargs_display_test(obj):
        obj.display()

    def kwargs_display_test(obj):
        obj.display(n=0, total=1)


# Generated at 2022-06-24 10:32:11.291228
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Tests that method clear does not throw an exception.
    """
    with tqdm(total=1) as t:
        t.clear()


# Unit test
if __name__ == '__main__':
    import time

    with tqdm(total=100) as t:
        for _ in range(10):
            time.sleep(.1)
            t.update(10)

# Generated at 2022-06-24 10:32:15.457305
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Ensure the close method doesn't throw an exception."""
    try:
        with tqdm_rich(total=10) as pbar:
            for i in pbar:
                pbar.update(1)
    except Exception:
        assert False, "tqdm_rich.close() raised an exception"

# Generated at 2022-06-24 10:32:20.715208
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import Mock

    mytq = tqdm_rich(_range(100))
    mytq.n = 10
    mytq.total = 100
    mytq.desc = "Test"

    mytq.display = Mock()
    mytq.display()
    mytq.display.assert_called_once()

# Generated at 2022-06-24 10:32:31.062397
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Unit test for method display of class tqdm_rich.

    :return: list of unhandled exceptions.
    """
    res = []
    import sys
    try:
        with tqdm(desc='bar', dynamic_ncols=True, unit='B', unit_scale=True,
                  leave=True) as t:
            t.display()
            sys.stdout.flush()
            assert t.disable is False
            t.disable = True
            t.display()
            sys.stdout.flush()
            assert t.disable is True
            t.disable = False
            t.display()
            sys.stdout.flush()
            assert t.disable is False
    except Exception as e:
        res.append(str(e))
    return res

# Generated at 2022-06-24 10:32:33.597393
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import BarColumn, ProgressColumn, Text
    progress_column=RateColumn()
    progress_column.render(BarColumn(bar_width=None))


# Generated at 2022-06-24 10:32:36.783164
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    """
    >>> RateColumn()
    RateColumn()
    """



# Generated at 2022-06-24 10:32:42.084388
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.

    Tests
    -----
    test_one_fraction: FractionColumn: determines completed vs. total of
                       a progress bar scenario.
    test_two_fraction: FractionColumn: determines completed vs. total of
                       a progress bar scenario.
    test_three_fraction: FractionColumn: determines completed vs. total of
                         a progress bar scenario.
    test_four_fraction: FractionColumn: determines completed vs. total of
                        a progress bar scenario.

    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.progress import ProgressBarRenderOptions as Options

    # unit_scale = False, unit_divisor = 1000
    def test_one_fraction():
        """Test completed is less than total."""

# Generated at 2022-06-24 10:32:49.862871
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn("m", True, 1024)
    assert column.render({'speed': 1024}) == Text("1.0 Km/s", style="progress.data.speed")
    assert column.render({'speed': int(1024/3)}) == Text("0.3 Km/s", style="progress.data.speed")
    assert column.render({'speed': 10}) == Text("10.0 m/s", style="progress.data.speed")

    column = RateColumn("", True)
    assert column.render({'speed': 1024}) == Text("1.0 K/s", style="progress.data.speed")
    assert column.render({'speed': int(1024/3)}) == Text("0.3 K/s", style="progress.data.speed")

# Generated at 2022-06-24 10:32:59.180592
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    import random
    rate_column = RateColumn(unit="k", unit_scale=False, unit_divisor=1024)

    def assert_rate_column_render(task,
                                  speed=random.randint(0, 1000),
                                  expected_speed=speed,
                                  expected_suffix="",
                                  expected_unit=""):
        class TestTask:
            def __init__(self, speed):
                self.speed = speed

        assert rate_column.render(TestTask(speed)) == Text(
                f"{expected_speed}{expected_suffix}{expected_unit}k/s",
                style="progress.data.speed")

    assert_rate_column_render(None)
    assert_rate_column_render(None, 0, 0, "", "")
    assert_

# Generated at 2022-06-24 10:33:07.517399
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from sys import executable as python

    # Test with real tqdm
    from subprocess import Popen
    cmd = [python, "-m", "tqdm.rich", "-n", "5", "-d", "5", "-s", "5", "-u", "5"]
    with Popen(cmd) as proc:
        try:
            proc.wait(timeout=10)  # give it time to run
        except TimeoutError:  # pragma: no cover
            proc.kill()
            print("\nTEST_NAME=\"tqdm_rich\" FAILED")

    # Test with mock tqdm (fake progress bar)
    cmd = ["python", "-m", "tqdm.rich", "-n", "5", "-d", "5", "-s", "0", "-u", "5"]

# Generated at 2022-06-24 10:33:17.934935
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Test for unit
    rate = RateColumn(unit="B")
    assert rate.render(std_tqdm())[:2] == "0 "
    rate = RateColumn(unit="b")
    assert rate.render(std_tqdm())[:2] == "0 "
    rate = RateColumn(unit="")
    assert rate.render(std_tqdm())[:2] == "0 "
    rate = RateColumn(unit="b/s")
    assert rate.render(std_tqdm())[:2] == "0 "
    rate = RateColumn(unit="B/s")
    assert rate.render(std_tqdm())[:2] == "0 "
    # Test for unit_scale
    rate = RateColumn(unit_scale=False)

# Generated at 2022-06-24 10:33:20.442430
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=3) as pbar:
        pbar.update(1)
        pbar.update(1)
        pbar.update(1)

# Generated at 2022-06-24 10:33:21.053528
# Unit test for constructor of class RateColumn
def test_RateColumn():
    pass

# Generated at 2022-06-24 10:33:22.641601
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=100, position=1)
    t.clear()
    t.close()

# Generated at 2022-06-24 10:33:30.085528
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .std import tqdm

    # Conditional import to support Python 2.6
    try:
        from multiprocessing import JoinableQueue, Process
    except ImportError:
        from multiprocessing.dummy import JoinableQueue, Process

    class TqdmTypeError(Exception):
        pass

    def tqdm_mp_queue(total):
        """Test fast updating of tqdm instances in separate processes."""
        global _instances  # pylint: disable=global-statement
        _instances = {}

        def get_instance(desc=None):
            """Get or create an instance of tqdm."""
            pid = current_process().pid

# Generated at 2022-06-24 10:33:33.060920
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    assert f.render(Progress(total=10)) == Text('0.0/10 ', style='progress.download')
    # Test for non-default arguments
    f = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert f.render(Progress(total=10**9)) == Text('0.0/976.6 M', style='progress.download')


# Generated at 2022-06-24 10:33:39.805826
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    with tqdm_rich(10, disable=True) as t:
        t._prog = Progress()
    t.reset()


if __name__ == "__main__":
    from time import sleep
    with Progress() as p:
        for i in tqdm(_range(100), total=100, desc="Hello", leave=True, unit="B", unit_scale=True,
                      miniters=1):
            sleep(0.1)
            p.update(i)
    # Unit test for method reset of class tqdm_rich
    test_tqdm_rich_reset()

# Generated at 2022-06-24 10:33:48.171703
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    print('Test the constructor of class FractionColumn')
    column = FractionColumn()
    assert column.unit_scale == False
    assert column.unit_divisor == 1000
    column = FractionColumn(unit_scale=True)
    assert column.unit_scale == True
    assert column.unit_divisor == 1000
    column = FractionColumn(unit_divisor=1024)
    assert column.unit_scale == False
    assert column.unit_divisor == 1024

test_FractionColumn()


# Generated at 2022-06-24 10:33:51.457562
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    x = tqdm_rich(total=100, desc="w")
    x.update(0)

if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-24 10:33:53.246280
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=10)
    t.close()
    assert t._prog.tasks


# Generated at 2022-06-24 10:33:55.021198
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress_column = FractionColumn()
    progress_column.render(Progress(total=10))


# Generated at 2022-06-24 10:33:57.752375
# Unit test for function trange
def test_trange():  # pragma: no cover
    for i in trange(4):
        pass


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:34:00.779125
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():

    # This test runs on a system but doesn't assert anything.
    # It's only intended to make sure the trange() doesn't crash.
    # This is a demo for #897.
    # TODO: add tests
    # pylint: disable=abstract-class-not-used
    for i in trange(100):
        pass

# Generated at 2022-06-24 10:34:03.507174
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Testing clear method of tqdm_rich."""
    t = tqdm_rich("test")
    t.clear()

# Generated at 2022-06-24 10:34:06.241259
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task(object):
        def __init__(self):
            self.completed = 0
            self.total = 12345678901

    # Test render with no scale
    col = FractionColumn(unit_scale=False)
    col.render(Task())
    # Test render with scale
    col = FractionColumn(unit_scale=True)
    col.render(Task())



# Generated at 2022-06-24 10:34:11.179896
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    import os
    import random
    import tempfile
    with tempfile.TemporaryDirectory() as dir_name:
        for i in tqdm(range(10)):
            with open(os.path.join(dir_name, str(i)), 'w') as f:
                f.write(str(random.random()))
            time.sleep(0.5)

# Generated at 2022-06-24 10:34:14.260452
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for kwargs in [
            {'disable': None},
            {'disable': True},
            {'progress': None},
            {'progress': ("[progress.description]",)},
    ]:
        tqdm_rich(**kwargs)

# Generated at 2022-06-24 10:34:17.030243
# Unit test for function trange
def test_trange():
    """Test function trange"""
    list(trange(10))


if __name__ == '__main__':
    test_trange()  # pragma: no cover

# Generated at 2022-06-24 10:34:19.844125
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    print(rate_column.render(Progress.Task(speed=10, completed=10, total=10)))

# Generated at 2022-06-24 10:34:30.045266
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn"""
    from datetime import datetime
    test_task = Progress.get_task()
    test_task.description = "Unit test for method render of class RateColumn"
    test_task.start_time = datetime(2020, 5, 21, 12, 0, 0)
    test_task.end_time = datetime(2020, 5, 21, 12, 0, 2)
    test_task.total = 100
    test_task.completed = 50
    test_task.bar_width = 0
    test_task.speed = None

    rate_column_test = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-24 10:34:34.678523
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        with tqdm_rich(total=10) as pbar:
            for i in range(10):
                pbar.update()
        pbar.clear()
        with tqdm_rich(total=10) as pbar:
            for i in range(10):
                pbar.update()
        pbar.clear()
        assert True
    except:
        assert False

# Generated at 2022-06-24 10:34:44.830896
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test the render method of class FractionColumn which return the
    completed/total progress."""
    class TestProgress:
        """Create a Progress object."""
        def __init__(self, max_value, desc):
            self.max_value = max_value
            self.n = max_value // 2
            self.desc = desc

    # Test with a constant suffix
    column = FractionColumn(unit_scale=False, unit_divisor=1)
    progress = TestProgress(max_value=10, desc="")
    result = column.render(progress)
    assert result.text == "5.0/10.0"
    # Test with a suffix (e.g. K, M, G, etc.)
    column = FractionColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-24 10:34:47.544042
# Unit test for function trange
def test_trange():
    "smoke test for function trange"
    assert isinstance(trange(10), tqdm_rich)

# Generated at 2022-06-24 10:34:57.796031
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest

    r = RateColumn()
    assert r.render(None) == "? "

    r = RateColumn(unit_scale=False)
    assert r.render(None) == "? "

    r = RateColumn(unit_scale=True)
    assert r.render(None) == "? "

    r = RateColumn(unit="B")
    assert r.render(None) == "? B"

    r = RateColumn(unit_scale=False, unit="B")
    assert r.render(None) == "? B"

    r = RateColumn(unit_scale=True, unit="B")
    assert r.render(None) == "? B"

    r = RateColumn(unit="/s")
    assert r.render(None) == "? /s"


# Generated at 2022-06-24 10:35:03.171473
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Method `tqdm_rich.reset` should set total to new value.
    """
    with tqdm(total=10) as t:
        assert t._prog.get_task(t._task_id).total == 10
        t.reset(50)
        assert t._prog.get_task(t._task_id).total == 50

# Generated at 2022-06-24 10:35:06.964902
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm.rich.progress import Progress

    progress = Progress()
    task_id = progress.add_task("tqdm_rich", total=100)
    progress.update(task_id, completed=100)
    progress.__exit__(None, None, None)

# Generated at 2022-06-24 10:35:10.423200
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for `trange`."""
    for _ in trange(10):
        pass
    for _ in trange(1, 11):
        pass

# Generated at 2022-06-24 10:35:17.745049
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Unit test for method clear.

    It is a dummy test that verifies that the method clear catches the
    exception
    """
    #pylint: disable=protected-access
    tq = tqdm_rich(
        total=10, leave=True, smoothing=0.0, bar_format='{desc}: {n_fmt}')
    tq.clear()
    tq.n = 11
    tq._repr_running_offset = 0  # has no effect
    tq.clear()

# Generated at 2022-06-24 10:35:18.460400
# Unit test for function trange
def test_trange():
    return list(tqdm_rich([]))

# Generated at 2022-06-24 10:35:29.166886
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import re
    import random
    import string
    from rich.progress import Progress, TaskID
    from rich.console import Console
    def random_hex(length):
        return "".join([random.choice(string.hexdigits) for i in range(length)])
    fc = FractionColumn(unit_scale=True)

    completed = [random.randint(0,9999) for i in range(10)]
    total = [random.randint(0,9999) for i in range(10)]
    p = Progress()
    for i in range(10):
        task_id = TaskID(random_hex(16))
        p.add_task(task_id, complete=completed[i], total=total[i])