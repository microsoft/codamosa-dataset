

# Generated at 2022-06-24 10:25:40.221509
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import unittest
    from contextlib import redirect_stdout

    class TestMethods(unittest.TestCase):
        def test_close(self):
            with redirect_stdout(sys.stderr):  # ipython notebook "IOError: [Errno 0] Error"
                try:
                    with tqdm_rich(total=3) as t:
                        t.write("abc")
                        t.close()
                except:
                    self.fail()

    unittest.main(argv=[''], verbosity=2, exit=False)


if __name__ == "__main__":
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:25:43.655581
# Unit test for function trange
def test_trange():  # pragma: no cover
    list(trange(10))
    list(trange(10, 25))
    list(trange(10, 25, 1.5))
    list(trange(10, None, 1.5))
    list(trange(10, None, -1.5))

# Generated at 2022-06-24 10:25:53.976283
# Unit test for function trange
def test_trange():
    # Test
    with trange(10) as t:
        for k in t:
            t.set_description("Test")
            assert k == t.n
            t.update(2)  # update by 2
            t.update()  # no-op
            t.update()
            t.refresh()  # no-op
            t.set_postfix(ordered_dict=[('a', 1), ('b', 2)],
                          a=1, b=2)  # no-op: should warn
            t.set_postfix({'a': 1, 'b': 2})

    with trange(10, desc="Test", unit_scale=True, unit_divisor=10) as t:
        for k in t:
            t.update(1)

# Generated at 2022-06-24 10:26:03.383064
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column_obj = FractionColumn()
    class Task:
        completed = 8
        total = 10
    task_obj = Task()
    assert column_obj.render(task_obj) == Text('0.8/1.0 ', style='progress.download')
    column_obj = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column_obj.render(task_obj) == Text('0/1 ', style='progress.download')
    column_obj = FractionColumn(unit_scale=True, unit_divisor=1)
    assert column_obj.render(task_obj) == Text('0/1 ', style='progress.download')
    column_obj = FractionColumn(unit_scale=True, unit_divisor=100)
    assert column_obj.render(task_obj)

# Generated at 2022-06-24 10:26:13.507874
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Test default Progress
    with tqdm_rich(total=8, desc="test tqdm_rich", mininterval=0.0,
                   miniters=None) as pbar:
        for n in range(8):
            pbar.update()
        assert pbar.total == 8
        assert pbar.n == 8
        assert pbar.n_fmt == '8/8'
        assert pbar.desc == 'test tqdm_rich'

    # Test custom Progress

# Generated at 2022-06-24 10:26:20.055576
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    def rate(num, unit_suffix='', unit_scale=False, unit_divisor=1000):
        """
        Calculate rate

        Parameters
        ----------
        num : int or float
            number
        unit_suffix : str
            unit suffix
        unit_scale : bool
            whether apply unit scale
        unit_divisor : int
            divisor for unit scale

        Returns
        -------
        str
            rate as text
        """
        r = RateColumn(unit=unit_suffix, unit_scale=unit_scale, unit_divisor=unit_divisor)
        return r._text(num)

    assert rate(None) == '? /s'

    assert rate(0) == '0.0 /s'
    assert rate(100) == '100.0 /s'

# Generated at 2022-06-24 10:26:29.322813
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.console import Console
    from rich import progress
    from rich.progress import Progress
    from rich.columns import Columns

    console = Console(file=None)
    task = progress.Progress(
        console=console,
        title="Graphing",
        description="Drawing",
        total=10,
        transient=False,
        console=console,
        # columns=[FractionColumn(unit_scale=True)],
    )
    console.print(task)
    task.update(completed=5, total=10)
    task.update(completed=10, total=10)
    return



# Generated at 2022-06-24 10:26:35.414884
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test function for method tqdm_rich.reset"""
    with tqdm_rich(total=10, leave=True) as t:
        assert t.total == 10
        t.reset(total=20)
        assert t.total == 20
        assert t._prog._tasks[t._task_id].total == 20
        t.reset()
        assert t.total == 20
        assert t._prog._tasks[t._task_id].total == 20

# Generated at 2022-06-24 10:26:42.766040
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich import print, Styled
    from rich.progress import Progress
    from rich.console import Console

    Progress.DEFAULT_CONSOLE = Console()
    output = []

    def print_styled(line, *args, **kwargs):
        line = line.strip()
        output.append(line)
        print(line)

    old_print = print
    print = print_styled
    with tqdm(total=100, desc='test') as pbar:
        time.sleep(0.01)
    progress = output[-1]
    assert progress == Styled(
        '[progress.description]test   [progress.percentage]  5%',
        'progress.bar'
    )

# Generated at 2022-06-24 10:26:48.609623
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm(range(4), total=4):
        if i == 2:
            tqdm.reset(total=3)
            assert tqdm.n == 0
            assert tqdm.total == 3
        tqdm.update()
    assert tqdm.n == 3
    assert tqdm.total == 3
    tqdm.reset(total=5)
    assert tqdm.n == 0
    assert tqdm.total == 5


# Generated at 2022-06-24 10:26:58.386929
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import Progress
    except ImportError:
        return
    p = Progress()

    p.__enter__()
    # "Task id" must be int
    assert p.add_task(None, 0, description=None, total=1) == 1
    # "Task id" must be int
    assert p.add_task(None, '2', description=None, total=1) == 2
    assert p.add_task(None, 2, description=None, total=1) == 2
    assert p.add_task(None, 3, description=None, total=1) == 3

    # Failed init
    p = Progress()
    try:
        p.add_task(None, 2, description=None, total=1)
    except SystemExit:
        pass

# Generated at 2022-06-24 10:27:06.270494
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    import sys
    from textwrap import dedent
    _test_tqdm_rich_display_orig_stdout = sys.stdout
    sys.stdout = sys.__stdout__
    with tqdm_rich(total=10, ascii=True, unit='B', unit_scale=True) as t:
        t.display()
    assert sys.stdout.getvalue() == dedent('''\
    0/10.00 MB [#                  ] |
    ''')
    sys.stdout = _test_tqdm_rich_display_orig_stdout

# Generated at 2022-06-24 10:27:11.751047
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import pytest
    # test close without init
    t = tqdm_rich()
    t.close()
    # test close with init:
    t = tqdm_rich(total=10)
    t.close()
    # test close with init and disable = True
    t = tqdm_rich(total=10,disable=True)
    t.close()

# Generated at 2022-06-24 10:27:15.843521
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    from tqdm._utils import _term_move_up
    # with open('test.txt', 'w') as f:
    #     f.write('bla'*10)
    with tqdm_rich(total=10, unit='K', unit_scale=False, unit_divisor=1000) as t:
        for i in range(10):
            t.update(1)
            time.sleep(0.1)

    print('bla')

test_tqdm_rich_close()

# Generated at 2022-06-24 10:27:19.894652
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    x = tqdm_rich(range(0,10))
    assert x.disable is False
    # Assert that a new instance of tqdm_rich was created
    assert hasattr(x, '_prog')
    assert hasattr(x, '_task_id')
    x.close()


# Generated at 2022-06-24 10:27:21.462090
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    rate_column = RateColumn()
    assert rate_column is not None

# Generated at 2022-06-24 10:27:29.480762
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .main import format_meter
    meter = tqdm(total=100, leave=False)
    for _ in meter:
        pass
    assert meter.closed
    meter.close()
    assert meter.closed
    meter = tqdm(disabled=True)
    meter.close()
    meter.close()
    meter.close()
    meter._instances = (1, )
    meter.close()
    meter._instances = (1, 2, 3)
    meter.close()
    meter = tqdm(total=100)
    meter.close()
    assert format_meter(meter) == ""



# Generated at 2022-06-24 10:27:37.166524
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .std import tqdm
    import time

    # Test a basic case
    for _ in tqdm_rich(range(100)):
        time.sleep(0.01)

    # Test that disable=True is handled correctly
    for _ in tqdm_rich(range(100), disable=True):
        time.sleep(0.01)

    # Test that disable=None is handled correctly
    for _ in tqdm_rich(range(100), disable=None):
        time.sleep(0.01)

    # Test that disable=False is handled correctly
    for _ in tqdm_rich(range(100), disable=False):
        time.sleep(0.01)

    # Test that 'rich' kwarg is deprecated

# Generated at 2022-06-24 10:27:41.918553
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn(unit_scale=False)
    assert rc.render(rc.task) == Text("? ", style="progress.data.speed")

    rc2 = RateColumn(unit_scale=True)
    assert rc2.render(rc2.task) == Text("? ", style="progress.data.speed")


# Generated at 2022-06-24 10:27:48.516721
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    from .tests import TestCase, add_test_module, add_test_function, create_progress_task
    add_test_module(__name__)
    add_test_function(FractionColumn.render)

    class TestProgress(Progress):
        def __init__(self):
            super(TestProgress, self).__init__()
            self.tasks = {}
            self.task_ids = []

        def add_task(self, description="", *, completed=0, total=1,
                     description_style=None):
            """Add a task to the progress bar and return its ID."""
            if description_style is None:
                description_style = getattr(self.style, "progress.description")
            self.tasks[id(self)] = create

# Generated at 2022-06-24 10:27:54.208221
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()
    RateColumn(unit_scale=True)
    RateColumn(unit="")
    RateColumn(unit_scale=True, unit="")
    RateColumn(unit_divisor=100)
    RateColumn(unit_scale=True, unit_divisor=100)
    RateColumn(unit="", unit_divisor=100)
    RateColumn(unit_scale=True, unit="", unit_divisor=100)

# Generated at 2022-06-24 10:28:05.244051
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    PRINT = False
    filesize = FractionColumn()
    print = (lambda *a, **k: None) if not PRINT else lambda *a, **k: print(*a, **k)
    class task():
        completed = 0
        total = None
        speed = None
    print(filesize.render(task()))
    task.completed = 1
    task.total = 1
    print(filesize.render(task()))
    task.total = 1.1
    print(filesize.render(task()))
    task.total = 1100
    print(filesize.render(task()))
    task.total = 1101
    print(filesize.render(task()))
    task.total = 1101
    task.speed = None
    print(filesize.render(task()))

# Generated at 2022-06-24 10:28:07.527021
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    task = FractionColumn()
    assert task.unit_scale == False
    assert task.unit_divisor == 1000


# Generated at 2022-06-24 10:28:10.961297
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn"""
    rate = RateColumn()
    rate.render(Task(15))
    rate.render(Task(15, 1.5, None))


# Generated at 2022-06-24 10:28:15.637994
# Unit test for method render of class RateColumn
def test_RateColumn_render():
	column = RateColumn(unit_scale=False, unit_divisor=1000, unit='K')
	assert column.render(std_tqdm()) == Text(u'0.0 K/s', style='progress.data.speed')
	assert column.render(std_tqdm(total=1000)) == Text(u'0.0 K/s', style='progress.data.speed')

# Generated at 2022-06-24 10:28:27.091523
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    from rich.progress import TaskID
    try:
        from _test_tqdm_rich import test_tqdm_rich_close_test1, test_tqdm_rich_close_test2, test_tqdm_rich_close_test3
    except ImportError:
        from ._test_tqdm_rich import test_tqdm_rich_close_test1, test_tqdm_rich_close_test2, test_tqdm_rich_close_test3

    it = trange(2, leave=True)
    time.sleep(0.1)
    it.close()
    time.sleep(0.1)
    assert it._prog.completed == {TaskID(it._task_id)}

    it = trange(2, leave=True)

# Generated at 2022-06-24 10:28:38.020045
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-24 10:28:44.203204
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from tqdm.rich import tqdm_rich

    fake_tqdm_rich = tqdm_rich(["a", "b", "c", "d"], desc='testing', unit_scale=True,
                               unit_divisor=1024)
    for i in fake_tqdm_rich:
        time.sleep(.1)

if __name__ == '__main__':
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:28:51.082245
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    import rich.progress
    import rich.traceback
    task = rich.progress.Task("", total=100)
    task.update(50)
    column = FractionColumn()
    assert column.render(task) == rich.text.Text("0.5/1.0 ", style="progress.download")
    task2 = rich.progress.Task("", total=1024)
    task2.update(512)
    column2 = FractionColumn(unit_scale=True)
    assert column2.render(task2) == rich.text.Text("0.5/1.0 K", style="progress.download")
    task3 = rich.progress.Task("", total=1024 * 1024)
    task3.update(512 * 1024)
    column3 = FractionColumn(unit_scale=True, unit_divisor=1024)


# Generated at 2022-06-24 10:28:58.514689
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import shutil
    try:
        from rich.progress import Screen
        assert hasattr(Screen, 'width')
    except (ImportError, AttributeError):
        raise unittest.SkipTest("rich not installed")

    with tqdm_rich(total=100) as progress:
        progress.desc = 'Test description'
        for i in range(100):
            progress.n = i
            progress.display()

    with tqdm_rich(total=10) as progress:
        progress.desc = 'Test description'
        for i in range(10):
            progress.update()

    class FakeTTY:
        def __init__(self, width):
            self.width = width
        def write(self, *_):
            pass

    # Make sure display works within a certain limit of window width when the
    # width

# Generated at 2022-06-24 10:29:08.228472
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .gui import tqdm_gui

    # Test the first init of _prog
    t = tqdm_rich(0)
    t.display()
    assert hasattr(t, '_prog'), \
        "Failed to init a Progress instance in the first display()"
    t.close()

    # Test the change of _prog
    t = tqdm_rich(0)
    t.reset(10)
    t.display()
    assert t._prog.total == 10, \
        "Failed to call _prog.reset() or _prog.__enter__ with the total"
    t.close()

    # Test the inherited method display()
    t = tqdm_rich(0)
    t.reset(10)
    t.display()
    t.n = 5
   

# Generated at 2022-06-24 10:29:19.769272
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    assert column.render({'total': 8, 'completed': 2}) == Text('0.2/1.0 ',
            style='progress.download')
    assert column.render({'total': 0, 'completed': 0}) == Text('0.0/0.0 ',
            style='progress.download')
    column.unit_scale = True
    assert column.render({'total': 8, 'completed': 2}) == Text('0.2/1.0 B',
            style='progress.download')
    assert column.render({'total': 700000, 'completed': 3}) == Text('0.0/0.7 kB',
            style='progress.download')

# Generated at 2022-06-24 10:29:20.953228
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(2)):
        _.clear()

# Generated at 2022-06-24 10:29:27.383508
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(0, 0)) == Text("0.0/0.0")
    assert FractionColumn().render(Progress(1, 0)) == Text("1.0/0.0")
    assert FractionColumn().render(Progress(0, 1)) == Text("0.0/1.0")
    assert FractionColumn().render(Progress(1, 1)) == Text("1.0/1.0")
    assert FractionColumn(False, 1000).render(Progress(1000, 0)) == Text("1.0/0.0 K")
    assert FractionColumn(False, 1000).render(Progress(1000000, 0)) == Text("1.0/0.0 M")
    assert FractionColumn(False, 1000).render(Progress(1000000000, 0)) == Text("1.0/0.0 G")

# Generated at 2022-06-24 10:29:31.325023
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column is not None
    assert rate_column != None


# Generated at 2022-06-24 10:29:32.046899
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-24 10:29:41.192119
# Unit test for method render of class FractionColumn

# Generated at 2022-06-24 10:29:50.036388
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.text import Text

    d = {'desc': 'Test description',
         'n': 10,
         'bar_format': '[progress.description]{task.description}',
         'ncols': None,
         'total': 10,
         'bar_str': '',
         'file': None}
    progress = Progress('[progress.description]{task.description}', transient=True)
    tqdm_rich_object = tqdm_rich(total=d['total'], desc=d['desc'], bar_format=d['bar_format'])
    tqdm_rich_object.n = d['n']
    tqdm_rich_object._prog = progress

# Generated at 2022-06-24 10:30:00.071802
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .utils import _range
    from .std import tqdm, format_interval
    from .std import format_meter, format_sizeof
    from .std import format_timespan, range_type, _supports_unicode, SimpleProgress, ETA

    # test variable
    unit_scale = True
    unit_divisor = 1000
    completed = 1000
    total = 10000
    precision = 1

    def bar(
        desc=None,
        total=None,
        unit_scale=unit_scale,
        unit_divisor=unit_divisor,
        unit="B",
        leave=False,
        disable=False,
    ):
        """testing function"""
        args = (completed/unit, total/unit)

# Generated at 2022-06-24 10:30:10.975622
# Unit test for function trange
def test_trange():
    from .utils import format_interval
    from .std import trange as std_tr

    for iterable in [_range(10), std_tr(10), std_tr(10), _range(10)]:
        for i in trange(iterable, desc="test", leave=True):
            pass
        for i in trange(iterable, total=100, desc="test", leave=True):
            pass
        for i in trange(iterable, mininterval=0.1, miniters=5,
                        desc="test", leave=True):
            pass
        for i in trange(iterable, mininterval=0.5, miniters=5,
                        desc="test", leave=True):
            pass

# Generated at 2022-06-24 10:30:13.100335
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Test tqdm_rich constructor.
    """
    from rich.console import Console
    console = Console()
    with console.progress() as pb:
        for i in trange(10):
            pass  # should be able to pass a task


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-24 10:30:23.379273
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(1) as t:
        t.update(1)
        assert t.format_dict["bar_format"] == ""
        assert t.format_dict["desc"] == ""
        assert t.format_dict["desc_ordered"] == False
        assert t.format_dict["unit"] == "it"
        assert t.format_dict["unit_scale"] == False
        assert t.format_dict["unit_divisor"] == 1000
        assert t.format_dict["total"] == 1
        assert t.format_dict["ncols"] == 80
        assert t.format_dict["rate"] == ""
        assert t.format_dict["dynamic_ncols"] == False
        assert t.format_dict["ascii"] == False

# Generated at 2022-06-24 10:30:33.435235
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn."""
    task = Progress(
        "Task 1",
        bar_width=None,
        total=100,
    )
    task.start()
    task.update(completed=50)
    assert str(FractionColumn(unit_scale=False).render(task)) == "0.5/1.0 "
    assert str(FractionColumn(unit_scale=True).render(task)) == "500.0/1,000.0 "
    assert str(FractionColumn(unit_scale=False, unit_divisor=1024).render(task)) == "0.5/1.0 "
    assert str(FractionColumn(unit_scale=False, unit_divisor=1000).render(task)) == "0.5/1.0 "

# Generated at 2022-06-24 10:30:43.965458
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # test no progress
    with tqdm_rich(2, disable=True) as t:
        for _ in t:
            pass
    assert not t.disable
    # test progress
    with tqdm_rich(2) as t:
        for _ in t:
            pass
    assert not t.disable


if __name__ == "__main__":  # pragma: no cover
    # (not part of doctests, and not run when installed)
    with tqdm(total=20) as pbar:
        pbar.set_description_str("Progress: ")
        for i in pbar:
            pbar.set_description_str(str(i))
            pbar.update()

# Generated at 2022-06-24 10:30:51.815759
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import os
    import time
    import gc
    from .std import tnrange, tqdm_tee, tqdm_gui, tqdm_notebook
    for cls in (tqdm_tee, tqdm_gui, tqdm_notebook):
        for desc in ("desc", None):
            for total in (10, None):
                for disable in (False, True):
                    d = cls(total=total, desc=desc, disable=disable, leave=True)
                    d.close()
                    d.clear()
                    del d
                    gc.collect()
    try:
        in_ipython = get_ipython  # noqa
    except NameError:
        pass

# Generated at 2022-06-24 10:30:55.467258
# Unit test for constructor of class RateColumn
def test_RateColumn():

    c = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    task = object()
    ret = c.render(task)

    assert(ret.text == "? B/s")
    assert(ret.style == "progress.data.speed")



# Generated at 2022-06-24 10:30:59.293649
# Unit test for constructor of class RateColumn
def test_RateColumn():
    col = RateColumn("B")
    assert col.unit == "B"
    assert col.unit_scale == False
    assert col.unit_divisor == 1000
    col = RateColumn("B", True, 1024)
    assert col.unit == "B"
    assert col.unit_scale == True
    assert col.unit_divisor == 1024

# Generated at 2022-06-24 10:31:02.593261
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    print(column.render(column))

if __name__ == '__main__':
    test_RateColumn_render()

# Generated at 2022-06-24 10:31:06.245254
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    import gc

    with tqdm_rich(total=10, leave=True) as t:
        for _ in t:
            time.sleep(0.001)
    assert gc.collect() == 0


# Generated at 2022-06-24 10:31:11.374105
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from pprint import pprint
    task = tqdm(total=1)
    fraction = FractionColumn()
    task.set_postfix(bar="")
    pprint(fraction.render(task))
    task.update(1)
    pprint(fraction.render(task))
    task.close()


# Generated at 2022-06-24 10:31:13.713255
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    column.render(1, 2)

# Generated at 2022-06-24 10:31:17.620476
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # basic functionality test
    obj = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert obj is not None
    

# Generated at 2022-06-24 10:31:27.216223
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    p = Progress(
        Text("{task.description}", style="bold blue"),
        BarColumn(bar_width=None, style="bright_yellow"),
        FractionColumn(),
        "\n",
        TimeElapsedColumn(),
        " [", TimeRemainingColumn(), "]",
        "\n",
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
    )
    # Create task
    task_id = p.add_task("Test", total=2, completed=0)
    # Initialize progress
    p.update(task_id, completed=1)
    # Update progress
    p.update(task_id, completed=2)
    p.__exit__(None, None, None)


# Generated at 2022-06-24 10:31:39.689089
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():          # pragma: no cover
    from rich.progress import Task
    task = Task()
    task.completed = 100                    # completed number of iterations
    task.total = 1000                       # total number of iterations
    column = FractionColumn(10, 1000)       # divisor = 1000
    assert column.render(task) == Text('0.1/1.0 K', style='progress.download')
    column = FractionColumn(1, 1000)        # divisor = 1000
    assert column.render(task) == Text('100/1000', style='progress.download')
    column = FractionColumn(1, 1)           # divisor = 1
    assert column.render(task) == Text('100/1000', style='progress.download')
    task.completed = 1

# Generated at 2022-06-24 10:31:48.129003
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    try:
        import numpy
        numpy.random.seed(8)
    except:
        import random
        random.seed(8)

    for use_numpy in [True, False]:
        with tqdm_rich(total=100) as t:
            for i in range(100):
                t.update()
                if use_numpy:
                    import numpy
                    val = numpy.random.random()
                else:
                    import random
                    val = random.random()
                t.reset(total=val)
                t.display()

# Generated at 2022-06-24 10:31:51.763588
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Test function to create a RateColumn object.
    progress_rate = RateColumn(unit = "Bytes", unit_scale = True, unit_divisor = 1000)

    # Return the object.
    return progress_rate

# Generated at 2022-06-24 10:31:55.942266
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = 1
    unit_scale = False
    unit_divisor = 1000
    f = FractionColumn(unit_scale, unit_divisor)
    assert type(f.render(task)) == Text
    assert f.render(task).text == '1/1 '

# Generated at 2022-06-24 10:32:05.797161
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # test when length of task.desc is less than or equal to length of "[progress.description]{task.description}"
    task = std_tqdm(total=100, desc="test task")
    task.n = 5
    assert FractionColumn().render(task) == Text("0.0/1.0 ", style="progress.download")
    # test when length of task.desc is greater than length of "[progress.description]{task.description}"
    task = std_tqdm(total=100, desc="test task")
    task.n = 5
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text("0.0/0.1 K", style="progress.download")
    # test when task.total is less than 1000

# Generated at 2022-06-24 10:32:15.095112
# Unit test for function trange
def test_trange():
    from .utils import format_sizeof, _supports_unicode
    if not _supports_unicode():
        raise unittest.SkipTest("Unicode not supported")
    with trange(10, desc="hi", ncols=80) as t:
        assert t.n == 0
        t.set_description("hello")
        assert t.n == 0
        t.set_postfix(ordered_dict=dict(zip('abc', [1, 5, 9])))
        assert t.n == 0


if __name__ == "__main__":
    from .utils import _test_env
    _test_env()

    from .main import test, _TestGui
    test()
    _TestGui().test()

# Generated at 2022-06-24 10:32:19.837233
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    fc = FractionColumn()
    t = Task(200, 10)
    print(fc.render(t))
    t = Task(20, 100)
    print(fc.render(t))


# Generated at 2022-06-24 10:32:27.793649
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    # pylint: disable=invalid-name
    for _ in trange(10, desc="0A"):
        for _ in trange(10, desc="1B"):
            for _ in trange(10, desc="2C", leave=True):
                for _ in trange(10, desc="3D", leave=False):
                    for _ in trange(10, desc="4E"):
                        for _ in trange(10, desc="5F"):
                            for _ in trange(10, desc="6G"):
                                break
    # pylint: disable=missing-docstring
    for _ in trange(0):
        assert False, "Should never be reached"

# Generated at 2022-06-24 10:32:34.625213
# Unit test for constructor of class RateColumn
def test_RateColumn():
    for unit, unit_scale, unit_divisor in (('B', False, 1000), ('B', True, 1000),
                                           ('B', False, 1024)):
        rc = RateColumn(unit=unit, unit_scale=unit_scale,
                        unit_divisor=unit_divisor)
        if unit_scale:
            unit, suffix = filesize.pick_unit_and_suffix(
                1000, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
                unit_divisor,
            )
        else:
            unit, suffix = filesize.pick_unit_and_suffix(1000, [""], 1)
        precision = 0 if unit == 1 else 1

# Generated at 2022-06-24 10:32:37.414640
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import Progress
        progress_mock = Progress()
        progress_mock.update = lambda: None
        t = tqdm_rich('test', desc='desc', ncols=10, disable=False, total=100)
        t._prog = progress_mock
        t.display()
    except TypeError:
        assert False

# Generated at 2022-06-24 10:32:42.973490
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import pytest

    tqdm_test = tqdm_rich(total=3, disable=True)
    tqdm_test.total = 3
    tqdm_test.display()
    tqdm_test.total = None
    with pytest.raises(TypeError) as excinfo:
        tqdm_test.display()

    assert "unsupported operand type(s)" in str(excinfo.value)

# Generated at 2022-06-24 10:32:44.310216
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    d = tqdm_rich()._default_dict
    RateColumn().render(d)

# Generated at 2022-06-24 10:32:45.194295
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r_c = RateColumn()

# Generated at 2022-06-24 10:32:56.206131
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    assert column.render(None) == Text("0.0/0.0 ", style="progress.download")
    assert column.render(std_tqdm()) == Text("0.0/0.0 ", style="progress.download")
    assert column.render(std_tqdm(total=10 ** 0)) == Text("0.0/10 ", style="progress.download")
    assert column.render(std_tqdm(total=10 ** 1)) == Text("0.0/100 ", style="progress.download")
    assert column.render(std_tqdm(total=10 ** 1, unit='iB')) == Text("0.0/100 iB", style="progress.download")
    assert column.render(std_tqdm(total=10 ** 1, unit='B')) == Text

# Generated at 2022-06-24 10:32:58.637981
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .tests import dummy_tqdm_func
    dummy_tqdm_func(tqdm_rich)

# Generated at 2022-06-24 10:33:07.331792
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    from .utils import _supports_unicode
    from .utils import format_interval

    # Test
    with tqdm(total=4) as pbar:
        for i in trange(4):
            pbar.update()
            time.sleep(0.1)

    with tqdm(total=4) as pbar:
        for i in trange(4):
            pbar.update()
            time.sleep(0.1)
        pbar.close()

    _range = range if not PY2 else xrange
    with tqdm(_range(8), ascii=True, desc="test", unit="custom") as pbar:
        for i in pbar:
            pbar.update()

# Generated at 2022-06-24 10:33:11.511454
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the render method of class RateColumn
    """
    rate_column = RateColumn()
    rate_column.unit = "B"
    rate_column.unit_scale = False
    rate_column.unit_divisor = 1000

    completed = int(1)
    total = int(3)
    speed = int(5)

    task = object()
    task.total = total
    task.completed = completed
    task.speed = speed

    expected_ratecolumn = Text(f"5.0 B/s", style="progress.data.speed")
    assert rate_column.render(task) == expected_ratecolumn

# Generated at 2022-06-24 10:33:21.130779
# Unit test for constructor of class RateColumn
def test_RateColumn():
    test_list = [Text("1.2 K/s", style="progress.data.speed"), Text("1.2 M/s", style="progress.data.speed"), Text("1.2 G/s", style="progress.data.speed"), Text("1.2 T/s", style="progress.data.speed"), Text("1.2 P/s", style="progress.data.speed"), Text("1.2 E/s", style="progress.data.speed"), Text("1.2 Z/s", style="progress.data.speed"), Text("1.2 Y/s", style="progress.data.speed"), Text("1.2 /s", style="progress.data.speed")]
    s = [None, None, None, None, None, None, None, None, None]
    divisor = 1000
    i = 1
    unit = ""

# Generated at 2022-06-24 10:33:24.579339
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm_rich(total=1, unit='B', unit_scale=True, miniters=1) as t:
        time.sleep(0.1)
        t.update(1)
        assert t.n == 1

# Generated at 2022-06-24 10:33:26.257386
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    rate_column.render(Progress(total=10))     # None is acceptable

# Generated at 2022-06-24 10:33:30.931536
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # pylint: disable=protected-access
    # python 3.X: total is a keyword only argument
    total = 10
    t = tqdm_rich(total=total)
    assert t.total == t._prog._tasks[t._task_id].total == total
    reset_total = 100
    t.reset(total=reset_total)
    assert t.total == t._prog._tasks[t._task_id].total == reset_total

# Generated at 2022-06-24 10:33:33.744878
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # real test is done in test_std.py
    t = tqdm_rich(total=10)
    t.reset(total=10)
    t.close()

# Generated at 2022-06-24 10:33:37.922101
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    warnings = []
    class warn:
        def __init__(self, msg):
            warnings.append(msg)
    old_warn = tqdm_rich.warn
    tqdm_rich.warn = warn
    try:
        tqdm_rich.display()
    finally:
        tqdm_rich.warn = old_warn
    assert warnings == [
        "You have used the tqdm.rich.tqdm() function, but the default output "
        "has not been overridden by the tqdm_gui/monitor module. Use tqdm_gui() "
        "instead of tqdm_rich() to prevent unexpected errors.",
    ]

# Generated at 2022-06-24 10:33:48.880311
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Method close of class tqdm_rich"""
    from unittest import mock
    from .gui import _usage_warning_handler

    mock.patch.object(
        _usage_warning_handler,
        'warn',
        spec=_usage_warning_handler.warn).start()
    # disable=True
    tqdm_r = tqdm_rich(disable=True)
    tqdm_r.n = 50
    tqdm_r.total = 100
    tqdm_r.close()

    # disable=False
    tqdm_r = tqdm_rich()
    tqdm_r.n = 50
    tqdm_r.total = 100
    tqdm_r.clear = mock.MagicMock()
    tqdm_r.display = mock.MagicMock()

# Generated at 2022-06-24 10:33:56.111727
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn."""
    rc = RateColumn(unit="B")
    assert rc.render(tqdm_rich(0)) == "[1.00 B/s]"
    rc = RateColumn(unit="B", unit_scale=True)
    assert rc.render(tqdm_rich(1000)) == "[1.00 K/s]"
    rc = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rc.render(tqdm_rich(1000)) == "[0.98 KiB/s]"

# Generated at 2022-06-24 10:33:59.181812
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test constructor of class FractionColumn."""
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fraction_column.unit_scale == True
    assert fraction_column.unit_divisor == 1000

# Generated at 2022-06-24 10:34:10.632256
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .std import tqdm_gui
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange

    assert tqdm is tqdm_rich
    assert trange is trrange
    assert tqdm is tqdm_gui
    assert tqdm is std_tqdm
    assert trange is std_trange

    t = tqdm(total=100, progress=(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
    ))
    t.update(50)

# Generated at 2022-06-24 10:34:14.507800
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    test function for close method of class tqdm_rich
    """
    # Call tqdm_rich class with [] as arguments and check for output
    for _ in tqdm_rich([], disable=False):
        break
    # Assert that output is not empty
    assert True


# Generated at 2022-06-24 10:34:18.824578
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn()) == "<RateColumn>"
    assert str(RateColumn(unit="B")) == "<RateColumn(unit=B)>"
    assert str(RateColumn(unit_scale=True)) == "<RateColumn(unit_scale=True)>"
    assert str(RateColumn(unit_divisor=1000)) == "<RateColumn(unit_divisor=1000)>"



# Generated at 2022-06-24 10:34:29.586174
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .utils import _range, format_sizeof, format_interval
    from datetime import timedelta

    with tqdm_rich(total=100, miniters=10) as bar:
        for i in _range(10):
            bar.reset(total=100 + i * 10, miniters=10)
            for j in bar:
                bar.set_description("i:%d,j:%d" % (i, j))
        assert bar.total == 100 + i * 10
        assert bar.n == 10
        assert bar.miniters == 10
        assert str(bar) == "i:9,j:9/210 [00:00<?, ?it/s]"
        bar.reset()
        assert bar.total == 0
        assert bar.n == 0
        assert bar.miniters == 0

# Generated at 2022-06-24 10:34:33.507317
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Tests :class:`tqdm_rich.tqdm_rich` for the method :meth:`clear`

    There is no rich.progress GUI output, but there should be no runtime error
    """
    from tqdm.auto import tqdm

    for i in tqdm(range(10)):
        tqdm.clear()


# Generated at 2022-06-24 10:34:34.925824
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    return tqdm_rich(range(100), desc='test', total=100)

# Generated at 2022-06-24 10:34:38.374721
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    obj = FractionColumn(unit_scale = True, unit_divisor = 1000)
    assert obj.unit_scale == True
    assert obj.unit_divisor == 1000


# Generated at 2022-06-24 10:34:40.553473
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10, desc="test_tqdm_rich") as pbar:
        pass
    assert pbar.n == 10

# Generated at 2022-06-24 10:34:44.500216
# Unit test for constructor of class tqdm_rich

# Generated at 2022-06-24 10:34:45.068827
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    pass

# Generated at 2022-06-24 10:34:47.199800
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass



# Generated at 2022-06-24 10:34:50.208996
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as t:
        for _ in range(10):
            t.update(1)

# Generated at 2022-06-24 10:34:51.663292
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm(total=10)
    t.close()

# Generated at 2022-06-24 10:34:54.176356
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pbar = tqdm_rich(total=1)
    pbar.clear(nolock=False)
    pbar.display()
    pbar.close()
    assert True

# Generated at 2022-06-24 10:34:57.264817
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for RateColumn constructor"""
    ratecolumn = RateColumn(unit="B")
    assert ratecolumn.unit == "B"
    assert ratecolumn.unit_scale is False
    assert ratecolumn.unit_divisor == 1000

# Generated at 2022-06-24 10:35:01.701475
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Default case
    column = FractionColumn()
    column.render(Progress.Task(total=1000, completed=500))
    # Test case: unit_scale
    column = FractionColumn(unit_scale=False)
    column.render(Progress.Task(total=1000000, completed=500000))


# Generated at 2022-06-24 10:35:03.556118
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for _ in tqdm_rich(range(10)):
        pass


# Generated at 2022-06-24 10:35:10.515386
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test if the FractionColumn works properly."""
    from rich.progress import Progress
    from rich.columns import Columns
    from tqdm.rich.progress_columns import TimeElapsedColumn
    task = Progress('name')
    task.total = 10
    task.completed = 5
    columns = Columns()
    columns.append(TimeElapsedColumn(style="progress.elapsed.time"))
    columns.append(FractionColumn(unit_scale=False))
    columns.append(FractionColumn(unit_scale=True, unit_divisor=1024))
    assert str(columns) == "0:0  5/10 5.00/10.00 0.0K/9.77K"

# Generated at 2022-06-24 10:35:17.833518
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for trange()"""
    for _ in trange(10):
        pass

    for _ in trange(10, leave=True):
        pass

    for _ in trange(10, unit='B'):
        pass

    for _ in trange(10, unit_scale=False):
        pass

    for _ in trange(10, unit_divisor=1024):
        pass

    for _ in trange(10, disable=True):
        pass

# Generated at 2022-06-24 10:35:20.504737
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from .std import tqdm as std_tqdm
    for i in trange(10):
        std_tqdm(i)



# Generated at 2022-06-24 10:35:26.952982
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    with tqdm_rich(total=10, disable=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            # pbar.display()
    assert pbar._prog.get_task(pbar._task_id).is_completed()

if __name__ == '__main__':
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:35:35.036908
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()

    rate_column.unit = 'B'
    rate_column.unit_scale = True
    rate_column.unit_divisor = 1024
    # when speed is not None, return rate with unit
    assert rate_column.render(Progress(speed=1024)) == Text(
        f"1.00 KB/s", style="progress.data.speed")
    assert rate_column.render(Progress(speed=1048576)) == Text(
        f"1.00 MB/s", style="progress.data.speed")
    # when speed is None, return '? <unit>/s'
    assert rate_column.render(Progress(speed=None)) == Text(
        f"? B/s", style="progress.data.speed")

    rate_column.unit = 'bit'
    rate_column