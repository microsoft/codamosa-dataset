

# Generated at 2022-06-24 10:25:33.511552
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert r.render({'speed': 100}) == Text('100/s', style='progress.data.speed')

    r = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    assert r.render({'speed': 1010}) == Text('1.0 K/s', style='progress.data.speed')



# Generated at 2022-06-24 10:25:34.779542
# Unit test for function trange
def test_trange():
    from .tests import TestTrange
    TestTrange.test_trange(trange)

# Generated at 2022-06-24 10:25:38.121741
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    test_class = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    result = test_class.render(None)
    assert result == Text("? B/s", style="progress.data.speed")


# Generated at 2022-06-24 10:25:42.930231
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn('B', unit_scale=True, unit_divisor=1000)
    RateColumn('B', unit_scale=True, unit_divisor=1024)
    RateColumn('B', unit_scale=False, unit_divisor=12345)


if __name__ == "__main__":
    from doctest import testmod  # pragma: no cover
    testmod()  # pragma: no cover
    test_RateColumn()

# Generated at 2022-06-24 10:25:50.644463
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()

    for n in trange(5, desc='outer'):
        for m in trange(3, desc='inner'):
            trange(2).reset(total=4)
            for l in trange(4, desc='innermost'):
                sleep(0.01)
            trange(4).reset()
    Progress(console).update(2, total=3)

# Generated at 2022-06-24 10:26:00.431140
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    import time
    # testing method tqdm_rich
    """
    Example of subclassing tqdm_rich.
    """

    class tqdm_rich_reset(tqdm_rich):

        def reset(self, total=None):
            """
            Resets to 0 iterations for repeated use.

            Parameters
            ----------
            total  : int or float, optional. Total to use for the new bar.
            """
            if self.disable:
                return
            super(tqdm_rich_reset, self).reset(total=total)


    for i in tqdm_rich_reset(range(8), desc='1st loop'):
        for j in tqdm_rich_reset(range(100), desc='2nd loop', leave=False):
            time.sleep(0.01)


# Generated at 2022-06-24 10:26:09.350951
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from pathlib import Path
    from time import sleep
    from rich.progress import Progress
    from math import ceil, floor

    with Progress(bar_width=40, transient=True) as p:
        t = p.add_task("Test 1")
        sleep(0.02)
        p.update(t, completed=0, total=100)
        sleep(0.02)
        p.update(t, completed=30)
        sleep(0.02)
        p.update(t, completed=floor(0.3 * 100))
        sleep(0.02)
        p.update(t, completed=ceil(0.3 * 100))
        sleep(0.02)
        p.update(t, completed=0.3 * 100)
        sleep(0.02)

# Generated at 2022-06-24 10:26:10.621989
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(0))

# Generated at 2022-06-24 10:26:18.449868
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test RateColumn without unit
    column = RateColumn()
    assert column.render(Progress(total=100, speed=50)) == Text('50.0 B/s', style='progress.data.speed')
    assert column.render(Progress(total=1023*1000, speed=156*1000)) == Text('0.2 KB/s', style='progress.data.speed')
    assert column.render(Progress(total=1023*1000*1000, speed=156*1000*1000)) == Text('0.2 MB/s', style='progress.data.speed')
    assert column.render(Progress(total=40*1024*1024*1024, speed=7.5*1024*1024*1024)) == Text('7.5 GB/s', style='progress.data.speed')

    # RateColumn with unit=s

# Generated at 2022-06-24 10:26:20.195333
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    pass

# Generated at 2022-06-24 10:26:22.641132
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(["", "", ""]) == Text('0.0/0.0 ', style='progress.download')

# Generated at 2022-06-24 10:26:33.717421
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test function of RateColumn
    :return:
    """
    Column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert Column.render(Progress(1, 100, speed=0)) == Text("? B/s", style="progress.data.speed")
    assert Column.render(Progress(0, 100, speed=100.0)) == Text("100.0 B/s", style="progress.data.speed")
    assert Column.render(Progress(0, 100, speed=1227.0)) == Text("1.2 KB/s", style="progress.data.speed")
    assert Column.render(Progress(0, 100, speed=1227.0)) == Text("1.2 KB/s", style="progress.data.speed")

# Generated at 2022-06-24 10:26:34.961431
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=100, disable=True) as pbar:
        pbar.clear()
        pbar.clear()

# Generated at 2022-06-24 10:26:42.929199
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test the render method of class FractionColumn.
    """
    assert FractionColumn().render(Progress('Test', total=1)) == Text("0.0/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(Progress('Test', total=1024)) == Text("0/1 K", style="progress.download")
    assert FractionColumn(unit_scale=True).render(Progress('Test', total=1048575)) == Text("0/1024 K", style="progress.download")
    assert FractionColumn(unit_scale=True).render(Progress('Test', total=1048576)) == Text("0/1 M", style="progress.download")

# Generated at 2022-06-24 10:26:52.919100
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # for the old style
    f = FractionColumn()
    assert f.unit_scale is False
    assert f.unit_divisor == 1000
    # for the new style
    f = FractionColumn(unit_scale=True)
    assert f.unit_scale is True
    assert f.unit_divisor == 1000
    f = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert f.unit_scale is True
    assert f.unit_divisor == 1024
    f = FractionColumn(unit_scale=False, unit_divisor=1024)
    assert f.unit_scale is False
    assert f.unit_divisor == 1024
    # wrong arguments

# Generated at 2022-06-24 10:26:56.007469
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=4) as pbar:
        pbar.clear()
        pbar.update(2)
        pbar.refresh()
        pbar.clear()
        pbar.update(2)
        pbar.refresh()

# Generated at 2022-06-24 10:27:05.337460
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    progress = Progress(
        *[FractionColumn(unit_scale=True)], transient=True
    )
    progress.add_task("", total=100)
    progress.update(completed=10)
    assert progress.last_render == "[progress.download]0.1/1.0 K"
    assert progress.completed == 10
    progress.update(completed=1_000)
    assert progress.last_render == "[progress.download]1.0/1.0 M"
    assert progress.completed == 1_000
    progress.update(completed=1_000_000)
    assert progress.last_render == "[progress.download]1.0/1.0 G"
    assert progress.completed == 1_000_000

# Generated at 2022-06-24 10:27:07.702844
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn().render(None)

# Generated at 2022-06-24 10:27:15.126696
# Unit test for constructor of class RateColumn
def test_RateColumn():
    try: # pragma: no cover
        r = RateColumn()
        assert False, "Missing required parameter"
    except: # pragma: no cover
        pass

    try: # pragma: no cover
        r = RateColumn(3.1415, "b/s")
        assert False, "Invalid unit parameter"
    except: # pragma: no cover
        pass

    try: # pragma: no cover
        r = RateColumn(unit_scale=True)
        assert False, "unit_scale parameter requires unit parameter"
    except: # pragma: no cover
        pass

# Generated at 2022-06-24 10:27:18.305374
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm_rich(total=10) as pbar:
        for _ in range(5):
            pbar.reset(total=1)
            pbar.update()

# Generated at 2022-06-24 10:27:20.941934
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fraction_column.unit_scale == True
    assert fraction_column.unit_divisor == 1000


# Generated at 2022-06-24 10:27:30.754535
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from tqdm.auto import trange
    from tqdm.utils import _term_move_up
    from tqdm import TqdmDeprecationWarning
    from tqdm.std import tqdm
    from .std import tqdm_pandas

    import os
    import warnings

    # Test the new constructor to make sure
    # that old arguments are discarded
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        with tqdm(total=10, ascii=False, desc="foo", ncols=0, bar_format="") as t:
            pass

        assert len(w) == 0

        # To keep backward compatibility

# Generated at 2022-06-24 10:27:42.096851
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    class _stub_task:
        def __init__(self):
            self.total = 100
            self.completed = 0
            self.desc = "desc"

    def _stub_add_task():
        return _stub_task()

    def _stub_update(task, total=None):
        if total is not None:
            task.total = total

    _stub_reset = lambda self, task_id: None

    progress_stub = lambda *args, **kwargs: None
    progress_stub.add_task = _stub_add_task
    progress_stub.update = _stub_update
    progress_stub.reset = _stub_reset

    obj = tqdm_rich(gui=True)
    obj._prog = progress_stub

    obj.reset

# Generated at 2022-06-24 10:27:46.958049
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # This function tests the close method of the tqdm_rich class
    # Input:
    #    tqdm_rich object without subclassing
    # Output
    #    prints total number of iterations completed on the screen
    # NOTE: the function cannot be tested using pytest, since the decorator will not work
    #       with pytest.
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.update()

if __name__ == "__main__":
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:27:50.693467
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = FractionColumn(True, 1000)
    assert progress.unit_scale == True
    assert progress.unit_divisor == 1000
    assert progress.unit_divisor == 1000
    assert progress.unit_divisor == 1000
    return progress

# Generated at 2022-06-24 10:27:54.876691
# Unit test for function trange
def test_trange():
    for i in trange(9, desc='Testing trange'):
        assert i <= 9
    for i in trange(4, desc='Testing trange', ascii=True):
        assert i <= 4
    for i in trange(7, desc='Testing trange', leave=True):
        assert i <= 7


# Generated at 2022-06-24 10:28:00.864491
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        with tqdm_rich(total=100) as t:
            t.set_postfix_str('100')
            t.set_postfix_str('200')
            t.set_postfix_str('300')
    except Exception as e:
        assert False, 'Should not have raised an exception.'

if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:28:09.595046
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Unit test for method render of class RateColumn.
    """
    rc = RateColumn()
    rc.total = 1
    rc.start_t = 0
    rc.dynamic_ncols = True
    assert rc.render(rc) == Text("? /s", style="progress.data.speed")
    rc.total = 10
    rc.dynamic_ncols = False
    rc.ncols = len("10 /s")
    assert rc.render(rc) == Text("1.0 /s", style="progress.data.speed")
    rc.dynamic_ncols = True
    rc.unit_scale = True
    assert rc.render(rc) == Text("0.9 K/s", style="progress.data.speed")
    rc.unit_scale = False

# Generated at 2022-06-24 10:28:13.371958
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # DataDivisor Scale
    RateColumn(unit_scale=False, unit_divisor=1000)
    # Binary Scale
    RateColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-24 10:28:16.969901
# Unit test for function trange
def test_trange():
    """Test `tqdm.rich.trange`"""
    trange_result = list(trange(0, 9, 2, desc="tqdm.rich.trange"))
    assert trange_result == [0, 2, 4, 6, 8]

# Generated at 2022-06-24 10:28:27.947425
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task_test_speed = {"completed": 100, "total": 1000, "speed": 100, "unit": "MB"}
    class test_RateColumn:
        def __init__(self, unit="", unit_scale=False, unit_divisor=1000):
            self.unit = unit
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super().__init__()

        def render(self, task):
            speed = task.speed
            if speed is None:
                return Text(f"? {self.unit}/s", style="progress.data.speed")

# Generated at 2022-06-24 10:28:35.749822
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = None
    fc = FractionColumn()
    fs = fc.render(task)
    assert isinstance(fs, Text)
    assert fs.text == '0.0/0.0'
    assert fs.style == 'progress.download'
    task = type(str('DummyTask'), (object, ), {
        'completed': 1.0,
        'total': 1.0,
    })
    fs = fc.render(task)
    assert fs.text == '1.0/1.0'
    assert fs.style == 'progress.download'

# Generated at 2022-06-24 10:28:42.615442
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class MockTask1:
        speed = None
    class MockTask2:
        speed = 1024
    class MockTask3:
        speed = 1000000000
    tasks = [MockTask1(),MockTask2(),MockTask3()]
    for task in tasks:
        if task.speed is None:
            assert RateColumn().render(task) == Text(f"? B/s", style="progress.data.speed")
        else:
            assert RateColumn().render(task) == Text(f"{task.speed} B/s", style="progress.data.speed")


# Generated at 2022-06-24 10:28:53.298452
# Unit test for function trange
def test_trange():
    from .std import trange, tqdm
    from .std import trange as std_trange
    from .std import tqdm as std_tqdm
    for i in trange(5, desc='tqdm_gui', leave=True):
        for j in std_trange(5, desc='tqdm', leave=True):
            for _ in std_tqdm(filesize.filesize_to_unit(2300),
                              desc="tqdm_std"):
                pass
    for i in std_trange(5, desc='tqdm', leave=True):
        for _ in std_tqdm(filesize.filesize_to_unit(2300),
                          desc="tqdm_std"):
            pass

# Generated at 2022-06-24 10:28:58.089557
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn("b")
    task = mock.create_autospec(Progress)
    task.speed = 12.34
    rate = rate_column.render(task)
    assert rate.text == "12.34 b/s"
    assert rate.style == "progress.data.speed"

# Generated at 2022-06-24 10:29:05.496268
# Unit test for constructor of class RateColumn
def test_RateColumn():
    columns = RateColumn()
    assert columns.unit_scale == False
    assert columns.unit_divisor == 1000

    columns = RateColumn(unit_scale=True, unit_divisor=1024)
    assert columns.unit_scale == True
    assert columns.unit_divisor == 1024

    # assert columns.render({'speed':1234}) == '1.23 k/s'
    # assert columns.render({'speed':1}) == '1.00  /s'
    # assert columns.render({'speed':0.1}) == '0.10  /s'

# Generated at 2022-06-24 10:29:10.859458
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():  # pragma: no cover
    task = tqdm_rich(total=500)
    fc = FractionColumn()
    assert fc.render(task) == Text('0.000/0.500 K', "progress.download")
    task.update(100)
    assert fc.render(task) == Text('0.100/0.500 K', "progress.download")
    task.update(200)
    assert fc.render(task) == Text('0.300/0.500 K', "progress.download")
    task.update(300)
    assert fc.render(task) == Text('0.600/0.500 K', "progress.download")
    task.update(400)
    assert fc.render(task) == Text('0.800/0.500 K', "progress.download")
    task

# Generated at 2022-06-24 10:29:21.801901
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        import rich
    except ImportError:
        raise ImportError("rich not found!")
    try:
        import pandas
    except ImportError:
        raise ImportError("pandas not found!")
    is_pandas_v0 = pandas.__version__.startswith('0')

    # check whether bar is printed on screen
    _, _, _, test_count = tqdm(range(10))  # noqa
    assert test_count == 10

    # check whether bar is printed on screen
    _, _, _, test_count = tqdm(range(10), desc='TEST')  # noqa
    assert test_count == 10

    # check whether bar is printed on screen
    _, _, _, test_count = tqdm(range(10), total=10)

# Generated at 2022-06-24 10:29:23.859975
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import re
    for _ in tqdm_rich(["a", "b", "c"], desc="test_tqdm_rich"):
        tqdm_rich.clear(0, "test")
        assert re.match("^test\r$", tqdm.write.__self__.write_buffer) is None

# Generated at 2022-06-24 10:29:27.837502
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from rich import print
    print("\n[bold cyan]Unit Test[/bold cyan]")
    for i in tqdm(range(5), desc="Unit Test:", leave=True,
                  dynamic_ncols=True, color='white',
                  bar_style='cyan'):
        sleep(0.5)

if __name__ == '__main__':
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:29:34.823575
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    """Unit test for method display of class tqdm_rich."""
    from unittest import mock
    with mock.patch('rich.progress.Progress', return_value="object"):
        total = 10
        tr = tqdm(range(total))
        for i, _ in enumerate(tr):
            assert tr.n == i
            tr.display()
            tr.n = i + 1
        assert tr.n == total

# Generated at 2022-06-24 10:29:42.645534
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import time

    with tqdm_rich(total=100, progress=(
            "[progress.description]{task.description}"
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
            ",", RateColumn(unit='B', unit_scale=True,
                            unit_divisor=1024), "]"
    )) as pbar:
        for i in range(100):
            pbar.set_description("|%02d|" % i)
            pbar.update(1)
            time.sleep(0.01)

if __name__ == "__main__":  # pragma: no cover
    test_

# Generated at 2022-06-24 10:29:48.102608
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Test: constructor with no args
    t = tqdm_rich()
    t.close()

    # Test: constructor with positional arg
    t = tqdm_rich(10)
    t.close()

    # Test: constructor with named arg
    t = tqdm_rich(total=10)
    t.close()

    # Test: constructor with named arg and positional arg
    t = tqdm_rich(10, total=10)
    t.close()

    # Test: constructor with non-numeric positional arg
    t = tqdm_rich(['a', 'b', 'c'])
    t.close()

# Generated at 2022-06-24 10:29:53.326828
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for _ in tqdm(range(2), total=3):
        pass
    # Reset tqdm_rich instance
    tqdm.reset(total=5)
    for _ in tqdm(range(5)):
        pass
    # Exit tqdm_rich
    tqdm.close()

# Generated at 2022-06-24 10:29:59.216910
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test reset method of tqdm_rich class.
    """
    import tempfile
    import time
    with tempfile.TemporaryDirectory() as tmp:
        for i in trange(2, desc='Test', leave=True):
            with open(tmp + '/test.txt', 'w') as f:
                end = time.time() + 1
                while time.time() < end:
                    f.write('test')
                    f.flush()
                    time.sleep(0)

# Generated at 2022-06-24 10:30:04.874552
# Unit test for constructor of class RateColumn
def test_RateColumn():
    task_id = "Test"
    speed = 10.1
    unit = "MB"
    progress = Progress()
    progress.add_task("Test", total=100)
    RateColumn(unit, True, 1000).render(progress._tasks[task_id], speed)
    RateColumn(unit, False, 1000).render(progress._tasks[task_id], speed)

# Generated at 2022-06-24 10:30:06.877234
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    test = RateColumn("")
    test = RateColumn("", unit_scale=False)
    test = RateColumn("", unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-24 10:30:15.761697
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange
    import sys

    with trange(1, position=0, leave=True) as t1:
        for _ in t1:
            with trange(1, position=1, leave=True) as t2:
                for _ in t2:
                    with trange(1, position=2, leave=True) as t3:
                        for _ in t3:
                            pass

    sys.stderr.write(_term_move_up())
    sys.stderr.write(_term_move_up())
    sys.stderr.write(_term_move_up())
    sys.stderr.write(_term_move_up())
    sys.stderr.flush()


# Generated at 2022-06-24 10:30:19.240789
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        t = tqdm_rich('aa')
    except Exception:
        print("Fail to initialize tqdm_rich")
    assert t.display() is None, 'display failed'



# Generated at 2022-06-24 10:30:28.966050
# Unit test for function trange
def test_trange():
    from random import seed, uniform
    from time import sleep

    for _ in trange(10):
        sleep(uniform(0.1, 0.2))
    seed(10)
    for _ in trange(2, 10, 2):
        sleep(uniform(0.1, 0.2))
    for _ in trange(10, 0, -1):
        sleep(uniform(0.1, 0.2))
    for _ in trange(0, 10, 2):
        sleep(uniform(0.1, 0.2))
    for _ in trange(10, 0, -2):
        sleep(uniform(0.1, 0.2))

# Generated at 2022-06-24 10:30:31.856890
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=2) as timer:
        if timer.__enter__():
            pass
        else:
            pass
        timer.clear()



# Generated at 2022-06-24 10:30:34.592654
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Unit test for method render of class FractionColumn
    """
    fraction = FractionColumn()
    task = fraction.render(FractionColumn)
    assert(len(task._text) == 8)


# Generated at 2022-06-24 10:30:40.761983
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress.Task(completed=2, total=4)  #task.speed=1.0
    task.started = 1
    task.total = 1
    task.completed = 0.5
    rc = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rc.render(task) == Text('500.0 KB/s', style='progress.data.speed')

# Generated at 2022-06-24 10:30:49.706304
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm.format_dict['unit_scale'] = True
    tqdm.format_dict['unit_divisor'] = 1024
    task = type('obj', (object,), {
        'completed': 12345678,
        'total': 12345678901234
    })
    tqdm.format_dict['unit_scale'] = False
    tqdm.format_dict['unit_divisor'] = 1000
    # unit_divisor doesn't affect the result when unit_scale is false
    task.completed = 1234
    task.total = 1234567890
    assert str(FractionColumn().render(task)) == "1.23/1234.57 G"

# Generated at 2022-06-24 10:30:50.596934
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    trange(20)

# Generated at 2022-06-24 10:30:52.056458
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as bar:
        bar.clear()

# Generated at 2022-06-24 10:30:53.288167
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich() as t:
       t.display()

# Generated at 2022-06-24 10:30:56.189561
# Unit test for constructor of class RateColumn
def test_RateColumn():
    lStage = "Begin"
    try:
        lRateColumn = RateColumn()
        if lRateColumn is None:
            return False
        lStage = "End"
    except:
        return False

    return True


# Generated at 2022-06-24 10:31:01.739534
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for i in tqdm_rich(range(100000), desc="testing rich", leave=True, unit='B',
                       unit_scale=True, unit_divisor=1024, miniters=1,
                       total=100000, bar_format='{n_fmt}/{total_fmt} '
                                                '[{bar:50}] {percentage:3.0f}% '
                                                '{rate_fmt}',
                       ascii=True):
        if i == 99999:
            return

# Generated at 2022-06-24 10:31:06.888851
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # unit, suffix = filesize.pick_unit_and_suffix(
    #     2097152, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], 1024)
    # assert unit == 2**20
    # assert suffix == "M"
    # rate = RateColumn()
    # print(rate.render())
    pass

# Generated at 2022-06-24 10:31:15.420482
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from collections import namedtuple
    import time

    progress = namedtuple('progress', ['description', 'percentage'])
    for i in trange(10, progress=[
            "[progress.description] {task.description}",
            "[progress.percentage] {task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(unit_scale=False, unit_divisor=1000),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"]):
        desc = progress(description=f"Progress bar {i}", percentage=i)
        time.sleep(0.1)


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-24 10:31:22.301002
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=0, unit_scale=True, unit_divisor=1000,
                   unit='iB', desc='testing', leave=True) as t:
        assert t.desc == 'testing'
        assert t.total == 0
        assert t.unit_scale is True
        assert t.unit_divisor == 1000
        assert t.unit == 'iB'
        assert t.leave is True
        assert t.disable is False

# Generated at 2022-06-24 10:31:25.772112
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    try:
        with tqdm_rich(total=100) as _:
            pass
    except Exception:  # pragma: no cover
        raise
    else:
        pass

if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-24 10:31:32.129854
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import rich
    p = rich.Progress('Task', BarColumn(), '{task.description}')
    try:
        p.__enter__()
        task_id = p.add_task('show', 0)
        p.update(task_id, 'hide', 1)
        p.clear()
        assert True
    except:
        assert False
    finally:
        p.__exit__(None, None, None)

# Generated at 2022-06-24 10:31:41.666706
# Unit test for function trange
def test_trange():
    from tqdm._utils import _term_move_up
    from .utils import format_interval

    with trange(10, desc="trange") as t:
        for i in t:
            assert t.n == i
            t.set_description("desc %i" % i)
            t.set_postfix(ordered_dict=dict(
                i="%i" % i,
                n='%.1f' % t.n,
                rate='%.2f' % t.rate(),
                avg=format_interval(t.avg),
                elapsed=format_interval(t.elapsed)))
            assert len(t) == 10
            assert len(_term_move_up()) <= t.total - t.n

# Generated at 2022-06-24 10:31:46.599596
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn()
    test_task = Progress().add_task("task")
    test_task.total = 10000000
    test_task.completed = 1000000
    assert fraction_column.render(test_task) == Text("1.0/10.0 M", style="progress.download")

# Generated at 2022-06-24 10:31:58.294234
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    progress_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert progress_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert progress_column.render(1) == Text("1.0 B/s", style="progress.data.speed")
    assert progress_column.render(100) == Text("100.0 B/s", style="progress.data.speed")
    assert progress_column.render(100_000) == Text("100.0 KB/s", style="progress.data.speed")
    assert progress_column.render(100_000_000) == Text(
        "100.0 MB/s", style="progress.data.speed")

# Generated at 2022-06-24 10:31:59.529698
# Unit test for function trange
def test_trange():
    assert trange(0) is not None

# Generated at 2022-06-24 10:32:01.588973
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(desc="test", ascii=True) as pbar:
        pbar.display()

# Generated at 2022-06-24 10:32:04.732319
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    progress = ("[progress.description]{task.description}"
                "[progress.percentage]{task.percentage:>4.0f}%",
                BarColumn(bar_width=None),
                FractionColumn())
    x = tqdm_rich(range(10), progress=progress, desc='Progress:')
    for i in x:
        sleep(0.1)

# Generated at 2022-06-24 10:32:11.683841
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    >>> RateColumn(unit="bps")
    RateColumn(unit='bps')
    >>> RateColumn(unit="bps", unit_scale=True)
    RateColumn(unit='bps', unit_scale=True)
    >>> RateColumn(unit="bps", unit_divisor=1000)
    RateColumn(unit='bps', unit_divisor=1000)
    """
    pass

# Generated at 2022-06-24 10:32:16.043227
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Set up __init__ arguments
    unit_scale = False
    unit_divisor = 1000
    # Assert result of instantiation of FractionColumn
    test = FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
    return test


# Generated at 2022-06-24 10:32:25.582617
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        with tqdm_rich(range(10), desc="test tqdm_rich_close") as t:
            pass
    except:
        assert False


if __name__ == "__main__":  # pragma: no cover
    import shutil, sys

    with Progress("[progress.description]{task.description}",
                  BarColumn(bar_width=None),
                  TimeElapsedColumn(), ">",
                  TimeRemainingColumn(),
                  transient=True,
                  ) as progress:
        task = progress.add_task("Test")
        for i in trange(10, desc="test trange"):
            task.update(completed=i, description=f"Test {i} / 10")


# Generated at 2022-06-24 10:32:28.515577
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test constructor."""
    c = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert c.unit_scale == True
    assert c.unit_divisor == 1000

# Generated at 2022-06-24 10:32:30.943018
# Unit test for constructor of class RateColumn
def test_RateColumn():
    task=range(1000)
    rc=RateColumn('b/s',unit_scale=True,unit_divisor=1024)
    rc.render(task)

# Generated at 2022-06-24 10:32:36.428291
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    fc2 = FractionColumn(unit_divisor=100)
    fc3 = FractionColumn(unit_scale=True, unit_divisor=100)

    assert fc.render(None) == Text("0.0/0.0", style="progress.download")
    assert fc2.render(None) == Text("0.0/0.0", style="progress.download")
    assert fc3.render(None) == Text("0.0/0.0", style="progress.download")

# Generated at 2022-06-24 10:32:43.613403
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Constructor of class RateColumn.
    """
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=True,
                        unit_divisor=1000), "]"
    )

# Generated at 2022-06-24 10:32:45.156143
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tgrange
    for _ in tgrange(4):
        pass

# Generated at 2022-06-24 10:32:46.566212
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    d = tqdm_rich(range(1000))
    for _ in d:
        pass
    d.close()

# Generated at 2022-06-24 10:32:49.276486
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    t = tqdm_rich(10, progress=(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "",
    ))
    t.write("Hello world!")
    for _ in t:
        pass

# Generated at 2022-06-24 10:32:56.090841
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = Progress()
    progress.add_task(task_id="task_id", total=10)
    progress.update(task_id="task_id", completed=1)
    progress.render()
    expected = ("[progress.description] \n" "\u001b[1;1H\u001b[0m  1/10  ")
    actual = progress.console.get_screen_string()
    assert expected == actual


# Generated at 2022-06-24 10:32:57.030337
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich.clear()
    assert True

# Generated at 2022-06-24 10:33:01.933175
# Unit test for function trange
def test_trange():
    from tqdm._tqdm import FormatCustomText
    try:
        from tqdm._tqdm_gui import _format_meter
    except ImportError:
        pass
    else:
        FormatCustomText.format_meter = staticmethod(_format_meter)
    trange(10)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:33:03.607693
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    FractionColumn(unit_scale=True)
    FractionColumn(unit_scale=False)
    pass


# Generated at 2022-06-24 10:33:05.129890
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=100, desc="testing") as pbar:
        pbar.clear()

# Generated at 2022-06-24 10:33:11.683066
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    if hasattr(tqdm_rich, "_instances"):
        tqdm_rich._instances.clear()
    t = tqdm_rich(total=10, unit_scale=True)
    assert t.format_dict['unit_scale'] == True
    assert t.format_dict['unit_divisor'] == 1000

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich()

# Generated at 2022-06-24 10:33:16.299331
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    x = tqdm_rich(total=50, progress=("test progress", "{task.description}", BarColumn()))
    x.reset(10)
    x.n = 7
    x.close()
    mt = tqdm_rich(total=0)
if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-24 10:33:25.400370
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import mock
    from pytest import raises

    def _tqdm_mock(disable=False):
        t = mock.Mock(disable=disable, total=1, desc='desc')

# Generated at 2022-06-24 10:33:32.823599
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .main import format_sizeof
    from .utils import format_interval
    from .compatibility import PY2
    if PY2:
        from itertools import izip as zip
    from time import time, sleep

    # Test
    t_max = 100
    n_max = 500
    with tqdm(total=t_max, leave=False) as t:
        for n in range(n_max):
            t.set_description("Description: {0}".format(
                format_interval(time() - t.start_t)))
            t.refresh(n)
            sleep(0.01)
            assert t.get_lock()._RLock__count == 1

    # Test
    t_max = 100
    n_max = 50

# Generated at 2022-06-24 10:33:40.808158
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn(unit='B', unit_scale=True, unit_divisor=1000)) == "0.0 B/s"
    assert str(RateColumn(unit='B', unit_scale=False, unit_divisor=1000)) == "0.0 B/s"
    assert str(RateColumn(unit='B', unit_scale=True, unit_divisor=1024)) == "0.0 B/s"
    assert str(RateColumn(unit='B', unit_scale=False, unit_divisor=1024)) == "0.0 B/s"
    assert str(RateColumn(unit='B', unit_scale=True)) == "0.0 KB/s"
    assert str(RateColumn(unit='B', unit_scale=False)) == "0.0 B/s"

# Generated at 2022-06-24 10:33:48.875448
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test for `tqdm.rich.clear`."""
    import rich
    import rich.console

    console = rich.console.Console()
    rich.console.Console.reset_console = lambda *a, **kw: None
    assert not console.print_lines

    with tqdm_rich(total=3, leave=True, ascii=True) as tqdm_instance:
        assert console.print_lines
        tqdm_instance.clear()
        assert console.print_lines



# Generated at 2022-06-24 10:33:51.094933
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert(RateColumn().render(None)==Text("? /s", style="progress.data.speed"))
    


# Generated at 2022-06-24 10:33:52.384841
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4):
        pass

# Generated at 2022-06-24 10:34:01.316372
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Unit test for constructor of class tqdm_rich.
    """
    # This class accepts the following parameters *in addition* to
    # the parameters accepted by `tqdm`.

# Generated at 2022-06-24 10:34:03.260522
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn()
    assert column.render("task") == "?"

# Generated at 2022-06-24 10:34:05.542453
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for bar1 in (tqdm_rich(range(10)), tqdm_rich(range(10), disable=True)):
        bar1.close()

# Generated at 2022-06-24 10:34:08.660958
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=2) as pbar:
        pbar.write("foo")
        pbar.close()
        pbar.write("bar")

# Generated at 2022-06-24 10:34:16.013535
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test FractionColumn.render()"""
    test_task_completed = 1
    test_task_total = 2
    test_unit_scale = True
    test_unit_divisor = 1000

    fraction_column = FractionColumn(
        unit_scale=test_unit_scale, unit_divisor=test_unit_divisor)
    test_task = Mock()
    test_task.completed = test_task_completed
    test_task.total = test_task_total

    result, _ = fraction_column.render(test_task)
    assert result == Text(f"0.000/0.001 K", style="progress.download")



# Generated at 2022-06-24 10:34:17.941697
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(object()) == Text("0.0/0.0", style="progress.download")

# Generated at 2022-06-24 10:34:27.961338
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.progress import BarColumn, Progress, Text
    from time import sleep
    for i in tqdm_rich(total=10, leave=True, progress=("[", BarColumn(bar_width=None), "]")):
        sleep(0.1)
    for i in tqdm_rich(total=10, leave=True, progress=(Text("Progress: ", style="class:progress.label"),"[", BarColumn(bar_width=None), "]")):
        sleep(0.1)
    for i in tqdm_rich(total=10, leave=True, progress=("[", BarColumn(bar_width=None), "]", Text("Progress: "))):
        sleep(0.1)

# Generated at 2022-06-24 10:34:35.761705
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(None).text == "0/0 "
    assert FractionColumn(unit_scale=True).render(None).text == "0/0 "
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(None).text == "0/0 "

# Generated at 2022-06-24 10:34:39.037966
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test for method render.
    task = type("MockTask", (), {"speed": None})()
    rate_column = RateColumn()
    display = rate_column.render(task)
    assert display.text == "? /s"
    assert display.style_name == "progress.data.speed"

# Generated at 2022-06-24 10:34:41.264599
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        pbar = tqdm_rich(total=1)
        pbar.clear()
    except NotImplementedError:
        pass

# Generated at 2022-06-24 10:34:42.595297
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm_gui
    from .utils import FormatStrin

# Generated at 2022-06-24 10:34:45.074034
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None).text == "? /s"
    assert RateColumn(unit_scale=True).render(None).text == "?  /s"
    assert RateColumn(unit_scale=True, unit="b").render(None).text == "? b/s"



# Generated at 2022-06-24 10:34:56.325460
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.completed = 1000
    task.total = 3000
    column = FractionColumn()
    text = column.render(task)
    assert text.value == "1.0/3.0 "
    assert text.style == "progress.download"
    column = FractionColumn(unit_scale=True)
    text = column.render(task)
    assert text.value == "1.0/3.0 K"
    assert text.style == "progress.download"
    column = FractionColumn(unit_scale=False)
    text = column.render(task)
    assert text.value == "1.0/3.0 "
    assert text.style == "progress.download"
    column = FractionColumn(unit_divisor=1024)
    text = column.render(task)
   

# Generated at 2022-06-24 10:35:00.920882
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm(total=3) as t:
        assert t.display() is None
        assert t.display(1.0) is None
        assert t.display(0.0, 1.0) is None
        assert t.display('1', '2') is None
        assert t.display(1, 2) is None

# Generated at 2022-06-24 10:35:02.411522
# Unit test for function trange
def test_trange():
    for _ in trange(5):
        pass



# Generated at 2022-06-24 10:35:10.522363
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task('Test', total=100)
    task.update_progress(20)
    assert FractionColumn().render(task) == Text('0.2/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1).render(task) == Text('0.2/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text('200/1000 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=10000).render(task) == Text('20/100 ', style='progress.download')
    task.update_progress(50)

# Generated at 2022-06-24 10:35:13.584798
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit='B', unit_scale=True, unit_divisor=1000)
    unit, suffix = filesize.pick_unit_and_suffix(
        speed=100,
        units=["", "K", "M", "G", "T", "P", "E", "Z", "Y"],
        unit_divisor=1000)
    assert str(rate_column.render(unit)) == "0.1 KB/s"

# Generated at 2022-06-24 10:35:17.911817
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for __ in tqdm_rich(range(1000)):  # pragma: no cover
        pass
    for __ in tqdm_rich(range(1000)):  # pragma: no cover
        pass
    for __ in tqdm_rich(range(1000)):  # pragma: no cover
        pass
    for __ in tqdm_rich(range(1000)):  # pragma: no cover
        pass

# Generated at 2022-06-24 10:35:26.517506
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    with tqdm(total=100) as pbar:
        for i in range(100):
            pbar.update()
        assert pbar.n == 100
        pbar.reset(total=200)
        assert pbar.n == 0
        assert pbar.total == 200
        for i in range(200):
            pbar.update()
        assert pbar.n == 200
        pbar.reset(total=100)
        assert pbar.n == 0
        assert pbar.total == 100
        pbar.reset(total=0)
        assert pbar.total == 0

# Generated at 2022-06-24 10:35:34.766736
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    from tqdm._utils import _term_move_up
    from tqdm.utils import _environ_cols_wrapper
    # simulate tqdm.std.tqdm.close
    sys.stderr.write(_term_move_up())
    @_environ_cols_wrapper
    def my_print(*a, **k):
        print(k.get('file', sys.stdout), *a)
    if hasattr(sys.stderr, 'isatty') and sys.stderr.isatty():
        my_print('\n')
    # simulate tqdm.rich.tqdm.close
    t = tqdm_rich(total=4)
    for i in range(4):
        t.update()
    t.close()