

# Generated at 2022-06-24 10:25:27.868158
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    if __name__ == '__main__':
        progress = Progress()
        progress.add_task("Test Task", total = None)
        if progress.update('Test Task', completed = 0):
            print("Test passed")

# Generated at 2022-06-24 10:25:35.573761
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tqdm_rich.reset()
    task = tqdm_rich()
    task.n = 0
    task.total = 100000
    task.start_t = 12345
    task.last_print_n = 0
    task.last_print_t = 12345
    task.dynamic_miniters = None
    rate_column = task.format_dict['rate_column']

    # Time is a line and rate is none
    assert rate_column.render(task) == "[progress.data.speed]? s/s"

    # Time is none and rate is 0
    task.n = 10000
    task.last_print_n = 0
    assert rate_column.render(task) == "[progress.data.speed]0 s/s"

    # Time is 1 and rate is 10
    task.n = 10000

# Generated at 2022-06-24 10:25:36.181580
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pass

# Generated at 2022-06-24 10:25:38.828508
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=10, desc='Default')
    for i in range(10):
        t.update()
        t.display()
    t.close()

# Generated at 2022-06-24 10:25:41.372282
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    file_size = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert file_size.unit_scale == True
    assert file_size.unit_divisor == 1000


# Generated at 2022-06-24 10:25:45.843440
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn(unit="b", unit_scale=False, unit_divisor=1000)
               .render(Progress(total=1000, completed=100, speed=100))) == '100.0 b/s'
    assert str(RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
               .render(Progress(total=1000, completed=100, speed=100))) == '100.0 B/s'



# Generated at 2022-06-24 10:25:53.022677
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test that `render()` returns the correct value for each given speed
    value, using the default unit ("") and unit scale set to `False`
    (not using different units for the speed).
    """
    rate_column = RateColumn(unit_scale=False)

    for speed in [0, 10, 100, 1000, 10000, 100000]:
        task = type('', (), {'speed': speed})()
        assert rate_column.render(task) == Text(f"{speed} /s", style="progress.data.speed")



# Generated at 2022-06-24 10:26:02.425176
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test for tqdm_rich.__init__() constructor."""
    try:
        from rich.console import Console
        from rich.progress import Progress
    except ImportError:
        raise ImportError("run: pip install rich")
    # Test with default parameter
    from rich.traceback import install
    install()
    t = tqdm_rich(total=10)
    t.close()
    # Test with custom parameters

# Generated at 2022-06-24 10:26:06.354796
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    ratecol = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert ratecol.render(Progress()) == Text("? B/s", style="progress.data.speed")



# Generated at 2022-06-24 10:26:08.339242
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    column.render("1/1")
    assert(False)

# Generated at 2022-06-24 10:26:17.116554
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import Progress
    from rich.columns import Columns
    from rich.table import Table
    from rich.text import Text
    import copy
    import rich.console
    from rich.syntax import Syntax

    with Progress() as progress:
        task = progress.add_task("Testing FractionColumn", total=0)
        progress.set_columns(Columns("[progress.description]{task.description}", FractionColumn()))
        assert len(progress.tasks) == 1

        task = progress.add_task("Testing FractionColumn", total=0)
        progress.set_columns(Columns("[progress.description]{task.description}", FractionColumn(unit_scale=True)))
        assert len(progress.tasks) == 2


# Generated at 2022-06-24 10:26:29.221376
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from collections import namedtuple
    tq = namedtuple("tq", "completed total speed desc")
    for example in examples:
        assert RateColumn().render(tq(0,0,example, "")) == Text(f"{example[0]} {example[1]}/s", style="progress.data.speed")
        assert RateColumn().render(tq(0,0,example, "hi")) == Text(f"{example[0]} {example[1]}/s", style="progress.data.speed")
        assert RateColumn("/s").render(tq(0,0,example, "")) == Text(f"{example[0]} {example[1]}/s/s", style="progress.data.speed")
        assert RateColumn("/s").render(tq(0,0,example, "hi")) == Text

# Generated at 2022-06-24 10:26:31.207692
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    assert f.render({'completed': 2, 'total': 5})


# Generated at 2022-06-24 10:26:33.030192
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    console = Console()
    pbar = tqdm_rich(total=10)
    pbar.update(5)
    pbar.reset(total=20)
    pbar.update(5)
    pbar.close()
    console.clear()

# Generated at 2022-06-24 10:26:40.263144
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = None
    task.completed = 1000
    task.total = None
    rc = RateColumn()
    t = rc.render(task)
    assert str(t) == '? B/s'
    task.completed = 10
    task.speed = 10
    t = rc.render(task)
    assert str(t) == '1.0 B/s'
    task.speed = 1024
    task.unit_scale = True
    t = rc.render(task)
    assert str(t) == '1.0 KB/s'
    task.speed = 1000
    t = rc.render(task)
    assert str(t) == '1.0 KB/s'


# Generated at 2022-06-24 10:26:41.280847
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(range(10))

# Generated at 2022-06-24 10:26:47.501600
# Unit test for constructor of class RateColumn

# Generated at 2022-06-24 10:26:51.081884
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    task = Progress()
    task.completed = 2
    task.total = 7
    task.description = "test"
    column = FractionColumn()
    column.render(task)



# Generated at 2022-06-24 10:26:58.317009
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.progress import Progress, TimeRemainingColumn, BarColumn
    from rich.console import Console

    console = Console()
    with console:
        for i, _ in zip(tqdm_rich("Hello World!", progress=(
                "[progress.description]{task.description}",
                BarColumn(bar_width=None),
                "[progress.percentage]{task.percentage:>4.0f}%",
                "[", TimeRemainingColumn(), "] ",
        )),
                range(1, 100)):
            if i >= 50:
                pass
            else:
                pass
            pass

# Generated at 2022-06-24 10:27:00.951157
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    a = tqdm_rich(total=10, position=0)
    a.reset(total=12)
    assert a.total == 12

# Generated at 2022-06-24 10:27:05.855609
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm(total=100)
    task.update(10)
    column = FractionColumn()
    assert column.render(task) == Text("10.0/100.0 ", style="progress.download")
    task.update(100)
    assert column.render(task) == Text("100.0/100.0 ", style="progress.download")
    task.close()


# Generated at 2022-06-24 10:27:17.041418
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from io import StringIO

    progress = Progress(
        Text("{task.percentage:>4.0f}%", style="progress.percentage"),
        BarColumn(bar_width=None),
        RateColumn(unit="B", unit_scale=True, unit_divisor=1024),
    )

    # Case 1: None speed
    task_id = progress.add_task("test")
    buffer = StringIO()
    progress.update(task_id, percentage=10, description="test")
    progress.render(buffer)
    assert buffer.getvalue() == "\rtest   10% ┃ ██                                         █▏  ? B/s"

    # Case 2: Valid speed
    progress.update(task_id, percentage=100, speed=100)
    buffer = StringIO()

# Generated at 2022-06-24 10:27:21.681601
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Unit testing of the method render of class FractionColumn
    """
    from rich.progress import Task

    task = Task()
    task.completed = 300000
    assert str(FractionColumn().render(task)) == "300,000/NaN"



# Generated at 2022-06-24 10:27:27.960599
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    """Unit test for method :meth:`tqdm_rich.close`."""
    t = tqdm_rich("test")
    # Python 2:
    exec("assert isinstance(t, tqdm_rich)")
    # Python 3:
    assert isinstance(t, tqdm_rich)
    t.close()
    assert t.disable
    t.disable = False
    t.close()
    assert t.disable

# Generated at 2022-06-24 10:27:33.011456
# Unit test for function trange
def test_trange():
    import os
    with trange(100) as t:
        assert os.get_terminal_size()[1] >= 10
        for i in t:
            assert t.n == i
            assert t.n == t.last_print_n
            assert t.n <= 100
            assert t.total == 100
        assert t.n == t.last_print_n == 100
        assert t.n == t.total == 100



# Generated at 2022-06-24 10:27:39.884299
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test that `tqdm.rich.tqdm` callbacks work even after the bar has ended,
    via the `.display()` method. This is used by `tqdm.notebook`.
    """
    import time

    with tqdm(total=2) as t:
        time.sleep(1)
        t.update()
        time.sleep(1)
        t.update()
    time.sleep(1)
    t.display()  # not tested

# Generated at 2022-06-24 10:27:42.979488
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        for i in t:
            assert hasattr(t, '_prog')
            t.set_description(str(i))
            t.update()



# Generated at 2022-06-24 10:27:54.389794
# Unit test for method render of class RateColumn
def test_RateColumn_render():  # pragma: no cover
    import pytest

    # case 1
    task_1 = std_tqdm.tqdm(_range(1000))
    task_1.total = 1000
    task_1.update(100)
    task_1.update(200)
    task_1.update(300)
    task_1.close()

    rc = RateColumn()
    assert rc.render(task_1) == Text("600.0 /s", style="progress.data.speed")

    # case 2
    task_2 = std_tqdm.tqdm(_range(1000))
    task_2.total = 1000
    task_2.update(100)
    task_2.update(200)
    task_2.update(300)
    task_2.close()


# Generated at 2022-06-24 10:27:57.027489
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    prog_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    prog_column.__init__()


# Generated at 2022-06-24 10:27:58.359054
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    assert not tqdm_rich().close()

# Generated at 2022-06-24 10:28:06.155319
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    console = Console()
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.update()
            pbar.reset(total=100)
    assert pbar.total == 100
    pbar.reset(total=200)
    assert pbar.total == 200
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.update()
            pbar.reset()
    pbar.reset(total=200)
    assert pbar.total == 100

# Generated at 2022-06-24 10:28:16.310647
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    from rich.console import Console
    console = Console()
    progress = Progress()
    task = Task("task1", Console(), progress)
    task.total = 1024*1024*1024
    task.completed = 10*1024*1024
    task.write()
    # test unit of 1024
    column1 = FractionColumn()
    output = column1.render(task)
    text1 = "[progress.download]9.8/1024.0 M"
    assert output.text == text1, "render() returned wrong string."
    # test unit of 1K
    column2 = FractionColumn(unit_divisor=1)
    output = column2.render(task)
    text2 = "[progress.download]10048.0/1048576.0 K"
    assert output.text == text2

# Generated at 2022-06-24 10:28:22.150288
# Unit test for function trange
def test_trange():  # pragma: no cover
    # noqa
    pbar = trange(100)
    for _i in pbar:
        pbar.set_description("Fizz" * (_i % 3 == 0) + "Buzz" * (_i % 5 == 0))
    pbar.close()
    assert pbar.n == 100



# Generated at 2022-06-24 10:28:30.847582
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    unit_scale = False
    unit_divisor = 1000
    with FractionColumn(unit_scale, unit_divisor):
        Text(
            f"{1/1000:,.0f}/{1/1000:,.0f} ",
            style="progress.download")
        Text(
            f"{1/1000000:,.0f}/{1/1000000:,.0f} K",
            style="progress.download")
        Text(
            f"{1/1000000000:,.0f}/{1/1000000000:,.0f} M",
            style="progress.download")
        Text(
            f"{1/1000000000000:,.0f}/{1/1000000000000:,.0f} G",
            style="progress.download")

# Generated at 2022-06-24 10:28:38.752894
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import trange

    # tqdm reset takes no args
    assert tqdm_rich.reset.__code__.co_argcount == 1

    with tqdm_rich(total=10) as bar:
        bar.reset(total=20)
        assert bar.total == 20
        bar.n = 10
        bar.reset()
        assert bar.n == 0

    with trange(10) as bar:
        bar.reset(total=20)
        assert bar.total == 20

# Generated at 2022-06-24 10:28:41.564501
# Unit test for function trange
def test_trange():
    from .utils import format_interval
    n = 500000
    for i in trange(1, n + 1, miniters=1, maxinterval=0.5, mininterval=0.05):
        format_interval(i)
        format_interval(i + 0.1)


__all__ = ['tqdm_rich', 'trrange', 'tqdm', 'trange']

# Generated at 2022-06-24 10:28:44.966016
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from random import random
    for _ in tqdm(range(int(1e7))):
        random()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich()

# Generated at 2022-06-24 10:28:49.846875
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Test constructor.
    """
    assert FractionColumn().unit_scale == False
    assert FractionColumn().unit_divisor == 1000
    assert FractionColumn(True, 1024).unit_scale == True
    assert FractionColumn(True, 1024).unit_divisor == 1024


if __name__ == '__main__':  # pragma: no cover
    # Test code
    with tqdm_rich(total=10, desc='Testing', leave=True) as progress:
        for i in progress:
            progress.display()
            progress.n = i

# Generated at 2022-06-24 10:28:56.520141
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import TaskID
    fc = FractionColumn()
    assert fc.render(TaskID(1, completed=122, total=444)) == Text('0.3/1.5 ', style='progress.download')
    fc = FractionColumn(unit_scale=True)
    assert fc.render(TaskID(2, completed=1, total=9)) == Text('1000.0/9000.0 ', style='progress.download')


# Generated at 2022-06-24 10:28:57.965482
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich method display"""
    tqdm_rich._prog.__exit__(None, None, None)

# Generated at 2022-06-24 10:29:00.345292
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(total=500)
    fcolumn = FractionColumn()
    fcolumn.render(task)
    task.close()

# Generated at 2022-06-24 10:29:01.036301
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-24 10:29:05.848515
# Unit test for function trange
def test_trange():
    list(trange(3))
    list(trange(5))
    list(trange(3, 3))
    list(trange(3, 2, -1))
    list(trange(0, 5, 0))
    list(trange(0, 1, 0.1))
    list(tqdm([]))
    list(tqdm(iter([])))

# Generated at 2022-06-24 10:29:09.392551
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(range(10)) as t:
        assert t.disable is False
        t.clear()
        assert t.disable is False
        t.disable = True
        assert t.disable is True
        t.clear()
        assert t.disable is True

# Generated at 2022-06-24 10:29:20.511512
# Unit test for function trange
def test_trange():
    """Testing function trange"""
    with trange(10) as t:
        for i in t:
            assert i in t
            assert i == t.n
            t.set_description("Sushi")
            assert t.desc == "Sushi"
            t.set_postfix(str(i))
            assert t.postfix == str(i)
            t.refresh()

    with trange(10, desc="Sushi") as t:
        for i in t:
            assert i in t
            assert i == t.n
            t.set_description("Sushi")
            assert t.desc == "Sushi"
            t.set_postfix(str(i))
            assert t.postfix == str(i)
            t.refresh()


# Generated at 2022-06-24 10:29:26.137756
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # test when unit == 1
    fc = FractionColumn(unit_scale=True)
    assert fc.unit_scale == True
    assert fc.unit_divisor == 1000

    # test when unit > 1
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.unit_scale == True
    assert fc.unit_divisor == 1024

    # test when unit < 1
    fc = FractionColumn(unit_scale=False)
    assert fc.unit_scale == False
    assert fc.unit_divisor == 1000



# Generated at 2022-06-24 10:29:29.875992
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(desc="Testing call to close() method", total=10) as pbar:
        for _ in pbar:
            pass


# Generated at 2022-06-24 10:29:39.839473
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    d = tqdm_rich(total=10)
    d.n = 5
    f = FractionColumn()
    assert f.render(d) == '5.0/10'
    d.reset(total=100)
    assert f.render(d) == '5.0/100'
    d.reset(total=1000)
    assert f.render(d) == '5.0/1000'
    d.reset(total=10000)
    assert f.render(d) == '5.0/10000'
    d.reset(total=100000)
    assert f.render(d) == '5.0/100000'
    d.reset(total=1000000)
    assert f.render(d) == '5.0/1000000'
    d.reset(total=10000000)
    assert f

# Generated at 2022-06-24 10:29:47.549335
# Unit test for function trange
def test_trange():  # pragma: no cover
    import time
    import sys
    if sys.version_info >= (3, 4):
        # destroy customizations done by text version
        try:
            del tqdm.terminals.tqdm_gui.screen
        except AttributeError:
            pass
    for _ in trange(4, desc='A loop', leave=True):
        for _ in trange(5, desc='B loop', leave=True):
            for _ in trange(50, desc='C loop'):
                time.sleep(0.01)
        time.sleep(0.1)
    time.sleep(2)

# Generated at 2022-06-24 10:29:56.542345
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Task
    t = Task("Test", total=1)
    rate_column = RateColumn(unit="b", unit_scale=True, unit_divisor=1000)
    # Test unit, suffix and precision
    assert rate_column.render(t) == Text("? b/s", style="progress.data.speed")
    t.speed = 1000
    assert rate_column.render(t) == Text("1 Kb/s", style="progress.data.speed")
    t.speed = 100000
    assert rate_column.render(t) == Text("100 Kb/s", style="progress.data.speed")

# Generated at 2022-06-24 10:30:01.515883
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm(range(10), gui=True)
    assert (t._prog.tasks[t._task_id].completed == 0)
    t.update(1)
    t.close()
    assert (t._prog.tasks[t._task_id].completed == 1)


# Generated at 2022-06-24 10:30:05.634131
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from .utils import FormatStdoutTest

    with FormatStdoutTest():
        for i in tqdm_rich(range(10)):
            print(i, end=' ')
            pass



# Generated at 2022-06-24 10:30:13.032279
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    with tqdm_rich(total=10, desc='task 1') as progress_bar:
        for i in range(10):
            time.sleep(1)
            progress_bar.set_postfix(foo='bar', i=i)
            progress_bar.n = i + 1

    progress_bar.reset(total=5)
    progress_bar.set_description('task 2')

    for i in range(5):
        time.sleep(1)
        progress_bar.n = i + 1
        progress_bar.set_postfix(foo='bar', i=i)

# Generated at 2022-06-24 10:30:23.366694
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    progress_list = [
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit='B', unit_scale=False, unit_divisor=1000), "]"
    ]
    tqdm(total=3, desc='test subclass', progress=progress_list)


if __name__ == "__main__":  # pragma: no cover
    import unittest
    _test_tqdm = unittest.TestLoader().loadTestsFromTestCase(test_tqdm_rich)
   

# Generated at 2022-06-24 10:30:30.406754
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import TestCase, main
    class Test(TestCase):
        def test_display(self):
            import os
            import signal

            p = os.getpid()
            t_pid = os.fork()
            if t_pid == 0:
                t = tqdm_rich(0)
                t.display()
                os.kill(p, signal.SIGTERM)
            else:
                main()

    test = Test()
    test.test_display()


# Generated at 2022-06-24 10:30:34.374922
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Tests the display method of tqdm_rich."""
    with tqdm_rich(total=100) as progress:
        progress.display()
        progress.update(1)
        progress.display()
        progress.update(10)
        progress.display()
        progress.close()
        progress.display()
    progress.display()

# Generated at 2022-06-24 10:30:42.246325
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = object()
    task.completed = 15
    task.total = 200
    assert FractionColumn().render(task) == Text('0.1/2.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('15/200 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0/0 ', style='progress.download')


# Generated at 2022-06-24 10:30:44.830630
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as t:
        t.clear()

# Generated at 2022-06-24 10:30:46.559544
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Tests that clear method does not raise an error,
    
    """
    t = tqdm_rich(total=100)
    for i in t:
        t.clear()



# Generated at 2022-06-24 10:30:55.273169
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    sys.modules['tqdm.auto'] = sys.modules['tqdm.auto.tqdm']
    import tqdm.auto as tqdm
    import time

    print("Manually tqdm", end='\r')
    time.sleep(0.1)
    t = tqdm.tqdm(total=200, ncols=20)

    for i in range(200):
        print("Manually tqdm", end='\r')
        time.sleep(0.01)
        t.update(1)
    t.display()
    print()

    print("Automatically tqdm")
    for i in tqdm.tqdm(range(200)):
        time.sleep(0.01)
    print()

    # tqdm.tqdm.write

# Generated at 2022-06-24 10:30:59.775696
# Unit test for function trange
def test_trange():
    """Test ``rich.progress.trange``."""
    from pytest import raises

    with raises(ValueError):
        for _ in trange(-3):
            pass
    for _ in trange(3):
        pass
    it = trange(3, desc="test", smoothing=0)
    assert (next(it), it.n, it.last_print_n) == (0, 0, 0)
    assert (next(it), it.n, it.last_print_n) == (1, 1, 1)
    assert (next(it), it.n, it.last_print_n) == (2, 2, 2)
    with raises(StopIteration):
        next(it)



# Generated at 2022-06-24 10:31:02.075848
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn(unit_scale=True)
    task = column.ProgressColumn
    task.speed = 1024
    task.style = "progress.data.speed"
    column.render(task)

# Generated at 2022-06-24 10:31:03.044123
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    assert str(tqdm_rich('Test'))

# Generated at 2022-06-24 10:31:13.447675
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test RateColumn.render method."""
    task = std_tqdm()
    task.speed = 100
    print(RateColumn(unit='B').render(task))
    print(RateColumn(unit='B', unit_scale=True).render(task))
    print(RateColumn(unit='B', unit_scale=True, unit_divisor=1024).render(task))
    task.speed = 1024
    print(RateColumn(unit='B').render(task))
    print(RateColumn(unit='B', unit_scale=True).render(task))
    print(RateColumn(unit='B', unit_scale=True, unit_divisor=1024).render(task))
    task.speed = 2048
    print(RateColumn(unit='B').render(task))

# Generated at 2022-06-24 10:31:25.355554
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=100) as t:
        for i in _range(100):
            t.update()
            t.set_postfix(postfix=i)
    assert t.n == t.total
    with tqdm_rich(total=100) as t:
        for i in _range(100):
            t.update(1)
            t.set_postfix(postfix=i)
    assert t.n == t.total
    with tqdm_rich(total=-1) as t:
        pass
    assert t.n == 0
    with tqdm(total=-1) as t:
        pass
    assert t.n == 0
    with tqdm(total=0) as t:
        pass
    assert t.n == 0

# Generated at 2022-06-24 10:31:28.256456
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import os
    try:
        del os.environ["COLUMNS"]
    except KeyError:
        pass
    with tqdm(total=100) as pbar:
        pbar.reset(total=50)

# Generated at 2022-06-24 10:31:40.286020
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test reset method of tqdm_rich"""
    from .std import tqdm as std_tqdm
    with tqdm_rich(total=10) as bar:
        bar.update()
        bar.reset(total=100)
        assert bar._prog.tasks[bar._task_id].total == 100
        assert bar.total == 100
        bar.reset()
        assert bar._prog.tasks[bar._task_id].total == 100
        assert bar.total == 100
        bar.reset(total=200)
        assert bar._prog.tasks[bar._task_id].total == 200
        assert bar.total == 200
    with tqdm_rich(total=10) as bar:
        bar.update()
        bar.reset(total=100)

# Generated at 2022-06-24 10:31:49.154312
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.console import Console
    console = Console()

    rc = RateColumn()
    rc.render(task=None)
    rc.render(task=None)
    assert rc.render(task=None)

    rc = RateColumn(unit="b")
    rc.render(task=None)
    rc.render(task=None)
    assert rc.render(task=None)

    rc = RateColumn(unit="b", unit_scale=True)
    rc.render(task=None)
    rc.render(task=None)
    assert rc.render(task=None)
    rc.console = console
    rc.render(task=None)



# Generated at 2022-06-24 10:31:54.374204
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    with Progress() as progress:
        task = progress.add_task("test", start=0, end=10)
        test = tqdm_rich(total=10)
        test._prog = progress
        test._task_id = task
        test.display()

# Generated at 2022-06-24 10:31:57.789975
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(10) == "1.0/10 "
    assert FractionColumn(unit_scale=True).render(10240) == "10.0/10.0 K"
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(10240) == "10.0/9.77 K"



# Generated at 2022-06-24 10:32:03.371680
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm.auto import trange
    with trange(10) as t:
        try:
            for x in t:
                if x > 3:
                    t.reset(total=0)
                else:
                    t.reset()
        except ValueError as e:
            assert str(e) == "New total must be greater than current total", "unexpected error message: " + str(e)

# Generated at 2022-06-24 10:32:07.703991
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        with tqdm(total=1) as pbar:
            pbar.clear()
    except Exception:
        raise AssertionError("tqdm_rich.clear() not working correctly.")

# Generated at 2022-06-24 10:32:10.191915
# Unit test for function trange
def test_trange():
    """Test trange alias"""
    with trange(10) as t:
        for _ in t:
            pass



# Generated at 2022-06-24 10:32:11.937337
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="", unit_scale=False, unit_divisor=1000)


# Generated at 2022-06-24 10:32:17.423668
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich.console
    except ModuleNotFoundError:
        return
    progress = [
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
    ]
    with tqdm_rich(total=100, desc="test", progress=progress) as bar:
        bar.clear()
        bar.display()

# Generated at 2022-06-24 10:32:23.408738
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from unittest.mock import patch, MagicMock
    from tqdm.rich import tqdm_rich
    
    iterator = (i for i in range(10))
    iterbar = tqdm_rich(iterator, disable=False)
    iterbar._prog = MagicMock()
    iterbar.disable = False
    iterbar.close()
    iterbar._prog.__exit__.assert_called_with(None, None, None)

# Generated at 2022-06-24 10:32:26.293509
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Test for the constructor of class RateColumn.
    """
    progress_column = RateColumn()
    rendered_text = progress_column.render(None)
    assert rendered_text == Text(f"? /s", style="progress.data.speed")

# Generated at 2022-06-24 10:32:33.501880
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Unit test for constructor of class FractionColumn."""
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(
        Progress.__base__(total=2.3*1000**3, completed=0.5*1000**3)) == \
        Text("464.8/2,300.0 G", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(
        Progress.__base__(total=2.3*1024**3, completed=0.5*1024**3)) == \
        Text("491.7/2,391.0 G", style="progress.download")

# Generated at 2022-06-24 10:32:37.914847
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    col = FractionColumn()
    expected = Text('0.0/1.0 ', style='progress.download')
    assert col.render(Progress(total=1, completed=0)) == expected



# Generated at 2022-06-24 10:32:42.382272
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import time

    for _ in tqdm_rich(range(50), desc="I am a progress bar!"):
        time.sleep(0.1)

        sys.stdout.write('\x08' * 8 + '[{}]'.format('=' * _))
        sys.stdout.flush()

# Generated at 2022-06-24 10:32:45.726421
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)
    text = rate_column.render(rate_column)
    assert text._style == "progress.data.speed"
    assert text._text == "? /s"



# Generated at 2022-06-24 10:32:51.383180
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    from .gui import tgrange

    for _min, _max, _n, leave, unit, unit_scale, total in [
            (0, 10, None, True, None, None, None),
            (0, 10, None, True, "iB", None, None),
            (0, 10, None, True, "iB", True, None),
            (0, 10, None, True, "iB", None, 1000),
    ]:
        with tgrange(_min, _max, _n, leave, unit, unit_scale, total) as t:
            for i in t:
                t.sleep()

# Generated at 2022-06-24 10:32:59.279273
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from io import StringIO
    import sys

    class FakeTqdm:
        def __init__(self, *a, **k):
            self.stdout = StringIO()
            self.format_dict = dict(desc='title', unit='bytes', unit_scale=True,
                                    unit_divisor=1024, miniters=1, miniters_fixed=False,
                                    mininterval=1, mininterval_fixed=False, maxinterval=100,
                                    maxinterval_fixed=False, max_width=80, leave=True,
                                    file=self.stdout, gui=True, disable=False)

        def reset(self, total=None):
            self.stop()

        def stop(self):
            self.stdout.close()


# Generated at 2022-06-24 10:33:05.736604
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.console import Console
    from rich.progress import TaskID
    
    console = Console()
    fmt = RichFormat()
    fmt.default_format_dict_locale = ['es_ES', 'es-ES', 'es-419']
    print(fmt.default_format_dict_locale)

    task_label = fmt.format_dict['task_label']
    task_label['completed'] = ''
    task_label['total'] = ''

    task = FractionColumn()
    task.render(TaskID(console, **task_label))

# Generated at 2022-06-24 10:33:07.710475
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm_rich(range(100), clear=True):
        pass


# Generated at 2022-06-24 10:33:18.061766
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test for method render"""
    import math

    # Case 1: speed = None, unit = None
    task = type('', (), {'speed': None})()
    rate_column = RateColumn()
    assert (
        rate_column.render(task) ==
        Text('? /s', style='progress.data.speed')
    )

    # Case 2: speed = None, unit = 'test'
    task = type('', (), {'speed': None})()
    rate_column = RateColumn(unit='test')
    assert (
        rate_column.render(task) ==
        Text('? test/s', style='progress.data.speed')
    )

    # Case 3: unit_scale = True, unit_divisor = 1000
    task = type('', (), {'speed': 500000})()
    rate_

# Generated at 2022-06-24 10:33:26.946463
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = type('Progress', (object,),
                 {'description': 'Test', 'total': 10, 'completed': 5,
                  'speed': 20, 'percentage': 80})()
    # Unit = s
    result = RateColumn().render(task)
    assert result.text == "20 s/s"
    assert result.style == "progress.data.speed"
    # Unit scale
    result = RateColumn(unit_scale=True).render(task)
    assert result.text == "20 s/s"
    # Unit scale, unit
    result = RateColumn(unit="B", unit_scale=True).render(task)
    assert result.text == "20 B/s"
    # Unit
    result = RateColumn(unit="B").render(task)
    assert result.text == "20 B/s"
   

# Generated at 2022-06-24 10:33:29.565841
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os, sys
    sys.stderr = open(os.devnull, 'w')
    try:
        t = tqdm_rich(range(10000), disable=True)
        t.n = 5000
        t.display()
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:33:31.479998
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        for i in tqdm_rich(range(10)):
            assert i
    except Exception as e:
        raise e



# Generated at 2022-06-24 10:33:34.844549
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert str(column.render({'completed': 522, 'total': 1430})) == '0.522/1.430 k'

# Generated at 2022-06-24 10:33:39.861629
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert (RateColumn('/s', False, False).render(
        Progress(total=100, initial=0)) == Text('? /s', style='progress.data.speed')
            )
    assert (RateColumn('/s', False, False).render(
        Progress(total=100, initial=10)) == Text('10 /s', style='progress.data.speed')
            )
    assert (RateColumn('/s', False).render(
        Progress(total=100000, initial=30)) == Text('0.03 K/s', style='progress.data.speed')
            )
    assert (RateColumn('/s', True).render(
        Progress(total=1000000, initial=20)) == Text('2.0 K/s', style='progress.data.speed')
            )

# Generated at 2022-06-24 10:33:48.128439
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    task = Progress()
    task.total = 1024
    task.completed = 0
    assert column.render(task).text == "0/1.0 K"

    task.total = 1024
    task.completed = 524
    assert column.render(task).text == "0.5/1.0 K"

    task.total = 1024
    task.completed = 1024
    assert column.render(task).text == "1.0/1.0 K"



# Generated at 2022-06-24 10:33:51.417836
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    class Task:
        def __init__(self):
            self.completed = 0
            self.total = 0
    task = Task()
    column = FractionColumn()
    column.render(task)
    assert True

# Generated at 2022-06-24 10:33:56.295302
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress

    with Progress() as progress:
        task_id = progress.add_task("Test", total=2)
        for i in tqdm_rich(range(10), leave=True, unit="s", bar_format="[%s] %e %r"):
            sleep(0.01)
            progress.reset(total=2)

# Generated at 2022-06-24 10:34:02.229255
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn().render(None) == Text('? /s', style='progress.data.speed')
    assert RateColumn(unit='B').render(None) == Text('? B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True).render(None) == Text('? B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True, unit_divisor=1024).render(None) == Text('? B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True, unit_divisor=1000).render(None) == Text('? B/s', style='progress.data.speed')

# Generated at 2022-06-24 10:34:06.893242
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    time.sleep(1)
    for i in tqdm_rich(range(100)):
        time.sleep(0.1)
        tqdm.write(str(i))

if __name__ == '__main__':
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:34:09.000363
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test minimalistic tqdm_rich constructor."""
    _ = tqdm_rich(total=1000)

# Generated at 2022-06-24 10:34:10.561499
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-24 10:34:12.256064
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress()).text == "0/0 "



# Generated at 2022-06-24 10:34:16.321273
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.rich.trange`.
    """
    from random import random
    from time import sleep
    try:
        with tqdm_rich(total=10) as t:
            for i in range(10):
                sleep(random() / 2)
                t.update()
    except (AssertionError, AttributeError):
        pass

# Generated at 2022-06-24 10:34:18.031339
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    print("Test constructor of class FractionColumn")
    assert FractionColumn()



# Generated at 2022-06-24 10:34:20.118275
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_progress_column = FractionColumn()


# Generated at 2022-06-24 10:34:22.158241
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn()) == '?'
    assert str(RateColumn(unit="B")) == '? B/s'

# Generated at 2022-06-24 10:34:24.578992
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    p = tqdm_rich(range(5))
    for i in p: pass
    p.close()



# Generated at 2022-06-24 10:34:30.719250
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = trrange(10)
    task.update()
    task.speed = 0.1
    assert RateColumn().render(task) == Text(f"0.1 /s", style="progress.data.speed")
    assert RateColumn().render(task) == Text(f"0.1 /s", style="progress.data.speed")
    assert RateColumn(unit=" ").render(task) == Text(f"0.1  /s", style="progress.data.speed")



# Generated at 2022-06-24 10:34:36.603224
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    RateColumn_test = RateColumn(unit_scale=False)
    assert RateColumn_test.render(Task(speed=100)) == Text("100.0 /s", style="progress.data.speed")
    RateColumn_test = RateColumn(unit_scale=True)
    assert RateColumn_test.render(Task(speed=100)) == Text("100.0 K/s", style="progress.data.speed")
    RateColumn_test = RateColumn(unit_scale=True, unit="/s")
    assert RateColumn_test.render(Task(speed=100)) == Text("100.0 K/s", style="progress.data.speed")
    RateColumn_test = RateColumn(unit_scale=True, unit="/s")

# Generated at 2022-06-24 10:34:42.138651
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import time
    with tqdm_rich(total=10) as pbar:
        for i in _range(10):
            time.sleep(1)
            pbar.update(1)
        assert pbar.n == 10
        assert pbar.total == 10
        assert pbar.format_dict['unit'] == '/s'
        assert pbar.format_dict['unit_scale'] is True



# Generated at 2022-06-24 10:34:43.842803
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .std import tqdm_rich_test
    tqdm_rich_test(tqdm_rich)

# Generated at 2022-06-24 10:34:46.608172
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(100))
    t.close()
    t.clear()

# Generated at 2022-06-24 10:34:51.741729
# Unit test for constructor of class RateColumn
def test_RateColumn():
    with tqdm(total=100, unit="iB", unit_scale=True, unit_divisor=1024,
              miniters=1) as t:
        for i in t:
            t.update()
            pass

if __name__ == "__main__":
    test_RateColumn()

# Generated at 2022-06-24 10:35:00.813938
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    method = RateColumn.render
    method_name = 'RateColumn.render()'
    # Config
    prefix = 'prefix-'
    kwargs = {}
    kwargs_parent = {}

    # Test 1
    kwargs_test = kwargs_parent.copy()
    kwargs_test.update(kwargs)
    obj = RateColumn()
    task = obj
    task.speed = None
    kwargs_test['task'] = task
    expected = 'prefix-? /s'
    result = method(obj, **kwargs_test)
    if not (expected == result):
        raise ValueError(f'{method_name} Task 1')
    # Test 2
    kwargs_test = kwargs_parent.copy()
    kwargs_test.update(kwargs)
    obj

# Generated at 2022-06-24 10:35:06.873174
# Unit test for function trange
def test_trange():
    "test trange function"
    # with trange(10) as t:
    #     for i in t:
    #         pass
    # t.write("\n")
    assert len(list(trange(10))) == 10
    assert len(list(trange(0))) == 0
    assert len(list(trange(10, 0, -1))) == 10
    assert len(list(trange(10, 0, -1, leave=False))) == 10

# Generated at 2022-06-24 10:35:12.064577
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(disable=True, leave=True)
    t.update(1)
    t.update()
    t.update(2)
    t.update()
    t.n = 3
    t.refresh()
    t.close()

# Generated at 2022-06-24 10:35:12.561526
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass

# Generated at 2022-06-24 10:35:13.585333
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.unit_scale == False
    assert fc.unit_divisor == 1000

# Generated at 2022-06-24 10:35:22.817695
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(**{'desc': 'test', 'total': 100, 'position': 1, 'n': 10,
                       'bar_format': '{percentage}|{bar}| {remaining}', 'sma_window': 1,
                       'disable': False, 'mininterval': 0.1, 'maxinterval': 10.0, 'unit': 'it',
                       'unit_scale': False, 'unit_divisor': 1000,
                       'gui': True, 'leave': False})
    task.speed = 100
    assert (RateColumn('it', unit_scale=False, unit_divisor=1000).render(task).string == '100 it/s')
    task.speed = 1000

# Generated at 2022-06-24 10:35:26.471191
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import rich.console
    console = rich.console.Console(width=80)
    console.print("\r{}".format(" "*80), end="")