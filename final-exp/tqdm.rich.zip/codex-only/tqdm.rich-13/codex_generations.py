

# Generated at 2022-06-24 10:25:35.835427
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="/s", unit_scale="True", unit_divisor=1000) is not None
    assert RateColumn(unit="/s", unit_scale="False", unit_divisor=1000) is not None



# Generated at 2022-06-24 10:25:41.747104
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .std import tqdm
    from .std import trange

    desc = "Test tqdm_rich.display()"
    for _ in tqdm(trange(1), desc=desc, disable=True):
        pass


if __name__ == "__main__":  # pragma: no cover
    from .std import tqdm

    def test_trange():
        for i in trange(10):
            print(i)

    test_trange()
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:25:47.300364
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 10000
    unit = "B"
    suffix_expected = "K"
    unit_expected = 1000

    RateColumn_test = RateColumn(unit=unit, unit_scale=True, unit_divisor=1000)
    string_returned = RateColumn_test.render({'speed': speed})
    string = str(string_returned)
    assert string.find(suffix_expected) != -1 and string.find(unit) != -1
    string = string.replace(suffix_expected, '').replace(unit, '').strip()
    assert string == str(speed/unit_expected)


# Generated at 2022-06-24 10:25:50.845949
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn("")
    assert column.unit == ""
    column = RateColumn("B")
    assert column.unit == "B"



# Generated at 2022-06-24 10:25:57.878003
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for unit in [False, True]:
        t = tqdm(
            range(1000),
            smoothing=0,
            total=1000,
            unit_scale=unit,
            miniters=1,
            mininterval=0
        )
        t.update(100)
        t.clear()
        t.update(200)
        assert t.n == 300
        t.clear()
        t.update(700)
        assert t.n == 1000
        t.clear()
        t.update(1000)
        assert t.n == 1000
        t.close()

# Generated at 2022-06-24 10:26:00.776153
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import random
    with tqdm_rich(total=10) as bar:
        bar.reset(total=20)
        for _ in bar:
            bar.n = random.randint(0, 3)

# Generated at 2022-06-24 10:26:03.932128
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .gui import tnrange
    for _ in trange(7, desc='test', leave=True):
        pass
    for _ in tnrange(4, desc='test', leave=True):
        pass

# Generated at 2022-06-24 10:26:08.840074
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.unit_scale is False
    assert fc.unit_divisor == 1000
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.unit_scale is True
    assert fc.unit_divisor == 1024


# Generated at 2022-06-24 10:26:10.326472
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate = RateColumn()
    assert callable(rate.render)


# Generated at 2022-06-24 10:26:18.246628
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(1) \
        == Text('1 B/s', style='progress.data.speed')
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(100) \
        == Text('100 B/s', style='progress.data.speed')
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(999) \
        == Text('999 B/s', style='progress.data.speed')
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(1000) \
        == Text('1.0 KB/s', style='progress.data.speed')

# Generated at 2022-06-24 10:26:24.618237
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import time as sleep
    d = tqdm(total=2, dynamic_ncols=True)
    sleep.sleep(1)
    d.update(1)
    if sys.stderr.isatty():
        assert (d.format_dict['l_bar'] != d.format_dict['bar'])
    d.close()

# Generated at 2022-06-24 10:26:28.993857
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.unit_scale == False
    assert fc.unit_divisor == 1000


if __name__ == "__main__":  # pragma: no cover
    for i in tqdm_rich(range(1000)):
        pass

# Generated at 2022-06-24 10:26:34.386109
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(Progress()) == "0/0 "
    assert FractionColumn(unit_scale=False).render(Progress()) == "0/0 "
    assert FractionColumn().render(Progress(completed=500, total=2000)) == "500/2000 "
    assert FractionColumn(unit_scale=True).render(Progress(completed=500, total=2000)) == "0.5/2.0 K"

# Generated at 2022-06-24 10:26:41.560652
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    unit_scale = False
    unit_divisor = 1000
    completed = 0
    total = 1024
    expected_output = Text(
        f"0.0/1.0 ", style="progress.download")
    # unit_scale = False
    fraction = FractionColumn(unit_scale, unit_divisor)
    class mockProgress:
        def __init__(self,completed,total):
            self.completed = completed
            self.total = total
    mock_progress = mockProgress(completed,total)
    mock_task = mock_progress
    actual_output = fraction.render(mock_task)
    assert actual_output == expected_output
    # unit_scale = True
    unit_scale = True
    unit_divisor = 1000
    completed = 0

# Generated at 2022-06-24 10:26:46.793558
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tgrange
    from .std import tqdm

    expected_val = 20

    with tgrange(expected_val) as progressbar:
        progressbar.reset(total=expected_val)
        assert progressbar.total == expected_val

    with tqdm(total=expected_val) as progressbar:
        progressbar.reset(total=expected_val)
        assert progressbar.total == expected_val

# Generated at 2022-06-24 10:26:57.358107
# Unit test for constructor of class RateColumn
def test_RateColumn():
    task_1 = {'speed': 1}
    task_2 = {'speed': 100}
    task_3 = {'speed': 1000}
    task_4 = {'speed': 1000000}
    rate_col_1 = RateColumn()
    rate_col_2 = RateColumn(unit_scale=True)
    print(rate_col_1.render(task_1))
    print(rate_col_2.render(task_1))
    print(rate_col_1.render(task_2))
    print(rate_col_2.render(task_2))
    print(rate_col_1.render(task_3))
    print(rate_col_2.render(task_3))
    print(rate_col_1.render(task_4))

# Generated at 2022-06-24 10:27:07.703340
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test FractionColumn."""
    from .utils import _test_reset
    try:
        progress = Progress(
            Text("Rendering: ", style="class:progress-header"),
            FractionColumn(),
            BarColumn(),
        )
        progress.__enter__()
        task_id = progress.add_task("Render", start=0, total=100)
        progress.update(task_id, completed=10)
        progress.update(task_id, completed=100)
        progress.update(task_id, completed=20)
        _test_reset(progress)
        progress.__exit__(None, None, None)
    except (Exception, KeyboardInterrupt):
        progress.__exit__(*sys.exc_info())
        raise

# Generated at 2022-06-24 10:27:14.667960
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.panel import Panel
    from rich.progress import Progress
    from rich.text import Text
    from rich.table import Table
    from rich.box import BOX_HEAVY_UP

    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=True),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=True), "]"
    )
    progress.__enter__()

    task_id = progress.add_task("Progress", total=3, completed=1)
    progress.update(task_id, speed=1000, completed=2)

    progress.update(task_id, speed=2000, completed=3)

# Generated at 2022-06-24 10:27:21.729485
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.progress import Progress

    t = tqdm(total=4096, disable=False, desc="Test")
    assert t._prog.tasks["root"].total == 4096
    assert t._prog.tasks["root"]._description == "Test"
    assert t._prog.tasks["root"].completed == 0
    assert t._prog.tasks["root"]._parent is t._prog.root
    assert isinstance(t._prog, Progress)
    t.close()



# Generated at 2022-06-24 10:27:31.720283
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = trange(0, 5)
    assert isinstance(progress._prog, Progress)
    assert len(progress._prog.columns) == 4

    for column in progress._prog.columns:
        assert isinstance(column, ProgressColumn)

    assert isinstance(progress._prog.columns[2], FractionColumn)

# Generated at 2022-06-24 10:27:38.641235
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import rich
    import rich.progress as progress

    output = progress.Console()
    result = FractionColumn()
    assert result._unit_scale == False
    assert result._unit == ""
    assert result._unit_divisor == 1000
    assert result._rich_console == output
    assert result.rate_unit == "s"
    assert result.update_interval == 0.1
    assert result.task == None


# Generated at 2022-06-24 10:27:40.177564
# Unit test for function trange
def test_trange():
    for _ in trange(1, 9, 2):
        pass

# Generated at 2022-06-24 10:27:44.118944
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    d = {'task': {'completed': '0.1', 'total': '20'}}
    assert column.render(d['task']) == Text("0.1/20 ", style="progress.download")

# Generated at 2022-06-24 10:27:48.997561
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tests import common
    pbar = tqdm_rich(total=common.total,
                     desc=common.desc,
                     bar_format=common.bar_format)
    for _ in pbar:
        pbar.update()
    pbar.close()

# Generated at 2022-06-24 10:27:50.423862
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(None).text == '0/0'

# Generated at 2022-06-24 10:27:52.560023
# Unit test for function trange
def test_trange():
    """Test if trange works as expected."""
    with tqdm(total=100) as prg:
        for i in trange(20):
            prg.update()
        for i in trange(20, 100, 3):
            prg.update()



# Generated at 2022-06-24 10:27:58.645142
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from io import StringIO
    from rich.console import Console
    from rich.progress import BarColumn, Text, TimeRemainingColumn

    console = Console(file=StringIO())
    progress = Progress(
        BarColumn(),
        Text("{task.description}"),
        TimeRemainingColumn()
    )
    console.print(progress)

    with progress.task("Label") as task:
        task.update(0.5, "Label")

# Generated at 2022-06-24 10:28:06.506803
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Task
    from rich.progress import TaskID
    from rich.progress import get_all_tasks
    try:
        tqdm_rich(0).close()
    except Exception:
        assert False

    try:
        task = Task(1, range(3))
        task_id = TaskID()
        task.add_track(task_id)
        assert (len(get_all_tasks()) == 1)
        tqdm_rich(0).close()
        assert (len(get_all_tasks()) == 0)
    except Exception:
        assert False



# Generated at 2022-06-24 10:28:13.537443
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test example of tqdm_rich."""
    try:
        import rich.console
    except ImportError:
        pass
    else:
        # console needs to be set up to render rich objects
        console = rich.console.Console()
        with tqdm_rich(total=100) as t:
            for i in range(100):
                t.update()
                t.set_description(f"Iteration {i}")



# Generated at 2022-06-24 10:28:21.112430
# Unit test for function trange
def test_trange():  # pragma: no cover
    import sys
    import time

    n = 100
    try:
        import numpy as np
    except ImportError:
        pass
    else:
        n = np.int64(n)

    # Check dynamic range
    range_iterator = trange(1, n, 1, leave=False)
    for _ in range_iterator:
        range_iterator.set_description("myrange")
        if range_iterator.total - range_iterator.n <= 5:
            range_iterator.total = n * 10
        time.sleep(0.01)  # sleeping is needed to test dynamic_ncols
    print("\n")

    with trange(n, leave=None) as range_iterator:
        for _ in range_iterator:
            pass
    print("\n")


# Generated at 2022-06-24 10:28:27.931572
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    temp = FractionColumn(unit_scale = False, unit_divisor = 1000)
    assert temp.render({'completed':1,'total':1}) == Text('1.0/1.0', style = "progress.download")
    assert temp.render({'completed':10,'total':1}) == Text('10.0/1.0', style = "progress.download")
    assert temp.render({'completed':1,'total':10}) == Text('1.0/10.0', style = "progress.download")
    assert temp.render({'completed':10000,'total':50000}) == Text('10.0/50.0', style = "progress.download")

# Generated at 2022-06-24 10:28:30.336783
# Unit test for function trange
def test_trange():
    for _ in trange(10, desc='TEST', leave=True):
        pass



# Generated at 2022-06-24 10:28:33.104578
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test method clear of class tqdm_rich."""
    # tqdm_rich should not raise exception on method clear
    tqdm_rich.clear()

# Generated at 2022-06-24 10:28:44.519078
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import io
    import unittest
    from unittest.mock import MagicMock

    tqdm_rich_1 = tqdm_rich(disable=True)
    assert tqdm_rich_1.display(_, __) is None

    tqdm_rich_2 = tqdm_rich(disable=False)
    tqdm_rich_2.write = MagicMock(wraps=tqdm_rich_2.write)

    # Save output.
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    # Test [smoothing=N] error message.

# Generated at 2022-06-24 10:28:49.759076
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import math
    import os
    import sys
    import time

    # Redirect all stdout to /dev/null
    f = open(os.devnull, 'w')
    sys.stdout = f

    with tqdm_rich(range(10)) as bar:
        for i in bar:
            time.sleep(0.1)
            bar.set_description("Performing %d operations" % i)
            bar.set_postfix(loss=i ** 2 / 2)
            bar.update()

    # Reset stdout
    sys.stdout = sys.__stdout__



# Generated at 2022-06-24 10:28:51.954307
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    test_bar = tqdm_rich(total=2)
    test_bar.update(1)
    test_bar.clear()

# Generated at 2022-06-24 10:29:02.788308
# Unit test for function trange
def test_trange():
    """Test function."""
    # pylint: disable=protected-access

# Generated at 2022-06-24 10:29:06.120360
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    rate_column = RateColumn('/s')
    rate_column = RateColumn(unit_scale=True)
    rate_column = RateColumn(unit_divisor=1000)


# Generated at 2022-06-24 10:29:07.400785
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass



# Generated at 2022-06-24 10:29:11.957342
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        from rich.progress import Progress
        import rich.traceback
    except ImportError:
        return
    rich.traceback.install()
    progress = Progress()
    progress.add_task("", total=10)
    with tqdm_rich(total=10) as t:
        for _ in range(10):
            t.update()
    progress.__exit__(None, None, None)

test_tqdm_rich_display()

# Generated at 2022-06-24 10:29:16.965865
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm_rich(total=100) as t:
        time.sleep(0.25)
        t.display()
        time.sleep(0.25)
        t.display()
        time.sleep(0.25)
        t.display()



# Generated at 2022-06-24 10:29:21.295125
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .std import tqdm
    from .utils import _range
    from rich.progress import Progress
    import contextlib
    with contextlib.redirect_stdout(None):
        for i in tqdm(_range(100), disable=False):
            pass
    assert not Progress.__enter__

# Generated at 2022-06-24 10:29:27.573597
# Unit test for function trange
def test_trange():
    """Test for `tqdm.rich.trange`"""
    import os
    import sys
    import time

    for i in trange(10, leave=False, desc="1 loop"):
        time.sleep(0.1)
    print("\n")
    for i in trange(10, leave=True, desc="2 loop"):
        time.sleep(0.1)
    print("\n")
    for i in trange(10, desc="3 loop"):
        time.sleep(0.1)

    with trange(10, desc="4 loop") as t:
        for i in t:
            time.sleep(0.1)
    print("\n")

# Generated at 2022-06-24 10:29:30.796908
# Unit test for function trange
def test_trange():  # pragma: no cover
    from time import sleep
    for i in trange(5, desc="prefix"):
        assert i in range(5)
        sleep(0.01)

# Generated at 2022-06-24 10:29:38.385396
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest
    class Test(unittest.TestCase):
        def test_render(self):
            speed = 1.0
            unit = ""
            unit_scale = False
            unit_divisor = 1000
            rate = RateColumn(unit, unit_scale, unit_divisor)
            task = rate.render(speed)
            self.assertEqual(str(task), "1.0 /s")

    unittest.main(exit=False)


if __name__ == "__main__":
    test_RateColumn_render()

# Generated at 2022-06-24 10:29:43.424846
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    obj = FractionColumn()
    assert obj.render({'completed': 0, 'total': 0}) == Text('0.0/0.0 ', style='progress.download')
    assert obj.render({'completed': 0, 'total': 1}) == Text('0.0/1.0 ', style='progress.download')


# Generated at 2022-06-24 10:29:49.394860
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    This test is for method reset of class tqdm_rich.
    """
    from tqdm.auto import trange

    with trange(total=None, desc='Test trange!') as r:
        assert r.total is None
        r.reset(total=10)
        assert r.total == 10
        assert r._prog.total == 10
        r.reset(total=None)
        assert r.total is None
        assert r._prog.total is None



# Generated at 2022-06-24 10:29:51.608597
# Unit test for function trange
def test_trange():
    """Test for function trange."""
    list(trange(3))

# Generated at 2022-06-24 10:30:01.166263
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import TaskID
    from rich.traceback import install
    install()
    initial_total = 3
    initial_n = 2
    t = tqdm_rich(total=initial_total)
    t.n = initial_n
    assert t.total == initial_total
    assert t.n == initial_n
    assert t._task_id == TaskID(1)
    assert t._prog.completed == initial_n
    assert t._prog.total == initial_total
    new_total = 7
    t.reset(total=new_total)
    assert t.total == new_total
    assert t.n == 0
    assert t._task_id == TaskID(1)
    assert t._prog.completed == 0
    assert t._prog.total == new_total

# Generated at 2022-06-24 10:30:08.356189
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        from tqdm.autonotebook import tqdm
    except ImportError:
        pass
    # Test adding several projects in the bar
    pbar = tqdm(total=3)

    # Test generating output
    pbar.update(1)
    pbar.set_description("test")
    pbar.update(1)

    # Test clearing output
    pbar.clear()

    # Test closing the bar
    pbar.close()

# Generated at 2022-06-24 10:30:10.554562
# Unit test for function trange
def test_trange():
    """Test whether trange works"""
    for _ in trange(1):
        return True
    # Check that trange uses xrange on Python2
    assert str(type(trange(1))) != "<class 'range'>"

# Generated at 2022-06-24 10:30:20.871269
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """
    Unit test for constructor of class `tqdm_rich`
    """
    from rich.console import Console
    from rich.progress import TaskID
    console = Console()
    console.print("[green]Test a tqdm_rich object!")
    rng = range(3)
    t = tqdm_rich(rng)
    isinstance(t, tqdm_rich)
    isinstance(t._prog, Progress)
    isinstance(t._task_id, TaskID)
    t = tqdm_rich(rng, desc='Cool', bar_format='{bar}')
    t.desc


if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-24 10:30:31.428065
# Unit test for constructor of class RateColumn
def test_RateColumn():
    x = RateColumn(unit_scale=True)
    assert x.render(TqdmType(speed=1)) == Text("1 B/s", style="progress.data.speed")
    assert x.render(TqdmType(speed=1000)) == Text("1 K/s", style="progress.data.speed")
    assert x.render(TqdmType(speed=100000)) == Text("100 K/s", style="progress.data.speed")
    assert x.render(TqdmType(speed=1000000)) == Text("1 M/s", style="progress.data.speed")
    assert x.render(TqdmType(speed=1000000000)) == Text("1 G/s", style="progress.data.speed")

# Generated at 2022-06-24 10:30:34.689716
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        import rich
    except ImportError:
        return
    for _ in tqdm([1]):
        pass

# Generated at 2022-06-24 10:30:45.557998
# Unit test for function trange
def test_trange():
    """Unit tests for all functions in `rich.progress`."""
    from time import sleep
    # Using trange, without optional arguments.
    with trange(100) as t:
        # Update the progress bar.
        for i in t:
            sleep(0.01)
            t.display()
    # Using trange, with optional arguments.
    for i in trange(20, desc='1st loop'):
        for j in trange(100, desc='2nd loop', leave=False, total=200):
            for k in trange(300, desc='3rd loop', leave=False,
                            total=400, unit_scale=True):
                sleep(0.01)
            assert k == 300
        assert j == 100
    assert i == 20

# Generated at 2022-06-24 10:30:48.385935
# Unit test for function trange
def test_trange():
    """Test trange function."""
    with trange(10) as bar:
        for _ in bar:
            pass
        bar.reset()
        for _ in bar:
            pass
        bar.reset()
        for _ in bar:
            pass

# Generated at 2022-06-24 10:30:52.313229
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm_rich(total=100, desc="Test tqdm_rich") as pbar:
        for i in range(100):
            pbar.update(1)

# Generated at 2022-06-24 10:31:00.572676
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os
    import sys
    if sys.version_info >= (3, 5):
        return  # does not work in python 3.5

    import pytest
    from .auto import tqdm as auto_tqdm
    from .gui import tqdm as gui_tqdm

    test_str = "show me the progress!"
    with pytest.raises(AttributeError, match="object has no attribute '_task_id'"):
        with tqdm_rich(test_str, disable=True) as pbar:
            pbar.display()
    with tqdm_rich(test_str, disable=False) as pbar:
        pbar.display()


if __name__ == "__main__":
    test_tqdm_rich_display()

# Generated at 2022-06-24 10:31:03.747867
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch, Mock
    with patch('tqdm.rich._tqdm_rich.Progress') as mockProgress:
        mockProgress.return_value.update = Mock()
        with tqdm_rich(total=10, ncols=60) as t:
            t.display()
        assert mockProgress.return_value.update.called

# Generated at 2022-06-24 10:31:13.731759
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tc = RateColumn()
    assert tc.render(None) == Text(f"? /s", style="progress.data.speed")

    tc = RateColumn(unit="i")
    assert tc.render(None) == Text(f"? i/s", style="progress.data.speed")

    tc = RateColumn(unit="i", unit_scale=True, unit_divisor=1024)
    assert tc.render(None) == Text(f"? i/s", style="progress.data.speed")

    tc = RateColumn(unit="i", unit_scale=False, unit_divisor=1024)
    assert tc.render(None) == Text(f"? i/s", style="progress.data.speed")

    tc = RateColumn(unit="", unit_scale=False, unit_divisor=1024)

# Generated at 2022-06-24 10:31:22.656590
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    t = tqdm_rich(total=1000)
    t.update(1000)
    if sys.version_info < (3,):
        assert t.n == 1000
    else:
        assert t.n == 1001
        # NOTE:
        # t.n == 1001 because:
        # t.n is an int and not a long
        # t.update(1000) cause t.n to increment by 1001 instead of 1000
        # This leads to a failure in _prog.__exit__(None, None, None)



# Generated at 2022-06-24 10:31:26.654031
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn(unit_scale=True)
    task = Progress()
    task.completed = 1
    task.total = 100
    assert fraction.render(task) == Text("0.0/1.0 K", style="progress.download")


# Generated at 2022-06-24 10:31:28.358161
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Class FractionColumn
        method render()
    """
    assert FractionColumn.render(1, 1) is None


# Generated at 2022-06-24 10:31:31.675984
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for i in tqdm(range(10000), gui=True, leave=True):
        assert i == i
    float().is_integer()

# Generated at 2022-06-24 10:31:34.602257
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    frac = FractionColumn()
    assert [i for i in dir(frac) if not i.startswith('__')] == ['render']


# Generated at 2022-06-24 10:31:40.791533
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    test_FractionColumn_render
    """
    column = FractionColumn()
    assert column.render(Task(completed=1, total=1)) == Text(
        "1.0/1.0 ", style="progress.download")
    assert column.render(Task(completed=999, total=1024)) == Text(
        "999.0/1,024.0 ", style="progress.download")



# Generated at 2022-06-24 10:31:42.943021
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=11) as pbar:
        pbar.reset(total=12)



# Generated at 2022-06-24 10:31:45.137923
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = FractionColumn()
    progress.render([])
    # assert False, 'Test not implemented'

# Generated at 2022-06-24 10:31:48.994481
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
    try:
        t.get_lock()
    except Exception:
        raise Exception("Calling close() does not render tqdm to completed!")



# Generated at 2022-06-24 10:32:00.533907
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="", unit_scale=False, unit_divisor=1)
    assert rate_column.render(progress.ProgressTask(completed=10, total=100, speed=1)) == Text("1 /s", style="progress.data.speed")
    assert rate_column.render(progress.ProgressTask(completed=10, total=100, speed=2)) == Text("2 /s", style="progress.data.speed")
    rate_column = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(progress.ProgressTask(completed=10, total=100, speed=1)) == Text("1 /s", style="progress.data.speed")

# Generated at 2022-06-24 10:32:02.986912
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    t = tqdm_rich(total=1000, desc="foo")
    assert t.total == 1000
    assert t.desc == 'foo'

# Generated at 2022-06-24 10:32:04.077252
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass


# Generated at 2022-06-24 10:32:07.306593
# Unit test for function trange
def test_trange():
    with trange(4) as t:
        for i in t:
            if i == 3:
                break

# Generated at 2022-06-24 10:32:08.547311
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass
    # TODO: implement

# Generated at 2022-06-24 10:32:12.795953
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test function for method clear of class tqdm_rich"""
    with tqdm(total=2) as pbar:
        pbar.update()
        pbar.clear()
        pbar.update()
        pbar.clear()

# Generated at 2022-06-24 10:32:21.512462
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import time
    import random
    sys.modules.pop("tqdm.rich", None)
    rich = __import__("tqdm.rich")
    tqdm = rich.tqdm
    sys.modules["tqdm.rich"] = rich
    list(tqdm(range(10000), desc=''))
    tqdml = tqdm(range(1, 10))
    for i in tqdml:
        time.sleep(random.randrange(0, 1001) / 1000.0)
        tqdml.display()
    tqdml.close()
    sys.modules["tqdm.rich"] = rich

# Generated at 2022-06-24 10:32:24.649093
# Unit test for constructor of class FractionColumn
def test_FractionColumn():  # pragma: no cover
    task = std_tqdm(total=5)
    task.update(5)
    FractionColumn().render(task)

# Generated at 2022-06-24 10:32:34.053960
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from shutil import get_terminal_size
    from rich.console import Console
    from rich.table import Table

    save = {'disable': None, 'dynamic_ncols': None}

# Generated at 2022-06-24 10:32:38.869056
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert column.unit_scale == False
    assert column.unit_divisor == 1000
    assert column.render(None).text == "0.0/0.0 "

# Generated at 2022-06-24 10:32:47.344529
# Unit test for function trange
def test_trange():
    """Simple unit tests for `trange`."""
    from time import sleep

    @tqdm_rich
    def work(name, seconds, unit='ms'):
        sleep(seconds / 1000)

    work(name='test1', seconds=100, unit='ms')
    for _ in trange(3, desc='test2'):  # Check nested
        for _ in trange(3, desc='test3'):
            pass
    for _ in trange(3, desc='test4'):  # Check reset
        work(name='test5', seconds=100, unit='ms')
    with tqdm_rich(desc='test6') as pbar:  # Check context
        pass
    with tqdm_rich(desc='test7') as pbar:  # Check context
        raise Exception('Test 8')
    #

# Generated at 2022-06-24 10:32:51.972898
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .gui import tgrange
    import time
    from unittest import TestCase

    class Test(TestCase):
        def test_method_close(self):
            for i in tgrange(4):
                time.sleep(0.1)
    test = Test()
    test.test_method_close()

# Generated at 2022-06-24 10:32:56.508051
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    pbar = tqdm_rich(total=20)
    assert pbar.disable == False
    assert pbar.total == 20
    assert pbar.n == 0
    pbar.close()
    assert pbar.disable == False
    assert pbar.total == 20
    assert pbar.n == 20


# Generated at 2022-06-24 10:33:02.107412
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column, _ = RateColumn().render(None)
    assert column.text == "? "
    column, _ = RateColumn(unit="bits").render(None)
    assert column.text == "? bits"
    column, _ = RateColumn(unit_scale=False).render(None)
    assert column.text == "? "
    column, _ = RateColumn(unit_scale=True).render(None)
    assert column.text == "? "

# Generated at 2022-06-24 10:33:04.293826
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn()) == "<FractionColumn unit_scale=False>"
    assert str(FractionColumn(unit_scale=True)) == "<FractionColumn unit_scale=True>"


# Generated at 2022-06-24 10:33:10.492372
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Ensure that tqdm.gui is not set by default
    assert not getattr(tqdm, 'gui')
    # Ensure that tqdm does not accept gui=True
    assert getattr(tqdm, 'gui', True) is True
    # Ensure that tqdm_rich.gui is set
    assert getattr(tqdm_rich, 'gui', True) is True

# Generated at 2022-06-24 10:33:12.717491
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        with tqdm(total=1) as t:
            t.clear()
    except AttributeError:
        raise AttributeError("Method clear not implemented of tqdm_rich")

# Generated at 2022-06-24 10:33:16.201485
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    tqdm_rich_obj= tqdm_rich(range(10))
    for i in tqdm_rich_obj:
        time.sleep(0.1)

# Generated at 2022-06-24 10:33:25.279057
# Unit test for function trange
def test_trange():
    """Simple unit tests for trange()"""
    tr = trange(10)
    assert isinstance(tr, tqdm_rich)
    assert len(tr) == 10
    assert list(tr) == list(tqdm_rich(range(10)))
    assert list(tr) == list(tqdm_rich(range(10)))

    tr = trange(10, 20)
    assert len(tr) == 10
    assert list(tr) == list(tqdm_rich(range(10, 20)))
    assert list(tr) == list(tqdm_rich(range(10, 20)))

    tr = trange(10, 20, 2)
    assert len(tr) == 5
    assert list(tr) == list(tqdm_rich(range(10, 20, 2)))
    assert list(tr)

# Generated at 2022-06-24 10:33:26.909796
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-24 10:33:28.086504
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:33:38.637406
# Unit test for function trange
def test_trange():  # pragma: no cover
    from time import sleep
    import re
    from threading import Thread
    from rich.console import Console
    from rich.table import Table

    console = Console()

    # Test threading
    for i in trange(10, desc="Test Threading"):
        sleep(.2)

    # Test nested
    for i in trange(10):
        for j in trange(5):
            sleep(.1)

    # Test manual iteration
    pbar = trange(10)
    for _ in pbar:
        sleep(.2)

    # Test manual iteration (2)
    pbar = trange(1, 10)
    for _ in pbar:
        sleep(.2)

    # Test manual iteration (3)
    pbar = trange(1, 10, 2)
   

# Generated at 2022-06-24 10:33:49.884522
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn(unit_scale=False, unit_divisor=1000)
    """
    Check if completed and total is rendered properly.
    """

    completed = 100
    total = 500
    assert fraction.render(Progress(task={'completed':completed, 'total':total})) == '0.2/1.0'

    completed = 1000
    total = 2000
    assert fraction.render(Progress(task={'completed':completed, 'total':total})) == '0.5/2.0'

    completed = 1000
    total = 10000
    assert fraction.render(Progress(task={'completed':completed, 'total':total})) == '0.1/10.0'
    
    """
    Check if file size is shown properly.
    """
    completed = 1000
    total = 5000


# Generated at 2022-06-24 10:33:51.621422
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    pass


# Generated at 2022-06-24 10:33:54.533121
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.progress import TaskID
    task = TaskID()
    task.speed = 500
    task.completed = 500
    task.total = 1000
    column = RateColumn()
    column.render(task)

# Generated at 2022-06-24 10:33:57.243317
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Check if the method is called without error
    tqdm_rich().clear()
    tqdm_rich().clear(nolock=True)
    tqdm_rich().clear(nolock=False)

# Generated at 2022-06-24 10:34:00.174702
# Unit test for constructor of class RateColumn
def test_RateColumn():
    class mytask(object):
        def __init__(self):
            self.speed = 12345
    rc = RateColumn()
    assert rc.render(mytask()) == Text('12.3 K/s', style='progress.data.speed')

# Generated at 2022-06-24 10:34:10.881597
# Unit test for method display of class tqdm_rich

# Generated at 2022-06-24 10:34:18.888713
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Unit test for method render of class FractionColumn
    fcUnitTest = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fcUnitTest.render(fcUnitTest) == '101.0/123.0 k'
    assert fcUnitTest.render(fcUnitTest) == '1.0/1.0 '
    fcUnitTest = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fcUnitTest.render(fcUnitTest) == '101.0/123.0 '
    fcUnitTest = FractionColumn(unit_scale=False, unit_divisor=1)
    assert fcUnitTest.render(fcUnitTest) == '101.0/123.0 '


# Generated at 2022-06-24 10:34:22.050286
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .utils import FormatMixin
    from .std import tqdm as tqdm_standard
    for t in trange(2):
        assert isinstance(t, tqdm_standard)
    d = tqdm_rich(total=10)
    assert isinstance(d, FormatMixin)
    assert hasattr(d, '_prog')
    assert isinstance(d._prog, Progress)
    d.display()
    d.close()

# Generated at 2022-06-24 10:34:39.839277
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Default settings
    fraction_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert fraction_column.render(Progress([], completed=999, total=10000)) == Text("0.1/10 ", style="progress.download")
    # Not unit_scale
    assert fraction_column.render(Progress([], completed=999, total=1000)) == Text("1/1 ", style="progress.download")
    assert fraction_column.render(Progress([], completed=1, total=10)) == Text("0.1/1 ", style="progress.download")
    assert fraction_column.render(Progress([], completed=1, total=999999)) == Text("0.001/1 ", style="progress.download")

# Generated at 2022-06-24 10:34:44.660136
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # In case of total=None and total=[1, 2], should not raise
    for total in [None, [1, 2]]:
        desc = "test test"
        t = tqdm_rich(total=total, desc=desc)
        t.reset(total=total)
        t.close()
        assert t.desc == desc, "desc is not set correctly"

# Generated at 2022-06-24 10:34:48.426870
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Check that calling `tqdm.clear` works as expected"""
    x = tqdm_rich(total=100)
    x.close()
    x.reset()

# Generated at 2022-06-24 10:34:55.329568
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test to check if close() method properly restores the terminal state
    """
    # Get current terminal width, set it to 35, create and close progress bar,
    # and then restore the terminal width
    from shutil import get_terminal_size
    total_columns = get_terminal_size()[0]
    get_terminal_size((35,))
    bar = tqdm_rich(total=10)
    bar.close()
    get_terminal_size((total_columns,))

# Generated at 2022-06-24 10:34:57.404534
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn()
    assert fraction.unit_scale == False
    assert fraction.unit_divisor == 1000


# Generated at 2022-06-24 10:35:07.449627
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test class tqdm_rich."""
    from .utils import FormatCustomText

# Generated at 2022-06-24 10:35:19.083786
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import ProgressBar
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.text import Text

    class DownloadTask(ProgressBar):
        def __init__(self, total=None):
            self.completed = 0
            self.total = total

    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(),
        FractionColumn(
            unit_scale=True, unit_divisor=1000),
        width=100
    )
    progress.__enter__()

    task = DownloadTask(1024)
    task.__enter__()
    task.completed = 1024

# Generated at 2022-06-24 10:35:29.722192
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    Formatter = std_tqdm.default_gui_dict['format_dict'].__class__
    bar_format = std_tqdm.default_gui_dict['bar_format']
    fd = Formatter(desc=bar_format.get("desc"),
                   total=bar_format.get("total"),
                   ncols=bar_format.get("ncols"),
                   bar_format=bar_format.get("bar"),
                   initial=bar_format.get("initial"))
    d = fd.format_dict
    t = tqdm_rich(total=d['total'], desc=d['desc'],
                  unit=d['unit'], unit_scale=d['unit_scale'],
                  unit_divisor=d['unit_divisor'])
    t

# Generated at 2022-06-24 10:35:36.737423
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich("RateColumn test")
    ft = RateColumn("B")
    task.n = 1
    task.total = 1024
    task.last_print_n = 0
    task.last_print_t = 0

    task.n = 512
    assert ft.render(task) == Text("0.50 B/s", style="progress.data.speed")
    task.n = 1024
    assert ft.render(task) == Text("0.98 B/s", style="progress.data.speed")
    task.n = 1024
    assert ft.render(task) == Text("1.00 B/s", style="progress.data.speed")

    task.n = 1024 ** 2
    assert ft.render(task) == Text("1.00 KB/s", style="progress.data.speed")
    task