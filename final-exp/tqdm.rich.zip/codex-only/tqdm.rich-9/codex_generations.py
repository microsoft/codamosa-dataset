

# Generated at 2022-06-24 10:25:33.644960
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(10), leave=True)
    t.clear()
    t.close()

# Generated at 2022-06-24 10:25:42.331804
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Test for constructor of class RateColumn."""
    task = std_tqdm.tqdm(range(2), disable=True)
    task.n = 1
    task.total = 1
    task.last_print_t = None

# Generated at 2022-06-24 10:25:46.520356
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    x = FractionColumn()
    assert x.render(Progress(total=100, completed=78)) == Text("0.8/1.0 ",
                                                               style="progress.download")



# Generated at 2022-06-24 10:25:49.982563
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in range(1,4):
        t = tqdm_rich(total=total)
        assert t._prog.total == total
        t.update(1)
        t.reset()
        assert t._prog.completed == 0
        t.update(t._prog.total)
        t.reset(total=total+1)
        assert t._prog.total == total+1
        assert t._prog.completed == 0

# Generated at 2022-06-24 10:25:59.883709
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Testing N/A rate
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? ", style="progress.data.speed")

    # Testing rate with 'B' unit
    rate_column = RateColumn(unit='B')
    assert rate_column.render(123) == Text("123 B/s", style="progress.data.speed")

    # Testing rate with unit_scale=True + unit_divisor=1000
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)

    assert rate_column.render(1023) == Text("1 KB/s", style="progress.data.speed")
    assert rate_column.render(1536) == Text("1.5 KB/s", style="progress.data.speed")

# Generated at 2022-06-24 10:26:08.353814
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich._style import Style
    task = {'task': {'speed': None, 'description':'Progress'}}
    t = RateColumn('', False, 1000)(task)
    assert t.text == '? /s'
    assert t.style == Style.from_dict({'progress.data.speed': ''})
    task = {'task': {'speed': 10}}
    t = RateColumn('', False, 1000)(task)
    assert t.text == '10.0 /s'
    assert t.style == Style.from_dict({'progress.data.speed': ''})
    task = {'task': {'speed': 10.1}, 'unit': 'k'}
    t = RateColumn('k',False, 1000)(task)
    assert t.text == '10.1 k/s'
    assert t.style

# Generated at 2022-06-24 10:26:17.151001
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=3) as t:
        for i in range(3):
            t.update(1)
            t.clear()


if __name__ == '__main__':
    from tqdm import __version__
    from time import sleep

    __main__ = {"name__": "__main__", "__file__": __file__}

    # Test
    print("Version:", __version__)
    with tqdm(total=3) as t:
        for i in range(3):
            sleep(0.01)
            t.update(1)

    # Test

# Generated at 2022-06-24 10:26:26.168713
# Unit test for function trange
def test_trange():
    from .std import trange as std_trange
    for a, b, c in [(1, 3, 1), (1, 3, 2), (3, 1, -1)]:
        for kwargs in [dict(), dict(total=100)]:
            x = list(trange(a, b, c, **kwargs))
            y = list(std_trange(a, b, c, **kwargs))
            assert x == y
    for i in trange(3, leave=True):
        assert i == 0
    assert list(trange(3, disable=True)) == list(range(3))

# Generated at 2022-06-24 10:26:33.809795
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    try:
        from rich.console import Console
    except ImportError:
        pass
    else:
        Console.init()

    with tqdm_rich(bar_format="[{bar:10}] {n:02}/{total:02}", total=5) as pbar:
        for i in pbar:
            assert i == len(pbar) - 1
            pbar.set_description(f"loop {i}")
            pbar.refresh()
            assert pbar.gui

# Generated at 2022-06-24 10:26:35.078751
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = std_tqdm(range(10))
    t.clear()

# Generated at 2022-06-24 10:26:40.167599
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    '''
    Tests `tqdm_rich.reset(total)`.
    '''
    def test_tqdm_rich_reset_aux(total):
        t = tqdm_rich(total=total)
        t.reset()
        assert t.total == total

    test_tqdm_rich_reset_aux(123)
    test_tqdm_rich_reset_aux(None)
    test_tqdm_rich_reset_aux(total=tqdm._utils.decimal.Decimal(123))

# Generated at 2022-06-24 10:26:48.146758
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    from rich import box

    console = Console()
    console.print("Testing reset()...")
    prog = tqdm_rich(total=100, bar_width=10, console=console)
    prog.reset(total=50)
    console.print("Should be half filled:")
    console.print(box("", "", prog, style="ascii"))
    prog.reset()
    console.print("Should be full:")
    console.print(box("", "", prog, style="ascii"))
    prog.close()


# Execute the unit test if called from the command line
if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-24 10:26:56.341631
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test for tqdm_rich.display()."""
    from unittest.mock import mock_open
    from unittest.mock import patch
    mock_open = mock_open()
    with patch('tqdm.rich.tqdm_rich.open', mock_open, create=True):
        t = tqdm_rich(total=4, desc="test")
        for i in range(4):
            t.update(1)
            assert len(t._prog.tasks) == 1
            assert t.n == i + 1
            t.display()
    t.close()

# Generated at 2022-06-24 10:27:17.276614
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(object(completed=0, total=90)) == Text('0.0/90 ')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(object(completed=0, total=100000000)) == Text('0.0/0.1 G')
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(object(speed=10)) == Text('10 /s', style='progress.data.speed')
    assert RateColumn(unit="/s", unit_scale=True, unit_divisor=1000).render(object(speed=10)) == Text('0.0 /s/s', style='progress.data.speed')

# Generated at 2022-06-24 10:27:25.242452
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import sleep
    from .std import format_dict
    from .std import get_lock

    disable = False

    # Instantiation
    desc = "description"
    total = 100
    miniters = None
    mininterval = None
    mininterval = mininterval or 1e-3
    miniters = miniters or 1
    mininterval = max(mininterval, 0.)
    maxinterval = 1e-1
    maxinterval = max(maxinterval, mininterval)
    delta_t = maxinterval

    format_dict['unit'] = format_dict['unit'] or 'it'
    format_dict['unit_scale'] = bool(format_dict['unit_scale'])

# Generated at 2022-06-24 10:27:27.701652
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test `tqdm.rich.tqdm` alias of `tqdm.rich.tqdm_rich`."""
    x = tqdm(range(10))
    assert isinstance(x, tqdm_rich)
    # return x  # for manual interactive testing

