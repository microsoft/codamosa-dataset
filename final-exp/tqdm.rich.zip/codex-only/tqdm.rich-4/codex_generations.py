

# Generated at 2022-06-24 10:25:34.092296
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10, unit='B', unit_scale=True) as t:
        for i in _range(10):
            t.update()

# Generated at 2022-06-24 10:25:36.388702
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    text = "This is a test."
    from rich import print
    print(text)


if __name__ == '__main__':
    test_RateColumn_render()

# Generated at 2022-06-24 10:25:44.701751
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.rich.trange`.
    """
    from .gui import tgrange
    from .utils import _supports_unicode
    from .std import tqdm as _tqdm

    for _ in tgrange(0):
        tgrange(1)
        tgrange(1, 2)
        tgrange(1, 2, 3)
        tgrange(3, 0, -1)
        tgrange(3, 0, -1, 1)
        tgrange(3, 0, -1, 1, 2)

    if not _supports_unicode():
        _tqdm.write("\nNOTE: unicode not supported on this console")

    # Range
    trange(2)
    trange(2, 3)

# Generated at 2022-06-24 10:25:46.621233
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn()) == '0/0'


# Generated at 2022-06-24 10:25:51.569458
# Unit test for function trange
def test_trange():
    from .utils import format_interval, format_sizeof, _format_meter
    from .utils import _time, _term_move_up
    from .std import tqdm as tqdm_std

    for __ in tqdm_std(range(100), disable=True):
        pass

    with trange(100) as t:
        for i in t:
            if i >= 95:
                t.set_description(_format_meter(i+1, 100, [6, 45], "it/s"))
            assert isinstance(t, trange)

    it = tqdm_std(trange(5))
    assert isinstance(it, tqdm_std)
    assert isinstance(next(it), int)

    it = trange(0, 10, 0.1)

# Generated at 2022-06-24 10:25:54.720156
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    with tqdm(total=10) as prog:
        for x in prog:
            pass
        prog.reset(total=1)
        for x in prog:
            pass



# Generated at 2022-06-24 10:25:57.635936
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from nose.tools import raises

    with raises(TypeError):
        list(trange())

    with raises(TypeError):
        list(trange(object()))

    # Test that trange is working properly
    from time import sleep
    for _ in trange(4, leave=True):
        sleep(0.01)

# Generated at 2022-06-24 10:26:06.480959
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    from contextlib import contextmanager
    from .utils import suppress_stdout_stderr

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, _):
        with trange(2, file=out, unit='B') as t:  # nothing will be printed
            t.set_

# Generated at 2022-06-24 10:26:12.324014
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1000).render(None).text == '? B/s'
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(None).text == '? B/s'
    assert RateColumn(unit="B", unit_scale=False, unit_divisor=1).render(None).text == '? B/s'

# Generated at 2022-06-24 10:26:15.407358
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = {
        'task': 'test_RateColumn_render',
        'completed': 1,
        'total': 1,
        'speed': None,
    }
    rate_column = RateColumn()
    rate_column.render(task)
    assert True

# Generated at 2022-06-24 10:26:17.620204
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction = FractionColumn()
    assert fraction.render('task') == '0/0'

# Generated at 2022-06-24 10:26:19.072875
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich()
    assert t.display() == None


# Generated at 2022-06-24 10:26:31.209776
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .std import tqdm
    from .position import _get_free_space  # noqa
    from .version import __version__  # noqa
    from .utils import FormatLabel, Percentage  # noqa
    from .gui import format_meter  # noqa
    from .main import TqdmTypeError, TqdmKeyError  # noqa
    from .utils import format_sizeof  # noqa
    from .std import format_interval, time_to_str, time_to_str_short  # noqa
    from .std import format_meter as format_meter_std  # noqa

    bar_wid = _get_free_space()  # pylint: disable=invalid-name
    wid = bar_wid - 46

# Generated at 2022-06-24 10:26:39.510102
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    tc = RateColumn()
    result = tc.render(Progress(total=None, completed=None, description="", task_id=None))
    assert str(result) == "? /s"
    tc = RateColumn(unit="B")
    result = tc.render(Progress(total=None, completed=None, description="", task_id=None))
    assert str(result) == "? B/s"
    tc = RateColumn(unit_scale=True)
    result = tc.render(Progress(total=None, completed=None, description="", task_id=None))
    assert str(result) == "? /s"
    tc = RateColumn(unit_scale=True, unit_divisor=1024)
    result = tc.render(Progress(total=None, completed=None, description="", task_id=None))

# Generated at 2022-06-24 10:26:40.707340
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.clear()

# Generated at 2022-06-24 10:26:49.510037
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Representing human readable transfer speed."""
    speed = RateColumn(unit="B")
    task = tqdm_rich(total=100, unit_scale=False, unit='B', unit_divisor=1)
    task.n = 50
    task.speed = 100
    assert speed.render(task) == Text("100.0 B/s", style="progress.data.speed")

    speed = RateColumn(unit="")
    task = tqdm_rich(total=1000, unit_scale=True, unit='B', unit_divisor=1000)
    task.n = 500
    task.speed = 1000
    assert speed.render(task) == Text("1.0 K/s", style="progress.data.speed")
    task.n = 501
    task.speed = 1000

# Generated at 2022-06-24 10:26:58.536263
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert r.render(None).text == "? B/s"

    r = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert r.render(None).text == "? B/s"

    r = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert r.render(None).text == "? B/s"

    r = RateColumn(unit="B", unit_scale=False, unit_divisor=1024)
    assert r.render(None).text == "? B/s"


# Generated at 2022-06-24 10:27:04.891243
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit='B').render(None).text == '? B/s'
    assert RateColumn(unit='B').render(type('', (object,), {'speed': None})).text == '? B/s'
    assert RateColumn(unit='B').render(type('', (object,), {'speed': 0})).text == '0 B/s'
    assert RateColumn(unit='B').render(type('', (object,), {'speed': 1024})).text == '1.0 KB/s'

# Generated at 2022-06-24 10:27:09.959270
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test reset."""
    with tqdm(total=10) as pbar:
        assert pbar.n == 0
        assert pbar._prog.total == 10
        # test reset with total argument
        pbar.reset(total=100)
        assert pbar.n == 0
        assert pbar._prog.total == 100
        # test reset without total argument
        pbar.reset()
        assert pbar.n == 0
        assert pbar._prog.total == 10

# Generated at 2022-06-24 10:27:11.360608
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()
    RateColumn(unit_divisor=1024, unit='B')
    RateColumn(unit='B', unit_scale=True)

# Generated at 2022-06-24 10:27:14.861986
# Unit test for function trange
def test_trange():
    from time import sleep
    from unittest.mock import MagicMock

    trange_obj = trange(8, file=MagicMock(), leave=True)
    for _ in trange_obj:
        sleep(.25)

# Generated at 2022-06-24 10:27:23.649678
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import six
    from rich.console import Console

    # sys.modules[__name__] = tqdm_rich
    class mocked_sys:
        def __getattr__(self, attr):
            if attr == 'stdout':
                return sys.__getattribute__('stdout')
            return lambda x: x

    sys.modules[__name__] = mocked_sys()
    import tqdm_rich
    tqdm = tqdm_rich.tqdm

    # Python 2 (unicode)
    if six.PY2:
        console_width = Console(record=True).width
        width = int(console_width * 0.6)

        for _ in tqdm(list(range(width)), ascii=True, leave=True):
            pass

    # Python 2+

# Generated at 2022-06-24 10:27:32.851942
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test the behavior of FractionColumn.render() with different options.
    """
    # With no option, the default is to show exact file size.
    completed = 5
    total = 7
    column = FractionColumn()
    assert column.render(completed, total) == Text(f"{completed}/{total} ")

    # When activating the option unit_scale, we see the fraction
    # in common unit between completed and total.
    column = FractionColumn(unit_scale=True)
    assert column.render(1, 1000) == Text(f"1/1000 ")
    assert column.render(1000, 1000000) == Text(f"1/1000 ")
    assert column.render(5, 7) == Text(f"5.0/7.0 ")

# Generated at 2022-06-24 10:27:38.926792
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # Test rebind and close
    pbar = tqdm_rich(total=100)
    pbar.close()
    pbar = tqdm_rich(range(100))
    pbar.close()
    pbar = tqdm_rich(total=100)
    pbar.close()
    pbar = tqdm_rich(range(100))
    pbar.close()


# Generated at 2022-06-24 10:27:47.629155
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .tests.utils import isclose
    from rich.console import Console
    from rich.progress import Progress

    max_value = 1.0
    progress = Progress(
        '[progress.description]{task.description}',
        '[progress.percentage]{task.percentage:>4.0f}%',
        BarColumn(bar_width=None),
        TimeElapsedColumn(),
        console=Console(),
    )


# Generated at 2022-06-24 10:27:48.455988
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-24 10:27:49.894629
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(None) == Text("0.0/0.0")

# Generated at 2022-06-24 10:27:53.711758
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    """Test constructor of RateColumn."""
    speed = RateColumn()
    assert str(speed) == "Speed: ? /s"
    speed = RateColumn("bps")
    assert str(speed) == "Speed: ? bps/s"

# Generated at 2022-06-24 10:28:00.608809
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Prints best unit for bytes."""
    rate_column = RateColumn(unit_scale=True)
    rate_column.render(None)
    rate_column = RateColumn(unit_scale=True)
    rate_column.render(None)
    rate_column = RateColumn(unit_scale=False)
    rate_column.render(None)
    rate_column = RateColumn(unit_scale=False, unit="/s")
    rate_column.render(None)

# Generated at 2022-06-24 10:28:06.983602
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from .utils import FormatStdout

    with FormatStdout(
            mode='ansi',
            desc=" ",
            unit='it',
            leave=True,
    ) as (out, _):
        list(trange(3))
        assert out.getvalue() == " 0%| | 0/3 [00:00<?, ?it/s]\n100%|######| 3/3 [00:00<00:00, 100.00it/s]\n"

# Generated at 2022-06-24 10:28:16.851212
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render({'completed': 3, 'total': 4}) == Text('3/4 ', style='progress.download')
    assert fc.render({'completed': 30, 'total': 40}) == Text('30/40 ', style='progress.download')
    assert fc.render({'completed': 300, 'total': 400}) == Text('300/400 ', style='progress.download')
    assert fc.render({'completed': 3000, 'total': 4000}) == Text('3.0/4.0 ', style='progress.download')
    assert fc.render({'completed': 30000, 'total': 40000}) == Text('30.0/40.0 ', style='progress.download')
    assert fc.render({'completed': 300000, 'total': 400000})

# Generated at 2022-06-24 10:28:18.116199
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    a = tqdm_rich(0)

# Generated at 2022-06-24 10:28:20.154196
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4, desc="Hi!", unit="Blop"):
        pass

# Generated at 2022-06-24 10:28:29.872680
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import disable_tqdm
    with disable_tqdm():
        # pylint: disable=protected-access
        tqdm_rich.display(None)
        assert hasattr(tqdm_rich, '_prog') is False
        tqdm_rich(total=100)
        assert hasattr(tqdm_rich, '_prog')
        tqdm_rich.display()
        tqdm_rich.update(10)
        tqdm_rich.display()
        tqdm_rich.close()
        assert hasattr(tqdm_rich, '_prog') is False
        tqdm_rich(total=100)
        assert hasattr(tqdm_rich, '_prog')
        tqdm_rich.display()

# Generated at 2022-06-24 10:28:39.591714
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm constructor for rich progress bar."""
    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=True),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit_scale=True, unit="B"), "]"
    )
    with tqdm_rich(progress=progress, desc='progress', leave=True, disable=False, total=-1) as t:
        pass

if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-24 10:28:48.019352
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Test tqdm_rich display function"""
    from tqdm.tests import pretest_posttest_run

# Generated at 2022-06-24 10:28:50.660601
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    t = FractionColumn()
    t.render(task = {'completed':'1', 'total':'2'})

# Generated at 2022-06-24 10:28:52.200885
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=100)
    t.close()



# Generated at 2022-06-24 10:28:55.750807
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from sys import stdout

    with tqdm(total=100, desc="test_tqdm_rich", file=stdout) as t:
        for i in range(100):
            t.update()

# Generated at 2022-06-24 10:28:56.855714
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-24 10:29:01.668111
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    passed = True

# Generated at 2022-06-24 10:29:09.191473
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os
    x = tqdm_rich(total=10)
    try:
        x.display()
    except AttributeError:
        raise AssertionError("method display of class tqdm_rich should not "
                             "raise AttributeError")
    try:
        os.name = "antigravity"
        x.display()
    except RuntimeError:
        pass
    else:
        raise AssertionError("method display of class tqdm_rich should raise "
                             "RuntimeError with `os.name = 'antigravity'`")
    finally:
        os.name = "posix"
    return

# Generated at 2022-06-24 10:29:17.246088
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tgrange
    for n in tgrange(4, desc='testing trange'):
        pass
    for n in trange(4, desc='testing trange'):
        pass

    with trange(10) as t:
        for i in (1, 2, 3):
            t.update()
            if i == 2:
                t.reset(10)
                t.set_description("updated desc")
            t.set_postfix(postfix="postfix")

# Generated at 2022-06-24 10:29:18.586765
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn("bit", unit_scale=False)) == "[? bit/s]"

# Generated at 2022-06-24 10:29:26.467685
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests_tqdm import pretest_posttest  # NOQA
    from .tests_tqdm import closing, leaving, unit_scale, unit, total, miniters, mininterval, mininterval_sleep

    # Create progress bar and add it as a task
    with closing(tqdm_rich(
            total=total, unit_scale=unit_scale, unit=unit, mininterval=mininterval,
            miniters=miniters, disable=False)) as t:
        assert hasattr(t, '_task_id')
        assert hasattr(t, '_prog')

    # Test closing without initialization

# Generated at 2022-06-24 10:29:38.096329
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test method clear in tqdm_rich."""
    from .tests.test_tqdm import misc
    from .tests.test_tqdm import _range
    from .tests.test_tqdm import format_interval
    from .tests.test_tqdm import FormatCustom, format_meter

    # Get initial values

# Generated at 2022-06-24 10:29:41.033957
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    col = FractionColumn()
    ret = col.render(col)
    assert ret.text == "0/0 "


# Generated at 2022-06-24 10:29:49.929908
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .utils import format_interval
    from .utils import format_meter
    from .std import trange

    with trange(4, desc="a", mininterval=0, miniters=0) as t:
        assert t.mininterval == 0
        assert t.miniters == 0
        assert t.dynamic_miniters
        t.sleep(0)
        assert t.miniters == 1
        t.update()
        assert t.miniters == 1
        t.update()
        assert t.miniters == 1
        t.sleep(0)
        assert t.miniters == 2
        t.update()
        assert t.miniters == 2
        t.sleep(0)
        assert t.miniters == 3
        t.update()

# Generated at 2022-06-24 10:30:00.071618
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = ProgressColumn.test_task
    assert FractionColumn().render(task) == Text("0.0/1 G", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1).render(task) == Text("0.0/1 G", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=2).render(task) == Text("0.0/1 G", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text("0.0/1 G", style="progress.download")

# Generated at 2022-06-24 10:30:07.458557
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Unit test for constructor of class RateColumn"""
    unit = "m"
    unit_scale = False
    unit_divisor = 1000
    r = RateColumn(unit, unit_scale, unit_divisor)
    assert r.unit == "m"
    assert r.unit_scale == False
    assert r.unit_divisor == 1000
    assert r.style == "progress.data.speed"
    assert isinstance(r.column, ProgressColumn)

# Generated at 2022-06-24 10:30:15.201248
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    tqdm_ = tqdm_rich(total=1000)
    tqdm_.n = 100
    tqdm_.unit_scale = True
    tqdm_.unit_divisor = 1
    fc = FractionColumn(unit_scale=True, unit_divisor=1)
    print(fc.render(tqdm_))
    assert fc.render(tqdm_).text == "100.0/1,000.0 "
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    print(fc.render(tqdm_))
    assert fc.render(tqdm_).text == "0.1/1.0 K"

# Generated at 2022-06-24 10:30:24.579293
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    import time
    import rich.console
    console = rich.console.Console(log_level="DEBUG")
    # TODO: expand test coverage
    def test_timeout(func, max_time=3, demo=True):
        start_time = time.time()
        timeout = False
        try:
            func()
        except KeyboardInterrupt:
            timeout = True
            if demo:
                raise
            console.print("<buzz>", style="blink")
        except Exception:
            raise
        finally:
            time_elapsed = time.time() - start_time
            assert time_elapsed <= max_time, f"{time_elapsed} > {max_time}"
            assert timeout, "Timeout timed out"

# Generated at 2022-06-24 10:30:31.959797
# Unit test for function trange
def test_trange():
    for iterable in [range(2), range(2, 5), range(2, 10, 3), range(10),
                     range(10, 0, -1), range(0, -10, -1)]:
        iterable = list(iterable)
        for n in [None, 0, 5, 10, len(iterable) // 2, len(iterable) - 1, len(iterable)]:
            tqdm_iterable = trange(len(iterable))
            # Check if total iterations are correct
            assert tqdm_iterable.total == len(iterable)
            # Check if iteration works correctly
            for elem in iterable:
                next(tqdm_iterable)
                tqdm_iterable.update()
            assert tqdm_iterable.n == len(iterable)
            tq

# Generated at 2022-06-24 10:30:32.902420
# Unit test for constructor of class RateColumn
def test_RateColumn():
    pass

# Generated at 2022-06-24 10:30:44.620432
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test method render of class RateColumn"""
    from tqdm.rich.utils import format_speed_and_suffix
    task = Progress()
    task.speed = 1000
    task.total = 1234
    task.completed = 123
    test_unit = "bit/s"
    test_unit_scal = True
    test_unit_divis = 1000
    test_rate_column = RateColumn(unit=test_unit,
                                  unit_scale=test_unit_scal,
                                  unit_divisor=test_unit_divis)
    test_rate_column.render(task)
    result = format_speed_and_suffix(task.speed, test_unit, 1000, 1)
    assert test_rate_column.render(task).text == result



# Generated at 2022-06-24 10:30:47.924537
# Unit test for constructor of class RateColumn
def test_RateColumn():
    r = RateColumn(unit='B', unit_scale=False, unit_divisor=1000)
    assert r.unit == "B"
    assert r.unit_scale == False
    assert r.unit_divisor == 1000

# Generated at 2022-06-24 10:30:53.288570
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    text = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert text.render(None) == "0.0/0.0"

    text = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert text.render(None) == "0.0/0.0"


# Generated at 2022-06-24 10:30:57.863252
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm as _tqdm
    from .utils import FormatWidget

    with _tqdm(total=5, gui=True) as pbar:
        assert isinstance(pbar, tqdm_rich)
        assert pbar._prog is None
        pbar.display()
        assert isinstance(pbar._prog, FormatWidget)
        assert pbar._prog is not None

# Generated at 2022-06-24 10:31:04.797592
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    result = RateColumn(unit_scale=False, unit_divisor=1000).render(ProgressColumn.Task(speed = 1024))
    assert str(result) == "1.0K/s"
    result = RateColumn(unit_scale=True, unit_divisor=1000).render(ProgressColumn.Task(speed = 1024))
    assert str(result) == "1.0K/s"
    result = RateColumn(unit_scale=False, unit_divisor=1024).render(ProgressColumn.Task(speed = 1024))
    assert str(result) == "1.0/s"
    result = RateColumn(unit_scale=True, unit_divisor=1024).render(ProgressColumn.Task(speed = 1024))
    assert str(result) == "1.0K/s"


# Generated at 2022-06-24 10:31:08.055768
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Tests that `tqdm_rich.close()` doesn't throw any exception
    """
    t = tqdm_rich(range(50), leave=None)
    t.close()

# Generated at 2022-06-24 10:31:16.282036
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import IncrementalProgressBar
    from tqdm import tnrange
    from tqdm.rich import tqdm_rich
    with tqdm(total=12, dynamic_ncols=True) as pbar:
        for i in tnrange(12):
            time.sleep(0.1)
            pbar.update()

    with tqdm(total=12, dynamic_ncols=True, gui=True) as pbar:
        for i in tnrange(12):
            time.sleep(0.1)
            pbar.update()


# Generated at 2022-06-24 10:31:22.481037
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_col = FractionColumn()
    print(test_col.render(Progress(2, 2, 0)))
    print(test_col.render(Progress(0.5, 2.3, 0)))
    test_col = FractionColumn(True, 1000)
    print(test_col.render(Progress(2000, 2000, 0)))
    print(test_col.render(Progress(500, 2300, 0)))


# Generated at 2022-06-24 10:31:26.616115
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test case."""
    # TODO: tqdm_rich(bar_format='{l_bar}{r_bar}').start()
    with tqdm_rich(total=2) as prog:
        prog.update(1)
        prog.n = 1

# Generated at 2022-06-24 10:31:29.096923
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        raise NotImplementedError()
    except NotImplementedError:
        tqdm_rich().clear()

# Generated at 2022-06-24 10:31:40.716070
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    x = tqdm_rich(total=100, desc="test test_tqdm_rich_display")
    # Testing total <= 0
    x.reset(total=0)
    assert x.n == 0
    x.reset(total=-10)
    assert x.n == 0
    # Testing display
    x.reset(total=100)
    assert x.n == 0
    for i in range(50):
        x.display()
        x.n = i + 1
        assert x.n == i + 1
        x.refresh()
        assert x.n == i + 1
    assert x.n == 50
    x.total = 200
    x.display()
    x.set_postfix_str("test_tqdm_rich_display")
    assert x.n == 50
    assert x.post

# Generated at 2022-06-24 10:31:42.854670
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    tqdm(total=3)._prog, Progress(Console(), total=3)

# Generated at 2022-06-24 10:31:52.032066
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """Test example"""
    from time import sleep
    # a = trange(10, leave=True)
    # for i in a:
    #     sleep(0.1)
    # raw_input()
    with trange(100) as t:
        for i in t:
            sleep(0.01)
            t.set_description(f'ID: {i:d}')
            t.refresh()
            # if i == 10:
            #     print('foobar')
    # a = trange(10, bar_format="{l_bar}  {n_fmt}/{total_fmt} [{elapsed}<{remaining}]")
    # for i in a:
    #     sleep(0.1)


# Generated at 2022-06-24 10:31:54.180809
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(5)
    t.display()
    t.update(2)
    t.display()
    t.update()
    t.display()
    t.update()
    t.display()
    t.update()
    t.display()
    t.close()

# Generated at 2022-06-24 10:31:56.478664
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=100) as pbar:
        pbar.update(50)

# Generated at 2022-06-24 10:32:04.028372
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test for trange and tqdm alias"""
    def test_external_write(n, bsize=100):
        """Test for manual tqdm write"""
        with trange(n, file=open(os.devnull, 'w')) as t:
            for i in _range(n):
                t.set_description('test')
                t.display()
                t.write('test')
                t.update(bsize)
                if i % 5 == 1:
                    t.n = i - 1  # simulate unpredicted behaviour
                    t.refresh()
            t.close()
            assert t.n == t.total

# Generated at 2022-06-24 10:32:11.978203
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    [progress.description]{task.description}
    [progress.percentage]{task.percentage:>4.0f}%
    [{task.bar}]{task.completed}/{task.total}
    {task.elapsed}<{task.remaining}, {task.eta}
    """
    with tqdm(total=10) as t:
        for _ in range(10):
            t.update()

# Generated at 2022-06-24 10:32:22.237743
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import tqdm
    import time

    with tqdm(total=5, bar_format="{rate[0]} {rate[1]}") as t:
        for i in range(5):
            time.sleep(1)
            t.update()
            assert t.format_dict['rate'][0] == i + 1
    assert t.format_dict['rate'][0] == 5
    assert t.format_dict['rate'][1] == 'it/s'
    with tqdm(total=5, bar_format="{rate_fmt}") as t:
        for i in range(5):
            time.sleep(1)
            t.update()
            rate = t.format_dict['rate_fmt']

# Generated at 2022-06-24 10:32:32.757315
# Unit test for function trange
def test_trange():
    """Unit test function for trange()."""
    from collections import Counter
    from itertools import chain
    import sys

    for _ in trange(12):
        pass

    for x in trange(3, 1, -1):  # count down
        assert x == 1
        break

    # Check that tqdm is able to iterate over lists, tuples and ranges
    for n in TrangeTestIterators:
        list(trange(n))
        list(trange(tuple(range(n))))
        list(trange(range(n)))
        list(trange(xrange(n)))

    # Check that a dynamically-resizing iterator can be used normally
    c = Counter()
    for n in trange(12):
        c[n] += 1
        if n > 5:
            break

# Generated at 2022-06-24 10:32:34.863318
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_progress_column = FractionColumn()
    assert test_progress_column.unit_scale is False
    assert test_progress_column.unit_divisor == 1000


# Generated at 2022-06-24 10:32:38.674955
# Unit test for constructor of class FractionColumn
def test_FractionColumn():  # pragma: no cover
    assert FractionColumn().render(ProgressColumn.Task(0.5, 1.0, "", "", 0., 1., None, None)) == Text('0.5/1 ', style="progress.download")

# Generated at 2022-06-24 10:32:47.259329
# Unit test for function trange
def test_trange():
    """Test function trrange."""
    assert list(trange(5)) == list(range(5))
    assert list(trange(10)) == list(range(10))
    assert list(trange(1)) == list(range(1))
    assert list(trange(1, 20)) == list(range(1, 20))
    assert list(trange(1, 20, 2)) == list(range(1, 20, 2))
    assert list(trange(20, 1, -2)) == list(range(20, 1, -2))
    assert list(trange(20, 1, 1)) == list(range(20, 1, 1))
    assert list(trange(1, 20, 5.5)) == list(range(1, 20, 5.5))



# Generated at 2022-06-24 10:32:48.693943
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-24 10:32:54.826632
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=50, smooth=0.1)
    Task = task._task_factory()
    taskx = Task(0, 50, 50, 0, 0, 1, 0.1, 10, None)
    tasky = Task(0, 50, 50, 0, 0, 1, 0.1, 1000, None)
    taskz = Task(0, 50, 50, 0, 0, 1, 0.1, 1000000, None)
    taskt = Task(0, 50, 50, 0, 0, 1, 0.1, 1000000000, None)

    task1 = Task(0, 50, 50, 0, 0, 1, 0.1, 1, None)

    ratel = RateColumn()

# Generated at 2022-06-24 10:33:04.218971
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import sys

    progress = (
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )


# Generated at 2022-06-24 10:33:15.833807
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .tests import dummy_tqdm
    from .std import _tqdm_tqdm_newlines
    from .rich import tqdm_rich

    for cls in (tqdm_rich, tqdm):
        # class instantiation
        t = cls(range(10))
        t.close()

        # test of no errors/warnings raised with non-TTY/file
        t = cls(range(200), file=open('tqdm.txt', 'w'))
        with open('tqdm.txt') as f:
            s = f.read()
        assert s == "[" + "".join(["."] * 200) + "]" + _tqdm_tqdm_newlines
        t.close()

        t = cls(range(200))
        t.close()

# Generated at 2022-06-24 10:33:18.469509
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.unit_scale == True
    assert fc.unit_divisor == 1000

# Generated at 2022-06-24 10:33:21.130122
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=3) as tr:
        tr.update()
        tr.reset(total=5)
        tr.update()
        assert tr.n == 2
        assert tr.total == 5

# Generated at 2022-06-24 10:33:23.816631
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert column.render(None) == Text(f"? B/s", style="progress.data.speed")

# Generated at 2022-06-24 10:33:25.032533
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    c = FractionColumn()
    assert c.render(None) == ''

# Generated at 2022-06-24 10:33:32.593239
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from ._tqdm_gui import tnrange, trange
    from .gui import tnrange
    from .utils import format_sizeof
    from time import sleep
    from math import nan

    with trange(10) as t:
        for i in t:
            try:
                assert t.n == i
                assert t.n != i + 1
            except Exception as e:
                raise type(e)(e.message +
                              (" (n={0}, i={1})".format(t.n, i))).with_traceback(e.__traceback__)

            if i > 3:
                t.total = None  # Disable repr
                t.total = nan
                t.update(1)  # Has no effect
                t.n = 2.3

# Generated at 2022-06-24 10:33:33.872193
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        trange(10).clear()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-24 10:33:37.491240
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    task_id = 1
    with tqdm(total=10, desc="Test") as t:
        t._prog.add_task("Test2", total=10)
        t._prog.add_task("Test3", total=10)
        for i in t:
            task_id += 1
            t.set_description("Test" + str(task_id))
            time.sleep(0.1)
            t.reset(total=20)
            time.sleep(0.1)

# Generated at 2022-06-24 10:33:39.958381
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm_rich(total=100) as prog:
        for i in range(100):
            prog.update(i)
            time.sleep(0.01)

# Generated at 2022-06-24 10:33:43.195300
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    for _ in tqdm([1, 2, 3], desc="Foo", unit="B", unit_scale=True):
        pass



# Generated at 2022-06-24 10:33:52.256830
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    with tqdm_rich(1234, disable=False) as t:
        t.reset(6.0)
        t.reset(total=6.0)
        t.reset()
        for i in range(3):
            time.sleep(0.01)
            t.update()
        t.reset(total=0.0)
        for i in range(4):
            time.sleep(0.01)
            t.update(n=1)
        t.reset()
        for i in range(3):
            time.sleep(0.01)
            t.update(n=1)
        with tqdm_rich(disable=True) as t:
            t.reset(total=10)
            t.update(n=10)

# Generated at 2022-06-24 10:33:57.255439
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    Rich bar column: Test constructor of class FractionColumn
    """
    assert str(FractionColumn()) == "<FractionColumn: unit_scale=False, unit_divisor=1000>"
    assert str(FractionColumn(unit_scale=True, unit_divisor=1024)) == "<FractionColumn: unit_scale=True, unit_divisor=1024>"

# Generated at 2022-06-24 10:34:01.317086
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    std_tqdm(tqdm_rich()).close()
    std_tqdm(tqdm_rich(total=100)).close()
    std_tqdm(tqdm_rich(desc='123')).close()


if __name__ == '__main__':
    # Unit test for constructor of class tqdm_rich
    test_tqdm_rich()

# Generated at 2022-06-24 10:34:08.001663
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    import time
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            time.sleep(0.1)
        assert t.n == 10
        t.reset(total=100)
        for i in range(100):
            t.update()
            time.sleep(0.1)
        assert t.n == 100



# Generated at 2022-06-24 10:34:16.733338
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Unit scale is True
    unit_scale = True
    unit_divisor = 1000
    # assert task.total == 1024
    task = type("", (), {"completed": 512, "total": 1024})
    column = FractionColumn(unit_scale, unit_divisor)
    result = column.render(task)
    assert result == Text("0.5/1.0 K", style="progress.download")
    # assert task.total == 1234
    task = type("", (), {"completed": 512, "total": 1234})
    column = FractionColumn(unit_scale, unit_divisor)
    result = column.render(task)
    assert result == Text("0.5/1.2 K", style="progress.download")
    # assert task.total == 12340

# Generated at 2022-06-24 10:34:27.912626
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Test without unit scaling
    fraction_column = FractionColumn(unit_scale=False, unit_divisor=1000)
    task1 = std_tqdm(total=50)
    task1.update(12)
    result1 = fraction_column.render(task1)
    task1.close()
    assert result1.text == "12.0/50.0 "

    # Test with unit scaling
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    task2 = std_tqdm(total=25600)
    task2.update(12800)
    result2 = fraction_column.render(task2)
    task2.close()
    assert result2.text == "12.8/25.6 K"


# Generated at 2022-06-24 10:34:31.045560
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover # pragma: no cover
    """Test tqdm_rich constructor"""
    from time import sleep
    for i in tqdm_rich(range(10), desc='test', leave=True):
        sleep(0.01)

# Generated at 2022-06-24 10:34:33.577075
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import rich.console
    console = rich.console.Console()
    console.print(Text("[bold blue]Hello [bold red]World!"))

# Generated at 2022-06-24 10:34:39.007085
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    with trange(10, desc="Task1") as task1:
        assert task1.__enter__() == task1
        # check that tqdm_rich.display doesn't raise exception
        task1.display()
        assert task1.__exit__() is None
        assert task1.disable is False
        task1.reset(10)  # re-initialize
        assert task1.desc == "Task1"
        task1.display()
        for _ in task1:
            task1.display()



# Generated at 2022-06-24 10:34:39.534266
# Unit test for constructor of class RateColumn
def test_RateColumn():
    _ = RateColumn()

# Generated at 2022-06-24 10:34:41.721024
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    t1 = tqdm_rich(disable=True, file=sys.stdout)
    t2 = tqdm_rich(disable=False, file=sys.stdout)
    t1.clear()
    t2.clear()

# Generated at 2022-06-24 10:34:44.704149
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    completed, total, speed = 50, 100, 10
    completed = rateColumn.render({'completed':completed, 'total':total, 
        'speed':speed})
    assert str(completed) == '10 B/s'



# Generated at 2022-06-24 10:34:56.158427
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import math

    rate = RateColumn()
    # Assume base 10, no scaling and no units
    assert rate.unit == ''
    assert rate.unit_scale == False
    assert rate.unit_divisor == 1000

    rate = RateColumn(unit='m')
    # Assume base 10, no scaling and metres
    assert rate.unit == 'm'
    assert rate.unit_scale == False
    assert rate.unit_divisor == 1000

    rate = RateColumn(unit='m', unit_scale=True, unit_divisor=10)
    # Assume base 10 and metres, with base 10 scaling
    assert rate.unit == 'm'
    assert rate.unit_scale == True
    assert rate.unit_divisor == 10

    # Assume base 2, no units and no scaling

# Generated at 2022-06-24 10:35:01.303681
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4, leave=True):
        pass
    for _ in trange(1, 4, leave=True):
        pass
    with trange(4, leave=True) as t:
        for _ in t:
            pass
    with trange(1, 4, leave=True) as t:
        for _ in t:
            pass

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:35:06.178264
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.auto import tqdm
    from tqdm._tqdm import format_meter
    from tqdm.utils import _term_move_up
    import sys
    import shutil
    try:
        width, _ = shutil.get_terminal_size()
    except Exception:
        width = 80
    width, _ = shutil.get_terminal_size()
    fmt = "  {l_bar}{bar}{r_bar} [{percentage:3.0f}%]"
    with tqdm(total=10, desc="TEST", leave=True,
              bar_format=fmt.format(l_bar='', bar='{bar}', r_bar='')) as t:
        t.display()
        sys.stdout.write(_term_move_up())
        sys

# Generated at 2022-06-24 10:35:13.565620
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich."""
    import time
    with tqdm_rich(total=10, unit="B", unit_scale=True, unit_divisor=1024) as t:
        for i in range(10):
            time.sleep(0.02)
            t.update(1)
        t.reset(total=20)
        for i in range(20):
            time.sleep(0.02)
            t.update(1)

# Generated at 2022-06-24 10:35:21.658416
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    column = RateColumn(unit_scale=False)
    assert column.render({'speed':1}) == Text("1.00 B/s", style="progress.data.speed")
    assert column.render({'speed':2048}) == Text("2.00 KB/s", style="progress.data.speed")
    assert column.render({'speed':2048*1024}) == Text("2.00 MB/s", style="progress.data.speed")
    assert column.render({'speed':2048*1024*1024}) == Text("2.00 GB/s", style="progress.data.speed")
    column = RateColumn(unit_scale=True)
    assert column.render({'speed':1}) == Text("1.00  B/s", style="progress.data.speed")
    assert column.render({'speed':1024}) == Text

# Generated at 2022-06-24 10:35:28.110753
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = Progress(
        "[progress.description]{task.description} done",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000))
    with progress:
        task_id = progress.add_task("file", total=1000)
        for i in _range(1000):
            progress.update(task_id, completed=i+1)

# Generated at 2022-06-24 10:35:32.419014
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import datetime

    timer = datetime.datetime.now()
    with tqdm_rich(total=10, desc='Testing') as pbar:
        for i in _range(10):
            pbar.update(1)
            assert not pbar.disable

    print(f"\n{(datetime.datetime.now() - timer).seconds} seconds")

