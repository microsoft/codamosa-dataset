

# Generated at 2022-06-24 10:25:41.541417
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render(Progress.Task("",completed=0,total=0)) == Text("0.0/0 0")
    assert fc.render(Progress.Task("",completed=1,total=1)) == Text("1/1 0")
    assert fc.render(Progress.Task("",completed=1,total=2)) == Text("0.5/2 0")
    assert fc.render(Progress.Task("",completed=1000,total=2000)) == Text("0.5/2 0")
    assert fc.render(Progress.Task("",completed=1000000,total=2000000)) == Text("0.5/2 M")

# Generated at 2022-06-24 10:25:43.990612
# Unit test for constructor of class RateColumn
def test_RateColumn():
    tc = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert tc.unit == ""
    assert tc.unit_scale == False
    assert tc.unit_divisor == 1000

# Generated at 2022-06-24 10:25:52.294256
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    task = Progress(total=100, style="percent")
    task.completed = 100
    assert(column.render(task) == Text('1/1 ', style='progress.download'))
    task.completed = 1000
    assert(column.render(task) == Text('10.0/10 ', style='progress.download'))
    task.completed = 0
    assert(column.render(task) == Text('0/1 ', style='progress.download'))
    task.style = "unset"
    assert(column.render(task) == Text('0/1 ', style='progress.download'))


# Generated at 2022-06-24 10:25:54.671513
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        for i in t:
            assert i == t.n
        assert t.n == 10

# Generated at 2022-06-24 10:26:04.085953
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # tests for unit='' and unit_scale=False
    assert RateColumn().render({'speed': None}) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render({'speed': -100}) == Text("-100.0 /s", style="progress.data.speed")
    assert RateColumn().render({'speed': 0}) == Text("0.0 /s", style="progress.data.speed")
    assert RateColumn().render({'speed': 1}) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn().render({'speed': 999}) == Text("999.0 /s", style="progress.data.speed")
    assert RateColumn().render({'speed': 1000}) == Text("1.0 K/s", style="progress.data.speed")
    assert RateColumn

# Generated at 2022-06-24 10:26:10.475221
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    with tqdm_rich(total=5) as pbar:
        for i in range(1, 6):
            time.sleep(0.1)
            pbar.update(1)
    time.sleep(0.1)
    with tqdm_rich(total=5) as pbar:
        for i in range(1, 6):
            time.sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-24 10:26:12.279889
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .main import _test_cls
    _test_cls(tqdm_rich)

# Generated at 2022-06-24 10:26:19.376102
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .tests_tqdm import TestCase, closing, long_running_iterable, nullcontext
    # Test normal display
    with TestCase(tqdm_rich(range(10))) as tc:
        tc.assertOutput('[%%%%%%%%%%] 100%|##########|  ETA: 00:00:00\r')

    # Test normal with leave
    with TestCase(tqdm_rich(range(10), leave=True)) as tc:
        tc.assertOutput('[%%%%%%%%%%] 100%|##########|  ETA: 00:00:00')

    # Test normal with miniters

# Generated at 2022-06-24 10:26:23.119832
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Arrange
    pbar = tqdm_rich(total=100)
    # Act
    pbar.reset(total=5)
    # Assert
    assert pbar.total == 5


# Generated at 2022-06-24 10:26:34.121863
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from random import randint, random
    from time import sleep
    from rich.console import Console
    from rich.progress import Progress

    def foo(n):
        p = tqdm_rich(total=n, desc='foo')
        for i in p:
            p.set_description("%s: %d%%" % (p.desc, p.percent))
            p.set_postfix_str("i: %d" % i)
            sleep(0.05)

    def reset(n):
        p = tqdm_rich(total=n, desc='reset', bar_format='{bar} {percentage}%')
        for _ in p:
            p.total = p.total + 1
            p.reset()

    # create a progress bar for testing
    n = randint(100, 150)
    console

# Generated at 2022-06-24 10:26:36.842720
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    column = FractionColumn()
    task = Progress()
    task.total, task.completed = 100, 50
    assert column.render(task).text == "50/100"
    task.total, task.completed = 1000, 500
    assert column.render(task).text == "0.5/1.0 K"


# Generated at 2022-06-24 10:26:40.776692
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # The total argument will be passed to the internal Progress
    t = tqdm_rich(total=2, leave=True)
    for i in t:
        if i == 1:
            t.reset(total=4)
        assert t.total == 4
        t.update()
    t.close()
    assert t._prog._tasks[t._task_id].total == 4

# Generated at 2022-06-24 10:26:49.574774
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """
    Tests for the class `RateColumn` in the module `tqdm.rich.progress`.
    """

    import tqdm.rich.progress
    from rich.progress import ProgressColumn

    class test_rate_column(tqdm.rich.progress.RateColumn):
        """
        Tests the class `RateColumn`.
        """

        def __init__(self, unit='', unit_scale=False, unit_divisor=1000):
            """
            Initialise the class.
            """
            self.unit = unit
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super(test_rate_column, self).__init__()

        def render(self, task):
            """
            Show data transfer speed.
            """
            speed = task.speed


# Generated at 2022-06-24 10:26:51.782204
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    tqdm_rich(range(100)).clear()

# Generated at 2022-06-24 10:26:55.177102
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for method render of class RateColumn"""
    rate_column = RateColumn(unit_scale=True)
    task = 'task'
    task.speed = 1000
    assert rate_column.render(task) == Text('1.0 K/s', style='progress.data.speed')

# Generated at 2022-06-24 10:27:01.706808
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn(unit_scale=False, unit_divisor=1000)
    task = object()
    task.completed = 10
    task.total = 10
    assert fc.render(task) == "10.0/10.0"
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    task.total = 1000000
    assert fc.render(task) == "0.0/1.0 M"
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    task.total = 1000000000000
    assert fc.render(task) == "0.0/931.32 G"



# Generated at 2022-06-24 10:27:10.048211
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import TaskID, Progress
    from unittest import TestCase
    import sys

    _stdout = sys.stdout
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

    class TestProgress(TestCase):
        def test_tqdm_rich_display(self):
            ttr = tqdm_rich(total=2, desc="test_display")
            self.assertEqual(ttr._prog.task_map[ttr._task_id].total, 2)
            ttr.display()
            ttr.n = 1
            self.assertEqual(ttr._prog.task_map[ttr._task_id].completed, 1)
            ttr.n = 2

# Generated at 2022-06-24 10:27:15.348130
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    assert r.render(object()) == Text(f"? /s", style="progress.data.speed")
    assert r.render(object()) == Text(f"? /s", style="progress.data.speed")
    rate = object()
    rate.speed = None
    assert r.render(rate) == Text(f"? /s", style="progress.data.speed")
    rate = object()
    rate.speed = 1024
    assert r.render(rate) == Text(f"1.0 K/s", style="progress.data.speed")
    rate = object()
    rate.speed = 2 ** 10
    assert r.render(rate) == Text(f"1.0 K/s", style="progress.data.speed")
    rate = object()
    rate.speed = 2 ** 20
    assert r

# Generated at 2022-06-24 10:27:19.534913
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich."""
    import time
    pbar = tqdm_rich(total=10)
    for i in range(10):
        pbar.update(1)
        time.sleep(0.1)
    pbar.close()

# Generated at 2022-06-24 10:27:21.148570
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        for i in t:
            t.clear()

# Generated at 2022-06-24 10:27:23.927031
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    t = tqdm_rich(range(10), ncols=20)
    t.update()
    t.clear()
    t.close()

# Generated at 2022-06-24 10:27:33.086243
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn"""
    class Task:
        def __init__(self, completed=0, total=0):
            self.completed = completed
            self.total = total

    task = Task(completed=10, total=100)
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert column.render(task) == Text("0.0/1.0 ", style="progress.download")

    task = Task(completed=10, total=100)
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column.render(task) == Text("0.0/0.1 ", style="progress.download")

    task = Task(completed=10, total=100)

# Generated at 2022-06-24 10:27:35.117092
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=100) as pbar:
        pbar.update(1)



# Generated at 2022-06-24 10:27:38.166566
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=10)
    for i in range(10):
        t.update()
    t.close()



# Generated at 2022-06-24 10:27:47.101618
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from collections import namedtuple
    Task = namedtuple('Task', 'completed total')

    fc_0 = FractionColumn()
    assert fc_0.render(Task(0, 5)) == Text('0/5 ', style='progress.download')
    assert fc_0.render(Task(1, 5)) == Text('1/5 ', style='progress.download')
    assert fc_0.render(Task(2, 5)) == Text('2/5 ', style='progress.download')
    assert fc_0.render(Task(3, 5)) == Text('3/5 ', style='progress.download')
    assert fc_0.render(Task(4, 5)) == Text('4/5 ', style='progress.download')

# Generated at 2022-06-24 10:27:50.781711
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=True)
    assert column.unit_scale is True
    assert column.unit_divisor is 1000
    assert str(column) == "<FractionColumn unit_scale=True unit_divisor=1000>"

# Generated at 2022-06-24 10:27:52.063379
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = FractionColumn()

# Generated at 2022-06-24 10:27:54.827177
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test if `tqdm.rich.tqdm.reset` works.
    """
    l = trange(0)
    assert l.total == 0
    l.reset(total=6)
    assert l.total == 6

# Generated at 2022-06-24 10:28:00.398466
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from time import time as time_
    from .utils import format_sizeof
    try:
        from rich.console import Console
    except ImportError:  # pragma: no cover
        Console = None

    if Console is not None:
        console = Console()

    # Test: disable
    with tqdm(total=9, disable=True) as pbar:
        for _ in range(9):
            pbar.update()
    with tqdm(disable=True) as pbar:
        for _ in range(9):
            pbar.update()

    # Test: enabled
    tstart = time_()
    with tqdm(total=9) as pbar:
        for _ in range(9):
            pbar.update()
    assert abs(pbar.last_print_t - time_()) < 0.

# Generated at 2022-06-24 10:28:07.347824
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    completed = 2
    total = 3
    column = FractionColumn(False)
    assert column.render({'completed': completed, 'total': total}) == Text(
        f"{completed}/{total} ",
        style="progress.download")


if __name__ == "__main__":  # pragma: no cover
    # This will start the tqdm GUI!
    for i in trange(10, desc="testing", unit="B", unit_scale=True, unit_divisor=1024, ascii=False, leave=False):
        pass

# Generated at 2022-06-24 10:28:16.964043
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn("/s").render({'speed': None}) == Text(f"? /s", style="progress.data.speed")
    assert RateColumn("/s").render({'speed': 100}) == Text(f"100.0 /s", style="progress.data.speed")
    assert RateColumn("/s", unit_scale=False).render({'speed': 100}) == Text(f"100.0 /s", style="progress.data.speed")
    assert RateColumn("/s", unit_scale=True).render({'speed': 100}) == Text(f"100.0 /s", style="progress.data.speed")
    assert RateColumn("/s", unit_scale=True, unit_divisor=1024).render({'speed': 100}) == Text(f"97.7 K/s", style="progress.data.speed")


# Generated at 2022-06-24 10:28:27.947455
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Test with unit_scale and unit_divisor
    scale_column = FractionColumn(unit_scale=True,unit_divisor=1000)
    assert(scale_column.unit_scale==True)
    assert(scale_column.unit_divisor==1000)
    # Test with unit_scale=False and unit_divisor
    scale_column = FractionColumn(unit_scale=False,unit_divisor=1000)
    assert(scale_column.unit_scale==False)
    assert(scale_column.unit_divisor==1000)
    # Test with unit_scale and unit_divisor=1024
    scale_column = FractionColumn(unit_scale=True,unit_divisor=1024)
    assert(scale_column.unit_scale==True)

# Generated at 2022-06-24 10:28:30.599077
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    assert tqdm_rich(disable=True)
    assert tqdm_rich(disable=False)
    assert tqdm_rich(disable=None)

# Generated at 2022-06-24 10:28:34.130520
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Unit test for method close of class tqdm_rich."""
    t1 = tqdm_rich(total=2, bar_format="{n_fmt}/{total_fmt}")
    t1.n = 2
    t1.close()

# Generated at 2022-06-24 10:28:35.497058
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    tqdm_rich(0).clear()

# Generated at 2022-06-24 10:28:38.148801
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as t:
        for i in t:
            t.update(1)
    assert t.n == t.total == 10

# Generated at 2022-06-24 10:28:38.678833
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    assert True

# Generated at 2022-06-24 10:28:48.313746
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    1. Test FractionColumn.render with unit_scale = False, unit_divisor = 1000

    2. Test FractionColumn.render with unit_scale = False, unit_divisor = 1000
    """
    # Test 1
    task = {
        "description": "Test description",
        "total": 1000,
        "completed": 200,
        "speed": 20
    }
    fraction_column_unit_scale_true = FractionColumn(unit_scale = True)
    fraction_column_unit_scale_false = FractionColumn(unit_scale = False, unit_divisor = 1000)
    fraction_column_unit_scale_true.render(task)
    fraction_column_unit_scale_false.render(task)

    # Test 2
    task["total"] = 200
    fraction_column_

# Generated at 2022-06-24 10:28:59.831420
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test whether tqdm_rich closes properly
    """
    import os

    def close():
        import os

        os.system('tput reset')


# Generated at 2022-06-24 10:29:04.135007
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test method clear of class tqdm_rich."""
    # Arrange
    import rich.progress
    progress = rich.progress.Progress("", transient=True)

    # Act
    with progress.start("Rich Progress") as task:
        task.update(1)
        task.clear()

    # Assert
    assert True

# Generated at 2022-06-24 10:29:08.816931
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import time
    with trange(4) as t:
        for i in t:
            assert i == t.n
            time.sleep(0.05)
            t.update()
    assert t.n == 4
    assert t.n == len(t)
    assert str(t) == '100%|██████████'

# Generated at 2022-06-24 10:29:14.504532
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class TaskMock:
        completed = (10 ** 2) * (10 ** 3)
        total = 2.3 * (10 ** 3)
    task_mock = TaskMock()
    assert FractionColumn().render(task_mock) == Text("10,000.0/2.30 K")


# Generated at 2022-06-24 10:29:23.013095
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    pc = FractionColumn()
    # assert pc.render(task={"completed":49, "total":100}) == "0.5/2.3 G"
    # assert pc.render(task={"completed":50, "total":100}) == "0.5/1 G"
    assert pc.render(task={"completed":50, "total":100}) == "0.5/1.0 G"
    assert pc.render(task={"completed":49, "total":100}) == "0.5/1.0 G"
    assert pc.render(task={"completed":8.2, "total":25.6}) == "0.3/0.1 G"
    # assert pc.render(task={"completed":1, "total":3}) == "0.3/2.0 M"


# Generated at 2022-06-24 10:29:26.646162
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10,
                   desc="Test",
                   unit="bytes",
                   unit_scale=True,
                   unit_divisor=1024) as pbar:
        for _ in range(10):
            pbar.update(1)

# Generated at 2022-06-24 10:29:33.784119
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from io import io
    from io import BytesIO as _BytesIO


    class BytesIO(_BytesIO):
        def isatty(self):
            return True


    io.IOBase.register(BytesIO)
    out = BytesIO()
    t = tqdm(range(10), total=10, file=out)
    t.clear()
    assert not out.getvalue()  # Assert that nothing has been printed

# Generated at 2022-06-24 10:29:38.329777
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    total = 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1000000
    unit, prefix = filesize.pick_unit_and_suffix(total, ["", "K", "M", "G", "T", "P", "E", "Z", "Y"], 1000)
    assert unit == 1000*1000*1000*1000*1000*1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 10
    assert prefix == "T"
    completed = 1024
    assert FractionColumn().render(completed, total, unit, prefix) == "0.0010/" + str(total/unit) + " " + prefix

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:29:41.596414
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    t = tqdm_rich(range(10))
    assert not hasattr(t, '_prog')
    t.close()

# Generated at 2022-06-24 10:29:50.364154
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from .std import tqdm
    from .std import trange
    from .std import tqdm_gui
    from .std import tgrange
    from .std import tqdm_notebook
    from .std import tnrange
    from .std import tqdm_pandas
    from .std import tpandas
    from .std import tqdm_gui
    from .std import tqdm_tex
    from .std import tqdm_pandas
    from .std import tqdm_std
    from .std import tqdm_monitor
    from .autonotebook import tqdm as tqdm_notebook
    from .autonotebook import trange as tnrange
    from .autonotebook import tqdm_pandas as tqdm_pandas

# Generated at 2022-06-24 10:29:54.486355
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    completed = 50
    total = 100
    fc = FractionColumn()
    assert fc.render(completed, total) == Text("50.0/100.0 ")

    completed = 2048
    total = 2048
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.render(completed, total) == Text("2.0/2.0 ")

    completed = 2048
    total = 2048
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(completed, total) == Text("2.0/2.0 ")

    completed = 1024
    total = 1024
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render

# Generated at 2022-06-24 10:30:02.741475
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Unit test for class tqdm_rich."""
    from tqdm.utils import _term_move_up
    with tqdm(total=10) as pbar:
        assert not pbar._prog.closed
        assert not pbar.disable
        assert pbar.gui

# Generated at 2022-06-24 10:30:12.782532
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test render method of FractionColumn class."""
    class TestProgress():
        """Test class."""

        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    task_completed_200 = TestProgress(completed=200, total=144)
    task_completed_50 = TestProgress(completed=50, total=60)
    task_completed_100 = TestProgress(completed=100, total=100)

    fcolumn = FractionColumn()
    assert '0.1/1.4 K' == fcolumn.render(task_completed_200).text
    assert '0.8/0.8 K' == fcolumn.render(task_completed_100).text

# Generated at 2022-06-24 10:30:23.151745
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task_1 = std_tqdm()  # task 1 for testing
    task_1.total = 1000
    task_1.n = 50
    task_1.unit = 'B'
    task_1.unit_scale = True
    task_1.unit_divisor = 1000
    task_1.last_print_n = None
    task_1.dynamic_ncols = False

    task_2 = std_tqdm()  # task 2 for testing
    task_2.total = 1000
    task_2.n = 50
    task_2.unit = 'B'
    task_2.unit_scale = True
    task_2.unit_divisor = 1024
    task_2.last_print_n = None
    task_2.dynamic_ncols = False

    task_

# Generated at 2022-06-24 10:30:29.009183
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    from rich.bar import IncrementalBar

    bar = IncrementalBar()
    task = Task("test", total=100, completed=50)
    fraction_column = FractionColumn(unit_scale=True)
    fraction_column.get_task_id = lambda: 0
    title = fraction_column.render(task)

    assert title.text == "50/100", "Test render FractionColumn"

# Generated at 2022-06-24 10:30:31.165316
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction_columnt = FractionColumn()
    assert fraction_columnt is not None


# Generated at 2022-06-24 10:30:38.329525
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # kwargs
    with tqdm_rich(desc="test_1") as t:
        assert t.disable is False
        assert t.ascii is False
    with tqdm_rich(desc="test_2", disable=True) as t:
        assert t.disable is True
        assert t.ascii is False
    with tqdm_rich(desc="test_3", gui=False) as t:
        assert t.disable is True
        assert t.ascii is False
    with tqdm_rich(desc="test_4", gui=True) as t:
        assert t.disable is False
        assert t.ascii is False
    with tqdm_rich(desc="test_5", disable=False) as t:
        assert t.disable is False
        assert t.ascii

# Generated at 2022-06-24 10:30:44.522037
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch
    tq = tqdm_rich(total=10, desc="Test display", position=0)
    tq.n = 0
    tq.display()
    tq.__exit__ = lambda a, b, c: False
    tq.__enter__ = lambda: False
    with patch('sys.stderr') as s:
        tq.close()

# Generated at 2022-06-24 10:30:53.096792
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert (RateColumn().render(std_tqdm(total=4)) == Text('? /s', style='progress.data.speed'))
    assert (RateColumn().render(std_tqdm(total=4, unit='')) == Text('? /s', style='progress.data.speed'))
    assert (RateColumn(unit='B').render(std_tqdm(total=4, unit='')) == Text('? B/s', style='progress.data.speed'))
    assert (RateColumn().render(std_tqdm(total=4, unit_scale=False)) == Text('? /s', style='progress.data.speed'))
    assert (RateColumn().render(std_tqdm(total=4, unit='')) == Text('? /s', style='progress.data.speed'))
   

# Generated at 2022-06-24 10:30:54.594733
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn.__init__(True, 1000) == None


# Generated at 2022-06-24 10:30:55.797502
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(object()) == '0.0/0.0'

# Generated at 2022-06-24 10:30:59.916837
# Unit test for function trange
def test_trange():
    """Test for trange()."""
    for _ in trange(10):
        pass


if __name__ == '__main__':  # pragma: no cover
    import sys
    from .std import _tqdm_test_script
    _tqdm_test_script(sys.argv)
    for i in trange(10):
        pass

# Generated at 2022-06-24 10:31:01.908264
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for n in tqdm_rich(range(4), desc="foo"):
        pass

# Generated at 2022-06-24 10:31:05.387096
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    import time
    t = tqdm_rich(["1", "2", "3"], total=4)
    t.clear()
    time.sleep(1)
    t.close()

# Generated at 2022-06-24 10:31:11.051520
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test method clear of class tqdm_rich."""
    import platform

    if platform.system() == "Windows":
        return

    with trange(10) as t:
        for i in t:
            t.clear()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_rich_clear()

# Generated at 2022-06-24 10:31:22.742950
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert FractionColumn().render_for_tests(None) == Text("0.0/0.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render_for_tests(5, 10) == Text("5.0/10.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render_for_tests(5, 7) == Text("0.0/0.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render_for_tests(10, 7) == Text("1.0/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render_for_tests(10, 3) == Text("3.3/3.3 ", style="progress.download")

# Generated at 2022-06-24 10:31:33.572520
# Unit test for function trange
def test_trange():
    it = trange(0, 1000.0, 100.0, miniters=2, mininterval=0.1,
                maxinterval=0.5, smoothing=0.1, unit='x', unit_scale=True,
                leave=True, ascii=False, file=None, desc=None, position=None,
                ncols=None, ncols_fraction=None, postfix=None,
                disable=False, dynamic_ncols=False, unit_divisor=1024,
                initial=0, miniters_to_switch_to_trange=None,
                slicer=None, total=None)
    for _ in it:
        pass
    it.close()


# Generated at 2022-06-24 10:31:42.118198
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Simple test that RateColumn's method render works correctly"""
    column = RateColumn()
    task = Progress()

    assert column.render(task) == Text("? B/s", style="progress.data.speed")

    task.speed = 1500
    assert column.render(task) == Text("1,500 B/s", style="progress.data.speed")

    task.speed = 1500*2**10
    assert column.render(task) == Text("1.5 KB/s", style="progress.data.speed")

    task.speed = 1500*2**20 # 1.43 MB/s
    assert column.render(task) == Text("1.4 MB/s", style="progress.data.speed")

# Generated at 2022-06-24 10:31:51.661464
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # normal case
    my_tqdm = tqdm_rich(total=3, desc='my_tqdm')
    my_tqdm.close()
    assert hasattr(my_tqdm, '_prog')

    # disable
    my_tqdm2 = tqdm_rich(total=3, desc='my_tqdm2', disable=True)
    my_tqdm2.close()
    assert not hasattr(my_tqdm2, '_prog')

    # no _prog
    my_tqdm3 = tqdm_rich(total=3, desc='my_tqdm2')
    del my_tqdm3._prog
    my_tqdm3.close()

# Generated at 2022-06-24 10:31:53.697182
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .tests import _test_tqdm_rich
    _test_tqdm_rich()



# Generated at 2022-06-24 10:31:57.665375
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    tc = fc.render({'total':1, 'completed':1})
    assert tc.text == '1.0/1.0 B'

# Generated at 2022-06-24 10:32:01.723510
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    message = "Rich is awesome!"
    with tqdm_rich(range(10), desc=message) as progress:
        time.sleep(0.1)
        assert progress.format_dict['desc'] == message
        progress.close()



# Generated at 2022-06-24 10:32:09.155853
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import TestCase, mock
    with mock.patch("tqdm.rich.tqdm_rich.update") as update:
        update.assert_called_once = False
        tqdm_rich(iterator=range(10))
        update.assert_called_once


if __name__ == "__main__":  # pragma: no cover
    import sys
    from urllib.request import urlopen  # noqa

    with tqdm(total=1000) as bar:
        bar.unit = "B"
        bar.unit_scale = True
        bar.unit_divisor = 1024

# Generated at 2022-06-24 10:32:12.448051
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_task = Progress(total=100)
    test_task.completed = 56
    test_FractionColumn = FractionColumn()
    assert test_FractionColumn.render(test_task) == "56.0/100"

# Generated at 2022-06-24 10:32:15.082227
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
  assert FractionColumn().render({'completed': 1, 'total': 2}) == Text('0.5/2.0 ', style='progress.douwnload')

# Generated at 2022-06-24 10:32:16.624998
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    for _ in tqdm(range(2)):
        pass


# Generated at 2022-06-24 10:32:18.507528
# Unit test for function trange
def test_trange():
    for _ in trange(4, 0, -1):
        pass
    assert _ == 0



# Generated at 2022-06-24 10:32:20.362895
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    f = FractionColumn()
    # [doc]
    assert hasattr(f, "render")



# Generated at 2022-06-24 10:32:28.209742
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import task
    task_desc = "test"
    task_completed = 1.23456789
    task_total = 9.87654321
    task_unit = 1000
    task_unit_scale = False
    task = task.Task(task_desc, task_completed, task_total)
    fraction_column = FractionColumn(task_unit_scale, task_unit)

    assert fraction_column.render(task) == Text(
        '1.2/9.9 ', style='progress.download')



# Generated at 2022-06-24 10:32:30.128553
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(2) as t:
        for x in t:
            continue

# Generated at 2022-06-24 10:32:32.053844
# Unit test for function trange
def test_trange():  # pragma: no cover
    l = trange(10)
    assert iter(l) == l
    assert next(l) == 0
    assert l.n == 0  # last initialised value

# Generated at 2022-06-24 10:32:36.227831
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm(range(10)):
        tqdm.reset(total=i)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:32:43.706048
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm._tqdm import StatusPrinter

    tqdm_test = tqdm_rich(total=1, smoothing=0.5, leave=False)
    assert isinstance(tqdm_test, StatusPrinter)
    tqdm_test.display()
    assert tqdm_test._task_id
    assert isinstance(tqdm_test._prog, Progress)
    tqdm_test.display()
    assert tqdm_test._prog.completed == 0.5
    tqdm_test.close()
    del tqdm_test

# Generated at 2022-06-24 10:32:47.621232
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn("b", unit_scale=False)
    assert column.render({'speed': 1}) == Text("5.0 b/s", style="progress.data.speed")
    column = RateColumn("KiB", unit_scale=True)
    assert column.render({'speed': 1024}) == Text("1.000 KiB/s", style="progress.data.speed")

# Generated at 2022-06-24 10:32:54.076999
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich."""

    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text

    # Setup a console and a progress bar.
    console = Console(record=True)
    progress = Progress(
        Text("[progress.description]{task.description}"),
        Text("[progress.percentage]{task.percentage:>4.0f}%"),
        BarColumn(bar_width=None),
        Text("["),
        Text(style="progress.time_remaining", text="{task.time_remaining}"),
        Text(", "),
        Text(style="progress.data.speed", text="{task.speed}/s"),
        Text("]"),
        transient=True,
    )

    # Save current console so it

# Generated at 2022-06-24 10:32:59.008274
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test FractionColumn.render function."""
    from rich import console
    console = console.Console()
    f = FractionColumn()
    assert (f.render({'completed': 1, 'total': 2}) == '1.0/2.0 ')
    assert (f.render({'completed': 502, 'total': 2534}) == '502.0/2,534.0 ')



# Generated at 2022-06-24 10:33:00.465808
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(1) as proto:
        pass
    return True

# Generated at 2022-06-24 10:33:03.809542
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=1000) as t:
        assert t.n == 0
        t.update(50)
        assert t.n == 50
        t.reset(total=500)
        assert t.n == 0
    assert t.n == 500



# Generated at 2022-06-24 10:33:06.281892
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(3):
        pass



# Generated at 2022-06-24 10:33:08.949088
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn(unit_divisor=2).unit_divisor == 2
    assert FractionColumn(unit_scale=1).unit_scale == 1

# Generated at 2022-06-24 10:33:19.278722
# Unit test for method render of class RateColumn

# Generated at 2022-06-24 10:33:22.605803
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm_rich(total=1000) as bar:
        for i in bar:
            pass
assert bar.n == 1000  # nosec


# Generated at 2022-06-24 10:33:24.203504
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    progress_bar = tqdm_rich(total=100, unit="B")
    progress_bar.close()

# Generated at 2022-06-24 10:33:27.721817
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import rich
    from rich.progress import Progress

    task = tqdm_rich(total=10)
    assert isinstance(task._prog, Progress)
    assert task._prog.tasks

    # check if the method display of class tqdm_rich throws an exception
    task.display()

# Generated at 2022-06-24 10:33:33.134198
# Unit test for constructor of class RateColumn
def test_RateColumn():

    # create object
    rate_column = RateColumn()

    # testing attributes
    assert rate_column.unit == ''
    assert rate_column.unit_scale is False
    assert rate_column.unit_divisor == 1000

    # create object
    rate_column = RateColumn(
        unit='/s',
        unit_scale=True,
        unit_divisor=1000
    )

    # testing attributes
    assert rate_column.unit == '/s'
    assert rate_column.unit_scale is True
    assert rate_column.unit_divisor == 1000


# Generated at 2022-06-24 10:33:35.061867
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    for i in tqdm_rich(range(10), desc="This is a test"):
        pass

# Generated at 2022-06-24 10:33:38.518880
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test case for method clear of class tqdm_rich."""
    # Instantiate a dummy tqdm_rich object
    tqdm_obj = tqdm_rich(disable=True)

    # Call method clear and check if it returns nothing
    assert tqdm_obj.clear() is None


# Generated at 2022-06-24 10:33:49.613271
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm(**{'desc': "hello", 'total': 1000000000, 'unit': 'B'})
    task.update()
    task.update(10)
    fc = FractionColumn()

    assert fc.render(task).text == '10/1,000,000,000 B'

    task.update(100000000)
    assert fc.render(task).text == '100/1,000,000,000 B'

    task.update(1000000000)
    assert fc.render(task).text == '1,000/1,000,000,000 B'

    task.update(50000000000)
    assert fc.render(task).text == '5,000/1,000,000,000 B'

    task.update(500000000000)

# Generated at 2022-06-24 10:33:52.342902
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(Progress(completed=1, total=1)) == Text("1.0/1.0 ", style="progress.download")

# Generated at 2022-06-24 10:33:55.841090
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn(unit_scale=False, unit_divisor=1000)
    for i in range(10):
        assert '{}/10'.format(i) == column.render(Progress(total=10, completed=i)).plain_text

# Generated at 2022-06-24 10:34:03.518346
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import copy
    try:
        import unittest
        from unittest.mock import patch, mock_open, MagicMock
    except ImportError:
        import unittest2 as unittest
        from mock import patch, mock_open, MagicMock

    from .std import tqdm
    from .utils import _range

    class Tests(unittest.TestCase):
        def setUp(self):
            self.int_range = _range(3)
            self.int_range_len = len(self.int_range)

# Generated at 2022-06-24 10:34:11.635230
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn()
    assert rc.unit == ""
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1000
    rc = RateColumn(unit='B')
    assert rc.unit == "B"
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1000
    rc = RateColumn(unit_scale=True)
    assert rc.unit == ""
    assert rc.unit_scale == True
    assert rc.unit_divisor == 1000
    rc = RateColumn(unit_divisor=1024)
    assert rc.unit == ""
    assert rc.unit_scale == False
    assert rc.unit_divisor == 1024

# Generated at 2022-06-24 10:34:18.912784
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    This can be tested directly via `python -m tqdm.rich`,
    but is also tested by `pytest tests/test_tqdm_rich.py::test_tqdm_rich_reset`.
    """
    import time
    from tqdm.auto import tqdm

    for i in tqdm(range(4), desc="1st loop"):
        for j in tqdm(range(3), desc="2nd loop"):
            for k in tqdm(range(40), desc="3rd loop", leave=False):
                time.sleep(0.01)

# Generated at 2022-06-24 10:34:29.587250
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    task = tqdm_rich(total=100)
    test = FractionColumn(unit_scale=True)
    assert test.render(task) == Text("0.0/1.0 ", style="progress.download")
    task = tqdm_rich(total=1000)
    test = FractionColumn(unit_scale=True)
    assert test.render(task) == Text("0.0/1.0 K", style="progress.download")
    task = tqdm_rich(total=100000)
    test = FractionColumn(unit_scale=True)
    assert test.render(task) == Text("0.0/100.0 K", style="progress.download")
    task = tqdm_rich(total=1000000)
    test = FractionColumn(unit_scale=True)
    assert test.render

# Generated at 2022-06-24 10:34:32.583284
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [0, None]:
        t = tqdm_rich(total=0)
        t.reset(total=total)
        t.close()


if __name__ == '__main__':
    _test()

# Generated at 2022-06-24 10:34:40.059418
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from .tests_tqdm import closing, UnicodeIO  # noqa

    with closing(UnicodeIO()) as our_file:
        progress = Progress()
        progress.console = our_file

        col = FractionColumn()
        col.append_to_progress(progress)

        task = progress.add_task("Test render", total=10**6, start=True)
        task.update(completed=0)
        assert u"[progress.download]    0.0/1.0 M" in our_file.getvalue()
        task.update(completed=10**6)
        assert u"[progress.download]    1.0/1.0 M" in our_file.getvalue()

        progress.console = None
        col.append_to_progress(progress)


# Generated at 2022-06-24 10:34:47.307169
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import datetime
    task = Progress.Task(
        description="Downlading",
        completed=1000,
        total=10000,
        start=datetime.datetime.now(),
    )
    t = FractionColumn(unit_scale=True)
    assert t.render(task) == Text("0.1/1.0 K")
    t = FractionColumn(unit_scale=False)
    assert t.render(task) == Text("1,000/10,000 ")
    t = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert t.render(task) == Text("0.1/1.0 K")


# Generated at 2022-06-24 10:34:51.957882
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Tests if the tqdm_rich method reset actually sets the total of the tqdm instance
    """
    t = tqdm_rich(total=10000, desc='test')
    t.update(5000)
    t.reset(total=20000)
    t.close()

# Generated at 2022-06-24 10:34:53.785936
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rc = RateColumn()
    assert rc.__class__.__doc__ == "Renders human readable transfer speed."

# Generated at 2022-06-24 10:35:02.020861
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    """
    Unit tests for constructor of class tqdm_rich.
    """
    from .collections import tqdm_obj
    from .std import _unicode

    for __ in tqdm_rich(["a", "b", "c"],
                        bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]"):
        pass
    for __ in tqdm_rich(["a", "b", "c"],
                        bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]",
                        disable=True):
        pass

# Generated at 2022-06-24 10:35:04.849764
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    obj = FractionColumn()
    assert obj.unit_scale == False, "Expected False"
    assert obj.unit_divisor == 1000, "Expected 1000"


# Generated at 2022-06-24 10:35:08.391129
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich
    except:
        raise ImportError('install rich to perform this test')
    with tqdm(total=3, desc='description', dynamic_ncols=True) as t:
        t.clear()

if __name__ == "__main__":
    test_tqdm_rich_clear()

# Generated at 2022-06-24 10:35:12.701429
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    t = tqdm_rich(0)
    t.reset(10); t.update(0)
    t.close()


# Methods for unit tests:

# Generated at 2022-06-24 10:35:22.288717
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test for method display of class tqdm_rich."""
    import unittest
    import sys
    import os
    import time
    from io import StringIO
    from contextlib import redirect_stdout

    class TqdmRichTest(unittest.TestCase):
        """Unit test for method display of class tqdm_rich."""

        def test_tqdm_rich_display(self):
            """Unit test for method display of class tqdm_rich."""
            sys.stdout = StringIO()
            rich_bar = tqdm_rich(total=2)
            with redirect_stdout(sys.stdout):
                rich_bar.display()
                rich_bar.update()
            self.assertEqual(
                sys.stdout.getvalue(),
                os.linesep)
            sys

# Generated at 2022-06-24 10:35:32.533768
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    This tests the method render(self, task) of class tqdm.rich.FractionColumn
    """
    import tqdm
    import rich.progress
    maxInt = 2 ** 32

    # Testing with rate_fmt = None
    c = FractionColumn()
    assert(c.render(rich.progress.Task(maxInt - 1, maxInt)) == Text(
        "4,294,967,295/4,294,967,295 ", style="progress.download"))

    # Testing when completed_value = 0
    assert(c.render(rich.progress.Task(0, maxInt)) == Text(
        "0.0/4,294,967,295 ", style="progress.download"))

    # Testing when completed_value = maxInt - 1