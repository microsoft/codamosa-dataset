

# Generated at 2022-06-24 10:25:34.090197
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(10) as t:
        t.display()

# Generated at 2022-06-24 10:25:42.778195
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import rich._progress as prog
    from rich.console import Console
    from rich.progress import Progress, ProgressColumn
    from rich.progress import TaskID

    prog._console = Console()
    prog._console._print("")
    prog._console = Console()
    prog._console._print("")
    task = TaskID("")
    task.completed = 0
    task.total = 0
    FractionColumn().render(task)
    FractionColumn(unit_scale=True, unit_divisor=1000).render(task)
    FractionColumn(unit_scale=False, unit_divisor=1000).render(task)
    FractionColumn(unit_scale=True, unit_divisor=1024).render(task)
    FractionColumn(unit_scale=False, unit_divisor=1024).render(task)


# Generated at 2022-06-24 10:25:43.440533
# Unit test for constructor of class RateColumn
def test_RateColumn():
    print(RateColumn())

# Generated at 2022-06-24 10:25:48.989442
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """TODO: put into module utils and better test coverage."""
    rate_column = RateColumn(unit='B', unit_scale=False)
    task = ProgressTask(total=10, completed=0, speed=1)
    rate_column.render(task) == '1.0 B/s'

# Generated at 2022-06-24 10:25:52.083262
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    assert hasattr(tqdm_rich(), "_prog")
    assert not hasattr(tqdm_rich("default"), "_prog")
    assert not hasattr(tqdm_rich("default", disable=None), "_prog")

# Generated at 2022-06-24 10:25:52.700562
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    pass

# Generated at 2022-06-24 10:26:00.900620
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    columns = (
        "[",
        TimeElapsedColumn(),
        ",",
        RateColumn(unit_scale=True, unit_divisor=1000),
        "]"
    )
    progress = Progress(*columns, transient=False)

    task = progress.add_task("Task", total=100, unit="B")
    # Initialize the rate with a value larger than the divisor
    progress.update(task, n=100, rate=100000)

    # Check that the speed is reset to an invalid value
    progress.update(task, n=0, rate=None)

if __name__ == '__main__':
    test_RateColumn_render()

# Generated at 2022-06-24 10:26:03.183026
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with trange(1) as t:
        t.refresh()  # TODO: does nothing

# Generated at 2022-06-24 10:26:06.851878
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(4):
        pass
    for _ in trange(1, 4):
        pass
    for _ in trange(1, 4, 0.5):
        pass



# Generated at 2022-06-24 10:26:14.878578
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    t = tqdm_rich(total=1)
    t.close()


if __name__ == "__main__":
    # Test and demo
    import time
    from rich.progress import Progress

    with Progress() as prog:
        task_id = prog.add_task("Root", total=2, start=False)
        with prog.add_task("Child", total=1, start=False) as child:
            for i in tqdm_rich(range(1, 500), desc="Loop Test"):
                time.sleep(0.001)
                child.update(i)
                prog.update(task_id)

# Generated at 2022-06-24 10:26:17.889721
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # preliminary tests to ensure that method clear of class tqdm_rich does not generate errors
    from unittest import TestCase
    class TestTqdmRichClear(TestCase):
        def test_clear_tqdm_rich(self):
            for i in tqdm_rich(range(2)):
                self.assertIsNotNone(tqdm_rich.clear)

# Generated at 2022-06-24 10:26:30.185842
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest import TestCase

    # define class TqdmRichReset
    class TqdmRichReset(TestCase):
        """ Unit test for method reset of class tqdm_rich"""

# Generated at 2022-06-24 10:26:38.834764
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import rich.console
    console = rich.console.Console()
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False,
                        unit_divisor=1000), "]",
        transient=False
    )
    progress.__enter__()
    task_id = progress.add_task('test', total=100)
    for i in range(100):
        progress.update(task_id, completed=i+1)
    progress.__exit

# Generated at 2022-06-24 10:26:45.901602
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render({'completed': 0, 'total': 1}) == \
        ('0.0/1.0 ', 'progress.download')
    assert FractionColumn().render({'completed': 0.5, 'total': 2.3}) == \
        ('0.5/2.3 ', 'progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(
            {'completed': 0.5, 'total': 2.3}) == \
        ('0.5/2.3 ', 'progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(
            {'completed': 1024, 'total': 1048576}) == \
        ('1.0/1.0 K', 'progress.download')

# Generated at 2022-06-24 10:26:57.197860
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for i in tqdm_rich(range(2)):
        assert i == 0
        break
    for i in tqdm_rich(range(2)):
        assert i == 0
        break
        # Check if reset total doesn't raise
    tqdm_rich(range(2)).reset(total=1)
    # Check if reset of unknown total doesn't raise
    tqdm_rich(range(2), total=None).reset(total=1)
    # Check if reset of unknown total doesn't raise
    tqdm_rich(range(2), total=None).reset()
    # Check if reset with no iteration doesn't raise
    tqdm_rich(range(2)).reset(total=1)
    # Check if reset total doesn't raise
    tqdm_rich(range(2)).reset(total=1)

# Generated at 2022-06-24 10:27:05.461076
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from .gui import tqdm_gui
    from .gui import tgrange
    from .gui import trange as tgtrange

    for cls in [tqdm_gui, tqdm_rich]:
        for func in [cls, cls.write, tgrange, tgtrange]:
            with func(range(3), unit='B', unit_scale=True, unit_divisor=1024) as t:
                time.sleep(1.1)
                func.write(t, 'hello world')
                t.update(1)

# Generated at 2022-06-24 10:27:09.042864
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert str(RateColumn(unit_scale=True)) == "0 B/s"
    assert str(RateColumn(unit_scale=False)) == "0 /s"


# Generated at 2022-06-24 10:27:11.089684
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    x = tqdm_rich(total=20)
    while x.n < 20:
        x.update(2)

# Generated at 2022-06-24 10:27:12.505748
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    # TODO: Implement tests for tqdm_rich_close
    assert False

# Generated at 2022-06-24 10:27:19.210339
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit="B", unit_scale=True,
                             unit_divisor=1000)
    # Test for speed == None case
    assert rate_column.render(Progress(speed=None)) == Text(f"? B/s", style="progress.data.speed")
    # Test for speed != None case and unit_scale==True
    assert rate_column.render(Progress(speed=5.55*10**5)) == Text(f"555.0 KB/s", style="progress.data.speed")

# Generated at 2022-06-24 10:27:24.180918
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test rich version of trange"""
    from time import sleep

    bar = trange(10)
    assert bar.total == 10
    assert bar.n == 0
    for _ in bar:
        sleep(0.2)


if __name__ == '__main__':  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:27:27.866429
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import TaskID

    progress_column = FractionColumn()
    task = TaskID(completed=1, total=2, speed=2)

    rendered = progress_column.render(task)
    assert rendered.text == "0.5/2.0 "

# Generated at 2022-06-24 10:27:29.354367
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test if method clear of class tqdm_rich is callable."""
    tqdm_rich(10).clear()

# Generated at 2022-06-24 10:27:32.016137
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert repr(FractionColumn(unit_scale=True, unit_divisor=1000)) == \
        "FractionColumn(unit_scale=True, unit_divisor=1000)"


# Generated at 2022-06-24 10:27:38.938495
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    v = tqdm_rich(total=1)
    v.reset()
    assert v.n == 0
    v.reset(total=2)
    assert v.n == 0
    assert v.total == 2
    v.reset(total=100)
    assert v.n == 0
    assert v.total == 100
    v.reset(total=8)
    assert v.n == 0
    assert v.total == 8

# Generated at 2022-06-24 10:27:39.905643
# Unit test for constructor of class RateColumn
def test_RateColumn():
    progress = RateColumn(unit_scale=True)
    assert progress.unit_scale == True

# Generated at 2022-06-24 10:27:46.845538
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import unittest

    class tqdm_rich_reset(unittest.TestCase):
        def test_tqdm_rich_reset(self):
            from tqdm.rich import tqdm_rich
            pbar = tqdm_rich(_range(3), desc='foo')
            self.assertEqual(pbar.__len__(), 3)
            self.assertEqual(pbar.desc, 'foo')
            pbar.reset(total=4)
            self.assertEqual(pbar.__len__(), 4)
            self.assertEqual(pbar.desc, 'foo')

    unittest.main()

# Generated at 2022-06-24 10:27:48.141137
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=10)
    t.close()

# Generated at 2022-06-24 10:27:56.054091
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 17250
    unit = 1000
    suffix = ["", "K", "M", "G", "T", "P", "E", "Z", "Y"]
    rate_column = RateColumn(unit_scale=True, unit_divisor=unit)
    assert rate_column.render(speed) == Text('\x1b[38;5;250m'
                                             + f"{speed/unit:,.0f} {suffix[1]}/s"
                                             + '\x1b[0m',
                                             style='progress.data.speed')



# Generated at 2022-06-24 10:27:58.876892
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn()
    task = fraction_column.render(progress_object)
    assert task.get_text() == "0/0"


# Generated at 2022-06-24 10:28:05.321848
# Unit test for function trange
def test_trange():
    """Test for function trange."""
    for _ in trange(4):
        pass

    for _ in trange(4, 1, -1):
        pass

    for _ in trange(1, 4):
        pass

    for _ in trange(1, 4, 0.5):
        pass

    for _ in trange(1, 4, 1):
        pass

    for _ in trange(1, 4, None):
        pass


test_trange()

# Generated at 2022-06-24 10:28:07.741326
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    f = FractionColumn()
    class Task:
        completed = 192
        total = 1024
    assert f.render(Task) == Text("0.2/1.0 K")

# Generated at 2022-06-24 10:28:09.984194
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    f = tqdm_rich([0,1,2,3])
    f.close()

# Generated at 2022-06-24 10:28:12.702092
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from nose.tools import assert_raises
    with assert_raises(AttributeError):
        tqdm = tqdm_rich(range(10)).clear()

# Generated at 2022-06-24 10:28:24.574818
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert FractionColumn().render(Progress(total=200)).text == '0.0/2.0 K'
    assert FractionColumn(unit_scale=True).render(Progress(total=10000)).text == '0.0/10.0 K'
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=8700)).text == '0.0/8.4 K'
    assert FractionColumn(unit_scale=True).render(Progress(total=8700)).text == '0.0/8.7 K'
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=10000)).text == '0.0/9.8 K'

# Generated at 2022-06-24 10:28:25.778902
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    assert hasattr(tqdm_rich, "close")

# Generated at 2022-06-24 10:28:30.937886
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    from __main__ import tqdm as main_tqdm
    try:
        for _ in main_tqdm(range(0)):
            main_tqdm.clear()
    except Exception as e:
        assert str(e) == "main_tqdm.clear() is not supported. Use tqdm_notebook, or tqdm_gui() instead."

# Generated at 2022-06-24 10:28:33.680847
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_FractionColumn = FractionColumn(unit_scale=False, unit_divisor=1000)
    assert test_FractionColumn.unit_scale == False
    assert test_FractionColumn.unit_divisor == 1000


# Generated at 2022-06-24 10:28:37.237548
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import types
    import tqdm
    import rich
    test = tqdm.tqdm_rich(0, 0)
    if type(test.display) is types.MethodType:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:28:46.634614
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm import trange
    import time
    # Test close of bar.
    with trange(10) as t:
        for i in t:
            time.sleep(0.1)
    # Test close after reaching 100 percent completion of bar.
    with trange(10) as t:
        for i in t:
            time.sleep(0.1)
            if i == 9:
                break
        t.update(10)
    # Test close without reaching 100 percent completion of bar.
    with trange(10) as t:
        for i in t:
            time.sleep(0.1)
            if i == 5:
                break
        t.update(10)
    # Test close of bar when `leave` set to True

# Generated at 2022-06-24 10:28:57.914134
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test for FractionColumn.render()."""
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(task=None) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(task=Progress(total=None, completed=0, speed=0)) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="", unit_scale=False, unit_divisor=1000).render(task=Progress(total=None, completed=0, speed=None)) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-24 10:29:03.774683
# Unit test for function trange
def test_trange():
    from . import tqdm
    for i in trange(9, desc='A loop'):
        # Do some work
        pass
    # Check the first and last values are correct
    assert i == 8
    try:
        for i in trange(5):
            raise ValueError("Error")
    except ValueError:
        pass
    else:
        assert False

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:29:05.097841
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        for i in trange(10):
            pass
    except KeyboardInterrupt:
        raise AssertionError("should not raise KeyboardInterrupt error")

# Generated at 2022-06-24 10:29:06.017720
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    columns = FractionColumn()
    assert columns is not None

# Generated at 2022-06-24 10:29:07.276306
# Unit test for function trange
def test_trange():
    for _ in trange(4, 0, -1):
        pass

# Generated at 2022-06-24 10:29:09.801093
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate = RateColumn(unit="data", unit_scale=False, unit_divisor=1000)
    assert rate.render(object()) == Text("? data/s", style="progress.data.speed")

# Generated at 2022-06-24 10:29:14.653635
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test :class: `FractionColumn`
    """
    number = 42.696
    result = FractionColumn().render(number)
    expected = Text("42.7/42.7  ", style="progress.download")
    assert result == expected

# Generated at 2022-06-24 10:29:18.735889
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    # Test on instance of bar class
    bar = tqdm_rich(total=1000)
    bar.n = 100
    progress = FractionColumn()
    assert progress.render(bar) == Text(
        "0/10.0 ",
        style="progress.download")
    bar.close()


# Generated at 2022-06-24 10:29:20.241513
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn(unit="k")
    RateColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-24 10:29:26.251919
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from .std import tqdm as std_tqdm
    import io
    from contextlib import redirect_stdout
    f = io.StringIO()
    try:
        with redirect_stdout(f):
            for i in tqdm_rich(range(10)):
                pass
    except (UnicodeEncodeError,) if std_tqdm.IS_PYTHON2 else ():
        pass
    try:
        with redirect_stdout(f):
            for i in tqdm_rich(range(10), disable=True):
                pass
    except (UnicodeEncodeError,) if std_tqdm.IS_PYTHON2 else ():
        pass

# Generated at 2022-06-24 10:29:29.982141
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    frac_col = FractionColumn()
    assert frac_col.render('task') == Text('0.0/0.0 ', style='progress.download')



# Generated at 2022-06-24 10:29:37.427600
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Unit test for function constructor of class FractionColumn."""
    assert FractionColumn(unit_scale=True, unit_divisor=None).unit_scale == True
    assert FractionColumn(unit_scale=False, unit_divisor=None).unit_scale == False
    assert FractionColumn(unit_scale=False, unit_divisor=1000).unit_divisor == 1000
    assert FractionColumn(unit_scale=False, unit_divisor=None).unit_divisor == 1000


# Generated at 2022-06-24 10:29:43.177538
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    task = Task(completed=10, total=9)
    test = FractionColumn(unit_scale=True, unit_divisor=1000).render(task)
    assert test.text == "1.1/9.9 "

# Generated at 2022-06-24 10:29:45.252886
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=1)
    t.close()


# Generated at 2022-06-24 10:29:46.532039
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for _ in tqdm_rich(range(2)):
        pass

# Generated at 2022-06-24 10:29:48.376327
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()
        t.clear()

# Generated at 2022-06-24 10:29:51.468599
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(object) == Text(f"0/0 ", style="progress.download")

# Generated at 2022-06-24 10:29:59.370144
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    _task = std_tqdm(total=100)
    _task.speed = 1000.0
    _task.desc = "Download"
    _task.unit = "bytes"

    progress = Progress(
        "[progress.description]{task.description}",
        FractionColumn(),
        BarColumn(bar_width=None),
        RateColumn(unit=_task.unit),
        TimeRemainingColumn(),
        transient=True)
    progress.__enter__()
    task = progress.add_task("Download", completed=50)
    progress.update(task, speed=1000.0)
    progress.__exit__(None, None, None)

# Generated at 2022-06-24 10:30:04.306426
# Unit test for function trange
def test_trange():  # pragma: no cover
    try:
        from unittest import mock
    except ImportError:
        from unittest.mock import mock

    with mock.patch('tqdm.std.tqdm', tqdm_rich):
        a = trange(3)
        next(a)

# Generated at 2022-06-24 10:30:08.852822
# Unit test for function trange
def test_trange():
    """Test function ``trange``."""
    # pylint: disable=missing-docstring
    with trange(3) as t:
        assert isinstance(t, tqdm_rich)
        for _i in t:
            pass
        assert t.n == 3


# Generated at 2022-06-24 10:30:16.865584
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.text import Text
    from tqdm.rich import RateUnit
    from time import time

    progress = Progress(
        Text("[progress.description]{task.description}", " ["),
        BarColumn(),
        Text("] {task.completed:>6.1%}", style="bold blue"),
        " < [",
        TimeElapsedColumn(),
        " ",
        TimeRemainingColumn(),
        "] [",
        FractionColumn(),
        " ",
        RateColumn(),
        "]",
    )

    with progress:
        task = progress.add

# Generated at 2022-06-24 10:30:22.729314
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    for disable in [False, True]:
        for n in [0, 1, 2, 3]:
            for desc in [None, 'desc']:
                tqdm_rich(disable=disable, total=3).update(n=n, desc=desc)
                tqdm_rich(desc, disable=disable, total=3).update(n=n)
                tqdm_rich(desc, disable=disable, total=3).update(n=n,
                                                                  desc=desc)

# Generated at 2022-06-24 10:30:28.617249
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    '''Unit test for the constructor of class tqdm_rich.'''
    import sys
    for _ in tqdm_rich(range(10), file=sys.stdout, mininterval=0.01):
        pass
    for _ in tqdm_rich(range(10), file=sys.stdout):
        pass


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_rich()

# Generated at 2022-06-24 10:30:36.965628
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    import os
    import time

    def sleep(n=0.01):
        time.sleep(n)

    sys.stderr = sys.stdout  # make the example progress bar not get stuck
    sys.stderr.write("\n\nA TQDM EXAMPLE:\n")
    with tqdm(total=300) as pbar:
        for i in _range(300):
            sleep()
            pbar.update(1)
    sys.stderr.write("\n\nA TDQM EXAMPLE WITH FILE-LIKE OBJECT:\n")
    with open(os.devnull, 'w') as fd, \
            tqdm(total=300, file=fd) as pbar:
        for i in _range(300):
            sleep()
            pbar

# Generated at 2022-06-24 10:30:46.210530
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    it = tqdm_rich(total=0, desc='Test', unit='B', unit_scale=True, bar_format='{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{unit_divisor}{unit}]')
    it.reset(total=2)
    assert it.total == 2, "1st reset"
    it.reset()
    assert it.total == 2, "2nd reset"
    it.reset(total=3)
    assert it.total == 3, "3rd reset"



# Generated at 2022-06-24 10:30:49.194988
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10, unit="B", unit_scale=True, unit_divisor=1000) as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-24 10:30:53.158555
# Unit test for constructor of class RateColumn
def test_RateColumn():
    bar = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert bar.unit == "B"
    assert bar.unit_scale == True
    assert bar.unit_divisor == 1024


# Generated at 2022-06-24 10:30:55.757684
# Unit test for function trange
def test_trange():
    """Test for trange function."""
    list(trange(4))

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:30:57.007973
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert str(column) == "FractionColumn"

# Generated at 2022-06-24 10:31:04.245780
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    t = tqdm_rich(range(10000), unit=' K', unit_scale=True, miniters=1,
        total=6000, desc='test', bar_format=str(FractionColumn()))
    assert t.format_dict == {'bar_format': '{l_bar}{bar}| {n_fmt}/{total_fmt} {postfix}',
                             'total': 6000,
                             'unit': ' K',
                             'unit_scale': True,
                             'unit_divisor': 1000,
                             'ncols': 80}
    assert t.desc == "test"
    assert t.miniters == 1
    assert t._last_print_n == 0
    assert t.last_print_t is None
    # TODO: handle this exception in a better way


# Generated at 2022-06-24 10:31:11.418793
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    # Warning: this test was not designed to work in parallel execution e.g. -n auto
    try:
        with tqdm_rich(total=20, desc="foo", leave=True) as pbar:
            pbar.clear()
            pbar.n = 10
            pbar.display()
            assert pbar.n == 10
    finally:
        try:
            pbar._prog.__exit__(None, None, None)
        except Exception:
            pass



# Generated at 2022-06-24 10:31:12.177170
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    pass

# Generated at 2022-06-24 10:31:13.507823
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(range(3)) as t:
        pass

# Generated at 2022-06-24 10:31:18.213047
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    class_instance = FractionColumn()
    assert isinstance(class_instance, FractionColumn)
    assert isinstance(class_instance, ProgressColumn)
    assert class_instance.unit_scale is False
    assert class_instance.unit_divisor == 1000

# Generated at 2022-06-24 10:31:21.245669
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=100) as progress:
        progress.reset(total=50)
    assert progress.total == 50, "Problem with method 'reset'."

# Generated at 2022-06-24 10:31:23.857564
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    p = tqdm_rich(range(10), desc="Test", mininterval=0)
    p.update(8)
    p.close()



# Generated at 2022-06-24 10:31:30.906447
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():

    from .utils import format_dict, format_meter
    from .tqdm import tqdm

    task_id = 0

    def _format_dict(n):
        fmt = format_dict(n)
        fmt['total'] = int(fmt['total'])
        fmt['n'] = int(fmt['n'])
        return fmt

    class MockTask:
        pass

    class MockProgress:
        def get_task(self, i):
            task = MockTask()
            fmt = _format_dict(i)
            task.__dict__.update(fmt)
            return task

    # Test with only int and total > 1000
    task_id = task_id + 1
    columns = [FractionColumn()]
    progress = MockProgress()

# Generated at 2022-06-24 10:31:33.426076
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    t = FractionColumn()
    assert t.unit_scale == False
    assert t.unit_divisor == 1000


# Generated at 2022-06-24 10:31:36.310504
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn(unit="B")
    assert rate_column.unit == "B"

# Generated at 2022-06-24 10:31:43.348706
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn()
    assert fc.render(None) == Text('0.0/0.0 ', style='progress.download')

    fc = FractionColumn(unit_scale=True)
    assert fc.render(None) == Text('0.0/0.0 ', style='progress.download')

    fc = FractionColumn(unit_scale=False)
    assert fc.render(None) == Text('0.0/0.0 ', style='progress.download')

    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.render(None) == Text('0.0/0.0 ', style='progress.download')

    fc = FractionColumn(unit_scale=False, unit_divisor=1024)
    assert fc.render

# Generated at 2022-06-24 10:31:45.337790
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass



# Generated at 2022-06-24 10:31:48.552590
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total = 10)
    r = RateColumn()
    r.render(task)
    task.close()



# Generated at 2022-06-24 10:31:50.244734
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=2, desc="test")
    t.close()
    assert not t.disable

# Generated at 2022-06-24 10:31:57.521874
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from .std import trange
    from .std import tqdm
    for speed in [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]:
        rate_column = RateColumn("B", unit_scale=True, unit_divisor=1000)
        rate_column.render(TaskID(completed=speed*10, total=speed*100, speed=speed))

# Generated at 2022-06-24 10:32:06.673194
# Unit test for function trange
def test_trange():
    """Unit test for function `trange` and `tqdm`"""
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .utils import _range

    for iter_range in ((0, 1), list(range(0, 1))):
        for iterable in (
            list(range(*iter_range)),
            list(std_trange(*iter_range)),
            std_tqdm(*iter_range),
            tqdm(*iter_range),
            trange(*iter_range),
            _range(*iter_range),
        ):
            n_iter = 0
            if isinstance(iterable, std_tqdm):
                iterable.close()

# Generated at 2022-06-24 10:32:12.622284
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .gui import tqdm_notebook
    from time import sleep

    for cls in (tqdm, tqdm_notebook):
        with cls(total=10, leave=True) as pbar:
            for i in range(5):
                pbar.update()
            pbar.reset(total=5)
            for i in range(5):
                pbar.update()
            sleep(0.5)

# Generated at 2022-06-24 10:32:20.172959
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich
    except ImportError:
        return None

    with tqdm_rich(total=None, leave=True) as _:
        pass

    with Progress('Testing class tqdm_rich', transient=True) as progress:
        task_id = progress.add_task('Test tqdm_rich clear', total=None)
        tqdm_rich(total=None, leave=True, bar_format='{desc}',
                  desc=progress.format(task_id), progress=progress)
        progress.remove_task(task_id)

# Generated at 2022-06-24 10:32:28.606390
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task_1 = Task(total=1500000000, completed=150000000, description="test_1")
    task_2 = Task(total=1500000000, completed=150000000, description="test_2")
    task_3 = Task(total=1500000000, completed=150000000, description="test_3")
    column_1 = FractionColumn(unit_scale=False)
    column_2 = FractionColumn(unit_scale=False, unit_divisor=1000)
    column_3 = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column_1.render(task_1) == Text(
        '150,000,000/1,500,000,000 ', style='progress.download'), \
        "Unexpected output"

# Generated at 2022-06-24 10:32:33.701174
# Unit test for function trange
def test_trange():
    # Gives the same results as xrange
    from distutils.version import LooseVersion
    from platform import python_version
    assert tuple(trange(5)) == tuple(_range(5))
    if LooseVersion(python_version()) >= LooseVersion('3'):
        assert tuple(trange(5)) == tuple(range(5))

# Preventing subprocess call of tqdm in `if __name__ == '__main__':`



# Generated at 2022-06-24 10:32:44.766853
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = 0
    RateColumn_unit = ""
    RateColumn_unit_scale = False
    RateColumn_unit_divisor = 1000
    RateColumn_ = RateColumn(RateColumn_unit, RateColumn_unit_scale,
                             RateColumn_unit_divisor)
    assert RateColumn_.render(speed) == "0.0 /s"
    speed = 1e9
    RateColumn_unit = "bps"
    RateColumn_unit_scale = True
    RateColumn_unit_divisor = 1000
    RateColumn_ = RateColumn(RateColumn_unit, RateColumn_unit_scale,
                             RateColumn_unit_divisor)
    assert RateColumn_.render(speed) == "1.0 Gbps"
    speed = None
    RateColumn_unit = "B"

# Generated at 2022-06-24 10:32:46.309843
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    iterable = range(100)
    iterable_len = len(iterable)
    t = tqdm(iterable)
    for _ in t:
        pass
    t.close()
    # If the progress bar is not displayed, the test will pass

# Generated at 2022-06-24 10:32:49.486601
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        import rich
    except ImportError:
        warn("rich is not installed: skipping rich tests.", TqdmExperimentalWarning,
             stacklevel=2)
        return

    # instantiate tqdm_rich
    t_bar = tqdm_rich(range(5))
    t_bar.clear()

# Generated at 2022-06-24 10:32:52.817443
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as t:
        t.clear()
        assert t._prog.tasks is not None


# Generated at 2022-06-24 10:32:56.783578
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    import random

    total = random.randint(1, 100)
    with tqdm_rich(total=total) as pbar:
        assert pbar.total == total
        total = random.randint(1, 100)
        pbar.reset(total=total)
        assert pbar.total == total

# Generated at 2022-06-24 10:33:04.738175
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    from rich.text import Text
    from rich.panel import Panel
    from rich.console import Console

    console = Console()
    progress = Progress("[bold]{task.description}", BarColumn())
    task = progress.add_task("Loading")
    progress.__enter__()
    progress.render(console, 0)
    progress.__exit__(None, None, None)
    try:
        progress.render(console, 0)
    except TypeError:
        print("Rendering when the progress bar is closed is not allowed.")


if __name__ == '__main__':
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:33:12.183352
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test for method render of class FractionColumn.
    """
    from rich.console import Console
    from rich.progress import TaskID

    fc = FractionColumn()
    task_id = TaskID(total=100)
    fc.update(task_id, completed=50)
    console = Console()
    console.print(fc)
    assert console.output == '[progress.download]0.5/1.0 \n'



# Generated at 2022-06-24 10:33:21.754228
# Unit test for function trange
def test_trange():  # pragma: no cover
    with trange(2) as t:
        assert isinstance(t, tqdm_rich)
    with trange(1, 2) as t:
        assert isinstance(t, tqdm_rich)
    with trange(1, 2, 1) as t:
        assert isinstance(t, tqdm_rich)
    with trange(1, 2, 1, 1) as t:
        assert isinstance(t, tqdm_rich)
    with trange(1, 2, 1, 1, 1) as t:
        assert isinstance(t, tqdm_rich)

# Generated at 2022-06-24 10:33:29.082370
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import rich.progress
    import rich.panel
    progress = rich.progress.Progress()
    progress.add_task('now downloading...',
                      start=0, end=100, total=100, completed=0, description='now downloading...', style_completed=rich.progress.Progress.STYLE_COMPLETED, style_remaining=rich.progress.Progress.STYLE_REMAINING, console=rich.panel.Panel(), bar_style=rich.style.Style(base='progress.bar.download', reverse=True), speed=None)
    task = progress.tasks[0]
    rate_column = RateColumn()
    assert rate_column.render(task) == rich.text.Text(text='? /s', style='progress.data.speed')

# Generated at 2022-06-24 10:33:33.078184
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    for total in [None, 1000]:
        with tqdm_rich(total=total) as pbar:
            assert pbar._prog._tasks[pbar._task_id].total == total
            pbar.reset()
            assert pbar._prog._tasks[pbar._task_id].total == 0
            pbar.reset(total=total)
            assert pbar._prog._tasks[pbar._task_id].total == total

# Generated at 2022-06-24 10:33:40.913972
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .utils import _supports_unicode
    from rich.console import Console
    from rich.table import Table

    table = Table(title="Processing Files")
    table.add_column("Files", justify="right", style="cyan")
    table.add_column("Size")
    row = table.add_row("Test File 1", filesize.format(1024))
    row.add_color("[bright_red]")
    row = table.add_row("Test File 2", filesize.format(2048))
    row.add_color("[bright_yellow]")
    row = table.add_row("Test File 3", filesize.format(3072))
    row.add_color("[bright_green]")
    table.add_row("Test File 4", filesize.format(4096))

# Generated at 2022-06-24 10:33:46.411428
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """Unit test of tqdm_rich.display method"""
    def run():
        """Run the tqdm_rich object"""
        with tqdm_rich(total=10) as t:
            for i in _range(10):
                t.update()

    run()

# Generated at 2022-06-24 10:33:56.248023
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test ``Progress.update()`` with ``clear=False`` option"""
    for leave in [True, False]:
        for desc in ["desc1", "desc2"]:
            for total in [None, None, 0, 1, 5, 10]:
                with tqdm_rich(total=total, leave=leave, desc=desc) as t:
                    assert t.desc == desc

                    # Test clearing not completely filled progressbar
                    t.total = total
                    t.n = total // 2
                    t.refresh()
                    t.desc = "new description"
                    t.refresh(clear=False)
                    assert t.desc == "new description"

                    # Test clearing completely filled progressbar
                    t.total = total
                    t.n = total
                    t.refresh()
                    t.desc = "new description"
                    t

# Generated at 2022-06-24 10:34:01.639770
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    from rich.progress import filesize
    from .std import PY3
    # Test below is for Python3. Test for Python2 is not required because
    # the only method called in FractionColumn.render is filesize.pick_unit_and_suffix,
    # and that method works the same on Python2 and Python3.
    if PY3:
        f = FractionColumn()
        t = Task(completed=123456789, total=123456789)
        assert f.render(t) == Text("1.2 G/1.2 G", style="progress.download")
        f = FractionColumn(unit_scale=True)
        assert f.render(t) == Text("1.2 G/1.2 G", style="progress.download")

# Generated at 2022-06-24 10:34:11.549448
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.text import Text
    from rich.table import Table

    # TODO: Prevent useless opening/closing of stdout
    # (try to reproduce https://github.com/tqdm/tqdm/issues/763)
    console = Console()

    console.print(Text("<green>Testing rich.progress GUI ...</green>", justify="center"))
    console.print("")

    kwargs = {
        'desc': 'Task1',
        'total': 10,
        'unit_scale': True,
        'unit': 'iB',
        'unit_divisor': 1024,
        'leave': False,
        'disable': False
    }

    with tqdm(**kwargs) as t:
        for i in range(5):
            t.update()



# Generated at 2022-06-24 10:34:15.558477
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    assert r.render(100) == Text("100.0 /s", style="progress.data.speed")
    assert r.render(1000) == Text("1.0 K/s", style="progress.data.speed")
    assert r.render(None) == Text("? /s", style="progress.data.speed")


# Generated at 2022-06-24 10:34:22.308158
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    task = Progress.Task("test_FractionColumn", completed=0.5, total=2.3, **{"unit_scale": True, "unit_divisor": 1000})
    p = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert p.render(task) == Text("0.3/1.0 K", style="progress.download")


# Generated at 2022-06-24 10:34:25.974676
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from .gui import tqdm_gui
    with tqdm_rich(ascii=True) as t:
        for i in tqdm_gui(range(10), ascii=True):
            t.display()

# Generated at 2022-06-24 10:34:31.787092
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import random
    import string
    random.seed(0)
    for i in range(10):
        speed = random.randint(0, 100)
        if speed < 10:
            expected = f"{speed}   B/s"
        elif speed < 100:
            expected = f"{speed}  B/s"
        else:
            expected = f"{speed} B/s"
        actual = RateColumn().render(speed=speed)
        assert (expected == actual.text)

# Generated at 2022-06-24 10:34:33.850686
# Unit test for function trange
def test_trange():  # pragma: no cover
    for i in tqdm_rich(trange(10)):
        pass


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:34:35.174278
# Unit test for function trange
def test_trange():
    list(tqdm([1]))



# Generated at 2022-06-24 10:34:44.997970
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # test trange, tqdm with default arguments
    t = trange(100)
    assert len(t) == 100
    t = tqdm(100)
    assert len(t) == 100

    # test tqdm,trange with non-default arguments
    t = trange(100, bar_format='{n}')
    assert len(t) == 100
    t = tqdm(100, bar_format='{n}')
    assert len(t) == 100

    # test tqdm,trange with non-default arguments
    t = trange(100, bar_format='{n}')
    assert len(t) == 100
    t = tqdm(100, bar_format='{n}')
    assert len(t) == 100

    # test trange with non-default arguments with tq

# Generated at 2022-06-24 10:34:49.443405
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    """Unit test for constructor of class RateColumn."""
    print(RateColumn(unit='B/s')(Progress(
        total=1000, completed=500, speed=500)))

# Generated at 2022-06-24 10:34:56.827027
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fraction_column = FractionColumn()

    class Task:
        completed = 0
        total = 1000

    task = Task()

    assert fraction_column.render(task) == Text('0.0/1.0', style='progress.download')

    task.completed = task.total
    assert fraction_column.render(task) == Text('1.0/1.0', style='progress.download')

    task.completed = task.total // 2
    assert fraction_column.render(task) == Text('0.5/1.0', style='progress.download')

# Generated at 2022-06-24 10:34:59.246431
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm(total=100) as t:
        assert t._prog
        assert t._task_id


# Generated at 2022-06-24 10:35:02.285605
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fc = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fc.render(object) == '0.0/0.0 '



# Generated at 2022-06-24 10:35:10.462414
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from tqdm.rich import tqdm_rich
    from tqdm.std import tqdm
    for cls in [tqdm, tqdm_rich]:
        for i in cls(range(0,100), unit='it', leave=True):
            pass
        for i in cls(range(0,100), unit='it', leave=True):
            pass
        for i in cls(range(0,100), unit='it', leave=True):
            pass
        cls.close()
        for i in cls(range(0,100), unit='it', leave=True):
            pass
        for i in cls(range(0,100), unit='it', leave=True):
            pass
        for i in cls(range(0,100), unit='it', leave=True):
            pass

# Generated at 2022-06-24 10:35:11.018803
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    trange(10).display()

# Generated at 2022-06-24 10:35:21.309866
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import os
    import sys
    import time
    try:
        import rich
    except ImportError:
        warn("Test failed: rich not available", TqdmExperimentalWarning)
        return False

    # initialize variables
    pbar = tqdm_rich(total=20)
    total_size = 100.0
    nb_files = 100
    nb_files_label = 'files'
    file_size_label = 'size'
    progress_formatter = '{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'
    fps = 1.0

    # reset for repeated use
    pbar.reset()

    # check that display function does not raise any exception
    for i in range(nb_files):
        pbar.set_

# Generated at 2022-06-24 10:35:23.915787
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():  # pragma: no cover
    progress = tqdm_rich(total=100)
    progress.update(100)
    progress.close()


# Generated at 2022-06-24 10:35:28.110657
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_column = FractionColumn()
    assert isinstance(test_column, ProgressColumn)
    assert test_column.unit_scale == False
    assert test_column.unit_divisor == 1000
    return test_column


# Generated at 2022-06-24 10:35:31.901487
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Unit test for method reset of class tqdm_rich"""
    pbar = tqdm_rich(total=10)
    for _ in range(10):
        pbar.update()
    pbar.reset(total=10)
    for _ in range(10):
        pbar.update()
    pbar.close()

# Generated at 2022-06-24 10:35:35.473126
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import time
    import warnings
    warnings.simplefilter('always')
    x = tqdm_rich(range(2))
    time.sleep(1)
    assert str(x) in sys.stderr.getvalue()
    x.close()
    assert str(x) not in sys.stderr.getvalue()

