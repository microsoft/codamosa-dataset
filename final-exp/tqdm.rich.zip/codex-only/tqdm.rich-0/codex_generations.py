

# Generated at 2022-06-24 10:25:27.775575
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=4) as t:
        assert t.total == 4
        t.reset(total=7)
        assert t.total == 7
        t.reset()
        assert t.total is None

# Generated at 2022-06-24 10:25:35.505020
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rc = RateColumn('B')
    assert str(rc.render(object)) == '? B/s'
    for x in [1, 0.9, 0.25, 0.11, 0.05, 0.04, 0.01, 0.009, 0.005]:
        setattr(rc.render(object), 'speed', x)
        assert str(rc.render(object)) == '1.0 B/s'
        setattr(rc.render(object), 'speed', x * 1000)
        assert str(rc.render(object)) == '1.0 KB/s'
        setattr(rc.render(object), 'speed', x * 1000 * 1000)
        assert str(rc.render(object)) == '1.0 MB/s'

# Generated at 2022-06-24 10:25:43.990765
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    class Task: # pragma: no cover
        speed = None

    task = Task()
    assert RateColumn(unit="B").render(task) == Text("? B/s", style="progress.data.speed")
    task.speed = 100
    assert RateColumn(unit="B").render(task) == Text("100.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True).render(task) == Text("100.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=2).render(task) == Text("100.0 B/s", style="progress.data.speed")
    task.speed = 200

# Generated at 2022-06-24 10:25:47.606805
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    t = tqdm_rich(total=100)
    t.reset(total=150)
    t.reset(total=200)

# Generated at 2022-06-24 10:25:49.337960
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    list_ = list(tqdm_rich([]))
    assert list_ == []


# Generated at 2022-06-24 10:25:55.002843
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    class tqdm_rich(std_tqdm):
        def clear(self, *_, **__):
            raise ValueError("Should not get here")
    with tqdm_rich(desc="Test clear", total=1, disable=False) as pbar:
        pass
    with tqdm_rich(desc="Test clear", total=1, disable=True) as pbar:
        pass

# Generated at 2022-06-24 10:25:56.133553
# Unit test for function trange
def test_trange():
    r = list(trange(10))
    assert r == list(range(10))
    assert len(r) == 10

# Generated at 2022-06-24 10:26:01.110624
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # Simple usage of tqdm_rich
    with tqdm(total=10) as t:
        for _ in range(10):
            sleep(0.01)
            t.update()

    # Use tqdm_rich as a context manager
    with tqdm_rich(total=10) as t:
        for _ in range(10):
            sleep(0.01)
            t.update()

# Generated at 2022-06-24 10:26:09.380331
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    from tqdm.auto import tqdm as auto_tqdm
    from tqdm.gui import tqdm as gui_tqdm
    for name, t in zip(['auto_tqdm', 'gui_tqdm', 'tqdm_rich'],
                       [auto_tqdm, gui_tqdm, tqdm_rich]):
        with t(total=2, ascii=True) as tt:
            tt.clear()
            tt.display()
            tt.update(1)
            tt.clear()
            tt.display()
            tt.update(1)
            tt.close()
            print(name)

# Generated at 2022-06-24 10:26:13.713033
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from rich.console import Console
    console = Console()
    rate_col = RateColumn()
    task = TaskID(None, console, "tqdm_rich")
    task.speed = 10
    result = rate_col.render(task)
    assert result.text == "10 B/s"

# Generated at 2022-06-24 10:26:17.681982
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Unit test for method close of class tqdm_rich."""
    from .testing import _suppress_stderr
    with _suppress_stderr():
        first_tqdm = tqdm(total=2e6)
        first_tqdm.update(1e6)
        first_tqdm.desc = 'tqdm rich'
        first_tqdm.close()

# Generated at 2022-06-24 10:26:29.778200
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    from _tqdm import tqdm as std_tqdm

    tqdm_bar_format = "Fraction: {n_fmt}/{total_fmt}{postfix}"

    # Test format with bar
    for n in [1, 10, 100, 1000, 10000]:
        for total in [10, 100, 1000, 10000]:
            with std_tqdm(total=total, unit_scale=True,
                          bar_format=tqdm_bar_format) as t:
                t.update(n)
                assert t.format_dict["n_fmt"] == filesize.size(n, 1)
                assert t.format_dict["total_fmt"] == filesize.size(
                    total, 1)

    # Test format without bar

# Generated at 2022-06-24 10:26:30.532250
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-24 10:26:34.519856
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    "Test progress bar in GUI"
    with tqdm_rich(total=10) as t:
        for _ in range(10):
            t.update()


if __name__ == '__main__':  # pragma: no cover
    # Test
    test_tqdm_rich()

# Generated at 2022-06-24 10:26:37.024559
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    try:
        t = tqdm_rich(range(10))
        t.display()
        t.close()
    except Exception:
        raise AssertionError("tqdm_rich display error")

# Generated at 2022-06-24 10:26:44.768245
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    import time
    import unittest

    # Test for a bug that happened when resetting the progress bar
    #   from a value that is bigger than the current value.
    class TestTqdmRich(unittest.TestCase):
        def test_reset(self):
            for n in trange(100):
                time.sleep(0.01)
                if n == 20:
                    raise ValueError("")

    suite = unittest.TestSuite()
    suite.addTest(TestTqdmRich("test_reset"))
    res = unittest.TextTestRunner(verbosity=2).run(suite)
    if res.failures or res.errors:
        sys.exit(1)


if __name__ == "__main__":
    test_tqdm_rich_reset()

# Generated at 2022-06-24 10:26:47.202783
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=1) as pbar:
        pbar.clear()
        pbar.clear(nolock=True)



# Generated at 2022-06-24 10:26:53.253159
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_case_1=FractionColumn()
    assert(test_case_1.unit_scale == False)
    assert(test_case_1.unit_divisor == 1000)
    test_case_2=FractionColumn(True,1)
    assert(test_case_2.unit_scale == True)
    assert(test_case_2.unit_divisor == 1)



# Generated at 2022-06-24 10:26:56.005744
# Unit test for constructor of class RateColumn
def test_RateColumn():
    column = RateColumn(unit="M")
    assert column.render(Task(speed=1000, completed=0, total=0)) == Text("1 M/s", style="progress.data.speed")

# Generated at 2022-06-24 10:26:58.736655
# Unit test for constructor of class FractionColumn
def test_FractionColumn():  # pragma: no cover
    tqdm.tqdm(total=10)

# Generated at 2022-06-24 10:27:08.150314
# Unit test for constructor of class RateColumn
def test_RateColumn():
    task = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit=" MB", unit_scale=True, unit_divisor=1000),
        "]")
    task = task.add_task("speed test", total=100)
    task.update(completed=0)
    task.update(speed=100)
    task.update(speed=1024)
    task.update(speed=1024**2)
    task.update(speed=1024**3)

# Generated at 2022-06-24 10:27:18.681105
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = type('testtask', (), {'total' : 200, 'completed': 100, 'speed': 20})
    assert RateColumn().render(task) == '1 B/s'
    assert RateColumn().render(task) == '1 B/s'
    assert RateColumn(unit='b').render(task) == '1 b/s'
    assert RateColumn(unit_scale=True, unit_divisor=1000).render(task) == '1.0 K/s'
    assert RateColumn(unit_scale=True, unit_divisor=1000).render(task) == '1.0 K/s'
    assert RateColumn(unit_scale=True, unit_divisor=1024).render(task) == '0.9 K/s'

# Generated at 2022-06-24 10:27:24.700809
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import time
    with tqdm_rich(total=100, desc="test1") as pbar:
        for _ in range(10):
            time.sleep(0.01)
            pbar.clear()
    with tqdm_rich(total=100, desc="test2") as pbar:
        for _ in range(10):
            time.sleep(0.01)
            pbar.clear(nolock=True)

# Generated at 2022-06-24 10:27:28.737642
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from os import environ, pathsep
    try:
        import rich  # type: ignore
    except ImportError:
        pass
    else:
        tqdm_rich(desc="Packages", total=len(environ['PATH'].split(pathsep)))

# Generated at 2022-06-24 10:27:31.441381
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10) as t:
        for i in range(11):
            t.update()

if __name__ == '__main__':
    test_tqdm_rich()

# Generated at 2022-06-24 10:27:42.765111
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # error: argument `bar_format` is not accepted
    try:
        t = tqdm_rich(bar_format="")
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError not raised")

    # error: argument `position` is not accepted
    try:
        t = tqdm_rich(position=0)
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError not raised")

    # error: argument `progress` should be a tuple
    try:
        t = tqdm_rich(progress=())
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError not raised")

    # error: argument `progress` should be a tuple

# Generated at 2022-06-24 10:27:54.319210
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import platform
    import sys

    pytest_plugins = "pytest_trio"
    sys.platform = platform.system().lower()

    from unittest.mock import MagicMock
    from rich import panel
    from rich.progress import Progress

    panel.Panel.clear = MagicMock(return_value=None)
    Progress.update = MagicMock(return_value=None)
    Progress.__exit__ = MagicMock(return_value=None)

    import trio
    from trio_typing import TaskStatus

    async def _test_tqdm_rich_close(status):
        import sys
        import threading
        from tqdm.rich import trange
        await trio.sleep(0.5)
        assert not status.cancelled_caught
        sys.stdout.close()
        threading

# Generated at 2022-06-24 10:27:57.948765
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    with tqdm_rich(total=10, progress=(FractionColumn(unit_scale=True, unit_divisor=1000),)) as progress:
        for i in progress:
            progress.update()

# Generated at 2022-06-24 10:28:07.562079
# Unit test for function trange
def test_trange():
    global trange
    from .tests_tqdm import pretest_posttest, closing, UnicodeIO
    from .tests_tqdm import discretesleep, assertAlmostEqual
    from time import time
    from os import sys

    class trange_class(tqdm_rich):
        """Shameless hack for testing purposes"""
        _instances = set()

        def __init__(self, *args, **kwargs):
            self._instances.add(self)
            std_tqdm.__init__(self, *args, **kwargs)

        def __exit__(self, exc_type, exc_val, exc_tb):
            self._instances.remove(self)
            std_tqdm.__exit__(self, exc_type, exc_val, exc_tb)

    trange

# Generated at 2022-06-24 10:28:12.275985
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest.mock import patch

    with patch("rich.console.Console") as mock_console:
        with tqdm_rich(total=10, desc="Testing tqdm_rich..."):
            pass
        mock_console.return_value.print.assert_called()

# Generated at 2022-06-24 10:28:24.195134
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    import time
    import sys

    with tqdm_rich(range(10), desc="test_tqdm_rich") as t:
        for i in t:
            time.sleep(0.01)

    if sys.platform.startswith("win"):  # pragma: no cover
        # XXX: on windows, multiprocessing spawns new console
        # windows that are immediately closed, breaking ^C
        from .utils import _term_move_up

        print(_term_move_up() + "\r" + "                            ")
        print(_term_move_up() + "\r" + "                            ")
        print(_term_move_up() + "\r" + "                            ")


if __name__ == '__main__':  # pragma: no cover
    test

# Generated at 2022-06-24 10:28:26.833568
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10, desc='clear')
    for i in _range(10):
        t.clear()
        t.update()
    t.close()

# Generated at 2022-06-24 10:28:37.474905
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import os
    import sys
    import time
    import tqdm
    from tqdm.auto import tqdm as _tqdm  # import fix

    tqdm._instances.clear()
    sleep_durations_in_seconds = [0.3, 0.2, 0.1]
    with _tqdm(total=len(sleep_durations_in_seconds)) as pbar:
        for sleep_duration_in_seconds in sleep_durations_in_seconds:
            time.sleep(sleep_duration_in_seconds)
            pbar.update()
    tqdm._instances.clear()
    assert not tqdm._instances

    if os.name == "nt":
        return
    # ensure a non-blocking write

# Generated at 2022-06-24 10:28:39.725112
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from pytest import raises
    with raises(TypeError):
        tqdm_rich().display()

# Generated at 2022-06-24 10:28:46.501667
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    '''
    Tests the method clear of class tqdm_rich.
    '''
    from tqdm._tqdm import _term_move_up

    # tests with `ncols`
    out = io.StringIO()
    with closing(out):
        with tqdm_rich(total=9, ncols=20, file=out) as t:
            t.update(0)
            t.clear()
            t.display()
            out.seek(0)
            buf = out.read()
    assert _term_move_up + '\r' + resize(t._prog, width=20).rstrip() in buf

    # tests with no `ncols`
    out = io.StringIO()

# Generated at 2022-06-24 10:28:52.411066
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=3)
    task.refresh()
    task.set_description('test_RateColumn_render')
    task.update(1)
    progress_column = RateColumn(unit_scale=True)
    progress_column.render(task)
    task.close()

if __name__ == "__main__":
    test_RateColumn_render()

# Generated at 2022-06-24 10:28:55.198387
# Unit test for constructor of class RateColumn
def test_RateColumn():
    assert RateColumn(unit="bytes", unit_scale=False, unit_divisor=1000).render(RateColumn(unit="bytes", unit_scale=False, unit_divisor=1000)) == "[0.00] bytes / s"

# Generated at 2022-06-24 10:29:05.892205
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from textwrap import dedent

    # Test that task id generated from reset is unique (we don't
    # reuse the task id from previous call to tqdm_rich)
    with Progress(
        " [progress.description]{task.description} [progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]"
    ) as prog:
        for i in trange(2, desc="First"):
            sleep(0.2)
        t = trange(2, desc="Second", progress=prog)
        for i in t:
            sleep(0.2)
            t.reset(total=6)
        t.reset(total=0)

# Generated at 2022-06-24 10:29:09.873504
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column1 = RateColumn()
    rate_column2 = RateColumn('/s')
    rate_column3 = RateColumn(unit_scale=True)
    rate_column4 = RateColumn(unit_divisor=1000)
    rate_column5 = RateColumn(unit='/s', unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-24 10:29:14.344269
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    for _ in tqdm_rich(range(4)):
        pass
    with tqdm_rich(range(4)) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:29:22.884510
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import io
    import time
    from .std import tqdm
    
    stdout_org=sys.stdout
    sys.stdout = io.StringIO()
    stdout_org.write("\n")

    for i in tqdm(range(10), desc='1', gui=True):
        stdout_org.write("\n")
        time.sleep(0.1)

    for i in tqdm(range(10), desc='2', gui=True):
        stdout_org.write("\n")
        time.sleep(0.1)

    sys.stdout.close()
    sys.stdout = stdout_org

if __name__ == "__main__":
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:29:26.122023
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(total=10, desc='testing close method')
    for i in range(10):
        t.update()
    assert t.n == 10
    t.clear()
    t.close()
    assert hasattr(t, '_prog') == False


# Generated at 2022-06-24 10:29:32.535065
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    it = _range(10)
    with tqdm_rich(it) as t:
        assert t.gui
        assert not t.bar_format
        assert t.format_dict['unit'] == ''
        assert t.format_dict['unit_scale'] is False
        for _ in it:
            pass
    assert t.n == 10



# Generated at 2022-06-24 10:29:41.503007
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Unit test utils.filesize.pick_unit_and_suffix()."""
    from .utils import B, KB, MB, GB, TB, PB, EB, ZB, YB
    unit_suffix = {1: ('', ''),
                   B: ('', 'B'), KB: ('K', 'B'), MB: ('M', 'B'), GB: ('G', 'B'),
                   TB: ('T', 'B'), PB: ('P', 'B'), EB: ('E', 'B'),
                   YB: ('Y', 'B')}
    for value, unit_suffix_expected in unit_suffix.items():
        unit, suffix = filesize.pick_unit_and_suffix(value, [""], 1)

# Generated at 2022-06-24 10:29:45.890505
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=100) as __tqdm__:
        assert __tqdm__.total == 100

        __tqdm__.reset(total=2)
        assert __tqdm__.total == 2

        __tqdm__.reset(total=200)
        assert __tqdm__.total == 200

# Generated at 2022-06-24 10:29:50.909671
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    unit_scale = False
    unit_divisor = 1000
    completed = 0
    total = 0

    f = FractionColumn(unit_scale=unit_scale, unit_divisor=unit_divisor)
    
    assert f.render(Task(completed, total)) == Text(
        f"{completed}/{total}",
        style="progress.download")

# Generated at 2022-06-24 10:29:56.138759
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.progress import Progress
    p = Progress()
    assert isinstance(RateColumn(), ProgressColumn)
    assert RateColumn(unit="m/s").render(p) == "? m/s/s"
    assert RateColumn(
        unit="m/s", unit_scale=True, unit_divisor=100).render(p) == "? m/s/s"

# Generated at 2022-06-24 10:30:07.840849
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.rich.trange`
    """
    import time
    with trange(10) as t:
        for _ in t:
            time.sleep(0.01)

    # Test with an iterator
    try:
        from tensorflow.python.keras.utils.data_utils import Sequence
    except ImportError:
        Sequence = object

    class TestIterator(Sequence):

        def __init__(self, *args, **kwargs):
            self.start = 0
            self.stop = kwargs['stop']
            self.epochs = kwargs['epochs']
            self.batch_size = kwargs['batch_size']

        def __len__(self):
            return int(self.epochs)


# Generated at 2022-06-24 10:30:17.459044
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm_rich constructor"""
    progress = (
        Text("[bold blue]{task.description:8}", justify="right"),
        "[", TimeElapsedColumn(), "]", " [", FractionColumn(), "]",
        BarColumn(bar_width=None),
    )
    total = 100

# Generated at 2022-06-24 10:30:22.485030
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import rich.console
    import rich.progress
    with rich.console.Console() as console:
        with rich.progress.Progress(
                "[progress.description]{task.description}",
                "[progress.percentage]{task.percentage:>4.0f}%",
                transient=False, console=console) as progress:
            task = progress.add_task("test", total=100)
            t = tqdm_rich(total=100, desc='test')
            t.n = 50
            assert t.n == 50
            t.reset()
            t.display()
            assert t.n == 0
            t.close()
            assert t._prog == progress and t._task_id == task

# Generated at 2022-06-24 10:30:30.394754
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # Test with unit_scale:
    fc = FractionColumn(unit_scale=True)
    assert fc.render({'completed': 0.0, 'total': 0.0}) == Text(
        f"0.0/0.0 ", style="progress.download")
    assert fc.render({'completed': 1234.0, 'total': 56.78}) == Text(
        f"1.2/0.1 ", style="progress.download")
    assert fc.render({'completed': 12345.0, 'total': 5678.0}) == Text(
        f"12.3/5.7 K", style="progress.download")

# Generated at 2022-06-24 10:30:32.353912
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    r = RateColumn(unit="B", unit_scale=True)
    r.render({"speed": 1024})

# Generated at 2022-06-24 10:30:44.107476
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    import sys
    import time
    with tqdm_rich(total=100) as pbar:
        for i in _range(10):
            pbar.update(10)

    with tqdm(total=100) as pbar:
        for _ in pbar:
            time.sleep(0.01)
            pbar.update()
            if pbar.n >= pbar.total:
                break

    with tqdm_guo(total=100) as pbar:
        for _ in pbar:
            time.sleep(0.01)
            pbar.update()
            pbar.set_description("test")
            if pbar.n >= pbar.total:
                break


# Generated at 2022-06-24 10:30:52.961094
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import time
    RateColumn(unit="B/s", unit_scale=True, unit_divisor=1024)
    RateColumn(unit="B/s", unit_scale=False, unit_divisor=1024)

    # Unit test for constructor of class trange
    trange(10)
    trange(10, 2)

    # Unit test for constructor of class tqdm
    tqdm(10)
    tqdm(10, 2)

    # Unit test for display()
    t = tqdm(10, leave=True)
    t.display()
    assert str(t.__next__()) == "  0%|                                                                                        | 0/10 [00:00<?, ?it/s]"

    # Unit test for reset()
    t.reset(total=20)
    assert t.total

# Generated at 2022-06-24 10:31:01.497640
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    completed = 50
    total = 230
    
    assert '0.2/2.3 K' == FractionColumn(unit_scale=True, unit_divisor=1000).render(task=tqdm_rich(total_=total,n_=completed))
    assert '0/2.3 G' == FractionColumn(unit_scale=True, unit_divisor=1000).render(task=tqdm_rich(total_=total,n_=0))
    assert '0/2.3 G' == FractionColumn(unit_scale=True, unit_divisor=1000).render(task=tqdm_rich(total_=total,n_=None))

# Generated at 2022-06-24 10:31:12.284611
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    assert str(FractionColumn().render(Progress(total=1.0))) == '0.0/1.0'
    assert str(FractionColumn().render(Progress(total=1000))) == '0/1000'
    assert str(FractionColumn().render(Progress(total=1024.5))) == '0.0/1.0 K'
    assert str(FractionColumn().render(Progress(total=1024.5))) == '0.0/1.0 K'
    assert str(FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=1024.5))) == '0.5/1.0 K'
    assert str(FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=1024.5))) == '0.5/1.0 K'

# Generated at 2022-06-24 10:31:18.591836
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=3, desc="test_display") as pbar:
        pbar.set_description("new desc")
        pbar.set_postfix_str("mem: 1024M")
        pbar.update(2)
        pbar.close()
    # Issue 858: non-zero exit code for completed progress bar

# Generated at 2022-06-24 10:31:21.642523
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    assert rate_column.unit == ''
    assert rate_column.unit_scale == False
    assert rate_column.unit_divisor == 1000

# Generated at 2022-06-24 10:31:29.626690
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    progress = Progress()
    task_id = progress.add_task("", description="", total=1)
    progress.update(task_id, speed=None)
    task = progress.tasks[task_id]
    rate_column = RateColumn("/s", unit_scale=False, unit_divisor=1000)
    result = rate_column.render(task)
    assert result == Text("? /s", style="progress.data.speed")

    rate_column = RateColumn("/s", unit_scale=True, unit_divisor=1000)
    result = rate_column.render(task)
    assert result == Text("? /s", style="progress.data.speed")

    progress.update(task_id, speed=1)

# Generated at 2022-06-24 10:31:34.085832
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=4) as t:
        for i in _range(4):
            t.update()
        t.reset()
        assert t.n == 0
        assert t.total == 4
        t.update()
        assert t.n == 1

# Generated at 2022-06-24 10:31:37.043693
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=7) as pbar:
        pbar.display()


# Generated at 2022-06-24 10:31:39.770159
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import io
    with io.StringIO() as buf:
        with tqdm_rich(_range(20), file=buf, leave=True) as bar:
            for i in bar:
                bar.clear()

# Generated at 2022-06-24 10:31:48.461770
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.table import Table

    progress = Progress()
    test_case = FractionColumn(unit_scale=True, unit_divisor=1024, style="progress.download")
    expected_value = Table(title="test", show_header=False, show_edge=False)
    expected_value.add_column("test", justify="left", style="progress.download")
    expected_value.add_row("100.00K/100.00K")
    assert test_case.render(progress.add_task("test", total=100*1024)) == expected_value


# Generated at 2022-06-24 10:31:53.846587
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fractionColumn = FractionColumn(unit_scale=True, unit_divisor=1000)
    fractionColumn.render(object())

    # Unit test for constructor of class RateColumn
    def test_RateColumn():
        rateColumn = RateColumn(unit="M", unit_scale=True, unit_divisor=1000)
        rateColumn.render(object())

# Generated at 2022-06-24 10:32:02.853558
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    task = type('', (object,), {'completed': 0, 'total': 1})
    assert column.render(task) == Text('0.0/1.0' ,style="progress.download")
    column = FractionColumn(unit_scale=True)
    assert column.render(task) == Text('0.0/1.0' ,style="progress.download")
    column = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert column.render(task) == Text('0.0/1.0 K',style="progress.download")


# Generated at 2022-06-24 10:32:08.491931
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test for function trange"""
    for i in trange(5):
        assert i is not None
    try:
        trange(5).start()
    except Exception:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-24 10:32:16.886489
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    t = tqdm_rich(total=20, unit_divisor=1000)
    t.n = 10
    t.total = 30
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(t) == Text(
        "10/30 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(t) == Text(
        "10/30 ", style="progress.download")
    t.n = 1000
    t.total = 30000
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(t) == Text(
        "1000/30000 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(t)

# Generated at 2022-06-24 10:32:26.342204
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    import unittest
    test = unittest.TestCase()
    text = FractionColumn()
    text.update(completed=0, total=10, speed=None)
    test.assertEqual(str(text), "0.0/10 ")
    test.assertEqual(text.style, "progress.download")
    text.update(completed=1, total=10, speed=None)
    test.assertEqual(str(text), "0.1/10 ")
    test.assertEqual(text.style, "progress.download")
    text.update(completed=10, total=10, speed=None)
    test.assertEqual(str(text), "1.0/10 ")
    test.assertEqual(text.style, "progress.download")

# Generated at 2022-06-24 10:32:29.634021
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    col = FractionColumn()
    assert str(col.render(Progress(total=547483647))) == '5,474,836,447/5,474,836,447 '


# Generated at 2022-06-24 10:32:37.171638
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test the method `reset` of class `tqdm_rich`.
    """
    # Test progress bar with default value.
    bar_1 = tqdm_rich(["Test"])
    bar_1.reset()
    assert bar_1._prog.total == 0

    # Test progress bar with default value.
    bar_2 = tqdm_rich(["Test"], total=10)
    bar_2.reset(11)
    assert bar_2._prog.total == 11

# Generated at 2022-06-24 10:32:46.046465
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    test_col = FractionColumn(unit_scale=True, unit_divisor=1000)
    test_task = Progress(
        Text("Test!"),
        FractionColumn(unit_scale=True, unit_divisor=1000)
    )
    test_prog = tqdm_rich(
        "Test!",
        total=2000,
        unit_scale=True,
        unit_divisor=1000,
        bar_format=test_col
    )
    try:
        test_prog.start()
        test_task.start()
        test_task.update(completed=1000, total=2000)
        test_prog.update(1000)
    finally:
        test_prog.close()

# Generated at 2022-06-24 10:32:47.512636
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for _ in tqdm([1, 2, 3, 4]):
        pass

# Generated at 2022-06-24 10:32:48.978132
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(1, desc="test") as p:
        pass
    assert p.n == 1

# Generated at 2022-06-24 10:32:51.968512
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    with trange(10) as t:
        for _ in t:
            pass

# Generated at 2022-06-24 10:32:59.538673
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()

    table = Table(show_header=False, show_edge=False)
    table.add_column("Completed", style="cyan", justify="right")
    table.add_column("Speed", style="green", justify="right")

    progress = Progress(
        Text("[progress.description]{task.description}"),
        Text("[progress.percentage]{task.percentage:>4.0f}%"),
        BarColumn(bar_width=None),
        RateColumn(unit="B"),
        Text("[", TimeElapsedColumn(), ",", RateColumn(unit="B", unit_scale=True), "]"),
        transient=True,
    )


# Generated at 2022-06-24 10:33:06.090811
# Unit test for function trange
def test_trange():  # pragma: no cover
    # Test
    for _ in trange(4, desc='Cool', unit='i', leave=False):
        for _ in trange(4, desc='Fun', unit='j', leave=True):
            for _ in trange(4, desc='Awesome', unit='k', leave=True):
                pass
                # time.sleep(0.01)
            # time.sleep(0.01)
        # time.sleep(0.01)

if __name__ == '__main__':  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:33:16.641755
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import os
    import threading
    import time

    def close_wrapper(tqdm, tqdm_dict):
        tqdm.close(clear=tqdm_dict['clear'])

    for gui_mode in [False, True]:
        # clear=True
        progressbar = tqdm_rich(total=2, desc='Test', disable=gui_mode)

        progressbar.close(clear=True)
        if not gui_mode:
            assert os.get_terminal_size().columns == progressbar.dynamic_mess

        # clear=False
        progressbar = tqdm_rich(total=2, desc='Test', disable=gui_mode)

        thread_to_close = threading.Thread(
            target=close_wrapper, args=(progressbar, {'clear': False}))
        thread

# Generated at 2022-06-24 10:33:25.718142
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from unittest import TestCase, main
    from collections import namedtuple
    Task = namedtuple("Task", ["completed", "total"])
    class TestRender(TestCase):
        def test_render_1(self):
            """
            Test that the render method of FractionColumn works correctly
            """
            fraction_column = FractionColumn()
            task = Task(completed=10, total=30)
            self.assertEqual(str(fraction_column.render(task)), "0.3/1.0 ")

            task = Task(completed=1000, total=3000)
            self.assertEqual(str(fraction_column.render(task)), "1.0/3.0 ")

            task = Task(completed=100000, total=300000)

# Generated at 2022-06-24 10:33:33.107061
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()  # human_readable_rate=True, unit_scale=False, unit_divisor=1000
    assert(rate_column.unit == "")
    assert(rate_column.unit_scale == False)
    assert(rate_column.unit_divisor == 1000)
    assert(rate_column.render(task=None) == Text("? ", style="progress.data.speed"))

    rate_column = RateColumn(unit="B")  # human_readable_rate=True, unit_scale=False, unit_divisor=1000
    assert(rate_column.unit == "B")
    assert(rate_column.unit_scale == False)
    assert(rate_column.unit_divisor == 1000)

# Generated at 2022-06-24 10:33:35.942748
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    d = tqdm_rich("\r", desc="rich", total=10)
    assert d.dynamic_ncols
    assert d.disable is False
    assert d.desc == "rich"
    assert not d.total
    d.reset(total=10)  # reset total
    assert d.total == 10
    d.close()

# Generated at 2022-06-24 10:33:46.018028
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .utils import FormatCustomTextType
    from .utils import FakeDict, FakeTqdmFile

# Generated at 2022-06-24 10:33:51.909127
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    fc = FractionColumn()
    assert fc.render(['1', '10']) == "[progress.download]1.0/10.0 "
    assert fc.render(['1', '1000']) == "[progress.download]1.0/1,000.0 K"
    assert fc.render(['1', '1000', 'random']) == "[progress.download]1.0/1,000.0 K"

# Generated at 2022-06-24 10:34:01.003774
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    F = FractionColumn()
    assert F.render(ProgressColumn.Task(0, 2)) == Text(
        '0.0/2.0', style='progress.download')
    assert F.render(ProgressColumn.Task(50, 300)) == Text(
        '0.2/3.0', style='progress.download')
    assert F.render(ProgressColumn.Task(500, 3000)) == Text(
        '0.2/3.0', style='progress.download')
    assert F.render(ProgressColumn.Task(5000, 30000)) == Text(
        '5.0/30.0', style='progress.download')
    assert F.render(ProgressColumn.Task(50000, 300000)) == Text(
        '50.0/300.0', style='progress.download')

# Generated at 2022-06-24 10:34:08.600489
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    import sys
    import shutil
    from rich.progress import Console

    console = Console()
    console.print("Hello World")
    console.print("I'm going to sleep for a bit")
    for i in trange(4):
        sleep(0.5)
    console.print("\n" * (shutil.get_terminal_size()[1]))
    console.print("I'm done!")
    # the following print is necessary to avoid mouse selection in PyCharm
    print()
    sys.exit(0)

# Generated at 2022-06-24 10:34:10.304145
# Unit test for constructor of class RateColumn
def test_RateColumn():
    # Unit test for constructor of class RateColumn
    # Should not raise any error
    obj = RateColumn()

# Generated at 2022-06-24 10:34:14.785471
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    empty = RateColumn(unit="")
    assert empty.unit == ""
    assert empty.render(None) == Text("? /s", style="progress.data.speed")

    byte = RateColumn(unit="B")
    assert byte.unit == "B"
    assert byte.render(None) == Text("? B/s", style="progress.data.speed")



# Generated at 2022-06-24 10:34:20.070543
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import io
    import re
    import sys

    progress = []

    stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()
        std_tqdm.write = lambda s: progress.append(s)
        with tqdm_rich(total=10) as t:
            for _ in range(0, 10):
                t.update()
            t.clear()  # should not raise

        assert len(re.findall(r'\d+%', ''.join(progress))) == 10

    finally:
        sys.stdout = stdout



# Generated at 2022-06-24 10:34:25.926180
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    # test tqdm_rich
    import sys
    import time

    with tqdm_rich(total=10, desc="test", unit_scale=True, unit="B", unit_divisor=1024) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()
    sys.stdout.write("\n")

# Generated at 2022-06-24 10:34:38.382527
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test function for method reset of class tqdm_rich
    """
    pbar = tqdm_rich(total=50, unit="B", unit_scale=True, unit_divisor=1024)
    assert pbar.total == 50
    assert pbar.unit == 'B'
    assert pbar.unit_scale == True
    assert pbar.unit_divisor == 1024

    pbar.reset(123)
    assert pbar.total == 123
    assert pbar.unit == 'B'
    assert pbar.unit_scale == True
    assert pbar.unit_divisor == 1024

# Generated at 2022-06-24 10:34:40.432435
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=2)
    assert t.n == 0
    t.update()
    assert t.n == 1
    t.update()
    assert t.n == 2
    t.close()



# Generated at 2022-06-24 10:34:41.469866
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10):
        pass

# Generated at 2022-06-24 10:34:44.179136
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    bar = FractionColumn()
    task = std_tqdm(total=100)
    task.desc = "desc"
    task.n = 50
    task.total = 200
    assert bar.render(task) == Text(
        "50.0/200 desc", style="progress.download")

# Generated at 2022-06-24 10:34:50.352563
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    from rich.progress import TaskID
    from tqdm.rich import FractionColumn
    task = TaskID()
    task.completed = 123
    task.total = 456
    text = FractionColumn().render(task)
    assert text.text == '0.3/1.0 ', 'FractionColumn().render()'

# Generated at 2022-06-24 10:34:56.241355
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn()
    assert rate.render(100) == Text("100.0  /s", style="progress.data.speed")
    assert rate.render(1000) == Text("1.0 K/s", style="progress.data.speed")
    assert rate.render(1000000) == Text("1.0 M/s", style="progress.data.speed")
    assert rate.render(None) == Text("? /s", style="progress.data.speed")


# Generated at 2022-06-24 10:34:58.842414
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    t = tqdm(total=4)
    for i in range(4):
        t.update()
    assert t.n == 4

