

# Generated at 2022-06-24 10:25:38.248118
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    class TestTqdmRich(tqdm_rich):
        def __init__(self, *args, **kwargs):
            super(TestTqdmRich, self).__init__(*args, **kwargs)
            self.update_display_called = False

        def update_display(self, *_, **__):
            self.update_display_called = True

    with TestTqdmRich(total=10) as t:
        assert not t.update_display_called
        t.display()
        assert t.update_display_called

# Generated at 2022-06-24 10:25:39.777644
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(5) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:25:40.637342
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import rich.progress


# Generated at 2022-06-24 10:25:44.857578
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    with tqdm(10, disable=False, miniters=0, maxiters=10) as t:
        assert isinstance(t, tqdm_rich)
    assert t._task_id == 1


if __name__ == '__main__':
    for i in tqdm(range(10), disable=True, miniters=0, maxiters=5):
        pass

# Generated at 2022-06-24 10:25:54.380506
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .utils import format_sizeof

    format_dict = tqdm.format_dict

# Generated at 2022-06-24 10:26:00.026857
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress('test', 20, 50)).text == '20/50 '
    assert FractionColumn(unit_scale=True).render(Progress('test', 20, 5000)).text == '20.0/5.0 K'
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress('test', 20, 5015)).text == '19.6/4.9 K'
    assert FractionColumn().render(Progress('test', 20, 1)).text == '20/1 '
    assert FractionColumn().render(Progress('test', 1, 20)).text == '0/20 '
    assert FractionColumn(unit_scale=True).render(Progress('test', 1, 20000)).text == '0.1/2.0 K'

# Generated at 2022-06-24 10:26:04.084992
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    progress = Progress(
                "[progress.description]{task.description}"
                "[progress.percentage]{task.percentage:>4.0f}%",
                BarColumn(bar_width=None),
                FractionColumn(unit_scale=1),
                )
    print(progress)



# Generated at 2022-06-24 10:26:11.891186
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .tqdm import tnrange
    from time import sleep

    with tnrange(100, desc='tqdm_rich: 1') as t:
        for i in t:
            sleep(.01)
            if i == 30:
                t.reset(total=50)
            if i == 38:
                # test nested
                with tnrange(6, desc='tnrange: 1') as t2:
                    for j in t2:
                        sleep(.1)
                        if j == 3:
                            t2.reset(total=10)

# Generated at 2022-06-24 10:26:13.508281
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from pytest import raises
    with raises(NotImplementedError):
        tqdm_rich().clear()

# Generated at 2022-06-24 10:26:20.074054
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm_pandas
    from .main import tqdm_gui
    from .tqdm import tqdm as _tqdm

    def _test_tqdm_rich_reset(tqdm_cls, reset_on_iterable):
        # init
        bar = tqdm_cls(total=1, desc='desc', unit='iB', unit_scale=True,
                       dynamic_ncols=True, smoothing=0, miniters=1, mininterval=0)
        assert bar.total == 1
        assert bar.dynamic_ncols
        assert bar.smoothing == 0
        assert bar.miniters == 1
        assert bar.mininterval == 0
        assert not bar.disable
        assert bar.n == 0
        assert bar.last_

# Generated at 2022-06-24 10:26:20.844981
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Test FractionColumn"""
    frac = FractionColumn()

# Generated at 2022-06-24 10:26:22.854092
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(10) as t:
        t.close()



# Generated at 2022-06-24 10:26:23.527933
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-24 10:26:25.134876
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """
    >>> FractionColumn()
    <__main__.FractionColumn object at 0x7fdd050d9e80>
    """
    obj = FractionColumn()


# Generated at 2022-06-24 10:26:35.701111
# Unit test for constructor of class RateColumn

# Generated at 2022-06-24 10:26:37.366538
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=10) as t:
        assert(t.disable is False)
        t.close()
        assert(t.disable is True)


# Generated at 2022-06-24 10:26:39.729741
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(1, 1, 1) == Text('1.0/1.0 ', style='progress.download')


# Generated at 2022-06-24 10:26:41.981004
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from .gui import tnrange
    trange(1)
    tnrange(1)
    tnrange(range(100))

# Generated at 2022-06-24 10:26:43.512266
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    column = FractionColumn()
    assert column.render(Progress()) == Text("0/0 ", style="progress.download")

# Generated at 2022-06-24 10:26:53.362473
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from unittest import TestCase

    class TqdmRichTest(TestCase):
        """Test the tqdm_rich class."""
        def test_empty_iterable(self):
            """Test tqdm_rich class with an empty iterable."""
            for _ in tqdm_rich([]):
                pass

        def test_end_list(self):
            """Tests the `bar_format` end_list option."""
            for _ in tqdm_rich([], bar_format="{l_bar}{bar}{r_bar}"):
                pass

        def test_add_progress(self):
            """Tests the add_progress option."""
            for _ in tqdm_rich([], bar_format="{n}/{total}", add_progress=True):
                pass


# Generated at 2022-06-24 10:26:55.344680
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rateColumn = RateColumn()
    assert rateColumn.render(None) == Text('? /s', style='progress.data.speed')

# Generated at 2022-06-24 10:27:00.857862
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import Progress

    progress = Progress()
    try:
        task = progress.add_task("A")
        tq = tqdm_rich(total=10, desc="test", mininterval=0,
                       postfix={"test": 1}, format_dict={'test': 2})
        tq.write(10)
        for i in range(20):
            time.sleep(0.1)
            tq.update(0)
    finally:
        progress.__exit__(None, None, None)
        tq.close()

# Generated at 2022-06-24 10:27:07.362603
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest.mock
    from .std import tqdm
    c = RateColumn(unit="/s")
    task = unittest.mock.MagicMock(speed=1023, total=1024)
    assert isinstance(c.render(task), Text)
    assert c.render(task).text == "1 K/s"
    task = unittest.mock.MagicMock(speed=1023, total=1024, unit_scale=True)
    assert c.render(task).text == "1,023.0 /s"

# Generated at 2022-06-24 10:27:09.588395
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    The method close is meant to close the progress bar by calling super()
    close method.
    """
    t = tqdm_rich()
    t.close()
    assert t.disable == True

# Generated at 2022-06-24 10:27:11.646916
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    obj = FractionColumn()
    assert obj._render(ProgressColumn()) == None



# Generated at 2022-06-24 10:27:13.921483
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(range(10)) as t:
        for i in t:
            pass
        t.close()

# Generated at 2022-06-24 10:27:17.184207
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Functional test for function trange."""
    with trrange(10) as t:
        for i in t:
            pass
    assert t.n == 10

# Generated at 2022-06-24 10:27:21.268695
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in tqdm(range(1, 3), total=3, dynamic_ncols=True):
        pass


if __name__ == '__main__':  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:27:31.060028
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    # with initial total
    with tqdm_rich(100) as progress:
        assert progress._prog._total_fraction == 1.0
        assert progress._prog._current_fraction == 0.0
        progress.update(20)
        assert progress._prog._total_fraction == 1.0
        assert progress._prog._current_fraction == 0.2
        progress.n = 40
        assert progress._prog._total_fraction == 1.0
        assert progress._prog._current_fraction == 0.4

    # without initial total
    with tqdm_rich(total=None) as progress:
        assert progress._prog._total_fraction is None
        assert progress._prog._current_fraction == 0.0
        progress.total = 100
        assert progress._prog._total_

# Generated at 2022-06-24 10:27:42.225821
# Unit test for constructor of class RateColumn
def test_RateColumn():
    from rich import panel
    from rich.progress import Progress
    from rich.table import Table, Column

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Task")
    table.add_column("Completed")
    table.add_column("Remaining", justify="right")
    table.add_column("Transfer Rate", justify="right")


# Generated at 2022-06-24 10:27:45.712360
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

if __name__ == "__main__":
    from doctest import testmod
    from .main import _main

    if testmod()[0]:  # pragma: nocover
        sys.exit(1)
    sys.exit(_main())  # pragma: nocover

# Generated at 2022-06-24 10:27:51.429107
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # TODO: Remove after confirming that the function reset works correctly.
    from time import sleep

    def do_sleep(time_to_sleep):
        for _ in trange(10, desc='fake'):
            sleep(time_to_sleep)

    for time_to_sleep in [0.1, 0.2, 0.3]:
        do_sleep(time_to_sleep)

# Generated at 2022-06-24 10:27:53.054635
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    f = tqdm_rich(range(3))
    f.clear()

# Generated at 2022-06-24 10:27:59.330597
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        for i in t:
            assert i == t.n - 1
            t.set_description(str(i))
            t.set_postfix(str(i))
        else:
            assert i == 10 - 1

    with trange(10) as t:
        for i in t:
            assert i == t.n - 1
            t.update()
        else:
            assert i == 10 - 1

# Generated at 2022-06-24 10:28:02.942742
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    @tqdm_rich(total=0)
    def _test():  # pragma: no cover
        pass
    _test()


from ._version import get_versions
__version__ = get_versions()['version']
del get_versions

# Generated at 2022-06-24 10:28:13.496402
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    unit = "B"
    unit_scale = False
    unit_divisor = 1000

    speed = 100
    rate = RateColumn(unit, unit_scale, unit_divisor)
    assert rate.render(speed) == Text(f"100.0 B/s", style="progress.data.speed")

    unit = ""
    unit_scale = True
    unit_divisor = 1000
    rate = RateColumn(unit, unit_scale, unit_divisor)
    assert rate.render(speed) == Text(f"100.0 /s", style="progress.data.speed")
    speed = 101
    assert rate.render(speed) == Text(f"100.1 /s", style="progress.data.speed")

    unit = "B"
    unit_scale = True
    unit_divisor = 1024

# Generated at 2022-06-24 10:28:22.523385
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from datetime import datetime
    testRateColumn = RateColumn()
    # Verify with no task.speed
    task_speed_none_text = testRateColumn.render(None)
    assert task_speed_none_text == "? /s"
    # Verify with a task that has task.speed
    task_speed_datetime = datetime.now()
    task_speed = datetime.timestamp(task_speed_datetime)
    testRateColumn = RateColumn()
    task_speed_text = testRateColumn.render(task_speed)
    assert task_speed_text == "1.0 /s"

# Generated at 2022-06-24 10:28:27.511361
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=10)
    task.update(2)
    rate = RateColumn("")
    output = rate.render(task)
    assert output.text == "1.0  /s"
    rate = RateColumn("s")
    output = rate.render(task)
    assert output.text == "1.0 s/s"

# Generated at 2022-06-24 10:28:37.058961
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    r = RateColumn()
    assert r.render(Progress._ProgressTask("", 23, 123)) == "23 B/s"
    r = RateColumn(unit="B")
    assert r.render(Progress._ProgressTask("", 23, 123)) == "23 B/s"
    r = RateColumn(unit="B", unit_scale=True)
    assert r.render(Progress._ProgressTask("", 23, 123)) == "23 B/s"
    r = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert r.render(Progress._ProgressTask("", 23, 123)) == "23 B/s"
    r = RateColumn(unit="", unit_scale=True)
    assert r.render(Progress._ProgressTask("", 23, 123)) == "23 B/s"

# Generated at 2022-06-24 10:28:45.221546
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=100, unit='B', unit_scale=True, unit_divisor=1024) as pbar:
        pbar.reset(total=100, unit='B', unit_scale=True, unit_divisor=1024)
        pbar.reset(total=100, unit='B', unit_scale=True, unit_divisor=1000)
        pbar.reset(total=1e3, unit='B', unit_scale=True, unit_divisor=1024)
        pbar.reset(total=1e6, unit='B', unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-24 10:28:55.704367
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    try:
        with tqdm(total=10) as pbar:
            pass
    except Exception:
        pass
    else:
        raise AssertionError

    try:
        with tqdm(total=10, disable=True) as pbar:
            pass
    except Exception:
        raise AssertionError


# Generated at 2022-06-24 10:29:00.254545
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    with tqdm_rich(total=100) as t:
        for i in range(10):
            time.sleep(1)
            t.update(10)

if __name__ == '__main__':
    test_tqdm_rich_close()

# Generated at 2022-06-24 10:29:02.745098
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(range(2)) as t:
        for i in t:
            assert (not t.disable)
    assert (not t.disable)

# Generated at 2022-06-24 10:29:09.150252
# Unit test for constructor of class RateColumn
def test_RateColumn():
    x = RateColumn()
    assert x.unit == ''
    x = RateColumn('B/s')
    assert x.unit == 'B/s'
    x = RateColumn(unit='B/s')
    assert x.unit == 'B/s'
    x = RateColumn(unit_scale=True, unit_divisor=1)
    assert x.unit_scale == True
    x = RateColumn(unit_scale=False, unit_divisor=1)
    assert x.unit_scale == False

# Generated at 2022-06-24 10:29:09.828844
# Unit test for constructor of class RateColumn
def test_RateColumn():
    RateColumn()

# Generated at 2022-06-24 10:29:13.080687
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fractionColumn = FractionColumn()
    assert fractionColumn is not None, "FractionColumn() failer. "


# Generated at 2022-06-24 10:29:16.154332
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    progress = tqdm_rich(total=10)
    progress.reset(total=20)
    assert progress.total == 20, 'Method reset of class tqdm_rich'

# Generated at 2022-06-24 10:29:17.887311
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm(total=0) as pbar:
        pbar.close()


# Generated at 2022-06-24 10:29:20.787630
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    total = 1
    with tqdm_rich(total=total) as pbar:
        assert pbar.total == total

        pbar.reset(total=10)
        assert pbar.total == 10


# Generated at 2022-06-24 10:29:25.759070
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test filesize is B
    assert RateColumn().render(object()) == Text("? B/s", style="progress.data.speed")
    # Test filesize is KB
    assert RateColumn().render(object()) == Text("? B/s", style="progress.data.speed")
    # Test filesize is MB
    assert RateColumn().render(object()) == Text("? B/s", style="progress.data.speed")
    # Test filesize is GB
    assert RateColumn().render(object()) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-24 10:29:32.679168
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    class _Progress(Progress):
        def __init__(self):
            super().__init__()
            self.__enter__()
        def __exit__(self, *args, **kwargs):
            self.exited = True
    p = _Progress()
    t = tqdm_rich([1,3,5], total=7, progress=p)
    t.close()
    assert p.exited

# Generated at 2022-06-24 10:29:36.869558
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render
    """
    from .std import tqdm
    from .utils import _range
    import time

    for i in tqdm(_range(1000), disable=True, unit='B'):
        time.sleep(1.0/100)

# Generated at 2022-06-24 10:29:47.521393
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    """Unit test for class FractionColumn"""
    from .tests import string_test
    from .utils import FormatWidget

    string_test(FractionColumn())
    string_test(FractionColumn(unit_scale=True))
    string_test(FractionColumn(unit_scale=True, unit_divisor=1024))
    string_test(FractionColumn(unit_scale=False))

    frac = FractionColumn()
    fw = FormatWidget('test', completed=500, total=1_000)

    string_test(frac.render(fw))

    frac = FractionColumn(unit_scale=True)
    fw = FormatWidget('test', completed=100_000, total=200_000)

    string_test(frac.render(fw))


# Generated at 2022-06-24 10:29:49.509827
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    for i in std_tqdm(range(2)):
        tqdm_rich().clear()

# Generated at 2022-06-24 10:29:59.942343
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    import sys
    task = Progress.Task("test", 50, 100)
    text = FractionColumn().render(task)
    assert text.text == "50.0/100.0 "
    assert text.style == "progress.download"
    if sys.version_info < (3, 0):
        task = Progress.Task("test", 5000, 10000)
        text = FractionColumn(unit_scale=True).render(task)
        assert text.text == "5.0/10.0 K"
        assert text.style == "progress.download"
        task = Progress.Task("test", 5000000000, 10000000000)
        text = FractionColumn(unit_scale=True).render(task)
        assert text.text == "5.0/10.0 G"
        assert text.style == "progress.download"
    task

# Generated at 2022-06-24 10:30:03.253080
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    speed = None
    unit = "bit"
    unit_scale = None
    unit_divisor = 8
    rc = RateColumn(
        unit=unit,
        unit_scale=unit_scale,
        unit_divisor=unit_divisor
    )
    actual = rc.render(speed)
    expected = "0.0 b/s"
    assert actual == expected

# Generated at 2022-06-24 10:30:13.234276
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Create as many test cases for method render as possible.
    """
    # RateColumn.render(None)
    assert RateColumn().render(None) == Text('? /s', style='progress.data.speed')
    # RateColumn.render(Zero)
    assert RateColumn().render(type('', (), {'speed' : 0})) == Text('0 /s', style='progress.data.speed')
    # RateColumn.render(Zero with suffix)
    assert RateColumn('i/s').render(type('', (), {'speed' : 0})) == Text('0 i/s', style='progress.data.speed')
    # RateColumn.render(Small)
    assert RateColumn().render(type('', (), {'speed' : 0.0001})) == Text('0.0 /s', style='progress.data.speed')

# Generated at 2022-06-24 10:30:16.108006
# Unit test for function trange
def test_trange():
    """Test function trange"""
    l = list(trange(int(1e6)))
    assert len(l) == int(1e6)

# Generated at 2022-06-24 10:30:25.303357
# Unit test for function trange
def test_trange():
    """Unit test function trange."""
    from datetime import timedelta
    from rich.console import Console
    from rich.progress import TaskID

    console = Console()
    with tqdm_rich(unit="bkMGTPEZY", unit_scale=True,
                   unit_divisor=1024, miniters=1,
                   mininterval=0.1, maxinterval=0.5) as t:
        for i in trange(1000, leave=True):
            assert isinstance(t.__exit__, type(tqdm_rich.__exit__))
            assert isinstance(t.format_dict, dict)
            assert isinstance(t.bar_format, str)
            assert isinstance(t.get_lock(), type(tqdm_rich.get_lock()))

# Generated at 2022-06-24 10:30:34.655757
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    import numpy as np
    from tqdm._tqdm import format_meter
    from tqdm.std import tqdm as tqdm_std

    def f(x):  # pragma: no cover
        sleep(0.01)
        return x

    with tqdm_rich(range(100), mininterval=1, smoothing=0,
                   total=100) as t:
        for i in t:
            assert t.n == i + 1
            t.reset(total=0)
            assert len(t.format_dict['bar']) == 0
            t.reset(total=100)
            assert t.total == 100
            assert len(t.format_dict['bar']) == 25


# Generated at 2022-06-24 10:30:41.444073
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    progress = tqdm_rich(total=100,
                         unit='B',
                         unit_scale=True,
                         unit_divisor=1024,
                         desc='test')
    progress.n = 10
    assert FractionColumn(unit_scale=True,
                          unit_divisor=1024).render(progress)._text == "9.8/97.7 KiB"
    progress.close()



# Generated at 2022-06-24 10:30:43.963439
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as bar:
        assert bar.disable == False
        bar.close()
        assert bar.disable == True

# Generated at 2022-06-24 10:30:48.871484
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .gui import tgrange
    from .utils import format_sizeof
    from .std import tqdm as std_tqdm

    # tests
    with tgrange(1000, desc='Testing trange') as progress:
        for i in progress:
            _ = [i**2 for i in range(10000)]
    assert format_sizeof(progress.obj) == '3.0 KB'

    with tgrange(1000, bar_format='{l_bar}{bar}{r_bar}',
                 desc='Classic style trange') as progress:
        for i in progress:
            _ = [i**2 for i in range(10000)]
    assert format_sizeof(progress.obj) == '3.0 KB'


# Generated at 2022-06-24 10:30:51.921938
# Unit test for function trange
def test_trange():
    import sys
    import time
    with trange(10, desc='A loop') as t:
        for i in t:
            time.sleep(1)

# Generated at 2022-06-24 10:30:54.842312
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(FractionColumnTestCase("test_FractionColumn"))
    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-24 10:30:58.759684
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate = RateColumn(unit="B", unit_scale=True, unit_divisor=None)
    result = rate.render(tqdm_rich(None, total=100, desc="Test", disable=True))
    assert result.text == "? B/s"
    assert result.style == "progress.data.speed"

# Generated at 2022-06-24 10:31:02.910536
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import tqdm.rich
    tqdm.rich.FractionColumn().render(tqdm.std.tqdm().__dict__)
    return True

# Generated at 2022-06-24 10:31:13.351831
# Unit test for function trange
def test_trange():
    """Simple unit test for trange."""
    from .utils import _decode_unicode
    from .std import FakeTqdmType
    with FakeTqdmType(unit='', unit_scale=False, gui=True, disable=False) as faketqdm:
        for _ in trange(1, 5):
            faketqdm.update()

# Generated at 2022-06-24 10:31:19.967357
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    pbar = tqdm_rich(total=2)
    pbar.update(1)
    pbar.reset(total=5)
    time.sleep(0.5)
    pbar.update(2)
    time.sleep(0.5)
    pbar.update(3)
    time.sleep(0.5)
    pbar.close()

# Generated at 2022-06-24 10:31:21.594640
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with trange(0) as t:
        t.clear()

# Generated at 2022-06-24 10:31:23.238941
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    fraction_column = FractionColumn()
    assert fraction_column is not None



# Generated at 2022-06-24 10:31:30.769298
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    class TqdmRichMock(tqdm_rich):
        def __init__(self, *args, **kwargs):
            self.desc = 'mocked description'
            self.n = 0
            self.total = 0
            super().__init__(*args, **kwargs)

    task = TqdmRichMock()
    task.display()


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:31:35.991419
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=1)
    t.close()
    for _ in tqdm_rich(total=2):
        pass
    try:
        tqdm_rich(total=3).clear()
    except NotImplementedError:
        pass

# Generated at 2022-06-24 10:31:41.136230
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    try:
        from rich import progress
    except:
        return
    with progress.Progress() as progress_bar:
        progress_bar.add_task("Downloading", start=0, total=100)
        pbar = tqdm_rich(total=100)
        assert hasattr(pbar._prog, '_platform')
        pbar.close()
        assert not hasattr(pbar._prog, '_platform')

# Generated at 2022-06-24 10:31:51.005476
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    stuff = {'completed': 0, 'total': 0}
    # - test_FractionColumn_unit_scale_unit_divisor_bytes
    # - test_FractionColumn_unit_scale_unit_divisor_kilobytes
    # - test_FractionColumn_unit_scale_unit_divisor_megabytes
    # - test_FractionColumn_unit_scale_unit_divisor_gigabytes
    # - test_FractionColumn_unit_scale_unit_divisor_terabytes
    # - test_FractionColumn_unit_scale_unit_divisor_petabytes
    # - test_FractionColumn_unit_scale_unit_divisor_exabytes
    # - test_FractionColumn_unit_scale_unit_divisor_zettabytes
    # - test_

# Generated at 2022-06-24 10:31:55.472258
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """Test closing a tqdm_rich object."""
    bar = tqdm_rich(range(5), disable=True).close()
    assert bar.disable is True
    assert bar._task_id is None
    assert bar._prog is None


# Generated at 2022-06-24 10:32:01.307779
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    """
    Test method tqdm_rich.close()
    """
    t = tqdm_rich(total=10)
    assert t.disable == False
    t.close()
    assert t.disable == True

    t = tqdm_rich(disable=True, total=10)
    assert t.disable == True
    t.close()
    assert t.disable == True



# Generated at 2022-06-24 10:32:12.354052
# Unit test for constructor of class RateColumn
def test_RateColumn():
    """Test class RateColumn"""
    progress = Progress(
        "[progress.description]{task.description}"
        "| [progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), ",", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=True, unit_divisor=1000), "]"
    )
    with progress:
        task = progress.add_task("Downloading...", total=1024)
        for _ in range(1024):
            task.update()
            time.sleep(0.1)

if __name__ == '__main__':
    test_RateColumn()

# Generated at 2022-06-24 10:32:13.877800
# Unit test for function trange
def test_trange():
    """Test trange"""
    trange(5).close()

# Generated at 2022-06-24 10:32:23.819028
# Unit test for constructor of class RateColumn
def test_RateColumn():
    import unittest
    class TestRateColumn(unittest.TestCase):
        def test_init(self):
            rate = RateColumn()
            self.assertIsInstance(rate, ProgressColumn)
            self.assertEqual(rate.unit, '')
            self.assertFalse(rate.unit_scale)
            self.assertEqual(rate.unit_divisor, 1000)
            rate = RateColumn(unit='/s', unit_scale=True, unit_divisor=1024)
            self.assertIsInstance(rate, ProgressColumn)
            self.assertEqual(rate.unit, '/s')
            self.assertTrue(rate.unit_scale)
            self.assertEqual(rate.unit_divisor, 1024)

    unittest.main(verbosity=2)

# Generated at 2022-06-24 10:32:25.157268
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    _, _ = tqdm_rich().clear()

# Generated at 2022-06-24 10:32:27.297796
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    rich = tqdm_rich(total=1)
    rich.close()

    rich.disable = True
    rich.close()

# Generated at 2022-06-24 10:32:29.321683
# Unit test for function trange
def test_trange():
    """Test trange with custom position."""
    from .std import trange as tr
    with tr(total=50, position=10) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:32:36.833818
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from datetime import timedelta

    task = std_tqdm(total=100, desc="Desc", unit="B", unit_scale=True)
    # Test with different value of speed
    task.start_t = task.last_print_t = 3.2  # speed = (100-0)/(3.2-3.2) = 0.0
    assert RateColumn(unit=" B/s", unit_scale=True).render(task).content == "0.0  B/s"

    # speed = (100-0)/(3.2-2.2) = 100.0
    task.start_t = task.last_print_t = 2.2
    assert RateColumn(unit=" B/s", unit_scale=True).render(task).content == "100.0  B/s"

    # speed = (

# Generated at 2022-06-24 10:32:44.966670
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    from rich.console import Console
    console = Console()
    task = Task("test_render", 0)
    task.total = 2
    column = FractionColumn()
    columns = [column]
    console.print("[0/2]", style="progress.download")
    task.completed = 1
    console.print("[1/2]", style="progress.download")
    task.total = sys.maxsize
    console.print("[1/2.3G]", style="progress.download")
    task.completed = sys.maxsize
    console.print("[2.3G/2.3G]", style="progress.download")

# Generated at 2022-06-24 10:32:47.968718
# Unit test for constructor of class RateColumn
def test_RateColumn():
    rate_column = RateColumn()
    rate_column = RateColumn(unit="test")
    rate_column = RateColumn(unit="test", unit_scale=True)
    rate_column = RateColumn(unit="test", unit_scale=True, unit_divisor=100)

# Generated at 2022-06-24 10:32:54.013696
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    import rich.console
    import rich.progress

    with rich.console.Console() as c:
        with rich.progress.Progress(transient=True) as task:
            task.start()
            task.__exit__(None, None, None)

    with rich.console.Console() as c:
        with rich.progress.Progress() as task:
            task.start()
            task.__exit__(None, None, None)

# Generated at 2022-06-24 10:33:03.292656
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.add_task('a', total=100000.0)
    task.update(task_id=0, completed=10000.0)
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text(
        '1.0/100.0 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text(
        '1.0/100.0 K', style='progress.download')
    task.update(task_id=0, completed=100000.0)
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text(
        '100.0/100.0 K', style='progress.download')
   

# Generated at 2022-06-24 10:33:09.878981
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(
        description="Downloading...",
        completed=1000,
        total=4000,
    )
    # No scale
    fraction = FractionColumn()
    assert fraction.render(task) == Text(
        "1,000/4,000 ", style="progress.download")
    # Scale = 1000
    fraction = FractionColumn(unit_scale=True)
    assert fraction.render(task) == Text(
        "1/4 K", style="progress.download")
    # Scale = 1024
    fraction = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fraction.render(task) == Text(
        "0.9/3.8 K", style="progress.download")
    # Scale = 1000, large numbers

# Generated at 2022-06-24 10:33:17.934320
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import TaskID

    # to test the method reset
    bar = tqdm_rich(desc='testing method reset', total=5, mininterval=0)

    for i in bar:
        sleep(0.3)  # some work

    # testing new total
    bar.reset(new_total=4)
    assert bar.total == 4

    # testing new description
    bar.reset(desc='testing new description')
    assert bar.desc == 'testing new description'

    # testing different TaskID
    bar.reset()
    assert bar._task_id != TaskID(None)

# Generated at 2022-06-24 10:33:26.762011
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # unit scale is False
    fc = FractionColumn(False)
    assert fc.unit_scale is False
    assert fc.unit_divisor == 1000
    fc = FractionColumn(False, 1000)
    assert fc.unit_scale is False
    assert fc.unit_divisor == 1000
    # unit scale is True by default
    fc = FractionColumn()
    assert fc.unit_scale is True
    assert fc.unit_divisor == 1000
    fc = FractionColumn(True)
    assert fc.unit_scale is True
    assert fc.unit_divisor == 1000
    fc = FractionColumn(True, 1000)
    assert fc.unit_scale is True
    assert fc.unit_divisor == 1000
    fc = Fraction

# Generated at 2022-06-24 10:33:29.818425
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
  """
  Test for method `tqdm.rich.tqdm.display()`.

  Muted from non-tox-env to avoid failing on `No progress bar available`
  when not in interactive mode.
  """
  display_tqdm = tqdm_rich(total=100)
  display_tqdm.display()



# Generated at 2022-06-24 10:33:36.517006
# Unit test for constructor of class RateColumn
def test_RateColumn():
    unit_scales = ["", "K", "M", "G", "T", "P", "E", "Z", "Y"]
    RateColumn().render(Progress(0, 0))  # coverage
    assert all(RateColumn(unit_scale=True).render(
        Progress(1 << (i * 10), 1 << (i * 10))
    ).text.endswith(f'{unit_scales[i]}/s') for i in range(9))

# Generated at 2022-06-24 10:33:42.959941
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from unittest.mock import patch
    from rich.progress import Progress
    from rich.progress import ProgressColumn

    class MockProgress(Progress):
        def __init__(self, columns, *args, **kwargs):
            self.columns = columns
            self._total = 0
            self._completed = 0
            self._percentage = 0

        def __enter__(self, *args, **kwargs):
            return self

        def __exit__(self, *args, **kwargs):
            pass

        def add_task(self, description, **kwargs):
            return 1

        def update(self, task_id, completed, description=None, **kwargs):
            self._completed = completed
            self._total = int(kwargs['total'])
            self._percentage = self._completed/self._

# Generated at 2022-06-24 10:33:53.511936
# Unit test for constructor of class FractionColumn
def test_FractionColumn():
    # progress = (
    #     "[progress.description]{task.description}"
    #     "[progress.percentage]{task.percentage:>4.0f}%",
    #     BarColumn(bar_width=None),
    #     FractionColumn(
    #         unit_scale=d['unit_scale'], unit_divisor=d['unit_divisor']),
    #     "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
    #     ",", RateColumn(unit=d['unit'], unit_scale=d['unit_scale'],
    #                     unit_divisor=d['unit_divisor']), "]"
    # ),
    progress = Progress()
    progress.__enter__()

# Generated at 2022-06-24 10:33:57.051135
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():  # pragma: no cover
    from tqdm.auto import trange
    with trange(2, 3) as t:
        t.reset()

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_rich_reset()

# Generated at 2022-06-24 10:34:04.297464
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import io
    import tempfile
    try:
        from rich.progress import Console
        from rich.theme import Theme
        from rich.panel import Panel
        from rich.text import Text
    except ImportError:
        print("rich.progress module not installed. skipping test")
    else:
        console = Console(file=io.StringIO(), theme=Theme({"progress.download": "bold green"}))
        panel = Panel("Downloading")
        panel.add_column(Text("0.5/2.3 G", style="progress.download"))
        panel.write(console)
        panel.add_column(Text("0.5/2.3 G", style="progress.download"))
        panel.write(console, width=30)
        panel.add_column(Text("0.5/2.3 G", style="progress.download"))

# Generated at 2022-06-24 10:34:11.934713
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """test tqdm_rich.reset()"""
    for _ in tqdm_rich(range(2), desc='A', total=2):
        for _ in tqdm_rich(range(3), desc='B', total=3):
            for _ in tqdm_rich(range(4), desc='C', total=4):
                pass
    for _ in tqdm_rich(range(5), desc='A', total=5):
        for _ in tqdm_rich(range(6), desc='B', total=6):
            for _ in tqdm_rich(range(7), desc='C', total=7):
                pass

# Generated at 2022-06-24 10:34:17.548710
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task(object):
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total
    task = Task(completed=0, total=10)
    column = FractionColumn()
    assert column.render(task) == Text('0.0/10.0 ', style='progress.download')
    task = Task(completed=10000, total=2048)
    assert column.render(task) == Text('4.8/2.0 K', style='progress.download')

# Generated at 2022-06-24 10:34:20.616510
# Unit test for function trange
def test_trange():
    """Test trange function"""
    return tqdm.tests.test_trange.test_trange(trange)



# Generated at 2022-06-24 10:34:26.363706
# Unit test for constructor of class RateColumn
def test_RateColumn():  # pragma: no cover
    assert RateColumn().render(1) == '1  /s'
    assert RateColumn(unit='B').render(1) == '1 B/s'
    assert RateColumn(unit='B').render(1000) == '1,000 B/s'
    assert RateColumn(unit='B', unit_scale=True).render(1000) == '1.0 KB/s'

# Generated at 2022-06-24 10:34:30.304151
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # The expect result is `5 K/s` when calling method `render` of class `RateColumn`
    rate_column = RateColumn(unit="", unit_scale=True, unit_divisor=1000)
    assert '5 K/s' == rate_column.render("5")


# Generated at 2022-06-24 10:34:39.944917
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():  # pragma: no cover
    """Unit test for method display of class tqdm_rich."""
    # Test method display of class tqdm_rich
    with tqdm_rich(total=10) as progressbar:
        for i in range(10):
            progressbar.set_description(f"Step {i + 1}")
            assert progressbar.n == i
            progressbar.update()
    # Test method display of class tqdm_rich
    with tqdm_rich(total=10) as progressbar:
        for i in range(10):
            progressbar.set_description_str(f"Step {i + 1}")
            assert progressbar.n == i
            progressbar.update()
    # Test method display of class tqdm_rich

# Generated at 2022-06-24 10:34:42.416750
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    t = tqdm_rich(1)
    t.close()


# tqdm_rich._prog = Progress(*self._prog, transient=not self.leave)

# Generated at 2022-06-24 10:34:53.506186
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    import math
    Task = Progress(FractionColumn()).__enter__()[0]

    class task_:
        # task.completed and task.total are two given parameters.
        completed = 237
        total = 347
        def __init__(self, task_):
            self.task = task_
    task = task_(task_)

    # a function calls another function
    def test(unit_scale, unit_divisor):
        return Task.render(FractionColumn(unit_scale, unit_divisor).render(task))

    # case 1:
    # unit_scale is False and unit_divisor is 1000
    # Expected text: 237/347 
    assert test(False, 1000) == '237/347 \n'

    # case 2:
    # unit_

# Generated at 2022-06-24 10:35:00.237274
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():  # pragma: no cover
    try:
        import rich
    except ImportError:
        return
    import time
    with tqdm(total=100, desc='Desc1', leave=True) as t:
        t.reset(total=10)
        t.set_description('Desc2')
        time.sleep(0.1)
        t.clear()
        time.sleep(0.1)
        t.set_description('Desc3')
        time.sleep(0.1)
        t.close()

# Generated at 2022-06-24 10:35:09.354814
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import rich.panel
    import rich.console
    import rich.theme
    import rich.style
    import rich.decoration
    from rich.console import Console
    import rich.syntax
    import rich.table

    with Console(highlight=True, highlight_style="pygments", width=80) as console:
        console.print("", style="red")
        console.print(
            "Source: ",
            rich.syntax.Syntax(
                "def foo(x):\n    return x + 1", "python", theme="monokai"),
            justify="left")
        console.print(
            rich.panel.Panel(
                "Tip",
                justify="left",
                style="on black",
                padding=(2, 0, 1, 0),
            ),
            border=False)
        console.print_sty

# Generated at 2022-06-24 10:35:12.020350
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    for _ in tqdm_rich(range(10000)):
        pass

# Generated at 2022-06-24 10:35:21.958128
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import bar_width, total_width
    from rich.progress import Progress, FractionColumn

    progress_args = ["test"]
    progress = Progress(*progress_args)
    progress.__enter__()
    bar = BarColumn(bar_width=None)
    completed_column = FractionColumn()
    total_column = FractionColumn()
    task_id = progress.add_task("", 0, 10, total_width=total_width,
                                total=10)
    assert progress.rows[0].style.bar_color == "progress.default"
    assert progress.rows[0].style.char == bar.char
    assert progress.rows[0].style.color == bar.color

# Generated at 2022-06-24 10:35:32.130259
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    import mock
    from tqdm.rich import FractionColumn

    class TestFractionColumn(unittest.TestCase):
        
        def test_render(self):
            expected = '3.3/1.3 K'
            test_task = mock.Mock()
            test_task.completed = 3353
            test_task.total = 1349
            test_fc = FractionColumn()
            
            self.assertEqual(test_fc.render(test_task), expected)
        
        def test_render_precision(self):
            expected = '3.3/1.3 T'
            test_task = mock.Mock()
            test_task.completed = 333300000
            test_task.total = 134900000
            test_fc = FractionColumn()
            