

# Generated at 2022-06-18 11:49:45.582741
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

# Generated at 2022-06-18 11:49:55.014470
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    task.total = 230
    assert FractionColumn().render(task) == Text("0.2/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.2/1.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.2/1.0 Ki", style="progress.download")
    task.completed = 1
    task.total = 2
    assert FractionColumn().render(task) == Text("1.0/2.0", style="progress.download")

# Generated at 2022-06-18 11:49:56.830594
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:50:02.241329
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:13.902709
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2 ", style="progress.download")
    task = Task(description="test", completed=1024, total=2048)
    assert FractionColumn(unit_scale=True).render(task) == Text("1.0/2.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render

# Generated at 2022-06-18 11:50:25.434149
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B")
    assert rate_column.render(std_tqdm(total=100, unit="B")) == Text("0.0 B/s", style="progress.data.speed")
    assert rate_column.render(std_tqdm(total=100, unit="B", unit_scale=True)) == Text("0.0 B/s", style="progress.data.speed")
    assert rate_column.render(std_tqdm(total=100, unit="B", unit_scale=True, unit_divisor=1000)) == Text("0.0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:34.732849
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=100)
    t = tqdm_rich(total=100, progress=(progress, task_id))
    t.reset(total=200)
    t.close()
    progress.__exit__(None, None, None)
    console.print(progress)

# Generated at 2022-06-18 11:50:46.741386
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_UP
    from rich.padding import Padding
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.traceback import Traceback
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_UP
    from rich.padding import Padding

# Generated at 2022-06-18 11:50:55.101097
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")


# Generated at 2022-06-18 11:51:05.309180
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP, BOX_LIGHT_VERTICAL, BOX_LIGHT_HORIZONTAL
    from rich.padding import Padding
    from rich.border import Border
    from rich.highlighter import RegexHighlighter
    from rich.style import Style
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.panel import Panel
    from rich.padding import Padding

# Generated at 2022-06-18 11:51:18.906140
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn

    console = Console()

# Generated at 2022-06-18 11:51:27.985570
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    import pytest
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text

    class TestColumn(ProgressColumn):
        """
        Test class for method render of class FractionColumn.
        """
        def __init__(self, unit_scale=False, unit_divisor=1000):
            self.unit_scale = unit_scale
            self.unit_divisor = unit_divisor
            super().__init__()

        def render(self, task):
            """
            Test method render of class FractionColumn.
            """
            completed = int(task.completed)
            total = int(task.total)
            if self.unit_scale:
                unit, suffix = filesize.pick_unit

# Generated at 2022-06-18 11:51:38.177577
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import BarColumn, ProgressColumn, TextColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn
    from rich.progress import filesize
    from rich.table import Table
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress
    from rich.progress import BarColumn, ProgressColumn, TextColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn

# Generated at 2022-06-18 11:51:49.257891
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.style import Style
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.console import Console
    from rich.progress import Progress
    from rich.syntax import Syntax
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.text import Text
    from rich.markdown import Markdown

# Generated at 2022-06-18 11:52:01.488112
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    task = Task(description="test", completed=1, total=2048)
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 K", style="progress.download")

# Generated at 2022-06-18 11:52:04.123515
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:52:16.111309
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize

# Generated at 2022-06-18 11:52:27.219086
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50, speed=10)) == Text("10.0 /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=50, speed=10)) == Text("10.0 B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True).render(Progress(total=100, completed=50, speed=10)) == Text("10.0 /s", style="progress.data.speed")
    assert RateColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=100, completed=50, speed=10)) == Text("10.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:52:35.438706
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich.reset()."""
    from time import sleep
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-18 11:52:46.420432
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:04.683047
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress

# Generated at 2022-06-18 11:53:12.616249
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn

# Generated at 2022-06-18 11:53:23.017038
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:34.434364
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:53:44.023479
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    """Test tqdm_rich constructor."""
    from .std import tqdm as std_tqdm
    from .std import tqdm_gui as std_tqdm_gui
    from .std import tqdm_notebook as std_tqdm_notebook
    from .std import tqdm_pandas as std_tqdm_pandas

    assert tqdm_rich is std_tqdm_gui
    assert tqdm is std_tqdm_gui
    assert trange is std_tqdm_gui
    assert tqdm_rich is std_tqdm_notebook
    assert tqdm is std_tqdm_notebook
    assert trange is std_tqdm_notebook
    assert tqdm_rich is std_tqdm_pandas

# Generated at 2022-06-18 11:53:51.906659
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(Progress(total=10, completed=1, speed=1)) == Text("1.0 B/s", style="progress.data.speed")
    assert rate_column.render(Progress(total=10, completed=1, speed=1000)) == Text("1.0 KB/s", style="progress.data.speed")
    assert rate_column.render(Progress(total=10, completed=1, speed=1000000)) == Text("1.0 MB/s", style="progress.data.speed")
    assert rate_column.render(Progress(total=10, completed=1, speed=1000000000)) == Text("1.0 GB/s", style="progress.data.speed")
    assert rate_column

# Generated at 2022-06-18 11:54:00.598930
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="Test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0", style="progress.download")
    task = Task(description="Test", completed=1024, total=2048)
    assert FractionColumn(unit_scale=True).render(task) == Text("1.0/2.0 K", style="progress.download")

# Generated at 2022-06-18 11:54:08.857447
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:54:11.215450
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

# Generated at 2022-06-18 11:54:17.719393
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description='test', total=100, completed=50)
    assert FractionColumn().render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('500.0/1.0 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('488.3/1.0 K', style='progress.download')


# Generated at 2022-06-18 11:54:47.889872
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()

# Generated at 2022-06-18 11:54:59.236977
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BoxStyle
    from rich.padding import Padding
    from rich.border import Border
    from rich.rule import Rule
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import HighlightedSection
    from rich.highlighter import HighlightedText
    from rich.highlighter import HighlightedCode
    from rich.highlighter import HighlightedTable
   

# Generated at 2022-06-18 11:55:08.234013
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.panel import Panel
    from rich.table import Table

# Generated at 2022-06-18 11:55:09.842744
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        t.clear()

# Generated at 2022-06-18 11:55:21.839247
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    # Test case 1
    task = Progress(
        "Test case 1",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False,
                        unit_divisor=1000), "]"
    )
    task.__enter__()
    task_id = task.add_task("Test case 1", total=100, unit="B", unit_scale=False, unit_divisor=1000)
    task.update(task_id, completed=50, speed=50)

# Generated at 2022-06-18 11:55:27.107227
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from tqdm.auto import trange
    from time import sleep
    for i in trange(10, desc='1st loop'):
        sleep(0.01)
    for i in trange(5, desc='2nd loop', leave=True):
        sleep(0.01)
    for i in trange(100, desc='3rd loop'):
        sleep(0.01)

# Generated at 2022-06-18 11:55:37.024730
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn."""
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0", style="progress.download")
    task = Task(description="test", completed=1, total=2048)

# Generated at 2022-06-18 11:55:47.748473
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.box import BOX_DOUBLE, BOX_SINGLE, BOX_HEAVY
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.console import Console
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.markdown import Markdown

# Generated at 2022-06-18 11:55:50.318297
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:55:52.556435
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update()

# Generated at 2022-06-18 11:56:29.931249
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 K", style="progress.download")
    task.total = 1048576
   

# Generated at 2022-06-18 11:56:40.414162
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.completed = 1
    task.total = 2
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    task.total = 1024
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:56:49.976089
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize

# Generated at 2022-06-18 11:56:52.191610
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update(1)

# Generated at 2022-06-18 11:56:59.953506
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import TaskID
    task = TaskID(description='test', completed=0, total=0)
    assert FractionColumn().render(task) == Text('0.0/0.0 ', style='progress.download')
    task = TaskID(description='test', completed=1, total=2)
    assert FractionColumn().render(task) == Text('1.0/2.0 ', style='progress.download')
    task = TaskID(description='test', completed=1, total=2)
    assert FractionColumn(unit_scale=True).render(task) == Text('1.0/2.0 ', style='progress.download')
    task = TaskID(description='test', completed=1000, total=2000)

# Generated at 2022-06-18 11:57:09.318073
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn.
    """
    # Test case 1
    task = tqdm_rich(total=100)
    task.update(1)
    task.update(2)
    task.update(3)
    task.update(4)
    task.update(5)
    task.update(6)
    task.update(7)
    task.update(8)
    task.update(9)
    task.update(10)
    task.update(11)
    task.update(12)
    task.update(13)
    task.update(14)
    task.update(15)
    task.update(16)
    task.update(17)
    task.update(18)
    task.update(19)
    task.update(20)
    task

# Generated at 2022-06-18 11:57:18.835945
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.theme import Theme
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.syntax import Syntax

# Generated at 2022-06-18 11:57:28.598436
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, ProgressColumn, TextColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn, ProgressColumn, TextColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn, ProgressColumn, TextColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn
    from rich.progress import filesize


# Generated at 2022-06-18 11:57:39.389583
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.style import Style
    from rich.padding import Padding
    from rich.border import Border
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import HighlightedCode
    from rich.highlighter import HighlightedSection
    from rich.highlighter import HighlightedText
    from rich.highlighter import Highlighter
    from rich.highlighter import PygmentsHigh

# Generated at 2022-06-18 11:57:48.566541
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Unit test for method display of class tqdm_rich.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import ConsoleOptions
    from rich.progress import ProgressOptions
    from rich.table import TableOptions
    from rich.panel import PanelOptions
    from rich.markdown import MarkdownOptions
    from rich.text import TextOptions
    from rich.style import StyleOptions
    from rich.theme import ThemeOptions
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.panel import Panel