

# Generated at 2022-06-18 11:49:31.289489
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.progress import TaskID
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.padding import Padding
    from rich.measure import Measurement
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import HighlightedCode
    from rich.highlighter import Highlighter
    from rich.highlighter import HighlightRule
    from rich.highlighter import HighlightTarget

# Generated at 2022-06-18 11:49:39.699146
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test method reset of class tqdm_rich.
    """
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.panel import Panel

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)

# Generated at 2022-06-18 11:49:48.469784
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn
    """
    from rich.progress import Task
    task = Task(description="test", completed=0, total=100)
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("0.0 B/s", style="progress.data.speed")
    task.speed = 100
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    task.speed = 1024
    assert rate_column.render(task) == Text("1.0 KB/s", style="progress.data.speed")
    task.speed = 1024 * 1024

# Generated at 2022-06-18 11:49:57.371782
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn
    from rich.progress import RateColumn

# Generated at 2022-06-18 11:50:07.661209
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.measure import Measurement
    from rich.progress import BarColumn, Progress, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn, filesize
    from rich.theme import Theme
    from rich.style import Style
    from rich.text import Text
   

# Generated at 2022-06-18 11:50:19.267215
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=10, total=100)
    column = FractionColumn()
    assert column.render(task) == Text("0.1/1.0 ", style="progress.download")
    column = FractionColumn(unit_scale=True)
    assert column.render(task) == Text("0.1/1.0 ", style="progress.download")
    task = Task(description="test", completed=1000, total=100)
    column = FractionColumn(unit_scale=True)
    assert column.render(task) == Text("1.0/0.1 K", style="progress.download")
    task = Task(description="test", completed=1000000, total=100)
    column = FractionColumn(unit_scale=True)

# Generated at 2022-06-18 11:50:23.041440
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding

# Generated at 2022-06-18 11:50:33.480917
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import sys
    from io import StringIO
    from rich.progress import Progress
    from tqdm.auto import tqdm
    from tqdm.rich import tqdm_rich
    from tqdm.utils import _range

    # Test tqdm_rich.close()
    with StringIO() as our_file:
        with tqdm_rich(_range(10), file=our_file) as t:
            for i in t:
                pass
        assert t.n == 10
        assert t.total == 10
        assert t.last_print_n == 10
        assert t.last_print_refresh_time == t.start_t
        assert t.last_print_t == t.start_t
        assert t.last_print_n == t.n
        assert t.last_print_n == t

# Generated at 2022-06-18 11:50:45.246099
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm(total=100)
    task.update(10)
    task.close()
    task._prog.update(task._task_id, completed=task.n, description=task.desc)
    task._prog.__exit__(None, None, None)
    assert task.format_dict['unit'] == 'i'
    assert task.format_dict['unit_scale'] == False
    assert task.format_dict['unit_divisor'] == 1000
    assert RateColumn(unit=task.format_dict['unit'], unit_scale=task.format_dict['unit_scale'], unit_divisor=task.format_dict['unit_divisor']).render(task) == Text('0.0 i/s', style='progress.data.speed')

# Generated at 2022-06-18 11:50:48.236571
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
    assert t.n == 10


# Generated at 2022-06-18 11:51:04.952822
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.style import Style
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_UP, BOX_LIGHT_VERTICAL
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.syntax import Syntax
    from rich.table import Table
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.progress import Progress
    from rich.console import Console

# Generated at 2022-06-18 11:51:09.240746
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(total=100)
    task.completed = 50
    task.speed = 50
    task.start_time = 0
    task.end_time = 1
    task.update()
    assert RateColumn().render(task).text == "50.0 /s"
    assert RateColumn(unit="B").render(task).text == "50.0 B/s"
    assert RateColumn(unit_scale=True).render(task).text == "50.0 /s"
    assert RateColumn(unit_scale=True, unit_divisor=1024).render(task).text == "50.0 /s"
    assert RateColumn(unit_scale=True, unit_divisor=1000).render(task).text == "50.0 K/s"

# Generated at 2022-06-18 11:51:12.985157
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
        t.reset(total=20)
        for i in range(20):
            t.update()

# Generated at 2022-06-18 11:51:22.501968
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    progress.update(task_id, completed=10)
    progress.update(task_id, completed=20)
    progress.update(task_id, completed=30)
    progress.update(task_id, completed=40)
    progress.update(task_id, completed=50)

# Generated at 2022-06-18 11:51:31.030364
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    # Test 1
    task = Progress()
    task.speed = None
    task.unit = "B"
    task.unit_scale = False
    task.unit_divisor = 1000
    rate_column = RateColumn(unit=task.unit, unit_scale=task.unit_scale, unit_divisor=task.unit_divisor)
    assert rate_column.render(task) == Text(f"? {task.unit}/s", style="progress.data.speed")
    # Test 2
    task = Progress()
    task.speed = 1024
    task.unit = "B"
    task.unit_scale = False
    task.unit_divisor = 1000

# Generated at 2022-06-18 11:51:41.731208
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import TaskID
    from rich.console import Console
    from rich.progress import Progress

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    progress.update(task_id, completed=1)
    time.sleep(0.1)
    progress.update(task_id, completed=2)
    time.sleep(0.1)

# Generated at 2022-06-18 11:51:53.503248
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500.0/1,000.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/976.6 K", style="progress.download")
    task.completed = 0
    assert FractionColumn().render(task) == Text("0.0/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.0/1,000.0 ", style="progress.download")
   

# Generated at 2022-06-18 11:52:06.852823
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn
    """
    from rich.progress import Task
    task = Task(description="test", completed=0, total=1)
    fc = FractionColumn()
    assert fc.render(task) == Text("0.0/1.0", style="progress.download")
    fc = FractionColumn(unit_scale=True)
    assert fc.render(task) == Text("0.0/1.0", style="progress.download")
    fc = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert fc.render(task) == Text("0.0/1.0", style="progress.download")
    task = Task(description="test", completed=1, total=1)
    fc = FractionColumn()

# Generated at 2022-06-18 11:52:18.871508
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Task
    task = Task(completed=0, total=0)
    fraction_column = FractionColumn()
    assert fraction_column.render(task) == Text("0.0/0.0 ", style="progress.download")
    task = Task(completed=1, total=1)
    assert fraction_column.render(task) == Text("1.0/1.0 ", style="progress.download")
    task = Task(completed=1, total=2)
    assert fraction_column.render(task) == Text("1.0/2.0 ", style="progress.download")
    task = Task(completed=1, total=2.5)

# Generated at 2022-06-18 11:52:29.989384
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import ReprHighlighter
    from rich.measure import Measurement
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns

# Generated at 2022-06-18 11:52:47.717342
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.traceback import Traceback
    from rich.padding import Padding
    from rich.markup import Markup
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:52:57.672283
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighters.pygments import PygmentsHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.ansi import AnsiHighlighter
    from rich.highlighters.regex import RegexHighlighter
    from rich.highlighters.ansi_light import AnsiLightHighlighter

# Generated at 2022-06-18 11:53:07.871357
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0.0 B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=1)) == Text("1.0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:18.148321
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:29.183282
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.syntax import PygmentsSyntaxHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.ansi import AnsiHighlighter
    from rich.highlighters.ansi_light import AnsiLightHighlighter


# Generated at 2022-06-18 11:53:39.191936
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.syntax import Syntax
    from rich.highlighters.pygments import PygmentsHighlighter
    from rich.traceback import Traceback
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax

# Generated at 2022-06-18 11:53:48.467262
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test for method render of class RateColumn."""
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_

# Generated at 2022-06-18 11:53:57.836676
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn
    """
    from rich.progress import Task
    task = Task(description="test", completed=0, total=1)
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("? B/s", style="progress.data.speed")
    task.speed = 1000
    assert rate_column.render(task) == Text("1.0 KB/s", style="progress.data.speed")
    task.speed = 1000000
    assert rate_column.render(task) == Text("1.0 MB/s", style="progress.data.speed")
    task.speed = 1000000000

# Generated at 2022-06-18 11:54:05.968183
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map
    from tqdm.contrib.concurrent import thread_map_reduce
    from tqdm.contrib.concurrent import thread_map_reduce_barrier
    from tqdm.contrib.concurrent import thread_map_reduce_barrier_iter
    from tqdm.contrib.concurrent import thread_map_reduce_iter
    from tqdm.contrib.concurrent import thread_map_reduce_iter_barrier
    from tqdm.contrib.concurrent import thread_map_reduce_iter_barrier_iter
    from tqdm.contrib.concurrent import thread

# Generated at 2022-06-18 11:54:12.496050
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement

    console = Console(file=None)
    progress = Progress(
        "Task 1",
        BarColumn(bar_width=None),
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=100)

# Generated at 2022-06-18 11:54:35.200725
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress

    console = Console(file=None)
    progress = Progress(
        Text("[progress.description]{task.description}"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    progress.update(task_id, completed=1)

# Generated at 2022-06-18 11:54:45.250107
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None)

# Generated at 2022-06-18 11:54:56.813652
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.box import Box

# Generated at 2022-06-18 11:55:04.672382
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=True, unit_divisor=1000), "]",
        transient=False,
        console=console)
    task_id = progress.add_task("test", total=100, start=0, completed=0)

# Generated at 2022-06-18 11:55:15.894836
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test RateColumn.render()."""
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object(speed=1)) == Text("1.0 /s", style="progress.data.speed")
    assert rate_column.render(object(speed=1.1)) == Text("1.1 /s", style="progress.data.speed")
    assert rate_column

# Generated at 2022-06-18 11:55:27.107921
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test method display of class tqdm_rich
    """
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmRichDisplay(TestCase):
        """
        Test method display of class tqdm_rich
        """
        @patch('tqdm.rich.tqdm_rich.Progress.update')
        def test_tqdm_rich_display(self, mock_update):
            """
            Test method display of class tqdm_rich
            """
            tqdm_rich_obj = tqdm_rich(total=100)
            tqdm_rich_obj.display()
            mock_update.assert_called_once()

    TestTqdmRichDisplay().test_tqdm_rich_display()

# Generated at 2022-06-18 11:55:37.113067
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.padding import Padding

# Generated at 2022-06-18 11:55:47.711890
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", total=100, completed=50)
    column = FractionColumn()
    assert column.render(task) == Text("0.5/1.0 ", style="progress.download")
    column = FractionColumn(unit_scale=True)
    assert column.render(task) == Text("500.0/1.0 K", style="progress.download")
    column = FractionColumn(unit_scale=True, unit_divisor=1024)
    assert column.render(task) == Text("488.3/1.0 K", style="progress.download")
    column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert column.render(task) == Text("500.0/1.0 K", style="progress.download")


# Generated at 2022-06-18 11:55:57.402295
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.progress import TaskID
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import Highlight, Highlighter
    from rich.highlighter import PygmentsHighlighter
    from rich.highlighter import PygmentsRegexHighlighter
    from rich.highlighter import PygmentsLexer

# Generated at 2022-06-18 11:56:07.027951
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}"),
        Text("[progress.percentage]{task.percentage:>4.0f}%"),
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        Text("["),
        TimeElapsedColumn(),
        Text("<"),
        TimeRemainingColumn(),
        Text(","),
        RateColumn(unit="", unit_scale=False, unit_divisor=1000),
        Text("]"),
    )
    progress.__enter

# Generated at 2022-06-18 11:57:30.555556
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import ReprHighlighter
    from rich.console import Console
    from rich.measure import Measurement
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box

# Generated at 2022-06-18 11:57:41.550560
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 10
    assert FractionColumn().render(task) == Text('0.1/1.0 ', style='progress.download')
    task.completed = 100
    assert FractionColumn().render(task) == Text('1.0/1.0 ', style='progress.download')
    task.completed = 1000
    assert FractionColumn().render(task) == Text('1.0/10.0 ', style='progress.download')
    task.completed = 10000
    assert FractionColumn().render(task) == Text('10.0/100.0 ', style='progress.download')
    task.completed = 100000
    assert FractionColumn().render(task) == Text('100.0/1.0 K', style='progress.download')
    task.completed = 100

# Generated at 2022-06-18 11:57:50.374386
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=50)
    assert rate_column.render(task) == Text("? /s", style="progress.data.speed")
    task.update(speed=50)
    assert rate_column.render(task) == Text("50.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task) == Text("50.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)

# Generated at 2022-06-18 11:57:58.472281
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import Progress
    from rich.progress import ProgressBar
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBarColumn
    from rich.progress import TextColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn


# Generated at 2022-06-18 11:58:05.435805
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:58:14.633829
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress()
    task.speed = None
    assert rate_column.render(task) == Text(f"? /s", style="progress.data.speed")
    task.speed = 1024
    assert rate_column.render(task) == Text(f"1.0 K/s", style="progress.data.speed")
    task.speed = 1024 * 1024
    assert rate_column.render(task) == Text(f"1.0 M/s", style="progress.data.speed")
    task.speed = 1024 * 1024 * 1024
    assert rate_column.render(task) == Text(f"1.0 G/s", style="progress.data.speed")
    task.speed = 1024 * 1024 * 1024 * 1024
   

# Generated at 2022-06-18 11:58:22.962968
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    task = Progress(total=100)
    task.completed = 50
    task.total = 100
    fraction_column = FractionColumn()
    assert fraction_column.render(task) == Text("50.0/100.0 ", style="progress.download")
    task.completed = 50
    task.total = 200
    assert fraction_column.render(task) == Text("50.0/200.0 ", style="progress.download")
    task.completed = 50
    task.total = 300
    assert fraction_column.render(task) == Text("50.0/300.0 ", style="progress.download")
    task.completed = 50
    task.total = 400

# Generated at 2022-06-18 11:58:27.839264
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm.auto import trange
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            time.sleep(0.01)
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            time.sleep(0.01)

# Generated at 2022-06-18 11:58:35.292708
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import TaskID
    task = TaskID(completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2 ", style="progress.download")
    task = TaskID(completed=10, total=20)
    assert FractionColumn().render(task) == Text("10/20 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("10/20 ", style="progress.download")

# Generated at 2022-06-18 11:58:41.241635
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import Fraction