

# Generated at 2022-06-18 11:49:35.802910
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
    pbar.close()

# Generated at 2022-06-18 11:49:43.659445
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.padding import Padding
    from rich.style import Style
    from rich.theme import Theme
    from rich.columns import Columns
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.style import StyleOptions
    from rich.style import StyleType
    from rich.style import StyleGroup
    from rich.style import StyleFactory
    from rich.style import StyleMapping
    from rich.style import StyleSheet

# Generated at 2022-06-18 11:49:48.553722
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(console)
    with progress:
        task = progress.add_task("Test", total=10)
        for i in range(10):
            progress.update(task, completed=i)
        progress.reset(total=20)
        for i in range(20):
            progress.update(task, completed=i)

# Generated at 2022-06-18 11:49:51.420133
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
    assert t.n == 10


# Generated at 2022-06-18 11:50:00.424715
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:05.364075
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import time
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)
            pbar.clear()
            pbar.display()
    assert pbar.n == 10

# Generated at 2022-06-18 11:50:16.920993
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.5/1.0 ', style='progress.download')
    task.total = 1000
    assert FractionColumn().render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.5/1.0 K', style='progress.download')

# Generated at 2022-06-18 11:50:19.128307
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=1) as pbar:
        pbar.close()


# Generated at 2022-06-18 11:50:30.017513
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test that the method reset of class tqdm_rich works correctly.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.style import Style
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.box import Box

# Generated at 2022-06-18 11:50:41.771269
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", total=100, completed=50)
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task = Task(description="test", total=1024, completed=512)
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:50:59.973778
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 1000
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:51:09.941463
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task("test", total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500.0/1.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/1.0 K", style="progress.download")
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 K", style="progress.download")
    task.total = 1025

# Generated at 2022-06-18 11:51:20.001871
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import TextColumn
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBar
    from rich.progress import ProgressDots
    from rich.progress import ProgressSpinner
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import Progress

# Generated at 2022-06-18 11:51:28.944688
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}", justify="right"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    for i in range(100):
        sleep(0.01)
        progress.update(task_id, completed=i)
    progress.reset(total=200)

# Generated at 2022-06-18 11:51:39.549923
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    task = Progress(
        description="Test",
        completed=100,
        total=1000,
        transient=False,
    )
    task.__enter__()
    task.update(task.add_task("Test", completed=100, total=1000))
    task.__exit__(None, None, None)
    assert FractionColumn().render(task) == Text(
        "0.1/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text(
        "100.0/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:51:51.193793
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn
    """
    from rich.progress import Task
    task = Task(description="test", total=100)
    task.completed = 50
    task.speed = 50
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("50.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(task) == Text("48.8 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render

# Generated at 2022-06-18 11:51:53.652460
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()

# Generated at 2022-06-18 11:51:56.893476
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        pbar.clear()
        pbar.update(5)
        pbar.clear()
        pbar.update(5)


# Generated at 2022-06-18 11:52:10.446287
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, TimeElapsedColumn, TimeRemainingColumn, FractionColumn, RateColumn
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress
    from rich.progress import BarColumn, TimeElapsedColumn, TimeRemainingColumn, FractionColumn, RateColumn
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress
    from rich.progress import BarColumn, TimeElapsedColumn, TimeRemainingColumn, FractionColumn, RateColumn
   

# Generated at 2022-06-18 11:52:21.929568
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 1000
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:52:33.582354
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test tqdm_rich.clear()"""
    with tqdm_rich(total=2) as pbar:
        pbar.clear()
        pbar.update()
        pbar.clear()
        pbar.update()

# Generated at 2022-06-18 11:52:44.787377
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import Progress

# Generated at 2022-06-18 11:52:48.120235
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-18 11:52:58.261503
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    task = Task(description="test", completed=1024, total=2048)
    assert FractionColumn(unit_scale=True).render(task) == Text("1.0/2.0 K", style="progress.download")

# Generated at 2022-06-18 11:53:08.493348
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False
    )
    with progress:
        task_id = progress.add_task("Task 1", total=10)
        for i in range(10):
            progress.update(task_id, completed=i)
            sleep(0.1)
        progress.reset(total=20)

# Generated at 2022-06-18 11:53:12.535888
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.completed = 50
    task.speed = 100
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:15.143415
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.clear()
            pbar.update()


# Generated at 2022-06-18 11:53:19.392978
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich.reset() method."""
    with tqdm_rich(total=10) as t:
        for _ in t:
            pass
    t.reset(total=20)
    with tqdm_rich(total=20) as t:
        for _ in t:
            pass

# Generated at 2022-06-18 11:53:22.705788
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
        t.reset(total=20)
        for i in range(20):
            t.update()


# Generated at 2022-06-18 11:53:34.017028
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test method display of class tqdm_rich.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.box import Box
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import Highlighter
    from rich.syntax import Syntax
    from rich.console import ConsoleOptions
    from rich.columns import Columns
    from rich.measure import Measurement
    from rich.prompt import Prompt
    from rich.progress import Progress

# Generated at 2022-06-18 11:53:58.726087
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(1) == Text("1.0 /s", style="progress.data.speed")
    assert rate_column.render(1000) == Text("1.0 K/s", style="progress.data.speed")
    assert rate_column.render(1000000) == Text("1.0 M/s", style="progress.data.speed")
    assert rate_column.render(1000000000) == Text("1.0 G/s", style="progress.data.speed")
    assert rate_column.render(1000000000000) == Text("1.0 T/s", style="progress.data.speed")

# Generated at 2022-06-18 11:54:07.051765
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.table import Table
    from rich.columns import Columns
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel
    from rich.padding import Padding

# Generated at 2022-06-18 11:54:08.376267
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:54:16.841287
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import TaskID
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import TextColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import TaskID
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import TextColumn

# Generated at 2022-06-18 11:54:24.655153
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=10, speed=10)
    assert rate_column.render(task) == Text("10.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task) == Text("10.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(task) == Text("10.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(task) == Text

# Generated at 2022-06-18 11:54:33.109114
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test if the method reset of class tqdm_rich works properly.
    """
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=10)
    for i in tqdm(range(10), desc="Test", progress=(progress, task_id)):
        sleep(0.1)
    progress

# Generated at 2022-06-18 11:54:35.248895
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update(1)
            t.clear()
    assert t.n == 10

# Generated at 2022-06-18 11:54:45.250047
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress.Task(
        description="",
        completed=0,
        total=0,
        start_time=0,
        speed=None,
        eta=None,
        position=0,
    )
    rate_column = RateColumn()
    assert rate_column.render(task) == Text("? /s", style="progress.data.speed")
    task.speed = 0
    assert rate_column.render(task) == Text("0 /s", style="progress.data.speed")
    task.speed = 1
    assert rate_column.render(task) == Text("1 /s", style="progress.data.speed")
    task.speed = 1000
    assert rate_column.render(task) == Text("1K /s", style="progress.data.speed")
    task.speed = 1000000
   

# Generated at 2022-06-18 11:54:54.513041
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=True,
        console=console,
    )
    task_id = progress.add_task("Test", total=100)
    progress.update(task_id, completed=50)
    progress.reset(total=200)
    progress.update(task_id, completed=100)
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:55:03.578998
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, TextColumn, TimeRemainingColumn, TimeElapsedColumn

    console = Console()
    progress = Progress(
        TextColumn("[bold blue]{task.fields[description]}"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    for i in range(100):
        progress.update(task_id, completed=i)


# Generated at 2022-06-18 11:55:46.697782
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.style import Style
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BoxStyle, Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.text import Text
    from rich.table import Table
    from rich.progress import Progress
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BoxStyle, Box

# Generated at 2022-06-18 11:55:53.702355
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.style import Style
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import BarColumn, TextColumn
    from rich.progress import TimeRemainingColumn, TimeElapsedColumn
    from rich.progress import FractionColumn, AbsoluteDeltaColumn
    from rich.progress import PercentageColumn, TaskIDColumn

# Generated at 2022-06-18 11:56:03.378589
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.markdown import MarkdownTable
    from rich.markdown import MarkdownTableColumn
    from rich.markdown import MarkdownTableRow
    from rich.markdown import MarkdownTableCell
    from rich.markdown import MarkdownTableCellAlign
    from rich.markdown import MarkdownTableCellStyle
    from rich.markdown import MarkdownTableCellAlign
    from rich.markdown import MarkdownTableCellStyle
    from rich.markdown import MarkdownTableCellAlign
    from rich.markdown import MarkdownTableCellStyle
    from rich.markdown import MarkdownTableCellAlign

# Generated at 2022-06-18 11:56:12.688007
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.5/1.0 ', style='progress.download')
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.5/1.0 K', style='progress.download')
    task.total = 1024 * 1024

# Generated at 2022-06-18 11:56:15.143522
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()

# Generated at 2022-06-18 11:56:26.501588
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object())

# Generated at 2022-06-18 11:56:36.285443
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table

# Generated at 2022-06-18 11:56:46.228505
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style

    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
    )
    console = Console()

# Generated at 2022-06-18 11:56:55.538259
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object())

# Generated at 2022-06-18 11:57:04.010797
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = tqdm_rich(total=100)
    task.update(50)
    task.close()
    assert FractionColumn().render(task) == Text('50.0/100 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('50.0/100 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('48.0/96.0 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text('50.0/100 ', style='progress.download')