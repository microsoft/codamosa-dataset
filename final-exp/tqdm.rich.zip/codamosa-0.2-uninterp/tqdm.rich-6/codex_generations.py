

# Generated at 2022-06-18 11:49:34.792927
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.box import Box
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.console import Console
    from rich.panel import Panel
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighl

# Generated at 2022-06-18 11:49:36.401303
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-18 11:49:42.287772
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Unit test for method clear of class tqdm_rich"""
    import sys
    from io import StringIO
    from contextlib import contextmanager
    @contextmanager
    def capture_stdout():
        """Capture stdout"""
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    with capture_stdout() as stdout:
        tqdm_rich(range(10), desc='test_tqdm_rich_clear').clear()
    assert stdout.getvalue() == ''

# Generated at 2022-06-18 11:49:51.511363
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    from io import StringIO
    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    with captured_output() as (out, err):
        tqdm_rich(range(10), desc='test_tqdm_rich_clear').clear()
    assert out.getvalue() == ''
    assert err.getvalue() == ''

# Generated at 2022-06-18 11:49:59.140266
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import BarColumn
    from rich.progress import filesize
    from tqdm.rich import RateColumn
    from tqdm.rich import FractionColumn
    from tqdm.rich import tqdm_rich
    from tqdm.rich import trange
    from tqdm.rich import trrange
    from tqdm.rich import tqdm
    from tqdm.rich import trange
    from tqdm.rich import trrange
    from tqdm.rich import tqdm_rich
    from tqdm.rich import trange
    from tqdm.rich import trrange


# Generated at 2022-06-18 11:50:01.819063
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update()

# Generated at 2022-06-18 11:50:04.550227
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:50:16.229473
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.measure import Measurement
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style


# Generated at 2022-06-18 11:50:27.261614
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=0, total=0)
    fc = FractionColumn()
    assert fc.render(task) == Text("0.0/0.0 ", style="progress.download")
    task.completed = 1
    task.total = 1
    assert fc.render(task) == Text("1.0/1.0 ", style="progress.download")
    task.completed = 1
    task.total = 2
    assert fc.render(task) == Text("1.0/2.0 ", style="progress.download")
    task.completed = 1
    task.total = 10
    assert fc.render(task) == Text("1.0/10.0 ", style="progress.download")
    task.completed = 1

# Generated at 2022-06-18 11:50:38.686946
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:54.785367
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_stats
    from .utils import format_line
    from .utils import format_size
    from .utils import format_interval_short
    from .utils import format_interval_long
    from .utils import format_interval_floating
    from .utils import format_interval_guess
    from .utils import format_interval_guess_short
    from .utils import format_interval_guess_long
    from .utils import format_interval_guess_floating

# Generated at 2022-06-18 11:50:58.613174
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import _range
    for i in tqdm(_range(10)):
        pass
    tqdm.reset(total=100)
    for i in tqdm(_range(100)):
        pass

# Generated at 2022-06-18 11:51:07.325929
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        console=console,
    )
    with progress:
        task_id = progress.add_task("Task 1", total=10)
        for i in range(10):
            progress.update(task_id, completed=i + 1)
        progress.reset(total=20)
        for i in range(20):
            progress.update(task_id, completed=i + 1)
    assert progress.completed == 20

# Generated at 2022-06-18 11:51:17.899029
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(0) == Text("0.0 /s", style="progress.data.speed")
    assert rate_column.render(1) == Text("1.0 /s", style="progress.data.speed")
    assert rate_column.render(10) == Text("10.0 /s", style="progress.data.speed")
    assert rate_column.render(100) == Text("100.0 /s", style="progress.data.speed")
    assert rate_column.render(1000) == Text("1.0 K/s", style="progress.data.speed")
    assert rate_column.render

# Generated at 2022-06-18 11:51:25.808927
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}", justify="right"),
        BarColumn(bar_width=None),
        Text("{task.completed}/{task.total}", justify="center"),
        Text("[progress.percentage]{task.percentage:>4.0f}%", justify="left"),
        transient=True,
    )
    with progress:
        for i in tqdm_rich(range(10), desc="Test", progress=progress):
            pass

# Generated at 2022-06-18 11:51:32.870956
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Task
    task = Task(description="test", total=1000)
    task.completed = 500
    task.speed = None
    task.start_time = None
    task.end_time = None
    task.update_time = None
    task.last_print_n = None
    task.last_print_t = None
    task.last_print_n_lines = None
    task.n = None
    task.smoothing = None
    task.dynamic_ncols = None
    task.miniters = None
    task.mininterval = None
    task.maxinterval = None
    task.avg_time = None
    task.avg_size = None

# Generated at 2022-06-18 11:51:35.449034
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        for i in range(100):
            t.clear()
            t.update()


# Generated at 2022-06-18 11:51:46.927397
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test the display method of class tqdm_rich.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel

# Generated at 2022-06-18 11:51:58.049186
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.pygments import PygmentsHighlighter
    from rich.highlighters.terminal import TerminalHighlighter
    from rich.highlighters.ansi import AnsiHighlighter

# Generated at 2022-06-18 11:52:11.520316
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method reset of class tqdm_rich"""
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
    )
    with progress:
        task_id = progress.add_task("Task 1", total=10)
        for _ in range(10):
            sleep(0.1)
            progress.update(task_id, advance=1)
        progress.reset(total=20)

# Generated at 2022-06-18 11:52:30.414383
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighters import HtmlHighlighter
    from rich.highlighters import PygmentsHighlighter
    from rich.highlighters import TerminalHighlighter
    from rich.highlighters import TextHighlighter
    from rich.highlighters import XmlHighlighter

# Generated at 2022-06-18 11:52:41.731956
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("", total=100)
    progress.update(task_id, completed=10)
    progress.reset(total=200)
    progress.update(task_id, completed=20)
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:52:50.494548
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.progress import BarColumn, ProgressColumn, TextColumn, TimeRemainingColumn
    from rich.progress import TimeElapsedColumn, FractionColumn, RateColumn
    from rich.progress import FilesizeColumn, TransferSpeedColumn
    from rich.progress import BarColumn, ProgressColumn, TextColumn, TimeRemainingColumn
    from rich.progress import TimeElapsedColumn, FractionColumn, RateColumn
    from rich.progress import FilesizeColumn, TransferSpeedColumn
    from rich.progress import BarColumn, ProgressColumn

# Generated at 2022-06-18 11:53:00.841845
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .utils import format_sizeof
    from time import sleep

    # Test for method display of class tqdm_rich
    with tqdm(total=100, unit_scale=True, unit='B') as t:
        for i in range(10):
            t.update(10)
            sleep(0.01)
    assert t.n == 100

    # Test for method display of class tqdm_rich
    with tqdm(total=100, unit_scale=True, unit='B') as t:
        for i in range(10):
            t.update(10)
            sleep(0.01)
    assert t.n == 100

    # Test for method display of class tqdm_rich

# Generated at 2022-06-18 11:53:10.317842
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.measure import Measurement
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style


# Generated at 2022-06-18 11:53:20.102778
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Unit test for method render of class FractionColumn."""
    from rich.progress import Task
    task = Task(completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0", style="progress.download")
    task = Task(completed=1, total=10)
    assert FractionColumn().render(task) == Text("0.1/10.0", style="progress.download")

# Generated at 2022-06-18 11:53:31.615819
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn
    from rich.progress import TextColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:53:41.134276
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn.
    """
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(None) != Text("? B/s", style="progress.data.speed2")
    assert rate_column.render(None) != Text("? B/s", style="progress.data.speed3")
    assert rate_column.render(None) != Text("? B/s", style="progress.data.speed4")
    assert rate_column.render(None) != Text("? B/s", style="progress.data.speed5")

# Generated at 2022-06-18 11:53:42.991463
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=10) as t:
        t.clear()


# Generated at 2022-06-18 11:53:51.384925
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    assert FractionColumn().render(Progress(total=10)) == Text('0.0/10.0 ', style='progress.download')
    assert FractionColumn().render(Progress(total=10, completed=5)) == Text('0.5/10.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(Progress(total=10)) == Text('0.0/10.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(Progress(total=10, completed=5)) == Text('0.5/10.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(Progress(total=10)) == Text('0.0/10.0 ', style='progress.download')
    assert FractionColumn

# Generated at 2022-06-18 11:54:22.963508
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}", style="bold"),
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
    )
    progress.__enter__()
    task_id = progress.add_task("Downloading", start=0, total=100)
    progress.update(task_id, completed=10)
    progress.update(task_id, completed=20)
    progress.update(task_id, completed=30)

# Generated at 2022-06-18 11:54:31.250111
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(None) != Text("? /s", style="progress.data.speed1")
    assert rate_column.render(None) != Text("? /s1", style="progress.data.speed")
    assert rate_column.render(None) != Text("1? /s", style="progress.data.speed")
    assert rate_column.render(None) != Text("? /s", style="progress.data.speed1")
    assert rate_column.render(None) != Text("? /s", style="progress.data.speed1")
    assert rate_column.render(None) != Text

# Generated at 2022-06-18 11:54:40.576021
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn
    """
    from rich.progress import Task
    task = Task(total=100, completed=50)
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("0.5 KB/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(task) == Text("500 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-18 11:54:43.369474
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

# Generated at 2022-06-18 11:54:54.409959
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object())

# Generated at 2022-06-18 11:55:03.609823
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn
    from rich.text import Text
    from rich.style import Style

    console = Console()

# Generated at 2022-06-18 11:55:05.543918
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:55:16.892752
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in range(10):
        progress.update(task_id, completed=i+1)
        sleep(0.1)
    progress.reset(total=20)
    for i in range(20):
        progress.update(task_id, completed=i+1)
        sleep(0.1)
   

# Generated at 2022-06-18 11:55:28.407922
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test method render of class RateColumn."""
    from rich.progress import Task
    task = Task(completed=0, total=0, speed=None)
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(task) == Text("? B/s", style="progress.data.speed")
    task = Task(completed=0, total=0, speed=0)
    assert rate_column.render(task) == Text("0 B/s", style="progress.data.speed")
    task = Task(completed=0, total=0, speed=1)
    assert rate_column.render(task) == Text("1 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:30.115002
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as t:
        t.clear()

# Generated at 2022-06-18 11:56:00.982254
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test tqdm_rich.clear()"""
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .std import tqdm_gui as std_tqdm_gui
    from .std import trange_gui as std_trange_gui

    for t in [std_tqdm, std_trange, std_tqdm_gui, std_trange_gui]:
        with t(total=10) as pbar:
            pbar.clear()
            pbar.update()
            pbar.close()

# Generated at 2022-06-18 11:56:10.581405
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import ReprHighlighter
    from rich.console import ConsoleOptions
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.progress import BarColumn, ProgressColumn, TextColumn, TimeRemainingColumn
    from rich.table import Table
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel

# Generated at 2022-06-18 11:56:19.709724
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=20)
    for i in range(20):
        progress.update(task_id, completed=i)
       

# Generated at 2022-06-18 11:56:23.131983
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.auto import tqdm
    import time

    for _ in tqdm(range(10), desc='test', leave=True):
        time.sleep(0.1)

# Generated at 2022-06-18 11:56:26.379844
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test for method clear of class tqdm_rich.
    """
    t = tqdm_rich(total=100)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:56:35.900908
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import HEAVY_HEAD
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:56:38.349197
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.clear()
            pbar.update()

# Generated at 2022-06-18 11:56:48.093537
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0.0 /s", style="progress.data.speed")
    assert rate_column.render(object(speed=1)) == Text("1.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:56:50.734288
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:56:52.235850
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as t:
        t.clear()

# Generated at 2022-06-18 11:57:52.720912
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:58:00.305670
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=True,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("task 1", total=10)
    for i in range(10):
        sleep(0.1)
        progress.update(task_id, completed=i+1)
    progress.reset(total=20)
    task_id = progress.add_task("task 2", total=20)

# Generated at 2022-06-18 11:58:08.195566
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:58:17.229224
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=100, speed=100)) == Text("100.0 /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=100, speed=100)) == Text("100.0 B/s", style="progress.data.speed")
    assert RateColumn(unit_scale=True).render(Progress(total=100, completed=100, speed=100)) == Text("100.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:58:24.544499
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(console=console)
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    t = tqdm_rich(total=100, progress=(), console=console)
    for i in range(100):
        time.sleep(0.01)
        t.update(i)
        progress.update(task_id, completed=i)
    t.close()
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:58:32.887249
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress

    console = Console()
    theme = Theme({
        "progress.download": "bold red",
        "progress.data.speed": "bold green",
    })

# Generated at 2022-06-18 11:58:39.619746
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:58:47.978160
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(None, speed=None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(None, speed=0) == Text("0 /s", style="progress.data.speed")
    assert rate_column.render(None, speed=1) == Text("1 /s", style="progress.data.speed")
    assert rate_column.render(None, speed=1000) == Text("1,000 /s", style="progress.data.speed")
    assert rate_column.render(None, speed=1000000) == Text("1,000,000 /s", style="progress.data.speed")
    assert rate_column.render

# Generated at 2022-06-18 11:58:57.047129
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:59:05.490035
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.syntax import PythonSyntaxHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.ansi import AnsiHighlighter