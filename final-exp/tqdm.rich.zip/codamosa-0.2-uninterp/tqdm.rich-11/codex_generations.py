

# Generated at 2022-06-18 11:49:43.905854
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.table import Table
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.text import Text
    from rich.theme import Theme
    from rich.style import Style
    from rich.padding import Padding
    from rich.panel import Panel
    from rich.table import Table
    from rich.columns import Columns

# Generated at 2022-06-18 11:49:53.409012
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:50:02.376589
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize

# Generated at 2022-06-18 11:50:13.797974
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.style import Style
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.console import Console
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.style import Style
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
   

# Generated at 2022-06-18 11:50:22.709119
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from time import sleep
    from random import random
    from multiprocessing import cpu_count
    from os import getpid

    def f(x):
        sleep(random() / 10)
        return x

    with tqdm(total=100) as pbar:
        for _ in process_map(f, range(100), max_workers=cpu_count()):
            pbar.update()
            pbar.set_description(f"PID: {getpid()}")


# Generated at 2022-06-18 11:50:33.212727
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:44.675035
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == "? B/s"
    assert rate_column.render(object()) == "? B/s"
    assert rate_column.render(object()) == "? B/s"
    assert rate_column.render(object(speed=None)) == "? B/s"
    assert rate_column.render(object(speed=0)) == "0 B/s"
    assert rate_column.render(object(speed=1)) == "1 B/s"
    assert rate_column.render(object(speed=999)) == "999 B/s"

# Generated at 2022-06-18 11:50:56.960499
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:06.607953
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import format_sizeof
    from time import sleep
    from random import random

    def test_reset(total=None):
        with tqdm(total=total) as pbar:
            for i in range(10):
                pbar.update(1)
                sleep(random())
            pbar.reset(total=total)
            for i in range(10):
                pbar.update(1)
                sleep(random())

    for total in [None, 100, 1000]:
        test_reset(total)

    # Test unit_scale
    with tqdm(total=1000, unit_scale=True) as pbar:
        for i in range(10):
            pbar.update(100)
            sleep(random())
        pbar.reset(total=1000)


# Generated at 2022-06-18 11:51:17.091847
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:28.727458
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-18 11:51:39.075175
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsed

# Generated at 2022-06-18 11:51:50.269897
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=10)
    task.completed = 5
    task.total = 10
    assert FractionColumn().render(task) == Text('5.0/10.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('5.0/10.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text('5.0/10.0 ', style='progress.download')
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text('5.0/1.0 K', style='progress.download')
    task.total = 1048576

# Generated at 2022-06-18 11:52:03.165990
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.text import Text
    from rich.style import Style
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import HighlightedCode
    from rich.highlighter import Highlighter
    from rich.highlighter import HighlightedValue
    from rich.highlighter import HighlightedSection

# Generated at 2022-06-18 11:52:15.004477
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task("test", total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0", style="progress.download")
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 K", style="progress.download")
    task.total = 1024 * 1024

# Generated at 2022-06-18 11:52:19.586446
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(total=100)
    task.completed = 50
    task.speed = 100
    rate_column = RateColumn()
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")


# Generated at 2022-06-18 11:52:30.507968
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = std_tqdm(total=100)
    task.update(1)
    task.update(2)
    task.update(3)
    task.update(4)
    task.update(5)
    task.update(6)
    task.update(7)
    task.update(8)
    task.update(9)
    task.update(10)
    task.update(11)
    task.update(12)
    task.update(13)
    task.update(14)
    task.update(15)
    task.update(16)
    task.update(17)
    task.update(18)
    task.update(19)
    task.update(20)
    task.update(21)
    task.update(22)
    task.update(23)
   

# Generated at 2022-06-18 11:52:42.107720
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(Progress(total=1000, completed=500)) == Text("0.5 KB/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(Progress(total=1000, completed=500)) == Text("0.5 KiB/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(Progress(total=1000000, completed=500000)) == Text("0.5 MB/s", style="progress.data.speed")

# Generated at 2022-06-18 11:52:50.692578
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown

# Generated at 2022-06-18 11:53:01.098606
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import TextColumn
    from rich.progress import Columns
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import Progress
    from rich.progress import ProgressBar
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBarColumn

# Generated at 2022-06-18 11:53:15.235092
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description='test', completed=0, total=100)
    assert FractionColumn().render(task) == Text('0.0/100.0 ', style='progress.download')
    task = Task(description='test', completed=100, total=100)
    assert FractionColumn().render(task) == Text('1.0/1.0 ', style='progress.download')
    task = Task(description='test', completed=100, total=1000)
    assert FractionColumn().render(task) == Text('0.1/1.0 ', style='progress.download')
    task = Task(description='test', completed=1000, total=1000)
    assert FractionColumn().render(task) == Text('1.0/1.0 ', style='progress.download')

# Generated at 2022-06-18 11:53:26.218382
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from rich.console import Console
    from rich.progress import TaskID

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)

# Generated at 2022-06-18 11:53:36.745356
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=False, unit_divisor=1000), "]"
    )
    progress.__enter__()
    task_id = progress.add_task("Downloading", total=100, unit="B")
    progress.update(task_id, completed=0, speed=None)
    console.print(progress)
   

# Generated at 2022-06-18 11:53:46.403313
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    # Test case 1
    task = tqdm_rich(total=100)
    task.update(10)
    task.refresh()
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(task) == Text("? B/s", style="progress.data.speed")

    # Test case 2
    task = tqdm_rich(total=100)
    task.update(10)
    task.refresh()
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("? B/s", style="progress.data.speed")

    # Test case 3

# Generated at 2022-06-18 11:53:56.717008
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import sys
    from io import StringIO
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.style import Style
    from rich.box import BOX_DOUBLE, BOX_LIGHT_DOUBLE, BOX_HEAVY_DOUBLE
    from rich.border import Border
    from rich.syntax import Syntax
    from rich.highlighter import Highlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.text import Text
    from rich.progress import Progress
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.padding import Padding


# Generated at 2022-06-18 11:54:04.074324
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn
    """
    from rich.progress import Task
    task = Task()
    task.speed = 100
    task.completed = 100
    task.total = 100
    rate_column = RateColumn()
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(task) == Text("97.66 KB/s", style="progress.data.speed")

# Generated at 2022-06-18 11:54:12.342215
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:54:21.574625
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress.Task()
    task.speed = 100
    task.completed = 100
    task.total = 100
    task.description = "test"
    task.percentage = 100
    task.style = "progress.data.speed"
    task.style_completed = "progress.data.speed"
    task.style_remaining = "progress.data.speed"
    task.style_description = "progress.data.speed"
    task.style_percentage = "progress.data.speed"
    task.style_bar = "progress.data.speed"
    task.style_eta = "progress.data.speed"
    task.style_elapsed = "progress.data.speed"
    task.style_total = "progress.data.speed"
    task.style_unit = "progress.data.speed"


# Generated at 2022-06-18 11:54:30.727164
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.style import Style
    from rich.box import BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.theme import Theme
    from rich.style import Style
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.text import Text
    from rich.padding import P

# Generated at 2022-06-18 11:54:39.489524
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    task = Task(description="test", completed=1, total=1024)
    assert FractionColumn(unit_scale=True).render(task) == Text("0.0/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:55:00.810404
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(Text("[progress.description]{task.description}"),
                        BarColumn(bar_width=None),
                        Text("{task.percentage:>4.0f}%"),
                        transient=True,
                        console=console)
    progress.__enter__()
    task_id = progress.add_task("Downloading", start=0, total=100)
    for i in range(100):
        sleep(0.1)
        progress.update(task_id, completed=i+1)
    progress.reset(total=100)
    for i in range(100):
        sleep(0.1)
        progress.update

# Generated at 2022-06-18 11:55:11.245313
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn."""
    from rich.progress import Task
    task = Task(description="test", total=10)
    task.completed = 5
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 K", style="progress.download")
    task

# Generated at 2022-06-18 11:55:23.190318
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = None
    task.unit = "B"
    task.unit_scale = False
    task.unit_divisor = 1000
    assert RateColumn().render(task) == Text("? B/s", style="progress.data.speed")
    task.speed = 1024
    assert RateColumn().render(task) == Text("1.0 B/s", style="progress.data.speed")
    task.speed = 1024 * 1024
    assert RateColumn().render(task) == Text("1.0 K/s", style="progress.data.speed")
    task.speed = 1024 * 1024 * 1024
    assert RateColumn().render(task) == Text("1.0 M/s", style="progress.data.speed")
    task.speed = 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-18 11:55:31.972773
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=True,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        time.sleep(0.1)
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:55:41.940367
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    class Task:
        def __init__(self, completed, total):
            self.completed = completed
            self.total = total

    task = Task(completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text("0.5/2.0 K", style="progress.download")
    assert Fraction

# Generated at 2022-06-18 11:55:51.420973
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.markup import Markup
    from rich.panel import Panel
    from rich.table import Table
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.rule import Rule
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.theme import Theme
    from rich.style import Style
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    from rich.markup import Markup
    from rich.panel import Panel

# Generated at 2022-06-18 11:56:01.127914
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=False)

# Generated at 2022-06-18 11:56:10.845502
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:56:20.730479
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import Progress
    from rich.progress import ProgressBar
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn

# Generated at 2022-06-18 11:56:31.021097
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:57:01.175027
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.style import Style
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.console import Console
    from rich.progress import Progress
    from rich.panel import Panel

# Generated at 2022-06-18 11:57:03.197759
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    rate_column.render(None)

# Generated at 2022-06-18 11:57:12.411807
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    from rich.progress import Task

    class TestFractionColumn(unittest.TestCase):
        def test_render(self):
            task = Task(completed=0, total=0)
            self.assertEqual(FractionColumn().render(task), Text("0.0/0.0"))

            task = Task(completed=1, total=1)
            self.assertEqual(FractionColumn().render(task), Text("1.0/1.0"))

            task = Task(completed=1, total=2)
            self.assertEqual(FractionColumn().render(task), Text("1.0/2.0"))

            task = Task(completed=1, total=2.5)

# Generated at 2022-06-18 11:57:22.522196
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import BarColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn

# Generated at 2022-06-18 11:57:32.538012
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:57:43.485255
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:57:52.261591
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighters.pygments import PygmentsHighlighter

    console = Console(file=None)
    progress = Progress(
        Text("[progress.description]{task.description}", style="progress.description"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=10)

# Generated at 2022-06-18 11:57:59.841755
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn

    console = Console()

# Generated at 2022-06-18 11:58:05.900223
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(
        "test",
        BarColumn(bar_width=None),
        RateColumn(unit="B", unit_scale=False, unit_divisor=1000),
    )
    task.__enter__()
    task_id = task.add_task("test", total=100, unit="B", unit_scale=False, unit_divisor=1000)
    task.update(task_id, completed=50, speed=100)
    task.__exit__(None, None, None)
    assert task.render() == "[progress.description]test [progress.percentage] 50% [██████████████████████████████████████████████████] 100.0 B/s"

# Generated at 2022-06-18 11:58:15.091484
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B").render(Progress(total=100, completed=10, speed=10)) == Text("1.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(Progress(total=100, completed=10, speed=10)) == Text("1.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(Progress(total=100, completed=10, speed=1000)) == Text("1.0 K/s", style="progress.data.speed")