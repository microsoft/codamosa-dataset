

# Generated at 2022-06-18 11:49:38.639827
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500/1,000 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/976.6 K", style="progress.download")


# Generated at 2022-06-18 11:49:44.818586
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500.0/1.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/1.0 K", style="progress.download")


# Generated at 2022-06-18 11:49:54.412864
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")

    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

    rate_column = RateColumn

# Generated at 2022-06-18 11:49:59.067488
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    for i in tqdm(_range(10), total=10):
        sleep(0.1)
    for i in tqdm(_range(10), total=10):
        sleep(0.1)
    for i in tqdm(_range(10), total=10):
        sleep(0.1)

# Generated at 2022-06-18 11:50:09.766070
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.highlighters.pygments import PygmentsHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.terminal import TerminalHighlighter
    from rich.highlighters.ansi import AnsiHighlighter
    from rich.highlighters.ansi_dark import AnsiDarkHighlighter
    from rich.highlighters.ansi_light import AnsiLightHighlighter


# Generated at 2022-06-18 11:50:21.773449
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, TextColumn, TimeRemainingColumn, TimeElapsedColumn, FractionColumn
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import ConsoleOptions
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.text import Text
    from rich.box import Box
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import Console

# Generated at 2022-06-18 11:50:23.678269
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    t = tqdm_rich(total=10)
    t.display()
    t.close()

# Generated at 2022-06-18 11:50:33.716761
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test the method reset of class tqdm_rich.
    """
    # Test reset with total
    with tqdm_rich(total=10) as t:
        t.reset(total=20)
        assert t.total == 20
        t.reset(total=30)
        assert t.total == 30
    # Test reset without total
    with tqdm_rich(total=10) as t:
        t.reset()
        assert t.total == 10
        t.reset()
        assert t.total == 10
    # Test reset with total=0
    with tqdm_rich(total=10) as t:
        t.reset(total=0)
        assert t.total == 0
        t.reset(total=0)
        assert t.total == 0

# Generated at 2022-06-18 11:50:45.528597
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    from .std import tqdm
    from .utils import _range
    from .std import format_sizeof
    import time
    import sys
    import os

    # Test for RateColumn

# Generated at 2022-06-18 11:50:57.642341
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.auto import trange as trange_auto
    from tqdm.auto import tqdm_gui as tqdm_gui_auto
    from tqdm.auto import trange_gui as trange_gui_auto
    from tqdm.auto import tqdm_notebook as tqdm_notebook_auto
    from tqdm.auto import trange_notebook as trange_notebook_auto


# Generated at 2022-06-18 11:51:05.096131
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:51:09.394830
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import unittest
    class TestRateColumn(unittest.TestCase):
        def test_RateColumn_render(self):
            self.assertEqual(RateColumn(unit="B").render(None), "? B/s")
            self.assertEqual(RateColumn(unit="B").render(None), "? B/s")
            self.assertEqual(RateColumn(unit="B", unit_scale=True).render(None), "? B/s")
            self.assertEqual(RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(None), "? B/s")
            self.assertEqual(RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(None), "? B/s")

# Generated at 2022-06-18 11:51:16.692903
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmRichDisplay(TestCase):
        @patch('tqdm.rich.tqdm_rich.Progress.update')
        def test_display(self, mock_update):
            t = tqdm_rich(total=10)
            t.display()
            mock_update.assert_called_once_with(
                t._task_id, completed=0, description='')

    TestTqdmRichDisplay().test_display()

# Generated at 2022-06-18 11:51:25.911713
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
        console=console
    )
    progress.__enter__()
    task_id = progress.add_task("task1", total=10)
    progress.update(task_id, completed=5)
    progress.reset(total=20)
    progress.update(task_id, completed=10)
    progress.__exit__(None, None, None)
    assert console.get_text() == 'task1\n[██████████▌                 ] 25%\n'

# Generated at 2022-06-18 11:51:32.755115
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    console = Console()
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")
    console.print("[bold]Test tqdm_rich.display()[/bold]")

# Generated at 2022-06-18 11:51:43.990250
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.measure import Measurement

    console = Console(file=None, force_terminal=True)
    theme = Theme({
        "progress": Style(color="white", background_color="blue"),
        "progress.download": Style(color="white", background_color="blue"),
        "progress.data.speed": Style(color="white", background_color="blue"),
    })

# Generated at 2022-06-18 11:51:55.496718
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    from rich.progress import ProgressColumn, ProgressBar, ProgressDots, ProgressSpinner
    from rich.progress import ProgressTime, ProgressText, ProgressBarColumn
    from rich.progress import ProgressSpinnerColumn, ProgressDotsColumn, ProgressTimeColumn
    from rich.progress import ProgressTextColumn, ProgressColumn, Progress
    from rich.progress import BarColumn, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn, filesize
    from rich.progress import FractionColumn, RateColumn

# Generated at 2022-06-18 11:52:08.603776
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = None
    task.unit = "B"
    task.unit_scale = False
    task.unit_divisor = 1000
    rate_column = RateColumn(unit=task.unit, unit_scale=task.unit_scale, unit_divisor=task.unit_divisor)
    assert rate_column.render(task) == Text(f"? {task.unit}/s", style="progress.data.speed")
    task.speed = 1000
    assert rate_column.render(task) == Text(f"1.0 {task.unit}/s", style="progress.data.speed")
    task.speed = 1000000
    assert rate_column.render(task) == Text(f"1.0 K{task.unit}/s", style="progress.data.speed")


# Generated at 2022-06-18 11:52:20.355095
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=0, total=100)
    assert FractionColumn().render(task) == Text("0.0/100.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.0/100.0", style="progress.download")
    task = Task(description="test", completed=100, total=100)
    assert FractionColumn().render(task) == Text("100.0/100.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("100.0/100.0", style="progress.download")
    task = Task(description="test", completed=100, total=1000)

# Generated at 2022-06-18 11:52:31.278424
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    import pytest
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import BarColumn
    from rich.progress import filesize
    from tqdm.rich import tqdm_rich
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange
    from tqdm.rich import trange

# Generated at 2022-06-18 11:52:49.231614
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test the method reset of class tqdm_rich.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_HORIZONTAL, BOX_DOUBLE_VERTICAL, BOX_DOUBLE_UP, BOX_DOUBLE_LEFT, BOX_DOUBLE_RIGHT, BOX_SINGLE_DOWN, BOX_SINGLE_HORIZONTAL, BOX_SINGLE_VERTICAL, BOX_SINGLE_UP, BOX_SING

# Generated at 2022-06-18 11:52:59.464422
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import Time

# Generated at 2022-06-18 11:53:09.284704
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID

# Generated at 2022-06-18 11:53:19.101539
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import ConsoleOptions
    from rich.progress import ProgressOptions

    # Create a console

# Generated at 2022-06-18 11:53:30.102747
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test method reset of class tqdm_rich.
    """
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}", justify="right"),
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=20)

# Generated at 2022-06-18 11:53:31.852224
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(range(10))
    t.clear()

# Generated at 2022-06-18 11:53:41.405570
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(
        "Downloading",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=True, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=True,
                        unit_divisor=1000), "]"
    )
    task.__enter__()
    task_id = task.add_task("test", total=100)
    task.update(task_id, completed=100, speed=100)
    task.__exit__(None, None, None)

# Generated at 2022-06-18 11:53:43.548401
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test that method clear of class tqdm_rich does not raise an exception.
    """
    tqdm_rich(total=10).clear()

# Generated at 2022-06-18 11:53:51.666683
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50)) == Text('? /s', style='progress.data.speed')
    assert RateColumn().render(Progress(total=100, completed=50, speed=10)) == Text('10 /s', style='progress.data.speed')
    assert RateColumn(unit='B').render(Progress(total=100, completed=50, speed=10)) == Text('10 B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True).render(Progress(total=100, completed=50, speed=10)) == Text('10 B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True, unit_divisor=1024).render(Progress(total=100, completed=50, speed=10))

# Generated at 2022-06-18 11:54:00.460617
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import sys
    from io import StringIO
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import BarColumn
    from rich.progress import TextColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import ProgressColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.text import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize

# Generated at 2022-06-18 11:54:25.345291
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.syntax import Syntax
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import HighlightedCode
    from rich.highlighter import HighlightedSection
    from rich.highlighter import HighlightedTable
    from rich.highlighter import HighlightedText
    from rich.highlighter import Highlight

# Generated at 2022-06-18 11:54:32.446308
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.box import BoxStyle
    from rich.style import Style
    from rich.theme import Theme
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.measure import Measurement
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress
    from rich.box import BoxStyle
    from rich.style import Style
    from rich.theme import Theme

# Generated at 2022-06-18 11:54:42.045825
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]",
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("", total=10)
    progress.update(task_id, completed=5)
    progress.reset(total=20)
    progress.update

# Generated at 2022-06-18 11:54:52.846025
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.completed = 100
    task.total = 200
    task.unit_scale = False
    task.unit_divisor = 1000
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(task) == Text(
        f"{100/1:,.0f}/{200/1:,.0f} ", style="progress.download")
    task.unit_scale = True
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text(
        f"{100/1:,.0f}/{200/1:,.0f} ", style="progress.download")
    task.unit_scale = False
    task.unit_divisor = 1024

# Generated at 2022-06-18 11:54:56.340799
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:02.662672
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.theme import Theme
    from rich.console import ConsoleOptions
    from rich.markdown import MarkdownOptions
    from rich.table import TableOptions
    from rich.progress import ProgressOptions
    from rich.syntax import SyntaxOptions
    from rich.padding import PaddingOptions
    from rich.highlighter import HighlighterOptions

# Generated at 2022-06-18 11:55:13.264910
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(
        description="Downloading",
        completed=0,
        total=100,
        speed=100,
        start_time=0,
    )
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(task) == Text("97.7 K/s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:16.349326
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.update()
            pbar.clear()
            pbar.display()

# Generated at 2022-06-18 11:55:27.805156
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    # Test case 1
    task = Progress(total=100)
    task.completed = 50
    task.total = 100
    task.unit_scale = False
    task.unit_divisor = 1000
    fraction_column = FractionColumn(unit_scale=task.unit_scale, unit_divisor=task.unit_divisor)
    assert fraction_column.render(task) == Text("50.0/100.0 ", style="progress.download")

    # Test case 2
    task = Progress(total=100)
    task.completed = 50
    task.total = 100
    task.unit_scale = True
    task.unit_divisor = 1000

# Generated at 2022-06-18 11:55:37.643306
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=20)
    for i in range(20):
        progress.update(task_id, completed=i)
        sleep(0.1)

# Generated at 2022-06-18 11:56:29.765733
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
   

# Generated at 2022-06-18 11:56:39.969798
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0 B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=1)) == Text("1 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:56:44.193546
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import ReprHighlighter
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_HORIZONTAL, BOX_DOUBLE_UP, BOX_DOUBLE_VERTICAL, BOX_LIGHT_DOWN, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_UP, BOX_LIGHT_VERTICAL, BOX_SINGLE_DOWN, BOX_SINGLE_HORIZONTAL, BOX_SINGLE_UP, BOX_SINGLE_VERTICAL, BOX_SOL

# Generated at 2022-06-18 11:56:53.591509
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    task = Progress(total=100)
    task.completed = 50
    task.total = 230
    assert FractionColumn().render(task) == Text("0.2/0.2 K", style="progress.download")
    assert FractionColumn(unit_scale=False).render(task) == Text("0.2/0.2", style="progress.download")
    assert FractionColumn(unit_divisor=1024).render(task) == Text("0.2/0.2 K", style="progress.download")
    task.completed = 100
    task.total = 230
    assert FractionColumn().render(task) == Text("0.4/0.2 K", style="progress.download")
    assert FractionColumn(unit_scale=False).render

# Generated at 2022-06-18 11:57:00.879146
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.measure import Measurement
    from rich.box import Box
    from rich.rule import Rule
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.measure import Measurement
    from rich.box import Box
   

# Generated at 2022-06-18 11:57:03.311616
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()


# Generated at 2022-06-18 11:57:05.511390
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:57:14.494482
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.columns import Columns
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter

# Generated at 2022-06-18 11:57:24.522833
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(1) == Text("1.0 /s", style="progress.data.speed")
    assert rate_column.render(1000) == Text("1.0 K/s", style="progress.data.speed")
    assert rate_column.render(1000000) == Text("1.0 M/s", style="progress.data.speed")
    assert rate_column.render(1000000000) == Text("1.0 G/s", style="progress.data.speed")
    assert rate_column.render(1000000000000) == Text("1.0 T/s", style="progress.data.speed")

# Generated at 2022-06-18 11:57:34.852271
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, TextColumn, TimeRemainingColumn, TimeElapsedColumn

    console = Console()
    progress = Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)
    for i in range(10):
        sleep(0.1)
        progress.update(task_id, completed=i)
    progress.reset(total=5)

# Generated at 2022-06-18 11:59:09.698759
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:59:17.199049
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}"),
        Text("[progress.percentage]{task.percentage:>4.0f}%"),
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        Text("["), TimeElapsedColumn(), Text("<"), TimeRemainingColumn(),
        Text(","), RateColumn(unit="", unit_scale=False, unit_divisor=1000), Text("]")
    )
    progress.__enter__()

# Generated at 2022-06-18 11:59:22.026830
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    # Test 1
    task = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
    )
    task.__enter__()
    task_id = task.add_task("", total=100, unit="", unit_scale=False, unit_divisor=1000)
    task.update(task_id, completed=50, speed=None)
   

# Generated at 2022-06-18 11:59:29.885986
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, ProgressColumn, TextColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn
    from rich.progress import filesize
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text
    from rich.console import Console
    from rich.progress import Progress