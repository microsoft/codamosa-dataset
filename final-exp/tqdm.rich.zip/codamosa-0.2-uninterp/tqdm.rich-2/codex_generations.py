

# Generated at 2022-06-18 11:49:41.680500
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():  # pragma: no cover
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.box import BOX_DOUBLE
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.text import Text
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.theme import Theme

# Generated at 2022-06-18 11:49:50.963352
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.console import Console
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns

# Generated at 2022-06-18 11:49:58.875923
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:09.504835
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.padding import Padding
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress
    from rich.console import Console
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.panel import Panel

# Generated at 2022-06-18 11:50:21.086489
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import TaskID

    console = Console()
    progress = Progress()
    task_id = progress.add_task("", total=100)
    progress.update(task_id, completed=50)
    progress.render(console)
    assert console.output == "[progress.description]\n" \
                             "[progress.percentage] 50%\n" \
                             "[progress.bar]\n" \
                             "[progress.download] 0.5/2.0 \n" \
                             "[progress.data.speed] 0.0 /s\n" \
                             "[progress.data.eta] 0:00:00<0:00:00, 0.0 /s"

# Generated at 2022-06-18 11:50:28.699319
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500.0/1,000.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/977.0 K", style="progress.download")


# Generated at 2022-06-18 11:50:31.458079
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:50:34.678708
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test that method clear of class tqdm_rich does not raise an exception.
    """
    t = tqdm_rich(total=10)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:50:46.583283
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.highlighters.syntax import PythonHighlighter
    from rich.theme import Theme
    from rich.style import Style
    from rich.console import Console
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown


# Generated at 2022-06-18 11:50:58.578295
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Task
    task = Task(description="Test", completed=1, total=2)
    fraction_column = FractionColumn()
    assert fraction_column.render(task) == Text("0.5/2.0 ", style="progress.download")
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)
    assert fraction_column.render(task) == Text("0.5/2.0 ", style="progress.download")
    task = Task(description="Test", completed=1, total=1000)
    fraction_column = FractionColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-18 11:51:05.041209
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
    assert t.n == 10

# Generated at 2022-06-18 11:51:15.479946
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:24.780240
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .std import trange
    from .std import tqdm_gui
    from .std import tgrange
    from .std import tqdm_notebook
    from .std import tnrange
    from .std import tqdm_pandas
    from .std import tqdm_pandas
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui
    from .std import tqdm_gui

# Generated at 2022-06-18 11:51:32.335135
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test method reset of class tqdm_rich.
    """
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in tqdm(range(10), desc="Task 1", progress=(progress, task_id)):
        sleep(0.1)
    progress.reset

# Generated at 2022-06-18 11:51:43.572704
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=0, total=0)
    column = FractionColumn()
    assert column.render(task) == Text("0.0/0.0 ", style="progress.download")
    task.completed = 1
    task.total = 2
    assert column.render(task) == Text("0.5/2.0 ", style="progress.download")
    task.completed = 1
    task.total = 2.3
    assert column.render(task) == Text("0.5/2.3 ", style="progress.download")
    task.completed = 1
    task.total = 2.3
    column = FractionColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-18 11:51:55.184907
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:52:08.551294
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.padding import Padding
    from rich.box import BoxStyle
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme

# Generated at 2022-06-18 11:52:10.809351
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=100)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:52:14.528113
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
        t.reset(total=20)
        for i in range(20):
            t.update()

# Generated at 2022-06-18 11:52:26.061316
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    import unittest
    from rich.progress import Task
    task = Task(description="test", total=100)
    task.completed = 50
    column = FractionColumn()
    assert column.render(task) == Text("0.5/1.0 ", style="progress.download")
    task.completed = 100
    assert column.render(task) == Text("1.0/1.0 ", style="progress.download")
    task.completed = 0
    assert column.render(task) == Text("0.0/1.0 ", style="progress.download")
    task.completed = 0.5
    assert column.render(task) == Text("0.5/1.0 ", style="progress.download")
    task.completed = 0.5
    task.total = 0.5

# Generated at 2022-06-18 11:52:45.111595
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    task.total = 100
    assert FractionColumn().render(task) == Text("0.5/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0", style="progress.download")
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 K", style="progress.download")
    task.total = 1024 * 1024

# Generated at 2022-06-18 11:52:56.373795
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.box import HEAVY_HEAD
    from rich.padding import Padding
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.highlighters import RegexHighlighter
    from rich.highlighters.syntax import PythonSyntaxHighlighter
    from rich.highlighters.syntax import JavaScriptSyntaxHighlighter
    from rich.highlighters.syntax import BashSyntaxHighlighter
    from rich.highlighters.syntax import CssSyntaxHighlighter
    from rich.highlighters.syntax import Html

# Generated at 2022-06-18 11:53:06.776629
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import TextColumn
    from rich.progress import TaskIDColumn
    from rich.progress import Progress
    from rich.progress import ProgressBarColumn
    from rich.progress import ProgressColumn
    from rich.progress import ProgressTextColumn
    from rich.progress import ProgressTimeColumn
    from rich.progress import ProgressTimeRemainingColumn

# Generated at 2022-06-18 11:53:15.688335
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.style import Style
    from rich.box import BOX_LIGHT_HORIZONTAL, BOX_LIGHT_DOWN_AND_RIGHT, BOX_LIGHT_UP_AND_RIGHT
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.theme import Theme
    from rich.style import Style
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown

# Generated at 2022-06-18 11:53:26.500972
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description='test', completed=0, total=100)
    assert FractionColumn().render(task) == Text('0.0/100.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.0/100.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.0/100.0 ', style='progress.download')
    task = Task(description='test', completed=100, total=100)
    assert FractionColumn().render(task) == Text('100.0/100.0 ', style='progress.download')

# Generated at 2022-06-18 11:53:31.252157
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress.Task(total=100, completed=50, speed=50)
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("50.0 KB/s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:40.998900
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    from rich.progress import filesize
    from rich.style import Style
    from rich.theme import Theme
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    from rich.progress import filesize
    from rich.panel import Panel

# Generated at 2022-06-18 11:53:49.913202
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
        console=console,
        color_system="truecolor",
        width=80,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    for i in range(100):
        progress.update(task_id, completed=i)
        sleep(0.01)
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:53:55.863482
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    import time
    with Progress() as progress:
        task = progress.add_task("Test", start=0, total=10)
        for i in range(10):
            progress.update(task, completed=i+1)
            time.sleep(0.1)
        progress.reset(total=20)
        for i in range(20):
            progress.update(task, completed=i+1)
            time.sleep(0.1)

# Generated at 2022-06-18 11:54:03.495240
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import TaskID
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn

# Generated at 2022-06-18 11:54:42.297867
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import install
    install()

    console = Console()
    theme = Theme({
        "progress.download": Style(color="green"),
        "progress.data.speed": Style(color="blue"),
    })
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )

# Generated at 2022-06-18 11:54:44.291175
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=1)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:54:55.505332
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress(
        description="Downloading",
        transient=True,
        console=None,
        columns=(
            "[progress.description]{task.description}",
            "[progress.percentage]{task.percentage:>4.0f}%",
            BarColumn(bar_width=None),
            FractionColumn(unit_scale=False, unit_divisor=1000),
            "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
            ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
        )
    )
    task.__enter__()
    task_id = task.add_task("Downloading", total=100, completed=0,
                            unit="B", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-18 11:55:04.150848
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        with tqdm_rich(total=2) as pbar:
            pbar.clear()
            pbar.update()
            pbar.clear()
            pbar.update()
            pbar.clear()
            pbar.update()

# Generated at 2022-06-18 11:55:15.295624
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:26.972350
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.measure import Measurement
    from rich.theme import Theme
    from rich.style import Style
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.syntax import SyntaxHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.ansi import AnsiHighlighter
    from rich.highlighters.ansi_light import AnsiLightHighlighter

# Generated at 2022-06-18 11:55:36.850589
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object(speed=None)) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object(speed=0)) == Text("0.0 /s", style="progress.data.speed")
    assert rate_column.render(object(speed=1)) == Text("1.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:47.702166
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    with tqdm_rich(total=5) as pbar:
        for i in range(5):
            pbar.update()
            assert pbar.n == i + 1
            assert pbar.desc == ''
            assert pbar.total == 5
            assert pbar.unit == ''
            assert pbar.unit_scale == False
            assert pbar.unit_divisor == 1000
            assert pbar.miniters == 1
            assert pbar.mininterval == 0.1
            assert pbar.maxinterval == 10
            assert pbar.dynamic_miniters == False
            assert pbar.smoothing == 0.3
            assert pbar.avg_time == 0
            assert pbar.last_print_n == 0
            assert pbar.last_print_t == 0
            assert pbar

# Generated at 2022-06-18 11:55:57.310430
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
        console=console
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=20)

# Generated at 2022-06-18 11:56:07.121723
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test the method clear of class tqdm_rich.
    """
    from .std import tqdm as std_tqdm
    from .std import tqdm_gui as gui_tqdm
    from .std import tqdm_notebook as notebook_tqdm
    from .std import tqdm_pandas as pandas_tqdm
    from .std import tqdm_stdout as stdout_tqdm
    from .std import tqdm_wget as wget_tqdm
    from .std import tqdm_gui as gui_tqdm
    from .std import tqdm_gui as gui_tqdm

    # Test the method clear of class tqdm_rich

# Generated at 2022-06-18 11:56:41.552683
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(std_tqdm(total=1000, unit="B", unit_scale=False, unit_divisor=1000)) == Text("0.0 B/s", style="progress.data.speed")
    assert rate_column.render(std_tqdm(total=1000, unit="B", unit_scale=False, unit_divisor=1000, miniters=1)) == Text("0.0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:56:51.116766
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.measure import Measurement
    from rich.markdown import Markdown
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax

# Generated at 2022-06-18 11:56:53.503203
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm(total=100) as pbar:
        for i in range(100):
            pbar.update(1)
            pbar.clear()


# Generated at 2022-06-18 11:57:00.739991
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    # Test case 1
    task = tqdm_rich(total=100)
    task.n = 0
    task.start_t = 0
    task.last_print_t = 0
    task.total = 100
    task.dynamic_ncols = True
    task.miniters = 1
    task.mininterval = 0.1
    task.maxinterval = 10
    task.smoothing = 0.3
    task.avg_time = 0.1
    task.last_print_n = 0
    task.n = 0
    task.dynamic_miniters = False
    task.unit = 'B'
    task.unit_scale = False
    task.unit_divisor = 1000
    task.desc = ''

# Generated at 2022-06-18 11:57:10.162246
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn.
    """
    # Test case 1:
    #   speed = None
    #   unit = ""
    #   unit_scale = False
    #   unit_divisor = 1000
    #   expected = Text("? /s", style="progress.data.speed")
    task = type('', (), {'speed': None})()
    rate_column = RateColumn(unit="", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(task) == Text("? /s", style="progress.data.speed")

    # Test case 2:
    #   speed = 100
    #   unit = ""
    #   unit_scale = False
    #   unit_divisor = 1000
    #   expected = Text("100 /s", style="

# Generated at 2022-06-18 11:57:17.572822
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}", justify="right"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=True,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)
    progress.update(task_id, completed=5)
    progress.__exit__(None, None, None)
    console.print(progress)

# Generated at 2022-06-18 11:57:27.497729
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.progress import BarColumn, ProgressColumn, TimeElapsedColumn, TimeRemainingColumn, filesize

    console = Console()

# Generated at 2022-06-18 11:57:38.357393
# Unit test for method render of class RateColumn

# Generated at 2022-06-18 11:57:42.008466
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    for i in tqdm_rich(range(10), total=10):
        sleep(0.1)
    for i in tqdm_rich(range(10), total=10):
        sleep(0.1)

# Generated at 2022-06-18 11:57:44.642256
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test tqdm_rich.clear()"""
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:58:56.970331
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    task = Progress(
        "Downloading",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=False, unit_divisor=1000), "]",
        transient=False,
    )
    task.__enter__()
    task_id = task.add_task("Downloading", total=100, unit="B",
                            unit_scale=False, unit_divisor=1000)
    task.update(task_id, completed=10, speed=100)

# Generated at 2022-06-18 11:59:05.565147
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.theme import Themeable
    from rich.theme import ThemeError
    from rich.theme import ThemeManager
    from rich.theme import ThemeManagerError
    from rich.theme import ThemeManagerWarning
    from rich.theme import ThemeManagerDeprecationWarning
    from rich.theme import ThemeManagerPendingDeprecationWarning
    from rich.theme import ThemeManagerFutureWarning
    from rich.theme import ThemeManagerResourceWarning
    from rich.theme import ThemeManagerRuntimeWarning
   

# Generated at 2022-06-18 11:59:13.818266
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:59:15.902289
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test that method clear of class tqdm_rich does not raise an exception.
    """
    tqdm_rich(total=10).clear()

# Generated at 2022-06-18 11:59:17.306767
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:59:23.798437
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object())

# Generated at 2022-06-18 11:59:31.735544
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)