

# Generated at 2022-06-18 11:49:49.988941
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import Time

# Generated at 2022-06-18 11:49:54.924805
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """Test tqdm_rich.clear()."""
    with tqdm_rich(total=10) as t:
        for _ in t:
            t.clear()


if __name__ == '__main__':
    from time import sleep
    with tqdm_rich(total=10) as t:
        for i in t:
            sleep(0.1)
            t.update()

# Generated at 2022-06-18 11:50:04.453536
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.style import Style
    from rich.columns import Columns
    from rich.rule import Rule
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import Highlight
    from rich.highlighter import Highlighter
    from rich.highlighter import HighlightStyle
    from rich.highlighter import HighlightTarget
    from rich.highlighter import HighlightTargetType
    from rich.highlighter import HighlightTargetScope

# Generated at 2022-06-18 11:50:07.259882
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:50:18.893163
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.columns import Columns
    from rich.box import Box
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.pygments import PygmentsHighlighter
    from rich.highlighters.terminal import TerminalHighlighter
    from rich.highlighters.xml import XmlHighlighter

# Generated at 2022-06-18 11:50:29.825037
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.syntax import Syntax
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.syntax import Syntax
    from rich.console import ConsoleOptions
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress
    from rich.progress import BarColumn, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn, filesize
    from rich.progress import Progress

# Generated at 2022-06-18 11:50:41.563468
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=50)
    task.speed = 100
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1024)
   

# Generated at 2022-06-18 11:50:52.977895
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text('? /s', style='progress.data.speed')
    rate_column = RateColumn(unit='B')
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')
    rate_column = RateColumn(unit='B', unit_scale=True)
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')
    rate_column = RateColumn(unit='B', unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')

# Generated at 2022-06-18 11:51:03.945910
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:51:05.987263
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:51:19.607171
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.text import Text
    from rich.table import Table
    from rich.progress import Progress
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel

# Generated at 2022-06-18 11:51:21.609627
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-18 11:51:30.256914
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL
    from rich.style import Style
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.highlighter import ReprHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown

# Generated at 2022-06-18 11:51:40.889486
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn
    from rich.progress import RateColumn

# Generated at 2022-06-18 11:51:43.311042
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        for i in range(10):
            t.update()
            t.clear()

# Generated at 2022-06-18 11:51:45.441140
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:51:56.705601
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description='test', completed=1, total=2)
    assert FractionColumn().render(task) == Text('0.5/2.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.5/2.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.5/2.0 ', style='progress.download')
    task = Task(description='test', completed=10, total=20)
    assert FractionColumn().render(task) == Text('10.0/20.0 ', style='progress.download')

# Generated at 2022-06-18 11:52:00.469283
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update()

# Generated at 2022-06-18 11:52:13.166564
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500.0/1.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/1.0 K", style="progress.download")
    task.completed = 0
    assert FractionColumn().render(task) == Text("0.0/1.0 ", style="progress.download")

# Generated at 2022-06-18 11:52:24.888471
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn(unit="B").render(None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, speed=100)) == Text("100.0 B/s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, speed=1000)) == Text("1.0 KB/s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, speed=1000000)) == Text("1.0 MB/s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, speed=1000000000)) == Text("1.0 GB/s", style="progress.data.speed")

# Generated at 2022-06-18 11:52:44.555581
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        with tqdm_rich(total=10) as t:
            for i in range(10):
                t.clear()
                t.update()
    assert out.getvalue() == ''
    assert err.getvalue() == ''

# Generated at 2022-06-18 11:52:46.685225
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:52:48.707475
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:52:58.928977
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    task = Task(description="test", completed=1024, total=2048)
    assert FractionColumn(unit_scale=True).render(task) == Text("1.0/2.0 K", style="progress.download")

# Generated at 2022-06-18 11:53:03.682990
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.completed = 50
    task.speed = 100
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:11.859608
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.style import Style
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.measure import Measurement
    from rich.markup import Markup
    from rich.print import RichPrint
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.console import Console
    from rich.progress import Progress
    from rich.columns import Columns

# Generated at 2022-06-18 11:53:21.844070
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-18 11:53:33.173695
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import TextColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBar
    from rich.progress import ProgressBarColumn
    from rich.progress import ProgressDots
    from rich.progress import ProgressSpinner
    from rich.progress import ProgressSpinnerColumn
    from rich.progress import Progress

# Generated at 2022-06-18 11:53:42.672032
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighters import HtmlHighlighter
    from rich.highlighters import PygmentsHighlighter
    from rich.highlighters import TerminalHighlighter
    from rich.highlighters import TextHighlighter
    from rich.highlighters import XmlHighlighter

# Generated at 2022-06-18 11:53:51.132231
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP
    from rich.progress import BarColumn, ProgressColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.console import ConsoleOptions
    from rich.panel import PanelStyle
    from rich.table import TableStyle
    from rich.text import TextStyle
    from rich.markdown import MarkdownStyle
    from rich.syntax import SyntaxStyle
    from rich.progress import ProgressStyle

# Generated at 2022-06-18 11:54:49.626963
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50, speed=50)) == Text('50.0 /s', style='progress.data.speed')
    assert RateColumn(unit='B').render(Progress(total=100, completed=50, speed=50)) == Text('50.0 B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True).render(Progress(total=100, completed=50, speed=50)) == Text('50.0 B/s', style='progress.data.speed')
    assert RateColumn(unit='B', unit_scale=True, unit_divisor=1024).render(Progress(total=100, completed=50, speed=50)) == Text('50.0 B/s', style='progress.data.speed')

# Generated at 2022-06-18 11:55:00.610052
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50)) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=50)) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=50, speed=100)) == Text("100 B/s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=50, speed=100000)) == Text("100.0 KB/s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:10.952035
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test that the method reset of class tqdm_rich works as expected.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.box import Box
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.console import Console
    from rich.text import Text
    from rich.table import Table

# Generated at 2022-06-18 11:55:16.530415
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm.auto import tqdm
    with tqdm(total=10) as pbar:
        for i in range(5):
            pbar.update()
            time.sleep(0.1)
        pbar.reset(total=20)
        for i in range(10):
            pbar.update()
            time.sleep(0.1)

# Generated at 2022-06-18 11:55:18.004233
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=1) as t:
        t.clear()

# Generated at 2022-06-18 11:55:29.443435
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Unit test for method reset of class tqdm_rich
    """
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
        console=console
    )
    progress.__enter__()
    task_id = progress.add_task("", total=100)
    progress.update(task_id, completed=50)
    progress.reset(total=50)
    progress.update(task_id, completed=50)

# Generated at 2022-06-18 11:55:39.134603
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.style import Style
    from rich.progress import Progress
    from rich.progress import BarColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import TextColumn
    from rich.progress import ProgressColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn


# Generated at 2022-06-18 11:55:49.605328
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    import time
    import sys
    import os
    import signal
    from .utils import _range

    def signal_handler(sig, frame):
        print('You pressed Ctrl+C!')
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=10)
    for i in _range(10):
        progress

# Generated at 2022-06-18 11:55:59.319515
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    import time
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )
    progress

# Generated at 2022-06-18 11:56:02.068509
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:56:41.993443
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.highlighters.syntax import PythonSyntaxHighlighter
    from rich.highlighters.syntax import JavaScriptSyntaxHighlighter
    from rich.highlighters.syntax import JSONSyntaxHighlighter
    from rich.highlighters.syntax import HTMLSyntaxHighlighter
    from rich.highlighters.syntax import CSSSyntaxHighlighter
    from rich.highlighters.syntax import YamlSyntaxHighlighter

# Generated at 2022-06-18 11:56:44.796280
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()
    t.reset(total=20)
    for i in range(20):
        t.update()

# Generated at 2022-06-18 11:56:49.039919
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(console)
    task_id = progress.add_task("test", total=10)
    progress.update(task_id, completed=5)
    progress.reset(total=20)
    progress.update(task_id, completed=10)

# Generated at 2022-06-18 11:56:51.706805
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)


# Generated at 2022-06-18 11:56:59.669501
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.style import Style
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule

# Generated at 2022-06-18 11:57:08.876274
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=True,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in range(10):
        sleep(0.1)
        progress.update(task_id, completed=i+1)
    progress.reset(total=5)
    task_id = progress.add_task("Task 2", total=5)

# Generated at 2022-06-18 11:57:18.337569
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_HORIZONTAL, BOX_DOUBLE_VERTICAL, BOX_DOUBLE_UP, BOX_LIGHT_DOWN, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL, BOX_LIGHT_UP, BOX_SINGLE_DOWN, BOX_SING

# Generated at 2022-06-18 11:57:28.025032
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress.Task(completed=0, total=0, speed=0)
    rate_column = RateColumn()
    assert rate_column.render(task) == Text("0.0 /s", style="progress.data.speed")
    task = Progress.Task(completed=0, total=0, speed=1)
    assert rate_column.render(task) == Text("1.0 /s", style="progress.data.speed")
    task = Progress.Task(completed=0, total=0, speed=10)
    assert rate_column.render(task) == Text("10.0 /s", style="progress.data.speed")
    task = Progress.Task(completed=0, total=0, speed=100)

# Generated at 2022-06-18 11:57:39.070599
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.panel import Panel
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_HORIZONTAL, BOX_DOUBLE_VERTICAL, BOX_DOUBLE_UP, BOX_DOUBLE, BOX_LIGHT_DOWN, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL, BOX_LIGHT_UP, BOX_LIGHT, BOX_HEAVY_DOWN, BOX_HEAVY_HORIZONTAL, BOX_HEAVY_VERTICAL, BOX_HEAVY_UP, BOX_HEAVY, BOX_SINGLE_DOWN, BOX_S

# Generated at 2022-06-18 11:57:48.300122
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False)
    progress.__enter__()
    task_id = progress.add_task("test", total=10)

    # Test display()
    tqdm_rich.display(progress, task_id, 0)
    tqdm_rich.display(progress, task_id, 1)

# Generated at 2022-06-18 11:59:06.392555
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map
    from tqdm.contrib.concurrent import thread_map_reduce
    from tqdm.contrib.concurrent import thread_map_reduce_barrier
    from tqdm.contrib.concurrent import thread_map_reduce_barrier_deprecated
    from tqdm.contrib.concurrent import thread_map_reduce_deprecated
    from tqdm.contrib.concurrent import thread_map_deprecated
    from tqdm.contrib.concurrent import thread_map_unordered
    from tqdm.contrib.concurrent import thread_map_unordered_deprecated

# Generated at 2022-06-18 11:59:14.585860
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.table import Table
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel

# Generated at 2022-06-18 11:59:20.442094
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    # Test case 1: speed = None
    task = tqdm_rich(total=100)
    task.speed = None
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(task) == Text("? B/s", style="progress.data.speed")

    # Test case 2: speed = 0
    task = tqdm_rich(total=100)
    task.speed = 0
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(task) == Text("0 B/s", style="progress.data.speed")

    # Test case 3: speed = 1

# Generated at 2022-06-18 11:59:28.054135
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.text import Text
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.highlighters.syntax import PythonSyntaxHighlighter
    from rich.highlighters.syntax import BashSyntaxHighlighter
    from rich.highlighters.syntax import JsonSyntaxHighlighter
    from rich.highlighters.syntax import YamlSyntaxHighlighter
    from rich.highlighters.syntax import HtmlSyntaxHighlighter
    from rich.highlighters.syntax import XmlSyntaxHighlighter

# Generated at 2022-06-18 11:59:34.051208
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import sys
    from io import StringIO
    from tqdm.auto import tqdm as auto_tqdm

    # Test with auto_tqdm
    with StringIO() as f:
        with auto_tqdm(total=10, file=f, leave=False) as pbar:
            pbar.clear()
            pbar.write("test")
        assert f.getvalue() == "test\n"

    # Test with tqdm_rich
    with StringIO() as f:
        with tqdm_rich(total=10, file=f, leave=False) as pbar:
            pbar.clear()
            pbar.write("test")
        assert f.getvalue() == "test\n"

    # Test with tqdm