

# Generated at 2022-06-18 11:49:44.024116
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
    assert t.n == 10


# Generated at 2022-06-18 11:49:53.533062
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP
    from rich.style import Style
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BOX_

# Generated at 2022-06-18 11:49:56.181782
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    try:
        with tqdm_rich(total=10) as pbar:
            for _ in range(10):
                pbar.clear()
    except Exception:
        raise AssertionError("tqdm_rich.clear() method failed")

# Generated at 2022-06-18 11:50:06.093863
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm.auto import tqdm as tqdm_auto
    with tqdm_rich(total=100, desc="test") as pbar:
        for i in range(100):
            time.sleep(0.01)
            pbar.update(1)
    with tqdm_auto(total=100, desc="test") as pbar:
        for i in range(100):
            time.sleep(0.01)
            pbar.update(1)
    with tqdm_rich(total=100, desc="test") as pbar:
        for i in range(100):
            time.sleep(0.01)
            pbar.update(1)

# Generated at 2022-06-18 11:50:17.592883
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    import time
    import pytest
    with Progress() as progress:
        task = progress.add_task("Test", total=100)
        for i in range(100):
            time.sleep(0.01)
            progress.update(task, advance=1)
        progress.reset(total=200)
        for i in range(200):
            time.sleep(0.01)
            progress.update(task, advance=1)
        progress.reset(total=300)
        for i in range(300):
            time.sleep(0.01)
            progress.update(task, advance=1)
        progress.reset(total=400)
        for i in range(400):
            time.sleep(0.01)
            progress.update(task, advance=1)
        progress.reset

# Generated at 2022-06-18 11:50:21.669097
# Unit test for method close of class tqdm_rich
def test_tqdm_rich_close():
    import time
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            time.sleep(0.01)
            pbar.update(1)
    assert pbar.n == 100

# Generated at 2022-06-18 11:50:32.126233
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    """
    Test the method display of class tqdm_rich.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.measure import Measurement
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel

# Generated at 2022-06-18 11:50:43.671512
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.traceback import Traceback
    from rich.box import BOX_LIGHT_HORIZONTAL, BOX_LIGHT_DOWN_AND_RIGHT, BOX_LIGHT_UP_AND_RIGHT
    from rich.syntax import Syntax
    from rich.style import Style
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.columns import Columns
    from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn

# Generated at 2022-06-18 11:50:55.759766
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=10)) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=10, speed=0)) == Text("0.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=10, speed=10)) == Text("10.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=10, speed=100)) == Text("100.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=10, speed=1000)) == Text("1.0 K/s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:58.567169
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:51:13.537432
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.syntax import PygmentsSyntaxHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.ansi import AnsiHighlighter
    from rich.highlighters.ansi_light import AnsiLightHighlighter


# Generated at 2022-06-18 11:51:15.807580
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:51:25.002643
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.progress import TaskID
    from rich.progress import Task

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=100)
    task = Task(task_id, progress)
    task.update(completed=50)
    sleep(0.1)
    task.reset(total=200)
    task.update(completed=100)
    sleep(0.1)
    task.reset(total=300)


# Generated at 2022-06-18 11:51:32.536762
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import ConsoleOptions
    from rich.progress import ProgressOptions
    from rich.table import TableOptions
    from rich.markdown import MarkdownOptions
    from rich.style import StyleOptions
    from rich.theme import ThemeOptions
    from rich.panel import PanelOptions
    from rich.text import TextOptions
    from rich.progress import BarColumnOptions
    from rich.progress import FractionColumnOptions
    from rich.progress import TimeElapsedColumnOptions


# Generated at 2022-06-18 11:51:40.548856
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.progress import Progress

    class tqdm_rich_test(tqdm_rich):
        def __init__(self, *args, **kwargs):
            self.console = Console()
            self.format_dict = {'total': 100, 'n': 50, 'desc': 'test'}
            self._prog = Progress()
            self._task_id = TaskID(self._prog, self.format_dict['desc'])

    tqdm_rich_test().display()

# Generated at 2022-06-18 11:51:52.079200
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test for method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn

# Generated at 2022-06-18 11:52:04.817159
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.style import Style
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme
    from rich.theme import Theme

# Generated at 2022-06-18 11:52:10.446930
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=50)
    task.update(completed=100)
    assert rate_column.render(task) == Text("2.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:52:18.567906
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress.Task(description="", total=100, completed=50)
    assert FractionColumn().render(task) == Text("0.5/1.0", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500/1.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/1.0 K", style="progress.download")


# Generated at 2022-06-18 11:52:29.631940
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit='B', unit_scale=False, unit_divisor=1000)
    assert rate_column.render(None) == Text('? B/s', style='progress.data.speed')
    assert rate_column.render(object()) == Text('? B/s', style='progress.data.speed')
    assert rate_column.render(object()) == Text('? B/s', style='progress.data.speed')
    assert rate_column.render(object(speed=None)) == Text('? B/s', style='progress.data.speed')
    assert rate_column.render(object(speed=0)) == Text('0 B/s', style='progress.data.speed')

# Generated at 2022-06-18 11:52:47.990412
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=0, total=100)
    assert FractionColumn().render(task) == Text("0.0/100.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.0/100.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.0/100.0 ", style="progress.download")
    task = Task(description="test", completed=100, total=100)
    assert FractionColumn().render(task) == Text("100.0/100.0 ", style="progress.download")

# Generated at 2022-06-18 11:52:58.306780
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.progress import BarColumn
    from rich.progress import TextColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn
    from rich.progress import Progress
    from rich.progress import TaskID
    from rich.progress import Task

    class FractionColumn(ProgressColumn):
        """Renders completed/total, e.g. '0.5/2.3 G'."""
        def __init__(self, unit_scale=False, unit_divisor=1000):
            self.unit_scale = unit

# Generated at 2022-06-18 11:53:06.293375
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test that resetting a tqdm_rich bar works as expected.
    """
    from time import sleep
    from rich.progress import Progress
    from tqdm.auto import tqdm

    with Progress() as progress:
        task = progress.add_task("Task", total=100)
        for i in tqdm(range(100)):
            sleep(0.01)
            progress.update(task, advance=1)
        progress.reset(total=200)
        for i in tqdm(range(200)):
            sleep(0.01)
            progress.update(task, advance=1)

# Generated at 2022-06-18 11:53:13.594069
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import RateColumn

    console = Console()
    progress = Progress(
        Text("[progress.description]{task.description}", style="progress.description"),
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B"), "]",
        transient=True,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=100)
    progress.update(task_id, completed=10)

# Generated at 2022-06-18 11:53:24.165618
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test the method render of class RateColumn.
    """
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:35.112364
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize

# Generated at 2022-06-18 11:53:44.692680
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import ReprHighlighter
    from rich.console import Console
    from rich.measure import Measurement
    from rich.style import Style
    from rich.text import Text
    from rich.progress import Progress
    from rich.panel import Panel

# Generated at 2022-06-18 11:53:52.320430
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=5)

# Generated at 2022-06-18 11:53:53.848916
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=2) as pbar:
        pbar.update()
        pbar.clear()
        pbar.update()

# Generated at 2022-06-18 11:53:55.820509
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    with tqdm_rich(total=10, desc="test") as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-18 11:54:08.994777
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-18 11:54:10.723116
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()


# Generated at 2022-06-18 11:54:16.353696
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.syntax import Syntax
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.highlighter import ReprHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
   

# Generated at 2022-06-18 11:54:24.357435
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:54:31.886567
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.completed = 50
    task.speed = 100
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(task) == Text("100.0 B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)

# Generated at 2022-06-18 11:54:37.984600
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.table import Table
    from rich.text import Text
    from rich.traceback import Traceback
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:54:48.152381
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="", unit_scale=False, unit_divisor=1000), "]"
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=100)
    progress.update(task_id, completed=50)
    progress.render(console)

# Generated at 2022-06-18 11:54:51.350396
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

# Generated at 2022-06-18 11:55:01.721998
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.text import TextStyle
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress, BarColumn, TextColumn
    from rich.panel import Panel
    from rich.text import Text
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding

# Generated at 2022-06-18 11:55:12.343085
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:55:45.267322
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(1) == Text("1.0 /s", style="progress.data.speed")
    assert rate_column.render(1000) == Text("1.0 K/s", style="progress.data.speed")
    assert rate_column.render(1000000) == Text("1.0 M/s", style="progress.data.speed")
    assert rate_column.render(1000000000) == Text("1.0 G/s", style="progress.data.speed")
    assert rate_column.render(1000000000000) == Text("1.0 T/s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:53.108312
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.box import Box
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.markdown import Markdown

# Generated at 2022-06-18 11:56:02.967567
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=1, total=2)
    assert FractionColumn().render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/2.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/2.0 ", style="progress.download")
    task = Task(description="test", completed=1024, total=2048)
    assert FractionColumn(unit_scale=True).render(task) == Text("1.0/2.0 K", style="progress.download")

# Generated at 2022-06-18 11:56:12.528088
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import BOX_DOUBLE_DOWN, BOX_DOUBLE_HORIZONTAL, BOX_DOUBLE_VERTICAL, BOX_DOUBLE_UP, BOX_DOUBLE_LEFT, BOX_DOUBLE_RIGHT, BOX_DOUBLE, BOX_SINGLE, BOX_HEAVY, BOX_LIGHT_DOWN, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL, BOX_LIGHT_UP

# Generated at 2022-06-18 11:56:22.635220
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=True,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=100)
    for i in range(100):
        progress.update(task_id, completed=i)
        time.sleep(0.01)
    progress.reset(total=200)
    for i in range(200):
        progress

# Generated at 2022-06-18 11:56:32.977058
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? B/s", style="progress.data.speed")
    assert rate_column.render(object())

# Generated at 2022-06-18 11:56:42.921672
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)
    progress.update(task_id, completed=5)
    progress.reset(total=20)
    progress.update(task_id, completed=10)
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:56:52.618291
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:57:00.206848
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:57:09.871257
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table

# Generated at 2022-06-18 11:58:28.570187
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=10)
    task.update(completed=20)
    assert rate_column.render(task) == Text("10.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:58:35.878515
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.padding import Padding
    from rich.style import Style
    from rich.text_layout import TextLayout
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.progress import Progress
    from rich.markup import Markup
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighters import Highlighter
    from rich.table import Table
    from rich.text import Text
   

# Generated at 2022-06-18 11:58:41.461427
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(None, speed=None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(None, speed=0) == Text("0 /s", style="progress.data.speed")
    assert rate_column.render(None, speed=1) == Text("1 /s", style="progress.data.speed")
    assert rate_column.render(None, speed=10) == Text("10 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:58:50.107488
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    progress = Progress()
    progress.add_task("task", total=100)
    progress.update(0, completed=50)
    progress.update(0, completed=100)
    progress.update(0, completed=150)
    progress.update(0, completed=200)
    progress.update(0, completed=250)
    progress.update(0, completed=300)
    progress.update(0, completed=350)
    progress.update(0, completed=400)
    progress.update(0, completed=450)
    progress.update(0, completed=500)
    progress.update(0, completed=550)
    progress.update(0, completed=600)
    progress.update(0, completed=650)
    progress.update(0, completed=700)

# Generated at 2022-06-18 11:58:52.548174
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    with tqdm_rich(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()

# Generated at 2022-06-18 11:59:02.120018
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.box import Box
    from rich.panel import Panel
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markup import Markup
    from rich.console import ConsoleOptions
    from rich.progress import Progress, TaskID
    from rich.progress import BarColumn, FractionColumn, TimeRemainingColumn, TimeElapsedColumn, RateColumn
    from rich.text import Text
    from rich.style import Style
    from rich.theme import Theme

# Generated at 2022-06-18 11:59:04.624908
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:59:11.024182
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """Test method render of class FractionColumn."""
    task = tqdm_rich(total=100)
    task.update(50)
    task.close()
    assert FractionColumn().render(task) == Text("50.0/100 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("50.0/100 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("48.8/97.7 K", style="progress.download")


# Generated at 2022-06-18 11:59:18.380098
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL, BOX_LIGHT_DOWN_LEFT, BOX_LIGHT_DOWN_RIGHT, BOX_LIGHT_UP_LEFT, BOX_LIGHT_UP_RIGHT
    from rich.style import Style
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.text import Text

# Generated at 2022-06-18 11:59:22.916078
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    column = FractionColumn()
    assert column.render(task) == Text("0.5/1.0 ", style="progress.download")
    task.completed = 100
    assert column.render(task) == Text("1.0/1.0 ", style="progress.download")
    task.completed = 0
    assert column.render(task) == Text("0.0/1.0 ", style="progress.download")
    task.completed = 1
    assert column.render(task) == Text("0.0/1.0 ", style="progress.download")
    task.completed = 0.5
    assert column.render(task) == Text("0.5/1.0 ", style="progress.download")
    task.completed = 0.1