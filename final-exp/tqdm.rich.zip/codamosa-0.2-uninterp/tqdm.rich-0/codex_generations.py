

# Generated at 2022-06-18 11:49:52.352499
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    import time
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map

    def f(x):
        time.sleep(0.01)
        return x

    # Test process_map
    with tqdm(total=10) as pbar:
        for _ in process_map(f, range(10)):
            pbar.update()
        pbar.reset(total=5)
        for _ in process_map(f, range(5)):
            pbar.update()

    # Test thread_map
    with tqdm(total=10) as pbar:
        for _ in thread_map(f, range(10)):
            pbar.update()

# Generated at 2022-06-18 11:50:00.642992
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50, speed=50)) == Text("50.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=50.0)) == Text("50.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=50.5)) == Text("50.5 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=50.55)) == Text("50.6 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:50:02.883398
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import pytest
    with pytest.raises(AttributeError):
        tqdm_rich().clear()

# Generated at 2022-06-18 11:50:12.444333
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    import unittest
    from rich.progress import Task
    from rich.progress import ProgressColumn
    from rich.text import Text

    class TestFractionColumn(unittest.TestCase):
        """
        Test class FractionColumn.
        """
        def test_render(self):
            """
            Test method render.
            """
            task = Task(description="test", completed=1, total=2)
            fraction_column = FractionColumn()
            self.assertEqual(fraction_column.render(task), Text("0.5/2.0 ", style="progress.download"))

    unittest.main()

# Generated at 2022-06-18 11:50:15.148916
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in t:
            t.clear()
            t.display()

# Generated at 2022-06-18 11:50:26.417535
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = tqdm_rich(total=100)
    task.update(10)
    task.update(20)
    task.update(30)
    task.update(40)
    task.update(50)
    task.update(60)
    task.update(70)
    task.update(80)
    task.update(90)
    task.update(100)
    task.close()
    assert task.speed == 0
    task = tqdm_rich(total=100)
    task.update(10)
    task.update(20)
    task.update(30)
    task.update(40)
    task.update(50)
    task.update(60)
    task.update(70)
    task.update(80)
    task.update(90)

# Generated at 2022-06-18 11:50:37.986078
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.progress import BarColumn, FractionColumn, TimeElapsedColumn, TimeRemainingColumn, RateColumn
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.measure import Measurement
    from rich.style import Style
    from rich.text import Text
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress

# Generated at 2022-06-18 11:50:40.532500
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()

# Generated at 2022-06-18 11:50:51.591325
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize

# Generated at 2022-06-18 11:51:02.846585
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.box import Box
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.columns import Columns

# Generated at 2022-06-18 11:51:09.004697
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()

# Generated at 2022-06-18 11:51:18.994076
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = None
    task.unit = 'B'
    task.unit_scale = False
    task.unit_divisor = 1000
    rate_column = RateColumn(unit=task.unit, unit_scale=task.unit_scale, unit_divisor=task.unit_divisor)
    assert rate_column.render(task) == Text(f"? {task.unit}/s", style="progress.data.speed")
    task.speed = 0
    assert rate_column.render(task) == Text(f"0 {task.unit}/s", style="progress.data.speed")
    task.speed = 1000
    assert rate_column.render(task) == Text(f"1 {task.unit}/s", style="progress.data.speed")
    task.speed = 100

# Generated at 2022-06-18 11:51:28.044054
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    import sys
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=True,
        console=console,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=20)
    for i in range(20):
        progress.update(task_id, completed=i)
        sleep(0.1)
   

# Generated at 2022-06-18 11:51:38.510076
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")
    assert rate_column.render(object()) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:41.378181
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as pbar:
        for i in range(100):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:51:52.994525
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import ProgressBarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import BarColumn
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn

# Generated at 2022-06-18 11:51:56.589716
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    console = Console()
    with tqdm_rich(total=10, desc="Test", console=console) as pbar:
        for i in range(10):
            pbar.update(1)
    console.print()

# Generated at 2022-06-18 11:52:04.285486
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            if i == 5:
                pbar.reset(total=20)
                for j in range(10):
                    pbar.update(1)
                pbar.reset(total=30)
                for j in range(10):
                    pbar.update(1)

# Generated at 2022-06-18 11:52:10.029938
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=50)
    task.update(completed=100)
    assert rate_column.render(task) == Text("? /s", style="progress.data.speed")

# Generated at 2022-06-18 11:52:21.541946
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test if the method reset of class tqdm_rich works properly.
    """
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.columns import Columns
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.box import HEAVY_HEAD
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.highlighters.pygments import PygmentsHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.ansi import AnsiHighlighter
    from rich.highlighters.regex import RegexHighlighter

# Generated at 2022-06-18 11:52:40.378654
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.progress import Progress, BarColumn, TimeRemainingColumn
    from rich.progress import TimeElapsedColumn, FractionColumn, RateColumn
    from rich.progress import filesize
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.box import Box
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.console import Console
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress, BarColumn, TimeRem

# Generated at 2022-06-18 11:52:49.619341
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=0)) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1)) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1, completed=1)) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1, completed=1, speed=1)) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1, completed=1, speed=1.1)) == Text("1.1 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:00.282491
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.json import JsonHighlighter
    from rich.highlighters.python import PythonHighlighter
    from rich.highlighters.xml import XmlHighlighter
    from rich.highlighters.yaml import YamlHighlighter


# Generated at 2022-06-18 11:53:09.953456
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import TaskID
    from rich.text import Text
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.style import Style
    from rich.text import Text
    from rich.box import Box
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.style import Style
    from rich.text import Text
    from rich.box import Box
    from rich.console import Console
    from rich.progress import Progress

# Generated at 2022-06-18 11:53:19.751210
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.table import Table

# Generated at 2022-06-18 11:53:22.339787
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:53:25.436948
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        for i in range(100):
            t.update()
            t.clear()
            t.display()

# Generated at 2022-06-18 11:53:34.974560
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text

    console = Console()
    progress = Progress(Text("[progress.description]{task.description}"),
                        BarColumn(bar_width=None),
                        Text("{task.percentage:>4.0f}%"),
                        transient=True)
    progress.__enter__()
    task_id = progress.add_task("", total=100)
    progress.update(task_id, completed=50)
    progress.reset(total=200)
    progress.update(task_id, completed=100)
    progress.__exit__(None, None, None)
    console.print(progress)

# Generated at 2022-06-18 11:53:37.578689
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()


# Generated at 2022-06-18 11:53:39.642799
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update(1)

# Generated at 2022-06-18 11:54:03.181473
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.progress import TaskID
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:54:09.601899
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import TaskID
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.padding import Padding
    from rich.box import BOX_LIGHT_ROUNDED, BOX_LIGHT_HEAVY
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.style import Style
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.text import Text
    from rich.table import Table
    from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn
    from rich.panel import Panel
    from rich.padding import Padding

# Generated at 2022-06-18 11:54:18.487955
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn
    """
    from rich.progress import Task
    task = Task(description="Test")
    task.speed = None
    task.completed = 0
    task.total = 0
    task.start_time = 0
    task.end_time = 0
    task.update_time = 0
    task.update_every = 0
    task.last_print_n = 0
    task.last_print_t = 0
    task.dynamic_ncols = 0
    task.ncols = 0
    task.n = 0
    task.miniters = 0
    task.mininterval = 0
    task.maxinterval = 0
    task.avg_time = 0
    task.smoothing = 0
    task.dynamic_miniters = 0


# Generated at 2022-06-18 11:54:20.972323
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:54:30.247639
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import Progress, TaskID
    from rich.table import Table

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    progress.update(task_id, completed=50)
    progress.__exit__(None, None, None)
    console.print(progress)


# Generated at 2022-06-18 11:54:32.125900
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    import pytest
    with pytest.raises(AttributeError):
        with tqdm_rich(total=10) as t:
            t.clear()

# Generated at 2022-06-18 11:54:41.430102
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .std import tqdm_gui as std_tqdm_gui
    from .std import trange_gui as std_trange_gui
    from .std import tnrange as std_tnrange
    from .std import tqdm_pandas as std_tqdm_pandas
    from .std import tqdm_notebook as std_tqdm_notebook
    from .std import tqdm_pandas as std_tqdm_pandas
    from .std import tgrange as std_tgrange
    from .std import tqdm_gui as std_tqdm_gui
    from .std import trange_gui as std_trange_gui

# Generated at 2022-06-18 11:54:51.960239
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        t.clear()
        assert t.n == 0
        t.update(10)
        assert t.n == 10
        t.clear()
        assert t.n == 0
        t.update(10)
        assert t.n == 10
        t.clear()
        assert t.n == 0
        t.update(10)
        assert t.n == 10
        t.clear()
        assert t.n == 0
        t.update(10)
        assert t.n == 10
        t.clear()
        assert t.n == 0
        t.update(10)
        assert t.n == 10
        t.clear()
        assert t.n == 0
        t.update(10)
        assert t.n == 10

# Generated at 2022-06-18 11:55:02.127552
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.traceback import Traceback
    from rich.measure import Measurement
    from rich.prompt import Prompt
    from rich.progress import Progress
    from rich.progress_bar import ProgressBar
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text
    from rich.theme import Theme


# Generated at 2022-06-18 11:55:12.780320
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=1, completed=0)) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1, completed=1)) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=1, completed=1, speed=2)) == Text("2.0 /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=1, completed=1, speed=2)) == Text("2.0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:51.521521
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("500.0/1.0 K", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("488.3/1.0 K", style="progress.download")


# Generated at 2022-06-18 11:56:01.397269
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task('test', total=10)
    task.completed = 5
    assert FractionColumn().render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.5/1.0 ', style='progress.download')
    task.total = 1024
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('0.5/1.0 K', style='progress.download')
    task.total = 1024*1024

# Generated at 2022-06-18 11:56:05.095072
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Task
    task = Task(description="", completed=1, total=2)
    fraction_column = FractionColumn()
    assert fraction_column.render(task) == Text("0.5/2.0 ", style="progress.download")


# Generated at 2022-06-18 11:56:14.470397
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
        console=console
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=10)
    progress.update(task_id, completed=5)
    progress.reset(total=20)
    progress.update(task_id, completed=10)
    progress.__exit__(None, None, None)

# Generated at 2022-06-18 11:56:25.932170
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test the method render of class FractionColumn.
    """
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 1024
    assert FractionColumn().render(task) == Text("0.5/1.0 K", style="progress.download")

# Generated at 2022-06-18 11:56:35.645512
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.highlighter import HighlightedCode
    from rich.highlighter import Highlighter
    from rich.highlighter import HighlightedSection
    from rich.highlighter import HighlightedTable
    from rich.highlighter import Highlighted

# Generated at 2022-06-18 11:56:45.556806
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Task 1", total=10)
    for i in range(10):
        progress.update(task_id, completed=i)
        sleep(0.1)
    progress.reset(total=20)
    for i in range(20):
        progress.update(task_id, completed=i)
        sleep(0.1)

# Generated at 2022-06-18 11:56:49.528958
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        tqdm.reset()

# Generated at 2022-06-18 11:56:53.900648
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Task
    task = Task(description="test", completed=10, total=100, speed=10)
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(task) == Text("10.0 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:57:01.161528
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import RateColumn
    from rich.style import Style
    from rich.theme import Theme
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.box import BOX_LIGHT_HORIZONTAL, BOX_LIGHT_DOWN_AND_RIGHT, BOX_LIGHT_UP_AND_RIGHT, BOX_LIGHT_VERTICAL, BOX_LIGHT_DOWN_AND_HORIZONTAL, BOX_LIGHT_UP_AND_HOR

# Generated at 2022-06-18 11:58:23.182227
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()
            pbar.refresh()

# Generated at 2022-06-18 11:58:25.943696
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from tqdm.auto import trange
    for _ in trange(3, desc='test'):
        sleep(0.1)
        trange.reset(total=3)

# Generated at 2022-06-18 11:58:27.516759
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()

# Generated at 2022-06-18 11:58:31.251847
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=50)
    task.speed = 100
    assert rate_column.render(task) == Text("100.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:58:37.540750
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import BarColumn, ProgressColumn
    from rich.progress import TimeElapsedColumn, TimeRemainingColumn
    from rich.progress import FractionColumn, RateColumn

    console = Console()

# Generated at 2022-06-18 11:58:42.517147
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    task = Progress()
    task.speed = None
    task.unit = "B"
    task.unit_scale = False
    task.unit_divisor = 1000
    task.total = None
    task.completed = None
    task.description = None
    task.position = None
    task.start_time = None
    task.end_time = None
    task.elapsed_time = None
    task.remaining_time = None
    task.percentage = None
    task.eta = None
    task.l_avg_time = None
    task.s_avg_time = None
    task.avg_time = None
    task.avg_eta = None
    task.avg_percentage = None
    task.avg_speed = None
    task.avg_remaining_time

# Generated at 2022-06-18 11:58:44.664341
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

# Generated at 2022-06-18 11:58:52.809186
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:58:59.003272
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test method reset of class tqdm_rich."""
    from time import sleep
    from tqdm.auto import trange
    with trange(10) as t:
        for i in t:
            sleep(0.1)
            if i == 5:
                t.reset(total=15)
                t.set_description("Reset!")
    assert t.n == 15
    assert t.total == 15
    assert t.desc == "Reset!"

# Generated at 2022-06-18 11:59:01.329618
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)