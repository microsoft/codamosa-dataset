

# Generated at 2022-06-18 11:49:41.236808
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    progress = Progress()
    progress.add_task("Task", total=100)
    progress.update(completed=50)
    fraction_column = FractionColumn()
    fraction_column.render(progress.tasks[0])
    console = Console()
    table = Table(show_header=False, show_edge=False)
    table.add_column(fraction_column)
    table.add_row(progress.tasks[0])
    console.print(table)
    assert fraction_column.render(progress.tasks[0]) == Text("0.5/1.0 ", style="progress.download")

# Generated at 2022-06-18 11:49:50.768279
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress(total=100)
    task.completed = 50
    assert FractionColumn().render(task) == Text('0.5/1.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True).render(task) == Text('500.0/1,000.0 ', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text('488.3/977.0 K', style='progress.download')
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text('0.5/1.0 K', style='progress.download')
    task.total = 1000

# Generated at 2022-06-18 11:49:58.845285
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.table import Table
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.box import BOX_DOUBLE, BOX_HEAVY
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.columns import Columns
    from rich.table import Table
    from rich.progress import Progress
    from rich.markdown import Markdown
    from rich.console import Console
    from rich.text import Text
    from rich.panel import Panel

# Generated at 2022-06-18 11:50:09.450692
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    import time
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    console = Console()
    progress = Progress(Text("[progress.description]{task.description}"),
                        BarColumn(bar_width=None),
                        Text("[progress.percentage]{task.percentage:>4.0f}%"),
                        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
                        ",", RateColumn(unit="B"), "]",
                        transient=False)
    progress.__enter__()
    task_id = progress.add_task("Downloading", total=100)
    for i in range(100):
        progress.update(task_id, completed=i)
        time.sleep(0.1)
    progress.__exit__

# Generated at 2022-06-18 11:50:21.616501
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import BarColumn, TextColumn
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import BOX_LIGHT_HORIZONTAL, BOX_LIGHT_DOWN_AND_RIGHT, BOX_LIGHT_UP_AND_RIGHT, BOX_LIGHT_VERTICAL, BOX_LIGHT_DOWN_AND_HORIZONTAL, BOX_LIGHT_UP_AND_HORIZONTAL, BOX_LIGHT_UP_AND_LEFT, BOX_LIGHT_DOWN_AND_LEFT, BOX_LIGHT_LEFT_AND_

# Generated at 2022-06-18 11:50:32.066588
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.columns import Columns
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.progress import BarColumn, TextColumn, TimeRemainingColumn, TimeElapsedColumn
    from rich.progress import Progress, TaskID
    from rich.panel import Panel
    from rich.console import Console
    from rich.table import Table
    from rich.columns import Columns
    from rich.style import Style

# Generated at 2022-06-18 11:50:43.623873
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress.Task(0, 10, description="test")
    task.completed = 5
    task.total = 10
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True).render(task) == Text("0.5/1.0 ", style="progress.download")
    assert FractionColumn(unit_scale=True, unit_divisor=1024).render(task) == Text("0.5/1.0 ", style="progress.download")
    task.total = 1000
    assert FractionColumn().render(task) == Text("0.5/1.0 ", style="progress.download")

# Generated at 2022-06-18 11:50:55.917998
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50)) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=50)) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True).render(Progress(total=100, completed=50)) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(Progress(total=100, completed=50)) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:03.901205
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.completed = 1
    task.total = 2
    task.unit_scale = False
    task.unit_divisor = 1000
    assert FractionColumn(unit_scale=False, unit_divisor=1000).render(task) == Text("0.5/2.0 ", style="progress.download")
    task.unit_scale = True
    task.unit_divisor = 1000
    assert FractionColumn(unit_scale=True, unit_divisor=1000).render(task) == Text("0.5/2.0 K", style="progress.download")


# Generated at 2022-06-18 11:51:13.080913
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from .std import tqdm
    from .utils import _range
    from time import sleep

    with tqdm(_range(10), total=10) as t:
        for i in t:
            sleep(0.1)
            if i == 5:
                t.reset(total=20)
                for j in tqdm(_range(10), total=10):
                    sleep(0.1)
                t.reset(total=30)
                for j in tqdm(_range(10), total=10):
                    sleep(0.1)
                t.reset(total=40)
                for j in tqdm(_range(10), total=10):
                    sleep(0.1)

# Generated at 2022-06-18 11:51:25.945401
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50)) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(Progress(total=100, completed=50)) == Text("? B/s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=100)) == Text("100.00 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:33.022788
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test method render of class FractionColumn.
    """
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "Downloading [progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(
            unit_scale=False, unit_divisor=1000),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=False, unit_divisor=1000), "]"
    )
    progress.__enter__()
    task_id = progress.add_task("test", total=100)
    progress.update(task_id, completed=50)
    progress.render(console)

# Generated at 2022-06-18 11:51:44.197999
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(Progress(total=100, completed=50)) == Text("? /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=1)) == Text("1.0 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=1.5)) == Text("1.5 /s", style="progress.data.speed")
    assert RateColumn().render(Progress(total=100, completed=50, speed=1.5, unit="B")) == Text("1.5 B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:51:55.915481
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP, BOX_LIGHT_HORIZONTAL, BOX_LIGHT_VERTICAL
    from rich.padding import Padding
    from rich.style import Style
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.syntax import Syntax
    from rich.highlighters import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import Progress

# Generated at 2022-06-18 11:52:09.387885
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.highlighter import RegexHighlighter
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.theme import Theme
    from rich.traceback import Traceback

# Generated at 2022-06-18 11:52:20.811623
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.theme import Theme
    from rich.style import Style
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.columns import Columns

# Generated at 2022-06-18 11:52:31.502517
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.progress import ProgressColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import BarColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn

    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(unit="B", unit_scale=True, unit_divisor=1000), "]",
        transient=False,
    )
    progress.__

# Generated at 2022-06-18 11:52:43.202666
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_stats
    from .utils import format_size
    from .utils import format_line
    from .utils import format_overline
    from .utils import format_underline
    from .utils import format_block
    from .utils import format_width
    from .utils import format_ascii
    from .utils import format_len
    from .utils import format_dict
    from .utils import format_dict_html
    from .utils import format_dict_json
    from .utils import format_dict_

# Generated at 2022-06-18 11:52:50.880932
# Unit test for constructor of class tqdm_rich
def test_tqdm_rich():
    from rich.console import Console
    from rich.progress import Progress
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}"
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )
    with progress:
        task_id = progress.add_task("test", total=100)
        for i in range(100):
            progress.update(task_id, completed=i)
            console.print("test")

if __name__ == "__main__":
    test_tqdm_rich()

# Generated at 2022-06-18 11:52:55.108617
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    console = Console()
    with tqdm_rich(total=10, desc="Test", console=console) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.display()
    console.print("")

# Generated at 2022-06-18 11:53:03.911012
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()


# Generated at 2022-06-18 11:53:08.120505
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    rate_column = RateColumn()
    task = Progress(total=100)
    task.update(completed=50)
    task.update(completed=100)
    assert rate_column.render(task) == Text("2.0 /s", style="progress.data.speed")

# Generated at 2022-06-18 11:53:14.749966
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import ConsoleOptions
    from rich.progress import ProgressOptions
    from rich.table import TableOptions
    from rich.markdown import MarkdownOptions
    from rich.style import StyleOptions
    from rich.theme import ThemeOptions
    from rich.text import TextOptions
    from rich.panel import PanelOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.console import Console
    from rich.progress import Progress
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
   

# Generated at 2022-06-18 11:53:15.754387
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    t = tqdm_rich(total=10)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:53:26.619218
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-18 11:53:37.153129
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1024)
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit_scale=True, unit_divisor=1000)

# Generated at 2022-06-18 11:53:45.048783
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """Test RateColumn.render()"""
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        "[progress.percentage]{task.percentage:>4.0f}%",
        BarColumn(bar_width=None),
        FractionColumn(),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(),
        ",", RateColumn(), "]"
    )
    task_id = progress.add_task("test", total=100)
    progress.update(task_id, completed=50)
    console.print(progress)

# Generated at 2022-06-18 11:53:52.653594
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.progress import BarColumn, ProgressColumn, TimeElapsedColumn, TimeRemainingColumn, filesize
    from rich.progress import Progress
    from rich.progress import BarColumn, ProgressColumn, Text, TimeElapsedColumn, TimeRemainingColumn, filesize
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.progress import BarColumn, ProgressColumn, TimeElapsedColumn, TimeRemainingColumn, filesize

# Generated at 2022-06-18 11:53:59.493998
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.style import Style
    from rich.highlighter import Highlighter
    from rich.theme import Theme
    from rich.padding import Padding
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.style import Style
    from rich.highlighter import Highlighter
    from rich.theme import Theme

# Generated at 2022-06-18 11:54:07.651467
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    """
    Test the method render of class FractionColumn.
    """
    import pytest
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import Text
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import BarColumn
    from rich.progress import filesize
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from tqdm.rich import tqdm_rich
    from tqdm.rich import trrange
    from tqdm.rich import tqdm
    from tqdm.rich import trange
    from tqdm.std import TqdmExperimentalWarning
    from tqdm.std import tqdm as std_tqdm
    from tqdm.utils import _range


# Generated at 2022-06-18 11:54:37.482961
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for _ in range(10):
            pbar.clear()
            pbar.update()

# Generated at 2022-06-18 11:54:47.753119
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    assert RateColumn().render(None) == Text("? /s", style="progress.data.speed")
    assert RateColumn(unit="B").render(None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True).render(None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1024).render(None) == Text("? B/s", style="progress.data.speed")
    assert RateColumn(unit="B", unit_scale=True, unit_divisor=1000).render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:54:59.254095
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    rate_column = RateColumn()
    assert rate_column.render(None) == Text("? /s", style="progress.data.speed")
    rate_column = RateColumn(unit="B")
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    assert rate_column.render(None) == Text("? B/s", style="progress.data.speed")

# Generated at 2022-06-18 11:55:07.418547
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    # Test reset with total
    with tqdm_rich(total=10) as t:
        for i in range(5):
            t.update()
        t.reset(total=20)
        for i in range(10):
            t.update()
        t.reset(total=30)
        for i in range(20):
            t.update()
    # Test reset without total
    with tqdm_rich(total=10) as t:
        for i in range(5):
            t.update()
        t.reset()
        for i in range(10):
            t.update()
        t.reset()
        for i in range(20):
            t.update()

# Generated at 2022-06-18 11:55:09.894905
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=100) as t:
        for i in range(100):
            t.update()
            t.clear()

# Generated at 2022-06-18 11:55:21.838610
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.console import Console
    from rich.progress import Progress
    from rich.text import Text
    from rich.style import Style
    from rich.progress import BarColumn
    from rich.progress import ProgressColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import TaskID
    from rich.progress import Task
    from rich.progress import Progress
    from rich.progress import ProgressBar
    from rich.progress import ProgressColumn
    from rich.progress import ProgressText
    from rich.progress import ProgressBarColumn
    from rich.progress import ProgressFractionColumn
    from rich.progress import ProgressTimeColumn
    from rich.progress import ProgressTimeRemainingColumn

# Generated at 2022-06-18 11:55:32.230779
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    import time
    progress = Progress()
    progress.__enter__()
    task_id = progress.add_task("", total=100)
    progress.update(task_id, completed=0)
    time.sleep(0.1)
    progress.update(task_id, completed=50)
    time.sleep(0.1)
    progress.update(task_id, completed=100)
    time.sleep(0.1)
    progress.reset(total=200)
    time.sleep(0.1)
    progress.update(task_id, completed=0)
    time.sleep(0.1)
    progress.update(task_id, completed=100)
    time.sleep(0.1)
    progress.update(task_id, completed=200)
    time

# Generated at 2022-06-18 11:55:42.278073
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>4.0f}%",
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    progress.__enter__()
    task_id = progress.add_task("Test", total=100)
    for i in tqdm(range(100), total=100, desc="Test", progress=progress):
        sleep(0.01)
    progress.reset(total=200)

# Generated at 2022-06-18 11:55:44.549578
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()

# Generated at 2022-06-18 11:55:52.869767
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.style import Style
    from rich.progress import BarColumn, ProgressColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn, filesize
    from rich.syntax import Syntax
    from rich.traceback import Traceback
    from rich.box import Box
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text
    from rich.traceback import Traceback
    from rich.progress import Progress
    from rich.panel import Panel

# Generated at 2022-06-18 11:56:31.709626
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.panel import Panel
    from rich.table import Table
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.syntax import Syntax
    from rich.box import Box
    from rich.padding import Padding
    from rich.rule import Rule
    from rich.markdown import Markdown
    from rich.measure import Measurement
    from rich.highlighter import RegexHighlighter
    from rich.console import ConsoleOptions
    from rich.style import Style
    from rich.theme import Theme
    from rich.progress import Progress, TaskID
    from rich.progress import BarColumn, TextColumn, TimeRemainingColumn, TimeElapsedColumn, FractionColumn


# Generated at 2022-06-18 11:56:42.035712
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test method render of class RateColumn.
    """
    # Test case 1
    rate_column = RateColumn(unit="B", unit_scale=False, unit_divisor=1000)
    task = Progress(total=100)
    task.completed = 100
    task.speed = 100
    assert rate_column.render(task) == Text("100 B/s", style="progress.data.speed")

    # Test case 2
    rate_column = RateColumn(unit="B", unit_scale=True, unit_divisor=1000)
    task = Progress(total=100)
    task.completed = 100
    task.speed = 100
    assert rate_column.render(task) == Text("100 B/s", style="progress.data.speed")

    # Test case 3
    rate_column = RateColumn

# Generated at 2022-06-18 11:56:51.657243
# Unit test for method render of class RateColumn
def test_RateColumn_render():
    """
    Test for method render of class RateColumn.
    """
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render of class RateColumn
    # Test for method render

# Generated at 2022-06-18 11:56:59.608328
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style
    from rich.style import Style

# Generated at 2022-06-18 11:57:08.795732
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .std import tqdm_gui as std_tqdm_gui
    from .std import trange_gui as std_trange_gui
    from .std import tqdm_notebook as std_tqdm_notebook
    from .std import trange_notebook as std_trange_notebook
    from .std import tqdm_pandas as std_tqdm_pandas
    from .std import tgrange as std_tgrange
    from .std import tnrange as std_tnrange
    from .std import tqdm_pandas as std_tqdm_pandas
    from .std import tqdm_gui as std_tqdm_gui
   

# Generated at 2022-06-18 11:57:18.135891
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn
    from rich.progress import BarColumn
    from rich.progress import TimeElapsedColumn
    from rich.progress import TimeRemainingColumn
    from rich.progress import FractionColumn
    from rich.progress import RateColumn
    from rich.progress import filesize
    from rich.progress import Progress
    from rich.progress import ProgressColumn

# Generated at 2022-06-18 11:57:23.499181
# Unit test for method render of class FractionColumn
def test_FractionColumn_render():
    task = Progress()
    task.completed = 1
    task.total = 2
    task.unit_scale = False
    task.unit_divisor = 1000
    fc = FractionColumn(unit_scale=task.unit_scale, unit_divisor=task.unit_divisor)
    assert fc.render(task) == Text("0.5/2.0 ", style="progress.download")

# Generated at 2022-06-18 11:57:33.548417
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.text import Text
    from rich.theme import Theme
    from rich.panel import Panel
    from rich.table import Table
    from rich.markdown import Markdown
    from rich.padding import Padding
    from rich.syntax import Syntax
    from rich.console import ConsoleOptions
    from rich.measure import Measurement
    from rich.style import Style
    from rich.style import StyleOptions
    from rich.text import Text
    from rich.theme import Theme
    from rich.theme import ThemeOptions
    from rich.traceback import Traceback
    from rich.traceback import TracebackOptions
    from rich.markdown import Markdown
    from rich.markdown import MarkdownOptions
    from rich.panel import Panel

# Generated at 2022-06-18 11:57:36.283141
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:57:46.351998
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich.reset()."""
    from .std import tqdm
    from .utils import _range
    from .utils import format_sizeof

    for total in [None, 10, 100, 1000]:
        with tqdm(total=total) as t:
            for i in _range(total):
                t.update()
            t.reset(total=total)
            for i in _range(total):
                t.update()
            t.reset(total=total)
            for i in _range(total):
                t.update()

    for total in [None, 10, 100, 1000]:
        with tqdm(total=total) as t:
            for i in _range(total):
                t.update()
            t.reset(total=total)

# Generated at 2022-06-18 11:58:59.038673
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    with tqdm_rich(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()

# Generated at 2022-06-18 11:59:07.312276
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """
    Test the reset method of class tqdm_rich.
    """
    from time import sleep
    from rich.progress import Progress
    from rich.console import Console
    console = Console()
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=None),
        "[", TimeElapsedColumn(), "<", TimeRemainingColumn(), "]",
        transient=False,
    )
    with progress:
        task_id = progress.add_task("Task 1", total=10)
        for i in range(10):
            sleep(0.1)
            progress.update(task_id, completed=i)
        progress.reset(total=20)
        for i in range(20):
            sleep(0.1)

# Generated at 2022-06-18 11:59:08.898957
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from time import sleep
    for i in tqdm(range(10), total=10):
        sleep(0.1)
    tqdm.reset(total=20)
    for i in tqdm(range(20), total=20):
        sleep(0.1)

# Generated at 2022-06-18 11:59:16.625897
# Unit test for method display of class tqdm_rich
def test_tqdm_rich_display():
    from rich.progress import Progress
    from rich.console import Console
    from rich.style import Style
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.columns import Columns
    from rich.padding import Padding
    from rich.markdown import Markdown
    from rich.box import Box
    from rich.syntax import Syntax
    from rich.highlighter import RegexHighlighter
    from rich.highlighters.html import HtmlHighlighter
    from rich.highlighters.json import JsonHighlighter
    from rich.highlighters.python import PythonHighlighter
    from rich.highlighters.yaml import YamlHighlighter
    from rich.highlighters.xml import XmlHighlighter


# Generated at 2022-06-18 11:59:21.532786
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    from rich.progress import Progress
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP, BOX_LIGHT_VERTICAL, BOX_LIGHT_HORIZONTAL
    from rich.style import Style
    from rich.syntax import Syntax
    from rich.columns import Columns
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.text import Text
    from rich.console import Console
    from rich.progress import Progress
    from rich.panel import Panel
    from rich.box import BOX_LIGHT_DOWN, BOX_LIGHT_UP, BOX_LIGHT_VERTICAL, BOX_LIGHT

# Generated at 2022-06-18 11:59:23.035797
# Unit test for method clear of class tqdm_rich
def test_tqdm_rich_clear():
    """
    Test that tqdm_rich.clear() does not raise an exception.
    """
    tqdm_rich(range(10)).clear()

# Generated at 2022-06-18 11:59:30.823027
# Unit test for method reset of class tqdm_rich
def test_tqdm_rich_reset():
    """Test tqdm_rich reset method."""
    from time import sleep
    from tqdm.auto import trange
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map

    def f(x):
        sleep(0.01)
        return x ** 2

    for _ in trange(2, desc='1st loop'):
        for _ in trange(5, desc='2nd loop', total=5):
            for i in trange(10, desc='3rd loop', total=10):
                list(process_map(f, range(10), max_workers=2))
                list(thread_map(f, range(10), max_workers=2))
            # `leave=True` to keep bar