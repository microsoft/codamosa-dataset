

# Generated at 2022-06-11 22:04:37.818528
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:04:47.789925
# Unit test for function register
def test_register():
    """``register`` is simply a function that registers the ``b64`` codec
    with Python.  There is not much that can be tested.
    """
    register()


# Generated at 2022-06-11 22:04:56.230135
# Unit test for function register
def test_register():
    # pylint: disable=W0212
    # 'Access to a protected member'
    # This function is a unit test and needs protected access.
    b64_codec = _get_codec_info(NAME)

    # pylint: disable=I1101
    # Note: This class is private to the module but we need access to it
    # to verify that the codec is properly registered.
    from importlib import _bootstrap
    registered_dict = _bootstrap._get_abi_tag()  # type: ignore
    code_map = registered_dict[2]
    assert b64_codec == code_map[NAME]
    assert code_map[NAME] == code_map[NAME.lower()]
    assert code_map[NAME] == code_map[NAME.upper()]
    assert code_map[NAME]

# Generated at 2022-06-11 22:05:00.636675
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'Codec {NAME!r} not able to register with Python.'
        )
    return



# Generated at 2022-06-11 22:05:02.505855
# Unit test for function register
def test_register():
    # pylint: disable=R0201
    register()


# Generated at 2022-06-11 22:05:03.883935
# Unit test for function register
def test_register():
    assert hasattr(codecs, 'getdecoder')



# Generated at 2022-06-11 22:05:15.584100
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('SGVsbG8gV29ybGQ=') == (b'Hello World', 13)
    assert encode(u'SGVsbG8gV29ybGQ=') == (b'Hello World', 13)
    assert encode(u'\x99\xed\x94\xc0\x88\x8b\xd0\x80') == (b'\x99\xed\x94\xc0\x88\x8b\xd0\x80', 8)
    assert encode('SGVsbG8gV29ybGQ=\n') == (b'Hello World', 13)
    assert encode('\nSGVsbG8gV29ybGQ=\n') == (b'Hello World', 13)

# Generated at 2022-06-11 22:05:19.374719
# Unit test for function register
def test_register():
    """Test for the b64.register function."""
    # Unregister the codec.
    codecs.unregister(_get_codec_info)

    # Call the `register` function.
    register()

    # Verify the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('b64 codec not registered.')

# Generated at 2022-06-11 22:05:27.601260
# Unit test for function register
def test_register():
    """Unit test for function register"""
    from sys import modules as _modules

    # Remove the module from the module cache.
    try:
        _modules.pop(NAME)
    except KeyError:
        pass

    # Load the module into the module cache.
    try:
        import b64
        _modules[NAME] = b64
    except ImportError:
        # Not running in an environment that has the b64 codec.
        pass

    # Import the module into a local scope.
    import b64

    # Update the module globals to match they would have
    # if the module was reloaded.
    globals().update(_modules[NAME].__dict__)


# Generated at 2022-06-11 22:05:29.306001
# Unit test for function register
def test_register():
    register()
    out = codecs.getdecoder(NAME)
    assert out is not None


# Generated at 2022-06-11 22:05:39.335183
# Unit test for function register
def test_register():
    """verify that the Codec 'b64' is registered"""
    # Verify that the new codec is not in the codecs list.
    assert not hasattr(codecs, '_cache')
    assert nowattr(codecs, '_unknown')

    # Register the new codec.
    register()

    # Verify that the new codec is in the codecs dump.
    assert hasattr(codecs, '_cache')
    assert hasattr(codecs, '_unknown')
    assert NAME in codecs._cache
    assert NAME in codecs._unknown
    assert codecs._cache[NAME] is codecs._unknown[NAME]


# -------------------------
# Unit tests for functions
# -------------------------

# Generated at 2022-06-11 22:05:44.004217
# Unit test for function register
def test_register():
    """Test that codec object, is returned when ``codecs.getdecoder`` is called
    with 'b64' as argument.
    """
    if NAME not in codecs.__all__:  # type: ignore
        codecs.register(_get_codec_info)  # type: ignore
    obj_get = codecs.getdecoder(NAME)  # type: ignore
    obj_reg = _get_codec_info(NAME)  # type: ignore
    assert obj_get.name == obj_reg.name  # type: ignore
    assert obj_get.encode == obj_reg.encode  # type: ignore
    assert obj_get.decode == obj_reg.decode  # type: ignore



# Generated at 2022-06-11 22:05:49.624412
# Unit test for function register
def test_register():
    codecs.register(None)

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError('Codec was previously registered')

    register()

    codecs.getdecoder(NAME)


# Unit test of function encode

# Generated at 2022-06-11 22:05:54.750527
# Unit test for function register
def test_register():
    from typing import Any
    import sys
    if sys.version_info < (3, 7):
        from . import encode as _encode
        from . import decode as _decode
    else:
        from ._b64 import encode as _encode
        from ._b64 import decode as _decode

    # Add the Registered codec.
    register()
    # Verify the codec is registered.
    codec = codecs.getdecoder(NAME)
    assert codec.encode == _encode
    assert codec.decode == _decode

# Generated at 2022-06-11 22:05:56.961497
# Unit test for function register
def test_register():
    """Test for function register."""
    register()
    assert codecs.getdecoder(NAME)   # type: ignore



# Generated at 2022-06-11 22:06:01.213541
# Unit test for function register
def test_register():
    """Test the function register."""
    codecs.register(_get_codec_info)
    try:
        out = codecs.getdecoder(NAME)
        assert out is not None
    finally:
        codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:06:10.538184
# Unit test for function encode
def test_encode():
    """Test the ``b64`` codec's ``encode`` function."""
    # Make sure the b64 codec is registered.
    register()

    # Make sure that the codec is present in the codec list.
    assert codecs.getencoder(NAME) is not None

    # Make sure that the codec has the correct name.
    assert codecs.getencoder(NAME)[0].name == NAME  # type: ignore[attr-defined]

    # Test that a valid b64 string encodes correctly.
    assert 'dGVzdA==' == encode(b'dGVzdA==')[0].decode('utf-8')

    # Test that an invalid base64 string will throw a UnicodeEncodeError

# Generated at 2022-06-11 22:06:15.140617
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, f'Registering codec {NAME} did not work.'

# Generated at 2022-06-11 22:06:23.532841
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # If the error is raised, then getdecoder is working.
        pass
    else:
        # If no error is raised, then getdecoder is not working.
        assert False, \
            f'`{NAME}` decoder should not be registered.'

    # Call function :func:`register` which should add the codec
    # to the collection of codecs that can be found by the codec
    # search sequence.
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # If the error is raised, then getdecoder is not working.
        assert False, \
            f'`{NAME}` decoder should be registered.'

# Generated at 2022-06-11 22:06:26.253887
# Unit test for function register
def test_register():
    """Test the register function."""
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-11 22:06:29.383156
# Unit test for function register
def test_register():

    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:06:41.479833
# Unit test for function encode
def test_encode():
    assert encode('\r\n\t') == (b'', 0)
    assert encode('\n\n\t\r\t\r') == (b'', 0)
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    try:
        encode('abcd\x80')
    except UnicodeEncodeError as e:
        assert (
            str(e)
            == r"b64 '\x80' in position 4: b'\x80' not legal character"
        )

# Generated at 2022-06-11 22:06:44.064467
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:46.394970
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('Test Failed')

    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:06:49.021529
# Unit test for function register
def test_register():  # noqa: D103
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:06:54.162880
# Unit test for function register
def test_register():
    """Test registering of the ``b64`` codec."""
    # pylint: disable=W0212
    # W0212: Access to a protected member of a client class
    codecs._cache.clear()
    codecs._unknown_encoding_error = None
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:07:02.721177
# Unit test for function register
def test_register():
    from sys import modules
    from types import ModuleType
    from importlib import reload

    codecs_module = 'codecs'
    codecs_module_object = cast(ModuleType, modules[codecs_module])
    reload(codecs_module_object)
    from b64_codec import register
    import codecs

    assert codecs.getdecoder(NAME) is None
    register()
    assert codecs.getdecoder(NAME) is not None
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:07:08.528456
# Unit test for function register
def test_register():
    """Test the function register."""
    # When the 'b64' codec is already registered ensure that the 'register'
    # function doesn't error out.

    # Ensure 'b64' isn't registered by removing it if it is
    # registered.
    codecs.register(  # type: ignore
        lambda name: None if name == NAME else None
    )

    # Register 'b64'
    register()

    # Verify that 'b64' is registered
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:07:15.973244
# Unit test for function register
def test_register():
    """Test function register."""

    from unittest.mock import patch
    from test.test_base64 import (
        _get_codec_info as _mock_getcodec_info,
    )


# Generated at 2022-06-11 22:07:19.003915
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME) is decode

register()

# Generated at 2022-06-11 22:07:26.984943
# Unit test for function register
def test_register():     # pylint: disable=W0613
    """Test the function register()."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:07:28.484098
# Unit test for function register
def test_register():
    """Unit test for function :mod:`register`."""
    register()
    assert NAME in codecs.__all__

# Generated at 2022-06-11 22:07:34.525092
# Unit test for function register
def test_register():
    """Unit test of function register."""
    from . import codec_registry, test_b64

    codec_registry.register(test_b64)
    try:
        b64_codec = codecs.lookup(NAME)
    except LookupError:
        assert False
    else:
        assert NAME == b64_codec.name


# pylint: disable=W0622, R0903
# noinspection PyShadowingBuiltins, PyUnusedLocal

# Generated at 2022-06-11 22:07:38.577053
# Unit test for function register
def test_register():
    """Test function ``register``."""
    codecs.register(_get_codec_info)   # type: ignore
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:49.279984
# Unit test for function register
def test_register():
    import sys
    import unittest
    register()
    # noinspection PyUnresolvedReferences
    test_cases = (
        (b'blah blah blah', 'YmxhaCBibGFoIGJsYWg='),
        (b'blah blah blah\nblah blah blah', 'YmxhaCBibGFoIGJsYWgKYmxhaCBibGFoIGJsYWg=')
    )
    for data_in, text_out in test_cases:
        data_out, _ = codecs.getdecoder(NAME)(text_out)
        assert data_out == data_in

# Generated at 2022-06-11 22:07:56.654317
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import builtins
    import unittest

    # Setup Python.
    if 'encodings' in sys.modules:
        del sys.modules['encodings']
    if 'codecs' in sys.modules:
        del sys.modules['codecs']
    if 'builtins' in sys.modules:
        del sys.modules['builtins']

    # Setup builtins.
    builtins.__dict__.clear()

    # Test function register
    from codecs import encode, decode
    from b64_codec import register
    register()
    assert NAME in sys.modules['encodings'].__all__  # type: ignore
    assert NAME in sys.modules['codecs'].__all__  # type: ignore

    # Test encoding.
   

# Generated at 2022-06-11 22:07:57.744462
# Unit test for function register
def test_register():   # pylint: disable=W0613
    """Unit test for function register."""
    register()



# Generated at 2022-06-11 22:08:00.922133
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)

if __name__ == '__main__':
    print(f'testing {__file__}')
    test_register()
    print('OK')

# Generated at 2022-06-11 22:08:02.405265
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:05.790773
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        msg = 'Failed to register the codec: {!r}'.format(NAME)
        raise AssertionError(msg)

# Generated at 2022-06-11 22:08:16.678829
# Unit test for function register
def test_register():
    """Test the 'register' function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(NAME)
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:20.503823
# Unit test for function register
def test_register():
    """Test the b64 codec registration."""
    global NAME

    name = NAME
    NAME = 'foo'
    assert codecs.getdecoder(name) is None
    NAME = name

    register()
    assert codecs.getdecoder(name) is not None

# Generated at 2022-06-11 22:08:21.973731
# Unit test for function register
def test_register():
    """Test the register function with a known and unknown codec."""
    register()
    register()

# Generated at 2022-06-11 22:08:31.764316
# Unit test for function register
def test_register():
    """Unit test for :func:`register`."""
    from codecs import getdecoder
    from unittest import TestCase
    from unittest.mock import patch

    class TestRegister(TestCase):
        """Unit test for :func:`register`."""

        @patch('codecs.register')
        def test_register(self, mock_register):
            """Unit test for :func:`register`."""
            register()
            mock_register.assert_called_once_with(_get_codec_info)  # type: ignore

    def test_getdecoder():
        """Unit test for :func:`getdecoder`."""
        register()
        getdecoder(NAME)

    test_getdecoder()
    TestRegister('test_register').test_register()



# Generated at 2022-06-11 22:08:33.701993
# Unit test for function register
def test_register():  # pylint: disable=W0612
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:08:41.709880
# Unit test for function encode

# Generated at 2022-06-11 22:08:44.714300
# Unit test for function register
def test_register():
    from . import test_b64
    test_b64.test_register()



# Generated at 2022-06-11 22:08:55.666119
# Unit test for function register
def test_register():
    # Unregister any codec named 'b64'
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)
        assert not codecs.lookup(NAME)

    # Register the codec
    register()
    assert codecs.lookup(NAME)
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

    # Test the encoder
    codecs.lookup(NAME).encode('a') == (b'YQ==', 1)

    # Test the decoder
    codecs.lookup(NAME).decode(b'YQ==') == ('a', 3)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:57.215352
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME).__self__.name

# Generated at 2022-06-11 22:09:05.341337
# Unit test for function register
def test_register():
    # Create a dummy codec.
    class test_codec(codecs.Codec):
        def encode(self, input, errors='strict'):
            return b'', 0
        def decode(self, input, errors='strict'):
            return '', 0

    codec_info = codecs.CodecInfo(
        name='test',
        encode=test_codec().encode,   # type: ignore[arg-type]
        decode=test_codec().decode,   # type: ignore[arg-type]
    )

    # Register the dummy codec.
    codecs.register(lambda name: codec_info if name == 'test' else None)  # type: ignore

    # Get the dummy codec.
    codec = codecs.getdecoder('test')  # type: ignore

    # Unregister the dummy

# Generated at 2022-06-11 22:09:14.786178
# Unit test for function register
def test_register():
    """Test to ensure the ``b16`` codec is properly registered."""
    register()
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:20.937273
# Unit test for function encode
def test_encode():
    assert encode('hello world') == (b'aGVsbG8gd29ybGQ=\n', 11)
    assert encode('i am  here') == (b'aSBhbSAgaGVyZQ==\n', 13)
    assert encode('i am\n here') == (b'aSBhbQ0KaGVyZQ==\n', 15)

# Generated at 2022-06-11 22:09:23.696111
# Unit test for function register
def test_register():
    register()

    b = codecs.getdecoder(NAME)   # type: ignore

    assert b('Zm9v')[0] == 'foo'
    assert b('Zm9v')[1] == 4

# Generated at 2022-06-11 22:09:24.727132
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:09:28.863727
# Unit test for function encode
def test_encode():
    """Test function `encode`"""
    assert encode('TGVuIFRydW1w')[0] == b'Ken Trump'
    assert encode('VGhlIEZlZWRiYWNr')[0] == b'The Feedback'


# Generated at 2022-06-11 22:09:34.035961
# Unit test for function encode

# Generated at 2022-06-11 22:09:40.329283
# Unit test for function register
def test_register():  # pragma: no cover
    # pylint: disable=unused-variable
    try:
        text = """
                Hello World,
                  This is a test file.
                """
        utf_8_text = codecs.encode(text, 'utf-8')
        b64_text = codecs.encode(text, NAME)

        assert utf_8_text != b64_text

        decode_result = codecs.decode(b64_text, NAME)

        assert decode_result == text
        assert decode_result != utf_8_text
    except Exception:
        raise

# Register the codec
register()


if __name__ == '__main__':
    test_register()

# vim: set fileencoding=utf-8 :

# Generated at 2022-06-11 22:09:44.885947
# Unit test for function register
def test_register():  # noqa
    """Unit test for function register."""
    import sys
    if 'codecs' in sys.modules:
        del sys.modules['codecs']
    register()
    c = codecs.getdecoder(NAME)
    assert c is not None
    # Cleanup
    del sys.modules['codecs']

# Generated at 2022-06-11 22:09:46.400304
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:48.527665
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:01.796473
# Unit test for function register
def test_register():
    """Assert that the codec registers properly."""
    codecs.register(_get_codec_info)  # type: ignore
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:10:03.454647
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)   # type: ignore[arg-type]



# Generated at 2022-06-11 22:10:14.296510
# Unit test for function encode
def test_encode():
    # Test examples provided by https://en.wikipedia.org/wiki/Base64
    assert encode('any carnal pleas') == (b'YW55IGNhcm5hbCBwbGVhcw==', 23), \
        'Base 64 "any carnal pleas" failed'
    assert encode('any carnal pleas', errors='strict') == (b'YW55IGNhcm5hbCBwbGVhcw==', 23), \
        'Base 64 "any carnal pleas" failed'
    assert encode('any carnal pleas', errors='ignore') == (b'YW55IGNhcm5hbCBwbGVhcw==', 23), \
        'Base 64 "any carnal pleas" failed'

# Generated at 2022-06-11 22:10:19.051916
# Unit test for function register
def test_register():
    if 'b64' in codecs.getdecoder(NAME):
        raise AssertionError('b64 codec already registered.')
    register()
    if NAME not in codecs.getdecoder(NAME):
        raise AssertionError('Unable to register b64 codec.')
    codecs.lookup('b64')


# Generated at 2022-06-11 22:10:19.932715
# Unit test for function encode
def test_encode():
    pass



# Generated at 2022-06-11 22:10:25.882452
# Unit test for function register
def test_register():
    """Test the register function.  This requires the
    module be imported in order for the codec to be registered.
    """
    import sys

    # Encode an expected text with the codec.  If the codec has not been
    # registered then an exception is thrown.
    expected = 'Cj4K' # plaintext ``□``  encoded as utf8 bytes and then base64
    encoded = expected.encode(NAME)
    assert encoded == b'Cj4K'

    # Verify the registered codec.
    codecs.register(_get_codec_info)  # type: ignore


# Generated at 2022-06-11 22:10:28.348945
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:10:30.882544
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:10:33.484126
# Unit test for function register
def test_register():
    """Register the codec, and then register it again.  Ensure that no
    exception is thrown."""
    register()
    register()



# Generated at 2022-06-11 22:10:36.547956
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()



# Generated at 2022-06-11 22:11:10.078766
# Unit test for function encode
def test_encode():
    """Test the function `encode`."""
    import sys
    _bytes = b'\x01\xff'
    _str = 'A/8='
    _str_in = f'{_str}\n  '
    _str_out = encode(_str_in)
    assert _str_out[0] == _bytes
    assert _str_out[1] == len(_str)
    _str_in = f'  {_str}  \n  '
    _str_out = encode(_str_in)
    assert _str_out[0] == _bytes
    assert _str_out[1] == len(_str)
    try:
        encode('xx')
    except UnicodeEncodeError as e:
        assert len(e.args) == 5

# Generated at 2022-06-11 22:11:19.331075
# Unit test for function encode
def test_encode():
    # This is the inverse process of the base64 characters bHVrZXogc2Fz.
    # Run the following command to get the base64 characters:
    #   $ python -c 'import base64; print(base64.b64encode("hulk smash"))'
    #   b'bHVrZXogc2Fz'
    #
    # Test long strings
    long_string = "\n\nhulk smash\n\n"
    assert encode(long_string) == (b'hulk smash', 11)
    # Test short strings
    short_string = "hulk smash"
    assert encode(short_string) == (b'hulk smash', 11)



# Generated at 2022-06-11 22:11:23.986356
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:11:26.767637
# Unit test for function encode
def test_encode():
    if __name__ != '__main__':
        print("Unit test not run")
        return
    print("Unit test started")
    codecs.register(_get_codec_info)   # type: ignore
    import codecs
    codecs.decode("dGVzdCBvbmUgdHdv", "b64") == b"test one two"


# Generated at 2022-06-11 22:11:28.379377
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error(NAME) == (decode, encode)



# Generated at 2022-06-11 22:11:38.502321
# Unit test for function register
def test_register():
    from io import StringIO
    from .test_main import _generate_test_string

    # test
    test_str = _generate_test_string()
    register()

    # Confirm that the function register() works by retrieving
    # the decoder and encoding and then using them.
    decoder = codecs.getdecoder(NAME)
    encoder = codecs.getencoder(NAME)
    codecs.decode(encoder(test_str)[0], NAME)
    codecs.encode(decoder(test_str)[0], NAME)

    # Test the CodecInfo object.
    codec_obj = codecs.getdecoder(NAME)
    output = StringIO()
    codec_obj.decode(encoder(test_str)[0], NAME)

# Generated at 2022-06-11 22:11:39.652237
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)



# Generated at 2022-06-11 22:11:47.997685
# Unit test for function encode
def test_encode():
    """Unit test for the :function:`~.b64.encode` function."""
    # Some declared but unused variables.
    # noinspection PyUnusedLocal
    aa: str
    # noinspection PyUnusedLocal
    bb: int

    # Test with an empty string.
    aa, bb = encode('')
    assert aa == b''
    assert bb == 0

    # Test with a simple string.
    aa, bb = encode('ABCD')
    assert aa == b'QUJDRA=='
    assert bb == 4

    # Test with a simple string with a trailing newline.
    aa, bb = encode('ABCD\n')
    assert aa == b'QUJDRA=='
    assert bb == 5

    # Test with a multi-line string

# Generated at 2022-06-11 22:11:50.234470
# Unit test for function encode
def test_encode():
    assert encode('SSBsaXR0bGUgbG9uZA==') == (b'A little lon', 15)



# Generated at 2022-06-11 22:11:53.896040
# Unit test for function register
def test_register():
    print('\n[test_register()]')
    codec_name = NAME
    register()
    codecs.getencoder(codec_name)
    codecs.getdecoder(codec_name)
    print('Passed')



# Generated at 2022-06-11 22:12:21.823705
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:29.364008
# Unit test for function register
def test_register():
    """Test the ``b64`` codec registration."""
    # pylint: disable=W0603
    # global register
    global register

    register()
    # Save the actual 'register' function away in the global register_backup
    # variable.
    register_backup = register

    def exception_register():
        """Raise a LookupError."""
        raise LookupError()

    # Install exception_register function in the global 'register' variable.
    register = exception_register
    # run the register function.
    register()
    # Install the actual register function back in the 'register' variable.
    register = register_backup



# Generated at 2022-06-11 22:12:32.488901
# Unit test for function register
def test_register():
    """Test registering the b64 codec with Python."""
    register()
    codecs.getdecoder(NAME)  # Should not raise LookupError
    codecs.getencoder(NAME)  # Should not raise LookupError



# Generated at 2022-06-11 22:12:33.893097
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # No exception raised if register works


# Generated at 2022-06-11 22:12:38.300636
# Unit test for function register
def test_register():
    try:
        codec = codecs.getdecoder(NAME)
        codecs.register(_get_codec_info)
        found = codecs.getdecoder(NAME)
        codecs.register(codec)
        assert codec is found
        codecs.lookup(NAME)
    except LookupError:
        assert False
test_register()


# Unit Test for function decode

# Generated at 2022-06-11 22:12:48.011888
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('aa') == (b'YWE=', 2)
    assert encode('aaa') == (b'YWFh', 3)
    assert encode('aaaa') == (b'YWFhYQ==', 4)
    assert encode('aaaaa') == (b'YWFhYWE=', 5)
    assert encode('aaaaaa') == (b'YWFhYWFh', 6)
    assert encode('aaaaaaa') == (b'YWFhYWFhYQ==', 7)
    assert encode('aaaaaaaa') == (b'YWFhYWFhYWE=', 8)

# Generated at 2022-06-11 22:12:51.983946
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs_tuple = codecs.getdecoder(NAME)
    assert codecs_tuple == (decode, codecs.IncrementalDecoder, None, None)


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:12:53.101175
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:13:04.364255
# Unit test for function register
def test_register():
    register()

    encoder = codecs.getencoder(NAME)
    decoder = codecs.getdecoder(NAME)

    values = [
        # Test tuples where the first value is the base64
        # string and the second value is the decoded value.
        ('aGVsbG8gd29ybGQ=', 'hello world'),
        ('Yml6', 'biz'),
        ('Yml6Lg==', 'biz.'),
    ]

    for value in values:
        encoded = value[0]
        decoded = value[1]

        assert decoder(encoded)[0] == decoded
        assert encoder(decoded)[0].decode('utf8') == encoded

# Generated at 2022-06-11 22:13:05.740160
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:14:07.019480
# Unit test for function register
def test_register():
    # Since the codec name is not in 'sys.modules', the codec has
    # not been registered with Python.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError('codecb64.py already registered')

    # Register the codec
    register()

    # Verify that the codec is registered with Python.
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:14:08.818766
# Unit test for function register
def test_register():
    """Test the function register."""
    # Register the b64 codec and ensure it exists in the Python instances.
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:14:13.298352
# Unit test for function register
def test_register():
    """Test registration of the (de)encoder."""
    register()
    e = codecs.getencoder(NAME)
    d = codecs.getdecoder(NAME)
    assert callable(e)
    assert callable(d)


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:14:22.417878
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    # noinspection PyUnresolvedReferences
    import codecs
    from test.constant import DIR

    # Register the b64 codec with Python.
    register()

    # Verify that the b64 codec is not already registered with Python.
    assert NAME not in codecs.__all__

    # Verify that the b64 codec has been registered with Python.
    assert NAME in codecs.__all__
    assert hasattr(codecs, NAME)

    # Verify that the b64 codec is of type CodecInfo
    assert isinstance(getattr(codecs, NAME), codecs.CodecInfo)

    # Verify that the b64 codec has the expected attributes
    assert hasattr(getattr(codecs, NAME), 'decode')

# Generated at 2022-06-11 22:14:27.739165
# Unit test for function encode
def test_encode():
    input_text = 'YW55IGNhcm5hbCBwbGVhc3VyZS4='
    encoded_bytes, length_of_text = encode(input_text)
    assert len(encoded_bytes) == length_of_text
    assert len(input_text) == length_of_text
    assert len(encoded_bytes) == 22
    assert encoded_bytes.decode('utf-8') == 'any carnal pleasure.'


# Generated at 2022-06-11 22:14:33.073787
# Unit test for function register
def test_register():
    """Test the register function"""
    try:
        codecs.getdecoder(NAME)
        assert False, (
            'Registering twice should not be possible.'
        )
    except LookupError:
        pass
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Registering should not fail.'

# Unit tests for the decode function