

# Generated at 2022-06-11 22:04:37.923714
# Unit test for function register
def test_register():
    """Test the `register` function."""
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.lookup(NAME).name == NAME

# Generated at 2022-06-11 22:04:41.509106
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:04:52.842471
# Unit test for function encode
def test_encode():
    """Test the encode function."""

# Generated at 2022-06-11 22:04:54.371168
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:05:00.765643
# Unit test for function register
def test_register():
    import sys
    import io

    register()
    output = io.StringIO()
    # pylint: disable=W0612
    # noinspection PyUnboundLocalVariable
    _ = codecs.getencoder(NAME)
    # pylint: disable=W0612
    # noinspection PyUnboundLocalVariable
    _ = codecs.getdecoder(NAME)
    # noinspection PyUnboundLocalVariable
    old_string_conversion_action = sys.flags.string_conversion_action
    sys.flags.string_conversion_action = 'silent'

# Generated at 2022-06-11 22:05:03.669013
# Unit test for function register
def test_register():
    """Unit tests for function register."""

    codecs.register(_get_codec_info)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:15.450199
# Unit test for function register
def test_register():
    """Test the function :meth:`register`."""
    import sys
    import unittest

    sys.modules[f'encodings.{NAME}'] = sys.modules[__name__]
    try:
        register()
    finally:
        del sys.modules[NAME]

    class TestRegister(unittest.TestCase):
        """Test that the ``b64`` codec is registered."""

        def test_b64_encoder(self):
            """Test that the ``b64`` codec exists."""
            self.assertIsNotNone(codecs.getencoder(NAME))

        def test_b64_decoder(self):
            """Test that the ``b64`` codec exists."""
            self.assertIsNotNone(codecs.getdecoder(NAME))

    unittest.main()

# Generated at 2022-06-11 22:05:18.173287
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass  # Ok, this is what we expect
    else:
        raise RuntimeError("The unit test 'test_register' failed.")



# Generated at 2022-06-11 22:05:22.008578
# Unit test for function register
def test_register():
    """Test :func:`register` function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:26.496547
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:05:34.564292
# Unit test for function register
def test_register():
    """Test function 'register'."""
    import codecs
    from b64 import register
    from b64.b64 import NAME

    register()

    codecs.lookup(NAME)

# Generated at 2022-06-11 22:05:40.369898
# Unit test for function encode
def test_encode():
    assert encode('TG9yZW0gaXBzdW0=') == (b'Lorem ipsum', 12)
    assert encode('TG9yZW0gaXBzd\nW0=') == (b'Lorem ipsum', 12)
    assert encode('TG9yZW0gaXBzd'
                  '\nW0=') == (b'Lorem ipsum', 12)
    try:
        encode('TG9yZW0gaXBzd\x7F\nW0==')
    except UnicodeEncodeError:
        return
    assert False



# Generated at 2022-06-11 22:05:52.285198
# Unit test for function register
def test_register():
    import sys

    # Remove the 'b64' from the codec list.
    list(map(
        sys.modules['encodings'].aliases.pop,
        filter(
            lambda x: x.lower().startswith(NAME),
            sys.modules['encodings'].aliases
        )
    ))

    # Remove the 'b64' from the decoders list.
    list(map(
        sys.modules['encodings'].decoders.pop,
        filter(
            lambda x: x.lower().startswith(NAME),
            sys.modules['encodings'].decoders
        )
    ))
    # Remove the 'b64' from the encoders list.

# Generated at 2022-06-11 22:05:56.461557
# Unit test for function register
def test_register():
    before = codecs.getencoder(NAME)
    before_decoder = codecs.getdecoder(NAME)
    register()
    after = codecs.getencoder(NAME)
    after_decoder = codecs.getdecoder(NAME)
    assert before == after
    assert before_decoder == after_decoder



# Generated at 2022-06-11 22:06:03.854557
# Unit test for function register
def test_register():
    # Check if the codec is registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'Codec {NAME} is already registered with Python.'
        )
    # Register the codec with Python
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'Codec {NAME} is not registering'
        )

# Generated at 2022-06-11 22:06:11.724506
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec.
    """
    # Remove the codec from the registered codec list.
    list(map(codecs.unregister, [NAME]))

    # Test that the codec is not registered.
    try:
        # calling codecs.getdecoder will raise a LookupError if the
        # codec is not registered.
        codecs.getdecoder(NAME)

        # No exception was raised, so the codec is registered.
        # So raise a RuntimeError.
        raise RuntimeError(f'{NAME} codec is registered.')
    except LookupError:
        # The expected exception was raised, so the codec is not
        # registered.
        pass

    # Register the codec.
    register()

    # Verify that the codec is registered.

# Generated at 2022-06-11 22:06:18.288527
# Unit test for function register
def test_register():
    """Unit test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-11 22:06:24.520401
# Unit test for function register
def test_register():
    """Test the registration of the codec b64."""
    import sys

    # Remove the global reference to the 'b64' codecs.
    try:
        del sys.modules[__name__]    # type: ignore
    except KeyError:
        pass
    else:
        # If the b64 codec was registered, then do a de-registration.
        try:
            codecs.lookup(NAME)
        except LookupError:
            pass
        else:
            codecs.lookup_error(NAME)

    # Now register the codec.
    register()
    codecs.lookup(NAME)

    # Now de-register
    codecs.lookup_error(NAME)
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        raise Assertion

# Generated at 2022-06-11 22:06:33.269795
# Unit test for function encode
def test_encode():
    """
    :return:
    """
    data = "c3VyZS4="
    result = encode(data)
    assert result == (b'sure.', 8)
    data = "VGhpcyBpcyBhIHRlc3QuIEhlcmUgYXJlIHNvbWUgY2hhcmFjdGVyczoKCQkJ4oCm"
    result = encode(data)
    assert result == (b'This is a test. Here are some characters:\n\n\t\u0425\u0438\u0442', 74)


# Generated at 2022-06-11 22:06:38.386469
# Unit test for function register
def test_register():
    """Test the :mod:`~register` function"""
    old = list(codecs.__dict__['_cache'].keys())
    register()
    new = list(codecs.__dict__['_cache'].keys())
    delt = set(new) - set(old)
    assert NAME in delt

# Unit Tests for function encode

# Generated at 2022-06-11 22:06:47.896470
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert NAME in codecs.getdecoder('b64')

# Generated at 2022-06-11 22:06:50.889283
# Unit test for function register
def test_register():
    """Test to make sure that b64 is registered and enabled."""
    assert NAME in codecs.decode.__code__.co_names

# Generated at 2022-06-11 22:06:52.063304
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:53.822221
# Unit test for function register
def test_register():
    register()
    assert(codecs.getdecoder(NAME))

# Generated at 2022-06-11 22:06:56.524752
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:06:58.695617
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:02.797218
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert NAME in codecs.getencoders()


# Generated at 2022-06-11 22:07:05.043038
# Unit test for function register
def test_register():
    """Test for function register()."""
    codecs.register(_get_codec_info)   # type: ignore


# Register the 'b64' codec with Python
register()

# Generated at 2022-06-11 22:07:08.766372
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)


# Generated at 2022-06-11 22:07:11.344327
# Unit test for function register
def test_register():
    '''
    Test the function :meth:`register`.

    '''
    register()
    assert NAME in str(codecs.getencoders())



# Generated at 2022-06-11 22:07:27.844624
# Unit test for function register
def test_register():
    """Coverage test for ``register()``."""
    register()
    assert codecs.getdecoder(NAME)  # type: ignore
    assert codecs.getencoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:07:30.966407
# Unit test for function register
def test_register():
    """Test the function register."""
    register()



# Generated at 2022-06-11 22:07:32.348869
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-11 22:07:33.181263
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:34.862919
# Unit test for function register
def test_register():
    """Test for the ``register`` function."""
    assert NAME not in codecs.__all__
    register()
    assert NAME in codecs.__all__

# Generated at 2022-06-11 22:07:39.012418
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:07:49.856405
# Unit test for function register
def test_register():   # pragma: no cover
    """Test registering the ``b64`` codec with Python."""
    # pylint: disable=C0301

# Generated at 2022-06-11 22:07:54.452131
# Unit test for function register
def test_register():
    """Test the register function."""
    # Make sure the register function has not already been ran.
    try:
        codecs.getdecoder(NAME)
        raise Exception('The codecs have already been registered.')
    except LookupError:
        pass

    try:
        register()
        codecs.getdecoder(NAME)
    finally:
        codecs.lookup(NAME)  # Removes the codec.
    return True


# Generated at 2022-06-11 22:07:57.415574
# Unit test for function encode
def test_encode():
    # Unit test for encode written
    encoded=encode("YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXk=\n")
    assert encoded == (b'abcdefghijklmnopqrstuvwxyz',43)


# Generated at 2022-06-11 22:08:01.890356
# Unit test for function register
def test_register():
    """Test the register function."""
    from collections import UserString
    from unittest.mock import call, patch
    from typing import Optional

    # Create the actual string/bytes test strings.
    test_string_with_indent = '''
       abcd
       1234
       XYZ
    '''.strip()
    test_string_with_indent_bytes = b'YWJjZA==\nMTIzNA==\nWFla\n'
    test_string_without_indent = 'abcd\n1234\nXYZ\n'
    test_string_without_indent_bytes = b'YWJjZA==\nMTIzNA==\nWFla\n'

    # Create the mock class for the codecs.CodecInfo object.

# Generated at 2022-06-11 22:08:20.113337
# Unit test for function register
def test_register():
    """Test the function :func:`.register`.

    This function is called by :func:`test_b64`.
    """
    register()
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod()

    if '--test' in sys.argv:
        from .test_b64 import test_b64
        test_b64()

# Generated at 2022-06-11 22:08:22.432960
# Unit test for function encode
def test_encode():
    assert (b'aGVsbG8gd29ybGQ=\n', 28) == encode('hello world')



# Generated at 2022-06-11 22:08:26.578703
# Unit test for function register
def test_register():
    """Unit test for the function ``register``."""
    register()
    assert codecs.getdecoder('b64') is not None
    assert codecs.getencoder('b64') is not None


# pylint: disable=W0621

# Generated at 2022-06-11 22:08:30.707442
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'Codec is already registered'
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec is not registered'



# Generated at 2022-06-11 22:08:38.480388
# Unit test for function encode
def test_encode():
    expected = b'I am the very model of a modern major general.'
    text = (
        'SQBBU0lEIHRoZSByZXZlcnkgbW9kZWwgb2YgYSBtb2Rlcm4gbWFqb3IgZ2VuZXJh\n'
        'bC4='
    )
    found, _ = encode(text)
    assert expected == found, (
        f'expected:\n'
        f'  {expected!r}\n'
        f'found:\n'
        f'  {found}'
    )


# Generated at 2022-06-11 22:08:40.079372
# Unit test for function register
def test_register():
    """Unit test for the function register()."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:08:52.115751
# Unit test for function register
def test_register():
    """Test for function register."""
    register()
    # noinspection PyUnresolvedReferences
    from base64 import b64decode
    from base64 import b64encode
    from base64 import standard_b64decode

    assert b64decode(b64encode(b'abcd')) == b'abcd'
    assert b64decode(b64encode(b'abcdefg')) == b'abcdefg'
    assert b64decode(b64encode(b'1112223445')) == b'1112223445'

# Generated at 2022-06-11 22:09:03.049153
# Unit test for function encode
def test_encode():
    assert encode('YnJvYg==') == (b'bro', 4)
    assert encode('YnJvYg') == (b'bro', 4)
    assert encode('YnJ\nvYg==') == (b'bro', 6)
    assert encode(' YnJvYg==') == (b'bro', 5)
    assert encode('YnJvYg==\n ') == (b'bro', 5)
    assert encode('Yn JvYg==') == (b'bro', 6)
    assert encode('YWxhcnJv\nYg==') == (b'alarbro', 8)
    assert encode('YWxhcnJvYg=') == (b'alarbro', 8)

# Generated at 2022-06-11 22:09:05.645503
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()



# Generated at 2022-06-11 22:09:09.103069
# Unit test for function register
def test_register():
    """Unit test for function :py:func:`~.register`."""
    register()
    b64 = codecs.getdecoder(NAME)
    assert b64


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:39.017889
# Unit test for function register
def test_register():
    """
    If we can get the decoder function, then the codec has been
    registered.
    """
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:09:44.045790
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

    def test_get_codec_info() -> None:
        """Test that the ``b64`` codec is registered."""
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)

    test_get_codec_info()


# Generated at 2022-06-11 22:09:48.570421
# Unit test for function register
def test_register():
    """Test function :func:`register`."""
    codecs.register = MagicMock(spec=codecs.register)
    register()
    # The codec 'b64' should be registered.
    codecs.register.assert_has_calls(
        call(
            decode=decode,  # type: ignore[arg-type]
            encode=encode,  # type: ignore[arg-type]
            name='b64',
        )
    )

# Generated at 2022-06-11 22:09:52.293164
# Unit test for function register
def test_register():
    """The function register should be registered with Python."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Expected that name 'b64' would be registered"



# Generated at 2022-06-11 22:10:03.009044
# Unit test for function register
def test_register():
    # pylint: disable=protected-access

    # First make sure that the codec is not already registered
    try:
        codecs.getdecoder(NAME)
        raise Exception('expected LookupError')
    except LookupError:
        pass

    # Then use the register function to register the codec
    register()

    # Now that the codec is registered, check that the codec's
    # CodecInfo object can be found
    codec_info = codecs.getdecoder(NAME)
    assert isinstance(codec_info, codecs.CodecInfo)

    # Make sure the found CodecInfo has our expected fields
    assert codec_info.name == NAME
    assert codec_info.encode == encode
    assert codec_info.decode == decode



# Generated at 2022-06-11 22:10:07.438017
# Unit test for function register
def test_register():
    """Test the function register()"""
    codecs.register(_get_codec_info)   # type: ignore
    codecs.lookup('b64')



# Generated at 2022-06-11 22:10:15.428037
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # clean all the codecs
    __module = name = None  # pylint: disable=W0612
    import _codecs
    codecs = _codecs.codecs.copy()
    for name in list(sys.modules.keys()):
        if name.endswith('_codecs') and sys.modules[name] is _codecs:
            del sys.modules[name]
    del sys.modules['_codecs']
    for name in codecs:
        if name not in ('aliases', '__builtins__'):
            try:
                del codecs[name]
            except KeyError:
                pass
    for name in list(_codecs.__dict__.keys()):
        if name == 'register':
            continue

# Generated at 2022-06-11 22:10:20.707484
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    try:
        assert codecs.lookup(NAME)   # type: ignore
    except LookupError:
        raise AssertionError(
            'Failed to register '
            f'the codec {NAME!r}.'
        )
    codecs.lookup(NAME).decode('aGVsbG8=')



# Generated at 2022-06-11 22:10:25.129768
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec with Python."""
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(msg=f"The codec '{NAME}' was not registered.")

# Unit tests for function decode

# Generated at 2022-06-11 22:10:27.569866
# Unit test for function register
def test_register():
    codecs.encode('abc', NAME)



# Generated at 2022-06-11 22:11:39.398747
# Unit test for function encode
def test_encode():
    assert "SGVsbG8h" == encode("Hello!")
    assert "MTIzNDU2Nzg5MDEyMzQ1Ng==" == encode("1234567890123456")

# Generated at 2022-06-11 22:11:44.274051
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    # pylint: disable=W0612
    import base64
    import codecs

    codecs.register(_get_codec_info)  # type: ignore

    data = base64.b64encode(b'Hello World')
    actual = codecs.decode(data, 'b64')
    assert actual == 'Hello World'

# Generated at 2022-06-11 22:11:46.038570
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:11:47.392235
# Unit test for function register
def test_register():
    """Simple test of function `register`"""
    codecs.unregister(NAME)
    register()

# Generated at 2022-06-11 22:11:52.794999
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    decoder_info = codecs.getdecoder(NAME)
    assert decoder_info.name == NAME
    assert decoder_info.decode == decode
    assert decoder_info.encode == encode


if __name__ == '__main__':
    """Run all of the unit tests when this module is called as a script."""
    test_register()

# Generated at 2022-06-11 22:11:58.205195
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""

    # Unregister the codec if it is already registered.
    try:
        codecs.lookup(NAME)
    except LookupError:
        ...
    else:
        codecs.unregister(NAME)

    # Register the codec and make sure that it is registered.
    register()
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:11:59.966637
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:12:01.828508
# Unit test for function register
def test_register():
    """Test for function register."""
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:12:06.800668
# Unit test for function encode

# Generated at 2022-06-11 22:12:17.508524
# Unit test for function encode
def test_encode():
    """test_encode() -> None

    Test the function :func:`encode`.
    """
    valid_values = (
        (
            'Zm9vCmJhcg==',
            b'foo\nbar'
        ),
        (
            'cXVpY2tzbmlmZg==',
            b'quicksniff'
        ),
        (
            'cXVpY2tzbmlmZg=',
            b'quicksniff'
        ),
        (
            'Zm9vIGJhcg==',
            b'foo bar'
        )
    )