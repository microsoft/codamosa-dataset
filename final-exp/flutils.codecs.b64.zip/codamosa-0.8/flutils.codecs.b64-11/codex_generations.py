

# Generated at 2022-06-11 22:04:40.873067
# Unit test for function register
def test_register():
    """Test for function :py:func:`register`."""
    register()
    from codecs import lookup
    obj = lookup(NAME)
    assert obj.name == 'b64'
    assert obj.encode(b'bytes') == (b'Ynl0ZXM=', 6)
    assert obj.decode('Ynl0ZXM=') == ('Ynl0ZXM=', 7)

if __name__ == '__main__':
    test_register()
    import os
    import sys
    try:
        import pytest
    except ImportError:
        PYTEST = False
    else:
        PYTEST = True
    main_module = sys.modules['__main__']

# Generated at 2022-06-11 22:04:48.117074
# Unit test for function encode
def test_encode():
    """
    Unit test for function encode
    """
    # Setup test data.
    test_value = "Hello World"
    test_bytes = b'SGVsbG8gV29ybGQ='
    # Execute test.
    encoded_data, length = encode(test_value)
    # Verify result.
    assert length == len(test_value)
    assert encoded_data == test_bytes


# Generated at 2022-06-11 22:04:55.837677
# Unit test for function register
def test_register():
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """Test registering the b64 codec with Python."""

        @classmethod
        def setUpClass(cls) -> None:
            """Register the b64 codec with Python."""
            b64 = sys.modules[__name__]
            b64.register()

        def test_register(self) -> None:
            """Test registering the b64 codec with Python."""
            # pylint: disable=E1101
            self.assertIn(NAME, codecs.getdecoder(NAME)())

    unittest.main(module=__name__)

# Generated at 2022-06-11 22:05:06.687062
# Unit test for function register
def test_register():
    """Test the register function.
    """
    from io import BytesIO
    from tempfile import TemporaryFile
    import codecs
    tbytes = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09'
    fp = BytesIO(tbytes)
    try:
        codecs.getdecoder('b64')
    except LookupError:
        pass

# Generated at 2022-06-11 22:05:08.983540
# Unit test for function register
def test_register():
    """Test that the 'b64' codec is registered."""

    register()

    codecs.lookup(NAME)


# Test that the 'b64' encoder can be looked up

# Generated at 2022-06-11 22:05:11.269053
# Unit test for function register
def test_register():
    """Testing function register."""
    register()


# Generated at 2022-06-11 22:05:18.983730
# Unit test for function encode
def test_encode():
    """See if the encode function works.

    For example,

    .. code-block:: python

       text = '''
           ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()
           '''
       result, _ = encode(text)
       print(result.decode('utf-8'))
    """
    text = '''
    ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()
    '''
    result, _ = encode(text)
    print(result.decode('utf-8'))



# Generated at 2022-06-11 22:05:24.401067
# Unit test for function register
def test_register():   # pragma: no cover
    register()
    assert codecs.lookup(NAME)


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__], raise_on_error=True)

    # Unit test for function register
    test_register()

# Generated at 2022-06-11 22:05:29.787403
# Unit test for function register
def test_register():
    codecs.register(  # type: ignore
        lambda x: None if x != NAME else codecs.CodecInfo(  # type: ignore
            NAME,
            encode,
            decode,
            incrementaldecoder=None,
            incrementaldecoder=None,
        )
    )

# Generated at 2022-06-11 22:05:32.642623
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:39.652817
# Unit test for function register
def test_register():
    """Test the function 'register'."""
    register()
    assert NAME in codecs.__all__
    assert NAME in codecs.codecs.keys()
    assert NAME in codecs.aliases.keys()
    assert NAME in codecs.decode.__code__.co_freevars
    assert NAME in codecs.encode.__code__.co_freevars
    assert NAME in codecs.lookup.__code__.co_freevars
    assert NAME in codecs.lookup_error.__code__.co_freevars



# Generated at 2022-06-11 22:05:43.033379
# Unit test for function register
def test_register():
    """Test that the codec is registered"""
    register()
    codecs.getdecoder(NAME) #pylint: disable=W0104
    codecs.getencoder(NAME) #pylint: disable=W0104


# Generated at 2022-06-11 22:05:48.718482
# Unit test for function register
def test_register():
    """Unit test for the function register"""
    # pylint: disable=W0212
    assert NAME not in codecs.__all__

    register()

    # pylint: disable=W0212
    assert NAME in codecs.__all__
    assert NAME in codecs.__codecinfo__



# Generated at 2022-06-11 22:05:50.642825
# Unit test for function register
def test_register():
    register()   # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:56.267184
# Unit test for function register
def test_register():
    # pylint: disable=W0612,W0613
    import io
    import os
    import sys

    if sys.version_info >= (3, 8):
        # See: https://bugs.python.org/issue29325
        # Python 3.8 is incompatible with codecs.open() and
        # codecs.StreamWriter.
        return

    # Register the b64 codec.
    register()

    # Create a temporary test file and write some data in it.
    test_mode = 'wb'
    with open('test_b64_codec_register.tmp', test_mode) as tmp_file:
        tmp_file.write(b'abcdefg\n')
        tmp_file.write(b'1234567\n')

        # Write some encoded data, that is decodable by the b64 codec.

# Generated at 2022-06-11 22:06:03.174813
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)
    assert encode('dGVz\ndA==') == (b'test', 10)
    assert encode('dGVz\n\tdA==') == (b'test', 11)

    try:
        encode(b'YWJj')
    except UnicodeEncodeError:
        pass

    try:
        encode(b'^')
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-11 22:06:05.839046
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    if codecs.lookup(NAME) is None:
        raise LookupError(
            f'Failed to find the codec with name of {NAME!r}'
        ) from None
test_register()

del test_register


# pylint: disable=C0111
# noinspection PyUnusedLocal

# Generated at 2022-06-11 22:06:07.829129
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-11 22:06:15.997104
# Unit test for function encode
def test_encode():
    data = 'Man is distinguished, not only by his reason, but by this ' \
           'singular passion from other animals, which is a lust of the ' \
           'mind, that by a perseverance of delight in the continued and ' \
           'indefatigable generation of knowledge, exceeds the short ' \
           'vehemence of any carnal pleasure.'

# Generated at 2022-06-11 22:06:18.427759
# Unit test for function encode
def test_encode():
    result = encode('QQ==')
    
    assert(result == (b'\xb8', 4))


# Generated at 2022-06-11 22:06:27.486572
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function :func:`.register`.  This function is
    normally not executed.  To execute this unit test, run the following
    command:

    .. code-block:: console

        python scripts/codecs/b64.py

    """
    register()



# Generated at 2022-06-11 22:06:35.323222
# Unit test for function encode
def test_encode():
    """Test the 'encode' function."""
    import unittest

    # Define all the test cases where:
    #
    #   test_name: The name of the test.
    #   text: The text to convert into bytes.
    #   expected_value: The correct value to convert 'text' into.
    #   expected_length: The byte length 'text' should be after
    #       it has been converted.

# Generated at 2022-06-11 22:06:45.727597
# Unit test for function register
def test_register():  # pylint: disable=R0915
    """Test the function register"""
    import sys
    import os
    import unittest

    try:
        del sys.modules['b64']   # type: ignore
    except KeyError:
        pass

    # Create a dummy imported module, b64, and then remove all of the
    # codecs that it might have.
    import b64
    del b64.__codecs_aliases__
    del b64.__codecs_encode__
    del b64.__codecs_decode__
    del b64.__codecs_nr_errors__

    # Register the 'b64' codec with Python.
    register()

    from b64 import __codecs_aliases__   # type: ignore
    from b64 import __codecs_encode

# Generated at 2022-06-11 22:06:58.819502
# Unit test for function encode
def test_encode():
    """Test encode function."""
    # Test 1: no indentation, no new lines
    s = "SGVsbG8gV29ybGQ="
    assert encode(s) == (b"Hello World", 15)

    # Test 2: some indentation, some new lines
    s = "SGVsbG8g\nV29y\nbGQ="
    assert encode(s) == (b"Hello World", 15)

    # Test 3: invalid character
    s = "SGVsbG8g\nV29y%\nbGQ="
    try:
        encode(s)
    except UnicodeEncodeError:
        pass
    else:
        assert False, "Expected UnicodeEncodeError"



# Generated at 2022-06-11 22:07:03.236585
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    codecs.lookup(NAME)
 

# Generated at 2022-06-11 22:07:05.628937
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    assert codecs.getdecoder(NAME) is not None, \
        'Failed to register the b64 codec'



# Generated at 2022-06-11 22:07:07.729637
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    register()
    assert codecs.getdecoder(NAME) is _get_codec_info(NAME)



# Generated at 2022-06-11 22:07:08.966931
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.decode.cache

# Generated at 2022-06-11 22:07:13.696022
# Unit test for function register
def test_register():
    from pytest import raises

    from . import register as register_test

    # Attempt to register the b64 codec
    register_test()

    # Make sure that the codec is registered
    codecs.getencoder('b64')

    # Attempt to register the b64 codec
    with raises(LookupError):
        raise codecs.Error

    # Make sure that the codec is registered
    codecs.getencoder('b64')

register()

# Generated at 2022-06-11 22:07:15.462237
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:24.149131
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:07:27.201047
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Register the b64 codec with Python
register()

# Generated at 2022-06-11 22:07:28.081175
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:31.786091
# Unit test for function encode
def test_encode():
    """Test the encode() function."""
    encode('The quick brown fox jumped over the lazy dog.')


# Generated at 2022-06-11 22:07:34.925062
# Unit test for function encode
def test_encode():
    """Test the 'encode' function."""
    input_str = 'text'
    actual = encode(input_str)[0]
    expected = 'dGV4dA=='
    assert actual.decode('utf-8') == expected



# Generated at 2022-06-11 22:07:38.701493
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    pass

# Generated at 2022-06-11 22:07:43.247081
# Unit test for function encode
def test_encode():
    """Test the `encode` function."""
    from base64 import b16encode

    data = b'\x00\xFF'
    b64_str = b16encode(data).decode('ascii')
    assert encode(b64_str) == (data, len(b64_str))



# Generated at 2022-06-11 22:07:46.638151
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # type: ignore
    codecs.getencoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:07:50.902770
# Unit test for function encode
def test_encode():
    # pylint: disable=E1120
    assert base64.decodebytes(
        b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    ) == encode('abcdefghijklmnopqrstuvwxyz')[0]



# Generated at 2022-06-11 22:07:53.397270
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:08:07.600560
# Unit test for function register
def test_register():
    """Test function register"""



# Generated at 2022-06-11 22:08:09.205884
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:08:18.917392
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('HQ==') == (b'h', 3)
    assert encode('QQ==') == (b'A', 3)
    assert encode('Vw==') == (b'W', 3)
    assert encode('Lg==') == (b'.', 3)
    assert encode('Rw==') == (b'R', 3)
    assert encode('/g==') == (b'/', 3)
    assert encode('\n') == (b'', 1)
    assert encode('\r\n') == (b'', 2)

# Generated at 2022-06-11 22:08:21.429336
# Unit test for function register
def test_register():
    """Ensure that the b64 codec is registered."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:08:26.402669
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('codecs.getdecoder(NAME) should not raise'
                             ' LookupError') from LookupError



# Generated at 2022-06-11 22:08:31.114422
# Unit test for function register
def test_register():
    orig_b64_decoder = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    assert orig_b64_decoder != codecs.getdecoder(NAME)
    # Ensure no error is raised when re-registering.
    codecs.register(_get_codec_info)


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:08:39.665547
# Unit test for function register
def test_register():
    test_register.__self__.maxDiff = None
    register()
    obj = codecs.lookup(NAME)
    ex_obj = codecs.CodecInfo(  # type: ignore
        name=NAME,
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )
    expected = {
        'name': NAME,
        '_is_text_encoding': False,
        'encode': encode,  # type: ignore
        'decode': decode,  # type: ignore
    }
    actual = vars(obj)
    assert expected == actual
    assert ex_obj.encode == encode
    assert ex_obj.decode == decode

# Generated at 2022-06-11 22:08:42.872469
# Unit test for function register
def test_register():
    """Test registering the codec."""
    try:
        register()
    except Exception:
        assert False, \
            'Registering the codec should not raise an Exception.'

# Generated at 2022-06-11 22:08:45.272582
# Unit test for function register
def test_register():
    """Unit test for :func:`register`"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:56.518616
# Unit test for function encode
def test_encode():
    assert encode('AQID') == (b'\x01\x02\x03', 4)
    assert encode('AQID\n') == (b'\x01\x02\x03', 4)
    assert encode('AQID ') == (b'\x01\x02\x03', 4)
    assert encode('A\nQ\nI\nD') == (b'\x01\x02\x03', 4)
    assert encode('A\nQ\nI\nD ') == (b'\x01\x02\x03', 4)
    assert encode('A \n Q \n I \n D ') == (b'\x01\x02\x03', 4)

# Generated at 2022-06-11 22:09:10.938030
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder('b64') is not None    # type: ignore


# Generated at 2022-06-11 22:09:19.569635
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert b"BASE64-TEST-BYTES" == encode("BASE64-TEST-BYTES", "strict")[0]
    assert b"BASE64-TEST-BYTES" == encode("BASE64-TEST-BYTES")[0]
    assert b'' == encode('')[0]
    assert encode("")[0] is None
    assert encode(b"BASE64-TEST-BYTES")[0] is None
    assert b'BASE64-TEST-BYTES' == encode('QkFTRTY0LVRFU1QtQllURVM=')[0]

# Generated at 2022-06-11 22:09:29.581624
# Unit test for function encode
def test_encode():
    for encoded, text in TEST_DATA_ENCODE:
        decoded, size = encode(encoded)
        assert decoded == text.encode('utf-8')
        assert size == len(encoded)



# Generated at 2022-06-11 22:09:33.066411
# Unit test for function register
def test_register():
    # noinspection PyBroadException
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()  # type: ignore
        assert codecs.lookup(NAME) is not None  # type: ignore

# Generated at 2022-06-11 22:09:40.062328
# Unit test for function encode
def test_encode():
    """Unit test for :func:`encode`."""
    # Test 1: 'password'.
    key = 'cGFzc3dvcmQ='
    text_bytes = encode(key)[0]
    assert text_bytes == b'password'

    # Test 2: 'SOME TEXT'.
    key = 'U09NRSBUVVFDe4oCm'
    text_bytes = encode(key)[0]
    assert text_bytes == b'SOME TEXT\n'

    # Test 3: 'SOME TEXT'.
    key = 'U09NRSBUVVFDe4oCm'
    text_bytes = encode(key)[0]
    assert text_bytes == b'SOME TEXT\n'

    # Test 4: 'SOME TEXT'.

# Generated at 2022-06-11 22:09:44.393909
# Unit test for function register
def test_register():
    """Unit test for function :py:func:`b64_codec.register`."""
    import codecs
    from importlib import reload

    reload(codecs)
    reload(base64)
    register()
    codecs.lookup('b64')
    codecs.lookup('base64')

# Generated at 2022-06-11 22:09:45.338705
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:09:51.411197
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Unit test for function encode"""
    # Test an empty string
    assert encode('') == (b'', 0)

    # Test a string with one line in it.
    assert encode('VGhpcyBpcyBhIHRlc3QgZm9yIHRlc3RpbmcgdGhlIGVuY29kZSw%20ZGVjb2Rl') == (b'This is a test for testing the encode, decode', 71)

    # Test a string with multiple lines in it.

# Generated at 2022-06-11 22:09:56.461912
# Unit test for function register
def test_register():
    """Test function register()"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'register() is not working'
    assert True, 'register() is working'


if __name__ == '__main__':
    print('Running unit tests')
    test_register()
    print('All unit tests passed')

# Generated at 2022-06-11 22:09:59.125669
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:48.282742
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # It will raise a LookupError if registration failed.

# Generated at 2022-06-11 22:10:51.965313
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    from . import b64
    b64.register()
    codecs.getencoder(b64.NAME)
    codecs.getdecoder(b64.NAME)



# Generated at 2022-06-11 22:10:57.614410
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'YQ==', 1)
    assert encode('B') == (b'Qg==', 1)
    assert encode('no') == (b'bm8=', 2)
    assert encode('or') == (b'b3I=', 2)
    assert encode('is') == (b'aXM=', 2)
    assert encode('de') == (b'ZGU=', 2)
    assert encode('fi') == (b'Zmk=', 2)
    assert encode('co') == (b'Y28=', 2)
    assert encode('nt') == (b'bnQ=', 2)
    assert encode('al') == (b'YWw=', 2)
    assert encode('so') == (b'c28=', 2)

# Generated at 2022-06-11 22:11:01.168769
# Unit test for function register
def test_register():
    """Unit test to verify the register function."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f'The codec {NAME} is not registered.')



# Generated at 2022-06-11 22:11:07.281203
# Unit test for function encode
def test_encode():
    text = ("""
            This is a very long string of text that spans several
            lines.  The text must be indented and the end of the
            string must contain at least one newline.
            """)
    text = text.encode('ascii')
    text = base64.b64encode(text)
    out, length = encode(text)
    assert len(out) == length



# Generated at 2022-06-11 22:11:09.019749
# Unit test for function register
def test_register():
    register()              # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:11:19.216007
# Unit test for function register
def test_register():
    """Test function register()."""
    import pytest
    register_before = codecs.getdecoder(NAME)  # type: ignore
    register()
    register_after = codecs.getdecoder(NAME)   # type: ignore
    assert register_before == register_after
    try:
        register()
    except TypeError as e:
        assert str(e) == 'Codec registry is locked'
    else:
        raise AssertionError('Expected the exception TypeError')
    try:
        codecs.getdecoder('not_present')
    except LookupError as e:
        assert str(e) == 'decoder not_present not found'
    else:
        raise AssertionError('Expected the exception LookupError')



# Generated at 2022-06-11 22:11:26.318053
# Unit test for function register
def test_register():
    """Test for function :func:`register`."""
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, f'Codec "{NAME}" not registered.'


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:32.367996
# Unit test for function register
def test_register():
    """Test for function register."""
    global codecs
    import sys
    import tempfile
    global codecs  # pylint: disable=W0603

    # Extract the original 'codecs' module from the namespace.
    codecs = sys.modules['codecs']
    del sys.modules['codecs']

    # Import and register the b64 codec
    import codecs as test_codecs
    import p4a.b64.codecs

    sys.modules['codecs'] = test_codecs
    p4a.b64.codecs.register()

    # Construct a test file
    with tempfile.TemporaryFile('w+') as test_file:
        text = 'this is a test\n'
        test_file.write(text)

# Generated at 2022-06-11 22:11:34.922918
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    try:
        codecs.getdecoder(NAME)
    # pylint: disable=bare-except
    except:
        assert False



# Generated at 2022-06-11 22:12:27.269159
# Unit test for function register
def test_register():
    """Test the registration of the ``b64`` codec."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:12:29.117625
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:12:33.185162
# Unit test for function register
def test_register():
    """Unit test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)
    register()
    codecs.getdecoder(NAME)
    codecs.unregister(NAME)


# Test codec encoding

# Generated at 2022-06-11 22:12:35.615341
# Unit test for function register
def test_register():
    """Verify that the given codec is registered with Python."""
    # Get the given codec.  If it fails, then the given codec was
    # unregistered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:41.718727
# Unit test for function register
def test_register():
    """Test the register function.

    Note:
        This function is executed if the command line
        ``python -m mccore.codecs.b64`` is executed.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f"The {NAME!r} codec is not register with Python."
        )
    else:
        print(f'The {NAME!r} codec is registered with Python.')



# Generated at 2022-06-11 22:12:43.296554
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:12:45.440940
# Unit test for function register
def test_register():
    registered = False
    try:
        codecs.getencoder(NAME)
    except LookupError:
        registered = True
    assert registered


register()

if __name__ == '__main__':
    pass

# Generated at 2022-06-11 22:12:51.286626
# Unit test for function register
def test_register():
    """Unit test for function register.

    This function runs the register function and verifies that the 'b64'
    codec is registered by attempting to get the 'b64' decoder and
    encoder.
    """
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Unit tests for the 'decode' function.

# Generated at 2022-06-11 22:13:03.946855
# Unit test for function encode

# Generated at 2022-06-11 22:13:06.269773
# Unit test for function register
def test_register():
    """Test the ``register`` function."""

    from codecs import lookup

    register()
    codec_tuple = lookup(NAME)
    assert codec_tuple.name == NAME

