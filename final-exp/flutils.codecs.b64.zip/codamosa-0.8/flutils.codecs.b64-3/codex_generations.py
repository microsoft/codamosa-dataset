

# Generated at 2022-06-11 22:04:46.103951
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)

    assert encode('\n') == (b'', 0)

    assert encode('\n\n\n') == (b'', 0)

    with pytest.raises(UnicodeEncodeError) as e:
        encode('\nq\n')
    assert e.value.start == 0
    assert e.value.end == 1

    with pytest.raises(UnicodeEncodeError) as e:
        encode('\nq')
    assert e.value.start == 0
    assert e.value.end == 1

    with pytest.raises(UnicodeEncodeError) as e:
        encode('\n  q\n')
    assert e.value.start == 1
    assert e.value.end == 2


# Generated at 2022-06-11 22:04:48.509576
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(lambda x: None)
    codecs.getdecoder(NAME)


register()

# Generated at 2022-06-11 22:04:56.698971
# Unit test for function register
def test_register():
    """Test the function register"""
    import sys
    from typing import Dict

    assert sys.getdefaultencoding() == "utf-8", \
        "The tests assume that the system default encoding is UTF-8"


# Generated at 2022-06-11 22:05:02.312363
# Unit test for function register
def test_register():
    # pylint: disable=W0212
    assert not hasattr(register, '_reg_codec')
    register()
    codecs.getdecoder(NAME)
    assert hasattr(register, '_reg_codec')
    register()
    codecs.getdecoder(NAME)
    assert hasattr(register, '_reg_codec')



# Generated at 2022-06-11 22:05:05.584325
# Unit test for function register
def test_register():
    """Test that registering the codec doesn't raise any exceptions."""
    assert not codecs.lookup(NAME)
    print('Testing _register_b64_codec.register')
    register()
    assert codecs.lookup(NAME)

# Generated at 2022-06-11 22:05:10.810080
# Unit test for function register
def test_register():
    """Test function register."""
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        pass
    register()
    assert codecs.getdecoder(NAME) is not None
    codecs.lookup(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:15.287260
# Unit test for function register
def test_register():
    """Unit test for function :meth:`register`."""
    assert codecs.lookup(NAME) is not None
    assert codecs.lookup(NAME).name == NAME
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


if __name__ == '__main__':
    # Test the register function if called directly.
    test_register()

# Generated at 2022-06-11 22:05:18.268857
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    test_register()
else:
    register()

# Generated at 2022-06-11 22:05:24.565158
# Unit test for function register
def test_register():
    # Test case when codec is not registered with python.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'Codec should not be registered with python.'

    # Test case when codec is registered with python.
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:35.356498
# Unit test for function register
def test_register():
    """Test the function register."""
    import sys

    # Make sure that the b64 codec is not already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, f'{NAME} is already registered.'

    # Try to register the b64 codec.
    register()
    codecs.register(_get_codec_info)

    # Make sure that the b64 codec is registered.
    try:
        codecs.getdecoder('b64')
    except LookupError:
        assert False, f'{NAME} was not registered.'

    # Remove the b64 codec from the codecs module.
    delattr(sys.modules['codecs'], f'{NAME}_codec')

# Generated at 2022-06-11 22:05:39.327716
# Unit test for function register
def test_register():
    """Test the function register."""
    # Use 'x' as the codec name to ensure it isn't already registered.
    codecs.codecs_manager.register(_get_codec_info('x'))  # type: ignore



# Generated at 2022-06-11 22:05:40.648474
# Unit test for function encode
def test_encode():
    text = 'YmJjZA=='
    assert encode(text) == (b'bbcd', 6)


# Generated at 2022-06-11 22:05:52.517947
# Unit test for function register
def test_register():
    import inspect
    import sys
    import unittest
    from test.support import captured_stdout
    from test_base64_codec import CodecTests

    class TestBase64Codec(CodecTests):

        module = sys.modules[__name__]
        codec_name = NAME
        check_encode_type_error = False
        register = staticmethod(register)
        test_decode_error = None
        test_encode_error = None

        @classmethod
        def setUpClass(cls):
            super().setUpClass()
            func = cls.module.register
            func()
            cls.codec = codecs.getdecoder(NAME)      # type: ignore
            cls.encode = cls.module.encode

# Generated at 2022-06-11 22:05:59.418184
# Unit test for function register
def test_register():
    # Create a list of the codecs
    codec_list = codecs.encode('', '').decode('').split()

    # Make sure that the codec is not yet registered
    assert NAME not in codec_list

    # Test that the codec is now in the list
    register()
    codec_list = codecs.encode('', '').decode('').split()
    assert NAME in codec_list


filename_encoding = 'b64'
"""The name of the ``b64`` encoding.

This variable is necessary because the standard :obj:`sys.stdout` and
:obj:`sys.stderr` streams do not have the ``name`` attribute.  See:
https://stackoverflow.com/q/14711560/1164295
"""

#
# +++++++++++++++++++++++++++
# +++++++++++++++++++++++++++

# Generated at 2022-06-11 22:06:01.213341
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)


# Generated at 2022-06-11 22:06:05.946528
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    # Try to Get the decoder.  If the decoder exists, that means the
    # register function worked.
    codec = codecs.getdecoder(NAME)
    assert callable(codec)



# Generated at 2022-06-11 22:06:09.574286
# Unit test for function encode
def test_encode():
    x = encode('YmFzZTY0')
    assert x == (b'base64', 6), 'Incorrect result: ' + str(x)
    x = encode('YWDDoWJhc2U2NA==')
    assert x == (b'@base64', 8), 'Incorrect result: ' + str(x)



# Generated at 2022-06-11 22:06:17.859818
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)
    assert NAME in codecs.__dict__['_getcodec']('')
    # Remove the codec for repeated testing.
    del codecs.__dict__['_getcodec']('')[NAME]
    del codecs.__dict__['_decoders']('')[NAME]
    del codecs.__dict__['_encoders']('')[NAME]


# Generated at 2022-06-11 22:06:18.822982
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:26.804664
# Unit test for function register
def test_register():
    """Confirm that the :obj:`register` function works as desired."""
    import sys
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('The b64 codec is already registered.')

    register()
    try:
        sys.getdefaultencoding()
    except LookupError:
        pass
    else:
        raise AssertionError('The b64 codec is already registered.')



# Generated at 2022-06-11 22:06:35.920275
# Unit test for function encode
def test_encode():
    from tests.test_toolbox.test_b64 import NORMAL_CASE, SPECIAL_CASE
    for text, expected_value in NORMAL_CASE + SPECIAL_CASE:
        actual_value = encode(text)[0]
        assert_equals(actual_value, expected_value)


# Generated at 2022-06-11 22:06:37.948039
# Unit test for function register
def test_register():
    """
    Unit test for function register
    """
    register()

    # PASS
    return True



# Generated at 2022-06-11 22:06:39.850211
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert NAME in codecs.getencodings()


# Generated at 2022-06-11 22:06:42.129410
# Unit test for function register
def test_register():
    """Unit test for function b64.register()."""
    register()
    try:
        codecs.lookup(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-11 22:06:43.836215
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:45.098987
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-11 22:06:50.091270
# Unit test for function register
def test_register():
    """Calling function register should register the codec."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:52.662703
# Unit test for function register
def test_register():
    """
    This is unit test for function :func:`register`

    Returns:
        None.
    """
    register()


# Generated at 2022-06-11 22:06:57.955858
# Unit test for function register
def test_register():
    # Verify that the 'b64' codec is not registered.
    assert codecs.lookup(NAME) is None

    # Register the 'b64' codec.
    register()

    # Verify that the 'b64' codec is now registered
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:06:59.375177
# Unit test for function register
def test_register():
    """Ensure that the ``b64`` codec is registered."""
    import codecs
    codecs.register(_get_codec_info)
    assert NAME in codecs.getdecoder(NAME)

test_register()

# Generated at 2022-06-11 22:07:09.735560
# Unit test for function register
def test_register():
    """Test that the codec can be registered with Python."""
    # Register the 'b64' codec.
    register()

    # Get the 'b64' codec and check it's name and attributes.
    codec = codecs.getdecoder(NAME)
    assert codec.name == NAME
    assert codec.encode == encode
    assert codec.decode == decode



# Generated at 2022-06-11 22:07:15.947106
# Unit test for function register
def test_register():
    """Test the register function"""
    register()


if __name__ == '__main__':
    register()
    print(f'Test encoding of ``"Hello, world!"``: {encode("Hello, world!")}')
    print(f'Test decoding of ``"SGVkYXM="``: {decode("SGVkYXM=")}')
    print(
        f"Test decoding of ``SGVkYXM=``: {encode('SGVkYXM=')}",
        file=sys.stderr
    )
    print(
        f"Test decoding of ``SGVkYXM``: {encode('SGVkYXM')}",
        file=sys.stderr
    )

# Generated at 2022-06-11 22:07:21.599241
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise Exception(
            f'The codec {NAME!r} was not registered as expected') from e
    else:
        print(f'The codec {NAME!r} was registered as expected')

# Generated at 2022-06-11 22:07:27.766825
# Unit test for function register
def test_register():
    """Unit testing for function register."""
    register()
    # Setup
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'{NAME} could not be added to the codec map.') from e
    # Teardown

# Generated at 2022-06-11 22:07:29.844661
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:35.350956
# Unit test for function register
def test_register():
    # Verify that the function register actually registers the codec
    # with python.
    #
    # Assert that the codec is not available.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.  This should not raise an exception.
    register()

    # Assert that after register is called, the codec is available.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:38.879241
# Unit test for function register
def test_register():
    from . import reset_register_b64_decoder

    # Reset the b64 decoder.
    reset_register_b64_decoder()

    # No exception is raised.
    register()


# Generated at 2022-06-11 22:07:49.574903
# Unit test for function encode
def test_encode():
    """Test :py:func:`~b64_codec.encode`."""
    # Test 1
    text: str = '\tSGVsbG8sd29ybGQ=\n'
    b64_bytes: bytes = base64.b64decode(text.encode('utf-8'))
    assert encode(text) == (b64_bytes, len(text))

    # Test 2
    text = '\tSGVsbG8sd29ybGQ=\r\n'
    b64_bytes = base64.b64decode(text.encode('utf-8'))
    assert encode(text) == (b64_bytes, len(text))

    # Test 3
    text = '\t\nSGVsbG8sd29ybGQ=\t\n'


# Generated at 2022-06-11 22:07:51.600063
# Unit test for function register
def test_register():
    """Test the function register."""
    codec = codecs.lookup(NAME)
    assert 'decode' in dir(codec)
    assert 'encode' in dir(codec)

# Generated at 2022-06-11 22:07:53.481451
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False   # pragma: no cover


# Generated at 2022-06-11 22:08:02.988874
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # When the codec has not been registered, register it and try
        # again.
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:14.041274
# Unit test for function encode

# Generated at 2022-06-11 22:08:16.644589
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:08:17.875131
# Unit test for function register
def test_register():
    '''
    Test the function register
    '''
    register()


# Generated at 2022-06-11 22:08:19.558904
# Unit test for function register
def test_register():
    """Unit test for function register"""
    import codecs

    register()
    codecs.lookup_error('b64')

# Generated at 2022-06-11 22:08:30.511639
# Unit test for function encode
def test_encode():
    assert encode("QQ==")[0] == b"A"
    assert encode("QQ")[0] == b"A"
    assert encode("QkM=")[0] == b"BC"
    assert encode("QkM")[0] == b"BC"
    assert encode("QkNDRg==")[0] == b"BCCF"
    assert encode("QkNDRg")[0] == b"BCCF"
    assert encode("QkNDRg==")[0] == b"BCCF"
    assert encode("QkNDRg")[0] == b"BCCF"
    assert encode("QkNDRg==")[0] == b"BCCF"
    assert encode("QkNDRg==")[0] == b"BCCF"

# Generated at 2022-06-11 22:08:39.311195
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    register()

    # Get the 'b64' codec
    codec_b64 = codecs.getdecoder(NAME)   # type: ignore

    # Create test data
    text = 'Hello World'
    text_b64_bytes = b'SGVsbG8gV29ybGQ='

    # Encode the test data
    text_b64_str, _ = codec_b64(text)

    # Compare the two
    assert text_b64_bytes == text_b64_str.encode()

    # Decode the test data
    text_bytes = codec_b64(text_b64_bytes)

    # Compare the two
    assert text_bytes == text

# Generated at 2022-06-11 22:08:49.370339
# Unit test for function register
def test_register():
    import sys
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter(
            'ignore',
            category=DeprecationWarning
        )
        original_getdecoder = codecs.getdecoder
        original_register = codecs.register
        codecs.getdecoder = lambda name: None
        codecs.register = lambda codec_info: None
        try:
            import b64.codec

            b64.codec.register()
            assert NAME in sys.modules['codecs'].getdecoder(NAME)
        finally:
            codecs.getdecoder = original_getdecoder
            codecs.register = original_register


# Generated at 2022-06-11 22:08:56.639169
# Unit test for function register
def test_register():
    """Test that the register function functions."""
    # Check to see it is already registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # The codec is not registered.  Register it.
        register()

    # Check if the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        # The codec is not registered.  It should have been.
        raise RuntimeError(f'Failed to register {NAME}') from e

# Generated at 2022-06-11 22:09:05.208211
# Unit test for function register
def test_register():  # pylint: disable=R0914
    # Delete the codec.
    if 'b64' in codecs.__dict__['__all__']:
        del codecs.__dict__['__all__']['b64']
    del codecs.__dict__[NAME]

    # Register the codec
    register()

    # Confirm that the codec is registered.
    codecs.getdecoder(NAME)
    # Confirm that the codec is in the codecs.__dict__['__all__']
    assert\
        NAME in codecs.__dict__['__all__']

    # Confirm that the codec is in the codecs.__dict__
    assert\
        NAME in codecs.__dict__


# Generated at 2022-06-11 22:09:21.984184
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-11 22:09:32.319864
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    # Ensure that the register function runs without errors.
    register()
    # Ensure that the lookup function returns a CodecInfo object.
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    from sys import argv

    # If called as a stand-alone python program decode the given text
    # as base64 characters to a string of bytes.  Output the bytes as
    # a string of hex digits.
    if len(argv) > 1:
        if len(argv) > 2:
            print('b64.py takes exactly one argument.')
        else:
            # Call the decode function.
            b64_str = argv[1]
            bytes_str, _ = decode(b64_str)

            # Convert the returned bytes into a string of

# Generated at 2022-06-11 22:09:34.104325
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:44.597139
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    # noinspection PyUnresolvedReferences
    from test.test_support import run_unittest
    import b64
    # pylint: disable=W0611
    from test import test_b64

    from unittest import TestCase

    class CodecTests(TestCase):
        def testRegister(self):
            codecs.register(_get_codec_info)  # type: ignore
            codecs.getdecoder(NAME)

        def testGetCodecInfo(self):
            obj = codecs.getdecoder(NAME)  # type: ignore
            self.assertEqual(obj.name, NAME)

        def testDecode(self):
            obj = codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:09:46.438459
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:09:49.388165
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:09:52.624605
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec has been registered."""
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:10:03.885923
# Unit test for function encode
def test_encode():
    # Test a normal case
    text = "Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure."
    result = encode(text)

# Generated at 2022-06-11 22:10:09.065317
# Unit test for function register
def test_register():
    """Test registration of the ``b64`` codec from the command line."""
    if __name__ == '__main__':
        print('Registering b64 codec')
        register()
        print('Done')


# Generated at 2022-06-11 22:10:14.859021
# Unit test for function register
def test_register():
    """Test function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore
    assert codecs.getencoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:10:33.130013
# Unit test for function register
def test_register():
    # pylint: disable=C0103,R0201
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:10:34.124536
# Unit test for function register
def test_register():
    """Test the function register."""
    register()

# Generated at 2022-06-11 22:10:39.320305
# Unit test for function register
def test_register():
    """Test function register()."""
    codecs.register(_get_codec_info)   # type: ignore
    found = codecs.lookup(NAME)
    assert found.name == NAME

# Generated at 2022-06-11 22:10:42.357326
# Unit test for function register
def test_register():
    """Test that register function is functioning as expected."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    import python_dev_tools.codecs.b64
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:10:45.932056
# Unit test for function register
def test_register():
    """Test the function ``register()``."""
    # noinspection PyTypeChecker
    try:
        decode()
        assert False
    except LookupError:
        assert True
    register()



# Generated at 2022-06-11 22:10:48.246351
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:10:50.979520
# Unit test for function encode
def test_encode():
    print(encode('SGVsbG8gV29ybGQ='))


# Generated at 2022-06-11 22:10:52.405262
# Unit test for function register
def test_register():   # type: ignore
    """Register the ``b64`` codec with Python."""
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:10:57.858782
# Unit test for function encode
def test_encode():
    """Unit Test for function encode"""

# Generated at 2022-06-11 22:11:00.395184
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Test for function decode

# Generated at 2022-06-11 22:11:35.574637
# Unit test for function encode
def test_encode():
    """Test unit for function encode."""
    # The given text is the base64 encoded 'Hello World'
    given_text = 'SGVsbG8gV29ybGQ='

    # Invoke the encode function with the given text
    actual_bytes, actual_length = encode(given_text)

    # The expected decoded bytes of the given_text
    expected_bytes = b'Hello World'

    # The length of the expected_bytes
    expected_length = len(given_text)

    # Verify the actual decoded bytes match the expected decoded bytes
    assert expected_bytes == actual_bytes

    # Verify the actual length of the decoded bytes match the expected
    # length of the decoded bytes.
    assert expected_length == actual_length



# Generated at 2022-06-11 22:11:37.975365
# Unit test for function register
def test_register():
    "Test the function register()."
    # pylint: disable=protected-access
    # pylint: disable=no-member
    import codecs
    codecs._search_function = None
    try:
        register()
        # Check that the ''b64' codec was registered.
        codecs.getdecoder('b64')
    finally:
        codecs._search_function = None


# Generated at 2022-06-11 22:11:47.530344
# Unit test for function register
def test_register():           # pylint: disable=R0915
    """Unit test for function register"""
    try:
        import codecs
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        import codecs
        _codec_info = codecs.getdecoder(NAME)  # type: ignore
        assert _codec_info.name == NAME
        assert decode('YWJjZA==') == ('abcd', 4)
        assert encode(b'abcd') == (b'YWJjZA==', 4)

    # Test function 'encode'.
    test_str = ' \n' \
               'YWJjZA==  \t\n'
    expected_bytes = b'abcd'
    expected_length = 4

# Generated at 2022-06-11 22:11:49.814424
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:11:54.111781
# Unit test for function register
def test_register():
    """Test function register."""
    try:
        codecs.getdecoder('b64')
        assert False, 'The codec was already registered.'
    except LookupError:
        pass
    register()
    assert codecs.getdecoder('b64') is not None
    assert codecs.getencoder('b64') is not None


# Generated at 2022-06-11 22:12:03.255271
# Unit test for function encode
def test_encode():
    '''
    Unit tests for function encode
    '''
    assert encode(
        """
        M55CY2VjcmV0IDExMTExMTEvMTY1MTY1MTY1Cg==
        """
    ) == (
        b'\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa',
        48
    )

    assert encode(
        """
        MTEzNjU5ODc2NQ==
        """
    ) == (
        b'\x01\x23\x45\x67\x89\xab\xcd\xef',
        22
    )


# Generated at 2022-06-11 22:12:10.057520
# Unit test for function encode
def test_encode():
    """Unit test for function encode.
    """
    text = '\n'.join(
        (
            'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=',
            'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo',
            'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo',
            'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo',
            '\n'
        )
    )
    out, _ = encode(text)
    assert isinstance(out, bytes)

# Generated at 2022-06-11 22:12:11.645938
# Unit test for function register
def test_register():
    """Test that registers the b64 codec"""
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-11 22:12:19.097771
# Unit test for function encode
def test_encode():
    """Unit test for ``encode``."""
    # Test 1
    assert encode('Zg==') == (b'f', 3)
    assert encode('Zm8=') == (b'fo', 4)
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('Zm9vYg==') == (b'foob', 6)
    assert encode('Zm9vYmE=') == (b'fooba', 7)
    assert encode('Zm9vYmFy') == (b'foobar', 7)

    # Test 2
    text = '''
        Zg==
        Zm8=
        Zm9v
        Zm9vYg==
        Zm9vYmE=
        Zm9vYmFy
    '''


# Generated at 2022-06-11 22:12:22.987530
# Unit test for function register
def test_register():
    """Validate that the ``b64`` codec is registered with Python.
    This test will actually cause a ``LookupError`` exception to be
    raised if the codec is not registered.
    """
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:52.884309
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # Make sure that the codec can be registered and unregistered.
    try:
        register()
    finally:
        codecs.unregister(NAME)



# Generated at 2022-06-11 22:12:55.206309
# Unit test for function register
def test_register():  # pragma: no cover
    register()
    assert codecs.codecs_encode([], 'A')[0] == b'QQ=='

# Generated at 2022-06-11 22:13:06.659501
# Unit test for function register
def test_register():

    def do_test(obj):
        if isinstance(obj, bytes):
            obj = obj.decode('utf-8')
        if not isinstance(obj, str):
            obj = str(obj)
        expected = f"{obj!r}"
        actual = ''
        try:
            if isinstance(obj, bytes):
                encoded = codecs.encode(obj, NAME)
                decoded = codecs.decode(encoded, NAME)
            else:
                encoded = codecs.encode(obj, NAME)
                decoded = codecs.decode(encoded, NAME)
        except Exception as e:
            actual = e
        assert expected == actual

    # Try ascii text
    test_str = 'ABCD'
    do_test(test_str)

# Generated at 2022-06-11 22:13:08.888616
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:13:12.002501
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:13:14.649954
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

register()

# Generated at 2022-06-11 22:13:19.339043
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)
    assert isinstance(codecs.getencoder(NAME), codecs.CodecInfo)


# Generated at 2022-06-11 22:13:28.581650
# Unit test for function encode
def test_encode():
    ret_val, ret_len = encode('YXNkZmFzZGZhc2RmYXNkZmFzZGZhc2RmYXNkZg==\n') \
                       # noqa: E501
    assert ret_val == b'asdfasdfasdfasdfasdfasdf'
    assert ret_len == 62

    ret_val, ret_len = encode('\n YXNk \n ZmFz \n ZGZh \n c2Rm \n YXNk \n Zg== \n\n') \
                       # noqa: E501
    assert ret_val == b'asdfasdfasdfasdf'
    assert ret_len == 26



# Generated at 2022-06-11 22:13:34.929361
# Unit test for function register
def test_register():
    """
    >>> test_register()
    ...
    """
    register()
    try:
        # pylint: disable=W0612
        encoder = codecs.getencoder(NAME)
        decoder = codecs.getdecoder(NAME)
    except LookupError:
        raise


# Generated at 2022-06-11 22:13:35.591710
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:14:08.703208
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys

    # pylint: disable=W0212
    sys.modules['b64'] = sys.modules['__main__']
    register()
    del sys.modules['b64']



# Generated at 2022-06-11 22:14:11.322558
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    test_register()

# Generated at 2022-06-11 22:14:20.306693
# Unit test for function register
def test_register():
    global NAME
    NAME = 'test'
    try:
        codecs.getencoder(NAME)
        assert False
    except LookupError as e:
        assert isinstance(e, LookupError)
        assert e.msg == f'unknown codec: {NAME}'

    # noinspection PyUnusedLocal
    def dummy_get_codec(name):
        return None

    # Replace the getencoder implementation with a dummy implementation
    # for the duration of this test.
    codecs.getencoder = dummy_get_codec
    codecs.getdecoder = dummy_get_codec

    # The codec should not be registered with Python.
    register()

# Generated at 2022-06-11 22:14:22.612828
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.encode('', NAME)
    assert NAME in codecs.encode('', NAME)



# Generated at 2022-06-11 22:14:26.935394
# Unit test for function register
def test_register():
    """Test function :func:`register`."""
    # Reset the codecs
    codecs.reset()
    # Assert that name not in codecs
    assert NAME not in codecs.__dict__
    # Register the codec.
    register()
    # Assert that name was registered.
    assert NAME in codecs.__dict__


# Register the codec.
register()
del register

# Generated at 2022-06-11 22:14:33.831918
# Unit test for function register
def test_register():
    from base64 import b64encode, b64decode
    register()
    data = b'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    encoded_str = b64encode(data).decode('utf-8')
    decoded_bytes = b64decode(encoded_str)
    assert data == decoded_bytes
    assert data == encoded_str.encode(NAME)
    assert encoded_str == decoded_bytes.decode(NAME)

if __name__ == '__main__':
    test_register()