

# Generated at 2022-06-11 22:04:41.135381
# Unit test for function register
def test_register():
    """Unit test for function register."""
    from b64 import b64
    from b64.b64 import decode, encode, NAME
    # noinspection PyUnresolvedReferences
    from b64.codec_b64 import register

    codecs.register(b64.get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:04:44.272961
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.lookup(NAME)
    codecs.lookup_error(NAME)

# Generated at 2022-06-11 22:04:49.751306
# Unit test for function register
def test_register():
    """
    Unit test for function register
    """
    register()
    codecs.getdecoder(NAME)


if __name__ == "__main__":
    test_register()


__all__ = [
    'decode',
    'encode',
    'register',
    'decode',
    'NAME',
    'test_register',
]

# Generated at 2022-06-11 22:04:52.842030
# Unit test for function register
def test_register():
    """Simple test to verify that the codec is registered with Python.
    """
    # Register the b64 codec
    register()

    # Verify that the codec is registered.
    assert NAME in codecs.getdecoders()



# Generated at 2022-06-11 22:04:55.455213
# Unit test for function register
def test_register():
    register()

    # noinspection PyUnresolvedReferences
    codec: codecs.CodecInfo
    codec = codecs.getdecoder(NAME)
    assert codec.decode(b'aG91cg==')[0] == 'hours'

# Generated at 2022-06-11 22:04:58.412451
# Unit test for function register
def test_register():
    """Test function register()"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:05:07.721490
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    from . import codec_test
    # Test that the expected codec is not yet registered
    try:
        codec_test.test__get_codec_info(NAME)
    except LookupError:
        # The codec is not yet registered.
        # Test the register function
        register()
    else:
        raise LookupError(
            f'{NAME} is already registered'
        )
    finally:
        # Test that the name registers
        obj = codec_test.test__get_codec_info(NAME)
        assert obj is not None
        assert obj.name == NAME
        assert obj.encode is encode
        assert obj.decode is decode

# Generated at 2022-06-11 22:05:09.987186
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:12.980883
# Unit test for function encode
def test_encode():
    text = 'example of base64 string'
    b_text = codecs.encode(text, NAME)
    assert b_text == b'ZXhhbXBsZSBvZiBiYXNlNjQgc3RyaW5n'


# Generated at 2022-06-11 22:05:14.912903
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None

register()

# Generated at 2022-06-11 22:05:17.570853
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:22.155966
# Unit test for function register
def test_register():
    """Unit test for function register"""
    assert _get_codec_info is not None
    assert decode is not None
    assert encode is not None



# Generated at 2022-06-11 22:05:33.742030
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Register the base64 codec.
    import base64codec
    base64codec.register()

    test_str = "Kx"
    test_bytes = base64.b64decode(test_str)

    # assert that the encode function can be used.
    encoded_str = base64codec.encode(test_bytes)
    assert encoded_str[0] == test_str

    # assert that the decode function can be used.
    decoded_bytes = base64codec.decode(encoded_str[0])
    assert decoded_bytes[0] == test_bytes

    # assert that the encoded string can be decoded using the base64 module.
    assert base64.b64decode(encoded_str[0]) == test_bytes

    # assert that the

# Generated at 2022-06-11 22:05:41.305065
# Unit test for function register
def test_register():
    # Setup
    b64_decoder = codecs.getdecoder('b64')
    # Exercise
    register()
    codecs.register(_get_codec_info)  # type: ignore
    # Verify
    b64_decoder == codecs.getdecoder(NAME)
    b64_encoder = codecs.getencoder('b64')
    b64_encoder == codecs.getencoder(NAME)

# pylint: disable=C0116

# Generated at 2022-06-11 22:05:44.180511
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    # remove the codec from the global codec table
    codecs.search_function.pop()


# Generated at 2022-06-11 22:05:46.269372
# Unit test for function register
def test_register():
    """Test the function :func:`^._get_codec_info`."""
    register()



# Generated at 2022-06-11 22:05:48.718724
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()



# Generated at 2022-06-11 22:05:54.367194
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert (
        encode('\n'.join(
            [
                "this is a comment",
                "",
                "VGVzdGluZyAxMjMtMTIzMTIz",
                "",
                "And 123-123123"
            ]
        )) == (b"Testing 123-123123", 69)
    )
    try:
        encode('bad input')
    except UnicodeEncodeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 22:05:57.533226
# Unit test for function register
def test_register():
    """Unit Test the register() function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:00.143850
# Unit test for function register
def test_register():
    assert not codecs.lookup(NAME)
    register()  # Add the codec to the 'codecs' module.
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:06:06.148395
# Unit test for function register
def test_register():
    register()
    b64 = codecs.lookup(NAME)
    assert b64.name == NAME
    assert b64.decode('sQ==') == 'a'
    assert b64.encode('a') == b'sQ=='



# Generated at 2022-06-11 22:06:15.976069
# Unit test for function register
def test_register():
    """Tests the function 'register'.
    """
    # pylint: disable=global-statement
    # pylint: disable=invalid-name
    # pylint: disable=redefined-outer-name
    # noinspection PyUnresolvedReferences
    global NAME
    global _get_codec_info
    global encode
    global decode

    old_get_codec_info: Optional[codecs.CodecInfo] = _get_codec_info  # type: ignore
    old_encode: Optional[codecs.Encoder] = encode
    old_decode: Optional[codecs.Decoder] = decode


# Generated at 2022-06-11 22:06:18.428499
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert NAME in codecs.getdecoder(NAME)   # type: ignore

# Generated at 2022-06-11 22:06:23.435961
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # Unregister the 'b64' codec.
    try:
        codecs.unregister(NAME)
    except LookupError:
        pass
    assert not codecs.lookup(NAME)

    # Register the 'b64' codec.
    register()

    # Check that the codec has been registered.
    assert codecs.lookup(NAME).name == NAME

    # Check that this function is idempotent
    register()
    assert codecs.lookup(NAME).name == NAME

# Generated at 2022-06-11 22:06:30.850636
# Unit test for function register
def test_register():
    import sys
    # Assert that the 'b64' codec is not in the codecs list.
    assert NAME not in tuple(codecs.getdecoders())
    # Register the 'b64' codec.
    register()
    # Assert that the 'b64' codec is in the codecs list.
    assert NAME in tuple(codecs.getdecoders())

    # Remove the 'b64' codec from the codecs list.
    del sys.modules['b64']



# Generated at 2022-06-11 22:06:34.513110
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    test_str = 'YQ=='
    test_bytes = 'a'.encode()
    assert codecs.decode(test_str, NAME) == test_bytes
    assert codecs.encode(test_bytes, NAME) == test_str

register()

# Generated at 2022-06-11 22:06:36.390385
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec"""
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:06:46.414603
# Unit test for function encode
def test_encode():
    """Unit test for ``encode()`` function."""
    test_data = (
        (
            'dGVzdA==',
            b'test',
        ),
        (
            'dGVzdA==\n',
            b'test',
        ),
        (
            '    dGVzdA==  ',
            b'test',
        ),
        (
            '    dGVzdA==\n  ',
            b'test',
        ),
        (
            'dGV zdA==\n  ',
            b'test',
        ),
        (
            'dGVzdA==\n  \n',
            b'test',
        ),
        (
            'dGVzdA=\n=\n',
            b'test',
        ),
    )



# Generated at 2022-06-11 22:06:56.523350
# Unit test for function register
def test_register():
    """Test function register"""
    # noinspection PyProtectedMember
    if sys.__plen__ == 2:
        pass
    else:
        # noinspection PyPackageRequirements
        import pytest
        pytest.skip('Test only available for Python 2')
    # Test the registered codecs
    # noinspection PyUnresolvedReferences
    from b64.codecs import codec_registry
    codec_registry.register()
    assert NAME in codecs.getencodings()
    assert NAME in codecs.getdecodings()
    assert NAME in sys.getdefaultencoding()

# Generated at 2022-06-11 22:06:59.017573
# Unit test for function register
def test_register():
    """Test the function ``register()``."""
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:07:04.640780
# Unit test for function register
def test_register():
    "b64.test_register()"
    register()
    assert(None != codecs.getdecoder(NAME))


# Unit Test function
# pylint: disable=W0613

# Generated at 2022-06-11 22:07:13.562746
# Unit test for function encode
def test_encode():
    TEXT = '''
        Hello world!
        How are you?
        This is a test.
        '''
    EXPECTED = b'SGVsbG8gd29ybGQhSG93IGFyZSB5b3U/VGhpcyBpcyBhIHRlc3Qu'

    # Convert the given 'text', that are of type UserString into a str.
    text_input = str(TEXT)

    # Cleanup whitespace.
    text_str = text_input.strip()
    text_str = '\n'.join(
        filter(
            lambda x: len(x) > 0,
            map(lambda x: x.strip(), text_str.strip().splitlines())
        )
    )

    # Convert the cleaned text into utf8 bytes
    text_bytes = text_str.en

# Generated at 2022-06-11 22:07:14.775362
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    assert NAME in codecs.__all__


register()

# Generated at 2022-06-11 22:07:17.900993
# Unit test for function register
def test_register():
    """Register ``b64`` codec and verify it can be looked up."""
    register()
    assert NAME == codecs.getdecoder(NAME).name  # type: ignore


# Generated at 2022-06-11 22:07:19.159421
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:07:23.687427
# Unit test for function register
def test_register():
    """Unit test for the function: 'register'."""
    #  Check if the name is already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # if not registered then register it.
        register()
    else:
        # The codec is already registered.  Do nothing.
        pass


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:27.505682
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)   # type: ignore
    codecs.getdecoder(NAME)   # type: ignore



# Generated at 2022-06-11 22:07:31.723132
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    assert codecs.getencoder(NAME) is not None     # type: ignore
    assert codecs.getdecoder(NAME) is not None     # type: ignore
    assert codecs.getincrementalencoder(NAME) is not None     # type: ignore
    assert codecs.getincrementaldecoder(NAME) is not None     # type: ignore


# Register with Python codecs at import time.
register()

# Generated at 2022-06-11 22:07:35.351092
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    assert obj.name == NAME


if __name__ == '__main__':
    import pytest
    pytest.main(['-r', '-s', __file__])

# Generated at 2022-06-11 22:07:46.397653
# Unit test for function register
def test_register():
    """Test the function :func:`~register`"""
    codecs.register(_get_codec_info)
    test_bytes = b'\xe4\xbd\xa0\xe5\xa5\xbd'
    assert (
        codecs.decode(
            # pylint: disable=C0301
            '5Lit5paH',
            encoding=NAME
        ) == test_bytes
    )
    assert (
        codecs.encode(
            # pylint: disable=C0301
            test_bytes,
            encoding=NAME
        ) == '5Lit5paH'
    )
    # Remove the codecs entry to allow the function to be re-run.
    del(codecs.lookup_error[NAME])

register()

# Generated at 2022-06-11 22:07:58.254039
# Unit test for function register
def test_register():
    # Get the initial set of codecs.
    init_codecs = codecs.getdecoder(NAME)

    # Call the function to register this new codec.
    register()

    # Get the codecs after the register function is called.
    new_codecs = codecs.getdecoder(NAME)

    # Validate that the new codec is registered.
    assert init_codecs is not new_codecs



# Generated at 2022-06-11 22:08:00.603320
# Unit test for function register
def test_register():
    """Test to register the codec."""
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-11 22:08:04.902034
# Unit test for function register
def test_register():
    """Test function register().
    """
    register()
    assert NAME in codecs.getdecoder(NAME)().name


if __name__ == '__main__':
    from pytest import main as pytest_main, skip
    skip('test_register')
    pytest_main(['test_b64.py'])

# Generated at 2022-06-11 22:08:07.089963
# Unit test for function register
def test_register():
    """Test registering the codec."""
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:08:16.573232
# Unit test for function encode
def test_encode():
    # Decoded input to encode.
    input_bytes = b'I am a boy.'

    # Encode the bytes.
    encoded_bytes = codecs.encode(input_bytes, NAME)

    # The expected output of the encode function.
    expected_bytes = b'SSBhbSBhIGJveS4='

    # Check that the encoded bytes are the same as the expected output.
    assert expected_bytes == encoded_bytes

    # Decode the encoded bytes.
    decoded_bytes = codecs.decode(encoded_bytes, NAME)

    # Check that the decoded bytes are the same as the original input.
    assert input_bytes == decoded_bytes



# Generated at 2022-06-11 22:08:27.511340
# Unit test for function register
def test_register():
    """Unit test for function ``register()``."""

    import sys
    import types

    # Save the current codecs.getdecoder.
    old_getdecoder = codecs.getdecoder
    # Replace the current codecs.getdecoder with a stub.
    codecs.getdecoder = lambda name: old_getdecoder(name)

    # Register the b64 codec.
    register()

    # Retrieve the codec information for the b64 codec.
    c_info = codecs.getdecoder(NAME)
    # Ensure that the codec information is not None.
    assert c_info is not None

    # Unit test for the b64 decode method.
    d_obj = c_info.decode


# Generated at 2022-06-11 22:08:30.864649
# Unit test for function register
def test_register():
    """Test that the codec is register with python."""
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj is not None


test_register()

# Generated at 2022-06-11 22:08:32.180440
# Unit test for function register
def test_register():  # pylint: disable=W0105
    register()



# Generated at 2022-06-11 22:08:37.478315
# Unit test for function register
def test_register():
    """Test the `register` function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError(
            'The codec has already been registered.'
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('The codec has not been registered.')

# Generated at 2022-06-11 22:08:41.380194
# Unit test for function register
def test_register():
    """Unittest for the function register()."""
    class DummyObject:
        """Class to test that the register function functions
        when the codec is not defined."""
        pass

    codecs.register = DummyObject()  # type: ignore
    assert codecs.register != DummyObject()
    codecs.register = DummyObject()  # type: ignore
    assert codecs.register != DummyObject()


# Generated at 2022-06-11 22:09:03.882251
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('test') == (b'', 0)
    assert encode('\ntest') == (b'', 0)
    assert encode('\n test') == (b'', 0)
    assert encode('\n test\n') == (b'', 0)
    assert encode('  \n  test\n') == (b'', 0)
    assert encode('  \n  test\n  ') == (b'', 0)
    assert encode('  \n  te st\n  ') == (b'', 0)
    assert encode('  \n  te st\n  ') == (b'', 0)

# Generated at 2022-06-11 22:09:11.662902
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    #     Assert that this module has not been registered.
    try:
        codecs.getdecoder(NAME)
        assert (
            False and
            "This module should not yet be registered."
        )  # pragma: no cover
    #     Handle the 'LookupError' exception generated by the
    #     'codec.getdecoder' call.
    except LookupError:
        pass

    # Register this codec.
    register()

    # Assert that the 'b64' codec is registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:15.245805
# Unit test for function register
def test_register():
    """Test the :func:`register` function"""
    import sys
    # Register the codec.
    sys.modules[__name__].register()

    import codecs
    codecs.lookup(NAME)


# Generated at 2022-06-11 22:09:21.775241
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    encoder = codecs.getencoder(NAME)
    text = '1234'
    text_bytes = text.encode('utf-8')
    out = encoder(text_bytes)[0]
    assert out == 'MTIzNA=='
    assert encoder(text_bytes)[0] == out

    text_bytes2 = b'1234'
    assert encoder(text_bytes2)[0] == out

    assert decoder('MTIzNA==')[0] == text
    assert decoder(out)[0] == text



# Generated at 2022-06-11 22:09:24.672296
# Unit test for function register
def test_register():
    """Unit test for function :mod:`~b64.register`."""
    # pylint: disable=C0103
    _ = codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:28.087962
# Unit test for function register
def test_register():  # pragma: no cover
    from pydoctest import test_module
    test_module(__name__)

# Test function register
if __name__ == '__main__':  # pragma: no cover
    test_register()

# Generated at 2022-06-11 22:09:30.138024
# Unit test for function register
def test_register():
    """Unit test for the method that registers the codec with Python."""
    register()



# Generated at 2022-06-11 22:09:38.512107
# Unit test for function encode
def test_encode():
    text1 = 'SGVsbG8sIHRoaXMgaXMgYSB0ZXN0Cg=='

# Generated at 2022-06-11 22:09:42.720962
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # Use the codecs module to test if the codec is registered.
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:09:45.257342
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getencoder(NAME)  # type: ignore
    codecs.getdecoder(NAME)  # type: ignore
    return


register()

# Generated at 2022-06-11 22:10:07.468107
# Unit test for function register
def test_register():
    def _decoder(
            data: _ByteString,
            errors: _STR = 'strict'
    ) -> Tuple[bytes, int]:
        return bytes(data), len(data)

    def _encoder(
            text: _STR,
            errors: _STR = 'strict'
    ) -> Tuple[str, int]:
        return str(text), len(text)

    codecs.register(lambda x: codecs.CodecInfo(
        name='munger',
        encode=_encoder,
        decode=_decoder,
    ))
    codecs.register(lambda x: codecs.CodecInfo(
        name='munger',
        encode=_encoder,
        decode=_decoder,
    ))  # Should not throw exception.

    # Get codec info for 'b64' and

# Generated at 2022-06-11 22:10:10.466178
# Unit test for function register
def test_register():  # pylint: disable=R0201
    """Test for the register function."""
    import sys
    register()
    assert NAME in sys.modules['encodings'].__dict__

# Generated at 2022-06-11 22:10:15.514070
# Unit test for function register
def test_register():
    """Unit test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        msg = 'codec b64 has not been registered with Python'
        raise AssertionError(msg) from None



# Generated at 2022-06-11 22:10:18.902738
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`encode`"""
    assert encode('dGVzdGluZw==') == (bytes('testing', 'utf-8'), 8)



# Generated at 2022-06-11 22:10:25.448724
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('YQ==') == (b'a', 0)
    assert encode('YWI=') == (b'ab', 0)
    assert encode('YWJj') == (b'abc', 0)
    assert encode('YWJjZA==') == (b'abcd', 0)
    assert encode('YWJjZGU=') == (b'abcde', 0)
    assert encode('YWJjZGVm') == (b'abcdef', 0)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 0)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 0)
   

# Generated at 2022-06-11 22:10:32.868306
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered with Python."""
    register()
    actual = codecs.getencoder(NAME)  # type: ignore
    assert actual[0] is encode, (
        f'b64.encode() was not properly registered with the codecs module: '
        f'{actual}'
    )
    actual = codecs.getdecoder(NAME)  # type: ignore
    assert actual[0] is decode, (
        f'b64.decode() was not properly registered with the codecs module: '
        f'{actual}'
    )



# Generated at 2022-06-11 22:10:39.851398
# Unit test for function register
def test_register():
    import sys
    for importer, modname, ispkg in pkgutil.iter_modules():
        if modname == 'b64':
            break
    else:
        raise RuntimeError('Module b64 not found')

    del sys.modules[modname]
    register()
    assert modname in sys.modules
    del sys.modules[modname]



# Generated at 2022-06-11 22:10:42.953976
# Unit test for function register
def test_register():
    """Unit test for module function ``register``."""
    from sys import modules

    try:
        register()
    except:
        del modules[__name__]
        raise



# Generated at 2022-06-11 22:10:48.207993
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    base64_str = 'IiBCaXQgQmxvY2sgU3lzdGVtIEVuZ2luZWVyaW5nIg=='
    result = encode(base64_str)
    assert result[0] == b' " Bit Block System Engineering"'
    assert result[1] == len(base64_str)



# Generated at 2022-06-11 22:10:55.652773
# Unit test for function encode
def test_encode():
    """Encode random set of bytes into base64 characters."""
    import random

    # Generate random 'bytes' of size from 15 to 50
    data_bytes = bytes(''.join([chr(random.randrange(ord(' '), ord('~')))
                                for i in range(random.randrange(15, 50))]))
    # Encode the random bytes into base64 characters
    data_b64, length = encode(data_bytes)
    # Decode the base64 characters back into bytes
    data_bytes_1, length_1 = base64.decodebytes(data_b64)

    # Check whether the decoded bytes match the original random bytes.
    assert data_bytes == data_bytes_1



# Generated at 2022-06-11 22:11:30.390102
# Unit test for function register
def test_register():
    # Remove the 'b64' codec, if it is already registered.
    codecs.lookup_error(NAME)

    # Register the 'b64' codec.
    register()

    # Verify that the 'b64' codec was registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:11:35.484365
# Unit test for function register
def test_register():
    """Test the function register()."""
    # Register the codec.
    register()

    # Verify that the codec is registered.
    try:
        # noinspection PyUnresolvedReferences
        decoder_info: codecs.CodecInfo = codecs.lookup(NAME)
    except LookupError:
        raise AssertionError('Codec b64 not registered.')


test_register()

# Generated at 2022-06-11 22:11:36.920098
# Unit test for function register
def test_register():
    """Unit test to confirm that ``NAME`` object is registered with Python."""
    register()
    name = NAME
    obj = codecs.getdecoder(name)
    assert name == obj.name

# Generated at 2022-06-11 22:11:42.521540
# Unit test for function encode
def test_encode():
    expected = b'Hello world!'
    text = codecs.encode(
        'SGVsbG8gd29ybGQh', 'b64')
    assert expected == text, \
        'Expected "{}", but got "{}"'.format(expected, text)



# Generated at 2022-06-11 22:11:46.450189
# Unit test for function register
def test_register():
    """Unit test for function register.

    It ensures that the ``register`` function can be called without error
    and that the codec information can be retrieved from the codecs
    module.
    """
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:11:51.181989
# Unit test for function register
def test_register():
    """Test :func:`register` on codecs registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:12:00.810153
# Unit test for function register
def test_register():
    """Test the 'register' function."""
    # Verify that b64 is not already registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    register()

    # Verify that b64 is now registered.
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    import sys

    def main():
        """Program entry point."""
        # pylint: disable=R1702
        if len(sys.argv) < 3:
            print(
                '\n'.join(
                    [
                        'usage:',
                        '    python -m b64 encode plain_text',
                        '    python -m b64 decode base64_text',
                    ]
                )
            )
            return
        cmd = sys.argv[1]

# Generated at 2022-06-11 22:12:02.420729
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)


# Unit Test for function decode

# Generated at 2022-06-11 22:12:09.676422
# Unit test for function register
def test_register():
    """Test to make sure the ``b64`` codec is registered with Python.
    """
    from unittest import TestCase
    from unittest.mock import patch
    from typing import Any


    class CodecTestCase(TestCase):
        @patch('lib2to3.fixes.fix_codecs.codecs.register',
               wraps=codecs.register)
        def test_register(self, mock_codecs_register):
            """Test function register()
            """
            from lib2to3.fixes.fix_codecs import register as codec_register
            codec_register()

            self.assertEqual(mock_codecs_register.call_count, 1)

            args, kwargs = mock_codecs_register.call_args

# Generated at 2022-06-11 22:12:18.333354
# Unit test for function encode
def test_encode():
    from textwrap import dedent as dd
    # Test 1

# Generated at 2022-06-11 22:12:52.559545
# Unit test for function register
def test_register():
    """Test the function 'register()'."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:57.024262
# Unit test for function register
def test_register():
    """
    To test the function :func:`register` the function is called then it
    is verified that the codec does exist by retrieving it from Python.
    """
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:59.480163
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:13:02.997674
# Unit test for function register
def test_register():
    """Registers the ``b64`` codec with ``Python``.  Should not raise any
    exceptions.
    """
    register()



# Generated at 2022-06-11 22:13:04.998544
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codec = codecs.getdecoder(NAME)
    assert codec is not None



# Generated at 2022-06-11 22:13:05.604796
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:13:06.733025
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)

# Generated at 2022-06-11 22:13:10.624454
# Unit test for function encode
def test_encode():
    assert(encode('QUJDRA==') == (b'ABCD', 8))



# Generated at 2022-06-11 22:13:12.113941
# Unit test for function register
def test_register():
    """Test that the codec is registered with Python."""
    from . import codecs_test
    codecs_test.test_register(NAME, reg_function=register)


# Generated at 2022-06-11 22:13:15.793295
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__['__all__']
    register()
    assert NAME in codecs.__dict__['__all__']
    assert codecs.codec(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-11 22:13:52.869727
# Unit test for function register
def test_register():
    register()

# Local Variables:
# python-indent-offset: 4
# fill-column: 100
# indent-tabs-mode: nil
# End:
# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-11 22:13:58.771867
# Unit test for function register
def test_register():
    """Test function :func:`register`."""
    global NAME
    try:
        NAME = 'b64'
        register()
        assert True
    except ImportError:
        assert True
    except AssertionError:
        assert False
    # Should not raise an error if the codec has already been registered.
    try:
        register()
        assert True
    except ImportError:
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-11 22:14:06.222932
# Unit test for function encode
def test_encode():
    # pylint: disable=E0611
    from ..python.b64 import b64_encode

    # test 1
    expected_1 = b'\x00\x01\x02\x03\x04\x05\x06\x07'
    text_input_1 = 'AAECAwQFBgcICQ=='

    assert encode(text_input_1)[0] == expected_1

    # test 2
    expected_2 = b'\x08\t\n\x0b\x0c\r\x0e\x0f'
    text_input_2 = 'CAgJCAkKCgsLDA=='

    assert encode(text_input_2)[0] == expected_2

    # test 3

# Generated at 2022-06-11 22:14:08.385886
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.register(
        lambda name: None if name == NAME else None)
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:14:09.861306
# Unit test for function register
def test_register():

    import typing

    assert typing.TYPE_CHECKING



# Generated at 2022-06-11 22:14:11.711906
# Unit test for function register
def test_register():
    """
    The function ``register`` is tested.
    """
    register()

# Generated at 2022-06-11 22:14:16.179015
# Unit test for function register
def test_register():
    """Unit tests for the :func:`register` function."""
    register()
    assert codecs.getdecoder(NAME) is not None, (
        'The b64 codec was not registered.'
    )
    assert codecs.getencoder(NAME) is not None, (
        'The b64 codec was not registered.'
    )

register()
# End of file.

# Generated at 2022-06-11 22:14:19.488838
# Unit test for function register
def test_register():
    """Test the function register()"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'b64 codec is not registered: {e}'
        ) from e



# Generated at 2022-06-11 22:14:22.202489
# Unit test for function register
def test_register():
    """Test the function register."""
    if codecs.lookup(NAME) is None:
        register()
        assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:14:31.683282
# Unit test for function register
def test_register():
    test_codec = codecs.getdecoder(NAME)
    test_decode = test_codec('strict').decode
    # pylint: disable=W0108
    test_encode = test_codec('strict').encode
    # pylint: disable=W0108

    test_text = '''
        VGhpcyB0ZXh0IGlzIGVuY29kZWQgaW4gYmFzZTY0


        dGhpcyBpcyBzb21ldGhpbmcgb3RoZXI=
    '''

    test_data = b'this is some byte data'

    assert test_encode(test_data)[0] == 'dGhpcyBpcyBzb21lIGJ5dGUgZGF0YQ=='