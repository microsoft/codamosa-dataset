

# Generated at 2022-06-11 22:04:37.106232
# Unit test for function register
def test_register():
    """Test registering the b64 codec into Python's codecs module."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:04:47.711044
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    codecs.getdecoder(NAME)

if __name__ == '__main__':
    # Unit test for function decode
    def test_decode():
        """Test the ``decode`` function."""
        # Test 1 - basic function
        res = decode(b'aGVsbG8=\n')
        assert res == ('hello', 7)

        # Test 2 - Bad string

# Generated at 2022-06-11 22:04:50.360664
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""
    # Test the function in the simplest way possible.
    assert encode('a')[0] == b'YQ=='

# Generated at 2022-06-11 22:04:57.536836
# Unit test for function register
def test_register():
    """Test the function :func:`register`"""
    # Remove the 'b64' codec if it is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.lookup(NAME)
        codecs.lookup_error(NAME)

    # Register the 'b64' codec.
    register()

    # Check to make sure the registration was successful.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise Exception(
            f'Unable to register the {NAME} codec: {e}'
        ) from e



# Generated at 2022-06-11 22:05:00.499599
# Unit test for function register
def test_register():
    """Unit test that verifies that the register functions registers the
       codec properly.
    """
    codecs.register(_get_codec_info)

    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:02.762044
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:07.130933
# Unit test for function register
def test_register():
    """Test register"""
    from pytest import fail
    try:
        register()
    except Exception:
        assert False
        return
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        fail("Failed to register the codec {NAME!r}")



# Generated at 2022-06-11 22:05:16.886288
# Unit test for function register
def test_register():   # type: ignore
    # pylint: disable=unused-argument
    def mock_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    with mock.patch('base64encoded.register.codecs.register',
                    side_effect=lambda x: codecs.register(mock_codec_info)):
        with mock.patch('base64encoded.register.codecs.getdecoder',
                        side_effect=LookupError):
            try:
                register()
            except LookupError:
                assert False

        with mock.patch('base64encoded.register.codecs.getdecoder',
                        side_effect=lambda x: False):
            try:
                register()
                assert False
            except Exception:
                assert True

# Generated at 2022-06-11 22:05:23.566581
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError(
            f'Failed to register the codec: {NAME}'
        )


__all__ = [
    'decode',
    'encode',
    'register',
    'test_register',
]

# Generated at 2022-06-11 22:05:27.121974
# Unit test for function register
def test_register():
    # Register b64
    register()
    # Verify registration
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:05:33.127080
# Unit test for function register
def test_register():
    """Unit test for function register."""
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:05:35.223815
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
# End of unit test for function register



# Generated at 2022-06-11 22:05:40.421481
# Unit test for function register
def test_register():
    """Verify the register function registers the b64 codec with Python."""
    from .. import codecs_test
    register()
    codecs_test.test_register(__name__.split('.')[-1])

if __name__ == "__main__":
    test_register()

# Generated at 2022-06-11 22:05:47.221282
# Unit test for function register
def test_register():
    """Test :func:`~py36compat.codecs_b64.register`"""
    register()
    try:
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError(
            f'codecs did not register properly: cannot find '
            f'{NAME!r} codec.'
        )

# Generated at 2022-06-11 22:05:52.738060
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    encoded = codecs.encode("Hello World in b64.", "b64")
    assert encoded == b'SGVsbG8gV29ybGQgaW4gYjY0Lg==\n'
    decoded = codecs.decode(encoded, "b64")
    assert decoded == "Hello World in b64.\n"

# Generated at 2022-06-11 22:05:54.471896
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:57.753033
# Unit test for function register
def test_register():
    """Test the :meth:`codecs.register` function."""
    import doctest

    result = doctest.testmod()
    assert result.failed == 0
    assert result.attempted > 0

# Generated at 2022-06-11 22:05:59.850068
# Unit test for function register
def test_register():
    """Test whether the 'b64' codec is registered."""
    register()
    codecs.getdecoder(NAME)
    assert True



# Generated at 2022-06-11 22:06:09.993983
# Unit test for function encode

# Generated at 2022-06-11 22:06:13.358791
# Unit test for function register
def test_register():
    """Test for function register"""
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f'Test failed registering codec {NAME}')
    else:
        assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:20.873656
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    encode('MQ==')

# Generated at 2022-06-11 22:06:32.593581
# Unit test for function register
def test_register():
    # Assert that our codec is not yet registered with the codecs module.
    assert NAME not in codecs.__dict__.keys()

    # Assert that our codec is not yet registered with the codecs module.
    assert NAME not in codecs.__dict__.keys()

    # Register our codec with the codecs module.
    register()

    # Assert that our codec is now registered with the codecs module.
    assert NAME in codecs.__dict__.keys()

    # Get our registered codec.
    codec = codecs.getdecoder(NAME)
    assert isinstance(codec, codecs.CodecInfo)  # type: ignore
    assert codec.decode is decode
    assert codec.encode is encode


register()

# Generated at 2022-06-11 22:06:39.067165
# Unit test for function register
def test_register():
    """Test the function `register`."""
    # Check that the codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception

    # Register the codec.
    register()

    # Check that the codec has been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception



# Generated at 2022-06-11 22:06:48.010400
# Unit test for function encode
def test_encode():
    assert encode(
        text='YWJj',
    ) == (
        b'abc',
        4
    )
    assert encode(
        text='YWJj\n',
    ) == (
        b'abc',
        4
    )
    assert encode(
        text='YWJj\n',
    ) == (
        b'abc',
        4
    )
    assert encode(
        text='YWJj\n',
    ) == (
        b'abc',
        4
    )
    assert encode(
        text='YWJj\n',
    ) == (
        b'abc',
        4
    )
    assert encode(
        text='YWJj\n',
    ) == (
        b'abc',
        4
    )
    assert encode

# Generated at 2022-06-11 22:06:54.353368
# Unit test for function register
def test_register():
    """Test the function register.

    Expecting:
    This function is expected to raise no exceptions.
    """
    # Register the 'b64' codec with Python.
    register()

    # Test if the 'b64' codec is registered with Python.
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

test_register()



# Generated at 2022-06-11 22:06:59.057833
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered.
    """
    register()
    assert codecs.codecs_registered[-1] == NAME


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:08.106786
# Unit test for function encode

# Generated at 2022-06-11 22:07:10.743939
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-11 22:07:13.746880
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # I don't think this function can be unit tested.
    ...

# Generated at 2022-06-11 22:07:18.032894
# Unit test for function register
def test_register():
    """Ensure that the ``b64`` codec is registered with Python."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:37.306132
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    codecs.getencoder(NAME)
    codecs.encode('\u4520', NAME)
    # Make sure it throws an error
    try:
        codecs.encode(b'\u4520', NAME)
    except UnicodeEncodeError:
        pass
    try:
        codecs.encode('\u4520', 'b64')
    except LookupError:
        pass
    codecs.encode('\u4520'.encode('utf-8'), NAME)


# Generated at 2022-06-11 22:07:48.429282
# Unit test for function encode
def test_encode():

    from base64 import b64decode as decode


# Generated at 2022-06-11 22:07:55.510207
# Unit test for function register
def test_register():
    """Test the function 'register' in the module."""
    # Test that the 'b64' codec is not registered to start.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        pass
    else:
        raise Exception(f'The "{NAME}" codec should not be registered.')

    # Use 'register()' to register the 'b64' codec.
    register()

    # Test that the 'b64' codec is now registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        print('>>> e')
        raise Exception(f'The "{NAME}" codec should be registered.')
    else:
        pass

# Generated at 2022-06-11 22:07:57.542647
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert isinstance(codecs.getencoder(NAME), codecs.CodecInfo)
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)



# Generated at 2022-06-11 22:08:00.126307
# Unit test for function register
def test_register():
    """Test the function register()"""
    import codecs

    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:08:09.832472
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    import random
    # Register the 'b64' codec with Python.
    register()

    # Create a test string encoding
    rand = random.Random()
    text = str(rand.getrandbits(128))
    encode_text = encode(text)

    # Get the 'b64' codec
    b64_codec = codecs.getencoder(NAME)  # type: ignore

    # Encode the text with the 'b64' codec
    codec_text, _ = b64_codec(text)
    # Decode the text with the 'b64' codec
    decode_text, _ = codecs.getdecoder(NAME)(codec_text)

    assert encode_text == codec_text
    assert decode_text == text


# Execute the test function if this module is

# Generated at 2022-06-11 22:08:19.268778
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test for empty input.
    out, _ = encode('')
    assert out == b''

    # Test for a single character input.
    out, _ = encode('/')
    assert out == b'/w=='

    # Test for a single character input.
    out, _ = encode('A')
    assert out == b'QQ=='

    # Test decoding a base64 character string with a single line and
    # no indentation.

# Generated at 2022-06-11 22:08:30.299182
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('bGVhc3VyZS4=\n') == b"leasure."
    assert encode('bGVhc3VyZSDigJM=\n') == b"leasure."
    assert encode('') == b''
    assert encode('==') == b'\x00\x00'
    assert encode('=') == b'\x00'
    assert encode('bGVhc3VyZS4====') == b'leasure.'
    assert encode('bGVhc3VyZSDigJM====') == b'leasure.'

    assert encode('bGVhc3VyZS4=\n') == b"leasure."
    assert encode('bGVhc3VyZSDigJM=\n') == b"leasure."


# Generated at 2022-06-11 22:08:32.913226
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec has been registered."""
    assert codecs.getdecoder(NAME) is not None, "codec b64 not registered."



# Generated at 2022-06-11 22:08:36.168112
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode(
        "cG9kY2FzdA",
        errors="strict"
    ) == (b'podcast', 8)



# Generated at 2022-06-11 22:08:49.362717
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:08:54.469298
# Unit test for function register
def test_register():
    """Test this module as a script."""
    # Test to make sure the registered codec can be found.
    codecs.lookup(NAME)
    # Test decoding
    assert 'I am codex!' == codecs.decode(
        'SSBhbSBjb2RleCEn',
        NAME
    )
    # Test encoding
    assert (
        'SSBhbSBjb2RleCEn' == codecs.encode(
            'I am codex!',
            NAME
        ).decode('utf-8')
    )
    assert 'I am codex!\n' == codecs.encode(
        'I am codex!\n',
        NAME
    ).decode('utf-8')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:56.800185
# Unit test for function register
def test_register():
    import testdata.codec.common as testdata
    testdata.test_register(_get_codec_info, 'b64')



# Generated at 2022-06-11 22:09:04.282198
# Unit test for function register
def test_register():
    try:
        # Confirm that the 'b64' codec is not found.
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{NAME} codec is already registered.')

    # Register the codec.
    register()

    # Confirm that the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'{NAME} codec was not registered.')
    else:
        pass


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:08.615144
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    # pylint: disable=protected-access
    assert NAME in codecs.__all__
    # pylint: enable=protected-access
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:09:13.129489
# Unit test for function register
def test_register():
    """Test function register"""
    assert not hasattr(codecs, 'b64_decode')
    register()
    assert hasattr(codecs, 'b64_decode')
    assert hasattr(codecs, 'b64_encode')



# Generated at 2022-06-11 22:09:20.342167
# Unit test for function encode
def test_encode():
    assert (b"", 0) == encode('')
    assert (b'a', 1) == encode('YQ==')
    assert (b'ab', 1) == encode('YWI=')
    assert (b'abc', 1) == encode('YWJj')
    assert (b'abcd', 1) == encode('YWJjZA==')
    assert (b'abcde', 1) == encode('YWJjZGU=')
    assert (b'abcdef', 1) == encode('YWJjZGVm')
    assert (b'abcdefg', 1) == encode('YWJjZGVmZw==')
    assert (b'abcdefgh', 1) == encode('YWJjZGVmZ2g=')

# Generated at 2022-06-11 22:09:22.712657
# Unit test for function register
def test_register():
    """Test function ``register``."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:09:25.750416
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Expected {!r} to be registered.'.format(NAME)

# Generated at 2022-06-11 22:09:35.947549
# Unit test for function register
def test_register():
    import sys
    import b64

    # Save the currently loaded encodings
    encodings = sys.modules['encodings']

    # sys.modules['encodings'] = None
    # Reload b64, which will try to re-register the b64 codec.
    reload(b64)

    # Restore sys.modules['encodings'] to it's original value.
    sys.modules['encodings'] = encodings

    # Create a codec object
    codec = b64.Codec()

    # Make sure the encoder is there (doesn't raise any exceptions)
    codec.encode('Hi there!')

    # Make sure the decoder is there (doesn't raise any exceptions)
    codec.decode('SGkgdGhlcmUh')



# Generated at 2022-06-11 22:10:08.913878
# Unit test for function register
def test_register():
    """Verify that the python ``b64`` codec is not registered."""
    # Verify that the b64 codec is not registered
    # Assertions are written as if it was not registered
    # If the assertion is raised, then it is registered and
    # needs to be unregistered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        # Remove the registration
        codecs.lookup(NAME).unregister()
    assert codecs.lookup(NAME) is None
    assert codecs.getdecoder(NAME) is None
    register()
    assert isinstance(codecs.getdecoder(NAME), type(codecs.CodecInfo))


# Performs unit testing when called from the command line

# Generated at 2022-06-11 22:10:14.680344
# Unit test for function register
def test_register():
    original_codec_list = list(codecs.__dict__.keys())
    codecs.register(_get_codec_info)
    updated_codec_list = list(codecs.__dict__.keys())
    _assert_equal(updated_codec_list, original_codec_list)



# Generated at 2022-06-11 22:10:18.441847
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) == _get_codec_info(NAME)
    codecs.unregister(NAME)


# Generated at 2022-06-11 22:10:21.058294
# Unit test for function register
def test_register():
    """Unit test: Test that the register function registers the b64 codec."""
    # Test that the codec is not registered
    assert NAME not in codecs.decode.cache

    # Register the codec
    register()

    # Test that the codec is registered
    assert NAME in codecs.decode.cache

# Generated at 2022-06-11 22:10:25.277689
# Unit test for function encode
def test_encode():
    c1 = "hello"
    c2 = "SGVsbG8gV29ybGQ="
    assert(encode(c1) == (b"hello", 5))
    assert(encode(c2) == (b"Hello World", 11))


# Generated at 2022-06-11 22:10:28.048466
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:29.444695
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error(NAME)



# Generated at 2022-06-11 22:10:33.331212
# Unit test for function register
def test_register():
    """Test the output of :func:`register` is correct."""
    register()
    assert NAME in codecs.__dict__
    info_obj = codecs.getdecoder(NAME)
    assert isinstance(info_obj, codecs.CodecInfo)
    assert info_obj.name == NAME
    assert info_obj.encode == encode
    assert info_obj.decode == decode



# Generated at 2022-06-11 22:10:45.728007
# Unit test for function register
def test_register():
    """
    Remove the b64 codec from the codec registry, and then test that it's
    not defined by attempting to get the codec info for it.  Finally,
    attempt to register the codec, and test that the codec is now defined,
    and contains the expected values.
    """
    # Remove the b64 codec from the codec registry.
    codec_registry.pop(NAME, None)

    # Test that the codec is not defined.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'Expecting LookupError when attempting to get codec info for {NAME!r}.'
        )

    # Register the codec, and verify that it is now defined.
    register()
    codec_info = codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:10:53.533713
# Unit test for function register
def test_register():
    """Test registers the ``b64`` Python codec."""
    from io import StringIO
    from sys import stderr

    # Mess with out codecs
    codecs.lookup_error('strict')
    codecs.getdecoder('b64')

    # Add an object to the codecs error registry
    codecs_error_registry = codecs.error_registry.setdefault('strict',{})
    codecs_error_registry.update({'b64': UnicodeEncodeError})
    codecs.error_registry = codecs.error_registry.setdefault('strict', {})

    # Test the register function
    register()



# Generated at 2022-06-11 22:11:20.910616
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:11:27.022690
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`encode`."""
    # Programmer's notes:
    #
    # The given test strings are based on the example in the Python
    # documentation for the 'base64' module.  The reason for this is
    # that I want to ensure that the given strings work in the Python
    # 'base64' module, and then ensure that this codec will work with
    # the Python 'base64' module.
    #
    # This unit test shows how this codec is meant to be used with the
    # Python 'ast' module.
    #
    # This codec is meant to be used with the Python 'ast' module
    # because the 'ast.literal_eval' function would throw a
    # 'SyntaxError' exception when passed in an expression that
    # contains a 'bytes' object.  The 'bytes

# Generated at 2022-06-11 22:11:30.332934
# Unit test for function register
def test_register():
    register()
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Could not find the 'b64' codec"

# Generated at 2022-06-11 22:11:32.910178
# Unit test for function register
def test_register():
    """Test the function register()."""
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:11:33.881180
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    register()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:41.779677
# Unit test for function encode
def test_encode():
    str_in = \
        """
        SGVsbG8sIHdvcmxkIQ==
        SSBhbSBlbXB0eS4=
        """
    exp_str = \
        """
        Hello, world!
        I am empty.
        """

    str_out, len_in = encode(str_in)
    str_out2, len_out = decode(str_out)

    print(str_in)
    print(exp_str)
    print(str_out)
    print(str_out2)
    if not isinstance(str_out, bytes):
        raise Exception(f'Type {type(str_out)} is not bytes')

# Generated at 2022-06-11 22:11:50.878351
# Unit test for function encode

# Generated at 2022-06-11 22:11:52.631765
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:00.534901
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('R0lGODlhDQAGAMQfAL3GMI3GMs3G9T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3G+T3H+T3IBPc=') == (b'\x01\x02\x03\x04\x05\x06\x07\x08', 0)


# Generated at 2022-06-11 22:12:02.983121
# Unit test for function register
def test_register():
    """If the ``b64`` codec is not registered, then register it."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


# Generated at 2022-06-11 22:12:37.749430
# Unit test for function register
def test_register():
    """Test function ``register`` with no prior 'b64' codec registered."""
    # Get the list of registered codecs before we register the 'b64'
    # codec.
    pre_codec_list = codecs.registered_errors.keys()
    assert len(pre_codec_list) > 0

    # Register the 'b64' codec.
    register()

    # Get the list of registered codecs after we register the 'b64' codec.
    post_codec_list = codecs.registered_errors.keys()
    assert len(post_codec_list) > 0
    assert len(post_codec_list) > len(pre_codec_list)
    assert 'b64' in post_codec_list
    assert 'b64' not in pre_codec_list


# Unit test encode function


# Generated at 2022-06-11 22:12:41.789830
# Unit test for function register
def test_register():
    # pylint: disable=no-member
    # pylint: disable=unused-variable
    # Test if the given codec is found in Python.
    codecs.getdecoder(NAME)


# Test if the register function runs, creating the codec
test_register()

# Generated at 2022-06-11 22:12:50.538139
# Unit test for function register
def test_register():
    # pylint: disable=protected-access
    codecs._cache.clear()
    codecs._search_function_cache.clear()  # type: ignore
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    try:
        codecs.getencoder(NAME + '_nonsense')
        assert False, 'LookupError exception should have been thrown'
    except LookupError:
        pass
    try:
        codecs.getdecoder(NAME + '_nonsense')
        assert False, 'LookupError exception should have been thrown'
    except LookupError:
        pass



# Generated at 2022-06-11 22:12:55.065918
# Unit test for function register
def test_register():
    # pylint: disable=global-statement
    global NAME

    orig_name = NAME
    for name in (
            'b64',
            'base64',
            'base64_',
            'base_64',
            '_base64',
            'b64_',
            '_b64',
    ):
        with pytest.raises(LookupError):
            codecs.getdecoder(name)
        NAME = name
        register()
        obj = codecs.getdecoder(name)
        assert obj.name == name
        assert obj.decode == decode
        assert obj.encode == encode
        with pytest.raises(AttributeError):
            obj.encode_b64 = None

    NAME = orig_name



# Generated at 2022-06-11 22:13:06.623499
# Unit test for function encode
def test_encode():
    """Test the 'encode' function."""
    assert encode('') == (b'', 0)

    assert encode('c3VyZS4=') == (b'sure.', 8)
    assert encode('dGhpcyBpcyBhIHRlc3Q=') == (b'this is a test', 18)
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)

    assert encode(
        '''
            c3VyZS4=
            dGhpcyBpcyBhIHRlc3Q=
            aGVsbG8gd29ybGQ=
        '''
    ) == (b'sure.this is a testhello world', 44)


# Generated at 2022-06-11 22:13:12.166605
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('codec b64 is already registered')

    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:13:14.152832
# Unit test for function register
def test_register():
    """Test registering the 'b64' codec."""
    register()
    codecs.getdecoder(NAME)    # type: ignore



# Generated at 2022-06-11 22:13:21.384999
# Unit test for function encode
def test_encode():
    """Unit test for function encode()."""
    assert encode('YXNkYXNkYXNkYXNkYXNkYXNkYXNkYXNkYXNkYXNkYXNkYQ==') == (
        b'asdasdasdasdasdasdasdasdasdasda',
        21
    )



# Generated at 2022-06-11 22:13:24.100967
# Unit test for function register
def test_register():
    """'register' function test"""
    assert decode is None
    assert codecs is None
    assert NAME == 'b64'
    assert _get_codec_info is None



# Generated at 2022-06-11 22:13:30.860157
# Unit test for function register
def test_register():
    """Unit test the ``register`` function."""
    # Setup of unit test
    import sys

    # Verify 'b64' is not registered before the test
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            'The codec "b64" should not be registered before running '
            'this test.'
        )

    # Run the test
    register()

    # Verify 'b64' was registered properly
    # noinspection PyBroadException
    try:
        decoder = codecs.getdecoder(NAME)
    except:
        error_message = sys.exc_info()[1]

# Generated at 2022-06-11 22:14:37.184146
# Unit test for function register
def test_register():  # type: ignore[misc]
    """Test the :function:`register` function."""
    # Get the list of codecs registered before registering the 'b64' codec.
    before = codecs.__dict__['_cache'].keys()

    # Register the 'b64' codec.
    register()

    # Get the list of codecs registered after registering the 'b64' codec.
    after = codecs.__dict__['_cache'].keys()

    # Determine if the 'b64' codec was actually registered.
    delta = after - before
    assert len(delta) == 1
    assert NAME in delta

