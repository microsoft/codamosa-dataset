

# Generated at 2022-06-11 22:04:34.923836
# Unit test for function register
def test_register():
    """Test for function register"""
    register()

# Generated at 2022-06-11 22:04:46.053586
# Unit test for function encode
def test_encode():

    def _test_unicode_encode_error(
            text: _STR,
            msg: str
    ) -> None:
        try:
            encode(text)
        except UnicodeEncodeError as e:
            assert e.reason == msg
        else:
            raise AssertionError("Expected exception did not occur")

    assert encode('Zg==')[0] == b'f'
    assert encode('Zm8=')[0] == b'fo'
    assert encode('Zm9v')[0] == b'foo'
    assert encode('Zm9vYg==')[0] == b'foob'
    assert encode('Zm9vYmE=')[0] == b'fooba'
    assert encode('Zm9vYmFy')[0] == b'foobar'

# Generated at 2022-06-11 22:04:51.298441
# Unit test for function register
def test_register():
    """Unit test for function register."""
    unregister()
    register()
    assert codecs.lookup(NAME).name == NAME
    assert codecs.lookup(NAME).encode(b'foo') == ('Zm9v', 3)
    assert codecs.lookup(NAME).decode('Zm9v') == ('foo', 3)



# Generated at 2022-06-11 22:04:52.915534
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)


# Generated at 2022-06-11 22:04:58.858231
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    """Ensure register() successfully registers the b64 codec."""
    # Ensure the 'b64' codec is not already registered.
    try:
        # noinspection PyUnresolvedReferences
        codecs.getdecoder('b64')
    except LookupError:
        pass
    else:
        # noinspection PyUnresolvedReferences
        codecs.getencoder('b64')
        raise AssertionError('b64 codec is already registered.')

    # Call the 'register' function.  This should register the 'b64' codec.
    # noinspection PyUnresolvedReferences
    register()

    # Ensure the 'b64' codec is registered.

# Generated at 2022-06-11 22:05:02.217547
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:05:11.171748
# Unit test for function encode
def test_encode():
    # Test the encode function's method arguments are correct.
    input_str = 'YmFzZTY0IHN0cmluZw=='
    bytes_expected = b'base64 string'
    bytes_actual, bytes_actual_len = encode(input_str)
    assert bytes_actual == bytes_expected
    assert bytes_actual_len == len(input_str)

    # Test that if a string contains more than just base64 characters,
    # a 'UnicodeEncodeError' will be thrown.
    input_str = 'YmFzZTY0IHN0cmluZw==\n1'
    try:
        encode(input_str)
    except UnicodeEncodeError as e:
        assert '1 is not a proper bas64 character string' in str(e)
    else:
        assert False

# Generated at 2022-06-11 22:05:14.004879
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    if NAME in sys.modules:
        # Python 3.7+
        del sys.modules[NAME]
    register()
    # No exception raised
    return True


# Generated at 2022-06-11 22:05:17.047942
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode("") == (b"", 0)
    assert encode("A") == (b"QQ==", 1)
    assert encode("AA") == (b"QQA=", 2)



# Generated at 2022-06-11 22:05:25.731820
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    from unittest import TestCase
    from sys import getdefaultencoding

    class RegisterTestCase(TestCase):
        """Unit test for function :func:`register`."""
        def test_register(self):
            """Ensure the codec for ``b64`` is registered."""
            self.assertEqual(
                getdefaultencoding(),
                'utf-8',
            )
            self.assertEqual(
                codecs.lookup(NAME).name,
                NAME,
            )

    RegisterTestCase().test_register()

# Generated at 2022-06-11 22:05:41.620189
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``."""

    IN_TEXT = "foo"
    OUT_BYTES, NUM_CONSUMED = encode(IN_TEXT)
    assert len(IN_TEXT) == NUM_CONSUMED
    assert OUT_BYTES == b"Zm9v"

    IN_TEXT = "f\no\no"
    OUT_BYTES, NUM_CONSUMED = encode(IN_TEXT)
    assert len(IN_TEXT) == NUM_CONSUMED
    assert OUT_BYTES == b"Zm9v"

    IN_TEXT = "f\n\to\no"
    OUT_BYTES, NUM_CONSUMED = encode(IN_TEXT)
    assert len(IN_TEXT) == NUM_CONSUMED
    assert OUT_BYT

# Generated at 2022-06-11 22:05:45.470665
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) == _get_codec_info(NAME)



# Generated at 2022-06-11 22:05:48.769958
# Unit test for function register
def test_register():
    """Unit test for function ``register``"""
    register()
    assert NAME in codecs.__dict__['_cache']    # type: ignore

# Generated at 2022-06-11 22:05:55.695737
# Unit test for function encode
def test_encode():
    """Test the encode function by decoding a known string."""

# Generated at 2022-06-11 22:06:07.487124
# Unit test for function encode
def test_encode():
    text = "abcd"
    text_expected = b"YWJjZA=="
    result = encode(text)
    # print(result)
    assert result == (text_expected, 4), "result should be equal to the expected value"

    text = "abcd efgh"
    text_expected = b"YWJjZCBlZmdo"
    result = encode(text)
    # print(result)
    assert result == (text_expected, 9), "result should be equal to the expected value"

    text = "ab cd efgh"
    text_expected = b"YWIgY2QgZWZnaA=="
    result = encode(text)
    # print(result)
    assert result == (text_expected, 11), "result should be equal to the expected value"

    error

# Generated at 2022-06-11 22:06:15.975978
# Unit test for function register
def test_register():
    """Test the ``b64`` codec for correct registration."""
    # Register the test_b64 module.
    test_register()

    # Retrieve the codec info for 'b64'
    codec_info = codecs.lookup(NAME)   # type: ignore

    # Confirm that codec_info is of type 'CodecInfo'
    assert type(codec_info) == codecs.CodecInfo  # type: ignore

    # Retrieve the codec_info's functions
    b64_encode = codec_info.encode  # type: ignore
    b64_decode = codec_info.decode  # type: ignore

    # Confirm that the codec_info functions are of the appropriate types
    assert type(b64_encode) == codecs.CodecInfo.encode   # type: ignore

# Generated at 2022-06-11 22:06:23.855332
# Unit test for function encode
def test_encode():
    assert 'YmFzZTY0' == encode('base64')[0]
    assert 'dGhpcyBpcyBzdHJpbmcgYmFzZWQgb24gdGhlIHRleHQgZG9jdW1lbnQ=' == encode(
        'this is string based on the text document'
    )[0]

# Generated at 2022-06-11 22:06:34.230621
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

# Generated at 2022-06-11 22:06:37.768888
# Unit test for function register
def test_register():
    """Test the register function works.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.
    """
    register()
    assert NAME in codecs.getdecoder('b64')



# Generated at 2022-06-11 22:06:45.341331
# Unit test for function register
def test_register():
    # Register the 'b64' codec
    register()

    # Get the 'b64' codec
    codec = codecs.getdecoder(NAME)  # type: ignore

    # Assert the codec's encode function is the b64 package's encode function.
    assert codec.encode('\n'.join(range(16))) == \
        encode('\n'.join(map(str, range(16))))

    # Assert the codec's decode function is the b64 package's decode function.
    assert codec.decode(bytes(range(16))) == decode(bytes(range(16)))

# Generated at 2022-06-11 22:06:50.234997
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    (codecs.getdecoder(NAME))
    (codecs.getencoder(NAME))


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:56.808485
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # pylint: disable=protected-access
    from . import _b64_codec
    assert _b64_codec._get_codec_info(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:07:04.721383
# Unit test for function register
def test_register():
    from io import StringIO
    from unittest import TestCase, TestLoader, TextTestRunner
    from unittest.mock import patch

    class TestRegister(TestCase):
        def test_register_call(self):
            with patch(
                    'codecs.register',
                    wraps=codecs.register
            ) as mock_register:
                register()
                self.assertTrue(mock_register.called)
    return TextTestRunner(
        buffer=True,
        verbosity=2
    ).run(
        TestLoader().loadTestsFromTestCase(TestRegister)
    )



# Generated at 2022-06-11 22:07:06.992803
# Unit test for function register
def test_register():
    def check():
        assert codecs.getdecoder(NAME) is not None
    _test_register(test_register.__name__, check)


# Generated at 2022-06-11 22:07:10.038610
# Unit test for function register
def test_register():
    """Test the function register."""
    # suppresses pylint warning that this is not a function
    # pylint: disable=W0108
    assert not codecs.lookup(NAME)
    register()
    assert codecs.lookup(NAME)
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:07:16.632195
# Unit test for function encode

# Generated at 2022-06-11 22:07:25.014353
# Unit test for function encode
def test_encode():
    """Test that the function :obj:`encode` works as intended."""
    try:
        encode(123, 'strict')
        assert False, 'expected exception not thrown'
    except TypeError as e:
        assert 'str' in str(e)

    try:
        encode(b'', 'strict')
        assert False, 'expected exception not thrown'
    except UnicodeEncodeError as e:
        assert (
            'b64 codec can\'t encode characters in position 0-1' in str(e)
        )
        assert repr(b'') in str(e)

    assert encode(UserString('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='))[0] == b'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-11 22:07:32.692215
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # The 'b64' codec is not registered.
        # It's ok, this is what we want.
        pass
    else:
        raise AssertionError(
            'The register function did not unregister the b64 codec.'
        )

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'The register function did not register the b64 codec.'
        )
    else:
        # It's ok, this is what we want.
        pass

    # For coverage ensure we can call the register() function multiple times
    # without failing.

# Generated at 2022-06-11 22:07:37.251577
# Unit test for function register
def test_register():
    """Test the register function."""
    codecs.register = mock.Mock()
    codecs.getdecoder = mock.Mock(
        side_effect=LookupError()
    )
    register()
    codecs.getdecoder.assert_called_once_with(NAME)
    codecs.register.assert_called_once()



# Generated at 2022-06-11 22:07:41.277010
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder.__name__ == decode.__name__
    encoding = codecs.getencoder(NAME)
    assert encoding.__name__ == encode.__name__

# Generated at 2022-06-11 22:07:48.937406
# Unit test for function register
def test_register():
    """Unit test for function register
    """
    import codecs

    # Codec does not exist yet.
    with pytest.raises(LookupError):
        codecs.getdecoder('b64')

    register()

    # Codec exists now.
    codecs.getdecoder('b64')

# Generated at 2022-06-11 22:07:51.857710
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    obj = codecs.getdecoder(NAME)        # type: codecs.CodecInfo
    assert obj is not None
    assert obj.name == NAME


# Generated at 2022-06-11 22:07:52.905825
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-11 22:07:56.743347
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('dGhlc2Ugd29ybGQK') == (b'these world\n', 17)
    assert encode(
        'YmFzZTY0dXRmOA==\n'
    ) == (
        b'base64utf8',
        15
    )

# Generated at 2022-06-11 22:08:04.900485
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    # Load the codec
    register()

    # Try to get the decoder.
    try:
        _ = codecs.getdecoder(NAME)    # type: ignore
    except LookupError:
        assert False, 'Failed to register the codec'

    # Check the encoding and decoding functions
    try:
        _ = codecs.encode('Hello World', 'b64')     # type: ignore
        _ = codecs.decode(b'SGVsbG8gV29ybGQ=', 'b64')    # type: ignore
    except UnicodeEncodeError:
        assert False, 'Failed to use codec to encode/decode'



# Generated at 2022-06-11 22:08:10.484291
# Unit test for function register
def test_register():

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'{NAME} should not be registered.'
        )

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'{NAME} should be registered.'
        )



# Generated at 2022-06-11 22:08:13.154822
# Unit test for function register
def test_register():
    # pylint: disable=I0011,W0612,E0611
    from codectools.encodings.b64 import register
    register()

# Generated at 2022-06-11 22:08:16.912596
# Unit test for function register
def test_register():
    """Ensure the ``b64`` codec is registered with Python."""
    try:
        functions = codecs.getdecoder(NAME)
    except LookupError:
        functions = None
    assert functions is not None


# Generated at 2022-06-11 22:08:20.744221
# Unit test for function encode
def test_encode():
    text = '\n'.join([
        '',
        'Um9sZQ==',
        '',
        '',
    ])
    out = encode(text)
    assert out == (b'Role', len(text))

test_encode()


# Generated at 2022-06-11 22:08:31.051141
# Unit test for function encode
def test_encode():
    """Unit tests for function encode."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\t') == (b'', 0)
    assert encode('This is a test.') == (
        b'VGhpcyBpcyBhIHRlc3Qu',
        15
    )
    assert encode('This is a test\n') == (
        b'VGhpcyBpcyBhIHRlc3Q=',
        14
    )
    assert encode('This is a test\n\n') == (
        b'VGhpcyBpcyBhIHRlc3Q=',
        14
    )

# Generated at 2022-06-11 22:08:42.046528
# Unit test for function encode
def test_encode():
    # Tests for the encode function.
    assert encode('eW91IGNhbid0IHJlYWQgdGhpcyE=')[0] == b"you can't read this!"
    assert encode('eW91IGNhbid0IHJlYWQgdGhpcyE=\n')[0] == b"you can't read this!"
    assert encode('\neW91IGNhbid0IH    \n\n\n   cnQgcmVhZCB0aGlz\n \n \n   !')[0] == b"you can't read this!"


# Generated at 2022-06-11 22:08:54.043835
# Unit test for function register
def test_register():

    def _codec_decode(encoded_data, errors='strict'):
        """Decode the given 'encoded_data' into a string of characters.

        This function is a mock for the function codecs.getdecoder.

        Returns:
            bytes: The converted bytes.
            int: The length of the converted bytes.
        """
        raise LookupError('decoder not found')

    # Create a mock codecs module.
    codecs_mock = MagicMock(
        return_value={
            'decode': _codec_decode
        }
    )

    # Load the b64 module
    spec = importlib.util.spec_from_loader(
        'b64',
        codecs_mock,
    )

# Generated at 2022-06-11 22:08:56.599262
# Unit test for function register
def test_register():
    register()
    coder = codecs.getdecoder(NAME)
    assert coder is not None
    assert decode is coder[0]



# Generated at 2022-06-11 22:09:03.503687
# Unit test for function register
def test_register():
    # Delete the codec from the codecs.
    try:
        del codecs.decode[NAME]
    except:
        pass
    # Assert that the codec is not defined....
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    # Now register the codec...
    register()
    # Assert that the codec is now defined.
    assert codecs.getdecoder(NAME) is not None
    # Remove the codec.
    del codecs.decode[NAME]



# Generated at 2022-06-11 22:09:06.876030
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Should be no output if register succeeds
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:10.547504
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) is codecs.lookup(NAME)


# Generated at 2022-06-11 22:09:11.917274
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:09:13.362023
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:15.669256
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:09:21.827866
# Unit test for function register
def test_register():
    import sys
    import io
    import unittest.mock as mock
    b64_codecs = mock.Mock()
    codecs_module = sys.modules['codecs']
    codecs_module.register = mock.Mock()
    register()
    # codecs.register(b64_codecs.codec_info)
    args, kwargs = codecs_module.register.call_args
    assert args[0] == b64_codecs.get_codec_info
    assert args[0] == b64_codecs.codec_info


# Generated at 2022-06-11 22:09:32.366731
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    registered = codecs.getdecoder(NAME)
    assert isinstance(registered, codecs.CodecInfo)
    assert registered.name == NAME
    assert registered.encode == encode
    assert registered.decode == decode



# Generated at 2022-06-11 22:09:34.847724
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# pylint: disable=invalid-name

# Generated at 2022-06-11 22:09:41.468664
# Unit test for function register
def test_register():
    """
    Test function register
    """
    register()
    assert codecs.lookup_error('strict') is None
    with pytest.raises(LookupError):
        codecs.lookup_error('b64')
    assert codecs.lookup_error('b64', 'strict') is None

    assert codecs.lookup_codec(NAME) is not None
    assert b64.decode('RmFzdCB0ZXN0IGZvciB0ZXN0X2RlY29kZQ==') == (
        'Fast test for test_decode'
    )

# Generated at 2022-06-11 22:09:48.482999
# Unit test for function register
def test_register():
    import sys

    register()  # pylint: disable=no-value-for-parameter

    expected_result = "<class 'base64._b64_decode'>"
    assert sys.modules[NAME].__name__ == NAME
    assert sys.modules[NAME]._get_codec_info.__name__ == '_get_codec_info'
    assert sys.modules[NAME].decode.__name__ == 'decode'
    assert sys.modules[NAME].encode.__name__ == 'encode'
    assert str(sys.modules[NAME].register.__code__) == expected_result
    assert sys.modules[NAME].register.__code__.co_filename == __file__


# Generated at 2022-06-11 22:09:50.523589
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    codecs.encode('test', NAME)

# Generated at 2022-06-11 22:09:52.747375
# Unit test for function register
def test_register():
    """Unit test for function register.

    Ensures the function does not raise any exceptions for a known valid
    encoder.
    """
    register()

# Generated at 2022-06-11 22:09:54.410949
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.lookup(NAME).name == NAME


# Generated at 2022-06-11 22:10:03.306902
# Unit test for function register
def test_register():
    """Test that the codec registers and unregisters properly."""
    tmp = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)

    def cleanup():
        codecs.register(tmp)

    request = codecs.lookup(NAME)
    assert request == _get_codec_info(NAME)
    cleanup()
    try:
        request = codecs.lookup(NAME)
    except LookupError:
        pass  # Expected.
    else:
        assert False, '''The codec should be unregistered.'''


register()

# Generated at 2022-06-11 22:10:08.416877
# Unit test for function register
def test_register():
    """Unit test for register()."""
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.lookup(NAME) == _get_codec_info(NAME)


# Generated at 2022-06-11 22:10:13.439268
# Unit test for function register
def test_register():
    """Test that the function register works correctly."""
    from . import _registry
    func1 = _registry.get_registry_func(NAME)
    register()
    func2 = _registry.get_registry_func(NAME)
    assert func1 is None
    assert func2 is not None
    assert func2 == _get_codec_info
    assert func2.__name__ == '_get_codec_info'

# Generated at 2022-06-11 22:10:33.735477
# Unit test for function register
def test_register():
    """
    Test that the ``b64`` codec is registered and the codec objects
    can be retrieved.
    """
    register()

    decoder = codecs.getdecoder(NAME)
    assert decoder is not None
    assert callable(decoder)

    encoder = codecs.getencoder(NAME)
    assert encoder is not None
    assert callable(encoder)

    info = codecs.lookup(NAME)
    assert info is not None
    assert isinstance(info, codecs.CodecInfo)



# Generated at 2022-06-11 22:10:34.313405
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:10:38.096173
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None


# Generated at 2022-06-11 22:10:40.727505
# Unit test for function register
def test_register():
    """Test that the b64 Codec is registered."""
    assert 'b64' in codecs.encode.__code__.co_varnames

# Generated at 2022-06-11 22:10:42.543927
# Unit test for function encode
def test_encode():
    assert 'Hello world!'.encode('b64') == b'SGVsbG8gd29ybGQh\n'

# Generated at 2022-06-11 22:10:52.796980
# Unit test for function register
def test_register():
    NAME = 'b64'
    codec_info = codecs.lookup(NAME)

    assert codec_info.name == NAME


# Generated at 2022-06-11 22:10:58.037586
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python.

    This is a unit test for the register() function.  This unit test
    exists as a secondary verification that the b64 codec has been
    registered in the Python Codec Registry.

    Raises:
        CodecLookupError: if the ``b64`` codec has not been registered.
    """
    # pylint: disable=W0612
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        print(
            f'{os.path.basename(__file__)}:'
            f'test_register():'
            f'Registering the {NAME!r} codec.'
        )
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:11:00.623638
# Unit test for function register
def test_register():
    """Unit test for register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:11:04.801936
# Unit test for function register
def test_register():
    obj = _get_codec_info('b64')
    codecs.register(obj)
    assert codecs.getdecoder('b64')
    assert codecs.getencoder('b64')



# Generated at 2022-06-11 22:11:07.280870
# Unit test for function register
def test_register():
    """The unit test for the 'register' function."""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:11:29.572473
# Unit test for function register
def test_register():
    """Test the function ``register`` from this module."""
    from os import remove
    from sys import modules
    from tempfile import mkstemp
    # Create a temp file
    _, file_path = mkstemp()
    with open(file_path, 'w') as temp_file:
        temp_file.write('import pystr_encode\n'
                        'pystr_encode.b64.register()\n')


# Generated at 2022-06-11 22:11:36.674135
# Unit test for function register
def test_register():
    # unregister the previously registered codec
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        # test that lookup does not work
        with pytest.raises(LookupError):
            codecs.getdecoder(NAME)

    register()

    # test that lookup now works
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            'expected codecs.getdecoder not to raise LookupError'
        )


# Unit test function decode

# Generated at 2022-06-11 22:11:47.077401
# Unit test for function encode
def test_encode():
    """Unit testing for function encode."""
    assert encode('AQAB') == (b'\x01', 4)
    assert encode('aQAB') == (b'\x01', 4)
    assert encode('AQAB\n') == (b'\x01', 5)
    assert encode('aQAB\n') == (b'\x01', 5)
    assert encode('AQAB\r') == (b'\x01', 5)
    assert encode('aQAB\r') == (b'\x01', 5)
    assert encode('AQAB\r\n') == (b'\x01', 6)
    assert encode('aQAB\r\n') == (b'\x01', 6)

# Generated at 2022-06-11 22:11:56.518663
# Unit test for function register
def test_register():
    # pylint: disable=import-outside-toplevel
    import sys
    import unittest

    import codecs

    class TestRegister(unittest.TestCase):
        def test_register_codec(self):
            try:
                codecs.getdecoder(NAME)
            except LookupError:
                with self.assertRaises(LookupError):
                    codecs.getdecoder(NAME)
                register()
                # noinspection PyUnresolvedReferences
                codecs.getdecoder(NAME)
            else:
                raise Exception(
                    f'The codec {NAME!r} has already been registered.'
                )
            # Cleanup
            try:
                del sys.modules['lethe.codec']
            except KeyError:
                pass

    unittest.main()

# Generated at 2022-06-11 22:12:02.580008
# Unit test for function register
def test_register():
    """Test the function ``register()``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        msg = f'{NAME} is not a valid Python CodecName.'
        raise AssertionError(msg)
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        msg = f'{NAME} was not registered.'
        raise AssertionError(msg)



# Generated at 2022-06-11 22:12:08.415377
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.lookup(NAME).name == NAME, \
        f'{NAME} codec not registered'


codecs.register(_get_codec_info)   # type: ignore
# Register the 'b64' codec with the codecs module.

__all__: Tuple[str, ...] = (
    NAME,
    'decode',
    'encode',
    'register',
)

# Generated at 2022-06-11 22:12:16.770409
# Unit test for function register
def test_register():
    class Codecs:
        @classmethod
        def register(cls, codec_info: codecs.CodecInfo):
            cls.codec = codec_info
    def get_decoder(name: str) -> codecs.CodecInfo:
        if name == NAME:
            raise LookupError('Already registered')
        return Codecs.codec

    codecs.register = Codecs.register
    codecs.getdecoder = get_decoder

    register()

    codecs.register = object()
    codecs.getdecoder = object()



# Generated at 2022-06-11 22:12:18.380599
# Unit test for function register
def test_register():
    """Test for function register."""
    register()
    assert codecs.lookup(NAME).getincrementaldecoder()



# Generated at 2022-06-11 22:12:28.448042
# Unit test for function register
def test_register():
    """Test for function register."""
    # Register the codec.
    register()

    # Test the 'decode' function from the codec.
    decoded = codecs.decode(
        b'Mi4wNzEwMjQ2NzY0NDQ5OTY0MTg1ODgxMjgxNDc0NjcyMjgwMjUzODg5MjI3MDI3NDYxMjg5MzQ2ODI2MjkyMzk4NzM4MzQ2ODQ2OTg3NjA3MDUyNDcwMjI3NzM0MjYyNzc2OH0=',
        NAME
    )

# Generated at 2022-06-11 22:12:29.664575
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:13:01.421752
# Unit test for function register
def test_register():
    """Test the register() function.  This is an integration test."""
    import codecs
    register()
    codecs.decode('aGVsbG8g d29ybGQ=', 'b64')
# end test_register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:05.416611
# Unit test for function register
def test_register():
    register()
    b = codecs.getdecoder(NAME)
    t = codecs.getencoder(NAME)
    assert b is not None
    assert t is not None


# pylint: disable=W0613
# noinspection PyUnusedLocal

# Generated at 2022-06-11 22:13:07.478087
# Unit test for function register
def test_register():
    prev_count = len(codecs.getdecoder(NAME))
    register()
    assert prev_count < len(codecs.getdecoder(NAME))

# Generated at 2022-06-11 22:13:17.483463
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test 1
    text = "UHJhY2UgU2NpZW5jZSBpcyBhIGdyZWF0IGhlbGxvIHdvcmxk"
    expected = b"Place Science is a great hello world"
    actual, _ = encode(text)
    assert actual == expected

    # Test 2 with extra/unnecessary whitespaces

# Generated at 2022-06-11 22:13:19.718469
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    assert NAME in codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:29.049664
# Unit test for function register
def test_register():
    import sys
    import os
    import tempfile
    import pytest
    import b64codec
    from b64codec import _get_codec_info

    # Create a temporary directory for testing.
    test_dir = tempfile.TemporaryDirectory()
    assert os.path.isdir(test_dir.name)

    # Save the old sys.path
    old_path = sys.path[:]

    # Append our test directory to the python path
    sys.path.append(test_dir.name)

    # The directory that holds the unit test module
    mod_dir = os.path.dirname(os.path.realpath(__file__))

    # Create a temporary module directory
    mod_dir_name = os.path.join(test_dir.name, 'b64codec')
    os.mkdir

# Generated at 2022-06-11 22:13:33.665609
# Unit test for function register
def test_register():
    """Register the b64 codec with Python."""
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
    assert codecs.getencoder(NAME)


# Generated at 2022-06-11 22:13:39.843046
# Unit test for function encode
def test_encode():
    """Unit test for ``encode()``"""

    def encode_test(
            text: _STR = None,
            expected_text: _STR = None,
            expected_len: int = 0
    ) -> None:
        """Create a unit test for the ``encode()`` function.

        Args:
            text (str): A string to be encoded into base64 bytes.
            expected_text (str): The expected result of the string
                encoding.  This is the string that is used when comparing
                the result of the output of the ``encode()`` function.
            expected_len (int): The expected length of the ``text``
                argument used in the ``encode()`` function call.
        """
        if text is None:
            text = ''

        if expected_text is None:
            expected_text = text

        encoded_

# Generated at 2022-06-11 22:13:43.158202
# Unit test for function register
def test_register():
    """Test the register() function works.

    Raises:
        AssertionError: If the register() function does not register
            the 'b64' codec.
    """
    register()
    assert 'b64' in codecs.encode

# Generated at 2022-06-11 22:13:46.705803
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    from TEST.encoders.b64 import code_readme
    code_readme.main(None)


# Generated at 2022-06-11 22:14:18.607253
# Unit test for function register
def test_register():
    """Ensure ``register()`` does not throw an error."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:14:21.905302
# Unit test for function register
def test_register():
    register()
    # codecs.register(_get_codec_info)
    test_str = 'Daniel Maximilian Jarboe'
    encoded = test_str.encode('b64')
    decoded = encoded.decode('b64')
    assert test_str == decoded

# Generated at 2022-06-11 22:14:24.423517
# Unit test for function register
def test_register():
    # Register the 'b64' codec
    register()

    # Get the 'b64' codec
    codec = codecs.getdecoder(NAME)

    assert isinstance(codec, codecs.CodecInfo)

# Generated at 2022-06-11 22:14:33.865225
# Unit test for function register
def test_register():
    import os
    import pathlib
    import subprocess
    import sys

    # Get the absolute path of the currently running Python interpreter.
    python_bin = os.path.realpath(sys.executable)
    # Get the absolute path of the script being run.
    script_path = pathlib.Path(os.path.realpath(__file__)).parent
    # Get the absolute path of the file that the codec is written in in
    # this case this is the codec itself.
    file_path = script_path / 'b64.py'
