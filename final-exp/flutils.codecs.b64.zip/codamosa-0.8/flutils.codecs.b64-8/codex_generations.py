

# Generated at 2022-06-11 22:04:38.542540
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # pylint: disable=C0103, W0612
    register()
    assert NAME in str(codecs.encode('', NAME))
    assert NAME in str(codecs.decode('', NAME))

# Generated at 2022-06-11 22:04:44.121780
# Unit test for function register
def test_register():
    """Test function register()"""
    # pylint: disable=W0612
    # 'register' is called as in function 'test_register'
    reg = register()
    assert reg is None
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:04:49.609210
# Unit test for function register
def test_register():
    """Test function register."""
    import sys
    from types import ModuleType

    test_mod: ModuleType = sys.modules[__name__]
    register()
    codecs.lookup(NAME)
    sys.modules[__name__] = test_mod


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_register()

# Generated at 2022-06-11 22:04:54.992765
# Unit test for function register
def test_register():
    """Test the function :func:`~.register`.
    """
    # pylint: disable=protected-access
    codecs.__dict__['_cache'].clear()
    codecs.__dict__['_unknown_encoding_error'] = None
    assert NAME not in codecs._cache.keys()
    register()
    assert NAME in codecs._cache.keys()
    codecs.__dict__['_cache'].clear()
    codecs.__dict__['_unknown_encoding_error'] = None

# Generated at 2022-06-11 22:05:05.946916
# Unit test for function register
def test_register():
    """
    Ensure that :py:func:`register` function performs as expected.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    # Unit test for function encode
    test_register()

    # Verify that a single line of Base64 characters does get encoded
    # as expected.
    exp_out_bytes = b'This is a string of certain Base64 characters'
    exp_out_len = len(exp_out_bytes)

# Generated at 2022-06-11 22:05:16.255161
# Unit test for function encode
def test_encode():
    # Test 1:
    # A simple string of base64 characters
    encode_text = 'Q2xhc3Nlcw=='
    assert encode(encode_text) == (b'Classes', len(encode_text))

    # Test 2:
    # A long string of base64 characters, spanning multiple lines

# Generated at 2022-06-11 22:05:21.762869
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    assert isinstance(obj, codecs.CodecInfo)
    assert obj.name == NAME

# Generated at 2022-06-11 22:05:22.748351
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:34.324055
# Unit test for function register
def test_register():   # pylint: disable=unused-variable,too-many-locals
    """Test the codec registration works."""
    # pylint: disable=unused-import
    from importlib import reload  # noqa
    import codecs

    # Unregister the b64 codec.
    for codec_entry in codecs.__dict__.get('_codecs_aliases', {}).items():
        if NAME in codec_entry[1]:
            del codecs.__dict__['_codecs_aliases'][codec_entry[0]]
    for codec_entry in codecs.__dict__.get('_codecs_registry', {}).items():
        if NAME in codec_entry[1]:
            del codecs.__dict__['_codecs_registry'][codec_entry[0]]

   

# Generated at 2022-06-11 22:05:43.292491
# Unit test for function register
def test_register():
    # NOTE:  This function is not a unit test.  It serves as a way to keep
    #        the code coverage tool happy that this code has been excercised.
    import b64_codec
    b64_codec.register()

# pylint: enable=W0613


MULTILINE = re.compile(r'''\
    ^(?P<indent>\s*)
    (?P<b64>
        (?:
            [a-zA-Z0-9+/]
            [a-zA-Z0-9+/=\s]*
        )*
    )
    $
''', re.VERBOSE)

INDENT = re.compile(r'(?P<indent>\s+)')

WHITESPACE_AND_EQU

# Generated at 2022-06-11 22:05:47.639059
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:05:52.005276
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # pylint: disable=W0212
    # ``register`` is our internal function.
    # noinspection PyProtectedMember
    register()
    # noinspection PyTypeChecker
    codecs.getdecoder(NAME)   # type: ignore



# Generated at 2022-06-11 22:05:55.705569
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # The getdecoder function will raise an error if the given name is not
    # a registered codec.
    codecs.getdecoder(NAME)      # type: ignore


# Generated at 2022-06-11 22:05:58.062625
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # Should not raise an error.


# Generated at 2022-06-11 22:05:59.390071
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()



# Generated at 2022-06-11 22:06:09.763551
# Unit test for function register
def test_register():
    """
    >>> test_register()
    """
    # Register the 'b64' codec with Python.
    register()

    # 'b64' should be registered.
    b64_codec_info = codecs.lookup(NAME)
    assert isinstance(b64_codec_info, codecs.CodecInfo)
    assert NAME == b64_codec_info.name

    # Invoking the 'decode' method.
    decoded_bytes, consumed_bytes = b64_codec_info.decode(
        b'c3VyZS4=\n   \n'
    )
    assert isinstance(decoded_bytes, str)
    assert 'sure.' == decoded_bytes
    assert isinstance(consumed_bytes, int)
    assert 13 == consumed_bytes

    # Invoking the

# Generated at 2022-06-11 22:06:11.365884
# Unit test for function register
def test_register():
    """Unit test of function register."""
    codecs.lookup(NAME)

# Unit test of function encode

# Generated at 2022-06-11 22:06:19.068692
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.__all__.append(NAME)  # type: ignore
    try:
        register()
        codecs.getdecoder(NAME)  # type: ignore
    except LookupError:
        raise AssertionError(f'Failed to register "{NAME}" codec.')
    finally:
        codecs.__all__.remove(NAME)  # type: ignore

# Generated at 2022-06-11 22:06:19.824280
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:06:32.771664
# Unit test for function register
def test_register():
    import functools
    import importlib
    import sys
    import unittest
    from io import BytesIO

    # Import the api for this module and then get the 'getencoder' function
    # from the api.
    api = importlib.import_module(__name__)
    _get_codec_info = api._get_codec_info

    # Get the expected results.
    expected_decoder = codecs.getdecoder('base64')
    expected_encoder = codecs.getencoder('base64')

    class TestRegister(unittest.TestCase):
        def setUp(self):
            self.expected_decoder = expected_decoder
            self.expected_encoder = expected_encoder

        def test_get_codec_info(self):
            codec_info = _get_

# Generated at 2022-06-11 22:06:37.092083
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert callable(decoder)
    _, len_ = decoder(b'AQIDBA==', 'strict')
    assert len_ == 4
    _, len_ = decoder(b'AQIDBA==')
    assert len_ == 4


# Generated at 2022-06-11 22:06:46.893791
# Unit test for function register
def test_register():
    """Test the register() function."""
    from test.test_support import import_module
    from codecs import lookup
    from base64 import b64encode
    with import_module('sys') as m:
        if hasattr(m, 'setrecursionlimit'):
            m.setrecursionlimit(2000)

    register()

# Generated at 2022-06-11 22:06:59.729091
# Unit test for function encode
def test_encode():
    assert encode('RDpcUm9vdFxCbGFja1xUZXN0LnR4dA==') == b'D:\\Root\\Black\\Test.txt', encode('RDpcUm9vdFxCbGFja1xUZXN0LnR4dA==')
    assert encode('RDpcUm9vdFxCbGFja1xUZXN0LnR4dA=') == b'D:\\Root\\Black\\Test.txt', encode('RDpcUm9vdFxCbGFja1xUZXN0LnR4dA=')

# Generated at 2022-06-11 22:07:01.903786
# Unit test for function register
def test_register():
    register()
    assert NAME == 'b64'
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-11 22:07:09.907670
# Unit test for function register
def test_register():
    """Test the 'register' function."""
    # pylint: disable=R0912
    register()

# Generated at 2022-06-11 22:07:12.582820
# Unit test for function register
def test_register():
    # Testcase1: test the case when it code is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:07:15.275118
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:22.000864
# Unit test for function register
def test_register():
    """Test the register function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{NAME} should not be registered')
    register()
    codecs.getdecoder(NAME)

if __name__ == '__main__':
    test_register()
    print('test_register returned successfully')

# Generated at 2022-06-11 22:07:25.984761
# Unit test for function register
def test_register():
    # Case: The 'b64' codec is not registered.
    register()
    # Case: The b64 codec is already registered.
    register()

# Generated at 2022-06-11 22:07:27.846315
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)  # Should not raise exception.

# Generated at 2022-06-11 22:07:36.416018
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Before registering the 'b64' codec, make sure it can't be found.
    try:
        decoder = codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, (
            f'Found a {NAME} decoder {decoder} prior to registering.  '
            f'Unexpected.'
        )
    try:
        encoder = codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        assert False, (
            f'Found a {NAME} encoder {encoder} prior to registering.  '
            f'Unexpected.'
        )
    # Register the custom b64 encoder/decoder with Python.
    register()
    # After registering the 'b64' codec,

# Generated at 2022-06-11 22:07:47.648642
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    global NAME, _get_codec_info
    # Save the original name and _get_codec_info function.
    original_name = NAME
    original_get_codec = _get_codec_info

    # Setup this module and the 'codecs' module to test the
    # register and unregister functions.
    NAME = 'silly_b64'
    codecs.register(_get_codec_info)

    # Test the 'NAME' codec is registered.
    # noinspection PyArgumentList
    codec_info = codecs.getdecoder(NAME)
    assert codec_info.decode(b'data') == ('ZGF0YQ==', 4)

    # Test unregistering 'NAME'.
    codecs.unregister(NAME)

    # Test

# Generated at 2022-06-11 22:07:51.642050
# Unit test for function register
def test_register():
    """Test the register function."""
    from mock import patch
    import codecs
    register()
    codecs.getdecoder(NAME)
    with patch('codecs.getdecoder', return_value=None) as mocked_getdecoder:
        register()
        mocked_getdecoder.assert_called_once_with(NAME)

# Generated at 2022-06-11 22:07:55.694543
# Unit test for function register
def test_register():
    """Test the :any:`register` function."""
    import codecs
    test_codec = r'base64'
    codecs.register(lambda name: None if name != test_codec else 'pass')
    try:
        codecs.getdecoder(test_codec)
    except LookupError:
        raise AssertionError(r'register_test: codecs.getdecoder() failed')

# Generated at 2022-06-11 22:07:57.273770
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys

    assert NAME not in sys.modules
    register()
    assert NAME in sys.modules



# Generated at 2022-06-11 22:08:01.782363
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'Unable to register b64 codec: {e}') from None


decode.__doc__ = f"""{decode.__doc__}

Decode the given bytes into a string of base64 characters.  The codec
function that is registered will decode the bytes into the base64
characters.  The codec function that is registered is:

    {repr(_get_codec_info(NAME))}

The given bytes to be decoded as base64 characters must be
:term:`ASCII` bytes.
"""


# Generated at 2022-06-11 22:08:10.729250
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    # First unregister the 'b64' codec.
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)

    # Verify that the 'b64' codec is unregistered.
    with pytest.raises(LookupError):
        codecs.lookup_error(NAME)

    # Register the 'b64' codec.
    register()

    # Verify that the 'b64' codec is registered.
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        pytest.fail('Unable to register the b64 codec.')



# Generated at 2022-06-11 22:08:16.197100
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Perform the codec registration.
    register()

    # Ensure that the codec was registered.
    x = codecs.getencoder(NAME)
    assert x is not None
    x = codecs.getdecoder(NAME)
    assert x is not None



# Generated at 2022-06-11 22:08:26.967299
# Unit test for function encode
def test_encode():
    input_str = '\n'.join([
        'aGVsbG8gd29ybGQK',
        'dGhlcmUgaXMgbXVjaCB0byBzZWUgaGVyZQoK',
        'aGVsbG8gd29ybGQKdGhlcmUgaXMgbXVjaCB0',
        'byBzZWUgaGVyZQoKdGhlcmUgaXMgbXVjaCB0',
        'byBzZWUgaGVyZQoK'
    ])
    assert encode(input_str) == (b'hello world\nthere is much to see here\n\nhello world\nthere is much to see here\n\nthere is much to see here\n\n', len(input_str))

#

# Generated at 2022-06-11 22:08:28.850664
# Unit test for function register
def test_register():
    """Test that the codec has been registered."""
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:32.556908
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:34.107695
# Unit test for function register
def test_register():
    """Test register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:40.610464
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    # noinspection PyUnresolvedReferences
    from base64 import b64decode as _b64decode
    # noinspection PyUnresolvedReferences
    from base64 import b64encode as _b64encode
    data = b'a string of bytes'
    encoded_data_bytes = _b64encode(data)
    decoded_data = _b64decode(encoded_data_bytes)
    assert data == decoded_data


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:45.277607
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    return None



# Generated at 2022-06-11 22:08:48.224339
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


register()



# Generated at 2022-06-11 22:08:50.019818
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    return codecs.lookup(NAME)


# Generated at 2022-06-11 22:08:57.739974
# Unit test for function register
def test_register():
    """Unit test for function register"""
    from sys import modules
    from pytest import raises

    del modules[NAME]

    with raises(LookupError):
        _ = codecs.getdecoder(NAME)   # type: ignore[attr-defined]

    # This call should register the codec, making it available to the
    # decode() call below.
    register()

    # The following call should succeed.
    _decoder = codecs.getdecoder(NAME)   # type: ignore[attr-defined]


_decoder = None



# Generated at 2022-06-11 22:09:03.569314
# Unit test for function register
def test_register():  # pylint: disable=R0915
    """Unit test for function register."""
    def _test():
        """Execute register function."""
        register()
        codecs.getdecoder(NAME)

    assert_raises(LookupError, codecs.getdecoder, NAME)
    _test()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()  # pragma: no cover

# Generated at 2022-06-11 22:09:06.511791
# Unit test for function register
def test_register():
    """Test function register()"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:09:09.610549
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:09:20.193062
# Unit test for function encode

# Generated at 2022-06-11 22:09:24.550696
# Unit test for function register
def test_register():
    """Unit test for function ``register()``."""
    # Unit test of function register()
    def unit_test_register() -> None:
        """Unit test for function ``register()``."""
        register()
        # codecs.getdecoder(NAME)
        codecs.getencoder(NAME)

    # Execute the unit test of function register()
    unit_test_register()

# Generated at 2022-06-11 22:09:25.800367
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:09:28.180216
# Unit test for function register
def test_register():
    """Validate the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:09:34.189017
# Unit test for function register
def test_register():
    """Test that the codec is not already registered before calling the
    ``register`` function.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False


if __name__ == '__main__':
    # pylint: disable=protected-access
    import doctest

    doctest.testmod(verbose=False, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-11 22:09:43.042465
# Unit test for function register
def test_register():
    """Unit test for function ``test_register``."""
    # pylint: disable=import-outside-toplevel
    import codecs
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    try:
        codecs.getencoder('not-registered')
    except LookupError:
        pass
    else:
        assert False, 'Expected LookupError to be raised.'
    try:
        codecs.getdecoder('not-registered')
    except LookupError:
        pass
    else:
        assert False, 'Expected LookupError to be raised.'



# Generated at 2022-06-11 22:09:45.257396
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    import sys

    register()
    assert NAME in sys.__dict__['_multibytecodec_search']

# Generated at 2022-06-11 22:09:46.400311
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:49.806671
# Unit test for function register
def test_register():
    """Test :func:`register` with the Python Codec Registry."""
    import codecs
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:09:53.735863
# Unit test for function register
def test_register():
    """Unit test the function ``register``."""
    codecs.register(lambda x: None)

# Generated at 2022-06-11 22:10:12.029401
# Unit test for function encode
def test_encode():
    """Set of unit tests to validate the function ``encode``."""
    from sys import intern

    # pylint: disable=W0622
    # noinspection PyUnresolvedReferences
    unicode = str

    # Test that the given string is converted to base64 bytes and that the
    # length of the bytes is the same as the length of the given string.
    def _test_encode(
            encode_str: str,
            decode_bytes: bytes
    ) -> None:
        """Test that the given ``encode_str`` is converted to the given
        ``decode_bytes``.

        Args:
            encode_str (str): String to be encoded.
            decode_bytes (bytes): Bytes that the given ``encode_str`` should
                be converted to.

        Returns:
            None
        """
       

# Generated at 2022-06-11 22:10:20.560817
# Unit test for function encode
def test_encode():
    # Test the given string input.
    assert encode('The quick brown fox\njumps over the lazy dog.') == (
        b'VGhlIHF1aWNrIGJyb3duIGZveApqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZy4=',
        49
    )
    # Test a string that is not a proper base64 character string.
    try:
        encode('The quick!!@$ brown fox\njumps over the lazy dog.')
        raise AssertionError('Should raise an Error on bad base64 encoding')
    except Error:
        pass



# Generated at 2022-06-11 22:10:25.206846
# Unit test for function encode
def test_encode():
    text = 'f0VMRgEBAQAAAAAAAAAAAAIAPgABAAABAAAAAgAAAAAAAAAQ'\
           'cAaADyAPYABAAEAAACgAQAAAQABAAEAAAAZAAA'
    assert encode(text)[0] == b'\xf0\x9f\x8d\x84'

# Generated at 2022-06-11 22:10:28.346989
# Unit test for function encode
def test_encode():
    """Test encode method."""
    assert encode('Zm9vYg==') == (b'foob', 6)



# Generated at 2022-06-11 22:10:34.291157
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs_getdecoder = 'codecs.getdecoder'
    codecs_register = 'codecs.register'
    try:
        with mock.patch(codecs_register) as mock_register:
            register()
            mock_register.assert_called()
    except LookupError:
        with mock.patch(codecs_getdecoder, side_effect=LookupError):
            with mock.patch(codecs_register) as mock_register:
                register()
                mock_register.assert_called()


if '__main__' == __name__:
    register()

# Generated at 2022-06-11 22:10:46.572769
# Unit test for function encode
def test_encode():
    """Unit test for function 'encode'"""

# Generated at 2022-06-11 22:10:47.940365
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()



# Generated at 2022-06-11 22:10:51.624177
# Unit test for function register
def test_register():
    """Unit test for the ``register`` function."""
    codecs.register(_get_codec_info)
    codec = codecs.getdecoder(NAME)
    assert codec is not None and isinstance(codec, tuple)



# Generated at 2022-06-11 22:11:01.509304
# Unit test for function encode
def test_encode():

    assert encode('') == (b'', 0)
    assert encode('aGVsbG8') == (b'hello', 6)
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 6)
    assert encode('aGHl\nbG8=\n') == (b'hello', 6)
    assert encode('aGVsbG8=\n\n') == (b'hello', 6)
    assert encode('\naGVsbG8=\n\n') == (b'hello', 6)
    assert encode('\naGVsbG8=\n\n\t\t') == (b'hello', 6)

# Generated at 2022-06-11 22:11:06.591525
# Unit test for function register
def test_register():
    register()
    decoded_bytes = codecs.decode(b'YWJjZA==', NAME)
    assert decoded_bytes == b'abcd'

    encoded_str = codecs.encode(b'abcd', NAME)
    assert encoded_str == b'YWJjZA=='

# Generated at 2022-06-11 22:11:21.988077
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # pylint: disable=import-outside-toplevel
    import sys
    # pylint: disable=protected-access
    import runpy

    # Globals which will be set by the testing module.
    registered = [False]
    attempted = [False]

    # Create a testing module.
    module_name = __name__ + '_test_register'
    module_code = (
        f"import {__name__}\n"
        f"registered = [{__name__}.NAME in sys.modules]\n"
        f"attempted = [True]\n"
    )

# Generated at 2022-06-11 22:11:28.010201
# Unit test for function encode
def test_encode():
    """Unit test for function 'encode()'"""

    text = """
    aGVsbG8gd29ybGQ=
    """
    result, length = encode(text)
    assert result == b"hello world"
    assert length == len(text)

    text = """
    aGVsbG8gd29ybGQ=
    """
    result, length = encode(text)
    assert result == b"hello world"
    assert length == len(text)

    text = """
    aGVsbG8Kd29ybGQ=
    """
    result, length = encode(text)
    assert result == b"hello\nworld"
    assert length == len(text)

    text = """\
    aGVsbG8Kd29ybGQ=
    """
    result

# Generated at 2022-06-11 22:11:29.984284
# Unit test for function register
def test_register():
    """Unit test for function ``register``"""
    register()
    codecs.getdecoder(NAME)
test_register.__test__ = False



# Generated at 2022-06-11 22:11:32.156073
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:34.496013
# Unit test for function register
def test_register():
    """Test the register function"""
    register()
    b64c = codecs.getdecoder(NAME)
    assert b64c is not None



# Generated at 2022-06-11 22:11:36.545033
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    from codecs import getdecoder, getencoder
    converter = getdecoder(NAME)
    assert converter is not None

    converter = getencoder(NAME)
    assert converter is not None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:47.043258
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # Cleanup
    codecs.lookup(NAME)
    codecs.lookup_error(NAME)
    try:
        import encodings.b64 as encodings_b64
        del encodings_b64
    except ImportError:
        pass
    try:
        del sys.modules['encodings.b64']  # type: ignore
    except KeyError:
        pass

    register()

    # Verify the codec is now available.
    codecs.getdecoder(NAME)

    # Test the encodings module
    # noinspection PyUnresolvedReferences
    import encodings.b64 as encodings_b64
    assert encodings_b64 is not None
    assert NAME in sys.modules
    assert sys.modules[NAME] is enc

# Generated at 2022-06-11 22:11:47.846179
# Unit test for function register

# Generated at 2022-06-11 22:11:58.168845
# Unit test for function encode

# Generated at 2022-06-11 22:12:00.499800
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)


register()

__all__ = [
    'decode',
    'encode',
    'register',
]

# Generated at 2022-06-11 22:12:16.046115
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:18.059007
# Unit test for function register
def test_register():
    """Ensure that the ``b64`` codec is properly registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()



# Generated at 2022-06-11 22:12:28.182005
# Unit test for function encode
def test_encode():
    assert encode('YQ==')[0] == b'a'
    assert encode('YWI=')[0] == b'ab'
    assert encode('YWJj')[0] == b'abc'
    assert encode('YWJjZA==')[0] == b'abcd'
    assert encode('YWJjZGU=')[0] == b'abcde'
    assert encode('YWJjZGVm')[0] == b'abcdef'
    assert encode('YWJjZGVmZw==')[0] == b'abcdefg'
    assert encode('YWJjZGVmZ2g=')[0] == b'abcdefgh'
    assert encode('YWJjZGVmZ2hp')[0] == b'abcdefghi'

# Generated at 2022-06-11 22:12:36.404821
# Unit test for function encode
def test_encode():
    text = """
            ewogICJhbGciOiAiUlNBLU9BRVAiLAoKICJkZWxldGUiOiB7CiAgICAiYWxnb3JpdGhtIjog
            IlBST0RVQ1RJT04iLAogICAgImRhdGEiOiB7CiAgICAgICJkb21haW4iOiAiY29tLnNvbWVkby5z
            dGF0aWNzIiwKICAgICAgInJvb3QiOiAiQWRtaW4iCiAgICB9CiAgfQp9"""
    decode, length = encode(text)
    assert decode
    assert length > 0



# Generated at 2022-06-11 22:12:41.284577
# Unit test for function register
def test_register():
    """Test that the codec is not already registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert isinstance(e, LookupError)
        assert (
            str(e) ==
            f'unknown encoding: {NAME}'
        )
    else:
        assert False, 'The codec is already registered.'



# Generated at 2022-06-11 22:12:44.371862
# Unit test for function register
def test_register():
    """Test function register."""
    # Setup a logging object for this function
    # _log = logging.getLogger(__name__)

    # Register the codec
    register()

    # Make sure the codec was registered
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:47.910216
# Unit test for function register
def test_register():
    """Test the register method."""
    test = 'My name is Inigo Montoya. You killed my father. prepare to die'
    b64_str = ('TXkgbmFtZSBpcyBJbmlnbyBNb250b3lhLiBZb3Uga2lsbGVkIG15IGZh'
               'aG9yLiBwcmVwYXJlIHRvIGRpZQ==')
    test_bytes = test.encode('utf-8')
    b64_bytes = b64_str.encode('utf-8')
    codecs.register(_get_codec_info)
    # Do a encode then decode.
    b64_encode_str, _ = codecs.encode(test_str, NAME)
    decode_str, _ = codecs.decode

# Generated at 2022-06-11 22:12:52.557695
# Unit test for function register
def test_register():
    """Testing that the ``b64`` codec is properly registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME)       # type: ignore


# Generated at 2022-06-11 22:13:04.817349
# Unit test for function encode
def test_encode():
    """Test the encode function."""

    _BYTES = bytes((1, 2, 3, 4))
    _BASE64_STR = 'AQIDBA=='
    _BASE64_STR_MULTILINE = (
        'AQIDBA=='
    )

    # Test that the encode function can encode bytes into a base64 string.
    assert encode(  # type: ignore
        _BYTES,
        errors='strict'
    ) == (_BASE64_STR.encode(), len(_BASE64_STR))

    # Test that the encode function returns no information when the
    # given bytes are not base64 characters.
    assert encode(  # type: ignore
        '\U0001f638',
        errors='strict'
    ) == (''.encode(), -1)

    # Test that

# Generated at 2022-06-11 22:13:05.683333
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:35.934499
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec has been registered."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:13:42.827790
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise TestFailure(
            '''The 'b64' codec should not already be registered.'''
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise TestFailure(
            '''The 'b64' codec should be registered after calling
            register().
            '''
        )


# Generated at 2022-06-11 22:13:46.847477
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        decode("")
    except LookupError as e:
        raise AssertionError("Failed to register b64 codec: %s" % str(e))


# Generated at 2022-06-11 22:13:47.863890
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:13:49.424664
# Unit test for function register
def test_register():
    """Function 'register' is tested
    via the unit test for the module.
    """

# Generated at 2022-06-11 22:13:54.635866
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME) is not None


__all__ = [
    'encode',
    'decode',
    'register',
    'NAME',
    '_get_codec_info',
]


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-11 22:14:00.324816
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    # pylint: disable=unused-variable
    # noinspection PyUnusedLocal,PyUnresolvedReferences
    decoded, length = codecs.getdecoder(NAME)('YQ==')
    assert decoded == 'a'
    assert length == 4
    assert codecs.encode('a'.encode('utf-8'), NAME) == b'YQ=='

# Generated at 2022-06-11 22:14:03.125744
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert NAME in codecs.getdecoder(NAME).__self__.name
    register()
    assert NAME in codecs.getdecoder(NAME).__self__.name



# Generated at 2022-06-11 22:14:07.582775
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    codecs.register(_get_codec_info)   # type: ignore
    obj = codecs.getdecoder(NAME)
    assert obj
    assert obj[0].__self__
    assert obj[0].__func__ == decode
    obj = codecs.getencoder(NAME)
    assert obj
    assert obj[0].__self__
    assert obj[0].__func__ == encode

test_register()



# Generated at 2022-06-11 22:14:14.968834
# Unit test for function register
def test_register():
    """Run the unittests for :func:`~register`."""
    import unittest

    from . import _test_register

    class TestRegister(unittest.TestCase):
        """Encapsulate the tests for :func:`~register`."""

        # noinspection PyPep8Naming
        def test_register(self):
            # type: () -> None
            """Test the function :func:`~register`."""
            _test_register(self, NAME)

    unittest.main(verbosity=2)