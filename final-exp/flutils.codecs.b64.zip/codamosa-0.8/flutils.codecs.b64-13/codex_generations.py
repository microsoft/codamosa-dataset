

# Generated at 2022-06-11 22:04:38.373289
# Unit test for function register
def test_register():
    """Test that the codec is registered correctly."""
    import sys

    try:
        del(sys.modules[__name__])
    except KeyError:
        pass

    import encoder
    encoder.register()
    result = codecs.lookup(encoder.NAME)
    assert result is not None
    assert result.name == encoder.NAME
    assert result.encode == encoder.encode
    assert result.decode == encoder.decode


# Generated at 2022-06-11 22:04:44.432231
# Unit test for function register
def test_register():
    text = r"""
        This is a test to make sure that the b64 codec is properly
        registered.  The b64 codec should be the first codec.
    """

    # This is a test to make sure that the b64 codec is properly
    # registered.  The b64 codec should be the first codec.
    b64_encoded = 'VGhpcyBpcyBhIHRlc3QgdG8gbWFrZSBzdXJlIHRoYXQgdGhlIGI2NCBjb2RlYyBpcyBwcm9wZXJseSByZWdpc3RlcmVkLiAgVGhlIGI2NCBjb2RlYyBzaG91bGQgYmUgdGhlIGZpcnN0IGNvZGVjLg=='

    #

# Generated at 2022-06-11 22:04:47.344206
# Unit test for function register
def test_register():
    """Register the b64 codec with Python."""
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


# Generated at 2022-06-11 22:04:55.970128
# Unit test for function encode

# Generated at 2022-06-11 22:04:58.874133
# Unit test for function register
def test_register():
    """Test the function register."""
    register()

    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:08.657122
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`~b64.encode`.

    function:
        :func:`~b64.encode`

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: A test assertion failed.
    """
    # Test default text
    input_text = (
        '\n'
        'This is the first line of text.\n'
        'This is the second line of text.\n'
        'This is the third line of text.\n'
    )

# Generated at 2022-06-11 22:05:17.592408
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    # noinspection PyUnresolvedReferences
    from base64 import b64decode
    b64decode(b'YW55IGNhcm5hbCBwbGVhc3VyZQ==\n')
    b64decode(b'SGVsbG8sIHdvcmxkIQ==')
    b64decode(b'aGVsbG8gd29ybGQ=')
    b64decode(b'aGVsbG8gd29ybGQ')
    b64decode(b'hello world')
    b64decode(b'hello world=')
    b64decode(b'hello world==')
    b64decode(b'hello world===')



# Generated at 2022-06-11 22:05:21.812851
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function :obj:`register`."""
    register()

# Generated at 2022-06-11 22:05:28.373769
# Unit test for function encode
def test_encode():
    assert encode('aG9sYWJsYXRjYXN0aWZ5') == b'holablatify'
    assert encode('ZW9rZXVzZW9rZXVzZW9r') == b'eokersueokersueok'
    assert encode('bWFhYXBlcnljYXRlcg==') == b'maahaperycater'


# Generated at 2022-06-11 22:05:41.469519
# Unit test for function encode
def test_encode():
    # This can be removed once 'userstring' is eliminated.
    assert isinstance('s'.__class__, type(UserString('s')))

    # Test the 'encode()' function with correct data.
    assert encode('YQ==', 'strict') == (b'a', 3)
    assert encode('YWI=', 'strict') == (b'ab', 3)
    assert encode('YWJj', 'strict') == (b'abc', 4)
    assert encode('YWJjZA==', 'strict') == (b'abcd', 4)
    assert encode('YWJjZGU=', 'strict') == (b'abcde', 4)
    assert encode('YWJjZGVm', 'strict') == (b'abcdef', 4)

# Generated at 2022-06-11 22:05:49.183302
# Unit test for function register
def test_register():
    """Simple test for function register."""
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:52.702119
# Unit test for function register
def test_register():
    """Test Case:  Unit test for function :func:`register`."""
    try:
        assert NAME in codecs.getencodings()
    except AssertionError:
        register()
        assert NAME in codecs.getencodings()



# Generated at 2022-06-11 22:05:54.102570
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:00.667559
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # Import the standard library codecs.
    import codecs

    # Remove the 'b64' codec from the codec lookup.

# Generated at 2022-06-11 22:06:02.595005
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:05.746264
# Unit test for function register
def test_register():
    # Reset the 'b64' codec registry.
    codecs.register(_get_codec_info)
    register()



# Generated at 2022-06-11 22:06:15.923137
# Unit test for function register
def test_register():
    """Test the ``register`` function.

    Ensure that the ``register`` function doesn't throw any errors and that
    if the codec is already register, that it only registers once.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception(  # pylint: disable=C0103
            f'The {NAME} codec is already registered.'
        )

    # noinspection PyTypeChecker
    register()
    # noinspection PyTypeChecker
    codecs.getdecoder(NAME)  # Should not raise an exception
    # noinspection PyTypeChecker
    register()  # Should not raise an exception.
    # noinspection PyTypeChecker
    codecs.getdecoder(NAME)  # Should not raise an exception

#

# Generated at 2022-06-11 22:06:23.837331
# Unit test for function encode

# Generated at 2022-06-11 22:06:27.337182
# Unit test for function register
def test_register():
    """Unit test the register function"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:06:30.963620
# Unit test for function register
def test_register():
    global codecs
    if codecs is None:
        codecs = __import__('codecs')

    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        fail('Failed to register the codec.')

# Generated at 2022-06-11 22:06:38.288472
# Unit test for function register
def test_register():
    """Unit test for :py:meth:`register`."""
    register()
    _ = codecs.getdecoder(NAME)   # type: ignore
    _ = codecs.getencoder(NAME)   # type: ignore


del codecs

# Generated at 2022-06-11 22:06:44.110177
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f'{NAME} is not registered')


BAD_CHARS = 'xyzXYZ'
BAD_B64 = '=='
GOOD_B64 = 'Zm9v'
GOOD_CHARS = 'foo'



# Generated at 2022-06-11 22:06:46.248207
# Unit test for function encode
def test_encode():
    actual = encode('ABCD')
    expected = (b'\x41\x42\x43\x44', 4)
    assert actual == expected, (actual, expected)


# Generated at 2022-06-11 22:06:49.907837
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    codecs.getdecoder(NAME)   # type: ignore


# Generated at 2022-06-11 22:06:51.859921
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # Should not throw a LookupError



# Generated at 2022-06-11 22:07:01.448806
# Unit test for function register
def test_register():
    class TestError(Exception):
        """Exception object for testing."""
        pass

    def mock_register(
            codec: codecs.CodecInfo,
    ) -> None:   # type: ignore
        if codec.name != NAME:
            raise TestError(
                'Failed.  The function "register" did not register the '
                'correct codec.'
            )

    test_module = sys.modules[__name__]
    orig_register = codecs.register
    test_module.codecs.register = mock_register
    register()
    test_module.codecs.register = orig_register

register()

# Generated at 2022-06-11 22:07:09.746271
# Unit test for function register
def test_register():
    ____test()
    orig_getdecoder: Optional[Callable[..., codecs.CodecInfo]] = codecs.getdecoder
    codecs.getdecoder = _get_codec_info
    try:
        register()
        # If the register function gets the correct codec object from
        # _get_codec_info, then the getdecoder function should be able to
        # retrieve the codec object for the codec name NAME.
        assert codecs.getdecoder(NAME) is not None
    finally:
        # Reset the getdecoder function to how it was before call to
        # the register function.
        codecs.getdecoder = orig_getdecoder
    register()
    assert codecs.getdecoder(NAME) is not None
    codecs.lookup_error('b64')



# Generated at 2022-06-11 22:07:11.380526
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:15.782939
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError("failed to register codec")


# Generated at 2022-06-11 22:07:21.449931
# Unit test for function register
def test_register():
    """Verify the ``b64`` codec is registered."""
    register()

    def test_getdecoder():
        """Ensure the ``b64`` codec decoder can be retrieved."""
        return codecs.getdecoder(NAME)[0]

    test_getdecoder()


# Generated at 2022-06-11 22:07:34.147789
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

# Generated at 2022-06-11 22:07:38.511542
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    __ = codecs.getdecoder(NAME)  # type: ignore
    codecs.register(_get_codec_info)  # type: ignore
    __ = codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:07:46.639851
# Unit test for function register
def test_register():
    """Test the register function."""
    register()

    # Confirm that our codec is registered.
    dec = codecs.getdecoder(NAME)
    enc = codecs.getencoder(NAME)
    assert dec is not None and enc is not None

    # Unregister our codec and confirm that it has been unregistered.
    try:
        codecs.unregister(NAME)
    except LookupError:
        pass
    dec = codecs.getdecoder(NAME)
    enc = codecs.getencoder(NAME)
    assert dec is None and enc is None



# Generated at 2022-06-11 22:07:48.428245
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:52.599421
# Unit test for function register
def test_register():
    """Test that register functions correctly."""
    register()
    assert NAME in codecs.getdecoder(NAME)
    # codecs.getdecoder returns a codecinfo object.
    # noinspection PyTypeChecker
    assert isinstance(
        codecs.getdecoder(NAME),
        (type(None), codecs.CodecInfo)
    )



# Generated at 2022-06-11 22:08:02.524989
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert codecs.getdecoder(NAME) == _get_codec_info(NAME)
    assert codecs.getencoder(NAME) == _get_codec_info(NAME)
    assert codecs.lookup(NAME) == _get_codec_info(NAME)

    expected = b'\x00\xff\xaa'
    result = encode('AAECAw==')[0]
    assert result == expected
    assert len(result) == len(expected)

    expected = b'\x00\xdd\xaa'
    result = encode('AAECAw==')[0]
    assert result == expected
    assert len(result) == len(expected)

    expected = b'\x00\xdd\xaa'

# Generated at 2022-06-11 22:08:07.600771
# Unit test for function register
def test_register():
    assert (
        codecs.getdecoder(NAME) is not None
    ), 'Failed to register the base64 codec.'


if __name__ == '__main__':
    print()
    print('Registering the base64 codec.')
    print('-' * 78)
    register()
    print('-' * 78)
    print('Successfully registered base64 codec.')

# Generated at 2022-06-11 22:08:10.320126
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    register()
    assert NAME in codecs.getdecoder('b64')
    assert NAME in codecs.getencoder('b64')



# Generated at 2022-06-11 22:08:18.863360
# Unit test for function register
def test_register():
    """Test function `register`.  Asserts that when invoked, the ``b64``
    codec becomes registered.
    """
    codecs.register(_get_codec_info)


# pylint: disable=W0613

# Generated at 2022-06-11 22:08:29.967005
# Unit test for function encode
def test_encode():
    """Unittest for encode function."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def t(expected, given):
        try:
            result, _ = encode(given)
            assert result == expected
        except UnicodeEncodeError:
            assert False
    t(b'', '')
    t(b'M', 'TQ==')
    t(b'Ma', 'TWE=')
    t(b'Man', 'TWFu')
    t(b'Man\n', 'TWFuCg==')
    t(b'Man\nMan', 'TWFuCg\nTWFu')

# Generated at 2022-06-11 22:08:40.848869
# Unit test for function encode
def test_encode():
    # Test class
    class TestClass:
        def __init__(self, value):
            self._value = value

        def __repr__(self):
            return repr(self._value)

        def __str__(self):
            return str(self._value)

        def __bytes__(self):
            return bytes(self._value, 'utf-8')

    # Positive test cases (examples) with interesting inputs

# Generated at 2022-06-11 22:08:44.488025
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:08:55.794599
# Unit test for function encode
def test_encode():

    # Test a proper base64 string encode.
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 10)

    # Test a badly formatted base64 string.
    try:
        encode('YWJjZGVmZ2j')
        assert False, 'Should have raised an exception.'
    except UnicodeEncodeError:
        pass
    except AssertionError:
        raise

    # Test a string that has whitespace in it.
    assert encode('YWJjZGVmZ2g=\n') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZ2g=  ') == (b'abcdefgh', 12)

# Generated at 2022-06-11 22:09:01.647334
# Unit test for function register
def test_register():
    """Unit test for the ``register`` function."""
    # Verify the 'b64' codec is not registered
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the 'b64' codec
    register()

    # Verify the 'b64' codec is registered
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:09:03.810912
# Unit test for function register
def test_register():    # pragma: no cover
    """Unit test for function register."""
    register()


# Generated at 2022-06-11 22:09:07.224816
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    encoded_bytes = encode('HelloWorld')
    assert encoded_bytes == (base64.b64encode(b'HelloWorld'), 10)



# Generated at 2022-06-11 22:09:09.997951
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:09:19.100966
# Unit test for function register
def test_register():  # pylint: disable=R0914
    import codecs
    from test_b64 import (
        _NAME,
        _get_codec_info,
    )
    from b64 import (
        NAME,
        decode,
        encode,
        register,
    )

    assert NAME == _NAME, f'NAME is {NAME!r}, but expected {_NAME!r}'

    # Check that the _get_codec_info() function returns the expected value.
    obj = _get_codec_info(NAME)
    assert obj is not None, 'Expected _get_codec_info() to return non-None'
    assert obj.name == NAME, f'Expected codec.name to be {NAME!r}, but got {obj.name!r}'

# Generated at 2022-06-11 22:09:25.801967
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    try:
        codecs.getdecoder('urf-8')
        raise Exception('Expected LookupError')
    except LookupError:
        pass
    try:
        codecs.getencoder('urf-8')
        raise Exception('Expected LookupError')
    except LookupError:
        pass


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:30.848186
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert NAME in codecs.getdecoder(NAME)

if __name__ == '__main__':
    print(f'[{NAME}] __name__ == __main__')
    test_register()
    print(f'[{NAME}] Test passed.')

# Generated at 2022-06-11 22:09:41.765897
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # See if the codec is registered.
    registered = True
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        registered = False

    # Register the codec if it is not registered.
    if not registered:
        register()



# Generated at 2022-06-11 22:09:43.446230
# Unit test for function register
def test_register():
    """Unit test for function :py:func:`register`."""
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:09:46.585161
# Unit test for function register
def test_register():

    import sys

    register()
    assert NAME in sys.modules['encodings'].aliases
    assert NAME in sys.modules['encodings'].codec_aliases
    assert NAME in sys.modules['encodings'].search_function_cache



# Generated at 2022-06-11 22:09:58.969102
# Unit test for function encode
def test_encode():
    # type: () -> None
    input_str = \
        """
        YW55IGNhcm5hbCBwbGVhcw==
        YW55IGNhcm5hbCBwbGVhc3Vy
        ZS4=
        YW55IGNhcm5hbCBwbGVhc3Vy
        ZS4=
        YW55IGNhcm5hbCBwbGVhc3Vy
        ZS4=
        YW55IGNhcm5hbCBwbGVhcw==
        """

    expect_bytes = \
        b"any carna bles\x80any carna blessure.\x80any carna blessure."\
        b"\x80any carna bles\x80"

    actual_bytes = encode(input_str)[0]

# Generated at 2022-06-11 22:10:00.382903
# Unit test for function register
def test_register():
    codecs.lookup_error(NAME)
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:10:05.557350
# Unit test for function register
def test_register():
    """Test function register"""
    # pylint: disable=W0612
    assert register() is None
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)
    assert codecs.getincrementalencoder(NAME)
    assert codecs.getincrementaldecoder(NAME)
    assert codecs.getreader(NAME)
    assert codecs.getwriter(NAME)



# Generated at 2022-06-11 22:10:08.889135
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhcw==') == (b'any carnal pleas', 22)
    assert encode(b'YW55IGNhcm5hbCBwbGVhcw==') == (b'any carnal pleas', 22)



# Generated at 2022-06-11 22:10:10.551288
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-11 22:10:14.985175
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:10:23.544798
# Unit test for function encode
def test_encode():
    """Test the 'encode' function."""
    assert encode(
        '''YWJjZA=='''
    ) == (b'abcD', 8)

    assert encode(
        '''YWJjZA==='''
    ) == (b'abcD', 10)

    assert encode(
        '''YWJjZA==
        ='''
    ) == (b'abcD', 10)

    assert encode(
        '''YWJjZA==
        ='''
    ) == (b'abcD', 11)

    assert encode(
        '''YWJjZA==
        ='''
    ) == (b'abcD', 12)


# Generated at 2022-06-11 22:10:41.228046
# Unit test for function register
def test_register():
    """
    Unit test of function 'register'
    """
    # pylint: disable=protected-access
    import sys

    # Create a default python state.
    decoders = sys.__stdout__.encoding
    encoders = sys.__stdout__.encoding
    incremental_decoders = sys.__stdout__.encoding
    incremental_encoders = sys.__stdout__.encoding
    stream_readers = []
    stream_writers = []

    # Save the current state.
    sys.setdefaultencoding(decoders, encoders)
    sys.setdefaultincrementaldecoder(decoders, encoders)
    sys.setdefaultincrementalencoder(decoders, encoders)
    sys.setdefaultreader(decoders, encoders)


# Generated at 2022-06-11 22:10:51.740061
# Unit test for function register
def test_register():
    import pytest
    from pytest import fail
    from utils.functional import get_first

    test_tuple = (
        (
            'decoder',
            lambda: get_first(lambda x: x[0] == NAME, codecs.getdecoder(NAME))
        ),
        (
            'encoder',
            lambda: get_first(lambda x: x[0] == NAME, codecs.getencoder(NAME))
        ),
    )
    for name, func in test_tuple:
        try:
            func()
        except LookupError:
            pass
        else:
            fail(f'The {name} already exists. Code should not be registered')
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:10:53.061267
# Unit test for function register
def test_register():
    """Test the codec registration."""
    import codecs

    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:10:56.316238
# Unit test for function register
def test_register():
    """Unit test for the :func:`register` function."""
    # pylint: disable=protected-access
    if NAME not in codecs._cache:
        register()



# Generated at 2022-06-11 22:10:58.077180
# Unit test for function register
def test_register():
    # codecs.getdecoder(NAME)
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:11:04.618411
# Unit test for function register
def test_register():
    # Verify that Python does not have a codec for the 'b64' codec.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the 'b64' codec with Python.
    register()

    # Verify that the 'b64' codec is registered with Python.
    codecs.getdecoder(NAME)   # Should not raise



# Generated at 2022-06-11 22:11:07.139409
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)  # Should not raise a LookupError exception
    codecs.getdecoder(NAME)  # Should not raise a LookupError exception



# Generated at 2022-06-11 22:11:08.532970
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:11:16.325129
# Unit test for function register
def test_register():
    # Verify that the the codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, (
            f'The codec {NAME!r} should not be registered initially.'
        )
    # Register the codec
    register()
    # Verify that the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, (
            f'The codec {NAME!r} was not registered.'
        )

# Generated at 2022-06-11 22:11:22.176225
# Unit test for function register
def test_register():
    from . import codecs as m_codecs  # pylint: disable=W0611
    # pylint: disable=C0415
    from b64_codec.b64_codec import (
        decode,
        encode,
    )
    register()
    codec_info = codecs.lookup(NAME)
    codec_info.decode(b'x')
    codec_info.encode('')



# Generated at 2022-06-11 22:11:57.983709
# Unit test for function register
def test_register():
    """Unit test function to test the function ``register``.  This function
    tests the following:

    1. Import the 'b64codec' module
    2. Register the codec
    3. Check that the codec is registered in the "codecs" module
    4. Check the codecs encode and decode functions.
    5. Remove the codec from the "codecs" module.
    6. Check that the codec is not registered.

    """
    import sys
    import codecs
    from hashlib import sha256
    from os import remove
    from os.path import abspath, dirname, join
    from pathlib import Path
    from tempfile import TemporaryDirectory

    import b64codec


# Generated at 2022-06-11 22:12:00.361850
# Unit test for function register
def test_register():
    """Unit test for function register"""
    name = 'b64'
    register()
    codecs.getdecoder(name)
    codecs.getencoder(name)



# Generated at 2022-06-11 22:12:08.442954
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`b64.encode`."""

# Generated at 2022-06-11 22:12:18.274036
# Unit test for function register
def test_register():
    """Test base64 codec registration."""
    # pylint: disable=C0116
    @static_var('number_of_registrations', 0)
    def codec_info(name: str) -> Optional[codecs.CodecInfo]:
        """Used as a mock function in tests.

        Args:
            name (str): The given name.

        Returns:
            None: if the given name is not 'b64'
            Statically instantiated :obj:`~codecs.CodecInfo`: if
                the given name is 'b64'
        """
        if name != 'b64':
            return None
        # noinspection PyUnresolvedReferences
        # pylint: disable=E0602
        codec_info.number_of_registrations += 1
        # noinspection PyUnresolved

# Generated at 2022-06-11 22:12:28.384001
# Unit test for function encode
def test_encode():
    """Test the :func:`encode` function."""
    # Assert the type of the decoded bytes.
    assert isinstance(
        encode(
            b'YmFzZTY0IGVuY29kZWQ='
        )[0],
        bytes
    )
    # Assert the type of the decoded bytes.
    assert isinstance(
        encode(
            'YmFzZTY0IGVuY29kZWQ='
        )[0],
        bytes
    )
    # Assert the length of the decoded bytes.
    assert len(encode('YmFzZTY0IGVuY29kZWQ=')[0]) == 12
    # Assert the value of the decoded bytes.

# Generated at 2022-06-11 22:12:29.589111
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()



# Generated at 2022-06-11 22:12:34.210610
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # Registering the codec twice is okay.
    register()
    # Verify that the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'Registering the b64 codec failed: {e}'
        ) from e
    return


# Generated at 2022-06-11 22:12:36.373154
# Unit test for function register
def test_register():
    """Unit test for register()"""
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "register() did not work"

# Generated at 2022-06-11 22:12:46.848207
# Unit test for function encode
def test_encode():
    """Ensure the 'encode' function (module level) functions properly."""
    assert encode('QQ==') == (b'A', 4)
    assert encode('YQ==') == (b'a', 4)
    assert encode('eA==') == (b'\x00', 4)
    assert encode('CA==') == (b'\x02', 4)
    assert encode('EQ==') == (b'\x04', 4)
    assert encode('QQ==') == (b'A', 4)
    assert encode('Dg==') == (b'\x10', 4)
    assert encode('wqA=') == (b'4A', 4)
    assert encode('yQA=') == (b'6A', 4)

# Generated at 2022-06-11 22:12:52.163175
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True


# Generated at 2022-06-11 22:13:27.251682
# Unit test for function encode
def test_encode():
    """Unit test for ``encode`` function."""
    decoded = "hello world"
    encoded = "aGVsbG8gd29ybGQ="
    assert encode(encoded)[0] == decoded.encode('utf-8')
    assert encode(encoded, 'ignore')[0] == decoded.encode('utf-8')
    assert encode(encoded, 'replace')[0] == decoded.encode('utf-8')
    assert encode(encoded, 'xmlcharrefreplace')[0] == decoded.encode('utf-8')



# Generated at 2022-06-11 22:13:32.741659
# Unit test for function register
def test_register():
    """Unit test for the ``register`` function."""
    import sys
    import os
    import tempfile
    temp_file_name = tempfile.mktemp()
    registered = False

# Generated at 2022-06-11 22:13:34.340396
# Unit test for function register
def test_register():
    "Unit test to register the b64 codec."
    register()



# Generated at 2022-06-11 22:13:36.451571
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 22:13:45.351252
# Unit test for function register
def test_register():
    # pylint: disable=unused-variable
    # pylint: disable=protected-access
    class FakeRegistry:
        # pylint: disable=unused-variable
        def __init__(self):
            self._cache = {}
            self._known_encoding = set()

    try:
        codecs.CodecInfo  # pylint: disable=pointless-statement
    except AttributeError:
        codecs.CodecInfo = None  # type: ignore

    register()

    if codecs.CodecInfo is None:
        # Python 3.5.3
        assert NAME in codecs._registry._encodings  # type: ignore
    else:
        # Python 3.8.0
        assert NAME in codecs._cache.keys()  # type: ignore



# Generated at 2022-06-11 22:13:48.027855
# Unit test for function register
def test_register():  # pylint: disable=W0613
    """Unit test for the register() function."""
    register()
    assert 'b64' in codecs.lookup('b64')


# Generated at 2022-06-11 22:13:50.327672
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

###############################################################################
# Unit tests

# Generated at 2022-06-11 22:13:55.610369
# Unit test for function register
def test_register():
    """Test function register()."""

    def _test(name_in: str) -> None:
        register()
        obj = codecs.getdecoder(name_in)
        assert isinstance(obj, codecs.CodecInfo)
        assert obj.name == NAME

    _test('')
    _test('b64')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:14:00.564380
# Unit test for function register
def test_register():
    """Unit test for the ``register`` function."""
    # pylint: disable=W0612
    from typing import Dict
    global _get_codec_info

    reg: Dict[str, _get_codec_info] = {}
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return reg.get(name, None)
    register()

# Generated at 2022-06-11 22:14:02.046355
# Unit test for function register
def test_register():
    """Test for function register"""
    register()
    _ = codecs.getdecoder(NAME)