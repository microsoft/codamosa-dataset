

# Generated at 2022-06-11 22:04:35.653919
# Unit test for function register
def test_register():
    """Test for func:``register``."""
    codecs.register(_get_codec_info)
    assert NAME in codecs.getdecoder('b64') # type: ignore


# Generated at 2022-06-11 22:04:42.662419
# Unit test for function register
def test_register():
    """Unit test for function register."""

    # Ensure we have not yet registered this codec.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The {NAME!r} codec has already been registered. '
            f'Can not complete this unit test.'
        )

    # Register the codec.
    register()

    try:
        # Ensure that the codec has been registered properly.
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise AssertionError(
                f'The {NAME!r} codec has failed to register.'
            )
    finally:
        # Un-register the codec.
        codecs.unregister(NAME)

    # Ensure we have un-registered the codec

# Generated at 2022-06-11 22:04:44.816218
# Unit test for function register
def test_register():
    """Test the b64.register function."""
    try:
        decode('dGVzdA==')
    except LookupError:
        register()
        assert decode('dGVzdA==') == ('test', 6)
    else:
        assert decode('dGVzdA==') == ('test', 6)

# Generated at 2022-06-11 22:04:49.424587
# Unit test for function register
def test_register():
    # noinspection PyProtectedMember
    from sys import _getframe, modules
    from types import ModuleType

    # Test the register function by verifying that the object is
    # added to the 'codecs' module dictionary.
    import_module = codecs

    # Remove the 'codecs.b64' object if this module has already been
    # registered with the Python codecs module.
    try:
        delattr(import_module, NAME)
    # Catch AttributeError
    except AttributeError:
        pass

    # Assert that the '_getframe' returns a ModuleType object.
    assert isinstance(
        import_module,
        ModuleType
    ), \
        f'{_getframe().f_code.co_name} expects a {ModuleType} object'

    # Assert that the 'codecs'

# Generated at 2022-06-11 22:04:55.135400
# Unit test for function register
def test_register():
    """Unit test function for function ``register()``."""
    # Unregister the 'b64' codec, then register it.
    codecs.unregister(NAME)

    # Register the 'b64' codec.
    register()

    # Get the codec
    codec = codecs.getdecoder(NAME)
    codec_name = codec.__class__.__name__
    assert codec_name == 'CodecInfo'

    # Unregister the 'b64' codec.
    codecs.unregister(NAME)


# Generated at 2022-06-11 22:04:58.732958
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    assert obj.name == NAME



# Generated at 2022-06-11 22:05:02.458780
# Unit test for function register
def test_register():  # pylint: disable=W0613
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError(f'Codec {NAME!r} is not registered')



# Generated at 2022-06-11 22:05:04.563524
# Unit test for function register
def test_register(): # type: ignore[no-redef]
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:15.782453
# Unit test for function register
def test_register():
    """Test the :func:`~register()` function."""
    # This should be a valid encode

# Generated at 2022-06-11 22:05:17.222820
# Unit test for function register
def test_register():
    """Unit test for :func:`register`"""
    codecs.lookup('b64')


register()

# Generated at 2022-06-11 22:05:22.206077
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:32.473799
# Unit test for function register
def test_register():
    """Unit test for function register.

    Perform the following unit tests for function register.

    * Test that the ``b64`` codec is not yet registered.
    * Test that registering the ``b64`` codec succeeds.
    * Test that registering the ``b64`` codec again raises a warning.
    """
    # Test that the 'b64' codec is not yet registered
    with pytest.raises(LookupError):
        _ = codecs.getdecoder('b64')

    # Test that registering the 'b64' codec succeeds
    register()

    # Test that registering the 'b64' codec again raises a warning
    setup_logging(__name__)
    with pytest.warns(UserWarning):
        register()



# Generated at 2022-06-11 22:05:42.656665
# Unit test for function register
def test_register():
    # Create a codecs original state.
    original_codec_info = codecs.lookup(NAME)

    # Remove the b64 codec from the codecs library.
    codecs.unregister(_get_codec_info)  # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('b64 codec should have been removed')

    # Register the b64 codec.
    register()

    # Test that the b64 codec has been registered.
    codec_info = codecs.lookup(NAME)
    assert codec_info.name == NAME
    assert codec_info.decode == decode  # type: ignore[arg-type]
    assert codec_info.encode == encode  # type: ignore[arg-type]

   

# Generated at 2022-06-11 22:05:48.415957
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    global NAME
    NAME = 'b64'
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, "Could not register 'b64' codec"
    return

# Generated at 2022-06-11 22:05:52.125716
# Unit test for function register
def test_register():
    """Unit test for function :obj:`register`."""
    # Unit test for function register
    from b64codec.test._test_b64_codec import _Test_b64_codec
    _Test_b64_codec.test_register()

# Generated at 2022-06-11 22:05:58.136231
# Unit test for function register
def test_register():
    """Test the register function."""
    # When the codec is not registered
    print("is base64 registered", codecs.lookup('base64'))
    print("is custom base64_codec registered", codecs.lookup('b64'))
    try:
        codecs.getdecoder(NAME)
        assert False, "b64 codec should not be registered"
    except LookupError:
        pass

    # When the codec is registered
    register()
    assert codecs.getdecoder(NAME)
    print("is custom base64_codec registered", codecs.lookup('b64'))

# Generated at 2022-06-11 22:06:08.921605
# Unit test for function encode
def test_encode():
    """Test the :func:`encode` function."""

# Generated at 2022-06-11 22:06:16.153663
# Unit test for function encode

# Generated at 2022-06-11 22:06:20.835755
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    from importlib import reload
    import pytest

    from . import b64

    b64.register()

    with pytest.raises(LookupError) as err:
        reload(b64)
    assert err.match(
        '^cannot import name'
    ) is not None


# Unit tests for function encode

# Generated at 2022-06-11 22:06:33.141625
# Unit test for function register
def test_register():
    """Unit test for :func:`register`."""
    register()


if __name__ == '__main__':

    import codecs
    codecs.register(_get_codec_info)

    def test_b64_in(text: _STR, expected: str) -> None:
        """Test decoding base64 bytes from the given ``text``.

        Args:
            text (str): A string of base64 characters.
            expected(str): The expected base64 decoded text.
        """
        decoded, len_decoded = codecs.decode(text.encode('utf-8'), NAME)
        assert len_decoded == len(text)
        assert decoded.decode('utf-8') == expected


# Generated at 2022-06-11 22:06:40.249957
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered with Python 3."""
    try:
        register()
    except UnicodeEncodeError:
        pass  # Unit tests for the ``b64`` codec.  Not used in production.
    # Tests that the codec is registered with Python.
    codecs.getdecoder(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:43.212103
# Unit test for function register
def test_register():
    """Test the function 'register'."""
    # Register the codec into the system.
    register()

    # Retrieve the codec info
    codec_info = codecs.lookup(NAME)

    # Assert that the decode function is the one we defined.
    assert codec_info.decode is decode

    # Assert that the encode function is the one we defined.
    assert codec_info.encode is encode


# Register the base64 codec into the system.
register()



# Generated at 2022-06-11 22:06:50.070329
# Unit test for function register
def test_register():
    """
    Unit test for function register
    """
    from pytest import raises

    # Register the codec.
    register()

    # Create our own exceptions for testing.
    class MyCustomError(ValueError):
        """A custom exception for testing."""

    class MyCustomCleanupWhitespaceError(ValueError):
        """A custom exception for testing."""

    class MyCustomBase64DecodeError(ValueError):
        """A custom exception for testing."""

    # Create some variables for testing.

# Generated at 2022-06-11 22:06:56.522954
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is decode


if __name__ == "__main__":
    # Unit test for function register
    test_register()
    assert encode('\n'.join(['YmFzZTY0', 'bXVsdGktbGluZQ=='])) == b'base64\nmulti-line'

# Generated at 2022-06-11 22:07:03.207764
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj.name == NAME
    assert decode("YW55IGNhcm5hbCBwbGVhcw",) == ('any carnal pleas', 27)
    assert encode("any carnal pleas") == (b'YW55IGNhcm5hbCBwbGVhcw',)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:03.822875
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-11 22:07:11.028242
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8=') == (b'Hello', 6)
    assert encode('SGVsbG8K') == (b'Hello', 6)
    assert encode('SGVsbG8K  ') == (b'Hello', 6)
    assert encode('  SGVsbG8K  ') == (b'Hello', 6)
    assert encode(' SGVsbG8K') == (b'Hello', 6)
    assert encode('SGVsbG8K\n') == (b'Hello', 6)
    assert encode('\nSGVsbG8K') == (b'Hello', 6)
    assert encode('\nSGVsbG8K\n') == (b'Hello', 6)

# Generated at 2022-06-11 22:07:22.043639
# Unit test for function register
def test_register():
    """Unit test for function register."""
    r"""
    Register the ``b64`` codec with Python.

    >>> test_register()
    """
    register()

    # Check the ``decode`` function
    decoder = codecs.getdecoder(NAME)
    assert NAME == decoder(
        b'c2V2ZW5maWxsZXJzb25l',
    )[0]

    # Check the encode function
    encoder = codecs.getencoder(NAME)
    assert b'c2V2ZW5maWxsZXJz' == encoder(
        'sevenfillersone',
    )[0]

# Generated at 2022-06-11 22:07:26.983958
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME)
    assert codecs.lookup_error(NAME)


# Generated at 2022-06-11 22:07:35.331601
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

    # Test 1: Assert function decode returns the expected value.
    actual = encode('')
    expected = (b'', 0)
    assert actual == expected, (expected, actual)

    # Test 2: Assert function decode returns the expected value.
    actual = encode('H')
    expected = (b'SA==', 1)
    assert actual == expected, (expected, actual)

    # Test 3: Assert function decode returns the expected value.
    actual = encode('Ho')
    expected = (b'SG8=', 2)
    assert actual == expected, (expected, actual)

    # Test 4: Assert function decode returns the expected value.
    actual = encode('Hod')
    expected = (b'SG9k', 3)
    assert actual == expected, (expected, actual)

   

# Generated at 2022-06-11 22:07:40.327695
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:41.865315
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:52.208299
# Unit test for function encode

# Generated at 2022-06-11 22:07:54.619078
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    try:
        register()
        codecs.lookup(NAME)
    except LookupError:
        print(f'{NAME} codec failed registration.')
        raise

# Generated at 2022-06-11 22:07:56.013967
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:08:00.342452
# Unit test for function register
def test_register():
    from sys import modules
    from codecs import lookup

    register()

    # Verify that the 'b64' codec was registered.
    codec_name = lookup(NAME).name
    assert codec_name == NAME

    # Verify that the 'b64' codec was registered to the 'codecs' module.
    codecs_module = modules[__name__]
    assert hasattr(codecs_module, 'getdecoder')
    assert hasattr(codecs_module, 'getencoder')
    assert hasattr(codecs_module, 'register')

# Unit tests for function decode

# Generated at 2022-06-11 22:08:04.033262
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('') == (b'', 0)
    assert encode('this is a test') == (b'this is a test', 14)
    assert encode('this is a test\n') == (b'this is a test', 14)

# Generated at 2022-06-11 22:08:15.337533
# Unit test for function encode
def test_encode():
    """Test conversion of a base64 character string into bytes"""

    # Test with a simple base64 encoded string
    data = 'aGVsbG8gd29ybGQ='
    result = encode(data)
    assert result[0] == b'hello world'
    assert result[1] == len(data)

    # Test with a simple base64 encoded string with trailing whitespace
    data = 'aGVsbG8gd29ybGQ= \n'
    result = encode(data)
    assert result[0] == b'hello world'
    assert result[1] == len(data) - 1

    # Test with a simple base64 encoded string with leading whitespace
    data = ' \n aGVsbG8gd29ybGQ='
    result = encode(data)

# Generated at 2022-06-11 22:08:23.660491
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode(  # type: ignore[arg-type, call-arg]
        'QQ=='
    )[0] == b'A'

    # The character '=' is not a valid base64 character.
    try:
        # The following line raises an exception.
        encode(  # type: ignore[arg-type, call-arg]
            'Q==='
        )
    except UnicodeEncodeError as e:
        assert e.reason == (
            'b64: b\'Q===\' is not a proper bas64 character string: '
            'Incorrect padding'
        )
    else:
        assert False



# Generated at 2022-06-11 22:08:32.378648
# Unit test for function register
def test_register():
    from sys import modules
    from inspect import currentframe
    from importlib import reload

    # Walk up the stack until the function main was found.
    call_frame = currentframe()
    while call_frame.f_code.co_name != 'main':
        call_frame = call_frame.f_back
    test_locals = call_frame.f_locals

    # Save the current 'modules[__name__]' module and reload it.
    old_module = modules[__name__]
    reload(modules[__name__])

    # Assert that the codec has been registered.
    try:
        codecs.getdecoder(NAME)
        register_status = True
    except LookupError:
        register_status = False
    assert register_status is True

    # Restore the old 'modules[__name__]' module


# Generated at 2022-06-11 22:08:36.636448
# Unit test for function register
def test_register():
    """Test the function register by making sure that the  ``b64`` codec
    is registered."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:40.884525
# Unit test for function register
def test_register():
    """Unit test for the ``register`` function."""
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getencoder(NAME)     # type: ignore
    assert codecs.getdecoder(NAME)     # type: ignore
    assert codecs.getincrementalencoder(NAME)     # type: ignore
    assert codecs.getincrementaldecoder(NAME)     # type: ignore



# Generated at 2022-06-11 22:08:50.337113
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    # Register the codec.
    register()

    # After registration this should not raise a LookupError exception.
    # Get the decoder function and assert that it is our expected function.
    decoder = codecs.getdecoder(NAME)
    assert decoder == decode  # type: ignore[arg-type]

    # Get the encoder function and assert that it is our expected function.
    encoder = codecs.getencoder(NAME)
    assert encoder == encode  # type: ignore[arg-type]



# Generated at 2022-06-11 22:09:01.443183
# Unit test for function encode
def test_encode():
    """Unit test for function :meth:`encode`."""
    # Test that encode/decode are inverses
    test_str = 'I am a test'
    assert str(test_str) == decode(encode(test_str)[0])[0]

    # Test that encode() runs
    assert encode(test_str)  # type: ignore[no-return]

    # Test for error
    test_str = 'I am a test, but I am an invalid base64 string'
    with pytest.raises(UnicodeEncodeError):
        encode(test_str)  # type: ignore[no-return]

    test_str = 'I am a test with whitespace'
    expected = '''
I am a te
st with whitespace
'''

# Generated at 2022-06-11 22:09:06.078805
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    decoder = codecs.getdecoder(NAME)
    assert isinstance(decoder, codecs.CodecInfo)
    assert NAME == decoder.name



# Generated at 2022-06-11 22:09:13.378676
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    from unittest import TestCase
    from contextlib import contextmanager

    from . import _mock_stdout

    class Test_register(TestCase):
        """Unit test for function register."""

        def test_register(self):
            """Ensure the codec is registered with Python."""
            with self.redirect_stdout() as mock:
                register()
                self.assertIn(
                    ('<module \'{}\' from '
                     '\''.format(NAME)
                     ),
                    mock.stdout.getvalue()
                )


# Generated at 2022-06-11 22:09:15.669245
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    assert codecs.getdecoder(NAME).__name__ == NAME  # type: ignore

# Generated at 2022-06-11 22:09:21.827305
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('{!r} codec is already registered'.format(NAME))
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            '{!r} codec could not be registered: {}'.format(NAME, e)
        )
    finally:
        codecs.name_mapping.pop(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:32.270277
# Unit test for function register
def test_register():
    """Test function register_codec for Python."""
    register()
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    def _test_main():
        """Test function b64 for Python."""
        register()
        assert codecs.decode(  # type: ignore[arg-type]
            'QQ==',
            encoding=NAME,
        ) == '1'

        assert codecs.encode(  # type: ignore[arg-type]
            1,
            encoding=NAME,
        ) == 'MQ=='

        assert codecs.decode(  # type: ignore[arg-type]
            'QUJDZAA=',
            encoding=NAME,
        ) == 'ABC'


# Generated at 2022-06-11 22:09:37.860590
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # Test that an exception is raised when the codec cannot be registered.
    with patch('codecs.getdecoder', side_effect=LookupError):
        with expect.raises(AssertionError):
            codecs.register(_get_codec_info)

    # Test that no exception is raised when the codec can be registered.
    with patch('codecs.getdecoder', side_effect=KeyError):
        codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:09:45.220985
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert NAME in codecs.getdecoder(NAME)()[0]



# Generated at 2022-06-11 22:09:51.161974
# Unit test for function register
def test_register():
    register()
    if 'b64' in codecs.__dict__['_cache']:
        codecs.__dict__['_cache'].pop('b64')
    assert 'b64' not in codecs.__dict__['_cache']
    register()
    assert 'b64' in codecs.__dict__['_cache']
    import b64
    print(b64)
    b64.register()
    if 'b64' in codecs.__dict__['_cache']:
        codecs.__dict__['_cache'].pop('b64')
    assert 'b64' not in codecs.__dict__['_cache']
    b64.register()
    assert 'b64' in codecs.__dict__['_cache']



# Generated at 2022-06-11 22:09:53.614311
# Unit test for function register
def test_register():
    """Unit test for the register function."""

    import b64
    import sys

    b64.register()
    assert NAME in sys.modules['encodings']

# Generated at 2022-06-11 22:09:56.462510
# Unit test for function register
def test_register():
    register()
    assert 'b64' in codecs.encode.__code__.co_varnames


codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:10:06.523580
# Unit test for function encode
def test_encode():
    """Unit test for the ``encode`` function."""


# Generated at 2022-06-11 22:10:15.276143
# Unit test for function register
def test_register():
    """Unit test for function register"""
    import io
    import shutil
    from contextlib import redirect_stdout
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """Unit test for function register"""

        def test_register(self):
            """Unit test for function register"""
            f_name = 'test_register.out'
            encoding = NAME
            test_data = b'Test data'
            expected = 'VGVzdCBkYXRh'
            output_str = 'No Output'
            modified_path = False

# Generated at 2022-06-11 22:10:20.901080
# Unit test for function register
def test_register():
    """
    Test the 'register()' function.
    """
    from base64 import b64decode, b64encode
    s = 'aGVsbG8='
    assert b64encode(b64decode(s)) == s.encode('utf-8')

    register()
    try:
        codecs.lookup_error('strict')
    except LookupError:
        pass
    else:
        assert False

# Generated at 2022-06-11 22:10:31.773860
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Register the 'b64' codec if not already registered
    register()

    # Attempt to get the 'b64' codec decoder
    decoder = codecs.getdecoder(NAME)

    # Verify the codec's decode method is the expected decode method
    assert decoder(b'abc') == ('YWJj', 3)
    assert decoder(b'YWJj', errors='strict') == ('YWJj', 3)

    # Attempt to get the 'b64' codec encoder
    encoder = codecs.getencoder(NAME)

    # Verify the codec's encoder method is the expected encoder method
    assert encoder(b'YWJj') == (b'YWJj', 3)

# Generated at 2022-06-11 22:10:43.945591
# Unit test for function encode

# Generated at 2022-06-11 22:10:45.616569
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec can be registered into Python."""
    register()
    code_info = codecs.getdecoder(NAME)
    assert code_info.name == NAME



# Generated at 2022-06-11 22:11:03.267322
# Unit test for function register
def test_register():
    register()
    codecs.encode('this is a test', 'b64')
    codecs.decode('dGhpcyBpcyBhIHRlc3Q=', 'b64')

# Generated at 2022-06-11 22:11:10.115859
# Unit test for function register
def test_register():
    """Unit test for the function :func:`register`"""
    from dataclasses import dataclass

    from unittest import TestCase

    from b64codec import b64encode
    from b64codec import b64decode

    @dataclass
    class _Mydata(object):
        data: int

    def _encode(data: _Mydata) -> str:
        return b64encode(data)

    def _decode(text: str) -> _Mydata:
        return b64decode(text)

    class _MyTests(TestCase):
        def test_register(self):
            register()
            self.assertEqual(
                'Cg==',
                _encode('\x00')
            )


# Generated at 2022-06-11 22:11:10.859804
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:11:16.452809
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'The b64 codec should not be registered'
    register()
    # noinspection PyUnresolvedReferences
    tmp = codecs.getdecoder(NAME)
    assert tmp is not None, 'The b64 codec is not loaded'


# Generated at 2022-06-11 22:11:20.231436
# Unit test for function register
def test_register():  # pragma: nocover
    """Test the function :func:`register`."""
    b64 = codecs.getdecoder(NAME)
    assert b64
    assert b64(b'amF2YSArIHB5dGhvbiA9IGphdmFzY3JpcHQ=') == ('java + python = javascript', 64)

# Generated at 2022-06-11 22:11:23.996236
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    assert codecs.getdecoder(NAME)


# Unit tests for function decode

# Generated at 2022-06-11 22:11:30.096385
# Unit test for function encode
def test_encode():
    """Test function encode

    Notes:
        "b64" is an alias for function encode.
    """
    # Test encode with non-base64 byte string
    try:
        bytes, len_ = encode('YWJjQDIzRDQ=')
    except UnicodeEncodeError as uee:
        assert str(uee) == (
            "'YWJjQDIzRDQ=' is not a proper bas64 character string: "
            "Incorrect padding"
        )
    else:
        raise RuntimeError('The non-base64 string was able to be encoded.')

    # Test with a proper base64 string
    bytes, len_ = encode('YWJjQDIzRDQ=\n')
    assert len_ == 12
    assert bytes == b'abcd@23D4'

    # Test with a proper base

# Generated at 2022-06-11 22:11:31.878960
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:11:39.587256
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    # pylint: disable=W0612
    global encode, decode
    import base64
    from binascii import Error

    # Capture the original 'encode', and 'decode' functions.
    b64_encode = encode
    b64_decode = decode

    print(f"Testing function 'register'")
    # noinspection PyStatementEffect
    """
    Test that the original functions are not 'None'
    """
    assert b64_encode is not None
    assert b64_decode is not None

    # Unregister the codec
    try:
        codecs.unregister(NAME)  # type: ignore
    except LookupError:
        pass

    # Test that the original functions are still not 'None'
    assert b64_encode is not None


# Generated at 2022-06-11 22:11:47.997012
# Unit test for function encode
def test_encode():
    # Test normal operation
    good_text = '''
    AAABBBBCC
    --
    '''
    expected_bytes = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f' + \
                    b'\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f' + \
                    b' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_' + \
                    b

# Generated at 2022-06-11 22:12:15.861459
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)      # type: ignore

# Generated at 2022-06-11 22:12:17.262699
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:12:25.857891
# Unit test for function register
def test_register():
    import codecs

    # Delete the codec if it is already loaded.
    try:
        del codecs.decode._cache[NAME]
    except LookupError:
        pass

    # Check that the codec is not loaded.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False

    register()

    # Check that the codec is loaded.
    try:
        assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)
    except LookupError:
        assert False


# noinspection PyPep8Naming

# Generated at 2022-06-11 22:12:28.338567
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    codecs.getdecoder(NAME)


# pylint: disable=C0103,C0111

# Generated at 2022-06-11 22:12:36.318678
# Unit test for function register
def test_register():
    """Ensure that the 'register'() function registers the correct codec."""
    register()
    codec = codecs.getdecoder(NAME)
    assert codec.decode(b'') == ('', 0)
    assert codec.decode(b'YQ==') == ('a', 4)
    assert codec.decode(b'YWI=') == ('ab', 4)
    assert codec.decode(b'YWJj') == ('abc', 4)
    assert codec.encode('a') == (b'YQ==', 1)
    assert codec.encode('ab') == (b'YWI=', 2)
    assert codec.encode('abc') == (b'YWJj', 3)


# Generated at 2022-06-11 22:12:40.566462
# Unit test for function register
def test_register():

    # Register the codec.
    register()

    # Retrieve the codec information and make sure it is the same as the
    # one set during the registration.
    codec_info = codecs.getdecoder(NAME)
    assert codec_info.name == NAME
    assert codec_info.decode == decode
    assert codec_info.encode == encode

# Generated at 2022-06-11 22:12:46.708070
# Unit test for function register
def test_register():
    """Test function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass

    codecs.register(_get_codec_info)     # type: ignore

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

    pass


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:12:50.501717
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.lookup(NAME) is not None


encode.__doc__  # disable=pointless-statement



# Generated at 2022-06-11 22:12:53.687884
# Unit test for function register
def test_register():
    """Unit test for 'register' function."""
    from . import test_codec  # pylint: disable=redefined-outer-name

    test_codec.test_register(NAME, register)

# Generated at 2022-06-11 22:13:00.778769
# Unit test for function register
def test_register():
    expected = codecs.CodecInfo(  # type: ignore
        name=NAME,
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )
    codecs.register(_get_codec_info)   # type: ignore
    actual = codecs.getdecoder(NAME)   # type: ignore
    assert actual == expected


# Generated at 2022-06-11 22:14:02.560484
# Unit test for function register
def test_register():
    test_codecs = (
        codecs.getdecoder(NAME),
        codecs.getencoder(NAME),
    )
    for codec in test_codecs:
        with pytest.raises(LookupError):
            codec()

    register()
    test_codecs = (
        codecs.getdecoder(NAME),
        codecs.getencoder(NAME),
    )
    for codec in test_codecs:
        with pytest.raises(AssertionError):
            codec()


test_register()

# Generated at 2022-06-11 22:14:08.062289
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    in_bytes = b'a\xde\xff\x00\x9f\n'
    in_str = 'a\xde\xff\x00\x9f\n'
    in_str_b64 = 'YmZgYGB6fn4K'
    enc_bytes, _ = encode(in_str)
    assert enc_bytes == in_bytes, 'Base64 encoder failed'
    enc_bytes, _ = encode(in_str_b64)
    assert enc_bytes == in_bytes, 'Base64 encoder failed'


# Generated at 2022-06-11 22:14:17.851094
# Unit test for function encode
def test_encode():
    result = encode("dGhpcyBpcyBub3QgYmFzZTY0Cg==")
    assert result == (b'this is not base64\n', 20)
    result = encode("dGhpcyBpcyBub3QgYmFzZTY0Cg", errors="strict")
    assert result == (b'this is not base64\n', 20)
    result = encode("dGhpcyBpcyBub3QgYmFzZTY0Cg=", errors="strict")
    assert result == (b'this is not base64\n', 20)
    result = encode("dGhpcyBpcyBub3QgYmFzZTY0Cg==", errors="strict")

# Generated at 2022-06-11 22:14:19.258891
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:14:28.322606
# Unit test for function encode
def test_encode():
    # pylint: disable=missing-docstring
    text = '''
    VGhpcyBpcyBhIG1lc3NhZ2Ugd2hpY2ggc2hvdWxkIGJlIHJlYWQgYnkgYW4gaW50ZXJuYWwgZGVhbGVy
    IG1hbmFnZXIgYW5kIG1lcmVjb25kZWQgYnkgZGF0YSB0aGF0IGlzIG1hcmtlZCBieSB0aGUgZGVh
    bGVyY29uZm9ybWVyLg==
    '''
    data, count = encode(text)
    assert count == len(text)

# Generated at 2022-06-11 22:14:32.051297
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore


# Test the '_get_codec_info' function.