

# Generated at 2022-06-11 22:04:36.045162
# Unit test for function register
def test_register():
    """Register the ``b64`` codec for the tests."""
    return register()



# Generated at 2022-06-11 22:04:37.954177
# Unit test for function register
def test_register():
    """Test the ``register()`` function."""
    register()
    assert NAME in codecs.getdecoder(NAME).name



# Generated at 2022-06-11 22:04:41.874721
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj

# Generated at 2022-06-11 22:04:48.111088
# Unit test for function register
def test_register():
    """Test register functions"""
    register()
    b = codecs.getdecoder(NAME)
    assert b(b'aGVsbG8gd29ybGQ=') == ('hello world', 13)
    a = codecs.getencoder(NAME)
    assert a(b'hello world') == (b'aGVsbG8gd29ybGQ=', 11)

# Generated at 2022-06-11 22:04:54.848207
# Unit test for function register
def test_register():
    """Unit test of function ``register``."""
    register()
    # Now try to register again.  It should ignore the request.
    register()

    try:
        decoder_obj = codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'Cannot find decoder for {NAME!r}: {e}') from e

    try:
        encoder_obj = codecs.getencoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'Cannot find encoder for {NAME!r}: {e}') from e

# Generated at 2022-06-11 22:05:05.946420
# Unit test for function register
def test_register():   # pylint: disable=W0611
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)

# pylint: enable=W0613


if __name__ == '__main__':
    register()
    print(f'NAME={NAME}')
    a = 'Hello World'
    print(f'encode(a) = {encode(a)}')
    b = base64.b64encode(a.encode('utf-8'))
    print(f'base64.b64encode(a.encode("utf-8")) = {b}')
    c = base64.b64decode(b)
    print(f'base64.b64decode(b) = {c}')
    d = c.decode('utf-8')


# Generated at 2022-06-11 22:05:08.418181
# Unit test for function register
def test_register():
    """Unit test for function :meth:`register`

    This unit test verifies that the codec will not register twice.
    """
    register()
    register()

# Generated at 2022-06-11 22:05:17.668524
# Unit test for function register
def test_register():
    """Test the register() function."""
    import sys
    import builtins

    #
    # Get the codec lookup table before the registration.
    #
    old_decoders = sys.getdecoders()
    old_encoders = sys.getencoders()

    old_decoders = {
        x[0].lower(): x[1]
        for x in old_decoders
    }
    old_encoders = {
        x[0].lower(): x[1]
        for x in old_encoders
    }

    #
    # Register the b64 codec to Python.
    #
    register()

    #
    # Get the codec lookup table after the registration.
    #
    new_decoders = sys.getdecoders()
    new_encoders = sys.get

# Generated at 2022-06-11 22:05:27.387052
# Unit test for function encode
def test_encode():
    assert encode('c29yZWltZW50YWw=') == (b'soreimental', len('soreimental'))
    assert encode('c2VydmVyIGxpY2Vuc2U=') == (b'server license', len('server license'))
    assert encode('dGhlIGZpbmVyIGlzIGZhbWlseQ==') == (b'the finer is family', len('the finer is family'))
    assert encode('aGV5IGFyZSB0aGUgYmVzdCE=') == (b'hey are the best!', len('hey are the best!'))
    assert encode('dG8gYmUgb24gdGhlIG1hcw==') == (b'to be on the map', len('to be on the map'))
   

# Generated at 2022-06-11 22:05:29.547356
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    # Should not throw an exception
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:05:36.011440
# Unit test for function register
def test_register():
    """Test function register."""
    codecs.register(_get_codec_info)  # type: ignore


if __name__ == '__main__':
    unit_test.main()

# Generated at 2022-06-11 22:05:38.805176
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    assert codecs.lookup(NAME) == _get_codec_info(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:41.097417
# Unit test for function register
def test_register():
    """Test the register function.
    """
    register()
    # Check that the codec is registered.
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:44.269860
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    register()
    assert NAME in codecs.__codec_aliases__  # type: ignore[attr-defined]


# Generated at 2022-06-11 22:05:50.319094
# Unit test for function register
def test_register():
    """Unit test for function register.

    Asserts:
        The assertion will fail if the function register fails to register
        the 'b64' codec.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

register()

# Generated at 2022-06-11 22:05:52.844108
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    # pylint: disable=W0212
    codecs.__all__ = []
    register()
    assert NAME in codecs.__all__



# Generated at 2022-06-11 22:05:55.155541
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    print('Testing register()')
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:02.030335
# Unit test for function register
def test_register():
    """Test the function: :py:func:`register`."""
    tests = [
        {'name': NAME, 'expect': NAME},
    ]
    for test in tests:
        try:
            codecs.getdecoder(test['name'])
        except LookupError:
            codecs.register(_get_codec_info)

        name = codecs.lookup(test['name']).name
        assert name == test['expect']



# Generated at 2022-06-11 22:06:04.086774
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:06.350800
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

# Generated at 2022-06-11 22:06:21.191169
# Unit test for function encode
def test_encode():
    """Run unit test for ``b64.encode``"""
    print('Begin: test_encode()')
    text = 'This is some text'
    result, length = encode(text)
    print(f'text={text!r}')
    print(f'result={result!r}')
    print(f'length={length}')
    assert result == text.encode('ascii')
    assert length == len(text)

    text = ('YQo=' + '\n' +
            'aW8g' + '\n' +
            'YWxs' + '\n' +
            'IGRv' + '\n' +
            'dAo=' + '\n')
    result, length = encode(text)
    print(f'text={text!r}')
   

# Generated at 2022-06-11 22:06:28.711524
# Unit test for function register
def test_register():
    from pytest import raises

    with raises(LookupError):
        _ = codecs.getdecoder(NAME)

    register()
    _ = codecs.getdecoder(NAME)

    with raises(LookupError):
        _ = codecs.getencoder(NAME)

    register()
    _ = codecs.getdecoder(NAME)
    _ = codecs.getencoder(NAME)



# Generated at 2022-06-11 22:06:35.648218
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert (
        decoder('aGVsbG8gd29ybGQ=') == ('hello world', 14)
    )
    encoder = codecs.getencoder(NAME)
    assert (
        encoder('hello world') == (b'aGVsbG8gd29ybGQ=', 11)
    )


# register()

# def test_decode():
#     assert (
#         decode(b'0123456789abcdef', '')
#         == ('MDEyMzQ1Njc4OWFiY2RlZg==', 16)
#     )
#
#
# def test_encode():
#     assert (
#         encode('MDEyMzQ1Njc4OW

# Generated at 2022-06-11 22:06:39.769717
# Unit test for function register
def test_register():
    """Test the function register."""
    codecs.register(_get_codec_info)
    try:
        assert codecs.getdecoder(NAME)
        assert codecs.getencoder(NAME)
    finally:
        codecs.unregister(NAME)


register()

# Generated at 2022-06-11 22:06:43.553535
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass  # ignore error
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:50.211720
# Unit test for function register
def test_register():
    # pylint: disable=protected-access
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
    # Test the function in 'codecs' module.
    # This test is run so that this module is imported.
    try:
        # Get the dictionary that maps the codec names to codec callables.
        codec_dict = codecs.__dict__['_codec_search_path']
    except KeyError:
        # The codec_dict does not exist.  This may be the result of an
        # import of an older version of the 'codecs' module.
        # Regardless the cause, this is an error.
        raise

# Generated at 2022-06-11 22:07:02.084047
# Unit test for function encode
def test_encode():
    """Test function encode of module b64_codec_base64."""
    codecs.register(_get_codec_info)
    assert encode("AA==")[0] == b'\x00'
    assert encode("AAA=")[0] == b'\x00\x00'
    assert encode("AAAA")[0] == b'\x00\x00\x00'
    assert encode("/////w==")[0] == b'\xeb\x5d'
    assert encode("/////w")[0] == b'\xeb'
    assert encode("/////w/")[0] == b'\xeb'
    assert encode("/////w/=")[0] == b'\xeb'
    assert encode("/////w//")[0] == b'\xeb'
    assert encode

# Generated at 2022-06-11 22:07:04.479819
# Unit test for function register
def test_register():
    """Unit test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


# Generated at 2022-06-11 22:07:12.230513
# Unit test for function register
def test_register():
    # pylint: disable=protected-access
    import copy
    import typing
    import b64
    orig_dict = copy.deepcopy(codecs._codecs_cn.cache)
    b64.register()
    new_dict = codecs._codecs_cn.cache
    orig_dict[b64.NAME] = new_dict[b64.NAME]
    assert orig_dict == new_dict
    expected = typing.cast(codecs.CodecInfo, orig_dict[b64.NAME])
    actual = codecs.getdecoder(b64.NAME)
    assert actual is expected



# Generated at 2022-06-11 22:07:18.575370
# Unit test for function register
def test_register():
    """Test function ``register`` in module ``_codecs``."""
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:26.582590
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)   # type: ignore
    assert decoder



# Generated at 2022-06-11 22:07:29.929162
# Unit test for function register
def test_register():
    """Test for function 'register'."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    finally:
        codecs.set_decoding_error_handler(None)  # type: ignore



# Generated at 2022-06-11 22:07:32.509310
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


register()
del register

# Generated at 2022-06-11 22:07:41.237571
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    from base64 import b64encode

    original = sys.getdefaultencoding()
    try:
        sys.getdefaultencoding = lambda: 'b64'
        codecs.register(_get_codec_info)
        bytes_ = b'hello world'
        result = b64encode(bytes_)
        assert result == b'aGVsbG8gd29ybGQ='
        assert not result.isascii()
        result = bytes_.decode('b64')
        assert result == ('hello world')
    finally:
        sys.getdefaultencoding = original



# Generated at 2022-06-11 22:07:43.544208
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__
    register()
    assert NAME in codecs.__dict__



# Generated at 2022-06-11 22:07:46.738384
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:47.817639
# Unit test for function register
def test_register():
    assert not register()

# Generated at 2022-06-11 22:07:49.936446
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup('b64')[0] == decode



# Generated at 2022-06-11 22:07:52.320024
# Unit test for function register
def test_register():
    """Unit test for the function ``register()``."""
    register()
    # Verify that the codec exists.
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:54.478931
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    # codecs.lookup(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:11.110525
# Unit test for function register
def test_register():
    """Test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail("Could not find the 'b64' codec")



# Generated at 2022-06-11 22:08:19.840698
# Unit test for function encode
def test_encode():
    test_string = (
        "Man is distinguished, not only by his reason, but by this singular passion from other animals, which "
        "is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of "
        "knowledge, exceeds the short vehemence of any carnal pleasure."
    )

# Generated at 2022-06-11 22:08:30.580287
# Unit test for function encode
def test_encode():
    """Test the function `~codecs.encode`."""
    # Basic tests
    assert encode("YQ==") == (b"a", 4)
    assert encode("YWI=") == (b"ab", 4)
    assert encode("YWJj") == (b"abc", 4)
    assert encode("YWJjZA==") == (b"abcd", 8)

    # Whitespace tests.
    assert encode(" YQ== ") == (b"a", 4)
    assert encode(" YQ==") == (b"a", 4)
    assert encode("YQ== ") == (b"a", 4)
    assert encode("  YQ =\n= ") == (b"a", 4)

    # Tests with non-base64 characters
    assert encode("YQ==a")[0]

# Generated at 2022-06-11 22:08:34.623997
# Unit test for function register
def test_register():
    """Unit test for the function ``register``."""
    register()
    try:
        codecs.getdecoder("b64")
    except LookupError:
        raise AssertionError(
            f"codecs.getdecoder('b64') should not throw a LookupError")


# Unit Test for the decode function.

# Generated at 2022-06-11 22:08:36.961891
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:39.092835
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:08:40.378380
# Unit test for function register
def test_register():
    """Unit test for register"""
    register()
    assert NAME in codecs.getdecoder("b64")


# Generated at 2022-06-11 22:08:44.152843
# Unit test for function register
def test_register():
    """Test the :func:`~register` function."""
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:08:51.344835
# Unit test for function register
def test_register():
    """Test the register() function."""
    # Get a list of codecs at the beginning of this function.
    codecs_str = codecs.__all__

    # Test the register function.
    register()

    # Ensure that the 'b64' codec exists.
    codecs_str_after_register = codecs.__all__
    assert NAME in codecs_str_after_register
    assert len(codecs_str_after_register) == len(codecs_str) + 1



# Generated at 2022-06-11 22:08:55.731718
# Unit test for function register
def test_register():
    """Test the b64_codec.register() function."""
    def _test():
        """Function to unit test the b64_codec.register() function."""
        # Register the codec.
        register()
        # Test the codec.
        text = 'aGVsbG8gYmFzZTY0IGNvZGluZw=='
        expected = 'hello base64 coding'
        decoded = text.encode('utf-8').decode(NAME)
        if decoded != expected:
            raise ValueError(
                f"decode() failed.  Expected: '{expected}'.  Actual: "
                f"'{decoded}'."
            )
        text = 'hello base64 coding'

# Generated at 2022-06-11 22:09:27.950135
# Unit test for function register
def test_register():
    # Reset Python Codec Registry
    codecs.registered_search_functions.clear()   # type: ignore
    codecs.__init__()
    # Make sure the 'b64' codec is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)   # type: ignore
    # Register the 'b64' codec
    register()
    # Ensure the 'b64' codec was registered.
    decode_func = codecs.getdecoder(NAME)   # type: ignore
    assert decode_func == decode, 'decode_func'


# Generated at 2022-06-11 22:09:31.714756
# Unit test for function register
def test_register():
    """
    >>> test_register()
    """
    import sys
    from types import ModuleType

    module = sys.modules[__name__]
    if isinstance(module, ModuleType):
        register()
        register()



# Generated at 2022-06-11 22:09:39.334024
# Unit test for function register
def test_register():
    """Unit test for function register"""
    from re import compile as re_compile

    # First unregister the 'b64' codec to make sure it is not being used.
    codecs.lookup(('b64',))

    # Register the 'b64' codec
    register()

    # Test the 'b64' codec.
    pat = re_compile(
        r'\s*"([A-Za-z0-9+/\n]*)"\s*:\s*"([A-Za-z0-9+/=]*)"'
    )
    for m in map(pat.match, TEST_TABLE_STR.splitlines()):
        assert m is not None
        text = codecs.decode(m.group(1), 'b64')

# Generated at 2022-06-11 22:09:42.800680
# Unit test for function register
def test_register():
    import codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:09:45.978916
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()

    coder = codecs.getdecoder(NAME)
    assert coder[0] == decode
    coder = codecs.getencoder(NAME)
    assert coder[0] == encode


# Generated at 2022-06-11 22:09:49.624352
# Unit test for function register
def test_register():
    """Test the function :obj:`~b64f.register`"""
    register()
    assert codecs.getdecoder(NAME), "CodecInfo not found in codecs."



# Generated at 2022-06-11 22:09:52.460726
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:56.102553
# Unit test for function register
def test_register():
    """Ensure that the :obj:`b64` codec module is registered with python."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:10:06.287014
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    obj = codecs.getdecoder(NAME)
    assert obj is not None


# Unit tests for the 'b64' codec.
#
#     NOTE:
#         b64 is identical to base64 except the trailing equals sign
#         is dropped.
#
#     .. seealso::
#         The Python standard library's ``base64`` module.
#
#     .. seealso::
#         The Python standard library's ``base64_codec`` codec.
#
#     .. seealso::
#         The Python standard library's ``base64_codec`` codec works
#         on lines.  The 'b64'

# Generated at 2022-06-11 22:10:09.753662
# Unit test for function register
def test_register():
    """Test the function `register` from the module `b64codecs`."""
    register()
    assert NAME in codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:03.841468
# Unit test for function register
def test_register():
    """The function register should not throw an error."""
    register()



# Generated at 2022-06-11 22:11:05.844025
# Unit test for function register
def test_register():
    """Test function register."""
    # pylint: disable=W0212
    # noinspection PyProtectedMember
    register()



# Generated at 2022-06-11 22:11:15.842335
# Unit test for function encode
def test_encode():
    assert codecs.encode('a', 'b64') == b'YQo='
    assert codecs.encode('', 'b64') == b''
    assert codecs.encode('abcdefghijklmnopqrstuvwxyz', 'b64') == b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    assert codecs.encode(
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'b64') == b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo='
    assert codecs.encode(
        '0123456789', 'b64') == b'MDEyMzQ1Njc4OQ=='
   

# Generated at 2022-06-11 22:11:17.070188
# Unit test for function register
def test_register():
    """Test the function register()"""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:11:20.902782
# Unit test for function register
def test_register():
    """Test function register."""
    # Register the codec
    register()
    # Decode a text string into bytes
    out_bytes, consumption = codecs.decode('YWJjZA==', NAME)
    # should be base64 decoded to bytes object
    assert out_bytes == b'abcd'
    # and consumption should be 7.
    assert consumption == 7

# Generated at 2022-06-11 22:11:27.023057
# Unit test for function register
def test_register():
    """Function register()"""
    # pylint: disable=missing-function-docstring
    # pylint: disable=invalid-name
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # pylint: disable=unused-variable

    # Setup
    # Cleanup
    # Exercise + Verify
    _str = str(NAME)
    # If the function is registered then the following will throw a
    # LookupError exception.
    try:
        codecs.getdecoder(_str)
    except LookupError:
        register()
    else:
        # If it is not then register it.
        register()

    # At this point, the function is registered.


# Generated at 2022-06-11 22:11:34.001727
# Unit test for function register
def test_register():
    """Test for function register."""
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


if __name__ == '__main__':
    log.msg(f"""b64.py:  Registering the '{NAME}' codec.
    To use the '{NAME}' codec,
    call the function:
        b64.register()
    """)
    register()
    test_register()


# EOF

# Generated at 2022-06-11 22:11:35.946432
# Unit test for function register
def test_register():
    """Unit test for the 'register' function."""
    register()
    assert NAME in codecs.getdecoder('b64')



# Generated at 2022-06-11 22:11:43.563339
# Unit test for function encode

# Generated at 2022-06-11 22:11:48.115317
# Unit test for function register
def test_register():
    """Test :func:`register`."""
    try:
        codecs.getdecoder(NAME)
        func_register_was_called = False
    except LookupError:
        func_register_was_called = True

    register()

    if func_register_was_called:
        assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:12:45.642097
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencoders()
    assert NAME in codecs.getdecoders()
    assert NAME in codecs.getincrementalencoders()
    assert NAME in codecs.getincrementaldecoders()
    assert NAME in codecs.getaliases()



# Generated at 2022-06-11 22:12:47.314687
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:49.526442
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:51.635506
# Unit test for function register
def test_register():
    """Unit test for the :func:`register` function."""
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:12:53.728974
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:54.641499
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:12:56.173010
# Unit test for function register
def test_register():
    """Test the register function by seeing if we can unregister it."""
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:13:04.591577
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    import pytest
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        pytest.fail(
            f"Codec named {NAME!r} is already registered."
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            f"Codec named {NAME!r} is not registered."
        )



# Generated at 2022-06-11 22:13:06.063200
# Unit test for function register
def test_register():
    """Unit Test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:13:10.837823
# Unit test for function register
def test_register():
    from io import TextIOWrapper
    from io import BytesIO

    register()
    codecs.lookup(NAME)

    bin_data = b'abc\x00\x01\r\n'
    encoded = 'YWJjACAwCgA='

    encoded_bytes = encoded.encode(NAME)
    assert len(encoded_bytes) == len(encoded)

    s = BytesIO(encoded_bytes)
    r = TextIOWrapper(s, NAME)
    decoded_bytes = r.read()
    assert len(decoded_bytes) == len(bin_data)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:14:17.851889
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``."""
    text_input = (
        '''
            \n
            \tYW55IGNhcm5hbCBwbGVhc3VyZS4=\n
        '''
    )
    text_str = (
        'YW55IGNhcm5hbCBwbGVhc3VyZS4='
    )

    text_str_with_indent = '    ' + text_str
    text_str_with_blank = ' ' + text_str
    text_str_with_crlf = '\r\n' + text_str
    text_str_with_cr = '\r' + text_str
    text_str_with_lf = '\n' + text_str

    # Test input with indented text
    out,

# Generated at 2022-06-11 22:14:19.257633
# Unit test for function register
def test_register():                                                            # noqa: D103
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:14:22.921060
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False, 'codecs.getdecoder(NAME) should have raised a LookupError'
    except LookupError:
        pass

    register()

    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:14:32.340226
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0704
    # Disable the warning about the Catch All Exception.
    # When we call register, there can be an exception.
    # We want the exception, to test that the codec is not registered.
    try:
        register()
    except Exception:
        codecs.register(_get_codec_info)
    # Now call register again.  If the codec is registered, we should
    # get an exception.
    try:
        register()
        raise AssertionError(
            'The codec should NOT have been registered. '
            'It is registered.'
        )
    except LookupError:
        pass


if __name__ == '__main__':
    # Register the codec with Python.
    register()

    # Test the encoding.