

# Generated at 2022-06-11 22:04:35.233214
# Unit test for function register
def test_register():
    """Test function 'register'"""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:04:36.422906
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder('b64')

# Generated at 2022-06-11 22:04:43.183271
# Unit test for function register
def test_register():
    """Unit test for function ``register``"""
    # Save the current encoder
    saved_getdecoder = codecs.getdecoder
    try:
        # Reset 'getencoder' to None
        codecs.getdecoder = None

        # Verify that 'register' will raise a 'LookupError'
        with pytest.raises(LookupError):
            # pylint: disable=W0604
            # noinspection PyGlobalUndefined
            codecs.getdecoder(NAME)

        # Register the b64 codec
        register()

        # Verify that 'register' did not cause a 'LookupError'
        codecs.getdecoder(NAME)
    finally:
        # Reset the 'getencoder' to its saved value
        codecs.getdecoder = saved_getdecoder


# Generated at 2022-06-11 22:04:45.241046
# Unit test for function register
def test_register():
    """Test the register function."""
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:04:49.081897
# Unit test for function register
def test_register():
    """Test function register"""
    from pytest import raises
    from b64.codec import NAME
    import codecs
    register()
    with raises(LookupError) as exc:
        codecs.lookup_error(NAME)


# Generated at 2022-06-11 22:04:53.532284
# Unit test for function register
def test_register():
    # Reset the codec list.
    codecs.__init__()

    # Ensure the 'b64' codec is not registered.
    assert NAME not in codecs.__all__

    # Call register to register the 'b64' codec.
    register()

    # Ensure the 'b64' codec is registered.
    assert NAME in codecs.__all__


# Generated at 2022-06-11 22:04:55.422593
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    assert codecs.getencoder(NAME) == encode
    assert codecs.getdecoder(NAME) == decode

# Generated at 2022-06-11 22:05:04.259686
# Unit test for function register
def test_register():
    """Register the ``b64`` Codec."""
    from unittest.mock import Mock, patch
    mock_codec_info = Mock(codecs.CodecInfo)
    with patch('codecs.register', autospec=True) as mock_register:
        with patch('codecs.getdecoder', autospec=True) as mock_getdecoder:
            mock_getdecoder.side_effect = LookupError('nope')
            register()
            mock_register.assert_called_once_with(mock_codec_info)
            mock_getdecoder.assert_called_once_with(NAME)



# Generated at 2022-06-11 22:05:11.710130
# Unit test for function encode
def test_encode():
    """Test :func:`encode`"""
    input_bytes = b'SGVsbG8gV29ybGQh\nTWFkZSBieSBQeXRob24u\n'
    expected = b'Hello World!\nMade by Python.\n'
    result = encode(input_bytes)
    assert len(result) == 2
    assert result == (expected, len(input_bytes))



# Generated at 2022-06-11 22:05:14.155893
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        # Test the codec has been registered
        assert False, f'Expected Codec {NAME} to be registered'

test_register()

# Generated at 2022-06-11 22:05:24.691536
# Unit test for function register
def test_register():
    """Test that this module can be registered with Python."""
    from b64codec.register import unregister

    register()

    codecs.getdecoder(NAME)  # Should not raise a LookupError

    # noinspection PyProtectedMember
    unregister()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('Could not unregister this module.')



# Generated at 2022-06-11 22:05:33.764622
# Unit test for function register
def test_register():
    """Test to ensure the ``register`` function works as expected."""
    # Register the b64 codec.
    registered_before = NAME in codecs.__dict__['aliases'].keys()
    if not registered_before:
        register()
    # Make sure it is registered.
    registered_after = NAME in codecs.__dict__['aliases'].keys()
    assert registered_before == registered_after


try:
    # Register the b64 codec.
    register()
except Exception as e:
    err = f'Unable to register the {NAME} codec: {e}'
    raise RuntimeError(err) from e

# Generated at 2022-06-11 22:05:36.480122
# Unit test for function register
def test_register():
    """Test the function register()"""
    import pytest
    register()
    with pytest.raises(LookupError):
        codecs.lookup_error(NAME)

# Generated at 2022-06-11 22:05:40.854679
# Unit test for function register
def test_register():
    register()

    # noinspection PyProtectedMember
    out = codecs._lookup_name(NAME)
    assert isinstance(out, tuple)
    assert len(out) == 4


# Unit tests for function encode

# Generated at 2022-06-11 22:05:43.993500
# Unit test for function register
def test_register():
    """Test the b64.register function."""
    test = codecs.getdecoder(NAME)  # type: ignore
    assert test is not None



# Generated at 2022-06-11 22:05:50.133409
# Unit test for function register
def test_register():
    """Test that the b64 codec was correctly registered."""
    codec_info = codecs.getdecoder(NAME)
    assert codec_info.encode(b'', 'strict') == (b'', 0)
    assert codec_info.decode(b'', 'strict') == ('', 0)



# Generated at 2022-06-11 22:05:53.978834
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    # noinspection PyUnresolvedReferences,PyCompatibility
    assert 'b64' in codecs.decode.__code__.co_names
    # noinspection PyUnresolvedReferences,PyCompatibility
    assert 'b64' in codecs.encode.__code__.co_names



# Generated at 2022-06-11 22:05:55.583141
# Unit test for function register
def test_register():
    """
    Unit test for register().
    """
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:59.390147
# Unit test for function encode
def test_encode():
    # Test a normal value
    in_val = 'SmVmZQ=='
    result, result_len = encode(in_val)
    assert result == b'Jeef'
    assert result_len == len(in_val)

# Generated at 2022-06-11 22:06:02.407707
# Unit test for function register
def test_register():
    register()

    # Test to make sure the 'b64' codec was registered with Python.
    codecs.getdecoder(NAME)


# Unit test function for function encode

# Generated at 2022-06-11 22:06:11.837900
# Unit test for function register
def test_register():
    from random import randint
    from random import seed
    from secrets import token_bytes

    from .base64_bytes import decode as decode_bytes
    from .base64_bytes import encode as encode_bytes
    from .base64_bytes import NAME as NAME_BYTES

    def test_codec():
        seed(1)
        data_bytes = token_bytes(randint(0, 10))
        data_str = data_bytes.decode('utf-8')
        encoded_bytes, _encoded_len_bytes = encode_bytes(data_bytes)
        encoded_str, _encoded_len_str = encode(data_str)
        decoded_bytes, _decoded_len_str = decode_bytes(encoded_str)

# Generated at 2022-06-11 22:06:22.791056
# Unit test for function register
def test_register():
    import pickle
    import sys
    # Setup the environment to test the case where the
    # codec module has been not been registered.
    if NAME in sys.modules:
        del sys.modules[NAME]

    codecs._cache.clear()
    codecs._unknown_encoding_error.clear()

    # Re-import the codec module.  The module should now unregistered.
    try:
        import b64 as b64_lib
    except SystemError as e:
        if e.args[0] == 'Parent module ''b64'' not loaded, cannot perform'\
                        ' relative import':
            from . import b64 as b64_lib
        else:
            raise e

    # Test the codec module.  It should not be registered
    # with Python.

# Generated at 2022-06-11 22:06:33.839857
# Unit test for function register
def test_register():
    import socket
    import sys
    import time
    from _test_codec_common import _test_codec_common
    from _test_codec_common import _Verbose
    sys.path.insert(0, '..')
    import b64

    if _Verbose:
        print("\nBegin test_register")

    # Verify that the unit test is not being ran on the same host that
    # the webserver is running on.
    #   The webserver is running on port 8080.
    webserver = 'localhost'
    webserver = webserver.encode('utf-8')
    addr_info = socket.getaddrinfo(
        webserver, 8080, socket.AF_UNSPEC, socket.SOCK_STREAM
    )

    this_host = socket.gethostname()
    this_host

# Generated at 2022-06-11 22:06:35.744068
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert 'Decoder not found' in str(NAME)
        register()
        codecs.getdecoder(NAME)
    else:
        assert 'Decoder already registered' in str(NAME)


# Generated at 2022-06-11 22:06:36.904861
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:39.368662
# Unit test for function register
def test_register():
    """Unit-test for :func:`register`"""
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:41.927081
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    assert codecs.lookup(NAME) is not None
    assert codecs.lookup_error('b64') is None

# Unit tests for functions decode and encode

# Generated at 2022-06-11 22:06:46.924453
# Unit test for function register
def test_register():
    """Unit test for function: ``codec_b64.register``."""
    register()

    # Verify that the 'b64' Codec is registered.
    codec: codecs.CodecInfo = codecs.getdecoder(NAME)

    assert codec.name == NAME
    assert codec.decode == decode
    assert codec.encode == encode



# Generated at 2022-06-11 22:06:54.489170
# Unit test for function encode
def test_encode():
    assert encode('   YWJjZGVhYmNkZQ  ==') == (b'abcdeabcde', 18)
    # test methods to delete whitespace
    assert encode('  GJhc2UgNjQgY2hhcmFjdGVy\nIHN0cmluZwo=\n  ') == (b'Base 64 character string', 36)
    with pytest.raises(UnicodeEncodeError):
        encode('`')

# Generated at 2022-06-11 22:06:58.861123
# Unit test for function register
def test_register():
    """Test the function register."""
    register()

    # Check that the 'b64' codec is registered.
    assert NAME in codecs.getdecoder('b64')().name



# Generated at 2022-06-11 22:07:03.145351
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


register()

# Generated at 2022-06-11 22:07:10.569885
# Unit test for function register
def test_register():
    """Unit test for function register."""
    from typing import Any, Callable, Dict
    from typing import List

    # pylint: disable=W0621,W0622
    # Redefinition of function register from outer scope
    # Redefinition of variable b64 from outer scope
    assert NAME == 'b64'

    # Save of the original codecs.
    previous: Dict[str, Any] = {}
    register_ = codecs.register
    getdecoder = codecs.getdecoder

    # Override the original 'codecs' functions with a dummy version.

# Generated at 2022-06-11 22:07:22.801683
# Unit test for function register
def test_register():
    # Reset the codecs
    codecs.aliases.aliases = {}
    codecs.aliases.codec_aliases = {}
    codecs.aliases.encoding_alias = {}
    codecs.aliases.search_function = {}

    # Register the 'base64' codec
    codecs.register(_get_codec_info)  # type: ignore

    # Get the codec
    codec = codecs.getdecoder('base64')

    # Verify the object type
    assert isinstance(codec, tuple)

    # Verify the 2nd object is of type function
    assert inspect.isfunction(codec[1])

    # Reset the codecs
    codecs.aliases.aliases = {}
    codecs.aliases.codec_aliases = {}

# Generated at 2022-06-11 22:07:23.901897
# Unit test for function register
def test_register():
    """Test for the function register"""
    register()
    # Must not raise any exceptions
    assert True



# Generated at 2022-06-11 22:07:32.434553
# Unit test for function encode
def test_encode():
    # Test with a single base64 Character string
    assert encode('QQ==') == (b'A', 4)
    assert encode('aQ==') == (b'i', 4)
    assert encode('cXE=') == (b'qx', 4)
    assert encode('d3h4') == (b'wxh', 4)
    assert encode('eXl6fg==') == (b'yzzw', 8)

# Generated at 2022-06-11 22:07:42.154153
# Unit test for function register
def test_register():  # pylint: disable=too-many-locals
    """Unit test for function register."""
    expected_result = (
        'aGVsbG8gd29ybGQ=',
        'hello world'
    )

    register()
    encoder = codecs.getencoder(NAME)
    decoder = codecs.getdecoder(NAME)
    encoded_str, encoded_len = encoder(expected_result[1])
    decoded_str, decoded_len = decoder(expected_result[0])

    assert expected_result[0] == encoded_str
    assert len(expected_result[1]) == encoded_len
    assert expected_result[1] == decoded_str
    assert len(expected_result[0]) == decoded_len

# Generated at 2022-06-11 22:07:46.926534
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:07:55.077380
# Unit test for function register
def test_register():
    # Verify the codec is not yet registered.
    try:
        codecs.getdecoder(NAME)
        raise AssertionError(
            'The codec was already registered before the test was run'
        )
    except LookupError:
        pass

    # Register the codec and verify it is registered.
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('The codec was not registered')

    # Unregister the codec and verify it is no longer registered.
    # noinspection PyUnboundLocalVariable
    codecs.unregister(obj)
    try:
        codecs.getdecoder(NAME)
        raise AssertionError(
            'The codec was still registered after it was unregistered'
        )
    except LookupError:
        pass


# Generated at 2022-06-11 22:08:00.780002
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import builtins

    # pylint: disable=global-statement
    global codecs

    # Create a new list to contain the codec information
    codec_list = []

    # Patch the built-in codecs module.
    _orig_getdecoder = codecs.getdecoder

    def _mock_getdecoder(name: str) -> codecs.CodecInfo:
        codec_list.append(name)
        return _orig_getdecoder(name)

    builtins.codecs = sys.modules['codecs']
    codecs.getdecoder = _mock_getdecoder  # type: ignore

    # Call the function under test.
    try:
        register()
    except LookupError:
        pass

# Generated at 2022-06-11 22:08:01.978693
# Unit test for function register
def test_register():
    "If the codec is not registered, register it."
    register()



# Generated at 2022-06-11 22:08:09.520530
# Unit test for function encode
def test_encode():
    # Test logic
    assert encode('MTIz') == (b'123', 3)

# Generated at 2022-06-11 22:08:11.342573
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    _ = codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:15.457392
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register b64 codec'



# Generated at 2022-06-11 22:08:18.039455
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME)
    else:
        assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:20.503059
# Unit test for function register
def test_register():
    register()
    actual = codecs.getdecoder(NAME) is not None
    expect = True
    assert actual == expect


# Generated at 2022-06-11 22:08:23.404752
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec."""
    register()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:08:28.996763
# Unit test for function register
def test_register():
    """Unit Test for function register."""
    import sys
    register()
    assert __name__ in sys.modules
    assert codecs.getencoder(NAME) is encode
    assert codecs.getdecoder(NAME) is decode


if __name__ == "__main__":
    # Run the unit tests
    test_register()
    print('Test Successful...')

# Generated at 2022-06-11 22:08:36.506617
# Unit test for function register
def test_register():
    import sys
    import unittest

    # Remove b64 if it currently exists.
    try:
        del sys.modules['b64']
    except KeyError:
        pass

    try:
        import b64
    except ImportError:
        raise unittest.SkipTest(
            'Cannot import b64, therefore cannot register.'
        )
    from b64 import NAME

    try:
        assert NAME in codecs.__dict__['_cache']
    finally:
        del sys.modules['b64']

# Generated at 2022-06-11 22:08:38.261888
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise
    return



# Generated at 2022-06-11 22:08:39.934968
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:08:57.700525
# Unit test for function register
def test_register():
    # pylint: disable=import-outside-toplevel
    import codecs
    from sys import modules

    # Delete the codec from the codecs register.
    try:
        del modules[__name__ + '.b64']
    except KeyError:
        pass

    # Ensure that the module does not have a function of `register`.
    assert not getattr(modules[__name__], 'register', None)


# Generated at 2022-06-11 22:09:05.395685
# Unit test for function register
def test_register():
    """Unit test for function register."""
    from pprint import pprint
    from sys import modules

    def _test():
        """Unit test for function register."""
        assert NAME in modules
        assert NAME in globals()

        assert NAME in dir(modules[__name__])
        assert NAME in globals()

        register()

        assert NAME in codecs.lookup(NAME).name
        assert codecs.lookup(NAME).decode(b'YQ==') == ('a', 1)
        assert codecs.lookup(NAME).encode('a') == (b'YQ==', 1)
    _test()
    # pylint: disable=I0011,W0122
    del _test
    pprint(codecs.__dict__)



# Generated at 2022-06-11 22:09:07.224334
# Unit test for function register
def test_register():
    """Assert the ``b64`` codec has been registered."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:09:10.851139
# Unit test for function register
def test_register():
    """Test that the codec can be registered when needed."""
    register()

    # noinspection PyUnresolvedReferences
    import test_task
    # noinspection PyUnresolvedReferences
    import b64


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:18.462108
# Unit test for function register
def test_register():
    """Unit test for ``register``."""
    # Cleanup any previous registrations.
    codecs.lookup(NAME)
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    # Test that it is not registered.
    with pytest.raises(LookupError):
        codecs.decode(b'', NAME)
    # Register the codec.
    register()
    # Test that it is now registered
    codecs.decode(b'', NAME)


if __name__ == '__main__':
    # Register this codec with Python
    register()

    # Run the test suite for unit testing.
    test_register()

# Generated at 2022-06-11 22:09:20.758500
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:29.297087
# Unit test for function register
def test_register():
    """Test the :func:`~b64enc` register function."""
    register()
    with pytest.raises(TypeError):
        codecs.decode('', 'b64')
    with pytest.raises(TypeError):
        codecs.encode('', 'b64')


if __name__ == '__main__':
    args = sys.argv.copy()
    sys.argv.clear()
    sys.argv.append('--cov=b64enc')
    sys.argv.append('--cov-report=term-missing')
    sys.argv.extend(args)
    pytest.main(args)

# Generated at 2022-06-11 22:09:32.366573
# Unit test for function register
def test_register():
    """Unit test for function :func:`~data_algebra.util.b64_codec.register``."""
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:09:34.525570
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8gd29ybGQh') == (b'Hello world!', 14)


# Generated at 2022-06-11 22:09:43.446643
# Unit test for function register
def test_register():  # noqa: D202
    """Function register() unit test."""
    register()

    # Test registering multiple times does not change anything.
    register()

    # Test that the codec is properly registered.
    codec = codecs.CodecInfo(
        decode=None,
        encode=None,
        error_handler=None,
        stream_reader=None,
        stream_writer=None,
        name=None,
    )
    codec.name = NAME
    assert codecs.getdecoder(NAME) == (decode, None)
    assert codecs.getencoder(NAME) == (encode, None)


# Generated at 2022-06-11 22:10:04.554822
# Unit test for function register
def test_register():
    # Register the b64 codec.
    register()

    # Get the b64 codec
    b64_codec = codecs.getdecoder(NAME)

    # Encode test bytes with the b64 codec
    encoded_bytes = b64_codec(b'This is to be encoded.', errors='strict')

    # Decode the base64 encoded bytes with the base64 codec.
    decoded_bytes = base64.b64decode(encoded_bytes[0].encode('utf-8'))

    # Ensure that 'test_bytes' is what was encoded.
    assert b'This is to be encoded.' == decoded_bytes


# Generated at 2022-06-11 22:10:08.220840
# Unit test for function register
def test_register():
    """Test the register() function."""
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:12.211158
# Unit test for function register
def test_register():
    """Test that ``register()`` does not throw an exception."""
    register()


try:
    # If the codec has already been registered, calling
    # ``register()`` will throw an exception.
    register()
except:
    # If the codec has already been registered,
    # there is nothing to do.
    pass

# Generated at 2022-06-11 22:10:13.934514
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# pylint: disable=C0103

# Generated at 2022-06-11 22:10:22.084715
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    # Ensure the 'b64' codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The codec \'{NAME}\' is not registered.'
        )

    # Register the 'b64' codec.
    register()

    # Ensure the 'b64' codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'The codec \'{NAME}\' is not registered.'
        )
    else:
        pass


# Generated at 2022-06-11 22:10:28.566140
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    import sys
    import os
    import unittest

    register()
    print(sys.builtin_module_names)
    print('b64' in sys.modules)
    print(sys.modules['b64'])
    print(os.environ['PYTHONPATH'])



# Generated at 2022-06-11 22:10:35.044918
# Unit test for function register
def test_register():
    """Make sure that the register function works."""
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None

if __name__ == '__main__':
    register()


# Generated at 2022-06-11 22:10:47.105219
# Unit test for function encode

# Generated at 2022-06-11 22:10:55.360106
# Unit test for function register
def test_register():
    """Unit test ``register`` function."""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    from . import test_data

    base64_str = ('W3N0cmluZ10NCg==' +
                  'W3N0cmluZ10NCg==')
    text = test_data.get_text_from_base64_encoded_text(base64_str)

    # Test encode  # pylint: disable=no-member
    expected_bytes = b'W3N0cmluZ10NCg==' + b'W3N0cmluZ10NCg=='
    assert text.encode('b64') == expected_bytes
    assert text.encode('b64', errors='ignore') == expected_

# Generated at 2022-06-11 22:10:57.365037
# Unit test for function register
def test_register():
    """Test function register with codecs.getdecoder(NAME)."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:11:21.309050
# Unit test for function register
def test_register():
    """Test the register function."""
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)
    try:
        codecs.register(_get_codec_info)
    except LookupError:
        pass  # This is the desired outcome for this test.

    assert isinstance(obj, codecs.CodecInfo)
    assert obj.name == 'b64'
    assert obj.decode(b'aGVsbG8sIG15IGZyaWVuZA==') == ('hello, my friend', 16)
    assert obj.encode('hello, my friend') == (b'aGVsbG8sIG15IGZyaWVuZA==', 16)


if __name__ == '__main__':
    import os
    import sys
    import unitt

# Generated at 2022-06-11 22:11:25.438033
# Unit test for function register
def test_register():
    """Test registering the codec with Python."""
    codecs.register(_get_codec_info)
    # This should not raise an exception
    codecs.getdecoder(NAME)
    #
    # Should raise exception with the message
    # 'LookupError: unknown encoding: b64'
    with pytest.raises(LookupError) as e:
        codecs.getdecoder('wxyz')
    assert str(e.value) == 'unknown encoding: wxyz'


# Generated at 2022-06-11 22:11:28.352141
# Unit test for function register
def test_register():
    """Unit test for the 'register' function."""
    register()
    assert NAME in codecs.__all__
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


test_register()

# Generated at 2022-06-11 22:11:30.785642
# Unit test for function register
def test_register():
    """Unit test for the function register"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, (
            'Codec b64 was not registered with the Python Codecs module.'
        )



# Generated at 2022-06-11 22:11:33.810546
# Unit test for function register
def test_register():
    """Test function ``register()``."""
    assert 'b64' not in codecs.__dict__.keys()
    register()
    assert 'b64' in codecs.__dict__.keys()



# Generated at 2022-06-11 22:11:41.712007
# Unit test for function register
def test_register():
    """Unit test for the register() function."""

    def _reset_codecs():
        try:
            del codecs.decode.cache[NAME]
        except KeyError:
            pass
        codecs.decode.cache.clear()
        codecs.encode.cache.clear()

    # pylint: disable=protected-access
    _reset_codecs()
    codecs_getdecoder = codecs.getdecoder
    codecs_getencoder = codecs.getencoder

# Generated at 2022-06-11 22:11:50.804690
# Unit test for function encode
def test_encode():
    """Test the encode() function."""
    # Test the default behavior of the encode function.
    test_str = '"""'
    test_bytes = b'"""'
    expected = (test_bytes, 3)
    actual = encode(test_str)
    assert actual == expected, f'bad base64 decode: {actual}'
    actual = encode(UserString(test_str))
    assert actual == expected, f'bad base64 decode: {actual}'

    
    # Test the encode function with a multiline string with no white space.
    test_str = '"""'
    test_bytes = b'"""'
    expected = (test_bytes, 3)
    actual = encode(test_str)
    assert actual == expected, f'bad base64 decode: {actual}'

# Generated at 2022-06-11 22:11:52.630973
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:01.650680
# Unit test for function register
def test_register():
    """Unit test for function register"""
    import sys
    import unittest

    assert NAME not in sys.modules, f'{NAME!r} already imported.'
    try:
        register()
    finally:
        del sys.modules[NAME]

    # The following re-registers codecs.
    try:
        del sys.modules['encodings']
    except KeyError:
        pass
    try:
        import encodings
    finally:
        if 'encodings' in sys.modules:
            del sys.modules['encodings']

    # The following import will register the codec.
    import encodings.b64

    # The encodings module did not change, hence no warning
    # message.



# Generated at 2022-06-11 22:12:02.935305
# Unit test for function register
def test_register():
    """Unit test the register() function."""
    assert NAME not in codecs.getdecoder('b64')

    register()
    assert NAME in codecs.getdecoder('b64')



# Generated at 2022-06-11 22:12:17.986435
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:12:22.987699
# Unit test for function register
def test_register():
    """Test to ensure `register` is registered."""
    codec = codecs.getdecoder(NAME)
    assert codec(b'\xab\xcd\xad\xbe') == ('qr/R', 4)
    assert codecs.encode('qr/R', NAME) == b'\xab\xcd\xad\xbe'

# Generated at 2022-06-11 22:12:30.722596
# Unit test for function encode
def test_encode():  # pragma: no cover
    """Unit test for function encode."""
    from itertools import product

    from binascii import Error as b64Error

    from .pytest_helper import make_mock_class

    encode.__globals__['base64'] = make_mock_class(
        (b64Error,),
        decodebytes=lambda data: data
    )


# Generated at 2022-06-11 22:12:39.334698
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('A') == (b'A', 1)
    assert encode('BA') == (b'BA', 2)
    assert encode('CBA') == (b'CBA', 3)
    assert encode('DCBA') == (b'DCBA', 4)
    assert encode('EDCBA') == (b'EDCBA', 5)
    assert encode('FEDCBA') == (b'FEDCBA', 6)
    assert encode('GFEDCBA') == (b'GFEDCBA', 7)
    assert encode('HGFEDCBA') == (b'HGFEDCBA', 8)
    assert encode('IHGFEDCBA') == (b'IHGFEDCBA', 9)
    assert encode('JIHGFEDCBA')

# Generated at 2022-06-11 22:12:48.763005
# Unit test for function register
def test_register():
    """Unit test the function :func:`register`."""
    def assert_register():
        """Assert the Register."""
        assert codecs.getencoder(NAME)    # type: ignore
        assert codecs.getdecoder(NAME)    # type: ignore

    def assert_unregister():
        """Assert the Unregister."""
        with pytest.raises(LookupError):
            codecs.getencoder(NAME)    # type: ignore
        with pytest.raises(LookupError):
            codecs.getdecoder(NAME)    # type: ignore

    def test_register():
        """Test :obj:`register`."""
        assert_unregister()
        register()
        assert_register()

    def test_register_again():
        """Test :obj:`register` again."""


# Generated at 2022-06-11 22:12:55.657248
# Unit test for function register
def test_register():
    codecs.lookup_error='strict'
    register()
    codecs.lookup_error='ignore'
    register()
    codecs.lookup_error='replace'
    register()
    codecs.lookup_error='xmlcharrefreplace'
    register()
    codecs.lookup_error='backslashreplace'
    register()
    codecs.lookup_error='namereplace'
    register()

codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:13:00.009149
# Unit test for function encode
def test_encode():
    """Test function encode"""
    # Test case: ignoring errors
    assert encode('aGVsbG8=') == (b'hello', 6)
    # Test case: raising errors
    with pytest.raises(UnicodeEncodeError):
        encode('hello')


# Generated at 2022-06-11 22:13:05.307076
# Unit test for function register
def test_register():
    """Test the register function."""
    codecs.register(_get_codec_info)
    try:
        codecs.lookup(NAME)
    except LookupError:
        assert False, f'{NAME} not registered'
    else:
        assert True
    finally:
        codecs.unregister(NAME)

# Generated at 2022-06-11 22:13:08.123632
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            f'Failed to register {NAME!r}, '
            f'it is not in sys.__standard_encoding__'
        )


# Generated at 2022-06-11 22:13:12.044798
# Unit test for function register
def test_register():
    """Test register function by checking to see if ``b64`` is registered."""
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:13:36.642934
# Unit test for function encode
def test_encode():
    """Test the encoding function."""

    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test(
            in_text: _STR,
            in_bytes: bytes,
            out_bytes: bytes,
    ) -> None:
        test_out = encode(in_text)
        assert test_out == (out_bytes, len(in_text))


    # Whitespace is ignored
    _test(
        in_text='\tZm9vCg==',
        in_bytes=b'foo\n',
        out_bytes=b'foo\n',
    )

    # lines are joined

# Generated at 2022-06-11 22:13:40.223611
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    # Setup
    assert not codecs.lookup(NAME)

    # Exercise
    register()

    # Verify
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:13:43.190661
# Unit test for function register
def test_register():
    """Verify that the codec is registered."""
    register()
    assert codecs.lookup(NAME) is not None
#     # Verify the codec is registered
#     assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:13:46.706224
# Unit test for function register
def test_register():
    """Unit Test of the function register."""
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj.name == NAME

# Generated at 2022-06-11 22:13:57.312179
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    # Register the 'b64' codec
    register()

    # Get the 'b64' codec
    b64 = codecs.getdecoder(NAME)
    assert b64 is not None

    inp = '''\
        QWxhZGRpbjpvcGVuIHNlc2FtZQ==
    '''

    # Decode the given string
    out, _ = b64(inp)

    # output is of type bytes, convert it to a string
    assert out.decode() == 'Aladdin:open sesame'

    # Encode a string into base64 encoded characters
    inp = 'Aladdin:open sesame'
    out_encoded, _ = b64(inp, 'encode')

    # Decode the b64 characters

# Generated at 2022-06-11 22:14:01.651211
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    import sys
    try:
        if NAME not in sys.modules['encodings'].__all__:
            sys.modules['encodings'].__all__.append(NAME)
    except KeyError:
        pass
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


# Generated at 2022-06-11 22:14:03.633886
# Unit test for function register
def test_register():
    from pycodec.core import TEST_MODE
    if TEST_MODE:
        register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:14:10.082361
# Unit test for function register
def test_register():
    """Unit test for the register() function."""
    import sys
    import unittest

    def _import_module(module_name: str) -> Any:
        import importlib
        try:
            return importlib.import_module(module_name)
        except ImportError:
            return None

    # noinspection PyMethodMayBeStatic
    class RegisterTestCase(unittest.TestCase):
        """Unit test for the register() function."""

        def setUp(self) -> None:
            """Setup the test case."""
            # Remove the 'codecs' module from sys.modules.
            self._sys_modules_backup = sys.modules.copy()

            sys.modules.pop('codecs', None)

        def tearDown(self) -> None:
            """Tear down the test case."""
           

# Generated at 2022-06-11 22:14:16.884239
# Unit test for function register
def test_register():
    """Test the function register by registering the ``b64`` codec and
    then unregistering it.

    Raises:
        AssertionError: if the ``b64`` codec is not registered properly
    """
    register()
    obj1 = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    obj2 = codecs.getdecoder(NAME)
    assert obj1 == obj2
    register()
    obj3 = codecs.getdecoder(NAME)
    assert obj3 == obj2

# Generated at 2022-06-11 22:14:26.095196
# Unit test for function register
def test_register():
    """Check the function ``register()`` in this module."""
    import sys
    import b64
    from b64 import b64   # type: ignore
    register()
    assert b64 in sys.modules
    import builtins
    b64 = builtins.__dict__.get('b64')
    assert b64 is not None
    # pylint: disable=import-outside-toplevel
    import codecs
    codec = codecs.getdecoder('b64')
    assert codec is not None
    # pylint: disable=import-outside-toplevel
    from b64 import b64_encode, b64_decode
    data = b'Unit Test'
    encoded_bytes = b64_encode(data)
    decoded_bytes = b64_decode(encoded_bytes)
    assert data