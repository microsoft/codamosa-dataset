

# Generated at 2022-06-11 22:04:35.464329
# Unit test for function register
def test_register():
    """Unit test for function :func:`~register`."""
    # Register the codec
    register()

    # Get the codec
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:04:36.683499
# Unit test for function register
def test_register():
    """Exercise the register() function and verify it works."""
    _ = "@TODO: Write unit tests."



# Generated at 2022-06-11 22:04:41.298970
# Unit test for function register
def test_register():
    """Test function register"""
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:04:43.995703
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:04:47.768628
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # noinspection PyUnresolvedReferences
    import codecs
    from test.utils import TestException
    with TestException():
        register()
        codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:04:56.221391
# Unit test for function register
def test_register():
    """Test the function :func:`b64.register`."""
    # Unregister the 'b64' codec if it is registered.
    try:
        codecs.lookup(NAME)  # type: ignore
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)  # type: ignore

    # Make sure 'b64' is not registered.
    with pytest.raises(LookupError):
        codecs.lookup(NAME)  # type: ignore

    # Register the 'b64' codec.
    register()

    # Make sure the 'b64' codec is registered.
    _ = codecs.lookup(NAME)  # type: ignore


# Generated at 2022-06-11 22:05:07.211770
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('MQ==') == (b'1', 4)
    assert encode('MTI=') == (b'12', 4)
    assert encode('MTIz') == (b'123', 4)
    assert encode('MTIzNA==') == (b'1234', 8)
    assert encode('\ndGhpcyBpcyBgeG1sYAAAAAAAAAAAA\n') == (
        b'<this is `xml`>',
        41,
    )
    assert encode('\n    \ndGhpcyBpcyBgeG1sYAAAAAAAAAAAA\n    \n    \n ') == (
        b'<this is `xml`>',
        47,
    )

# Generated at 2022-06-11 22:05:13.148329
# Unit test for function register
def test_register():
    """Make sure ``b64`` is not registered."""
    codecs.register(test_register)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception(NAME, 'already registered')

codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:05:16.233182
# Unit test for function register
def test_register():
    """Test register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'{NAME} was not registered: {e}')



# Generated at 2022-06-11 22:05:17.824801
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:22.613798
# Unit test for function register
def test_register():
    """Ensure the given codec is registered by this call."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:33.627054
# Unit test for function register
def test_register():
    """Test that the 'b64' codec can be registered
    and decoded.

    This unit test is not run when module `codec_b64` is imported.
    """
    import unittest
    # noinspection PyUnusedLocal
    class RegisterTestCase(unittest.TestCase):
        """Test that the 'b64' codec can be registered
        and decoded.
        """
        def test_decode(self):
            """Test that the 'b64' codec can be registered
            and decoded.
            """
            register()
            codecs.decode('YnRlc3Rfc3RyaW5n', NAME)
    # Run the unit test
    unittest.main(__name__)

# Generated at 2022-06-11 22:05:42.976119
# Unit test for function register
def test_register():
    """Test the function ``b64_codec.register``.  This function is not
    currently tested by the unit test suite.
    """
    # Reset the codecs to the 'original' registered codecs.
    codecs.clear_cache()

    # Make sure the b64 codec has not been registered
    try:
        codecs.getdecoder(NAME)
        raise AssertionError('codecs.getdecoder(NAME) returns something.')
    except LookupError:
        pass

    # Register the b64 codec.
    register()

    # Make sure the b64 codec has been registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('codecs.getdecoder(NAME) does not exist.')

# Generated at 2022-06-11 22:05:51.841163
# Unit test for function register
def test_register():
    """Test that the 'b64' codec was registered."""
    # Remove the b64 codec.

# Generated at 2022-06-11 22:05:59.305793
# Unit test for function encode
def test_encode():
    """Tests for the ``encode`` function."""

# Generated at 2022-06-11 22:06:05.292385
# Unit test for function register
def test_register():
    def test_type(obj: Optional[object]) -> None:
        assert isinstance(obj.name, str)

    register()
    test_type(codecs.getdecoder(NAME))   # noqa: E999
    test_type(codecs.getencoder(NAME))   # noqa: E999



# Generated at 2022-06-11 22:06:15.949720
# Unit test for function register
def test_register():
    """Test for function register."""
    import sys
    import os
    import tempfile
    import importlib

    truth_table = [
        [True, 'b64' in sys.modules],
        [True, 'b64' in os.environ['PYTHONPATH'].split(os.pathsep)],
        [True, 'b64' in sys.path],
        [True, 'b64' in sys.meta_path],
        [True, 'b64' in sys.path_hooks],
        [True, 'b64' in sys.path_importer_cache],
    ]

    sys.path.insert(0, '')
    for (truth, result) in truth_table:
        assert truth == result, 'Unexpected result.'


# Generated at 2022-06-11 22:06:19.395633
# Unit test for function register
def test_register():
    # unit test for function register
    register()
    assert codecs.lookup(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:25.123036
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.encode(b'', NAME) == (b'', 0)
    assert codecs.decode('', NAME) == ('', 0)



# Generated at 2022-06-11 22:06:28.521599
# Unit test for function register
def test_register():
    """Test that the codec is registered."""
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:06:35.424490
# Unit test for function register
def test_register():
    """Test that the 'b64' codec is not registered."""
    registered = False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        registered = False
    assert not registered


# Generated at 2022-06-11 22:06:37.861833
# Unit test for function register
def test_register():
    """Test the ``b64`` codec registration with Python."""
    register()
    assert NAME in codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:06:40.410068
# Unit test for function register
def test_register():
    """Test that the b64 codec can be registered."""
    register()

    decoder = codecs.getdecoder(NAME)
    assert decoder is not None



# Generated at 2022-06-11 22:06:41.204557
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:06:47.220986
# Unit test for function register
def test_register():
    import sys
    import encoder_decoders.base_64.codec as codec

    codec.register()

    # Verify that the 'b64' codec exists.
    if sys.version_info.major < 3:
        assert sys.getdefaultencoding() != NAME
    else:
        # Python 3 does not use the sys.getdefaultencoding() call.
        assert True

    # Try to register again.  This should not error.
    codec.register()



# Generated at 2022-06-11 22:06:58.145770
# Unit test for function register
def test_register():
    # Get the initial / built-in codecs.
    initial_codecs = codecs.__dict__
    # Register the codec (this is a no-op if already registered).
    register()
    # Get the final / built-in codecs.
    final_codecs = codecs.__dict__
    # Get the set-difference between the initial codecs and final codecs
    new_codecs = set(final_codecs) - set(initial_codecs)
    assert len(new_codecs) == 0
    return


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:00.098788
# Unit test for function register
def test_register():
    codecs.register = register
    assert codecs.getdecoder(NAME)

# Register the 'b64' codec with Python
register()

# Generated at 2022-06-11 22:07:03.088781
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    # Register the codec.
    register()

    # Get the decoder.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:09.963823
# Unit test for function register
def test_register():
    """Test the register function."""
    import sys
    import warnings

    # Register the codec
    register()

    # Verify the codec was registered
    assert NAME in sys.modules

    # Try to register the codec again. This should raise a warning.
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Try to register again.
        register()
        # Verify the warning was issued.
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)
        assert str(w[-1].message) == f'{NAME} codec already registered'



# Generated at 2022-06-11 22:07:10.862532
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:23.986017
# Unit test for function encode
def test_encode():
    import pytest

    # Test proper, stripped text
    text = '''
    SSdtIGtpbGxpbmcgeW91ciBicmFpbiBsaWtlIGEgcG9pc29ub3VzIG11c2hyb29t
    '''

# Generated at 2022-06-11 22:07:27.886843
# Unit test for function register
def test_register():
    """Test function register()."""
    register()
    codecs.getdecoder(NAME)
    # Reset the codec after the test.
    codecs.lookup(NAME).reset()



# Generated at 2022-06-11 22:07:32.510461
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:07:40.239986
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Register the codec
    register()

    # Due to some weirdness with the codecs library, if the codec
    # was already registered, a LookupError is raised.  However,
    # the codec is still now available.  So we just silently
    # ignore the LookupError.
    try:
        # Retrieve a decoder for the b64 codec.
        codecs.getdecoder(NAME)

    except LookupError:  # pragma: no cover
        #
        # It was already registered.
        #
        pass



# Generated at 2022-06-11 22:07:41.783730
# Unit test for function encode
def test_encode():
    assert encode('VGVzdA==') == (b'Test', 6)


# Generated at 2022-06-11 22:07:43.288145
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:46.638280
# Unit test for function register
def test_register():
    """Test for ``register``."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:49.403014
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME)
    assert isinstance(codecs.getencoder(NAME), codecs.CodecInfo)

# Generated at 2022-06-11 22:07:51.387789
# Unit test for function register
def test_register():
    """Test the register() function

    The unit test for the register() function is contained in the
    test_codec.py module
    """
    pass

# Generated at 2022-06-11 22:07:53.550841
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise ValueError(f'{e}')



# Generated at 2022-06-11 22:07:58.264538
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.lookup_error(NAME)
    codecs.lookup(NAME)


# Generated at 2022-06-11 22:07:59.793639
# Unit test for function register
def test_register():
    """Test: code.register()"""
    register()



# Generated at 2022-06-11 22:08:07.811718
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    print('Testing function encode')
    assert encode('abc')[0] == b'YWJj'
    assert encode('a b\nc')[0] == b'YWIKYw=='
    assert encode('a b\nc')[1] == 5
    assert encode('')[0] == b''
    try:
        encode('YWJj')
    except UnicodeEncodeError as e:
        error = e.reason
    else:
        error = ''
    assert error == "'YWJj' is not a proper bas64 character string: " \
                    "Incorrect padding"


# Generated at 2022-06-11 22:08:18.023718
# Unit test for function register
def test_register():
    # Get the current codec lookup.
    lookup_list = codecs.codecs_for_encoding.items()

    # Register the b64 codec.
    register()

    # Get the updated codec lookup.
    new_lookup_list = codecs.codecs_for_encoding.items()

    # Remove the b64 codec from the updated codecs.
    b64_items = list(filter(lambda x: x[0] == NAME, new_lookup_list))
    new_lookup_list = list(filter(lambda x: x[0] != NAME, new_lookup_list))

    # Compare the current lookup with the updated lookup.
    assert lookup_list == new_lookup_list

    # Check that the b64 codec was added.
    assert len(b64_items) == 1


# Unit test

# Generated at 2022-06-11 22:08:19.742287
# Unit test for function register
def test_register():
    codecs.lookup_error = LookupError  # type: ignore
    register()

# Generated at 2022-06-11 22:08:23.211605
# Unit test for function register
def test_register():
    with capture_stdout() as (out, err):
        register()
        # pylint: disable=unused-variable
        first_codec = codecs.lookup(NAME)



# Generated at 2022-06-11 22:08:32.242841
# Unit test for function encode

# Generated at 2022-06-11 22:08:34.744384
# Unit test for function register
def test_register():
    assert not hasattr(register, '_registered')
    register()
    assert register._registered is not None, f'{register!r} is not registered'


# pylint: disable=W0613

# Generated at 2022-06-11 22:08:36.998597
# Unit test for function encode
def test_encode():
    assert encode('YmFzZTY0') == (b'base64', 6)



# Generated at 2022-06-11 22:08:38.829251
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:08:49.499051
# Unit test for function register
def test_register():
    """Test registering the module with codecs."""
    # Verify that the codec is already registered.
    if NAME not in codecs.__all__:
        codecs.register(_get_codec_info)
    assert NAME in codecs.__all__



# Generated at 2022-06-11 22:08:50.675447
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:08:54.724989
# Unit test for function register
def test_register():
    """Test the register function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)

    register()

    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:55.878315
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-11 22:09:04.820426
# Unit test for function encode
def test_encode():
    assert encode('\n') == (b'\n', 1)
    assert encode('\n\n') == (b'\n\n', 2)
    assert encode('\n\n\n') == (b'\n\n\n', 3)
    assert encode(' \n\n \n') == (b'\n\n\n', 4)

    assert encode('q') == (b'q', 1)
    assert encode('qq') == (b'qq', 2)
    assert encode('qqq') == (b'qqq', 3)
    assert encode('qqq=') == (b'qqq=', 4)
    assert encode('qqq==') == (b'qqq==', 5)
    assert encode('qqq===') == (b'qqq===', 6)

# Generated at 2022-06-11 22:09:07.030452
# Unit test for function encode
def test_encode():
    assert (b'hello', 5) == encode('aGVsbG8=')
    assert (b'', 5) == encode('====')


# Generated at 2022-06-11 22:09:12.651061
# Unit test for function encode
def test_encode():
    input_text = """
    ABCD
    EFG
    H
    IJ
    KLMN
    OPQR
    STU
    VWXYZ
    12345
    67890
    """
    expected = b'\x00\x10\x83@\x1c\x10\x04\x02\x08\x10\x01\x03\x04\x04\x10\x10\x00@'
    out = codecs.decode(input_text, 'b64')
    assert out == expected



# Generated at 2022-06-11 22:09:14.968539
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    test_register()

# Generated at 2022-06-11 22:09:16.123479
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup('b64')



# Generated at 2022-06-11 22:09:19.018506
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)   # type: ignore
    assert callable(obj)


# pylint: enable=W0613

# Generated at 2022-06-11 22:09:29.486537
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) == codecs.CodecInfo(
        encode=encode,
        decode=decode,
        name=NAME,
    )



# Generated at 2022-06-11 22:09:31.768884
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:34.965551
# Unit test for function register
def test_register():
    """Test that the function ``register`` is working correctly."""
    register()

    assert NAME in codecs.codecs   # type: ignore
    assert NAME in codecs.decoders
    assert NAME in codecs.encoders



# Generated at 2022-06-11 22:09:41.058216
# Unit test for function register
def test_register():
    """Test that the b64 codec is registered properly.  Will also
    test that the :func:`~test_register` function can be invoked.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None


INPUT = '''
    aW5pdGlhbGlzYXRpb24gY29kZSB0byB0ZXN0IGBjb2RlYy5iNjRgIHdpdGggY29kZWNzLmZvcm1hdA==
'''

OUTPUT = '''
    initialization code to test `codec.b64` with codecs.format
'''




# Generated at 2022-06-11 22:09:48.951478
# Unit test for function encode
def test_encode():
    encoder = encode()
    text = "This is a test."
    text_bytes, length = encoder(text)
    assert length == len(text)
    assert text_bytes == b"VGhpcyBpcyBhIHRlc3Qu"

    text = "This is also a test."
    text_bytes, length = encoder(text)
    assert length == len(text)
    assert text_bytes == b"VGhpcyBpcyBhbHNvIGEgdGVzdC4="

    text = "This is the longest test of them all!"
    text_bytes, length = encoder(text)
    assert length == len(text)

# Generated at 2022-06-11 22:09:51.943161
# Unit test for function register
def test_register():
    """If the 'b64' codec is not registered, then register it."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

# Generated at 2022-06-11 22:09:57.668368
# Unit test for function register
def test_register():
    # Register the codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    # Get the codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True

# Generated at 2022-06-11 22:10:07.337483
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhcw==') == (b'any carnal pleasure', 24)
    assert encode('YW55IGNhcm5hbCBwbGVhc3U=') == (b'any carnal pleasures', 25)
    assert encode('YW55IGNhcm5hbCBwbGVhc3Vy') == (b'any carnal pleasure', 25)
    assert encode('Ynl0ZXM=') == (b'bytes', 6)
    assert encode('bit') == (b'bit', 3)
    assert encode('bXkg') == (b'my ', 3)
    assert encode('bXkgc2VjcmV0') == (b'my secret', 10)
    assert encode('bXk= =') == (b'my', 9)

# Generated at 2022-06-11 22:10:10.747245
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f"codec {NAME!r} is not registered")



# Generated at 2022-06-11 22:10:15.096948
# Unit test for function register
def test_register():
    """Test the register function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:33.894052
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None

# Unit tests for function decode

# Generated at 2022-06-11 22:10:37.444231
# Unit test for function register
def test_register():
    """Test that this module registers the 'b64' codec with Python."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:43.253621
# Unit test for function register
def test_register():
    """PyTest unit test for ``register()``."""
    # Get the 'decode' method.
    decode_method = getattr(codecs.lookup(NAME), 'decode')

    # Make sure the method returns a Tuple[str, int].
    assert decode_method(b'\x00') == ('AA==', 1)



# Generated at 2022-06-11 22:10:45.623099
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is _get_codec_info(NAME)
#     codecs.lookup(NAME)

# Generated at 2022-06-11 22:10:50.592808
# Unit test for function register
def test_register():
    """Unit test for the register function."""
    register()
    assert NAME in codecs.codecs.__all__
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
test_register.__test__ = False   # type: ignore


# Register this codec
register()

# Generated at 2022-06-11 22:10:56.884687
# Unit test for function encode
def test_encode():
    """Unit test for encode()"""
    assert encode(b'VGhpcyBtZXNzYWdlIGlzIGFuIGV4YW1wbGU=') == (b'This message is an example', 36)
    assert encode(b'VGhpcyBtZXNzYWdlIGlzIGFuIGV4YW1wbG' + 'U='.encode('utf-8')) == (b'This message is an example', 36)
    assert encode(b'VGhpcyBtZXNzYWdlIGlzIGFuIGV4YW1wbGk=', 'surrogateescape') == (b'This message is an example', 36)
    assert encode(b'VGhpcyBtZXNzYWdlIGlzIGFuIGV4YW1wbGk=', 'replace')

# Generated at 2022-06-11 22:10:58.354065
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:11:01.295356
# Unit test for function register
def test_register():
    """Test function ``register``."""
    register()
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:11:09.881560
# Unit test for function encode
def test_encode():
    """Unit Test for function encode()

    Test to make sure that we can handle a b64 characters strings
    in various formats.

    Raises:
        AssertionError: if any of the tests fail
    """

# Generated at 2022-06-11 22:11:20.075768
# Unit test for function encode

# Generated at 2022-06-11 22:12:00.327671
# Unit test for function encode
def test_encode():
    """Test the encode function"""
    # Test with a single row string
    assert(encode('VGhpcyBpcyBhIHN0cmluZw==') == (b'This is a string', 22))

    # Test with a multi row string
    assert(encode('VGhpcyBpcyBhIHN0cmluZw==\nVGhpcyBpcyBhIHN0cmluZw==') ==
            (b'This is a stringThis is a string', 44))

    # Test with a single row string
    assert(encode('VmVyeSBsb25n\nIGFuZCB3b3Jk\nIGJhY2t3YXJk\nIHN0cmluZw==') ==
            (b'Very long and word backward string', 45))

   

# Generated at 2022-06-11 22:12:02.761658
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)  # type: ignore
    assert decoder is not None
    assert 'b64' == decoder.__name__



# Generated at 2022-06-11 22:12:03.747618
# Unit test for function register
def test_register():
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:12:06.949106
# Unit test for function register
def test_register():
    """Test the function register.

    Test that the ``b64`` codec is registered with Python.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # The codec is not registered.
        assert False
    assert True



# Generated at 2022-06-11 22:12:10.329374
# Unit test for function register
def test_register():
    register()

    # The registry should not register the codec if it is already registered.
    before = sorted(codecs.__DICT_ENCODING_NAME_TO_CODEC_INFO.keys())
    register()
    after = sorted(codecs.__DICT_ENCODING_NAME_TO_CODEC_INFO.keys())
    assert len(set(before)) == len(set(after)) == len(before) == len(after)
    assert before == after



# Generated at 2022-06-11 22:12:16.737160
# Unit test for function register
def test_register():
    """Test the :func:`~pylogix.util.b64_codec.register` function"""
    try:
        import b64_codec   # pylint: disable=unused-variable, import-outside-toplevel
        codecs.getdecoder(NAME)
    except LookupError:
        print('Cannot test b64_codec registration in this environment')
        return

    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-11 22:12:21.352416
# Unit test for function register
def test_register():
    """Test to validate the register function."""
    # pylint: disable=unused-variable
    assert not codecs.lookup(NAME)
    register()
    codec_info = codecs.lookup(NAME)
    codec_info.encode('hello world')
    codec_info.decode('Z29vZCBieXRl')
    # pylint: enable=unused-variable

# Generated at 2022-06-11 22:12:28.604190
# Unit test for function encode
def test_encode():
    """Test for function encode"""
    text = "Zm9vCmJhcgo="
    text_bytes =  b"foo\nbaz\n"
    out, len_out = encode(text)
    assert out == text_bytes
    assert len_out == len(text)

    text = "Zm9vIGJhcg=="
    text_bytes =  b"foo baz"
    out, len_out = encode(text)
    assert out == text_bytes
    assert len_out == len(text)


# Generated at 2022-06-11 22:12:30.291527
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:33.311745
# Unit test for function register
def test_register():
    """Unit test for ``register``"""
    if NAME == 'b64':
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            return False
        return True
    return True



# Generated at 2022-06-11 22:13:46.068687
# Unit test for function encode
def test_encode():
    assert encode('YQ==\n') == (b'a', 4)
    assert encode('YQ==\n') == (b'a', 4)
    assert encode('YWI=\n') == (b'ab', 4)
    assert encode('YWJj\n') == (b'abc', 4)
    assert encode('YWJjZA==\n') == (b'abcd', 6)

    assert encode('YWJjZGU=\n') == (b'abcde', 6)
    assert encode('YWJjZGVm\n') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==\n') == (b'abcdefg', 8)

# Generated at 2022-06-11 22:13:47.390020
# Unit test for function register
def test_register():
    b64 = codecs.lookup('b64').name
    assert b64 == NAME


# Generated at 2022-06-11 22:13:50.326602
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    item = codecs.getdecoder(NAME)
    assert item[0] is decode



# Generated at 2022-06-11 22:13:53.537719
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    assert _get_codec_info(NAME) is not None
    register()
    assert _get_codec_info(NAME) is not None



# Generated at 2022-06-11 22:13:57.533441
# Unit test for function encode
def test_encode():
    given_input = 'AAAAA\n' \
                  'BBBBB\n' \
                  'CCCCC\n'
    expected_output = b'AAAAABBBBBCCCCC'
    output, _ = encode(given_input)
    assert output == expected_output



# Generated at 2022-06-11 22:14:05.241222
# Unit test for function register
def test_register():
    test_cases=['b64']
    if NAME in test_cases:
        import sys
        import timeit
        from pprint import pprint
        from typing import List

        def main(argv: List[str]) -> int:
            dprint = pprint
            tname = f'{__name__}'
            func_names = [
                'register',
            ]
            for func_name in func_names:
                print(f"\nFunction '{tname}.{func_name}':")
                print(f"\tStart time: "
                      f"{timeit.default_timer():%Y-%m-%d %H:%M:%S}")
                print(f"\tFunction doc:\n{getattr({tname}, func_name).__doc__}")

# Generated at 2022-06-11 22:14:06.447875
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-11 22:14:09.013582
# Unit test for function register
def test_register():  # pylint: disable=W0613
    """Unit test for function register"""
    try:
        codecs.getencoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
        assert codecs.getencoder(NAME)

# Generated at 2022-06-11 22:14:11.901356
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)  # type: ignore
    assert decoder == (decode, None)



# Generated at 2022-06-11 22:14:17.655128
# Unit test for function register
def test_register():
    """Unit test for function register.
    """
    import sys
    old_getdecoder = getattr(sys.modules['codecs'], 'getdecoder')

    def side_effect(*args: str, **kwargs: str) -> None:
        raise LookupError

    setattr(sys.modules['codecs'], 'getdecoder', side_effect)
    register()
    setattr(sys.modules['codecs'], 'getdecoder', old_getdecoder)