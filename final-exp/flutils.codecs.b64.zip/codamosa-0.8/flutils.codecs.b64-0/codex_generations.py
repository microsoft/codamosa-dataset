

# Generated at 2022-06-11 22:04:38.536804
# Unit test for function encode
def test_encode():
    assert encode('ZG9ua19uZV9jb252ZXJ0IQ==') == (b"don't_ne_convert!", 25)
    assert encode('Q2hlY2sgb3V0IHRoZXNlIGJhc2U2NCBjaGFyYWN0ZXJz') == (b'Check out these base64 characters', 52)



# Generated at 2022-06-11 22:04:42.804481
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:04:44.259238
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    _test_codec_registration(NAME, encode, decode)

# Generated at 2022-06-11 22:04:46.853833
# Unit test for function register
def test_register():
    """Test the register() function."""
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:04:51.081434
# Unit test for function register
def test_register():
    """Unit test for registering the codec with Python."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec was not registered.'


# Generated at 2022-06-11 22:04:58.293752
# Unit test for function register
def test_register():
    import sys
    from . import shared

    # Remove the test module from the path.
    for _ in range(sys.path.count(shared.TEST_MODULE_DIR)):
        sys.path.remove(shared.TEST_MODULE_DIR)

    # Load the b64 module
    # noinspection PyPep8
    import b64

    # noinspection PyShadowingNames
    # pylint: disable=W0612
    def f():
        # Register the b64.b64 codec
        b64.register()

        # Retrieve the b64.b64 codec
        codecs.getdecoder(b64.NAME)  # Force exception if codec not present

    # Run the function
    f()

    # Put the test module back on the path.

# Generated at 2022-06-11 22:05:05.500354
# Unit test for function encode
def test_encode():
    assert encode('Iw==') == (b'2', 3)
    assert encode('IgM=') == (b'2 3', 4)
    assert encode('IgMgNCA1') == (b'2 3 4 5', 8)
    assert encode('IgMgNCA1IDYKNyA4IAo5') == (b'2 3 4 5 6\n7 8 \n9', 14)


if __name__ == '__main__':
    test_encode()
    test_decode()

# Generated at 2022-06-11 22:05:11.625875
# Unit test for function register
def test_register():
    """Test function register()."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj.decode(   # type: ignore[call-overload]
        'YQ=='
    ) == ('a', 2)
    assert obj.encode(   # type: ignore[call-overload]
        'a'
    ) == ('YQ==', 1)

# Generated at 2022-06-11 22:05:17.747087
# Unit test for function register
def test_register():
    """Test the ``register`` function of this module."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # There should not be an error when the function is called
        # because the 'b64' codec has not yet been registed.
        register()

        # Get the 'b64' decoder.
        codecs.getdecoder(NAME)
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise AssertionError(f'Failed to register the {NAME} codec.')


# Generated at 2022-06-11 22:05:23.889529
# Unit test for function encode
def test_encode():
    """Test function encode"""
    # To run this test:
    #   python -m doctest -v test_codec.py # Note: the function name has to
    #   be in the form test_<function name>.
    #
    import doctest
    doctest.testmod()


# Generated at 2022-06-11 22:05:28.289631
# Unit test for function register
def test_register():
    """Unit test for function register"""


# vim: fileencoding=utf-8 filetype=python ts=4 sw=4 et tw=78

# Generated at 2022-06-11 22:05:31.018373
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:42.505341
# Unit test for function encode

# Generated at 2022-06-11 22:05:53.579159
# Unit test for function encode

# Generated at 2022-06-11 22:05:55.660780
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:58.389276
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:06:02.449115
# Unit test for function register
def test_register():
    """Tests for function ``register``."""
    register()
    # noinspection PyTypeChecker
    codecs.getdecoder(NAME)
    # noinspection PyTypeChecker
    codecs.getencoder(NAME)


# Unit test

# Generated at 2022-06-11 22:06:09.671191
# Unit test for function register
def test_register():
    # Get the current list of codecs and check that 'b64' is not in the list.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, "Register did not work (1)"

    # Call register and get the list of codecs again and check that 'b64'
    # is now in the list.
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Register did not work (2)"



# Generated at 2022-06-11 22:06:16.864170
# Unit test for function encode
def test_encode():
    from base64 import b64encode

    text_bytes = b64encode(b'\xde\xad\xbe\xef')
    text_str = text_bytes.decode('ascii')

    expected = text_bytes
    actual, _ = encode(text_str)

    assert(expected == actual)
    return None



# Generated at 2022-06-11 22:06:18.902176
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:30.312063
# Unit test for function register
def test_register():
    """Assert that the b64 codec is registered with Python."""
    # Remove the b64 codec from Python and assert it is gone.
    codecs.__dict__['_cache'].pop(NAME, None)
    codecs.__dict__['_unknown_encoding_error'].pop(NAME, None)

    # Assert the b64 codec is not found.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the b64 codec.
    register()

    # Assert the b64 codec is found now.
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:33.598441
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:06:44.253618
# Unit test for function register
def test_register():
    """
    The register function is tested by checking for two different conditions.
    1. When the register function is called, the codec ``b64`` should be
        registered.
    2. When the register function is called more than once, the ``b64``
        codec should still be registered.
    """
    # Verify that the b64 codec is not yet registered.
    try:
        codecs.getdecoder('b64')
    except LookupError:
        pass
    else:
        assert False, 'The b64 codec is already registered'

    # Register the b64 codec.
    register()
    try:
        codecs.getdecoder('b64')
    except LookupError:
        assert False, 'The b64 codec is not registered'

    # Register the b64 codec again.
    register()

# Generated at 2022-06-11 22:06:54.490466
# Unit test for function encode
def test_encode():
    assert encode('TmljayB' + '\u0003' + 'A==') == (b'Nic\x03', 5)
    assert encode('\n') == (b'', 1)
    assert encode('\r') == (b'', 1)
    assert encode('\t') == (b'', 1)
    assert encode(' ') == (b'', 1)
    assert encode('\n\t\r ') == (b'', 4)
    assert encode('\n\t\r ' + 'TmljayB' + '\u0003' + 'A==') == (b'Nic\x03', 9)


# Generated at 2022-06-11 22:07:00.940778
# Unit test for function register
def test_register():
    """Test the function :func:`~register`"""
    codecs.register(_get_codec_info)
    result1 = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    result2 = codecs.getdecoder(NAME)
    assert result1 == result2, 'Multiple registrations of the codec failed'

# Unit tests for function encode

# Generated at 2022-06-11 22:07:05.249345
# Unit test for function register
def test_register():
    """Unit test for function register."""
    from codecs import getdecoder
    from codecs import getencoder
    register()
    decoder = getdecoder(NAME)
    assert decoder is not None
    encoder = getencoder(NAME)
    assert encoder is not None
    assert NAME in codecs.__all__



# Generated at 2022-06-11 22:07:06.874480
# Unit test for function register
def test_register():
    if __name__ == '__main__':
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:10.420958
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register"""

    register()

    # Test that the codec exists.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register function register'



# Generated at 2022-06-11 22:07:16.880148
# Unit test for function register
def test_register():
    """
    Ensure that the ``b64`` codec properly registers itself.
    """
    from importlib import reload
    from multiprocessing import Process
    from queue import Queue
    from time import sleep
    from urllib.request import urlopen
    from xmlrpc.server import SimpleXMLRPCServer

    xmlrpc_server_port = 9000
    xmlrpc_server_url = (
        f'http://127.0.0.1:{xmlrpc_server_port}/RPC2'
    )

    def _xmlrpc_server():
        """Run the XML-RPC server."""

# Generated at 2022-06-11 22:07:19.452008
# Unit test for function register
def test_register():
    assert NAME not in codecs.lookup()
    register()
    assert NAME in codecs.lookup()



# Generated at 2022-06-11 22:07:28.919539
# Unit test for function register
def test_register():
    """Unit test for function register"""
    from importlib import reload
    import test_register_b64
    test_register_b64.register()

    # Reload the codecs module to clear out the previous codecs
    codecs = reload(codecs)

    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


register()

# Generated at 2022-06-11 22:07:35.324124
# Unit test for function register
def test_register():
    register()
    expected = NAME
    actual = codecs.getencoder(NAME).__name__
    assert expected == actual
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-11 22:07:38.878188
# Unit test for function register
def test_register():  # pylint: disable=unused-argument
    """Unit test for function register"""
    register()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:07:40.794649
# Unit test for function register
def test_register():
    """Test the ``register()`` function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:46.880713
# Unit test for function register
def test_register():
    """Unit Test Function"""
    _export = "__all__"
    globals()[_export] = list(filter(lambda k: not k.startswith('_'), globals().keys()))
    try:
        register()
        codecs.getencoder(NAME)
    except LookupError as e:
        print(f'{e}; {NAME!r}')
        raise

# Generated at 2022-06-11 22:07:49.815316
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Could not find b64 codec'

# Generated at 2022-06-11 22:07:51.315015
# Unit test for function register
def test_register():
    try:
        codecs.register(_get_codec_info)
    except LookupError:
        pass

# Generated at 2022-06-11 22:07:54.014863
# Unit test for function register
def test_register():
    """Test function register."""
    codecs.register(_get_codec_info)   # type: ignore
    codecs.getencoder(NAME)   # type: ignore



# Generated at 2022-06-11 22:07:59.056314
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    _TEST_STR = r'''
        aGVsbG8gd29ybGQgMDAxMjM0NTY3ODkwMTIzNA==
        YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    _TEST_BYTES = b'hello world 001234567890'
    _TEST_BYTES += bytes(range(16))
    encoded_str, _ = encode(_TEST_BYTES)
    assert _TEST_STR == encoded_str



# Generated at 2022-06-11 22:08:00.067714
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:08:09.832252
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
    assert True

# Unit tests for function encode

# Generated at 2022-06-11 22:08:19.268602
# Unit test for function encode
def test_encode():  # pragma: no cover
    # Normal case
    input_text = '''\
    TUVXRlRXUldRVUZRVUZUVlRUVlVRVVdRVlRUWVVUWVdRVVVU
    VUZRVUZUVVRUWVVUWlVRVlVUVUVRVlVTVFRVV1VRVUZRVUZUV
    UVRVlVRVlVUVVVUWlVRVlVUVUVRVlVRVlVUVVVUWlVRVlVUVU
    VRVlVRVlVUVVVUWlVRVlVUVUVRVlVRVlVUVVVUWlVRVlVUVUV
    RVlVRVlVU'''

# Generated at 2022-06-11 22:08:30.300122
# Unit test for function encode

# Generated at 2022-06-11 22:08:36.729724
# Unit test for function register
def test_register():
    # Setup
    expected_name = 'b64'
    expected_errors_type = str
    # Exercise
    register()
    codec_info = codecs.getdecoder(expected_name)
    actual_name = codec_info.name
    actual_errors_type = type(codec_info.errors)
    # Verify
    assert actual_name == expected_name
    assert actual_errors_type is expected_errors_type
# Setup:
test_register()


# Generated at 2022-06-11 22:08:40.253175
# Unit test for function register
def test_register():
    """Unit test for ``register``."""
    # Define the codec name
    codec_name = 'b64'

    # Register the codec
    register()

    # Attempt to get the codec and confirm it is the same as 'b64'
    assert codec_name == codecs.getdecoder(codec_name)[0].name


# Generated at 2022-06-11 22:08:45.097013
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:08:49.369503
# Unit test for function register
def test_register():
    """Unit test for function register."""
    with mock.patch(
            'codecs.register',
            return_value=None,
            autospec=True
    ) as mock_register:
        register()
        mock_register.assert_called_once()

# Generated at 2022-06-11 22:09:00.507627
# Unit test for function register
def test_register():
    """Confirm that the ``b64`` codec can be registered with Python.

    Note:
        It is not possible to register the ``b64`` codec twice.
        With this limitation there is no test that verifies that the
        ``b64`` codec can be registered twice.

    """
    # pylint: disable=protected-access,bare-except
    before = len(codecs.__all__)  # pylint: disable=no-member
    try:
        register()
    except:
        # The 'b64' codec has already been registered
        pass
    after = len(codecs.__all__)  # pylint: disable=no-member
    assert after == before + 1, (
        'Failed to register the b64 codec with Python.'
    )



# Generated at 2022-06-11 22:09:02.624455
# Unit test for function register
def test_register():
    """Unit test for register."""
    register()
    codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:09:12.344802
# Unit test for function encode
def test_encode():
    """Test the encode function of the b64 codec. 
    """

# Generated at 2022-06-11 22:09:20.656005
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:22.382863
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:09:32.607106
# Unit test for function register
def test_register():
    from .functools import to_bytes
    from .test.test_base64 import TestBase64
    test = TestBase64()
    test.test_b64_str()
    data_str = 'Hello world!'
    encoded_str = 'SGVsbG8gd29ybGQh'
    # Test encoding
    result = encode(data_str)
    assert encoded_str == result[0].decode('ascii')
    # Test decoding
    result = decode(to_bytes(encoded_str))
    assert data_str == result[0]
    assert len(encoded_str) == result[1]
    # Test the codecs module.
    encoded_bytes = bytes(encoded_str, encoding='utf-8')
    decoded_str = data_str
    encoded = codecs.encode

# Generated at 2022-06-11 22:09:35.651565
# Unit test for function register
def test_register():
    # This function is designed to be called once.  Calling it a second
    # time should cause an exception.
    register()
    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:09:37.684395
# Unit test for function register
def test_register():
    register()
    decode('b64:eW91IGNhbirigKY=')



# Generated at 2022-06-11 22:09:47.371978
# Unit test for function encode
def test_encode():
    # Simple encode.
    in0 = str('YmluamFtYQ==')
    out0, _ = encode(in0)
    assert out0.decode() == 'bjamama'
    # Encode with spaces.
    in0 = str('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=')
    out0, _ = encode(in0)
    assert out0.decode() == 'abcdefghijklmnopqrstuvwxyz'
    # Encode with spaces and newline.

# Generated at 2022-06-11 22:09:59.481687
# Unit test for function encode
def test_encode():    # type: ignore
    """Test the base64.encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4=') == (b'abcdefghijklmnopqrstuvwxyz', 36)
    try:
        encode('a')
    except UnicodeEncodeError as e:
        assert e.reason == "'a' is not a proper bas64 character string: Incorrect padding"
        assert e.start == 0
        assert e.end == 1


# Generated at 2022-06-11 22:10:12.173955
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""

    from binascii import Error as BinasciiError
    from unittest.mock import patch


# Generated at 2022-06-11 22:10:17.171829
# Unit test for function encode
def test_encode():
    # Happy path
    # --------------
    # Test the encode function with a string of valid base64 characters
    # The given string is:
    # 'BASE64 is the Encoding Scheme that was proposed by \
    # John G.\nMitchell and Peter J.\nStern in RFC 1421.\n\n'
    # (The "backslashes" are using literals)
    input_str = 'BASE64 is the Encoding Scheme that was proposed by ' \
                'John G.\nMitchell and Peter J.\nStern in RFC 1421.\n\n'

    # The expected output is a tuple of:
    #   (bytes, int)
    # The bytes are:
    # b'BASE64 is the Encoding Scheme that was proposed by John G.\n'
    #  b'Mitchell

# Generated at 2022-06-11 22:10:24.596955
# Unit test for function encode
def test_encode():
    print('encode() ...')
    input_str = """
    drwxrwxrwx 1 root root  4096 Mar  9  2010 .
    drwxrwxrwx 1 root root  4096 Mar  9  2010 ..
    -rwxrwxrwx 1 root root 10189 Sep 26  2007 .index.php
    """
    out, len_out = encode(input_str)
    assert(len_out == len(input_str))

# Generated at 2022-06-11 22:10:50.746863
# Unit test for function register
def test_register():
    """
    Test to verify the register() function registers the b64 codec
    with Python.

    Returns:
        None

    """
    import codecs  # pylint: disable=import-outside-toplevel
    # Test the code by running it.  If an exception is raised, the
    # test fails.
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    # Register the `b64` codec with Python
    register()

    # Base cases.
    assert decode(b'AA==') == ('', 1)
    assert decode(b'') == ('', 0)

    # Current test cases. The output values are encoded as base64
    # characters.  The input values are encoded as base64 bytes.

# Generated at 2022-06-11 22:10:54.971020
# Unit test for function register
def test_register():
    # If the codec has already been registered, then the following statement
    # will raise a LookupError exception.  No exception means that the codec
    # has not yet been registered
    codecs.getencoder(NAME)
    # Register the 'b64' codec.
    register()
    # The codec should now be registered and the following lookup should
    # succeed.
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:10:57.365377
# Unit test for function register
def test_register():  # noqa: D103
    register()
    codecs.getencoder(NAME)  # type: ignore
    codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:11:01.295369
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    register()
    has_codecs = True
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        has_codecs = False
    assert has_codecs



# Generated at 2022-06-11 22:11:08.539528
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8gd29ybGQh') == (b'Hello world!', 16)
    assert encode(
        '''SGVsbG8gd29ybGQh
        bXkgbmFtZSBpcyBjb2RlciEh'''
    ) == (b'Hello world!\nmy name is codeci!', 41)
    try:
        encode('ABCD')
        raise AssertionError('encode did not raise an exception.')
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-11 22:11:18.265560
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # codecs.register is used in the try/except block.  However, due
    # to the fact that we are registering the codec and then unregistering
    # the codec, this codec is used in the except block.  So, we need to
    # ignore the pylint warning of pylint: disable=used-before-assignment.
    # pylint: disable=used-before-assignment
    # unregister the module, first.
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)

    register()
    assert codecs.lookup_error(NAME) is not None



# Generated at 2022-06-11 22:11:27.687492
# Unit test for function register
def test_register():
    import codecs
    register()
    decoder = codecs.getdecoder(NAME)
    assert str == decoder('ZW1haWw6c2RmQGd1aWxmy5jb20=')[0]
    encoded_str, len_used = codecs.getencoder(NAME)('email:sdg@guilf.com')
    assert 'ZW1haWw6c2RmQGd1aWxmy5jb20=' == encoded_str
    assert 15 == len_used

# unit test for encode

# Generated at 2022-06-11 22:11:37.815747
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    import sys
    if sys.version_info.minor >= 8:
        from tempfile import TemporaryDirectory
    else:
        from backports.tempfile import TemporaryDirectory

    register()

    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        pyname_path = tmp_path.joinpath('test_codecs.py')
        pyname_path.write_text(
            dedent(
                """
                #!/usr/bin/env python3.8
                import b64
                import sys
                b64.register()
                name = sys.argv[1]
                codecs.getdecoder(name)
                """
            )
        )
        pyname_path.chmod(0o755)
        subprocess.check

# Generated at 2022-06-11 22:11:39.827275
# Unit test for function register
def test_register():
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:11:42.556130
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.register(_get_codec_info)
    assert NAME in codecs.getdecoder('b64')


# Generated at 2022-06-11 22:11:57.817309
# Unit test for function register
def test_register():
    # Call the function to be tested
    r = register()
    # Verify the results
    assert r is None



# Generated at 2022-06-11 22:12:01.050022
# Unit test for function encode
def test_encode():
    assert encode('The quick brown fox jumps over the lazy dog')\
           == (b'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZw==', 43)

# Generated at 2022-06-11 22:12:08.949738
# Unit test for function encode
def test_encode():
    test_data = {
        "": "",
        "a": "YQ==",
        "aa": "YWE=",
        "aaa": "YWFh",
        "aaaa": "YWFhYQ==",
        "aaaaa": "YWFhYWE=",
        "aaaaaa": "YWFhYWFh",
        "Hello World!": "SGVsbG8gV29ybGQh",
        "Hello\tWorld!": "SGVsbG8gV29ybGQh",
        "!@#$%^&*()": "IUAjJCVeJiooKQ==",
        "xyz1234567890": "eHl6MTIzNDU2Nzg5MA==",
    }

    for text in test_data:
        expected = test

# Generated at 2022-06-11 22:12:17.043742
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert str(e) == f'LookupError: {NAME!r} is not a registered codec.'

    # Register the codec.
    register()          # type: ignore

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert False, (
            'Failed to register the {!r} codec.  The error returned was '
            '{!r}'.format(NAME, str(e))
        )


# pylint: disable=W0611

# Generated at 2022-06-11 22:12:19.087681
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    assert True, 'function register() did not raise an exception'

# Generated at 2022-06-11 22:12:22.987137
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    test_codec = codecs.getdecoder(NAME)
    assert test_codec is not None, 'Failed to register the b64 codec'

# Generated at 2022-06-11 22:12:27.122208
# Unit test for function register
def test_register():
    """Test the function register."""
    from pyshexc.parser_impl.codecs_py import unregister

    unregister()
    assert codecs.getdecoder(NAME) is None  # type: ignore
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore

# Generated at 2022-06-11 22:12:35.861575
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8gV29ybGQ=') == (b'Hello World', 14)
    assert encode('  c2hh  c2hh    c2hh  c2hh plo=') == (b'\x00\x00\x00\x00\x00', 20)
    text = '''
    SGVsbG8gV29ybGQ=   SGEgaGVsbG8gV29ybGQ=


    c2hh    c2hh   c2hh  c2hh
    plo='''
    assert encode(text) == (b'Hello World\x00Hello World\x00\x00\x00\x00\x00', 42)
    # Test non-base64 text.

# Generated at 2022-06-11 22:12:46.336391
# Unit test for function register
def test_register():
    from _pytest.monkeypatch import MonkeyPatch
    from py._path.local import LocalPath

    class _MockLocalPath:
        def __init__(
                self,
                **kwargs
        ):
            setattr(self, 'read', kwargs['read'])

    class _MockCodecs:
        def __init__(self):
            self.register_info = dict()

        def getdecoder(self, name):
            if name in self.register_info:
                return self.register_info[name]
            raise LookupError

        def register(self, info):
            name = info.name
            self.register_info[name] = info


# Generated at 2022-06-11 22:12:50.895536
# Unit test for function register
def test_register():
    # Register the codec
    register()
    name = NAME
    codecs.getdecoder(name)
    try:
        codecs.getencoder(name)
    except LookupError as e:
        assert 'encoder' in str(e)



# Generated at 2022-06-11 22:13:05.417005
# Unit test for function register
def test_register():  # noqa: D103
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:08.451862
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    obj = codecs.getencoder(NAME)
    assert obj is not None and callable(obj)
    obj = codecs.getdecoder(NAME)
    assert obj is not None and callable(obj)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:13.908674
# Unit test for function register
def test_register():
    """Test the function register()."""
    codecs.getdecoder(NAME)
    try:
        codecs.getencoder(NAME)
    except LookupError:
        print(
            'encoder for codecs name:', NAME, 'is not registered with Python'
        )
        raise



# Generated at 2022-06-11 22:13:25.354710
# Unit test for function register
def test_register():
    """Test register"""
    register()
    # noinspection PyUnresolvedReferences
    codecs.getencoder(NAME)
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)
    # codecs.lookup(NAME)
    # codecs.encode(b'abcdefg', NAME)
    # codecs.decode(b'abcdefg', NAME)
    # codecs.encode(b'abcdefg', 'b64')
    # codecs.decode(b'abcdefg', 'b64')
    # codecs.encode('YWJjZGVmZw==', NAME)
    # codecs.decode('YWJjZGVmZw==', NAME)
    # codecs.encode('YWJjZGVmZw==

# Generated at 2022-06-11 22:13:27.400728
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:13:32.630020
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered with Python."""
    # pylint: disable=protected-access,unused-variable
    from codecs import __codecs__
    from io import StringIO
    from unittest import mock
    from contextlib import redirect_stdout
    register()
    assert NAME in __codecs__, \
        "The 'b64' codec must be registered in Python's codecs module."
    f = StringIO()
    with redirect_stdout(f):
        codecs.lookup(NAME)
    assert f.getvalue().startswith('<codecs.CodecInfo object for encoding b64')


if __name__ == '__main__':
    """Execute the ``b64`` codec unit tests."""
    test_register()

# Generated at 2022-06-11 22:13:38.732784
# Unit test for function register
def test_register():
    from unittest import TestCase, main
    from unittest import mock

    class Test(TestCase):
        def test(self):
            with mock.patch('builtins.__import__', return_value=mock.MagicMock) as mock_import:
                register()

                mock_import.assert_has_calls(
                    [
                        mock.call('codecs'),
                        mock.call().getdecoder(NAME),
                    ],
                    any_order=True
                )
                mock_import.return_value.register.assert_called_once_with(_get_codec_info)

    main()

# Generated at 2022-06-11 22:13:41.839779
# Unit test for function register
def test_register():
    """Ensure that we can register the 'b64' encode."""
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:13:44.134136
# Unit test for function register
def test_register():
    """Unit test for function register()."""
    codecs.lookup_error('asdfzxvc')


# Run the ``test_register`` function when this module is run directly.
if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:48.559859
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    assert NAME == codecs.getdecoder(NAME).name  # type: ignore
    assert NAME == codecs.getencoder(NAME).name  # type: ignore
    # Now unregister
    codecs.unregister(NAME)

# Generated at 2022-06-11 22:14:05.080153
# Unit test for function register
def test_register():
    register()
    # Check that the codec is registered.
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:14:11.098801
# Unit test for function register
def test_register():
    "Run as 'python b64.py' from the command line."

# Generated at 2022-06-11 22:14:14.193264
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj.name == NAME
    assert obj.decode is decode
    assert obj.encode is encode



# Generated at 2022-06-11 22:14:15.620767
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)


# Generated at 2022-06-11 22:14:21.825015
# Unit test for function register
def test_register():
    # Simple line decode case
    assert b64decode("Zm9v").decode("utf-8") == "foo"
    # Simple line encode case
    assert encode("foo")[0].decode("utf-8") == "Zm9v"
    # Handling of indentation and line breaks.
    assert b64decode("Zm\n9v\n").decode("utf-8") == "foo"
    # Handling of errors
    with raises(UnicodeEncodeError):
        encode("A?")[0].decode("utf-8")

# Generated at 2022-06-11 22:14:24.146156
# Unit test for function register
def test_register():
    """Unit test that the ``b64`` codec is registered with Python."""
    register()
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:14:26.899633
# Unit test for function register
def test_register():
    # Setup:
    codecs.register(_get_codec_info)

    # Execute
    register()

    # Verify
    # Code will raise LookupError if codec was not registered.



# Generated at 2022-06-11 22:14:36.624266
# Unit test for function encode
def test_encode():
    # Test 1

    # Setup
    text_input = 'U3ByaW5nIFRoaXM=\n'

    # Run
    out, consumed_len = encode(text_input)

    # Verify
    assert out == b'Spring This'
    assert consumed_len == len(text_input)

    # Test 2

    # Setup
    text_input = 'U2hhcmUgdGhpcyBhY3JvdXNlbGluZSBvbmNlIGFuZCBhbGwK\n'

    # Run
    out, consumed_len = encode(text_input)

    # Verify
    assert out == b'Share this acrobatsline once and all'
    assert consumed_len == len(text_input)

    # Test 3

    # Setup