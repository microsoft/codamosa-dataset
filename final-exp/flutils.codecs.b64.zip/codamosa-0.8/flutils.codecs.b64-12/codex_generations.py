

# Generated at 2022-06-11 22:04:40.522733
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # Make sure we get a LookupError since the ``b64`` codec is not
    # yet registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    codecs.register(_get_codec_info)  # type: ignore

    # Make sure we can get the codec decoder.
    assert codecs.getdecoder(NAME)  # type: ignore

    # Unregister the ``b64`` codec.
    codecs.unregister(NAME)



# Generated at 2022-06-11 22:04:48.287600
# Unit test for function register
def test_register():
    """Verify that the codec is registered with Python."""
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False,\
            f'Encoding Error: The codec named {NAME!r} is not registered.'

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False,\
            f'Decoding Error: The codec named {NAME!r} is not registered.'

    assert True


# Generated at 2022-06-11 22:04:49.802213
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec registered with Python."""
    register()

# Generated at 2022-06-11 22:04:58.107261
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    import codecs
    try:
        _ = codecs.getdecoder('b64')
    except LookupError:
        # The 'b64' codec has not been registered; register it.
        register()

        # The 'b64' codec has been registered; get the 'b64' decoder.
        b64dec = codecs.getdecoder('b64')

        # Decode a base64 encoded string
        b64dec_str, _ = b64dec(b'VGhpcyBpcyBhIHN0cmluZyB0byBiZSBlbmNvZGVkLg==')

        # Encode a string in base64
        b64enc = codecs.getencoder('b64')

# Generated at 2022-06-11 22:05:07.750692
# Unit test for function encode
def test_encode():
    assert encode('QQ==\n') == (b'\xde', 4)
    assert encode('YXNkLg==') == (b'asd.', 8)
    assert encode('YXNkLg==\n') == (b'asd.', 9)
    assert encode('YXNkLg==\n\n') == (b'asd.', 11)

    my_str = 'YXNkLg=='
    other_str = UserString(my_str)
    assert encode(other_str) == (b'asd.', 8)

    try:
        encode('Not a base64 string')
    except UnicodeEncodeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 22:05:11.710034
# Unit test for function register
def test_register():
    # pylint: disable=C0103
    try:
        register()
    except Exception as e:  # pylint: disable=W0703
        raise Exception(e)



# Generated at 2022-06-11 22:05:13.544795
# Unit test for function register
def test_register():
    """Test the module's register function."""
    codecs.register(register)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:15.174129
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:21.732816
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    import sys
    import collections

    register()

    codec = NAME
    # Test that the registered codec is contained in the sys.codec_info
    assert codec in sys.codec_info.keys()   # type: ignore
    # Test that the registered codec is contained in the sys.codecs.decoders
    assert codec in sys.codecs.decoders.keys()  # type: ignore
    # Test that the registered codec is contained in the sys.codecs.decoders
    assert codec in sys.codecs.decoders.keys()  # type: ignore

    # Test that the registered codec is contained in the sys.codec_info
    ci = collections.namedtuple('ci', ['name'])

# Generated at 2022-06-11 22:05:23.252699
# Unit test for function register
def test_register():
    register()  # type: ignore
    r = codecs.getdecoder(NAME)  # type: ignore
    assert callable(r)

# Generated at 2022-06-11 22:05:30.721831
# Unit test for function register
def test_register():
    """Test the function register."""
    assert NAME not in codecs.getdecoder(NAME)
    assert NAME not in codecs.getencoder(NAME)
    register()
    assert NAME in codecs.getdecoder(NAME)
    assert NAME in codecs.getencoder(NAME)



# Generated at 2022-06-11 22:05:40.747080
# Unit test for function encode
def test_encode():
    for test_id, test_data in enumerate((
            ('YWJjZGVm', b'abcdef'),
            ('', b''),
            ('Zm9vYmFy', b'foobar'),
            ('Zm9vYg==', b'foob'),
            ('Zm9vYmE=', b'fooba'),
    )):
        text = test_data[0]
        data = test_data[1]
        out = encode(text)
        assert out[0] == data, 'id: %s' % test_id



# Generated at 2022-06-11 22:05:43.366540
# Unit test for function register
def test_register():
    """Glue function to allow the function register() to be imported
    into other modules and be unit tested.
    """
    register()


# Generated at 2022-06-11 22:05:45.404330
# Unit test for function encode
def test_encode():
    assert encode('QQ==')[0] == b'\x01'



# Generated at 2022-06-11 22:05:54.845681
# Unit test for function register
def test_register():
    try:
        # pylint: disable=import-outside-toplevel
        import b64
    except ImportError:
        # noinspection PyUnreachableCode
        if __name__ == '__main__':
            sys.path.insert(0, '.')
            import b64
        else:
            raise
    try:
        b64.register()
    except LookupError:
        if python_major_version == 2 or (
                python_major_version == 3 and
                python_minor_version == 6 and
                python_micro_version < 10
        ):
            # The 'b64' codec was already registered.  It is not an error
            # for Python 2x and for Python 3.6 prior to 3.6.10.
            pass
        else:
            raise

# Generated at 2022-06-11 22:06:06.391542
# Unit test for function encode
def test_encode():
    """Ensure that test_encode() is properly decoding strings"""
    assert encode('') == (b'', 0)
    assert encode('A') == (b'A', 1)
    assert encode('a') == (b'a', 1)
    assert encode('C@') == (b'C@', 2)
    assert encode('C@8') == (b'C@8', 3)
    assert encode('C@8AA') == (b'C@8AA', 5)
    assert encode('C@8AA==') == (b'C@8AA==', 8)
    assert encode('C@8AA==   ') == (b'C@8AA==', 8)
    assert encode('C@8AA==\n  ') == (b'C@8AA==', 8)

# Generated at 2022-06-11 22:06:08.052556
# Unit test for function register
def test_register():
    """Verify that the 'register' function works."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:16.018867
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``"""

# Generated at 2022-06-11 22:06:23.335136
# Unit test for function register
def test_register():
    # pylint: disable=global-statement
    global register, codecs
    global NAME
    # Capture the original values
    register_orig = register
    codecs_orig = codecs
    NAME_orig = NAME

    # Create the codec values for testing.
    NAME = 'testname'

    # Perform the test.
    try:
        register()

        # Assert that the codec is registered.
        codecs.getdecoder(NAME)
    except Exception as e:
        raise Exception(f'FAILED: {e}') from e
    finally:
        # Restore the captured values
        register = register_orig
        codecs = codecs_orig
        NAME = NAME_orig



# Generated at 2022-06-11 22:06:26.118292
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    codecs.decode(b'', NAME)
    codecs.encode(b'', NAME)

# Generated at 2022-06-11 22:06:33.812423
# Unit test for function encode
def test_encode():
    tests = [
        {
            'text': '',
            'bytes': b'',
        },
    ]
    for i in range(0, 255):
        tests.append(
            {
                'text': chr(i),
                'bytes': bytes([i]),
            },
        )
    for test in tests:
        assert encode(test['text'])[0] == test['bytes']



# Generated at 2022-06-11 22:06:36.860928
# Unit test for function encode
def test_encode():
    """Unit Test"""
    assert encode(
        text='YmFzZTY0c3RyaW5n',
        errors='strict',
    )[0] == b'base64string'



# Generated at 2022-06-11 22:06:46.857690
# Unit test for function encode
def test_encode():
    input_data = (
        'Mr. and Mrs. Dursley, of number four, Privet Drive, were '
        'proud to say that they were perfectly normal, thank you very '
        'much. They were the last people you\'d expect to be involved '
        'in anything strange or mysterious, because they just didn\'t '
        'hold with such nonsense.'
    )

# Generated at 2022-06-11 22:06:59.678001
# Unit test for function encode
def test_encode():  # noqa: D103, D205, D400
    assert encode('AAAAAAAAAA==') == (b'\x00\x00\x00', 12)
    assert encode('AAAAAAAAA=') == (b'\x00\x00\x00', 12)
    assert encode('AAAAAAAAA') == (b'\x00\x00\x00', 12)
    assert encode('AAAAAAA=') == (b'\x00\x00\x00', 12)
    assert encode('AAAAAAA') == (b'\x00\x00\x00', 12)
    assert encode('AAAAAA=') == (b'\x00\x00\x00', 12)
    assert encode('AAAAAA') == (b'\x00\x00\x00', 12)

# Generated at 2022-06-11 22:07:08.601145
# Unit test for function encode
def test_encode():
    """Unit test of function encode."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8') == (b'hello', 5)
    assert encode('aGVsbG8=\n') == (b'hello', 6)
    assert encode('aGVsbG8\n') == (b'hello', 5)
    assert encode('aGVsbG8=    \n') == (b'hello', 6)
    assert encode('aGVsbG8    \n') == (b'hello', 5)
    assert encode('\n\n\naGVsbG8\n\n\n') == (b'hello', 5)

# Generated at 2022-06-11 22:07:15.998580
# Unit test for function encode
def test_encode():
    """Unit tests for ``encode()``"""
    # pylint: disable=W0612
    # pylint: disable=too-many-locals

    # Test the following:
    # 1. The function returns values of the proper types.
    # 2. The returned values are correct.
    # 3. The function handles indented strings
    # 4. The function handles multi-line strings
    # 5. The function handles strings that contains only whitespace
    # 6. The function handles a single line of base64 characters.
    # 7. The function raises a UnicodeEncodeError when given a string that
    #    is not a proper base64 character string.
    # 8. The function handles a string that is only a single non-base64
    #    character.
    # 9. The function handles an empty string.

    # Test 1, 2,

# Generated at 2022-06-11 22:07:21.917611
# Unit test for function register
def test_register():
    import doctest
    doctest.testmod(
        argv=['--doctest-modules', '-v'],
        verbose=True,
        # opcode_ignore=ignore_opcodes,
        # optionflags=doctest.ELLIPSIS,
        # name=__file__[:-3],
    )


# Generated at 2022-06-11 22:07:28.594270
# Unit test for function encode
def test_encode():
    # encode the base64 string 'aGVsbG8gd29ybGQ=' should return the bytes:
    # b'hello world'
    expect = b'hello world'
    text = "aGVsbG8gd29ybGQ="
    actual, _length = encode(text)
    assert actual == expect



# Generated at 2022-06-11 22:07:36.322531
# Unit test for function encode
def test_encode():
    # Test base64 string decode
    assert encode(
        "YQ==") == (
        b"a",
        4)

    # Test base64 string decoding with extra whitespace
    assert encode(
        "YQ== ") == (
        b"a",
        5)

    # Test base64 string decoding that across multiple lines
    assert encode('''
        YQ==''') == (
        b"a",
        10)

    # Test given text that is not a proper base64 string
    with pytest.raises(
            UnicodeEncodeError) as exc_info:

        encode("YQ")


# Generated at 2022-06-11 22:07:47.559689
# Unit test for function encode
def test_encode():
    text = '''
        VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZy4=
    '''
    text_clean = '''
        The quick brown fox jumps over the lazy dog.
    '''
    encoded_bytes, _ = encode(text)
    assert encoded_bytes == text_clean.encode()
    text_fail = '''VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZy5'''
    try:
        encode(text_fail)
    except UnicodeEncodeError:
        assert True
    else:
        assert False

# Unit test

# Generated at 2022-06-11 22:08:02.525799
# Unit test for function register
def test_register():
    # 1. Ensure that the given codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('The module is already registered.')

    # 2. Register the module.
    try:
        register()
    except Exception as e:
        print(f'Failed to register: {e}')
        raise

    # 3. Ensure that the codec is now registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'The module was registered but the name '
            f'"{NAME}" is not registered: {e}'
        ) from e


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:04.073064
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    register()

# Generated at 2022-06-11 22:08:14.986442
# Unit test for function encode
def test_encode():
    print("Testing encode")
    v = encode("/w==")
    assert v == (b'\x00', 4)

    v = encode("/w==","replace")
    assert v == (b'\x00', 4)

    v = encode("//////w==")
    assert v == (b'\x00', 10)

    v = encode("///////w==")
    assert v == (b'\x00', 10)

    v = encode("9/////w==")
    assert v == (b'\x00', 10)

    v = encode(b"//////w==")
    assert v == (b'\x00', 10)

    v = encode("/////w==")
    assert v == (b'\x00', 8)


# Generated at 2022-06-11 22:08:24.978988
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)

# Generated at 2022-06-11 22:08:32.903433
# Unit test for function encode

# Generated at 2022-06-11 22:08:41.289203
# Unit test for function register
def test_register():
    import sys

    # Save the original state of 'sys.modules'.
    original_sys_modules = sys.modules.copy()

    # Register the 'b64' codec with the Python encoding and decoding
    # functions.
    try:
        sys_modules = sys.modules.copy()
        register()
    except Exception:
        # Restore the state of 'sys.modules'
        sys.modules = sys_modules
        raise

    try:
        # See if the 'b64' codec was registered.
        b64_decoder = codecs.getdecoder('b64')  # type: ignore
        b64_encoder = codecs.getencoder('b64')  # type: ignore
    finally:
        # Restore the state of 'sys.modules'.
        sys.modules = original_sys_modules

    assert b64_decoder

# Generated at 2022-06-11 22:08:53.824403
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    import sys
    import os
    import tempfile

    filename = 'tempfile.txt'
    with tempfile.TemporaryDirectory() as temp_dir:
        file_path = os.path.join(temp_dir, filename)
        # Register the codec
        register()

        text = '\n'.join([
            '',
            '    SGVsbG8gV29ybGQ='
            '',
            '    ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        ])
        text_bytes = text

        # Encode 'text' into base64 and print the result to a file.
        with open(file_path, mode='wb') as file_out:
            file_out.write(text.encode(NAME))

        #

# Generated at 2022-06-11 22:08:57.382739
# Unit test for function register
def test_register():
    """Unit test for function register"""
    with unittest.mock.patch('codecs.register') as m_register:
        register()
        m_register.assert_called_once()


# Generated at 2022-06-11 22:08:59.779427
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:05.509193
# Unit test for function register
def test_register():
    """Test the register function with unregistering and reregistering."""
    # Already registerd?
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore
        registered = False
    else:
        registered = True

    register()

    try:
        codecs.getdecoder(NAME)
        assert True
    except LookupError:
        assert False

    if registered is False:
        codecs.unregister(NAME)
        try:
            codecs.getdecoder(NAME)
            assert False
        except LookupError:
            assert True



# Generated at 2022-06-11 22:09:24.425927
# Unit test for function register
def test_register():
    """Test for the function register."""
    # Unregister the 'b64' codec
    codecs.unregister(NAME)

    # Check that 'b64' is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the 'b64' codec
    register()

    # Check that the 'b64' codec is now registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:29.718609
# Unit test for function encode
def test_encode():
    """Tests the encode function"""
    assert encode('SGVsbG8=') == (b'Hello', 7)
    assert encode('SGVs bG8=') == (b'Helo', 7)
    assert encode('SGVsbG8= ') == (b'Hello', 8)
    assert encode(' SGVsbG8=') == (b'Hello', 8)


# Generated at 2022-06-11 22:09:35.003315
# Unit test for function register
def test_register():
    # noinspection PyProtectedMember
    codecs.__getcodec_cache.clear()

    # Assert that no codec found
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the b64 codec
    register()

    # Assert that the codec is now registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:38.510871
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    import sys
    sys.modules.pop(__name__, None)
    register()
    assert NAME in codecs.getdecoder(NAME)()  # type: ignore

# Generated at 2022-06-11 22:09:44.006257
# Unit test for function encode
def test_encode():
    tests = [
        ('\n'.join([
            'cHl0aG9u\n',
            'DQo='
        ]), b'python\n\n'),
    ]

    for text_input, expected in tests:
        out, _ = codecs.encode(text_input, NAME)
        assert expected == out
    return



# Generated at 2022-06-11 22:09:47.343228
# Unit test for function register
def test_register():
    """Test ``register`` function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None
    else:
        assert codecs.getdecoder(NAME) is not None


test_register()

# Generated at 2022-06-11 22:09:53.935943
# Unit test for function register
def test_register():
    """Verify that the codec is registered with Python."""
    try:
        codecs.getdecoder(NAME)
        assert False, 'Duplicate codec registration is not allowed.'
    except LookupError:
        pass
    assert codecs.lookup(NAME) is None, 'Codec is already registered.'
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:59.636878
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)
    register()
    if codecs.getdecoder(NAME) is None:  # type: ignore
        raise RuntimeError(f'Failed to register Codec {NAME}')



# Generated at 2022-06-11 22:10:09.955047
# Unit test for function register
def test_register():
    """Test Function"""
    # pylint: disable=W0212
    prev = codecs.CodecInfo._getdecoders.copy()
    codecs.CodecInfo._getdecoders.clear()

    codecs.register(lambda x: None)

    assert NAME not in codecs.CodecInfo._getdecoders
    register()
    assert NAME in codecs.CodecInfo._getdecoders

    codecs.CodecInfo._getdecoders.clear()
    codecs.CodecInfo._getdecoders.update(prev)



# Generated at 2022-06-11 22:10:20.926221
# Unit test for function register
def test_register():
    """Test function register()."""
    # Force the codec to be re-registered by calling register().
    register()

    # Find the codec info for the 'b64' codec.
    obj = codecs.getdecoder(NAME)

    # Verify the name is 'css'.
    assert obj.name == NAME  # type: ignore

    # Get the given bytes of the CSS encoded string,
    # '\u00FF' * 1000

# Generated at 2022-06-11 22:10:51.740834
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('TWFu') == (b'Man', 4)
    assert encode('TWFueg==') == (b'Many', 6)
    assert encode('TWFu aGVsbG8=') == (b'Man hello', 7)



# Generated at 2022-06-11 22:10:56.686285
# Unit test for function register
def test_register():
    """
    Unit test for :func:`register()`.
    """
    #: The codec name of this codec.
    codec_name = NAME
    #: The exepected codec object.
    expected = codecs.CodecInfo(
        decode=decode,
        encode=encode,
        name=codec_name,
    )

    #: The current codec object.
    actual = None
    try:
        actual = codecs.getdecoder(NAME)
    except LookupError:
        register()
        actual = codecs.getdecoder(NAME)

    # Assert the codec object is identical.
    assert actual == expected

# Generated at 2022-06-11 22:11:00.840652
# Unit test for function encode
def test_encode():  # noqa: D103
    """Unit test for function encode"""
    text = (
        'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    )
    print(text)
    print(encode(text))



# Generated at 2022-06-11 22:11:09.626996
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    from argparse import ArgumentParser
    from pathlib import Path
    from sys import stdin, stdout

    arg_parse = ArgumentParser()
    arg_parse.add_argument(
        '-i',
        '--input',
        default='-',
        type=Path,
        help=(
            'Path of the file to read input data.  Defaults to stdin.'
        )
    )
    arg_parse.add_argument(
        '-o',
        '--output',
        default='-',
        type=Path,
        help=(
            'Path of the file to write encoded data.  Defaults to stdout.'
        )
    )

# Generated at 2022-06-11 22:11:14.318726
# Unit test for function register
def test_register():

    def test_register() -> None:
        """Register the ``b64`` codec with Python."""
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            codecs.register(_get_codec_info)   # type: ignore

# Module test for function register

# Generated at 2022-06-11 22:11:22.677284
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    # Get the system wide codec registry.
    registry = codecs.lookup  # type: ignore

    # Has the encoding been registered?
    assert NAME not in registry

    # Register the encoding.
    register()

    # Has the encoding been registered?
    assert NAME in registry

    # Test the 'decode' method.
    out = registry[NAME].decode(b'AQIDBAUGBwgJCg==')   # type: ignore
    assert out == ('AQIDBAUGBwgJCg==', len(b'AQIDBAUGBwgJCg=='))

    # Test the 'encode' method.
    out = registry[NAME].encode('AQIDBAUGBwgJCg==')   # type: ignore
   

# Generated at 2022-06-11 22:11:26.851240
# Unit test for function register
def test_register():
    """Test that function register adds the codec to the codecs
    registry."""
    register()
    codecs.getencoder(NAME)


# pylint: disable=W0613

# Generated at 2022-06-11 22:11:36.404508
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass  # The b64 codec has not registered.  We want this.
    else:
        assert False, 'The b64 codec is already registered.  We need it to not be'
    register()
    obj = codecs.getdecoder(NAME)  # type: codecs.CodecInfo
    # Check that the codec was registered with the correct
    # decoding function.
    assert obj.decode == decode, 'Did not register the correct function'
    # Check that the codec was registered with the correct
    # encoding function.
    assert obj.encode == encode, 'Did not register the correct function'



# Generated at 2022-06-11 22:11:43.342141
# Unit test for function encode
def test_encode():
    # decode_text is the correct result - the expected result.
    decode_text = "AaBbCc"
    # text is the text to be decoded.
    text = "QQFiQmJDYw=="
    # Decode the text
    _bytes, _len = encode(text)
    assert decode_text == _bytes.decode()


# Generated at 2022-06-11 22:11:52.755392
# Unit test for function register
def test_register():
    """Test that this module registers with Python as a codec"""
    from os.path import abspath, dirname, join

    # Remove this module from sys.modules, so the register() function
    # will re-register the b64 codec.
    import sys
    mod = sys.modules[__name__]
    del sys.modules[__name__]
    # Reload the module, so the codecs.CodecInfo is recreated.
    import importlib
    mod = importlib.reload(mod)
    # Re-regester the codec.
    mod.register()

    # Import the codec now that it is registered.
    import codecs
    # Load the test data.

# Generated at 2022-06-11 22:12:55.683070
# Unit test for function register
def test_register():
    from sys import modules
    from pytest import raises

    from b64 import b64

    modules.pop('b64')
    with raises(KeyError, match='name \'b64\' is not defined'):
        codecs.getdecoder(b64)

    # pylint: disable=W0611
    # Just using the codec to register it.
    b64.register()

    reg_b64 = codecs.getdecoder(b64)
    assert reg_b64.name == b64
    assert reg_b64.decode == b64.decode
    assert reg_b64.encode == b64.encode



# Generated at 2022-06-11 22:13:01.421215
# Unit test for function register
def test_register():
    # pylint: disable=W0212
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        register()
        codecs.getdecoder(NAME)
test_register()

del test_register

# Register the codec with Python.
register()

# Generated at 2022-06-11 22:13:05.126590
# Unit test for function encode
def test_encode():
    assert encode('c3VyZS4=') == (b'sure.', 10)
    assert encode('c3VyZS4=\n') == (b'sure.', 11)


# Unit tests for function decode

# Generated at 2022-06-11 22:13:06.170779
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None


# Generated at 2022-06-11 22:13:09.178718
# Unit test for function register
def test_register():
    """test_register(test_register) -> None

    Register the b64 codec module with Python.

    Raises:
        AssertionError: The b64 codec failed to register.
        LookupError: The codec module has already been registered.
    """
    register()
    codec = codecs.getdecoder(NAME)  # type: ignore
    assert codec is not None



# Generated at 2022-06-11 22:13:14.152855
# Unit test for function encode
def test_encode():
    assert encode('a')[0] == b'YQ=='
    assert encode('ab')[0] == b'YWI='
    assert encode('abc')[0] == b'YWJj'
    assert encode('abcd')[0] == b'YWJjZA=='



# Generated at 2022-06-11 22:13:25.104252
# Unit test for function register
def test_register():
    """Unittest for function register"""
    codecs.register(_get_codec_info)   # type: ignore
    try:
        decoder = codecs.getdecoder(NAME)
        test_val = 'ImlhY2hhbmdlIHRoZSB3b3JsZCBhbmQgCmJlIHN1cnByaXNlZCB3aGF0IGhh' \
                   'cHBlbnMhCg=='
        assert decoder(test_val)[0] == 'I change the world and\n' \
                                       'be surprised what happens!\n'
    finally:
        del codecs.decode_error_registry[NAME]
        del codecs.encode_error_registry[NAME]    # type: ignore

# Generated at 2022-06-11 22:13:27.618839
# Unit test for function register
def test_register():
    # pylint: disable=protected-access
    """Test the register function."""
    register()
    codecs_registry = codecs._registry
    assert codecs_registry[NAME][0][0] == NAME


# Generated at 2022-06-11 22:13:32.885347
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # pylint: disable=unused-variable
    import tempfile
    import contextlib

    # Register the 'b64' codec
    register()

    # When the codec is registered, the b64 module should be able to be
    # imported.
    with contextlib.suppress(ImportError):
        import b64    # noqa

    # pylint: disable=E0611
    from b64 import codec  # noqa

    # Create a temporary test file.
    with tempfile.NamedTemporaryFile('w', encoding='b64') as file:
        # Write some text to the file
        text = 'Testing'
        file.write(text)
        file.flush()
        # Read the text back from the file, which should be the same as
        # it was written.


# Generated at 2022-06-11 22:13:35.897669
# Unit test for function register
def test_register():
    register()
    # pylint: disable=undefined-variable
    assert codecs.getdecoder(NAME) is not None


# Unit tests for function decode