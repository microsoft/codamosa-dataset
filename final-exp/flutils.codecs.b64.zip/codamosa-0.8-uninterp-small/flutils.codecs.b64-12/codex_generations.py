

# Generated at 2022-06-25 16:58:38.870870
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 16:58:39.695740
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 16:58:41.699692
# Unit test for function register
def test_register():
    try:
        register()
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 16:58:42.217468
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 16:58:43.550304
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 16:58:44.750730
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 16:58:46.557028
# Unit test for function register
def test_register():
    """Test that the codec is registered."""
    register()
    _ = codecs.getdecoder(NAME)


# Generated at 2022-06-25 16:58:50.887832
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        assert codecs.getdecoder(NAME) is not None
    else:
        assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-25 16:58:56.163619
# Unit test for function encode
def test_encode():
    # Test case 0:
    data = 'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual = base64.decodebytes(data.encode('utf-8'))
    assert actual == expected



# Generated at 2022-06-25 16:59:05.064231
# Unit test for function encode
def test_encode():
    register()
    # Case 0
    assert (encode('AA==') == (b'\x00', 4))
    # Case 1
    assert (encode('AAA=') == (b'\x00'*2, 4))
    # Case 2
    assert (encode('AAAA') == (b'\x00'*3, 4))
    # Case 3
    assert (encode('AAAB') == (b'\x00\x01', 4))
    # Case 4
    assert (encode('AAAC') == (b'\x00\x02', 4))
    # Case 5
    assert (encode('AAAD') == (b'\x00\x03', 4))
    # Case 6
    assert (encode('AAAE') == (b'\x00\x04', 4))
    # Case

# Generated at 2022-06-25 16:59:11.285081
# Unit test for function encode
def test_encode():
    test_case_0()

    # Check case 0
    text = "VGVzdCB0ZXN0"
    expected_out = b"Test test"
    out = codecs.encode(text, 'b64')
    assert out[0] == expected_out
    assert out[1] == len(expected_out)


# Generated at 2022-06-25 16:59:13.179801
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None
    assert codecs.lookup(NAME).name == NAME



# Generated at 2022-06-25 16:59:15.173739
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 16:59:18.766209
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__



# Generated at 2022-06-25 16:59:21.957384
# Unit test for function register
def test_register():
    assert_raises(
        LookupError,
        codecs.getdecoder,
        NAME
    )
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 16:59:30.495810
# Unit test for function encode
def test_encode():
    register()
    s = "Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure."
    bs = encode(s)
    assert bs[1] == len(s)

# Generated at 2022-06-25 16:59:31.715804
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 16:59:32.704982
# Unit test for function register
def test_register():
    # Test register()
    register()



# Generated at 2022-06-25 16:59:43.465036
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 16:59:44.375559
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 16:59:56.710284
# Unit test for function register
def test_register():
    import sys
    import builtins
    current = sys.getdefaultencoding()

# Generated at 2022-06-25 17:00:04.282874
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError as err:
        assert False, f'Expected encoder to be registered, but exception ' \
                      f'occurred: {str(err)}'
    try:
        codecs.getdecoder(NAME)
    except LookupError as err:
        assert False, f'Expected decoder to be registered, but exception ' \
                      f'occurred: {str(err)}'



# Generated at 2022-06-25 17:00:08.153107
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        assert True
    else:
        assert False



# Generated at 2022-06-25 17:00:10.075190
# Unit test for function encode
def test_encode():
    register()
    assert(encode(b'abcdefg') == (b'YWJjZGVmZw==', 2))


# Generated at 2022-06-25 17:00:11.465207
# Unit test for function register
def test_register():
    pass



# Generated at 2022-06-25 17:00:15.935451
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            msg = 'Unable to register the "b64" codec.'
            raise AssertionError(msg)
    else:
        msg = 'The "b64" codec is already registered'
        raise AssertionError(msg)



# Generated at 2022-06-25 17:00:21.011050
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register the "b64" codec.'
    else:
        assert True, '"b64" codec registered.'


# Generated at 2022-06-25 17:00:24.794984
# Unit test for function register
def test_register():
    # Verify that the 'NAME' can be decoded from the
    # codecs.getdecoder() function.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            'Failed to register the b64 codec with Python'
        )



# Generated at 2022-06-25 17:00:25.663204
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:00:30.284746
# Unit test for function register
def test_register():
    """
    Unit test for function register
    """
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:00:36.225377
# Unit test for function register
def test_register():
    """Test the function register"""
    from codecs import CodecInfo

    # Test that Python cannot find the codec 'b64'
    try:
        codecs.getdecoder(NAME)
        assert False, 'This function should fail before registering'
    except LookupError:
        pass

    # Register the 'b64' codec, and try to find it.
    register()
    codec_info = codecs.getdecoder(NAME)  # type: CodecInfo
    assert codec_info.name == NAME



# Generated at 2022-06-25 17:00:41.019242
# Unit test for function register
def test_register():
    """Test codec registration"""
    register()
    text = 'test'
    expected = b'dGVzdA=='
    actual = text.encode(NAME)
    assert expected == actual



# Generated at 2022-06-25 17:00:42.493639
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:00:46.447825
# Unit test for function register
def test_register():
    assert NAME not in codecs.decode.cache
    assert NAME not in codecs.encode.cache
    register()
    assert NAME in codecs.decode.cache
    assert NAME in codecs.encode.cache



# Generated at 2022-06-25 17:00:48.092370
# Unit test for function register
def test_register():
    register()
    assert True



# Generated at 2022-06-25 17:00:50.145633
# Unit test for function register
def test_register():
    codecs.register(get_codec_info)
    assert codecs.getdecoder("base64")


# Generated at 2022-06-25 17:00:52.353652
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:00:54.319049
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:00:58.137033
# Unit test for function register
def test_register():
    from unittest.mock import patch
    register_mock = patch.object(codecs, "register")

    test_case_0()
    register_mock.assert_called()



# Generated at 2022-06-25 17:01:00.141695
# Unit test for function register
def test_register():
    register()

    test_str = 'Zm9vCg==='

    codecs.decode(test_str, NAME)



# Generated at 2022-06-25 17:01:03.926190
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:01:04.895041
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:01:13.391614
# Unit test for function register
def test_register():
    # Test that the codec is not already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError(
            f'The codec {NAME!r} is already registered.'
        )
    # Test that registering the codec does not raise an exception.
    try:
        register()
    except:
        raise RuntimeError(
            f'The codec {NAME} failed registering.'
        )
    else:
        # Test that the codec is now registered.
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise RuntimeError(
                f'The codec {NAME!r} failed registering.'
            )



# Generated at 2022-06-25 17:01:22.240245
# Unit test for function encode
def test_encode():

    # Various text and encodings.
    text_in = 'Hello World'
    text_in_bytes = text_in.encode('utf-8')
    text_in_b64 = 'SGVsbG8gV29ybGQ='
    text_in_b64_bytes = text_in_b64.encode('utf-8')

    # Test when passing in the 'text' as a UserString, bytes, str or
    # b64_bytes.  Using the b64_bytes, the 'encode' should raise
    # an Error exception.
    text_types = (
        text_in,
        text_in_bytes,
        text_in_b64,
        text_in_b64_bytes
    )

# Generated at 2022-06-25 17:01:24.580640
# Unit test for function register
def test_register():
    try:
        codecs.register(_get_codec_info)
    except LookupError:
        pass
    codecs.register(_get_codec_info)


# Generated at 2022-06-25 17:01:32.700701
# Unit test for function register
def test_register():
    """Test for registering ``b64`` codec.

    To run all tests:
        python3 b64.py
    """

    # pylint: disable=W0612
    # pylint: disable=W0212
    # pylint: disable=W0621

    # pylint: disable=C0103
    from string import printable as Printable
    from string import ascii_lowercase as Lower
    from string import ascii_uppercase as Upper
    from string import digits as Digits
    from string import punctuation as Punctuation

    # Test for encoding decoding a single byte.
    assert bytes(0b00101010) == codecs.encode(
        '*', 'b64'
    )[0]  # type: ignore

# Generated at 2022-06-25 17:01:33.487249
# Unit test for function register
def test_register():
    pass


# Generated at 2022-06-25 17:01:36.147460
# Unit test for function register
def test_register():
    assert not codecs.getdecoder(NAME)
    assert codecs.lookup(NAME)
    assert codecs.lookup(NAME).decode
    assert codecs.lookup(NAME).encode



# Generated at 2022-06-25 17:01:48.266336
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # This test is to make sure that the codec was not previously
    # registered.
    with pytest.raises(LookupError):
        codecs.getencoder(NAME)
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    register()
    # This test is to make sure that the codec was registered.
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:01:50.345503
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:02:00.711604
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        pass

    register()
    assert isinstance(codecs.getdecoder(NAME),  # type: ignore
                      codecs.CodecInfo)



# Generated at 2022-06-25 17:02:02.752462
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:02:06.659742
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered using ``register()``."""
    register()
    r = codecs.getdecoder(NAME)
    assert r[0] == decode



# Generated at 2022-06-25 17:02:10.026767
# Unit test for function register
def test_register(): # pylint: disable=W0613
    """Unit Test of function register()"""
    register()

    assert NAME in codecs.getencodings()
    assert NAME in codecs.getdecodings()

# Unit Test for function encode

# Generated at 2022-06-25 17:02:23.594952
# Unit test for function encode

# Generated at 2022-06-25 17:02:28.548511
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('Failed to register the b64 codec with Python.')



# Generated at 2022-06-25 17:02:31.861598
# Unit test for function register
def test_register():
    register()

    # The codec should now be found.
    assert codecs.getdecoder(NAME), \
        f'Failed to register codec {NAME!r}'



# Generated at 2022-06-25 17:02:34.538623
# Unit test for function register
def test_register():
    """Test function register()."""
    codecs.lookup(NAME)



# Generated at 2022-06-25 17:02:40.853627
# Unit test for function register
def test_register():
    """
    The objective of this test case is verify the ``register`` function. The
    test case will check whethter the ``b64`` codec is registered with Python
    correctly.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    finally:
        assert codecs.getdecoder(NAME) is not None
        assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:02:49.507469
# Unit test for function encode
def test_encode():
    # Test case: 'AQIBAQkBAEZhY2Vz', 'b64'
    text = 'AQIBAQkBAEZhY2Vz'
    encoded_text, _text_len = encode(text)
    assert encoded_text == \
        b'\x13\x00\x01\x00\x02\x00\x01\x00\x07\x00\x01\x00\x04\x00\r\x00\x00'


# Generated at 2022-06-25 17:03:05.619588
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:03:08.081054
# Unit test for function register
def test_register():
    register()
    result = codecs.lookup(NAME)
    assert isinstance(result, codecs.CodecInfo)



# Generated at 2022-06-25 17:03:09.021539
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:14.797336
# Unit test for function register
def test_register():
    # Register the b64 codec
    register()

    # Test that the b64 codec is registered.
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    assert codecs.lookup(NAME)


# Test the encode function

# Generated at 2022-06-25 17:03:20.042031
# Unit test for function register
def test_register():
    register()
    # The 'encode' function
    is_encode_defined = callable(codecs.encode)
    assert is_encode_defined
    # The 'decode' function
    is_decode_defined = callable(codecs.decode)
    assert is_decode_defined



# Generated at 2022-06-25 17:03:20.633460
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:03:23.005372
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:03:23.958873
# Unit test for function register
def test_register():
    """Test function register"""
    test_case_0()

# Generated at 2022-06-25 17:03:34.506855
# Unit test for function encode
def test_encode():
    register()
    # Precondition:  'text_str' is a properly encoded string.

# Generated at 2022-06-25 17:03:35.903278
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:04:05.344320
# Unit test for function encode
def test_encode():
    register()
    string = 'Hello Python!'
    expect_out = b'SGVsbG8gUHl0aG9uIQ=='
    out, _ = codecs.encode(string, NAME)
    assert out == expect_out


# Generated at 2022-06-25 17:04:09.424176
# Unit test for function encode
def test_encode():
    for (text, expect) in (
            (
                'Shipper::Name::Email',
                b'Shipper::Name::Email'
            ),
            (
                '''
    Shipper::Name::Email
    ''',
                b'Shipper::Name::Email'
            ),
            (
                '''
    Shipper::Name::Email
    Shipper::Name::Email
    ''',
                b'Shipper::Name::EmailShipper::Name::Email'
            )
    ):
        result = encode(text)
        assert result[0] == expect
        assert result[1] == len(text)



# Generated at 2022-06-25 17:04:19.153896
# Unit test for function register
def test_register():
    # Create a 'BytesIO' object
    file = io.BytesIO()

    # Write a bytes value to the 'BytesIO' object.
    file.write(b'\x00\x01\x02\x03\x04')

    # Reset the internal pointer of the 'BytesIO' object
    file.seek(0)

    codecs.register(_get_codec_info)
    out = codecs.decode(file.read(), NAME)
    assert isinstance(out, str)
    assert out == 'AAECAwQFBg=='

    in_str = 'AQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEB'
    in_bytes = codecs.encode(in_str, NAME)

# Generated at 2022-06-25 17:04:21.477525
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:04:26.273660
# Unit test for function encode
def test_encode():
    assert decode(encoded_0) == decoded_0
    assert encode(decoded_1) == encoded_1
    assert decode(encoded_2) == decoded_2
    assert encode(decoded_3) == encoded_3


if __name__ == "__main__":
    test_encode()

# Generated at 2022-06-25 17:04:31.182283
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['_cache']
    assert NAME in codecs.__dict__['_unknown']
    assert NAME in codecs.__dict__['_aliases']


# Generated at 2022-06-25 17:04:34.707905
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Test that all registration functions actually register
        # their codecs.
        test_case_0()
        # Test that registering the codec twice does not raise an
        # exception.
        test_case_0()


# Generated at 2022-06-25 17:04:40.257490
# Unit test for function register
def test_register():
    def mock_codecs_getdecoder(name: str) -> None:
        raise LookupError()

    try:
        with mock.patch(
            'codecs.getdecoder',
            mock_codecs_getdecoder
        ):
            register()
    except LookupError:
        assert False



# Generated at 2022-06-25 17:04:45.557023
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Register the codec
        register()
        # Get the codec
        codecs.getdecoder(NAME)

# Generated at 2022-06-25 17:04:57.129578
# Unit test for function encode
def test_encode():
    register()
    assert (b'\xd3\x90\xb5\x0c\x00\x00\x00\x00\x00\x00\x00\x00', 12) == encode(
        '1AA==\n'
    )
    assert (b'\xd3\x90\xb5\x0c\x00\x00\x00\x00\x00\x00\x00\x00', 12) == encode(
        '  1AA==\n'
    )
    assert (b'\xd3\x90\xb5\x0c\x00\x00\x00\x00\x00\x00\x00\x00', 12) == encode(
        '  1AA==\n   \n'
    )


# Generated at 2022-06-25 17:06:00.666665
# Unit test for function register
def test_register():
    # Initialize the test
    test_name = 'test_register'
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # We failed to register the 'b64' codec
        raise AssertionError(
            f'{test_name} failed due to LookupError'
        ) from None


# Generated at 2022-06-25 17:06:05.377870
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    assert codecs.register(NAME)
    assert codecs.unregister(NAME)



# Generated at 2022-06-25 17:06:10.772139
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 17:06:14.595725
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


test_register()

# Generated at 2022-06-25 17:06:16.338022
# Unit test for function register
def test_register():
    register()

    # Assert the codec has been registered.
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:06:19.743667
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:06:20.935165
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:06:22.558063
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:06:28.892662
# Unit test for function register
def test_register():
    try:
        assert(codecs.getdecoder(NAME) is None)
    except LookupError:
        pass
    register()
    assert(codecs.getdecoder(NAME) is not None)



# Generated at 2022-06-25 17:06:32.113313
# Unit test for function register
def test_register():
    not_registered = True
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        not_registered = True
    assert not_registered
    register()
    assert not_registered
