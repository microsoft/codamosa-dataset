

# Generated at 2022-06-25 16:58:42.298411
# Unit test for function register
def test_register():
    with pytest.raises(LookupError):
        codecs.lookup(NAME)
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-25 16:58:47.401567
# Unit test for function encode
def test_encode():
    # Test w/ valid string
    assert encode("QW5kIHNvIEkgYW0gYmFzZTY0")[0] == b"And so I am base64"

    # Test w/ invalid string: 'a'
    try:
        assert encode("a")[0] == "And so I am base64"
    except UnicodeEncodeError as e:
        assert str(e) == \
            "b64: 'a' is not a proper bas64 character string: Incorrect padding"

    # Test w/ invalid string: '==='
    try:
        assert encode("===")[0] == "And so I am base64"
    except UnicodeEncodeError as e:
        assert str(e) == \
            "b64: '===' is not a proper bas64 character string: Incorrect padding"

# Generated at 2022-06-25 16:58:58.512848
# Unit test for function encode

# Generated at 2022-06-25 16:59:00.170877
# Unit test for function register
def test_register():
    register()
    result = codecs.getdecoder(NAME)
    assert result is not None



# Generated at 2022-06-25 16:59:03.426455
# Unit test for function encode
def test_encode():
    text = 'A lower case alpha character.'

    # Test valid base64 character string input.
    assert encode(text)[0] == b'QSBsb3dlciBjYXNlIGFscGhhIGNoYXJhY3Rlcg=='



# Generated at 2022-06-25 16:59:07.917249
# Unit test for function register
def test_register():
    # Make sure that the 'b64' codec is not registered with Python.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception(f"{NAME!r} codec is already registered with Python")

    # Register the 'b64' codec with Python.
    register()

    # The 'b64' codec should now be registered with Python.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(f"{NAME!r} codec is not registered with Python")



# Generated at 2022-06-25 16:59:11.107424
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError

    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError



# Generated at 2022-06-25 16:59:20.950409
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 16:59:23.489238
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error('b64')



# Generated at 2022-06-25 16:59:27.020828
# Unit test for function register
def test_register():
    # test function register with the following assert statements
    register()
    assert codecs.lookup(NAME).name == NAME
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None

# Generated at 2022-06-25 16:59:30.651467
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 16:59:31.866344
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 16:59:35.351741
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            assert False
    else:
        assert False



# Generated at 2022-06-25 16:59:45.937829
# Unit test for function encode

# Generated at 2022-06-25 16:59:56.751790
# Unit test for function encode
def test_encode():
    register()
    # pylint: disable=R0204
    # noinspection PyUnusedLocal
    def _encode_test(
            test_str: _STR,
            expected_str: _STR,
            expected_bytes: bytes
    ) -> None:
        """Test the encode function.

        Args:
            test_str (str): the string to put into the ``encode``
                function.
            expected_str (str): the expected result of ``encode``
                after calling it with ``test_str``.
            expected_bytes (bytes): the expected bytes that are
                returned from the ``encode`` function.

        Returns:
            None: None is returned.
        """
        result = codecs.encode(test_str, NAME)
        assert isinstance(result, Tuple[bytes, int])


# Generated at 2022-06-25 17:00:04.282612
# Unit test for function register
def test_register():
    import sys
    import os

    # Set the current working directory to the directory of this
    # Python source file with the assumption that this Python
    # script is stored in the same directory as the sample
    # data.  Change directories so that the sample data files are
    # found.
    os.chdir(os.path.dirname(sys.argv[0]))

    # Set the system path to include the parent directory so
    # that the test-data directory is found.
    os.sys.path.pus

# Generated at 2022-06-25 17:00:13.358865
# Unit test for function register
def test_register():
    import sys
    import pytest

    # Suppress a message about Python Codec Registry
    # being updated.
    sys.stdout = open(os.devnull, 'w')

    register()
    codec_info = codecs.getdecoder(NAME)  # type: ignore
    assert NAME == codec_info.name
    assert codec_info.decode == decode  # type: ignore
    assert codec_info.encode == encode  # type: ignore

    with pytest.raises(ValueError):
        codec_info.encode('test')



# Generated at 2022-06-25 17:00:14.759114
# Unit test for function register
def test_register():
    pass



# Generated at 2022-06-25 17:00:17.739403
# Unit test for function register
def test_register():
    codec = codecs.getdecoder(NAME)
    assert codec is not None
    codec = codecs.getencoder(NAME)
    assert codec is not None



# Generated at 2022-06-25 17:00:20.331890
# Unit test for function encode
def test_encode():
    assert str(encode("MTM=")[0]) == "13"
    assert encode("MTM=")[1] == 3


# Generated at 2022-06-25 17:00:32.686884
# Unit test for function register
def test_register():

    # Verify that the expected exception is raised when accessing the
    # b64 decoder.
    with pytest.raises(LookupError):
        # pylint: disable=E1101, C0301
        codecs.getdecoder('b64')
    with pytest.raises(LookupError):
        # pylint: disable=E1101, C0301
        codecs.getencoder('b64')

    # Register the b64 codec.
    register()

    # Verify that no exception is raised when accessing the b64 decoder.

# Generated at 2022-06-25 17:00:38.200948
# Unit test for function register
def test_register():
    """Test that the :func:`register` function
    successfully registers the ``b64`` codec.

    Note:
        The ``b64`` Codec can only be added once
        to the :mod:`codecs` module.
        Therefore, if this function raises an exception then it is
        possible that this function was not executed within a function
        that was run by :command:`python -m unittest discover`.
    """
    register()

    # Test that the codec info is registered and that
    # '-*-' encoding is not in use.
    codec_info = codecs.getdecoder(NAME)
    assert codec_info is not None


# pylint: disable=missing-docstring
# pylint: disable=too-few-public-methods
# noinspection PyShadowingBuiltins

# Generated at 2022-06-25 17:00:43.667047
# Unit test for function register
def test_register():
    register()
    out = codecs.decode("VGVzdCBzdHJpbmc=", "b64")
    assert out == b"Test string"
    out = codecs.encode("Test string", "b64")
    assert out == b"VGVzdCBzdHJpbmc="



# Generated at 2022-06-25 17:00:51.090935
# Unit test for function encode
def test_encode():
    text="YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo="
    text1="YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n"
    text2="YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\r\n"
    text3="\tYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\r\n"

# Generated at 2022-06-25 17:00:55.897310
# Unit test for function register
def test_register():
    # Verify the b64 codec is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the b64 codec.
    register()

    # Verify the b64 codec is registered.
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:00:59.540612
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# pylint: disable=R0201

# Generated at 2022-06-25 17:01:00.467989
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:01:01.803310
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:01:03.090586
# Unit test for function register
def test_register():
    """Test for function register."""
    test_case_0()



# Generated at 2022-06-25 17:01:06.189545
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('b64') == ('b64', encode)   # type: ignore
    assert codecs.lookup_error('b64') == ('b64', decode)   # type: ignore


# Generated at 2022-06-25 17:01:09.486466
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:01:11.443285
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['_codec_search_path']  # type: ignore



# Generated at 2022-06-25 17:01:13.351688
# Unit test for function register
def test_register():
    test_case_0()


if __name__ == '__main__':
    # unit test for encode
    test_register()

# Generated at 2022-06-25 17:01:15.055371
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        assert True


# Generated at 2022-06-25 17:01:16.081110
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-25 17:01:17.008597
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:01:19.393869
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-25 17:01:23.522989
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    assert codecs.decode(b'taken', NAME) == b'given'



# Generated at 2022-06-25 17:01:31.661131
# Unit test for function register
def test_register():
    import sys
    import collections
    import subprocess
    import tempfile

    class Isolated:
        def __init__(self):
            self.previous_vars = set(sys.modules.keys())
            self.previous_paths = list(sys.path)
            self.previous_argv = sys.argv[:]
            self.previous_builtins = sys.modules['builtins']
            self.previous_imported_modules = set(sys.modules.keys())

        def __enter__(self):
            sys.path.clear()
            builtins = collections.UserDict()
            for name in dir(sys.modules['builtins']):
                if not name.startswith('_'):
                    builtins[name] = getattr(sys.modules['builtins'], name)
            sys

# Generated at 2022-06-25 17:01:32.545538
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:01:45.702569
# Unit test for function register
def test_register():
    # Backup the original codec list
    codec_list_backup = list(codecs.getencoders()) + list(codecs.getdecoders())

    register()

    # Compare the codec lists before and after register
    codec_list = codecs.getencoders() + codecs.getdecoders()
    assert codec_list != codec_list_backup

    # Clean up the codec list
    codecs.register()

    # Compare the original codec list
    codec_list_new = codecs.getencoders() + codecs.getdecoders()
    assert codec_list_backup == codec_list_new



# Generated at 2022-06-25 17:01:46.779091
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:01:54.437009
# Unit test for function register
def test_register():
    # Reset codecs cache
    from sys import modules
    from os import remove

    try:
        remove(modules['encodings'].__file__.replace('pyc', 'pyo'))
        remove(modules['encodings'].__file__)
    except OSError:
        pass

    test_case_0()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:01:58.135325
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)

# Generated at 2022-06-25 17:01:59.053338
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:02:00.399354
# Unit test for function register
def test_register():
    test_case_0()
    return



# Generated at 2022-06-25 17:02:06.424832
# Unit test for function register
def test_register():
    register()
    str_b64 = codecs.encode('This is a test', 'b64')
    assert str(str_b64) == "b'VGhpcyBpcyBhIHRlc3Q='"

    str_b64 = codecs.decode(str_b64, 'b64')
    assert str(str_b64) == "'This is a test'"



# Generated at 2022-06-25 17:02:13.268034
# Unit test for function encode
def test_encode():
    register()


# Generated at 2022-06-25 17:02:26.473983
# Unit test for function encode
def test_encode():
    test_case_0()

    testcase1_input_text = "AQIDBAUGBwgJCgsMDQ4PEBESF"
    testcase1_expected_output = b'\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12'

    testcase2_input_text = "AQIDBAUGBwgJCgsMDQ4PEBERY"

# Generated at 2022-06-25 17:02:28.026239
# Unit test for function register
def test_register():

    # The codec is already registered.
    register()



# Generated at 2022-06-25 17:02:39.243763
# Unit test for function register
def test_register():
    # Register the 'b64' codec with Python
    register()

    # Try to get the 'b64' codec from Python.
    b64_codec = codecs.getencoder(NAME)
    assert b64_codec



# Generated at 2022-06-25 17:02:41.641202
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert NAME in codecs.__all__
        codecs.lookup(NAME)



# Generated at 2022-06-25 17:02:45.464064
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8=') == (b'Hello', 6)
    assert encode('SGVsbG8=') != (b'Hello', 4)
    assert encode('SGVsbG8=') != (b'Helo', 6)


# Generated at 2022-06-25 17:02:47.054539
# Unit test for function register
def test_register():
    register()
    assert(NAME in codecs.getdecoder(NAME).__name__)
    assert(NAME in codecs.getencoder(NAME).__name__)



# Generated at 2022-06-25 17:02:51.541314
# Unit test for function encode
def test_encode():
    test_text = '''\
Zm9v
YmFy
'''
    exp = (
        b'\x66\x6f\x6f\x62\x61\x72',
        len(test_text)
    )
    act = encode(test_text)
    assert act == exp, f'encode failed: expected={exp!r}, actual={act!r}'



# Generated at 2022-06-25 17:02:57.912534
# Unit test for function register
def test_register():
    """Test the function :func:`register` from module ``b64``."""
    import codecs

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(register)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError(f"The b64 codec can't be found.")



# Generated at 2022-06-25 17:03:03.161458
# Unit test for function register
def test_register():
    test_case_0()

########################################################################
#                             MAIN                                     #
########################################################################

if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:03:05.765082
# Unit test for function register
def test_register():
    test_case_0()




# Generated at 2022-06-25 17:03:07.526578
# Unit test for function register
def test_register():
    registered_codecs = set(codecs.getencodings())
    assert NAME in registered_codecs

# Generated at 2022-06-25 17:03:09.096809
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


# Generated at 2022-06-25 17:03:25.096132
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except Exception as e:
        pytest.fail(f'Raised exception: {e!r},{e.__class__.__name__}')


# Generated at 2022-06-25 17:03:29.394087
# Unit test for function register
def test_register():
    """Test the function ``register()``"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'The function "register()" does not install'
            f'the codec {NAME}'
        )



# Generated at 2022-06-25 17:03:33.542535
# Unit test for function register
def test_register():
    register()
    actual = codecs.lookup(NAME)
    assert actual.name == NAME
    assert actual.encode is encode
    assert actual.decode is decode
    # assert 0, f'debug will not run unit test'



# Generated at 2022-06-25 17:03:36.900659
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:03:38.230348
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:03:47.261476
# Unit test for function register
def test_register():
    # Register the 'b64' codec with Python.
    register()
    # Encode the string 'Hello World' with the b64 codec.
    out = codecs.encode('Hello World', 'b64')
    assert out == b'SGVsbG8gV29ybGQ=\n', out
    # Decode the 'out' bytes into a string of base64 characters.
    out2 = codecs.decode(out, 'b64')
    assert out2 == 'Hello World', out2



# Generated at 2022-06-25 17:03:51.239382
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)


# unit test for function encode

# Generated at 2022-06-25 17:03:52.363737
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:53.826733
# Unit test for function register
def test_register():
    """Unit test for function register."""
    test_case_1()



# Generated at 2022-06-25 17:03:54.706070
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:04:26.797230
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:04:27.691106
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:04:32.876760
# Unit test for function register
def test_register():
    # pylint: disable=W0212
    # noinspection PyProtectedMember
    try:
        codecs._cache.clear()
        codecs.open = Mock(side_effect=LookupError)
    finally:
        codecs._cache.clear()
    register()



# Generated at 2022-06-25 17:04:33.938283
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:04:48.244252
# Unit test for function encode
def test_encode():
    """Test encoder."""
    import uuid
    register()
    for _ in range(10):
        in_bytes = uuid.uuid4().bytes
        out_str = codecs.encode(in_bytes, NAME)  # type: ignore
        codecs.encode(in_bytes, NAME)  # type: ignore
        assert len(out_str) == 24
        assert len(out_str.encode('utf-8')) == 24  # type: ignore
    in_bytes = b'\xdd*='
    out_str = codecs.encode(in_bytes, NAME)  # type: ignore
    assert len(out_str) == 4
    assert len(out_str.encode('utf-8')) == 4
    assert out_str.encode('utf-8') == in_

# Generated at 2022-06-25 17:04:49.381370
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:04:54.413525
# Unit test for function register
def test_register():
    register()
    return True



# Generated at 2022-06-25 17:05:03.814361
# Unit test for function register
def test_register():
    import sys
    from test.testlib.asserts import is_in

    # Verify that the codec 'b64' is not in the standard codec list.
    is_in(NAME, map(lambda x: x.name, codecs.codecs_gen()))
    # Verify that the codec 'b64' is not in the standard codec lookup
    # cache.
    is_in(NAME, codecs.decode.cache.keys())
    # Verify that the codec 'b64' is not in the standard codec lookup
    # cache.
    is_in(NAME, codecs.encode.cache.keys())

    # Register the 'b64' codec.
    register()

    # Verify that the codec 'b64' is in the standard codec list.

# Generated at 2022-06-25 17:05:06.952643
# Unit test for function register
def test_register():
    register()
    x = codecs.getencoder(NAME)
    y = codecs.getdecoder(NAME)
    assert x()[1] == y(b'')[1]


if __name__ == '__main__':
    register()
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 17:05:20.689609
# Unit test for function encode
def test_encode():
    text_input = "c2VyYWlnaHRjbGFz"

# Generated at 2022-06-25 17:06:25.383210
# Unit test for function register
def test_register():
    """Unit tests for function register()."""
    import doctest
    from click.testing import CliRunner
    from .cli import run_cmd

    result = doctest.testmod()
    assert result.failed == 0

    # Test the CLI for this module.
    runner = CliRunner()
    result = runner.invoke(run_cmd, ['help', 'register'])
    assert result.exit_code == 0
    assert result.output.count('\n') > 0
    assert not result.exception



# Generated at 2022-06-25 17:06:35.453913
# Unit test for function encode
def test_encode():
    register()

    # Test 0.
    # Test that encode can convert a string into a bytes object.
    #
    converted = encode(text='Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure.')

# Generated at 2022-06-25 17:06:36.804741
# Unit test for function register
def test_register():
    expected = 'b64'
    actual = codecs.lookup(expected).name
    assert expected == actual



# Generated at 2022-06-25 17:06:39.803195
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:06:42.851142
# Unit test for function encode
def test_encode():
    test_case_0()

# Generated at 2022-06-25 17:06:44.214693
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:06:49.196056
# Unit test for function encode
def test_encode():
    register()
    # Test 0:
    given_text_0 = 'Hello World!'
    given_text_0_expected_bytes = b'SGVsbG8gV29ybGQh'
    given_text_0_expected_bytes_len = 15
    given_text_0_expected_text = 'Hello World!'
    given_text_0_expected_text_len = 12

    given_encoded_0, given_encoded_len_0 = encode(given_text_0)
    assert given_encoded_0 == given_text_0_expected_bytes
    assert given_encoded_len_0 == given_text_0_expected_bytes_len

    given_decoded_0, given_decoded_len_0 = decode(given_encoded_0)
    assert given_decoded_0

# Generated at 2022-06-25 17:06:50.205838
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:06:58.573990
# Unit test for function register
def test_register():
    """Unit test for the ``register()`` function."""
    register()
    # Verify that the codec file is registered.
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:07:00.797989
# Unit test for function register
def test_register():
    test_case_0()

if __name__ == '__main__':
    test_register()