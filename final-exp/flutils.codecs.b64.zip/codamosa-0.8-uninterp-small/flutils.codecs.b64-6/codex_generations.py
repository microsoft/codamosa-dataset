

# Generated at 2022-06-25 16:58:40.740333
# Unit test for function register
def test_register():
    register()
    a = codecs.getencoder(NAME)
    assert a is not None
    a = codecs.getdecoder(NAME)
    assert a is not None


# Generated at 2022-06-25 16:58:42.151825
# Unit test for function register
def test_register():
    """Exercise the function :func:`register`."""
    # Expected Exceptions
    test_case_0()

# Generated at 2022-06-25 16:58:42.882318
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()



# Generated at 2022-06-25 16:58:43.387879
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 16:58:44.237013
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 16:58:46.626442
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # pylint: disable=W0612
    __test_register()
    try:
        __test_register()
    except ValueError:
        pass



# Generated at 2022-06-25 16:58:47.625606
# Unit test for function encode
def test_encode():
    test_case_0()


# Generated at 2022-06-25 16:58:51.265886
# Unit test for function register
def test_register():
    """Verify that the codec is registered"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False  # type: ignore
    assert True  # type: ignore

# Generated at 2022-06-25 16:58:55.751471
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        final_try = codecs.getdecoder(NAME)
        assert final_try is not None
    else:
        assert True



# Generated at 2022-06-25 16:58:57.948838
# Unit test for function register
def test_register():
    # Test case 0
    # Call the function under test
    test_case_0()
    # Assertions
    pass


# Generated at 2022-06-25 16:59:02.790486
# Unit test for function register
def test_register():
    assert NAME in codecs.getdecoder(NAME)()   # type: ignore



# Generated at 2022-06-25 16:59:08.695110
# Unit test for function encode
def test_encode():
    register()
    assert encode('QQ==')[0] == b'\x00\x00'
    assert encode('AA==')[0] == b'\x01\x00'
    assert encode('Ag==')[0] == b'\x01\x01'
    assert encode('AQ==')[0] == b'\x01\x02'
    assert encode('Aw==')[0] == b'\x01\x03'
    assert encode('BA==')[0] == b'\x01\x04'
    assert encode('BQ==')[0] == b'\x01\x05'
    assert encode('Bg==')[0] == b'\x01\x06'
    assert encode('Bw==')[0] == b'\x01\x07'
   

# Generated at 2022-06-25 16:59:11.195588
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    return True


# Generated at 2022-06-25 16:59:12.898693
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 16:59:22.703026
# Unit test for function register
def test_register():
    def decoder_error(
            obj: bytes,
            index: int,
            errors: str
    ) -> codecs.DecodeResult:
        raise UnicodeDecodeError('b64', obj, index, index + 1, 'error')

    try:
        register()
    except Exception:
        raise AssertionError('register: Unexpected exception')

    # Test with the encoding defined in Python's 'encodings' module
    assert NAME in codecs.getencodings()
    assert codecs.getdecoder(NAME)(b'', 'strict') == ('', 0)
    try:
        codecs.getdecoder(NAME)(b'', 'ignore')
        raise AssertionError(
            'getdecoder: unexpected exception: ignore'
        )
    except LookupError:
        pass

# Generated at 2022-06-25 16:59:25.168249
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    assert codecs.lookup(NAME)


# noinspection PyUnboundLocalVariable

# Generated at 2022-06-25 16:59:30.143532
# Unit test for function register
def test_register():
    """Test the register function"""
    with pytest.raises(LookupError) as e:
        codecs.getdecoder(NAME)
    assert str(e.value) == f'unknown encoding: {NAME!r}'

    register()
    codecs.getdecoder(NAME)  # This should not raise an error



# Generated at 2022-06-25 16:59:37.400215
# Unit test for function register
def test_register():
    # Create a temp logger object so the tests do not log anything.
    with temp_logging() as test_logger:
        # Pre-Test
        codec_info = codecs.getdecoder(NAME)
        assert codec_info.name == NAME

        # Test
        register()
        codec_info = codecs.getdecoder(NAME)
        assert codec_info.name == NAME

        # Post-Test
        codec_info = codecs.getdecoder(NAME)
        assert codec_info.name == NAME



# Generated at 2022-06-25 16:59:40.704870
# Unit test for function encode
def test_encode():
    expected = (b'U3RyaW5n', 7)
    actual = encode('U3RyaW5n')
    assert(expected == actual)


# Generated at 2022-06-25 16:59:41.325585
# Unit test for function register
def test_register():
    """Test function ``register``."""
    test_case_0()



# Generated at 2022-06-25 16:59:45.828757
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

# Generated at 2022-06-25 16:59:48.088411
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 16:59:50.173412
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-25 17:00:00.112405
# Unit test for function encode

# Generated at 2022-06-25 17:00:10.413024
# Unit test for function encode

# Generated at 2022-06-25 17:00:11.108851
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:00:13.305714
# Unit test for function register
def test_register():
    # noinspection PyUnreachableCode
    if False:
        # noinspection PyStatementEffect
        test_case_0()



# Generated at 2022-06-25 17:00:16.338069
# Unit test for function register
def test_register():
    # Execute the function under test
    register()

    # Verify that the codec was registered.
    codecs.lookup(NAME)



# Generated at 2022-06-25 17:00:17.739391
# Unit test for function register
def test_register():
    pass


# Generated at 2022-06-25 17:00:22.076681
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__['_cache']
    register()
    assert NAME in codecs.__dict__['_cache']
    register()
    assert NAME in codecs.__dict__['_cache']



# Generated at 2022-06-25 17:00:35.461823
# Unit test for function encode
def test_encode():
    """
    Test that the encode function can convert strings of different lengths
    with valid base64 characters.
    """
    data01 = 'a'
    data02 = 'ab'
    data03 = 'abc'
    data04 = 'abcd'
    data05 = 'abcde'
    data06 = 'abcdef'
    data07 = 'abcdefg'
    data08 = 'abcdefgh'
    data09 = 'abcdefghi'
    data10 = 'abcdefghij'
    data11 = 'abcdefghijk'
    data12 = 'abcdefghijkl'
    data13 = 'abcdefghijklm'
    data14 = 'abcdefghijklmn'
    data15 = 'abcdefghijklmno'
    

# Generated at 2022-06-25 17:00:36.789910
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:00:39.286095
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert callable(decoder)

    encoder = codecs.getencoder(NAME)
    assert callable(encoder)


# Generated at 2022-06-25 17:00:41.944620
# Unit test for function register
def test_register():
    register()
    # There is nothing to test since register can not fail.
    # It always returns None.


# Generated at 2022-06-25 17:00:46.051794
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
        assert False, 'The b64 codec should not be registered yet.'
    except LookupError:
        pass
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'The b64 codec should be registered now.'
    return

# Generated at 2022-06-25 17:00:56.658284
# Unit test for function register
def test_register():
    """Test case for function register"""
    register()


if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:01:03.566797
# Unit test for function register
def test_register():
    """
    Test the function register()
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False, f'The "{NAME}" codec is already registered'
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, f'The "{NAME}" codec was not registered'
    else:
        assert True



# Generated at 2022-06-25 17:01:12.882084
# Unit test for function register
def test_register():
    import sys                                                                           # pylint: disable=import-outside-toplevel
    from pytest import importorskip                                                      # pylint: disable=import-outside-toplevel

    importorskip('codecs')
    from codecs import getdecoder
    from codecs import getencoder

    register()

    # noinspection PyUnresolvedReferences
    assert NAME in sys.modules

    ci = getdecoder(NAME)                                                                # type: ignore
    assert ci.decode == decode                                                           # type: ignore
    assert ci.encode == encode                                                           # type: ignore

    ei = getencoder(NAME)                                                                # type: ignore
    assert ei.decode == decode                                                           # type: ignore

# Generated at 2022-06-25 17:01:14.010897
# Unit test for function register
def test_register():
    register()

# Test that 'register' has been called.

# Generated at 2022-06-25 17:01:22.439735
# Unit test for function register
def test_register():
    """Test that the registration of the 'b64' codec is successful.
    """
    # Try to register the codec before it has been registered.
    try:
        codecs.getencoder(NAME)
        assert False
    except LookupError as e:
        # pylint: disable=unpacking-non-sequence
        assert NAME == e.args[0]

    # Register the 'b64' codec.
    register()

    # Try to register the 'b64' codec again.
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        # pylint: disable=unpacking-non-sequence
        assert False, e.args



# Generated at 2022-06-25 17:01:27.088039
# Unit test for function register
def test_register():
    register()

    # Verify the new codec is registered.
    obj = codecs.getdecoder(NAME)
    assert obj



# Generated at 2022-06-25 17:01:29.463481
# Unit test for function register
def test_register():
    # Arrange
    test_case_0()
    # Act
    for _ in range(2):
        # Assert
        assert NAME in codecs._cache
        assert NAME in codecs._registry



# Generated at 2022-06-25 17:01:32.191208
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    else:
        unregister()
        register()



# Generated at 2022-06-25 17:01:40.822778
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore

    encoded_bytes = b'SGVsbG8gV29ybGQ='
    my_decoded_bytes = b'Hello World'

    encoded_str = 'SGVsbG8gV29ybGQ='

    encoded_str_multi_line = (
        'SGVsbG8gV29ybGQ=\n'
        'aGVsbG8gdGhlIHdvcmxk\n'
    )
    my_decoded_bytes_multi_line = (
        b'Hello World'
        b'hello the world'
    )

    ################################################################################
    # Test the 'encode'

# Generated at 2022-06-25 17:01:45.581826
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('codec with name "{NAME}" already exists')

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('codec with name "{NAME}" was not found')



# Generated at 2022-06-25 17:01:48.009293
# Unit test for function register
def test_register():
    assert codecs.getdecoder('b64') == decode
    assert codecs.getencoder('b64') == encode



# Generated at 2022-06-25 17:01:48.979262
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:01:57.299038
# Unit test for function encode
def test_encode():
    register()
    # Test Case 1
    text_input = "hello world"
    assert codecs.encode(text_input, NAME) == b'aGVsbG8gd29ybGQ='
    # Test Case 2
    text_input = "hello world"
    assert codecs.encode(text_input, NAME) == b'aGVsbG8gd29ybGQ='


# Generated at 2022-06-25 17:01:59.748102
# Unit test for function register
def test_register():
    register()

    # Check if the codec is registered.
    assert(codecs.lookup(NAME) is not None)


# Unit test of function encode

# Generated at 2022-06-25 17:02:09.330603
# Unit test for function encode
def test_encode():
    register()

    # Test that a single line of base64 characters can be converted
    # into the expected bytes.
    text_input = "IyEvdXNyL2Jpbi9lbnYgYmFzaAogIyBBZGQgYW5kIHJlbW92ZSB0aGUgJ2Jhc2gvbm9ydG9n'\n"
    text_input += "cmlldCcgdG8gdGhlIGVudmlyb25tZW50IHZhcmlhYmxlICRBVEFMVkVSU0lPTi4="

# Generated at 2022-06-25 17:02:16.324975
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:02:17.937578
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:02:23.795375
# Unit test for function register
def test_register():
    tests = [
        ('b64', 'encoded'),
        ('b64', 'decoded')
    ]
    for name, type_ in tests:
        try:
            codecs.getdecoder(name)
            codecs.getencoder(name)
        except LookupError:
            raise AssertionError(f'{name!r} {type_!r} codec is not registered')

# Generated at 2022-06-25 17:02:32.188491
# Unit test for function register
def test_register():
    register()
    got = codecs.getdecoder(NAME)
    fmt = "type(got)={0}, type(got.decode)={1}, type(got.encode)={2}"
    fmt = fmt.format(type(got), type(got.decode), type(got.encode))
    assert got.name == NAME, fmt
    want = 'abc123'
    want = want.encode('utf8')
    want = base64.b64encode(want)
    want = want.decode('utf8')
    got = got.encode(want)
    assert got == (want, len(want)), fmt + '\nwant={0}, got={1}'.format(
        want, got
    )
    got = got.decode()
    assert got == (want, len(want)), fmt

# Generated at 2022-06-25 17:02:36.248452
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder('b64')
    assert obj is not None


# Unit tests for function encode

# Generated at 2022-06-25 17:02:38.189943
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:02:43.907167
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, f'Failed to lookup {NAME}'



# Generated at 2022-06-25 17:02:47.005453
# Unit test for function register
def test_register():

    # Get a way to test the register function
    # even when the codec has already been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:02:50.707211
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise AssertionError(f'{NAME} is already registered')
    except LookupError:
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise AssertionError(f'{NAME} is not registered')



# Generated at 2022-06-25 17:02:51.441851
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:08.081526
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:03:08.726099
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-25 17:03:13.030871
# Unit test for function encode
def test_encode():
    register()
    input_string = "RmlsbGVyIEJ1cmI="
    decoded_string, _ = encode(input_string)
    assert decoded_string == b"Filler Burr"


# Generated at 2022-06-25 17:03:20.867901
# Unit test for function encode
def test_encode():
    text = '''
    SGVsbG8sIFdvcmxkIQ==
    '''
    out, out_len = encode(text)
    assert out == b'Hello, World!'
    assert out_len == len(text)



# Generated at 2022-06-25 17:03:23.597488
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)

# Generated at 2022-06-25 17:03:34.215927
# Unit test for function encode
def test_encode():
    assert encode("YW55IGNhcm5hbCBwbGVhc3VyZS4=") == (b"any carnal pleasure.", 25)
    expected_error = UnicodeEncodeError(
        'b64',
        "YW55IGNhcm5hbCBwbGVhc3VyZS4=\n",
        0,
        29,
        "b'YW55IGNhcm5hbCBwbGVhc3VyZS4=\\n' is not a proper bas64 character "
        "string: Incorrect padding"
    )
    with pytest.raises(UnicodeEncodeError) as e:
        encode("YW55IGNhcm5hbCBwbGVhc3VyZS4=\n")
    assert e.value.start == expected_error.start

# Generated at 2022-06-25 17:03:44.166035
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The codec "{NAME}" is already registered with Python.'
        )

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'The codec "{NAME}" is not registered with Python.'
        )
    else:
        pass
        # If the codec it registered and we can decode, then we are good.

    # Test the encode/decode cycle.
    decoded = ' '
    encoded = decoded.encode(NAME)
    decoded = encoded.decode(NAME)
    assert decoded == ' '
    decoded = b' '

# Generated at 2022-06-25 17:03:52.811818
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    name = NAME
    # Get the decoder information for the name 'b64'.  The decoder
    # information returned should be 'b64.decode' as the decoder.
    decoder_info = codecs.getdecoder(name)
    assert name == decoder_info[0]
    assert decoder_info[1] == decode
    # Get the encoder information for the name 'b64'.  The encoder
    # information returned should be 'b64.encode' as the encoder.
    encoder_info = codecs.getencoder(name)
    assert name == encoder_info[0]
    assert encoder_info[1] == encode



# Generated at 2022-06-25 17:03:53.780457
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:55.564619
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-25 17:04:30.214049
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'codec not registered: {NAME}')

# Generated at 2022-06-25 17:04:33.152146
# Unit test for function register
def test_register():
    """Test the function :class:`register`."""

# Generated at 2022-06-25 17:04:36.007189
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except AssertionError as err:
        raise AssertionError(str(err)) from err
    except Exception as err:
        raise AssertionError(f'An unexpected exception was raised: {err}') from err



# Generated at 2022-06-25 17:04:50.752078
# Unit test for function encode
def test_encode():
    register()
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('a') == (b'eA==', 1)
    assert encode('ab') == (b'eWI=', 2)
    assert encode('abc') == (b'eWJj', 3)
    assert encode('abcd') == (b'eWJjZA==', 4)
    assert encode('abcde') == (b'eWJjZGU=', 5)
    assert encode('abcdef') == (b'eWJjZGVm', 6)
    assert encode('abcdefg') == (b'eWJjZGVmZw==', 7)

# Generated at 2022-06-25 17:04:51.261279
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:04:57.744949
# Unit test for function register
def test_register():
    """Assert the ``b64`` codec is registered using the ``register()``
    function.
    """
    register()
    with pytest.raises(LookupError):  # type: ignore
        codecs.getencoder(NAME)
    assert NAME in codecs.getencodings()

# Generated at 2022-06-25 17:05:03.516974
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-25 17:05:13.429165
# Unit test for function encode
def test_encode():
    out, size = encode(
        '''\
        ZXhhbXBsZSB0ZXh0IGZvciB0ZXN0IFwKICAgIGFuZCBzbyBvbi4uLi\
        '''
    )
    expect = b'example text for test \n    and so on...'
    assert out == expect, 'encode failed'


# Generated at 2022-06-25 17:05:17.762582
# Unit test for function encode
def test_encode():
    # Ensure that the given 'text' is converted into base64 bytes.
    sample_text = """
    8dLv9XU5Q6UxDUSg
    """
    expected = bytes([24, 3, 193, 216])
    actual = encode(sample_text)[0]
    assert actual == expected



# Generated at 2022-06-25 17:05:19.080549
# Unit test for function register
def test_register():
    # pylint: disable=C0116
    test_case_0()

# Generated at 2022-06-25 17:06:16.920049
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:06:23.185522
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    # pylint: disable=W0212
    assert NAME in codecs.__dict__['_cache']
    assert NAME in codecs.__dict__['_cache_alias']
    assert NAME in codecs.__dict__['_unknown_error_handlers']


test_case_0()

# Generated at 2022-06-25 17:06:32.928090
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise AssertionError('Codec already registered')
    except LookupError:
        pass

    codecs.register(_get_codec_info)

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Codec not registered')

    codecs.unregister(NAME)

    try:
        codecs.getdecoder(NAME)
        raise AssertionError('Codec still registered')
    except LookupError:
        pass



# Generated at 2022-06-25 17:06:41.648277
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 17:06:55.254687
# Unit test for function encode
def test_encode():
    assert (encode('\x00\x01\x02') == (b'AAEC', 6))
    assert (encode('\x00\x01\x02') == (b'AAEC', 6))

    assert (encode('\x00\x01\x02', 'strict') == (b'AAEC', 6))
    assert (encode('\x00\x01\x02', 'strict') == (b'AAEC', 6))

    # Test some basic whitespace removal.
    assert (encode('  \t\n\nAAEC') == (b'AAEC', 6))
    assert (encode('  \t\n\nAAEC') == (b'AAEC', 6))

# Generated at 2022-06-25 17:06:59.797188
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:07:03.492037
# Unit test for function encode
def test_encode():
    # Data
    text_str = 'Hello World'

    # Process
    text_bytes, len_bytes = encode(text_str)

    # Verify
    assert type(text_bytes) is bytes
    assert type(len_bytes) is int
    assert text_bytes == b'Hello World'
    assert len_bytes == len(text_str)



# Generated at 2022-06-25 17:07:04.709184
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:07:06.592167
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:07:07.658447
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.lookup(NAME)

