

# Generated at 2022-06-25 16:58:43.920359
# Unit test for function encode
def test_encode():
    def _test_encode(text, expected_value):
        # Convert the given 'text', that are of type UserString into a str.
        text_input = str(text)

        # Cleanup whitespace.
        text_str = text_input.strip()
        text_str = '\n'.join(
            filter(
                lambda x: len(x) > 0,
                map(lambda x: x.strip(), text_str.strip().splitlines())
            )
        )

        # Convert the cleaned text into utf8 bytes
        text_bytes = text_str.encode('utf-8')
        out, out_len = codecs.getdecoder(NAME)(text)
        assert len(expected_value) == out_len
        assert expected_value == out


# Generated at 2022-06-25 16:58:45.710841
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME)(b'DEADBEEF')[0] == 'RERFRkVF'


# Generated at 2022-06-25 16:58:56.430620
# Unit test for function encode

# Generated at 2022-06-25 16:59:03.539114
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('strict') == codecs.strict_errors
    assert codecs.lookup_error('ignore') == codecs.ignore_errors
    assert codecs.lookup_error('replace') == codecs.replace_errors
    assert codecs.lookup_error('backslashreplace') \
        == codecs.backslashreplace_errors
    assert codecs.lookup_error('xmlcharrefreplace') \
        == codecs.xmlcharrefreplace_errors
    assert codecs.lookup_error('namereplace') == codecs.namereplace_errors



# Generated at 2022-06-25 16:59:04.024441
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 16:59:05.865632
# Unit test for function register
def test_register():
    assert NAME not in codecs.getdecoders().keys()
    register()
    assert NAME in codecs.getdecoders().keys()



# Generated at 2022-06-25 16:59:07.011734
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 16:59:13.669592
# Unit test for function register
def test_register():
    """Unit test for the register function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Cannot unregister a codec that has already been registered.
        pass
    else:
        codecs.unregister(NAME)    # type: ignore
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Failed to register')
    else:
        codecs.unregister(NAME)    # type: ignore



# Generated at 2022-06-25 16:59:23.379192
# Unit test for function encode
def test_encode():
    test_bytes = b'!@#$%^&*()'
    test_bytes_length = 9
    test_string = 'I am the king'
    test_string_length = 13
    test_encoded_string = 'SSBhbSB0aGUga2luZw=='
    test_multiline_string = 'This is\n\n  a multiple\nline string'
    test_multiline_string_length = 31
    test_multiline_string_encoded = 'VGhpcyBpcyBhIG11bHRpcGxlCmxpbmUgc3RyaW5n'
    test_decoded_string, output_length = encode(test_encoded_string)
    assert test_decoded_string == test_string
    assert output_length == 22

    test_

# Generated at 2022-06-25 16:59:31.122623
# Unit test for function encode

# Generated at 2022-06-25 16:59:38.508459
# Unit test for function register
def test_register():
    try:
        codecs.lookup_error('b64')
    except LookupError as e:
        assert str(e) == 'unknown error handler name b64'

    register()
    try:
        codecs.lookup_error('b64')
    except LookupError as e:
        assert str(e) == 'unknown error handler name b64'
    else:
        assert False, 'Should not get here'


# Generated at 2022-06-25 16:59:39.447818
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 16:59:43.793235
# Unit test for function register
def test_register():
    register()
    res = str(codecs.lookup_error('b64')) == str(
        LookupError(
            "unknown encoding: b64", 'b64'
        )
    )
    if res is False:
        raise AssertionError('register() failed')



# Generated at 2022-06-25 16:59:44.966183
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-25 16:59:45.817866
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 16:59:50.530988
# Unit test for function encode
def test_encode():
    input_str = ('\n'.join(
        ['aGVsbG8gd29ybGQh'],
    ))
    input_bytes = input_str.encode('utf-8')
    output_bytes = b'hello world!'
    output_bytes_len = len(output_bytes)
    actual_bytes, actual_bytes_len = encode(input_str)
    assert actual_bytes == output_bytes
    assert actual_bytes_len == output_bytes_len

# Generated at 2022-06-25 17:00:00.395723
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    from . import codec_b64
    from .codec_b64 import register
    from .codec_b64 import NAME
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'the b64 codec should not be registered'
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'the b64 codec should be registered'
    else:
        pass
# #Uncomment and run when codec-b64.py is in codecs/
# def test_case_1():
#     register()
#
#     out_bytes = b'\xd0\x8f\xcb\x90\xcb\x87\xcb

# Generated at 2022-06-25 17:00:03.717673
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error(NAME) is not None
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-25 17:00:08.112177
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)
    # And that it's our custom b64 codec.
    assert NAME in str(decode)



# Generated at 2022-06-25 17:00:16.706878
# Unit test for function register
def test_register():
    import sys
    import pytest
    from typing import Optional


    def _get_registered_codec() -> Optional[str]:
        """Return the name of the registered codec."""
        for name in sys.modules['encodings'].aliases.aliases.values():
            if name.startswith('b64'):
                return name
        return None


    before = _get_registered_codec()
    register()
    after = _get_registered_codec()


    def teardown_function(function) -> None:
        """Remove the ``b64`` codec registration."""
        if before is None:
            del sys.modules['encodings'].aliases.aliases[after]
        else:
            sys.modules['encodings'].aliases.aliases[before] = after



# Generated at 2022-06-25 17:00:21.636662
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:00:32.686217
# Unit test for function register

# Generated at 2022-06-25 17:00:35.374186
# Unit test for function register
def test_register():
    from sys import modules
    from codecs import getencoder
    from codecs import getdecoder
    try:
        del modules[NAME]
    except KeyError:
        pass

    register()
    assert getencoder(NAME)
    assert getdecoder(NAME)



# Generated at 2022-06-25 17:00:38.590870
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('Failed to register "{}" codec'.format(NAME))



# Generated at 2022-06-25 17:00:39.965999
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:00:47.343352
# Unit test for function register
def test_register():
    """Test the registration of the ``b64`` codec by testing that the
    codec can be used.
    """
    for _ in range(2):
        register()
        text = 'U3lzdGVtLg=='
        # Encoding
        # noinspection PyTypeChecker
        b = text.encode('b64')
        assert b == b'System.'
        assert isinstance(b, bytes)
        # Decoding
        assert b.decode('b64') == text
        assert isinstance(b.decode('b64'), str)


# Generated at 2022-06-25 17:00:48.858476
# Unit test for function register
def test_register():
    # pylint: disable=W0621
    assert callable(register)



# Generated at 2022-06-25 17:00:49.398376
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:00:51.462095
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        return 1
    return 0



# Generated at 2022-06-25 17:00:55.456839
# Unit test for function register
def test_register():
    """
    The codecs module looksup the codecs by name.  This test is to insure
    that the register function properly registers the b64 codec.
    """
    register()
    result = codecs.getdecoder(NAME)
    assert result is not None
    assert NAME in result.__name__



# Generated at 2022-06-25 17:01:01.800672
# Unit test for function register
def test_register():
    assert True

# Generated at 2022-06-25 17:01:02.752751
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:01:03.703822
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:01:12.998455
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    # pylint: disable=W0603
    # pylint: disable=C0111
    # pylint: disable=C0103
    # pylint: disable=C0413
    # pylint: disable=W0621
    import sys
    import os
    import unittest


    def _test_register_0():
        # pylint: disable=W0612
        # pylint: disable=W0603
        # pylint: disable=C0111
        # pylint: disable=C0103
        # pylint: disable=C0413
        # pylint: disable=W0621
        import sys
        import os
        import unittest



# Generated at 2022-06-25 17:01:13.508828
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:01:15.118727
# Unit test for function register
def test_register():
    register()

    # Confirm the b64 codec was registerd with the codec library.
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-25 17:01:25.306757
# Unit test for function encode

# Generated at 2022-06-25 17:01:26.153019
# Unit test for function register
def test_register():
    pass


# Generated at 2022-06-25 17:01:28.893631
# Unit test for function register
def test_register():
    test_name = f'{__file__}.{test_case_0.__name__}'
    print(f'Running Test: {test_name}')
    test_case_0()
    print('Test Passed')



# Generated at 2022-06-25 17:01:30.899831
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:01:44.126697
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:01:45.612882
# Unit test for function register
def test_register():
    assert not codecs.lookup(NAME)
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-25 17:01:47.045265
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)



# Generated at 2022-06-25 17:01:51.481545
# Unit test for function register
def test_register():
    """Test the register function"""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None, 'Failed to register the "b64" codec.'
    assert obj.name == NAME, f'The codec name is expected to be "{NAME}".'

# Generated at 2022-06-25 17:01:58.382888
# Unit test for function register
def test_register():
    import codecs as _codecs
    assert NAME not in _codecs.__all__

    register()

    assert NAME in _codecs.__all__

    codec = _codecs.getencoder(NAME)
    assert codec

    codec = _codecs.getdecoder(NAME)
    assert codec



# Generated at 2022-06-25 17:01:58.932757
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:01:59.513704
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:02:08.139526
# Unit test for function register
def test_register():
    if not hasattr(codecs, 'register'):
        return
    assert hasattr(codecs, 'register')
    assert callable(codecs.register)

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    finally:
        codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-25 17:02:11.067859
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME).encode('a') == (b'YQ==', 1)



# Generated at 2022-06-25 17:02:24.546780
# Unit test for function register
def test_register():

    codec_name = NAME
    # codec_name = 'b64'

    # Print the codec's information
    codec_info = codecs.lookup(codec_name)
    print(f'name: {codec_info.name}')
    print(f'decode: {codec_info.decode}')
    print(f'encode: {codec_info.encode}')

    # Test the codec's encode method
    encoded_str = codec_info.encode(b'Classroom')[0]
    print(f'{b"Classroom"!r} => {encoded_str!r}')
    assert encoded_str == 'Q2xhc3Nyb29t'

    # Test the codec's decode method

# Generated at 2022-06-25 17:02:56.566068
# Unit test for function register
def test_register():
    expected = codecs.CodecInfo(
        name='b64',
        encode=encode,
        decode=decode,
    )
    assert _get_codec_info(NAME) == expected

# Generated at 2022-06-25 17:03:05.672353
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 17:03:18.729805
# Unit test for function register
def test_register():
    import random
    import string

    random.seed(12345)

    def random_string(num_chars: int) -> str:
        # noinspection PyUnusedLocal
        return ''.join([
            random.choice(string.ascii_letters)
            for _ in range(num_chars)
        ])

    # Disable pylint's "Too many local variables" warning
    # pylint: disable=R0914
    def check(
            input_str: str,
            expected_str: str,
            expected_bytes: bytes
    ) -> bool:
        input_bytes = input_str.encode('utf-8')
        decoded_str, num_input_bytes_consumed = decode(input_bytes)
        assert expected_str == decoded_str
        assert len(input_bytes)

# Generated at 2022-06-25 17:03:22.628700
# Unit test for function register
def test_register():
    # Call the function under test.
    test_case_0()


# pylint: disable=E1136
# noinspection PyStatementEffect,PyUnresolvedReferences

# Generated at 2022-06-25 17:03:23.732738
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:24.305110
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-25 17:03:34.788542
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import unittest
    from collections import UserString
    from typing import Union

    from b64 import register

    # A codec register function does not return anything.  ValueError is
    # raised if the given ``encoding`` is not the name of an encoding.
    with self.assertRaises(ValueError):
        codecs.register(register)  # type: ignore

    # Register the 'b64' codec.
    register()

    # Get the codec information for the codec named 'b64'.
    codec_info = codecs.lookup('b64')   # type: ignore

    # The codec information should have a member named 'name'.  This
    # member should contain the name of the codec.

# Generated at 2022-06-25 17:03:38.134577
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise RuntimeError('Could not get codec for {}'.format(NAME))



# Generated at 2022-06-25 17:03:45.795264
# Unit test for function encode
def test_encode():
    """Test encode function"""
    # Test case #0
    text = "b64(Hello World)"
    expected_output = b'SGVsbG8gV29ybGQ='
    expected_output_len = len(text)
    actual_output = encode(text=text)
    assert(expected_output == actual_output[0])
    assert(expected_output_len == actual_output[1])


# Generated at 2022-06-25 17:03:54.037453
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    from functools import partial

    # Try to get the decoder.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # The b64 codec was not registered.
        register()
        # Get the decoder.
        decoder = codecs.getdecoder(NAME)   # type: ignore
    else:
        # Get the decoder.
        decoder = codecs.getdecoder(NAME)   # type: ignore

    # Try to get the encoder.
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
        # Get the encoder.
        encoder = codecs.getencoder(NAME)   # type: ignore

# Generated at 2022-06-25 17:04:56.860329
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except LookupError:
        assert False, 'Failed to register the new b64 codec.'
    else:
        assert True



# Generated at 2022-06-25 17:05:01.468318
# Unit test for function register
def test_register():
    register()
    expected = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    encoded = expected.encode(NAME)
    assert not type(encoded) == str
    assert expected == encoded.decode(NAME)

# Generated at 2022-06-25 17:05:17.805719
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 17:05:22.037279
# Unit test for function register
def test_register():
    register()

    # Test that the register function added the new codecs.CodecInfo
    # object to the Python codec registry.
    codecs_info = codecs.getdecoder(NAME)
    assert type(codecs_info) == codecs.CodecInfo



# Generated at 2022-06-25 17:05:23.284970
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:05:26.151542
# Unit test for function register
def test_register():
    register()
    x = codecs.getdecoder(NAME)
    assert x[0](b'Hello world') == ('SGVsbG8gd29ybGQ=', 11)
    x = codecs.getencoder(NAME)
    assert x[0]('Hello world') == (b'SGVsbG8gd29ybGQ=', 11)



# Generated at 2022-06-25 17:05:28.125091
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-25 17:05:34.989194
# Unit test for function encode

# Generated at 2022-06-25 17:05:37.538761
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.decode.__code__.co_varnames
    assert NAME in codecs.encode.__code__.co_varnames


# Generated at 2022-06-25 17:05:39.069744
# Unit test for function register
def test_register():
    assert register() is None

# Unit tests for function decode

# Generated at 2022-06-25 17:07:55.528227
# Unit test for function encode
def test_encode():
    """
    Unit test for function encode
    """
    # Test encoding with white space.
    test_0 = "TGV0J3MgYmxvY2sgYW5kIGRyYWZ0IGFuZCBlbGlnaWJsZSBlZmZlY3RpdmUgYXBwbGljYWJsZSBlbmNvdW50ZXJzLg=="
    assert test_0 == encode('Let\'s block and draft and eligible effective applicable encountern.')[0].decode()



# Generated at 2022-06-25 17:08:02.129278
# Unit test for function register
def test_register():
    input_data = 'This is a string to be encoded.'.encode('utf-8')
    expected = (
        'VGhpcyBpcyBhIHN0cmluZyB0byBiZSBlbmNvZGVkLg==\n',
        45,
    )

    dec = codecs.getdecoder(NAME)
    result = dec(input_data)
    assert expected == result



# Generated at 2022-06-25 17:08:03.485585
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:08:09.724802
# Unit test for function register
def test_register():
    assert not hasattr(sys.modules[__name__], 'b64_codec')
    assert codecs.lookup(NAME) is None
    test_case_0()
    assert hasattr(sys.modules[__name__], 'b64_codec')
    assert codecs.lookup(NAME) is not None
    assert codecs.lookup(NAME).name == NAME
    assert codecs.lookup(NAME).encode('') == (b'', 0)



# Generated at 2022-06-25 17:08:16.891507
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False, 'Codec already registered'
    except LookupError:
        assert True

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec not registered'
    else:
        assert True



# Generated at 2022-06-25 17:08:29.049171
# Unit test for function register
def test_register():
    # Test the 'register()' function.
    import sys

    # Get a copy of the 'sys.modules' with the 'codecs' module removed.
    sys_modules_1 = sys.modules.copy()
    sys_modules_2 = sys_modules_1.copy()

    # Remove the codecs module
    del sys_modules_2['codecs']

    # Restore the original 'sys.modules'
    sys.modules = sys_modules_2

    # Ensure that the 'b64' codec is not available
    try:
        codecs.getencoder('b64')
        assert False
    except LookupError:
        pass
    try:
        codecs.getdecoder('b64')
        assert False
    except LookupError:
        pass

    # Register the 'b64' codec
    register()



# Generated at 2022-06-25 17:08:30.044295
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-25 17:08:34.149240
# Unit test for function register
def test_register():
    def test_case_0():
        # Test the case where the b64 codec is already registered.
        register()
        register()

    def test_case_1():
        # Test the case where the b64 codec is not registered.
        try:
            codecs.getencoder(NAME)
        except LookupError:
            pass
        else:
            raise AssertionError
        register()
        codecs.getencoder(NAME)

    test_case_0()
    test_case_1()

