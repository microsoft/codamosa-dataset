

# Generated at 2022-06-25 16:58:42.159523
# Unit test for function register
def test_register():
    register()
    with pytest.raises(LookupError):
        codecs.getdecoder('b64')



# Generated at 2022-06-25 16:58:42.932394
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 16:58:45.905951
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        assert NAME in codecs.getdecoder(NAME)
    else:
        assert NAME in codecs.getdecoder(NAME)



# Generated at 2022-06-25 16:58:48.328789
# Unit test for function register
def test_register():
    """Register the `b64` codec with Python."""
    register()
    with pytest.raises(LookupError):
        codecs.register(NAME)



# Generated at 2022-06-25 16:58:59.403512
# Unit test for function encode
def test_encode():
    test_case_0()

    # Test the empty string
    text = ''
    bytes_ = encode(text)[0]
    assert bytes_ == b''

    # Test a text with a single line
    text = 'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wZWQgb3ZlciB0aGUgbGF6eSBkb2cu'
    bytes_ = encode(text)[0]
    assert bytes_ == b'The quick brown fox jumped over the lazy dog.'

    # Test a text with multiple lines
    text = 'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wZWQgb3ZlciB0aGUgbGF6eSBkb2cu\n\n'
    bytes_ = encode(text)[0]

# Generated at 2022-06-25 16:59:07.068927
# Unit test for function register
def test_register():
    register()
    decode_func = codecs.getdecoder(NAME)
    encode_func = codecs.getencoder(NAME)
    expected_bytes = b'\x00\x01\x02'
    expected_text = 'AAEC'

    result_bytes, bytes_length = decode_func(expected_text)
    result_text, text_length = encode_func(expected_bytes)

    # Assert that the functions return the expected results
    assert result_bytes == expected_bytes and bytes_length == len(expected_text)
    assert result_text == expected_text and text_length == len(expected_bytes)

    # Assert that the functions raise an error when passed invalid values
    failed = False
    try:
        decode_func('')
    except (TypeError, ValueError):
        failed = True


# Generated at 2022-06-25 16:59:08.123804
# Unit test for function register
def test_register():
    """Register the b64 codec."""
    register()

# Generated at 2022-06-25 16:59:16.767788
# Unit test for function encode
def test_encode():
    register()
    """Test case for function encode"""
    encode_bytes = b'\xc9\x9a\x86\xb0\x97\x9f\x97w\x8e\x0f\x9d...\xb3'
    assert encode(encode_bytes, 'strict') == (
        b'w7VlYl9uX1tlXlxgfCDlYFzZ2BucG5kY2Jz', 13
    )
    assert encode(
        'w7VlYl9uX1tlXlxgfCDlYFzZ2BucG5kY2Jz', 'strict'
    ) == (encode_bytes, 13)



# Generated at 2022-06-25 16:59:25.700109
# Unit test for function encode
def test_encode():
    """
    Test 'encode' function
    """
    base_str = 'dGVzdF91c2VyX2lkXzEgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXN0X3NlY3JldF90b2tlbl8xCg=='
    expect = 'test_user_id_1                                                                               test_secret_token_1\n'

    actual_out, _actual_out_len = encode(base_str)
    assert expect == actual_out.decode('utf-8')



# Generated at 2022-06-25 16:59:30.549982
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('Codec is already registered.')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Codec is not registered.')



# Generated at 2022-06-25 16:59:34.339367
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


# Generated at 2022-06-25 16:59:40.531521
# Unit test for function register
def test_register():
    """Test the registers of base64 encoder/decoder."""
    register()
    encoded = 'SGVsbG8gd29ybGQh'
    expected = 'Hello world!'
    assert encoded == codecs.encode(expected, NAME).decode('utf-8')
    assert expected == codecs.decode(encoded, NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 16:59:41.178578
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 16:59:43.299687
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-25 16:59:50.856276
# Unit test for function encode
def test_encode():
    # Test encode with a string argument
    text = '''
    ZWNobyAiSSBhbSBiYXNlNjQtZGVjb2Rpbmci
    IHwgYmFzZTY0LWRlY29kZSA+PiBkZWNvZGVk
    LnR4dDo7IGVjaG8gIkknbSBvcGVuLXNoZWxs
    ICAgICAgICAgICAgICAgICAgIGJhc2U2NC1l
    bmdhZ2UgLXMgZGVjb2RlZC50eHQiIHwgYmFz
    ZTY0ICAgPiA+PiBkZWNvZGVkMi50eHQ='''
    # text = 'ZWNoby

# Generated at 2022-06-25 16:59:57.633357
# Unit test for function register
def test_register():
    from pytest import raises

    # Arrange
    codecs_getdecoder = codecs.getdecoder

    # Act
    with raises(LookupError):
        codecs.getdecoder(NAME)

    register()
    actual = codecs.getdecoder(NAME)

    # Assert
    assert actual is not None

    # Cleanup
    codecs.getdecoder = codecs_getdecoder


test_case_0()

# Generated at 2022-06-25 17:00:04.921053
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{NAME} is already registered')
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError(f'{NAME} is not registered.')
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'{NAME} is not registered.')



# Generated at 2022-06-25 17:00:08.194746
# Unit test for function register
def test_register():
    # Verify registration succeeds
    test_case_0()
    # Verify registration fails
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:00:14.068760
# Unit test for function register
def test_register():
    # Testing for ability for function register to register the b64
    # codec with the python codec package.
    register()

    # Testing for the ability of function register to do nothing if
    # the b64 codec is already registered.
    register()

    # Testing for the ability of function register to register the b64
    # codec after the b64 codec has been unregistered.
    codecs.unregister(NAME)
    register()



# Generated at 2022-06-25 17:00:16.430666
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-25 17:00:23.065455
# Unit test for function encode
def test_encode():
    register()
    text = "It's a trap!"
    errors = "strict"
    text_bytes = encode(text, errors)
    assert text_bytes == b"SXQncyBhIHRyYXA="


# Generated at 2022-06-25 17:00:25.611263
# Unit test for function register
def test_register():
    assert 'b64' in codecs.__all__



# Generated at 2022-06-25 17:00:35.855606
# Unit test for function encode
def test_encode():
    import codecs
    register()
    codec = codecs.getencoder(NAME)
    out, l = codec(b'12345')
    assert l == 5
    assert out == 'MTIzNDU=\n'
    out, l = codec(b'1234')
    assert l == 4
    assert out == 'MTIzNA==\n'
    out, l = codec(b'123')
    assert l == 3
    assert out == 'MTIz\n'
    out, l = codec(b'12')
    assert l == 2
    assert out == 'MTI=\n'
    out, l = codec(b'1')
    assert l == 1
    assert out == 'MQ==\n'
    out, l = codec(b'')
    assert l == 0

# Generated at 2022-06-25 17:00:37.002619
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:00:44.542750
# Unit test for function encode

# Generated at 2022-06-25 17:00:45.877503
# Unit test for function register
def test_register():
    test_case_0()
    pass


# Generated at 2022-06-25 17:00:56.610342
# Unit test for function encode
def test_encode():
    from random import randint

    register()
    # Create some random base64 text
    num_lines = randint(2, 6)
    lines = [
        random_string(randint(1, 25), base64_chars)
        for _ in range(num_lines)
    ]
    text = '\n'.join(lines)
    # Create a random indented string
    indent = random_string(randint(0, 8), punctuation_chars)
    # Create the indented string
    indented_text = '\n'.join([f'{indent}{line}' for line in lines])

    # Encode the text
    encoded_data, length = encode(text)
    assert length == len(text)
    # Encode the indented text

# Generated at 2022-06-25 17:01:07.209967
# Unit test for function register
def test_register():
    register()
    for test_case in (
            b'',
            b'A',
            b'AA',
            b'AAA',
            b'ABC',
            b'a',
            b'aa',
            b'aaa',
            b'aaaa',
            b'aaaaa',
            b'aaaaaa',
            b'aaaaaaa',
            b'aaaaaaaa',
            b'aaaaaaaaa',
            b'aaaaaaaaaa',
            b'balance',
            b'balance\x00',
            b'balance\x00\x00',
            b'balance\x00\x00\x00',
            b'balance\x00\x00\x00\x00',
    ):
        expected_b64 = base64.b64encode(test_case).decode('utf-8')
       

# Generated at 2022-06-25 17:01:09.691073
# Unit test for function register
def test_register():

    # Test function name
    assert test_case_0.__name__ == 'test_case_0'

    # Test function output
    assert test_case_0() is None



# Generated at 2022-06-25 17:01:12.401794
# Unit test for function encode
def test_encode():
    text_input = 'T3B0aW9ucw=='
    text = 'Options'
    assert(encode(text_input)[0] == text.encode('utf-8'))


# Generated at 2022-06-25 17:01:21.021491
# Unit test for function register
def test_register():
    # Register the 'b64' codec.
    register()

    # Confirm that the codec was registered.
    codecs.getdecoder(NAME)  # Should not raise LookupError


# Generated at 2022-06-25 17:01:24.121373
# Unit test for function encode
def test_encode():
    register()
    string = 'hi'
    assert encode(string) == (b'aGk=', 2)
    assert encode(string) == (b'aGk=', 2)



# Generated at 2022-06-25 17:01:32.273915
# Unit test for function encode
def test_encode():
    register()

    data = (
        "Man is distinguished, not only by his reason, but by this "
        "singular passion from other animals, which is a lust of the "
        "mind, that by a perseverance of delight in the continued and "
        "indefatigable generation of knowledge, exceeds the short "
        "vehemence of any carnal pleasure."
    )


# Generated at 2022-06-25 17:01:34.015114
# Unit test for function register
def test_register():
  try:
    codecs.getdecoder(NAME)
    return True
  except LookupError:
    return False

test_case_0()

# Generated at 2022-06-25 17:01:38.088080
# Unit test for function register
def test_register():
    message = '''
    Testing function register.
    The function is used as a decorator.
    The function is used to register the codec 'b64'
    with Python.
    The register function is not tested, as the
    codec is used in other testing functions.
    '''
    print(message)



# Generated at 2022-06-25 17:01:41.927525
# Unit test for function register
def test_register():
    """Test the register function."""
    test_case_0()

# Generated at 2022-06-25 17:01:43.162649
# Unit test for function register
def test_register():
    assert True



# Generated at 2022-06-25 17:01:45.870615
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:01:50.527562
# Unit test for function encode
def test_encode():
    text = '\n  \n \t \n   Zm9vIG9jdHViZQ== \n \t \n \t\n'
    out, length = encode(text)
    assert out == b'foo oculus'
    assert length == len(text)


# Generated at 2022-06-25 17:02:00.968758
# Unit test for function encode
def test_encode():
    register()
    assert encode('QQ==\n') == (b'\x04', 4)
    assert encode('Qg==') == (b'\x08', 3)
    assert encode('QA==') == (b'\x00', 3)
    assert encode('Qg==') == (b'\x08', 3)
    assert encode('VGVzdCBpbnB1dA==') == (b'Test input', 11)
    assert encode('VGVzdCBpbnB1dAo=') == (b'Test input\n', 12)
    assert encode('\nVGVzdCBpbnB1dA==') == (b'\nTest input', 12)

# Generated at 2022-06-25 17:02:23.855860
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 16)
    assert encode('  aGVsbG8gd29ybGQ=\n') == (b'hello world', 16)
    assert encode('  aGVsbG8gd29ybGQ=\n \n') == (b'hello world', 16)
    assert encode('  aGVsbG8gd29ybGQ=\n \t \n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n \t \n') == (b'hello world', 16)

# Generated at 2022-06-25 17:02:25.031409
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:02:26.114230
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:02:29.599333
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-25 17:02:30.503714
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:02:32.501055
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)



# Generated at 2022-06-25 17:02:35.296112
# Unit test for function register
def test_register():
    codecs.lookup(NAME)


# Generated at 2022-06-25 17:02:41.243801
# Unit test for function register
def test_register():
    try:
        c = codecs.lookup(NAME)
        c_name = c.name
        assert c_name == NAME
    except LookupError:
        assert False



# Generated at 2022-06-25 17:02:47.103951
# Unit test for function encode
def test_encode():
    # Given
    text = '\n'.join([
        'ZM4wODI2Y2Y6OmF0dGFjaG1lbnQ6Og==',
        '  6c6f6f6b696520726f636b657465',
    ])
    expected = b'\x1f\x08\x26\xcf::attachment:::lookie rockete'

    # When
    actual, _ = encode(text)

    # Then
    assert expected == actual



# Generated at 2022-06-25 17:02:48.363600
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()

# Generated at 2022-06-25 17:03:02.334854
# Unit test for function register
def test_register():
    assert register() == None


# Generated at 2022-06-25 17:03:08.514163
# Unit test for function register
def test_register():
    capitalize = register

    # pylint: disable=W0613
    # noinspection PyUnusedLocal
    def _assert_codec_exists(name):
        codecs.getdecoder(name)  # Type: ignore

    # noinspection PyTypeChecker
    capitalize()
    _assert_codec_exists(NAME)

# Generated at 2022-06-25 17:03:10.418208
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    # pylint: disable=unused-variable
    test_case_0()



# Generated at 2022-06-25 17:03:14.914045
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:17.964226
# Unit test for function register
def test_register():
    """Test the function ``register``"""
    test_case_0()

# Generated at 2022-06-25 17:03:19.087302
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:03:20.251590
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:03:24.088964
# Unit test for function register
def test_register():
    """
    Test Case:
     - Register b64
    Expected Results:
     - Register the b64 codec with Python.
    """
    test_case_0()



# Generated at 2022-06-25 17:03:24.941979
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:35.324571
# Unit test for function register
def test_register():
    test_case_0()

if __name__ == '__main__':
    from os import sys
    from typing import Any, List
    from unittest import TestCase, TextTestRunner

    class Test_register(TestCase):  # noqa pylint: disable=R0904
        def test_0(self: Any) -> None:
            test_register()

    class Test_decode(TestCase):  # noqa pylint: disable=R0904
        def test_0(self: Any) -> None:
            expected = '42'
            actual = decode(b'NDI=')[0]
            self.assertEqual(expected, actual)

        def test_1(self: Any) -> None:
            expected = '4\n2\n'

# Generated at 2022-06-25 17:03:56.912516
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:03:57.856451
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:04:01.747334
# Unit test for function register
def test_register():
    assert_raises(
        LookupError,
        codecs.getdecoder,
        NAME
    )
    register()

    decoder = codecs.getdecoder(NAME)  # type: ignore
    assert decoder.name == NAME



# Generated at 2022-06-25 17:04:06.879468
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:04:12.035053
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__
    assert codecs.__dict__[NAME][0] == NAME
    assert codecs.__dict__[NAME][1] == decode
    assert codecs.__dict__[NAME][2] == encode
    assert codecs.__dict__[NAME][3] == 'b64'
    assert codecs.__dict__[NAME][4] == '<does nothing>'


# Generated at 2022-06-25 17:04:17.058683
# Unit test for function register
def test_register():
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    register()
    assert NAME == codecs.getdecoder(NAME).name
    assert NAME == codecs.decode.__name__



# Generated at 2022-06-25 17:04:22.242511
# Unit test for function register
def test_register():
    assert not hasattr(codecs, 'b64_encode')
    assert not hasattr(codecs, 'b64_decode')
    register()
    assert 'b64_encode' in dir(codecs)
    assert 'b64_decode' in dir(codecs)



# Generated at 2022-06-25 17:04:30.622713
# Unit test for function register
def test_register():
    register()
    # Test that the codecs.getdecoder() returns the expected class.
    decoder = codecs.getdecoder(NAME)
    assert decoder[0].__name__ == NAME



# Generated at 2022-06-25 17:04:33.192962
# Unit test for function register
def test_register():
    # Setup
    result = None

    # Act
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        result = False
    else:
        result = True

    # Assert
    assert result

# Generated at 2022-06-25 17:04:36.293348
# Unit test for function register
def test_register():
    register()
    """Test registerning the b64 codec"""
    codec_info = codecs.getdecoder(NAME)
    assert codec_info.name == NAME



# Generated at 2022-06-25 17:05:28.165544
# Unit test for function register
def test_register():
    register()   # type: ignore
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

# Generated at 2022-06-25 17:05:30.087184
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None
    return



# Generated at 2022-06-25 17:05:31.182552
# Unit test for function register
def test_register():
    # pylint: disable=pointless-statement
    assert register()



# Generated at 2022-06-25 17:05:40.613800
# Unit test for function encode
def test_encode():
    from binascii import hexlify
    from base64 import b64decode, b64encode
    from pytest import raises
    import codecs
    from typing import Tuple
    from typing import (
        Optional,
        Union,
    )
    _STR = Union[str, UserString]
    _ByteString = Union[bytes, bytearray, memoryview]
    # assert codecs.encode('hello world', 'b64') == b64encode(b'hello world')
    assert encode('foo') == (b'Zm9v', 3)
    assert encode('foo.bar') == (b'Zm9vLmJhcg==', 8)
    assert encode('exclamation mark') == (b'ZXhjbGFtYXRpb24gbWFyaw==', 20)

# Generated at 2022-06-25 17:05:44.010403
# Unit test for function encode
def test_encode():
    if not hasattr(sys, 'pypy_version_info'):
        # pylint: disable=C0103
        import utf8codec_test
        utf8codec_test.test_encode(NAME)


# Generated at 2022-06-25 17:05:47.897604
# Unit test for function encode
def test_encode():
    register()
    msg_text = u'V2hhdCBhIGNhcmVmdWwgcmVxdWVzdCE='
    msg_bytes = b'What a careful request!'
    assert msg_text.encode(NAME) == msg_bytes


# Generated at 2022-06-25 17:05:59.351509
# Unit test for function register
def test_register():  # noqa: D103
    from collections import UserString
    from typing import ByteString as _ByteString

    test_case_0()

    test_string = 'The Quick Brown Fox Jumped Over The Lazy Dog'
    test_bytes = test_string.encode()

    encoded_string = test_string.encode(NAME).decode(NAME)
    assert encoded_string == test_string

    decoded_string = test_bytes.decode(NAME).encode(NAME)
    assert decoded_string == test_bytes

# Generated at 2022-06-25 17:06:03.345396
# Unit test for function register
def test_register():
    """Test the function `register`"""
    test_case_0()
    test_case_0()
    test_case_0()


test_register()

# Generated at 2022-06-25 17:06:05.889569
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:06:14.939127
# Unit test for function register
def test_register():
    assert_equals(b64_decode(b'ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert_equals(b64_encode('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')

if __name__ == '__main__':
    test_case_0()
    test_register()

# Generated at 2022-06-25 17:07:14.973446
# Unit test for function register
def test_register():
    import codecs
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:07:19.360895
# Unit test for function register
def test_register():
    # Check to see if the codecs are already registered.
    try:
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
        have_codec = True
    except LookupError:
        have_codec = False

    if have_codec:
        unregister()

    # The codecs are not registered, register them.
    register()

    # Confirm that they are now registered.
    try:
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
        is_registered = True
    except LookupError:
        is_registered = False
    assert is_registered

    # Unregister the codecs again.
    unregister()

    # Confirm that they are no longer registered.

# Generated at 2022-06-25 17:07:22.614014
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:07:30.192990
# Unit test for function encode
def test_encode():
    simple_str = ''
    assert encode(simple_str) == (b'', 0)

    simple_str = 'a'
    assert encode(simple_str) == (b'YQ==', 1)

    simple_str = 'ab'
    assert encode(simple_str) == (b'YWI=', 2)

    simple_str = 'abc'
    assert encode(simple_str) == (b'YWJj', 3)

    simple_str = 'abcd'
    assert encode(simple_str) == (b'YWJjZA==', 4)

    simple_str = 'abcde'
    assert encode(simple_str) == (b'YWJjZGU=', 5)

    simple_str = 'abcdef'

# Generated at 2022-06-25 17:07:30.733014
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:07:31.929858
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:07:36.284496
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:07:38.574281
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:07:41.487678
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('codec already registered')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('codec not registered')
    else:
        pass


# Generated at 2022-06-25 17:07:46.388015
# Unit test for function register
def test_register():

    register()