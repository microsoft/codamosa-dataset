

# Generated at 2022-06-25 16:58:41.144157
# Unit test for function encode
def test_encode():
    import pytest
    register()
    text = "AQIDBA=="
    b_text = encode(text)
    assert b_text[0] == b'\x01\x02\x03\x04'
    text = "AQIDBA"
    b_text = encode(text)
    assert b_text[0] == b'\x01\x02\x03\x04'


# Generated at 2022-06-25 16:58:48.128506
# Unit test for function encode
def test_encode():
    # Unit test for function encode
    register()
    # Decode a base64 string
    s = "U3VubnkgaXMgYSBoYXJkIHdvcmsgZm9yIHRoZSB3b3JsZCdzIGZpcnN0IGphdmFzY3JpcHQgZGVjb2RpbmcgY29kZWMuIEdpdGh1YiBkb2VzIG5vdCBzdXBwb3J0IGphdmFzY3JpcHQsIGJ1dCBJIHN0cnVnZ2xlZCBhbG9uZyB0byBmaW5kIGEgd2F5IHRvIGdldCB0aGUgdGVzdCB0byB3b3JrLg=="

# Generated at 2022-06-25 16:58:51.320299
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 16:58:52.593829
# Unit test for function register
def test_register():
    """Test function register"""
    # Case 0
    test_case_0()

# Generated at 2022-06-25 16:58:59.929668
# Unit test for function encode
def test_encode():
    # Test all possible ascii characters.
    ascii_string = ''.join(map(chr, range(256)))
    ascii_bytes = bytes(ascii_string, encoding='ascii')
    test_input = ascii_string.encode('base64', errors='replace').decode('ascii')
    actual_bytes, _len = encode(test_input)
    assert actual_bytes == ascii_bytes, (
        'encoded base64 bytes are not the same as the input bytes'
    )



# Generated at 2022-06-25 16:59:02.904077
# Unit test for function register
def test_register():
    """Test function ``_register``.
    Test that the ``b64`` codec is registered with the ``codecs`` module.
    """
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-25 16:59:03.541820
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 16:59:06.694846
# Unit test for function register
def test_register():
    register()

    decoder_func, encoder_func, stream_reader_func, stream_writer_func, _ = \
        codecs.lookup(NAME)
    assert decoder_func is decode
    assert encoder_func is encode
    assert stream_reader_func is None
    assert stream_writer_func is None



# Generated at 2022-06-25 16:59:16.421881
# Unit test for function register
def test_register():
    register()
    encoded = "99999\n"
    inp = b'\x9b'
    out = b'\x9b'
    encoded_bytes = b'OTk5OTk=\n'
    try:
        decoded = codecs.decode(encoded, NAME)
    except Exception as e:
        print(e)
        assert False

    assert encoded.encode(NAME) == encoded_bytes
    assert codecs.decode(encoded_bytes, NAME) == encoded
    assert encode(encoded)[0] == encoded_bytes
    assert decode(encoded_bytes)[0] == encoded
    assert decode(encoded_bytes)[1] == len(encoded_bytes)
    assert encode(encoded)[1] == len(encoded)

# Generated at 2022-06-25 16:59:18.766007
# Unit test for function register
def test_register():
    # Exercise the function.
    test_case_0()



# Generated at 2022-06-25 16:59:22.249502
# Unit test for function register
def test_register():
    assert test_case_0() is None

# Generated at 2022-06-25 16:59:23.499719
# Unit test for function register
def test_register():
    # Test that the register function works.
    test_case_0()



# Generated at 2022-06-25 16:59:25.700167
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME).name
    assert NAME in codecs.getencoder(NAME).name


# Generated at 2022-06-25 16:59:27.101882
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 16:59:29.116683
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error(NAME) is None
    assert codecs.getdecoder(NAME) is decode

# Generated at 2022-06-25 16:59:32.466391
# Unit test for function register
def test_register():
    # Test for the codec being registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, (
            f'The codec {NAME!r} was not registered with Python.'
        )



# Generated at 2022-06-25 16:59:37.812858
# Unit test for function encode
def test_encode():
    register()
    str1 = "Test string"
    encode_str, length = codecs.encode(str1, 'b64')
    print(encode_str)
    if isinstance(encode_str, bytes):
        encode_str = encode_str.decode('utf-8')
    assert encode_str == 'VGVzdCBzdHJpbmc='


# Generated at 2022-06-25 16:59:47.613828
# Unit test for function encode
def test_encode():
    register()
    assert encode('SGVsbG8hIFdvcmxkIQ==\n') == (b'Hello! World!', 24)
    assert encode('SGVsbG8hIFdvcmxkIQ==') == (b'Hello! World!', 24)
    assert encode('SGVsbG8hIFdvcmxkIQ') == (b'Hello! World!', 24)
    assert encode('SGVsbG8hIFdvcmxkIQ==\n', 'ignore') == (b'Hello! World!', 24)
    assert encode('SGVsbG8hIFdvcmxkIQ==', 'ignore') == (b'Hello! World!', 24)

# Generated at 2022-06-25 16:59:51.835603
# Unit test for function register
def test_register():
    in_str = "Hello\nWorld\n"
    in_bytes = codecs.decode(in_str, 'utf-8')
    encoded_str = codecs.encode(in_bytes, 'b64').decode('utf-8')

    assert encoded_str == "SGVsbG8KV29ybGQK"


# Generated at 2022-06-25 17:00:01.002499
# Unit test for function encode

# Generated at 2022-06-25 17:00:15.319982
# Unit test for function encode
def test_encode():
    from pytest import approx
    from .testdata import (
        LONG_BASE64_STR,
        LONG_BASE64_BYTES,
    )
    text = LONG_BASE64_STR
    expected = LONG_BASE64_BYTES
    actual = encode(text)
    assert actual[0] == expected
    assert actual[1] == approx(len(expected))



# Generated at 2022-06-25 17:00:22.976463
# Unit test for function register
def test_register():
    # get decoder for the `b64` codec
    get_decoder = codecs.getdecoder('b64')
    # verify the given decoder is the desired decoder
    assert get_decoder('QQ==') == ('A', 2)
    # get encoder for the `b64` codec
    get_encoder = codecs.getencoder('b64')
    # verify the given encoder is the desired encoder
    assert get_encoder(b'A') == ('QQ==', 1)



# Generated at 2022-06-25 17:00:28.592217
# Unit test for function register
def test_register():
    # Function to be tested
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-25 17:00:31.577606
# Unit test for function register
def test_register():
    # Setup test
    test_case_0()

    # Test register
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:00:39.884665
# Unit test for function encode
def test_encode():
    assert encode(
        '''
        VGhlIEJhc2U2NCBzdHJpbmcKZGlmZmVyZW50IGZyb20gdGhhdCBpbiB0aGUgVVJJCgo=
        '''
    ) == (b'The Base64 string\ndifferent from that in the URI\n', 115)

    assert encode(
        '''
        Zm9v
        YmFy
        Cg==
        '''
    ) == (b'foo\nbar\n\n', 18)

    assert encode(
        '''
        Zm9v
        YmFy
        Cg==
        '''
    ) == (b'foo\nbar\n\n', 18)

    # The following tests were taken from Base64's test

# Generated at 2022-06-25 17:00:40.987856
# Unit test for function register
def test_register():
    assert register() == None

# Generated at 2022-06-25 17:00:44.196011
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()

    assert NAME in codecs.getdecoder('b64')


# Generated at 2022-06-25 17:00:45.435086
# Unit test for function encode
def test_encode():
    """
    Unit Test for function encode
    """
    pass


# Generated at 2022-06-25 17:00:49.169684
# Unit test for function register
def test_register():
    register()
    try:
        # pylint: disable=C0301
        # noinspection PyUnresolvedReferences
        from my_codecs_b64 import b64
    except ImportError as e:
        # pylint: disable=raise-missing-from
        raise ImportError(
            f'The "{NAME}" codec has not been registered: {e}'
        )



# Generated at 2022-06-25 17:00:59.640462
# Unit test for function register

# Generated at 2022-06-25 17:01:17.001235
# Unit test for function encode

# Generated at 2022-06-25 17:01:27.253792
# Unit test for function register
def test_register():
    # Make sure the required codec is registered.
    register()

    # Make sure the codec is registered as expected.
    # codecs.lookup returns a CodecInfo object.
    # http://docs.python.org/3/library/codecs.html#codecs.CodecInfo
    info = codecs.lookup(NAME)
    assert info.encode(
        b'hello world',
        'strict'
    ) == (b'aGVsbG8gd29ybGQ=', 11)
    assert info.decode(
        b'aGVsbG8gd29ybGQ',
        'strict'
    ) == ('aGVsbG8gd29ybGQ', 11)

# Generated at 2022-06-25 17:01:31.771743
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Register the codec.
    register()

    # Lookup the codec object.
    try:
        codecs.lookup(NAME)
    except LookupError as e:
        raise LookupError(
            'Unable to lookup "{}".'.format(NAME)
        ) from e


if __name__ == '__main__':
    test_case_0()
    test_register()

# Generated at 2022-06-25 17:01:34.485516
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False, 'calling register did not raise a LookupError'
    except LookupError:
        pass
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:01:44.271918
# Unit test for function encode
def test_encode():
    register()
    assert encode('QUJD')[0] == b'ABC'
    assert encode('IUVcYlVd')[0] == b'HX\x9cU]'
    assert encode(r'QUJDICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAog')[0] == b'ABC                                                                                       \n'
    assert encode(r'QUJDICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAog')[1] == 71
    # In the following we test some strings that are not valid base64
    # encodings.

# Generated at 2022-06-25 17:01:46.673659
# Unit test for function register
def test_register():
    """Unit test for function register."""

    # Call the ``register()`` function.
    register()

    # Verify the ``b64`` codec is now registered by trying to get the
    # ``decoder`` for the ``b64`` codec.
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:01:57.099851
# Unit test for function encode
def test_encode():
    test_str = '\n'.join([
        'AQIDBAUGBwgJ',
        'AAECAwQFBgcI',
    ])
    test_bytes = bytes([
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05,
        0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b,
    ])

    assert encode(test_str)[0] == test_bytes
    assert encode(test_str)[1] == len(test_str)


# Generated at 2022-06-25 17:02:09.010941
# Unit test for function register
def test_register():
    arg0 = b'SGVsbG8gV29ybGQ='
    arg1 = 'Hello World'

    # Test the encode/decode functions
    assert base64.b64decode(arg0, validate=True) == arg1.encode('utf-8')
    assert arg0 == base64.b64encode(arg1.encode('utf-8'))

    # Test the b64 codec
    assert arg0.decode('b64') == arg1
    assert arg1.encode('b64') == arg0



# Generated at 2022-06-25 17:02:10.945442
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:02:13.926861
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:02:36.311107
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is encode
    assert codecs.getdecoder(NAME) is decode



# Generated at 2022-06-25 17:02:39.805949
# Unit test for function encode
def test_encode():
    assert encode('TWFu')[0] == b'Man'
    assert encode('TWFuIHxyYXcK')[0] == b'Man raw'



# Generated at 2022-06-25 17:02:48.796852
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception(
            f'Expected LookupError, but did not get one.  The "{NAME}" codec '
            'is already registered.'
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(
            f'Expected to be able to find the "{NAME}" codec in the set of '
            'available codecs, but could not.'
        )



# Generated at 2022-06-25 17:02:50.258624
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:02:52.668807
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError('unexpected success')
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:02:58.545830
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from b64 import NAME, decode, encode

    import codecs

    # Get the 'b64' CodecInfo object.
    codec_info = codecs.getdecoder(NAME)

    # Make sure we get the 'b64' CodecInfo object we expect.
    assert codec_info.name == NAME
    assert codec_info.decode == decode
    assert codec_info.encode == encode



# Generated at 2022-06-25 17:03:05.413561
# Unit test for function encode
def test_encode():
    result = encode("SSdtIG5vdCBmb3VuZCBpbiB0aGUgQkE=")
    assert result == (b'I\x84\x01\x03\x03', 21)

# Generated at 2022-06-25 17:03:08.947115
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:03:15.281076
# Unit test for function register
def test_register():
    register()
    assert codecs.codecs_encode(['b64'], b'abc') == (b'YWJj', 4)  # type: ignore
    assert codecs.codecs_encode(['b64'], 'abc') == (b'YWJj', 2)  # type: ignore



# Generated at 2022-06-25 17:03:20.263030
# Unit test for function register
def test_register():
    # type: () -> None
    """Unit test for function register"""

    assert NAME not in codecs.__dict__['_cache']
    register()
    assert codecs.getencoder(NAME) == encode     # type: ignore
    assert codecs.getdecoder(NAME) == decode     # type: ignore



# Generated at 2022-06-25 17:04:01.434082
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.encode(NAME, 'b64')



# Generated at 2022-06-25 17:04:05.797367
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:04:09.329607
# Unit test for function register
def test_register():
    # Register the codec using the codecs module.
    assert 'b64' not in codecs.getencoders()
    register()
    assert 'b64' in codecs.getencoders()



# Generated at 2022-06-25 17:04:12.804895
# Unit test for function encode
def test_encode():
    data = "0xU6KuUF0E/1YI/1a8mZp6g=="
    result = encode(data)
    assert result == (b'\x00\x00\x00\x00\x00\x00\x00\x00', 0)


# Generated at 2022-06-25 17:04:20.910834
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    def _test_decoder(
            text_input: _STR,
            expected_bytes: bytes
    ) -> None:
        actual_bytes, _ = codecs.decode(text_input.encode('utf8'), NAME)
        assert actual_bytes == expected_bytes

    def _test_encoder(
            data_bytes: bytes,
            expected_str: _STR
    ) -> None:
        actual_str, _ = codecs.decode(data_bytes, NAME)
        assert actual_str == expected_str


# Generated at 2022-06-25 17:04:24.219264
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:04:30.668664
# Unit test for function register
def test_register():
    # Check that we can register the "b64" codec.
    assert 'b64' not in codecs.__dict__
    register()
    assert 'b64' in codecs.__dict__



# Generated at 2022-06-25 17:04:38.045184
# Unit test for function encode
def test_encode():
    """Test for function encode"""
    register()
    assert(encode("Zm9v") == (b"foo", 4))
    assert(encode("Zm9\n9") == (b"foo", 4))
    assert(encode("Zm9v\n") == (b"foo", 4))
    assert(encode("Zm9v\n\n") == (b"foo", 4))
    assert(encode("Zm9v\n\n\n") == (b"foo", 4))
    assert(encode("\nZm9v\n\n\n") == (b"foo", 4))
    assert(encode("\nZm\n9v\n\n\n") == (b"foo", 4))

# Generated at 2022-06-25 17:04:40.445472
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:04:47.358317
# Unit test for function register
def test_register():
    try:
        # pylint: disable=W0104
        codecs.getdecoder(NAME)   # type: ignore
    except LookupError:
        register()
        # pylint: disable=W0104
        codecs.getdecoder(NAME)   # type: ignore


if __name__ == '__main__':
    test_register()
    test_case_0()

# Generated at 2022-06-25 17:06:27.926331
# Unit test for function encode
def test_encode():
    # Test argument that is of type UserString
    before_text = UserString(
        'bGFuZ190ZXN0IGxhbmdfdGVzdA==\nCg==\n'
    )
    after_bytes = b'lang_test lang_test\n\n'
    before_text_str: str = str(before_text)
    assert 'lang_test lang_test' in before_text_str, (
        'The given text should exist in before_text_str'
    )
    decoded_bytes, _ = encode(before_text)
    assert decoded_bytes == after_bytes, (
        'The given UserString should return a bytes sequence equivalent to '
        'after_bytes'
    )

    # Test argument that is of type str

# Generated at 2022-06-25 17:06:32.547340
# Unit test for function register
def test_register():
    register()

    # register() should register the 'b64' codec.
    decoder = codecs.getdecoder(NAME)
    assert NAME == decoder.__name__

    text = 'dGVzdA=='
    actual = decoder(text)[0]
    expected = b'test'
    assert expected == actual



# Generated at 2022-06-25 17:06:34.404607
# Unit test for function encode
def test_encode():
    register()
    out = encode(
        "YWJj"
    )
    assert out == (b'abc', 4)


# Generated at 2022-06-25 17:06:41.412831
# Unit test for function encode
def test_encode():
    """Test :meth:`~base64_codec.encode`."""
    register()
    example_text = """
        SGVsbG8gd29ybGQK
    """
    example_text_bytes = b'Hello world\n'
    example_text_utf8 = 'Hello world\n'
    text_bytes, length = encode(
        example_text,
        errors='strict',
    )
    assert text_bytes == example_text_bytes
    assert length == len(example_text)
    assert text_bytes.decode() == example_text_utf8


# Generated at 2022-06-25 17:06:44.146642
# Unit test for function encode
def test_encode():
    assert decode('unF1b3N5Y3') == ('functions', 8)


# Generated at 2022-06-25 17:06:45.610657
# Unit test for function register
def test_register():
    assert callable(register), f'Method is not callable: {register}'



# Generated at 2022-06-25 17:06:56.791447
# Unit test for function register
def test_register():
    # Register the b64 codec.
    register()

    # Verify this codec correctly decodes the given 'data'.
    decode_1 = codecs.getdecoder(NAME)   # type: ignore
    data = '\x01\x02\x03\x04'
    # noinspection PyTypeChecker
    data_bytes = data.encode(NAME)     # type: ignore
    data_str, consumed = decode_1(data_bytes, 'strict')
    assert data_str == 'AQIDBA=='
    assert consumed == len(data_bytes)

    # Verify this codec correctly encodes the given 'text'.
    encode_1 = codecs.getencoder(NAME)   # type: ignore
    text = 'AQIDBA=='

# Generated at 2022-06-25 17:07:01.670712
# Unit test for function register
def test_register():
    register()

    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise ValueError(
            'The b64 codec must be registered before running this test.'
        ) from e



# Generated at 2022-06-25 17:07:09.213183
# Unit test for function encode
def test_encode():
    # Testing encode(text, errors='strict')
    with pytest.raises(UnicodeEncodeError, message=(
            f'{encode.__name__}() must raise a UnicodeEncodeError when the '
            f'given "text" argument is not of type str.'
    )):
        encode(b'')

    with pytest.raises(UnicodeEncodeError, message=(
            f'{encode.__name__}() must raise a UnicodeEncodeError when the '
            f'given "text" argument is not of type str.'
    )):
        encode(None)


# Generated at 2022-06-25 17:07:14.658457
# Unit test for function register
def test_register():
    register()
    import codecs
    codecs.getencoder(NAME)

