

# Generated at 2022-06-25 16:58:42.903659
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except Exception as e:
        print('Exception:', e)
        raise



# Generated at 2022-06-25 16:58:52.389371
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise RuntimeError('The codec has not been registered.')
    except LookupError:
        # Expected exception.
        pass

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('The codec has not been registered.')


# noinspection SpellCheckingInspection

# Generated at 2022-06-25 16:58:55.798264
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    register()
    # noinspection PyUnresolvedReferences
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 16:58:59.920750
# Unit test for function register
def test_register():
    expected = codecs.CodecInfo(
        name=NAME,
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )
    actual = codecs.getdecoder(NAME)
    assert expected == actual


# Generated at 2022-06-25 16:59:00.802089
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 16:59:06.578123
# Unit test for function register
def test_register():
    # Register the b64 codec.
    register()

    # Verify that the b64 codec was registered
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 16:59:09.971760
# Unit test for function register
def test_register():
    """Check if the b64 codec is registered in Python."""
    codec_info = codecs.getdecoder(NAME)
    assert codec_info
    codec_info = codecs.getencoder(NAME)
    assert codec_info



# Generated at 2022-06-25 16:59:10.971872
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 16:59:20.806583
# Unit test for function encode
def test_encode():
    # Test Case 1
    in_str = 'hey'
    out, _ = encode(in_str)
    assert out == b'aGV5'

    # Test Case 2
    in_str = "aG9sYQ=="
    out_str, _ = encode(in_str)
    assert out_str == b'aG9sYQ=='

    # Test Case 3
    in_str = 'YWDDoG9sYQ=='
    out_str, _ = encode(in_str)
    assert out_str == b'YWDDoG9sYQ=='

    # Test Case 4
    in_str = 'aG9sYQ'
    out_str, _ = encode(in_str)
    assert out_str == b'aG9sYQ'

    # Test

# Generated at 2022-06-25 16:59:27.140976
# Unit test for function encode
def test_encode():
    test_case_0()
    text = (
        'Hello world\n'
        'How are you?'
    )
    b64 = (
        'SGVsbG8gd29ybGQK'
        'SG93IGFyZSB5b3U/'
    )
    assert encode(text)[0].hex() == b64


# Generated at 2022-06-25 16:59:31.343012
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 16:59:32.751703
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    test_case_0()

# Generated at 2022-06-25 16:59:38.508362
# Unit test for function encode
def test_encode():
    assert isinstance(encode(b'my data'), (tuple))
    assert len(encode(b'my data')) == 2
    assert isinstance(encode(b'my data')[0], bytes)
    assert isinstance(encode(b'my data')[1], int)
    assert encode(b'my data')[0] == b'my data'
    assert encode(b'my data')[1] == 7



# Generated at 2022-06-25 16:59:41.963218
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Unable to register as a codec."



# Generated at 2022-06-25 16:59:47.313941
# Unit test for function register
def test_register():
    """Unit test for function register"""
    def build_test_case(input_value: str, want: str) -> Tuple[str, str, str]:
        got = input_value.encode(NAME).decode(NAME)

        if got != want:
            msg = (
                f'\ninput     = {input_value!r}\n'
                f'           -> encoded: {got!r}\n'
                f'           -> decoded: {got!r}\n'
                f'expected: {want!r}'
            )
            raise Exception(msg)

        return input_value, got, want


# Generated at 2022-06-25 16:59:51.092872
# Unit test for function register
def test_register():
    def _test_register(name: str) -> None:
        with pytest.raises(LookupError):
            codecs.getdecoder(name)
        register()
        codecs.getdecoder(name)

    _test_register(NAME)


test_case_0()


# Generated at 2022-06-25 16:59:52.511995
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 16:59:54.359762
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 16:59:55.452320
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 16:59:56.930266
# Unit test for function encode
def test_encode():
    inp = 'aGVsbG8gd29ybGQhCg=='
    expected = 'hello world!\n'
    actual = encode(inp)
    assert actual[0].decode('ascii') == expected
    assert actual[1] == len(inp)



# Generated at 2022-06-25 17:00:09.250139
# Unit test for function register
def test_register():
    """Unit test for register"""
    register()
    codec_info = codecs.lookup(NAME)
    assert codec_info.name == NAME
    assert codec_info.decode is decode
    assert codec_info.encode is encode



# Generated at 2022-06-25 17:00:15.187459
# Unit test for function register
def test_register():
    register()

    # Create a string of valid base64 characters.
    # 'ZmlndXJlZA==' is the base64 encoding of 'figured'
    text_str = 'ZmlndXJlZA=='

    # Verify that the encoded string is valid base64.
    obj = codecs.getdecoder(NAME)
    decoded_bytes = obj(text_str)[0]
    assert decoded_bytes == b'figured'



# Generated at 2022-06-25 17:00:18.027298
# Unit test for function register
def test_register():
    # Test the register() function.
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:00:18.703120
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:00:21.097395
# Unit test for function register
def test_register():
    # Test the case where NAME is 'b64'
    test_case_0()


# Generated at 2022-06-25 17:00:25.325183
# Unit test for function register
def test_register():
    """Exercise the :func:`register` function."""
    test_case_0()

# Generated at 2022-06-25 17:00:28.592214
# Unit test for function register
def test_register():
    register()
    # Check that the codec is registered.
    codecs.lookup(NAME)

# Generated at 2022-06-25 17:00:29.240798
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:00:33.713957
# Unit test for function register
def test_register():
    # Test that the codecs.getencoder(...) returns something
    register()
    assert(codecs.getencoder(NAME) is not None)  # type: ignore
    assert(codecs.getdecoder(NAME) is not None)  # type: ignore


# Generated at 2022-06-25 17:00:40.050562
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-25 17:00:48.680032
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:00:52.714615
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            assert False


if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:01:01.408576
# Unit test for function encode
def test_encode():
    """Test ``encode``"""
    # Test that 'encode' works.
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)



# Generated at 2022-06-25 17:01:05.731674
# Unit test for function register
def test_register():
    def verify(
            *,
            name: str
    ) -> None:
        try:
            codecs.getdecoder(name)
        except LookupError:
            raise AssertionError(
                f'Expected the codec "{name}" to be registered'
            )

    verify(name=NAME)



# Generated at 2022-06-25 17:01:07.761954
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

# Generated at 2022-06-25 17:01:09.936741
# Unit test for function register
def test_register():
    register()
    assert 'b64' in codecs.decode.cache
    assert 'b64' in codecs.encode.cache



# Generated at 2022-06-25 17:01:14.796735
# Unit test for function register
def test_register():
    with pytest.raises(
            LookupError
    ) as error_info:
        codecs.getdecoder(NAME)
    assert 'b64' in repr(error_info.value)
    assert 'is not registered' in repr(error_info.value)
    assert 'os.register_b64' in repr(error_info.value)
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:01:22.779589
# Unit test for function encode
def test_encode():
    register()
    # Missing arguments
    try:
        encode()
    except TypeError:
        pass
    else:
        raise RuntimeError("encode() missing argument")

    # Passing text as bytes
    try:
        encode(b"Hello")
    except TypeError:
        pass
    else:
        raise RuntimeError("encode() missing argument")

    # Passing text as str
    try:
        encode("Hello")
    except TypeError:
        pass
    else:
        raise RuntimeError("encode() missing argument")



if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:01:23.748244
# Unit test for function register
def test_register():
    assert test_case_0() == None

# Generated at 2022-06-25 17:01:25.591240
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:01:43.293448
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:01:45.870780
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:01:58.781810
# Unit test for function encode

# Generated at 2022-06-25 17:02:07.608776
# Unit test for function encode
def test_encode():
    test_cases = (
        (  # Test case id: 0
            'xCells,yCells,Node_Count,title',  # arg0
            ('WENlTGVscyx5Q2VsbHMsTm9kZV9Db3VudCx0aXRsZQ==\n', 48)
        ),
    )

    for test_case in test_cases:
        out, expected_len = encode(*test_case[:-1])
        assert isinstance(out, bytes)
        assert len(out) == expected_len
        assert out == test_case[-1][0].encode('utf-8')


# Generated at 2022-06-25 17:02:09.305473
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['_cache']
    assert NAME in codecs.__dict__['_unknown_encoding_error']


# Generated at 2022-06-25 17:02:22.245863
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('strict') == 'b64'
    assert codecs.lookup_error('b64')
    assert codecs.lookup_error('b64').name == 'b64'
    assert codecs.lookup(NAME).name == NAME
    assert codecs.lookup(NAME).encode(
        "Hello World 1234567890!@#$%^*()<>",
        errors='strict'
    ) == (b"SGVsbG8gV29ybGQgMTIzNDU2Nzg5MCFAIyQlXiUoKDw-", 27)



# Generated at 2022-06-25 17:02:27.861241
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError("The b64 codec should not be registered "
                             "before this test.")
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-25 17:02:32.812457
# Unit test for function register
def test_register():
    register()


# -------------------------------------------

# Generated at 2022-06-25 17:02:40.787523
# Unit test for function encode
def test_encode():
    register()
    # https://en.wikipedia.org/wiki/Base64#Examples
    # for valid base64
    assert encode('Man') == (b'TWFu', 3)
    assert encode('Ma') == (b'TWo=', 3)
    assert encode('M') == (b'TQ==', 3)
    # for invalid base64
    '''
    assert encode('Mn') == None
    assert encode('Mam') == None
    assert encode('MaM') == None
    '''


# Generated at 2022-06-25 17:02:42.530202
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:03:20.650410
# Unit test for function register
def test_register():
    # pylint: disable=W0104
    x = "'"

    res_str = codecs.encode(x, 'b64')
    expected_str = "'"
    assert res_str == expected_str

    res_bytes = codecs.decode(x, 'b64')
    expected_bytes = b'\''
    assert res_bytes == expected_bytes

    assert isinstance(res_bytes, bytes)
    assert isinstance(res_str, str)




# Generated at 2022-06-25 17:03:27.572702
# Unit test for function encode
def test_encode():
    register()
    assert codecs.encode('abcdefg', 'b64') == b'YWJjZGVmZw=='
    try:
        codecs.encode('abcdefghijklmnopqrstuvwxyz-1234567890', 'b64')
        assert False, "Encoding a longer string than is valid should throw an exception."
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-25 17:03:35.717265
# Unit test for function encode
def test_encode():
    """
    Test the ``encode`` function for the "b64" codec.

    The bulk of the testing for the ``encode`` function is done
    in the documentation of the ``b64`` codec.
    """
    register()
    sample_text = '\u00BC\u00BD\u00BE'
    encoded_text = 'LTFM'
    result = codecs.encode(sample_text, NAME)  # type: ignore
    expected = encoded_text.encode('utf8')
    print('Result   :', repr(result))
    print('Expected :', repr(expected))
    assert result == expected



# Generated at 2022-06-25 17:03:44.456021
# Unit test for function register
def test_register():
    import sys
    import unittest

    try:
        import b64_codec
    except ImportError:
        b64_codec = sys.modules['b64_codec']

    class TestRegister(unittest.TestCase):
        def test_function_register_is_present(self):
            self.assertTrue(hasattr(b64_codec, 'register'))

        def test_function_register_does_not_throw(self):
            b64_codec.register()

        def test_function_decode_is_present(self):
            self.assertTrue(hasattr(b64_codec, 'decode'))

        def test_function_decode_does_not_throw(self):
            b64_codec.decode(b'AAAA==')


# Generated at 2022-06-25 17:03:46.808002
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:03:50.889617
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:03:58.965922
# Unit test for function encode
def test_encode():
    """Test the function ``encode`` for the ``b64`` encoding.

    """
    in_text = \
        '''
        AAAAAA
        AAAAAA
        AAAAAA
        AAAAAA
        AAAAAA
        AAAAAA
        '''
    out, _ = encode(in_text)
    assert out.hex() == '5154455354454154494f4e4c4f47205055424c49432050726f6772616d'
    assert out.hex() == '5154455354454154494f4e4c4f47205055424c49432050726f6772616d'



# Generated at 2022-06-25 17:04:05.684321
# Unit test for function encode
def test_encode():
    register()
    in_str = 'T1MgTnVtYmVy'.lower()
    in_bytes = in_str.encode('b64')
    out_bytes, _ = codecs.decode(in_bytes, 'b64')
    assert out_bytes == b'I am Number'



# Generated at 2022-06-25 17:04:11.557370
# Unit test for function encode
def test_encode():
    text = """
    MTIzNDVhYmNkZWYK
    MTIzNDVhYmNkZWY=
    MTIzNDVhYmNkZQo=
    MTIzNDVhYmNk
    """

    result = "12345abcdef\n12345abcdef\n12345abcde\n12345abcde".encode()

    assert encode(text)[0] == result

# Generated at 2022-06-25 17:04:20.377504
# Unit test for function register
def test_register():

    # Get the current "b64" codecs.
    prev_codec = codecs.getdecoder(NAME)

    # Unregister the "b64" codecs.
    codecs.unregister_error(NAME)

    # Try to retrieve the "b64" codecs.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('"b64" codecs should not have been registered.')

    register()

    # Get the current "b64" codecs.
    curr_codec = codecs.getdecoder(NAME)
    if curr_codec is not None:
        # Unregister the "b64" codecs.
        codecs.unregister_error(NAME)

    # Restore the "b64" codecs

# Generated at 2022-06-25 17:05:28.043921
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:05:30.865122
# Unit test for function encode
def test_encode():
    register()
    test_str = "Hello World"
    res = encode(test_str)
    assert res == (b'SGVsbG8gV29ybGQ=\n', 12)

# Generated at 2022-06-25 17:05:37.083613
# Unit test for function register
def test_register():
    """Tests for the register function using a function defined in this
    module."""
    # pylint: disable=W0612
    codecs.getdecoder(NAME)


# Unit Test for the decode function

# Generated at 2022-06-25 17:05:46.195458
# Unit test for function register
def test_register():
    _codec_info = _get_codec_info(NAME)
    if _codec_info is None:
        raise ValueError(f"Could not find codec {NAME}")

    # pylint: disable=protected-access
    assert codecs.codecs_decode == _codec_info._decode, (
        f"{NAME} is not registered as a decoder"
    )

    # pylint: disable=protected-access
    assert codecs.codecs_encode == _codec_info._encode, (
        f"{NAME} is not registered as an encoder"
    )


# unit test for function decode

# Generated at 2022-06-25 17:05:49.585416
# Unit test for function register
def test_register():
    # Create a list of codecs registered an test if the 'b64' codec is
    # registered.
    codecs_set = set(codecs.registered_extras)
    assert 'b64' in codecs_set



# Generated at 2022-06-25 17:05:54.500389
# Unit test for function encode
def test_encode():
    register()
    test_input = 'foo'
    input_bytes = test_input.encode('utf-8')
    result = base64.b64encode(input_bytes)
    test = encode(test_input)
    assert test == result


# Generated at 2022-06-25 17:05:57.116408
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:06:00.494956
# Unit test for function register
def test_register():
    import codecs
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:06:01.032101
# Unit test for function register
def test_register():
    assert True


# Generated at 2022-06-25 17:06:04.936216
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    register()
    actual_0 = codecs.getencoder(NAME)
    assert actual_0 is not None



# Generated at 2022-06-25 17:07:05.099608
# Unit test for function register
def test_register():
    """Test the function register()."""
    try:
        codecs.getdecoder('b64')
    except LookupError:
        codecs.register(_get_codec_info)


test_case_0()

# Generated at 2022-06-25 17:07:14.386529
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'IA==', 3)
    assert encode('A') == (b'QQ==', 1)
    assert encode('AA') == (b'QUE=', 2)
    assert encode('AAA') == (b'QUFB', 3)
    # Test encoding of base64 characters.
    assert encode('AQA') == (b'QVFB', 3)
    assert encode('AAQ') == (b'QVFB', 3)
    assert encode('AAAA') == (b'QUFBQQ==', 4)
    assert encode('AAAAA') == (b'QUFBQUE=', 5)
    assert encode('AAAAAA') == (b'QUFBQUE=', 5)

# Generated at 2022-06-25 17:07:16.689327
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:07:26.195727
# Unit test for function encode
def test_encode():
    test_str = 'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h' \
               '5eg=='
    test_bytes = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    test_bytes_result = (test_bytes, len(test_str))
    assert encode(test_str) == test_bytes_result



# Generated at 2022-06-25 17:07:29.691350
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    output = codecs.getdecoder(NAME)[0](b'eHlo')
    assert output == (b'Hell', 4)



# Generated at 2022-06-25 17:07:34.048650
# Unit test for function encode
def test_encode():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-25 17:07:46.583474
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import codecs

    #
    # Test the 'b64' codec.
    #
    # Test decoding.
    #
    # Test that round trip decoding works properly.
    #
    TEXT1 = (
        '''
        Test decoding that spans across multiple lines.
        Test that even for a single line decoding still works.
        Test that even for a single line decoding still works.
        '''
    )
    TEXT2 = (
        '''
        Test decoding that spans across multiple lines.
        Test that even for a single line decoding still works.
        Test that even for a single line decoding still works.
        Test that even for a single line decoding still works.
        '''
    )

# Generated at 2022-06-25 17:07:56.421528
# Unit test for function register
def test_register():
    text_str = (
        '''
        Man is distinguished, not only by his reason, but by this
        singular passion from other animals, which is a lust of the
        mind, that by a perseverance of delight in the continued and
        indefatigable generation of knowledge, exceeds the short
        vehemence of any carnal pleasure.
        '''.strip()
    )

    # Encode the 'text_str' into base64 bytes
    text_bytes = text_str.encode('utf-8')
    encoded_bytes = base64.b64encode(text_bytes)

    # Decode the 'base64_bytes' as utf8 into a string.
    encoded_str = encoded_bytes.decode('utf-8')

    # Use the b64 codec to encode the 'text_str' and produce the string,
    # '

# Generated at 2022-06-25 17:07:56.842898
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:08:07.044616
# Unit test for function register
def test_register():
    # Verify that the 'b64' decoder is not register prior to calling
    # the 'register' function
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError()

    # Verify that calling 'register' does not raise any exceptions.
    register()

    # Verify that the 'b64' decoder is register after calling
    # the 'register' function
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError()

    # Verify that the decoder's decode function is correct
    if codecs.getdecoder(NAME)[1] is not decode:
        raise AssertionError()

    # Verify that the decoder's encode function is correct