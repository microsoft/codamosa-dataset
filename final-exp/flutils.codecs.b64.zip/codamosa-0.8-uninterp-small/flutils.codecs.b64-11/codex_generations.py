

# Generated at 2022-06-25 16:58:46.581559
# Unit test for function encode

# Generated at 2022-06-25 16:58:57.627168
# Unit test for function encode

# Generated at 2022-06-25 16:59:05.984360
# Unit test for function register
def test_register():
    test_data_0_text = Base64Text()
    test_data_0_input = test_data_0_text.test_input.text
    test_data_0_expected = test_data_0_text.test_expected.text
    test_data_1_text = Base64Text()
    test_data_1_input = test_data_1_text.test_input.text
    test_data_1_expected = test_data_1_text.test_expected.text
    test_data_2_text = Base64Text()
    test_data_2_input = test_data_2_text.test_input.text
    test_data_2_expected = test_data_2_text.test_expected.text
    test_data_3_text = Base64Text()
    test_data_

# Generated at 2022-06-25 16:59:07.115168
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 16:59:16.654058
# Unit test for function encode
def test_encode():

    # Test case 0
    b'hello world\n' == b64.encode('aGVsbG8gd29ybGQK')[0]
    # Test case 1
    b'\x00\x01\x02\x03\x04' == b64.encode('AAECAQIDBAUG')[0]
    # Test case 2
    b'abcdefghijklmnopqrstuvwxyz' == b64.encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=')[0]
    # Test case 3

# Generated at 2022-06-25 16:59:27.337686
# Unit test for function register
def test_register():
    # Test to see if wrapping of the base64 encoding is done properly.  The
    # 'bb64' codec performs no wrapping.  The base64 encoding, on the other
    # hand, wraps by default.  The 'bb64' codec will preserve the input
    # formatting/wrapping as is.  I.e. if the input string is wrapped, the
    # resulting output string will be wrapped the same way.

    # Encoding the following string with the base64 codec results in the
    # string given below.
    text = '''This is a string that is wrapped across
many lines.  It is indented to show how the 'bb64' codec
will preserve the line wrapping and indentation of the input.

The decode method will unwrap the input.'''

    # The result from encoding the above string with the base64 codec is:

# Generated at 2022-06-25 16:59:34.340479
# Unit test for function register
def test_register():
    # Try to remove a codec.
    codecs.unregister(NAME)    # type: ignore

    # Assert that 'b64' is not registered.
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('b64 is registered before registering it')

    # Call the register method
    register()

    # Assert that b64 is registered after calling 'register()'
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 16:59:35.557754
# Unit test for function register
def test_register():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:59:38.821176
# Unit test for function register
def test_register():
    register()
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        assert False
    _ = codecs.getdecoder(NAME)


# Generated at 2022-06-25 16:59:47.822984
# Unit test for function encode
def test_encode():
    # Tests the example in the docstring.
    register()
    input = 'TWEsbXQtbWFyeQ=='
    # Decode the input string of base64 characters.
    decoded, _ = codecs.getdecoder('b64')(input)
    assert decoded == b'I love-mary'

    # Test error
    try:
        _, _ = codecs.getdecoder('b64')('a' * 1000000)
        assert False
    except UnicodeError:
        pass

    # Test the error of the 'text' argument being the wrong type
    try:
        _, _ = codecs.getdecoder('b64')(b'test')
        assert False
    except TypeError:
        pass



# Generated at 2022-06-25 16:59:57.747025
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    assert NAME not in codecs.__codecinfo__
    register()
    assert NAME in codecs.__codecinfo__
    assert 'b64_encode' == codecs.__codecinfo__[NAME].encode.__name__
    assert 'b64_decode' == codecs.__codecinfo__[NAME].decode.__name__



# Generated at 2022-06-25 17:00:01.880463
# Unit test for function register
def test_register():
    with pytest.raises(LookupError):
        # pylint: disable=E0602
        codecs.getdecoder(NAME)

    register()
    codecs.getdecoder(NAME)
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:00:09.341185
# Unit test for function encode
def test_encode():
    data_str = """
        d2FudW4=
    """
    # noinspection SpellCheckingInspection
    yanwen_str = """
        言文
    """
    yanwen_bytes = yanwen_str.encode('utf-8')
    yanwen_b64_str = base64.b64encode(yanwen_bytes).decode('utf-8')
    data = [
        (
            data_str,
            b'wannu'
        ),
        (
            yanwen_b64_str,
            yanwen_bytes
        )
    ]
    for (input_str, expected_bytes) in data:
        got_bytes, got_len = encode(input_str)

# Generated at 2022-06-25 17:00:14.432702
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise AssertionError('b64 codec already registered')
    except LookupError:
        pass
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Unable to get {NAME} codec: {e}')



# Generated at 2022-06-25 17:00:20.513515
# Unit test for function register
def test_register():
    """Verify that the codec registered correctly."""
    register()
    codec_info = codecs.getdecoder(NAME)
    assert codec_info is not None
    assert isinstance(codec_info, codecs.CodecInfo)
    assert isinstance(codec_info.encode, codecs.Codec)
    assert isinstance(codec_info.decode, codecs.Codec)


# Generated at 2022-06-25 17:00:26.563106
# Unit test for function encode
def test_encode():
    assert encode('Hello, World!') == (b'SGVsbG8sIFdvcmxkIQ==', 13)
    # noinspection SpellCheckingInspection
    assert encode('全世界はキミを愛してる。') == (
        b'44OG44K544OI44Op44Ki44Kv44Oq44O844K/',
        11
    )
    assert encode('Hello, World!', 'ignore') == (b'SGVsbG8sIFdvcmxkIQ==', 13)



# Generated at 2022-06-25 17:00:35.882397
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)

    assert encode('a') == (b'YQ==', 1)
    assert encode('aa') == (b'YWE=', 2)
    assert encode('aaa') == (b'YWFh', 3)
    assert encode('aaaa') == (b'YWFhYQ==', 4)
    assert encode('aaaaa') == (b'YWFhYWE=', 5)
    assert encode('aaaaaa') == (b'YWFhYWFh', 6)
    assert encode('aaaaaaa') == (b'YWFhYWFhYQ==', 7)
    assert encode('aaaaaaaa') == (b'YWFhYWFhYWE=', 8)
    assert encode('aaaaaaaaa') == (b'YWFhYWFhYWFh', 9)

# Generated at 2022-06-25 17:00:42.488453
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['_cache']
    assert NAME in codecs.__dict__['_unknown_encoding_error']



# Generated at 2022-06-25 17:00:43.511263
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:00:50.968122
# Unit test for function encode
def test_encode():
    test_case_0()
    # to base64
    # From RFC 4648
    assert encode('', errors='ignore') == (b'', 0)
    assert encode('', errors='strict') == (b'', 0)
    assert encode('f') == (b'Zg==', 1)
    assert encode('fo') == (b'Zm8=', 2)
    assert encode('foo') == (b'Zm9v', 3)
    assert encode('foob') == (b'Zm9vYg==', 4)
    assert encode('fooba') == (b'Zm9vYmE=', 5)
    assert encode('foobar') == (b'Zm9vYmFy', 6)

# Generated at 2022-06-25 17:01:07.566343
# Unit test for function encode
def test_encode():

    # Test case where input is an empty string
    assert encode('') == (b'', 0)

    # Test case where input is a single char string
    assert encode('0') == (b'MA==', 1)

    # Test case where input is a 2 char string
    assert encode('00') == (b'MDA=', 2)

    # Test case where input is a 3 char string
    assert encode('000') == (b'MDAw', 3)

    # Test case where input is a 4 char string
    assert encode('0000') == (b'MDAwMA==', 4)

    # Test case where input is a 5 char string
    assert encode('00000') == (b'MDAwMDA=', 5)

    # Test case where input is a 6 char string

# Generated at 2022-06-25 17:01:13.510742
# Unit test for function encode
def test_encode():
    # testing encode
    data = str.encode("""
    \t  text to be encoded
    \t  can span\tacross many lines
    \t
    \t  and be indented
    \t     any number of spaces
    """)
    output = base64.decodebytes(data)
    assert output == b"text to be encoded can span\tacross many lines\n\nand be indented      any number of spaces"
    print("test_encode SUCCESS")


# Generated at 2022-06-25 17:01:17.920620
# Unit test for function register
def test_register():
    import _codecs
    import codecs
    try:
        _codecs.search_function('dummy_b64')
    except LookupError:
        _codecs.register(_get_codec_info)
    assert _codecs.search_function('dummy_b64') is _get_codec_info(NAME)
    assert codecs.lookup('dummy_b64') is _get_codec_info(NAME)
    test_register.called = True


# Generated at 2022-06-25 17:01:27.087374
# Unit test for function register
def test_register():

    # Get the current values for the b64 codec.
    pre_decode = codecs.lookup(NAME).decode
    pre_encode = codecs.lookup(NAME).encode

    register()

    post_decode = codecs.lookup(NAME).decode
    post_encode = codecs.lookup(NAME).encode

    # Assert that the current encode/decode functions are now the
    # functions within this module.
    assert post_decode is decode
    assert post_encode is encode

    # Assert that encode/decode functions have been updated.
    assert post_decode is not pre_decode
    assert post_encode is not pre_encode


# Generated at 2022-06-25 17:01:27.891022
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:01:29.354149
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:01:30.187996
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:01:30.973297
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:01:34.592770
# Unit test for function register
def test_register():
    """Test :func:`register`."""
    assert NAME not in codecs.lookup()

    register()

    codec_info = codecs.lookup(NAME)[0]
    assert codec_info.name == NAME
    assert codec_info.encode('')[1] == 0
    assert codec_info.decode(b'')[1] == 0

# Generated at 2022-06-25 17:01:36.576463
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:01:58.345455
# Unit test for function encode
def test_encode():
    b64_str = (
        'SGVsbG8sIFdvcmxkIQ==\n'
        'Q2hpY2FnbywgV29ybGQh'
    )
    assert b64_str.encode(NAME).decode('utf-8') == b64_str
    assert b64_str.encode(NAME).decode(NAME).encode(NAME) == b64_str.encode(NAME)


# Generated at 2022-06-25 17:02:02.616204
# Unit test for function register
def test_register():
    assert not hasattr(codecs, 'b64_decode')
    assert not hasattr(codecs, 'b64_encode')
    register()
    assert hasattr(codecs, 'b64_decode')
    assert hasattr(codecs, 'b64_encode')



# Generated at 2022-06-25 17:02:05.413266
# Unit test for function register
def test_register():
    assert callable(register)


# noinspection PyUnresolvedReferences

# Generated at 2022-06-25 17:02:14.965783
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 17:02:26.577260
# Unit test for function encode
def test_encode():
    register()

# Generated at 2022-06-25 17:02:32.188585
# Unit test for function encode
def test_encode():
    assert encode(b'aGVsbG8h') == (b'hello!', 0)
    assert encode(b'fdsa') == (b'fdsa', 0)
    assert encode(b'Zm9vYmFy') == (b'foobar', 0)

    invalid_string = b"\xed\x99\xac\xec\x9d\xb4\xeb\xa0\xa8"  # 학쟁차
    try:
        encode(b'Zm9vYmFy')
    except UnicodeEncodeError:
        pass
    else:
        assert False, f'{invalid_string} is not a proper base64 character'



# Generated at 2022-06-25 17:02:37.558484
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:02:40.707280
# Unit test for function register
def test_register():
    register()
    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)



# Generated at 2022-06-25 17:02:46.963964
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None
    else:
        codecs.unregister(NAME)
        register()
        assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:02:49.285696
# Unit test for function encode
def test_encode():
    register()
    data = encode("hello world")
    assert data == (b'aGVsbG8gd29ybGQ=', 11)


# Generated at 2022-06-25 17:03:24.063863
# Unit test for function register
def test_register():
    import sys
    import os
    import base64
    original_stdin = sys.stdin
    original_stdout = sys.stdout

# Generated at 2022-06-25 17:03:26.548035
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-25 17:03:27.205489
# Unit test for function register
def test_register():
    from base64_codec import register
    register()



# Generated at 2022-06-25 17:03:28.195824
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:03:30.257889
# Unit test for function register
def test_register():
    register()
    # Test that the name is registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:03:37.998404
# Unit test for function register
def test_register():
    register()
    obj = codecs.getencoder(NAME)
    assert NAME == obj[0]
    out_bytes, out_len = obj[1]('')
    assert 0 == out_len
    assert b'' == out_bytes
    out_bytes, out_len = obj[1]('AA==')
    assert 4 == out_len
    assert b'\x00' == out_bytes

    obj = codecs.getdecoder(NAME)
    assert NAME == obj[0]
    out_str, out_len = obj[1](b'')
    assert 0 == out_len
    assert '' == out_str
    out_str, out_len = obj[1](b'AA==')
    assert 4 == out_len
    assert '\x00' == out_str

    obj = codecs.get

# Generated at 2022-06-25 17:03:43.785985
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f'Codec {NAME!r} was not registered (See function '
                    f'codecs.register).')



# Generated at 2022-06-25 17:03:45.535871
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-25 17:03:53.953655
# Unit test for function register
def test_register():
    register()
    get_decoder = codecs.getdecoder(NAME)
    decoder = get_decoder('strict')
    out_str, len_str = decoder(str_input)
    out_bytes, len_bytes = decoder(bytes_input)
    assert out_str == out_bytes
    assert len(str_input) == len_str
    assert len(bytes_input) == len_bytes
    get_encoder = codecs.getencoder(NAME)
    encoder = get_encoder('strict')
    out_bytes = encoder(str_input)
    assert out_bytes[0] == bytes_input
    assert len(out_bytes[0]) == len(str_input)

# Strings used for unit testing.

# Generated at 2022-06-25 17:03:58.880975
# Unit test for function register
def test_register():
    assert_raises(
        LookupError,
        lambda: codecs.getdecoder('b64')
    )

    register()

    # Successful registration.
    assert_is_instance(
        codecs.getdecoder('b64'),
        codecs.CodecInfo
    )

    # Already registered, no exception is raised.
    assert_nothing_raised(
        lambda: register()
    )



# Generated at 2022-06-25 17:04:52.610211
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise Exception(
            'The codec {!r} has already been registered'.format(NAME)
        )
    except LookupError:
        # The codec 'b64' has not been registered.
        assert True
    register()



# Generated at 2022-06-25 17:04:58.747010
# Unit test for function encode
def test_encode():
    register()
    input_string = "TmF0aXZlIHRvIHRoZSBtYXJrZXQgYW5kIGZ1bGx5IHN1cHBvcnRlZCBieSBHb29nbGU=\n"
    output = encode(input_string)
    assert output[0].decode("utf-8") == "Native to the market and fully supported by Google\n"

# Generated at 2022-06-25 17:05:00.099706
# Unit test for function register
def test_register():

    return None



# Generated at 2022-06-25 17:05:04.538044
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencoders()
    assert NAME in codecs.getdecoders()



# Generated at 2022-06-25 17:05:06.129835
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:05:07.248477
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-25 17:05:11.163116
# Unit test for function register
def test_register():
    # Make sure unit test works.
    register()
    # Make sure it's registered.
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:05:15.222931
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:05:24.859982
# Unit test for function register
def test_register():

    # Capture the stderr for any Error logging message that occurs.
    err_str = io.StringIO()  # type: io.StringIO
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler(err_str))

    #  Test that 'b64' is not a registered codec
    assert not any(map(lambda x: x == NAME, codecs.__all__))

    # Register the codec.
    register()
    assert err_str.getvalue() == ''

    #  Test that 'b64' is a now registered codecs.
    assert any(map(lambda x: x == NAME, codecs.__all__))



# Generated at 2022-06-25 17:05:25.698134
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:07:17.828794
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencoders()
    assert NAME in codecs.getdecoders()


# Generated at 2022-06-25 17:07:19.897679
# Unit test for function register
def test_register():
    """Make sure that the 'b64' codec is registered"""
    register()
    assert 'b64' in codecs.__all__



# Generated at 2022-06-25 17:07:24.158167
# Unit test for function register
def test_register():
    assert NAME not in codecs.getdecoder('name')
    register()
    assert NAME in codecs.getdecoder('name')



# Generated at 2022-06-25 17:07:29.215344
# Unit test for function register
def test_register():
    # When:

    # Then:
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('register() has failed.')

    return



# Generated at 2022-06-25 17:07:36.145036
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert True
    else:
        assert False
    register()
    get_decoder = codecs.getdecoder(NAME)
    assert get_decoder is not None
    assert get_decoder[0] == decode
    assert get_decoder[1] == encode


# Unit test of function test_case_0

# Generated at 2022-06-25 17:07:39.220307
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

test_case_0()
# test_register()

# Generated at 2022-06-25 17:07:39.935534
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:07:40.635051
# Unit test for function register
def test_register():
    capture_stdout(test_case_0)

# Generated at 2022-06-25 17:07:41.821024
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:07:53.152480
# Unit test for function encode
def test_encode():
    """Unit test for encode."""
    text = '''
        RG91Z2VudSBJc3N1aW5nIFRFPQ==
        RG91Z2VudSBGdXJ0aGVyIElzc3VpbmcgVEU=
        RG91Z2VudSBFbmNyeXB0ZWQgVEU=
        RG91Z2VudSBNdWFwIElzc3VpbmcgVEU=
        RG91Z2VudSBDL3BtIElzc3VpbmcgVEU=
        RG91Z2VudSBTdW1tYXJ5IFRFPQ==
    '''
    txt_bytes, _ = encode(text)