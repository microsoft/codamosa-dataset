

# Generated at 2022-06-25 16:58:40.820549
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 16:58:47.344202
# Unit test for function register

# Generated at 2022-06-25 16:58:48.747051
# Unit test for function encode
def test_encode():
    # Call function encode
    test_case_1()


# Generated at 2022-06-25 16:58:54.413482
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    actual_obj = codecs.getdecoder(NAME)
    expected_obj = codecs.CodecInfo(
        name=NAME,
        decode=decode,
        encode=encode
    )
    assert actual_obj == expected_obj



# Generated at 2022-06-25 16:58:56.134330
# Unit test for function register
def test_register():
    test_case_0()
    return


# Generated at 2022-06-25 16:59:00.556490
# Unit test for function encode
def test_encode():
    print("Testing encode")
    assert encode("AQIDBAUGBwgJCgsMDQ4PEA==") == (b'\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f', 24)



# Generated at 2022-06-25 16:59:05.278516
# Unit test for function register
def test_register():
    """Test case: Registering the codec with Python."""
    test_case_0()

# Generated at 2022-06-25 16:59:08.502781
# Unit test for function register
def test_register():
    # Test 1: Register the 'b64'
    # codec with the codec registry.
    obj = _get_codec_info(NAME)
    assert codecs.CodecInfo == type(obj)



# Generated at 2022-06-25 16:59:10.602462
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 16:59:19.966616
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        raise codecs.LookupError(f'{NAME!r} encoder is already registered')
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise codecs.LookupError(f'{NAME!r} decoder is already registered')

    register()

    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError(
            f'{NAME!r} encoder is not registered after register() call'
        )

# Generated at 2022-06-25 16:59:26.381572
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getdecoder("b64")



# Generated at 2022-06-25 16:59:27.259019
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 16:59:37.145293
# Unit test for function encode
def test_encode():
    assert encode(
        'YXNkYWZmYWthZGFmZg=='
    )[0] == b'asdfafkadaff'
    assert encode(
        'asdfafkadaff'
    )[0] == b'YXNkYWZmYWthZGFmZg=='
    assert encode(
        'YXNkYWZmYWthZGFmZg=='
    )[0] == encode(
        'asdfafkadaff'
    )[0]

# Generated at 2022-06-25 16:59:44.176198
# Unit test for function register
def test_register():
    # The codec should not yet be registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, (
            'The codec should not be registered before calling register()')

    # Call register().
    register()

    # The codec should now be registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, (
            'Register failed to register the b64 codec.')


# Generated at 2022-06-25 16:59:44.733155
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 16:59:46.880541
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    codecs.getdecoder(NAME)


# Unit Test for function decode.

# Generated at 2022-06-25 16:59:49.516996
# Unit test for function register
def test_register():
    assert NAME in codecs.getencoder(NAME)  # type: ignore
    assert NAME in codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-25 16:59:50.579108
# Unit test for function encode
def test_encode():
    test_case_0()

# Unit Test Function for decode

# Generated at 2022-06-25 16:59:52.849070
# Unit test for function register
def test_register():
    register()
    # codec, _ = codecs.lookup(NAME)
    # assert codec is not None


# Unit test b64.decode

# Generated at 2022-06-25 17:00:00.325706
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'register() failed to register the codec'
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'register() failed to register the codec'
    try:
        codecs.getreader(NAME)
    except LookupError:
        assert False, 'register() failed to register the codec'
    try:
        codecs.getwriter(NAME)
    except LookupError:
        assert False, 'register() failed to register the codec'


# Generated at 2022-06-25 17:00:06.537420
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:00:08.866204
# Unit test for function encode
def test_encode():
    assert encode("TmljaG9sIGNoZWxsaW4gY2huc2h0YQ\n==")



# Generated at 2022-06-25 17:00:16.994818
# Unit test for function encode

# Generated at 2022-06-25 17:00:18.795811
# Unit test for function register
def test_register():
    try:
        register()
        assert True
    except:
        assert False


# Generated at 2022-06-25 17:00:19.662147
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:00:25.353052
# Unit test for function encode
def test_encode():
    text = str.encode(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")
    errors = 'strict'
    assert encode(text, errors) == (
        b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        64)

# Generated at 2022-06-25 17:00:27.787328
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:00:32.200885
# Unit test for function register
def test_register():
    from codecs import lookup   # pylint: disable=import-outside-toplevel

    # Register the b64 codec with Python.
    register()

    # Verify that the b64 codec was registered.
    codec_info = lookup(NAME)
    assert codec_info.name == NAME



# Generated at 2022-06-25 17:00:36.096718
# Unit test for function register
def test_register():
    # pylint: disable=wildcard-import
    # pylint: disable=unused-wildcard-import
    from codecs import *   # noqa: F401, F403
    from . import *        # noqa: F401, F403
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f'Cannot find {NAME!r} codec.')



# Generated at 2022-06-25 17:00:42.564547
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('a') == (b'YQ==\n', 3)
    assert encode('ab') == (b'YWI=\n', 4)
    assert encode('abc') == (b'YWJj\n', 4)
    assert encode('abcd') == (b'YWJjZA==\n', 7)
    assert encode('abcde') == (b'YWJjZGU=\n', 7)
    assert encode('abcdef') == (b'YWJjZGVm\n', 7)
    assert encode('abcdefg') == (b'YWJjZGVmZw==\n', 10)

# Generated at 2022-06-25 17:00:46.368310
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:00:48.092443
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:00:49.395577
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:00:56.816777
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Check that the 'b64' codec does not exist.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'codec {NAME!r} is already registered')

    # Call the function to be tested.
    register()

    # Check that the 'b64' codec exist.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'codec {NAME!r} is not registered')



# Generated at 2022-06-25 17:00:58.321109
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:01:00.011413
# Unit test for function register
def test_register():
    register()

    codecs.getdecoder(NAME)

    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:01:09.160475
# Unit test for function register
def test_register():
    """Ensure that the ``register`` function is called."""
    # noinspection PyProtectedMember
    with mock.patch(
            target='pyconf.b64._get_codec_info',
            new=_get_codec_info
    ) as mock_get_codec_info:
        with mock.patch(
                target='pyconf.b64.codecs.register',
                new=codecs.register
        ) as mock_register:
            register()
            mock_get_codec_info.assert_called_once_with(NAME)
            mock_register.assert_called_once_with(mock_get_codec_info.return_value)


if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:01:12.841701
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None
    codecs.getencoder(NAME)
    encoder = codecs.getencoder(NAME)
    assert encoder is not None



# Generated at 2022-06-25 17:01:13.970833
# Unit test for function register
def test_register():
    assert(test_case_0() is None)


# Generated at 2022-06-25 17:01:14.366220
# Unit test for function register
def test_register():
    assert True

# Generated at 2022-06-25 17:01:18.983425
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


# Generated at 2022-06-25 17:01:20.271741
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:01:26.153096
# Unit test for function register
def test_register():
    import sys
    assert NAME not in sys.modules

    # noinspection PyProtectedMember
    assert NAME not in codecs.__all__
    assert NAME not in codecs._cache
    assert NAME not in codecs._registry

    register()

    # noinspection PyProtectedMember
    assert NAME in codecs.__all__
    assert NAME in codecs._cache
    assert NAME in codecs._registry



# Generated at 2022-06-25 17:01:34.191192
# Unit test for function register

# Generated at 2022-06-25 17:01:35.559497
# Unit test for function register
def test_register():
    for func in [test_case_0]:
        func()



# Generated at 2022-06-25 17:01:36.426019
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:01:48.605854
# Unit test for function encode
def test_encode():
    register()
    # Test case 0
    encoded_bytes = "b=sfw(n~f-@r8p*d1h$a7g9cm&'z56ei3vxu0k-w\n"
    decoded_bytes = encode(encoded_bytes)
    assert decoded_bytes == (b'ab\n123\n', 11)

    # Test case 1
    encoded_bytes = "YQ==\n"
    decoded_bytes = encode(encoded_bytes)
    assert decoded_bytes == (b'a\n', 4)

    # Test case 2
    encoded_bytes = "YWI=\n"
    decoded_bytes = encode(encoded_bytes)
    assert decoded_bytes == (b'ab\n', 4)

    # Test case 3
    encoded_

# Generated at 2022-06-25 17:01:55.918358
# Unit test for function register
def test_register():
    try:
        decoder = codecs.getdecoder(NAME)
        assert decoder[0] is decode
    except LookupError:
        pytest.fail("Unable to find encoder")

    try:
        encoder = codecs.getencoder(NAME)
        assert encoder[0] is encode
    except LookupError:
        pytest.fail("Unable to find decoder")



# Generated at 2022-06-25 17:02:07.573872
# Unit test for function encode
def test_encode():
    register()
    # Test a valid base64 string
    assert encode(
        'e3kyMQ=='
    ) == (b'ok12', 6)
    # Test a string with no equal signs
    assert encode(
        'e3kyMQ'
    ) == (b'ok12', 5)
    # Test a string with extra equal signs
    assert encode(
        'e3kyMQ==='
    ) == (b'ok12', 6)
    # Test a string with extra equal signs
    assert encode(
        'e3kyMQ==='
    ) == (b'ok12', 6)
    # Test a string with extra equal signs
    assert encode(
        'e3kyMQ==='
    ) == (b'ok12', 6)
    # Test a string with extra equal signs

# Generated at 2022-06-25 17:02:08.484668
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:02:16.501196
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    else:
        raise AssertionError


# Generated at 2022-06-25 17:02:22.197369
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:02:28.931083
# Unit test for function register
def test_register():
    # Test the function register()
    register()

    # Get the codecs information and verify it is as expected.
    codecs_info = codecs.lookup(NAME)
    # noinspection PyTypeChecker
    assert codecs_info.encode('') == (b'', 0)
    assert codecs_info.decode(b'') == ('', 0)



# Generated at 2022-06-25 17:02:30.342727
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-25 17:02:31.814143
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:02:33.048674
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:02:39.567883
# Unit test for function encode
def test_encode():
    register()
    test_line = b"VGhpcyBpcyB0ZXN0IGJhc2U2NCBkYXRh"
    test_result = b"This is test base64 data"
    assert test_line == base64.b64encode(test_result)


# Generated at 2022-06-25 17:02:44.419540
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        assert codecs.getdecoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:02:50.241731
# Unit test for function register
def test_register():
    f = globals()['test_case_0']
    # noinspection PyProtectedMember
    g = f.__code__.co_firstlineno
    # noinspection PyProtectedMember
    code = codecs.decode(f.__code__.co_code, 'utf-8')
    assert code.startswith('def test_case_0():\n')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:02:52.381306
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.codecs.keys()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-25 17:03:19.709744
# Unit test for function encode
def test_encode():
    """Test function encode"""
    # Test 0

# Generated at 2022-06-25 17:03:20.677798
# Unit test for function register
def test_register():
    assert test_case_0() is None

# Generated at 2022-06-25 17:03:32.826023
# Unit test for function register
def test_register():
    import b64  # type: ignore
    import codecs  # type: ignore
    import sys  # type: ignore
    import pathlib  # type: ignore

    # Define text that is to be encoded.
    text = '\n'.join(
        [
            'Hello',
            'World',
            'This is a test',
            '    of the emergency broadcasting system',
        ]
    )

    # Verify that 'b64' is not already registered in the encodings tables.
    try:
        codecs.getdecoder('b64')
    except LookupError:
        pass
    except Exception as e:
        raise e
    else:
        raise RuntimeError(
            'The "b64" codec is already registered with Python.'
        )

    #  Check that b64 is not present in sys.path
   

# Generated at 2022-06-25 17:03:43.858316
# Unit test for function register
def test_register():
    from b64.codec import NAME
    from b64.codec import _get_codec_info

    obj = _get_codec_info(NAME)
    assert obj is not None

    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None

    obj = codecs.getencoder(NAME)
    assert obj is not None

    # If this test raises a UnicodeError, then the test has failed.
    try:
        encoded_text, length_consumed = encode('')
    except UnicodeEncodeError:
        assert False

    assert isinstance(encoded_text, bytes)
    assert encoded_text == b''
    assert length_consumed == 0

    encoded_text, length_consumed = encode('3q2+7w==')

# Generated at 2022-06-25 17:03:48.083680
# Unit test for function register
def test_register():
    register()
    assert 'b64' in [codec.name for codec in iter(codecs.getdecoder('b64'))]
    assert 'b64' in [codec.name for codec in iter(codecs.getencoder('b64'))]



# Generated at 2022-06-25 17:03:52.101897
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:03:53.918360
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:03:56.474046
# Unit test for function register
def test_register():
    """Test :func:`~register`"""
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert NAME == obj.name



# Generated at 2022-06-25 17:03:58.095052
# Unit test for function register
def test_register():
    register()

    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:04:07.434126
# Unit test for function register
def test_register():
    # Run the 'register' function
    register()

    # Examine the codecs to see if the 'b64' codec is present.
    codec_names = [x.name for x in codecs.getdecoders()]

    # The unit test fails if the 'b64' codec is not present in the codecs
    if NAME not in codec_names:
        raise RuntimeError(
            f'The "{NAME}" codec has not been registered.'
        )


if __name__ == '__main__':
    # Run the unit test for the 'register' function.  The outcome of the
    # test is displayed in the console.
    test_case_0()
    test_register()

# Generated at 2022-06-25 17:04:47.878928
# Unit test for function register
def test_register():
    """Test registration of the codec"""
    # Unregister the codec if it is registered
    codecs.lookup(NAME)
    # Ensure the codec really got unregistered
    # noinspection PyBroadException
    try:
        # noinspection PyUnresolvedReferences
        codecs.lookup(NAME)
    except LookupError:
        pass
    # Register the codec
    register()
    # Ensure the codec registry got updated
    codecs.lookup(NAME)
    # noinspection PyUnresolvedReferences
    codecs.lookup(NAME)



# Generated at 2022-06-25 17:05:00.455404
# Unit test for function register
def test_register():
    # pylint: disable=unused-variable
    from unicodedata import normalize, name

    register()
    test_text_list = [
        '',
        'Twilight Sparkle',
        'Twilight  Sparkle',
        'Twilight\nSparkle',
        'Twilight \nSparkle',
        'Twilight   \nSparkle',
        'Twilight   \n Sparkle',
        'Twilight   \n  Sparkle',
        'Twilight   \n   \n   \n   \n   \n   \n   \n   \n   \n   \n   \n   '
        'Sparkle'
    ]
    for text in test_text_list:
        text_encoded = text.encode(NAME)
        text_decoded = text_encoded.decode

# Generated at 2022-06-25 17:05:03.830139
# Unit test for function register
def test_register():
    assert callable(register)



# Generated at 2022-06-25 17:05:14.484474
# Unit test for function register
def test_register():
    register()
    expected = b'Hello World!\n'
    string = 'SGVsbG8gV29ybGQhCg=='
    decoded, _ = decode(string)
    assert decoded == string
    decoded, _ = codecs.decode(string, 'b64')
    assert decoded == expected
    string = 'SGVsbG8gV29ybGQhCg'
    decoded, _ = decode(string)
    assert decoded == string
    decoded, _ = codecs.decode(string, 'b64')
    assert decoded == expected
    string = 'SGVsbG8gV29ybGQhCg='
    decoded, _ = decode(string)
    assert decoded == string

# Generated at 2022-06-25 17:05:18.917259
# Unit test for function register
def test_register():
    register()
    with pytest.raises(LookupError):
        codecs.getencoder(NAME)
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:05:20.756827
# Unit test for function register
def test_register():
    register()  # no error

# Generated at 2022-06-25 17:05:23.081862
# Unit test for function register
def test_register():
    # Call the testing function
    test_case_0()

# Generated at 2022-06-25 17:05:24.763371
# Unit test for function register
def test_register():
    # Get the codec information
    codec_info = codecs.lookup(NAME)
    assert codec_info


# Generated at 2022-06-25 17:05:30.484121
# Unit test for function register
def test_register():
    """Test registering the b64 with Python."""
    # pylint: disable=protected-access
    from string import printable
    from binascii import a2b_base64, b2a_base64
    from textwrap import dedent
    from random import sample

    # Generate random bytes and string.
    random_bytes = bytes(sample(range(0xff), 9))
    random_str = random_bytes.decode('utf-8')

    # Test the the codecs are loaded.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception((
            f'The codec {NAME!r} is not register with Python.'
        ))

    # Test the the codecs are loaded.

# Generated at 2022-06-25 17:05:35.433421
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:06:36.599912
# Unit test for function register
def test_register():
    print('\ntest_register')
    register()



# Generated at 2022-06-25 17:06:41.601592
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    obj = codecs.lookup(NAME)
    assert obj is not None
    assert obj.name == NAME
    assert obj.encode('') == ('', 0)
    assert obj.encode(b'') == ('')


# Generated at 2022-06-25 17:06:42.591677
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:06:44.077283
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:06:47.278882
# Unit test for function register
def test_register():
    register()
    # This assertion will fail if the 'b64' codec is not registered.
    assert codecs.lookup(NAME) is not None


# pylint: disable=too-many-statements
# pylint: disable=too-many-branches
# pylint: disable=too-many-locals
# pylint: disable=too-many-return-statements

# Generated at 2022-06-25 17:06:48.530447
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-25 17:06:57.537084
# Unit test for function encode
def test_encode():
    register()

    # Test Case 0:
    actual = encode('TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2\nNpbmcgZWxpdC4gRHVpcyBzZWQgaXBzdW0gdmVsIGFsaXF1aXAgZXQgbGliZXJvLg==')
    assert actual[0] == b'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed ipsum vel aliquip et libero.'
    assert actual[1] == 121

    # Test Case 1:

# Generated at 2022-06-25 17:07:03.172703
# Unit test for function register
def test_register():
    assert test_case_0() is None, "Test case 0 Failed"
# print(f"Registered {NAME} as {codecs.getencoder(NAME)}")

# Generated at 2022-06-25 17:07:06.900258
# Unit test for function register
def test_register():
    """Test the register function."""
    register()

    # Assert only one 'b64' codec exists.
    b64_codec_info = codecs.getdecoder(NAME)  # type: ignore
    assert codecs.lookup(NAME) == b64_codec_info



# Generated at 2022-06-25 17:07:14.822808
# Unit test for function encode
def test_encode():
    register()

    assert encode('') == (b'', 0)
    assert encode('abcdef') == (b'YWJjZGVm', 7)
    assert encode('abcd\nef') == (b'YWJjZGVm', 7)
    assert encode('abcd\n\nef') == (b'YWJjZGVm', 7)
    assert encode('abcd\n  \nef') == (b'YWJjZGVm', 7)
    assert encode('abcd\n    \nef  ') == (b'YWJjZGVm', 7)

