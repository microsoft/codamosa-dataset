

# Generated at 2022-06-21 12:22:42.925196
# Unit test for function decode
def test_decode():  # noqa: D102
    assert decode(b"") == ('', 0)
    assert decode(b"d") == ('cA==\n', 1)
    assert decode(b"da") == ('cGE=\n', 2)
    assert decode(b"dG") == ('dGg=\n', 2)
    assert decode(b"dGV") == ('dGVzdA==\n', 4)
    assert decode(b"dGVz") == ('dGVzdDE=\n', 5)
    assert decode(b"dGVzdA") == ('dGVzdDEy\n', 6)
    assert decode(b"dGVzdDE") == ('dGVzdDEyMw==\n', 8)

# Generated at 2022-06-21 12:22:47.170876
# Unit test for function decode
def test_decode():
    input_byte_data = b'hello world'
    byte_data = codecs.decode(input_byte_data, 'b64')  # type: ignore
    assert byte_data == 'aGVsbG8gd29ybGQ='


# Generated at 2022-06-21 12:22:54.435955
# Unit test for function register
def test_register():
    from functools import partial
    from typing import Callable
    from codecs import lookup, getdecoder, getencoder

    register()
    assert lookup(NAME) is not None

    get_decoder: Callable[..., Any] = partial(getdecoder, NAME)
    assert get_decoder is None
    assert get_decoder()[0] is not None


    get_encoder: Callable[..., Any] = partial(getencoder, NAME)
    assert get_encoder is None
    assert get_encoder()[0] is not None



# Generated at 2022-06-21 12:23:00.728619
# Unit test for function encode
def test_encode():
    input_string = "Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure."
    output_string = codecs.encode(input_string, 'b64')

# Generated at 2022-06-21 12:23:07.858491
# Unit test for function register
def test_register():
    """Test that the "b64" codec is registered."""
    from types import ModuleType
    codecs.register(_get_codec_info)  # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert "lookup {!r} on {!r}".format(NAME, ModuleType.__name__) in str(e)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:23:11.456742
# Unit test for function decode
def test_decode():
    # type: () -> None
    """Unit test for function decode"""

    assert codecs.decode(
        codecs.encode(
            b'hello world in utf8 bytes', 'utf-8'
        ),
        'b64'
    ) == 'aGVsbG8gd29ybGQgaW4gdXRmOCBieXRlcw=='



# Generated at 2022-06-21 12:23:16.284611
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    info = codecs.lookup(NAME)
    assert NAME == info.name
    assert decode == info.decode
    assert encode == info.encode
test_register()


# Generated at 2022-06-21 12:23:23.838116
# Unit test for function encode
def test_encode():
    """Test encoding strings"""
    
    string = "Hello World"
    expected = b'SGVsbG8gV29ybGQ='
    assert encode(string)[0] == expected
    
    string = "Hello World!"
    expected = b'SGVsbG8gV29ybGQh'
    assert encode(string)[0] == expected
    
    string = "Hello World. How are you?"
    expected = b'SGVsbG8gV29ybGQuIEhvdyBhcmUgeW91Pw=='
    assert encode(string)[0] == expected

    string = "Hello World. How are you? My name is John!"

# Generated at 2022-06-21 12:23:27.265741
# Unit test for function register
def test_register():
    """Test the function register()"""
    import codecs
    assert not codecs.lookup('b64')
    register()
    assert codecs.lookup('b64')

# Generated at 2022-06-21 12:23:28.451477
# Unit test for function register
def test_register():
    """This function can be used to test the function register."""
    register()

# Generated at 2022-06-21 12:23:38.600657
# Unit test for function decode
def test_decode():
    # Test error condition.

    # Test simple text
    text = '\n' * 10 + dedent(r'''
    abcdefghijklmnopqrstuvwxyz
    ABCDEFGHIJKLMNOPQRSTUVWXYZ
    0123456789
    +/
    ''').strip()

    result, _ = decode(text, 'strict')
    assert (
        result == (  # type: ignore
            'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXpBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZ\n'
            'WjAxMjM0NTY3ODkrLw=='
        )
    )

    # Test leading and

# Generated at 2022-06-21 12:23:42.735796
# Unit test for function encode
def test_encode():
    assert encode(b'some bytes')[0] == b'c29tZSBieXRlcw=='\
        b'\n'
    assert encode(b'some bytes')[0] != b'c29tZSBieXRlcw=='



# Generated at 2022-06-21 12:23:47.750336
# Unit test for function encode
def test_encode():   # pragma: no branch
    """Unit test for function encode"""
    text = (
        "SGVsbG8gV29ybGQh\n"
        "VGhpcyBpcyBhIHRlc3QgYmFzZTY0IGVuY29kaW5nLiBXb3JsZCE="
    )
    out, _len = encode(text)
    assert out == b"Hello World!\n" \
                   b"This is a test base64 encoding. World!"


# Generated at 2022-06-21 12:23:52.377198
# Unit test for function decode
def test_decode():
    # Decode the bytes: b'\x01\x02\x03' as a base64 characters string
    # and verify the returned output.
    test_data: bytes = b'\x01\x02\x03'
    expect: str = 'AQID'
    out, _ = decode(test_data)
    assert out == expect

    # Decode the bytes: b' ' as a base64 characters string and verify
    # the returned output.
    test_data = b' '
    expect = 'IA=='
    out, _ = decode(test_data)
    assert out == expect

    # Decode the bytes: b' ' as a base64 characters string and verify
    # the returned output.
    test_data = b' '
    expect = 'IA=='
    out, _ = decode(test_data)

# Generated at 2022-06-21 12:23:54.606598
# Unit test for function register
def test_register():
    """Unit test for the function ``register``."""
    assert callable(decode)
    assert callable(encode)
    # Register the codec
    register()

    # Get the codec
    assert NAME == codecs.getdecoder(NAME).name

# Generated at 2022-06-21 12:24:02.128752
# Unit test for function register
def test_register():
    """Verify the ``b64`` codec is not currently registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
    else:
        raise LookupError('b64')
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        raise LookupError('b64')


# Generated at 2022-06-21 12:24:05.353734
# Unit test for function register
def test_register():
    # pylint: disable=W0212
    try:
        codecs.codecs_map.pop(NAME)
    except KeyError:
        pass

    assert NAME not in codecs.codecs_map
    register()
    assert NAME in codecs.codecs_map

# Generated at 2022-06-21 12:24:13.774590
# Unit test for function decode
def test_decode():
    """Unit test for ``decode()``"""
    # pylint: disable=C0301, R0914

# Generated at 2022-06-21 12:24:22.380040
# Unit test for function decode
def test_decode():
    """Test that function decode() converts correctly."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

    assert encode(
        'Ty9cX1FWT1VXT0tQQw=='
    ) == codecs.decode('Ty9cX1FWT1VXT0tQQw==', 'b64')

    assert encode(
        'Ty9cX1FWT1VXT0tQQw'
    ) == codecs.decode('Ty9cX1FWT1VXT0tQQw', 'b64')


# Generated at 2022-06-21 12:24:27.515352
# Unit test for function encode

# Generated at 2022-06-21 12:24:38.246523
# Unit test for function decode
def test_decode():
    # pylint: disable=protected-access
    assert 'i am a string' == decode('aSBhbSBhIHN0cmluZw==')[0]
    assert 'i am a string' == decode('aSBhbSBhIHN0cmluZw==\n')[0]
    assert 'i am a string' == decode('aSBhbSBhIHN0cmluZw==\r\n')[0]
    assert 'i am a string' == decode('aSBhbSBhIHN0cmluZw=\n=\n')[0]
    assert 'i am a string' == decode('aSBhbSBhIHN0cmluZ\n=\nw==\n')[0]

# Generated at 2022-06-21 12:24:49.900692
# Unit test for function decode
def test_decode():
    from os import path

    from chardet.universaldetector import UniversalDetector

    _PATH = path.dirname(path.abspath(__file__))
    _PATH = path.join(_PATH, "test_data")

    test_cases = [
        (
            path.join(_PATH, "unicode-test-case2.b64"),
            '{test_file}'
        )
    ]

    detector = UniversalDetector()

    for b64_file, exp_file in test_cases:
        with open(b64_file, 'rb') as b64_fobj:
            b64_bytes = b64_fobj.read()

        exp_bytes = b64_bytes

        # Substitute {test_file} with the b64_file.
        exp_bytes = exp_bytes.dec

# Generated at 2022-06-21 12:24:53.090462
# Unit test for function decode
def test_decode():
    a = "sdfsdfsdfsdfsdfsdfsfd"
    b, c = decode(a)

    assert b == "c2Rmc2Rmc2Rmc2Rmc2Rmc2Zk"



# Generated at 2022-06-21 12:24:59.249954
# Unit test for function encode
def test_encode():
    # Arrange
    text = 'CgFKCIsEKQojPBJmYnBgYgBQYCoQQBQYGCJEDQUJkDxMCZg8WZgYEEwAFCA=='

    # Act
    text_bytes, length = codecs.encode(text, NAME)

    # Assert
    assert length == len(text)
    assert isinstance(text_bytes, bytes)
    assert text_bytes.decode('utf-8') == text

# Generated at 2022-06-21 12:25:01.339893
# Unit test for function decode
def test_decode():
    assert decode(b'c3B4d3M=') == ('spxw3S', 8)


# Generated at 2022-06-21 12:25:06.694778
# Unit test for function encode
def test_encode():
    assert encode('Zm9v') == b'foo'
    assert encode('Zm9vYg') == b'foob'
    assert encode('Zm9vYmE') == b'fooba'
    assert encode('Zm9vYmFy') == b'foobar'



# Generated at 2022-06-21 12:25:11.428847
# Unit test for function register
def test_register():
    # Call the codecs.register() function
    register()

    # Try to get the codec from 'codecs'
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Unable to register codec'


# Unit tests for function decode

# Generated at 2022-06-21 12:25:14.288184
# Unit test for function decode
def test_decode():
    in_str = str('abcdefgabc12345!')
    exp_str = str('YWJjZGVmZ2FiYzEyMzQ1IQ==')
    out_str = str(decode(in_str))
    assert out_str == exp_str


# Generated at 2022-06-21 12:25:23.954504
# Unit test for function register
def test_register():         # pragma: no cover
    import sys
    from io import (
        BytesIO,
        TextIOWrapper,
    )

    register()
    # noinspection SpellCheckingInspection
    csv_str_input = """
    aW1hZ2Ugc3R1ZGVudCBvbmU=
    aW1hZ2Ugc3R1ZGVudCB0d28=
    aW1hZ2Ugc3R1ZGVudCB0aHJlZQ==
    """
    buff = BytesIO()
    out_file = TextIOWrapper(buff, encoding=NAME)
    out_file.write(csv_str_input)
    out_file.close()
    bin_data = buff.getvalue()

    # noinspection SpellCheckingInspection


# Generated at 2022-06-21 12:25:28.485775
# Unit test for function encode

# Generated at 2022-06-21 12:25:40.926792
# Unit test for function encode
def test_encode():
    # Testing for some strings that can be properly encoded
    assert encode('xg') == (b'eA==', 2)
    assert encode('xg') == encode(' x\ng ')
    assert encode('') == (b'', 0)
    assert encode('1234') == (b'MTIzNA==', 4)
    assert encode('12345') == (b'MTIzNDU=', 5)
    assert encode('123456') == (b'MTIzNDU2', 6)
    # Testing for some strings that are not properly encoded
    try:
        encode('abg')
    except UnicodeEncodeError:
        # If the string is not properly encoded, the UnicodeEncodeError will
        # be raised.
        pass

# Generated at 2022-06-21 12:25:52.306500
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``.
    """
    # Test string
    test_str: _STR = (  # noqa
        "F\n"
        "b4AREwgATgBAAkCABMAEwAACgADAAYAEQAQABcAEgAaABMAEwAACgADAAUAEQAQABcA"
        "EgAaABMAEwAACgADAAYAEQAQABcAEgAaABIAEgAaABIAEgAaABIAEgAaABIAEgAaABIA"
        "EgAa"
    )

    # Define the expected values

# Generated at 2022-06-21 12:26:04.013852
# Unit test for function decode
def test_decode():
    assert decode(b'A') == ('QQ==', 1)
    assert decode(b'AB') == ('QUI=', 2)
    assert decode(b'ABC') == ('QUJD', 3)

    assert decode(b'\xfb') == ('/w==', 1)
    assert decode(b'\xfb\xbf') == ('//8=', 2)
    assert decode(b'\xfc\xbf\xff') == ('//8A', 3)

    assert decode(b'a') == ('YQ==', 1)
    assert decode(b'ab') == ('YWI=', 2)
    assert decode(b'abc') == ('YWJj', 3)

    assert decode(b'\xfb') == ('/w==', 1)

# Generated at 2022-06-21 12:26:09.303350
# Unit test for function decode
def test_decode():
    # Simple string test
    assert codecs.decode("dGVzdA==", encoding='b64') == b"test"
    # Test string with newline
    assert codecs.decode("dGVz\ndA==", encoding='b64') == b"test"
    # Test string with newlines and extra spacing
    assert codecs.decode("dGVz\ndA==\n", encoding='b64') == b"test"
    # Test string with newlines and extra spacing
    assert codecs.decode(" dGVz\n dA==\n", encoding='b64') == b"test"
    assert codecs.encode(b'test', encoding='b64') == "dGVzdA=="

# Generated at 2022-06-21 12:26:12.708362
# Unit test for function decode
def test_decode():
    """
    Test the decode function
    """
    assert decode(b"test") == ("dGVzdA==", 4)



# Generated at 2022-06-21 12:26:23.322258
# Unit test for function decode
def test_decode():
    # Test 1
    print('Testing b64.decode()')
    data = b'Hello'
    expected = 'SGVsbG8='
    actual = codecs.decode(data, NAME)
    if expected == actual:
        print(
            'Test 1 succeeded\nExpected:\n',
            expected,
            '\nActual:\n',
            actual
        )
    else:
        print(
            'Test 1 failed\nExpected:\n',
            expected,
            '\nActual:\n',
            actual,
        )
    # Test 2
    data = b'World'
    expected = 'V29ybGQ='
    actual = codecs.decode(data, NAME)

# Generated at 2022-06-21 12:26:28.169656
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('test_register: Codec registration failed.')


# Generated at 2022-06-21 12:26:39.084923
# Unit test for function encode
def test_encode():
    """Test the b64.encode function."""
    print(NAME, 'encode', '\n', encode.__doc__)

# Generated at 2022-06-21 12:26:40.484516
# Unit test for function encode
def test_encode():
    assert encode('dGVzdAo=') == (b'test\n', 7)

# Generated at 2022-06-21 12:26:42.745103
# Unit test for function encode
def test_encode():  # pylint: disable=R0201
    result = encode('Hello World')
    print(result[0])
    print(result[1])


# Generated at 2022-06-21 12:26:47.543442
# Unit test for function register
def test_register():
    """Unit test for function register."""
    print('Testing register()')
    register()
    codecs.getencoder(NAME)  # type: ignore

# Generated at 2022-06-21 12:26:50.969020
# Unit test for function register
def test_register():
    """Verify that the codec is registered."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:27:01.377065
# Unit test for function encode

# Generated at 2022-06-21 12:27:11.859719
# Unit test for function encode
def test_encode():
    """Unit test for the ``encode`` function.
    """
    # Define the function input data

# Generated at 2022-06-21 12:27:17.825244
# Unit test for function encode
def test_encode():
    test_input = dedent("""\
        eyJ0ZXN0IjogIk1hbmJveCBEZW1vIn0=\
        """).strip()
    expected_output = b'{"test": "Mambo Demo"}'
    assert encode(test_input) == (expected_output, len(test_input))



# Generated at 2022-06-21 12:27:23.004283
# Unit test for function decode
def test_decode():
    """Unit test for function 'decode' (Extra credit)."""
    data = b'This is a string of bytes'
    result = decode(data)[0]
    expected_result = 'VGhpcyBpcyBhIHN0cmluZyBvZiBieXRlcw=='
    assert result == expected_result



# Generated at 2022-06-21 12:27:26.864665
# Unit test for function decode
def test_decode():
    """Test for the 'decode' function."""
    assert decode(b'\xc1\xe0\xa6\x85\x81\xc4\xaf\x0e\xee\x8e\xb1\x00') == (
        'w1/Bx5cBmsCZLwi3AA==',
        12
    )



# Generated at 2022-06-21 12:27:32.110198
# Unit test for function decode
def test_decode():
    in_str = '''
    A: B
    B: C
    '''
    out_str = b'QTogQgpCOiBDCg=='
    if decode(out_str)[0] != in_str.strip():
        raise AssertionError('decode failed')
    print('decode passed')



# Generated at 2022-06-21 12:27:43.419255
# Unit test for function encode
def test_encode():
    """Unittest for function encode"""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aG\tVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\t') == (b'hello', 6)
    assert encode('aGVsbG8=    ') == (b'hello', 6)
    assert encode('aGVsbG8=\t\t') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 6)
    assert encode('aGVsbG8=\n\n') == (b'hello', 6)

# Generated at 2022-06-21 12:27:47.605107
# Unit test for function decode
def test_decode():
    b = b'\x00\x00\x02\x00\x00\x00\x00\x00'
    out, length = decode(b)
    assert out == 'AAAAAgAAAAA='


# Generated at 2022-06-21 12:28:03.286710
# Unit test for function decode
def test_decode():
    # bytes_input is a set of hex values which make the string "Hello".
    bytes_input = bytearray.fromhex('48656c6c6f')
    # base64_input is "SGVsbG8=\n"
    base64_input = 'SGVsbG8=\n'

    decoded_bytes, bytes_consumed = decode(bytes_input)
    assert decoded_bytes == base64_input
    assert bytes_consumed == len(bytes_input)

    # bytes_input2 is a set of hex values which make the string "World".
    bytes_input2 = bytearray.fromhex('576f726c64')
    # base64_input2 is "V29ybGQ=\n"

# Generated at 2022-06-21 12:28:11.994864
# Unit test for function decode
def test_decode():
    """Test function ``decode()``"""
    # pylint: disable=line-too-long
    # Format is:
    # in_string, bytes, max_output_length, out_string, consumed

# Generated at 2022-06-21 12:28:14.859663
# Unit test for function register
def test_register():
    __tracebackhide__ = True
    from hlauto.codecs import codec_registry_, register
    register()
    assert NAME in codec_registry_.registry


# Generated at 2022-06-21 12:28:21.867592
# Unit test for function decode
def test_decode():
    from hamcrest import assert_that, is_

    def utest(expected: _ByteString, input_: str) -> None:
        decoded_str, consumed_length = decode(input_)
        assert_that(decoded_str, is_(expected))
        assert_that(consumed_length, is_(len(input_)))

    utest(b'\x00\x00\x00\x00', 'AAAA')
    utest(b'TheQuickBrown', 'VGhlUXVpY2tCcm93bg==')
    utest(b'TheQuickBrownFoxJumpsOverTheLazyDog',
          'VGhlUXVpY2tCcm93bkZveEp1bXBzT3ZlclRoZUxhenlEb2c=')

# Generated at 2022-06-21 12:28:30.365602
# Unit test for function encode
def test_encode():
    """Test function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 6)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVm\r') == (b'abcdef', 6)
    assert encode('YWJjZGVm\n') == (b'abcdef', 6)
    assert encode('YWJjZGVm\r\n') == (b'abcdef', 6)



# Generated at 2022-06-21 12:28:37.485043
# Unit test for function encode
def test_encode():
    """Unit test of function encode."""
    table = [
        ('a', 0, b'a', 1),
        ('aGVsbG8gd29ybGQK', 0, b'hello world', 1),
    ]

    for (text_input, start, expect, length) in table:
        out, out_length = encode(text_input, start)
        assert out == expect
        assert out_length == length


# Generated at 2022-06-21 12:28:40.287273
# Unit test for function register
def test_register():
    from . import codec_registry
    # Use a different registry.
    registry = codec_registry.Registry()

    registry.register(NAME)

register()

# Generated at 2022-06-21 12:28:44.257915
# Unit test for function decode
def test_decode():
    "Run simple decode tests."
    text = 'AA'
    out = decode(text)[0]
    assert out == 'QQ=='

    text = 'AAA'
    out = decode(text)[0]
    assert out == 'QUE='

    text = 'AAAA'
    out = decode(text)[0]
    assert out == 'QUFB'



# Generated at 2022-06-21 12:28:49.165394
# Unit test for function encode
def test_encode():
    text_input = '''
    SGVsbG8sIEkgYW0gdGhlIEJhc2U2NCB0ZXN0IG1lbnNhZ2Uh
    '''
    out, _ = encode(text_input)
    assert b'Hello, I am the Base64 test message!' == out

# Generated at 2022-06-21 12:29:00.166040
# Unit test for function register
def test_register():
    from sys import modules
    from unittest import TestCase
    from unittest.mock import patch, Mock

    foo = modules[__name__]
    with patch('{0}.codecs'.format(__name__), Mock()) as mock_codecs:
        # Test that the codec is already registered.
        register()
        mock_codecs.register.assert_not_called()

        from sys import modules
        from imp import reload
        reload(foo)

        # Test that the codec was not registered again.
        register()
        mock_codecs.register.assert_called_once()

        del modules[__name__]
        reload(foo)

        # Test that the codec was registered again.
        register()
        assert mock_codecs.register.call_count == 2



# Generated at 2022-06-21 12:29:16.943270
# Unit test for function decode

# Generated at 2022-06-21 12:29:24.051915
# Unit test for function decode
def test_decode():
    decoded = b"7375626d6974207468652062756c6c2773206a6f696e20666f722074686520696e7465676572207769746820746f6b656e7321"
    expectedOut = "submitted the bull's join for the integer with tokens!"
    out, consumed = decode(decoded)
    print(out)
    assert out == expectedOut
    assert consumed == len(decoded)

# Unit Test for function encode

# Generated at 2022-06-21 12:29:28.244098
# Unit test for function register
def test_register():  # pylint: disable=R0201
    b64 = codecs.lookup(NAME)

    assert b64.name == NAME

    assert b64.decode(b'*') == ('Kg==\n', 2)
    assert b64.encode(b'*') == ('Kg==', 2)



# Generated at 2022-06-21 12:29:34.974860
# Unit test for function decode
def test_decode():  # type: ignore
    decode(bytes.fromhex('e99a18c428cb38d5f260853678922e03')) == \
        '5JK8cb38d5f260853678922e03'
    decode(bytes.fromhex('a2e2d0a0f98a5e5d932b6829d3c03c17')) == \
        'hJK8cb38d5f260853678922e03'
    decode(bytes.fromhex('89a14fcb10ba0c4963cabd2a9b946c9e')) == \
        '8JK8cb38d5f260853678922e03'

# Generated at 2022-06-21 12:29:37.922226
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-21 12:29:46.575955
# Unit test for function encode
def test_encode():
    # Test with empty str
    assert encode('') == (b'', 0)

    # Valid base64 text
    assert encode('Zm9v') == (b'foo', 4)

    # Valid base64 text with whitespace (Tabs and NewLines)
    assert encode(
        '\n    Zm9v\n   '
    ) == (b'foo', 8)

    # Valid base64 text with extra characters from extended ASCII
    assert encode(
        'Zm9v \n   @'
    ) == (b'foo', 4)

    # Empty base64 text
    assert encode('') == (b'', 0)

    # empty base64 text with whitespace (Tabs and NewLines)
    assert encode('\n   \n\t') == (b'', 0)

    # Single character from

# Generated at 2022-06-21 12:29:48.379814
# Unit test for function register
def test_register():  # pragma: no cover
    """Test the :func:`register` function."""
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:29:51.724384
# Unit test for function decode
def test_decode():
    assert decode(b'dGVzdGluZw==') == ('dGVzdGluZw==', 12)


# Generated at 2022-06-21 12:29:57.821293
# Unit test for function encode
def test_encode():
    text = 'VWxnaXN0ZXIgYXQgaHR0cHM6Ly9naXRodWIuY29tL3N1aWxkc2xhYXAvd3Mtc3RvcmFnZS1kb3dubG9hZC5naXQ='
    out, len_text = encode(text)
    assert out == b'Einstein at https://github.com/suildsla/ws-storage-download.git'
    assert len_text == len(text)


# Generated at 2022-06-21 12:30:05.306947
# Unit test for function encode
def test_encode():
    result = encode(
        '''\
        IyBsaXN0IHVuY29tcHJlc3NlZCBmaWxlcyBpbiB0aGUgY3VycmVudCBkaXJl Y3RvcnkKZCAv
        ZmxhZ3MK'''
    )
    assert result == (
        b'# list uncompressed files in the current directory\nd /flags',
        len('# list uncompressed files in the current directory\nd /flags'),
    )


# Generated at 2022-06-21 12:30:16.918166
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.decode.cache  # type: ignore
    assert NAME in codecs.encode.cache  # type: ignore

# Generated at 2022-06-21 12:30:19.642076
# Unit test for function encode
def test_encode():
    assert b'\x00\x00\x00' == \
        encode('AAAA', errors='strict')[0]
    assert b'\x00\x00\x00' == \
        base64.decodebytes(
            'AAAA'.encode('utf-8')
        )



# Generated at 2022-06-21 12:30:21.524410
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)  # assert not LookupError



# Generated at 2022-06-21 12:30:27.953697
# Unit test for function register
def test_register():
    """Test the :func:`register` function."""
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Unable to getdecoder for {NAME!r} codec: {e}')


# Generated at 2022-06-21 12:30:32.038053
# Unit test for function encode
def test_encode():
    assert encode(
        "bm9kZXJzIGFyZSBnb29kCg==",
        errors='strict',
    ) == (b'nodes are good\n', 23)


# nosetest for function decode

# Generated at 2022-06-21 12:30:37.955217
# Unit test for function register
def test_register():
    # Make sure the b64 codec is not registered.
    try:
        codecs.getdecoder(NAME)
        assert False, 'b64 codec should not be registered.'
    except LookupError:
        pass

    # Now register the codec and make sure it is available.
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'b64 codec registration failed.'



# Generated at 2022-06-21 12:30:48.500996
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    # Create a codec info object.
    obj = codecs.CodecInfo(  # type: ignore
        name=NAME,
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )

    # Test for register
    codecs.register(obj)  # type: ignore
    assert codecs.lookup(NAME)       # type: ignore
    assert codecs.lookup(NAME) == obj  # type: ignore

    # Test for registering again
    codecs.register(obj)  # type: ignore
    assert codecs.lookup(NAME)       # type: ignore
    assert codecs.lookup(NAME) == obj  # type: ignore



# Generated at 2022-06-21 12:30:55.208924
# Unit test for function encode
def test_encode():
    """Unit test for the ``encode()`` function."""
    # Since the encode function only accepts strings, the output of
    # the 'decode()' function can be used to test the encode()
    # function.
    decode_test_string = "Hallo Hund"
    decode_test_bytes = b'SGVsbG8gSHVuZA==\n'
    decode_test_tuple = decode(decode_test_bytes)
    test_tuple = encode(decode_test_tuple[0])
    assert decode_test_bytes == test_tuple[0]



# Generated at 2022-06-21 12:30:56.594249
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-21 12:31:06.730488
# Unit test for function encode
def test_encode():
    assert encode(base64.b64encode(b'ABC').decode('utf-8'), 'strict') == (b'ABC', 4)
    assert encode(base64.b64encode(b'hello').decode('utf-8'), 'strict') == (b'hello', 5)
    assert encode(base64.b64encode(b'defg\n123.').decode('utf-8'), 'strict') == (b'defg\n123.', 9)
    assert encode(b'defg\nwxyz.', 'strict') == encode(b'defg\n1asd.', 'strict') == encode(b'defg\n123.', 'strict')

# Generated at 2022-06-21 12:31:20.302966
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8sIHdvcmxkIQ==', 'strict')\
        == (b'hello, world!', 17)

# Generated at 2022-06-21 12:31:29.799547
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    # Register the b64 codec.
    register()

    # Get the decoder.
    decoder = codecs.getdecoder(NAME)

    # Make sure the decoder is of type 'codecs.CodecInfo'
    assert isinstance(decoder, tuple)
    assert isinstance(decoder[0], codecs.CodecInfo)

    # Get the encoder.
    encoder = codecs.getencoder(NAME)

    # Make sure the encoder is of type 'codecs.CodecInfo'
    assert isinstance(encoder, tuple)
    assert isinstance(encoder[0], codecs.CodecInfo)



# Generated at 2022-06-21 12:31:37.897108
# Unit test for function register
def test_register():                                           # pragma: no cover
    from io import StringIO
    import re
    import sys

    # Perform the registration of the '64' codec with Python.
    register()

    # Capture the output of the registry.
    out_stream = StringIO()
    err_stream = StringIO()
    sys.stdout = out_stream
    sys.stderr = err_stream


# Generated at 2022-06-21 12:31:39.950958
# Unit test for function decode
def test_decode():
    data = b"ABC"
    result, bytes_consumed = decode(data)
    print(result, bytes_consumed)



# Generated at 2022-06-21 12:31:51.300439
# Unit test for function decode
def test_decode():
    """Test function ``decode()``"""
    assert decode(b'') == ('', 0)

    actual = decode(b'\x00\x00\x00\x00')
    assert actual == (
        'AAAAAAAAAAAAAA==\n',
        4,
    )

    actual = decode(b'\x00\x00\x00')
    assert actual == (
        'AAAAAAAAAAAAAA==\n',
        3,
    )

    actual = decode(b'\x00\x00')
    assert actual == (
        'AAAAAAAAAAAAAA==\n',
        2,
    )

    actual = decode(b'\x00')
    assert actual == (
        'AAAAAAAAAAAAAA==\n',
        1,
    )

    actual = decode(b'\x01')

# Generated at 2022-06-21 12:31:56.111609
# Unit test for function register
def test_register():
    # No codecs named 'b64' should exist.
    assert 'b64' not in codecs.__dict__
    # Register the 'b64' codec.
    register()
    assert 'b64' in codecs.__dict__
    # Re-register again, without error.
    register()
    assert 'b64' in codecs.__dict__



# Generated at 2022-06-21 12:32:06.451940
# Unit test for function decode
def test_decode():
    # pylint: disable=no-self-use
    # noinspection PyUnusedLocal
    class Test:
        def __str__(self):
            return 'test'

        def __bytes__(self):
            return b'bytes'

        def __repr__(self):
            return 'test'

        def __iter__(self):
            return iter(b'bytes')

    obj = Test()
    obj_bytes = Test()
    obj_bytes.__bytes__ = lambda: b'bytes'


# Generated at 2022-06-21 12:32:10.287357
# Unit test for function decode
def test_decode():
    input_text = """
    qwe
    asd
    zxc
    """
    input_bytes = b'cXdlCmFzZAp6eGMK'
    out = decode(input_bytes)
    assert out[0] == input_text



# Generated at 2022-06-21 12:32:15.425540
# Unit test for function register
def test_register():
    """Ensure the b64 codec is registered with Python."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-21 12:32:24.711854
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    def unit_test_config(
            data: _ByteString,
            errors: _STR,
            expected_result: str,
            expected_length: int,
    ) -> None:
        """Configure a unit test of base64 decoder"""
        nonlocal test_fnc
        nonlocal test_data

        result = decode(  # type: ignore[arg-type]
            data=data,
            errors=errors  # type: ignore[arg-type]
        )
        test_fnc(
            result,
            (expected_result, expected_length),
            msg=f'Decoded data bytes = {data!r} and errors = {errors!r}'
        )

    test_fnc = test.expected('decode', globals())
    test_data = test.get