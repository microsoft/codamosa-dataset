

# Generated at 2022-06-21 12:22:35.294850
# Unit test for function encode
def test_encode():
    # pylint: disable=missing-function-docstring
    assert encode('') == (b'', 0)
    assert encode('dGVzdGluZwo=') == (b'testing', 11)

    try:
        encode('dGVzdGluZwo')
        assert False
    except UnicodeEncodeError:
        pass

    try:
        encode('=')
        assert False
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-21 12:22:39.357600
# Unit test for function encode
def test_encode():
    assert encode(
        (
            "Zm9vZnJhY2s="
        )
    ) == b'\x14\xf1`BL\x8ct\xdd\x7f\xc6\xea\x9e\x1b'


# Generated at 2022-06-21 12:22:49.688812
# Unit test for function decode
def test_decode():
    assert decode(b'\x11\x22\x33\x44') == ('ESIzRA==', 4)
    assert decode(
        b'\x11\x22\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\xCC\xDD\xEE\xFF'
    ) == ('ESIzRFVmT1JWXk5WVlZWVlZW', 15)

# Generated at 2022-06-21 12:22:50.935141
# Unit test for function encode
def test_encode():
    assert encode('QQ==')[0] == b'A'


# Generated at 2022-06-21 12:22:53.966265
# Unit test for function register
def test_register():
    """Verify that the ``NAME`` codec is registered with Python."""
    register()
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-21 12:23:00.169732
# Unit test for function decode
def test_decode():
    assert 'YQ==' == decode(b'a')[0]
    assert 'YWI=' == decode(b'ab')[0]
    assert 'YWJj' == decode(b'abc')[0]
    assert 'YWJjZA==' == decode(b'abcd')[0]
    assert 'YWJjZGU=' == decode(b'abcde')[0]
    assert 'YWJjZGVm' == decode(b'abcdef')[0]

    assert 'YWJjZGVm' == decode(bytearray(b'abcdef'))[0]
    assert 'YWJjZGVm' == decode(memoryview(b'abcdef'))[0]


# Generated at 2022-06-21 12:23:05.616258
# Unit test for function encode
def test_encode():
    input_str = 'SXQgbWF5IGJlIGEgc3RyaW5nIG9mIHRleHQh'
    expected_bytes = b'I may be a string of text!'
    converted_bytes, _ = encode(input_str)
    assert expected_bytes == converted_bytes


# Generated at 2022-06-21 12:23:07.606214
# Unit test for function encode
def test_encode():
    result = encode('QQ==')
    assert result == (b'A', 2)



# Generated at 2022-06-21 12:23:17.244584
# Unit test for function decode
def test_decode():
    """Unit test to test :func:`~encoding.b64.decode`."""
    assert decode(b'\x00\x00\x00') == ('AAAA', 3)
    assert decode(b'\x00\x00\x00\x00') == ('AAAAAAAA', 4)
    assert decode(b'\x00\x00\x00\x00\x00') == ('AAAAAAAAAA==', 4)
    assert decode(b'\x00\x00\x00\x00\x00\x00') == ('AAAAAAAAAAA=', 5)
    assert decode(b'\x00\x00\x00\x00\x00\x00\x00') == ('AAAAAAAAAAAA', 6)

# Generated at 2022-06-21 12:23:25.311241
# Unit test for function encode

# Generated at 2022-06-21 12:23:34.755461
# Unit test for function register
def test_register():
    """Unit test for function 'register'."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('b64 codec is already registered.')

    register()
    assert NAME == codecs.getdecoder(NAME)[0]    # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:23:40.844263
# Unit test for function decode
def test_decode():
    assert decode(b'\x04\t\x1b\x1b\x1b\x1b\x0c\x15\x1b\x13\x03') == ('CeYjzdGObA==', 11)
    assert decode(b'\x0c\t\x19') == ('Dls=', 3)
    assert decode(b'\x1e\x0b\x0b\x06\x07\x0f\x00\x1f') == ('7Zrd6rO+', 8)
    assert decode(b'\x08\x18\x00\x0b') == ('JNIG', 4)
    assert decode(b'\x0b\x05\x18\x01\x15') == ('BpFmFw==', 5)

# Generated at 2022-06-21 12:23:47.721818
# Unit test for function decode
def test_decode():
    input_vars = [
        'RGVhc2UgYmxvb2QgZm9yIHRoZSBhYnN0aWNlJ3M=',
        'SSBhbSBhbiBhYnN0aWNl',
        'IEdhaGhhIHRoZSBhYnN0aWNl'
    ]
    for i in input_vars:
        out_val = decode(i)
        type_val = type(out_val[0])
        assert type_val is str
        assert len(out_val) == 2
        assert out_val[1] == len(i)
        

# Generated at 2022-06-21 12:23:57.507059
# Unit test for function decode
def test_decode():
    assert decode(b"YQ==")[0] == "a"
    assert decode(b"YWI=")[0] == "ab"
    assert decode(b"YWJj")[0] == "abc"
    assert decode(b"YW\nJj")[0] == "abc"
    assert decode(b"YW\n\nJj")[0] == "abc"
    assert decode(b"Y\nW\n\nJj")[0] == "abc"
    assert decode(b"Y\n\nW\n\nJj")[0] == "abc"
    assert decode(b"Y\n\n\nW\n\n\nJj")[0] == "abc"

# Generated at 2022-06-21 12:24:06.619336
# Unit test for function encode
def test_encode():
    """Test that the ``encode`` function works as expected."""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == b'YWJjZA=='
    assert encode('abcd\nefghi') == b'YWJjZGVmZ2hp'
    assert encode('abcd\nefghi\n') == b'YWJjZGVmZ2hp'
    assert encode('abcd\nefghi\nj') == b'YWJjZGVmZ2hpag=='

# Generated at 2022-06-21 12:24:14.992254
# Unit test for function encode
def test_encode():
    from binascii import Error as b64Error


# Generated at 2022-06-21 12:24:17.022271
# Unit test for function encode
def test_encode():
    assert 'Qmx1ZXZvb2Q='.encode('b64') == b'Bluevood'

    # Unit test for function decode

# Generated at 2022-06-21 12:24:22.920366
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    # noinspection PyUnusedLocal
    def my_decode(a, b):
        """Mock decode function."""
        # pylint: disable=unused-argument
        return 'A', 1
    codecs.register(lambda name: codecs.CodecInfo(  # type: ignore
        name='b64',
        encode=str.encode,
        decode=my_decode
    ))
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-21 12:24:24.067364
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('ZW5jb2Rl') == (b'encode', 6)



# Generated at 2022-06-21 12:24:29.032550
# Unit test for function register
def test_register():
    # Unregister the 'b64' codec, if it is already registered
    # pylint: disable=W0703
    try:
        codecs.lookup(NAME)
        codecs.unregister(NAME)
    except LookupError:
        pass

    try:
        assert NAME not in codecs.__dict__['_codec_info']._registry
    except KeyError:
        pass

    try:
        assert NAME not in codecs.__dict__['_codec_cache']._cache
    except KeyError:
        pass

    assert NAME not in codecs.__dict__['_aliases']._aliases

    register()

    assert NAME in codecs.__dict__['_codec_info']._registry

# Generated at 2022-06-21 12:24:37.614835
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    # Remove the codec from Python's codec map
    codecs.unregister(NAME)
    # Assert that the codec is not registered
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    # Assert that the codec is registered after the register function
    # is called.  And that the getdecoder function does not raise an
    # exception.
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:24:49.422241
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    # pylint: disable=W0613
    # pylint: disable=W0621
    import unittest
    from typing import Any

    class TestRegister(unittest.TestCase):

        def test_register(self):
            # pylint: disable=W0612
            # pylint: disable=W0613
            import sys
            import re
            from typing import List

            # Capture stdout and stderr before register() is called.
            out_buff = []
            err_buff = []
            temp_out = sys.stdout
            temp_err = sys.stderr
            sys.stdout = out_buff
            sys.stderr = err_buff

            # Ensure that the codec is not registered.

# Generated at 2022-06-21 12:24:54.953645
# Unit test for function register
def test_register():
    """Test the register() function one-time.

    This function is called from the main module's test_b64 and is only
    called one-time.  This test verifies the codec can be registered and
    that the function does not raise an exception.
    """
    register()
    # Verify the codec is registered.
    codec_info = codecs.getdecoder(NAME)
    assert codec_info.name == NAME


# Generated at 2022-06-21 12:25:03.083280
# Unit test for function decode
def test_decode():
    """Unit test for function :obj:`decode`."""
    assert decode(b'', 'strict') == ('YQ==', 0)

    assert decode(b'a', 'strict') == ('YQ==', 1)

    assert decode(b'aa', 'strict') == ('YWE=', 2)

    assert decode(b'aaa', 'strict') == ('YWFh', 3)

    assert decode(b'aaab', 'strict') == ('YWFhYg==', 4)

    assert decode(b'aaabc', 'strict') == ('YWFhYmM=', 5)

    assert decode(b'aaabcd', 'strict') == ('YWFhYmM=', 5)


# Generated at 2022-06-21 12:25:06.037297
# Unit test for function decode
def test_decode():
    """Test function ``decode``."""
    assert decode(bytes([0xFF, 0xFF]))[0] == '__8='



# Generated at 2022-06-21 12:25:17.825881
# Unit test for function encode
def test_encode():
    assert encode('YWJj\nZGVm\n') == (b'abcdef', 15)
    assert encode('YWJj\nZGVm\n', 'ignore') == (b'abcdef', 15)
    assert encode('YWJj\nZGVmZw==', 'ignore') == (b'abcdefg', 17)
    assert encode('YWJj\nZGVmZw==\n', 'ignore') == (b'abcdefg', 18)
    assert encode('YWJj\nZGVmZw==\n', 'ignore') == (b'abcdefg', 18)
    assert encode('YWJj\nZGVmZw==', 'strict') == (b'abcdefg', 17)

# Generated at 2022-06-21 12:25:19.482768
# Unit test for function decode
def test_decode():
    data = 'hello'
    result = decode(data.encode("utf-8"))
    print(result)


# Generated at 2022-06-21 12:25:28.312248
# Unit test for function decode
def test_decode():
    assert(decode(b'YWJjZA==') == ('abcd', 4))
    assert(decode(b'Zm9vYmFyYmF6') == ('foobarbaz', 9))
    assert(decode(b'Zm9vYmFyYmF6MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkwMTIzNDU2Nzg5') == ('foobarbaz123456789012345678901234567890123456789', 45))

# Generated at 2022-06-21 12:25:33.707901
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function"""
    print(__name__)

    # pylint: disable=broad-except
    try:
        from . import test_b64_decode
    except Exception as e:
        print(e)
        return False
    return test_b64_decode.test_main(decode)



# Generated at 2022-06-21 12:25:35.872950
# Unit test for function decode
def test_decode():
    assert decode(bytes([1,2,3])) == ('AQID', 3)


# Generated at 2022-06-21 12:25:47.710930
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 15)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWE=') == (b'aa', 5)



# Generated at 2022-06-21 12:25:49.961642
# Unit test for function decode
def test_decode():
    assert decode(b'\x01\x00\x00\x00') == ('AQAAAA==', 4)



# Generated at 2022-06-21 12:25:55.222706
# Unit test for function decode
def test_decode():
    import random
    random.seed(1234)
    for _ in range(1000):
        r = random.randint(0, 1024)
        d = bytearray(random.getrandbits(8) for _ in range(r))
        s, l = decode(d)
        assert l == r, f'Length {l} is not {r}'
        d2 = codecs.encode(s, 'ascii')
        assert d == d2, f'{d2} is not {d}'



# Generated at 2022-06-21 12:25:56.361179
# Unit test for function encode
def test_encode():
    """Test ``encode`` function."""
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 12:26:04.668100
# Unit test for function decode
def test_decode():
    EXPECTED_STR = 'foo bar'
    EXPECTED_BYTES = b'Zm9vIGJhcg=='
    STR, NUM_BYTES = decode(EXPECTED_BYTES)
    assert STR == EXPECTED_STR, f'{STR!r} != {EXPECTED_STR!r}'
    assert NUM_BYTES == len(EXPECTED_BYTES), \
        f'{NUM_BYTES} != {len(EXPECTED_BYTES)}'



# Generated at 2022-06-21 12:26:05.714555
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:26:07.994430
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-21 12:26:19.729185
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test a single line string
    text, _ = encode('aW5wdXQ=\n')
    assert text == b'input'

    # Test multiple lines
    text, _ = encode('Rmlyc3QKSW5wdXQKTWlkZGxlCk91dHB1dAoK')
    assert text == b'First\nInput\nMiddle\nOutput'

    # Test indented multiple lines
    text, _ = encode('IGZpcnN0CiAgaW5wdXQKIG1pZGRsZQogb3V0cHV0CgogICAg')
    assert text == b' first\n  input\n middle\n output'

# Generated at 2022-06-21 12:26:31.679958
# Unit test for function encode

# Generated at 2022-06-21 12:26:41.894851
# Unit test for function register
def test_register():
    """Test the magic behind the ``register`` function.

    The ``register`` function will only register the ``b64`` codec
    if the codec is not already registered.  This test first calls
    the ``register`` function to register the ``b64`` codec.  Then
    the test verifies that the ``b64`` codec is registered.  The
    test then calls the ``register`` function again.  At this point
    the ``b64`` codec should not be registered again.
    """
    # Verify the 'b64' codec is not registered before the register
    # function is called.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # The b64 codec is not registered. Good.
        pass

# Generated at 2022-06-21 12:26:51.917117
# Unit test for function register
def test_register():
    register()
    registering_codec = codecs.getencoder(NAME)  # type: ignore
    assert registering_codec(b'123')[0] == 'MTIz'  # type: ignore

# Generated at 2022-06-21 12:26:55.877248
# Unit test for function register
def test_register():
    """Test the register function"""
    print('register')

    codecs.getdecoder(NAME)

    # Assert that function register does not return anything.
    assert register() is None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:27:02.628490
# Unit test for function register
def test_register():
    """
    Test that the "b64" codec is registered with Python.
    """
    def check_b64_codec_is_registered() -> bool:
        try:
            _ = codecs.getdecoder(NAME)
            return True
        except LookupError:
            return False

    # Check that the b64 codec is NOT registered:
    assert check_b64_codec_is_registered() is False

    # Register the b64 codec.
    register()

    # Check that the b64 codec is registered:
    assert check_b64_codec_is_registered() is True



# Generated at 2022-06-21 12:27:07.561577
# Unit test for function encode
def test_encode():
    # Test that a given input produces the correct output
    assert encode('SGVsbG8gV29ybGQ=')[0].decode() == 'Hello World'
    # Test that an error is raised for incorrect input
    try:
        encode('💩')
        assert False
    except UnicodeError:
        pass


# Generated at 2022-06-21 12:27:10.277572
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'Unable to register codec for {NAME!r}')

register()

# Generated at 2022-06-21 12:27:22.173459
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # pylint: disable=missing-function-docstring
    assert encode('YW55IGNhcm5hbCBwbGVhcw==') == (b'any carnal pleas', 24)
    assert encode('YW5kIHRoZSBkZWNvZGVy') == (b'and the decoder', 19)
    assert encode('YW55IGNhcm5hbCBwbGVhcw') == (b'any carnal pleas', 24)
    assert encode('YW5kIHRoZSBkZWNvZGVy') == (b'and the decoder', 19)
    assert encode('YW55IGNhcm5hbCBwbGVhbw') == (b'any carnal pleas', 24)

# Generated at 2022-06-21 12:27:26.987838
# Unit test for function register
def test_register():
    register()
    actual_b64_codec_info = codecs.lookup(NAME)
    expected_b64_codec_info = codecs.CodecInfo(  # type: ignore[arg-type]
        name='b64',
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )
    assert actual_b64_codec_info == expected_b64_codec_info



# Generated at 2022-06-21 12:27:38.824112
# Unit test for function encode
def test_encode():
    # Unit test to make sure that whatever gets encoded, gets decoded
    # properly

    # Test strings
    teststr = "\n dv2CZqWGmOgYi9sB"
    teststr2 = "wV7B-jbzgV7B-jbz"
    teststr3 = "  aGVsbG8gd29ybGQ"
    teststr4 = "122121212121"

    # Encode the strings using the codec
    encoded_teststr = codecs.encode(teststr, "b64")
    encoded_teststr2 = codecs.encode(teststr2, "b64")
    encoded_teststr3 = codecs.encode(teststr3, "b64")

# Generated at 2022-06-21 12:27:43.494682
# Unit test for function register
def test_register():
    with patch('codecs.register', wraps=codecs.register) as mock_register, \
            patch('codecs.getdecoder', wraps=codecs.getdecoder) as mock_getdecoder:
        register()
        assert mock_register.called
        assert mock_getdecoder.called


# Generated at 2022-06-21 12:27:45.328293
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-21 12:28:02.249847
# Unit test for function encode
def test_encode():
    from .unit_test_util import TestCase
    bs = base64.b64encode(b'abc')
    out = encode('YWJj')
    TestCase(out.__class__.__name__).assertEqual(out[0], bs)



# Generated at 2022-06-21 12:28:11.371171
# Unit test for function encode
def test_encode():
    """Test the :func:`~.encode` function."""
    # Test basic usage:
    text = 'YQo='
    result = encode(text)
    assert result == (b'a\n', 3)

    # Test no '=' padding
    text = 'aaaaaaaaa'
    result = encode(text)
    assert result == (b'aaaaaaaaa', 10)

    # Test no '=' padding, with \n
    text = 'aaaaa\naaaa'
    result = encode(text)
    assert result == (b'aaaaa\naaaa', 10)

    # Test multiple spaces between characters
    text = 'Y  Q  o  =  ='
    result = encode(text)
    assert result == (b'a\n', 3)

    # Test whitespace

# Generated at 2022-06-21 12:28:20.106733
# Unit test for function decode
def test_decode():  # pylint: disable=R0914
    sample_bytes = bytes(range(256))

# Generated at 2022-06-21 12:28:22.848875
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8gd29ybGQ=') == ('hello world', 14)

# Generated at 2022-06-21 12:28:26.433259
# Unit test for function encode
def test_encode():
    encoded_bytes = base64.b64encode(b'abcdef123')
    encoded_str = encoded_bytes.decode('utf-8')
    assert encode(encoded_str) == (b'abcdef123', 12)



# Generated at 2022-06-21 12:28:32.953719
# Unit test for function register
def test_register():
    """Ensure the register function works as expected."""
    from unit_test_common import TestCommon
    import sys

    # Import the codec and verify it has been registered.
    import b64

    # Verify the codec exists and is a module.
    TestCommon.assert_is_instance(b64, module)

    # Unregister the codec.
    b64.unregister()

    # Verify the codec was unregistered.
    TestCommon.assert_is_none(
        codecs.lookup(b64.NAME),
        'b64 codec was not unregistered'
    )

    # Add the package path to the sys.path modules
    sys.path.insert(0, os.path.dirname(b64.__file__))

    # Import the codec again and verify it has been registered.
    import b64

    # Verify the codec

# Generated at 2022-06-21 12:28:39.961295
# Unit test for function decode
def test_decode():
    """Test the function decode."""
    assert 'a' == decode(b'YQ==')[0]
    assert 'ab' == decode(b'YWI=')[0]
    assert 'abc' == decode(b'YWJj')[0]
    assert 'abcd' == decode(b'YWJjZA==')[0]
    assert 'abcde' == decode(b'YWJjZGU=')[0]
    assert 'abcdef' == decode(b'YWJjZGVm')[0]
    assert 'abcdefg' == decode(b'YWJjZGVmZw==')[0]
    assert 'abcdefgh' == decode(b'YWJjZGVmZ2g=')[0]

# Generated at 2022-06-21 12:28:47.019432
# Unit test for function decode
def test_decode():
    """Unit tests for function decode."""
    assert decode(b'  eW91IGNhbid0IHJlYWQgdGhpcyEg')[0]\
        == 'you cant read this!'
    assert decode(b' \n\n  eW91IGNhbid0IHJlYWQgdGhpcyEg\n\n ')[0]\
        == 'you cant read this!'
    assert decode(b' \n\n  eW91IGNhbid0IHJlYWQgdGhpcyEg\n\n ')[0]\
        == 'you cant read this!'

# Generated at 2022-06-21 12:28:50.223852
# Unit test for function register
def test_register():
    """
    Call the register function.
    """
    register()

test_register()  # pylint: disable=no-value-for-parameter


# Generated at 2022-06-21 12:28:52.515874
# Unit test for function decode
def test_decode():
    ret = decode(b'hello')
    assert ret == ('aGVsbG8=', 5)



# Generated at 2022-06-21 12:29:20.291265
# Unit test for function decode
def test_decode():
    assert decode(b'U29tZSBvZiB0aGlzIGlzIHNlY3VyZS4=') == (str('Some of this is secure.'), 24)


# Generated at 2022-06-21 12:29:29.857976
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    # pylint: disable=protected-access
    from importlib import reload
    from codecs import lookup
    from . import b64, codec_info

    reload(b64)
    importlib.reload(codec_info)

    input_str = 'abc123'
    expected_output = 'YWJjMTIz'
    expected_output_bytes = b'YWJjMTIz'

    name = NAME
    test_codec: codecs.CodecInfo = lookup(name)

    # The codec name must the same as the test_codec name.
    assert b64.NAME == name == test_codec.name

    # The codec decode function must be the same as the test_codec decode
    # function.
    assert b64.decode == test

# Generated at 2022-06-21 12:29:40.428314
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""

# Generated at 2022-06-21 12:29:42.967290
# Unit test for function register
def test_register():
    """Unit test for the function 'register'."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True

# Generated at 2022-06-21 12:29:50.634852
# Unit test for function decode
def test_decode():
    # Test line length is 76 and indentation is 10 spaces
    assert(
        decode(
            data=b'SGVsbG8gV29ybGQ=\n',
            errors=0,
        )
    ) == ('Hello World', 14)

    # Test with no line length and indentation
    assert(
        decode(
            data=b'SGVsbG8gV29ybGQ=\n',
            errors=0,
        )
    ) == ('Hello World', 14)

    # Test line length is 76 and indentation is 11 spaces
    assert(
        decode(
            data=b'SGVsbG8gV29ybGQ=\n',
            errors=0,
        )
    ) == ('Hello World', 14)

    # Test line length is 76 and indentation is 14 spaces

# Generated at 2022-06-21 12:29:52.917449
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'SGVsbG8gV29ybGQ=') == ('Hello World', 12)

# Generated at 2022-06-21 12:29:54.165158
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:30:02.405217
# Unit test for function decode
def test_decode():
    """Unit test of function decode."""
    # pylint: disable=global-statement
    global NAME
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    if NAME == "b64":
        # ('b64', 'strict', 'strict')
        utf8_string = "fóo "
        utf8_bytes = utf8_string.encode('utf-8')
        b64_bytes = base64.b64encode(utf8_bytes)
        b64_string = b64_bytes.decode('utf-8')
        utf8_decoded_string, _ = codecs.decode(b64_string, NAME)
        assert utf8_string == utf8_decoded_string


# Generated at 2022-06-21 12:30:13.194913
# Unit test for function decode
def test_decode():
    # noinspection PyUnresolvedReferences
    from base64 import b64encode, b64decode
    from collections import UserString
    from .types_ import ByteString

    def is_bytes(obj):
        return isinstance(obj, bytes) or isinstance(obj, bytearray) \
               or isinstance(obj, memoryview)

    def is_str(obj):
        return isinstance(obj, str) or isinstance(obj, UserString)

    def to_bytes(obj):
        return bytes(obj) if is_bytes(obj) else obj.encode('utf-8')

    def to_str(obj):
        return str(obj) if is_str(obj) else obj.decode('utf-8')

    for i in range(10):
        # Generate some random bytes
        data = os

# Generated at 2022-06-21 12:30:19.109803
# Unit test for function encode
def test_encode():
    assert (encode('U2VuZAo=\n') == (b'Send\n', 8))
    assert (encode('U2VuZAo=') == (b'Send', 6))
    assert (encode('U2VuZA') == (b'Send', 6))


# Generated at 2022-06-21 12:30:54.533388
# Unit test for function decode
def test_decode():
    assert decode(b'YWJj') == (u'abc',3)
    assert decode(b'Zm9vZGJhcg==') == (u'foodbar',8)
    assert decode(b'YWJjODk5ZWRlYmY=') == (u'abc899edebf',12)
    assert decode(b'SeKAnA==') == (u'!@#$',4)
    assert decode(b'---') == (u'---',3)
    assert decode(b'KjwvPi8='), (u'<!@#$',5)
    assert decode(b'YTg5OTllZGViZg==') == (u'a899edebf',9)

# Generated at 2022-06-21 12:30:58.757093
# Unit test for function decode
def test_decode():
    """Test the :func:`~utl_lib.strings.b64.decode` function."""
    assert decode(b'harry') == ('aGFycnk=', 5)
    assert decode(b'harry potter') == ('aGFycnkgcG90dGVy', 12)



# Generated at 2022-06-21 12:31:04.600729
# Unit test for function encode
def test_encode():
    """Unit test for the encode function."""
    with pytest.raises(TypeError):
        decode('')
    expected = b'Hello, World!'
    assert decode(
        encode(
            'SGVsbG8sIFdvcmxkIQ=='
        )
    ) == expected
    assert decode(
        encode(
            '''
            SGVsbG8sIFdvcmxkIQ==
            '''
        )
    ) == expected
    assert decode(
        encode(
            '''
            SGVsbG8sIFdvcmxkIQ==
            '''
        )
    ) == expected

# Generated at 2022-06-21 12:31:09.825175
# Unit test for function register
def test_register():
    # pylint: disable=unused-variable
    # noinspection PyShadowingNames
    @register
    class TestRegister(object):
        pass
    # pylint: enable=unused-variable


    codecs.lookup(NAME)
    try:
        codecs.lookup(NAME.upper())
    except LookupError as e:
        if f'could not find codec' not in str(e):
            raise AssertionError(e)



# Generated at 2022-06-21 12:31:11.034808
# Unit test for function decode
def test_decode():
    assert decode(b'AAAA') == (u'QUFB', 4)


# Generated at 2022-06-21 12:31:14.158016
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None   # type: ignore
    assert codecs.getencoder(NAME) is not None   # type: ignore


# Make the codec available for import.
register()

# Generated at 2022-06-21 12:31:25.293469
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 32)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo', 'strict') == (b'abcdefghijklmnopqrstuvwxyz', 32)
    assert encode('  YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo  ') == (b'abcdefghijklmnopqrstuvwxyz', 32)

# Generated at 2022-06-21 12:31:27.167094
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-21 12:31:36.324432
# Unit test for function encode

# Generated at 2022-06-21 12:31:41.121300
# Unit test for function register
def test_register():
    import codecs

    # Register the module
    codecs.register(_get_codec_info)   # type: ignore

    # Verify that we can use the module after we register it.
    assert codecs.encode('abc', NAME) == 'YWJj'
    assert codecs.decode(b'YWJj', NAME) == 'abc'