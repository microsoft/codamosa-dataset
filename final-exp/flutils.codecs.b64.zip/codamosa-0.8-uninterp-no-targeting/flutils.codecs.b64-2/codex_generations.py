

# Generated at 2022-06-21 12:22:43.778678
# Unit test for function register
def test_register():
    """Run the :func:`~register` function and make sure is works as intended."""
    codecs.getencoder(NAME)
    # Test coverage on the 'if' block
    # pylint: disable=protected-access
    if NAME not in codecs.__all__:
        codecs.__all__.append(NAME)
        # pylint: enable=protected-access



# Generated at 2022-06-21 12:22:45.309617
# Unit test for function decode
def test_decode():
    assert decode('','strict') == ('', 0)


# Generated at 2022-06-21 12:22:52.611630
# Unit test for function decode
def test_decode():
    base64_input = b'\xc2\xa2\xc2\xab'
    base64_bytes = b'4pyT'

    out_bytes, _ = decode(base64_input, 'ignore')
    assert out_bytes == '4pyT'

    out_bytes, _ = decode(base64_bytes, 'ignore')
    assert out_bytes == '4pyT'

    try:
        decode(b'1`3', 'ignore')
        assert False
    except UnicodeEncodeError:
        assert True



# Generated at 2022-06-21 12:22:56.196036
# Unit test for function register
def test_register():
    """Unit test for the register() function."""
    import importlib
    importlib.reload(codecs)
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        raise

# Generated at 2022-06-21 12:23:01.522462
# Unit test for function encode

# Generated at 2022-06-21 12:23:08.064257
# Unit test for function decode
def test_decode():
    # Test no input.
    try:
        decode(b'')
    except Exception as e:
        msg = 'b64.decode() expects no input.'
        if str(e) != msg:
            raise e
    else:
        raise AttributeError(
            'b64.decode() did not raise an AttributeError when given no '
            'input.'
        )


# Test with single valid base64 character

# Generated at 2022-06-21 12:23:10.924579
# Unit test for function decode
def test_decode():
    bytes_ = bytes((97, 97, 97))
    chars = encode(bytes_, errors='strict')
    assert chars == (b'YWFh', 4)



# Generated at 2022-06-21 12:23:14.578027
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-21 12:23:25.074622
# Unit test for function encode
def test_encode():
    assert encode(b'YmFzZTY0IGlzIGZlZWxmdWw=') == (b'this is cool', 19)
    assert encode(b'YmFzZTY0IGlzIGZlZWxmdWxhYmFzZTY0IGlzIGZlZWxmdWxhYmFz') == (
        b'this is coolthis is coolthis is cool', 72
    )

# Generated at 2022-06-21 12:23:35.828141
# Unit test for function decode
def test_decode():
    assert decode('QQ==') == ('A', 4)
    assert decode('Qg==') == ('B', 4)
    assert decode('Qw==') == ('C', 4)
    assert decode('RA==') == ('D', 4)
    assert decode('RAI=') == ('DA', 12)
    assert decode('RAI=\n') == ('DA', 12)
    assert decode('RAI=\n\n') == ('DA', 12)
    assert decode('RAI=\n\n\n') == ('DA', 12)
    assert decode('\nRAI=') == ('DA', 12)
    assert decode('\n\nRAI=') == ('DA', 12)
    assert decode('\n\n\nRAI=') == ('DA', 12)

# Generated at 2022-06-21 12:23:46.649460
# Unit test for function decode
def test_decode():
    """Test function decode()."""
    a = b'\xfb\xef'
    b = '-'
    c = '+'
    d = b'\xfb\xef\xbf\xbd\xbf\xbd'
    e = b"\xf6\x96\x94\x93\x86\xfb\xef\xbf\xbd"
    codecs.register(_get_codec_info)
    assert(codecs.decode(a) == ('-', 2))
    assert(codecs.decode(b) == ('-', 1))
    assert(codecs.decode(c) == ('-', 1))
    assert(codecs.decode(d) == ('-', 6))

# Generated at 2022-06-21 12:23:51.236996
# Unit test for function decode
def test_decode():
    # pylint: disable=I0011,protected-access
    assert decode(b'eW91IGhhdmUgdGhpcyB0byBwcmVjYXV0ZQ==') == (
        'you have this to preclude',
        24
    )



# Generated at 2022-06-21 12:23:59.879468
# Unit test for function encode
def test_encode():
    """Test the :func:`encode` function."""

# Generated at 2022-06-21 12:24:04.305523
# Unit test for function decode
def test_decode():
    """Test decode function"""
    expected = '\u001b[34m[\u001b[35m::\u001b[34m]\u001b[0m'
    actual = decode(b'IFtbOjpdXQ==')

    assert actual[0] == expected
    assert actual[1] == len(expected)


# Generated at 2022-06-21 12:24:12.918847
# Unit test for function encode
def test_encode():
    # Fixure Data
    test_data1 = (
        'YW55IGNhcm5hbCBwbGVhcw==',
        b'any carnal pleas')
    test_data2 = (
        '=',
        b'')

    def check(data, expected_bytes, expected_int):
        result = encode(data)
        assert result[0] == expected_bytes, \
            f'{result[0]} {expected_bytes} - {data}'
        assert result[1] == expected_int, \
            f'{result[1]} {expected_int} - {data}'

    # Run test data
    check(test_data1[0], test_data1[1], len(test_data1[0]))

# Generated at 2022-06-21 12:24:19.765683
# Unit test for function decode
def test_decode():
    # Encode the text with 'b64' codec.
    text = 'sometext'
    text_b64 = text.encode('b64')

    # Decode the base64 encoded text.
    text_decoded_bytes = base64.b64decode(text_b64)

    # Decode the base64 encoded text from a str to a bytes
    text_decoded_str = text_b64.decode('b64')

    assert text == text_decoded_str
    assert text.encode('utf-8') == text_decoded_bytes


# Generated at 2022-06-21 12:24:26.174535
# Unit test for function decode
def test_decode():
    """
    Test the decode function by comparing the results to those from the
    python base64 decode function.
    """
    def check(b64_bytes: bytes) -> None:
        """Test function to decode the bytes.

        Args:
            b64_bytes:  bytes encoded as base64
        """
        result, _len = decode(b64_bytes)
        expect = base64.b64decode(b64_bytes)
        result = result.encode('utf-8')
        assert expect == result

    check(b'YQ==')
    check(b'YWI=')
    check(b'YWJj')
    check(b'YWJjZA==')
    check(b'YWJjZGU=')
    check(b'YWJjZGVm')

# Generated at 2022-06-21 12:24:28.354647
# Unit test for function encode
def test_encode():
    assert encode('cm9sbA==') == (b'lorem', 6)



# Generated at 2022-06-21 12:24:33.201909
# Unit test for function encode
def test_encode():
    # pylint: disable=line-too-long
    assert encode('''

aGVsbG8=
    ''') == (b'hello', 22)
    assert encode('''
a
G
Vs
b
G8=
''') == (b'hello', 26)


# Generated at 2022-06-21 12:24:37.666147
# Unit test for function register
def test_register():
    """Test the function register."""

    old_codec_info = codecs.getdecoder(NAME)

    # Delete the function from the codecs's decoders.
    del codecs._decoders[NAME]

    register()

    # Test to see if the codec was registered.
    assert codecs.getdecoder(NAME)

    # Re-register the old codec.
    codecs.register(old_codec_info)



# Generated at 2022-06-21 12:24:43.505285
# Unit test for function register
def test_register():
    """Test the function register()"""
    codecs.register(_get_codec_info)   # type: ignore
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj
    assert obj[0] == decode



# Generated at 2022-06-21 12:24:54.027840
# Unit test for function register
def test_register():
    from base64 import b64encode, b64decode
    from io import BytesIO
    from typing import Optional

    def _test_round_trip(message: _STR) -> None:
        """Perform a round trip test with the given ``message``.

        Test that the given ``message``, when encoded and then
        decoded, returns the original given ``message``.
        """
        with BytesIO() as fp:
            # Use the 'base64.b64encode()' function to generate the
            # 'encoded_bytes' object.  The 'encoded_bytes' object is
            # an object that implements the buffer interface.
            encoded_bytes = b64encode(message.encode('utf-8'))

            # Use the 'fp.write()' function, that expects an object
            # implementing the buffer interface

# Generated at 2022-06-21 12:25:02.190756
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # type: () -> None
    assert encode('') == (b'', 0)

    # Test UnicodeEncodeError is raised
    try:
        encode('++')
    except UnicodeEncodeError as e:
        assert (
            e.reason == 'b64'
            and e.start == 0
            and e.end == 2
            and e.object == '++'
            and e.args[0] == (
                "'++' is not a proper bas64 character string: "
                "binascii.Error('Incorrect padding')"
            )
            and e.args[1:] == ()
        )
    else:
        raise ValueError('pylint: disable=no-else-raise', 'Expected exception')


# Generated at 2022-06-21 12:25:08.262266
# Unit test for function encode
def test_encode():
    from base64 import b64encode

# Generated at 2022-06-21 12:25:11.535628
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


__all__ = [
    'decode',
    'encode',
    'register',
]

# Generated at 2022-06-21 12:25:19.332728
# Unit test for function register
def test_register():
    def test_decode():
        assert codecs.decode('SGkgam9obiBXZWxsbWF0IC4uLiE=\n', NAME) == b'Hi john Wellmat ..!\n'
        assert codecs.decode('aGVsbG8gd29ybGQ=\n', NAME) == b'hello world\n'
        assert codecs.decode('c2F2aW4gYnJvYWQgZ2FyZGNyaXRl\n', NAME) == b'savin broad gardrite\n'

# Generated at 2022-06-21 12:25:28.289468
# Unit test for function encode
def test_encode():
    """Test the encode() function
    """
    # Test with 'text' of type str and of type UserString
    assert encode('dGVzdCBtZXNzYWdl') == (b'test message', 17)
    assert encode(UserString('dGVzdCBtZXNzYWdl')) == (b'test message', 17)

    # Test encoding with a long text
    long_text = ('\n'
                 'ZGVjb2RlIHRleHQKcGF5bG9hZA==')
    assert encode(long_text) == (b'decode text\npayload', 25)

    # Test encoding with a text that spans across many lines
    multi_line_text = ('\tdGVzdCBtZXNzYWdlCg==')

# Generated at 2022-06-21 12:25:39.512058
# Unit test for function encode
def test_encode():
    assert encode("V2UgYXJlIGZvdW5k") == (b"We are fun", 13)
    assert encode("V2UgYXJlIGZvdW5kIGhlcmU=\n") == (b"We are fun here", 20)
    assert encode("V2UgYXJlIGZvdW5kIGhlcmU=\r") == (b"We are fun here", 20)
    assert encode("V2UgYXJlIGZvdW5kIGhlcmU=\r\n") == (b"We are fun here", 20)
    assert encode("V2UgYXJlIGZv\ndW5kIGhlcmU=\n") == (b"We are fun here", 20)


# Generated at 2022-06-21 12:25:50.679132
# Unit test for function decode
def test_decode():
    """Test the function :func:`~b64_codec.b64.decode`."""
    # Normal base64 encode
    result_str, length = decode(b'hello world')
    assert result_str == 'aGVsbG8gd29ybGQ=\n'
    assert length == 11

    # Normal base64 encode with a single byte
    result_str, length = decode(b'a')
    assert result_str == 'YQ==\n'
    assert length == 1

    # Base64 encode with a byte whose value is zero
    result_str, length = decode(b'\x00')
    assert result_str == 'AA==\n'
    assert length == 1

    # Base64 encode with bytes whose value is zero

# Generated at 2022-06-21 12:25:54.705121
# Unit test for function encode
def test_encode():
    assert encode('cw==') == (b'\x05', 4)
    assert encode('\ndm9pY2U=\n') == (b'magic', 8)
    assert encode(
        'Y2hhcmFjdGVyCg=='
    ) == (b'character', 16)
    assert encode('Vm9pY2UK', ) == (b'Voice', 8)

# Generated at 2022-06-21 12:26:07.272335
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8sIFdvcmxk') == (b'Hello, World', 17)
    assert encode(
        '''
        SGVsbG8sIFdvcmxk
        '''
    ) == (b'Hello, World', 19)
    assert encode(
        '''
            SGVsbG8sIFdvcmxk
        '''
    ) == (b'Hello, World', 21)
    assert encode(
        '''
            SGVsbG8s
            IFdvcmxk
        '''
    ) == (b'Hello, World', 23)
    assert encode(
        """
            SGVsbG8sIFdvcmxk
        """
    ) == (b'Hello, World', 23)

# Generated at 2022-06-21 12:26:12.514085
# Unit test for function register
def test_register():
    """
    >>> _get_codec_info('PXE') is None
    True
    >>> register()
    >>> codecs.lookup(NAME) is not None
    True
    """
    pass


# Generated at 2022-06-21 12:26:19.517009
# Unit test for function encode
def test_encode():
    data = '''aaaa
aaaa
bbbb
bbbb
cccc
cccc'''
    data_bytes = bytes(data, encoding='utf-8')
    encoded = b'YWFhYWFhYWFhYmJiYmJiYmJiYmJiY2NjY2NjY2NjY2NjY2NjY2Nj\n'
    assert base64.decodebytes(encoded) == data_bytes
    assert encode(data)[0] == data_bytes


# Generated at 2022-06-21 12:26:31.433615
# Unit test for function encode
def test_encode():
    assert encode('ICdzIHRoaXMgYSBub25uYW1l') == (b'I\'m this a nonname', 25)
    assert encode('IyBhbmQgYWNoaWV2ZW1lbnQh') == (b'# and achievement!', 24)
    assert encode('IyBCb3R0b21saW5lIHN0dWIgc3BvbnNvcnMh') == (b'# Bottomline sub sponsors!', 34)
    assert encode('IEkgYW0gdGhlIGJ1dHRvbiwgSSB0YWtlIElEJ3MgdXBhc3Q=') == (b'I am the button, I take ID\'s upast', 49)

# Generated at 2022-06-21 12:26:36.744406
# Unit test for function decode
def test_decode():
    print('test_decode()')
    register()
    input = b'0123456789'
    output = 'MDEyMzQ1Njc4OQ=='
    actual = codecs.decode(input, 'b64')
    assert actual == output
    print('\nSuccessfully tested function:decode()\n')


# Generated at 2022-06-21 12:26:40.474497
# Unit test for function encode
def test_encode():
    input_string ='aaaaaaaaaaa'
    output_bytes, length = encode(input_string)
    output_bytes_test = b'YWFhYWFhYWFhYWE='
    assert(output_bytes == output_bytes_test)
    assert(length == 11)

# Generated at 2022-06-21 12:26:48.146545
# Unit test for function decode
def test_decode():
    assert(encode("YmFyYmFyYg==\n") == (b"barbar", 11))
    assert(encode("\tYmFyYmFyYg==\n") == (b"barbar", 12))
    assert(encode("YmFyYmFyYg==") == (b"barbar", 10))
    assert(encode("YmFyYmFyYg== \n\n") == (b"barbar", 13))
    assert(encode("YmFyYmFyYg==") == (b"barbar", 10))
    assert(encode("YmFyYmFyYg") == (b"barbar", 9))

# Generated at 2022-06-21 12:26:50.825000
# Unit test for function register
def test_register():
    """Test registration of the b64 codec with Python."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:27:01.298700
# Unit test for function decode
def test_decode():
    import pytest

    def _assert(
            data: _ByteString,
            expected: _STR,
            **kwargs
    ) -> None:
        actual: str
        actual, _ = decode(data=data, **kwargs)
        assert actual == expected

    _assert(data=b'\x00\xff', expected='AA/8=')
    _assert(data=b'\x00\x00\xff\xff', expected='AAAAP8=')
    _assert(data=b'\x00\x00\x00\x00\xff\xff\xff\xff', expected='AAAAAAAARAAA=')
    _assert(data=b'\x3f\x4c\x1f\xc4', expected='/0Yi')

    # Raise a UnicodeEncodeError when the input is not ASCII
   

# Generated at 2022-06-21 12:27:04.395358
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    codecs.lookup(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:27:07.288766
# Unit test for function register
def test_register():
    """Test the interface of ``register()``."""
    register()


# Generated at 2022-06-21 12:27:15.434189
# Unit test for function encode
def test_encode():
    # Test encode function with a valid base64 string
    assert encode('Q2F0ZWdvcnk=')[0] == b'Category'

    # Test encode function with a valid base64 string that spans multiple
    # lines and has whitespace
    assert encode('Cml0\nZWxpbmE=')[0] == b'Russia'

    # Test encode function with an invalid base64 string
    try:
        encode('Cml0ZWxpbm=A')
        assert False
    except UnicodeEncodeError as err:
        assert err.reason == 'b64'
        assert err.object == 'Cml0ZWxpbm=A'
        assert err.start == 0
        assert err.end == len('Cml0ZWxpbm=A')
        assert err.reason == 'b64'
        assert err

# Generated at 2022-06-21 12:27:26.009240
# Unit test for function decode
def test_decode():
    assert decode(b'\x01\x02\x03\x04\x05') == ('AQIDBAU=', 5)
    assert decode(b'\x01\x02\x03\x04', errors='strict') == ('AQIDBA==', 4)
    assert decode(b'0123456789') == ('MDEyMzQ1Njc4OQ==', 10)
    assert decode(b'0123456789', errors='strict') == ('MDEyMzQ1Njc4OQ==', 10)
    assert decode(b'+/==') == ('Kw==', 1)
    assert decode(b'+/==', errors='strict') == ('Lw==', 1)

# Generated at 2022-06-21 12:27:37.997726
# Unit test for function decode
def test_decode():
    test_cases = [
        '',
        'Test',
        'test',
        'Test\n',
        'test\n',
        '\n',
        'Test\ntest\n',
        '\n',
        '\tTest\n',
        '  \n',
        '  ',
        '  Test  ',
        '  Test',
        'Test  ',
        '  Test  \n',
        '  Test  \n\t',
        '\n',
        '\t\n',
        '\t\t',
        '\t\t\n',
        '\t',
        '\t\n\t',
    ]

# Generated at 2022-06-21 12:27:46.856395
# Unit test for function register
def test_register():
    """Unit test for the function :func:`~register`."""
    import codecs

    # Test to verify that the 'b64' codec has already been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "The b64 codec doesn't appear to have been registered"

    # Now, unregister the b64 codec, if it is registered, and then register
    # it again, and then test to verify that the 'b64' codec has been
    # registered.
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        codecs.lookup(NAME).encode('abc')  # type: ignore
        codecs.lookup(NAME).decode(b'YWJj')  # type: ignore

   

# Generated at 2022-06-21 12:27:58.958113
# Unit test for function decode
def test_decode():
    # Decode the test string into bytes, then decode the bytes into b64
    # characters and then base64 decode the b64 characters.
    # If the re-encoding produces the same bytes then everything is good.
    test_string = (
        u'Man is distinguished, not only by his reason, but by this '
        u'singular passion from other animals, which is a lust of the '
        u'mind, that by a perseverance of delight in the continued and '
        u'indefatigable generation of knowledge, exceeds the short '
        u'veritues of the most violent pasion.'
    )
    test_bytes = codecs.encode(test_string, 'utf-8')
    test_b64_string = codecs.encode(test_bytes, 'b64').decode('ascii')
    test_re

# Generated at 2022-06-21 12:28:07.298055
# Unit test for function decode
def test_decode():
    # Testing when the given data is empty
    assert decode(data=bytes(), errors='strict') == ('', 0)

    # Testing when the given data is not empty
    data_test = 'Maria is the best person in the world'
    data_test_encoded = 'TWFyaWEgaXMgdGhlIGJlc3QgcGVyc29uIGluIHRoZSB3b3JsZA=='
    assert decode(data=data_test.encode(), errors='strict') == \
           (data_test_encoded, len(data_test))



# Generated at 2022-06-21 12:28:10.190543
# Unit test for function decode
def test_decode():
    data = codecs.decode('b64')
    assert data == 'dGVzdA=='

# Generated at 2022-06-21 12:28:19.384401
# Unit test for function register
def test_register():
    """Test the function register()"""
    import copy
    import sys

    # Save a working copy of the encoding/decoding functions and
    # restore them at the end of the test.
    tmp = {
        'encode': encode,
        'decode': decode,
        'codec_info': codecs.lookup('b64')
    }

    register()
    assert tmp['encode'] == codecs.lookup('b64').encode
    assert tmp['decode'] == codecs.lookup('b64').decode
    assert tmp['codec_info'].name == 'b64'

    # Remove the test codec before reloading.  This prevents an error
    # message from Python.
    sys.modules.pop('b64', None)
    sys.modules.pop('b64.b64', None)
   

# Generated at 2022-06-21 12:28:26.061369
# Unit test for function decode
def test_decode():
    test_data = ["12345","1234567890", "aBcD"]
    for test in test_data:
        decode_func = decode(test.encode("utf-8"))
        decode_base64 = base64.b64encode(test.encode("utf-8"))        
        assert decode_func[0] == decode_base64.decode("utf-8")


# Generated at 2022-06-21 12:28:40.821911
# Unit test for function encode
def test_encode():
    """Unit tests for the ``encode`` function."""
    examples = [  # type: ignore[var-annotated]
        ('TWFu', ),
        ('IcOg', ),
        ('TWFu\nIcOg\n', ),
        ('TWFu\nIcOg\nRm9v', ),
        ('\nTWFu\nIcOg\nRm9v\n\n', ),
    ]

    for (i, given) in enumerate(examples):
        text, = given
        out, _ = encode(text)
        expected = b'Man'

# Generated at 2022-06-21 12:28:41.677579
# Unit test for function register
def test_register():
    import doctest  # type: ignore
    doctest.testmod()

# Generated at 2022-06-21 12:28:46.420681
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'ZmluZSBKb2huIENhdmVsbG93IGluIHRoZSB3YXJtZWQgZG9vci4=') == \
        ('find John Cavalier in the warmed door.', 40)



# Generated at 2022-06-21 12:28:58.309974
# Unit test for function encode
def test_encode():
    text = "I am a string of text."
    expected = "SSBhbSBhIHN0cmluZyBvZiB0ZXh0Lg=="
    result, consumed = encode(text)
    assert consumed == len(text)
    assert result.decode('utf-8') == expected
    assert encode("")[0].decode('utf-8') == ""
    assert encode("\n\t")[0].decode('utf-8') == ""
    assert encode("aGVsbG8=")[0].decode('utf-8') == "hello"
    assert encode("aGVsbG8=\naGVsbG8=")[0].decode('utf-8') == "hellohello"

# Generated at 2022-06-21 12:29:01.698310
# Unit test for function decode
def test_decode():
    bytes_input = bytearray(b'\x80')
    input_text = 'gIGC'
    test_result, bytes_consumed = decode(bytes_input)
    assert input_text == test_result
    assert 1 == bytes_consumed


# Generated at 2022-06-21 12:29:10.926818
# Unit test for function decode
def test_decode():
    """Unit tests for function decode"""
    assert 'YQ==' == decode(b'a')[0]
    assert 'YWI=' == decode(b'ab')[0]
    assert 'YWJj' == decode(b'abc')[0]
    assert 'YWJjZA==' == decode(b'abcd')[0]
    assert 'YWJjZGU=' == decode(b'abcde')[0]
    assert 'YWJjZGVm' == decode(b'abcdef')[0]
    assert 'YWJjZGVmZw==' == decode(b'abcdefg')[0]
    assert 'YWJjZGVmZ2g=' == decode(b'abcdefgh')[0]

# Generated at 2022-06-21 12:29:21.674364
# Unit test for function decode

# Generated at 2022-06-21 12:29:25.429875
# Unit test for function decode
def test_decode():
    """Unit test for the ``decode`` functionality."""
    assert decode(b'hello world')[0] == 'aGVsbG8gd29ybGQ=\n'
    assert decode(b'hello world')[1] == 11



# Generated at 2022-06-21 12:29:33.248274
# Unit test for function encode
def test_encode():
    try:
        codec = codecs.getencoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        codec = codecs.getencoder(NAME)    # type: ignore

    # Test encode

# Generated at 2022-06-21 12:29:43.370431
# Unit test for function register
def test_register():
    _func_name = __name__ + '.' + register.__name__ + '():'
    try:
        import codecs

        codecs.getdecoder(NAME)
    except LookupError:
        register()
        import codecs

        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise AssertionError(_func_name +
                'Failed to register {} codec.'.format(NAME))
    else:
        # If no LookupError is raised, then the codec has already been
        # registered.
        # So, don't try to register it again.
        pass
    return True


if __name__ == '__main__':
    # Unit test the module.
    import sys

    print(__doc__)

# Generated at 2022-06-21 12:29:58.067236
# Unit test for function encode
def test_encode():
    """Test base64.b64decode()."""
    test_string = 'YW55IGNhcm5hbCBwbGVhc3VyZS4='
    clean = ''.join(test_string.split())
    assert base64.decodebytes(test_string.encode('utf-8')).decode('utf-8') == 'any carnal pleasure.'
    assert encode(test_string)[0].decode('utf-8') == 'any carnal pleasure.'
    assert encode('\n'.join(test_string.split()))[0].decode('utf-8') == 'any carnal pleasure.'
    assert encode(clean)[0].decode('utf-8') == 'any carnal pleasure.'

# Generated at 2022-06-21 12:30:02.173142
# Unit test for function register
def test_register():
    """Unit test for the function register"""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-21 12:30:05.534322
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None


# Generated at 2022-06-21 12:30:07.948670
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 12:30:15.586369
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n ') == (b'', 0)
    assert encode('   \n ') == (b'', 0)
    assert encode('Zg==  ') == (b'f', 4)
    assert encode('aA==\n') == (b'Z', 4)
    assert encode('zk42\n') == (b'\xfbB', 4)

    with pytest.raises(UnicodeEncodeError):
        encode('zk42-')



# Generated at 2022-06-21 12:30:25.055379
# Unit test for function encode
def test_encode():
    """Test that the function encode works as expected."""
    # Use the test string specified in PEP-263
    raw_string = (
        "The quick brown fox jumps over the lazy dog, "
        "Pack my box with five dozen liquor jugs."
    )

    # Encoded bytes of the raw string
    encoded_bytes = b'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZywgUGFjayBteSBib3ggd2l0aCBmaXZlIGRvemVuIGxpcXVvciBqdWdzLg=='

    # Encode the raw string
    text_str = raw_string

# Generated at 2022-06-21 12:30:31.150467
# Unit test for function encode
def test_encode():
    assert encode('c3VyZS4=') == (b'sure.', 8)
    assert encode('c3VyZS4') == (b'sure.', 7)
    assert encode('c3VyZQ') == (b'sure', 6)
    assert encode('c3Vy') == (b'sur', 4)
    assert encode('cw==') == (b'\xfc', 4)
    assert encode('c3VyZQ') == (b'sure', 6)
    assert encode('c3VyZS4') == (b'sure.', 7)
    assert encode('c3VyZS4=') == (b'sure.', 8)



# Generated at 2022-06-21 12:30:42.008909
# Unit test for function encode
def test_encode():
    # Test a one line base64 string that has been indented.
    result = encode(u'\t\t4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI')
    expected = (b'\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10', 39)
    assert result == expected

    # Test a one line that is not indented.
    result = encode(u'4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI4xi0mI')

# Generated at 2022-06-21 12:30:52.060713
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import unittest

    try:
        # Remove the existing b64 codec
        codecs.lookup(NAME)
        del(sys.modules[__name__])
        # Load the b64 module
        globals()['codecs'] = __import__('codecs')
        sys.modules[__name__] = globals()
        # Re-register the b64 codec
        register()
    except LookupError as e:
        # If the codec has not been previously registered, then just
        # register it.
        register()

    class MockData(object):
        """Mock Data"""

        def __repr__(self):
            """Return the value for b64."""
            return 'b64'

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 12:30:55.154488
# Unit test for function register
def test_register():
    register()
    assert decode('MQ==') == ('1', 3)

# Generated at 2022-06-21 12:31:16.487283
# Unit test for function encode
def test_encode():
    assert encode('Zm9vYmFy') == (b'foobar', len('Zm9vYmFy'))
    assert encode('Zm9vYmFyCg==') == (b'foobar', len('Zm9vYmFy\n'))
    assert encode('Zm9vYmFyCg==\n') == (b'foobar', len('Zm9vYmFy\n'))
    assert encode('Zm9vYmFyCg==\n\n') == (b'foobar', len('Zm9vYmFy\n'))
    assert encode('Zm9vYmFyCg==\n\n\n') == (b'foobar', len('Zm9vYmFy\n'))

# Generated at 2022-06-21 12:31:20.171118
# Unit test for function encode
def test_encode():
    assert encode("Zm9vYmFy") == b'foobar'
    assert encode("Zm9vYg==") == b'foo'
    assert encode("Zm9v") == b'fo'


# Generated at 2022-06-21 12:31:23.343218
# Unit test for function decode
def test_decode():
    # pylint: disable=I0011,C0103,W0613,E0611
    from .tests import test_codecs
    test_codecs.test_decode(NAME)



# Generated at 2022-06-21 12:31:26.231236
# Unit test for function decode
def test_decode():
    input = b'\x00\x01\x02'
    expected = 'AAEC'
    actual = decode(input)[0]
    assert expected == actual



# Generated at 2022-06-21 12:31:27.849159
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)

# Generated at 2022-06-21 12:31:34.676450
# Unit test for function encode
def test_encode():
    input_string = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    output_bytes, length = encode(input_string)
    expected_output_bytes = b'abcdefghijklmnopqrstuvwxyz'
    assert output_bytes == expected_output_bytes
    assert length == len(input_string)

if __name__ == '__main__':
    test_encode()
    print('All Tests passed')

# Generated at 2022-06-21 12:31:44.567348
# Unit test for function decode
def test_decode():
    result = decode(bytes())
    assert result == ('', 0)

    result = decode(bytes(range(256)))

# Generated at 2022-06-21 12:31:56.048374
# Unit test for function encode

# Generated at 2022-06-21 12:32:03.576656
# Unit test for function encode
def test_encode():
    # Basic Test
    assert encode(b'YQ==')[0] == b'a'
    # Strip whitespace
    assert encode(b'Y\nQ\t==')[0] == b'a'
    # Strip Indent
    assert encode(b'   YQ===')[0] == b'a'

    # Cleanup whitespace
    assert encode(b'\n   Y\nQ\t==\t')[0] == b'a'



# Generated at 2022-06-21 12:32:09.206094
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gV29ybGQ=') == (b'hello World', 16)
    assert encode('YmFzZTY0IGVuY29kaW5n') == (b'base64 encoding', 18)

    assert encode('FACE') == (b'\xfa\xce', 4)
    assert encode('/w==') == (b'\x2f', 1)
    assert encode('//8=') == (b'\x2f\x80', 2)
    assert encode('////') == (b'\x2f\x2f\x2f', 3)

    assert encode('/////w==') == (b'\x2f\x2f\x2f\x2f\x80', 5)



# Generated at 2022-06-21 12:32:42.732689
# Unit test for function register
def test_register():
    """Unit test for register function."""
    import base64
    import codecs

    assert codecs.lookup_error('b64') is UnicodeEncodeError \
        and codecs.lookup_error('b64_codec') is UnicodeEncodeError
    register()
    assert codecs.lookup_error('b64') is UnicodeEncodeError \
        and codecs.lookup_error('b64_codec') is UnicodeEncodeError

