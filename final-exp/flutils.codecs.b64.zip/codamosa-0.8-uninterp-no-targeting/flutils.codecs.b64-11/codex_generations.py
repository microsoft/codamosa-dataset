

# Generated at 2022-06-21 12:22:36.231472
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""

    with open('test.txt', 'rb') as f:
        _ = f.read()

    data = open('test.txt', 'rb').read()
    data_str, _ = decode(data)


# Generated at 2022-06-21 12:22:43.821815
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 13)
    try:
        encode('aGVsbG8gd29ybGQ')
    except UnicodeEncodeError as e:
        assert str(e) == (
            "b64 'hello world' is not a proper bas64 character string: "
            "Incorrect padding"
        )
    else:
        raise AssertionError('No error raised expected.')

register()

if __name__ == '__main__':
    test_encode()

# Generated at 2022-06-21 12:22:48.098752
# Unit test for function register
def test_register():
    # Do test only if not already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        decoder = codecs.getdecoder(NAME)
        assert decoder
        assert len(decoder) == 2

# Generated at 2022-06-21 12:22:49.488865
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    codecs.lookup(NAME)

# Generated at 2022-06-21 12:22:50.338377
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-21 12:22:58.820642
# Unit test for function decode
def test_decode():
    """Unit test for function :func:`decode`"""
    register()

    # Perform a base64 decode of the 'test_data' that is given.
    # The 'encoded_bytes' is the result of the base64 encoding of
    # byte array 'test_data_bytes'
    encoded_bytes = (
        b'VGhpcyBpcyB0aGUgc3RyaW5nIGNvbnRhaW5pbmcgYmFzZTY0\r\n'
        b'IENoYXJhY3RlcnM=\r\n'
    )   # type: bytes

    # The 'test_data_bytes' is the byte array of the string to be decoded.
    test_data_bytes = (
        b'This is the string containing base64 Characters'
    )  

# Generated at 2022-06-21 12:23:04.487046
# Unit test for function encode
def test_encode():
    input_text = "dGhpcyBpcyBhIHRlc3Q="
    correct = b"this is a test"
    output_bytes, output_num_bytes = encode(input_text)
    assert output_bytes == correct
    assert output_num_bytes == len(input_text)



# Generated at 2022-06-21 12:23:15.385226
# Unit test for function encode
def test_encode():
    # Test case 1
    expected_bytes = b'\xd5\xccV\xba\x8a\xce\x9f\x1c\x8d\n\x8c%\x7f2\x00u\x13\x9c\x1e'
    expected_length = 27
    case_input = 'w65iWpk8RkIjX04uXlVzZW5oYXQ='
    result_bytes, result_length = encode(case_input)
    assert result_bytes == expected_bytes
    assert result_length == expected_length

    # Test case 2

# Generated at 2022-06-21 12:23:25.074710
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode()``."""
    from os import path
    from pprint import pprint
    from sys import modules
    from typing import Any
    from unittest import main
    from unittest import TestCase
    from unittest.mock import patch

    # Get the location of this file.
    this_module = modules[__name__]
    this_file = path.abspath(this_module.__file__)
    this_dir = path.dirname(this_file)

    # Get the directory where the test files are located.
    test_dir = path.join(this_dir, 'test_files')

    # Create a function to get the contents of test files.
    # noinspection PyUnusedLocal

# Generated at 2022-06-21 12:23:33.257434
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhc3VyZQ==', 'strict') == (b'any carnal pleasure', 24)
    assert encode('YW55IGNhcm5hbCBwbGVhc3VyZQ==\n', 'strict') == (b'any carnal pleasure', 24)
    assert encode('\t\tYW55IGNhcm5hbCBwbGVhc3VyZQ==\n\t', 'strict') == (b'any carnal pleasure', 24)



# Generated at 2022-06-21 12:23:37.440503
# Unit test for function encode
def test_encode():
    encoded_bytes, _consumed = encode(
        "SGVsbG8gV29ybGQhCg==\n",
    )
    assert 3 == _consumed
    assert encoded_bytes == b'Hello World!'



# Generated at 2022-06-21 12:23:39.589003
# Unit test for function register
def test_register():
    """Test the :func:`register` function."""
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-21 12:23:42.608697
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-21 12:23:46.851303
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(
            f'{NAME} is not a registered codec'
        )

# Generated at 2022-06-21 12:23:48.155988
# Unit test for function register
def test_register():
    """Test the function register"""
    register()

# Generated at 2022-06-21 12:23:51.836144
# Unit test for function encode
def test_encode():
    expected_str = 'eyJ0aXRsZSI6InRoaXMgaXMgYSB0ZXN0In0='

    assert encode('{"title":"this is a test"}')[0] == expected_str.encode()


# Generated at 2022-06-21 12:23:55.072584
# Unit test for function register
def test_register():
    # pylint: disable=protected-access
    register()
    assert NAME in codecs.__all__  # pylint: disable=no-member
    assert NAME in codecs._cache   # pylint: disable=no-member



# Generated at 2022-06-21 12:24:03.225827
# Unit test for function decode
def test_decode():
    result = decode("A")[0]
    assert result == "QQ=="
    result = decode("AB")[0]
    assert result == "QUI="
    result = decode("ABC")[0]
    assert result == "QUJD"
    result = decode("ABCD")[0]
    assert result == "QUJDRA=="
    result = decode("ABCDE")[0]
    assert result == "QUJDREU="
    result = decode("ABCDEF")[0]
    assert result == "QUJDREVG"

    # Unit test for function encode

# Generated at 2022-06-21 12:24:11.967321
# Unit test for function encode
def test_encode():
    assert encode("SGVsbG8gV29ybGQ=") == (b"Hello World", 14)
    assert encode("QQ==") == (b"A", 3)
    assert encode("BFk=") == (b"_Z", 4)
    assert encode("CnIn") == (b"-i", 4)
    assert encode("DQQD") == (b"4A=", 4)
    # Test that incorrect base64 character strings fail
    try:
        encode("SGVsbG8gV29ybGQ")
        raise RuntimeError("Abnormal Success Test!")
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-21 12:24:13.209148
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:24:22.374079
# Unit test for function decode
def test_decode():
    """Test :func:`~pyutil.encoders.b64.decode` function."""

    # Test: cannot decode an empty string.
    with pytest.raises(UnicodeDecodeError):
        decode(b'')

    # Test: cannot decode a string of non-base64 bytes.
    with pytest.raises(UnicodeDecodeError):
        decode(b'0123456789')

    # Test: can decode a string of base64 bytes.
    assert decode(b'ABCD') == ('QuRB', 4)

    # Test: can decode a string of base64 characters.
    text = (
        'QuRB'
    )
    assert decode(
        text.encode('utf-8')
    ) == (text, len(text))


# Generated at 2022-06-21 12:24:29.151967
# Unit test for function register
def test_register():
    """Test function register()."""
    codecs.register(_get_codec_info)
    text_str = str(
        'eWVhaFdvcmxk'
    )
    text_bytes = text_str.encode(NAME)
    text_decoded = text_bytes.decode('b64')
    assert text_decoded == 'yeahWorld'
    assert text_bytes == b'\xab\xcd\xef'

# Generated at 2022-06-21 12:24:38.448348
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""

    def _check(
            text: _STR,
            expected: _STR,
    ):
        encoded, len_encoded = encode(text)
        assert len_encoded == len(text)
        assert len(encoded) == len(expected)
        assert encoded == expected
        assert encoded.decode('utf-8') == expected.decode('utf-8')

        # Convert the given 'text', that are of type UserString into a str.
        text_input = text if isinstance(text, str) else str(text)
        # Cleanup whitespace.
        text_str = text_input.strip()

# Generated at 2022-06-21 12:24:43.605798
# Unit test for function encode
def test_encode():
    assert encode(
        '''
        UmVhc29uX2lzX2V2ZW5fbGF0ZXJfdGhhbl9saWZl
        '''
    ) == (
        b'Reason_is_even_later_than_life', 28
    )



# Generated at 2022-06-21 12:24:44.940975
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-21 12:24:49.333601
# Unit test for function register
def test_register():
    """Unit test of the register() function.

    The register() function can only be tested by isolation.  Its
    execution must not be influenced by any other factors.
    """
    codecs.add(NAME, None, None, None)
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:24:53.739388
# Unit test for function decode
def test_decode():
    data = 'test string'
    data_bytes = data.encode('utf-8')
    enc_bytes = base64.b64encode(data_bytes)
    enc_str = enc_bytes.decode('utf-8')
    actual = decode(data_bytes)
    assert actual[0] == enc_str


# Generated at 2022-06-21 12:24:54.979749
# Unit test for function register
def test_register():
    """Test the :func:`register` function."""
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:24:58.870782
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'b64 codec not registered'
    else:
        assert True


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:25:01.096509
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()

    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-21 12:25:15.484622
# Unit test for function decode
def test_decode():
    codec = codecs.getdecoder(NAME)  # type: ignore[attr-defined]
    # Test the encode method works.
    test_data = b'\xc4\xa4\xc4\xab\xc4\xbc\xc4\x9f\xc4\x97'
    data_out = codec(test_data)[0]
    assert data_out == 'w6XDn8O8w6g='
    assert codec(test_data, 'ignore')[0] == data_out
    assert codec(test_data, 'replace')[0] == data_out
    try:
        codec(test_data, 'strict')[0]
    except UnicodeEncodeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 12:25:24.093064
# Unit test for function encode
def test_encode():
    """Tests the encode function in ``b64.py``."""
    # noinspection SpellCheckingInspection
    assert encode('bGFzdA==') == (b'las', 4)
    # noinspection SpellCheckingInspection
    assert encode('bGFzdCBob25nIGZpbmFs') == (b'last long final', 20)
    # noinspection SpellCheckingInspection
    assert encode('bGFzdCBob25nIGZpbmFs\n') == (b'last long final', 20)
    # noinspection SpellCheckingInspection
    assert encode('bGFzdCBsb25nIGZpbmFs')\
        == (b'last long final', 20)



# Generated at 2022-06-21 12:25:27.196674
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__['_cache'].keys()
    register()
    assert NAME in codecs.__dict__['_cache'].keys()
    codecs.lookup(NAME)
    return True

register()

# Generated at 2022-06-21 12:25:31.816723
# Unit test for function encode
def test_encode():
    input: _STR = textwrap.dedent("""\
        aGVsbG8gd29ybGQ=
    """)
    out, count = encode(input)
    assert count == len(input)
    assert out == b'hello world'



# Generated at 2022-06-21 12:25:34.592296
# Unit test for function encode
def test_encode():
    assert encode("aGVsbG8gdGVzdA==\n") == (b'hello test', 14)


# Generated at 2022-06-21 12:25:44.596723
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test to ensure that encode will raise an exception given invalid
    # base64 characters.
    try:
        assert encode('ü') == b'f'
    except UnicodeEncodeError:
        pass

    # Test to ensure that encode will stripe the unicode spaces and
    # decode the given base64 character string.
    assert encode(b'  aGVsbG8gd29ybGQ=  ') == b'hello world'

    # Test to ensure that encode will stripe the unicode spaces and
    # decode the given base64 character string.
    assert encode('aGVsbG8gd29ybGQ=') == b'hello world'

    # Test to ensure that encode will stripe the unicode spaces and
    # decode the given base64 character string.

# Generated at 2022-06-21 12:25:46.450224
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-21 12:25:49.958566
# Unit test for function decode
def test_decode():
    # Arrange
    data = b'\x1b\x12Hi\xff'
    # Act
    try:
        decoded_data = decode(data)
    # Assert
    except UnicodeEncodeError:
        assert False



# Generated at 2022-06-21 12:25:56.010320
# Unit test for function encode
def test_encode():
    """Set up a dummy test to check if the encoder works"""
    input_str = 'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZy4='
    input_utf8 = input_str.encode('utf-8')
    output = encode(input_str)
    assert input_utf8 == output[0]

# Generated at 2022-06-21 12:26:07.118172
# Unit test for function decode
def test_decode():
    out_str, out_len = decode(
        data=bytes([
            0x08, 0x04, 0x47, 0x1D, 0xB7, 0xCA, 0x8C, 0xF2, 0xD2, 0x6E,
            0x89, 0xF6, 0x8F, 0xD2, 0x1E, 0xF8, 0xAB, 0x7E, 0xCA, 0xB9,
            0x7D, 0x13, 0x01, 0xD2, 0x0F, 0xA5, 0x5A, 0xA5, 0x38, 0xD4,
        ]),
    )

# Generated at 2022-06-21 12:26:23.719772
# Unit test for function register
def test_register():
    from base64 import b64encode  # noqa: F401,E402

    value = 42
    value_bytes = bytes(value)
    value_str = b64encode(value_bytes).decode('utf-8')

    # The 'b64' codec isn't registered yet.
    try:
        some_value = value.to_bytes(1, 'big').decode('b64')
    except LookupError:
        assert True
    else:
        assert False, f'{some_value!r} matches {value_str!r}'

    # Register the 'b64' codec and try again
    register()

    some_value = value.to_bytes(1, 'big').decode('b64')

# Generated at 2022-06-21 12:26:35.676128
# Unit test for function decode
def test_decode():
    assert decode(b'AQAB') == ('AQAB', 4)
    assert decode(b'AQ==') == ('AQ==', 4)
    assert decode(b'AQAB\n') == ('AQAB', 4)
    assert decode(b'AQAB\r\n') == ('AQAB', 4)
    assert decode(b'AQAB  ') == ('AQAB', 4)
    assert decode(b'AQAB\t') == ('AQAB', 4)
    assert decode(b'AQAB  \t') == ('AQAB', 4)
    assert decode(b'AQAB  \n') == ('AQAB', 4)
    assert decode(b'A\nQAB\n') == ('A\nQAB', 5)

# Generated at 2022-06-21 12:26:43.776893
# Unit test for function encode
def test_encode():
    text = """
    aGVsbG8sIGNsb3VkIVxu
    VG9vIGxvbmcgdG8gZGlz
    YWJsZSB0aGUgZmlyc3Qg
    c2VjdGlvbiBvZiB0aGlz
    IHN0cmluZ1xuXG5Mb25n
    IHN0cmluZyBpbiB0aGUg
    c2Vjb25kIHNlY3Rpb24u
    """
    out, length = encode(text)
    print(out)
    print(length)


# Generated at 2022-06-21 12:26:48.644263
# Unit test for function register
def test_register():
    from unittest import TestCase

    class TestRegister(TestCase):
        """Test for function register."""

        def test_register(self):
            """Test for function register.
            """
            register()
            try:
                codecs.getencoder(NAME)
                codecs.getdecoder(NAME)
            except LookupError:
                self.fail()

    test_register.__doc__ = test_register.__doc__

    # Run the unit test
    from unittest import main
    main(__name__, verbosity=2, exit=False)

# Generated at 2022-06-21 12:26:51.653053
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-21 12:26:56.033691
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    decoder = codecs.getdecoder(NAME)   # type: ignore
    assert decoder
    encoder = codecs.getencoder(NAME)   # type: ignore
    assert encoder



# Generated at 2022-06-21 12:27:00.737507
# Unit test for function register
def test_register():
    # Get the list of codecs that are registered with Python
    codecs_registered = codecs.__all__  # type: ignore
    codecs_registered = [f'{c[0]}_' for c in codecs_registered]
    assert f'{NAME}_' not in codecs_registered

    # Register this codec with Python.
    register()

    # Verify th

# Generated at 2022-06-21 12:27:06.522318
# Unit test for function encode
def test_encode():
    """Test that :func:`encode` works properly."""
    err_msg = "encode failed"
    assert encode("")[0] == b""
    assert encode("b2Fzaw==")[0] == "oasw".encode("utf-8")
    assert encode("b2Fzaw==\n")[0] == "oasw".encode("utf-8")
    assert encode("one\nthree")[0] == "onet\nhr\x03".encode("utf-8")
    assert encode("one\nthree\n")[0] == "onet\nhr\x03".encode("utf-8")
    assert encode("one three")[0] == "onet three".encode("utf-8")

# Generated at 2022-06-21 12:27:14.384310
# Unit test for function register
def test_register():
    """Test the :func:`register` function."""
    pass


if __name__ == '__main__':
    register()
    if len(sys.argv) > 1:
        print(sys.argv[1].encode('b64'))
    else:
        usr = 'YWJjZGVmZ2hpamtsbW5vcA==\n'
        usr += 'bXJzdHV2d3h5enw=\n'
        usr += 'eHh4eHh4eHh4eHg=\n'
        usr += '='
        print(usr)
        print(usr.encode('utf-8').decode('b64'))

# Generated at 2022-06-21 12:27:17.080310
# Unit test for function register
def test_register():
    """Test the 'register' function."""
    register()
    codecs.getdecoder(NAME)


# Unit tests for the functions above

# Generated at 2022-06-21 12:27:41.007825
# Unit test for function encode
def test_encode():
    assert encode('QQ==', 'strict') == (b"\x01", 4), 'Encoded with 1 byte error'
    assert encode('Ag==', 'strict') == (b"\x11", 4), 'Encoded with 1 byte error'
    assert encode('Og==', 'strict') == (b"\x61", 4), 'Encoded with 1 byte error'
    assert encode('QUJD', 'strict') == (b'\x01\x02\x03', 4), 'Encoded with 3 bytes error'
    assert encode('VGVzdA==', 'strict') == (b'Test', 8), 'Encoded with 4 bytes error'
    assert encode('VGVzdA', 'strict') == (b'Test', 6), 'Encoded with 3 bytes error'

# Generated at 2022-06-21 12:27:54.256793
# Unit test for function decode
def test_decode():
    """Test the function decode"""

    # Test case: empty string
    # Expected: empty string
    assert decode(b'') == ('', 0)
    # Test case: two empty strings
    # Expected: empty string
    assert decode(b'\n\n') == ('', 2)
    # Test case: two empty strings
    # Expected: empty string
    assert decode(b' \n \n') == ('', 4)
    # Test case: one space
    # Expected: one space
    assert decode(b' ') == ('', 1)
    # Test case: one space indented
    # Expected: one space
    assert decode(b'  ') == ('', 2)
    # Test case: one space indented
    # Expected: one space

# Generated at 2022-06-21 12:28:06.222403
# Unit test for function register
def test_register():
    """
    Test the function register
    """
    # noinspection PyUnusedLocal
    def _noop(*args, **kwargs):
        """
        This function is a noop.
        """
        pass

    # noinspection PyUnusedLocal
    def _raise_exception(*args, **kwargs):
        """
        This function raises an exception.
        """
        raise Exception()

    # Disable the register function.
    old_reg_fun = codecs.register
    codecs.register = _noop

    # Ensure that we start out with the codec not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Re-enable the register function.
    codecs.register = old_reg_fun

    # Register the codec.
    register()

   

# Generated at 2022-06-21 12:28:17.632471
# Unit test for function decode
def test_decode():
    from textwrap import dedent
    from collections import UserString

    # The 'data' argument is of type bytes.
    data = b'Hello World!'

    # The 'errors' argument is of type 'UserString'.
    errors = UserString('strict')

    # Call the 'decode' function.
    out, consumed = decode(data, errors)

    # The type of the 'out' is 'str'.
    assert isinstance(out, str)

    # The 'out' string should equal the base64 decoded string.
    assert out == 'SGVsbG8gV29ybGQh'

    # The length of the bytes input should equal the 'consumed' value
    assert len(data) == consumed

    # The 'data' argument is of type bytes.

# Generated at 2022-06-21 12:28:28.821761
# Unit test for function decode
def test_decode():
    """Test the decode function for expected results."""
    cases = [
        ('YQ==', 'a'),
        ('YWI=', 'ab'),
        ('YWJj', 'abc'),
        ('YWJjZA==', 'abcd'),
        (
            'YmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MA==',
            'abcdefghijklmnopqrstuvwxyz0'
        ),
        ('LVRoIGZpcnN0IHN1Y2Nlc3M=', '-Th first success'),
        ('VGhlIGZpcnN0IHN1Y2Nlc3M=', 'The first success'),
    ]


# Generated at 2022-06-21 12:28:40.424993
# Unit test for function register
def test_register():
    """Unit tests for function register."""
    from sys import modules
    from os import path

    # Get this file's directory
    this_dir = path.dirname(path.realpath(__file__))

    # Create an encoding map
    encoding_map = {
        'b64': NAME,
        'base64': NAME
    }

    # Create a module
    this_module = type(modules[__name__])(__name__)

    # Add the encoding map to the module
    this_module.register_error('b64_decode', encoding_map)

    # Add the modules to the current python instance
    modules[__name__] = this_module

    # Load the b64 module into the current python instance
    # NOTE: This is the reason for this unit test

# Generated at 2022-06-21 12:28:41.978276
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-21 12:28:43.983694
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-21 12:28:45.153271
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)



# Generated at 2022-06-21 12:28:53.405038
# Unit test for function register
def test_register():
    """This function is used to verify the codec is registered properly.

    This test is to ensure the codec is registered, but this is a black box test.
    This function, only verifies that the ``register`` function didn't throw an
    exception, but it can't verify that the codec was actually registered.
    """
    register()


if __name__ == '__main__':
    # Run unit tests from the command line.  If a unit test fails,
    # raise SystemExit and the unit test output will be shown.
    import unittest
    unittest.main()

# Generated at 2022-06-21 12:29:23.376490
# Unit test for function decode
def test_decode():   # type: ignore
    """Check the :meth:`decode` function."""
    from . import B64_CHAR_STR
    assert decode(B64_CHAR_STR.encode('utf-8')) == (B64_CHAR_STR, len(B64_CHAR_STR))


# Generated at 2022-06-21 12:29:31.962448
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)

# Generated at 2022-06-21 12:29:35.257023
# Unit test for function register
def test_register():
    """Test to register the codec."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-21 12:29:38.866458
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('TmljayAoRXRvb2Q=') == (b'Micky (Etood)', 12)


# Generated at 2022-06-21 12:29:39.767192
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-21 12:29:48.225292
# Unit test for function decode
def test_decode():
    data1 = b'jshdkfhjksahflkjshdfkjshdkfhjksahflkjshdfkjshdkfhjksahflkjshdf'
    sdata1, _  = decode(data1)
    assert sdata1 == ('anNoa2hhZGtmaGprc2FoZmxramhkZmtqaHNpZGtmaGprc2FoZmxramhkZmtq'
                      'aHNpZGtmaGprc2FoZmxramhkZmtq')
    data2 = b'jshdkfhjksahflkjshdfkjshdkfhjksahflkjshdfkjshdkfhjksahflkjshdf\n'
    sdata2, _  = decode(data2)

# Generated at 2022-06-21 12:29:57.452055
# Unit test for function decode
def test_decode():

    from typing import List
    from typing import Tuple


# Generated at 2022-06-21 12:30:05.033168
# Unit test for function decode
def test_decode():
    """Test the function 'decode'."""
    # Decode 255 0 to 3F F
    test_bytes = b'\xFF'
    result_str, _ = decode(test_bytes)
    assert result_str == '//8='

    test_bytes = b'\x0C'
    result_str, _ = decode(test_bytes)
    assert result_str == 'DQ=='

    # Decode 255 254 to ZmY=
    test_bytes = b'\xFF\xFE'
    result_str, _ = decode(test_bytes)
    assert result_str == '////'

    test_bytes = b'\x0C\x0D'
    result_str, _ = decode(test_bytes)
    assert result_str == 'EQ0Q'

    # Decode 255 254

# Generated at 2022-06-21 12:30:14.736497
# Unit test for function encode

# Generated at 2022-06-21 12:30:18.958901
# Unit test for function encode
def test_encode():
    """Unit test for the encode() function."""
    assert encode('dGhlc2UgaW5jbHVkZSBsaW90IG91dHB1dA==') == (
        b'these include lithium output',
        44
    )



# Generated at 2022-06-21 12:30:50.307079
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 6)
    assert encode('\n\naGVs\n\nbG8=\n') == (b'hello', 6)


# Generated at 2022-06-21 12:30:51.234094
# Unit test for function register
def test_register():
    """Test for function register."""
    register()
    codecs.getdecoder(NAME)   # type: ignore

# Generated at 2022-06-21 12:30:54.380820
# Unit test for function decode
def test_decode():
    bytes_obj = b'Some random string'
    expected = ('U29tZSByYW5kb20gc3RyaW5n', 22)
    tst = decode(bytes_obj, errors='strict')
    assert tst == expected



# Generated at 2022-06-21 12:31:04.647433
# Unit test for function encode
def test_encode():
    """Test b64.encode()"""
    from six import u
    from six.moves import range
    from . import b64
    for i in range(21):
        txt_in = u('a' * i)
        txt_enc = b64.encode(txt_in)
        txt_out = b64.decode(txt_enc[0])
        assert txt_in == txt_out[0], 'decode(encode()) is not the identity'
    for i in range(21):
        txt_in = u('a' * i)
        txt_enc = b64.encode(txt_in)
        txt_out = b64.decode(txt_in)

# Generated at 2022-06-21 12:31:13.600924
# Unit test for function decode
def test_decode():
    """Test decode function."""

# Generated at 2022-06-21 12:31:24.570619
# Unit test for function decode

# Generated at 2022-06-21 12:31:27.451241
# Unit test for function register
def test_register():
    """Unit test: function register"""
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) == _get_codec_info(NAME)


# Generated at 2022-06-21 12:31:31.606855
# Unit test for function decode
def test_decode():
    # Arrange
    data = b'\x00\x01\x02\x03\x04\x05\x06\x07'

    # Act
    encoded_str, _ = decode(data)

    # Assert
    assert 'AAECAwQFBgc=' == encoded_str



# Generated at 2022-06-21 12:31:35.633059
# Unit test for function decode
def test_decode():
    # Given
    input_byte_string  = bytes([0x74, 0x46, 0x78, 0x90, 0x68])

    # When
    b64_chars = decode(input_byte_string)[0]

    # Then
    assert b64_chars == 'dEZ4aA=='



# Generated at 2022-06-21 12:31:45.740428
# Unit test for function encode

# Generated at 2022-06-21 12:32:18.868399
# Unit test for function register
def test_register():
    try:
        register()
    except Exception as e:
        print(f'>>> ERROR, Test Failed: {e}')



# Generated at 2022-06-21 12:32:27.252218
# Unit test for function encode
def test_encode():
    # Test when passed a valid string of base64 characters.
    #
    # Test both functions
    text = 'bG9yMDMKc3VkaW90MDMKc3VkbW9yZT'
    encoded_bytes, _ = encode(text)
    decoded_str, _ = codecs.decode(encoded_bytes, 'b64')
    assert decoded_str == text, (
        'Base64 encode/decode failed.'
    )

    # The following tests should raise UnicodeEncodeErrors
    text = 'lor01\nsuidot01\nsudmore'
    try:
        encode(text)
        assert False, (
            'Should have raised a UnicodeEncodeError'
        )
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-21 12:32:31.104104
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(f'Could not find "{NAME}" codec.')


register()