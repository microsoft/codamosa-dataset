

# Generated at 2022-06-21 12:22:38.014516
# Unit test for function register
def test_register():
    """Test the register function"""
    register()



# Generated at 2022-06-21 12:22:48.470791
# Unit test for function encode
def test_encode():
    """Test encoder."""
    assert encode('SGVsbG8gV29ybGQh')[0] == b'Hello World!'
    assert encode('SGVsbG8gV29ybGQ=')[0] == b'Hello World'
    assert encode('SGVsbG8gV29ybGQ')[0] == b'Hello World'
    assert encode('SGVsbG8=')[0] == b'Helo'
    assert encode('SGVsbG8')[0] == b'Helo'
    assert encode('RmFzdCBTZWN1cml0eSBJbnRlbGxpZ2VuY2U=')[0] == \
           b'Fast Security Intelligence'

# Generated at 2022-06-21 12:22:58.264435
# Unit test for function decode

# Generated at 2022-06-21 12:23:01.362392
# Unit test for function register
def test_register(): # type: ignore
    """Unit test for the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:23:13.046475
# Unit test for function decode

# Generated at 2022-06-21 12:23:18.760519
# Unit test for function register
def test_register():
    # Perform the registration
    register()

    # Verify the registration
    try:
        codecs.getdecoder(NAME)

    except LookupError as e:  # pragma: no cover
        assert False, f'Register failed: {e}'
    else:
        assert True



# Generated at 2022-06-21 12:23:24.855574
# Unit test for function decode
def test_decode():
    print('Testing decode')
    str_data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f' \
               b'\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19'
    expected_result = 'AAECAwQFBgcICQoLDA0ODxAREhM='
    result = decode(str_data)
    assert(result[0] == expected_result)



# Generated at 2022-06-21 12:23:35.532064
# Unit test for function encode

# Generated at 2022-06-21 12:23:45.894888
# Unit test for function encode
def test_encode():
    """Test the :func:`encode` function.
    """
    b64_text = '''
        YWJj

        ZGVm

        Z2hp

        aGVs
        cGxl
    '''
    b64_bytes = b'abcdefghilpsel'
    out, out_len = encode(b64_text)
    assert out == b64_bytes
    assert out_len == len(b64_text)
    b1_text = 'x'
    b1_bytes = '\x00'
    out, out_len = encode(b1_text)
    assert out == b1_bytes
    assert out_len == len(b1_text)

# Generated at 2022-06-21 12:23:49.161081
# Unit test for function encode
def test_encode():
    """
    >>> test_encode()
    b'plaintext'

    """
    assert encode(user_string('cGxhaW50ZXh0')) == (b'plaintext', 16)


# Generated at 2022-06-21 12:23:53.357969
# Unit test for function register
def test_register():
    got = register()
    assert got is None



# Generated at 2022-06-21 12:23:55.465168
# Unit test for function register
def test_register():
    import codecs

    codecs.getdecoder(NAME) # no exception



# Generated at 2022-06-21 12:23:58.600304
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:24:07.982132
# Unit test for function encode
def test_encode():  # type: ignore
    """Unit test for ``encode``

    The 'bytecode' that was used to create the test data was obtained
    with the following command:

        python3 -m dis data_cube_utilities/data_access_api/test/test_api.py
    """

# Generated at 2022-06-21 12:24:18.864812
# Unit test for function encode
def test_encode():
    """Test-case for encode() function

    Args:
        None:

    Returns:
        None:
    """

# Generated at 2022-06-21 12:24:20.053166
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:24:21.549448
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:24:33.705360
# Unit test for function register
def test_register():
    """Basic test of registering the `b64` codec."""
    from binascii import b2a_base64
    from codecs import decode, encode

    register()
    assert encode(b'abc') == b'YWJj'
    assert decode(b'YWJj') == b'abc'
    assert encode(b'abc', 'b64') == b'YWJj'
    assert decode(b'YWJj', 'b64') == b'abc'
    assert encode(b'\x00\x00\x00\x00\x00\x00\x00\x00', 'b64') == b'AAAAAAAA'
    assert decode(b'AAAAAAAA', 'b64') == b'\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-21 12:24:44.222458
# Unit test for function register
def test_register():
    # pylint: disable=protected-access

    def fake_get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    def fake_register(
            get_codec_info: codecs.CodecInfo,   # pylint: disable=unused-argument
            name: str,   # pylint: disable=unused-argument
            *,
            streaminfo: Optional[Tuple[int, int]] = None,   # pylint: disable=unused-argument
            replace: bool = False,   # pylint: disable=unused-argument
    ):
        """
        :param get_codec_info: Not used.
        :param name: Not used.
        :param streaminfo: Not used.
        :param replace: Not used.
        """

# Generated at 2022-06-21 12:24:47.703311
# Unit test for function encode
def test_encode():
    """The encode method correctly decodes a simple base64 string."""
    x = encode(b'Hello, World')
    assert x == (b'SGVsbG8sIFdvcmxk', 13)



# Generated at 2022-06-21 12:24:52.781343
# Unit test for function register
def test_register():
    """Test :func:`register`."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:25:01.522714
# Unit test for function encode
def test_encode():

    # Base Test
    assert encode('') == (b'', 0)

    # Test with padding
    assert encode('Zg==') == (b'f', 4)

    # Test with no padding
    assert encode('Zg') == (b'f', 3)

    # Test with multiple lines
    assert encode('''
Zg==
''') == (b'f', 7)

    # Test with multiple lines and extra padding
    assert encode('''
Zg==
===
''') == (b'f', 10)

    # Test with leading spaces
    assert encode('''
Zg==
''') == (b'f', 7)

    # Test with trailing spaces
    assert encode('''
Zg== 
''') == (b'f', 8)

    # Test with trailing spaces

# Generated at 2022-06-21 12:25:04.551513
# Unit test for function decode
def test_decode():
    test_string = "Man"
    expected_output = b'TWFu'
    assert decode(test_string)[0] == expected_output



# Generated at 2022-06-21 12:25:04.924698
# Unit test for function decode
def test_decode():
    pass

# Generated at 2022-06-21 12:25:08.048863
# Unit test for function decode
def test_decode():
    _bytes = b'Hi'
    _str, _ = decode(_bytes)
    assert _str == 'SGk='


# Generated at 2022-06-21 12:25:18.605122
# Unit test for function decode
def test_decode():
    assert decode(b'aW1nLnBuZw==')[0] == 'img.png'
    assert decode(b'aW1nLnBuZw==', 'strict')[0] == 'img.png'
    assert decode(b'aW1nLnBuZw==', 'replace')[0] == 'img.png'
    assert decode(b'aW1nLnBuZw==', 'ignore')[0] == 'img.png'
    assert decode(b'aW1nLnBuZw==', 'backslashreplace')[0] == 'img.png'
    assert decode(b'aW1nLnBuZw==', 'xmlcharrefreplace')[0] == 'img.png'


# Generated at 2022-06-21 12:25:21.937055
# Unit test for function encode
def test_encode():
    # Setup
    test_string = 'I am a test string of base64 characters'
    # Execute
    encoded_bytes, length = encode(test_string)
    # Verify
    assert length == len(test_string)
    assert encoded_bytes == base64.b64decode(test_string)


# Generated at 2022-06-21 12:25:29.734044
# Unit test for function decode

# Generated at 2022-06-21 12:25:34.841378
# Unit test for function register
def test_register():
    """This is not an automated test.  To determine if this is working
    properly, print the output and verify that the ``b64`` codec is
    listed in the output.
    >>> import binascii.b64codec
    >>> binascii.b64codec.register()
    """

# Generated at 2022-06-21 12:25:38.405511
# Unit test for function register
def test_register():
    """Unit test for function register"""
    expected = 'b64'
    assert NAME == expected

    register()
    actual = codecs.getdecoder(NAME)

    assert 'CodecInfo' in str(actual)
    register()

# Generated at 2022-06-21 12:25:45.657728
# Unit test for function register
def test_register():
    """Test function register."""
    codecs.lookup(NAME)

# Generated at 2022-06-21 12:25:53.008687
# Unit test for function register
def test_register():
    import sys
    # Save the 'stdout'
    saved_stdout = sys.stdout
    # Make 'stdout' an instance of StringIO
    from io import StringIO
    sys.stdout = StringIO()

    # Register the 'b64' codec
    register()

    # Get the 'stdout' text
    output = sys.stdout.getvalue()
    output = output.strip()
    # Restore 'stdout'
    sys.stdout = saved_stdout

    # Make sure 'b64' codec is registered
    assert output == 'b64'



# Generated at 2022-06-21 12:25:56.285841
# Unit test for function encode
def test_encode():
    assert encode('VGhpcyBpcyBzb21lIEJhc2U2NCB0ZXh0IQ==') == (b'This is some Base64 text!', 26)


# Generated at 2022-06-21 12:25:58.473437
# Unit test for function encode
def test_encode():
    assert encode('MTIzNDU2Nzg=') == (b'12345678', 11)



# Generated at 2022-06-21 12:26:01.956032
# Unit test for function register
def test_register():
    """Unit test for function register"""
    import sys
    register()
    assert NAME in sys.__dict__['_registered_codecs']  # type: ignore


# Generated at 2022-06-21 12:26:10.423089
# Unit test for function decode
def test_decode():
    test_str = (
        'Man is distinguished, not only by his reason, but by this '
        'singular passion from other animals, which is a lust of the '
        'mind, that by a perseverance of delight in the continued and '
        'indefatigable generation of knowledge, exceeds the short '
        'vehemence of any carnal pleasure.'
    )
    test_bytes = test_str.encode('utf-8')
    # Encode the test_bytes into base64 bytes.
    base64_bytes = base64.b64encode(test_bytes)
    # Decode the base64 bytes as utf8 into a string.
    base64_str = base64_bytes.decode('utf-8')

    # Check that the input test_bytes converts to the correct base64_str.

# Generated at 2022-06-21 12:26:15.718579
# Unit test for function decode
def test_decode():
    assert decode(b'BXkPfC8') == ('+P0/w==', 7)
    assert decode(b'0\nC\n0\n5\nM\nW\n5\n0\n6\nU\n5\n0\n5\n') == ('AEI', 15)


# Unit tests for function encode

# Generated at 2022-06-21 12:26:17.208920
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)  # type: ignore



# Generated at 2022-06-21 12:26:19.813523
# Unit test for function decode
def test_decode():
    result = decode(bytes([0x11, 0x22]))
    assert result[0] == 'GKsk'
    assert result[1] == 2


# Generated at 2022-06-21 12:26:23.150064
# Unit test for function register
def test_register():
    """Unit test function for function ``register``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:26:34.418854
# Unit test for function register

# Generated at 2022-06-21 12:26:40.898108
# Unit test for function register
def test_register():
    """Test the register function.

    The 'b64' codec should be registered.  The 'b64' codec should be
    registered only once.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert "The 'b64' codec was already registered."

    register()
    func = codecs.getdecoder(NAME)
    expected = NAME
    result = func.__name__
    assert result == expected
    register()



# Generated at 2022-06-21 12:26:48.421693
# Unit test for function encode
def test_encode():
    import os
    import random


# Generated at 2022-06-21 12:26:51.598975
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codec_info = codecs.getdecoder(NAME)   # type: ignore
    assert codec_info is not None

# Generated at 2022-06-21 12:27:01.768224
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    # Test decode of a small number of bytes
    data = b'small_number'
    decoded_str, _ = decode(data)
    assert decoded_str == 'c21hbGxfbnVtYmVy'

    # Test decode of a large number of bytes with padding
    data_bytes = b'0123456789abcdef0123456789abcdef'
    data_bytes += b'0123456789abcdef0123456789abcdef'
    data_bytes += b'0123456789abcdef0123456789abcdef'
    data_bytes += b'0123456789abcdef0123456789abcdef'
    data_bytes += b'0123456789abcdef0123456789abcdef'
    data_

# Generated at 2022-06-21 12:27:03.640868
# Unit test for function register
def test_register():
    """Unit test the function :func:`register`."""
    register()

# Generated at 2022-06-21 12:27:13.041337
# Unit test for function decode
def test_decode():
    input_bytes = bytes(range(128))

# Generated at 2022-06-21 12:27:21.439397
# Unit test for function decode
def test_decode():
    """Test the decode function"""
    print(decode(b'Hello'))
    print(decode(b'World'))
    print(decode(b'Random'))
    print(decode(b'Base'))
    print(decode(b'64'))
    print(decode(b'Codec'))
    print(decode(b'...'))
    print(decode(b'!!'))
    print(decode(b'uh'))
    print(decode(b'oh'))


# Generated at 2022-06-21 12:27:22.129206
# Unit test for function decode
def test_decode():
    pass

# Generated at 2022-06-21 12:27:29.354184
# Unit test for function decode
def test_decode():
    """Test that the ``decode`` function takes a byte string and returns
    a string of base64 characters.
    """
    # The string to use as the input data.
    x_str = 'This is a test'
    # Encode the 'x_str' as utf8 bytes.
    x_bytes = x_str.encode('utf-8')
    # Use the 'decode' function to convert the 'x_bytes' into base64
    # characters. Need to convert the 'x_bytes' into bytes as this is
    # what the 'decode' function expects.
    b64_str, _ = decode(bytes(x_bytes), 'strict')
    # Convert the 'x_bytes' into base64 bytes.
    b64_bytes = base64.b64encode(x_bytes)
    # Convert the '

# Generated at 2022-06-21 12:27:45.457488
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJj\nZGVm') == (b'abcdef', 10)
    assert encode('\n'.join(('YWJj', 'ZGVm'))) == (b'abcdef', 11)
    assert encode(' YWJjZGVm ') == (b'abcdef', 11)
    assert encode(' YWJj\nZGVm ') == (b'abcdef', 11)
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)

# Generated at 2022-06-21 12:27:48.026644
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-21 12:28:00.593999
# Unit test for function decode
def test_decode():
    """Test decoding a bytestring."""
    # Test the decode function.
    # Test the 'decode' function with bytes input.
    encoded_str_1: str = 'V2hhdCBhIGJhZCBmZXRjaCwgQmVhdGhlciE='
    decoded_bytes_1: bytes = b'What a bad fetch, Beather!'
    # Test that the decode function accepts byte data and returns a string.
    assert decode(decoded_bytes_1)[0] == encoded_str_1
    # Test that the decode function accepts bytearray data.
    assert decode(bytearray(decoded_bytes_1))[0] == encoded_str_1
    # Test that the decode function accepts memoryview data.
    assert decode(memoryview(decoded_bytes_1))[0]

# Generated at 2022-06-21 12:28:05.916838
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        msg = (
            f"Failed to register the '{NAME}' codec.  "
            f"Unable to retrieve the decoder for '{NAME}'"
        )
        raise LookupError(msg) from None



# Generated at 2022-06-21 12:28:13.267128
# Unit test for function encode
def test_encode():
    """Test :func:`~b64.encode`."""
    assert encode("YToyOntzOjE6ImMiO3M6NzoicC5zYXl0aCI7czoyOiJjYSI7czozMjoiY29tLnNheXRoLnNheXRoLmNvbXB1dGFibGUuc3RhbmRhbG9uZSI7fQ==") == (b'{"1":{"c":"p.sayt","ca":"com.sayt.sayt.computable.standalone"}}', 66)

# Generated at 2022-06-21 12:28:20.937868
# Unit test for function encode
def test_encode():
    assert encode('YmFzZTY0') == (b'base64', 6)
    assert encode('YmFzZTY0\n') == (b'base64', 7)
    assert encode('YmFzZTY0 \n\n') == (b'base64', 10)
    assert encode('YmFzZTY0  \n') == (b'base64', 8)
    try:
        encode('YmFzZT!4')
    except UnicodeEncodeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 12:28:24.561033
# Unit test for function decode
def test_decode():
    input = b"hello world"
    expected = "aGVsbG8gd29ybGQ="
    actual, _ = decode(input)
    assert actual == expected


# Generated at 2022-06-21 12:28:26.903063
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-21 12:28:38.860393
# Unit test for function encode
def test_encode():
    # type: ... -> None
    """Unit test for the :func:`encode` function."""
    # Verify that string is unchanged.
    assert encode('')[0] == b''
    assert encode('AB')[0] == b'AB'
    assert encode('ab')[0] == b'ab'
    assert encode('ABab')[0] == b'ABab'
    assert encode('ABab123')[0] == b'ABab123'

    # Verify that the encoding works.
    assert encode('Yg==')[0] == b'f'
    assert encode('YWI=')[0] == b'ab'
    assert encode('YWJj')[0] == b'abc'
    assert encode('YWJjZA==')[0] == b'abcd'

# Generated at 2022-06-21 12:28:41.021098
# Unit test for function register
def test_register():
    """Test function ``register`` for codec ``NAME``"""
    register()
    codecs.getdecoder(NAME)  # Should not raise LookupError.



# Generated at 2022-06-21 12:29:03.032409
# Unit test for function encode
def test_encode():
    # Test to check if the encoding works correctly.
    assert b'Hello World' == encode('Hello World')[0]
    # Test is encoding a verbatim text without spaces works correctly.
    assert b'' == encode('')[0]
    assert b'aGVsbG8gd29y' == encode('hello wor')[0]
    # Test is encoding works correctly for a text with newlines and
    # white spaces.
    assert b'aGVsbG8gd29y' == encode('hello wor')[0]
    assert b'aGVsbG8gd29y' == encode('hello wor')[0]
    assert b'aGVsbG8gd29y' == encode('hello \t \n wor')[0]

# Generated at 2022-06-21 12:29:06.282237
# Unit test for function decode
def test_decode():
    """Test that the decoding of bytes into base64 characters works
    correctly.
    """
    assert decode(b'\xff\xfe') == ('//8=', 2)



# Generated at 2022-06-21 12:29:16.539019
# Unit test for function decode
def test_decode():
    """Unit test for function b64.decode."""
    text = 'c3VyZS4='
    text_bytes = text.encode('utf-8')
    assert text_bytes == base64.b64decode(text)
    assert text_bytes == codecs.decode(text, 'b64')
    assert text_bytes == b64.decode(text)

    text = 'c3VyZS4='
    text_bytes = text.encode('utf-8')
    assert text_bytes == base64.b64decode(text)
    assert text_bytes == codecs.decode(text, 'b64')
    assert text_bytes == b64.decode(text)

    text = 'd3d3LnczLm9yZy8MMDAw'
    text_bytes

# Generated at 2022-06-21 12:29:19.523004
# Unit test for function register
def test_register():
    """Test the function register."""
    import codecs

    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:29:26.412614
# Unit test for function encode
def test_encode():
    assert encode('QmFzZTY0IGRlY29kZWQgZGF0YQ==') == (b'Base64 decoded data', 23)
    assert (
        encode(
            'SGVsbG8sIFdvcmxkIQ==\nSGVsbG8sIFdvcmxkIQ=='
        ) == (b'Hello, World!Hello, World!', 30)
    )
    assert encode('') == (b'', 0)

# unit test for function decode

# Generated at 2022-06-21 12:29:32.320917
# Unit test for function register
def test_register():
    from io import BytesIO
    from io import StringIO
    from pprint import pformat
    from textwrap import dedent

    from common_doc.assert_util import AssertUtil

    AssertUtil.assert_true(True)

    # Encode some text as base64 bytes
    text = 'Hello, World!'
    # Encode the text as base64 bytes.
    text_bytes = text.encode('utf-8')
    # Encode the text utf8 bytes into base64 bytes
    base64_bytes = base64.b64encode(text_bytes)
    base64_str = base64_bytes.decode('utf-8')

# Generated at 2022-06-21 12:29:43.046965
# Unit test for function decode
def test_decode():
    '''
    Test the decode function.
    '''
    # Test 1
    data = b'test'
    text = decode(data)
    assert(text == ('dGVzdA==\n', 4))

    # Test 2
    data = b'\x00\xff\x00\xff\x00\xff\x00\xff\x00\xff\x00\xff'
    text = decode(data)
    assert(text == ('AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wA=\n', 12))

    # Test 3
    data = b'\x00\xA0\x00\xA0\x00\xA0\x00\xA0\x00\xA0\x00\xA0'
   

# Generated at 2022-06-21 12:29:49.495875
# Unit test for function encode
def test_encode():
    assert encode(u"RGVjb2RlIHRoaXMgc3RyaW5nIGlucHV0") == (
        b"Decode this string input",
        35,
    )
    with pytest.raises(UnicodeEncodeError) as ex:
        encode(u"RGVjb2RlIHRoaXMgc3RyaW5nIGlucHV0 😀😁😂")
    assert str(ex.value) == 'b64: "Decode this string input 😀😁😂" '\
        'contains non-base64 characters'


# Generated at 2022-06-21 12:29:55.887972
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode(
        """
        aGVsbG8gd29ybGQ=
        """
    ) == (b'hello world', 32)
    assert encode(
        """
            aGVsbG8gd29ybGQ=
        """
    ) == (b'hello world', 32)
    assert encode(
        """
        aGVsbG8gd29ybGQ=
    """
    ) == (b'hello world', 32)

# Generated at 2022-06-21 12:30:00.776409
# Unit test for function encode
def test_encode():
    assert encode("any carnal pleasure. \n any carnal pleasure.") == (b'YW55IGNhcm5hbCBwbGVhc3VyZS4gYW55IGNhcm5hbCBwbGVhc3VyZS4=', 48)
    assert encode("any carnal pleasure.") == (b'YW55IGNhcm5hbCBwbGVhc3VyZS4=', 24)
    assert encode("any carnal pleasure") == (b'YW55IGNhcm5hbCBwbGVhc3VyZQ==', 22)
    assert encode("any carnal pleasur") == (b'YW55IGNhcm5hbCBwbGVhc3Vy', 21)

# Generated at 2022-06-21 12:30:39.523331
# Unit test for function register
def test_register():
    """Test the function `register`."""
    # Assert that the 'b64' codec has not been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('b64 decoder has already been registered.')

    # Register the codec
    register()

    # Assert that the codec was registered.
    base64_decoder = codecs.getdecoder(NAME)  # type: ignore
    assert isinstance(base64_decoder, codecs.CodecInfo)  # type: ignore

    # Decode some base64 text

# Generated at 2022-06-21 12:30:49.672799
# Unit test for function decode
def test_decode():
    """Unit test for ``b64`` decode"""
    #pylint: disable=protected-access
    def assert_decode_with_bytes(
            test_data_bytes: _ByteString,
            expected_str: str,
            expected_consumed_bytes: int,
            test_description: str
    ) -> None:
        """Helper function that asserts decode is working properly."""
        answer_str, answer_consumed_bytes = decode(test_data_bytes)
        assert \
            answer_str == expected_str, \
            f'{test_description}: \n' \
            f'Expected string: {expected_str!r}\n' \
            f'Answer string: {answer_str!r}'

# Generated at 2022-06-21 12:30:57.427178
# Unit test for function register
def test_register():
    """Test function :meth:`register`."""
    from bytes import maketrans

    # Create the translation table.
    trans_tbl = maketrans(b'AaBb', b'aaBB')

    # Remove the support for the 'b64' codec.  This is done to test
    # the function.  It is done before the import 'codecs' is imported
    # to prevent the 'b64' codec from being register by the module
    # importing 'codecs'.
    import sys
    if NAME in sys.modules['encodings'].aliases.aliases:
        del sys.modules['encodings'].aliases.aliases[NAME]

    # Register the 'b64' codec.  This is done to test the function.
    register()

    # Test the register function by trying to use

# Generated at 2022-06-21 12:31:01.156082
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME)

# pylint: enable=W0613


if __name__ == '__main__':
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-21 12:31:06.812811
# Unit test for function encode
def test_encode():
    """Test the encode function"""
    assert encode(
        'TGlmZSBpcyB3aGF0IHlvdSB1c2UgaXQgZm9yLiAgU2VlIHRoaXMgY2F0LiA6KQ=='
    ) == (b'Life is what you use it for.  See this cat. :)',
          71)

# Generated at 2022-06-21 12:31:12.555316
# Unit test for function decode
def test_decode():
    """Test that the decode function is encoding data correctly."""
    assert decode(b"\x00\x01") == ("AAE=", 2)
    assert decode(b"\x00\x01\x02") == ("AAECA==", 3)
    assert decode(b"\x00\x01\x02\x03") == ("AAECAw==", 4)
    assert decode(b"\x00\x01\x02\x03\x04") == ("AAECAwQF", 5)
    assert decode(b"\x00\x01\x02\x03\x04\x05") == ("AAECAwQFBg==", 6)

# Generated at 2022-06-21 12:31:20.086771
# Unit test for function decode
def test_decode():
    """Unit test for the decode function."""
    # pylint: disable=W0613
    # pylint: disable=W0621
    # pylint: disable=W0612
    import codecs

    # Create the expected output string.
    expected = 'This is a base64 character string.'
    expected_bytes = expected.encode('utf-8')
    # Convert the expected output into base64.
    expected_base64 = base64.b64encode(expected_bytes)
    # Convert the expected output into utf8 bytes.
    expected_base64_utf8 = expected_base64.decode('utf-8')

    # Encode the 'expected' string into utf8 bytes.
    input_bytes = expected.encode('utf-8')

    # Use the standard codec to decode the utf8 encoded bytes

# Generated at 2022-06-21 12:31:24.792464
# Unit test for function decode
def test_decode():
    data_bytes = b'\xff\xfe\xfd\xfc'
    expected_str = '////'
    actual_str, len_used_bytes = decode(data_bytes)
    assert len_used_bytes == len(data_bytes)
    assert actual_str == expected_str


# Generated at 2022-06-21 12:31:26.230865
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:31:35.634138
# Unit test for function register
def test_register():
    """Test the registration of the ``b64`` codec with Python."""
    import sys
    import unittest
    from typing import TextIO
    from typing import Any
    from typing import cast
    from typing import Union
    from typing import Optional

    from . import is_registered

    class TestRegister(unittest.TestCase):
        """Unit test for function register."""

        def setUp(self) -> None:
            """Set up the test unit."""
            self.__stderr = sys.stderr
            sys.stderr = cast(TextIO, None)

        def tearDown(self) -> None:
            """Clean up the test unit."""
            sys.stderr = self.__stderr


# Generated at 2022-06-21 12:32:15.686476
# Unit test for function encode
def test_encode():
    TEST_INPUT = '''\
    SGVsbG8sIFdvcmxkIQ==
    '''
    assert encode(TEST_INPUT) == (b'Hello, World!', 27), \
        f'{encode(TEST_INPUT)!r} != (b\'Hello, World!\', 27)'
    TEST_INPUT = '''\
    SFU6SFI6SFI6SFI6SFI6SFI6SFI6SFI6SFI6SFI6SFI6SFVW
    '''

# Generated at 2022-06-21 12:32:24.811602
# Unit test for function encode
def test_encode():
    from itertools import product
    from hypothesis import given
    from hypothesis import strategies as st

    @given(st.text())
    def do_test(text: str) -> None:
        """Ensure that ``text`` is converted as expected."""
        test_str, _ = encode(text)
        assert base64.b64decode(test_str.encode('utf-8')) == text.encode('utf-8')

    # Perform the test
    do_test()

    # Create a test string with runs of varying lengths of all possible
    # base64 characters.
    base64_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

# Generated at 2022-06-21 12:32:30.605583
# Unit test for function decode
def test_decode():
    cases = [
        (
            b'fjghjk',
            'ZmpnaGpr'
        ),
        (
            b'\xde\xad\xbe\xef',
            '3q2+7w=='
        ),
        (
            base64.b64encode(b'fjghjk'),
            'ZmpnaGpr'
        ),
        (
            base64.b64encode(b'\xde\xad\xbe\xef'),
            '3q2+7w=='
        ),
        (
            b'',
            ''
        ),
    ]
    for case in cases:
        exp_str, exp_int = encode(case[0])
        act_str, act_int = decode(case[1])
        assert exp_

# Generated at 2022-06-21 12:32:37.021871
# Unit test for function register
def test_register():
    """Test the register function."""
    codecs.register(_get_codec_info)
    out = codecs.getencoder(NAME)
    assert out[0].__name__ == 'encode'
    assert out[1].__name__ == 'encode'

    out = codecs.getdecoder(NAME)
    assert out[0].__name__ == 'decode'
    assert out[1].__name__ == 'decode'


# Run a unit test of the register function.
if __name__ == '__main__':
    test_register()