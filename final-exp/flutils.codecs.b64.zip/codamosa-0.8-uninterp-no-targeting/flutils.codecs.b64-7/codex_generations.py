

# Generated at 2022-06-21 12:22:43.265287
# Unit test for function register
def test_register():
    # The codec has not yet been registered
    # pylint: disable=W0212
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    register()
    # The codec has been registered
    assert NAME == codecs.getdecoder(NAME)[0]
    # Calling the 'register()' function again should not cause an error
    register()

# Generated at 2022-06-21 12:22:53.846857
# Unit test for function encode
def test_encode():
    """Test the :func:`base64_codec.b64.encode` function."""
    # Test 1: Correct case.
    input_1 = 'YW55IGNhcm5hbCBwbGVhc3VyZS4=\n'
    output_1 = encode(input_1)
    expected_out = (b'any cannab pallassur.', 29)
    assert output_1 == expected_out

    # Test 2: Incomplete case.
    input_2 = 'YW55IGNhcm5hbCBwbGVhc3VyZS4=\n'
    output_2 = encode(input_2[:27])
    expected_out = (b'any cannab pallassur.', 27)
    assert output_2 == expected_out

    # Test 3: Incorrect encoding case

# Generated at 2022-06-21 12:23:05.414128
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    from pytest import raises
    from yarl import URL
    from yarl.strings import String
    from yarl.util.encoders import register

    # pylint: disable=E1128, E1120
    # noinspection PyUnusedLocal
    def get_codec_info(name):
        class FakeCodecInfo:
            def __init__(self, name):
                self.name = name
        return FakeCodecInfo(name)

    # noinspection PyUnusedLocal
    def codecs_getdecoder(name):
        if name != NAME:
            raise LookupError(name)
        class FakeCodecs:
            def __init__(self):
                pass
        return FakeCodecs(), FakeCodecs


# Generated at 2022-06-21 12:23:14.821350
# Unit test for function decode
def test_decode():
    """Unit test for function decode
    """
    # Test 1:
    data = b'\x7F'
    assert decode(data) == ('fA==', 1)

    # Test 2:
    data = b'\x7F\x7F'
    assert decode(data) == ('fH3/', 2)

    # Test 3:
    data = b'\x7F\x7F\x00'
    assert decode(data) == ('fH/A', 3)

    # Test 4:
    data = b'\x7F\x7F\x00\x00'
    assert decode(data) == ('fH3A', 4)



# Generated at 2022-06-21 12:23:23.808719
# Unit test for function encode
def test_encode():
    """
    Unit test for function encode
    """
    # pylint: disable=C0325
    # pylint: disable=C0326

# Generated at 2022-06-21 12:23:30.770033
# Unit test for function register
def test_register():
    """
    Test the function ``register``.

    The following user defined codecs are defined:
    - b64
    """
    # pylint: disable=unused-variable
    codecs.register(lambda name: codecs.lookup('utf-8') if name == 'b64' else None)
    register()
    return

__all__ = [
    'register',
    'test_register',
]

# Generated at 2022-06-21 12:23:39.077379
# Unit test for function register
def test_register():
    """Unit test for function register.
    Tests that the ``b64`` codec is not currently registered.
    """
    from . import (  # pylint: disable=import-outside-toplevel
        unit_test_uri,
    )
    from .codec_test_case import CodecTestCase  # pylint: disable=import-outside-toplevel
    from .write_test_file import WriteTestFile  # pylint: disable=import-outside-toplevel

    # pylint: disable=protected-access
    class TestRegisterB64(CodecTestCase):
        """TestRegisterB64: Unit test for function register."""

        def test_register(self):
            """Unit test for function register.
            Tests that the ``b64`` codec is not currently registered.
            """
            # pylint: disable

# Generated at 2022-06-21 12:23:47.643020
# Unit test for function register
def test_register():
    # Make sure the 'b64' codec has not been previously registered.
    try:
        codecs.getdecoder(NAME)
        assert False, 'b64 codec is already registered'
    except LookupError:
        pass

    # Register the 'b64' codec.
    codecs.register(_get_codec_info)  # type: ignore

    # Get the 'b64' codec information.
    info = codecs.getdecoder(NAME)  # type: ignore

    # Make sure the 'b64' codec info is a CodecInfo object.
    assert isinstance(info, codecs.CodecInfo), \
        f'type(info) is {type(info)!r}'

    # Make sure the 'b64' codec info has the required fields.

# Generated at 2022-06-21 12:23:57.471414
# Unit test for function register
def test_register():
    """Verify that the ``b64`` codec functions are available.

    The ``b64.register()`` function should add the :meth:`~b64.encode` and
    :meth:`~b64.decode` functions to Python's codecs functions.  This function
    should also register the codec name ``b64`` with Python's codecs.  This
    function verifies that all of this was done by the :meth:`register`
    function.
    """

    # Register the b64 codec.
    register()

    codec_info = codecs.getdecoder(NAME)  # type: ignore
    assert codec_info is not None, (
        'The b64 codec was not found in Python decoding codecs'
    )

    # Verify the names and functions of the b64 codec


# Generated at 2022-06-21 12:24:00.530061
# Unit test for function decode
def test_decode():
    input_data: bytes = b'Hello'
    output_data: bytes = b'SGVsbG8='
    assert decode(input_data) == (output_data, len(input_data))


# Generated at 2022-06-21 12:24:03.830431
# Unit test for function encode
def test_encode():
    assert encode(b"aGVsbG8=", "strict") == (b"hello", 6)



# Generated at 2022-06-21 12:24:12.529180
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    assert decode(b'AA==') == ('0', 3)
    assert decode(b'AQ==') == ('1', 3)
    assert decode(b'Ag==') == ('2', 3)
    assert decode(b'Aw==') == ('3', 3)
    assert decode(b'BA==') == ('4', 3)
    assert decode(b'BQ==') == ('5', 3)
    assert decode(b'Bg==') == ('6', 3)
    assert decode(b'Bw==') == ('7', 3)
    assert decode(b'CA==') == ('8', 3)
    assert decode(b'CQ==') == ('9', 3)
    assert decode(b'Cg==') == ('a', 3)

# Generated at 2022-06-21 12:24:16.605569
# Unit test for function decode
def test_decode():
    """Unit test to ensure the 'decode' function is working as expected."""
    assert decode(b'\x00\x01\x02\x03')[0] == 'AAECAw=='
    assert decode(b'\x00\x01\x02\x03')[1] == 4



# Generated at 2022-06-21 12:24:21.071733
# Unit test for function decode
def test_decode():
    """Unit test for function 'decode'."""
    import unittest

    class Test(unittest.TestCase):
        """Tests for function 'decode'."""
        def test_defaults(self):
            """Function 'decode' with default arguments."""
            data_bytes = b'\x00\x01\x02\x03'
            expected = 'AAECAw=='
            actual, _ = decode(data_bytes)
            self.assertEqual(actual, expected)

    unittest.main()



# Generated at 2022-06-21 12:24:33.102179
# Unit test for function decode
def test_decode():
    # Single line string, no whitespace
    text = 'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wZWQgb3ZlciB0aGUgbGF6eSBkb2cu'

    # Convert the string of base64 characters into the base64 bytes
    expected = b'The quick brown fox jumped over the lazy dog.'
    assert decode(text) == (expected, len(text))

    # Multi line string, with whitespace
    text = '''
    VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wZWQgb3ZlciB0aGUgbGF6eSBkb2cu
    '''

    # Convert the string of base64 characters into the base64 bytes

# Generated at 2022-06-21 12:24:35.014261
# Unit test for function register
def test_register():
    """Test the :func:`register` function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    finally:
        register()



# Generated at 2022-06-21 12:24:46.394253
# Unit test for function encode

# Generated at 2022-06-21 12:24:51.041206
# Unit test for function register
def test_register():
    """Test the ``register()`` function."""
    # Ensure that the codec is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Ensure that the codec is registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:25:00.273060
# Unit test for function encode
def test_encode():
    # pylint: disable=C0116
    # pylint: disable=W0703
    # pylint: disable=R1705
    assert encode('') == (b'', 0)
    assert encode(''*100) == (b'', 0)
    try:
        encode('\n')
    except UnicodeEncodeError:
        pass
    else:
        assert False
    try:
        encode('\n'*100)
    except UnicodeEncodeError:
        pass
    else:
        assert False
    try:
        encode('\n'*100)
    except UnicodeEncodeError:
        pass
    else:
        assert False
    try:
        encode(' \n'*100)
    except UnicodeEncodeError:
        pass
    else:
        assert False

# Generated at 2022-06-21 12:25:01.291229
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-21 12:25:14.400898
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    test_data = [
        ('', b''),
        ('  \n \t \v ', b''),
        ('zZ==', b'\x01'),
        ('Zg==', b'f'),
        ('Zm8=', b'fo'),
        ('Zm9v', b'foo'),
        ('Zm9vYg==', b'foob'),
        ('Zm9vYmE=', b'fooba'),
        ('Zm9vYmFy', b'foobar'),
    ]
    for (base64_str, base64_bytes) in test_data:
        assert decode(base64_str)[0] == base64_str
        assert decode(base64_str)[1] == len(base64_str)

# Generated at 2022-06-21 12:25:24.058802
# Unit test for function encode
def test_encode():
    from itertools import repeat
    from random import randint
    from string import printable
    from typing import Generator, List

    TEXT_DATA_SIZE = 1024

    TEXT_DATA = [
        ''.join(
            repeat(
                printable[randint(0, len(printable) - 1)],
                randint(1, TEXT_DATA_SIZE)
            )
        )
        for _ in range(0, TEXT_DATA_SIZE)
    ]


# Generated at 2022-06-21 12:25:29.426893
# Unit test for function register
def test_register():
    """Test the b64 module's register() function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False

    register()

    # Test that the b64 codec exists.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-21 12:25:31.739955
# Unit test for function encode
def test_encode():
    print("Test encode")
    assert encode("b64") == (b'b64', 3)



# Generated at 2022-06-21 12:25:37.484932
# Unit test for function encode
def test_encode():
    """Test function encode"""
    assert (
        encode(
            'cHN0cm9uZw==\n'
        ) == (b'pstrong', 11)
    )
    assert (
        encode(
            'cHN0cm9uZw==    \n'
        ) == (b'pstrong', 11)
    )



# Generated at 2022-06-21 12:25:46.369785
# Unit test for function encode
def test_encode():
    # pylint: disable=C0200
    """
    Test the ``encode`` function.

    This is the 'encode' function from the module ``b64``.
    """
    # Test empty input
    text = ''
    out = encode(text)
    assert out[0] == b'', (
        f'encode function returned {out} for empty string.'
    )
    assert out[1] == 0, (
        f'encode function returned {out} for empty string.'
    )

    # Test null input
    text = None
    out = encode(text)
    assert out[0] == b'', (
        f'encode function returned {out} for null string.'
    )

# Generated at 2022-06-21 12:25:48.693457
# Unit test for function register
def test_register():
    """Ensure the registration of this codec with Python works."""
    register()
    codecs.getencoder(NAME)  # type: ignore

# Generated at 2022-06-21 12:25:56.425660
# Unit test for function decode
def test_decode():
    assert decode(b'AAAAAAA') == ('QUFBQUFB', 7)
    assert decode(b'7g') == ('dw==', 2)
    assert decode(b'7g\n') == ('dw==', 2)
    assert decode(b'7g\n ') == ('dw==', 2)
    assert decode(b'7g\n \t') == ('dw==', 2)
    assert decode(b'7g\n \t\r') == ('dw==', 2)
    assert decode(b'7g\n \t\r\n') == ('dw==', 2)
    assert decode(b'test') == ('dGVzdA==', 4)
    assert decode(b'\x00\x00') == ('AAAA', 2)

# Generated at 2022-06-21 12:25:59.853608
# Unit test for function register
def test_register():
    """Test that registering the ``b64`` codec doesn't raise an exception.

    """
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:26:02.902320
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME) is not None, f'{NAME} codec not registered'



# Generated at 2022-06-21 12:26:11.551335
# Unit test for function encode
def test_encode():
    """Test module function encode."""
    # No exceptions should be raised.
    try:
        text = 'fnishhhcqjqaiu5if5yh7t4nss4o5jt4'
        encode(text)
    except Exception as e:
        pytest.fail(f'Test failed: {e!r}')
    # Test string with embedded newlines and spaces.
    try:
        text = 'fnishhhc\nqjqaiu5i\nf5yh7t4n\nss4o5jt4'
        encode(text)
    except Exception as e:
        pytest.fail(f'Test failed: {e!r}')
    # Test string with embedded tabs, newlines, and spaces

# Generated at 2022-06-21 12:26:16.212315
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode
    """
    input_bytes = b"AA=="
    decoded_bytes, number_of_bytes_counted = decode(input_bytes)
    assert decoded_bytes == "KQ=="
    assert number_of_bytes_counted == len(input_bytes)



# Generated at 2022-06-21 12:26:19.344377
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``."""
    input_str = """\
    SGVsbG8sIHdvcmxkIQo=
    """
    output = encode(input_str)
    output_bytes = output[0]
    output_str = output_bytes.decode('utf-8')
    assert output_str == 'Hello, world!'



# Generated at 2022-06-21 12:26:21.745215
# Unit test for function register
def test_register():
    """Test register"""
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-21 12:26:33.173363
# Unit test for function decode

# Generated at 2022-06-21 12:26:43.244419
# Unit test for function decode
def test_decode():
    print('decode test')
    assert decode(b'one') == ('b25l', 3)
    assert decode(b'one', 'strict') == ('b25l', 3)
    assert decode(b'\xff\xff') == ('////', 4)
    assert decode(b'\xff\xff', 'strict') == ('////', 4)
    assert decode(b'\x0a') == ('Cg==', 4)
    assert decode(b'\x0a', 'strict') == ('Cg==', 4)
    try:
        decode(b'\xff\xf0', 'strict')
    except UnicodeEncodeError as e:
        assert e.encoding == 'b64'
        assert e.reason == 'incorrect padding'
        assert e.start == 0
        assert e.end == 2

# Generated at 2022-06-21 12:26:49.779892
# Unit test for function decode
def test_decode():
    """Test the function decode."""
    # Given,
    # Byte data to encode as base64 characters
    data = bytes([0, 255, 10, 20, 30])

    # When,
    # Decode the given bytes into base64 characters
    result, _ = decode(data)

    # Then,
    # The decoded result string should be equal to the
    # expected base64 character string
    result.should.be.equal(b'AAH+1iI=')


# Generated at 2022-06-21 12:27:00.815853
# Unit test for function encode
def test_encode():
    """Test function: ``encode``"""
    # Encode bytes.
    b64_bytes = b'aGVsbG8sIHdvcmxkIQ==\n'
    expected_bytes = b'hello, world!'
    assert encode(b64_bytes)[0] == expected_bytes

    # Encode string.
    b64_str = 'aGVsbG8sIHdvcmxkIQ==\n\t'
    assert encode(b64_str)[0] == expected_bytes

    # Encode with bad characters

# Generated at 2022-06-21 12:27:05.370869
# Unit test for function decode
def test_decode():
    """ Unit test for function decode """
    # Valid base64 input.
    assert decode(b'Man')[0] == 'TWFu'

    # Invalid base64 input.
    try:
        decode(b'\x00\x00')[0] == ''
    except UnicodeDecodeError as err:
        assert err.reason == 'Incorrect padding'
    except Exception as err:   # pylint: disable=W0703
        assert False

    # Valid base64 input exceeding padding.
    assert decode(b"Man'")[0] == "TWFu"



# Generated at 2022-06-21 12:27:07.154508
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder('b64')


# Generated at 2022-06-21 12:27:11.516323
# Unit test for function encode
def test_encode():
    assert encode(
        "MTIzNDU2"
    ) == (b'123456', 8)


# https://docs.python.org/3/library/codecs.html#binary-data-to-text-encodings

# Generated at 2022-06-21 12:27:14.442430
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    test = codecs.getdecoder(NAME)  # type: ignore
    assert test.__name__ == NAME

# Generated at 2022-06-21 12:27:25.384917
# Unit test for function decode
def test_decode():
    """Test the 'decode' function."""

    data = b'\x00\x01\x02'
    expected = 'AAEC'
    actual, num_bytes = decode(data)
    assert expected == actual and len(data) == num_bytes

    data = b''
    expected = ''
    actual, num_bytes = decode(data)
    assert expected == actual and len(data) == num_bytes

    data = b'\x00'
    expected = 'AA=='
    actual, num_bytes = decode(data)
    assert expected == actual and len(data) == num_bytes

    data = b'\x00\x01'
    expected = 'AAE='
    actual, num_bytes = decode(data)
    assert expected == actual and len(data) == num_bytes


# Generated at 2022-06-21 12:27:31.103936
# Unit test for function register
def test_register():
    """Test function register."""
    # pylint: disable=too-many-locals
    from importlib import reload
    import base64
    # Reload in order to reload the module's global variables.  It this
    # isn't done the test won't be valid.
    reload(encoding)

    # Test the codec is not registered
    name = f'encoding.{NAME}'
    try:
        codecs.getdecoder(name)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{name} should not be registered')

    # Register 'encoding.b64'
    encoding.register()

    # Test the codec is registered

# Generated at 2022-06-21 12:27:38.035095
# Unit test for function decode
def test_decode():
    sample_bytes_1 = b'this is a test.'
    expected_str_1 = 'dGhpcyBpcyBhIHRlc3Qu'
    actual_str_1, num_bytes_consumed_1 = decode(sample_bytes_1)
    assert num_bytes_consumed_1 == len(sample_bytes_1)
    assert actual_str_1 == expected_str_1


# Unit tests for function encode

# Generated at 2022-06-21 12:27:41.657351
# Unit test for function decode
def test_decode():  # noqa: D103
    data = b'\x00\x01\x02\x03\x04\x05'
    expected = b'AAECAwQF'
    actual = codecs.decode(data, 'b64')
    assert actual == expected



# Generated at 2022-06-21 12:27:54.596892
# Unit test for function decode
def test_decode():
    """Simple unit test for function decode."""
    assert decode(b'YXNkYXNk') == ('YXNkYXNk', 8)

# Generated at 2022-06-21 12:27:56.611885
# Unit test for function register
def test_register():
    """Test the function 'register'"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:28:03.091117
# Unit test for function decode
def test_decode():
    assert decode(b'9793d794e8bae886acf5') == ('5f4dcc3b5aa765d61d8327deb882cf99', 20)
    assert decode(b'5f4dcc3b5aa765d61d8327deb882cf99') == ('9793d794e8bae886acf5', 20)


# Generated at 2022-06-21 12:28:05.770139
# Unit test for function register
def test_register():  # type: ignore
    """Unit test for function register."""
    out = codecs.getdecoder(NAME)
    assert out[0] == decode



# Generated at 2022-06-21 12:28:18.030920
# Unit test for function decode
def test_decode():
    import re

    # Verify decoding of simple base64 bytes
    test_bytes = base64.b64encode(b'abcd')
    assert decode(test_bytes)[0] == 'YWJjZA=='

    # Verify decoding of multi line base64 bytes
    test_bytes = '\n'.join(
        b'YWJjZA==',
        b'A1Bjc2g=',
        b'WmRqbw=='
    )
    assert ''.join(decode(test_bytes)[0].split()) == 'YWJjZA==A1Bjc2g=WmRqbw=='

    # Verify decoding of simple base64 bytes with leading spaces
    test_bytes = '   YWJjZA=='

# Generated at 2022-06-21 12:28:20.832968
# Unit test for function register
def test_register():
    """Test function register."""
    codecs.lookup(NAME)


if __name__ == '__main__':
    register()

# Generated at 2022-06-21 12:28:30.475762
# Unit test for function encode

# Generated at 2022-06-21 12:28:41.953875
# Unit test for function decode
def test_decode():
    # pylint: disable=W0612,W0613
    d, q = decode(b'QQ==')
    assert d == 'A'
    assert q == 3

    d, q = decode(b'Queue')
    assert d == 'UXVlcg=='
    assert q == 6

    d, q = decode(b'QQ=')
    assert d == 'A'
    assert q == 3

    d, q = decode(b'QQ')
    assert d == 'A'
    assert q == 2

    d, q = decode(b'QQQ==')
    assert d == 'A'
    assert q == 4

    d, q = decode(b'QQQ')
    assert d == 'A'
    assert q == 3


# Generated at 2022-06-21 12:28:53.699003
# Unit test for function decode

# Generated at 2022-06-21 12:28:56.260015
# Unit test for function decode
def test_decode():
    """Test function decode in codecs_b64.py
    """
    assert decode('AA==')[0] == '\x00'
    assert decode('AAA=')[0] == '\x00\x00'
    assert decode('AAAA')[0] == '\x00\x00\x00'


# Generated at 2022-06-21 12:28:59.894184
# Unit test for function decode
def test_decode():  # noqa
    input_data = b'\x00' * 50
    data, count = codecs.getdecoder('b64')(input_data)
    print(data)
    assert data == 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'


# Unit tests for function encode

# Generated at 2022-06-21 12:29:03.505556
# Unit test for function encode
def test_encode():
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('') == (b'', 0)
    assert encode('cXVhbnRpdHk=') == (b'quantity', 10)


# Generated at 2022-06-21 12:29:11.598283
# Unit test for function encode
def test_encode():
    from binascii import Error as BinasciiError
    from re import compile
    from unittest import TestCase, main

    class TestEncode(TestCase):
        def test_encode_not_str(self):
            with self.assertRaises(TypeError):
                encode(b'bytes')
            with self.assertRaises(TypeError):
                encode(bytearray('bytearray', 'utf-8'))
            with self.assertRaises(TypeError):
                encode('bytes', errors=b'bytes')
            with self.assertRaises(TypeError):
                encode('text', errors=bytearray('bytearray', 'utf-8'))


# Generated at 2022-06-21 12:29:17.333097
# Unit test for function encode
def test_encode():
    assert(encode('aGVsbA==\n') == (b'hello', 8))
    assert(encode('aGVsbA==') == (b'hello', 6))
    assert(encode('aGVsbA=', 'strict') == (b'hello', 6))
    assert(encode('aGVsbA=\n') == (b'hello', 7))


# Generated at 2022-06-21 12:29:29.587579
# Unit test for function decode
def test_decode():
    assert decode(b'TmVnYSBteSBmYXZvcml0ZSBbaGlwcGVyfGVsYWJvcmF0ZXNdIGxhbmd1YWdlIGlzIEJvdw==', 'strict') == ('Nega my favorite [hippe|laborates] language is Bow', 72)

# Generated at 2022-06-21 12:29:31.876447
# Unit test for function decode
def test_decode():
    assert decode(b'foobar')[0] == 'Zm9vYmFy'
    assert decode(b'foobar')[1] == 6

#Unit test for function encode

# Generated at 2022-06-21 12:29:39.934822
# Unit test for function register
def test_register():
    # pylint: disable=undefined-variable
    codecs.__all__[0] = 'None'
    register()
    assert codecs.__all__[0] == NAME


codecs.__all__ = []
try:
    # noinspection PyUnresolvedReferences
    # pylint: disable=unused-import
    import __builtin__ as builtins
except ImportError:
    # noinspection PyUnresolvedReferences
    # pylint: disable=unused-import
    import builtins



# Generated at 2022-06-21 12:29:40.930081
# Unit test for function register
def test_register():
    """Test the function :func:`register`"""
    register()



# Generated at 2022-06-21 12:29:49.179828
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    assert encode('SSBibG9iIDIwMTggMTA6MzA6NTE=\n')[0] == b'Bob Loblaw 2018 10:30:51'
    assert encode('c2l0dGVycw==\n')[0] == b'citters'
    assert encode('SENV\n')[0] == b'BAMB'
    assert encode('c2l0dGVycw==')[0] == b'citters'
    assert encode('c2l0dGVycw==')[0] == b'citters'
    assert encode('c2l0dGVycw==\n')[0] == b'citters'
    assert encode('<h1>Hello world</h1>\n')

# Generated at 2022-06-21 12:29:54.703320
# Unit test for function decode
def test_decode():
    input = b'aGVsbG8gd29ybGQ='
    expected = 'aGVsbG8gd29ybGQ='
    actual = decode(input)[0]
    if actual != expected:
        print(f'FAIL: decode({input!r}) == {actual!r} != {expected!r}')
        raise RuntimeError('Failed test_decode.')


# Generated at 2022-06-21 12:30:02.857249
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""
    # Error if the given text is not a valid base64 string.
    with pytest.raises(UnicodeEncodeError) as exc_info:
        encode('\n'.join(['QQ==', 'QQ==']))
    assert str(exc_info.value) == \
        "('b64', '\\nQQ==\\nQQ==', 0, 11, " \
        "'\\nQQ==\\nQQ== is not a proper bas64 character string: Incorrect padding')"

    # Error if the given text is not a valid base64 string.
    with pytest.raises(UnicodeEncodeError) as exc_info:
        encode('\n'.join(['QQ=', 'QQ==']))

# Generated at 2022-06-21 12:30:06.834179
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    try:
        codecs.getdecoder(NAME)  # type: ignore
    except LookupError:
        assert False
    else:
        assert True

# Generated at 2022-06-21 12:30:10.023148
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # pylint: disable=W0212
    try:
        codecs._cache.pop(NAME)
    except KeyError:
        pass

    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:30:16.576338
# Unit test for function decode
def test_decode():
    assert decode(b'YXNkYXNk')[0] == 'asdasd'
    assert decode(b'YXNkYXNk', 'strict')[0] == 'asdasd'
    assert decode(b'YXNkYXNk', 'ignore')[0] == 'asdasd'
    assert decode(b'YXNkYXNk', 'replace')[0] == 'asdasd'
    assert decode(b'YXNkYXNk', 'surrogateescape')[0] == 'asdasd'

# Generated at 2022-06-21 12:30:26.733619
# Unit test for function register
def test_register():
    """Test that ``register()`` function is working."""
    register()
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-21 12:30:29.478920
# Unit test for function register
def test_register():
    """Unit test for function :func:`~register`."""
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:30:38.747121
# Unit test for function decode
def test_decode():
    """Test the decode function of the b64 codec."""
    # pylint: disable=line-too-long
    data_bytes: bytes = bytes(range(256))
    encoded_str: str = encode(data_bytes)[0]

    assert decode(data_bytes, 'ignore') == encoded_str  # type: ignore
    assert decode(data_bytes, 'replace') == encoded_str  # type: ignore
    assert decode(data_bytes, 'strict') == encoded_str  # type: ignore
    assert decode(data_bytes, 'xmlcharrefreplace') == encoded_str  # type: ignore
    # pylint: enable=line-too-long


# Generated at 2022-06-21 12:30:45.732427
# Unit test for function decode
def test_decode():
    assert decode(b'cGMt') == ('b64', 4)
    assert decode(b'YWFhYWFh') == ('aaaaaaaa', 8)
    assert decode(b'') == ('', 0)
    assert decode(b'aHVudGVyc3VwcG9ydA==') == ('huntersupport', 16)
    assert decode(b'c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0') == ('secretsecretsecretsecretsecretsecretsecretsecretsecretsecret', 64)
    return 'test OK'


# Generated at 2022-06-21 12:30:55.386849
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('\n') == (bytes(b''), 1)
    assert encode('YQ==') == (bytes(b'a'), 4)
    assert encode('YWI=\n') == (bytes(b'ab'), 3)
    assert encode('YWJj\n') == (bytes(b'abc'), 4)
    assert encode('YWJjZA==') == (bytes(b'abcd'), 8)
    assert encode('YWJjZGU=') == (bytes(b'abcde'), 8)
    assert encode('YWJjZGVm') == (bytes(b'abcdef'), 8)
    try:
        encode('YWJjZGVm')
    except UnicodeEncodeError:
        pass
    else:
        raise Exception

# Generated at 2022-06-21 12:30:57.088096
# Unit test for function register
def test_register():
    # Test the register function.
    assert NAME in codecs.__all__



# Generated at 2022-06-21 12:31:03.290884
# Unit test for function decode
def test_decode():
    # Tests to confirm that decode() works as expected with given sample data.
    # Adding a new test case here is not enough.  To keep the code coverage
    # tool from falsely reporting a lower % coverage, the test case must be
    # added to the :mod:`test.test_base64` module.
    assert decode(b'\x00\x01\x02\x03', errors='strict') == ('AAECAw==', 4)

# Generated at 2022-06-21 12:31:12.472809
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjCg==') == (b'abc', 6)
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjCg==') == (b'abc', 6)
    assert encode('YQ==\n') == (b'a', 5)
    assert encode('YWI=\n') == (b'ab', 5)
    assert encode('YWJj\n') == (b'abc', 5)

# Generated at 2022-06-21 12:31:20.004503
# Unit test for function decode
def test_decode():
    """Test of 'test_decode'."""

# Generated at 2022-06-21 12:31:24.224322
# Unit test for function encode
def test_encode():
    assert encode(  # type: ignore[arg-type]
        'SGVsbG8gd29ybGQh'
    ) == (b'Hello world!', 18)
    sp_text = ''.join([
        '   bG9uZyB0ZXh0IHdpdGggCm11bHRpcGxlIGxpbmVzLg==    ',
    ])
    assert encode(  # type: ignore[arg-type]
        sp_text
    ) == (b'long text with\nmultiple lines.', 42)
    assert encode(  # type: ignore[arg-type]
        'a'
    ) == (b'a', 1)
    assert encode(  # type: ignore[arg-type]
        'a\n'
    ) == (b'a', 1)


# Generated at 2022-06-21 12:31:41.381467
# Unit test for function encode
def test_encode():
    """Test encode"""
    actual = encode('eW91IGNhbid0IHJlYWQgdGhpcyE=')
    assert actual == (b'you can\'t read this!', 24)
    actual = encode('SGVsbG8sIHdvcmxkIQ==')
    assert actual == (b'Hello, world!', 10)


# Generated at 2022-06-21 12:31:52.884983
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('TWFu') == (b'Man', 4)

# Generated at 2022-06-21 12:32:03.276171
# Unit test for function encode
def test_encode():
    assert encode(b'a') == (b'YQ==', 1)
    assert encode(b'ab') == (b'YWI=', 2)
    assert encode(b'abc') == (b'YWJj', 3)
    assert encode(b'abcd') == (b'YWJjZA==', 4)
    assert encode(b'abcde') == (b'YWJjZGU=', 5)
    assert encode(b'abcdef') == (b'YWJjZGVm', 6)
    assert encode(b'abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode(b'abcdefgh') == (b'YWJjZGVmZ2g=', 8)

# Generated at 2022-06-21 12:32:05.457936
# Unit test for function decode
def test_decode():
    """Unit test function to test function decode().
    """
    assert decode(b'abcdef') == ('YWJjZGVm', 6)



# Generated at 2022-06-21 12:32:16.122619
# Unit test for function decode
def test_decode():
    """Test the b64.decode() function."""
    assert decode(
        b'TUFOQUdFIFBVU0ggT0YgRE9ORSBUTyBHQUxMQSBURVhU\n'
        b'U1VMQVIgQklOQVJZ\n'
        b'DQo=\n'
    ) == (
        'SUFOQUdFIFBVU0ggT0YgRE9ORSBUTyBHQUxMQSBURVhU\n'
        'U1VMQVIgQklOQVJZ',
        3
    )


# Generated at 2022-06-21 12:32:25.503677
# Unit test for function encode

# Generated at 2022-06-21 12:32:32.387551
# Unit test for function register
def test_register():
    try:
        codecs.lookup(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

    # Get the codec information for the registered codec.
    info = codecs.lookup(NAME)  # type: ignore

    # Ensure the codec information is complete
    assert NAME == info.name
    assert decode == info.decode
    assert encode == info.encode


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:32:39.762305
# Unit test for function encode