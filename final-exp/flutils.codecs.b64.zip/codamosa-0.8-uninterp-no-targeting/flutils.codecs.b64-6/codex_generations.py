

# Generated at 2022-06-21 12:22:44.402472
# Unit test for function decode
def test_decode():
    assert decode(b'YWJjZA==') == ('abcd', 4)
    assert decode(b'ZGFmZ2hpamtsbW5vcA==') == ('dafghijklmnop', 16)
    assert decode(b'ZGVmZ2hpamtsbW5vcA==') == ('defghijklmnop', 16)
    assert decode(b'ZGVmZw==') == ('defg', 4)


# Generated at 2022-06-21 12:22:54.709307
# Unit test for function decode

# Generated at 2022-06-21 12:23:06.220854
# Unit test for function encode
def test_encode():
    """Ensure that the function ``encode`` is working"""
    # Test a simple base 64 string with all characters
    text_str = (
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        '0123456789+/='
    )
    out, _ = encode(text_str)
    assert out == base64.b64decode(text_str)

    # Test an indented and multiline string
    text_str = """
        ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz
        0123456789+/=
    """
    out, _ = encode(text_str)

# Generated at 2022-06-21 12:23:08.212536
# Unit test for function encode
def test_encode():
    assert encode('c2VjcmV0\n')[0] == b'secret'


# Generated at 2022-06-21 12:23:17.384137
# Unit test for function encode
def test_encode():
    assert encode("dGhpcyBpcyB3b3Jk") == (b"this is word", 16)
    assert encode("dGhpcyBpcyB3b3Jk\n") == (b"this is word", 17)
    assert encode("dGhpcyBpcyB3b3Jk\n ") == (b"this is word", 18)
    assert encode("\ndGhpcyBpcyB3b3Jk") == (b"this is word", 17)
    assert encode(" \ndGhpcyBpcyB3b3Jk") == (b"this is word", 18)
    assert encode("\ndGhpcyBpcyB3b3Jk\n ") == (b"this is word", 19)


# Generated at 2022-06-21 12:23:22.776981
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    test_input = b'\x09\x08\x07\x06\x05\x04\x03\x02\x01'
    expected_output = 'CgwTDRUZGBs='
    test_output = decode(test_input)
    assert test_output[0] == expected_output
    assert test_output[1] == len(test_input)



# Generated at 2022-06-21 12:23:31.760071
# Unit test for function decode

# Generated at 2022-06-21 12:23:35.468411
# Unit test for function encode
def test_encode():
    assert encode('A') == (b'QQ==', 1)
    assert encode('AA') == (b'QUE=', 2)
    assert encode('AAA') == (b'QUFB', 3)
    assert encode('AAAA') == (b'QUFBQQ==', 4)
    assert encode('AAAAA') == (b'QUFBQUE=', 5)
    assert encode('AAAAAA') == (b'QUFBQUE=', 6)
    assert encode('AAAAAAA') == (b'QUFBQUEA', 7)



# Generated at 2022-06-21 12:23:43.741331
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Get the the codec
    codec = codecs.getdecoder(NAME)  # type: ignore

    # Test the codec
    test_data = b'abc123'
    exp = 'b3Bp\n'
    out, n = codec(test_data)  # type: ignore
    assert n == len(test_data)
    assert out == exp


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v', '-r sxX'])

# Generated at 2022-06-21 12:23:55.031752
# Unit test for function decode
def test_decode():
    assert decode(b'ZZZ0YXV0YQ==')[0] == 'uatu'
    assert decode(b'uatu')[0] == 'dXVhdQ=='
    assert decode(b'uatu', 'strict')[0] == 'dXVhdQ=='
    assert decode(b'uatu', 'replace')[0] == 'dXVhdQ=='
    assert decode(b'uatu', 'ignore')[0] == 'dXVhdQ=='
    assert decode(b'uatu', 'backslashreplace')[0] == 'dXVhdQ=='
    assert decode(b'uatu', 'xmlcharrefreplace')[0] == 'dXVhdQ=='


# Generated at 2022-06-21 12:24:02.127603
# Unit test for function register
def test_register():
    """Test the functionality of the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


encoder = codecs.getencoder(NAME)     # type: ignore
decoder = codecs.getdecoder(NAME)     # type: ignore


# Generated at 2022-06-21 12:24:04.655773
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8gd29ybGQ=')[0] == b'Hello world'



# Generated at 2022-06-21 12:24:06.731741
# Unit test for function encode
def test_encode():
    assert encode(u'SGVsbG8gV29ybGQ=') == (b'Hello World', 14)



# Generated at 2022-06-21 12:24:09.193762
# Unit test for function register
def test_register():
    """Verify that the ``b64`` codec is registered with Python."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:24:16.793329
# Unit test for function encode

# Generated at 2022-06-21 12:24:20.005373
# Unit test for function encode
def test_encode():
    chars = """
        abcdefghijklmnopqrstuvwxyz
        ABCDEFGHIJKLMNOPQRSTUVWXYZ
        0123456789
        +/
    """
    data = encode(chars)[0]
    assert data == base64.decodebytes(chars.strip().encode('utf-8'))



# Generated at 2022-06-21 12:24:24.657018
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert b'\x01\x02\x03\x04\x05\x06\x07\x08' == encode(
        'AQIDBAUGBwgJ'
    )[0]
    assert b'\x00\x01\x02\x03\x00\x01\x02\x03' == encode(
        'AAABAAAB\nAAA=\nAAA=='
    )[0]



# Generated at 2022-06-21 12:24:28.067261
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'Failed to register {NAME!r}: {e}') from e

# Generated at 2022-06-21 12:24:30.522781
# Unit test for function decode
def test_decode():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

    assert decode(b'eWVzdWY=')[0] == 'yesuf'
    assert decode(b'cHAx')[0] == 'pq1'

#Unit test for function encode

# Generated at 2022-06-21 12:24:39.090578
# Unit test for function encode
def test_encode():
    assert encode('A==\n') == (b'\x00', 4)
    assert encode('AQ==\n') == (b'\x00\x01', 5)
    assert encode('AQI=\n') == (b'\x00\x01\x02', 6)
    assert encode('AQID\n') == (b'\x00\x01\x02\x03', 7)
    assert encode('AQ==\n\nAQI=\n\n') == (b'\x00\x01\x00\x01\x02', 13)
    assert encode('AQ==\n\tAQI=\n\t') == (b'\x00\x01\x00\x01\x02', 13)

# Generated at 2022-06-21 12:24:54.532140
# Unit test for function encode
def test_encode():
    # pylint: disable=E1120
    # noinspection PyUnresolvedReferences
    # import my_importlib
    # my_importlib.reload_module(b64)
    from b64 import encode, decode
    # import b64

    print()
    print('=' * 70)
    print()

    # Encode a few simple strings.
    print(encode('f'))
    print(encode('fo'))
    print(encode('foo'))
    print(encode('foob'))
    print(encode('fooba'))
    print(encode('foobar'))

    # Encode a string with whitespace.
    print(encode('f o o b a r foo bar'))

    # Encode a string with control characters.

# Generated at 2022-06-21 12:25:02.506936
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Save the Python codecs.
    codecs_list = [codec_info.name for codec_info in codecs.__dict__['_cache']]

    # Execute function register.
    register()

    # Get the current Python codecs.
    codecs_after = [codec_info.name for codec_info in codecs.__dict__['_cache']]

    # Verify that the b64 codec was added.
    assert NAME in codecs_after, (
            f'Codec {NAME} was not added to the Python codecs.'
    )

    # Restore the python codecs.
    for codec in codecs_list:
        if codec not in codecs_after:
            codecs.__dict__['_cache'].pop(codec)


# Generated at 2022-06-21 12:25:14.252771
# Unit test for function encode
def test_encode():
    """Send a few strings of base64 characters and expect the bytes
    equivalent to be returned."""
    # pylint: disable=W0612, W0613
    # noinspection PyUnusedLocal
    def assert_encode(encoded_bytes: bytes, text: str) -> None:
        """Assert the given ``encoded_bytes`` equal to the base64
        encoded ``text``."""
        encoded_data, consumed = encode(text)
        assert consumed == len(text)
        assert encoded_data == encoded_bytes

    assert_encode(b'', '')
    assert_encode(b'', ' ')
    assert_encode(b'', '\t')
    assert_encode(b'', '\n')
    assert_encode(b'\x00', 'AA==')
   

# Generated at 2022-06-21 12:25:23.916899
# Unit test for function encode
def test_encode():
    input = u"""
    SGVsbG8gV29ybGQhCkNvbmZpcm0gdGhlIHBlcmZvcm1hbmNlIG9mIHJlZ2lzdGVyaW5nIHRoaXMgY29kaWVzLiBVbi1j
    b21wYXJlIHRoZSBhY2NlcHQgYW5kIGV4cGVjdGVkIGVycm9ycyBhcyB5b3UgYWRkIHNpZGVnZWUgdXRpbGl0aWVz
    Lg==
    """

# Generated at 2022-06-21 12:25:27.931791
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()


if __name__ == '__main__':
    # Test the content of this module.
    from unittest import TestLoader, TextTestRunner

    test_suite = TestLoader().loadTestsFromModule(__import__(__name__))
    TextTestRunner(verbosity=2).run(test_suite)

# Generated at 2022-06-21 12:25:32.981360
# Unit test for function register
def test_register():
    """Verify that the ``register`` function registers the ``b64``
    codec with Python."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            'The b64 codec is not registered with python.'
        )

# Generated at 2022-06-21 12:25:35.492461
# Unit test for function register
def test_register():
    """Test for function :obj:`register`"""
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-21 12:25:40.597897
# Unit test for function decode
def test_decode():
    codec = codecs.getencoder(NAME)
    data = b'\xab\xcd\xef\xfe\xdc\xba'
    output, number_of_bytes = codec(data)
    assert output == 'w7jNnZmRk+g='
    assert number_of_bytes == len(data)



# Generated at 2022-06-21 12:25:43.595313
# Unit test for function decode
def test_decode():
    assert decode(b'4pWw') == ('Hello', 4)


# Generated at 2022-06-21 12:25:53.203742
# Unit test for function encode
def test_encode():
    # Test 1
    text = '''
    SGVsbG8sIFdvcmxkIQ==
    '''
    text_bytes, _ = encode(text)
    assert text_bytes == b'Hello, World!'

    # Test 2
    text = '''
    QWxwaGFudXN3YXl0ZXIudGVzdA==
    '''
    text_bytes, _ = encode(text)
    assert text_bytes == b'Alphanumeric.test'

    # Test 3
    text = '''
    cGhldG9ncmFwaHkudGVzdA==
    '''
    text_bytes, _ = encode(text)
    assert text_bytes == b'photography.test'

    # Test 4 (Fails - base64 input is not properly formatted)
   

# Generated at 2022-06-21 12:26:08.852582
# Unit test for function encode
def test_encode():
    # noinspection PyUnusedLocal
    def _get_exception_msg(
            text: str,
            errors: str = None,
            expected_output: bytes = None
    ) -> str:
        (_, exception_msg) = encode(
            text,
            errors=errors,
        )
        return exception_msg

    assert encode('')[0] == b''
    assert encode(
        '\n\n\n'
    )[0] == b''
    assert encode(
        'YWJjZGVmZ2hpamtsbW5vcA=='
    )[0] == b'abcdefghijklmnop'

# Generated at 2022-06-21 12:26:13.597343
# Unit test for function register
def test_register():
    register()
    fi = codecs.lookup(NAME)
    assert fi
    assert fi.encode(NAME, errors='strict')
    assert fi.decode(NAME, errors='strict')

# Generated at 2022-06-21 12:26:24.075512
# Unit test for function encode
def test_encode():
    # Test some documented examples.
    assert encode("Léon") == (b'4pyT', 4)
    assert encode("Léon", 'ignore') == (b'4pyT', 4)
    assert encode("Léon", 'replace') == (b'4pyT', 4)
    assert encode("Léon", 'xmlcharrefreplace') == (b'4pyT', 4)
    assert encode("Léon", 'backslashreplace') == (b'4pyT', 4)

    assert encode("\u00E9") == (b'wqo=', 4)
    assert encode("\u00E9", 'ignore') == (b'wqo=', 4)
    assert encode("\u00E9", 'replace') == (b'wqo=', 4)

# Generated at 2022-06-21 12:26:36.077353
# Unit test for function encode
def test_encode():
    """Test the function ``encode``.
    """
    def do_test(text: _STR, expected: bytes) -> None:
        """Encode a base64 string into bytes and compare it with the
        expected result.
        """
        encoded, _ = encode(text)
        assert encoded == expected

    do_test('QUJDRA==', b'ABCD')

    # noinspection SpellCheckingInspection
    do_test(
        'VXNlIG5vIGVudmlyb25tZW50IHZhcmlhYmxlcyB0byBhcHBseSBmb3JtYXR0aW5n',
        b'Use no environment variables to apply formatting'
    )


# Generated at 2022-06-21 12:26:45.358051
# Unit test for function decode
def test_decode():
    print(decode(b'Zm9vYmFy\n'))
    print(decode(b'Zm9vYmFy\nYmF6'))
    print(decode(b'Zm9vYmFy\nYmF6\nYmF6YmF6'))
    try:
        decode(b'Zm9vYmFy\nYmF6\nYmF6YmF6\n')
    except UnicodeEncodeError as e:
        print(f'Failed to decode: {e}')

# Generated at 2022-06-21 12:26:57.485079
# Unit test for function encode
def test_encode():
    """Unit test for 'encode' function"""
    assert encode('Cg==') == (b'\x00', 3)
    assert encode('Cg') == (b'\x00', 3)
    assert encode('Cg =') == (b'\x00', 3)
    assert encode('Cg==') == (b'\x00', 3)
    assert encode('Cg= =') == (b'\x00', 3)
    assert encode('Cg   =') == (b'\x00', 3)
    assert encode('Cg    =') == (b'\x00', 3)
    assert encode(' Cg==') == (b'\x00', 3)
    assert encode('Cg ==') == (b'\x00', 3)

# Generated at 2022-06-21 12:27:07.463390
# Unit test for function encode
def test_encode():
    # Simple test:
    assert encode(
        'TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1d'
    ) == (
        b'Man is distinguished, not only by his reason, but ',
        84
    )


# Generated at 2022-06-21 12:27:08.771143
# Unit test for function register
def test_register():
    register()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:27:11.432145
# Unit test for function decode
def test_decode():
    assert decode(b'\x00\x01\x02\x03\x04\x05\x06\x07') == ('AAECAwQFBg==', 8)



# Generated at 2022-06-21 12:27:21.742970
# Unit test for function register
def test_register():
    try:
        original = codecs.getdecoder(NAME)
    except LookupError:
        original = None
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        failed = True
    else:
        failed = False
    register()
    if failed:
        raise AssertionError(
            f'codecs.{NAME} failed to register.'
        )
    if original is not None:
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise AssertionError(
                f'codecs.{NAME} failed to register.'
            )



# Generated at 2022-06-21 12:27:28.405683
# Unit test for function register
def test_register():
    """Perform the unit test for function register()"""


# Generated at 2022-06-21 12:27:32.110111
# Unit test for function decode
def test_decode():
    assert decode(b'AEI')[0] == 'QUk='
    assert decode(b'AEI') == ('QUk=', 3)
    assert decode(b'AEI')[1] == 3

# Generated at 2022-06-21 12:27:43.419153
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

    assert encode('SGVsbG8gV29ybGQ=') == (b'Hello World', 15)
    assert encode('SGVsbG8gV29ybGQ')  == (b'Hello World', 14)
    assert encode('SGVsbG8gV29ybGQ ===')  == (b'Hello World', 17)
    assert encode('SGVsbG8gV29ybGQ    =')  == (b'Hello World', 17)
    assert encode('Rg==')  == (b'F', 4)
    assert encode('Rg')  == (b'F', 2)
    assert encode('Rg===')  == (b'F', 6)
    assert encode('Rg== ===')  == (b'F', 8)
    assert encode

# Generated at 2022-06-21 12:27:54.211142
# Unit test for function register
def test_register():
    """Unit test for function register()."""
    # pylint: disable=protected-access
    # Verify that the b64 codec is NOT registered.
    assert NAME not in codecs._codecs_dec  # type: ignore[attr-defined]
    assert NAME not in codecs._codecs_enc  # type: ignore[attr-defined]

    # Register the codec
    register()

    # Verify that the b64 codec is registered.
    assert NAME in codecs._codecs_dec  # type: ignore[attr-defined]
    assert NAME in codecs._codecs_enc  # type: ignore[attr-defined]

    # Verify that registering the codec again does NOT raise an exception
    register()



# Generated at 2022-06-21 12:27:57.998393
# Unit test for function register
def test_register():
    """Unit tests to cover the register() function."""
    from . import b64_register
    register()
    assert NAME in b64_register.ENCODERS
    assert NAME in b64_register.DECODERS



# Generated at 2022-06-21 12:28:02.595403
# Unit test for function encode
def test_encode():
    assert encode('Zm9vOmJhcg==') == (b'foo:bar', 11)
    assert encode('Zm9vOmJhcg==\n') == (b'foo:bar', 12)



# Generated at 2022-06-21 12:28:03.574558
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'\x00\x01\x00\x01') == ('AAA=', 4), 'decode failed'



# Generated at 2022-06-21 12:28:09.394114
# Unit test for function decode
def test_decode():
    # Test a good value
    assert decode(b"abcabcabcabcabcabcabcabcabcabcabc")[0] == "YWJjYWJjYWJjYWJjYWJjYWJjYWJjYWJjYQ=="
    
    # Test a bad value
    try:
        decode("abc")
    except UnicodeDecodeError as e:
        print("Caught exception as expected:", e.reason)
        


# Generated at 2022-06-21 12:28:16.470041
# Unit test for function decode
def test_decode():
    """Test function decode for normal operation."""
    TEST_STRING = 'abcdefghijklmnopqrstuvwxyz0123456789-_'
    EXPECTED_ENCODED = 'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5LSM='
    ENCODED = decode(bytes(TEST_STRING, "utf8"))[0]
    assert ENCODED == EXPECTED_ENCODED


# Generated at 2022-06-21 12:28:19.106249
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec with Python."""
    codecs.register(_get_codec_info)



# Generated at 2022-06-21 12:28:31.732690
# Unit test for function decode
def test_decode():
    """Test function decode()."""
    register()
    message = 'Hello World'
    bytes_ = message.encode('utf-8')
    encoded_str = message.encode('b64').decode('utf-8')
    assert decode(bytes_) == (encoded_str, len(bytes_))
    assert decode(bytes_)[1] == len(bytes_)
    assert decode(bytes_)[0] == encoded_str
    value = 'YW55IGNhcm5hbCBwbGVhc3VyZQ=='
    out = decode(value.encode('utf-8'))[0]
    assert out == 'any carnal pleasure'



# Generated at 2022-06-21 12:28:36.996894
# Unit test for function decode
def test_decode():
    assert decode(b'abcd')[0] == 'YWJjZA'
    assert decode(b'abcd')[1] == 4
    assert decode(b'abc')[0] == 'YWJjIA=='
    assert decode(b'abc')[1] == 3


# Generated at 2022-06-21 12:28:42.065595
# Unit test for function encode
def test_encode():
    assert encode(
        '''
    am8WQmFzZTY0IGRlY29kZSBtZXNzYWdlIGhhcyBzcGxpdCBvdmVyIDIg
    bGluZXMu
    '''
    ) == (b'\nBase64 decode message has split over 2 lines.', 67)


# Generated at 2022-06-21 12:28:47.968506
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is properly registered"""
    import unittest.mock
    def mock_codecs_getdecoder(encoding: str = '') -> codecs.CodecInfo:
        raise LookupError

    register()
    with unittest.mock.patch('codecs.getdecoder', mock_codecs_getdecoder):
        register()



# Generated at 2022-06-21 12:28:59.431180
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('\n\t') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('aa') == (b'YWE=', 2)
    assert encode('aaa') == (b'YWFh', 3)
    assert encode('aaaa') == (b'YWFh', 4)
    assert encode('aaab') == (b'YWFhYg==', 5)
    assert encode('aaabb') == (b'YWFhYmI=', 6)
    assert encode('aaabbb') == (b'YWFhYmJi', 7)

# Generated at 2022-06-21 12:29:01.365146
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 12:29:09.077829
# Unit test for function encode
def test_encode():
    """Test Function encode
    - Test if is encode a string to base64 is correct
    """
    test_string = "Hello World!"
    test_string_bytes = test_string.encode('ascii')
    test_base64 = base64.b64encode(test_string_bytes)
    test_base64_string = test_base64.decode('ascii')
    (res, length) = encode(test_base64_string)
    assert res == test_string_bytes and length == len(test_base64_string)



# Generated at 2022-06-21 12:29:19.566533
# Unit test for function encode

# Generated at 2022-06-21 12:29:29.301909
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # pylint: disable=C0103
    # pylint: disable=W1401
    # pylint: disable=W0612
    from base64 import b64encode as b


# Generated at 2022-06-21 12:29:32.134197
# Unit test for function register
def test_register():
    """Test Registering."""
    register()
    try:
        codec = codecs.getdecoder(NAME)  # type: ignore
        assert codec is not None
    except LookupError:
        assert False, f"Codec '{NAME}' is not registered."



# Generated at 2022-06-21 12:29:42.281096
# Unit test for function register
def test_register():
    """Test the register function"""
    register()
    try:
        # pylint: disable=W0612
        a = codecs.getdecoder(NAME)  # should not raise LookupError
    except LookupError:
        raise AssertionError(
            f'Codec {NAME!r} not registered'
        )
    else:
        assert a is not None   # nosec



# Generated at 2022-06-21 12:29:43.780134
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:29:46.414388
# Unit test for function register
def test_register():
    """Test the register function"""
    register()
    codec = codecs.getdecoder(NAME)
    codec('YWJjMTIzIT8kKiYoKSctPUB+')



# Generated at 2022-06-21 12:29:48.155118
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)

if __name__ == '__main__':
    register()

# Generated at 2022-06-21 12:29:50.310110
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 7)



# Generated at 2022-06-21 12:29:59.403229
# Unit test for function decode
def test_decode():
    """Test ``decode``."""
    from_bytes = bytes(range(256))

# Generated at 2022-06-21 12:30:04.163184
# Unit test for function decode
def test_decode():
    """Test the ``b64`` codec's ``decode()`` function."""
    expected = 'YWFhYQ=='
    data = b'aaaa'
    result, _ = decode(data)
    assert result == expected



# Generated at 2022-06-21 12:30:08.293877
# Unit test for function encode
def test_encode():
    assert encode('QlPoOTFBWSZTWbLRpIzGnkYf1rIzB8') == \
        (b'foo bar baz\n', 23)

    assert len(encode('QlPo')) == (2, 4)


# Generated at 2022-06-21 12:30:16.824059
# Unit test for function register
def test_register():
    """Script to unit test the ``register`` function.  This function must
    be called after it is passed to the ``unittest`` module.
    """
    from copy import copy
    from sys import stdout, stderr
    from unittest import main, TestCase

    from pytest import raises
    from pytest import mark as mark_test

    from .register import register as codec_register
    from .register import unregister as codec_unregister
    from .register import unregister_error


# Generated at 2022-06-21 12:30:22.832874
# Unit test for function encode
def test_encode():
    assert encode("ABC") == (b'aWJj', 3)
    assert encode("a a A a") == (b'YSBhIEEgYQ==', 9)
    assert encode("hello\n hello\r\n hello") == (b'aGVsbG9pIGhlbGxvaQ==', 14)


if __name__ == '__main__':
    test_encode()
    print('All tests passed')

# Generated at 2022-06-21 12:30:32.724695
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode``."""
    assert decode(b'\x00\x01\x02') == ('AAEC', 3)



# Generated at 2022-06-21 12:30:37.822636
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)
    assert encode('dGVz\ndA==') == (b'test', 10)
    assert encode('dGVzdA==   ') == (b'test', 6)
    assert encode('dGVzdA==   \n') == (b'test', 6)



# Generated at 2022-06-21 12:30:44.686677
# Unit test for function decode
def test_decode():
    assert (
        decode(bytes([65, 66, 67])) == (
            'QUJD', 3
        )
    )
    assert (
        decode(
            bytes([61, 61, 61]),
            errors='surrogateescape'
        ) == (
            '\ufffd\ufffd\ufffd', 3
        )
    )
    assert (
        decode(
            bytes([61, 61, 61]),
            errors='replace'
        ) == (
            '===', 3
        )
    )


# Generated at 2022-06-21 12:30:54.571455
# Unit test for function decode
def test_decode():
    v = b'\x01\x02\x03\x04\x05'
    assert decode(v)[0] == 'AQIDBAU='
    assert decode(v)[1] == 5
    assert decode(b'\xff\xfe\xfc\xfd\xfb')[0] == '/w8/f/7g=='
    assert decode(b'\x00\x00')[0] == 'AA=='
    assert decode(b'\x0fkk\x0f')[0] == 'GmtpGg=='
    assert decode(b'y\x0f\x0f')[0] == 'eQ=='
    assert decode(b'~\xfe\xff')[0] == 'ff4='

# Generated at 2022-06-21 12:31:04.802988
# Unit test for function decode
def test_decode():
    assert decode(b'U3RhcjI0') == ('Star24', 8)
    assert decode(b'U3RhcjI0')[0] == 'Star24'
    assert decode(b'U3RhcjI0')[1] == 8
    # Test byte array
    assert decode(bytearray(b'U3RhcjI0')) == ('Star24', 8)
    assert decode(bytearray(b'U3RhcjI0'))[0] == 'Star24'
    assert decode(bytearray(b'U3RhcjI0'))[1] == 8
    # Test memory view
    assert decode(memoryview(bytearray(b'U3RhcjI0'))) == ('Star24', 8)

# Generated at 2022-06-21 12:31:13.397269
# Unit test for function register
def test_register():
    """Test the :obj:`register` function."""
    def check_register():
        """Check that the register function correctly registers the ``b64``
        codec.
        """
        try:
            codecs.getencoder(NAME)
        except LookupError:
            register()
            codecs.getencoder(NAME)
    # Check that the 'b64' codec is not registered.
    try:
        codecs.getencoder(NAME)
    except LookupError:
        # Good - nothing to unregister.
        check_register()
    else:
        # The codec is already registered.  So unregister it and reregister it.
        codecs.unregister(NAME)
        check_register()
        codecs.unregister(NAME)

register()

# Generated at 2022-06-21 12:31:20.558954
# Unit test for function decode
def test_decode():
    from pytools.python.pytools import ascii


# Generated at 2022-06-21 12:31:29.374443
# Unit test for function decode
def test_decode():
    for s, t in [
            (
                b'AAAA',
                'AAAA'
            ),
            (
                b'\x00\x00\x00\x00',
                'AAAAAAAA'
            ),
            (
                b'\x01\x01\x01\x01',
                'AQEBAQEBAQE='
            ),
            (
                b'\x01\x01\x01\x02',
                'AQEBAQECAg=='
            ),
    ]:
        result = decode(s)
        assert result[0] == t
        assert result[1] == len(s)


# Generated at 2022-06-21 12:31:32.636459
# Unit test for function encode
def test_encode():
    text = '''
        The quick brown fox jumped over the lazy dog.
    '''
    str_bytes, _ = encode(text)
    assert str_bytes == base64.b64decode(text)


# Generated at 2022-06-21 12:31:39.419701
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert (b'', 0) == encode('')
    assert (b'', 0) == encode('\n')
    assert (b'', 0) == encode('\n\n')
    assert (b'', 0) == encode('\t')
    assert (b'', 0) == encode('\t\t')
    assert (b'', 0) == encode('  ')
    assert (b'', 0) == encode('\t\t    ')
    assert (b'', 0) == encode('\n\n  \t  \t   \t\n\n')
    assert (b'', 0) == encode('   \n  \t  \t   \t\n  \n')

# Generated at 2022-06-21 12:31:50.861442
# Unit test for function register
def test_register():  # pylint: disable=W0613,C0116
    """Get the ``b64`` codec"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:31:55.558614
# Unit test for function decode
def test_decode():
    """Test the ``codec.decode`` function."""
    from codecs import decode
    from ..test.test_b64 import get_b64_test_instances
    for data, expected in get_b64_test_instances():
        actual = decode(data, 'b64')
        assert expected == actual


# Generated at 2022-06-21 12:32:04.146374
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is properly registered with Python."""
    # pylint: disable=W0212

    # pylint: disable=W0703
    try:
        register()
    except Exception as e:
        print(f'Failed to register the ``{NAME}`` codec: {e}')
        raise

    try:
        assert codecs.getdecoder(NAME) is not None
    except Exception as e:
        print(f'Could not find the ``{NAME}`` codec: {e}')
        raise



# Generated at 2022-06-21 12:32:15.643010
# Unit test for function decode
def test_decode():
    """Test ``decode`` against known results."""
    import unittest
    import unittest.mock as mock
    from binascii import Error
    from typing import (  # noqa: F401
        Dict,
        List,
        Tuple,
    )

    class TestDecode(unittest.TestCase):
        """TestDecode"""
        def setUp(self):
            """Set up test fixtures, if any."""

# Generated at 2022-06-21 12:32:24.812069
# Unit test for function encode
def test_encode():
    # Valid Inputs
    assert ('dGVzdA==', 4) == encode('dGVzdA==')
    assert ('dGVzdA==', 4) == encode(' dGVzdA==')
    assert ('dGVzdA==', 4) == encode('dGVzdA== ')
    assert ('dGVzdA==', 4) == encode(' dGVzdA== ')
    assert ('dGVzdA==', 4) == encode('\n\ndGVzdA==\r\r')
    assert ('dGVzdA==', 4) == encode('\ndGVzdA==')
    assert ('dGVzdA==', 4) == encode('dGVzdA==\n')

# Generated at 2022-06-21 12:32:34.888946
# Unit test for function encode
def test_encode():
    # Given: A string of base64 characters.
    text = "QQogICAgICBxdGFtYQoKICAgICAgeXJhbApCCiAgICAg"
    text = text + "IHF0YW1hCgogICAgICB5cmFsCg=="

    # When: I convert the text into base64 bytes
    bytes_output, _ = encode(text)

    # Then: Expect the output bytes to be equivalent to the given text.

# Generated at 2022-06-21 12:32:36.611908
# Unit test for function decode
def test_decode():
    assert decode(bytes("b3BlcmF0b3I=",encoding='utf-8'))[0] == "operator"

# Generated at 2022-06-21 12:32:47.055181
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(b'\x00')[0] == '/w=='
    assert decode(b'\0')[0] == '/w=='
    assert decode(b'o')[0] == 'bw=='
    assert decode(b'oo')[0] == 'b28='
    assert decode(b'foo')[0] == 'Zm9v'
    assert decode(b'foob')[0] == 'Zm9vYg=='
    assert decode(b'fooba')[0] == 'Zm9vYmE='
    assert decode(b'foobar')[0] == 'Zm9vYmFy'

    assert decode(b'\x00'*1000000)[0] == '/w=='*1000000