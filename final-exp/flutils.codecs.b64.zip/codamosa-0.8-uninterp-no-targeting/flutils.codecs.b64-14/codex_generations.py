

# Generated at 2022-06-21 12:22:31.466848
# Unit test for function register
def test_register():
    """Unit test for module function register()."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Unable to load the {NAME!r} codec: {e}.')



# Generated at 2022-06-21 12:22:37.154032
# Unit test for function decode
def test_decode():

    assert decode(b'AQID', 'strict') == ("QUJD", 4)
    assert decode(b'QUJDRA==', 'strict') == ("ABCDE", 8)
    assert decode(b'QUJDREU=', 'strict') == ("ABCDEF", 8)
    assert decode(b'QUJDREVG', 'strict') == ("ABCDEFG", 8)

    assert decode(b'AQID', 'ignore') == ("QUJD", 4)
    assert decode(b'QUJDRA==', 'ignore') == ("ABCDE", 8)
    assert decode(b'QUJDREU=', 'ignore') == ("ABCDEF", 8)
    assert decode(b'QUJDREVG', 'ignore') == ("ABCDEFG", 8)


# Generated at 2022-06-21 12:22:40.876897
# Unit test for function encode
def test_encode():
    """Test the encode() function."""
    text = '''
                YW55IGNhcm5hbCBwbGVhc3VyZQ==
            '''
    res = encode(text)
    assert res == (b'any carnal pleasure', 64)



# Generated at 2022-06-21 12:22:46.277829
# Unit test for function register
def test_register():
    """Unit test for function ``register`` in module ``b64``."""
    # pylint: disable=unused-import, protected-access
    from b64._b64 import register as register2, _get_codec_info
    register2()

    out = codecs.getdecoder(NAME)
    assert out == _get_codec_info(NAME)



# Generated at 2022-06-21 12:22:49.933593
# Unit test for function register
def test_register():
    """Test that function register will register the ``b64`` codec."""
    register()
    # If everything works, the next line should not raise an exception
    codecs.getdecoder(NAME)


# This code will execute when the python module is loaded
test_register()

# Generated at 2022-06-21 12:22:51.500526
# Unit test for function register
def test_register():
    """Test that the ``register`` function does not raise any exceptions
    when called.
    """
    register()



# Generated at 2022-06-21 12:22:54.049820
# Unit test for function encode
def test_encode():
    assert encode('dGhpcyBpcyBhIHRlc3Q=') == (b'this is a test', 24)



# Generated at 2022-06-21 12:22:55.760246
# Unit test for function register
def test_register():
    codecs._getcodecinfo_cache.clear()
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-21 12:23:07.807343
# Unit test for function decode
def test_decode():
    assert b'\x80' == base64.b64decode(decode(b'\x80')[0])

    assert b'Hello World' == base64.b64decode(decode(b'Hello World')[0])

    assert b'Hello World' == base64.b64decode(decode(b'\nHello World')[0])

    assert b'Hello World' == base64.b64decode(decode(b'\r\nHello World')[0])

    assert b'Hello World' == base64.b64decode(decode(b'\rHello World')[0])

    assert b'Hello World' == base64.b64decode(decode(b' \t\nHello World')[0])


# Generated at 2022-06-21 12:23:09.032865
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-21 12:23:15.041204
# Unit test for function encode
def test_encode():
    s = '''
    Zm9vCmJhcgo=
    '''
    assert encode(s)[0] == b'\nfoo\nbar\n'
    try:
        encode(b'garbage')
        assert False
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-21 12:23:21.948538
# Unit test for function encode
def test_encode():
    assert encode('Ym9iYXN0aWFu') == (b'bobastian', 8)
    assert encode('ZmVsaXBl') == (b'felipe', 6)
    assert encode('Ym9iYXN0aWFu\nZmVsaXBl') == (b'bobastian\nfelipe', 17)

    

# Generated at 2022-06-21 12:23:31.730356
# Unit test for function encode
def test_encode():
    """Unit test for function `encode`."""
    bs = b'abcabcabcabcabcabcabcabcabcabcabcab\n'
    bs += b'cabcabcabcabcabcabcabcabcabcabcab\n'
    bs += b'cabcabcabcabcabcabcabcabcabcabcab\n'
    bs += b'cabcabcabcabcabcabcabcabcabca'
    decode_data, len_data = encode(bs.decode())
    assert bs == decode_data
    assert len(bs) == len_data


# Generated at 2022-06-21 12:23:39.542769
# Unit test for function decode

# Generated at 2022-06-21 12:23:47.949759
# Unit test for function decode
def test_decode():
    """Test the function decode"""

# Generated at 2022-06-21 12:23:52.485596
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(b'\x01\x02') == ('AQI=', 2)
    assert decode(b'test') == ('dGVzdA==', 4)
    assert decode(b'\x01\x02\x03\x04') == ('AQIDBA==', 4)
    assert decode(
        b'\x19\x05\x00\xad\x1a\xd3\xad\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    ) == ('EQAAN8ZUAAA=', 16)

# Generated at 2022-06-21 12:23:54.478065
# Unit test for function register
def test_register():
    """Test function register."""
    # Reset the codec registry

# Generated at 2022-06-21 12:24:05.433968
# Unit test for function encode
def test_encode():
    """Unit test for function `encode`"""
    assert encode('') == (b'', 0)
    assert encode('U29tZUJpdHM=') == (b'SomeBits', 9)
    assert encode('U29tZUJpdHM=\n') == (b'SomeBits', 9)
    assert encode('U29tZUJpdHM=\n\t') == (b'SomeBits', 9)
    assert encode('U29tZUJpdHM=\n\t  ') == (b'SomeBits', 9)
    assert encode('U29tZUJpdHM=\n\t  \n\t  ') == (b'SomeBits', 9)

# Generated at 2022-06-21 12:24:08.469534
# Unit test for function decode
def test_decode():
    # Test that the decode function returns a string of the expected value
    inpt = b'\x06\x9a\x0c'
    assert decode(inpt)[0] == 'CjI='



# Generated at 2022-06-21 12:24:13.108249
# Unit test for function decode
def test_decode():
    encoded_str = b'YmFzZTY0IGVuY29kZWQgYnVmZmVy'
    expected_bytes = b'base64 encoded buffer'
    assert decode(encoded_str)[0] == expected_bytes



# Generated at 2022-06-21 12:24:22.914865
# Unit test for function encode

# Generated at 2022-06-21 12:24:24.339742
# Unit test for function encode
def test_encode():
    assert encode('RXXX')[0] == b'ab'

# Generated at 2022-06-21 12:24:29.861414
# Unit test for function register
def test_register():
    """Test the ``register()`` function."""
    print('Testing: register()')

    register()
    try:
        # pylint: disable=unused-variable
        codecs.getdecoder(NAME)
    except LookupError as e:
        print(f'Failed to register the {NAME} codec: {e}')
        raise



# Generated at 2022-06-21 12:24:32.287184
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG8=\n') == ('Hello', 7)



# Generated at 2022-06-21 12:24:39.470225
# Unit test for function decode
def test_decode():
    assert decode(b'Rm9yIG11bHRpcGxlIGxpbmVz') == ('Rm9yIG11bHRpcGxlIGxpbmVz',24)
    assert decode(b'VGhpcyBjb21tZW50IGlzIHRlc3RpbmcgdGhlIGJhc2U2NCBjb2RlYyBmb3IgRm9yIG11bHRpcGxlIGxpbmVz') == ('VGhpcyBjb21tZW50IGlzIHRlc3RpbmcgdGhlIGJhc2U2NCBjb2RlYyBmb3IgRm9yIG11bHRpcGxlIGxpbmVz', 81)


# Generated at 2022-06-21 12:24:50.761007
# Unit test for function encode
def test_encode():
    test_text = """
                ZXh0ZXJuYWwgdXJsKGh0dHA6Ly93d3cuYmxvZ2d5bS5jb20pIGJ5IHRoZSBjcmVhdG9ycyBvZiB0aGUgYmxvZ2d5
                bSBweXRob24gcGx1Z2luIGNvbXBhcmF0b3IgYXBwbGljYXRpb24u
                """
    test_bytes = b"external url(http://www.bloggym.com) by the creators of the bloggym python plugin comparator application."
    test_output = encode(test_text)
    assert test_output == (test_bytes, len(test_text))



# Generated at 2022-06-21 12:24:59.774099
# Unit test for function decode
def test_decode():
    """Test function :meth:`~b64.decode`."""
    from .test_data import (
        B64_BYTES_MULTI_LINE_UTF8,
        B64_BYTES_SINGLE_LINE_UTF8,
    )

    # Test single line.
    obj = decode(B64_BYTES_SINGLE_LINE_UTF8)[0]
    assert obj == B64_BYTES_SINGLE_LINE_UTF8.decode('utf-8')

    # Test multi lines.
    obj = decode(B64_BYTES_MULTI_LINE_UTF8)[0]
    assert obj == B64_BYTES_MULTI_LINE_UTF8.decode('utf-8')



# Generated at 2022-06-21 12:25:06.558784
# Unit test for function register
def test_register():
    import sys

    # Capture the current codec map dictionary
    old_codec_map = sys.getfilesystemencoding()

    # Register the b64 codec.
    register()

    # Capture the new codec map dictionary
    new_codec_map = sys.getfilesystemencoding()

    # Ensure the codec map was changed.
    assert old_codec_map != new_codec_map



# Generated at 2022-06-21 12:25:10.073966
# Unit test for function register
def test_register():
    register()  # pragma: no cover
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Unit test function encode

# Generated at 2022-06-21 12:25:12.008843
# Unit test for function register
def test_register():
    """Test for function register"""
    register()
    codecs.getdecoder(NAME)

test_register()

# Generated at 2022-06-21 12:25:16.476067
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()



# Generated at 2022-06-21 12:25:17.805748
# Unit test for function register
def test_register():
    register()
    # Ensure the codec is registered.
    assert NAME in codecs.__all__



# Generated at 2022-06-21 12:25:19.958599
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8sIHdvcmxk') == ('hello, world', 16), \
        'decode function failed'


# Generated at 2022-06-21 12:25:28.126853
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    from os.path import basename, dirname
    from inspect import getabsfile

    from importlib import reload

    # noinspection PyUnresolvedReferences
    del sys.modules['b64']

    target_module = __name__.split('.')[0]
    module_path = getabsfile(sys.modules[target_module])
    full_module_name = f'{target_module}.{basename(module_path)}'
    sys.path.insert(0, dirname(module_path))
    mod = __import__(full_module_name)
    reload(mod)
    register()
    assert mod == sys.modules[target_module]



# Generated at 2022-06-21 12:25:39.741173
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`encode`"""
    assert encode('YmFzZTY0') == (b'base64', 6)
    assert encode('YmFzZTY0')[0] == b'base64'
    text_str = """
        cG9zdHA6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2FjY2Vzc2JhbmNvcy9hY2Nlc3NiYW5jb3MvbWFzdGVyL3J1\n
        bGUudHh0\n"""

# Generated at 2022-06-21 12:25:46.282577
# Unit test for function decode
def test_decode():
    """ Test the decode function """
    # Test case 1
    text = """
    QWErTYIoP=asdFGHJklZXCvbNMnQASD\\
    =
    """
    result = decode(text)
    assert result[0] == "QWErTYIoPasdFGHJklZXCvbNMnQASD"
    assert result[1] == 29

    # Test case 2
    text = """

    """
    result = decode(text)
    assert result[0] == ""
    assert result[1] == 2


# Generated at 2022-06-21 12:25:49.789617
# Unit test for function register
def test_register():
    register()
    actual = get_codec_info(NAME)

# Generated at 2022-06-21 12:25:51.702095
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG8sIFdvcmxkIQ==\n') == ('Hello, World!', 25)


# Generated at 2022-06-21 12:25:58.101388
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # pylint: disable=import-outside-toplevel
    from binascii import hexlify, unhexlify

# Generated at 2022-06-21 12:26:08.474799
# Unit test for function decode
def test_decode():
    """Unit test for the ``b64.decode`` function."""

# Generated at 2022-06-21 12:26:22.038278
# Unit test for function encode
def test_encode():
    assert encode('c29tZSBkYXRhIGluIGEgYmFzZSA2NCBmb3JtYXQ=') == \
        (b'\x00some data in a base 64 format', 32)
    assert encode('c29tZSBkYXRhIGluIGEgYmFzZSA2NCBmb3JtYXQ') == \
        (b'\x00some data in a base 64 format', 32)
    assert encode('c29tZSBkYXRhIGluIGEgYmFzZSA2NCBmb3JtYXQ=\n') == \
        (b'\x00some data in a base 64 format', 32)

# Generated at 2022-06-21 12:26:33.614008
# Unit test for function register
def test_register():
    """Test function register."""
    # Get a copy of the base64 codec info object
    base64_codec_info = codecs.getdecoder('base64')

    # Unregister the base64 codec.
    codecs.unregister('base64')

    # Register the b64 codec, this will cause an error since the base64
    # codec is no longer registered and the 'b64' codec requires the
    # base64 codec to be registered.
    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)   # type: ignore

    # Register the base64 codec. This should pass without error.
    codecs.register(base64_codec_info)

    # Get the b64 codec info and compare it to the base64 codec info.
    b64_codec_info = codecs

# Generated at 2022-06-21 12:26:41.524669
# Unit test for function decode
def test_decode():
    num = 100000
    data = bytes(range(0, num))

    # Test that the given 'data' is converted to the expected base64 characters.
    converted, length = decode(data)
    assert num == length
    assert base64.b64encode(data) == converted.encode('utf-8')

    # Test the given data is bytes.
    with pytest.raises(TypeError):
        decode(data.decode('utf-8'))

    # Test that non-base64 byte sequences throw a UnicodeEncodeError
    seq = [0xFF, 0xFF]

    # Test that 'seq' is converted to the expected base64 characters.
    converted, length = decode(seq)
    assert len(seq) == length

# Generated at 2022-06-21 12:26:48.774742
# Unit test for function decode
def test_decode():
    """Test the decode function."""

# Generated at 2022-06-21 12:26:51.218005
# Unit test for function register
def test_register():
    """Test whether the codec is registered."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:27:01.523233
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' \n') == (b'', 0)
    assert encode('==') == (b'', 0)
    assert encode('TWFu') == (b'Man', 4)

# Generated at 2022-06-21 12:27:06.925478
# Unit test for function encode
def test_encode():
    test_cases = [
        (
            'RXNlcnZpY2VVc2VyOmxlYW5vQGFjbWUuY29tOjEyMzQ1Ng==',
            'MTIzNDU2',
        ),
        (
            'RXNlcnZpY2VVc2VyOmxlYW5vQGFjbWUuY29tOjEyMzQ1Ng==',
            'MTIzNDU2',
        ),
        (
            'R2lybGFudGljOmxhbm9AZHVtZS5jb206MTIzNDU2',
            'MTIzNDU2',
        ),
    ]
    for case in test_cases:
        in_str, out_

# Generated at 2022-06-21 12:27:15.815702
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    from typing import Callable

    # Since 'register' is a noop if the codec is already registered, to test
    # that the codec was registered, remove the codec from this python
    # instance.
    del codecs.decode
    assert codecs.decode is None
    register()
    assert isinstance(
        codecs.decode,
        Callable,
    )


if __name__ == '__main__':
    print('encode(decode(input_string))')

# Generated at 2022-06-21 12:27:26.291819
# Unit test for function encode
def test_encode():
    """Test for expected exceptions and normal cases of encode."""
    assert encode('') == (b'', 0)
    assert encode('g') == (b'Zw==', 1)
    assert encode('h') == (b'aA==', 1)
    assert encode('ha') == (b'aGE=', 2)
    assert encode('haz') == (b'aGF6', 3)
    assert encode('hazy') == (b'aGF6eQ==', 4)
    assert encode('hazyd') == (b'aGF6eWQ=', 5)
    assert encode('hazydu') == (b'aGF6eWR1', 6)
    assert encode('hazydui') == (b'aGF6eWR1aQ==', 7)

# Generated at 2022-06-21 12:27:28.537797
# Unit test for function register
def test_register():
    """Test :func:`register`."""
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:27:36.690320
# Unit test for function decode
def test_decode():
    """Test the function decode."""
    data_bytes: bytes = bytes(b'\x0b\x0b')
    expected_return: bytes = b'Cg=='

    # Call the function
    actual_return, _ = decode(data_bytes)

    # Ensure test_obj is equal to expected_return
    assert expected_return == actual_return

# Generated at 2022-06-21 12:27:41.987811
# Unit test for function encode
def test_encode():
    """Test function encode"""
    text = 'Test string'
    to_encode = text.encode('utf-8')
    encoded = encode(to_encode)[0].decode('utf-8')
    decoded = base64.b64decode(encoded).decode('utf-8')
    assert text == decoded

# Generated at 2022-06-21 12:27:54.451060
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('\n',) == (b'', 1)
    assert encode('SGVsbG8sIFdvcmxkIQ') == (
        b'Hello, World!',
        len('SGVsbG8sIFdvcmxkIQ')
    )
    assert encode('SGV5LCBNeSBtb25leSAxMjMh') == (
        b'Hey, My money 123!',
        len('SGV5LCBNeSBtb25leSAxMjMh')
    )
    assert encode('Rm9vCkJhcgo=') == (b'Foo\nBar\n', len('Rm9vCkJhcgo='))



# Generated at 2022-06-21 12:28:06.361466
# Unit test for function encode
def test_encode():
    """Test the function encode."""

    # Test that the encode function takes text, converts it into base64
    # bytes, and returns the number of characters converted.

    # Simple text with only two lines
    s = '\n'.join([
        'Foo',
        'Bar'
    ])
    expected_b64 = 'Rm9vQmFy'
    expected_len = len(s)
    out, len1 = encode(s)
    assert len1 == expected_len
    assert out == expected_b64.encode('utf-8')

    # Text with multiple lines and indents
    s = '\n'.join([
        '  Foo',
        'Bar',
        '   Baz',
        'FooBar'
    ])

# Generated at 2022-06-21 12:28:13.352956
# Unit test for function decode
def test_decode():
    assert decode(b'12345') == ('MTIzNDU=', 5)
    assert decode(b'\xff\xfe\xdd') == ('//4=', 3)
    assert decode(b'1') == ('MQ==', 1)
    assert decode(b'12') == ('MTI=', 2)
    assert decode(b'123') == ('MTIz', 3)



# Generated at 2022-06-21 12:28:16.513108
# Unit test for function encode
def test_encode():
        text = 'YWJj'
        out, len_of_text = encode(text)
        assert isinstance(out, bytes)
        assert out == b'abc'
        assert len_of_text == len(text)



# Generated at 2022-06-21 12:28:19.532607
# Unit test for function encode
def test_encode():
    """Test the encode function"""
    assert encode("This is a test") == (b'VGhpcyBpcyBhIHRlc3Q=', 16)


# Generated at 2022-06-21 12:28:29.826786
# Unit test for function decode
def test_decode():
    assert decode(
        data=b'\x1f\x8b\x08\x08\x6c\x05\xd1\x5c\x00\x03\x6c\x6f\x6f\x6b\x69\x6e\x67\x2e\x67\x7a\x00\xf3\x48\xcd\xc9\xc9\xd7\x51\x28\xcf\x2f\xca\x49\xe1\x02\x00\x8d\xcc\x9a\x7d\x0f\x00\x00\x00',
        errors='strict',
    ) == ('\n{ "name": "John Doe" }\n', 31)

# Generated at 2022-06-21 12:28:41.441933
# Unit test for function encode
def test_encode():
    # pylint: disable=W0612
    global encode
    # pylint: enable=W0612

    # What is the unicode representation of the string?

    # print("✓ ✓ ✓")
    # > '✓ ✓ ✓'
    # >>> '✓ ✓ ✓'.encode('utf-8')
    # > b'\xe2\x9c\x93 \xe2\x9c\x93 \xe2\x9c\x93'
    # >>> base64.b64encode(b'\xe2\x9c\x93 \xe2\x9c\x93 \xe2\x9c\x93')
    # > b'4pyX4pyX4pyX'
    t = '✓ ✓ ✓'

# Generated at 2022-06-21 12:28:52.604804
# Unit test for function encode
def test_encode():
    """Test that ``encode(text)`` work correctly.

    This function will fail if the given ``text`` does not throw
    a ``ValueError``.
    """
    def is_valid_char(char):
        return 'A' <= char <= 'Z' or 'a' <= char <= 'z' or \
            '0' <= char <= '9' or char == '+' or char == '/' or \
            char == '=' or char in ' \n\t\r'

    # The value of the ``text`` must be a valid base64 character.
    text = '\n'.join(
        filter(
            lambda line: is_valid_char(line[0]),
            TEXT
        )
    )

    encode(text)



# Generated at 2022-06-21 12:29:01.819695
# Unit test for function decode
def test_decode():
    assert decode(b'A')[0] == 'QQ==', 'decode did not work'
    assert decode(b'AB', errors='strict')[0] == 'QUI=', 'decode did not work'
    assert decode(b'ABC', errors='strict')[0] == 'QUJD', 'decode did not work'
    assert decode(b'ABCD', errors='strict')[0] == 'QUJDRA==', 'decode did not work'


# Generated at 2022-06-21 12:29:07.034088
# Unit test for function register
def test_register():  # pylint: disable=W0613
    """Test the function register()."""
    register()
    assert NAME == codecs.lookup(NAME).name
    assert NAME == codecs.lookup(NAME).encode('utf-8').decode('utf-8')


# Unit tests for function decode

# Generated at 2022-06-21 12:29:08.523370
# Unit test for function encode
def test_encode():
    assert encode('c2F2ZQ==\n') == (b'save', 6)


# Generated at 2022-06-21 12:29:19.071991
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(b'AQIDBAUGBwgJCgsMDQ4PEA') == ('AgMDAwQFBgcICQsLDA0ODxA', 24)
    assert decode(b'AgMDAwQFBgcICQsLDA0ODxA') == ('AwMDAwQFBgcICQsLDA0ODxA', 24)
    assert decode(b'AwMDAwQFBgcICQsLDA0ODxA') == ('BAMDAwQFBgcICQsLDA0ODxA', 24)
    assert decode(b'BAMDAwQFBgcICQsLDA0ODxA') == ('BAQDAwQFBgcICQsLDA0ODxA', 24)

# Generated at 2022-06-21 12:29:28.800126
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('aa') == (b'YWE=', 2)
    assert encode('aaa') == (b'YWFh', 3)
    assert encode('hi') == (b'aGk=', 2)
    assert encode('hi') == (b'aGk=', 2)
    assert encode('hello') == (b'aGVsbG8=', 5)
    assert encode('hello') == (b'aGVsbG8=', 5)
    assert encode('hi there') == (b'aGkgdGhlcmU=', 9)
    assert encode('hi there') == (b'aGkgdGhlcmU=', 9)
    assert encode('hi     there')

# Generated at 2022-06-21 12:29:31.881421
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert test_encode.__globals__['encode']('dXNlcl9uYW1lOnBhc3N3b3JkCg==\n') == (b'user_name:password', 19)



# Generated at 2022-06-21 12:29:42.642038
# Unit test for function encode
def test_encode():
    """Test the :func:`b64.encode` function."""

# Generated at 2022-06-21 12:29:50.395373
# Unit test for function register
def test_register():
    """Test the register function."""
    import sys
    import os
    import io

    def export_string(text: str) -> None:
        """Export the given string to a file.

        This function simulates the ``export`` bash command; it writes the
        given string to a file.

        Args:
            text (str): The text to write to a file.
        """
        with open('_test_'.encode('utf-8'), 'w+') as f:
            f.write(f'{text}\n')

    def import_string() -> str:
        """Import and return a string from a file.

        This function simulates the ``import`` bash command; it reads a
        string from a file and returns it.

        Returns:
            str: The text read from the file.
        """

# Generated at 2022-06-21 12:29:59.444618
# Unit test for function encode

# Generated at 2022-06-21 12:30:10.943235
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""

# Generated at 2022-06-21 12:30:18.919817
# Unit test for function decode
def test_decode():
    input_b = b'Hello, my name is Rose.'
    input_b64 = 'SGVsbG8sIG15IG5hbWUgaXMgUm9zZS4='
    assert decode(input_b)[0] == input_b64


# Generated at 2022-06-21 12:30:26.718317
# Unit test for function encode
def test_encode():
    # pylint: disable=W0621
    from valar import Assert
    Assert(
        encode(
            'QSBzdHJpbmcgb2YgYmFzZTY0IGNoYXJhY3RlcnMu\n'
            'Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4u\n'
            'Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4u',
        ),
        (
            b'A string of base64 characters.......................\n'
            b'...............................................'
        ),
    )

# Generated at 2022-06-21 12:30:38.066086
# Unit test for function decode
def test_decode():
    """Test the function `decode`."""
    # Make sure that the text is not a valid base64 character string.
    assert decode(b'\x00\x00\x00\x00\x00\x00\x00\x00')[0] == 'AAAAAAAA'
    assert decode(b'\x00\xff\x00\x00\x00\xff\x00\x00')[0] == 'AP8A/wD/'
    # Test the 'b' flag
    assert decode(b'\x00\x00\x00\x00\x00\x00\x00\x00')[0][3] == 'A'

# Generated at 2022-06-21 12:30:43.134295
# Unit test for function decode
def test_decode():
    """
    test the 'decode' function
    """
    data = b'this is a test for b64 encoding'
    decoded_str, _ = decode(data)
    assert decoded_str == 'dGhpcyBpcyBhIHRlc3QgZm9yIGI2NCBlbmNvZGluZw=='



# Generated at 2022-06-21 12:30:53.136510
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    text = 'AQIDBAUGBwgJCgsMDQ4PEA=='
    assert decode(text) == (
        b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f',
        24
    )
    assert decode('AQIDBAUGBwgJCgsMDQ4PEA==   \n') == (
        b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f',
        24
    )

# Generated at 2022-06-21 12:31:04.330930
# Unit test for function encode
def test_encode():
    """Test the encode function."""

# Generated at 2022-06-21 12:31:11.347563
# Unit test for function register
def test_register():
    """Test b64.register()"""
    # pylint: disable=protected-access
    # Get the codec from the codecs module
    codec = codecs.__all__[-1]
    # Get the encoder and decoder for the codec
    decoder = codecs._decode_getters[codec]
    encoder = codecs._encode_getters[codec]

    # Ensure the codec is b64
    assert codec == NAME

    # Ensure that the encoder and decoder are the b64 functions.
    assert decoder == decode  # type: ignore
    assert encoder == encode  # type: ignore


# Generated at 2022-06-21 12:31:19.379985
# Unit test for function decode

# Generated at 2022-06-21 12:31:22.051191
# Unit test for function encode
def test_encode():
    assert(encode(b'AQID') == (b'\x01\x02\x03', 4))


# Generated at 2022-06-21 12:31:28.380623
# Unit test for function decode
def test_decode():
    # Test for the case where the data is not a bas64 character string
    # noinspection PyUnusedLocal
    def run(data: _ByteString, errors: _STR = 'strict') -> Tuple[str, int]:
        return "1111", 4

    try:
        run(b'12345')
    except UnicodeEncodeError as e:
        print(e)


register()
if __name__ == '__main__':
    test_decode()
    # run(b'abc')

# Generated at 2022-06-21 12:31:34.121885
# Unit test for function decode
def test_decode():
    assert decode(bytes([0x11]) + bytes([0x22]), errors='strict') == ('DQo=', 2)



# Generated at 2022-06-21 12:31:40.554579
# Unit test for function encode
def test_encode():
    input_base64 = 'aGVsbG8='
    output_bytes = b'hello'

    # Convert the given 'text', that are of type UserString into a str.
    text_input = str(input_base64)

    # Cleanup whitespace.
    text_str = text_input.strip()
    text_str = '\n'.join(
        filter(
            lambda x: len(x) > 0,
            map(lambda x: x.strip(), text_str.strip().splitlines())
        )
    )

    # Convert the cleaned text into utf8 bytes
    text_bytes = text_str.encode('utf-8')

# Generated at 2022-06-21 12:31:46.324233
# Unit test for function decode
def test_decode():
    text = '''
    The rain in Spain
    falls mainly on the plains
    '''
    expected_bytes = text.encode('utf-8')
    encoded_str = encode(text)
    encoded_bytes = base64.b64encode(expected_bytes)
    assert encoded_str == encoded_bytes.decode('utf-8')
    assert decode(encoded_bytes)[0] == text
    assert decode(encoded_str)[0] == text


# Generated at 2022-06-21 12:31:55.628569
# Unit test for function decode
def test_decode():
    # Test decoding bytes
    assert decode(b'AQIDBAUGBwgJ') == ('AQIDBAUGBwgJ', 11)

    # Test decoding a memoryview of bytes
    mem = memoryview(b'AQIDBAUGBwgJ')
    assert decode(mem) == ('AQIDBAUGBwgJ', 11)

    # Test decoding a bytearray
    b_arr = bytearray(b'AQIDBAUGBwgJ')
    assert decode(b_arr) == ('AQIDBAUGBwgJ', 11)



# Generated at 2022-06-21 12:32:06.199121
# Unit test for function encode
def test_encode():
    print()

# Generated at 2022-06-21 12:32:17.115285
# Unit test for function encode
def test_encode():
    """Test the encodeing of base64 characters."""
    # pylint: disable=line-too-long

    # Test for an empty string.
    out = encode('')
    assert out == (b'', 0)

    # Test for a string of base64 characters.
    out = encode('YWJj')
    assert out == (b'abc', 4)

    # Test for a string of base64 characters split across two lines.
    out = encode('YWJj' + '\n' + 'ZGVm')
    assert out == (b'abcdef', 8)

    # Test for a string of base64 characters split across two lines,
    # and with a space indented by one space between the lines.
    out = encode('YWJj' + '\n' + ' ZGVm')

# Generated at 2022-06-21 12:32:20.044044
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Unit tests for function encode
# noinspection PyProtectedMember

# Generated at 2022-06-21 12:32:22.655620
# Unit test for function register
def test_register():
    """Unit test for register"""
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:32:33.441137
# Unit test for function encode
def test_encode():
    # Calling encode() with the example string from the module's docstring.
    text = """
      YQ==
      YWI=
      YWJj
      YWJjZA==
    """
    out_text, consumed = encode(text)
    assert consumed == len(text)
    assert out_text == codecs.decode(text.strip(), 'base64')

    # Calling encode() with a multi-line string.
    text = """
      YQ==
      YWI=
      YWJj
      YWJjZA==


      YWI=
      YWJj
      YWJjZA==
    """
    out_text, consumed = encode(text)
    assert consumed == len(text)
    assert out_text == codecs.decode(text.strip(), 'base64')

   