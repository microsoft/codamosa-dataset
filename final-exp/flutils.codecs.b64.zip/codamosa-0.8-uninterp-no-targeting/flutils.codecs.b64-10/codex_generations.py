

# Generated at 2022-06-21 12:22:42.541453
# Unit test for function decode
def test_decode():
    """Test function decode."""
    assert decode(b'\xde\xad\xbe\xef') == ('3q2+7w==', 4)
    assert decode(b'\xde\xad\xbe\xef', errors='strict') == ('3q2+7w==', 4)
    assert decode(b'\xde\xad\xbe\xef', errors='backslashreplace') == ('3q2+7w==', 4)
    assert decode(b'\xde\xad\xbe\xef', errors='namereplace') == ('3q2+7w==', 4)
    assert decode(b'\xde\xad\xbe\xef', errors='replace') == ('3q2+7w==', 4)

# Generated at 2022-06-21 12:22:44.088147
# Unit test for function register
def test_register():
    """Test function register."""
    register()



# Generated at 2022-06-21 12:22:46.765169
# Unit test for function decode
def test_decode():
    assert decode(b'ABCDEFGabcdefg') == ('QUJDREVGYWJjZGVmZw==', 16)


# Generated at 2022-06-21 12:22:56.232135
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test basic function
    assert encode(
        '`~!@#$%^&*()_+-=[]{}\|;:\'",<.>/?'  # pylint: disable=anomalous-backslash-in-string
    )[0] == b'`~!@#$%^&*()_+-=[]{}\\|;:\'",<.>/?'

    # Test string with newlines.
    assert encode(
        textwrap.dedent(
            """\
            `~!@#$%^&*()_+-=[]{}\|;:'"<,>.
            """
        )
    )[0] == b'`~!@#$%^&*()_+-=[]{}\\|;:\'"<,>.'



# Generated at 2022-06-21 12:23:08.467375
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('SGVsbG8sIHdvcmxkIQ==') == (b'Hello, world!', 14)
    assert encode('SGVsbG8sIHdvcmxkIQ==\n', 'strict') == (b'Hello, world!', 15)
    assert encode('\tSGVsbG8sIHdvcmxkIQ==\n', 'strict') == (b'Hello, world!', 16)
    assert encode('SGVsbG8sIHdvcmxkIQ==  ', 'strict') == (b'Hello, world!', 16)
    assert encode('SGVsbG8sIHdvcmxkIQ==\t', 'strict') == (b'Hello, world!', 16)

# Generated at 2022-06-21 12:23:11.800490
# Unit test for function register
def test_register():
    """Unit test for the register function."""
    register()
    # No action required.
    # The codec is only registered if it doesn't already exist.



# Generated at 2022-06-21 12:23:18.414323
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    # Register the codec.
    register()
    # Verify that the codec is registered.
    # pylint: disable=W0212
    assert NAME in codecs.__all__
    # Verify that the codec is registered under the correct name.
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:23:21.651836
# Unit test for function decode
def test_decode():
    """Unit test for the function decode."""
    assert decode(b'PII') == ('UElJ', 3)
    assert decode(b'PII=') == ('UElJ', 4)
    assert decode(b'PII==') == ('UElJ', 4)

# Generated at 2022-06-21 12:23:27.652439
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()

    # Check the codec exists.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Codec not registered with Python')



# Generated at 2022-06-21 12:23:32.188169
# Unit test for function decode
def test_decode():
    """Test the function decode"""
    assert codecs.decode(b'YmFzZTY0LnR5cGluZy5QYXRjaGVy', 'b64') == b''

if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:23:36.518020
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)

# Generated at 2022-06-21 12:23:46.135117
# Unit test for function decode
def test_decode():
    assert decode(b'AA==') == ('Ag==', 4)
    assert decode(b'AAA=') == ('Aw==', 4)
    assert decode(b'AAAA') == ('BAA=', 4)
    assert decode(b'ABCD') == ('QUI=', 4)
    assert decode(b'ABCDE') == ('QUJD', 4)
    assert decode(b'ABCDEF') == ('QUJDRA==', 4)
    assert decode(b'ABCDEFG') == ('QUJDREU=', 4)
    assert decode(b'ABCDEFGH') == ('QUJDREVG', 4)
    assert decode(b'ABCDEFGHI') == ('QUJDREVGRw==', 4)
    assert decode(b'ABCDEFGHIJ') == ('QUJDREVGR0g=', 4)

# Generated at 2022-06-21 12:23:53.834364
# Unit test for function register
def test_register():
    """Unit test for function 'register'."""
    register()
    try:
        # noinspection PyUnresolvedReferences
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            f"codecs.getdecoder('{NAME}') should not raise LookupError"
        )


# pylint: disable=C0103
if __name__ == "__main__":
    register()
    obj = codecs.getdecoder(NAME)    # type: ignore
    print(f"obj = {obj}")

# Generated at 2022-06-21 12:23:55.737903
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:24:05.904194
# Unit test for function decode
def test_decode():
    """Unit test for function :func:`~decode`."""
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n', '') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n', 'strict') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n', 'ignore') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n', 'replace')

# Generated at 2022-06-21 12:24:10.593329
# Unit test for function decode
def test_decode():
    data1_bytes = b'\x01\x02\x03'
    encoded_str, _ = decode(data1_bytes, errors='regular')
    assert encoded_str == 'AQID'

    decoded_bytes, _ = base64.b64decode(encoded_str)
    assert decoded_bytes == data1_bytes


# Generated at 2022-06-21 12:24:15.919802
# Unit test for function encode
def test_encode():
    """
    This function checks the encode function.
    :return: void
    """
    assert encode("aGVsbG8=") == b"hello"
    assert encode("YWJjMTIzIT8kKiYoKSctPUB+")[0] == b'abc123!?$*&()\'+=-@~'
    assert encode("")[0] == b''
    assert encode("ZXN0IGVzdA==") == b"test test"
    assert encode("ZXN0IGVzdA==") == b"test test"


# Generated at 2022-06-21 12:24:17.373299
# Unit test for function decode
def test_decode():
    assert decode(b'YWJjZGVmZw==') == ('abcdefg', 8)


# Generated at 2022-06-21 12:24:25.012253
# Unit test for function encode
def test_encode():
    """Unit test for the ``encode`` function."""

# Generated at 2022-06-21 12:24:25.805492
# Unit test for function decode
def test_decode():
    assert decode(b'\x00') == ('AA==', 1)


# Generated at 2022-06-21 12:24:39.588283
# Unit test for function decode
def test_decode():
    # type: () -> None
    """Test the encoding of the decode function."""
    # Test the invalid input type
    with pytest.raises(TypeError):
        decode(text='', errors='')
    with pytest.raises(TypeError):
        decode(text=None, errors='')
    with pytest.raises(TypeError):
        decode(text=2345, errors='')
    with pytest.raises(TypeError):
        decode(text='Hello', errors='')
    with pytest.raises(TypeError):
        decode(text=True, errors='')
    with pytest.raises(TypeError):
        decode(text={}, errors='')
    with pytest.raises(TypeError):
        decode(text=Exception(), errors='')
    # Test the

# Generated at 2022-06-21 12:24:48.277973
# Unit test for function encode
def test_encode():
    """Test encode function"""
    # pylint: disable=C0111
    # pylint: disable=W0612
    # pylint: disable=C0103
    # pylint: disable=W0212
    # pylint: disable=C0302
    # pylint: disable=W0621
    # noinspection PyUnusedLocal
    b = b'C\x0beB'
    txt = 'C\nbe\tB'

    (b_out, _) = encode(txt)

    assert b == b_out


# Generated at 2022-06-21 12:24:51.827516
# Unit test for function register
def test_register():
    expected = f'<b64 Codec "b64" from {__name__}>'
    codecs.register(_get_codec_info)
    actual = codecs.lookup(NAME)
    assert expected == str(actual)

# Generated at 2022-06-21 12:24:53.591266
# Unit test for function register
def test_register():
    """No unit tests for this function.  It is either used or not."""



# Generated at 2022-06-21 12:24:57.223953
# Unit test for function decode
def test_decode():
    """Ensure decode works like the base64.b64encode function."""
    from binascii import b2a_base64
    from random import choice, randint

    for _ in range(1000):
        length = randint(0, 100)
        data = bytes([randint(0, 127) for _ in range(length)])

        b64_str = b2a_base64(data).decode('ascii')
        b64_str = b64_str.replace('\n', '')

        d0, _ = b2a_base64(data, newline=False)
        d1 = b64_str.encode('utf-8')
        d2, _ = decode(data)

        assert d0 == d1
        assert d0 == d2



# Generated at 2022-06-21 12:25:04.440870
# Unit test for function encode
def test_encode():
    """Test function encode()."""
    import base64
    from pprint import pprint
    data = b'hello world'
    encoded_bytes = base64.b64encode(data)
    encoded_str = encoded_bytes.decode('utf-8')

    assert encode(encoded_bytes)[0] == data

    assert encode(encoded_str)[0] == data

    encoded_str_lines = (
        f'{encoded_str[0:16]}\n'
        f'{encoded_str[16:32]}\n'
        f'{encoded_str[32:48]}\n'
        f'{encoded_str[48:64]}\n'
        f'{encoded_str[64:80]}\n'
    )


# Generated at 2022-06-21 12:25:09.352658
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    # noinspection PyUnresolvedReferences
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'Failed to register {NAME!r} codec')

# Generated at 2022-06-21 12:25:20.016026
# Unit test for function encode
def test_encode():
    assert encode(
        'aGVsbG8gd29ybGQh',
        errors='strict'
    ) == (b'hello world!', 15)
    assert encode(
        'Y2F0ISA=\n',
        errors='strict'
    ) == (b'cat!', 6)
    assert encode(
        'd29ybGQ=',
        errors='strict'
    ) == (b'world', 6)

    with pytest.raises(UnicodeEncodeError) as exc_info:
        encode(
            'OiB5b3UgZW1vdGlvbmFsIEPESUc=',
            errors='strict'
        )

# Generated at 2022-06-21 12:25:28.401889
# Unit test for function encode
def test_encode():
    # Test for normal case
    result = encode('YmEyZmNkZWU=\n')
    assert(result == (b'b12fcde', 11))
    # Test for case with indentation
    result = encode('    YmEyZmNkZWU=\n')
    assert(result == (b'b12fcde', 15))
    # Test for case with multi-line input
    result = encode('YmEy\nZmNkZWU=\n')
    assert(result == (b'b12fcde', 14))
    # Test for case with non-base64 input
    with pytest.raises(UnicodeEncodeError):
        encode('YmEyZmNkZWU!')


# Generated at 2022-06-21 12:25:39.963273
# Unit test for function decode
def test_decode():
    # encode a text into bytes and return the converted bytes and the number
    # of consumed bytes.
    # Args:
    #      data (bytes or bytearray or memoryview): Bytes to be converted
    #          to a string of base64 characters.
    #      errors (str or :obj:`~UserString`): Not used.  This argument exists
    #          to meet the interface requirements.  Any value given to this
    #          argument is ignored.
    # Returns:
    #      str: of base64 Characters
    #      int: the number of the given ``data`` bytes consumed.
    print("#####################################################################")
    print("Unit test for function decode")
    print()
    print("decode(b'YW55IGNhcm5hbCBwbGVhc3VyZQ==\n')")
   

# Generated at 2022-06-21 12:25:54.476314
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import contextlib
    import io
    import sys

    @contextlib.contextmanager
    def redirect_stderr(stream):
        """Redirect stderr to a stream."""
        old_stderr = sys.stderr
        sys.stderr = stream
        try:
            yield
        finally:
            sys.stderr = old_stderr

    @contextlib.contextmanager
    def redirect_stdout(stream):
        """Redirect stdout to a stream."""
        old_stdout = sys.stdout
        sys.stdout = stream
        try:
            yield
        finally:
            sys.stdout = old_stdout


# Generated at 2022-06-21 12:25:59.144705
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    import test_b64

    # Make sure that the 'b64' codec has not been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise ValueError(
            f'The codec with the name {NAME!r} has already been registered.'
        )

    # Register the 'b64' codec.
    register()

    # Make sure that the 'b64' codec has been registered.
    try:
        b64_codec = codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'The codec with the name {NAME!r} should be registered.'
        )

    # Create a 'bytes' object to use for testing 'decode'
   

# Generated at 2022-06-21 12:26:09.115152
# Unit test for function decode
def test_decode():
    # Test empty input.
    assert decode(b'') == ('', 0)

    # Test single byte input.
    decoded_bytes, num_bytes_decoded = decode(b'\x01')
    assert num_bytes_decoded == 1
    assert decoded_bytes == 'AA=='

    # Test multiple byte input.
    decoded_bytes, num_bytes_decoded = decode(b'\x01\x02\x03')
    assert num_bytes_decoded == 3
    assert decoded_bytes == 'AQID'

    # Test passing garbage in.
    decoded_bytes, num_bytes_decoded = decode(
        b'garbage\x01\x02\x03'
    )
    assert num_bytes_decoded == 3
    assert decoded_bytes == 'AQID'

# Generated at 2022-06-21 12:26:12.707679
# Unit test for function decode
def test_decode():
    """Test function decode()"""
    assert decode(b'eHV0') == ('hut',4)



# Generated at 2022-06-21 12:26:13.797554
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME)
    return None

# Generated at 2022-06-21 12:26:14.400095
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:26:24.908391
# Unit test for function encode

# Generated at 2022-06-21 12:26:37.017979
# Unit test for function encode

# Generated at 2022-06-21 12:26:39.181691
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-21 12:26:47.056405
# Unit test for function encode
def test_encode():
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('\nZm9vYmFy') == (b'foobar', 8)
    assert encode('Zm9vYmFy') == (b'foobar', 7)
    assert encode('Zm9vYmFy') == (b'foobar', 7)
    assert encode('Zm9vYmFy') == (b'foobar', 7)
    assert encode('\n') == (b'', 1)
    assert encode('Zm9v\n') == (b'foo', 4)
    assert (
        encode('\nYWJjZGVmZ2g=\n') ==
        (b'abcdefgh', 14)
    )



# Generated at 2022-06-21 12:27:09.259219
# Unit test for function encode
def test_encode():
    # pylint: disable=C0103
    # noinspection PyGlobalUndefined
    global b

    # Test normal use.
    input_str = 'A' * 100
    b = codecs.getencoder(NAME)(input_str)[0]
    assert type(b) is bytes
    assert len(b) == 100

    # Test with zero bytes of input.
    b = codecs.getencoder(NAME)('')[0]
    assert type(b) is bytes
    assert len(b) == 0

    # Test with bad input.
    input_str = 'A' * 2   # type: ignore
    try:
        b = codecs.getencoder(NAME)(input_str)[0]
    except UnicodeEncodeError:
        assert True
        return
    assert False



# Generated at 2022-06-21 12:27:15.426543
# Unit test for function decode
def test_decode():
    assert decode(b'AAECAwQFBgc=')[0] == '-.-.---.--.-.....-.-.-.'
    assert decode(b'AAECAwQFBgc=')[1] == 12
    assert decode(b'S2VlcyBhbmQgVHJpcGxlcy4uLgo=')[0] == 'Keeps and Triplets...\n'



# Generated at 2022-06-21 12:27:25.972259
# Unit test for function encode
def test_encode():
    test_text = (
        'EDDDejR0ZXh0L3BsYWluOyBjaGFyc2V0PXV0Zi04CnNyYz1odHRwczovL2lvc2JlYXV0aC'
        '5jb20vbXkucGRmCg=='
    )

# Generated at 2022-06-21 12:27:30.669081
# Unit test for function register
def test_register():
    """Unit test for function register."""
    c = codecs.CodecInfo(  # type: ignore
        name='b64',
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )
    codecs.register(c)

# Generated at 2022-06-21 12:27:36.179258
# Unit test for function decode
def test_decode():
    """Test the :func:`decode` function"""
    assert decode(b"") == ("", 0)
    assert decode(b"YmFzZTY0Cg==") == ("base64\n", 13)
    assert decode(b"YmFzZTY0Cg") == ("base64\n", 11)

# Generated at 2022-06-21 12:27:43.338711
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME), 'encoder not found'
    assert codecs.getdecoder(NAME), 'decoder not found'
    assert issubclass(codecs.getencoder(NAME)[1], codecs.CodecInfo), \
        'encoder is not of the correct type'
    assert issubclass(codecs.getdecoder(NAME)[1], codecs.CodecInfo), \
        'decoder is not of the correct type'



# Generated at 2022-06-21 12:27:49.352273
# Unit test for function encode
def test_encode():
    assert encode('SSdtIGtpbGxpbmcgeW91ciBicmFpbiBsaWtlICpAaGVyb2t1Kg==') == (b"I'm killing your brain like a poisonous mushroom", 76)
    assert encode('UmFkbWluIHlvdSE') == (b'Admin you!', 14)



# Generated at 2022-06-21 12:28:01.944140
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YQ==') == (b'a', 2)
    assert encode('YWI=') == (b'ab', 3)
    assert encode('YWJjZGVmZ2dp') == (b'abcdefghi', 10)
    assert encode(
        """
        YWJjZGVmZ2hpamtsbW5vcHFy
        c3R1dnd4eXo=
        """
    ) == (b'abcdefghijklmnopqrstuvwxyz', 34)
    try:
        encode('YWJj\x01')
    except UnicodeEncodeError as e:
        assert e.reason == 'b64'
        assert e.object == 'YWJj\x01'

# Generated at 2022-06-21 12:28:03.861667
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-21 12:28:09.005142
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    data = bytes([0, 1, 2])
    data = b'\x00\x01\x02'
    data = bytearray([0, 1, 2])
    data = memoryview(bytes([0, 1, 2]))
    out, length = decode(data)
    assert out == 'AAEC'
    assert length == 3



# Generated at 2022-06-21 12:28:36.600586
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec with Python."""

    # Register the codec.
    register()

    # Create some base64 encoded text.
    base64_text = base64.b64encode(b'A test of the base64 codec')

    # Encode the base64 text as real characters.
    input_text = base64_text.decode('utf-8')

    # Encode the input_text as bytes.
    input_bytes = input_text.encode('utf-8')

    # Decode the input bytes as 'b64'
    output_bytes = codecs.decode(input_bytes, NAME)

    # Decode the output as 'utf-8'
    output_utf8 = output_bytes.decode('utf-8')

    assert output_utf8 == 'A test of the base64 codec'

# Generated at 2022-06-21 12:28:41.436805
# Unit test for function encode
def test_encode():
    in_str = '''
        Please encode me
    '''
    assert encode(in_str)[0] == b'UHJlcXVpcmVzIHRoZSB1c2Ugb2YgZW5jcnlwdGlvbiBhbmQgZGlnZXN0'


# Generated at 2022-06-21 12:28:47.795852
# Unit test for function decode
def test_decode():
    """Test for decode"""
    v = "R2VlbiB5b3Ugd29yayBJIHdpbGwgd29yayB0bw==\nUmVkIHlvdSB3b3JrIEkgd2lsbCB3b3JrIHRv"
    d1 = "Given you work I will work to\nRed you work I will work to"
    r = decode(v)
    assert r[0] == d1
    assert r[1] == len(v)
    v = "R2VlbiB5b3Ugd29yayBJIHdpbGwgd29yayB0bw==\nUmVkIHlvdSB3b3JrIEkgd2lsbCB3b3JrIHRv"

# Generated at 2022-06-21 12:28:58.167723
# Unit test for function decode
def test_decode():
    # Test decode with a 'Hello World' message.
    input_string = 'Hello World'
    input_bytes = input_string.encode()
    expected_output = 'SGVsbG8gV29ybGQ='
    output_string, length = decode(input_bytes)
    assert length == len(input_bytes)
    assert output_string == expected_output

    # Test decode with a single byte
    input_string = 'A'
    input_bytes = input_string.encode()
    expected_output = 'QQ=='
    output_string, length = decode(input_bytes)
    assert length == len(input_bytes)
    assert output_string == expected_output


# Generated at 2022-06-21 12:29:07.575120
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # Example from https://tools.ietf.org/html/rfc4648#section-10
    examples = (
        ("", b''),
        ("Zg==", b'f'),
        ("Zm8=", b'fo'),
        ("Zm9v", b'foo'),
        ("Zm9vYg==", b'foob'),
        ("Zm9vYmE=", b'fooba'),
        ("Zm9vYmFy", b'foobar'),
    )

    for example in examples:
        # Run the test
        result, _ = encode(example[0])
        assert result == example[1]


# Generated at 2022-06-21 12:29:10.536395
# Unit test for function register
def test_register():
    """Test that the ``register()`` function works."""

    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    codecs.lookup(NAME)



# Generated at 2022-06-21 12:29:19.386964
# Unit test for function register
def test_register():
    """Test register()"""
    # Get the decoder registered with Python.
    try:
        decoder = codecs.getdecoder(NAME)
    except LookupError:
        decoder = None
    # Check that the decoder is not the register decoder.
    assert decoder != decode
    # Register the 'b64' encoder.
    register()
    # Get the decoder registered with Python.
    try:
        decoder = codecs.getdecoder(NAME)
    except LookupError:
        decoder = None
    # Check that the decoder is the registered decoder.
    assert decoder == decode


# Generated at 2022-06-21 12:29:29.090906
# Unit test for function encode
def test_encode():
    sample_text = u'''\
    F2Fycml2ZV9jbGFzcz0iX19jb25pY19hZGRfcGxheWVyX2NyZWF0ZWRfY2FsbGJhY2si
    '''
    sample_bytes = b'\n'.join([
        b'F2Fycml2ZV9jbGFzcz0iX19jb25pY19hZGRfcGxheWVyX2NyZWF0ZWRfY2FsbGJhY2si'
    ])

# Generated at 2022-06-21 12:29:30.955031
# Unit test for function register
def test_register():
    """Unit Test for function register."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


test_register()

# Generated at 2022-06-21 12:29:41.613794
# Unit test for function decode

# Generated at 2022-06-21 12:30:46.181634
# Unit test for function decode
def test_decode():
    """Unit test for function :func:`decode`."""
    # Test that the encoded bytes have a line break every 64 characters.
    b64_bytes = b'\n'.join(
        [
            codecs.decode(b64_bytes, 'b64')
            for b64_bytes in b64.split(b'\n')
        ]
    )
    assert b64_bytes == (
        b64_bytes + b'\n'
    ).encode('utf-8')

    # Test the error handling: assert than 'b64_bytes' is a bytearray.
    with pytest.raises(AssertionError):
        codecs.decode(b64_bytes, 'b64')  # type: ignore[arg-type]


# Generated at 2022-06-21 12:30:50.219248
# Unit test for function encode
def test_encode():
    """Unit test for ``encode`` function.
    """
    assert encode(b'RG8gdGhlIGJhc2U2NCBkZWNvZGUu') == (b'Do the base64 decode.', 31)



# Generated at 2022-06-21 12:30:56.570481
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    assert decode(b'abcdef') == ('YWJjZGVm', 6)
    assert decode(bytearray([0, 1, 2, 3])) == ('AAECAw==', 4)
    assert decode(memoryview(b'abcdef')) == ('YWJjZGVm', 6)

    assert decode(b'thisispy') == ('dGhpc2lzcHk=', 8)

    try:
        decode(b"\xFF")
    except UnicodeEncodeError as e:
        assert 'is not a proper bas64 character string' in str(e)



# Generated at 2022-06-21 12:31:06.015255
# Unit test for function decode
def test_decode():
    # Check input: bytes
    b = b'Zm9v'
    s, _ = decode(b)
    assert s == 'Zm9v'
    # Check input: bytearray
    b = bytearray(b)
    s, _ = decode(b)
    assert s == 'Zm9v'
    # Check input: memoryview
    b = memoryview(b)
    s, _ = decode(b)
    assert s == 'Zm9v'
    # Check input: not of type bytes, bytearray, or memoryview
    try:
        s, _ = decode('Zm9v')
    except UnicodeDecodeError:
        pass
    else:
        assert False



# Generated at 2022-06-21 12:31:08.455573
# Unit test for function register
def test_register():
    # pylint: disable=C0103
    """Unit test for function register"""

    register()
    # Calling register() a second time should have no side-effects.
    register()



# Generated at 2022-06-21 12:31:16.996333
# Unit test for function decode
def test_decode():
    assert decode(b'A')[0] == 'QQ==\n'
    assert decode(b'AB')[0] == 'QUI=\n'
    assert decode(b'ABC')[0] == 'QUJD\n'
    assert decode(b'ABCD')[0] == 'QUJDRA==\n'
    assert decode(b'ABCDE')[0] == 'QUJDREU=\n'
    assert decode(b'ABCDEF')[0] == 'QUJDREVG\n'
    assert decode(b'ABCDEFG')[0] == 'QUJDREVGRw==\n'
    assert decode(b'ABCDEFGH')[0] == 'QUJDREVGR0g=\n'

# Generated at 2022-06-21 12:31:21.206907
# Unit test for function decode
def test_decode():
    assert decode(b'JTdCJTIyY29sb3IlMjI6JTIyZ3JlZW4lMjIlMjBc') == ('["color":"green" ', 34)


# Generated at 2022-06-21 12:31:30.987491
# Unit test for function decode

# Generated at 2022-06-21 12:31:38.773181
# Unit test for function decode
def test_decode():
    # test_decode_0_byte_data
    assert decode(b'', 'ignore') == ('', 0)

    # test_decode_many_bytes_data
    data = bytearray(256)

# Generated at 2022-06-21 12:31:43.497189
# Unit test for function register
def test_register():
    # Ensure that the codec has not been registed.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'The codec has already been registered.'

    # Register the codec then verify that it has been registered.
    register()
    assert NAME == codecs.getdecoder(NAME).name
