

# Generated at 2022-06-21 12:22:34.882570
# Unit test for function decode
def test_decode():
    assert decode(b'AQID') == ('AQID', 4)
    assert decode(b'AQID', 'strict') == ('AQID', 4)
    assert decode(b'AQID', 'ignore') == ('AQID', 4)
    assert decode(b'AQID', 'replace') == ('AQID', 4)


# Generated at 2022-06-21 12:22:45.353378
# Unit test for function encode
def test_encode():
    """Unit test of function encode"""
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 1)
    assert encode('\n') == (b'', 1)
    assert encode('\n\n') == (b'', 2)
    assert encode('\n \n') == (b'', 3)
    assert encode('\n \n \n') == (b'', 4)
    assert encode('\n\n\n\n\n') == (b'', 5)
    assert encode('a') == (b'', 1)
    assert encode('a\n') == (b'', 2)
    assert encode('a\nb') == (b'', 3)
    assert encode('a\nb\nc') == (b'', 5)

# Generated at 2022-06-21 12:22:48.786145
# Unit test for function encode
def test_encode():
    assert (
        codecs.encode(
            'aGVsbG8gV29ybGQ=', 'b64'
        ) == b'hello World'
    )



# Generated at 2022-06-21 12:22:50.980518
# Unit test for function register
def test_register():
    """Test the function ``register``"""
    codec = codecs.getdecoder(NAME)
    assert codec is not None
    
    
# Test Code


# Generated at 2022-06-21 12:22:51.874239
# Unit test for function decode
def test_decode():
    pass


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:22:59.624216
# Unit test for function encode
def test_encode():
    """Unittest for the ``encode`` function that is used by the custom
    b64 codec."""
    # test to make sure that an error is raised for a badly formed data set
    bad_input_str = '!ZWf\n!JmZ\n!ZmY\n!JmZ'
    try:
        encode(bad_input_str)
    except UnicodeEncodeError:
        pass
    else:
        assert(False), 'Bad string should raise UnicodeEncodeError.'

    # test some good sample strings

# Generated at 2022-06-21 12:23:08.937032
# Unit test for function encode
def test_encode():
    assert encode("YQ==") ==(b'a', 4)
    assert encode("YWI=") ==(b'ab', 4)
    assert encode("YWJj") ==(b'abc', 4)
    assert encode("YWJjZA==") ==(b'abcd', 8)
    assert encode("YWJjZAo=") ==(b'abcd\n', 8)
    assert encode("YWJjZCBOZXh0IHN0cmluZwo=") ==(b'abcde Next string\n', 22)


# Generated at 2022-06-21 12:23:14.744687
# Unit test for function register
def test_register():  # pragma: no cover
    """Test the function register."""
    import sys
    if sys.version_info < (3, 8):
        # This will fail during initialization of the function register.
        return

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        import pytest
        pytest.fail(f'Registration of b64 codec has failed')

# Generated at 2022-06-21 12:23:25.074918
# Unit test for function decode
def test_decode():
    # pylint: disable=line-too-long

    # A few simple tests
    assert decode(b'\xfb\xef') == ('+8P=', 2)
    assert decode(b'\xaf\x97\xec\xaf\xff') == ('sw/8/w==', 5)
    assert decode(b'\x8c\xe9\xef\x98\x91\xff') == ('h4/bDw==', 6)
    assert decode(b'\xfd\xfe\xf7\xa8\xe1\xbf\xff') == ('/9/4H8B', 7)

# Generated at 2022-06-21 12:23:25.885753
# Unit test for function register
def test_register():
    assert(codecs.getdecoder(NAME))

# Generated at 2022-06-21 12:23:36.476514
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    # pylint: disable=W0603
    # pylint: disable=W0621
    global codecs
    orig_reg = codecs.register
    orig_getdecoder = codecs.getdecoder
    codecs.register = mock.MagicMock(side_effect=orig_reg)
    codecs.getdecoder = mock.MagicMock(side_effect=orig_getdecoder)
    register()
    codecs.register.assert_called_once_with(_get_codec_info)
    codecs.getdecoder.assert_called_once_with(NAME)

# Generated at 2022-06-21 12:23:40.855516
# Unit test for function register
def test_register():
    # Clear the codecs list.
    codecs._cache.clear()
    codecs._unknown_encoding_error.clear()

    # Register the codec.
    register()

    # Ensure the codec is registered.
    item = codecs.getdecoder(NAME)
    assert item() == decode

# Generated at 2022-06-21 12:23:44.217588
# Unit test for function decode
def test_decode():
    # Test that decode works.
    data = bytes([10, 20, 40, 50])
    out, length = decode(data)
    assert out == 'CjIwCjQwCjUw'
    assert length == 4



# Generated at 2022-06-21 12:23:46.548160
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 10)



# Generated at 2022-06-21 12:23:56.727884
# Unit test for function encode
def test_encode():
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _encode(
            values: Tuple[str, _STR, int],
            errors: _STR = 'strict'
    ) -> Tuple[bytes, int]:
        return encode(*values, errors)
    # pylint: enable=W0612
    test_bytes = b'\x03\x04\x05\x06'
    test_str = 'AwECHwYFBggGBwoHCxo=\n'
    assert _encode((test_str,)) == (test_bytes, len(test_str))

    test_str = 'AwECHwYFBggGBwoHCxo='
    assert _encode((test_str,)) == (test_bytes, len(test_str))


# Unit

# Generated at 2022-06-21 12:24:06.170184
# Unit test for function decode
def test_decode():
    assert decode(b'\x01\x02\x03\x04\x05', 'strict') == (
        'AQIDBAU=',
        5
    )
    assert decode(b'\x01\x02\x03\x04\x05\x06', 'strict') == (
        'AQIDBAUG',
        6
    )
    assert decode(b'\x01\x02\x03\x04\x05\x06\x07', 'strict') == (
        'AQIDBAUGAw==',
        7
    )
    assert decode(b'\x01\x02\x03\x04\x05\x06\x07\x08', 'strict') == (
        'AQIDBAUGAwQE',
        8
    )

# Generated at 2022-06-21 12:24:08.631482
# Unit test for function decode
def test_decode():
    test_data = bytes([0x01, 0x02])
    assert decode(test_data) == ("AQI=", 2)

# Generated at 2022-06-21 12:24:15.919134
# Unit test for function decode
def test_decode():
    assert decode(b'') == ('', 0)
    assert decode(b'\x04\x06\x01\x06') == ('BCA', 4)
    assert decode(b'\x04\x06\x01\x06\x45\x4b') == ('BCAEK', 6)
    assert decode(b'\x04\x06\x01\x06\x45\x4b\x00\x02') == ('BCAEKAA', 8)
    assert decode(b'\x04\x06\x01\x06\x45\x4b\x00\x02\x47\x45\x41\x51\x42\x67') == (
        'BCAEKAAGEAQBg', 14
    )

# Generated at 2022-06-21 12:24:20.164266
# Unit test for function encode
def test_encode():
    actual = encode('QQ==')[0]
    expected = b'\xab'
    assert actual == expected

    actual = encode('QQ!=')[0]
    expected = b'\xab'
    assert actual == expected

    actual = encode('QQ==')[1]
    expected = 4
    assert actual == expected

    actual = encode('QQ!=')[1]
    expected = 4
    assert actual == expected



# Generated at 2022-06-21 12:24:32.338287
# Unit test for function decode
def test_decode():
    assert decode(b'AAAAAAAAA') == ('QUFBQUFBQUFB')
    assert decode(b'd29ybGQ=') == ('d29ybGQ')
    assert decode(b'c2VjcmV0') == ('c2VjcmV0')
    assert decode(b'YmFzZTY0') == ('YmFzZTY0')
    assert decode(b'QkFTRTY0') == ('QkFTRTY0')
    assert decode(b'QUJzZTY0') == ('QUJzZTY0')
    assert decode(b'QUJTRTY0') == ('QUJTRTY0')
    assert decode(b'QUFBQUFB') == ('QUFBQUFB')
    assert decode(b'QUFBQUFB') == ('QUFBQUFB')

# Generated at 2022-06-21 12:24:37.505229
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:24:49.285054
# Unit test for function decode
def test_decode():
    """Test function decode."""
    assert decode(b'aGVsbG8gd29ybGQ=') == ('hello world', 16)
    assert decode(b'YXNkZmFzZGZhc2Rmc2FkZmFzZGZhZHNmYXNkZmFhZGZhc2RmYXNkZg==') == (
        'asdfasdfasdfsadfasdfadfsadfasdfahdfasdfasdf',
        64
    )
    assert decode(b'YQ==') == ('a', 4)
    assert decode(b'bA==') == ('l', 4)

# Generated at 2022-06-21 12:24:58.911913
# Unit test for function encode

# Generated at 2022-06-21 12:24:59.626410
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-21 12:25:11.907165
# Unit test for function decode
def test_decode():
    assert decode(b'U3VwZXIgSUJN') == ('Super IBM', 10)
    assert decode(b'U3VwZXIgSUJN\n') == ('Super IBM', 11)
    assert decode(b'U3VwZXIgSUJN\r') == ('Super IBM', 11)
    assert decode(b'U3VwZXIgSUJN\r\n') == ('Super IBM', 12)
    assert decode(b'U3VwZXIgSUJN\r\r') == ('Super IBM', 12)
    assert decode(b'U3VwZXIgSUJN\n\n') == ('Super IBM', 12)
    assert decode(b'U3VwZXIgSUJN\n\r') == ('Super IBM', 12)

# Generated at 2022-06-21 12:25:19.272621
# Unit test for function decode
def test_decode():
    assert decode(data=b'hello')[0] == 'aGVsbG8='
    # assert decode(data=b'hello', errors='ignore')[0] == 'aGVsbG8='
    assert decode(data=b'\x06\xb5\x8f\x0b\x16\x1a\x1e"&*:0<@DHQ\\`d')[0] == 'BpEEO0A1BEIETghTgB1yA3FzcnK0Eo='


# Generated at 2022-06-21 12:25:25.541258
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # pylint: disable=protected-access
    from .test_base64_codec import (
        actual,
        expected,
    )
    for b64_str, expected_bytes in zip(actual, expected):
        expected_bytes = expected_bytes.encode('utf-8')
        out_bytes, _ = encode(b64_str)
        assert out_bytes == expected_bytes


if __name__ == "__main__":
    test_encode()

# Generated at 2022-06-21 12:25:28.153099
# Unit test for function register
def test_register():
    """Test the function register."""
    codecs.getincodecinfo(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:25:34.693721
# Unit test for function decode
def test_decode():
    """
    >>> text = "hello world"
    >>> btext = text.encode('utf-8')
    >>> b64_encoded = base64.b64encode(btext)
    >>> b64_encoded_text = b64_encoded.decode('utf-8')
    >>> assert decode(b64_encoded)[0] == b64_encoded_text

    """
    ...

# Generated at 2022-06-21 12:25:41.586233
# Unit test for function decode
def test_decode():
    """Test the :func:`~decode` function."""
    from random import randint
    from binascii import b2a_qp
    from codecs import getdecoder
    for i in range(100):
        lst = [randint(0, 255) for _ in range(randint(1, 8))]
        data_bytes = bytes(lst)
        encoded_str = getdecoder(NAME)(data_bytes)[0]
        assert encoded_str == b2a_qp(data_bytes).decode('utf-8')

# Generated at 2022-06-21 12:25:53.020229
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('Zg===') == (b'f', 3)
    assert encode('YQ==') == (b'a', 2)
    assert encode('Yg==') == (b'b', 2)
    assert encode('Yw==') == (b'c', 2)
    assert encode('ZA==') == (b'd', 2)
    assert encode('ZQ==') == (b'e', 2)
    assert encode('Zg==') == (b'f', 2)
    assert encode('Zw==') == (b'g', 2)
    assert encode('') == (b'', 0)



# Generated at 2022-06-21 12:26:04.749454
# Unit test for function decode
def test_decode():
    assert decode(b'hello') == ('aGVsbG8=', 5)
    assert decode(b'hello', 'ignore') == ('aGVsbG8=', 5)
    assert decode(b'aGVsbG8=', 'strict') == ('hello', 8)

    # Test a long string

# Generated at 2022-06-21 12:26:05.794059
# Unit test for function encode
def test_encode():
    assert(encode('SGVsbG8=')[0] == b'Hello')


# Generated at 2022-06-21 12:26:12.282508
# Unit test for function decode
def test_decode():
    # W0603: Using the global statement
    # pylint: disable=W063
    global decode

    # Test decode with an input that is not base64 characters
    try:
        decode(b'\xFF')
    except UnicodeDecodeError as e:
        assert e.object == b'\xFF'
        assert e.encoding == 'b64'
        assert e.start == 0
        assert e.end == 1
        assert (
            e.reason ==
            '\xFF is not a proper bas64 character string: Incorrect padding'
        )

    # Test decode with known proper base64 Characters
    assert decode(b'AAEC') == ('QQ==', 4)

    # Test decode with invalid type for the input
    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:26:22.981204
# Unit test for function register
def test_register():
    """Unit test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None

    # pylint: disable=W0613
    # noinspection PyUnusedLocal
    def _test_decoder(
            data: _ByteString,
            errors: _STR = 'strict'
    ) -> Tuple[str, int]:
        """Test decoder function."""
        return "test", 1

    # pylint: disable=W0613
    # noinspection PyUnusedLocal
    def _test_encoder(
            text: _STR,
            errors: _STR = 'strict'
    ) -> Tuple[bytes, int]:
        """Test encoder function."""
        return b"test", 1


# Generated at 2022-06-21 12:26:34.949040
# Unit test for function register
def test_register():
    import sys
    import unittest.mock

    class MockCodecs:
        def register(
                self,
                codec_info: codecs.CodecInfo
        ) -> None:
            self.codec_info = codec_info

    sys_module = unittest.mock.Mock()
    sys_module.modules = {}
    sys_module.modules['codecs'] = MockCodecs()

    with unittest.mock.patch.dict('sys.modules',
                                  {'codecs': sys_module.modules['codecs']}):
        with unittest.mock.patch.object(sys, 'modules', sys_module.modules):
            import codecs
            codecs.register = sys_module.modules['codecs'].register

            # import b64  # p

# Generated at 2022-06-21 12:26:44.465526
# Unit test for function encode
def test_encode():
    """Test function ``encode``"""
    encoded = encode('SGVsbG8sIHdvcmxkIQ==')
    assert encoded == (b'Hello, world!', 20)
    encoded = encode('SGVsbG8sIHdvcmxkIQ==')
    assert encoded == (b'Hello, world!', 20)
    encoded = encode('n')
    assert encoded == (b'\n', 1)
    encoded = encode('\\n')
    assert encoded == (b'\\n', 2)
    encoded = encode('\\\n')
    assert encoded == (b'\\\n', 3)
    encoded = encode('d2lzaF93aXNob3c=')
    assert encoded == (b'wish_wishow', 12)

# Generated at 2022-06-21 12:26:56.402291
# Unit test for function decode
def test_decode():
    import unittest

    class Test_decode(unittest.TestCase):
        """Test the ``decode`` function."""

        def test_bad_data_inputs(self):
            """The given ``data`` input must be bytes."""
            with self.assertRaises(TypeError):
                decode(text=12345)

        def test_empty_data(self):
            """The given ``data`` can be empty."""
            self.assertEqual(decode(data=b''), ('', 0))

        def test_single_byte(self):
            """Test a single byte."""
            data = b'\x00'
            self.assertEqual(decode(data=data), ('AA==', 1))

        def test_zero_bytes(self):
            """Test zero filled bytes."""
            data

# Generated at 2022-06-21 12:26:58.749140
# Unit test for function decode
def test_decode():
    # Given
    data = 'This is a test'.encode('utf-8')
    expected = 'VGhpcyBpcyBhIHRlc3Q='

    # When
    out, _ = decode(data)

    # Then
    assert out == expected



# Generated at 2022-06-21 12:27:05.801103
# Unit test for function decode
def test_decode():
    the_bytes = b'\x1b\x00\x01\x01\r\r\x13\x00\x01\x01\x05\x00\x01\x01'
    b64_decoded = 'MDAxMTAxNDEwMTAx'
    encoded, __ = decode(the_bytes)
    assert encoded == b64_decoded, f'{encoded} != {b64_decoded}'



# Generated at 2022-06-21 12:27:23.606170
# Unit test for function decode
def test_decode():
    import sys
    import unittest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class Test_decode(unittest.TestCase):
        def setUp(self):
            """Set up test fixtures."""
            pass

        def tearDown(self):
            """Tear down test fixtures."""
            pass

        def test_decode_1(self):
            """Tests the output of the decode function."""
            self.assertEqual(
                decode(b'What is this?'),
                ('V2hhdCBpcyB0aGlzPwo=', 15),
            )

# Generated at 2022-06-21 12:27:34.578964
# Unit test for function encode
def test_encode():
    assert encode(  # type: ignore
        'abcdefg',
    ) == (
        b'abcdefg',
        7
    )
    assert encode(  # type: ignore
        ' abcdefg ',
    ) == (
        b'abcdefg',
        7
    )
    assert encode(  # type: ignore
        ' abcdefg ',
    ) == (
        b'abcdefg',
        7
    )
    assert encode(  # type: ignore
        '\n     abcdefg ',
    ) == (
        b'abcdefg',
        7
    )

# Generated at 2022-06-21 12:27:37.783672
# Unit test for function register
def test_register():
    # type: () -> None
    register()
    assert NAME in codecs.name_mapping.keys()
    assert NAME in codecs.name_mapping.values()

# Generated at 2022-06-21 12:27:46.706755
# Unit test for function decode
def test_decode():
    """Test :func:`decode` function."""

    # Test case 01
    data_bytes = b'A' * 10
    out_str, _ = decode(data_bytes)
    assert out_str == "AAAAAAAAAAAA"

    # Test case 02
    data_bytes = b'A' * 11
    out_str, _ = decode(data_bytes)
    assert out_str == "AAAAAAAAAAAAA"

    # Test case 03
    data_bytes = b'A' * 9
    out_str, _ = decode(data_bytes)
    assert out_str == "AAAAAAAAA"

    # Test case 04
    data_bytes = b'A' * 8
    out_str, _ = decode(data_bytes)
    assert out_str == "AAAAAAAA"

    # Test case 05

# Generated at 2022-06-21 12:27:58.906396
# Unit test for function register
def test_register():
    """Test the function b64.register()."""
    # Can't import these until after the codec is registered.
    # pylint: disable=import-outside-toplevel
    import codecs
    import io
    import os

    # Get the pathname of the file where this module exists.
    # This file should be: $PROJ_HOME/src/bin/b64.py
    b64_pathname = os.path.abspath(__file__)

    # Open the file for reading as UTF-8 encoded bytes.
    b64_file = io.open(b64_pathname, 'rb')

    # Read the entire file into the b64_bytes.
    b64_bytes = b64_file.read()

    # Close the file.
    b64_file.close()

    # Use the 'b64

# Generated at 2022-06-21 12:28:02.045202
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('bGlh') == (b'li', 3)



# Generated at 2022-06-21 12:28:11.238681
# Unit test for function register
def test_register():
    """Validate that the codec is successfully registered."""
    import sys
    import os

    # Make sure the codec is not already registered.
    try:
        codecs.getdecoder(NAME)
        raise AssertionError('Codec already registered.')
    except LookupError:
        pass

    # Register the codec and make sure it is registered.
    register()
    codecs.getdecoder(NAME)

    # pylint: disable=protected-access
    # Remove the codec from Python.
    for key in sys.modules[__name__].__dict__.keys():
        __import__('codecs').__dict__['lookup'].cache.pop(key, None)
    os.environ['PYTHONIOENCODING'] = ''

    # Make sure the codec is not registered.

# Generated at 2022-06-21 12:28:12.601295
# Unit test for function decode
def test_decode():
    assert decode(b'Tw==')[0] == '2'



# Generated at 2022-06-21 12:28:19.346860
# Unit test for function encode
def test_encode():
    # needed to register the ``b64`` encoder and decoder.
    register()

    # The string to be converted to base64 bytes
    test_str = (
        'Zm9vYmFy\n'
        '\n'
        'c2VjcmV0'
    )
    # The expected result
    expected_bytes = b'foobar\x00\x00secret'

    # Test the 'encode()' function.
    encoded_bytes, _ = codecs.encode(test_str, NAME)   # type: ignore
    assert encoded_bytes == expected_bytes



# Generated at 2022-06-21 12:28:29.999028
# Unit test for function decode
def test_decode():
    # Test decoding base64 strings
    assert decode(b'Zm9v') == ('Zm9v', 4)
    assert decode(b'Zg==') == ('Z', 2)
    assert decode(b'Zm8=') == ('Zm', 3)
    assert decode(b'Zm9v') == ('Zm9v', 4)
    assert decode(b'Zm9vYg==') == ('Zm9vYg', 6)
    assert decode(b'Zm9vYmE=') == ('Zm9vYmE', 7)
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)

    # Testing invalid base64 strings
    # Missing padding

# Generated at 2022-06-21 12:28:54.074756
# Unit test for function encode
def test_encode():
    # Test with a string that is base64 encode-able.
    assert encode('c2xlZXAgZmV3IHNlY29uZHMh')[0] == b'sleep few seconds!'

    # Test with a string that is not base64 encode-able.
    assert encode('c2xlZXAgZmV3IHNlY29uZHMh@')[0] == b''

    # Test with a string that is not base64 encode-able but with the
    # strict error level

# Generated at 2022-06-21 12:29:04.295925
# Unit test for function encode
def test_encode():
    """Test the function :func:`encode`"""
    assert encode('') == (b'', 0)
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)
   

# Generated at 2022-06-21 12:29:08.715744
# Unit test for function decode
def test_decode():
    data_str = 'Hello\nWorl\nd\n'
    data_bytes = data_str.encode('utf-8')
    encoded_str, _ = decode(data_bytes)
    assert encoded_str == 'SGVsbG8KR29ybBxkCg=='



# Generated at 2022-06-21 12:29:19.297803
# Unit test for function decode

# Generated at 2022-06-21 12:29:21.522212
# Unit test for function decode
def test_decode():
    input = "SGVsbG8="
    output = decode(input)
    assert output == ("Hello", 8)


# Generated at 2022-06-21 12:29:27.432870
# Unit test for function encode
def test_encode():
    # Setup
    text_input = "I am here\nTo help your\nCoding along."
    expected_bytes = b"SSBhbSBoZXJlCFRvIGhlbHAgeW91cgpoQ29kaW5nIGFsb25nLg=="

    # Exercise
    actual_bytes, _ = encode(text_input)

    # Verify
    assert actual_bytes == expected_bytes

    # Cleanup - none necessary



# Generated at 2022-06-21 12:29:29.227153
# Unit test for function encode
def test_encode():
    text = "QUJDREVGRw=="
    errors = 'strict'
    assert encode(text, errors) == (b'ABCDEFG', 10)



# Generated at 2022-06-21 12:29:39.563616
# Unit test for function register
def test_register():
    """Test registering of the ``b64`` Codec."""
    try:
        # noinspection PyUnresolvedReferences
        import b64._internal.codec  # pylint: disable=import-outside-toplevel
    except ImportError:
        import _internal.codec  # pylint: disable=import-outside-toplevel
    mock_get_codec_info = None  # type: Optional[MagicMock]

    # Mock 'codecs.getdecoder'
    mock_getdecoder = codecs.getdecoder
    # noinspection PyUnusedLocal

# Generated at 2022-06-21 12:29:48.051993
# Unit test for function encode
def test_encode():
    """Test ``encode`` function."""
    assert encode('') == (b'', 0)
    assert encode('SGVsbG8=') == (b'Hello', 6)
    assert encode('UGFzc3dvcmQ=') == (b'Password', 8)
    assert encode('Tm92ZXIgbWl2ZQ==') == (b'Never mid', 10)
    assert encode('THlsYmVydA==') == (b'Helbert', 7)
    assert encode('dGVzdA==') == (b'test', 4)
    assert encode('Rm9v') == (b'Foo', 3)
    assert encode('THlsYmVydA==') == (b'Helbert', 7)


if __name__ == '__main__':
    test_encode()

# Generated at 2022-06-21 12:29:57.371602
# Unit test for function decode
def test_decode():
    assert(decode(b'\x86\x61\x89\x60')== ('oNcm', 4))
    assert(decode(b'\x82\x61\x84\x60\x80\x60\x82\x60')==('aaki', 4))
    assert(decode(b'\x89\x60\x81\x60\x83\x60')==('pae', 4))
    assert(decode(b'\x80\x61\x82\x60')==('ae', 4))
    assert(decode(b'\x86\x61\x89\x60 \x86\x61\x89\x60')==('oNcm oNcm', 8))

# Generated at 2022-06-21 12:30:19.156581
# Unit test for function decode

# Generated at 2022-06-21 12:30:23.221337
# Unit test for function register
def test_register():
    """Register ``b64`` codec with Python."""
    # Register the b64 codec.
    register()
    try:
        # Test for the existence of the b64 codec.
        assert codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-21 12:30:31.579466
# Unit test for function encode
def test_encode():
    """Unit tests for the ``encode`` function"""
    # Test 1: Test text with four lines of text each with 80 characters
    #         of whitespace.  This is the maximum amount of leading
    #         whitespace allowed by the base64 encoding specification.
    #         The maximum is to be as follows:
    #         # Lines of base64 data must be 64 characters wide, except for
    #         # the last line, which may be less than (or equal to) 64 characters
    #         # wide.
    #         In addition, the leading whitespace **must** be **EXACTLY** four
    #         spaces.

# Generated at 2022-06-21 12:30:41.026419
# Unit test for function decode
def test_decode():
    print("Testing decode()...", end="")

    assert "".encode("b64") == b""
    assert "f".encode("b64") == b"Zg=="
    assert "fo".encode("b64") == b"Zm8="
    assert "foo".encode("b64") == b"Zm9v"
    assert "foob".encode("b64") == b"Zm9vYg=="
    assert "fooba".encode("b64") == b"Zm9vYmE="
    assert "foobar".encode("b64") == b"Zm9vYmFy"

    print("...passed")


# Generated at 2022-06-21 12:30:47.727632
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    res_bytes, len_bytes = encode('YWJjMTIzIT8kKiYoKSctPUB+')
    res_str = 'abc123!?$*&()-=@~'
    assert res_bytes == res_str.encode('utf-8')
    assert len_bytes == 26
    res_bytes, len_bytes = encode('YWJjMTIzIT8kKiYoKSctPUB+Cg==\n')
    res_str = 'abc123!?$*&()-=@~'
    assert res_bytes == res_str.encode('utf-8')
    assert len_bytes == 28

# Generated at 2022-06-21 12:30:56.350393
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 11)
    assert encode('SFRUUC8xLjENCg0KLy4uLio=') == (b'HTTP/1.0\n\n/*.*', 19)

# Generated at 2022-06-21 12:31:06.453202
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefghijklmnopqrstuvwxyz') == (b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=', 26)

# Generated at 2022-06-21 12:31:14.667522
# Unit test for function decode
def test_decode():

    # Test the decode function with non-base64 characters.

    non_base64_inputs = [
        # Non-base64 characters
        '!!',
        '!!!',
        '!!!!',
        '!!!!!',

        # Whitespace
        ' ',
        '  ',
        '  ',
        '   ',
        '    ',
        '     ',

    ]

    for non_base64_input in non_base64_inputs:
        try:
            decode(non_base64_input)
        except UnicodeEncodeError:
            pass
        else:
            raise AssertionError(
                f'{non_base64_input!r} was not a properly detected '
                f'non-base64 character string.'
            )



# Generated at 2022-06-21 12:31:17.757095
# Unit test for function decode
def test_decode():
    assert decode(b'YWJjZA==')[0] == 'abcd'


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:31:28.210799
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)

# Generated at 2022-06-21 12:32:07.096684
# Unit test for function encode
def test_encode():
    """Unit test for the ``b64`` codec's ``encode`` function."""

# Generated at 2022-06-21 12:32:12.359767
# Unit test for function encode
def test_encode():
    # Arrange
    text = """
        Zm9vYmFy
        MWZv
        b2Jhcg==
    """
    expected = b'foobar1foobar'

    # Act
    result, length = encode(text)

    # Assert
    assert result == expected
    assert length == len(text)



# Generated at 2022-06-21 12:32:19.407353
# Unit test for function decode
def test_decode():
    """Unit test for the :func:`decode` function."""
    # Arrange
    test_input = b'bG9uZywgY29tcHJpc2VkIGJ5dGUgc3RyaW5n'
    expected = 'bG9uZywgY29tcHJpc2VkIGJ5dGUgc3RyaW5n'

    # Act
    actual = decode(test_input)

    # Assert
    assert actual == (expected, len(test_input))


# Generated at 2022-06-21 12:32:27.557484
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhcw==') == (b'any carnal pleas', 22)
    assert encode('YW55IGNhcm5hbCBwbGVhc2U=') == (b'any carnal pleas', 21)
    assert encode('YW55IGNhcm5hbCBwbGVhc3U=') == (b'any carnal pleas', 21)
    assert encode('YW55IGNhcm5hbCBwbGVhc3Vy') == (b'any carnal pleas', 21)
    assert encode('YW55IGNhcm5hbCBwbGVhc3VyZQ==') == (b'any carnal pleas', 22)

# Generated at 2022-06-21 12:32:37.120916
# Unit test for function register
def test_register():
    """Test that the 'register()' function registers the codec properly."""
    register()

    # Lookup the registered codec.
    decoder = codecs.getdecoder(NAME)  # type: ignore
    encoder = codecs.getencoder(NAME)  # type: ignore

    # Make sure that the codecs are the ones that we expect.
    assert decoder[0] == decode  # type: ignore
    assert encoder[0] == encode  # type: ignore

    # Make sure that the encoder/decoder work.
    out = encoder(b'hello')
    in_bytes = decoder(out[0])

    assert in_bytes[0] == b'hello'
    assert in_bytes[1] == 5


if __name__ == '__main__':
    # Register the codec
    register()

