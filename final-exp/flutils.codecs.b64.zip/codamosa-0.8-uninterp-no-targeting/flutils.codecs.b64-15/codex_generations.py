

# Generated at 2022-06-21 12:22:37.170137
# Unit test for function register
def test_register():
    '''The call to register should not raise an exception'''

    register()


# Generated at 2022-06-21 12:22:39.399496
# Unit test for function decode
def test_decode():
    data = b'hello'
    result = decode(data)
    assert result == ('aGVsbG8=\n', 5)


# Generated at 2022-06-21 12:22:42.542066
# Unit test for function encode
def test_encode():
    assert encode('SXQ=') == (b'a', 3)
    assert encode('SXQ==') == (b'a', 4)
    assert encode('SXQ===') == (b'a', 4)



# Generated at 2022-06-21 12:22:53.216917
# Unit test for function encode
def test_encode():
    # pylint: disable=pointless-string-statement
    """Unittest to test the encode function."""

# Generated at 2022-06-21 12:22:58.206034
# Unit test for function encode
def test_encode():
    text = """
        eW91IGNhbiByZWFkIHRoaXMgaW4gYSBsYW5ndWFnZSB0aGF0\n
        IHlvdSBkb24ndCBrbm93IG15IGNvZGUgaXMgc2FmZQ==\n"""
    expected = b'you can read this in a language that you don\'t know my code is safe'
    result = encode(text)
    assert result == (expected, len(text))



# Generated at 2022-06-21 12:23:02.187045
# Unit test for function encode
def test_encode():
    text = """
Zm9v
Cg==
"""

    text_bytes = encode(text)[0]
    assert text_bytes == b'foo\n\n'



# Generated at 2022-06-21 12:23:13.690784
# Unit test for function encode
def test_encode():
    # Test case 1
    print('Running Test Case 1 - valid')
    text_input = '''
        U3BpZGVyc1xzdGVlbGVyc1x0cmFqZWN0b3J5XGZlYXR1cmVzXHNwZWNpYWwtdmFsdWVzLXRvZ2V0aGVyLmRlZmF1bHQudHh0Cg==
    '''
    expected_out = b'Spider\x00sellers\x00tractory\x00features\x00special-values-together\x00.default.txt\x00'
    out, _ = encode(text_input)
    assert out == expected_out
    print('Test Case 1 passed')

    # Test case 2

# Generated at 2022-06-21 12:23:23.870082
# Unit test for function decode

# Generated at 2022-06-21 12:23:35.440204
# Unit test for function encode
def test_encode():
    test_obj = UserString(
        textwrap.dedent('''\
        ZXhhbXBsZSBvZiBlbmNvZGVkIG92ZXIgbXVsdGlwbGUgbGluZXMKCmFyZSBv
        biB0aGlzIHdheSBzbyB3ZSBjYW4gcHJpbnQgb3V0IHRoZSBjb2RlIGZvciB0
        aGlzIHByb2plY3QgYW5kIHRha2Ugc2Vuc2Ugb2YgdGhlIHdheSBiYXNlNjQg
        aXMgY29kZWQu
        ''')
    )
    # pylint: disable=W0108
    # if noinspection

# Generated at 2022-06-21 12:23:36.948739
# Unit test for function decode
def test_decode():
    assert(decode(b'foobar') == ('Zm9vYmFy', 6))



# Generated at 2022-06-21 12:23:40.189447
# Unit test for function register
def test_register():
    """Test function ``register``."""
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:23:42.608094
# Unit test for function decode
def test_decode():
    """Test the function ``decode``."""
    assert decode(b'YWJj') == ('abc', 3)



# Generated at 2022-06-21 12:23:48.758018
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)
    doctest.testmod(optionflags=doctest.REPORT_NDIFF)

# Generated at 2022-06-21 12:23:54.237793
# Unit test for function decode
def test_decode():
    from itertools import product
    from string import ascii_letters, printable, whitespace
    from random import choice

    register()
    # All random strings are the same length.
    # The length must be a multiple of 4.
    # It must end with 4 bytes that represent 4 base64 characters.
    length = 12

    for i in range(length):
        assert i % 4 == 0

        # Generate a random set of bytes.
        data = bytes(choice(range(256)) for _ in range(i))

        # Encode the 'data_bytes' into base64 bytes.
        base64_input = base64.b64encode(data)

        # Decode the 'base64_bytes' as utf8 into a string.
        input_str = base64_input.decode('utf-8')

        # Test

# Generated at 2022-06-21 12:24:01.615059
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    from base64 import b64decode
    from binascii import (Error as _Error,
                          hexlify)

    result, _ = encode('')
    assert result == b''
    assert encode('', errors='strict') == (b'', 0)
    try:
        encode('n', errors='strict')
        assert False, 'Expected exception'
    except UnicodeEncodeError as e:
        assert str(e) == \
            f"'b64' codec can't encode character 'n' in position 0: " \
            f"b'n' is not a proper bas64 character string: Incorrect " \
            f"padding"

    result, _ = encode(
        'SGVsbG8sIHdvcmxkIQ=='
    )

# Generated at 2022-06-21 12:24:05.082582
# Unit test for function encode
def test_encode():
    """Test correctness of encode"""
    # Negative test with UnicodeEncodeError: b64 'a' is not a proper bas64 character string: Incorrect padding
    with pytest.raises(UnicodeEncodeError) as excinfo:
        encode("a")
    assert 'Incorrect padding' in str(excinfo.value)
    assert encode("a") == (b'', 1)

    # Negative test with UnicodeEncodeError: b64 '\x01' is not a proper bas64 character string: Incorrect padding
    with pytest.raises(UnicodeEncodeError) as excinfo:
        encode("\x01")
    assert 'Incorrect padding' in str(excinfo.value)
    assert encode("\x01") == (b'', 1)

    # Negative test with UnicodeEncodeError: b64 '\x10'

# Generated at 2022-06-21 12:24:16.026035
# Unit test for function decode
def test_decode():
    register()
    assert decode(b'A')[0] == 'QQ=='
    assert decode(b'AB')[0] == 'QUI='
    assert decode(b'ABC')[0] == 'QUJD'
    assert decode(b'ABCD')[0] == 'QUJDRA=='
    assert decode(b'ABCDE')[0] == 'QUJDREU='
    assert decode(b'ABCDEF')[0] == 'QUJDREVG'
    assert decode(b'ABCDEFG')[0] == 'QUJDREVGRw=='
    assert decode(b'ABCDEFGH')[0] == 'QUJDREVGR0g='
    assert decode(b'ABCDEFGHI')[0] == 'QUJDREVGR0hJ'

# Generated at 2022-06-21 12:24:19.255249
# Unit test for function encode
def test_encode():
    string = "This is a string"
    test_encoded_input = "VGhpcyBpcyBhIHN0cmluZw=="
    result = encode(test_encoded_input)
    assert string == result[0].decode()
    assert isinstance(result[1], int)


# Generated at 2022-06-21 12:24:22.078107
# Unit test for function decode
def test_decode():
    assert (
        decode(b'UyB0ZXh0IGFyZSBiYXNlIDY0IGNoYXJhY3Rlci4=', 'strict')
        == ('My text are base 64 character.', 32)
    )



# Generated at 2022-06-21 12:24:26.297813
# Unit test for function register
def test_register():
    """Test that the b64 codec has been registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    codecs.getdecoder(NAME)
    return


# Generated at 2022-06-21 12:24:38.421831
# Unit test for function decode
def test_decode():
    assert decode(b'AA==') == ('*', 2)
    assert decode(b'YQ==') == ('a', 2)
    assert decode(b'YmI=') == ('bb', 3)
    assert decode(b'YmNj') == ('bcc', 4)
    assert decode(b'YmNjZA==') == ('bccd', 8)
    assert decode(b'YmNjZGQ=') == ('bccdd', 8)
    assert decode(b'YmNjZGRk') == ('bccddd', 8)
    assert decode(b'YmNjZGRkZA==') == ('bccdddd', 16)
    assert decode(b'YmNjZGRkZGQ=') == ('bccddddd', 16)

# Generated at 2022-06-21 12:24:40.475479
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) == encode
    assert codecs.getdecoder(NAME) == decode



# Generated at 2022-06-21 12:24:47.786796
# Unit test for function register
def test_register():
    """Unit test for function `register()`"""

    # Given
    old_dict = dict(codecs.__dict__)

    # When
    register()

    # Then
    new_dict = dict(codecs.__dict__)
    for test_key, test_value in new_dict.items():
        if test_key not in old_dict:
            assert test_value.name == NAME # type: ignore
            break

# Generated at 2022-06-21 12:24:51.697352
# Unit test for function encode
def test_encode():
    assert encode('This is a test of the encode function.') == \
        (b'VGhpcyBpcyBhIHRlc3Qgb2YgdGhlIGVuY29kZSBmdW5jdGlvbi4=', 53)

# Unit test function decode

# Generated at 2022-06-21 12:25:00.750017
# Unit test for function decode
def test_decode():
    assert decode(b'AQIDBA==') == ('12345', 8)
    assert decode(b'AQI~') == ('12\u0394', 4)
    assert decode(b'AQIDBA==', 'ignore') == ('12345', 8)
    assert decode(b'AQI~', 'replace') == ('12\uFFFD', 4)
    assert decode(b'!!!!!') == ('!!!!!', 5)
    assert decode(b'!!!!!') == ('!!!!!', 5)
    assert decode(b'AQIDBA') == ('123', 6)
    assert decode(b'AQIDBA', 'replace') == ('12\uFFFD\uFFFD\uFFFD', 6)

# Generated at 2022-06-21 12:25:05.134794
# Unit test for function decode
def test_decode():
    assert decode(b"\xd0\xb0\xd0\xb1\xd0\xb2\xd0\xb3", 'strict') == ('0L7RgdC10L3RgiDQv9C40YHQvtC6', 16)



# Generated at 2022-06-21 12:25:09.083000
# Unit test for function encode
def test_encode():
    """Test the encode function"""
    # Test encoding of the character A.
    # base64(A) = QQ==
    assert encode(b'\x41') == (b'A', 1)

# Generated at 2022-06-21 12:25:19.818737
# Unit test for function encode

# Generated at 2022-06-21 12:25:28.521316
# Unit test for function decode
def test_decode():
    data = b'\x48\x65\x6c\x6c\x6f\x0a\x0a\x48\x65\x6c\x6c\x6f\x0a\x0a'

    vals = [
        (b'SGVsbG8KClRoaXMgaXMgYSAKIGRlc2NyaXB0aW9uCiBvZiB0aGlzIGZpbGUK', '\n'),
        (b'SGVsbG8KClRoaXMgaXMgYSAKIGRlc2NyaXB0aW9uCiBvZiB0aGlzIGZpbGUK', '\t'),
    ]


# Generated at 2022-06-21 12:25:40.050600
# Unit test for function encode
def test_encode():  # pragma: no cover
    s = """
        eHl6
        eGVsbG8gd29ybGQ=
        dGhlIGZvbGxvd2luZyB
        Y2FuY2VsZWQgYnkgYSBaaXAgZml4
        IHRoZXJlIGFyZSB0cmFjZW1lbnRhbCBzeW1ib2xzIGFsbCBvdmVyIHRoZSBwbGFjZSBmb3IgdGhpcyBmZWF0
        dXJlCiAgICAgICAgCiAgICAgICAgIyManMgY2hlY2sKCg==
    """
    s = s.replace('\n', '')
    s = s.replace('\r', '')
   

# Generated at 2022-06-21 12:25:44.702705
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:25:52.534928
# Unit test for function decode
def test_decode():
    # Test decoding single byte values
    for byte_value in range(0, 256):
        byte_value_bytes = bytes([byte_value])
        # Decode the byte value
        decoded_text, consumed = decode(byte_value_bytes)
        # Ensure the correct text was decoded
        assert consumed == 1
        assert isinstance(decoded_text, str)
        assert len(decoded_text) == 4

        # Encode the text
        encoded_bytes, consumed = encode(decoded_text)
        assert consumed == 4
        assert isinstance(encoded_bytes, bytes)

        assert byte_value == encoded_bytes[0]


# Generated at 2022-06-21 12:25:58.539880
# Unit test for function decode
def test_decode():
    assert decode(b'123456') == ('MTIzNDU2', 6)
    assert decode(b'1234567890') == ('MTIzNDU2Nzg5MA==', 10)
    assert decode(b'1234567890abcdefghijklmnopqrstuvwxyz') == ('MTIzNDU2Nzg5MGFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6', 36)
    assert decode(b'1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ') == ('MTIzNDU2Nzg5MEFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFla', 36)

# Generated at 2022-06-21 12:26:01.597290
# Unit test for function encode

# Generated at 2022-06-21 12:26:08.401338
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
        raise ValueError(
            f'The {NAME!r} codec is already registered.'
        )
    except LookupError:
        pass
    register()
    codecs.getdecoder(NAME)
    try:
        register()
    except ValueError as e:
        assert str(e) == f'The {NAME!r} codec is already registered.'

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:26:13.552771
# Unit test for function encode
def test_encode():
    assert encode("UG93ZXJlZCBieSBJbnZlc3RpZ2F0aW9ucyE=", "strict") == (b'Powered by Investigations!', 31)


# Generated at 2022-06-21 12:26:24.077511
# Unit test for function encode
def test_encode():
    """A unit test for the ``encode`` function."""
    assert encode('') == (b'', 0)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcd', errors='ignore') == (b'YWJjZA==', 4)
    assert encode('abcd', errors='strict') == (b'YWJjZA==', 4)
    assert encode('abcd', errors='replace') == (b'YWJjZA==', 4)
    assert encode('abcd', errors='xmlcharrefreplace') == (b'YWJjZA==', 4)
    assert encode('abcd', errors='backslashreplace') == (b'YWJjZA==', 4)

# Generated at 2022-06-21 12:26:27.084235
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec."""
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:26:38.337149
# Unit test for function encode
def test_encode():
    """Unit test for function encode

    Note:
        To run this test execute the following command:

        > python -m b64.codec

    """
    assert encode('') == (b'', 0)

    # Normal single line
    text = 'YQ=='
    expected_bytes = b'a'
    expected_length = len('YQ==')
    assert encode(text) == (expected_bytes, expected_length)

    # Normal multi-line
    text = """\
    YQ==
    """
    expected_bytes = b'a'
    expected_length = len('YQ==')
    assert encode(text) == (expected_bytes, expected_length)

    # Special characters

# Generated at 2022-06-21 12:26:40.933727
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    register()
    obj = codecs.getdecoder(NAME)   # type: ignore
    assert obj is not None

# Generated at 2022-06-21 12:26:58.712701
# Unit test for function decode
def test_decode():
    # Test for a single base64 Character
    assert decode(b'A', 'strict')[0] == 'QQ=='

    # Test for multiple base64 Characters
    assert decode(b'ABC', 'strict')[0] == 'QUJD'
    assert decode(b'ABCD', 'strict')[0] == 'QUJDRA=='
    assert decode(b'ABCDE', 'strict')[0] == 'QUJDREU='
    assert decode(b'ABCDEF', 'strict')[0] == 'QUJDREVG'

    # Test bytearray
    assert decode(bytearray(b'ABC'), 'strict')[0] == 'QUJD'

    # Test memoryview
    assert decode(memoryview(b'ABC'), 'strict')[0] == 'QUJD'




# Generated at 2022-06-21 12:27:00.693486
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()   # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:27:03.339409
# Unit test for function register
def test_register():
    """Unit test for function :py:func:`register`"""
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:27:12.808382
# Unit test for function decode
def test_decode():
    assert decode(b'abc123') == ('YWJjMTIz', 6)
    assert decode(
        b'abcdefg'
    ) == ('YWJjZGVmZw==', 7)
    assert decode(b'123') == ('MTIz', 3)
    assert decode(b'q') == ('cQ==', 1)
    assert decode(b'Q') == ('UQ==', 1)
    assert decode(b'') == ('', 0)


# No Unit test for encode
#
# The only usable test for encode would need to be something that
# fails.  However, there is no exception to test on.  When
# encodebytes is given bad input, it silently returns ''.
#
# Instead, the following tests are equivalent and are tested
# indirectly by test_decode():
#
# assert

# Generated at 2022-06-21 12:27:15.672532
# Unit test for function register
def test_register():
    register()
    assert NAME == 'b64'
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


# Generated at 2022-06-21 12:27:21.849923
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
        registered = True
    except LookupError:
        registered = False

    register()
    assert registered is True

    try:
        codecs.getdecoder(NAME)
        registered = True
    except LookupError:
        registered = False
    assert registered is False

# Generated at 2022-06-21 12:27:29.185226
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``"""
    assert encode('SGVsbG8=')[0] == b'Hello'
    assert encode('SGVsbG8gR2V5')[0] == b'Hello Guy'
    assert encode('SGVsbG8gR2V5IA==')[0] == b'Hello Guy '
    assert encode('SGVsbG8gR2V5IA')[0] == b'Hello Guy '
    assert encode('SGVsbG8gR2V5IA==\r')[0] == b'Hello Guy '
    assert encode('SGVsbG8gR2V5IA==\r\n')[0] == b'Hello Guy '

# Generated at 2022-06-21 12:27:41.249067
# Unit test for function decode
def test_decode():
    # Test the empty string
    assert decode(b'') == ('', 0)

    # Test that the maximum number of bytes for a character is two.
    data = b'\xFF\xFF'
    expected = '//8='
    actual = decode(data)
    assert expected == actual[0]
    assert len(data) == actual[1]

    # Test that the minimum number of bytes for a character is two.
    data = b'\x00\x00'
    expected = 'AA=='
    actual = decode(data)
    assert expected == actual[0]
    assert len(data) == actual[1]

    # Test that the maximum number of bytes for a character is three.
    data = b'\xFF\xFF\xFF'
    expected = '////////'
    actual = decode(data)


# Generated at 2022-06-21 12:27:46.258067
# Unit test for function register
def test_register():
    """Test function :func:`~pybase64_codec.codec.register`"""
    register()
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:27:50.186978
# Unit test for function register
def test_register():
    # Register the `b64` codec in the 'codecs' package.
    register()

    # Verify the registration.
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:28:03.760706
# Unit test for function decode
def test_decode():
    assert decode(bytes([1, 2, 3]), None)[0] == 'AQID' 



# Generated at 2022-06-21 12:28:12.251813
# Unit test for function encode
def test_encode():
    """Test the b64.encode() function."""
    print('Test b64.encode()')
    assert encode(b'') == (b'', 0)
    assert encode('') == (b'', 0)
    assert encode('\x00') == (b'AA==', 3)
    assert encode('  \n\n  ') == (b'', 0)
    assert encode('   \n   \n   ') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('   aGVsbG8gd29ybGQ=   ') == (b'hello world', 23)
    assert encode('aGVsbG8gd29ybGQ= ') == (b'hello world', 20)

# Generated at 2022-06-21 12:28:18.748977
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    try:
        # Verify that the codec has not been registered with Python.
        codecs.getdecoder(NAME)
    except LookupError:
        # Register the codec with Python.
        register()

        # Verfity that the codec was registered with Python.
        codecs.getdecoder(NAME)

    # Remove the codec from Python.
    codecs.lookup(NAME).__delitem__(NAME)
    codecs.reset()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:28:26.689096
# Unit test for function register
def test_register(): # pragma: no cover
    """Register the ``b64`` codec with Python."""
    import sys

    # Import the codec register function.
    sys.path.append('..')
    from base64codec.b64 import register  # pylint: disable=E0611

    # Unregister the codec from Python.
    codecs.unregister(NAME)

    # Register the codec with Python.
    register()

    # Verify the codec was registered.
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:28:30.223319
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # pylint: disable=C0301
    import codecs
    from codecs import CodecInfo

    register()
    assert isinstance(codecs.getencoder(NAME), CodecInfo)
    assert isinstance(codecs.getdecoder(NAME), CodecInfo)

# Generated at 2022-06-21 12:28:34.515505
# Unit test for function decode
def test_decode():
    data = bytes([0, 1, 2, 3, 4, 5, 6, 7])
    expected = 'AAECAQQEBAQE'
    actual = decode(data)[0]
    assert actual == expected


# Generated at 2022-06-21 12:28:44.295218
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode(' \n \n \n ') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode(' \n \n \n \n \n ') == (b'', 0)
    assert encode('AQAB') == (b'\x01', 4)
    assert encode('\nAQAB\n') == (b'\x01', 4)

# Generated at 2022-06-21 12:28:54.073439
# Unit test for function encode
def test_encode():
    # These tests are a bit more ad hoc than I would like
    # I'm having trouble getting the real test_lib to work
    assert encode('') == (b'', 0)
    assert encode('A') == (b'\x41', 1)
    assert encode('L') == (b'\x4c', 1)
    assert encode('d') == (b'\x64', 1)
    assert encode('QQ') == (b'\x51\x51', 2)
    assert encode('9') == (b'\x39', 1)
    assert encode('==') == (b'\x00', 2)



# Generated at 2022-06-21 12:28:56.773393
# Unit test for function encode
def test_encode():
    # text_str = '===base64==='
    text_str = 'WmVraSBkb2RhIHNvbWUgZ3Jpc2VuIGJ5dGVz'
    text_bytes = text_str.encode()
    ref_bytes = b'Zeke doah some grisen bytes'
    out = encode(text_bytes)[0]
    assert out == ref_bytes

# Generated at 2022-06-21 12:29:07.367152
# Unit test for function encode
def test_encode():
    """Test for the encode function."""
    assert encode('OmFnaXN0dQ==') == (b'Fantasy', 7)
    assert encode('TmFtZSBpcyBKb2huIERvZQ==') == (b'Name is John Doe', 16)

# Generated at 2022-06-21 12:29:22.373978
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # Test every codec attribute.
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-21 12:29:24.281003
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)


# Unit tests for function 'decode'

# Generated at 2022-06-21 12:29:32.504084
# Unit test for function decode
def test_decode():
    assert decode(b'QQ==') == ('A', 1)
    assert decode(b'BGk=') == ('Ψ', 2)
    assert decode(b'OA==') == ('0', 1)
    assert decode(b'Zm9v') == ('foo', 3)
    assert decode(b'Zm9vYg==') == ('foob', 4)
    assert decode(b'Zm9vYmE=') == ('fooba', 5)
    assert decode(b'Zm9vYmFy') == ('foobar', 6)
    assert decode(b'Zm9v\r\nYmFy') == ('foobar', 6)
    assert decode(b'Zm9v\nYmFy') == ('foobar', 6)

# Generated at 2022-06-21 12:29:43.248447
# Unit test for function decode

# Generated at 2022-06-21 12:29:50.832738
# Unit test for function register
def test_register():
    import sys
    import os
    import copy
    import inspect
    from ofxstatement.plugins.standard.aib import AibParser

    # Save a copy of the current sys.modules
    sys_modules_before = copy.deepcopy(sys.modules)

    # Import package
    from importlib import import_module
    import_module(AibParser.__module__)

    AibParser_module = sys.modules[AibParser.__module__]
    sys.modules = sys_modules_before

    # Find the function in the module.
    register_module = inspect.getmodule(register)
    assert sys.modules[register_module.__name__] != register_module.__name__
    codecs = import_module(register_module.__name__)


# Generated at 2022-06-21 12:29:56.028865
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Unable to register factory function: {e}')
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Unable to register factory function: {e}')


# Generated at 2022-06-21 12:29:58.426654
# Unit test for function decode
def test_decode():
    """Test function decode"""
    print(decode(b'abc'))
    assert decode(b'abc') == ('YWJj', 3)

    try:
        decode(b'abc123')
    except UnicodeDecodeError:
        print('UnicodeDecodeError')


# Generated at 2022-06-21 12:30:05.730831
# Unit test for function encode
def test_encode():
    assert encode("ZW5jb2RlZCBieXRlcyBmb3IgdGhlIGJhc2U2NCBjb2RlY2g=") == (b"encoded bytes for the base64 codec", 38)
    assert encode("RGVjb2RlZCBieXRlcyBmb3IgdGhlIGJhc2U2NCBjb2RlY2g=") == (b"Decoded bytes for the base64 codec", 38)
    assert encode("UHJvbWlzZSE=") == (b"Promise!", 10)
    assert encode("TWlzcw==") == (b"Miss", 6)
    assert encode("TWlzcw") == (b"Miss", 5)

# Generated at 2022-06-21 12:30:09.242911
# Unit test for function decode
def test_decode():
    # Input string
    st = "This is an encoded string"

    # Encoded string
    en_st = codecs.encode(st, 'b64')

    # Decoded string
    de_st = codecs.decode(en_st, 'b64')

    # Check whether the orginal and decoded strings are equal
    assert (st == de_st.decode("utf-8"))

    print("Test decode passed")


# Generated at 2022-06-21 12:30:17.585368
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    line = (
        "This text contains spaces, tabs, and a newline."
        "  It's a total mess.\n"
        "I need to be encoded into base64 bytes!"
    )

    assert encode(line) == (
        b'VGhpcyB0ZXh0IGNvbnRhaW5zIHNwYWNlcywgdGFicywgYW5kIGEgbmV3b'
        b'GluZS4gSXQncyBhIHRvdGFsIG1lc3MuCkkgbmVlZCB0byBiZSBlbmNvZG'
        b'VkIGludG8gYmFzZTY0IGJ5dGVzIQ==',
        len(line)
    )

# Generated at 2022-06-21 12:30:48.909806
# Unit test for function decode
def test_decode():
    # Test normal decode
    test_data_bytes = bytes.fromhex(
        '595130c42efa9a8af8aefbaf0c00b11f5d53f8d6638c69b7c80a05'
    )
    expected_output = (
        'WQ0uMXrkAPrqAPq3ABE0ATXkXSPrR8g0=\n'
    )
    output = codecs.decode(test_data_bytes, 'b64')
    assert output == expected_output

    # Test decode with an input that would normally cause an Error
    # exception.

# Generated at 2022-06-21 12:30:53.705570
# Unit test for function register
def test_register():
    """Test function ``register``."""
    try:
        register()
    except Exception:  # pylint: disable=W0703
        pytest.fail(
            'register failed to register the codec: codecs.CodecInfo'
            ' but did not raise an exception.'
        )


if __name__ == '__main__':
    register()


# pylint: disable=W0613

# Generated at 2022-06-21 12:31:03.455027
# Unit test for function decode
def test_decode():
    assert decode(b'\x00\x70\x00') == ('AAAB', 3)
    assert decode(b'\x00\x70\x00', 'strict') == ('AAAB', 3)

    assert decode(bytearray(b'\x00\x70\x00')) == ('AAAB', 3)
    assert decode(bytearray(b'\x00\x70\x00'), 'strict') == ('AAAB', 3)

    assert decode(memoryview(b'\x00\x70\x00')) == ('AAAB', 3)
    assert decode(memoryview(b'\x00\x70\x00'), 'strict') == ('AAAB', 3)


# Generated at 2022-06-21 12:31:07.165449
# Unit test for function encode
def test_encode():
    """Test encoding string to base64 bytes"""
    data = "Hello, World!"
    # Test encoding string to base64
    assert b"SGVsbG8sIFdvcmxkIQ==" == encode(data)[0]
    # Test encoding string with extra spaces to base64
    assert b"SGVsbG8sIFdvcmxkIQ==" == encode("Hello, World!   ")[0]
    # Test encoding string with \n to base64
    assert b"SGVsbG8sIFdvcmxkIQ==" == encode("Hello,\nWorld!")[0]


# Generated at 2022-06-21 12:31:12.901303
# Unit test for function encode
def test_encode():
    from gettext import gettext as _

    # Test 'encode'
    assert encode('') == (b'', 0)
    assert encode('CWF') == (b'bXkgc2VjcmV0', 11)
    assert encode('\nCWF') == (b'bXkgc2VjcmV0', 11)
    assert encode('\n\n\nCWF\n\n\n') == (b'bXkgc2VjcmV0', 11)
    assert encode('\nCWF\n\n\n') == (b'bXkgc2VjcmV0', 11)
    assert encode('\nCWF\n\n\n') == (b'bXkgc2VjcmV0', 11)

# Generated at 2022-06-21 12:31:20.276111
# Unit test for function encode
def test_encode():
    """Tests for `encode`."""
    # Test for no input
    assert encode('') == (b'', 0)

    # Test for string of only spaces
    for i in range(1, 8):
        assert encode(' ' * i) == (b'', 0)

    # Test for string of only newlines
    for i in range(1, 8):
        assert encode('\n' * i) == (b'', 0)

    # Test for single line string
    assert encode('SGVsbG8sIHdvcmxkIQ==') == \
        (b'Hello, world!', 20)

    # Test for multi-line string
    # NOTE: This test was geared toward the function used before
    #       we learned of the Python's 'base64' module.
    #       This test will not fail,

# Generated at 2022-06-21 12:31:30.722185
# Unit test for function register
def test_register():
    """Unit test for function register
    """
    import sys
    import io

    # Call function register.
    register()

    # Test 1:
    #  Test the function register adding the 'b64'
    #  codec to Python's registry.

    # Get the 'b64' codec.
    codec = codecs.getdecoder(NAME)

    # Test the codec is not None.
    assert codec

    # Test codec.decode
    #  This is a unit test for function decode.
    assert codec.decode(b'SGVsbG8=')[0] == 'Hello'

    # Test codec.encode
    #  This is a unit test for function encode.
    assert codec.encode('Hello')[0].decode('utf-8') == 'SGVsbG8='

    # Test 2:
   

# Generated at 2022-06-21 12:31:38.561090
# Unit test for function encode
def test_encode():
    # Test for a one-line base64 string.
    text = 'cGFnbmFtZTogdGVzdGdyb3VwLXNpdGU='
    assert encode(text)[0] == b'pagename: testgroup-site'

    # Test for a multi-line, indented base64 string
    text = '''
        cGFnbmFtZTogdGVzdGdyb3VwLXNpdGU=
        '''
    assert encode(text)[0] == b'pagename: testgroup-site'

    # Test for a multi-line, indented, base64 string with a blank line
    # after the second line.

# Generated at 2022-06-21 12:31:42.888227
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Unable to retrieve the codec {NAME}: {e}')


# pylint: disable=W0401
# noinspection PyUnresolvedReferences
from . import (
    base64_test,
)

# Generated at 2022-06-21 12:31:54.722399
# Unit test for function encode
def test_encode():
    assert encode('V2UgaGF2ZSBhIGN1cnJlbnQgbGFuZ3VhZ2Uu'), \
        'V2UgaGF2ZSBhIGN1cnJlbnQgbGFuZ3VhZ2Uu'
    assert encode('V2UgaGF2ZSBhIGN1cnJlbnQgbGFuZ3VhZ2Uu\n'), 'V2UgaGF2ZSBhIGN1cnJlbnQgbGFuZ3VhZ2Uu'
    assert encode('V2UgaGF2ZSBhIGN1cnJlbnQgbGFuZ3VhZ2Uu\n    '), 'V2UgaGF2ZSBhIGN1cnJlbnQgbGFuZ3VhZ2Uu'