

# Generated at 2022-06-21 12:22:36.939911
# Unit test for function encode
def test_encode():
    # Create a test string
    test_line = 'QmFzZSA2NCBpcyBhIHNlYW1sZXNzIGJhc2ljIGRlY29kZSBpbnRlcmZhY2Ug' \
                'Zm9yIGVudHJ5IGxldmVsIHVzZXJzLiA='
    test_line_encoded = 'Base 64 is a seamless basic decode interface for entry ' \
                        'level users. '

    # Test the encode function.
    out, size = encode(test_line)
    assert out.decode('utf-8') == test_line_encoded
    assert size == len(test_line)


# Generated at 2022-06-21 12:22:39.570332
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:22:44.138693
# Unit test for function decode
def test_decode():
    """Tests :func:`~pasy.b64_codec.decode`"""
    register()
    # test the encode decode functions.
    test_data = bytes(range(256))
    encoded = decode(test_data)[0]
    decoded = encode(encoded)[0]
    assert test_data == decoded



# Generated at 2022-06-21 12:22:54.590466
# Unit test for function encode
def test_encode():
    assert encode('') == (b"", 0)
    assert encode(0) == (b"", 0)
    assert encode(57) == (b"", 0)
    assert encode(0.0) == (b"", 0)
    assert encode([]) == (b"", 0)
    assert encode({}) == (b"", 0)
    assert encode(None) == (b"", 0)
    assert encode('0') == (b"", 0)
    assert encode(False) == (b"", 0)
    assert encode(True) == (b"", 0)
    assert encode('RmFzdGVyIFN0YXJ0') == (b'Faster Start', 16)
    assert encode('RmFzdGVy\nU3RhcnQ') == (b'Faster Start', 16)

# Generated at 2022-06-21 12:22:56.835037
# Unit test for function register
def test_register():
    """Ensure the ``b64`` codec has been registered with Python."""
    assert decode(b'a')[0] == 'YQ=='
    assert encode('YQ==')[0] == b'a'

# Generated at 2022-06-21 12:23:09.387543
# Unit test for function register
def test_register():
    """Test function register"""
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        pass
    else:
        print('Unable to remove NAME from codecs')
        print('Codecs:')
        for k in codecs.__dict__.keys():
            if k not in ('__name__', '__doc__', '__package__'):
                print('     ', k)
        print('Should be None:')
        print('     ', codecs.lookup_error(NAME))
        print('     ', codecs.getdecoder(NAME))
        print('     ', codecs.getencoder(NAME))
    register()
    assert codecs.lookup_error(NAME) is None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getenc

# Generated at 2022-06-21 12:23:18.468615
# Unit test for function decode
def test_decode():
    # pylint: disable=W0212
    # noinspection PyProtectedMember
    b64 = decode._as_codec(NAME)
    assert (
        b64._decode_codec(
            b'A\xc3\xa4\xc3\xb6\xc3\xbc\xc3\x84\xc3\x96\xc3\x9c' +
            b'a\xc3\xa4\xc3\xb6\xc3\xbc\xc3\x84\xc3\x96\xc3\x9c',
            'strict'
        ) ==
        ('QSbQi5Ca0LjQsNC60Lg=', 13)
    )


# Generated at 2022-06-21 12:23:22.311945
# Unit test for function register
def test_register():
    # Deliberately delete the global STATUS
    import sys

    try:
        del sys.modules[__name__].STATUS
    except KeyError:
        pass

    register()
    # Unregister the 'b64' codec.
    codecs.unregister(NAME)

    # Register the 'b64codec'
    register()


STATUS = 'unregistered'



# Generated at 2022-06-21 12:23:26.851058
# Unit test for function encode
def test_encode():
    assert encode('Tml0ZSBkdW9sbw==')[0] == b'Mite duolb'  # type: ignore



# Generated at 2022-06-21 12:23:36.872168
# Unit test for function encode
def test_encode():
    assert encode(
        """
            ZlYjyShoNkNMT2tRQW1ONjJ0dzVZT3NIMXpWc1JnU3JiMjhqMGpLWGZ
            pdHVWS2x2QXRnTHdYQ2c2aU5GdU5SNjU4ZDhldE5zZDd1dmF4U1lYdz09
        """
    ) == b'\xee\x07}\x97\x07\xb7\x15O\x1c\x10\x14j\x8a\x15\x0c\x18\x85`M\x11\x0c\x1a'


# Generated at 2022-06-21 12:23:48.071237
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8gYmFzZTY0') == ('aGVsbG8gYmFzZTY0', 16)
    assert decode(b'aGVsbG8gYmFzZTY0\n') == ('aGVsbG8gYmFzZTY0', 17)
    assert decode(b'aGVsbG8gYmFzZTY0\n\n') == ('aGVsbG8gYmFzZTY0', 19)
    assert decode(b'aGVsbG8gYmFzZTY0\n\n\n') == ('aGVsbG8gYmFzZTY0', 20)
    assert decode(b'aGVsbG8gYmFzZTY0\r')

# Generated at 2022-06-21 12:23:52.161680
# Unit test for function decode
def test_decode():
    assert decode(b'\x00\x1f') == ('w==', 2)
    assert decode(b'\x00') == ('AA==', 1)
    assert decode(b'\x1f') == ('_w==', 1)



# Generated at 2022-06-21 12:23:53.791611
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-21 12:23:57.904791
# Unit test for function decode
def test_decode():
    data = b'\x00'
    expected = 'AA==\n'
    actual = decode(data)[0]
    assert actual == expected


# Generated at 2022-06-21 12:24:06.802315
# Unit test for function encode
def test_encode():
    with pytest.raises(UnicodeEncodeError) as excinfo:
        encode('\udcff')
    assert 'is not a proper bas64 character string:' in str(excinfo.value)
    assert str(encode('VGVzdGluZw==')) == b'Testing'

# Generated at 2022-06-21 12:24:09.272022
# Unit test for function decode
def test_decode():
    actual = codecs.decode("VGVzdA==", "b64")
    assert actual == b'Test'


# Generated at 2022-06-21 12:24:10.779312
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)  # type: ignore


# Generated at 2022-06-21 12:24:13.780277
# Unit test for function encode
def test_encode():
    """Example of how to use the ``encode`` function."""
    input_string = '''
    aGVsbG8=
    '''
    expected_output = b'hello'
    actual_output = encode(input_string)[0]
    assert actual_output == expected_output



# Generated at 2022-06-21 12:24:16.979730
# Unit test for function register
def test_register():
    """Make sure the codec can be registered with Python."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:24:24.750521
# Unit test for function decode
def test_decode():
    # noinspection SpellCheckingInspection
    # run with this command: python -m b64.b64
    b64_input = (
        'VW5pdCB0ZXN0IGZvciBhdHRyaWJ1dGUgaW5jbHVkZV9jb2RlIGNvbW1hbmRzLgoK'
        'RXhwZWN0ZWQgc3RyaW5nOiAiVGhpcyBwZmMgZG9lcyBub3QgaW5jbHVkZSBhIGZp'
        'bGUiCg=='
    )

# Generated at 2022-06-21 12:24:37.787627
# Unit test for function decode

# Generated at 2022-06-21 12:24:40.385300
# Unit test for function encode
def test_encode():
    assert encode('MDEwMTAwMTAwMTAw') == (b'\x01\x01\x01\x01\x01', 15)

# Generated at 2022-06-21 12:24:46.053854
# Unit test for function decode
def test_decode():
    """Test decoding."""
    data = bytes([0x12, 0x34, 0x56])
    expected = '"EjWH"\n'
    actual = decode(data)
    assert actual[0] == expected
    assert actual[1] == len(data)


# Generated at 2022-06-21 12:24:47.825806
# Unit test for function encode
def test_encode():
    """Test Function `encode`."""
    # TODO
    pass



# Generated at 2022-06-21 12:24:52.465516
# Unit test for function encode
def test_encode():
    assert encode(b'Hello,World!') == (b'SGVsbG8sV29ybGQh',14)
    assert encode(b'Hello,World!') != (b'SGVsbG8sV29ybGQh',13)
    assert encode(b'Hello,World!') != (b'',14)



# Generated at 2022-06-21 12:25:01.313828
# Unit test for function encode
def test_encode():
    """A unit test for `encode`"""
    # Test encode with no arguments
    try:
        encode()
    except TypeError:
        pass
    else:
        raise AssertionError('Failed to catch encode with no arguments.')

    # Test encode with a single argument
    try:
        encode('')
    except TypeError:
        pass
    else:
        raise AssertionError(
            'Failed to catch encode with a single argument.'
        )

    # Test encode with a single argument that is not of type str
    try:
        encode(10)
    except TypeError:
        pass
    else:
        raise AssertionError('Failed to catch encode with a non-str.')

    # Test encode with a single str argument

# Generated at 2022-06-21 12:25:04.318286
# Unit test for function register
def test_register():
    """Test that the codec is correctly registered with Python.  If the
    codec is already registered, this test will fail.
    """
    register()



# Generated at 2022-06-21 12:25:09.249044
# Unit test for function encode
def test_encode():
    assert encode('kztwm gjb.t') == b'am9leXMueCB5c2hv'
    assert encode(b'am9leXMueCB5c2hv') == b'am9leXMueCB5c2hv'


# Generated at 2022-06-21 12:25:19.281745
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode``"""
    assert decode(b'\x00\x01', 'strict') == ('AQE=', 2)
    assert decode(b'\xFF\x01', 'strict') == ('/wE=', 2)
    assert decode(b'\xFF\xFF', 'strict') == ('//8=', 2)
    assert decode(b'\x00', 'strict') == ('AA==', 1)
    assert decode(b'\x01', 'strict') == ('AQ==', 1)
    assert decode(b'\xFF', 'strict') == ('/w==', 1)
    assert decode(b'', 'strict') == ('', 0)



# Generated at 2022-06-21 12:25:25.540637
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


del _get_codec_info

# If the above registration fails, then we can register like so:
# codecs.register_decode(
#     r'b64',
#     (lambda string, errors: decode(string, errors=errors))
# )

# codecs.register_encode(
#     r'b64',
#     (lambda string, errors: encode(string, errors=errors))
# )

# Generated at 2022-06-21 12:25:39.963618
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Test the :func:`pymod.b64.encode` function."""
    from pymod import b64
    from pymod.utils.bytes_functions import is_binary

    ensure(b64.encode('Hello')[0]).equals(b'SGVsbG8=')
    ensure(b64.encode(b'Hello')[0]).equals(b'SGVsbG8=')
    ensure(b64.encode(u'Hello')[0]).equals(b'SGVsbG8=')
    ensure(b64.encode('Hello\nWorld')[0]).equals(b'SGVsbG8gV29ybGQ=')

# Generated at 2022-06-21 12:25:51.585300
# Unit test for function encode

# Generated at 2022-06-21 12:26:03.047292
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function with valid input.

    Test Case 1
    ===========
    Given:
        text = '...'
        errors = 'strict'
    Expect:
        bytes of the text converted to bytes
    """
    text = '...'
    out, _ = encode(text)
    assert out == b'...'

    text = '...\n...'
    out, _ = encode(text)
    assert out == b'...\n...'

    text = '...\n...\n...'
    out, _ = encode(text)
    assert out == b'...\n...\n...'

    text = '...\n...\n...\n...'
    out, _ = encode(text)
    assert out == b'...\n...\n...\n...'



# Generated at 2022-06-21 12:26:05.225780
# Unit test for function register
def test_register():
    """Test the ``register()`` function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:26:12.030607
# Unit test for function encode
def test_encode():
    """Tests the encode function"""
    assert encode(
        'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoxMjM0'
    ) == (b'abcdefghijklmnopqrstuvwxyz12345', 54)

# Generated at 2022-06-21 12:26:22.761878
# Unit test for function decode
def test_decode():
    test_bytes = bytes(range(256))

    # noinspection PyTypeChecker
    result_str, _ = decode(test_bytes)


# Generated at 2022-06-21 12:26:30.720175
# Unit test for function encode
def test_encode():
    """Unit test 'encode'"""
    assert encode('a') == (b'\x03', 1)
    assert encode('') == (b'', 0)
    assert encode('a\n  \n\t\tb\n') == (b'\x03\x02\x02\x02\x01', 5)
    assert encode('a\nb\nc') == (b'\x03\x01\x02\x01\x03', 5)



# Generated at 2022-06-21 12:26:41.073776
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    from binascii import Error
    from pytest import raises

    s = '''\
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w==
3q2+7w==
3q2-7w=='''


# Generated at 2022-06-21 12:26:42.999587
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(b'\x00\x00\x00') == ('AAAA', 3)



# Generated at 2022-06-21 12:26:54.165747
# Unit test for function register
def test_register():
    b64 = __import__('b64')

    # Delete the 'b64' codec from the Python codecs.
    codecs.lookup_error = 'ignore'
    del codecs.decode['b64']
    del codecs.encode['b64']
    del codecs.incrementalencoder['b64']
    del codecs.incrementaldecoder['b64']

    # b64.register()
    assert not hasattr(b64, 'getcodec')

    b64.register()
    assert hasattr(b64, 'getcodec')

    # codecs.register(b64.getcodec)
    assert not hasattr(b64, 'decode')

    codecs.register(b64.getcodec)
    assert hasattr(b64, 'decode')



# Generated at 2022-06-21 12:26:58.756996
# Unit test for function register
def test_register():
    """Test the register() function."""
    register()
    assert codecs.getencoder(NAME)



# Generated at 2022-06-21 12:27:05.586349
# Unit test for function decode
def test_decode():
    """Test various cases for the function ``decode``.
    """
    from pytest import raises

    assert decode(b'\x00\x01\x00\x00') == ('AAEAAA==', 4)
    assert decode(b'\x00\x01\x00\x02') == ('AAEAAQ==', 4)
    assert decode(b'\x00\x01\x00\x03') == ('AAEAAg==', 4)
    assert decode(b'\x00\x01\x00\x04') == ('AAEAAw==', 4)
    assert decode(b'\x00\x01\x00\x05') == ('AAEABAA=', 4)

# Generated at 2022-06-21 12:27:09.837128
# Unit test for function register
def test_register():
    """The register function should not fail."""
    assert callable(register), 'register() is not callable.'
    register()
    assert callable(codecs.getdecoder(NAME)), 'getdecoder() is not callable.'
    assert callable(codecs.getencoder(NAME)), 'getencoder() is not callable.'

# Generated at 2022-06-21 12:27:17.207275
# Unit test for function decode
def test_decode():
    """Tests: function decode"""

# Generated at 2022-06-21 12:27:26.565613
# Unit test for function encode
def test_encode():
    """Test encode."""
    enc = encode('aGVsbG8gd29ybGQ=')
    assert enc == (b'hello world', 13)

    enc = encode('aGVsbG8gd29ybGQ=\n  ')
    assert enc == (b'hello world', 13)

    enc = encode('\n  aGVsbG8gd29ybGQ=\n  ')
    assert enc == (b'hello world', 13)

    try:
        encode('aGVsbG8gd29ybGQ')
        assert False
    except UnicodeEncodeError:
        assert True

    try:
        encode('abc')
        assert False
    except UnicodeEncodeError:
        assert True



# Generated at 2022-06-21 12:27:35.115903
# Unit test for function encode
def test_encode():
    """Test that the 'encode' function works."""
    # pylint: disable=C0103,C0111,W0108
    from test.unit.codecs.dummy import dummy_codec, dummy_decode
    import base64

    def _dummy_decode(data, errors) -> Tuple[str, int]:
        return dummy_decode(data, errors, base64.b64decode, "b64", "ASCII-8BIT")

    dummy_codec('b64', encode, _dummy_decode)


# Generated at 2022-06-21 12:27:45.594323
# Unit test for function decode
def test_decode():
    print('\n'.join([
        '*' * 78,
        'Testing function decode',
        '*' * 78,
    ]))


# Generated at 2022-06-21 12:27:48.599815
# Unit test for function register
def test_register():
    """Test ``register``."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise e



# Generated at 2022-06-21 12:28:01.103346
# Unit test for function register
def test_register():
    """Unit test for function register"""
    import sys

    # Save the current encoding registry.
    registry = sys.getdefaultencoding()

    # Unregister the 'b64' codec.
    try:
        codecs.unregister_error(NAME)
    except LookupError:
        pass

    # Unit test that the 'b64' codec is not registered.
    assert sys.getdefaultencoding() != NAME
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        # This function raised a 'LookupError', which is expected
        # and wanted.
        pass
    else:
        raise RuntimeError(f'Codec {NAME} is already registered.')

    # Register the 'b64' codec.
    register()

    # Unit test that the 'b64' codec was registered.
   

# Generated at 2022-06-21 12:28:02.320179
# Unit test for function encode
def test_encode():
    assert encode(
        """
        aGVsbG8gQm9i
        """
    ) == (b'hello Bob', 12)



# Generated at 2022-06-21 12:28:15.366638
# Unit test for function decode
def test_decode():
    """Unit test for the decode function."""
    import unittest
    from test.support import run_unittest
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            source = b'\xdf\xaf\x00\xff'
            expected = 'w8AAAB/'
            actual = decode(source)[0]
            self.assertEqual(expected, actual)

    run_unittest(Test)


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:28:25.705367
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Get the current mapping of codecs.
    old_map = {key: codecs.getdecoder(key) for key in codecs.__dict__['_cache']}

    # Add our codec mapping.
    register()

    # Get the new mapping of codecs.
    new_map = {key: codecs.getdecoder(key) for key in codecs.__dict__['_cache']}

    # Remove our codec mapping and restore the original mapping.
    codecs.__dict__['_cache'] = old_map

    assert new_map.__contains__(NAME)



# Generated at 2022-06-21 12:28:27.479381
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except Exception:
        register()

# Generated at 2022-06-21 12:28:32.921358
# Unit test for function encode
def test_encode():
    cases = (
        (
            # Input str
            'ZW5jb2RlZCBoZXJl',
            # Output Tuple
            (b'encoded here', 15),
        ),
    )
    for input_str, expected_output in cases:
        actual_output = encode(input_str)
        assert actual_output == expected_output



# Generated at 2022-06-21 12:28:39.266966
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    try:
        _old_decoder = codecs.getdecoder(NAME)
        codecs.register(_get_codec_info)
        _new_decoder = codecs.getdecoder(NAME)
        assert _old_decoder != _new_decoder
    finally:
        codecs.register(_old_decoder)



# Generated at 2022-06-21 12:28:43.242138
# Unit test for function encode
def test_encode():
    """ unit test for function encode """
    # Convert a string of base64 characters into a string of bytes.
    b1 = r'b3UgY29tZS4uLi4='
    b2 = bytes('ou come...', 'utf-8')
    assert encode(b1) == (b2, len(b1))


# Generated at 2022-06-21 12:28:54.982507
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('  ') == (b'', 0)

    assert encode('''

    ''') == (b'', 0)

    assert encode('Lorem ipsum dolor sit amet') == (
        b'TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQ=',
        len('Lorem ipsum dolor sit amet')
    )


# Generated at 2022-06-21 12:29:03.878282
# Unit test for function encode
def test_encode():
    assert encode('M = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = DM = a = D\n') == ('M = a = D', 1)


# Generated at 2022-06-21 12:29:06.742864
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG8gV29ybGQ=')[0] == 'Hello World'


# Generated at 2022-06-21 12:29:08.256557
# Unit test for function decode
def test_decode():
    assert decode(b'abcdefg') == ('YWJjZGVmZw==', 7)



# Generated at 2022-06-21 12:29:21.820516
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    try:
        codecs.getdecoder('utf8')
    except LookupError:
        raise AssertionError('utf8 not found')
    try:
        codecs.getencoder('utf8')
    except LookupError:
        raise AssertionError('utf8 not found')


if __name__ == '__main__':
    # Register the codec for import.
    register()
    test_register()

# Generated at 2022-06-21 12:29:23.767438
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:29:29.008498
# Unit test for function decode
def test_decode():
    # Given
    s = 'masterkey'

    # When
    s_bytes = s.encode()
    decoded_bytes, consume_count = codecs.decode(s_bytes, NAME)

    # Then
    assert type(decoded_bytes) is bytes
    assert consume_count == len(s_bytes)
    assert decoded_bytes == b'bWFzdGVya2V5'



# Generated at 2022-06-21 12:29:30.597450
# Unit test for function register
def test_register():
    """Test that the b64 codec is registered"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:29:38.612661
# Unit test for function decode
def test_decode():
    data = b'abcd'
    out = decode(data)[0]
    assert out == 'YWJjZA=='
    assert b'abcd' == base64.b64decode(out.encode('utf-8'))

    data = b'hello world'
    out = decode(data)[0]
    assert out == 'aGVsbG8gd29ybGQ='
    assert b'hello world' == base64.b64decode(out.encode('utf-8'))



# Generated at 2022-06-21 12:29:47.216027
# Unit test for function register
def test_register():
    """
    Test for the function :func:`register`.
    """
    import sys
    _path = sys.path.pop(0)

# Generated at 2022-06-21 12:29:55.204119
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('AAAA') == (b'A', 1)
    assert encode('AA==') == (b'A', 1)
    assert encode('AA') == (b'A', 1)
    assert encode('AA?=') == (b'A', 1)
    assert encode('AA?=A') == (b'A', 1)
    assert encode('AA?=A?=A') == (b'A', 1)
    assert encode('A?=A?=A') == (b'A', 1)



# Generated at 2022-06-21 12:29:56.686473
# Unit test for function register
def test_register():
    """Test the :func:`~register` function."""
    assert register() is None



# Generated at 2022-06-21 12:30:04.494804
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode
    """
    data = b"hello"
    result = decode(data)
    assert result == ("aGVsbG8=", 5)
    data = b"NGQ2ZmE3ZjZmMjk0N2Y2YmY3YzYyZjVmMzRmMzVjZjYyZjVmMzRmNjdmMzY="
    result = decode(data)
    assert result == ("4d6faf7f6f294f6f6bf7c62f5f34f35cf62f5f34f67f36f", 64)
    data = b"name"
    result = decode(data)
    assert result == ("bmFtZQ==", 4)

# Generated at 2022-06-21 12:30:14.200502
# Unit test for function encode
def test_encode():
    print(encode('YWJj'))
    print(encode('YWJjZGU='))
    print(encode('YWJjZGVm'))
    print(encode('YWJjZGVmZw=='))
    print(encode('YWJjZGVmZ2g='))
    print(encode(
        """
        YWJjZGVmZ2hp
        """
    ))
    print(encode(
        """
        YW
        JjZGVmZ2hp
        """
    ))
    print(encode(''))
    print(encode('YQ=='))
    print(encode('YWJ'))
    print(encode('YWJj'))
    print(encode('YWJjZ'))

# Generated at 2022-06-21 12:30:24.852179
# Unit test for function decode
def test_decode():
    tests = [
        (b'\x00\x00\x00', 'AAAA'),
        (b'\x01\x01\x01', 'AQAB'),
        (b'\x16\x14\x12', 'GBoQ'),
    ]
    for test in tests:
        result = codecs.decode(test[0], NAME)
        assert result == (test[1], 3)


# Generated at 2022-06-21 12:30:27.667161
# Unit test for function decode
def test_decode():
    """ Unit test for function decode """
    assert decode(b'qwertyuiop', 'strict') == ('cXdlcnR5dWlvcA==', 10)


# Generated at 2022-06-21 12:30:39.215314
# Unit test for function decode
def test_decode():
    """Test the b64 decode function."""
    # noinspection PyUnusedLocal
    def _test(func):
        """Test the given 'func' function."""

# Generated at 2022-06-21 12:30:49.315655
# Unit test for function encode
def test_encode():
    #Test 1
    a = b'I\'m a coder'
    b = encode(a)
    assert (b == (b'SSdtIGEgY29kZXI=\n', 15))

    #Test 2
    a = 'I\'m a coder'
    b = encode(a)
    assert (b == (b'SSdtIGEgY29kZXI=\n', 15))

    #Test 3
    a = b'coder\n'
    b = encode(a)
    assert (b == (b'Y29kZXI=\n', 8))

    #Test 4
    a = 'coder\n'
    b = encode(a)
    assert (b == (b'Y29kZXI=\n', 8))

    #Test 5

# Generated at 2022-06-21 12:30:57.167963
# Unit test for function encode
def test_encode():
    """
    Ensure the encode function works correctly.
    """
    with pytest.raises(UnicodeEncodeError):
        encode('This is not base64 text. ')
    assert encode('VGhpcyBpcyBib3RoIHN0cmluZyBhbmQgYjY0IGRhdGE.')[0] == b'This is both string and b64 data.'
    assert encode('VGhpcyBpcyBib3RoIHN0cmluZyBhbmQgYjY0IGRhdGEu\n')[0] == b'This is both string and b64 data.'

# Generated at 2022-06-21 12:31:03.372772
# Unit test for function register
def test_register():
    """Test function register()"""
    # pylint: disable=missing-docstring
    # Do the import so the codec is registered.
    import _base64_codec                                    # pylint: disable=W0612
    # See if the codec is registered.
    codecs.getdecoder(NAME)                                 # pylint: disable=W0612


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:31:10.799384
# Unit test for function decode
def test_decode():
    assert decode(b'YQ==')[0] == 'a'
    assert decode(b'cw==')[0] == 'b'

    assert decode(bytes([1, 2, 3, 4])) == ('AQIDBA==', 4)
    assert decode(bytes([0, 1, 2, 3, 4])) == ('AAECAwQ=', 5)

    try:
        res = decode(b'Yz==')
    except UnicodeEncodeError as e:
        assert e.start == 0
        assert e.end == 1
        assert e.reason == 'b64'
        assert e.object == 'Yz=='



# Generated at 2022-06-21 12:31:19.110770
# Unit test for function register
def test_register():
    from os import remove
    from sys import modules
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import patch

    tdir: str = ''
    filename: str = ''

    class CustomTestCase(TestCase):

        def test_register(self):
            """Test function register"""
            register()
            import b64
            self.assertEqual(b64.NAME, __name__.split('.')[-1])
            self.assertIsNotNone(b64.codecs.getdecoder('b64'))
            self.assertIsNotNone(b64.codecs.getencoder('b64'))

        def test_encode(self):
            """Test function encode"""

# Generated at 2022-06-21 12:31:22.136195
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode()``. """
    assert encode('dGVzdA==', ) == (b'test', 6)


# Generated at 2022-06-21 12:31:28.458492
# Unit test for function register
def test_register():
    """Test the register() function."""
    import codecs
    from .test_decode import test_b64_decode
    from .test_encode import test_b64_encode

    register()
    # noinspection PyUnresolvedReferences
    assert codecs.getdecoder(NAME) is not None
    # noinspection PyUnresolvedReferences
    assert codecs.getencoder('b64') is not None
    test_b64_decode()
    test_b64_encode()

# Generated at 2022-06-21 12:31:43.656067
# Unit test for function decode
def test_decode():
    a = "hello world"
    data = a.encode()
    a_b64 = decode(data)
    a_decoded = a_b64[0]
    assert a_decoded == a



# Generated at 2022-06-21 12:31:45.832977
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None

register()

# Generated at 2022-06-21 12:31:52.882174
# Unit test for function encode
def test_encode():
    assert encode('SGF2aWQgQ2lkdg==') == (b'Havid Cidv', 14)
    assert encode('\n\tSGF2aWQgQ2lkdg==\t\n') == (b'Havid Cidv', 14)
    assert encode('IHdvcmtpbmc=') == (b' working', 9)



# Generated at 2022-06-21 12:31:54.076246
# Unit test for function register
def test_register():
    from _test.test_b64 import _test_register

    _test_register(register)

# Generated at 2022-06-21 12:31:59.754692
# Unit test for function decode
def test_decode():
    assert decode(bytes(0)) == ('', 0)
    assert decode('=') == ('PQ==', 2)
    assert decode('Aa') == ('QWE=', 2)
    assert decode('test') == ('dGVzdA==', 4)
    assert decode('TEST') == ('VEVTVA==', 4)



# Generated at 2022-06-21 12:32:07.500437
# Unit test for function encode
def test_encode():
    # test_case_1
    assert encode('') == (b'', 0)

    # test_case_2
    assert encode('a') == (b'YQ==', 1)

    # test_case_3
    assert encode('ab') == (b'YWI=', 2)

    # test_case_4
    assert encode('abc') == (b'YWJj', 3)

    # test_case_5
    assert encode('abcd') == (b'YWJjZA==', 4)

    # test_case_6
    assert encode('abcde') == (b'YWJjZGU=', 5)

    # test_case_7
    assert encode('abcdef') == (b'YWJjZGVm', 6)

    # test_case_8

# Generated at 2022-06-21 12:32:18.021241
# Unit test for function encode

# Generated at 2022-06-21 12:32:26.784572
# Unit test for function decode

# Generated at 2022-06-21 12:32:30.547618
# Unit test for function decode
def test_decode():
    """Unit test for function: decode"""
    assert decode(b'\x00\x01\x02\x03\x04\x05\x06\x07') == ('AAECAwQFBgc=', 8)

