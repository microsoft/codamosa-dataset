

# Generated at 2022-06-21 12:22:38.175944
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    """Test the ``codecs`` module's ``register`` function."""
    # Test with an unregistered name.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore

    # Codec should now be registered with the 'codecs' module.
    assert NAME in codecs.getdecoders().keys()
    assert NAME in codecs.getencoders().keys()

    # Test with a registered name.
    # This should not raise an Exception as the name is already registered.
    codecs.register(_get_codec_info)

# Generated at 2022-06-21 12:22:40.185663
# Unit test for function register
def test_register():  # pylint: disable=unused-argument
    """
    >>> assert test_register() == None
    """
    register()


# Generated at 2022-06-21 12:22:44.521427
# Unit test for function decode
def test_decode():
    """Unit test for function :func:`coding.base64.decode`"""
    assert decode(b'\x00\x00\x00') == ('AAAAAA==', 3)
    assert decode(b'\x00\x00\x00\x00') == ('AAAAAAAAAAA=', 4)



# Generated at 2022-06-21 12:22:54.820974
# Unit test for function decode
def test_decode():
    """Unit test for the ``b64.decode`` function."""
    str_input = 'anNvbmFtZSBsaXN0Cg=='
    exp_str_output = 'a noname list'
    exp_len = 14
    exp_bytes = b'a noname list'

    # Call the decode method
    (act_str_output, act_len) = b64.decode(str_input)

    # Verify the output is what is expected.
    assert act_str_output == exp_str_output
    assert act_len == exp_len

    # Call the encode method
    act_bytes = b64.encode(str_input)

    # Verify the output is what is expected.
    assert act_bytes == exp_bytes


# Unit Test for function encode

# Generated at 2022-06-21 12:22:57.309808
# Unit test for function register
def test_register():
    """Unit test function test_register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:22:58.664705
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:23:10.758566
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG8sIHdvcmxkLg==') == ('Hello, world.', 15)
    assert decode(b'SGVsbG8sIHdvcmxkLg==', 'ignore') == ('Hello, world.', 15)
    assert decode(b'SGVsbG8sIHdvcmxkLg==', 'strict') == ('Hello, world.', 15)
    assert decode(b'SGVsbG8sIHdvcmxkLg==', 'replace') == ('Hello, world.', 15)
    assert decode(b'SGVsbG8sIHdvcmxkLg==', 'backslashreplace') == \
        ('Hello, world.', 15)

# Generated at 2022-06-21 12:23:21.986903
# Unit test for function encode

# Generated at 2022-06-21 12:23:31.734268
# Unit test for function register
def test_register():
    """Test the function ``register()``()."""
    # Unregister the 'b64' codec to ensure it is not registered.
    try:
        codecs.lookup(NAME)
        codecs.unregister(NAME)
    except LookupError:
        pass

    # Make sure the 'b64' codec is not registered.
    try:
        codecs.lookup(NAME)
    except LookupError as e:
        assert (
            e.args[0] == f'unknown encoding: {NAME!r}'
        )
    else:
        assert False, f'{NAME!r} codec should not be registered.'

    # Register the 'b64' codec.
    register()

    # Make sure the 'b64' codec is registered.

# Generated at 2022-06-21 12:23:37.885153
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()

    # Get the codec info for 'b64'.
    codec_info = codecs.getdecoder(NAME)

    # Validate that the codec info name is the same as 'b64'.
    assert codec_info.name == NAME

    # Validate that the `decode` method is the same as `decode`.
    assert decode is codec_info.decode

    # Validate that the `encode` method is the same as `encode`.
    assert encode is codec_info.encode



# Generated at 2022-06-21 12:23:42.693530
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('YWJjZA==') == (b'abcd', 6)



# Generated at 2022-06-21 12:23:54.862050
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # Verify the codec is now registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)


# Unit tests for the functions decode and encode.

# Generated at 2022-06-21 12:23:59.585671
# Unit test for function register
def test_register():
    """Test the ``register`` function.
    This is not a normal unit test.  This function is called when
    this module is run as a script.
    """
    print('Registering b64 codec')
    register()



# Generated at 2022-06-21 12:24:01.618617
# Unit test for function decode
def test_decode():
    """Test decoding base64 data."""
    assert decode(b'\xFF', 'strict')[0] == '__8'


# Generated at 2022-06-21 12:24:04.315035
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    data = b'\x01\x02\x03\xF9\xFA\xFB\xFD\xFE\xFF'
    # Expected output from https://www.base64decode.org/
    expected = b'AwMEBw4PHw=='
    actual = encode(codecs.encode(data, 'b64'))[0]
    assert expected == actual



# Generated at 2022-06-21 12:24:15.245603
# Unit test for function encode
def test_encode():
    assert encode('QQ==')[0] == b'A'
    assert encode('QQ==').__len__() == 1
    assert encode('SXI=')[0] == b'12'
    assert encode('SXI=').__len__() == 2
    assert encode('THJjKkM=')[0] == b'abc*'
    assert encode('THJjKkM=').__len__() == 4
    assert encode('QUJDRU1TQT0=')[0] == b'ABCEMSA'
    assert encode('QUJDRU1TQT0=').__len__() == 7
    assert encode('QQ==\n')[0] == b'A'
    assert encode('QQ==\n').__len__() == 2

# Generated at 2022-06-21 12:24:16.227799
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:24:20.606367
# Unit test for function register
def test_register():
    """Test Function"""
    # Registering works on subsequent calls.
    register()
    codecs.register(_get_codec_info)  # type: ignore

    # Registering fails on duplicate calls.
    # noinspection PyTypeChecker
    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-21 12:24:26.952372
# Unit test for function register
def test_register():
    import unittest
    from b64codec.b64 import b64_decode, b64_encode
    from b64codec.b64_codec import register

    class Test_b64_codec(unittest.TestCase):
        def test_register(self):
            with self.assertWarns(DeprecationWarning):
                register()

    unittest.main()


# Generated at 2022-06-21 12:24:33.440451
# Unit test for function register
def test_register():
    # codecs.lookup('b64')
    try:
        import codecs
        tmp = codecs.lookup(NAME)  # type: ignore
    except LookupError:
        pass
    else:
        print(f'problem: {NAME} codecs.lookup%r' % tmp)
        raise
    register()
    codecs.lookup(NAME)


# Unit tests for function encode

# Generated at 2022-06-21 12:24:35.999897
# Unit test for function decode
def test_decode():
    assert decode(b'AAAA') == ('QUFB', 4)



# Generated at 2022-06-21 12:24:46.966611
# Unit test for function register
def test_register():

    class _Mock_codecs:

        def __init__(self):
            self.register = MagicMock()

    class _Mock_lookup_error(LookupError):
        pass

    codecs_ = _Mock_codecs()
    with patch('codecs.register', codecs_.register):
        with patch('codecs.getdecoder', side_effect=_Mock_lookup_error):
            register()

        assert codecs_.register.called

    codecs_ = _Mock_codecs()
    with patch('codecs.register', codecs_.register):
        with patch('codecs.getdecoder', return_value=None):
            register()

        assert not codecs_.register.called

# Generated at 2022-06-21 12:24:53.514556
# Unit test for function decode
def test_decode():

    # Unit test for normal case
    input = b'abcd'
    expected_result = u'YWJjZA=='
    result = decode(input)[0]
    assert result == expected_result

    # Unit test for byte containing special characters
    input = b'ab\u00cd'
    expected_result = u'YWJjY8K='
    result = decode(input)[0]
    assert result == expected_result

    # Unit test for byte containing special characters
    input = b'\uabcd'
    expected_result = u'4p2k'
    result = decode(input)[0]
    assert result == expected_result

    # Unit test for empty string
    input = b''
    expected_result = u''
    result = decode(input)[0]
    assert result == expected_result

   

# Generated at 2022-06-21 12:24:58.286863
# Unit test for function decode
def test_decode():
    assert decode(b'Man') == ('TWFu', 3)
    assert decode(b'TWFu') == ('Man', 3)
    assert decode(b'TWFua') == ('Mana', 4)
    assert decode(b'TWFuZ') == ('Manb', 4)
    assert decode(b'TWFuZWxs') == ('Manell', 6)



# Generated at 2022-06-21 12:25:00.534160
# Unit test for function encode
def test_encode():
    actual = encode('aGVsbG8=')
    assert actual == b'hello'



# Generated at 2022-06-21 12:25:03.495475
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


# Unit tests for functions encode and decode

# Generated at 2022-06-21 12:25:15.382343
# Unit test for function encode
def test_encode():
    """Unit test for encode"""
    assert encode('bWF0aG92cyBpcyBzbyBzYWZl')[0] == b'mathovs is so safe'
    assert encode('bWF0aG92cyBpcyBzbyBzYWZl')[1] == 21
    assert encode('bWF0aG92cyBpcyBzbyBzYWZl', 'strict')[0] == b'mathovs is so safe'
    assert encode('bWF0aG92cyBpcyBzbyBzYWZl', 'strict')[1] == 21
    assert encode('bWF0aG92cyBpcyBzbyBzYWZl', 'ignore')[0] == b'mathovs is so safe'

# Generated at 2022-06-21 12:25:24.561241
# Unit test for function decode
def test_decode():
    """Unit test for function :func:`decode`"""
    # pylint: disable=line-too-long

# Generated at 2022-06-21 12:25:25.644427
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


# Generated at 2022-06-21 12:25:31.631216
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    import base64
    from io import BytesIO
    from prance import ResolvingParser

    test_data_file_name = (
        'tests/swagger/v2.0/json/openapi-specification/examples'
        '/v2.0/json/petstore.json'
    )

    test_data_file_name_bytes = test_data_file_name.encode()

    test_data_bytes = BytesIO(base64.b64encode(test_data_file_name_bytes))
    test_data = test_data_file_name.encode()

    parser = ResolvingParser(test_data_file_name)
    parser_bytes = ResolvingParser(test_data_bytes)

    assert parser.specification == parser_bytes.specification

# Generated at 2022-06-21 12:25:42.583237
# Unit test for function encode
def test_encode():
    in0 = b'hello-world'
    exp0 = b'aGVsbG8td29ybGQ='
    in1 = b'hello-world-123'
    exp1 = b'aGVsbG8td29ybGQtMTIz'
    in2 = b'hello-world-123-456'
    exp2 = b'aGVsbG8td29ybGQtMTIzLTQ1Ng=='

    assert(encode(in0)[0] == exp0)
    assert(encode(in1)[0] == exp1)
    assert(encode(in2)[0] == exp2)


# Generated at 2022-06-21 12:25:49.619476
# Unit test for function decode
def test_decode():
    """Test the functionality of ``decode()`` function."""
    # Register the 'b64' codec with Python.
    register()
    # Test cases
    test_case_1 = (
        'TWFuCg==',
        3,
        'Man',
    )
    test_case_2 = (
        'VGhpcyBpcyBhbiBlbmNvZGVkIHN0cmluZw==',
        3,
        'This is an encoded string',
    )
    test_case_3 = (
        'RVQgb2YgdGhpcyBXZWIh',
        4,
        'ET of this Web!',
    )

# Generated at 2022-06-21 12:25:52.796510
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencoders()
    assert NAME in codecs.getdecoders()
    assert NAME in codecs.iter_encodings()
    assert NAME in codecs.iter_decodings()

# Unit tests for function encode

# Generated at 2022-06-21 12:26:04.570919
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode(' \t\n') == (b'', 0)
    assert encode('x') == (b'eA==', 1)
    assert encode('xx') == (b'eHg=', 2)
    assert encode('xxx') == (b'eHh4', 3)
    assert encode('xxxx') == (b'eHh4eA==', 4)
    assert encode('xxxxx') == (b'eHh4eHg=', 5)
    assert encode('xxxxxx') == (b'eHh4eHh4', 6)
    assert encode('xxxxxxx') == (b'eHh4eHh4eA==', 7)

# Generated at 2022-06-21 12:26:05.866557
# Unit test for function encode
def test_encode():
    assert encode('Zm9v') == (b'foo', 4)


# Generated at 2022-06-21 12:26:10.807893
# Unit test for function decode
def test_decode():
    import unittest

    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:26:21.614201
# Unit test for function encode
def test_encode():
    assert encode('YmFzZTY0IGVuY29kZWQgc3RyaW5n') == (b'base64 encoded string', 25)
    assert encode(
        'YmFzZTY0IGVuY29kZWQgc3RyaW5n\n\n'
    ) == (b'base64 encoded string', 25)
    assert encode(
        'YmFzZTY0IGVuY29kZWQgc3RyaW5n\r\n\r\n'
    ) == (b'base64 encoded string', 25)

# Generated at 2022-06-21 12:26:29.916680
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        test_str = 'dGVzdA=='

        result = test_str.encode('b64').decode('b64')
        assert result == 'test'

        result = 'test'.encode('b64').decode('b64')
        assert result == b'test'
    finally:
        codecs.register(None)
        codecs.register(lambda name: None)   # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:26:36.362225
# Unit test for function decode
def test_decode():
    """Demonstrate and test the b64.decode function."""
    # Setup
    data = b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a'
    exp = ('AQIDBAUGBwgJAA==', len(data))
    # Exercise and Test
    act = decode(data)
    # Verify
    assert act == exp



# Generated at 2022-06-21 12:26:45.541036
# Unit test for function decode
def test_decode():
    assert decode(b'YWJjZGVmZ2g=\n') == ('abcdefg', 14), "correctly transforms"
    assert decode(b'YWJjZGVmZ2g=') == ('abcdefg', 14), "correctly transforms"
    assert decode(b'YWJjZGVmZ2g=') == ('abcdefg', 14), "correctly transforms"
    assert decode(b'YWJjZGVmZ2g=') == ('abcdefg', 14), "correctly transforms"
    assert decode(b'YWJjZGVmZ2g=') == ('abcdefg', 14), "correctly transforms"
    assert decode(b'YWJjZGVmZ2g=') == ('abcdefg', 14), "correctly transforms"

# Generated at 2022-06-21 12:27:00.040249
# Unit test for function register
def test_register():
    """Unit test for the register()"""
    import sys
    import tempfile
    import textwrap

    # Create a temporary file to store the codecs module's codecs registry.
    with tempfile.NamedTemporaryFile('w+', encoding='utf-8') as tmpfile:
        # Create a copy of the codecs registry.
        tmpfile.write(str(sys.modules['codecs']))

        # Rewind the tmpfile and check that it was written correctly.
        tmpfile.seek(0)
        assert tmpfile.read() == str(sys.modules['codecs'])

        # Register the b64 module, so that 'b64' is recognized as a codec.
        module = sys.modules['codecs']
        import b64
        b64.register()
        tmpfile.seek(0)
        assert tmp

# Generated at 2022-06-21 12:27:03.341003
# Unit test for function register
def test_register():
    # pylint: disable=W0212
    assert BASE64.register.__module__ == f'{__name__}.{NAME}'


if __name__ == '__main__':
    # pylint: disable=W0611
    from pytest import main as test_main
    test_main([__file__, '-v'])

# Generated at 2022-06-21 12:27:06.897303
# Unit test for function decode
def test_decode():
    assert decode(
        bytes.fromhex('d0 a5 d0 b8 d0 ba d0 bd d0 b5 d0 bb')
    )[0] == '0J/Qiw=='


# Generated at 2022-06-21 12:27:08.902983
# Unit test for function encode
def test_encode():
    assert (
        encode("aGkgdGhlcmU=") ==
        (b'hi there', 12)
    )



# Generated at 2022-06-21 12:27:11.558718
# Unit test for function register
def test_register():
    """Unit test function

    :return: None
    """
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None

# Generated at 2022-06-21 12:27:23.305272
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """Test the function :func:`register`."""

        def setUp(self) -> None:
            """Remove the ``b64`` codec from the codec map."""
            import codecs
            codecs.codec_map.pop(NAME, None)

        def test_register(self) -> None:
            """Test registering the ``b64`` codec."""
            import codecs
            register()

            try:
                codecs.getdecoder(NAME)
            except LookupError:
                self.fail()

            del sys.modules['b64']
            register()

            try:
                codecs.getdecoder(NAME)
            except LookupError:
                self

# Generated at 2022-06-21 12:27:27.607222
# Unit test for function register
def test_register():
    import sys
    # Remove the codec, if present, from the namespace.
    sys.modules.pop(NAME, None)
    try:
        import importlib
        importlib.reload(__import__(NAME))
        # pylint: disable=W0704
    except Exception as e:
        raise RuntimeError(
            f'Error reloading {NAME}. Make sure it is importable: {e}'
        ) from e



# Generated at 2022-06-21 12:27:29.689586
# Unit test for function register
def test_register():
    global NAME
    backup = NAME
    NAME = 'b64'
    register()
    NAME = backup

# Generated at 2022-06-21 12:27:35.991106
# Unit test for function encode
def test_encode():
    assert encode('test') == (b'test', 4)
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 12)
    assert encode('aAo=') == (b'\n', 1)
    assert encode('aGVs\nbG8gd29y\nbGQ=') == (b'hello world', 12)


# Generated at 2022-06-21 12:27:45.036846
# Unit test for function register
def test_register():
    """Make sure the the b64.codec.b64 codec is registered."""
    from codecs import CodecInfo
    try:
        codec_info = codecs.getdecoder(NAME)  # type: ignore[attr-defined]
    except LookupError as e:
        raise AssertionError(
            'The b64 codec is not registered: '
            f'{e!r}'
        )

    assert isinstance(codec_info, CodecInfo)
    assert codec_info.name == NAME   # type: ignore[attr-defined]
    assert codec_info.encode is encode   # type: ignore[attr-defined]
    assert codec_info.decode is decode   # type: ignore[attr-defined]

# Generated at 2022-06-21 12:27:54.974308
# Unit test for function decode
def test_decode():
    simple_str = 'Draco Dormiens Nunquam Titillandus'
    simple_bytes = b'RHJyYWNvIERvcm1pZW5zIE51bnF1YW0gVGl0aWxsYW5kdXM='
    simple_bytes_extra = (
        b'\n\n'
        b'   RHJyYWNvIERvcm1pZW5zIE51bnF1YW0gVGl0aWxsYW5kdXM=  \n'
    )

    assert decode(simple_bytes)[0] == simple_str, 'Failed simple decode'
    assert (
        decode(simple_bytes_extra)[0]
        ==
        simple_str
    ), 'Failed simple decode with extra whitespace'


# Generated at 2022-06-21 12:28:06.532778
# Unit test for function register
def test_register():
    from unittest import mock

    mock_codecs = mock.Mock()

    # No codec named 'b64' is already registered.
    # Mock getdecoder to raise a LookupError.
    mock_obj = mock.Mock()
    mock_obj.getdecoder.side_effect = LookupError('oops')
    mock_codecs.__getitem__.return_value = mock_obj

    # Mock the register function.
    mock_register = mock_obj.register = mock.Mock()

    with mock.patch.dict(
            'sys.modules',
            {'codecs': mock_codecs}
    ):
        register()

    # The codecs register should be called.
    mock_register.assert_called_once()



# Generated at 2022-06-21 12:28:17.673439
# Unit test for function decode
def test_decode():
    assert decode(b'Hello World!') == ('SGVsbG8gV29ybGQh', 12)
    assert decode(b'1234567890') == ('MTIzNDU2Nzg5MA==', 10)
    assert decode(b'abcdefghijklmnopqrstuvwxyz') == ('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=', 26)

_TEST_STR = (
    'VGVzdC1zdHJpbmctdGhhdC1zaG91bGQtYmUtZW5jb2RlZC1hcy1iYXNlNjQtY29kZWQtYnl0ZXM='
)



# Generated at 2022-06-21 12:28:28.858805
# Unit test for function encode
def test_encode():
    """Unit test for encode"""

# Generated at 2022-06-21 12:28:40.417328
# Unit test for function decode
def test_decode():
    """Unit tests for the function `b64codec.decode()`."""
    # Set up objects to be tested.

# Generated at 2022-06-21 12:28:45.287820
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)


# Generated at 2022-06-21 12:28:54.633368
# Unit test for function decode
def test_decode():
    # Given a bytes object of the file to be converted
    data_bytes = bytes(b'\x01\n\x02\x03')
    # When the data_bytes is decoded
    decoded_str, bytes_consumed = decode(data_bytes)
    # Then the decoded should be correct
    assert decoded_str == 'AQ4BAg==', "AQ4BAg== expected, got {}".format(decoded_str)
    # And the consumed bytes should be correct
    assert bytes_consumed == 4, "4 bytes consumed, got {}".format(bytes_consumed)



# Generated at 2022-06-21 12:28:56.547092
# Unit test for function decode
def test_decode():
    assert decode(b'\x66\x6f\x6f')[0] == 'Zm9v'

# Generated at 2022-06-21 12:28:58.709785
# Unit test for function decode
def test_decode():
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)


# Generated at 2022-06-21 12:29:02.280488
# Unit test for function register
def test_register():
    """Test for function ``register``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        return
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:29:19.388570
# Unit test for function decode
def test_decode():
    given_str = 'YWJj'
    given_bytes = b'abc'
    expected_bytes = given_bytes
    expected_size = len(given_bytes)
    result_bytes, size = decode(given_str)
    assert result_bytes == expected_bytes
    assert size == expected_size



# Generated at 2022-06-21 12:29:29.096594
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Test the encode function."""
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 1)
    assert encode('\n') == (b'', 1)
    assert encode('\t') == (b'', 1)
    assert encode(' \t\n') == (b'', 3)
    # Test with a simple string.
    assert encode('duck') == (b'ZHVjaw==', 4)
    # Test with a multiline string.

# Generated at 2022-06-21 12:29:39.136545
# Unit test for function register
def test_register():
    """
    Test the register() function
    """
    from testfixtures import compare, ShouldRaise, Replacer, Replace

    def get_codec(name: str) -> Optional[codecs.CodecInfo]:
        if name == 'test':
            return codecs.CodecInfo(decode=lambda a, b: (a, b), encode=lambda a, b: (a, b))
        return None

    with Replacer() as replace:
        replace('testfixtures.b64.codecs.getdecoder', get_codec)
        with ShouldRaise(LookupError()):
            codecs.getdecoder('test')

        register()
        compare(codecs.getdecoder('test'), get_codec('test'))



# Generated at 2022-06-21 12:29:39.726780
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    return


# Generated at 2022-06-21 12:29:43.248093
# Unit test for function encode
def test_encode():
    """Test function encode"""
    # Test with a good value.
    test_str = 'aGVsbG8gd29ybGQ='
    result = encode(test_str)
    assert result[0] == b'hello world'
    assert result[1] == len(test_str)

# Generated at 2022-06-21 12:29:50.832581
# Unit test for function decode

# Generated at 2022-06-21 12:29:52.679169
# Unit test for function decode
def test_decode():
    assert decode(b'Hell') == ('SGVsbG8=\n', 4)


# Generated at 2022-06-21 12:29:55.560340
# Unit test for function register
def test_register():
    """Test that b64.register registers the b64 codec."""
    register()
    assert NAME == codecs.lookup(NAME).name  # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:29:56.724940
# Unit test for function register
def test_register():
    """Test that ``b64`` is registered with Python."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:30:03.748799
# Unit test for function encode
def test_encode():
    """Test the ``b64.encode`` function."""
    assert encode('\x00') == b'AA=='
    assert encode('\xff') == b'//8='
    assert encode('\x00\x00') == b'AAA='
    assert encode('\xff\xff') == b'////'
    assert encode('\x00\x00\x00') == b'AAAA'
    assert encode(
        'I can eat glass and it does not hurt me.'
    ) == b'SSBjYW4gZWF0IGdsYXNzIGFuZCBpdCBkb2VzIG5vdCBI'\
        b'cnV0IG1lLgo='


# Generated at 2022-06-21 12:30:25.247630
# Unit test for function decode
def test_decode():
    # Set global variable for testing
    global TAB_SIZE
    TAB_SIZE = 4

    # Empty string
    result, n = decode(b'', 'strict')
    assert n == 0
    assert result == ''

    # Simple string
    result, n = decode(b'QQ==', 'strict')
    assert n == 4
    assert result == 'A'

    # Long string
    result, n = decode(b'MQ==', 'strict')
    assert n == 4
    assert result == '1'

    # Indentation
    result, n = decode(b' \t\nMQ==', 'strict')
    assert n == 7
    assert result == '1'

    # Bad input

# Generated at 2022-06-21 12:30:31.734115
# Unit test for function register
def test_register():
    """Unit test for function register"""
    import sys
    import traceback

    # Import the codecs module.
    try:
        import codecs
    except ImportError:
        print(f'SKIP: codecs module not available: {sys.exc_info()}')
        return

    # Try to remove any previous b64 codec module with the
    # same name.
    try:
        del sys.modules['b64']
    except KeyError:
        pass

    # Now import the 'b64' module.
    try:
        import b64  # pylint: disable=import-error
    except ImportError:
        _, err, _ = sys.exc_info()
        traceback.print_exc()

# Generated at 2022-06-21 12:30:36.927861
# Unit test for function register

# Generated at 2022-06-21 12:30:46.851038
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode``."""
    # noinspection PyUnresolvedReferences,PyProtectedMember
    from . import codec_base64

    # Not much we can do here but test a few well known values.
    assert codec_base64.decode(b'foobar')[0] == 'Zm9vYmFy'
    assert codec_base64.decode(b'BbU6cw==')[0] == '+b†Ø'
    assert codec_base64.decode(b'A\xcb\x91')[0] == 'AƑ'

    # Test the UnicodeEncodeError error

# Generated at 2022-06-21 12:30:56.146231
# Unit test for function encode
def test_encode():
    assert encode('LyogLyogUmV2aXNpb24gY29kZSBmb3IgdGhpcyBmaWxlOiBodHRwOi8vdG9vbHMuaW8v'
                  'M1ZaQ2Z3LyAqKi8='.upper()) == (b'/* Revision code for this file: http://tools.io/3VZCfw/ */',
                                             104)


# Generated at 2022-06-21 12:31:01.237531
# Unit test for function register
def test_register():
    """
    >>> from codecs import getdecoder, getencoder
    >>> from eplm import b64
    >>> decode = getdecoder(b64.NAME)
    >>> encode = getencoder(b64.NAME)
    >>> encode(b'test')
    ('dGVzdA==', 4)
    >>> decode(b'dGVzdA==')
    ('test', 4)
    """

# Generated at 2022-06-21 12:31:07.204178
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)    # pylint: disable=W0104


if __name__ == '__main__':
    register()
    s = '\r\n'.join((
        'QQ==',
        'QQo=',
        'QQo=tQ==',
    ))
    r = s.encode(NAME)
    print(r)
    print(r.decode(NAME))

# Generated at 2022-06-21 12:31:10.551997
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)
    assert encode('\ndHV0b3JpYWw=\n') == (b'tutorial', 9)
    assert encode('\nZm9v\nYmFyIGJheg==') == (b'foobarbaz', 12)



# Generated at 2022-06-21 12:31:15.977593
# Unit test for function decode
def test_decode():
    """Using a known base64 string, confirm decode is working correctly."""
    input = 'base64 is cool'
    expect = 'YmFzZTY0IGlzIGNvb2w='
    actual = decode(input.encode('utf-8'))[0]
    assert (expect == actual), (
        f'base64.decode({input!r}) does not return {expect!r}: '
        f'{actual!r}'
    )



# Generated at 2022-06-21 12:31:27.167527
# Unit test for function decode
def test_decode():
    # Test empty string
    assert decode(b'') == ('', 0)

    # Test a string of base64 characters
    assert decode(b'aGVsbG8=') == ('hello', 8)

    # Test a string of base64 characters the spans multiple lines
    assert decode(b'aGVs\nbG8=') == ('hello', 8)
    assert decode(b'aGVs\n\nbG8=') == ('hello', 8)

    # Test bytes across multiple lines
    assert decode(b'aGVs\nbG8=\n') == ('hello', 8)

    # Test bytes that are a multiple of 4
    assert decode(b'aGVsbG8') == ('hello', 8)

    # Test with bytes that are a multiple of 3

# Generated at 2022-06-21 12:31:55.345629
# Unit test for function register
def test_register():
    """Test registering the `b64` codec."""
    register()
    assert codecs.lookup(__name__.split('.')[-1]) is not None

if __name__ == '__main__':
    print('Testing')
    test_register()

# Generated at 2022-06-21 12:32:05.940119
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.lookup(NAME) is _get_codec_info(NAME)


if __name__ == '__main__':
    import argparse
    import importlib

    def main() -> None:
        """Mainline"""
        parser = argparse.ArgumentParser(
            description=(
                f'Test the {NAME} codec module.  Using the {NAME} codec '
                'converts text containing base64 characters into bytes and '
                'converts bytes into a string containing base64 characters.'
            )
        )


# Generated at 2022-06-21 12:32:10.785743
# Unit test for function decode
def test_decode():
    data = "abc".encode('utf-8')
    data1 = "YWJj".encode('utf-8')
    encoded,length = decode(data)
    assert encoded == "YWJj"
    encoded, length = decode(data1)
    assert encoded == "YWJj"


# Generated at 2022-06-21 12:32:15.081087
# Unit test for function register
def test_register():
    NAME = __name__.split('.')[-1]
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
        codecs.lookup(NAME)



# Generated at 2022-06-21 12:32:24.483617
# Unit test for function decode
def test_decode():
    """Test the decoding of the ``b64`` codec."""
    print('\nRunning unit tests for the b64 codec...')
    print('\nTesting the decode function')
    print('Test case 1: b""')
    print(f'{decode(b"")!r}')

    print('\nTest case 2: b"YQ=="')
    print(f'{decode(b"YQ==")!r}')

    print('\nTest case 3: b"YWI="')
    print(f'{decode(b"YWI=")!r}')

    print('\nTest case 4: b"YWJj"')
    print(f'{decode(b"YWJj")!r}')


# Generated at 2022-06-21 12:32:26.112423
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None


# Generated at 2022-06-21 12:32:30.639760
# Unit test for function register
def test_register():
    """Test the function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        return
    raise RuntimeError(f'{NAME} is already registered.')

# Unit tests for function encode