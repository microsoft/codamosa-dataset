

# Generated at 2022-06-21 12:22:35.461394
# Unit test for function register
def test_register():
    """Test function register()."""
    # First assert that the 'b64' codec is not defined.
    try:
        codecs.getdecoder(NAME)
        raise RuntimeError(
            f'Test failed - \'{NAME}\' codec is already registered.'
        )
    except LookupError:
        pass

    # Register the 'b64' codec
    register()

    # Assert that the 'b64' codec is defined.
    codecs.getdecoder(NAME)
    print(f'Test successful for function register().')



# Generated at 2022-06-21 12:22:37.491254
# Unit test for function decode
def test_decode():
    assert decode(b'test') == ('dGVzdA==', 4)


# Generated at 2022-06-21 12:22:47.844008
# Unit test for function register
def test_register():
    import operator
    import functools
    import doctest
    import os
    import sys

    dir_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, dir_path)
    import __main__  # type: ignore[import]
    try:
        from ut_setup import setup_for_testing  # type: ignore[import]
        # noinspection PyUnresolvedReferences
        setup_for_testing(__main__)
    except ImportError as err:
        print('Error when importing ut_setup: ', err)

    def _get_object(obj_name: str) -> object:
        # Extract the object requested.
        obj = __main__

# Generated at 2022-06-21 12:22:54.049798
# Unit test for function decode
def test_decode():
    """
    >>> test_decode()
    True
    """
    import codecs
    test_str="testing 1-2-3"
    test_bytes = test_str.encode('utf-8')
    encoded_bytes = base64.b64encode(test_bytes)
    encoded_str = encoded_bytes.decode('utf-8')
    assert codecs.decode(encoded_str, NAME) == test_str
    return True


# Generated at 2022-06-21 12:23:01.429051
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)
    # noinspection PyUnusedLocal
    def _():
        return obj.decode(b'YQ==')
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:23:13.089787
# Unit test for function decode
def test_decode():
    # Unit testing for function decode
    print("\nBegin unit testing for function decode")
    # Test the encode function for a case of proper base64 input
    test_bytes_1 = bytearray(b"4A4B4C4D4E4F4G4H4I4J4K4L4M4N4O4P4Q4R4S4T4U4V4W4X4Y4Z")

# Generated at 2022-06-21 12:23:15.112782
# Unit test for function register
def test_register():
    """Test function register."""
    register()



# Generated at 2022-06-21 12:23:25.077921
# Unit test for function decode
def test_decode():
    assert decode(b'abc') == ('YWJj', 3)
    assert decode(b'YWJj') == ('YCYK', 3)
    assert decode(b'\0') == ('AA==', 1)
    assert decode(b'\x01') == ('AQ==', 1)
    assert decode(b'\x02') == ('Ag==', 1)
    assert decode(b'\x03') == ('Aw==', 1)
    assert decode(b'\x04') == ('BA==', 1)
    assert decode(b'\x05') == ('BQ==', 1)
    assert decode(b'\x06') == ('Bg==', 1)
    assert decode(b'\x07') == ('Bw==', 1)

# Generated at 2022-06-21 12:23:33.635071
# Unit test for function register
def test_register():
    register()
    actual = codecs.getencoder(NAME)
    expected = (encode, None, None)
    assert actual == expected
    actual = codecs.getdecoder(NAME)
    expected = (decode, None, None)
    assert actual == expected
    actual = codecs.lookup(NAME)
    expected = codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )
    assert actual == expected



# Generated at 2022-06-21 12:23:38.271047
# Unit test for function register
def test_register():
    '''Test the `register` function'''
    register()
    # noinspection PyProtectedMember
    registered_codecs = codecs._getcodec_cache()   # pylint: disable=protected-access
    assert NAME in registered_codecs
    assert (
        NAME in codecs.__all__ or
        'b64' in codecs.__all__  # pylint: disable=no-member
    )



# Generated at 2022-06-21 12:23:48.080113
# Unit test for function encode
def test_encode():
    assert \
        encode(  # type: ignore[arg-type]
            ''
        ) == (b'', 0)

    assert \
        encode(  # type: ignore[arg-type]
            'YWJjZA=='
        ) == (b'abcd', 6)

    assert \
        encode(  # type: ignore[arg-type]
            'YWJjZA'
        ) == (b'abcd', 6)

    assert \
        encode(  # type: ignore[arg-type]
            'YWJjZ'
        ) == (b'abcd', 6)

    assert \
        encode(  # type: ignore[arg-type]
            'YWJj'
        ) == (b'abcd', 4)


# Generated at 2022-06-21 12:23:49.382300
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)  # type: ignore


# Generated at 2022-06-21 12:23:54.718999
# Unit test for function encode
def test_encode():
    """Unit tests for :func:`encode`"""
    assert encode('SQ==')[0] == b'\x01'
    assert encode('Dw==')[0] == b'\x02\x02'
    assert encode('DQ==')[0] == b'\x03'
    assert encode('QQ==')[0] == b'\x04'
    assert encode('Cg==')[0] == b'\x05'
    assert encode('Ag==')[0] == b'\x06'
    assert encode('Dw==')[0] == b'\x02\x02'
    assert encode('bw==')[0] == b'\x02\x03'
    assert encode('SQ==')[0] == b'\x01'

# Generated at 2022-06-21 12:24:05.473510
# Unit test for function encode
def test_encode():
    """Unit tests for the `encode` method."""
    func = encode

    out, length = func('\n')
    assert out == b''
    assert length == 1

    out, length = func('   \n\t\n')
    assert out == b''
    assert length == 5

    out, length = func('SSdtIGtpbGxpbmcgeW91ciBicmFpbiBsaWtlIGEgcG9pc29ub3VzIG11c2hyb29t')
    assert out == b"I'm killing your brain like a poisonous mushroom"
    assert length == 56

    out, length = func('U2VjcmV0IHRvb2wgaXM6IF9feGluamVjdC5zaGVsbC5zaGVsbHNjcmlwdF9f')

# Generated at 2022-06-21 12:24:13.867444
# Unit test for function encode
def test_encode():
    assert encode(
        "ZW5jb2Rpbmc6IGJhc2U2NA=="
    ) == (b'encoding: base64', 26)

    assert encode(
        "ZW5jb2Rpbmc6IGJhc2U2NA==\n"
    ) == (b'encoding: base64', 27)

    assert encode(
        "ZW5jb2Rpbmc6IGJhc2U2NA==\n\n"
    ) == (b'encoding: base64', 29)

    assert encode(
        "ZW5jb2Rpbmc6IGJhc2U2NAA"
    ) == (b'encoding: base64', 26)


# Generated at 2022-06-21 12:24:20.217598
# Unit test for function decode
def test_decode():
    assert decode(b'AQIDBAUGBwgJCg==') == ('0123456789', 16)
    assert decode(b'AAYBAQIBAQQBAwM=') == ('ABCDEFGHABCDEFG', 16)
    assert decode(b'AA==') == ('\u0001', 2)
    assert decode(b'AgA=') == ('\x01\x01', 4)
    assert decode(b'AQE=') == ('\x01\x00\x01', 4)


# Generated at 2022-06-21 12:24:25.658969
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # Create test input
    test_input = '''
        YQ==
        YWI=
        YWJj
        '''
    test_result = b'abcd'

    # Run encode
    result = encode(test_input)
    assert result[0] == test_result



# Generated at 2022-06-21 12:24:36.484197
# Unit test for function decode
def test_decode():

    assert decode(b'eWVubyBibHVl') == ('enon blue', 11)

    assert decode(b'eWVubyBibHVl') == ('enon blue', 11)

    assert decode(b'eWVubyBibHVlDg==') == ('enon blue\n', 12)

    assert decode(b'eWVubyBibHVlCg==') == ('enon blue\r', 12)

    assert decode(b'eWVubyBibHVlDQ==') == ('enon blue\x00', 12)

    assert decode(b'eWVubyBibHVlCQ==') == ('enon blue\x01', 12)

    assert decode(b'eWVubyBibHVlDgE=')

# Generated at 2022-06-21 12:24:43.656983
# Unit test for function encode
def test_encode():
    assert encode("SSBsb3ZlIHlvdQ==") == (b'I love you', 15)
    # Create a test string.
    trans_str = str(
        "SSBsb3ZlIHlvdQ==\n"
        "SSBsb3ZlIHlvdQ==\n"
    )
    assert encode(trans_str) == (b'I love youI love you', 30)



# Generated at 2022-06-21 12:24:46.635740
# Unit test for function register
def test_register():
    """Test that the b64 codec is registered with Python."""
    codecs.getencoder(NAME)  # raises LookupError if not registered



# Generated at 2022-06-21 12:24:52.724693
# Unit test for function encode
def test_encode():
    assert (
        encode(
            b'AAAABBBBAAAABBBBAAAABBBB'
        )
        == (
            b'QUFBQUFCQUJCQUJBSUFBQUFBQUFBQUFBQUJCSUFBQUFBQUFBQUFCQk5SQQ==',
            37
        )
    )



# Generated at 2022-06-21 12:24:57.992478
# Unit test for function decode
def test_decode():
    # Test encode decode
    assert decode(b'SGVsbG8gV29ybGQ')[0] == 'Hello World'
    # Test encode decode with multiple lines
    assert decode(b'SGVsbG8gV29ybGQKbWFkZSBieSBwaHlmZXIK')[0] == ('Hello World\n'
        'made by phyfer\n')

# Generated at 2022-06-21 12:25:04.780124
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 6)
    assert encode('YWJjZGU=') == (b'abcde', 7)
    assert encode('YWJjZGVm') == (b'abcdef', 7)
    assert encode('YWJjZGVmZA==') == (b'abcdefg', 9)
    assert encode('YWJjZGVmZGU=') == (b'abcdefgh', 10)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)

# Generated at 2022-06-21 12:25:10.123831
# Unit test for function register
def test_register():
    # Test that b64 codec is not in codecs when function is
    # called to register the codecs.
    try:
        codecs.getencoder(NAME)
        # raise Exception('"b64" codec is already registered.')
    except LookupError:
        register()
        codecs.getencoder(NAME)

# Generated at 2022-06-21 12:25:20.511080
# Unit test for function decode
def test_decode():
    data = 'Hello'.encode('utf-8')
    assert decode(data) == ('SGVsbG8=', 5)
    data = 'Hello world!'.encode('utf-8')
    assert decode(data) == ('SGVsbG8gd29ybGQh', 13)
    data = '1234567890'.encode('utf-8')
    assert decode(data) == ('MTIzNDU2Nzg5MA==', 11)
    data = 'The quick brown fox jumps over the lazy dog.'.encode('utf-8')
    assert decode(data) == ('VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZy4=', 43)

# Generated at 2022-06-21 12:25:24.316521
# Unit test for function register
def test_register():
    """Test the register function"""
    register()
    codecs.getencoder(NAME)
    assert codecs.encode(b'my data', NAME) == (b'bXkgZGF0YQ==', None)


REGISTER: bool = False

if not REGISTER:
    register()

# Generated at 2022-06-21 12:25:30.964502
# Unit test for function encode
def test_encode():
    assert encode('TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNldGV0dXIgc2'
                  'FkaXBzY2luZyBlbGl0Lg==') == (b'Mor'
                                             b'em ipsu'
                                             b'm dolor '
                                             b'sit amet, '
                                             b'consetet'
                                             b'ur sadip'
                                             b'scing elit.', 64)

# Generated at 2022-06-21 12:25:41.851307
# Unit test for function encode
def test_encode():
    # pylint: disable=protected-access
    import codecs
    codecs._register(_get_codec_info)


# Generated at 2022-06-21 12:25:46.260516
# Unit test for function encode
def test_encode():
    # noinspection PyShadowingNames
    def encode_checker(text, expected) -> None:
        """Private function to check the ``encode()`` results."""
        bytes_r, _ = encode(text)
        assert bytes_r == expected

    encode_checker('Zm9vYmFy', b'foobar')
    encode_checker('Zm9v\nYmFy', b'foobar')
    encode_checker('Zm9v\n   YmFy', b'foobar')
    encode_checker('Zm9v \n  YmFy', b'foobar')
    encode_checker('   Zm9v\nYmFy\n', b'foobar')

# Generated at 2022-06-21 12:25:54.901624
# Unit test for function decode
def test_decode():
    assert decode(b'', 'strict') == ('', 0)
    assert decode(b'YQ==', 'strict') == ('a', 4)
    assert decode(b'YWI=', 'strict') == ('ab', 4)
    assert decode(b'YWJj', 'strict') == ('abc', 4)
    assert decode(b'YWJjZA==', 'strict') == ('abcd', 8)
    assert decode(b'YWJjZA', 'strict') == ('abcd', 6)
    assert decode(b'\r\nYWJjZA==\r\n', 'strict') == ('abcd', 10)
    assert decode(b'\r\n\t YWJjZA==\r\n', 'strict') == ('abcd', 12)
   

# Generated at 2022-06-21 12:26:05.950838
# Unit test for function register
def test_register():
    from importlib import reload
    import sys

    try:
        reload(sys.modules[__name__])

        # Verify that the codec is registered.
        b64 = codecs.getdecoder(NAME)

        # Perform a quick test.
        text = ' \n \n   aGVsbG8gd29ybGQ= \n \n    \n'
        _, _ = b64(text, 'strict')
    finally:
        # Remove the registered codec.
        del codecs.decode_error_registry[NAME]


# Generated at 2022-06-21 12:26:10.476944
# Unit test for function encode
def test_encode():
    assert encode('AA==') == (b'\0', 4)
    assert encode('AAA=') == (b'\0\0', 4)
    assert encode('AAAA') == (b'\0\0\0', 4)
    assert encode('AA') == (b'\0', 2)
    assert encode('AAE=') == (b'\0\0\0', 4)
    assert encode('AAE') == (b'\0\0', 3)

# Generated at 2022-06-21 12:26:14.357499
# Unit test for function decode
def test_decode():
    """Test that b64.decode() works as expected."""
    assert decode(bytes.fromhex('7D0A'))[0] == 'nd\n'
    assert decode(bytes.fromhex('7D'))[0] == 'm'
    assert decode(bytes.fromhex('6D61696E'))[0] == 'main\n'
    assert decode(bytes.fromhex('2F2F205468652066756E6374696F6E207469746C65732074686973'))[0] == '// The function titles this\n'
    assert decode(bytes.fromhex('76616C75652069733A202223692222'))[0] == 'value is: "#i""\n'

# Generated at 2022-06-21 12:26:20.331179
# Unit test for function register
def test_register():
    """Unit tests for function register()."""
    register()
    # Check that the module is loaded
    assert NAME in sys.modules

    # Check that the codec is registered.
    codecs.getdecoder(NAME)
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise Exception(
            'The codec b64 is not registered as an encoder'
        )
    assert True



# Generated at 2022-06-21 12:26:28.566719
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

    text = '\n'.join([
        'QmFzZTY0IGVuY29kaW5nLg==',
        '',
        'SW5jbHVkaW5nIHRoZSBiZXN0IGJhc2U2NCBzdWJzeXN0ZW1zLg==',
    ])

    assert encode(text) == (b'Base64 encoding.\n\nIncluding the best base64 subsystems.', 178)



# Generated at 2022-06-21 12:26:35.818153
# Unit test for function register
def test_register():

    # Reset the codecs.
    codecs.__init__()
    # No 'b64' Codec.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    register()

    # Ensure that the 'b64' Codec exists.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(
            'Could not get the decoder for the \'b64\' codec.'
        ) from e



# Generated at 2022-06-21 12:26:45.129943
# Unit test for function decode
def test_decode():
    print("Testing base64 decode:")

    # noinspection SpellCheckingInspection
    assert decode(b"ZW5jb2RlIHRlc3Q=", '')[0] == "encode test"

    # noinspection SpellCheckingInspection
    assert decode(b"bm90IGEgc3VyZSByZWFzb24gZm9yIERWQQ==", '')[0] == "not a sure reason for DVA"

    # noinspection SpellCheckingInspection
    assert decode(b"Zm94IGd1b3RpZnkgYmlrZXRz", '')[0] == "fox gutify biketts"

    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:26:57.254702
# Unit test for function encode
def test_encode():
    # pylint: disable=W0621
    """Test the 'encode' function with the following cases:

    - the given 'text' is a one line string.
    - the given 'text' is a multi-line string.
    - the given 'text' has non-ascii characters.
    - the given 'text' is of type UserString
    - the given 'text' is of type UserString with non-ascii characters.
    - the given 'text' contains non-base64 characters.
    """
    def _assert_encode(expected, text: str):
        """Test the 'encode' function with the given 'text' input."""
        actual, length = encode(text)
        assert len(actual) == length
        assert actual == expected
    # Case 1-1: the given 'text' is a one line

# Generated at 2022-06-21 12:27:07.421511
# Unit test for function decode
def test_decode():
    for v1 in [str, UserString]:
        v2 = v1('Kw==')
        v3 = decode(v2)
        v4 = (*v3, )
        assert v4 == ('a', 3)
        v2 = v1('YQ==')
        v3 = decode(v2)
        v4 = (*v3, )
        assert v4 == ('a', 3)
        v2 = v1('YWI=')
        v3 = decode(v2)
        v4 = (*v3, )
        assert v4 == ('ab', 4)
        v2 = v1('YWJj')
        v3 = decode(v2)
        v4 = (*v3, )
        assert v4 == ('abc', 4)
        v2 = v1('YWJjZA==')

# Generated at 2022-06-21 12:27:15.518954
# Unit test for function encode
def test_encode():
    from binascii import Error
    from base64 import b32decode, b32encode, b64decode, b64encode

    assert encode('ZmxhZ3tUaGlzIGlzIG5vdCBhIHJlYWwgaW5wdXR9') == (
        b64decode(b'ZmxhZ3tUaGlzIGlzIG5vdCBhIHJlYWwgaW5wdXR9'),
        len('ZmxhZ3tUaGlzIGlzIG5vdCBhIHJlYWwgaW5wdXR9')
    )

# Generated at 2022-06-21 12:27:27.510835
# Unit test for function encode
def test_encode():
    import sys
    import random

    # Create a random string that is four times the length of the
    # longest allowed string,
    #   max_size = int(1024 * 1.33 / 10) * 3
    # of base64 character codes.
    len_ = int((1024 * 1.33 / 10) * 12)
    data = ''.join(
        random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
                      '0123456789+/')
        for _ in range(len_)
    )

    result = codecs.encode(data, NAME)
    assert isinstance(result, bytes)
    assert len(result) == len(data)

    # Because each data character is one byte,
    # one encoded character is 10

# Generated at 2022-06-21 12:27:39.376545
# Unit test for function encode
def test_encode():
    """Test that function ``encode`` correctly encodes correctly formatted
    base64 strings into base64 bytes.

    The test will also check that the given base64 string, if it is not a
    proper base64 string, then the function will raise a
    UnicodeEncodeError.
    """
    # Test 1

# Generated at 2022-06-21 12:27:47.561911
# Unit test for function encode
def test_encode():
    """Test function encode"""
    text_in = b'\n'.join(
        (
            'ZWl0aGVyIG9yIG5vdCBpcyB0aGUgaWRlYSAgICAgICAgICAgICAg',
            'ICBvbmUga2luZCBvZiBxdWl6Lg=='
        )
    ).decode('utf-8')
    out, _ = encode(text_in)

# Generated at 2022-06-21 12:27:59.447754
# Unit test for function register
def test_register():
    import sys
    import tempfile
    import pathlib
    import contextlib
    import subprocess

    PYTHON_EXECUTABLE = sys.executable
    PYTHON_VERSION = sys.version[:3]

# Generated at 2022-06-21 12:28:10.066534
# Unit test for function decode
def test_decode():
    # noinspection PyUnresolvedReferences
    from pytest import raises

    # Test normal operation.
    test_data = b'foobar'
    expected = 'Zm9vYmFy'
    result = decode(test_data)
    assert result == (expected, len(test_data))

    # Test normal operation with memoryview.
    test_data = memoryview(b'foobar')
    result = decode(test_data)[0]
    assert result == expected

    # Test normal operation with bytearray.
    test_data = bytearray(b'foobar')
    result = decode(test_data)[0]
    assert result == expected

    # Test not enough input bytes.

# Generated at 2022-06-21 12:28:12.417372
# Unit test for function register
def test_register():
    """Test the function :func:`register`"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:28:20.692934
# Unit test for function encode
def test_encode():
    test_data = [
        (
            '''\
            example string''',
            '''\
            ZXhhbXBsZSBzdHJpbmc'''
        ),
        (
            '''\
            example
            string''',
            '''\
            ZXhhbXBsZSBzdHJpbmc'''
        ),
        (
            '''\
            example
            string''',
            '''\
            ZXhhbXBsZSBzdHJpbmc'''
        ),
        (
            '''\
            example
            string''',
            '''\
            ZXhhbXBsZSBzdHJpbmc'''
        ),
    ]


# Generated at 2022-06-21 12:28:29.690685
# Unit test for function decode
def test_decode():
    # pylint: disable=E1101
    # pylint: disable=E1102
    # pylint: disable=W0703
    # pylint: disable=W0621
    # pylint: disable=C0413
    test_str = '9f28b32c-4320-4dc8-837b-1a0976c79d0e'
    try:
        test_bytes = bytes.fromhex(test_str)
    except ValueError as e:
        print(e)
        raise
    test_decode_str, _length = decode(test_bytes)
    print(f"Decode: {test_decode_str}")


# Generated at 2022-06-21 12:28:31.584340
# Unit test for function decode
def test_decode():
    assert decode(b'Zm9v') == ('Zm9v', 4)



# Generated at 2022-06-21 12:28:42.727917
# Unit test for function encode
def test_encode():
    """Test function ``encode``."""
    assert encode('test')[0] == b'test'
    assert encode('')[0] == b''
    assert encode('Zm9v')[0] == b'foo'
    assert encode('Zm9vYmFy')[0] == b'foobar'
    assert encode('Zm9vIGJhcgo')[0] == b'foo bar\n'
    assert encode('Cg==')[0] == b'\n'
    assert encode('\n')[0] == b'\n'
    assert encode('YQ')[0] == b'a'
    assert encode('YQ==')[0] == b'a'
    assert encode('YWI=')[0] == b'ab'
    assert encode('YWJj')

# Generated at 2022-06-21 12:28:57.615250
# Unit test for function encode

# Generated at 2022-06-21 12:29:08.057635
# Unit test for function encode
def test_encode():
    """Test the ``b64.encode`` function.
    """
    # pylint: disable=R0201
    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:29:13.340029
# Unit test for function register
def test_register():
    # need enough scope to test the 'decode' function
    def decode_text(text):
        return codecs.decode(text, NAME)

    register()
    assert NAME in codecs.getdecoder('b64')

    input_text = b'SGVsbG8gV29ybGQh'
    out, _ = decode(input_text)
    assert out == b'Hello World!'
    out = decode_text(input_text)
    assert out == b'Hello World!'

    input_text = b'SGVsbG8gV29ybGQh\n'
    out, _ = decode(input_text)
    assert out == b'Hello World!'
    out = decode_text(input_text)
    assert out == b'Hello World!'


# Generated at 2022-06-21 12:29:20.640804
# Unit test for function register
def test_register():
    # Ensure the ``b64`` codec has not been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The "{NAME}" codec has already been registered.'
        )

    # Register the ``b64`` codec and get the CodecInfo object.
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)
    assert isinstance(obj, codecs.CodecInfo)



# Generated at 2022-06-21 12:29:30.119438
# Unit test for function decode
def test_decode():
    if __name__ != '__main__':
        return
    import unittest


    class TestDecode(unittest.TestCase):
        def test_decode_1(self):
            test_input = b'\x10\x00\x00\x00'
            test_output = 'EAAAAA=='
            r = decode(test_input)
            self.assertEqual(r[0], test_output)

        def test_decode_2(self):
            test_input = b'\x01'
            test_output = 'AQ=='
            r = decode(test_input)
            self.assertEqual(r[0], test_output)

        def test_decode_3(self):
            test_input = b'\x00'

# Generated at 2022-06-21 12:29:40.728964
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    line_1 = '''
      YmFzZTY0IEVuY29kZSBFbmNvZGUgU3RyZWFt
    '''

# Generated at 2022-06-21 12:29:49.000638
# Unit test for function decode

# Generated at 2022-06-21 12:29:57.749431
# Unit test for function encode
def test_encode():
    # pylint: disable=W0613
    # noinspection PyUnusedLocal
    def encode(
            text: _STR,
            errors: _STR = 'strict'
    ) -> Tuple[bytes, int]:
        """Convert the given ``text`` of base64 characters into the base64
        decoded bytes.

        Args:
            text (str): The string input.  The given string input can span
                across many lines and be indented any number of spaces.
            errors (str): Not used.  This argument exists to meet the
                interface requirements.  Any value given to this argument
                is ignored.

        Returns:
            bytes: The given ``text`` converted into base64 bytes.
            int: The length of the returned bytes.
        """
        # Convert the given 'text', that are of type UserString into a str

# Generated at 2022-06-21 12:30:09.706354
# Unit test for function encode
def test_encode():
    assert encode('TUlJRFNIRHdVZ0JtWlFnQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQQ==') == \
        (b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\
         \x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f',
         80)

# Generated at 2022-06-21 12:30:13.911682
# Unit test for function register
def test_register():
    """Ensure register function works as intended."""
    # First ensure that the codec is not registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{NAME} has already been registered')
    # Next, call the register function
    register()
    # Now, ensure that the codec is registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'{NAME} has not been registered')
    else:
        pass


# Generated at 2022-06-21 12:30:25.695453
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == \
        (b'abcdefghijklmnopqrstuvwxyz', 29)
    try:
        decode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=z')
    except UnicodeEncodeError as e:
        assert e.reason == (
            f"b\'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=z\' is not a proper bas64 "
            f"character string: Incomplete base64 string."
        )


# Generated at 2022-06-21 12:30:30.454849
# Unit test for function decode
def test_decode():
    assert decode(b'\x41') == ('QQ==', 1)
    assert decode(b'\x43') == ('SA==', 1)
    assert decode(b'\x46') == ('Rg==', 1)
    assert decode(b'\x41\x43\x46') == ('QUJDRA==', 3)
    assert decode(b'\x00') == ('AA==', 1)
    assert decode(b'\xff') == ('/w==', 1)


# Unit test the function encode

# Generated at 2022-06-21 12:30:41.296827
# Unit test for function register
def test_register():    # pragma: no cover
    from codecs import lookup, BOM_UTF8
    # Create the codec
    register()
    # Get the codec
    codec = lookup(NAME)
    # Create a test message
    msg = 'This is a message'
    # Encode the 'msg'
    msg_b64 = codec.encode(msg)[0]
    # Decode the 'msg_b64'
    decoded_msg, length = codec.decode(msg_b64)
    # The decoded message should match the original message.
    assert decoded_msg == msg
    # The length of the 'msg' and the length of the decoded 'msg_b64'
    # should both be the same.
    assert length == len(msg)
    # We can also decode the 'msg_b64' by passing it to the


# Generated at 2022-06-21 12:30:51.392370
# Unit test for function decode
def test_decode():
    """Test the ``b64.decode`` function."""

# Generated at 2022-06-21 12:30:58.634012
# Unit test for function encode
def test_encode():
    """Test B64.encode"""
    # Encrypt a string with B64.encode.
    string = "Hello World!\nI'm Duy"
    string_encrypt = "SGVsbG8gV29ybGQhCiJJJ20gRHV5"
    string_encrypt_bytes, _ = encode(string)
    assert string_encrypt == string_encrypt_bytes.decode("utf-8")


# Generated at 2022-06-21 12:31:04.477511
# Unit test for function register
def test_register():
    """Test the ``register()`` function."""
    assert NAME not in codecs.__dict__
    register()
    assert NAME in codecs.__dict__


# This module can be used as a script.
if __name__ == '__main__':
    register()
    print((
        'The ``b64`` encoding has been registered with Python.\n'
        'Use the ``b64`` encoding with the ``open()`` function.\n'
        '\n'
        'e.g.\n'
        '\n'
        '    with open(\'a_file.b64\', \'rt\', encoding=\'b64\') as f:\n'
        '        for line in f:\n'
        '            print(line, end=\'\')\n'
        '\n'
    ))

# Generated at 2022-06-21 12:31:13.438407
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""
    # pylint: disable=W0621
    # Redefinition of unused 'test_encode' from line 692
    # pylint: disable=W0621
    # Redefinition of unused 'test_encode' from line 692
    import pytest

    def _test(test_input: str, expect: str) -> None:
        try:
            output, _ = encode(test_input)
            assert output.decode('utf-8') == expect
        except UnicodeEncodeError as e:
            if expect.startswith('Error: '):
                assert str(e).startswith(expect[7:])
            else:
                raise e


# Generated at 2022-06-21 12:31:20.583429
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Test the function `encode()`"""
    # noinspection PyTypeChecker
    assert encode('SGVsbG8gd29ybGQh') == (b'Hello world!', 16)
    # noinspection PyTypeChecker
    assert encode('SGVs\nbG8g\nd29y\nbGQh') == (b'Hello world!', 16)
    # noinspection PyTypeChecker
    assert encode('SGVsbG8gd29ybGQh\n') == (b'Hello world!', 16)
    # noinspection PyTypeChecker
    assert encode(' SGVsbG8gd29ybGQh \n') == (b'Hello world!', 16)
    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:31:22.850901
# Unit test for function encode
def test_encode():
    base64Str = b'aGVsbG8gd29ybGQ='
    assert encode(base64Str)[0] == b'hello world'

# Generated at 2022-06-21 12:31:30.948257
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    input_str = "dGVzdCBiYXNlIDY0IGVuY29kaW5nCg=="
    correct_str = "test base 64 encoding\n"
    correct_str_bytes = correct_str.encode('utf-8')

    # Test the decode function
    actual = decode(input_str)

    print(f'Correct: {correct_str_bytes}')
    print(f'Actual: {actual[0].encode("utf-8")}')

    assert correct_str_bytes == actual[0].encode('utf-8')


# Generated at 2022-06-21 12:31:41.036546
# Unit test for function decode
def test_decode():
    """Test the codecs.decode(b'ABCDEFG==') == 'ABCDEFG'"""
    assert codecs.decode(b'ABCDEFG==', NAME) == 'ABCDEFG'



# Generated at 2022-06-21 12:31:46.441863
# Unit test for function encode
def test_encode():
    """Unit test: b64.encode."""
    import b64
    assert b64.encode('ABCDEFG') == (b'QUJDREVGRw==', 7)
    assert b64.encode('1234567') == (b'MTIzNDU2Nw==', 7)
    assert b64.encode('No Miss') == (b'Tm8gTWlzcw==', 8)


# Generated at 2022-06-21 12:31:56.941087
# Unit test for function decode
def test_decode():
    """Test the function ``decode`` against the known good result"""
    enc_bytes: bytes = b"hello world"
    enc_str: str = "aGVsbG8gd29ybGQ="
    enc_str_newline: str = "aGVsbG8gd29ybGQ=\n"

    assert decode(enc_bytes)[0] == enc_str
    assert decode(enc_bytes, "ignore")[0] == enc_str
    assert decode(enc_str)[0] == enc_str
    assert decode(enc_str, "ignore")[0] == enc_str
    assert decode(enc_str_newline)[0] == enc_str
    assert decode(enc_str_newline, "ignore")[0] == enc_str



# Generated at 2022-06-21 12:32:06.506506
# Unit test for function decode
def test_decode():
    """Tests for the decode function."""
    assert decode(b'\x80') == ('gA==', 1)
    assert decode(b'\x80\x80') == ('gIA=', 2)
    assert decode(b'\x80\x80\x80') == ('gICA', 3)
    assert decode(b'\x80\x80\x80\x80') == ('gICAgA==', 4)
    assert decode(b'\x80\x80\x80\x80\x80') == ('gICAgIA=', 5)
    assert decode(b'\x80\x80\x80\x80\x80\x80') == ('gICAgICA', 6)

# Generated at 2022-06-21 12:32:17.200871
# Unit test for function decode

# Generated at 2022-06-21 12:32:26.358996
# Unit test for function encode
def test_encode():
    """Ensure function 'encode' is working properly."""

# Generated at 2022-06-21 12:32:36.260254
# Unit test for function register
def test_register():
    """Test that the b64 codec will be registered with Python."""
    # Unregister all codecs
    codecs.register(lambda name: None)

    # Make sure the 'b64' codec was really unregistered.
    with pytest.raises(LookupError):
        codecs.getencoder('b64')
    with pytest.raises(LookupError):
        codecs.getdecoder('b64')

    # Register the 'b64' codec.
    register()

    # Make sure the 'b64' codec was registered correctly.
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

    codecs_register_orig = codecs.register
    codecs.register = lambda _: None
    codecs.getencoder.cache_clear()
    codecs.register = codecs