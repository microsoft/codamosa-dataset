

# Generated at 2022-06-17 18:57:09.612159
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 18:57:11.471756
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:13.206813
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:15.052744
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:16.992029
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:19.116482
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:21.920954
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:24.864531
# Unit test for function register
def test_register():
    """Test the function register()"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:57:26.408243
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:28.790718
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:34.087265
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:36.229821
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:40.700500
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test_register():
        """Test the function register."""
        register()
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
    _test_register()



# Generated at 2022-06-17 18:57:43.694799
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:47.381834
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 18:57:56.041817
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 6)
    assert encode('YWJjZGU=') == (b'abcde', 7)
    assert encode('YWJjZGVm') == (b'abcdef', 7)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 9)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 10)

# Generated at 2022-06-17 18:57:58.431867
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:58:00.295969
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:02.770297
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 18:58:05.705434
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:10.162831
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:12.401173
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:15.095933
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:18.588919
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:20.665603
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:23.410952
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:26.216557
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:34.065915
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('') == (b'', 0)
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 18:58:37.009681
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:40.511903
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:49.115918
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:52.296733
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:54.957671
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:56.728325
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:58.435949
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:59.946913
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:04.083269
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    from . import b64
    # pylint: enable=W0612
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:07.222333
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:16.943712
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )

# Generated at 2022-06-17 18:59:18.582923
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:35.137140
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:37.359240
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:40.072801
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:42.111242
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:46.098389
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:48.933106
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:51.398139
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:59.125627
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:00:06.669583
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test the encode function with a valid base64 string.
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        len('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=')
    )

    # Test the encode function with a valid base64 string that spans
    # multiple lines.

# Generated at 2022-06-17 19:00:08.464425
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:00:42.587343
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:45.049284
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:48.032530
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:49.849363
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:52.819743
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:54.315709
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:56.081720
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:01:05.030032
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )

# Generated at 2022-06-17 19:01:07.519518
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:10.071779
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:19.228902
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:22.298016
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:28.864730
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n\n') == (b'', 0)

# Generated at 2022-06-17 19:02:30.519582
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:38.205482
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('dGVzdA==') == (b'test', 6)
    assert encode('dGVzdA==\n') == (b'test', 7)
    assert encode('dGVzdA==\n\n') == (b'test', 8)
    assert encode('dGVzdA==\n\n\n') == (b'test', 9)
    assert encode('dGVzdA==\n\n\n\n') == (b'test', 10)
    assert encode('dGVzdA==\n\n\n\n\n') == (b'test', 11)
    assert encode('dGVzdA==\n\n\n\n\n\n') == (b'test', 12)

# Generated at 2022-06-17 19:02:39.728883
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:42.226571
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:53.668734
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmno', 14)

# Generated at 2022-06-17 19:02:56.168660
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:59.240487
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:05:29.647210
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:05:40.004454
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode('abcdefgh') == (b'YWJjZGVmZ2g=', 8)

# Generated at 2022-06-17 19:05:50.228239
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 19:05:52.973208
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:05:54.613971
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:06:02.681880
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:06:12.979251
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode('abcdefgh') == (b'YWJjZGVmZ2g=', 8)

# Generated at 2022-06-17 19:06:21.740958
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode('abcdefgh') == (b'YWJjZGVmZ2g=', 8)

# Generated at 2022-06-17 19:06:25.303214
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:06:35.092781
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test 1
    text = '''
    SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 2
    text = '''
    SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 3
    text = '''
    SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 4