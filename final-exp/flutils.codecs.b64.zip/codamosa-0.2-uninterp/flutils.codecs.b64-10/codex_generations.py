

# Generated at 2022-06-17 18:57:00.165660
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:07.237480
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test a simple case
    assert encode('aGVsbG8=') == (b'hello', 6)

    # Test a case with a newline
    assert encode('aGVsbG8K') == (b'hello', 6)

    # Test a case with a newline and indentation
    assert encode('aGVsbG8K') == (b'hello', 6)

    # Test a case with a newline, indentation and trailing whitespace
    assert encode('aGVsbG8K') == (b'hello', 6)

    # Test a case with a newline, indentation and trailing whitespace
    assert encode('aGVsbG8K') == (b'hello', 6)

    # Test a case with a newline, indentation and trailing whitespace

# Generated at 2022-06-17 18:57:09.135369
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:11.421167
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:13.690491
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:57:16.068390
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:57:22.059020
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None
    codecs.register = _get_codec_info
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 18:57:30.414930
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('dGVzdA==') == (b'test', 6)
    assert encode('dGVzdA==\n') == (b'test', 7)
    assert encode('dGVzdA==\n\n') == (b'test', 8)
    assert encode('dGVzdA==\n\n\n') == (b'test', 9)
    assert encode('dGVzdA==\n\n\n\n') == (b'test', 10)
    assert encode('dGVzdA==\n\n\n\n\n') == (b'test', 11)
    assert encode('dGVzdA==\n\n\n\n\n\n') == (b'test', 12)

# Generated at 2022-06-17 18:57:31.717043
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:33.456236
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:39.675546
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:41.308831
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:52.875223
# Unit test for function register
def test_register():
    """Test the register function."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register(_get_codec_info)  # type: ignore
    try:
        codecs.getdecoder(NAME)
        assert False, 'Expected LookupError'
    except LookupError:
        pass

    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:54.736860
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:05.707968
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test 1
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 2
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 3
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 4

# Generated at 2022-06-17 18:58:14.150328
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:58:15.665941
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:22.706802
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:58:25.106751
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:29.724514
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    from . import b64
    # pylint: enable=W0612
    assert b64.NAME == NAME
    assert b64.decode == decode
    assert b64.encode == encode
    assert b64.register == register



# Generated at 2022-06-17 18:58:39.295096
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:42.149831
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:46.533759
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:49.023192
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:53.159044
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:01.708719
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test 1
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 2
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 3
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 4

# Generated at 2022-06-17 18:59:03.809131
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:07.187860
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:10.144091
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:13.675804
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:38.609632
# Unit test for function encode
def test_encode():
    """Test the function :func:`encode`."""
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 18:59:42.858824
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    from b64codec import register
    register()
    assert codecs.lookup(NAME) is not None
    assert codecs.lookup(NAME).name == NAME



# Generated at 2022-06-17 18:59:45.659922
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:49.374398
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:51.059961
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:58.610478
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 19:00:01.165424
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:03.141578
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:05.153899
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:12.686310
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 19:00:50.856840
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:53.326256
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:54.854464
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:59.500270
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test_register(name: str) -> None:
        codecs.getdecoder(name)

    # Test that the codec is not registered.
    with pytest.raises(LookupError):
        _test_register(NAME)

    # Register the codec.
    register()

    # Test that the codec is registered.
    _test_register(NAME)



# Generated at 2022-06-17 19:01:03.234516
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:05.713784
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:09.599390
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612,W0613
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register = _get_codec_info
    register()



# Generated at 2022-06-17 19:01:12.422493
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:14.157821
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:15.918794
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:20.494522
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 19:02:23.324668
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:25.079130
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 19:02:26.989902
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:35.455862
# Unit test for function encode
def test_encode():
    """Test the function encode"""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode('abcdefgh') == (b'YWJjZGVmZ2g=', 8)

# Generated at 2022-06-17 19:02:37.706510
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:40.137352
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:42.316091
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert NAME in codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:44.622012
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:47.787162
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:04:56.883394
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:04:59.767880
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 19:05:02.665453
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:05:04.746606
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:05:08.094567
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:05:10.539887
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:05:18.884320
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 19:05:22.069598
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:05:24.639195
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:05:26.302093
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

