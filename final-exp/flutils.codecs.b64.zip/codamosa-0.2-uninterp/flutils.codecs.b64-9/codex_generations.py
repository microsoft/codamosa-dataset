

# Generated at 2022-06-17 18:57:01.997873
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:03.933049
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:05.864036
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:07.703579
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:10.336899
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:12.190289
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:14.039067
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:16.892829
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:19.881600
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:22.887725
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:27.947677
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:30.278961
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:32.066292
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 18:57:34.446276
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:37.430427
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:39.940253
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:50.608572
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:57:57.999122
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:58:01.279484
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:02.243066
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:10.083519
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:58:16.376635
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:58:25.338777
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 18:58:26.731911
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:28.270621
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:58:30.982814
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:32.816552
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:36.226897
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:46.729983
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:58:48.574038
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:03.488215
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:06.109570
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:12.835255
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test 1
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 2
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 3
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 4

# Generated at 2022-06-17 18:59:19.530035
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 7)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpag==') == (b'abcdefghij', 10)
    assert encode('YWJjZGVmZ2hpamY=')

# Generated at 2022-06-17 18:59:27.515479
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 18:59:36.814339
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # Test 1:
    #   Test that the function returns the expected bytes.
    text = '''
    aGVsbG8gd29ybGQ=
    '''
    expected = b'hello world'
    actual, _ = encode(text)
    assert actual == expected

    # Test 2:
    #   Test that the function returns the expected bytes.
    text = '''
    aGVsbG8gd29ybGQ=
    '''
    expected = b'hello world'
    actual, _ = encode(text)
    assert actual == expected

    # Test 3:
    #   Test that the function returns the expected bytes.
    text = '''
    aGVsbG8gd29ybGQ=
    '''

# Generated at 2022-06-17 18:59:38.262138
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:40.393091
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:49.318058
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('SGVsbG8gV29ybGQ=') == (b'Hello World', 14)
    assert encode('SGVsbG8gV29ybGQ=\n') == (b'Hello World', 15)
    assert encode('SGVsbG8gV29ybGQ=\n\n') == (b'Hello World', 16)
    assert encode('\nSGVsbG8gV29ybGQ=\n') == (b'Hello World', 17)
    assert encode('\n\nSGVsbG8gV29ybGQ=\n') == (b'Hello World', 18)

# Generated at 2022-06-17 18:59:50.990027
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:15.695973
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 7)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpag==') == (b'abcdefghij', 10)
    assert encode('YWJjZGVmZ2hpamY=')

# Generated at 2022-06-17 19:00:18.202927
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:28.199364
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)

# Generated at 2022-06-17 19:00:31.062008
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:37.776486
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 7)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpag==') == (b'abcdefghij', 10)
    assert encode('YWJjZGVmZ2hpamY=')

# Generated at 2022-06-17 19:00:41.208982
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 19:00:43.276172
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:44.835759
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:52.453408
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 19:01:00.091438
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 19:01:33.013575
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:35.564860
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:01:39.675288
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 19:01:42.784333
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:46.607001
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:49.129011
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:51.678366
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:01:54.202453
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:03.149303
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test the encode function with a simple string.
    assert encode('hello') == (b'hello', 5)

    # Test the encode function with a string that spans multiple lines.
    assert encode(
        '''
        hello
        '''
    ) == (b'hello', 5)

    # Test the encode function with a string that spans multiple lines
    # and is indented.
    assert encode(
        '''
            hello
        '''
    ) == (b'hello', 5)

    # Test the encode function with a string that spans multiple lines
    # and is indented.
    assert encode(
        '''
            hello
        '''
    ) == (b'hello', 5)

    # Test the encode function with a string that spans multiple lines
    # and is indented.
   

# Generated at 2022-06-17 19:02:05.929073
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:40.386346
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:43.177883
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:46.605865
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 19:02:48.312973
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:55.579806
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register(_get_codec_info)   # type: ignore

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'The codec is already registered.'

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'The codec is not registered.'



# Generated at 2022-06-17 19:02:57.410217
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:02:59.915289
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:03:01.625598
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:02.963007
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:03:04.943169
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:04:23.925343
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:25.970213
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:27.733308
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:33.286121
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n\n') == (b'hello world', 19)
   

# Generated at 2022-06-17 19:04:41.182781
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 19:04:49.300986
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 19:04:52.238028
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:04:55.463501
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:58.368681
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:05:01.532449
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None
