

# Generated at 2022-06-17 18:57:02.150524
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:03.812369
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:05.773979
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:08.511351
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:10.337671
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:12.190581
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:13.895937
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:15.444549
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:17.601115
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:20.287069
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:26.741343
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:57:27.761597
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:34.368729
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test the encode function with a valid base64 string.
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        len('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=')
    )

    # Test the encode function with a valid base64 string that spans
    # multiple lines.

# Generated at 2022-06-17 18:57:37.004403
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:39.860293
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:57:41.848650
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:44.984337
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:46.420156
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:49.751926
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:51.813985
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:01.484217
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:03.286766
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:06.728192
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:08.957949
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:11.532949
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:14.840732
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 18:58:18.228358
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:20.526409
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:21.974560
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:23.618885
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:40.764946
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:48.474956
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:58:52.659431
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:54.358128
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:56.631899
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:58.985873
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:02.399057
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:09.083237
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 18:59:17.847991
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test 1
    text = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual = encode(text)[0]
    assert actual == expected

    # Test 2
    text = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual = encode(text)[0]
    assert actual == expected

    # Test 3

# Generated at 2022-06-17 18:59:19.977961
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:49.755921
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:52.400689
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:53.831805
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:55.102015
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:57.780674
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:59.922745
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:00:02.278382
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:03.994791
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:00:12.351996
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n\n') == (b'', 0)


# Generated at 2022-06-17 19:00:15.694641
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:21.140628
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:22.551423
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:01:24.426111
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:27.298602
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:34.828540
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )

# Generated at 2022-06-17 19:01:38.698760
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:40.505806
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:01:44.781228
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode('abcdefgh') == (b'YWJjZGVmZ2g=', 8)

# Generated at 2022-06-17 19:01:55.080783
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The codec {NAME} is already registered.'
        )

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'The codec {NAME} is not registered.'
        )



# Generated at 2022-06-17 19:01:56.893633
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 19:03:05.120691
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 19:03:09.216502
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:03:11.224921
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:03:13.198528
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:14.910523
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:03:18.274064
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:03:27.379602
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 19:03:29.672229
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:32.764039
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:03:42.395391
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 19:06:18.609883
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:20.615514
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:24.596236
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:26.064512
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:06:28.226767
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 19:06:38.155301
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:06:41.593052
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:44.215266
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:46.840397
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:06:50.574034
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

