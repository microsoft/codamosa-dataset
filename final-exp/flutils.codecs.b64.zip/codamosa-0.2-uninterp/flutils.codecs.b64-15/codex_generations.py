

# Generated at 2022-06-17 18:57:00.419760
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)



# Generated at 2022-06-17 18:57:02.219576
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:57:04.301984
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:06.793942
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 18:57:09.468007
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:20.440142
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # Test 1:
    #   Test that the function returns the expected bytes.
    #   Test that the function returns the expected length.
    #   Test that the function raises an exception when given a
    #       non-base64 character string.
    #   Test that the function raises an exception when given a
    #       non-base64 character string.
    #   Test that the function raises an exception when given a
    #       non-base64 character string.
    #   Test that the function raises an exception when given a
    #       non-base64 character string.
    #   Test that the function raises an exception when given a
    #       non-base64 character string.
    #   Test that the function raises an exception when given a
    #       non-base64 character string.
    #   Test that the function

# Generated at 2022-06-17 18:57:22.328486
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:57:25.610146
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:33.199297
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test(
            text: str,
            expected_bytes: bytes,
            expected_length: int
    ) -> None:
        """Test the encode function."""
        actual_bytes, actual_length = encode(text)
        assert actual_bytes == expected_bytes
        assert actual_length == expected_length

    _test(
        text='',
        expected_bytes=b'',
        expected_length=0
    )
    _test(
        text='\n',
        expected_bytes=b'',
        expected_length=1
    )

# Generated at 2022-06-17 18:57:34.993752
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:57:38.231301
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:48.059909
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:57:57.302593
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:58:00.091213
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:10.442879
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 18:58:12.318107
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:14.991584
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:17.226469
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:20.198192
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:29.824614
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n\n') == (b'', 0)


# Generated at 2022-06-17 18:58:36.499302
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:38.994829
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:41.148634
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:42.388405
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:47.143923
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:48.933404
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:52.121269
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:54.659635
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None

# Generated at 2022-06-17 18:59:01.740028
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:59:08.795746
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 6)
    assert encode('YWJjZGU=') == (b'abcde', 7)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 10)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 11)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)

# Generated at 2022-06-17 18:59:14.165379
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:59:17.299626
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert NAME in codecs.getdecoder(NAME)
    assert NAME in codecs.getencoder(NAME)


# Generated at 2022-06-17 18:59:18.917753
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:27.211606
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('c3VyZS4=') == (b'sure.', 8)
    assert encode('c3VyZS4=\n') == (b'sure.', 9)
    assert encode('c3VyZS4=\n\n') == (b'sure.', 10)
    assert encode('c3VyZS4=\n\n\n') == (b'sure.', 11)
    assert encode('c3VyZS4=\n\n\n\n') == (b'sure.', 12)
    assert encode('c3VyZS4=\n\n\n\n\n') == (b'sure.', 13)

# Generated at 2022-06-17 18:59:29.181600
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:31.692964
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:35.278326
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:36.845338
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:39.471803
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:43.574322
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test_register():
        """Test the function register."""
        register()
        codecs.getdecoder(NAME)

    _test_register()



# Generated at 2022-06-17 18:59:52.617850
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:54.254553
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:03.981079
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('SGVsbG8gV29ybGQh') == (b'Hello World!', 16)
    assert encode('SGVsbG8gV29ybGQh\n') == (b'Hello World!', 17)
    assert encode('SGVsbG8gV29ybGQh\n\n') == (b'Hello World!', 18)
    assert encode('SGVsbG8gV29ybGQh\n\n\n') == (b'Hello World!', 19)
    assert encode('SGVsbG8gV29ybGQh\n\n\n\n') == (b'Hello World!', 20)

# Generated at 2022-06-17 19:00:12.357107
# Unit test for function encode
def test_encode():
    """Test the function encode"""
    # Test 1
    text = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual = encode(text)[0]
    assert expected == actual

    # Test 2
    text = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual = encode(text)[0]
    assert expected == actual

    # Test 3

# Generated at 2022-06-17 19:00:14.244432
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:17.177795
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:19.066223
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:24.785985
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:00:26.414765
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:27.971362
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:48.456327
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:58.483811
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 19:01:01.753675
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 19:01:05.001054
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:08.822345
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:19.422981
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test a simple string.
    text = 'Hello World'
    expected = b'SGVsbG8gV29ybGQ='
    actual = encode(text)[0]
    assert actual == expected

    # Test a string that spans multiple lines.
    text = '''
        Hello World
    '''
    expected = b'SGVsbG8gV29ybGQ='
    actual = encode(text)[0]
    assert actual == expected

    # Test a string that spans multiple lines and is indented.
    text = '''
        Hello World
    '''
    expected = b'SGVsbG8gV29ybGQ='
    actual = encode(text)[0]
    assert actual == expected

    # Test a string that spans multiple lines and is indented.


# Generated at 2022-06-17 19:01:20.765410
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:22.162956
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:27.899764
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 19:01:35.939639
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 19:02:12.143151
# Unit test for function register
def test_register():
    """Test that the codec is registered."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:13.733691
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:15.917936
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:19.041917
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:20.844982
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:22.917241
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:24.616182
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:33.936905
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:02:42.663002
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 6)
    assert encode('YWJjZGU=') == (b'abcde', 7)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 10)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 11)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)

# Generated at 2022-06-17 19:02:46.158372
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:07.926397
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:18.210236
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test a simple case.
    text = '''
        SGVsbG8sIHdvcmxkIQ==
    '''
    expected = b'Hello, world!'
    actual = encode(text)[0]
    assert actual == expected

    # Test a case with whitespace.
    text = '''
        SGVsbG8sIHdvcmxkIQ==
    '''
    expected = b'Hello, world!'
    actual = encode(text)[0]
    assert actual == expected

    # Test a case with whitespace.
    text = '''
        SGVsbG8sIHdvcmxkIQ==
    '''
    expected = b'Hello, world!'
    actual = encode(text)[0]
    assert actual == expected

    # Test

# Generated at 2022-06-17 19:04:25.045166
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 19:04:26.536809
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:29.310702
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:04:31.419953
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:40.629421
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 19:04:42.928434
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:44.533892
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:47.081938
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None

