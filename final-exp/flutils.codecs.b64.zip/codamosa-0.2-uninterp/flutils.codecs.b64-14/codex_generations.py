

# Generated at 2022-06-17 18:57:00.260042
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:02.073950
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:04.381289
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:57:10.666159
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpag==') == (b'abcdefghij', 10)

# Generated at 2022-06-17 18:57:13.389942
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:14.835195
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:57:16.783388
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:26.617802
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 18:57:30.040779
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:57:31.830806
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:45.389008
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:57:55.617431
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""
    assert encode('YWJjZA==') == (b'abcd', 6)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)
    assert encode('YWJjZA') == (b'abcd', 5)

# Generated at 2022-06-17 18:57:58.749274
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:00.733306
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:10.814074
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        28
    )
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (
        b'abcdefghijklmnopqrstuvwxyz',
        28
    )

# Generated at 2022-06-17 18:58:12.087855
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:22.831307
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 18:58:25.273040
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:26.899977
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:58:28.852159
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:39.041985
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:47.805279
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:58:57.303340
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def test_decode(
            data: _ByteString,
            errors: _STR = 'strict'
    ) -> Tuple[str, int]:
        """Test the function decode."""
        return '', 0

    # noinspection PyUnusedLocal
    def test_encode(
            text: _STR,
            errors: _STR = 'strict'
    ) -> Tuple[bytes, int]:
        """Test the function encode."""
        return b'', 0

    # noinspection PyUnusedLocal
    def test_get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        """Test the function _get_codec_info."""


# Generated at 2022-06-17 18:59:05.642471
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test 1
    text = '''
        SGVsbG8sIHdvcmxkIQ==
    '''
    expected = b'Hello, world!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 2
    text = '''
        SGVsbG8sIHdvcmxkIQ==
    '''
    expected = b'Hello, world!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 3
    text = '''
        SGVsbG8sIHdvcmxkIQ==
    '''
    expected = b'Hello, world!'
    actual, _ = encode(text)
    assert actual == expected

    # Test 4

# Generated at 2022-06-17 18:59:12.812460
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:59:19.500171
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:59:21.454790
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:23.358623
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:59:25.018642
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:59:33.437946
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test the function encode with a simple string.
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 15)

    # Test the function encode with a string that spans multiple lines.
    assert encode(
        """
        aGVsbG8gd29ybGQ=
        """
    ) == (b'hello world', 15)

    # Test the function encode with a string that spans multiple lines
    # and is indented.
    assert encode(
        """
        aGVsbG8gd29ybGQ=
        """
    ) == (b'hello world', 15)

    # Test the function encode with a string that spans multiple lines
    # and is indented.

# Generated at 2022-06-17 18:59:51.271546
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:53.684579
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:00.248593
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('Codec already registered.')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Codec not registered.')
    else:
        pass


# Generated at 2022-06-17 19:00:07.043136
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The codec {NAME!r} should not be registered.'
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'The codec {NAME!r} should be registered.'
        )
    else:
        pass

# Generated at 2022-06-17 19:00:09.741567
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:12.376108
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 19:00:14.661240
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 19:00:23.369971
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n\n') == (b'hello world', 19)
   

# Generated at 2022-06-17 19:00:25.859843
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:28.429329
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 19:01:05.060227
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:10.011494
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test_register():
        """Test the function register."""
        register()
        codecs.getdecoder(NAME)
    _test_register()



# Generated at 2022-06-17 19:01:12.813498
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:01:14.582180
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:01:22.407036
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test that the function encode works with a simple string.
    assert encode('aGVsbG8=') == (b'hello', 6)

    # Test that the function encode works with a string that spans
    # multiple lines.
    assert encode('aGVsbG8=\n') == (b'hello', 7)

    # Test that the function encode works with a string that spans
    # multiple lines and is indented.
    assert encode('    aGVsbG8=\n') == (b'hello', 11)

    # Test that the function encode works with a string that spans
    # multiple lines and is indented.
    assert encode('    aGVsbG8=\n    ') == (b'hello', 13)

    # Test that the function encode works with a string that spans


# Generated at 2022-06-17 19:01:23.720741
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:25.471385
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:27.299529
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:01:28.960615
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:29.997588
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:07.048073
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:16.619818
# Unit test for function encode
def test_encode():
    """Test the function encode"""
    # Test the function encode with a simple string.
    assert encode('aGVsbG8=') == (b'hello', 6)

    # Test the function encode with a string that spans multiple lines.
    assert encode(
        '''
        aGVsbG8=
        '''
    ) == (b'hello', 6)

    # Test the function encode with a string that spans multiple lines
    # and is indented.
    assert encode(
        '''
            aGVsbG8=
        '''
    ) == (b'hello', 6)

    # Test the function encode with a string that spans multiple lines
    # and is indented.
    assert encode(
        '''
            aGVsbG8=
        '''
    ) == (b'hello', 6)



# Generated at 2022-06-17 19:02:19.632790
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:22.916990
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:24.556413
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:26.946804
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:29.566495
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:37.547507
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )

# Generated at 2022-06-17 19:02:38.900120
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:02:40.355590
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:59.502637
# Unit test for function register
def test_register():
    """Test the function register()"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:02.342200
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:04.099406
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:05.968733
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:16.121924
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 19:04:18.226011
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:25.060035
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 19:04:31.078501
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n\n') == (b'hello world', 19)
   

# Generated at 2022-06-17 19:04:34.294287
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:04:41.885443
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test a simple base64 string.
    text = 'SGVsbG8gV29ybGQ='
    out = encode(text)
    assert out == (b'Hello World', len(text))

    # Test a base64 string that spans multiple lines.
    text = '''
        SGVsbG8gV29ybGQ=
    '''
    out = encode(text)
    assert out == (b'Hello World', len(text))

    # Test a base64 string that spans multiple lines and is indented.
    text = '''
        SGVsbG8gV29ybGQ=
    '''
    out = encode(text)
    assert out == (b'Hello World', len(text))

    # Test a base64 string that spans multiple lines and is