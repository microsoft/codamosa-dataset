

# Generated at 2022-06-17 18:57:04.243844
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:06.166018
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:09.267049
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:57:11.167704
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:12.874772
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:14.639430
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:57:16.669359
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 18:57:21.849005
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:57:23.438796
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:25.365452
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:34.944175
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:57:37.745996
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:47.325619
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 18:57:50.682145
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-17 18:57:52.653217
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:55.913822
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:58.269638
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:58:02.737460
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:58:05.660110
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:58:08.488150
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:19.023457
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:21.963473
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:30.136358
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n\n') == (b'', 0)


# Generated at 2022-06-17 18:58:31.750735
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:35.235132
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:37.285784
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:46.791051
# Unit test for function register
def test_register():
    """Test the register function."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        return None

    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            'The codec should not be registered.'
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'The codec should be registered.'
        )



# Generated at 2022-06-17 18:58:56.571262
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 18:59:05.356462
# Unit test for function encode
def test_encode():
    """Test the function encode"""
    # Test that the function encode works with a string that is a
    # single line.
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)

    # Test that the function encode works with a string that is
    # multiple lines.
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)

    # Test that the function encode works with a string that is
    # multiple lines and has indentation.
    assert encode('    aGVsbG8gd29ybGQ=\n') == (b'hello world', 19)

    # Test that the function encode works with a string that is
    # multiple lines and has indentation.

# Generated at 2022-06-17 18:59:07.587519
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:17.891360
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:59:20.287627
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:27.851942
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 7)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpag==') == (b'abcdefghij', 10)

# Generated at 2022-06-17 18:59:31.066503
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:38.551367
# Unit test for function encode
def test_encode():
    # Test 1
    text = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual, _ = encode(text)
    assert actual == expected

    # Test 2
    text = '''
    YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    '''
    expected = b'abcdefghijklmnopqrstuvwxyz'
    actual, _ = encode(text)
    assert actual == expected

    # Test 3

# Generated at 2022-06-17 18:59:48.488889
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:59:50.989266
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:53.409647
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:59:54.925471
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:56.876835
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:07.257540
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:09.495249
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:00:11.871162
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:00:13.753721
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:00:16.820424
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:19.314374
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:21.496747
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 19:00:29.865401
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test the encode function with a valid base64 string.
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 13)

    # Test the encode function with an invalid base64 string.
    try:
        encode('aGVsbG8gd29ybGQ')
    except UnicodeEncodeError as e:
        assert e.reason == (
            "'aGVsbG8gd29ybGQ' is not a proper bas64 character string: "
            "Incorrect padding"
        )
    else:
        raise AssertionError(
            'Expected UnicodeEncodeError to be raised.'
        )



# Generated at 2022-06-17 19:00:35.889213
# Unit test for function register
def test_register():
    """Test the function register."""
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """Test the function register."""

        def test_register(self):
            """Test the function register."""
            # Remove the 'b64' codec from the codecs registry.
            try:
                del sys.modules['b64']
            except KeyError:
                pass

            # Register the 'b64' codec.
            register()

            # Verify that the 'b64' codec is in the codecs registry.
            self.assertIn(NAME, codecs.__all__)

    unittest.main()



# Generated at 2022-06-17 19:00:38.057106
# Unit test for function register
def test_register():
    """Test function register()"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:57.698980
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:00:59.696860
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:02.319329
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:12.275237
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n\n') == (b'', 0)

# Generated at 2022-06-17 19:01:15.210120
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:17.109434
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:24.460517
# Unit test for function register
def test_register():
    """Test the function register."""
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """Test the function register."""

        def test_register(self):
            """Test the function register."""
            # Remove the b64 codec from the codec registry.
            try:
                del sys.modules[__name__].__loader__.decode_error
            except AttributeError:
                pass
            try:
                del sys.modules[__name__].__loader__.encode_error
            except AttributeError:
                pass
            try:
                del sys.modules[__name__].__loader__.name
            except AttributeError:
                pass
            try:
                del sys.modules[__name__].__loader__.state
            except AttributeError:
                pass
           

# Generated at 2022-06-17 19:01:26.980171
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:29.794129
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-17 19:01:31.265154
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-17 19:02:16.232091
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 19:02:19.277918
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:21.085119
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:23.097509
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:25.287749
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:28.171512
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:30.558095
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:33.275782
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:34.848092
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:37.440603
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:03:57.933573
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:03:59.711622
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:03.694547
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:04:05.262334
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:09.136881
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:12.144559
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert NAME == codecs.getdecoder(NAME)[0].name
    assert NAME == codecs.getencoder(NAME)[0].name



# Generated at 2022-06-17 19:04:14.976717
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 19:04:18.143763
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:19.657530
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:22.160297
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:07:00.728640
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

