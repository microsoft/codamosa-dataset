

# Generated at 2022-06-17 18:57:00.419603
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:02.701068
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:04.528369
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:07.211126
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:09.868287
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:12.986701
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:19.337222
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:57:22.463159
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:31.628645
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n\n') == (b'hello world', 19)
   

# Generated at 2022-06-17 18:57:34.305592
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:39.939411
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:45.413031
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)

# Generated at 2022-06-17 18:57:47.652783
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    from b64codec import register
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:50.745182
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 18:57:52.653563
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:53.956983
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:56.565359
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:07.893526
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test_encode(
            text: _STR,
            expected_bytes: bytes,
            expected_length: int
    ) -> None:
        """Test the function encode."""
        actual_bytes, actual_length = encode(text)
        assert actual_bytes == expected_bytes
        assert actual_length == expected_length

    # Test the function encode.
    _test_encode(
        text='',
        expected_bytes=b'',
        expected_length=0
    )
    _test_encode(
        text='\n',
        expected_bytes=b'',
        expected_length=1
    )

# Generated at 2022-06-17 18:58:09.523364
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:11.235062
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:19.305486
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:29.046533
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:58:30.674198
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:32.623840
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:43.116278
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 18:58:44.825759
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:58:46.462821
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:58:56.188198
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test(text: _STR, expected: bytes) -> None:
        """Test the function encode."""
        out, length = encode(text)
        assert out == expected
        assert length == len(text)

    _test(
        text='',
        expected=b''
    )
    _test(
        text='\n',
        expected=b''
    )
    _test(
        text='\n\n',
        expected=b''
    )
    _test(
        text='\n\n\n',
        expected=b''
    )
    _test(
        text='\n\n\n\n',
        expected=b''
    )
   

# Generated at 2022-06-17 18:58:57.990839
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.lookup(NAME)


# Generated at 2022-06-17 18:59:00.013875
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:59:24.096105
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVm') == (b'abcdef', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 9)
    assert encode('YWJjZGVmZ2hpag==') == (b'abcdefghij', 10)

# Generated at 2022-06-17 18:59:27.278159
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:36.681127
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test 1
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 2
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 3
    text = '''
        SGVsbG8gV29ybGQh
    '''
    expected = b'Hello World!'
    actual = encode(text)[0]
    assert actual == expected

    # Test 4

# Generated at 2022-06-17 18:59:38.486270
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 18:59:40.776549
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:42.591516
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:45.438306
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:59:47.973656
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:51.866836
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:54.233696
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:32.904798
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:00:36.815826
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:39.886120
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:00:45.331139
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test_register():
        """Test the function register."""
        codecs.getdecoder(NAME)

    # Test that the codec is not registered.
    with pytest.raises(LookupError):
        _test_register()

    # Register the codec.
    register()

    # Test that the codec is registered.
    _test_register()



# Generated at 2022-06-17 19:00:47.407378
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:57.448420
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('aGVsbG8=\n') == (b'hello', 7)
    assert encode('aGVsbG8=\n\n') == (b'hello', 8)
    assert encode('aGVsbG8=\n\n\n') == (b'hello', 9)
    assert encode('aGVsbG8=\n\n\n\n') == (b'hello', 10)
    assert encode('aGVsbG8=\n\n\n\n\n') == (b'hello', 11)
    assert encode('aGVsbG8=\n\n\n\n\n\n') == (b'hello', 12)
   

# Generated at 2022-06-17 19:01:05.565106
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test that encode returns the correct value
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:01:07.418375
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:01:09.376239
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:01:19.885826
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )

# Generated at 2022-06-17 19:01:54.165811
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:55.732976
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:01:58.565798
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:00.171580
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:02:02.244285
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:12.387353
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 29)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 30)

# Generated at 2022-06-17 19:02:15.203751
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:19.091663
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:22.084380
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 19:02:24.024714
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:37.031355
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:03:39.847096
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:03:41.568043
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:03:44.250392
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:47.532830
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:49.202701
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:03:52.385385
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:03:54.214772
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:03:55.652318
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:03:58.804139
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:29.827432
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:06:39.064217
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:06:41.354275
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:06:43.238296
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:06:45.103316
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:06:48.737409
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:06:51.783010
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:06:53.434034
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:06:55.368451
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)

