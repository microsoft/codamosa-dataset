

# Generated at 2022-06-17 18:56:58.235193
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:01.068364
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:57:03.490552
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 18:57:06.193347
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:14.541866
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 18:57:17.710447
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:20.543288
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:23.873250
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:25.359101
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:29.867763
# Unit test for function register
def test_register():
    """Test the function register."""
    # pylint: disable=W0212
    # noinspection PyProtectedMember
    codecs._cache.clear()
    codecs.encode = None
    codecs.decode = None
    register()
    assert codecs.encode(b'', NAME) == (b'', 0)
    assert codecs.decode(b'', NAME) == ('', 0)

# Generated at 2022-06-17 18:57:33.102209
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:35.714612
# Unit test for function register
def test_register():
    """Test the function register()"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:36.491265
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:57:40.557581
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=\n\n') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:57:43.556669
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:47.309192
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:57:50.008908
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 18:57:58.298479
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n') == (b'', 0)
    assert encode('\n\n\n\n\n\n\n\n') == (b'', 0)


# Generated at 2022-06-17 18:58:01.185844
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:03.778990
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:08.959560
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:15.654994
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    # Test a simple case.
    assert encode('YWJj') == (b'abc', 4)

    # Test a case with whitespace.
    assert encode('YWJj\n') == (b'abc', 4)

    # Test a case with whitespace and indentation.
    assert encode('  YWJj\n') == (b'abc', 4)

    # Test a case with whitespace and indentation.
    assert encode('  YWJj\n') == (b'abc', 4)

    # Test a case with whitespace and indentation.
    assert encode('  YWJj\n') == (b'abc', 4)

    # Test a case with whitespace and indentation.

# Generated at 2022-06-17 18:58:17.351862
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:20.309479
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:29.823909
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo') == (b'abcdefghijklmnopqrstuvwxyz', 28)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo==') == (b'abcdefghijklmnopqrstuvwxyz', 28)

# Generated at 2022-06-17 18:58:31.748890
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:58:36.040122
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:38.937321
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 18:58:41.818025
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:44.072505
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:53.645579
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:58:57.409306
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:05.708704
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd29ybGQ=\n') == (b'hello world', 15)
    assert encode('aGVsbG8gd29ybGQ=\n\n') == (b'hello world', 16)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n') == (b'hello world', 17)
    assert encode('aGVsbG8gd29ybGQ=\n\n\n\n') == (b'hello world', 18)

# Generated at 2022-06-17 18:59:07.478243
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:17.111979
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test(text: str, expected: bytes):
        """Test the given ``text`` against the given ``expected`` bytes."""
        actual, _ = encode(text)
        assert actual == expected

    _test(
        text="""
            YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
        """,
        expected=b'abcdefghijklmnopqrstuvwxyz'
    )


# Generated at 2022-06-17 18:59:19.247625
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 18:59:21.315327
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:23.216232
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-17 18:59:25.183911
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:28.618461
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register the b64 codec.'



# Generated at 2022-06-17 18:59:46.612963
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 18:59:49.235657
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 18:59:51.915687
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 18:59:54.279790
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:04.017897
# Unit test for function encode
def test_encode():
    """Test the function encode"""
    # Test with a simple string
    assert encode('Hello World') == (b'SGVsbG8gV29ybGQ=', 11)

    # Test with a string that spans multiple lines
    assert encode('Hello\nWorld') == (b'SGVsbG8gV29ybGQ=', 11)

    # Test with a string that spans multiple lines and has indentation
    assert encode('Hello\n  World') == (b'SGVsbG8gV29ybGQ=', 11)

    # Test with a string that spans multiple lines and has indentation
    assert encode('Hello\n\n  World') == (b'SGVsbG8gV29ybGQ=', 11)

    # Test with a string that spans multiple lines and has indentation

# Generated at 2022-06-17 19:00:12.371687
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:00:16.095762
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:17.524606
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:00:21.044631
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:00:24.024344
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:06.278421
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmno', 14)

# Generated at 2022-06-17 19:01:08.005053
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:01:10.454964
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:13.581364
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:16.531572
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:01:23.900899
# Unit test for function encode
def test_encode():
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('Zm9vYg==') == (b'foob', 6)
    assert encode('Zm9vYmE=') == (b'fooba', 7)
    assert encode('Zm9vYmFy') == (b'foobar', 8)
    assert encode('Zm9vYmFyIQ==') == (b'foobar!', 10)
    assert encode('Zm9vYmFyISE=') == (b'foobar!!', 11)
    assert encode('Zm9vYmFyISEh') == (b'foobar!!!', 12)
    assert encode('Zm9vYmFyISEhIQ==') == (b'foobar!!!!', 14)

# Generated at 2022-06-17 19:01:28.877615
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test that the encode function works.
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)

    # Test that the encode function works with a UserString.
    assert encode(UserString('aGVsbG8gd29ybGQ=')) == (b'hello world', 14)

    # Test that the encode function works with a multiline string.
    assert encode(
        '''
        aGVsbG8gd29ybGQ=
        '''
    ) == (b'hello world', 14)

    # Test that the encode function works with a multiline string.

# Generated at 2022-06-17 19:01:30.439872
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:01:32.426430
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-17 19:01:34.686709
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:10.806414
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:13.555895
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-17 19:02:15.775020
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:26.365148
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('YQ==')[0] == b'a'
    assert encode('YWI=')[0] == b'ab'
    assert encode('YWJj')[0] == b'abc'
    assert encode('YWJjZA==')[0] == b'abcd'
    assert encode('YWJjZGU=')[0] == b'abcde'
    assert encode('YWJjZGVm')[0] == b'abcdef'
    assert encode('YWJjZGVmZw==')[0] == b'abcdefg'
    assert encode('YWJjZGVmZ2g=')[0] == b'abcdefgh'
    assert encode('YWJjZGVmZ2hp')[0] == b

# Generated at 2022-06-17 19:02:29.131208
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:02:30.757517
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:32.278940
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:02:39.124805
# Unit test for function register
def test_register():
    """Test the function register."""
    from codecs import getdecoder
    from codecs import getencoder
    from codecs import getincrementaldecoder
    from codecs import getincrementalencoder
    from codecs import lookup

    # Register the b64 codec.
    register()

    # Verify that the codec was registered.
    assert lookup(NAME) is not None
    assert getdecoder(NAME) is not None
    assert getencoder(NAME) is not None
    assert getincrementaldecoder(NAME) is not None
    assert getincrementalencoder(NAME) is not None



# Generated at 2022-06-17 19:02:42.566011
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:02:46.023088
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:07.718545
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:18.050972
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGU=') == (b'abcde', 6)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 8)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 10)
    assert encode('YWJjZGVmZ2hpamts') == (b'abcdefghijkl', 12)
    assert encode('YWJjZGVmZ2hpamtsbW5vcA==') == (b'abcdefghijklmnop', 16)

# Generated at 2022-06-17 19:04:20.733170
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-17 19:04:23.147787
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-17 19:04:25.827736
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-17 19:04:27.994047
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-17 19:04:29.592790
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-17 19:04:32.674434
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-17 19:04:34.195586
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-17 19:04:41.794842
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('Zm9vYmFy') == (b'foobar', 8)
    assert encode('Zm9vYmFy\n') == (b'foobar', 9)
    assert encode('Zm9vYmFy\n\n') == (b'foobar', 10)
    assert encode('Zm9vYmFy\n\n\n') == (b'foobar', 11)
    assert encode('Zm9vYmFy\n\n\n\n') == (b'foobar', 12)
    assert encode('Zm9vYmFy\n\n\n\n\n') == (b'foobar', 13)