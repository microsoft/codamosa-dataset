

# Generated at 2022-06-23 17:42:41.276514
# Unit test for function encode
def test_encode():
    """Test :func:`~b64.encode`"""
    import doctest
    doctest.testmod(b64)


# Generated at 2022-06-23 17:42:49.084939
# Unit test for function encode
def test_encode():
    str = 'hello world'
    str_b64 = 'aGVsbG8gd29ybGQ='
    bytes_, size = encode(str)
    if bytes_ != str_b64.encode():
        raise ValueError
    if size != len(str):
        raise ValueError
    str_b64 = 'aGVsbG8gd29y\nbGQ='
    bytes_, size = encode(str_b64)
    if bytes_ != str_b64.replace('\n','').encode():
        raise ValueError
    if size != len(str_b64):
        raise ValueError
    str_b64 = 'aGVsbG8gd29y\nbGQ=  '
    bytes_, size = encode(str_b64)

# Generated at 2022-06-23 17:42:59.444224
# Unit test for function encode
def test_encode():
    """Test the ``encode()`` function."""
    registered = False
    try:
        codecs.getencoder(NAME)
        registered = True
    except LookupError:
        register()
        registered = False


# Generated at 2022-06-23 17:43:02.123559
# Unit test for function decode
def test_decode():
    # GIVEN
    data = b'\x02\x03\x01\x00'

    # WHEN
    ans, consumed = decode(data)

    # THEN
    assert ans == 'AjEE'
    assert consumed == 4

# Generated at 2022-06-23 17:43:05.101148
# Unit test for function decode
def test_decode():
    assert(decode(b'\x01\x02\x03\x04') == ('AQIDBA==', 4))
    assert(decode(b'\x01\x02\x03\x04', 'strict') == ('AQIDBA==', 4))


# Generated at 2022-06-23 17:43:16.888382
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import os
    from unittest import TestCase
    from contextlib import redirect_stdout, redirect_stderr

    # Save current values in case they need to be restored.
    _stderr = sys.stderr
    _stdout = sys.stdout

    # Test that the registration does not happen on a dummy file.
    with open(os.devnull, 'w') as f_null:
        with redirect_stdout(f_null):
            with redirect_stderr(f_null):
                register()

        try:
            codecs.getdecoder(NAME)
            test_1 = True
        except LookupError:
            test_1 = False
        TestCase().assertFalse(test_1)


# Generated at 2022-06-23 17:43:27.778328
# Unit test for function encode
def test_encode():
    input_text = """\
        dGVzdGluZyB0byBzZWUgaWYgZXJyb3IgaXMgdGhyb3du\
        IGNvcnJlY3RseQ==
        """

    expected = b'testing to see if error is thrown correctly'

    actual = encode(input_text)
    assert actual == (expected, 76)

    input_text = """\
        dGVzdGluZyB0byBzZWUgaWYgZXJyb3IgaXMgdGhyb3du\
        b3V0IGhhdmluZyBhbm90aGVyIEVSUiAbskssYWlk\
        JSE=
        """

# Generated at 2022-06-23 17:43:29.993630
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    register()
    # Register only needs to be called once.  Register it again to test
    # for the LookupError.
    register()



# Generated at 2022-06-23 17:43:42.500793
# Unit test for function decode
def test_decode():
    """Unit test of function 'decode'."""

# Generated at 2022-06-23 17:43:49.726554
# Unit test for function decode
def test_decode():
    """This is the unit test for the ``decode`` function"""

    # Test for line wrap and indentation
    test_data = """
        YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=
    """
    expected_result = 'abcdefghijklmnopqrstuvwxyz'

    # Decode the test data.
    actual_result = decode(test_data)

    # Test that the actual result is the expected result.
    assert expected_result == actual_result

    # Test that the actual result is the expected result.
    assert expected_result == actual_result[0]



# Generated at 2022-06-23 17:44:02.171536
# Unit test for function decode
def test_decode():
    """Unit test function to ensure that the function works properly."""
    # Simple test
    val = b'b64 decode this'
    exp = 'YjY0IGRlY29kZSB0aGlz'
    act = decode(val)[0]
    assert exp == act

    # Test with newlines
    val = b'\n      b64  \n  decode\n  this'
    exp = 'YjY0IGRlY29kZSB0aGlz'
    act = decode(val)[0]
    assert exp == act

    # Test with indentation
    val = '    b64 decode this    \n    \n'
    exp = 'YjY0IGRlY29kZSB0aGlz'
    act = decode(val)[0]
    assert exp == act

    #

# Generated at 2022-06-23 17:44:14.514883
# Unit test for function encode
def test_encode():
    assert encode('ZG9jdW1lbnQgY2'
                  'xpZW50\nIHNpZGUKZG9jdW1lb'
                  'nQgc2lkZQo=') == (b'document client\nside\n'
                                    b'document side\n',
                                    41)
    assert encode('ZG9jdW1lbnQgY2'
                  'xpZW50\nIHNpZGU=') == (b'document client\nside', 34)

# Generated at 2022-06-23 17:44:17.122618
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error(NAME)
    codecs.lookup(NAME)
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:44:25.362205
# Unit test for function decode
def test_decode():
    to_decode = b'YWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpam'
    decoded = decode(to_decode)
    assert decoded[0] == 'YWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpam'
    assert decoded[1] == len(to_decode)

#Unit test for function encode

# Generated at 2022-06-23 17:44:26.638474
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()



# Generated at 2022-06-23 17:44:32.586450
# Unit test for function register
def test_register():
    assert _get_codec_info(NAME).name == NAME


if __name__ == '__main__':
    print(__doc__)
    register()
    from base64_codec.test import test_main
    test_main()

# Generated at 2022-06-23 17:44:42.547987
# Unit test for function encode
def test_encode():
    print("Testing encode()...", end="")

    # Given blank text with no characters.
    assert encode('') == (b'', 0)

    # Given blank text with indented and new lines.
    assert encode('   \n   \n   ') == (b'', 0)

    # Given text with non-base64 characters.
    try:
        encode('foo')
        assert False
    except UnicodeEncodeError:
        pass

    # Given text with base64 characters.
    assert encode('YWJjZA==') == (b'abcd', 6)

    # Given multi line text.
    assert encode(
        """
        aGVsbG8=
        d29ybGQ=
        """
    ) == (b'helloworld', 13)

    print("Passed.")


# Unit test

# Generated at 2022-06-23 17:44:53.930956
# Unit test for function decode
def test_decode():
    expected_str = 'This is a test\n of the emergency broadcast system.'

# Generated at 2022-06-23 17:45:05.068912
# Unit test for function decode
def test_decode():
    """Unit test for the function decode."""

    # Making sure the test works.
    assert decode(b'AAAAAAAAAAA=') == ('AAAAAAAAAAA=', 12)

    # Test with a valid base64 character string.

# Generated at 2022-06-23 17:45:15.652314
# Unit test for function encode
def test_encode():
    import base64
    DIGITS = (
        b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/\n'
    )

    for i in range(0, 256):
        # The base64 encoding for the integer value, 'i'
        text = DIGITS[i:i+1].decode('utf-8')

        # Encode the base64 text into bytes.
        result, num_chars = encode(text)

        # Expect the first byte in the result to be the integer value, 'i'.
        assert result == bytes([i])

        # Expect the number of characters encoded to be 1.
        assert num_chars == 1



# Generated at 2022-06-23 17:45:17.319316
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-23 17:45:23.634984
# Unit test for function decode
def test_decode():
    inp = ('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        'AAAA')
    data = inp.encode('utf-8')
    out, num = decode(data)
    assert out == inp and num == len(data)



# Generated at 2022-06-23 17:45:35.702212
# Unit test for function encode
def test_encode():
    # pylint: disable=C0103
    """Unit test for ``b64.encode()``."""
    print(f'{NAME}.encode()')

    # Valid base64 input.
    text = '''
        eyJjb2RlIjogImZpdmUiLCAiZGF0YSI6ICJ0ZXN0IG9uZSIsICJ0eXBlIjog
        InRlc3QifQ==
        '''
    data_expected = b'{"code": "five", "data": "test one", "type": "test"}'

    # Encode the text.
    data_actual, _len = encode(text)

    # Verify the 'data_actual' value.
    assert data_expected == data_actual

    # Perform the same test, but give a User

# Generated at 2022-06-23 17:45:43.305985
# Unit test for function decode
def test_decode():
    """Test that the :obj:`b64.decode` function works as expected."""
    # noinspection PyUnusedLocal,PyShadowingNames
    def test_case(
            data: bytes,
            expected: str,
            errors: Optional[str] = None
    ):
        """
        Test that the :obj:`b64.decode` function returns the correct
        string.

        Args:
            data (bytes): The bytes to be decoded.
            expected (str): The expected output.
            errors (str or :obj:`~UserString`): The error to raise.
        """
        # Call the :obj:`b64.decode` function
        actual = decode(data)

        # Assert that the first return value is the expected value.
        assert actual[0] == expected

        # Assert that

# Generated at 2022-06-23 17:45:45.672922
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhc3VyZQ==') == (b'any carnal pleasure', 26)



# Generated at 2022-06-23 17:45:49.695082
# Unit test for function decode
def test_decode():
    txt_bytes = '''
        Hello,
        World!
    '''
    txt_bytes = codecs.encode(txt_bytes, 'utf-8')
    rd_txt = codecs.decode(txt_bytes, NAME)
    assert rd_txt == 'SGVsbG8sDQpXT3JsZCE='
    return



# Generated at 2022-06-23 17:45:58.066362
# Unit test for function encode
def test_encode():
    """Test function :func:`~b64_codec.encode`"""

    def _encode(text: _STR):
        """Test each of the item in 'b64_raw' and 'b64_urlsafe'."""
        utf8_text = str(text).encode('utf-8')
        expected = base64.b64decode(utf8_text)
        actual, length = encode(text)
        assert len(actual) == length
        assert actual == expected

    # Test for 'encode' function.

# Generated at 2022-06-23 17:46:09.249531
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""
    # Test basic encoding
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 3)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)

    # Test different input whitespace
    assert encode(' YWI= ') == (b'ab', 3)
    assert encode('Y W I=') == (b'ab', 3)
    assert encode('YWI =') == (b'ab', 3)
    assert encode('Y \n W \n I =') == (b'ab', 3)
    assert encode('Y \n \n W \n \n I =') == (b'ab', 3)

# Generated at 2022-06-23 17:46:10.052915
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 17:46:21.724362
# Unit test for function encode
def test_encode():
    # Test that the encode function behaves as expected.
    text = (
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ\n'
        'abcdefghijklmnopqrstuvwxyz\n'
        '0123456789+/\n'
        '\n'
        '\n'
        '   \n'
    )
    expected = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    assert encode(text)[0] == expected

    # Test that if 'text' is not a base64 character string, then the
    # 'UnicodeEncodeError' is raised.
    text = 'A~'

# Generated at 2022-06-23 17:46:24.335481
# Unit test for function decode
def test_decode():
    assert decode(b'AAAA')[0] == 'QUFB\n'
    assert decode(bytes([0, 0]))[0] == '/w==\n'


# Generated at 2022-06-23 17:46:30.945623
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``.
    """
    assert encode('U0ZC') == (b'\x00\x00\x00\x00', 4)
    assert encode('Z0ZC') == (b'\x00\x00\x00\x01', 4)
    assert encode('Y0ZC') == (b'\x00\x00\x00\x02', 4)
    assert encode('X0ZC') == (b'\x00\x00\x00\x03', 4)
    assert encode('W0ZC') == (b'\x00\x00\x00\x04', 4)
    assert encode('WUZC') == (b'\x00\x00\x00\x05', 4)

# Generated at 2022-06-23 17:46:35.679401
# Unit test for function encode
def test_encode():
    text = """
        L3RleHQgdGVzdHMKICAgICAgICBvbiB0d28gbGluZXM=
    """
    out_bytes, out_int = encode(text)
    assert out_bytes == b'text tests\n    on two lines'
    assert out_int == len(text)



# Generated at 2022-06-23 17:46:46.143597
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('aa') == (b'aa', 2)
    assert encode('aaa') == (b'aaa', 3)
    assert encode('aaaa') == (b'aaaa', 4)
    assert encode('aaaaa') == (b'aaaaa', 5)
    assert encode('aaaaaa') == (b'aaaaaa', 6)
    assert encode('aaaaaaa') == (b'aaaaaaa', 7)
    assert encode('aaaaaaaa') == (b'aaaaaaaa', 8)
    assert encode('aaaaaaaaa') == (b'aaaaaaaaa', 9)
    assert encode('aaaaaaaaaa') == (b'aaaaaaaaaa', 10)
    assert encode('aaaaaaaaaaa') == (b'aaaaaaaaaaa', 11)


# Generated at 2022-06-23 17:46:48.459984
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-23 17:46:53.444237
# Unit test for function encode
def test_encode():
    assert encode('QQ==')[0] == b'A'
    assert encode('aGVsbG8gd29ybGQ=')[0] == b'hello world'
    assert encode('aGVsbG8gd29ybGQK')[0] == b'hello world'



# Generated at 2022-06-23 17:46:56.535942
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Error: Codec "b64" was not registered.'
    else:
        assert True

# Generated at 2022-06-23 17:46:58.693267
# Unit test for function decode
def test_decode():
    """Test the `decode` function."""
    assert decode(b'SGVsbG8='), 5


# Generated at 2022-06-23 17:47:09.757248
# Unit test for function decode
def test_decode():
    assert(decode(b'\x01\x00\x00\x00\x00\x00\x00\x01') == 
                       ('AQAAAAAAAAE=', 8))
    assert(decode(b'\x00\x00\x00\x00\x00\x00\x00\x00') == 
                       ('AAAAAAAAAAA=', 8))
    assert(decode(b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF') == 
                       ('/////////+8=', 9))
    assert(decode(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00') == 
                       ('AAAAAAAAAAAA', 9))

# Generated at 2022-06-23 17:47:20.726183
# Unit test for function register
def test_register():
    """Assert that the return value of 'register()' meets some reasonable
    assuptions.
    """
    register()
    assert hasattr(codecs, 'b64_encode'), "Could not find 'b64_encode' in codecs"
    assert hasattr(codecs, 'b64_decode'), "Could not find 'b64_decode' in codecs"

    assert codecs.b64_encode.__name__ == 'encode', (
        "The 'b64_encode' attribute of the codecs module does not have the"
        " name 'encode'"
    )
    codecs.b64_decode  # noqa: F841
    # assert codecs.b64_decode.__name__ == 'decode', (
    #     "The 'b64_decode

# Generated at 2022-06-23 17:47:33.396854
# Unit test for function decode
def test_decode():
    # Test a normal case.
    out_bytes, _ = decode(b'\x01')
    assert out_bytes == 'AQ=='

    # Test a large number of bytes.
    out_bytes, _ = decode(bytearray(range(100)))

# Generated at 2022-06-23 17:47:39.760314
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    assert decode(b'') == ('', 0), "Expected: decode(b'') == ('', 0)"

    assert decode(b'\x01') == ('AQ==', 1), \
        "Expected: decode(b'\\x01') == ('AQ==', 1)"

    assert decode(b'\x00\x00\x00') == ('AAAA', 3), \
        "Expected: decode(b'\\x00\\x00\\x00') == ('AAAA', 3)"

    assert decode(b'\x01\x00\x00') == ('AQAA', 3), \
        "Expected: decode(b'\\x01\\x00\\x00') == ('AQAA', 3)"


# Generated at 2022-06-23 17:47:42.828591
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert NAME in codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:47:48.199711
# Unit test for function register
def test_register():
    """Test for function :func:`register`"""
    codecs_name = NAME
    codecs.register(_get_codec_info)
    codecs.register(_get_codec_info)
    codecs.register(_get_codec_info)

    assert NAME == codecs.getdecoder(codecs_name)[0].__name__



# Generated at 2022-06-23 17:47:57.005069
# Unit test for function encode
def test_encode():
    # pylint: disable=C0116
    from .codec_b64 import encode as func
    from .codec_b64 import decode as func2

    # pylint: disable=C0116
    from .codec_b64 import codec_info  # type: ignore

    assert codec_info.name == 'b64'
    assert codec_info.encode == func
    assert codec_info.decode == func2


    empty_text = ''.encode('utf-8')
    text_bytes = 'YQ=='.encode('utf-8')
    text_bytes2 = 'YWI='.encode('utf-8')
    text_bytes3 = 'YWJj'.encode('utf-8')
    empty = bytes()
    a = b'a'
    ab = b'ab'

# Generated at 2022-06-23 17:48:03.135242
# Unit test for function register
def test_register():
    """Unit test the ``register()`` function."""
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # noinspection PyUnresolvedReferences
    assert isinstance(
        codecs.__dict__['_cache']['lookup'][NAME],
        codecs.CodecInfo
    )

# Generated at 2022-06-23 17:48:07.822381
# Unit test for function register
def test_register():
    """
    >>> print(codecs.lookup(NAME))
    <codecs.CodecInfo object for encoding 'b64'>
    """
    register()

# Generated at 2022-06-23 17:48:19.199422
# Unit test for function register
def test_register():
    """Function test_register is run at import time to test the registration
    of the 'b64' codec with Python.

    Raises:
        AssertionError: Any assertion failed.
        LookupError: The 'b64' codec already exists.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        encoder = codecs.getencoder(NAME)
        decoder = codecs.getdecoder(NAME)
        assert encoder is not None
        assert decoder is not None
    else:
        raise LookupError(
            f"'{NAME}' codec is already registered.  "
            f'Only call this "test_register" function if the '
            f"'{NAME}' codec has not already been registered."
        )



# Generated at 2022-06-23 17:48:30.332635
# Unit test for function decode
def test_decode():
    """Test the function decode"""
    assert decode(b'+/+') == ('Lz4=', 3)
    assert decode(b'+/+/') == ('Lz4=', 4)
    assert decode(b'+/+/+/+') == ('Lz4vLz4=', 8)
    assert decode(b'+/+/+/+/') == ('Lz4vLz4=', 9)
    assert decode(b'=/+') == ('P+/', 3)
    assert decode(b'=/+/') == ('P+/', 4)
    assert decode(b'=/+/+/+') == ('P+/P+/', 7)
    assert decode(b'=/+/+/+/') == ('P+/P+/', 8)
    assert decode(b'==/+') == ('PT+/', 4)

# Generated at 2022-06-23 17:48:36.278561
# Unit test for function encode
def test_encode():
    test_input = "VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wZWQgb3ZlciB0aGUgbGF6eSBkb2cu"
    expected = b'The quick brown fox jumped over the lazy dog.'
    actual = codecs.decode(test_input, 'b64')
    print(actual)
    assert actual == expected



# Generated at 2022-06-23 17:48:39.301380
# Unit test for function decode
def test_decode():
    assert decode(b'YQo=') == ('a\n', 4)
    assert decode(b'YQ==') == ('a', 4)



# Generated at 2022-06-23 17:48:40.415181
# Unit test for function encode
def test_encode():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:48:42.142388
# Unit test for function encode
def test_encode():
    """Test ``b64_encode``."""
    assert ('aGVsbG8=' == encode('hello')[0].decode('utf8'))


# Generated at 2022-06-23 17:48:53.593781
# Unit test for function encode
def test_encode():
    """Test the function ``encode``."""

# Generated at 2022-06-23 17:48:55.973463
# Unit test for function decode
def test_decode():
    # TODO: write unit test for function decode
    assert decode(b'Hello world') == ('SGVsbG8gd29ybGQ=', 11), 'Function decode failed'

# Generated at 2022-06-23 17:49:03.744410
# Unit test for function encode
def test_encode():
    # Tests for function encode
    assert encode('YmFzZTY0') == (b'base64', 6)
    assert encode('IGJhc2U2NA==') == (b'base64', 8)
    assert encode('ICAgIGJhc2U2NA==') == (b'base64', 12)
    assert encode('ICAgIGJhc2U2NA==\n') == (b'base64', 12)
    assert encode('ICAgIGJhc2U2NA==\n\r') == (b'base64', 12)



# Generated at 2022-06-23 17:49:07.909746
# Unit test for function register
def test_register():
    print("Testing function register.")
    try:
        register()
    except Exception as e:  # pylint: disable=broad-except
        print(f"{__file__}: Error: {e}")
        assert False
    print(f"{__file__}: passtest")
    assert True


# Generated at 2022-06-23 17:49:15.312492
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``."""

    # Assert encode the empty string
    assert encode('') == (b'', 0)

    # Assert encode a string that is not a proper base64 character string.
    with pytest.raises(UnicodeEncodeError):
        encode('hello')

    # Assert encode a string that is not a proper base64 character string.
    with pytest.raises(UnicodeEncodeError):
        encode('YW55IGNhcm5hbCBwbGVhc3VyZS4=\n')

    # Assert encode a string that is a proper base64 character string.
    assert encode('YW55IGNhcm5hbCBwbGVhc3VyZS4=') == (b'any carnal pleasure.', 24)

    # Assert encode

# Generated at 2022-06-23 17:49:17.302886
# Unit test for function register
def test_register():
    """Unit test for function register.

    Test:
        >>> register()
        >>> codecs.getdecoder(NAME)
    """



# Generated at 2022-06-23 17:49:21.219573
# Unit test for function register
def test_register():
    """Unit test for function :func:`~common.codecs.b64.register`."""
    import common.codecs  # noqa: F401
    common.codecs.b64.register()
    assert common.codecs.b64.NAME == 'b64'



# Generated at 2022-06-23 17:49:31.903231
# Unit test for function decode
def test_decode():
    assert decode(b'') == ('', 0)
    assert decode(b'\x00') == ('AA==', 1)
    assert decode(b'\x01') == ('AQ==', 1)
    assert decode(b'\x02') == ('Ag==', 1)
    assert decode(b'\x03') == ('Aw==', 1)
    assert decode(b'\x04') == ('BA==', 1)
    assert decode(b'\x05') == ('BQ==', 1)
    assert decode(b'\x06') == ('Bg==', 1)
    assert decode(b'\x07') == ('Bw==', 1)
    assert decode(b'\x08') == ('CA==', 1)
    assert decode(b'\x09') == ('CQ==', 1)
   

# Generated at 2022-06-23 17:49:36.208714
# Unit test for function register
def test_register():
    """Unit test for function 'register' in module 'codecs'."""
    try:
        register()
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'Registering "{NAME}" codec failed.: {e}')

# Generated at 2022-06-23 17:49:41.719421
# Unit test for function decode
def test_decode():
    in1 = b'\x01\x03\x05\x07'
    expected1 = 'AQIDBAc='

    in2 = b'\x01\x03\x05\x07\x02\x04\x06\x08'
    expected2 = 'AQIDBAUGBwgJCg=='

    in3 = b''
    expected3 = ''

    actual1, _ = decode(in1)
    assert actual1 == expected1

    actual2, _ = decode(in2)
    assert actual2 == expected2

    actual3, _ = decode(in3)
    assert actual3 == expected3



# Generated at 2022-06-23 17:49:43.859135
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:49:49.684445
# Unit test for function decode
def test_decode():
    """Unit test for method encode"""
    assert decode(b'\xf0', errors='strict') == ('wOw=', 1)
    with pytest.raises(UnicodeEncodeError):
        decode(b'\xf1', errors='strict')
    with pytest.raises(UnicodeEncodeError):
        decode(b'\x00\x0a\x00\x05', errors='strict')


# Generated at 2022-06-23 17:49:57.053367
# Unit test for function decode
def test_decode():
    """Unit test for the :func:`decode` function."""
    test_bytes = bytes([1, 2, 4, 8, 16, 32, 64, 128])
    exp_encoded_str = 'AQIDBAUGBwgJ'
    exp_return = (
        f'{exp_encoded_str}',
        len(test_bytes),
    )
    act_return = decode(test_bytes)
    assert exp_return == act_return

# Generated at 2022-06-23 17:49:59.762688
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-23 17:50:04.430153
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    from importlib import reload
    from unittest.mock import MagicMock, patch
    import codecs

    reload(codecs)
    mock = MagicMock(return_value=None)
    with patch.object(codecs, 'register', mock):
        register()

    mock.assert_called_once_with(_get_codec_info)



# Generated at 2022-06-23 17:50:15.232770
# Unit test for function decode
def test_decode():
    data_bytes = b'\x00\x00'                        # type: ignore
    data_str = 'AAAA'

    assert decode(data_bytes)[0] == data_str

    # noinspection PyUnusedLocal
    def inner_test_decode(text):
        data_bytes = bytes(text, 'utf-8')
        assert decode(data_bytes)[0] == data_str

        user_string = UserString(text)
        assert decode(user_string)[0] == data_str

    inner_test_decode('AAAA')
    inner_test_decode('\n\tA\n\t\tA\n\t\tA\n\tA\n')
    inner_test_decode(' AAAA ')
    inner_test_decode('(')
    inner_test_dec

# Generated at 2022-06-23 17:50:19.395027
# Unit test for function register
def test_register():
    """Unit test for function register"""
    from test.utils import check_function_output
    from test.utils import TestRegistered

    check_function_output(
        expected_str=str(TestRegistered(NAME)),
        function=register,
    )



# Generated at 2022-06-23 17:50:29.674299
# Unit test for function decode
def test_decode():
    """Ensure the ``decode`` function returns the expected result."""
    # This is the base64 character string:
    #   WkdWemRXSWdlelZ5WlRGaVpXRmpaV0Zq
    expected_str = (
        'WkdWemRXSWdlelZ5WlRGaVpXRmpaV0Zq'
    )

    # This is the data that was used to create the above base64
    # character string, which is:
    #     b'\xd0\xaf\xce\xb2\xcf\x86\xd1\x83\xd0\xb9\xd0\xb6'
    #     b'\xce\xb3\xd1\x83\xd0\xb9\xd0\xb6\x

# Generated at 2022-06-23 17:50:40.149870
# Unit test for function encode
def test_encode():
    """Unit test for the 'encode' function."""
    # pylint: disable=I0011
    assert encode(
        '''
        AWEAVgVtYWlsIFNlcnZpY2UAYlNzZGxvZ28AYmFzZTY0AHRlc3QA
        YmFzZTY0AHRlc3QA
    ''',
    )[0] == codecs.decode(
        '''
        AWEAVgVtYWlsIFNlcnZpY2UAYlNzZGxvZ28AYmFzZTY0AHRlc3QA
        YmFzZTY0AHRlc3QA
    ''',
        'base64',
    )

    assert encode('YQ==')[0] == codecs

# Generated at 2022-06-23 17:50:51.703716
# Unit test for function register
def test_register():
    """Test function register.

    The function uses :mod:`unittest.mock` to mock the function call
    ``codecs.register`` and to intercept the call to ``getdecoder``.

    The function also uses a mock object to record the attributes of
    ``CodecInfo`` that are injected into the codecs module.
    """
    import sys
    from unittest.mock import Mock
    from unittest.mock import call

    mock_getdecoder = Mock(return_value=None)
    mock_reg = Mock(return_value=None)

    with \
            Mock() as mock_codecs, \
            Mock() as mock_info, \
            Mock() as mock_sys:
        mock_codecs.register = mock_reg
        mock_codecs.getdecoder = mock_

# Generated at 2022-06-23 17:50:56.864455
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('aa') == (b'YWE=', 2)
    assert encode('aaa') == (b'YWFh', 3)
    assert encode('  aa      aaa') == (b'YWFhYWFh', 11)
    assert encode('  aa\n  aaa') == (b'YWFhYWFh', 11)

# Generated at 2022-06-23 17:51:07.888519
# Unit test for function encode
def test_encode():
    """Test the function encode()."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 1)
    assert encode('\t') == (b'', 1)
    assert encode(' ') == (b'', 1)
    assert encode('o') == (b'', 1)
    assert encode('\n\t ') == (b'', 4)
    assert encode('o\n\t ') == (b'', 5)
    assert encode('o\n\to\t ') == (b'', 9)
    assert encode('\n\to\t ') == (b'', 8)
    assert encode('QQ==\n\n') == (b'', 6)

# Generated at 2022-06-23 17:51:18.523893
# Unit test for function decode
def test_decode():
    data: bytes
    name: str
    errors: str
    obj: codecs.CodecInfo
    ret: Tuple[str, int]
    text: str
    text_input: str
    text_str: str
    text_bytes: bytes
    out: bytes

    data = b'Hello World'
    ret = decode(data)
    # Do the test
    assert ret == ('SGVsbG8gV29ybGQ=', 11)

    data = b'SGVsbG8gV29ybGQ='
    ret = decode(data)
    # Do the test
    assert ret == ('SGVsbG8gV29ybGQ=', 15)

    data = b'aGVsbG8gd29ybGQ='
    ret = decode(data)
    # Do the test

# Generated at 2022-06-23 17:51:30.146440
# Unit test for function encode
def test_encode():
    assert encode('RGV dGEtbG9uZyBzdHJpbmc=') == (b'da-long string', 16)
    assert encode('IlxxdWVzdGlvbiBmcm9tIER1cmxleQ==') == (b'TheQuestion from Durley', 30)
    assert encode('SXQgb25seSB0YWtlcyBhIGNvbXBhc3Npb24uCg==') == (b'It only takes a compression.\n', 31)

# Generated at 2022-06-23 17:51:31.894625
# Unit test for function decode
def test_decode():
    assert decode(b'A') == ('QQ==', 1)
    assert decode(b'AB') == ('QUI=', 2)
    assert decode(b'ABA') == ('QUJBA==', 3)



# Generated at 2022-06-23 17:51:41.603952
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YW Jj ') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )
    assert encode('YWJjZGVm Z2hpamtsbW5 vcHFyc3R1 dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )



# Generated at 2022-06-23 17:51:51.082053
# Unit test for function encode
def test_encode():
    assert encode('cXI3NWJxM2k=') == (b'qR75bq3i', 12)
    assert encode('S2g2M0VJc1B4dEJ4') == (b'Kh63EIsPxtBx', 18)
    expected = (b'cFhCTGJUUm4=', 10)
    assert encode('cFhCTGJUUm4=') == expected
    expected = (b'DQo=', 4)
    assert encode('DQo=') == expected
    expected = (b'DQo=', 4)
    assert encode('D\nQ\no=') == expected
    expected = (b'DQo=', 4)
    assert encode('D\tQ\ro=') == expected

# Generated at 2022-06-23 17:52:02.499258
# Unit test for function encode
def test_encode():
    assert b'\xda\x00\x9a\xff\xd5' == encode(str('24-bit'))[0]
    assert b'\xda\x00\x9a\xff\xd5' == encode(str('24-bit\n'))[0]
    assert b'\xda\x00\x9a\xff\xd5' == encode(str('24-bit\r'))[0]
    assert b'\xda\x00\x9a\xff\xd5' == encode(str('24-bit\r\n'))[0]
    assert b'\xda\x00\x9a\xff\xd5' == encode(str('24-bit\n\r'))[0]


# Generated at 2022-06-23 17:52:13.254729
# Unit test for function encode

# Generated at 2022-06-23 17:52:21.528885
# Unit test for function encode
def test_encode():
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('Zm9vYmFy') == (b'foobar', 8)
    assert encode('Zm9vYmFyYmF6') == (b'foobarbaz', 11)
    assert encode('Zm9vYmFyYmF6YmF6') == (b'foobarbazbaz', 14)
    assert encode('Zm9vYmFyYmF6YmF6YmF6') == (b'foobarbazbazbaz', 17)
    assert encode('Zm9vYmFyYmF6YmF6YmF6YmF6') == (b'foobarbazbazbazbaz', 20)

# Generated at 2022-06-23 17:52:33.166966
# Unit test for function decode
def test_decode():
    """Testing the ``decode`` function."""
    # pylint: disable=invalid-name
    b64_decode = codecs.getdecoder(NAME)
    assert b64_decode(b'QQ==')[0] == 'a'
    assert b64_decode(b'QQ==', 'strict')[0] == 'a'
    assert b64_decode(b'QQ==\n', 'strict')[0] == 'a'

    assert b64_decode(b'QQ\n==')[0] == 'a'
    assert b64_decode(b'QQ\n=\n=')[0] == 'a'
    assert b64_decode(b'QQ\n =\n =')[0] == 'a'
    assert b

# Generated at 2022-06-23 17:52:36.405168
# Unit test for function decode
def test_decode():
    test_data = b'Hello world'
    expect_res = 'SGVsbG8gd29ybGQ='
    res, _ = decode(test_data)
    assert res == expect_res



# Generated at 2022-06-23 17:52:38.445942
# Unit test for function register
def test_register():
    """Test that ``b64`` codec is registered with Python."""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None

