

# Generated at 2022-06-23 17:42:45.421701
# Unit test for function decode

# Generated at 2022-06-23 17:42:57.132223
# Unit test for function encode

# Generated at 2022-06-23 17:42:59.007617
# Unit test for function register
def test_register():
    codecs.register = Mock()
    register()
    codecs.register.assert_called_once()

# Generated at 2022-06-23 17:43:02.049334
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()

# Generated at 2022-06-23 17:43:03.696725
# Unit test for function encode
def test_encode():
    """Perform simple unit testing for this module."""
    assert encode('YWJjZA')[0] == b'abcd'

# Generated at 2022-06-23 17:43:09.966647
# Unit test for function decode
def test_decode():
    assert decode(b'YQ==\n') == ('a', 4)
    assert decode(b'\xc3\x84\xc3\xa4\xc3\xa6') == ('Ääæ', 3)
    assert decode(b'\xc3\x84\xc3\xa4\xc3\xa6')[1] == 3
    assert decode(b'\xc3\x84\xc3\xa4\xc3\xa6\xc3')[1] == 3
    assert decode(b'\xc3\x84\xc3\xa4\xc3\xa6\xc3\x89')[1] == 4
    assert decode(b'\xc3\x84\xc3\xa4\xc3\xa6\xc3\x89\xc3')[1] == 4
    assert decode

# Generated at 2022-06-23 17:43:21.168853
# Unit test for function encode
def test_encode():
    here = os.path.dirname(__file__)
    fixtures_dir = os.path.join(here, 'fixtures')
    input_path = os.path.join(fixtures_dir, 'input.b64')
    with open(input_path, 'rb') as f:
        seq = f.read()
    decoded = decode(seq)
    assert decoded[0] == b'This is a test binary data file.\n'
    output_path = os.path.join(fixtures_dir, 'output.b64')
    with open(output_path, 'rb') as f:
        seq = f.read()
    enc_dec = encode(decoded[0])
    assert enc_dec[0].decode('utf-8') == seq.decode('utf-8')

# Generated at 2022-06-23 17:43:26.219962
# Unit test for function decode
def test_decode():
    data_input = bytes([0, 1, 2, 3, 4, 5])
    data_expected = 'AAECAwQ='

    actual, _ = decode(data_input)
    assert actual == data_expected, \
        f'\nActual: {actual!r}\nExpected: {data_expected!r}'



# Generated at 2022-06-23 17:43:32.876063
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    # Test input of type bytes
    # Test case 1: Standard base64 encode string
    b = decode(b'YWJj')
    assert b == ('abcd', 4)

    # Test case 1: Standard base64 encoded string of 4 bytes
    b = decode(b'b3VyIGRlY29kZSBmdW5jdGlvbiB3b3JrcyE=')
    assert b == ('our decode function works!', 24)

    # Test case 2: Standard base64 encoded string of 0 bytes
    b = decode(b'')
    assert b == ('', 0)

    # Test case 3: Standard base64 encoded string of 0 bytes

# Generated at 2022-06-23 17:43:42.950198
# Unit test for function encode
def test_encode():
    # Examples from https://en.wikipedia.org/wiki/Base64
    assert encode('Man') == b'TWFu'
    assert encode('Ma') == b'TWE='
    assert encode('M') == b'TQ=='

    assert encode('any carnal pleasure.') == b'YW55IGNhcm5hbCBwbGVhc3VyZS4='
    assert encode('any carnal pleasure') == b'YW55IGNhcm5hbCBwbGVhc3VyZQ=='
    assert encode('any carnal pleasur') == b'YW55IGNhcm5hbCBwbGVhc3Vy'
    assert encode('any carnal pleasu') == b'YW55IGNhcm5hbCBwbGVhc3U='

# Generated at 2022-06-23 17:43:50.949516
# Unit test for function encode
def test_encode():
    # Test values given an expected value
    test_correct = [
        ('b64', b'b64\n', b'YjY0Cg==\n'),
        ('', b'', b'\n'),
    ]

    # Test values given an expected raised value exception and error message
    test_error = {
        (  # key
            'This is a multiline\nbase64 string.\n',
            'strict',
        ): (  # value
            UnicodeEncodeError,
            '<string>:1:1: (b64) not a proper base64 character string\n'
            'This is a multiline\n'
            ' ^ (b64)'
        ),
    }

    # Test that the function return the expected results given the
    # 'test_correct' values.

# Generated at 2022-06-23 17:43:54.619677
# Unit test for function decode
def test_decode():
    pass
    data = 'abc=abc'
    data = codecs.encode(data, 'b64')
    assert ( data == b'YWJjPWFicyA=' )


# Generated at 2022-06-23 17:43:55.929493
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:44:05.020978
# Unit test for function encode

# Generated at 2022-06-23 17:44:13.105900
# Unit test for function encode
def test_encode():
    """Run a simple test."""
    text = """
    SGVsbG8gV29ybGQ=
    """
    # pylint: disable=C0330
    text = text.strip()
    text = '\n'.join(
        filter(
            lambda x: len(x) > 0,
            map(lambda x: x.strip(), text.strip().splitlines())
        )
    )
    out, _ = encode(text)
    assert out == b'Hello World'



# Generated at 2022-06-23 17:44:24.518924
# Unit test for function encode
def test_encode():
    """Ensure the encode function can encode valid base64 chars."""
    assert encode('QQ==') == (b'\xaa\x55', 4)
    assert encode('AaA') == (b'\xaa\x55\xaa', 6)
    assert encode('QQA=') == (b'\xaa\x55\xaa', 6)
    assert encode('QQAx==') == (b'\xaa\x55\xaa\x51', 8)
    assert encode('QQAx') == (b'\xaa\x55\xaa\x51', 8)
    assert encode('QQAx\nAQA=') == (b'\xaa\x55\xaa\x51\n\xaa\x55\xaa', 16)

# Generated at 2022-06-23 17:44:30.890614
# Unit test for function register
def test_register():
    """
    Test the function :func:`register`.
    """

    # Try to register the codec.
    register()

    # Try to get the decoder method.
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None

    # Try to use the decoder method.
    u_text = 'Hello, World!'
    b_bytes = b'SGVsbG8sIFdvcmxkIQ=='
    u_bytes = b_bytes.decode(NAME)

    assert u_text == u_bytes.encode(NAME).decode(NAME)



# Generated at 2022-06-23 17:44:35.341665
# Unit test for function decode
def test_decode():
    for x in b'\0\1\xffGg#;:/\xB0-{|}':
        assert(decode(bytes([x]))[0] == codecs.encode(bytes([x]), 'b64')[0].decode('utf-8'))


# Generated at 2022-06-23 17:44:44.260653
# Unit test for function decode
def test_decode():
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def _test(
            input_string: str,
            errors: Optional[str] = None,
            text: _STR = str(),
            expected_bytes: Optional[bytes] = None,
    ) -> None:
        out = decode(input_string, errors=errors)
        assert out == (text, len(input_string))
        if expected_bytes is not None:
            assert base64.b64decode(text.encode('utf-8')) == expected_bytes

    _test(b'abc', 'strict', 'YWJj')
    _test(b'abcd', 'strict', 'YWJjZA==')

# Generated at 2022-06-23 17:44:54.447274
# Unit test for function decode
def test_decode():
    assert decode(b'AAAA') == ('AAAA', 4)
    assert decode(b'AQAAAA') == ('AAAA', 6)
    assert decode(b'5wAAAA') == ('AAAA', 6)
    assert decode(b'-wAAAA') == ('AAAA', 6)
    #assert decode(b'1wAAAA') == ('AAAA', 6)  # Uncomment to see test fail with Raise
    #assert decode(b'1wAAAA') == ('AAAA', 6)  # Uncomment to see test fail with Raise
    #assert decode(b'1wAAAA') == ('AAAA', 6)  # Uncomment to see test fail with Raise
    #assert decode(b'1wAAAA') == ('AAAA', 6)  # Uncomment to see test fail with Raise
    #assert decode(b'1wAAAA') == ('AAAA', 6)  # Uncomment to

# Generated at 2022-06-23 17:44:59.712006
# Unit test for function register
def test_register():
    # Test if the codec is registered.
    assert NAME in codecs.__coding_error_registry__
    obj = codecs.__coding_error_registry__[NAME]
    assert isinstance(obj, tuple)
    assert obj[0] is decode
    assert obj[1] is encode


register()

# Generated at 2022-06-23 17:45:03.012929
# Unit test for function encode
def test_encode():
    assert 'YmFzZTY0IGlzIGJhc2U2NA=='.encode('b64') == \
        base64.b64encode('base64 is base64'.encode('utf-8'))

# Generated at 2022-06-23 17:45:14.501814
# Unit test for function decode
def test_decode():
    tests = (
        # No input
        (
            b'',
            b'',
            0,
        ),
        (
            '',
            b'',
            0,
        ),
        # Already a string
        (
            'aGVsbG8=',
            b'hello',
            6,
        ),
        (
            'aGVsbG8'.encode('utf-8'),
            b'hello',
            6,
        ),
    )
    # Encode each of the tests.
    for test in tests:
        text = test[0]
        expected = test[1]
        expected_length = test[2]
        result, result_length = decode(text)
        assert result == expected
        assert result_length == expected_length


register()



# Generated at 2022-06-23 17:45:19.734515
# Unit test for function encode
def test_encode():
    """Testing base64 with the codecs module."""
    # Register the codecs.
    register()

    # Create the base64 'codec' object.
    codec = codecs.getdecoder(NAME)

    # Test the base64 encoder
    assert 'dGVzdGluZwo=' == codec(  # type: ignore
        'testing\n', errors='replace'
    )[0]
    assert codec(  # type: ignore
        'TEVWRU5FIFVSSRTDgMOK\n', errors='replace'
    )[0] == 'LEVVNER USIEΣσσ'

    # Try some Microsoft UTF16 text

# Generated at 2022-06-23 17:45:25.616234
# Unit test for function encode

# Generated at 2022-06-23 17:45:36.836095
# Unit test for function register
def test_register():
    """Test the function register."""

    register()
    try:
        assert NAME == codecs.getencoder(NAME)[0]
        assert NAME == codecs.getdecoder(NAME)[0]
    finally:
        # noinspection PyUnusedLocal
        def _dummy_codec_info(name: str) -> Optional[codecs.CodecInfo]:
            return None

        # noinspection PyUnusedLocal
        def _dummy_getdecoder(name: str) -> Optional[codecs.CodecInfo]:
            return None

        # noinspection PyUnusedLocal
        # pylint: disable=W0612
        codecs.register(_dummy_codec_info)
        codecs.getdecoder = _dummy_getdecoder



# Generated at 2022-06-23 17:45:47.664698
# Unit test for function decode

# Generated at 2022-06-23 17:45:54.970296
# Unit test for function decode
def test_decode():
    # Test converting 2 hextets into one base64 digit
    assert(decode(b'\x00') == ('AA', 1))
    assert(decode(b'\x10') == ('JA', 1))
    assert(decode(b'\x20') == ('RA', 1))
    assert(decode(b'\x30') == ('gA', 1))

    assert(decode(b'\x3f') == ('/w==', 1))

    # Test converting 3 hextets into two base64 digits
    assert(decode(b'\x00\x00') == ('AAA=', 2))
    assert(decode(b'\x10\x00') == ('IIA=', 2))
    assert(decode(b'\x20\x00') == ('QAA=', 2))
   

# Generated at 2022-06-23 17:46:03.942228
# Unit test for function decode
def test_decode():
    # type: () -> None
    """Test: decode"""
    data = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    expected = (
        r'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMi'
        r'AzNDU2Nzg5Kw=='
    )
    out = decode(data)
    assert out[0] == expected, f'{out[0]!r} != {expected!r}'



# Generated at 2022-06-23 17:46:11.136184
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode(b'') == (b'', 0)

    assert encode(b'TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQ=') == (b'dolor sit amet', 28)

    assert encode(b'IyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMj') == (b'##################', 64)


# Generated at 2022-06-23 17:46:16.916856
# Unit test for function encode
def test_encode():
    import pytest
    # Test Case: Valid input
    assert encode('dGVzdA==') == (b'test', 5)

    # Test Case: Invalid input
    with pytest.raises(UnicodeEncodeError):
        encode('dGVzdq==')


# Generated at 2022-06-23 17:46:26.775276
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    assert codecs.lookup(NAME) is not None    # type: ignore
    assert codecs.encode(b'a', NAME) == b'YQ=='
    assert codecs.decode(b'YQ==', NAME) == 'a'   # type: ignore
    assert codecs.encode(b'abcd', NAME) == b'YWJjZA=='
    assert codecs.decode(b'YWJjZA==', NAME) == 'abcd'  # type: ignore

# Generated at 2022-06-23 17:46:37.292302
# Unit test for function decode
def test_decode():
    assert decode(b'YQ==') == ('a', 3), 'decode should return correct output'
    assert decode(b'YWI=') == ('ab', 4), 'decode should return correct output'
    assert decode(b'YWJj') == ('abc', 4), 'decode should return correct output'
    assert decode(b'c3VyZS4=') == ('sure.', 8), 'decode should return correct output'
    assert decode(b'bGVhc3VyZS4=') == ('leasure.', 8), 'decode should return correct output'
    assert decode(b'ZWFzdXJlLg==') == ('easure.', 8), 'decode should return correct output'

# Generated at 2022-06-23 17:46:43.723302
# Unit test for function register
def test_register():
    """Test the :func:`register` function to ensure it registers the codec
    with Python."""

    # Sanity check that the
    # pylint: disable=W0212
    assert codecs._getdecoder(NAME) is None

    register()

    # pylint: disable=W0212
    assert codecs._getdecoder(NAME) is not None


# Execute the safe_register function when this module is loaded.
register()

# Generated at 2022-06-23 17:46:47.791543
# Unit test for function decode
def test_decode():
    example = b'YmFzZTY0IGVuY29kZWQgYnl0ZXM='

    assert decode(example)[0] == 'base64 encoded bytes'


# Generated at 2022-06-23 17:46:51.097525
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.encode(bytes([1, 2, 3]), NAME)
    codecs.decode(b'0123456789ABCDEF', NAME)
    assert True

# Generated at 2022-06-23 17:46:59.386367
# Unit test for function decode
def test_decode():
    """ Unit test for function decode """
    good_data = b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoK'
    assert decode(good_data)[0] == 'abcdefghijklmnopqrstuvwxyz'
    assert decode(good_data, 'lenient')[0] == 'abcdefghijklmnopqrstuvwxyz'
    assert decode(good_data, 'strict')[0] == 'abcdefghijklmnopqrstuvwxyz'



# Generated at 2022-06-23 17:47:10.278535
# Unit test for function encode
def test_encode():
    """Unit tests for function ``encode()``."""

    # pylint: disable=C0116
    # noinspection PyStatementEffect
    """Test the following encodings"""

    # --------------- Positive tests ----------------
    # Encode a basic string.
    assert(encode('') == (b'', 0))

    # Encode a basic string.
    assert(encode(' ') == (b'', 0))

    # Encode a basic string.
    assert(encode('  ') == (b'', 0))

    # Encode a basic string.
    assert(encode('   ') == (b'', 0))

    # Encode a basic string.
    assert(encode('abc') == (b'abc', 3))

    # Encode a basic string.

# Generated at 2022-06-23 17:47:21.153132
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == (
        b'abcdefghijklmnopqrstuvwxyz',
        44
    )

# Generated at 2022-06-23 17:47:27.089882
# Unit test for function encode
def test_encode():
    assert encode('ZWxsd29vbGFuZw==')[1] == 14
    assert encode('ZWxsd29vbGFuZw==')[0] == b'ellwooland'


# Generated at 2022-06-23 17:47:30.597422
# Unit test for function decode
def test_decode():
    data = b'Test data for base64.'
    print(decode(data))
    assert decode(data) == ('VGVzdCBkYXRhIGZvciBiYXNlNjQu', 21)


# Generated at 2022-06-23 17:47:33.555682
# Unit test for function decode
def test_decode():
    result = decode(b'YXNkZg==')
    assert result[0] == 'asdf'
    assert result[1] == 6


# Generated at 2022-06-23 17:47:36.475382
# Unit test for function register
def test_register():
    # pylint: disable=W0612,W0613,E1101
    # Test with a registered codec
    register()
    registered_codec = codecs.getdecoder(NAME)
    assert callable(registered_codec)
    assert registered_codec == decode



# Generated at 2022-06-23 17:47:38.150346
# Unit test for function decode
def test_decode():
    assert decode(bytes([1,2,3,4])) == ('AQIDBA==', 4)


# Generated at 2022-06-23 17:47:45.027252
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode``."""
    input_data = b'\x00abcd'
    expected_output = 'AABiYw=='
    output = decode(input_data)[0]
    assert output == expected_output, (
        f'{output!r} should be {expected_output!r}'
    )


# Generated at 2022-06-23 17:47:50.953627
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('AQI') == (b'I', 3)
    assert encode('AbCDeFgH') == (b'\nG\x89\xabC\xef', 8)
    assert encode('apple') == (b'cGxl', 4)
    assert encode('\n') == (b'', 1)


# Generated at 2022-06-23 17:47:59.626774
# Unit test for function decode
def test_decode():
    """Unit tests for the function decode()"""
    import random
    import string
    for _ in range(30):
        data = bytearray((random.randint(0, 256) for _ in range(30)))
        print(f'\n{data}')
        result, _ = decode(data)
        print(f'{result}')
        assert base64.b64decode(result.encode('utf-8')) == data
    assert decode(b'\x00\x01\x02\x03\x04')[0] == 'AAECAwQ='
    unwanted_string = ''.join(
        random.choice(string.ascii_letters + string.digits)
        for _ in range(30)
    )

# Generated at 2022-06-23 17:48:06.328768
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test the register function."""
    test_registry = codecs.CodecInfo(  # type: ignore
        name=NAME,
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )
    register()
    actual_registry = codecs.CodecInfo(  # type: ignore
        name=NAME,
        decode=decode,  # type: ignore[arg-type]
        encode=encode,  # type: ignore[arg-type]
    )
    assert actual_registry == test_registry


# Generated at 2022-06-23 17:48:14.007066
# Unit test for function decode
def test_decode():
    # noinspection PyUnresolvedReferences
    """Unit test for function decode."""
    # Decode bytes
    b = b'I\r\nam\r\n \r\nthe\r\n \r\npresident\r\n \r\nof\r\n \r\nthe\r\n ' \
        b'\r\nunited\r\n \r\nstates\r\n \r\nof\r\n \r\namerica'
    t = 'SSBhbSB0aGUgcHJlc2lkZW50IG9mIHRoZSB1bml0ZWQgc3RhdGVzIG9mIGFtZXJpY2E='
    assert decode(b) == (t, len(b))

    # Decode bytearray

# Generated at 2022-06-23 17:48:21.844788
# Unit test for function decode
def test_decode():
    assert decode(b'Zm9v') == ('Zm9v', 4)
    assert decode(b'Zm9vYg==') == ('Zm9vYg==', 8)
    assert decode(b'Zm9vYmE=') == ('Zm9vYmE=', 8)
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9v')[0] == encode('foo')[0]
    assert decode(b'Zm9vYg==')[0] == encode('foob')[0]
    assert decode(b'Zm9vYmE=')[0] == encode('fooba')[0]
    assert decode(b'Zm9vYmFy')

# Generated at 2022-06-23 17:48:22.869721
# Unit test for function register
def test_register():
    """Test that the codecs module can be patched."""
    from codecs import lookup

    register()
    lookup(NAME)

# Generated at 2022-06-23 17:48:27.630727
# Unit test for function decode
def test_decode():

    msg = 'hello world'
    msg_hex = codecs.getencoder('hex')(msg)
    msg_b64 = decode(msg_hex[0])[0]
    msg2_hex = encode(msg_b64)[0]
    msg2 = codecs.getdecoder('hex')(msg2_hex)[0]

    assert msg2 == msg


# Generated at 2022-06-23 17:48:32.876042
# Unit test for function register
def test_register():
    # pylint: disable=import-outside-toplevel
    import sys
    if NAME in sys.modules.keys():
        del sys.modules[NAME]
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'The "{NAME}" module has failed to register.\n{str(e)}'
        ) from None



# Generated at 2022-06-23 17:48:40.325593
# Unit test for function encode
def test_encode():
    """Unit Test for function encode."""
    # Test the function's ability to handle UTF-8 Characters.
    encoded_text: str = (
        'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wZWQgb3ZlciB0aGUgbGF6eSBk'
        'b2Uu'
    )
    decoded: bytes = b''
    with codecs.open(
            './tests/test-data/test-utf8-chars.txt',
            mode='r',
            encoding=NAME
    ) as base64_file:
        decoded = base64_file.read().encode()

    assert decode(encoded_text)[0] == decode(decoded)[0]

    # Test the function's ability to handle ASCII Characters.
    encoded_text

# Generated at 2022-06-23 17:48:45.659815
# Unit test for function encode
def test_encode():
    """Unit test for encode"""
    INPUT = """
    YXNkZmFzZGYgc2Zhc2RmIGFmYXNkZg==
    """
    BYTES = b'asdfasdf sfasdf afasdf'
    assert encode(INPUT)[0] == BYTES



# Generated at 2022-06-23 17:48:56.471703
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    # noinspection PyProtectedMember
    # pylint: disable=protected-access
    output = decode(b'ZW50cnk6IHN0cmluZw==')

    expected = 'entry: string'

    assert output == (expected, 16)

    output = decode(b'ZW50cnk6IHN0cmluZw==')

    expected = 'entry: string'

    assert output == (expected, 16)

    output = decode(
        b'ZXJyb3IgbnVtYmVyOiB5LQ=='
    )
    expected = 'error number: y-'

    assert output == (expected, 18)

    # noinspection PyUnusedLocal

# Generated at 2022-06-23 17:49:07.240390
# Unit test for function encode
def test_encode():
    from itertools import combinations
    from string import ascii_letters, digits
    from random import randint
    from textwrap import dedent
    from typing import Tuple

    # Test for input with no new lines.

    def _test_function(text: _STR) -> Tuple[bytes, _STR]:
        return encode(text, errors='strict')

    # Verify that the 'b64' codec will properly decode
    # the given 'str'.

# Generated at 2022-06-23 17:49:09.542553
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    from b64 import decode as decode_function
    input_bytes = bytes([65, 98, 192])
    expected = 'QWJ4AA=='
    result = decode_function(input_bytes)
    assert result == (expected, 3)

# Generated at 2022-06-23 17:49:13.136719
# Unit test for function decode
def test_decode():
    # Given
    data_bytes = b'\x00'

    # When
    decoded_str, _ = decode(data_bytes)

    # Then
    assert decoded_str == 'AA=='



# Generated at 2022-06-23 17:49:16.625876
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered."""
    register()
    b64_codec = codecs.getdecoder(NAME)
    assert b64_codec is not None  # type: ignore
    assert b64_codec.name == NAME  # type: ignore


# Generated at 2022-06-23 17:49:20.954081
# Unit test for function register
def test_register():
    """
    Test the register function.
    """
    # Make a registry to be restored after the test.
    registry = codecs.__dict__['_cache'].copy()
    try:
        register()
        _ = codecs.getdecoder(NAME)
    finally:
        codecs.__dict__['_cache'] = registry



# Generated at 2022-06-23 17:49:26.196168
# Unit test for function encode
def test_encode():
    """
    There should be errors when calling encode() with wrong types of arguments
    """

    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        encode(b'')

    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        encode('',None)



# Generated at 2022-06-23 17:49:33.869722
# Unit test for function register
def test_register():
    """Test the register() function with a test case.

    The test case is the following.
    1.  get the codec information for the encoder b64 from the codecs module.
    2.  Register the b64 codec with the codecs module.
    3.  get the codec information for the encoder b64 from the codecs module
        again.

    The test case passes if the 2 codecs information objects are different
    objects.
    """
    codec = codecs.getdecoder(NAME)
    register()
    codec2 = codecs.getdecoder(NAME)
    assert codec != codec2

# Generated at 2022-06-23 17:49:40.942259
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""

# Generated at 2022-06-23 17:49:43.480109
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8sIFdvcmxkIQ==') == (b"Hello, World!", 15)

# Generated at 2022-06-23 17:49:46.069274
# Unit test for function decode
def test_decode():
    # testing decode() with valid input
    assert decode(b'YW50aG9ueTEyMw==') == ('anton123', 16)


# Generated at 2022-06-23 17:49:47.910618
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'hello')[0] == 'aGVsbG8='


# Generated at 2022-06-23 17:49:59.265375
# Unit test for function encode

# Generated at 2022-06-23 17:50:06.834267
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function.

    This test exists to support the unit test functions in
    ``test_codecs.py``.  This should be the only unit test for this
    function.  Test more use cases in the ``test_codecs.py`` module.
    """
    # Test a very simple 'abc' case.
    text = 'YWJj'
    output = decode(text.encode('utf-8'))
    assert output[0] == text

    # Test a case with a newline.
    text = 'YWJjCg=='
    output = decode(text.encode('utf-8'))
    assert output[0] == text

    # Test a case with a newline and indented whitespace.
    text = 'YWJjCg=='
    output = decode

# Generated at 2022-06-23 17:50:14.445502
# Unit test for function encode
def test_encode():
    """
    tests the encode function
    """
    assert encode('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzA0OWY5Y2QxNzE3') == (
        b'https://pastebin.com/raw/049f9cd1717',
        len('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzA0OWY5Y2QxNzE3')
    )


# Generated at 2022-06-23 17:50:18.756504
# Unit test for function register
def test_register():
    register()

    # check that we have the right codec registered
    assert codecs.getdecoder(NAME) == _get_codec_info(NAME)


if __name__ == '__main__':
    import pytest
    pytest.main(['-xrsv', __file__])

# Generated at 2022-06-23 17:50:29.492513
# Unit test for function register
def test_register():
    """Test :meth:`register()` to be sure it can register the codec."""
    register()

    # Make sure the codec is now in the list of decoders.
    get_decoder = codecs.getdecoder(NAME)
    assert get_decoder(b'AQEBAQEBAQE=')[0] == 'hellohellohello'
    assert get_decoder(b'AQEBAQEBAQE=')[1] == 12

    # Make sure the codec is now in the list of encoders.
    get_encoder = codecs.getencoder(NAME)
    assert get_encoder('hellohellohello')[0] == b'AQEBAQEBAQE='
    assert get_encoder('hellohellohello')[1] == 12



# Generated at 2022-06-23 17:50:32.184391
# Unit test for function decode
def test_decode():
    in_string: str = "SGVsbG8gV29ybGQ="
    returned_string = codecs.decode(in_string, NAME)
    assert returned_string == "Hello World"


# Generated at 2022-06-23 17:50:43.361540
# Unit test for function encode
def test_encode():
    """Test function encode."""
    # Test 1
    text = 'dGVzdA=='
    errors = 'strict'
    expected = (b'test', 8)
    actual = encode(text, errors)
    assert expected == actual

    # Test 2
    text = '''
        dGVzdA==
    '''
    errors = 'strict'
    expected = (b'test', 16)
    actual = encode(text, errors)
    assert expected == actual

    # Test 3
    text = '''
        dGVzdA==
    '''
    errors = 'strict'
    expected = (b'test', 16)
    actual = encode(text, errors)
    assert expected == actual

    # Test 4
    text = '''
        dGVzdA==
    '''


# Generated at 2022-06-23 17:50:49.050487
# Unit test for function encode
def test_encode():
    assert encode('YXNkZmFzZGY=') == (b'asdfasdf', 12)
    assert encode('YXNk ZmFz ZGY=') == (b'asdfasdf', 14)
    assert encode('YXNkZmFzZGY=') == (b'asdfasdf', 12)



# Generated at 2022-06-23 17:50:57.591451
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    assert decode(bytes([0x00]), '') == ('AA==', 1)
    assert decode(bytes([0x01]), '') == ('AQ==', 1)
    assert decode(bytes([0xFF]), '') == ('/w==', 1)

    assert decode(b'A', '') == ('QQ==', 1)
    assert decode(b'B', '') == ('Qg==', 1)
    assert decode(b'C', '') == ('Qw==', 1)
    assert decode(b'D', '') == ('RA==', 1)
    assert decode(b'E', '') == ('RQ==', 1)
    assert decode(b'F', '') == ('Rg==', 1)

# Generated at 2022-06-23 17:51:01.940114
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('aGVsbG8gd2\n9ybGQ=') == (b'hello world', 16)



# Generated at 2022-06-23 17:51:03.638154
# Unit test for function register
def test_register():
    """Test the function register"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:51:14.216770
# Unit test for function encode
def test_encode():
    """Test the 'encoder' function of the 'b64' module"""

# Generated at 2022-06-23 17:51:20.850867
# Unit test for function encode
def test_encode():
    """Unit test for function 'encode'."""
    # Base64 encode the given characters.
    out, bytes_consumed = codecs.encode("Base64 is a binary-to-text encoding scheme", encoding='b64')
    # The bytes consumed should be equal to the length of the given characters.
    assert bytes_consumed == len("Base64 is a binary-to-text encoding scheme")
    # The encoding should be equal to the expected output.
    assert out == b'QmFzZTY0IGlzIGEgYmluYXJ5LXRvLXRleHQgZW5jb2Rpbmcgc2NoZW1l'



# Generated at 2022-06-23 17:51:31.999914
# Unit test for function encode

# Generated at 2022-06-23 17:51:43.112402
# Unit test for function encode
def test_encode():
    # Encode the 'data' into base64 btyes
    data = 'This is a test string'
    data_bytes = data.encode('utf-8')
    encoded_bytes = base64.b64encode(data_bytes)

    # Check that the encode() function returns the same base64 bytes
    # as the base64.b64encode() function.
    assert encode(data)[0] == encoded_bytes

    # Check that encode() produces the same base64 bytes when given
    # data that spans many lines.
    data_lines = (
        'This is a test string',
        'that is on many lines\n'
        'of text',
    )
    data = '\n'.join(data_lines)
    data_bytes = data.encode('utf-8')

# Generated at 2022-06-23 17:51:51.641355
# Unit test for function register
def test_register():
    """1. Ensure the 'b64' codec is not registered with Python at the
       start of the unit test.

       2. Register the 'b64' codec with Python.

       3. Assert that the 'b64' codec has been registered with Python.
    """
    # pylint: disable=protected-access
    try:
        codecs.getdecoder(NAME)
        raise Exception(
            f'The codec named {NAME!r} was already registered before '
            f'the test was started.  Please restart the test.'
        )
    except LookupError:
        pass
    register()
    codec_info = codecs.lookup(NAME)
    codec_name = codec_info.name
    assert codec_name == NAME



# Generated at 2022-06-23 17:51:59.969184
# Unit test for function register
def test_register():
    """
    Test the function 'register'.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'{NAME} decoder is already registered.'
        )

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'{NAME} decoder not registered.'
        )
    else:
        codecs.unregister(NAME)


# Generated at 2022-06-23 17:52:08.872645
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``."""

# Generated at 2022-06-23 17:52:19.126525
# Unit test for function decode
def test_decode():
    assert decode(b'Zm9v') == ('Zm9v', 4)
    assert decode(b'Zm9vYg==') == ('Zm9vYg==', 8)
    assert decode(b'Zm9vYmE=') == ('Zm9vYmE=', 8)
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zg==') == ('Zg==', 4)
    assert decode(b'Zm8=') == ('Zm8=', 4)
    assert decode(b'Zm9v==') == ('Zm9v==', 8)
    assert decode(b'Zm94') == ('Zm94', 4)

# Generated at 2022-06-23 17:52:30.682769
# Unit test for function decode

# Generated at 2022-06-23 17:52:35.831138
# Unit test for function encode
def test_encode():
    """Test ``encode``'s assertions."""
    try:
        encode(b'MTAwCg==')
    except AssertionError as e:
        assert str(e) == 'text is not valid type, expected str or UserString.'
        pass
    else:
        assert False



# Generated at 2022-06-23 17:52:37.194542
# Unit test for function encode
def test_encode():
    assert encode("b3JnYW5pemF0aW9ucw==")

# Generated at 2022-06-23 17:52:40.503253
# Unit test for function register
def test_register():
    """
    >>> import pyazh.b64
    >>> pyazh.b64.register()
    >>> codecs.getdecoder(pyazh.b64.NAME)
    <function _get_codec_info.<locals>.decode at 0x...>
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()