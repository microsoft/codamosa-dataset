

# Generated at 2022-06-23 17:42:47.419431
# Unit test for function encode
def test_encode():
    """Test the encode() function."""
    assert encode('b')[0] == b'b'
    assert encode('bXk=')[0] == b'my'
    assert encode('bXlmZg==')[0] == b'myff'


# Generated at 2022-06-23 17:42:58.614624
# Unit test for function decode
def test_decode():
    """ Unit test for function decode()
    """
    # Test 0.
    #
    # Test a byte array that is decodable
    #
    # 0x41 = ord('A')
    # 0x3d = ord('=')
    # 0x42 = ord('B')
    # 0x3d = ord('=')
    bytes_in = bytearray([0x41, 0x3d, 0x42, 0x3d])

    # 'QQ=='
    expected_out = "QQ=="

    bytes_out, bytes_consumed = decode(bytes_in)
    assert bytes_out == expected_out
    assert bytes_consumed == 4

    # Test 0a.
    #
    # Test a byte array that is decodable
    #
    # 0x41 = ord('

# Generated at 2022-06-23 17:43:06.109550
# Unit test for function encode
def test_encode():
    NOT_B64 = (
        '`~!@#$%^&*()-_=+[]{}\\|;:\'",<.>/?\n'
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz\n'
        '0123456789 \n'
    )
    B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    B64 += '0123456789+/'

    def _test(text: str, expected_bytes: bytes):
        """Test the ``encode`` function."""
        bs, length = encode(text)
        assert length == len(text)
        assert bs == expected_bytes

    _

# Generated at 2022-06-23 17:43:13.704236
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    # Make sure the b64 codec is not registered.
    if NAME in sys.modules:
        del sys.modules[NAME]
    register()
    # Reload the codec and make sure it was registered.
    import b64
    from codecs import CodecInfo
    assert isinstance(b64.__codecinfo__, CodecInfo)
    assert b64.__codecinfo__.name == NAME


# Generated at 2022-06-23 17:43:22.532171
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""

# Generated at 2022-06-23 17:43:27.304967
# Unit test for function register
def test_register():
    """Test for the register function."""
    import sys

    # By default, the 'b64' codec is not registered.
    try:
        # This should raise an exception
        codecs.getdecoder('b64')
    except LookupError:
        pass
    else:
        raise AssertionError(
            "The 'b64' codec should not be registered by default."
        )

    # Now, register the 'b64' codec.
    register()

    # Lastly, register the 'b64' codec.  This should not raise an exception.
    try:
        # This should not raise an exception
        codecs.getdecoder('b64')
    except LookupError:
        raise AssertionError("The 'b64' codec should be registered.")

# Generated at 2022-06-23 17:43:29.621642
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    decode('AQIDBAUGBwgJCgsMDQ4PEA==')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:43:42.557814
# Unit test for function register
def test_register():
    """Test the function :func:`register`"""
    import sys

    # Remove the 'b64' codec from the codec look up table
    try:
        codecs.lookup_error('b64')
    except (LookupError, AttributeError):
        pass

    # Make sure it is no longer in the codec look up table
    try:
        codecs.getdecoder('b64')
    except LookupError:
        pass
    else:
        pytest.fail(
            'The b64 codec is already registered.  Unable to test '
            'register()'
        )

    # Register the codec with Python
    register()

    # Get the codec info object
    info_obj = codecs.getdecoder('b64')

    # The codec info object should be non-None

# Generated at 2022-06-23 17:43:50.708589
# Unit test for function decode

# Generated at 2022-06-23 17:43:56.032481
# Unit test for function decode
def test_decode(): # type: ignore
    """Unit test for function decode"""
    assert decode(b'HElLO') == ('SAlM', 5)
    assert decode(b'') == ('', 0)
    assert decode(b'0') == ('MA==', 1)


# pylint: disable=W0613

# Generated at 2022-06-23 17:44:01.867939
# Unit test for function decode
def test_decode():
    """Test decode function."""
    data = b'The quick brown fox jumps over the lazy dog'
    decoded, length = decode(data)
    assert decoded == 'VGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZw=='
    assert length == len(data)



# Generated at 2022-06-23 17:44:14.477226
# Unit test for function decode
def test_decode():
    print("Test Decode")
    print(b64.decode(b'1'))
    print(b64.decode(b'12'))
    print(b64.decode(b'123'))
    print(b64.decode(b'1234'))
    print(b64.decode(b'12345'))
    print(b64.decode(b'123456'))
    print(b64.decode(b'1234567'))
    print(b64.decode(b'12345678'))
    print(b64.decode(b'123456789'))
    print(b64.decode(b'1234567890'))
    print(b64.decode(b'12345678901'))

# Generated at 2022-06-23 17:44:19.745352
# Unit test for function register
def test_register():
    """Unit test of function register."""
    register()
    try:
        # pylint: disable=W0612
        # noinspection PyUnusedLocal
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(
            'The codec name \'b64\' was not registered with Python'
        )



# Generated at 2022-06-23 17:44:23.960912
# Unit test for function encode
def test_encode():
    assert encode("SGFsbG8gV29ybGQKISBXZWxjb21lIHRvIFlvdUF1dGg=")[0] == b"Hello World\n! Welcome to YouAuth"


# Generated at 2022-06-23 17:44:30.718021
# Unit test for function decode

# Generated at 2022-06-23 17:44:41.312660
# Unit test for function decode
def test_decode():
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n\n\n') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n\n\n\n') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9vYmFy\n\n\n\n\n') == ('Zm9vYmFy', 8)

# Generated at 2022-06-23 17:44:45.699892
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    integer = encode('3121')
    assert integer[0] == b'MQ=='
    assert integer[1] == 4

    decimal = encode('23.2')
    assert decimal[0] == b'MjMuMg=='
    assert decimal[1] == 5

    word = encode('word')
    assert word[0] == b'd29yZA=='
    assert word[1] == 4

    binary = encode(
        '0110100001100101011011000110110001101111'
    )
    assert binary[0] == b'aGVsbG8='
    assert binary[1] == 33

    sentence = encode('Hello, world!')
    assert sentence[0] == b'SGVsbG8sIHdvcmxkIQ=='


# Generated at 2022-06-23 17:44:54.847290
# Unit test for function encode

# Generated at 2022-06-23 17:44:59.807240
# Unit test for function decode
def test_decode():
    """Test decode function for input 'qwerty'."""
    data_bytes = b'qwerty'
    encoded_str = decode(data_bytes)[0]
    if encoded_str != 'cXdlcnR5':
        raise Exception



# Generated at 2022-06-23 17:45:02.155714
# Unit test for function encode
def test_encode():
    from test_base64_codec import test_encode as _test_encode
    _test_encode(NAME, encode)



# Generated at 2022-06-23 17:45:13.712414
# Unit test for function decode

# Generated at 2022-06-23 17:45:15.286510
# Unit test for function encode
def test_encode():
    assert encode('base64') == (b'YmFzZTY0', 6)



# Generated at 2022-06-23 17:45:20.434710
# Unit test for function decode
def test_decode():
    data = (
        b'bGVhc3VyZS4=\n'
        b'bGVhc3VyZS4=\n'
        b'bGVhc3VyZS4=\n'
        b'bGVhc3VyZS4=\n'
    )
    actual = decode(data)[0]
    assert actual == 'leasure.' * 4



# Generated at 2022-06-23 17:45:24.110405
# Unit test for function encode
def test_encode():
    """Unit test of function encode."""
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    # assert encode('YWJjZA==') == (b'abcd', 8)
    # assert encode('YWJjZGU=') == (b'abcde', 10)



# Generated at 2022-06-23 17:45:27.427996
# Unit test for function register
def test_register():
    from b64codec.b64 import register
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:45:32.622925
# Unit test for function register
def test_register():
    def _test():
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            register()
            codecs.getdecoder(NAME)
        else:
            raise AssertionError(
                f'The codec {NAME} is already registered.'
            )

    _test()


# Unit test function for function decode

# Generated at 2022-06-23 17:45:41.482231
# Unit test for function decode
def test_decode():  # type: ignore
    assert decode(b'abcdefghijklmnopqrstuvwxyz=+/') == ('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo9Kw==', 25)
    assert decode(b'ABCDEFGHIJKLMNOPQRSTUVWXYZ=+/') == ('QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo9Kw==', 25)

# Generated at 2022-06-23 17:45:44.318093
# Unit test for function encode
def test_encode():
    data = bytes([0x41, 0xFF, 0x10, 0x05])
    got = encode(data)
    want = (b'Qv////////', 4)

    assert got == want


# Generated at 2022-06-23 17:45:52.966121
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""

# Generated at 2022-06-23 17:46:04.298409
# Unit test for function decode
def test_decode():
    assert 'AAECAwQFBgcICQ==' == decode(b'\x00\x01\x02\x03\x04\x05')[0]
    assert 'AAECAwQFBgcICQoLDA0=' == decode(b'\x00\x01\x02\x03\x04\x05\x06')[0]

# Generated at 2022-06-23 17:46:12.144783
# Unit test for function decode
def test_decode():
    # Functionality Test
    assert decode(b'\x00\xf0\x0f\xff') == ('AA/9/', 4)

    # Check that an error is raised if data contains an invalid byte
    with pytest.raises(UnicodeDecodeError) as _e:
        decode(b'\x00\xf0\x0f\xff\xff')

    # Check that an error is raised if data is not a bytes type
    with pytest.raises(TypeError) as _e:
        decode('abc')



# Generated at 2022-06-23 17:46:15.345521
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()

    # Verify that the codec is registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:46:17.338856
# Unit test for function register
def test_register():
    """Unit test for the function 'register()'."""
    register()



# Generated at 2022-06-23 17:46:21.854011
# Unit test for function decode
def test_decode():
    assert decode(b"c3VyZS4=") == ('sure.', 8)
    assert decode(b"IisiLCJzdXJlLg") == ('"",sure.', 13)
    assert decode(b"IisiLCJzdXJlLg==") == ('"",sure.', 15)



# Generated at 2022-06-23 17:46:24.084000
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Check that the function register runs without any exceptions.
    register()


register()


# Generated at 2022-06-23 17:46:28.688421
# Unit test for function encode
def test_encode():
    """Test the encoding function."""
    assert encode(b64_str, errors='strict')[0] == b64_bytes
    assert encode(b64_str, errors='strict')[1] == len(b64_str)



# Generated at 2022-06-23 17:46:40.332578
# Unit test for function decode
def test_decode():
    """Run tests for function decode."""
    # Tests for empty input
    assert decode(b'') == ('', 0)

    # Test base64 string decode
    base64_str = 'JW5hbWU6IFRlc3QgTmFtZQ=='
    test_str = 'Name: Test Name'

    decoded_str = decode(base64_str)
    assert isinstance(decoded_str, tuple)
    assert isinstance(decoded_str[0], str)
    assert decoded_str[1] == len(base64_str)
    assert decoded_str[0] == test_str

    # Test base64 string decode of not proper base64 character string

# Generated at 2022-06-23 17:46:42.900750
# Unit test for function register
def test_register():
    """Unit test for function `register()`."""
    try:
        decode('YQ==', 'replace')
    except LookupError:
        register()


test_register()

# Generated at 2022-06-23 17:46:45.225968
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', len('aGVsbG8gd29ybGQ='))



# Generated at 2022-06-23 17:46:46.838523
# Unit test for function register
def test_register():  # pragma: no cover
    codecs.lookup(NAME)

# Generated at 2022-06-23 17:46:56.336687
# Unit test for function encode
def test_encode():
    base64_characters = '''
        ABCDEFGHIJKLMNOPQRSTUVWXYZ
        abcdefghijklmnopqrstuvwxyz
        0123456789
        +/
    '''
    encoded_bytes, _ = encode(base64_characters)
    assert encoded_bytes == b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNk\nZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0\nNTY3ODkrLw=='



# Generated at 2022-06-23 17:47:02.216354
# Unit test for function encode
def test_encode():
    result = encode(
        '''
        SGVsbG8sIHdvcmxkIQ==
        d2FuZ2RlcmluZyBhbGwgYWdhaW4hSXQncyBiZWNhdXNlIHlvdSB3YW50IHRvIGVzcGFjZSAn'.
        '''
    )

    assert result[0] == b'''
        Hello, world!
        wanting all again!It's because you want to escape '''
    assert result[1] == 98


# Generated at 2022-06-23 17:47:13.593218
# Unit test for function decode
def test_decode():
    """Test the 'decode' function"""

# Generated at 2022-06-23 17:47:18.654794
# Unit test for function decode
def test_decode():
    test_str = 'my test string'
    result = decode(test_str.encode('utf-8'))
    assert result[0] == 'bXkgdGVzdCBzdHJpbmc='
    assert result[1] == len(test_str)


# Generated at 2022-06-23 17:47:24.694650
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``."""

# Generated at 2022-06-23 17:47:32.154672
# Unit test for function decode
def test_decode():
    expected = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    actual = decode(b'ABCDEFGHIJKLMNOPQRSTUVWXYZa')[0]
    try:
        assert expected == actual
    except AssertionError:
        print(f'Expected: {expected!r}')
        print(f'  Actual: {actual!r}')


# Generated at 2022-06-23 17:47:41.091394
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode(' \n') == (b'', 0)
    assert encode(' \n\t') == (b'', 0)
    assert encode('aGVsbG8=\n') == (b'hello', 8)
    assert encode('\n aGVsbG8=\n') == (b'hello', 8)
    assert encode('\n \n aGVsbG8=\n') == (b'hello', 8)
    assert encode('\naGVsbG8=\n') == (b'hello', 8)
    assert encode('aGVs bG8=\n') == (b'he', 3)

#

# Generated at 2022-06-23 17:47:52.425522
# Unit test for function decode
def test_decode():
    """Test the function decode()"""
    # pylint: disable=redefined-builtin,too-many-function-args
    # noinspection PyMissingOrEmptyDocstring
    def check(
            data: _ByteString,
            text: _STR
    ) -> None:
        """
        Args:
            data (bytes or bytearray or memoryview): Bytes to be converted
                to a string of base64 characters.
            text (str): Expected output to the given ``data`` bytes.
        """
        result = decode(data)
        assert result[0] == text
        assert result[1] == len(data)

    # noinspection PyMissingOrEmptyDocstring

# Generated at 2022-06-23 17:48:02.108955
# Unit test for function decode
def test_decode():
    assert decode(
        b'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        b'abcdefghijklmnopqrstuvwxyz+/'
    ) == ('MDEyMzQ1Njc4OUFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaKy8=', 64)


# Generated at 2022-06-23 17:48:09.793481
# Unit test for function encode
def test_encode():
    """Test the encode function"""
    assert encode('') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)
    assert encode('a\nb') == (b'YQpC', 2)
    assert encode('\na') == (b'YQ==', 2)
    assert encode(' \n a ') == (b'YQ==', 5)


# Generated at 2022-06-23 17:48:17.685198
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        assert(codecs.lookup_error(NAME))
    except LookupError:
        assert(False)
    try:
        assert(codecs.lookup_error(NAME).name == NAME)
    except LookupError:
        assert(False)
    else:
        assert(True)


if __name__ == '__main__':
    # pylint: disable=no-value-for-parameter
    test_register()

# Generated at 2022-06-23 17:48:20.018641
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()

    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

# Generated at 2022-06-23 17:48:31.385213
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`~b64.encode`"""
    text = 'YmFzZTY0IGRlY29kZWQgZGF0YSB0ZXh0'
    expected = b'this is some base64 decoded data text'
    actual = encode(text)[0]
    assert expected == actual

    text = 'YmFzZTY0IGRlY29kZWQgZGF0YSB0ZXh0'
    expected = b'this is some base64 decoded data text'
    actual = base64.b64decode(text)
    assert expected == actual

    text = '\nYmFzZTY0IGRlY29kZWQgZGF0YSB0ZXh0'

# Generated at 2022-06-23 17:48:33.120443
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.lookup_error('ascii')
    register()


# Generated at 2022-06-23 17:48:34.620655
# Unit test for function decode
def test_decode():
    assert(decode(b'Zm9v') == ('Zm9v', 4))



# Generated at 2022-06-23 17:48:41.913731
# Unit test for function encode
def test_encode():
    # test 01
    # type = string
    # input = '\n       Hello World\r\n       '
    # expected output = b'SGVsbG8gV29ybGQ='
    # expected output length = 11
    assert encode('\n       Hello World\r\n       ', errors='strict') == (
        b'SGVsbG8gV29ybGQ=', 11
    )
    # input = ''
    # expected output = b''
    # expected output length = 0
    assert encode('', errors='strict') == (b'', 0)
    # input = '\n       1234\n       '
    # expected output = b'MTIzNA=='
    # expected output length = 6

# Generated at 2022-06-23 17:48:53.398444
# Unit test for function decode
def test_decode():
    """Unit Test for function decode"""
    # Test a simple value.
    data = b'\x00'
    expected_out = 'AA=='
    assert decode(data) == (expected_out, 1)

    # Test a simple value.
    data = b'\x00\x00'
    expected_out = 'AAA='
    assert decode(data) == (expected_out, 2)

    # Test a simple value.
    data = b'\x00\x00\x00'
    expected_out = 'AAAA'
    assert decode(data) == (expected_out, 3)

    # Test a simple value.
    data = b'\x00\x00\x00\x00'
    expected_out = 'AAAAAA=='
    assert decode(data) == (expected_out, 4)

   

# Generated at 2022-06-23 17:48:54.341432
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""



# Generated at 2022-06-23 17:49:05.202526
# Unit test for function decode
def test_decode():
    assert decode(b'\x00\x00\x00') == ('AAAA', 3)
    assert decode(b'\x00\x00\x00\x00') == ('AAAAAA==', 4)
    assert decode(b'\x00\x00\x00\x00\x00') == ('AAAAAAA=', 5)
    assert decode(b'\x00\x00\x00\x00\x00\x00') == ('AAAAAAAA', 6)
    assert decode(b'\x00\x00\x00\x00\x00\x00\x00') == ('AAAAAA==', 7)
    assert decode(b'\x00\x00\x00\x00\x00\x00\x00\x00') == ('AAA=', 8)

# Generated at 2022-06-23 17:49:08.571593
# Unit test for function register
def test_register():
    register()
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError(
            'Unit Test Failed:  b64 codec not registered with python'
        )



# Generated at 2022-06-23 17:49:10.215918
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'YWJj', 3)



# Generated at 2022-06-23 17:49:15.547796
# Unit test for function decode
def test_decode():
    test_cases = [
        ('{"a":1}', 'eyJhIjoxfQ=='),
        ('{"b":2}', 'eyJiIjoyfQ=='),
        ('{"c":3}', 'eyJjIjozfQ==')
    ]
    for test in test_cases:
        assert decode(test[0].encode('utf8'))[0] == test[1]


# Generated at 2022-06-23 17:49:23.989213
# Unit test for function encode
def test_encode():
    """Unit testing for the :func:`encode` function."""
    # pylint: disable=W1401
    # pylint: disable=W0212
    from b64 import _b64_codec as codec
    from b64 import decode as b64_decode

    # pylint: disable=W1401
    # pylint: disable=W0212
    from b64 import _b64_codec as codec

    # Happy path tests
    assert codec.encode('YWJj') == (b'abc', 4)
    assert codec.encode('YWJj\n') == (b'abc', 5)
    assert codec.encode('Y\nW\nJ\nj\n') == (b'abc', 6)

# Generated at 2022-06-23 17:49:34.549108
# Unit test for function decode
def test_decode():
    # Test case 1:
    data = b'Hello World'
    expected = 'SGVsbG8gV29ybGQ='
    assert decode(data)[0] == expected

    # Test case 2:
    data = b'Hello World'
    expected = 'SGVsbG8gV29ybGQ='
    assert decode(bytearray(data))[0] == expected

    # Test case 3:
    data = b'Hello World'
    expected = 'SGVsbG8gV29ybGQ='
    assert decode(memoryview(data))[0] == expected

    # Test case 4:
    data = b''
    expected = ''
    assert decode(data)[0] == expected

    # Test case 5:
    data = b'\xfb\xef'

# Generated at 2022-06-23 17:49:35.482486
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    register()

# Generated at 2022-06-23 17:49:42.821748
# Unit test for function register
def test_register():
    """Unit test for 'register'"""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    assert isinstance(obj, codecs.CodecInfo)


if __name__ == '__main__':  # pragma: no cover
    # pylint: disable=line-too-long
    register()

    msg = 'Müller'
    # Convert 'msg' into base64 bytes.
    msg_bytes = msg.encode()
    base64_bytes = base64.b64encode(msg_bytes)
    assert type(base64_bytes) is bytes
    base64_str = base64_bytes.decode()
    assert type(base64_str) is str
    assert base64_str == 'TXVsbGVy'

    # Convert 'base64_str

# Generated at 2022-06-23 17:49:48.660162
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8sIHdvcmxkIQ==')\
        == (b'Hello, world!', 20)
    assert encode('Zm9vIGJhciBmb28gYmFy')\
        ==  (b'foo bar foo bar', 20)
    assert encode('Zm9vIGJhciBmb28gYmFy')\
        ==  (b'foo bar foo bar', 20)


# Generated at 2022-06-23 17:49:59.494464
# Unit test for function decode
def test_decode():
    # Normal case.
    out, num_bytes = decode(b'.', 'strict')
    assert out == r'BA=='
    assert num_bytes == 1

    # Should work with a bytearray
    out, num_bytes = decode(bytearray(b'.'), 'strict')
    assert out == r'BA=='
    assert num_bytes == 1

    # Should work with a memoryview
    out, num_bytes = decode(memoryview(b'.'), 'strict')
    assert out == r'BA=='
    assert num_bytes == 1

    # Should work with an empty input
    out, num_bytes = decode(b'', 'strict')
    assert out == r''
    assert num_bytes == 0



# Generated at 2022-06-23 17:50:06.997273
# Unit test for function decode
def test_decode():
    """Test decode"""
    # pylint: disable=protected-access
    assert decode(b'YQ==')[0][:-1] == 'a'
    assert decode(b'YWI=')[0][:-1] == 'ab'
    assert decode(b'YWJj')[0][:-1] == 'abc'
    assert decode(b'YWJjZA==')[0][:-1] == 'abcd'
    assert decode(b'YWJjZGU=')[0][:-1] == 'abcde'
    assert decode(b'YWJjZGVm')[0][:-1] == 'abcdef'
    assert decode(b'YWJjZGVmZw==')[0][:-1] == 'abcdefg'

# Generated at 2022-06-23 17:50:16.814702
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Register the codec
    register()

    # Check that the codec is registered.
    codecs.getdecoder(NAME)

    # Check that the codec has the expected methods
    b64 = codecs.getdecoder(NAME)  # type: ignore
    assert b64.decode(b'AA==')[0] == '0'
    assert b64.decode(b'AAA=')[0] == '00'
    assert b64.encode(str('0'))[0] == b'AA=='
    assert b64.encode(str('00'))[0] == b'AAA='
    assert b64.encode(str('000'))[0] == b'AAAA'

# Generated at 2022-06-23 17:50:22.687573
# Unit test for function encode
def test_encode():
    """Test that the ``encode`` function works as expected."""
    assert encode('') == (b'', 0)
    assert encode(
        '''
            H4sIAAAAAAAAALWOVY7DMAwF0JrSkhSUpIyEtJTkpNyU0MTJSSkxMTklMTc0tTctT
            BEwzTk0tTcxMTk3MU3NTE3M0lMEAOWYIYBAAAA
        '''
    ) == (b'Hello World', 72)

# Generated at 2022-06-23 17:50:25.523995
# Unit test for function register
def test_register():
    """Unit test for function register

    This function is unlikely to fail.  When it does fail, it is
    because the b64 codec was already registered.
    """
    register()



# Generated at 2022-06-23 17:50:28.508205
# Unit test for function register
def test_register():
    """Test registering the ``b64`` codec with Python."""
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
        codecs.getencoder(NAME)

# Generated at 2022-06-23 17:50:32.230659
# Unit test for function decode
def test_decode():
    """Test the function i2c.b64.decode()."""
    # pylint: disable=missing-function-docstring
    assert decode(b'\x40') == ('PA==', 1)



# Generated at 2022-06-23 17:50:35.502343
# Unit test for function encode
def test_encode():
    expected = b'foo'
    actual, _ = encode('Zm9v')
    assert expected == actual
    assert len(expected) == len(actual)



# Generated at 2022-06-23 17:50:44.603831
# Unit test for function decode
def test_decode():
    """Test the ``decode()`` function."""
    test_text = textwrap.dedent("""
        4paF
        4pKR
        IoKR
        IgKR
        IYKR
        IWKR
        IUKR
        ISKR
    """).strip()
    test_data = b'\x01\x02\x03\x04\x05\x06\x07\x08'
    try:
        out, length = encode(test_text)
    except UnicodeEncodeError:
        assert False
    else:
        assert out == test_data
        assert length == len(test_text)



# Generated at 2022-06-23 17:50:48.382265
# Unit test for function encode
def test_encode():
    s = b'this is a test'
    t = 'dGhpcyBpcyBhIHRlc3Q=\n'
    assert encode(t)[0] == s


# Generated at 2022-06-23 17:50:50.610053
# Unit test for function register
def test_register():
    """Unit Test for function register."""
    try:
        register()
    except Exception:
        print('Cannot register the b64 codec.')



# Generated at 2022-06-23 17:50:52.649440
# Unit test for function decode
def test_decode():
    """Test function decode"""
    assert decode(b'SGVsbG8gV29ybGQ=') == ('Hello World', 15)



# Generated at 2022-06-23 17:50:59.698233
# Unit test for function decode
def test_decode():
    #  noinspection PyAttributeOutsideInit
    class codec_wrapper(UserString):
        """A UserString that allows additional attributes to be added."""
        pass

    # noinspection PyMissingOrEmptyDocstring
    class codec_tester(object):
        # noinspection PyAttributeOutsideInit
        def test_encode(self):
            value = self.input.encode(self.codec)
            assert value == self.expected, (
                f"{self.codec!r} Encode: "
                f"{self.input!r} != {self.expected!r}"
            )

        # noinspection PyAttributeOutsideInit
        def test_decode(self):
            value = self.input.decode(self.codec)

# Generated at 2022-06-23 17:51:00.645239
# Unit test for function register
def test_register():
    """Test that registering the ``b64`` codec
    does not raise an exception.
    """
    register()

# Generated at 2022-06-23 17:51:11.423551
# Unit test for function decode
def test_decode():
    """Test function p64.b64.decode"""
    # Test empty string.
    out = decode(b'')
    assert out[0] == '', 'Unexpected output'
    assert out[1] == 0, 'Unexpected number of data bytes consumed'

    # Test single byte
    out = decode(b'A')
    assert out[0] == 'QQ==', 'Unexpected output'
    assert out[1] == 1, 'Unexpected number of data bytes consumed'

    # Test two bytes
    out = decode(b'AB')
    assert out[0] == 'QUI=', 'Unexpected output'
    assert out[1] == 2, 'Unexpected number of data bytes consumed'

    # Test three bytes
    out = decode(b'ABC')

# Generated at 2022-06-23 17:51:14.486825
# Unit test for function register
def test_register():
    """Test that all codecs can be registered without raising an error."""
    register()

    with pytest.raises(LookupError):
        codecs.getdecoder('unknown')



# Generated at 2022-06-23 17:51:24.109222
# Unit test for function register
def test_register():
    """
    Unit test for function register.

    Test that:
        1. The ``b64`` encoder name is not already in the list of codec
           names.
        2. The name ``b64`` was added to the list of codec names.
        3. The ``b64`` encoder was added to the list of registered
           codecs.
    """
    from typing import Set
    from typing import (
        Tuple,
        Type,
    )
    from typing import List as _List
    from typing import Union as _Union

    def _get_names(obj: Any) -> Set[str]:
        """Get the names of all of the public methods from ``obj``.

        Args:
            obj (Any): The object to be introspected.

        Returns:
            List[str]: the object method names.
        """
       

# Generated at 2022-06-23 17:51:30.921596
# Unit test for function decode
def test_decode():
    test_1 = b'Zm9vCg=='
    test_2 = b'YmFy'
    test_3 = b'YmF6'

    assert decode(test_1)[0] == 'foo\n'
    assert decode(test_2)[0] == 'bar'
    assert decode(test_3)[0] == 'baz'

    try:
        decode(test_3)
    except Error as e:
        assert str(e) == 'Incorrect padding'

# Generated at 2022-06-23 17:51:36.077460
# Unit test for function decode
def test_decode():
    result = decode(b'012')
    expected = 'MDEy'
    assert(result[0]==expected)
    result = decode(b'012',errors='strict')
    expected = 'MDEy'
    assert(result[0]==expected)


# Generated at 2022-06-23 17:51:40.168904
# Unit test for function decode
def test_decode():
    """Test the function :func:`~python_utility.decode`."""
    bytes_decoded = b'abcd'
    result = decode(bytes_decoded)
    assert result[0] == 'YWJjZA=='



# Generated at 2022-06-23 17:51:49.915953
# Unit test for function encode

# Generated at 2022-06-23 17:51:53.795112
# Unit test for function register
def test_register():
    """Test that register properly registers the b64 codec."""
    codecs.codecs_manager.unregister(NAME)
    assert NAME not in codecs.codecs_manager.get_codecs_names()
    register()
    assert NAME in codecs.codecs_manager.get_codecs_names()

# Generated at 2022-06-23 17:51:58.478492
# Unit test for function encode
def test_encode():
    try:
        result = encode('')
    except Exception as e:
        print(f'Function encode raised {e}.')
        return
    out, n = result
    print(f'Function encode returned: {out!r},{n}')


# Generated at 2022-06-23 17:52:08.199119
# Unit test for function encode
def test_encode():
    D01 = '''SGVsbG8sIFdvcmxkIQ==
'''
    D01_ENCODE = 'Hello, World!'
    D01_DEOCODE = D01
    

# Generated at 2022-06-23 17:52:18.522380
# Unit test for function encode
def test_encode():
    print('base64.encode')
    assert encode('cm9vdA==', errors='strict') == (b'root', 6)
    assert encode('cm9vdA==\n', errors='strict') == (b'root', 7)
    assert encode('cm9vdA==\n\n', errors='strict') == (b'root', 8)
    assert encode('cm9vdA==\n\n\n', errors='strict') == (b'root', 9)
    assert encode('cm9vdA==\n\n\n     \n', errors='strict') == (b'root', 14)

# Generated at 2022-06-23 17:52:30.247018
# Unit test for function encode
def test_encode():
    # Test normal cases
    text = 'hello'
    assert text == encode(text)[0].decode('utf-8')
    text = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
    assert text == encode(text)[0].decode('utf-8')

    # Test whitespace
    text = '  \n   \n\t\n  \n'
    assert '' == encode(text)[0].decode('utf-8')

    text = 'aGVsbG8K'
    assert 'aGVsbG8K' == encode(text)[0].decode('utf-8')

   

# Generated at 2022-06-23 17:52:35.451473
# Unit test for function register
def test_register():
    """Test the ``b64.register`` function."""
    register()
    codecs.getencoder(NAME)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    from pytest import main
    main(['-x', '-s', __file__])

# Generated at 2022-06-23 17:52:42.681480
# Unit test for function encode
def test_encode():
    # Assert base64 decoding correctly.
    assert encode('VGhpcyBpcyBzb21lIGJhc2U2NCB0ZXh0') == \
        (b'This is some base64 text', 37)

    # Assert base64 decoding with whitespace correctly.
    assert encode('VGhpcyBpcyBzb21lIGJhc2U2NCB0ZXh0 \n\n') == \
        (b'This is some base64 text ', 37)

    # Assert base64 decoding with indentation correctly.
    assert encode('    VGhpcyBpcyBzb21lIGJhc2U2NCB0ZXh0') == \
        (b'    This is some base64 text', 45)

    # Assert base64 decoding with indentation and whitespace correctly.

# Generated at 2022-06-23 17:52:51.201305
# Unit test for function decode