

# Generated at 2022-06-23 17:42:57.233147
# Unit test for function encode
def test_encode():
    # pylint: disable=W0613
    assert encode('') == (b'', 0)
    assert encode('A') == (b'Bw==', 1)
    assert encode('AB') == (b'QUI=', 2)
    assert encode('ABC') == (b'QUJD', 3)
    assert encode('ABCD') == (b'QUJDRA==', 4)
    assert encode('ABCDE') == (b'QUJDREU=', 5)
    assert encode('ABCDEF') == (b'QUJDREVG', 6)
    assert encode('ABCDEFG') == (b'QUJDREVGRw==', 7)
    assert encode('ABCDEFGH') == (b'QUJDREVGR0g=', 8)

# Generated at 2022-06-23 17:43:01.238180
# Unit test for function register
def test_register():  # pylint: disable=R0201
    """Make sure the codec is registered."""
    from codecs import lookup
    try:
        lookup(NAME)
    except LookupError:
        register()
        lookup(NAME)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:43:08.174958
# Unit test for function decode
def test_decode():
    """This function tests the function decode"""
    decoded = codecs.decode("dGVzdA==", "b64")
    assert decoded == b"test"

    decoded = codecs.decode("dGVzdA", "b64")
    assert decoded == b"test"

    try:
        codecs.decode("dGVzd", "b64")
    except UnicodeEncodeError:
        pass
    else:
        assert False

    try:
        codecs.decode("dGVzdA=", "b64")
    except UnicodeEncodeError:
        pass
    else:
        assert False

    try:
        codecs.decode("dGVzdA==", "b64")
    except Exception:
        assert False


# Generated at 2022-06-23 17:43:19.838126
# Unit test for function encode
def test_encode():
    """Test encode()."""
    assert encode('Hello,World') == (b'SGVsbG8sV29ybGQ=', 11)
    assert encode('Hello, World') == (b'SGVsbG8sIFdvcmxk', 12)
    assert encode(
        '\nHello,\n World\n'
    ) == (b'SGVsbG8sIFdvcmxk', 12)
    assert encode('\n\n\n\nHello,\n\n\n\n World\n') == (b'SGVsbG8sIFdvcmxk', 12)

# Generated at 2022-06-23 17:43:21.118829
# Unit test for function register
def test_register():
    register()

# Unit test the encode function

# Generated at 2022-06-23 17:43:25.748361
# Unit test for function register
def test_register():
    """Unit test for function :meth:`register`"""
    register()
    codecs.getdecoder(NAME)  # Should not raise
    # Cleanup after the test
    del codecs.register._cache[NAME]
    del codecs.register_error.__dict__['cache'][NAME]



# Generated at 2022-06-23 17:43:32.893142
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function"""
    from base64 import standard_b64encode as b64encode

    assert encode('aGVsbG8=') == b64encode(b'hello'), encode('aGVsbG8=')

    assert encode('YWRtaW4=') == b64encode(b'admin'), encode('YWRtaW4=')

    assert encode('') == b64encode(b''), encode('')

    assert encode('aQ==') == b64encode(b'a'), encode('aQ==')

    assert encode('/') == b64encode(b'/'), encode('/')

    assert encode('\n') == b64encode(b'\n'), encode('\n')


# Generated at 2022-06-23 17:43:42.947772
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

    tests = [
        (
            'Hello World!\n',
            b'SGVsbG8gV29ybGQhCg==',
        ),
        (
            'Hello World!',
            b'SGVsbG8gV29ybGQh',
        ),
        (
            'SGVsbG8gV29ybGQh',
            b'U0dWbGJHbHVaRzlpT2lBaVlT',
        ),
    ]
    for test in tests:
        input_str, expected_bytes = test
        actual_bytes, _ = encode(input_str)
        assert actual_bytes == expected_bytes


# Generated at 2022-06-23 17:43:44.217352
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:43:54.141845
# Unit test for function decode

# Generated at 2022-06-23 17:43:55.881874
# Unit test for function decode
def test_decode():
    assert decode(data=b'Man') == ('TWFu', 3)

# Generated at 2022-06-23 17:44:03.886376
# Unit test for function encode
def test_encode():
    x=encode("RW5jb2RlIHRoaXMgc3RyaW5nIGludG8gYmFzZTY0")
    assert isinstance(x,tuple)
    assert x[0] == b'Decode this string into base64'
    assert x[1] == 45
    x=encode("")
    assert isinstance(x,tuple)
    assert x[0] == b''
    #assert x[1] == 45
    x=encode("    \n\t \n   \n\n\n  \t\n")
    assert x == (b'', 0)

# Generated at 2022-06-23 17:44:11.543556
# Unit test for function decode
def test_decode():
    test_list = [
        ('6465617273', 'dears'),
        ('6173', 'as'),
        ('24372437', '$7$7'),
        ('3D3D3D', '===')
    ]
    for arg, expected in test_list:
        arg = arg.encode()
        expected = expected.encode()
        actual = base64.decodebytes(arg)
        assert actual == expected

# Generated at 2022-06-23 17:44:13.407738
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG9Xb3JsZA==') == ('HelloWorld', 12)



# Generated at 2022-06-23 17:44:16.779720
# Unit test for function encode
def test_encode():
    assert encode('SGVsbG8sIHdvcmxkIQ==') == (b'Hello, world!', 20)



# Generated at 2022-06-23 17:44:23.466057
# Unit test for function register
def test_register():
    """Test the register() function.
    """

    register()
    with pytest.raises(TypeError):
        # pylint: disable=too-many-function-args
        codecs.decode(b'AQID', NAME)
        # pylint: disable=too-many-function-args
        codecs.encode('AQID', NAME)

# Generated at 2022-06-23 17:44:30.569581
# Unit test for function decode
def test_decode():
    """Test the ``b64.decode()`` function."""

# Generated at 2022-06-23 17:44:41.272761
# Unit test for function decode
def test_decode():
    utf8 = 'UTF-8'
    # Test a simple ascii string
    simple_ascii_str = 'simple ascii string'
    simple_ascii_bytes = simple_ascii_str.encode(utf8)
    simple_ascii_bytes_b64 = b'c2ltcGxlIGFzY2lpIHN0cmluZw=='
    decoded_str = decode(simple_ascii_bytes_b64)[0]
    assert decoded_str == simple_ascii_str

    # Test a simple unicode string

# Generated at 2022-06-23 17:44:43.479861
# Unit test for function decode
def test_decode():
    """Unit tests for function ``decode()``.
    """
    text = 'QQ=='
    ret = decode(text, 'strict')
    target_bytes = bytes([0x51])

    assert ret == (target_bytes, 1)


# Generated at 2022-06-23 17:44:54.160892
# Unit test for function encode
def test_encode():
    assert encode('QQ==') == (b'\x11', 3)
    assert encode('QQ=\n=') == (b'\x11', 4)
    assert encode('QQ=\n=\n\n') == (b'\x11', 6)
    assert encode('QQ=\n=\n\n    \n') == (b'\x11', 10)

    with pytest.raises(UnicodeEncodeError):
        assert encode('QQ=')

    with pytest.raises(UnicodeEncodeError):
        assert encode('QQ=\n')

    with pytest.raises(UnicodeEncodeError):
        assert encode('QQ=\n    \n')

    assert encode('') == (b'', 0)



# Generated at 2022-06-23 17:44:59.807006
# Unit test for function register
def test_register():
    """Unit test for function :meth:`register`."""
    # Register the codec.
    register()

    # Test to make sure the codec is registered.
    decoder = codecs.getdecoder(NAME)   # type: ignore
    assert decoder is not None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:45:03.985638
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8K') == ('aGVsbG8=\n', 8)
    assert decode(b'aGVsbG8K') == ('aGVsbG8=\n', 8)
    assert decode(b'aGVsbG8K') == ('aGVsbG8=\n', 8)

# Generated at 2022-06-23 17:45:05.843280
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:45:08.400067
# Unit test for function register
def test_register():
    """Test the :obj:`register` function."""
    codecs.register(_get_codec_info)


register()

# Generated at 2022-06-23 17:45:16.245572
# Unit test for function encode
def test_encode():
    text = """
    ZXhwaXJlZCA9IGZhbHNlCmFwcGxpY2F0
    aW9uX2lkID0gImFwcDoxOjUifQo="""
    text2 = """
    ZXhwaXJlZCA9IGZhbHNlCmFwcGxpY2F0
    aW9uX2lkID0gImFwcDoxOjUifQo="""
    assert encode(text) == encode(text2)



# Generated at 2022-06-23 17:45:24.502382
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)

    assert encode('AbCd==') == (b'AbCd', 5)
    assert encode('AbCd=') == (b'AbCd', 4)
    assert encode('AbCd') == (b'AbCd', 4)

    assert encode('AbCd== \n\n') == (b'AbCd', 5)
    assert encode('AbCd= \n\n') == (b'AbCd', 4)
    assert encode('AbCd \n\n') == (b'AbCd', 4)

    assert encode('AbCd==\n\n') == (b'AbCd', 5)
    assert encode('AbCd=\n\n') == (b'AbCd', 4)

# Generated at 2022-06-23 17:45:29.780756
# Unit test for function decode
def test_decode():
    assert decode(b'\x01\x02\x03', 'strict')[0] == 'AQID'
    assert decode(b'\x01\x02\x03', 'strict')[1] == 3
    assert decode(b'\x01\x02\x03')[1] == 3

# Generated at 2022-06-23 17:45:33.662865
# Unit test for function decode
def test_decode():
    # Tests cases with an incorrect input argument.
    got = decode([1, 2, 3])
    assert got == ('AQID', 3)

    # Tests cases with valid input arguments.
    got = decode(b'AAAA')
    assert got == ('QUFB', 4)

    got = decode(b'AAECAwQ=');
    assert got == ('QUFBQ0F3UQ==', 8)

    got = decode(b'AAECAwQF')
    assert got == ('QUFBQ0F3UUY=', 9)

    got = decode(b'AAECAwQFBAM')
    assert got == ('QUFBQ0F3UUZCQU0=', 12)

    got = decode(b'AAECAwQFBQU')

# Generated at 2022-06-23 17:45:37.484417
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    assert decode(b"herllo world") == ('aGVybGxvIHdvcmxk', 11)
    assert decode(bytearray(b"herllo world")) == ('aGVybGxvIHdvcmxk', 11)

# Generated at 2022-06-23 17:45:43.357929
# Unit test for function register
def test_register():
    """Unit test of function register."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        register()

    decoder = codecs.getdecoder(NAME)
    assert str(decoder) == (
        "<built-in function codecs.text_decoders."
        "getdecoder('b64')>"
    )

    encoder = codecs.getencoder(NAME)
    assert str(encoder) == (
        "<built-in function codecs.text_encoders."
        "getencoder('b64')>"
    )


# pylint: disable=W0613

# Generated at 2022-06-23 17:45:52.803472
# Unit test for function encode
def test_encode():
    # Given
    text_str = '''
        SGFsbG8gV29ybGQhCg==
    '''
    text_input = str(text_str)
    bytes_input = text_input.strip().encode('utf-8')
    result = base64.b64decode(bytes_input)

    # When
    encoded, size = encode(text_input)

    # Then
    assert encoded == result
    assert isinstance(encoded, bytes)
    assert isinstance(size, int)


# Generated at 2022-06-23 17:46:04.298267
# Unit test for function register
def test_register():
    from unittest import mock
    mock_query = mock.Mock()
    mock_register = mock.Mock()
    mock_register.return_value = None
    mock_codec = mock.Mock(  # type: ignore
        query=mock_query,  # type: ignore
        register=mock_register,  # type: ignore
    )
    with mock.patch.object(codecs, 'register', mock_register):
        with mock.patch.object(codecs, 'getdecoder', mock_query):
            with mock.patch('codecs', mock_codec):
                register()
                mock_query.assert_called_once()
                mock_register.assert_not_called()

    # Clear the mock history
    mock_query.reset_mock()
    mock_register.reset

# Generated at 2022-06-23 17:46:14.652910
# Unit test for function decode
def test_decode():
    """Test the `decode` function.

    The `decode` function is tested by examples from the
    [Wikipedia](https://en.wikipedia.org/wiki/Base64) page.
    """

    def _test(
        byte_input: bytes,
        expected_char_output: str,
        expected_bytes_used: int
    ):
        char_output, bytes_used = decode(byte_input, '')
        assert bytes_used == expected_bytes_used
        assert char_output == expected_char_output

    # Wikipedia examples of Base64
    # https://en.wikipedia.org/wiki/Base64
    _test(
        b'Man',
        'TWFu',
        3
    )
    _test(
        b'Ma',
        'TWE=',
        2
    )
    _test

# Generated at 2022-06-23 17:46:18.409358
# Unit test for function encode
def test_encode():
    from test.test_b64x import test_data
    for text_input, bytes_output in test_data:
        assert encode(text_input)[0] == bytes_output


# Generated at 2022-06-23 17:46:25.837538
# Unit test for function decode
def test_decode():
    """Exercise the ``decode`` function."""
    input_data = b'\xfb\xef\x7f'

    # Test correct processing
    output_data, length = decode(input_data)
    assert output_data == '////'
    assert length == len(input_data)

    # Test NotImplementedError
    encoder = codecs.getencoder(NAME)
    error_msg = 'Encode not implemented for codec b64'
    with pytest.raises(NotImplementedError, match=error_msg):
        encoder(input_data)



# Generated at 2022-06-23 17:46:32.549524
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    actual = encode('aGVsbG8gd29ybGQ=')
    expected = (b'hello world', 13)
    assert actual == expected



# Generated at 2022-06-23 17:46:34.481477
# Unit test for function register
def test_register():
    codecs.lookup_error(NAME)
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-23 17:46:41.073921
# Unit test for function register
def test_register():
    # pylint: disable=protected-access
    backup = codecs.__lookup_cache
    codecs.__lookup_cache = {}
    assert NAME not in codecs._get_codec_cache()
    register()
    assert NAME in codecs._get_codec_cache()
    codecs.__lookup_cache = backup



# Generated at 2022-06-23 17:46:42.901010
# Unit test for function register
def test_register():
    """ Test the register function. """
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:46:44.696691
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'AAABAC==') == ('444444', 5)



# Generated at 2022-06-23 17:46:56.336212
# Unit test for function encode
def test_encode():
    text_str = ('CAACAgIAAxkBAANrV7pHxC_8V7gBkY-Lz7DEGlk'
                'a3IXXmQACXQIAAq0BAANqYw-Lz7DEGlka3IXXmQFAA')
    text_bytes = b'\x01\x02\x03\x04\x05\x06\x07\x08'
    f = encode(text_str)
    assert f[0] == text_bytes
    assert f[1] == len(text_str)
    assert encode(text_str, errors='surrogateescape') == f
    assert encode(text_str, errors='surrogatepass') == f
    assert encode(text_str, errors='replace') == f

# Generated at 2022-06-23 17:46:57.369678
# Unit test for function decode
def test_decode():
    """docstring for test_decode"""
    pass

# Generated at 2022-06-23 17:47:02.389523
# Unit test for function encode
def test_encode():
    """Unit test for the function encode."""
    text = """
    QWxhZGRpbjpvcGVuIHNlc2FtZQ==
    """
    out, _ = encode(text)
    assert out == b"Aladdin:open sesame"

# Generated at 2022-06-23 17:47:06.133478
# Unit test for function decode
def test_decode():
    b64_str = 'Yg=='
    input_bytes = b'b'
    output_str, _ = decode(input_bytes)
    assert output_str == b64_str



# Generated at 2022-06-23 17:47:10.708096
# Unit test for function register
def test_register():
    """
    The test_register performs a unit test on the register function in the
    module.

    See Also:
        :func:`~.register`
    """
    with pytest.raises(LookupError):
        register()


# Generated at 2022-06-23 17:47:20.231620
# Unit test for function encode
def test_encode():
    assert encode('SSdtIGtpbGxpbmcgeW91ciBicmFpbiBsaWtlIGEgcG9pc29ub3VzIG11c2hyb29t') == (
        b'I\x02\xec\x00\x0f\x16\xef\x17\x08\xff\x04\xc7\x11\x80\x12\x86\x08\x0f\x04\xf6\xe9\x17\x0e\xc1\x04\x0f',
        56
    )



# Generated at 2022-06-23 17:47:22.714805
# Unit test for function register
def test_register():
    """Test that the ``register`` function works correctly."""
    import builtins
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

    assert NAME in builtins.__dict__.keys()



# Generated at 2022-06-23 17:47:27.386236
# Unit test for function register
def test_register():
    """Unit test for function register"""
    b64_codec = codecs.getdecoder(NAME)
    assert b64_codec('YWJj') == ('abc', 0)



# Generated at 2022-06-23 17:47:33.849314
# Unit test for function register
def test_register():
    """Test the function ``register()`` for the ``b64`` module."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('The "b64" codec should be registered.')


if __name__ == '__main__':
    print(
        f'{NAME} module is not intended to be executed directly.\n'
        'To register the "b64" codec with Python use the "register" '
        'function.'
    )

# Generated at 2022-06-23 17:47:35.878478
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    return


# Generated at 2022-06-23 17:47:36.985958
# Unit test for function register
def test_register():
    r = register()
    assert not r


# Generated at 2022-06-23 17:47:39.655166
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()



# Generated at 2022-06-23 17:47:50.866018
# Unit test for function encode
def test_encode():
    assert encode('A')[0] == bytes([0])
    assert encode('AA')[0] == bytes([0, 0])
    assert encode('AAA')[0] == bytes([0, 0, 0])
    assert encode('AAAA')[0] == bytes([0, 0, 0, 0])
    assert encode('AAAAA')[0] == bytes([0, 0, 0, 0, 0])
    assert encode('AAAAAA')[0] == bytes([0, 0, 0, 0, 0, 0])
    assert encode('AAAAAAA')[0] == bytes([0, 0, 0, 0, 0, 0, 0])
    assert encode('AAAAAAAA')[0] == bytes([0, 0, 0, 0, 0, 0, 0, 0])

# Generated at 2022-06-23 17:47:59.525925
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    # Test that an empty string returns
    # an empty string.
    text_input = ''
    text_str = text_input.strip()
    text_str = '\n'.join(
        filter(
            lambda x: len(x) > 0,
            map(lambda x: x.strip(), text_str.strip().splitlines())
        )
    )

    # Convert the cleaned text into utf8 bytes
    text_bytes = text_str.encode('utf-8')

# Generated at 2022-06-23 17:48:10.220424
# Unit test for function register
def test_register():  # pylint: disable=W0612
    """Unit test for the function register."""
    # pylint: disable=W0603,W0622,W0613
    #   W0603  - use of global statement
    #   W0622  - Redefining built-in <name>
    #   W0613  - Unused argument <name>
    #
    # In this case, the unused argument is expected to be unused.
    global codecs
    global NAME
    import codecs
    old_decode_func = codecs.getdecoder(NAME)
    old_encode_func = codecs.getencoder(NAME)
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        register()

# Generated at 2022-06-23 17:48:20.385777
# Unit test for function decode
def test_decode():
    """Test :func:`decode()`."""

# Generated at 2022-06-23 17:48:23.466479
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-23 17:48:24.500033
# Unit test for function decode
def test_decode():
    bytes_out = decode(b'ABC')
    assert bytes_out == ('QUJD', 3)


# Generated at 2022-06-23 17:48:33.302735
# Unit test for function decode
def test_decode():
    """Test of the decoding function.

    Verify the function properly decodes from base64 strings in the
    following ways:

    * Bytes are returned for the string
    * The bytes returned are the same as those returned if we
        encode then decode the given string using the base64 standard
        library module.

    """
    # Define the values to convert to a base64 character string.
    data_to_encode = b'\x44\x45\x46\x47\x48\x49\x50'

    # Convert the 'data_to_encode' bytestring into a base64 string.
    base64_string = decode(data_to_encode)[0]

    # Decode the base64 string using the standard library to values
    # of type 'bytes'.
    stdlib_bytes: bytes = base64.b64dec

# Generated at 2022-06-23 17:48:38.421329
# Unit test for function register
def test_register():
    """Test that the function ``register`` works as expected."""
    # pylint: disable=W0212
    assert NAME not in codecs._cache  # type: ignore
    assert NAME not in codecs.aliases._aliases
    register()
    assert NAME in codecs._cache  # type: ignore
    assert NAME in codecs.aliases._aliases
    # Repeat registration, should be fine
    register()
    assert NAME in codecs._cache  # type: ignore
    assert NAME in codecs.aliases._aliases

# Generated at 2022-06-23 17:48:50.203194
# Unit test for function register
def test_register():
    # Make sure ``b64`` is not already registered.
    codecs.unregister(NAME)

    # Make sure that ``b64`` is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False

    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        assert False

    # Register ``b64`` with the python codecs module.
    register()

    # Make sure register ``b64`` is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        pass

    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-23 17:48:53.594561
# Unit test for function register
def test_register():
    """Test that the b64 codec is not already registered with Python."""
    if NAME == 'b64':
        codecs.lookup(NAME)


# Generated at 2022-06-23 17:48:55.515890
# Unit test for function register
def test_register():  # pylint: disable=R0201,W0613,W0612
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:48:58.311662
# Unit test for function decode
def test_decode():
    assert decode(b'\x98sr\x8c\xcc\xd3\x01\xa3\x8c') == ('fwsr+/I=', 7)


# Generated at 2022-06-23 17:49:00.645602
# Unit test for function register
def test_register():
    """Test registration of the ``b64`` codec."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:49:01.629998
# Unit test for function encode
def test_encode():
    bytes_a = b'a'

    a = encode(bytes_a)[0]
    assert a == b'YQ=='


# Generated at 2022-06-23 17:49:12.550339
# Unit test for function encode
def test_encode():
    """Unit test for 'encode' function."""
# pylint: disable=W0612,R0201
    from binascii import Error as BinasciiError
    from hashlib import md5

    def _test_input(inp: str, expected: str) -> None:
        """Perform the encode unit test for the given input."""
        encoded = encode(inp)[0]
        if not isinstance(encoded, bytes):
            raise TypeError
        if not isinstance(expected, bytes):
            raise TypeError
        if not md5(encoded).hexdigest() == md5(expected).hexdigest():
            raise AssertionError(
                f'{inp!r} did not encode to expected value.  Expected {expected!r} but got {encoded!r}'
            )


# Generated at 2022-06-23 17:49:19.245363
# Unit test for function encode
def test_encode():
    # Test a valid base64 string.
    test_data_1 = 'aGVsbG8gd29ybGQ='
    test_result_1 = encode(test_data_1)
    assert test_result_1[0] == b'hello world'

    # Test an invalid base64 string.
    test_data_2 = 'aGVsbG8gd29ybG'
    with pytest.raises(UnicodeEncodeError) as e:
        encode(test_data_2)
    assert e.value.reason == (
        f'{test_data_2!r} is not a proper bas64 character string: '
        'Incorrect padding'
    )


# Generated at 2022-06-23 17:49:25.924494
# Unit test for function decode
def test_decode():
    input_string = "AQAAAAAAAP__9P__9P__9P__9P__9P__9P__9P__9"
    expected = b'\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa'
    assert decode(input_string)[0] == expected

# Generated at 2022-06-23 17:49:29.315403
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:49:35.611949
# Unit test for function encode
def test_encode():
    """Test encode"""
    data = '\x00\x01\x02\x03\x04\x05\x06\x07'
    out, _ = encode(data)
    assert out == b'\x00\x01\x02\x03\x04\x05\x06\x07'
    try:
        encode('XX')  # pylint: disable=W0104
        assert False
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-23 17:49:37.805403
# Unit test for function register
def test_register():
    """Verify the function register works as expected."""
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:49:48.359626
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    def expected_register():
        codecs.register(_get_codec_info)

    def expected_getdecoder():
        codecs.getdecoder(NAME)

    # Unregister the 'b64' codec if it is in the 'codecs' table.
    # pylint: disable=broad-except
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    except Exception:
        raise

    # Call the 'register' function.
    register()

    # Assert the codecs.register function was called.
    with patch('codecs.register') as m_c_r:
        m_c_r.side_effect = expected_register
        register()
    m_c_r.assert_called()

    # Ass

# Generated at 2022-06-23 17:49:59.647364
# Unit test for function encode
def test_encode():
    """Testing the encode function"""
    test_str = '~`!@#$%^&*()-_=+qwertyuiop[]{}\\|asdfghjkl;\':\",./<>?🐶'
    result_base64 = 'fmAgIUAjJCVeJiooKS1fPX4KcXdlcnR5dWlvcFtde30KXHwKYXNkZmdoamtsOydcIicsLzw+P8/8J+Qn+CflA=='
    encoded_str = base64.b64encode(test_str.encode())

# Generated at 2022-06-23 17:50:07.078551
# Unit test for function register
def test_register():
    """Test the b64 module's register function."""
    import copy
    import sys
    module_b64 = __import__(__name__, fromlist=[''])
    fake_module = copy.deepcopy(module_b64)
    is_registered = NAME in codecs.encode.__func__.__globals__
    try:
        module_b64.register()
    finally:
        if not is_registered:
            fake_module.register()
    is_registered = NAME in codecs.encode.__func__.__globals__

# Generated at 2022-06-23 17:50:09.291717
# Unit test for function decode
def test_decode():
    assert decode(b"hello") == ("aGVsbG8=", 5)


# Generated at 2022-06-23 17:50:14.869170
# Unit test for function encode
def test_encode():
    """
    Test encode function function
    """
    str1 = '0X1'
    str2 = 'I am a string'
    str3 = "Hello\nWorld"
    assert encode(str1) == (b'\x00\x01', 3)
    assert encode(str2) == (b'I am a string', 12)
    assert encode(str3) == (b'Hello\nWorld', 11)


# Generated at 2022-06-23 17:50:17.876389
# Unit test for function encode
def test_encode():
    """Test function encode"""
    assert (
        encode('dGhpcw0KbGlicmFyeQ==') == (
            b'this\nlibrary',
            len('dGhpcw0KbGlicmFyeQ==')
        )
    )



# Generated at 2022-06-23 17:50:20.951616
# Unit test for function decode
def test_decode():
    input = "c2t3ZWJnYzIw"
    output = (b"skwebgc20", 10)
    assert decode(input) == output # pass
    
    

# Generated at 2022-06-23 17:50:27.082593
# Unit test for function encode
def test_encode():
    assert 'YXNkZg==' == encode('asdf')
    assert 'YXNkZg==' == encode('a\nb\rc\td\fe')

    bad_text = 'a\nb\rc\td\fg'
    try:
        encode(bad_text)
    except Exception as e:
        assert 'is not a proper bas64 character string' in str(e)



# Generated at 2022-06-23 17:50:37.611179
# Unit test for function decode
def test_decode():
    test_input = b'\x1F\xD8\x00\xDA\x08\x01\x00\x0C\xFF\xEE\x00\xE1'
    expected_output = '/+/AAAA/wAAP//AAD/'
    output = decode(test_input)
    assert output[0] == expected_output
    assert output[1] == len(test_input)
    assert decode(b'\x01')[0] == 'AA=='
    assert 'AA==' == decode(b'\x01')[0]
    assert 'AAA=' == decode(b'\x01\x01')[0]
    assert 'AAAA' == decode(b'\x01\x01\x01')[0]

# Generated at 2022-06-23 17:50:41.596188
# Unit test for function decode
def test_decode():
    data: bytes = b'\x01\x00\x01'
    expected_data = b'AQAB'
    actual_data = base64.b64encode(data)
    assert actual_data == expected_data



# Generated at 2022-06-23 17:50:52.621638
# Unit test for function encode
def test_encode():
    # pylint: disable=R0914
    """Test function ``encode``."""
    from ..data.various import DATA_BASE64
    from ..data.various import DATA_BYTES
    from .binascii import b2a_base64
    from .binascii import a2b_base64
    from .bytes import b
    from .bytes import bord

    def get_b64_bytes() -> bytes:
        """Get the encoded base64 bytes using binary string."""
        return b(b2a_base64(DATA_BYTES))

    def get_b64_string() -> str:
        """Get the base64 string directly."""
        return DATA_BASE64

    # Test the binary encoded base64 bytes.

# Generated at 2022-06-23 17:50:54.640248
# Unit test for function register
def test_register():
    """Test ``register`` function."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:50:58.937497
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    coder = codecs.getdecoder(NAME)
    assert coder.__name__ == 'decode'
    coder = codecs.getencoder(NAME)
    assert coder.__name__ == 'encode'



# Generated at 2022-06-23 17:51:09.014908
# Unit test for function encode
def test_encode():
    """Test the ``b64.encode`` function."""
    # pylint: disable=protected-access
    assert encode('\x00\x01\x02\x03') == (b'AAECAw==', 8)
    assert encode('\x00\x01\x02\x03' + ' ' * 8) == (b'AAECAw==', 16)
    assert encode('\x00\x01\x02\x03' + '\n' * 8) == (b'AAECAw==', 16)
    assert encode('\x00\x01\x02\x03' + '\n' * 10) == (b'AAECAw==', 20)

# Generated at 2022-06-23 17:51:11.520328
# Unit test for function register
def test_register():
    register()
    codecs.register(_get_codec_info)

# Generated at 2022-06-23 17:51:13.382438
# Unit test for function encode
def test_encode():
    assert encode('Zm9vCmJhcg==') == b'foo\nbar'



# Generated at 2022-06-23 17:51:18.889496
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    test_data = [
        ("base64 text", "YmFzZTY0IHRleHQ="),
        ("another base64 text", "YW5vdGhlciBiYXNlNjQgdGV4dA=="),
    ]
    for text, data in test_data:
        encoded, length = decode(data.encode('utf-8'))
        assert text == encoded



# Generated at 2022-06-23 17:51:30.540873
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import types
    import functools

    # pylint: disable=C0103
    global_namespace = sys.modules['__main__'].__dict__

    # Save the names in the global namespace
    old_names = set(global_namespace.keys())

    # Register the codec
    register()

    # Get the difference between the old and new set of names.
    new_names = set(global_namespace.keys()) - old_names

    # Ensure that there is only one new attribute and that it is a
    # function with the name we expect.
    assert len(new_names) == 1
    new_name = list(new_names)[0]
    assert new_name == NAME

# Generated at 2022-06-23 17:51:36.077983
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME) # type: ignore
    assert NAME == obj.name
    assert decode == obj.decode  # type: ignore[attr-defined]
    assert encode == obj.encode  # type: ignore[attr-defined]



# Generated at 2022-06-23 17:51:42.788914
# Unit test for function decode
def test_decode():
    """Test decoding bytes to base64 char."""
    data = b'0\xcew\x93\xc2\x03\x95\x9e\xc8\xa1\xcc\x84\xfb\xde\xc7\x03\xbe'
    result = decode(data)
    assert result[0] == 'MOt8vy+tjaDV7PFQGUoX9j7k'
    assert result[1] == len(data)


# Generated at 2022-06-23 17:51:44.692257
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert(decoder is not None)

# Generated at 2022-06-23 17:51:46.168981
# Unit test for function register
def test_register():
    """Unit test for function register"""
    _test_register()

# Generated at 2022-06-23 17:51:50.810009
# Unit test for function encode
def test_encode():
    assert encode(':"') == (b'\'\':', 3)
    assert encode('a:') == (b'bg==', 2)
    assert encode(' "') == (b'Ig==', 2)
    assert encode('  "') == (b'ICA=', 3)
    assert encode('   "') == (b'ICAg', 4)


# Generated at 2022-06-23 17:51:53.800583
# Unit test for function decode
def test_decode():
    data_bytes = b'Hello World!'
    text, n = decode(data_bytes)
    assert text == 'SGVsbG8gV29ybGQh'
    assert n == len(data_bytes)


# Generated at 2022-06-23 17:52:04.799448
# Unit test for function encode
def test_encode():
    # Test decoding the base64 characters on a single line into bytes.
    text = 'U3VpdGF0ZWdsYXNnY2VuY2VzIGVyZSBjb21wZXRpdGl2ZSBzdWl0YXRlIGdsYXNnY2VuY2VzLg=='
    input_ = (text, 'strict')
    output = encode(*input_)
    assert output == (
        b'Suitegraphicscences are competitive suite graphicscences.',
        len(text)
    )

    # Test decoding the base64 characters on multiple lines into bytes.

# Generated at 2022-06-23 17:52:14.689454
# Unit test for function decode
def test_decode():
    # Base64 Testing
    assert 'YmFzZTY0' == base64.b64encode('base64'.encode('utf-8'))
    assert 'base64' == base64.b64decode('YmFzZTY0'.encode('utf-8')).decode('utf-8')

    data = b'12345\xf3\x0a'
    b64_data = base64.b64encode(data)
    b64_str = b64_data.decode('utf-8')
    print('b64_str:', b64_str)

    out_str, length = decode(data)
    print('out_str:', out_str)
    print('length:', length)


test_decode()

# Generated at 2022-06-23 17:52:21.784320
# Unit test for function encode
def test_encode():
    import unittest

    class EncodeTestCase(unittest.TestCase):
        """Unit test class for the function `encode`"""
        def test_return_type_when_given_none(self):
            """Test the return value when given `None`"""
            self.assertEqual(
                encode(None),
                (b'', 0)
            )

        def test_return_type_when_given_empty_string(self):
            """Test the return value when given an empty string"""
            self.assertEqual(
                encode(''),
                (b'', 0)
            )

        def test_return_type_when_given_one_character(self):
            """Test the return value when given a string with one character"""

# Generated at 2022-06-23 17:52:25.305626
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    assert codecs.getdecoder(NAME)(b'') == ('', 0)
    assert codecs.getencoder(NAME)('') == (b'', 0)

# Generated at 2022-06-23 17:52:28.960294
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    text = base64.b64encode(b'Hello World')
    result = decode(text)
    assert result == ('SGVsbG8gV29ybGQ=', 12)
    

# Generated at 2022-06-23 17:52:31.117854
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


register()


# Generated at 2022-06-23 17:52:40.489928
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    test_data = (
        (b'\x01\x02\x03\x04', 'AQIDBA=='),
        (b'\x00', 'AA=='),
        (b'\x00\x00', 'AAA='),
        (b'\x00\x00\x00', 'AAAA'),
        (b'', ''),
        (bytes(13), 'DQo='),
        (bytes(13) + b'\x00', 'DQogAA=='),
    )
    for test in test_data:
        input_data, expected_str = test
        assert decode(input_data)[0] == expected_str



# Generated at 2022-06-23 17:52:44.177776
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    test_register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-23 17:52:52.029929
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    # pylint: disable=too-many-function-args
    # noinspection PyTypeChecker
    assert b64.decode('AaGVsbG8gd29ybGQ=')[0] == 'Hello world'
    # noinspection PyTypeChecker
    assert b64.decode(b'SGVsbG8gd29ybGQ=')[0] == 'Hello world'
    # noinspection PyTypeChecker
    assert b64.decode(b'QQ==')[0] == 'A'
    # noinspection PyTypeChecker
    assert b64.decode(b'cA==')[0] == 'a'
    # noinspection PyTypeChecker