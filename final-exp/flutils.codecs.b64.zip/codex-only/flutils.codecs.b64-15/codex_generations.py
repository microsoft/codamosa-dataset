

# Generated at 2022-06-23 17:42:42.111620
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:42:46.413870
# Unit test for function decode
def test_decode():
    """Unit test for the b64.decode function."""
    data = b'\x01\x02\x03\x04'
    out = decode(data)
    assert out[0] == 'AQIDBA=='
    assert out[1] == 4



# Generated at 2022-06-23 17:42:57.766559
# Unit test for function encode
def test_encode():
    import sys, io
    # pylint: disable=C0302
    def _get_bytes(b64: _STR) -> bytes:
        sys.stdout = io.StringIO()
        try:
            out = bytes.fromhex(''.join(b64.split()))
        except ValueError:
            raise
        finally:
            sys.stdout = sys.__stdout__
        return out

    def _str_to_list(
        text: _STR
    ) -> Tuple[List[str], List[str], List[str]]:
        """Split the given string into a list of characters, a list of
        words, and a list of lines.
        """
        # Convert the given 'text', that are of type UserString into a str.
        text_input = str(text)

        # Cleanup whitespace

# Generated at 2022-06-23 17:43:05.562805
# Unit test for function encode
def test_encode():
    # Test: 0
    text = '''
    dGVzdA==
    '''
    out, count = encode(text)
    assert out == b'test'
    assert count == len(text)

    # Test: 1
    text = '''
    dGVzdA==
    '''
    out, count = encode(text)
    assert out == b'test'
    assert count == len(text)

    # Test: 2
    text = '''
    dGVzdA==
    '''
    out, count = encode(text)
    assert out == b'test'
    assert count == len(text)

    # Test: 3
    text = '''
    dGVzdA==
    '''
    out, count = encode(text)
    assert out == b'test'


# Generated at 2022-06-23 17:43:11.595222
# Unit test for function encode
def test_encode():
    assert encode('\n') == (b'', 0)
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWE=') == (b'aa', 4)
    assert encode('YWFh') == (b'aaa', 4)
    assert encode('YWFhcg==') == (b'aaar', 8)



# Generated at 2022-06-23 17:43:14.138546
# Unit test for function decode
def test_decode():
    assert decode(b'**&') == ('KioxKg==', 4)
    assert decode(b'') == ('', 0)


# Generated at 2022-06-23 17:43:17.076232
# Unit test for function register
def test_register():
    codec_info = codecs.lookup(NAME)
    assert (codec_info.name == NAME)



# Generated at 2022-06-23 17:43:22.518639
# Unit test for function encode
def test_encode():
    text = b'\xc0\x80'
    text_bytes = base64.standard_b64encode(text)
    expect_bytes = bytes(text_bytes)
    out, len_out = encode(text_bytes)
    assert out == expect_bytes
    assert len_out == len(text_bytes)

# Generated at 2022-06-23 17:43:24.772015
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-23 17:43:31.643477
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    # Let's make sure the 'b64' codec is not registered.
    try:
        codecs.getdecoder(NAME)
        assert False, 'b64 is already registered'
    except LookupError:
        pass

    # Now let's register it.
    register()

    # Let's make sure the 'b64' codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'unable to register the b64 codec'



# Generated at 2022-06-23 17:43:43.269480
# Unit test for function register
def test_register():
    """Test the :func:`register` function by registering the ``b64`` codec
    with Python and then attempting to obtain the codec to verify the
    registration.
    """
    # Ensure the codec is not registered.
    try:
        codecs.lookup_codec(NAME)
        assert True is False
    except LookupError:
        pass

    try:
        codecs.getencoder(NAME)
        assert True is False
    except LookupError:
        pass

    try:
        codecs.getdecoder(NAME)
        assert True is False
    except LookupError:
        pass

    # Register the codec.
    register()

    # Check that the codec was registered correctly.
    try:
        codecs.lookup_codec(NAME)
    except LookupError:
        assert True is False

   

# Generated at 2022-06-23 17:43:53.713222
# Unit test for function encode
def test_encode():
    assert encode('U29tZXRoaW5n') == (b'Something', 13)
    assert encode('') == (b'', 0)
    assert encode(' \n \n\n\nS29tZXRoaW5n\n\n') == (b'Something', 15)
    assert encode('dGhpcyBpcyBhIHZlcnkgbG9uZyBzdHJpbmc=') == (b'this is a very long string', 38)
    assert encode('dGhpcyBpcyBhIHZlcnkgaW5jb21wbGV0ZSBzdHJpbmc=') == (b'this is a very incomplete string', 45)



# Generated at 2022-06-23 17:43:55.015751
# Unit test for function register
def test_register():
    register()
    pass



# Generated at 2022-06-23 17:44:04.623494
# Unit test for function register
def test_register():
    """Test function register.
    """
    # Get the current encoding
    import sys
    old_encoding = sys.getdefaultencoding()

    # Set the encoding to ascii
    sys.setdefaultencoding('ascii')
    try:
        # Try to get an encoding for the b64 codec
        codecs.lookup('b64')
        # if the above command does not raise a LookupError, the codec
        # is already registered.
    except LookupError:
        # Try to register the b64 codec
        register()

        # Try again to get an encoding for the b64 codec, if we still
        # raise a LookupError, then the test failed.
        codecs.lookup('b64')

    # Reset the encoding back to the default
    sys.setdefaultencoding(old_encoding)




# Generated at 2022-06-23 17:44:09.938679
# Unit test for function register
def test_register():
    """Test the register function."""
    assert NAME not in codecs.decode._cache
    assert NAME not in codecs.encode._cache
    register()
    assert NAME in codecs.decode._cache
    assert NAME in codecs.encode._cache


# Generated at 2022-06-23 17:44:20.722669
# Unit test for function decode
def test_decode():
    """Testing the `decode` utility function."""
    r = codecs.getdecoder(NAME)

    # error_text = 'bad_b64'
    # with pytest.raises(UnicodeDecodeError) as info:
    #     r(error_text)
    # assert info.value.args[0] == f'{NAME!r} codec can\'t decode byte 0x62 in position 0: {error_text!r}'
    # assert info.value.args[1] == error_text
    # assert info.value.args[2] == 0
    # assert info.value.args[3] == len(error_text)
    # assert info.value.args[4] == 'bad base64 character'

    test_input = '''

Zm9vYmFy

'''

# Generated at 2022-06-23 17:44:30.878240
# Unit test for function encode
def test_encode():
    """Test encode to ensure it interprets eol and whitespace correctly."""
    text: str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'  # noqa: E501

    # eol, empty line
    text_input = (
        text + '\n' +
        '\n' +
        text + '\n'
    )
    text_str = (
        text + '\n' +
        text
    )
    text_bytes = base64.b64encode(text_str.encode('utf-8'))
    out, _ = encode(text_input)
    assert out == text_bytes

    # eol

# Generated at 2022-06-23 17:44:41.435294
# Unit test for function decode
def test_decode():
    # type: () -> None
    """Unit test for function encode.
    """
    from pytest import approx
    from base64 import b64encode
    import random
    import string

    for _ in range(10):
        _length = random.randint(1, 100)
        _data = bytes(
            random.choices(
                string.ascii_letters + string.digits,
                k=_length
            )
        )

        _data_encoded = b64encode(_data).decode('utf8')
        assert len(_data) == len(_data_encoded)
        assert decode(_data) == (_data_encoded, len(_data))

        assert decode(_data[0:]) == (_data_encoded, len(_data))


# Generated at 2022-06-23 17:44:42.881548
# Unit test for function decode
def test_decode():  # pragma: no cover
    """Run the unit tests contained in this module."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:44:53.930357
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode(' \n \n \n ') == (b'', 0)
    assert encode('   ') == (b'', 0)
    assert encode('    ') == (b'', 0)
    assert encode('     ') == (b'', 0)
    assert encode('  \n  \n  \n  ') == (b'', 0)
    assert encode('a') == (b'YQ==', 1)

# Generated at 2022-06-23 17:44:58.130853
# Unit test for function decode
def test_decode():
    # Arrange
    text_input = "SGVsbG8gV29ybGQu"

    # Act
    out, _ = decode(text_input)

    # Assert
    assert out == "Hello World."


# Generated at 2022-06-23 17:45:07.098319
# Unit test for function decode
def test_decode():
    assert decode(b'\t\n\t\n')   == ('Cg==', 4)
    assert decode(b'\n\n\t\t')   == ('AA==', 4)
    assert decode(b'\n\n')       == ('AA==', 2)
    assert decode(b'\n')         == ('AA==', 1)
    assert decode(b'\n\n\t\n')   == ('AAAA', 4)

    assert decode(b'\n\t\n\t')   == ('AAIA', 4)
    assert decode(b'\n\t\t\n')   == ('AAEA', 4)
    assert decode(b'\t\n\t\t')   == ('AQAA', 4)


# Generated at 2022-06-23 17:45:17.791226
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    assert encode('SGVsbG8sIFdvcmxkIQ==')[0].decode() == 'Hello, World!'

    assert encode('YWJjZA==')[0].decode() == 'abcd'

    assert encode('YWJjZA==')[0].decode() == 'abcd'

    # Allow for spaces that can appear in the encoding.
    assert encode('YWJjZA ==')[0].decode() == 'abcd'

    # Allow for line breaks that can appear in the encoding.
    assert encode('YWJjZA\n==')[0].decode() == 'abcd'

    assert encode('YWJjZA==\n')[0].decode() == 'abcd'

    # Allow for lines of different lengths.

# Generated at 2022-06-23 17:45:25.154499
# Unit test for function encode

# Generated at 2022-06-23 17:45:31.308317
# Unit test for function register
def test_register():
    """Test the register() function."""
    from . import b64  # pylint: disable=import-outside-toplevel

    # pylint: disable=import-outside-toplevel
    from .b64 import NAME as B64_NAME

    test_name = B64_NAME
    register()
    assert codecs.getdecoder(test_name) == (b64.decode, b64.encode)

# Generated at 2022-06-23 17:45:35.879514
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    d = codecs.getdecoder(NAME)
    assert d is not None and isinstance(d, codecs.CodecInfo) and \
        d.name == NAME and d.encode is encode and d.decode is decode



# Generated at 2022-06-23 17:45:43.413673
# Unit test for function encode
def test_encode():
    # Test 1
    text_input = 'YW55IGNhcm5hbCBwbGVhcw=='
    text_str = 'any carnal pleasu'
    text_bytes = text_str.encode('utf-8')
    text_b64_bytes = base64.decodebytes(text_bytes)
    out, num_bytes = encode(text_input)
    assert out == text_b64_bytes
    assert num_bytes == len(text_input)

    # Test 2
    text_input = '''
            YW55IGNhcm5hbCBwbGVhcw==
'''
    text_str = 'any carnal pleasu'
    text_bytes = text_str.encode('utf-8')

# Generated at 2022-06-23 17:45:48.330912
# Unit test for function register
def test_register():
    """Unit test for function :func:`~register`"""
    register()
    decode('b64_chars')
    encode(b'bytes')

# Generated at 2022-06-23 17:45:57.038556
# Unit test for function encode
def test_encode():
    """Unit test for the :func:`encode` function"""
    r = encode('bGV4')
    assert r == (b'lex', 4)
    r = encode('bGV4\n')
    assert r == (b'lex', 5)
    r = encode('bGV4')
    assert r == (b'lex', 4)

    txt1 = """\
bGV4
Cg==
"""
    r = encode(txt1)
    assert r == (b'lex\n', len(txt1))

    txt2 = """\
bGV4
Cg==
"""
    r = encode(txt2)
    assert r == (b'lex\n', len(txt2))

    txt3 = """\
bGV4
Cg==
"""
    r = encode(txt3)


# Generated at 2022-06-23 17:45:58.725409
# Unit test for function encode
def test_encode():
    assert(encode('aGVsbG8=') == (b'hello', 4))



# Generated at 2022-06-23 17:46:03.610160
# Unit test for function decode
def test_decode():
    assert decode(b'bXkgbmFtZSBpcyBqb2hu')[0] == 'bXkgbmFtZSBpcyBqb2hu'


# Generated at 2022-06-23 17:46:14.063824
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('a')[0] == b'a'
    assert encode('A')[0] == b'QQ=='
    assert encode('a')[0] == b'a'
    assert encode(' a ')[0] == b'a'
    assert encode(' a ') == encode(' a ')
    assert encode('  a ') == encode(' a ')
    assert encode(' a  ') == encode(' a ')
    assert encode(' a  ') == encode(' a  ')
    assert encode(' a   ') == encode(' a  ')
    assert encode(' a a ') == encode('YWE=')
    assert encode(' a  a ') == encode('YWE=')
    assert encode(' a   a ') == encode('YWE=')

# Generated at 2022-06-23 17:46:16.867684
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    decoder = codecs.getdecoder(NAME)  # type: ignore
    assert callable(decoder)

# Generated at 2022-06-23 17:46:18.781904
# Unit test for function register
def test_register():
    # There is no way to test this without affecting the entire Python
    # process.
    pass

# Generated at 2022-06-23 17:46:27.723941
# Unit test for function decode
def test_decode():
    func = decode
    assert func(b'\x01\x02\x03\x04\x05', errors='strict') == ('AQIDBAU=', 4)
    assert func(b'\x01\x02\x03\x04\x05', errors='ignore') == ('AQIDBAU=', 4)
    assert func(b'\x01\x02\x03\x04\x05', errors='replace') == ('AQIDBAU=', 4)
    assert func(b'\x01\x02\x03\x04\x05', errors='xmlcharrefreplace') == ('AQIDBAU=', 4)

# Generated at 2022-06-23 17:46:35.936846
# Unit test for function register
def test_register():
    """Unit test for function register."""
    test_codec_info = _get_codec_info(NAME)
    assert test_codec_info is not None

    test_codec_info.encode(
        '\n'.join([
            'QQo=',
            'QQo=',
            'QQo=',
        ])
    )
    assert test_codec_info.decode(b'foobar') == 'Zm9vYmFy'


# pylint: disable=W0621
# noinspection PyUnusedLocal

# Generated at 2022-06-23 17:46:46.256635
# Unit test for function decode
def test_decode():
    from binascii import hexlify
    from string import ascii_lowercase

    assert decode('b64')[0] == 'YjY0'
    assert decode('b64')[1] == len('b64')

    assert decode('b64\x00b64')[0] == 'YjY0YjY0'
    assert decode('b64\x00b64')[1] == len('b64\x00b64')

    assert decode('b64YjY0')[0] == 'YjY0YjY0'
    assert decode('b64YjY0')[1] == len('b64YjY0')

    assert decode(b'b64')[0] == 'YjY0'

# Generated at 2022-06-23 17:46:48.902743
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register codec.'



# Generated at 2022-06-23 17:46:55.501997
# Unit test for function register
def test_register():
    """Unit test for the function ``register``."""
    # Assert that the codec is not registered with python to begin with.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)  # type: ignore

    # Register the codec.
    register()

    # Assert that the codec was registered.
    codecs.getdecoder(NAME)


# Unit tests for the functions decode and encode.

# Generated at 2022-06-23 17:46:59.218436
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered correctly."""
    base64_codec = codecs.getdecoder(NAME)
    assert base64_codec


# pylint: disable=R0914
# noinspection PyUnusedLocal,PyPep8Naming

# Generated at 2022-06-23 17:47:03.727954
# Unit test for function encode
def test_encode():
    """Test ``encode`` fuction."""
    assert encode('>¦@Ç=') == (b'Pg_DQiA9', 12)
    assert encode('Ew-') == (b'RXct', 4)

# Generated at 2022-06-23 17:47:05.746743
# Unit test for function register
def test_register():
    """Unit test for ``register``."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:47:07.579192
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8=') == (b'hello', 8)



# Generated at 2022-06-23 17:47:18.200127
# Unit test for function encode
def test_encode():
    assert encode('AAAA') == (b'\x00', 4), f'{encode("AAAA")!r}'
    assert encode('AA==') == (b'\x00\x00', 4), f'{encode("AA==")!r}'
    assert encode('AA') == (b'\x00', 2), f'{encode("AA")!r}'
    assert encode('AQ==') == (b'\x01', 4), f'{encode("AQ==")!r}'
    assert encode('AQ') == (b'\x01', 2), f'{encode("AQ")!r}'
    assert encode('Ag==') == (b'\x02', 4), f'{encode("Ag==")!r}'

# Generated at 2022-06-23 17:47:20.030452
# Unit test for function decode
def test_decode():
    assert list(decode(b'hello'))[0] == 'aGVsbG8='


# Generated at 2022-06-23 17:47:25.409441
# Unit test for function decode

# Generated at 2022-06-23 17:47:35.451434
# Unit test for function encode
def test_encode():
    """Test encode() function."""
    # pylint: disable=C0415
    # noinspection PyProtectedMember
    from typing import Text
    from typing import Optional
    from b64codec import encode
    from b64codec import decode
    from b64codec import register
    from b64codec import NAME

    # Register the codec to allow decoding.
    register()

    # Simple case.
    assert encode('abc') == (b'abc', 3)
    assert encode(b'abc') == (b'abc', 3)
    assert encode(Text('abc')) == (b'abc', 3)

    # Check that the input string is properly decoded.
    assert decode(encode('abc')) == ('abc', 3)
    assert decode(encode('Hello World')) == ('Hello World', 11)

   

# Generated at 2022-06-23 17:47:40.651761
# Unit test for function decode
def test_decode():
    # test the codecs.decode function.
    # noinspection SpellCheckingInspection
    encoded_str = (
        'dGhpcyBpcyB0aGUgYmFzZTY0IGVuY29kaW5nIG9mIHRleHQ='
    )
    decoded_text = (
        'this is the base64 encoding of text'
    )
    assert decode(encoded_str)[0] == decoded_text



# Generated at 2022-06-23 17:47:43.270846
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

# Generated at 2022-06-23 17:47:53.257019
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('YQ==', 1)
    assert decode(b'ab') == ('YWI=', 2)
    assert decode(b'abc') == ('YWJj', 3)
    assert decode(b'abcd') == ('YWJjZA==', 4)
    assert decode(b'abcde') == ('YWJjZGU=', 5)
    assert decode(b'abcdef') == ('YWJjZGVm', 6)
    assert decode(b'abcdefg') == ('YWJjZGVmZw==', 7)
    assert decode(b'abcdefgh') == ('YWJjZGVmZ2g=', 8)
    assert decode(b'abcdefghi') == ('YWJjZGVmZ2hp', 9)

# Generated at 2022-06-23 17:48:00.025170
# Unit test for function encode

# Generated at 2022-06-23 17:48:10.283576
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode(' ') == (b'', 0)

    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)

    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)

    assert encode('YWJjZGVm\n') == (b'abcdef', 8)
    assert encode('YWJjZGVm\n    ') == (b'abcdef', 8)

# Generated at 2022-06-23 17:48:14.076359
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:48:21.512266
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    # pylint: disable=import-outside-toplevel
    import sys
    import unittest

    # Setup unit testing.
    register()

    # See if the codec was properly registered.
    codec_info = codecs.getdecoder(NAME)

    class TestRegister(unittest.TestCase):
        """Test that register was properly performed."""

        def test_register_is_codecs_CodecInfo(self) -> None:
            """Test that the ``register`` function is CodecInfo object."""
            self.assertIsInstance(codec_info, codecs.CodecInfo, 'CodecInfo')

    sys.exit(unittest.main())


# Generated at 2022-06-23 17:48:23.112184
# Unit test for function decode
def test_decode():
    """"
    In this test, we check that the output of the encode function is equivalent to the expected output
    """
    assert decode(b'test') == ('dGVzdA==', 4)


# Generated at 2022-06-23 17:48:26.891520
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    print(NAME)
    print(b'aGFsbG8='.decode(NAME))
    print('Hello'.encode(NAME))
    # Test the context manager.
    with codecs.open('test.txt', 'r', NAME) as file_input:
        print(file_input.read())

# Generated at 2022-06-23 17:48:36.719179
# Unit test for function encode
def test_encode():
    decoded = 'This is an example string'
    encoded = 'VGhpcyBpcyBhbiBleGFtcGxlIHN0cmluZw=='

    decoded_bytes = codecs.decode(encoded, NAME)
    print(decoded_bytes)
    assert decoded == decoded_bytes.decode('utf-8')

    # Multiple lines of b64 characters.
    decoded_bytes = codecs.decode(
        '\n'.join([encoded, encoded]),
        NAME
    )
    print(decoded_bytes)
    assert decoded + decoded == decoded_bytes.decode('utf-8')

    # Indented lines of b64 characters.

# Generated at 2022-06-23 17:48:39.353211
# Unit test for function decode
def test_decode():
    assert decode(b'TmFtZQ==')[0] == 'Name'
    assert decode(b'TmFtZQ==')[1] == 4



# Generated at 2022-06-23 17:48:45.611436
# Unit test for function register
def test_register():
    """
    Unit test for function :func:`register`.
    """
    register()
    assert NAME in codecs.__all__
    assert encode(u'où') == (b'b8O', 3)  # type: ignore[no-untyped-call]
    assert decode(b'b8O') == ('où', 3)  # type: ignore[no-untyped-call]

# Generated at 2022-06-23 17:48:56.435311
# Unit test for function decode
def test_decode():
    # Test with 2 byte input
    data = b'\x00\x01'
    expected_str = 'AAE='
    str_out, _ = decode(data)

    # Test with 4 byte input
    data = b'\x00\x01\x00\x02'
    expected_str = 'AAEBAQ=='
    str_out, _ = decode(data)

    # Test with 6 byte input
    data = b'\x00\x01\x00\x02\x00\x03'
    expected_str = 'AAEBAQI='
    str_out, _ = decode(data)

    # Test with 8 byte input
    data = b'\x00\x01\x00\x02\x00\x03\x00\x04'

# Generated at 2022-06-23 17:49:07.193657
# Unit test for function decode
def test_decode():
    """Test for the function :func:`decode`"""
    def test(text: _STR, expected: str) -> None:
        """Test the function :func:`decode` with the given inputs
        and expected output.

        Args:
            text (str): The input strings to be encoded.
            expected (str): The expected output.
        """
        actual, length = decode(text)
        msg = (
            f"'{text}' encoded as base64 should be '{expected}' but was '"
            f"{actual}'"
        )
        assert actual == expected, msg


# Generated at 2022-06-23 17:49:14.189958
# Unit test for function decode
def test_decode():
    # Test all variations of 'A'
    assert decode(bytes([0])) == ('AA==', 1)
    assert decode(bytes([17])) == ('Mg==', 1)
    assert decode(bytes([34])) == ('MzQ=', 1)
    assert decode(bytes([51])) == ('MzU=', 1)
    assert decode(bytes([68])) == ('Njg=', 1)
    assert decode(bytes([85])) == ('ODU=', 1)
    assert decode(bytes([102])) == ('ZmI=', 1)
    assert decode(bytes([119])) == ('b3c=', 1)
    assert decode(bytes([136])) == ('4LA=', 1)
    assert decode(bytes([153])) == ('4LQ=', 1)

# Generated at 2022-06-23 17:49:22.862562
# Unit test for function encode
def test_encode():
    """Test the encode function."""

    # Test function 'encode'
    assert encode('dGhpcyBpcyBhIHN0cmluZw==') == \
       (b'this is a string', 22)

    # Test function 'encode' on input not completely in the
    # base64 alphabet.

# Generated at 2022-06-23 17:49:27.551560
# Unit test for function decode
def test_decode():
    """Test the decoding of the base64 codec"""
    t = "This is a test"
    s = decode(t)
    assert s[0] == "VGhpcyBpcyBhIHRlc3Q=", "Supporting Text must be decoded properly "
    print(s[0])
    print("Decoding is successful")


# Generated at 2022-06-23 17:49:29.962621
# Unit test for function encode
def test_encode():
    """Test the encode function of this module."""
    assert encode("Hello world") == (b"SGVsbG8gd29ybGQ=", 12)


# Generated at 2022-06-23 17:49:36.586568
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'aGVsbG8=\n', 5)
    assert encode('\x01') == (b'AA==\n', 1)
    assert encode('') == (b'\n', 0)
    with pytest.raises(UnicodeEncodeError) as e:
        encode('\x00')
    assert e.value.reason == "b64: '\\x00' is not a proper bas64 character string: Incorrect padding"

# Generated at 2022-06-23 17:49:39.035687
# Unit test for function decode
def test_decode():
    data = b'\x01\x10\x81\x80\xFF'
    expected_str = 'AHEAIw=='
    result = decode(data)
    assert result == (expected_str, 5)



# Generated at 2022-06-23 17:49:42.791330
# Unit test for function decode
def test_decode():
    """Test the decode function of the 'b64' codec."""
    data = b'hello'
    actual = decode(data)
    expected = ('aGVsbG8=', 5)
    msg = (
        f"Expected: '{expected[0]}' {expected[1]}\n"
        f"Actual:   '{actual[0]}' {actual[1]}"
    )
    assert actual == expected, msg


# Generated at 2022-06-23 17:49:44.716249
# Unit test for function encode
def test_encode():
    encoded = encode('TWFu')
    assert encoded == (b'Man', 4)



# Generated at 2022-06-23 17:49:45.314184
# Unit test for function decode
def test_decode():
    pass

# Generated at 2022-06-23 17:49:56.880160
# Unit test for function encode
def test_encode():
    # pylint: disable=W0621
    #     Redefining name 'test' from outer scope
    # pylint: disable=C0103
    #     Invalid name "test" (should match [a-z_][a-z0-9_]{2,30}$)

    # Set the base64 encode functions to the Python base64 functions.
    from ._b64 import _BASE64_ENCODE_FUNC, set_base64_encode_func
    set_base64_encode_func(_BASE64_ENCODE_FUNC)

    from ._b64 import encode as test_encode_func

    # Test data with base64 decode errors.

# Generated at 2022-06-23 17:50:05.169528
# Unit test for function encode

# Generated at 2022-06-23 17:50:11.520513
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    text = "dGhpcyBpcyBhIHRlc3Q="
    expected_result = b'this is a test'
    length = 16
    actual_result = encode(text)
    if actual_result == (expected_result, length):
        print("Text encoded correctly!")
    else:
        print("Test failed.")


# Generated at 2022-06-23 17:50:12.870098
# Unit test for function register
def test_register():
    """Test the register function."""
    reg = codecs.lookup(NAME)
    assert reg.name == NAME
    assert reg.decode == decode
    assert reg.encode == encode

# Generated at 2022-06-23 17:50:20.440985
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    # Test: Should pass on any given bytes.
    for i in range(0, 100):
        data = bytes([i])
        out, _ = decode(data)
        assert out == 'AQ=='

    # Test: Should return the same string for a given byte sequence.
    byte_seq = b'\x31\x32\x33\x34\x35\x36\x37\x38\x39\x40\x41\x42\x43\x44\x45\x46\x47\x48\x49\x50'
    out, _ = decode(byte_seq)
    assert out == 'MTIzNDU2Nzg5QEFDREVGR0hJ'

    # Test: Should raise UnicodeEncodeError when bytes decode to a long

# Generated at 2022-06-23 17:50:23.372647
# Unit test for function decode
def test_decode():
    assert decode(b'eW91IGNhbid0IHJlYWQgdGhpcyE=') == ('you cant read this!', 24)



# Generated at 2022-06-23 17:50:32.251256
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8gd29ybGQ=')[0] == 'hello world'
    assert decode(b'SGVsbG8gV29ybGQ=')[0] == 'Hello World'
    assert decode(b'SGVsbG8gV2VsY29tZQ==')[0] == 'Hello Welcome'
    assert decode(b'Tm9Xb3JsZE9o')[0] == 'NoWorldOh'
    assert decode(b'TWFkZSBpbiBNYXNzYWNodXNldHRz')[0] == 'Made in Massachusetts'
    assert decode(b'T25lTWFpblRoZXJl')[0] == 'OneMainThere'

# Generated at 2022-06-23 17:50:37.151672
# Unit test for function register
def test_register():
    normal = codecs.lookup('normal')
    try:
        register()
        register()
        assert codecs.lookup(NAME) is not None
        assert codecs.lookup('normal') is normal
    finally:
        codecs.unregister(NAME)
        assert codecs.lookup('normal') is normal


# Generated at 2022-06-23 17:50:49.093772
# Unit test for function decode
def test_decode():
    # pylint: disable=unused-variable
    def do_assert(
            data,
            b64_str_out,
    ):
        b64_str_decode, _ = decode(data)
        assert b64_str_decode == b64_str_out

    b64_str_out = 'IHNoYWxsIGJlIGFsbCB0aGF0IHlvdSBjYW4g'
    b64_str_out += 'YmU=\n'
    b64_str_out += 'ICAgICAgICAgICAgeW91IG11c3QgcHJvdmlkZS'
    b64_str_out += 'IHRoZSBkZXRhaWxzLg=='


# Generated at 2022-06-23 17:50:56.647752
# Unit test for function decode
def test_decode():
    for value in [
        # (input, expected_output)
        (b'ABC', 'QUJD'),
        (b'TWE=', 'VFdF'),
        (b'TWEK', 'VFdF'),
        (b'TWE=K', 'VFdF'),
        (b'TWE=\n', 'VFdF'),
        (b'TWE\n', 'VFdF'),
        (b'TWE\n=', 'VFdF'),
        (b'TW\nEK', 'VFdF'),
    ]:
        assert decode(value[0])[0] == value[1]



# Generated at 2022-06-23 17:51:07.807866
# Unit test for function encode
def test_encode():
    """Unit test for ``encode``."""
    s = """
       SGVsbG9Xb3JsZCBBcHBsZQ==   # HelloWorld Apple
       SGVsbG9Xb3JsZCBNb3ppbGxh # HelloWorld Mozilla
       SGVsbG9Xb3JsZCBIVFYsIFdXUw== # HelloWorld HTTP, WWW
       """

# Generated at 2022-06-23 17:51:16.900695
# Unit test for function register
def test_register():
    """Test the function :func:`register`"""
    # Test that the ``b64`` codec was not registered.
    try:
        codecs.getdecoder('b64')
    except LookupError:
        pass
    else:
        raise Exception(
            'The codec "b64" was already registered before '
            'this test was run.'
        )

    # Register the b64 codec
    register()

    # Test that the b64 codec was registered.
    try:
        codecs.getdecoder('b64')
    except LookupError as e:
        raise Exception(f'Failed to register the b64 codec: {e}')



# Generated at 2022-06-23 17:51:21.972533
# Unit test for function register
def test_register():
    # noinspection PyBroadException
    try:
        codecs.getdecoder(NAME)
        registered = True
    except Exception:
        registered = False

    if not registered:
        codecs.register(_get_codec_info)  # type: ignore

    # noinspection PyBroadException
    try:
        codecs.getdecoder(NAME)
        registered = True
    except Exception:
        registered = False

    assert registered

# Generated at 2022-06-23 17:51:24.868929
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    raise SystemExit(pytest.main([__file__]))

# Generated at 2022-06-23 17:51:32.815800
# Unit test for function decode
def test_decode():
    """Unit test for the ``decode`` function."""
    input_bytes = b'\x00\x01\x02\x0a\x0b\x0c\x0d\x0e\x0f\xff'
    ref_str = "AAECCgwREhI="
    ref_len = 10

    out_str, out_len = decode(input_bytes)

    # Compare the 'out_str' against the 'ref_str'.
    assert out_str == ref_str

    # Compare the 'out_len' against the 'ref_len'
    assert out_len == ref_len


# Generated at 2022-06-23 17:51:40.491138
# Unit test for function encode
def test_encode():
    """
    Test convert a base64 character string into base64 bytes
    """
    encode_result1, length1 = encode('abcdefghijklmnopqrstuvwxyz')
    assert encode_result1 == b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    assert length1 == 26
    encode_result2, length2 = encode('\n \t\n')
    assert encode_result2 == b''
    assert length2 == 3



# Generated at 2022-06-23 17:51:42.567783
# Unit test for function register
def test_register():
    """Test that ``b64`` is registered."""
    register()
    # codecs.getdecoder(NAME)   # type: ignore



# Generated at 2022-06-23 17:51:48.077099
# Unit test for function encode
def test_encode():
    # pylint: disable=C0116
    text_str = 'SGkgaWdlIGZlZCBzYW5kIGJsYW5rIHRp'
    text_bytes = text_str.encode('utf-8')
    encoded = base64.b64decode(text_bytes)
    decoded, _ = encode(text_str)
    assert encoded == decoded


# Generated at 2022-06-23 17:51:58.861300
# Unit test for function decode
def test_decode():
    assert decode(b'a')[0] == 'YQ=='
    assert decode(b'aa')[0] == 'YWE='
    assert decode(b'aaa')[0] == 'YWFh'
    assert decode(b'aaaa')[0] == 'YWFhYQ=='
    assert decode(b'aaaaa')[0] == 'YWFhYWE='
    assert decode(b'aaaaaa')[0] == 'YWFhYWFh'
    assert decode(b'aaaaaaa')[0] == 'YWFhYWFhYQ=='
    assert decode(b'aaaaaaaa')[0] == 'YWFhYWFhYWE='
    assert decode(b'aaaaaaaaa')[0] == 'YWFhYWFhYWFh'

# Generated at 2022-06-23 17:52:08.426984
# Unit test for function encode
def test_encode():
    """Test the function encode."""
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'\n', 1)
    assert encode('\r') == (b'\r', 1)
    assert encode('\r\n') == (b'\r\n', 2)
    assert encode('\t') == (b'\t', 1)
    assert encode(' ') == (b' ', 1)
    assert encode('A') == (b'A', 1)
    assert encode('c') == (b'c', 1)
    assert encode('\n \n') == (b'\n \n', 3)
    assert encode(' a') == (b' a', 2)
    assert encode('  \na') == (b'  \na', 4)

# Generated at 2022-06-23 17:52:13.957740
# Unit test for function encode
def test_encode():
    test_data = '''\
V2VsY29tZSB0byB5b3VyIG5ldyBhcHBsaWNhdGlvbi4=
'''
    expected_result = b'Welcome to your new application.'
    out, _ = encode(test_data)
    assert out == expected_result



# Generated at 2022-06-23 17:52:21.977369
# Unit test for function encode
def test_encode():
    assert encode('Q3JlYXRlZCBieSBBYXR0ZWtyaW4') == (  # type: ignore
        b'Created by Attarkrin',
        41,
    )
    assert encode('Qml0bWFwIFZlcnNpb24gMjAxMS4=') == (  # type: ignore
        b'Bitmap Version 2011.',
        30,
    )
    assert encode('Qml0bWFwIFZlcnNpb24gMjAxMS44') == (  # type: ignore
        b'Bitmap Version 2011.',
        30,
    )

# Generated at 2022-06-23 17:52:24.925756
# Unit test for function register
def test_register():
    """Test the register function."""
    from unittest.mock import patch
    from wavepipe.b64 import codecs as m_codecs

    def mock_getdecoder(name: str):
        raise LookupError(f'{name} was not registered.')

    mock_codecs = patch.object(
        m_codecs, 'getdecoder', side_effect=mock_getdecoder
    ).start()
    _ = mock_codecs.getdecoder
    register()



# Generated at 2022-06-23 17:52:36.260698
# Unit test for function register
def test_register():    # -type: ignore
    """Test the ``register`` function."""

# Generated at 2022-06-23 17:52:42.811724
# Unit test for function encode
def test_encode():
    """Test the function: encode."""
    s = '''
    123
    456
    789
    abc
    def
    ghi
    jkl
    mno
    '''    # pragma: no cover
    assert encode(s) == (
        b'\x124Vx\x90\xab\xcd\xef\x89\xab\xcd\xef\x89\xab\xcd\xef'
        b'\x89\xab\xcd\xef\x89\xab\xcd\xef\x89\xab\xcd\xef\x89\xab\xcd\xef',
        111
    )