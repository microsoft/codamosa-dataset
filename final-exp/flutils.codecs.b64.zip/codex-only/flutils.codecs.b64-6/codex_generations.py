

# Generated at 2022-06-23 17:42:48.746463
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG8gV29ybGQh') == ('SGVsbG8gV29ybGQh', 14)
    assert decode(b'IA==',) == (' ', 1)
    assert decode(b'IA==',) == (' ', 1)
    assert decode(b'Cg==',) == ('\n', 1)
    assert decode(b'\r\nCg==',) == ('\n', 3)
    assert decode(b'\nCg==',) == ('\n', 2)
    assert decode(b'\tCg==',) == ('\n', 2)
    assert decode(b'\t\nCg==',) == ('\n', 3)
    assert decode(b'Cg== ',) == ('\n', 1)

# Generated at 2022-06-23 17:42:58.497051
# Unit test for function decode
def test_decode():
    """
        Test Cases for the decode function
    """
    assert decode(b'QUJDREVGRw==') == ('ABCDEFGH', 8)
    assert decode(b'QUJDREVGRw=') == ('ABCDEFGH', 8)
    assert decode(b'QUJDREVGRw') == ('ABCDEFGH', 8)
    assert decode(b'QUJDREVGRw==') == ('ABCDEFGH', 8)
    assert decode(b'QUJDREVGRw==') == ('ABCDEFGH', 8)
    assert decode(b'QUJDREVGRw==') == ('ABCDEFGH', 8)
    assert decode(b'QUJDREVGRw==') == ('ABCDEFGH', 8)


# Generated at 2022-06-23 17:43:06.046367
# Unit test for function register
def test_register():
    import os
    import pathlib
    import sys
    import unittest
    import warnings

    # Change the path to run the test only.
    sys.path.insert(0, pathlib.Path(os.path.abspath(__file__)).parent.as_posix())

    class TestEncoding(unittest.TestCase):
        def setUp(self) -> None:
            warnings.simplefilter('ignore', ResourceWarning)

        def test_sanity(self):
            # Assert the 'b64' module is not in the Python's codecs.
            if NAME in sys.modules:
                del sys.modules[NAME]
            self.assertNotIn(Name, sys.modules)
            self.assertIsNone(getattr(sys.modules[__name__], NAME, None))

# Generated at 2022-06-23 17:43:10.424627
# Unit test for function decode
def test_decode():
    """Test :meth:`decode`."""
    assert encode('dGVzdA==') == b'test'


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-23 17:43:19.781477
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec can be registered."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


if __name__ == '__main__':  # pragma: no cover
    print(decode(b'aGVsbG8gd29ybGQ='))
    print(encode('aGVsbG8gd29ybGQ='))
    print(encode(decode(b'aGVsbG8gd29ybGQ=')))
    print(decode(encode('aGVsbG8gd29ybGQ=')))
    register()

# Generated at 2022-06-23 17:43:24.818848
# Unit test for function register
def test_register():
    """Test the function register"""
    assert NAME not in [x[0] for x in codecs.__dict__['_cache'].values()]
    register()
    assert NAME in [x[0] for x in codecs.__dict__['_cache'].values()]



# Generated at 2022-06-23 17:43:29.282730
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'foo') == ('Zm9v', 3)
    assert decode(b'foo\nbar') == ('Zm9vYmFy', 7)
    assert decode(b'foobar') == ('Zm9vYmFy', 6)


# Generated at 2022-06-23 17:43:40.582441
# Unit test for function decode
def test_decode():
    for text in (
            'YWJjZA==',
            'YWJjZA',
            'YWJjZA\n',
    ):
        _, index = decode(text.encode('utf-8'))
        assert index == len(text)

    for text in (
            'YWJjZA=',
            'YWJjZ\n',
        ):
        with pytest.raises(UnicodeEncodeError) as err:
            decode(text.encode('utf-8'))
            assert err.text == text
            assert err.start == 0
            assert err.end == len(text)


# Generated at 2022-06-23 17:43:49.696448
# Unit test for function decode
def test_decode():
    def test_func(data: _ByteString, exp_val: str) -> None:
        decoded, consumed = decode(data)
        assert decoded == exp_val
        assert consumed == len(data)

    # Test cases from the docstring.
    test_func(b'\xff\x00\x00\xff', '77+977+9')
    test_func(b'A', 'QQ==')
    test_func(b'AB', 'QUI=')
    test_func(b'ABC', 'QUJD')
    test_func(b'ABCD', 'QUJDRA==')

    # Test the 'CodecInfo.decode()' method.

# Generated at 2022-06-23 17:43:52.947316
# Unit test for function decode
def test_decode():
    assert decode(b'abc123') == ('YWJjMTIz', 6)


# Generated at 2022-06-23 17:43:57.616209
# Unit test for function register
def test_register():
    # Setup: Ensure that a codec as this name does not exist.
    codecs.lookup('foobar')

    # Exercise: Run the function under test.
    register()

    # Verify: The codec exists.
    codecs.lookup('b64')



# Generated at 2022-06-23 17:44:01.473538
# Unit test for function register
def test_register():
    """Test the 'register' method."""
    register()
    codecs.getincrementalencoder(NAME)
    codecs.getincrementaldecoder(NAME)
    codecs.getreader(NAME)
    codecs.getwriter(NAME)



# Generated at 2022-06-23 17:44:05.554410
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:44:16.660060
# Unit test for function encode

# Generated at 2022-06-23 17:44:27.666510
# Unit test for function decode
def test_decode():
    assert decode(b'YW55IGNhcm5hbCBwbGVhcw==') == ('any carnal pleas', 26)
    assert decode(b'YW55IGNhcm5hbCBwbGVhc3U=') == ('any carnal pleasu', 27)
    assert decode(b'YW55IGNhcm5hbCBwbGVhc3Vy') == ('any carnal pleasur', 28)
    assert decode(b'YW55IGNhcm5hbCBwbGVhcw==\n') == ('any carnal pleas', 26)
    assert decode(b'YW55IGNhcm5hbCBwbGVhc3U=\n') == ('any carnal pleasu', 27)

# Generated at 2022-06-23 17:44:40.126813
# Unit test for function register
def test_register():
    register()
    name = NAME

    try:
        codecs.getdecoder(name)
    except LookupError:
        raise Exception(f'codecs.getdecoder("{name}") failed')


if __name__ == '__main__':
    import unittest

    class TestB64(unittest.TestCase):
        """Unit tests for the b64 codec."""


# Generated at 2022-06-23 17:44:45.062332
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    assert encode('dGVzdA==') == (b'test', 4)
    assert encode('dGVzdA==\n') == (b'test', 5)
    assert encode('  dGVzdA==\n  ') == (b'test', 9)
    assert encode('dGVzdA==\ndGVzdA==') == (b'testtest', 10)
    assert encode('dGVzdA==\n dGVzdA==') == (b'testtest', 11)
    assert encode('dGVzdA==\n  dGVzdA==') == (b'testtest', 12)
    assert encode('dGVzdA==dGVzdA==') == (b'testtest', 8)

# Generated at 2022-06-23 17:44:49.466001
# Unit test for function encode
def test_encode():
    """Test function encode()."""
    expected_bytes = b'\x00\x01\x10\x11'
    expected_len = 6

    actual_bytes, actual_len = encode('AAEAHg==')

    assert actual_len == expected_len
    assert actual_bytes == expected_bytes



# Generated at 2022-06-23 17:44:53.091283
# Unit test for function register
def test_register():
    """Verify the the ``b64`` codec is registered with Python."""
    # The 'codecs.getdecoder' call will raise a 'LookupError' if the codec is
    # not registered with Python.
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:44:57.343929
# Unit test for function decode
def test_decode():
    test_b_tuple = (b'\x00\x11\x22\x33\x44\x55', 6)
    answer_tuple = ('AAECAwQF', 6)
    assert decode(*test_b_tuple) == answer_tuple


# Generated at 2022-06-23 17:45:06.949419
# Unit test for function encode
def test_encode():
    # Test for empty input.
    value = encode('', 'strict')
    assert type(value) is tuple
    assert len(value) is 2
    assert type(value[0]) is bytes
    assert len(value[0]) is 0
    assert type(value[1]) is int
    assert value[1] == 0

    # Test for empty input with no errors check.
    value = encode('')
    assert type(value) is tuple
    assert len(value) is 2
    assert type(value[0]) is bytes
    assert len(value[0]) is 0
    assert type(value[1]) is int
    assert value[1] == 0

    # Test whitespace only
    value = encode(' \n\r\t\f\v')
    assert type(value) is tuple

# Generated at 2022-06-23 17:45:12.022870
# Unit test for function register
def test_register():
    """Test for :class:`register` function."""
    register()

    assert codecs.lookup(NAME).decode(b'bA==') == 'a'
    assert codecs.lookup(NAME).encode(b'a') == b'bA=='

# Generated at 2022-06-23 17:45:16.008114
# Unit test for function register
def test_register():
    """Test the register() function."""
    orig_codecs = codecs.__dict__['getdecoder'](NAME)
    register()
    new_codecs = codecs.__dict__['getdecoder'](NAME)

    assert new_codecs is not orig_codecs



# Generated at 2022-06-23 17:45:17.496150
# Unit test for function decode
def test_decode():
    """Unit test for the decode function."""

    assert decode(b'A' * 3)[0] == 'AAAAAA=='
    assert decode(b'A' * 4)[0] == 'AAAAAAA='
    assert decode(b'A' * 5)[0] == 'AAAAAAAA'



# Generated at 2022-06-23 17:45:24.989293
# Unit test for function encode
def test_encode():

    ##################################################################
    # Tests for expected failures.

    # Test that TypeError is raised when a non-string is given as the
    # text to decode.
    with pytest.raises(TypeError):
        try:
            encode(
                text=b'SGVsbG8sIHdvcmxkIQ==',
                errors='strict'
            )
        except UnicodeEncodeError as e:
            # Test that given the wrong type to encode, the encode
            # function reports the wrong type.
            assert e.encoding == 'b64'
            raise TypeError('Test to raise TypeError failed.') from e

    # Test that giving the wrong number of arguments raises a TypeError.
    with pytest.raises(TypeError):
        encode()

    # Test that giving an unknown keyword argument raises a TypeError.


# Generated at 2022-06-23 17:45:36.372779
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    # Test 1: A simple 'Hello World' string.
    assert (
        encode('SGVsbG8gV29ybGQK') ==
        (
            b'Hello World',
            16
        )
    )
    # Test 2: A very indented and multiline string.
    multi_str = '''
  \n\t\nSGVsbG8gV29ybGQK
'''
    assert (
        encode(multi_str) ==
        (
            b'Hello World',
            16
        )
    )
    # Test 3: A multi-byte string.

# Generated at 2022-06-23 17:45:47.229100
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    def encode_test(
            text: _STR,
            expected_text: bytes,
            expected_len: int
    ) -> None:
        """Test function for the conversion of a given string of base64
         datas into bytes.

        Args:
            text (str): The string of base64 characters to test
            expected_text (bytes): The expected output bytes
            expected_len (int): The expected length of returned bytes

        Returns:
            None
        """
        actual_text, actual_len = encode(text)
        assert actual_text == expected_text
        assert actual_len == expected_len

    # Test data.

# Generated at 2022-06-23 17:45:52.013547
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZA==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZGU=') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZGU=') == (b'abcdefgh', 12)

# Generated at 2022-06-23 17:45:55.094218
# Unit test for function encode
def test_encode():
    assert encode('Y29sb3JzLmNvbQ==')[0] == b'colors.com'
    assert encode('Y29sb3JzLmNvbQ')[0] == b'colors.com'



# Generated at 2022-06-23 17:46:05.009540
# Unit test for function encode
def test_encode():
    """Unit test for function encode
    """
    from binascii_utils.b64 import codec as b64_codec
    text = 'Tm93IGlzIHRoZSBsZWFkZXIgb2YgbmV0d29ya2luZyAo\n'    \
           'bXljbG9jayk='
    expected = b'Now is the leader of networking (myclock)'
    actual = b64_codec.encode(text)[0]
    assert actual == expected, (
        f"\n{'Got':<10}: {actual!r}"
        f"\n{'Expected':<10}: {expected!r}"
    )


# Generated at 2022-06-23 17:46:10.188083
# Unit test for function encode
def test_encode():
    """Test the encode function with a single line."""
    # Test with a single line of base64 text.
    expected = b'Foobar'
    actual = encode('Rm9vYmFy')
    assert actual == (expected, len('Rm9vYmFy'))



# Generated at 2022-06-23 17:46:21.892870
# Unit test for function decode
def test_decode():
    """Test function ``decode``."""
    # Test decoding bytes
    # 12345678901234
    # string = 'MTIzNDU2Nzg5MDEyMzQ='
    # 123456789012345678901234
    string = 'MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0'
    # string = 'MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0='

    out, _ = decode(b'1234', 'ignore')

# Generated at 2022-06-23 17:46:25.604103
# Unit test for function encode
def test_encode():
    test1 = 'aGVsbG8sIHdvcmxkIQo='
    test2 = encode('hello, world!\n')
    # print(test1, test2)
    assert test1 == test2[0].decode('utf-8')



# Generated at 2022-06-23 17:46:35.227956
# Unit test for function decode
def test_decode():
    print('Running unit test decode...', end=' ')
    assert decode(b'ab') == ('YWI=', 2), decode(b'ab')
    assert decode(b'abcd') == ('YWJjZA==', 4), decode(b'abcd')
    assert decode(b'aGVsbG8gd29ybGQ=') == ('aGVsbG8gd29ybGQ=', 14), decode(
        b'aGVsbG8gd29ybGQ='
    )

# Generated at 2022-06-23 17:46:45.949016
# Unit test for function decode
def test_decode():
    """Unit test for b64.decode(...)"""
    import unittest

    class TestDecode(unittest.TestCase):
        """Unit test"""
        def test_decode(self):
            """Unit test for decode(data: bytes) -> str"""
            # Map of test data that should be accepted by the function.

# Generated at 2022-06-23 17:46:57.322374
# Unit test for function encode
def test_encode():
    codecs.register(_get_codec_info)
    # Test with a proper base64 string.
    text = 'c2FtcGxlIGJhc2U2NCBzdHJpbmc=\n'
    ret, _ = encode(text)
    assert ret == b'sample base64 string'
    # Test with a base64 string containing newlines.
    text = ('c2FtcGxlIGJhc2U2NCBzdHJpbmc=\n'
            'c2FtcGxlIGJhc2U2NCBzdHJpbmc=\n\n')
    ret, _ = encode(text)
    assert ret == b'sample base64 string'
    # Test with a base64 string containing spaces and newlines.

# Generated at 2022-06-23 17:46:59.669013
# Unit test for function decode
def test_decode():
    assert decode(b"Hello World!\n")[0] == "SGVsbG8gV29ybGQhCg=="


# Generated at 2022-06-23 17:47:02.071111
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-23 17:47:06.446441
# Unit test for function register
def test_register():
    """Test function :func:`register`."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'Codec "{NAME}" is already registered.')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'Codec "{NAME}" not registered.')
    else:
        # noinspection PyUnresolvedReferences
        codecs.lookup(NAME)



# Generated at 2022-06-23 17:47:10.019108
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8=') == (b'hello', 6)
    assert encode('S\nO\nF\nT\n') == (b'\xaa\xbb\x00', 4)
    assert encode('QQ==') == (b'\x00', 1)



# Generated at 2022-06-23 17:47:12.714793
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.register(_get_codec_info)
    assert(codecs.getdecoder(NAME))
    codecs.register(lambda name: None)
# End unit test

# Generated at 2022-06-23 17:47:15.564424
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-23 17:47:23.467893
# Unit test for function decode

# Generated at 2022-06-23 17:47:28.497274
# Unit test for function decode
def test_decode():
    assert decode(b'AQ') == ('QQ==', 2)
    assert decode(b'AQA') == ('QUE=', 3)
    assert decode(b'AQAB') == ('QUFB', 4)



# Generated at 2022-06-23 17:47:33.024780
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()


# vim: ts=4 sw=4

# Generated at 2022-06-23 17:47:34.486048
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-23 17:47:39.308789
# Unit test for function encode
def test_encode():
    # Test code examples taken from https://docs.python.org/3/library/codecs.html#encodings-and-unicode
    assert encode("foo") == (b'Zm9v', 3)
    assert encode("foo") == (b'Zm9v', 3)
    assert encode("föö") == (b'ZsO8bw', 4)



# Generated at 2022-06-23 17:47:50.233583
# Unit test for function encode
def test_encode():
    # Test Python's base64.b64decode function on this string
    test_str = """
        U3RydWN0dXJlIGRlbW9uc3RyYXRpb24gYW5kIGludGVyYWN0aW9uIHdpdGggZWFzeSBpbnRl
        cmFjdGlvbiwgY2hhbmdpbmcgdGhlIGZvcm1hdCBvZiBhIHN0cmluZyBpbnRvIGEgdGV4dCBi
        eXRlIHN0cmluZy4=
    """

# Generated at 2022-06-23 17:47:58.934245
# Unit test for function register
def test_register():
    import sys
    from io import StringIO

    from b64codec.b64_codec import register

    stdout_hdl = StringIO()
    stderr_hdl = StringIO()

    # Preserve the stdout and stderr handles
    save_stdout_hdl = sys.stdout
    save_stderr_hdl = sys.stderr

    try:
        # Redirect the stdout and stderr handles to StringIO buffers
        sys.stdout = stdout_hdl
        sys.stderr = stderr_hdl

        register()

        # Get the output of 'help(reg)'
        help(register)
    finally:
        # Restore the stdout and stderr handles
        sys.stdout = save_stdout_hdl
        sys.stderr = save

# Generated at 2022-06-23 17:48:03.135377
# Unit test for function register
def test_register():
    if NAME not in codecs.getdecoder(NAME):
        raise RuntimeError(f"{NAME} is not in codecs")



register()



# Generated at 2022-06-23 17:48:12.512791
# Unit test for function decode
def test_decode():
    _, consumed = decode(b'MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkwMTI=' + b'\n' +
                         b'MzQ1Njc4OTAxMjM0NTY3ODkwMTIzNDU2Nzg5MA==')
    assert consumed == 64, consumed

    # Test to make sure that an error is raised if
    # the 'data' does not contain base64 data.
    failed = False
    try:
        decode(b'abcdefg')
    except UnicodeEncodeError:
        failed = True
    assert failed


# noinspection DuplicatedCode

# Generated at 2022-06-23 17:48:16.526554
# Unit test for function register
def test_register():
    """Ensure the ``b64`` codec is registered"""
    register()
    b64_codec = codecs.getencoder(NAME)
    assert b64_codec is not None
    assert b64_codec == codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:48:28.335315
# Unit test for function encode

# Generated at 2022-06-23 17:48:29.556989
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 17:48:33.910675
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # Make sure the 'b64' codec has not been registered.
    with assertRaises(LookupError):
        codecs.getdecoder(NAME)    # type: ignore
    # Register the 'b64' codec.
    register()
    # Make sure the 'b64' codec is registered.
    codecs.getdecoder(NAME)    # type: ignore



# Generated at 2022-06-23 17:48:41.575873
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode
    """
    # Test for encoding b64
    print("Test for Encoding b64")
    assert decode(b'\x05\x06')[0] == 'BQo='
    assert decode(b'\x00\x01\x02')[0] == 'AAEC'
    assert decode(b'A\x05\x06')[0] == 'QUE='
    assert decode(b'\x05A\x06')[0] == 'QW8='
    assert decode(b'\x05\x06A')[0] == 'QcQ='
    assert decode(b'\x00\x00\x00')[0] == 'AAA='

# Generated at 2022-06-23 17:48:53.064481
# Unit test for function encode
def test_encode():
    # type: () -> None

    # Perform some tests that should succeed.
    base_str = '''\
        ewogICAgICAgICAgZXN0YWRvIDogZWxpdGUgZW50cmFkbywKICAgICAgICBpbmljaWFs
        OiBhbm8sCiAgICAgICAgcHJpbmNpcGFsIDogcHJpbmNpcGFsCg==
    '''
    assert (
        encode(base_str)[0] ==
        b'\n    estado : elite entrado,\n    inicial: ano,\n    principal : principal\n'
    )

    # Perform a test that should fail.

# Generated at 2022-06-23 17:49:00.313052
# Unit test for function encode
def test_encode():
    text = (
        "Titanium is a chemical element with the symbol Ti and atomic number "
        "22. It is a lustrous transition metal with a silver color, "
        "low density, and high strength. Titanium is resistant to corrosion "
        "in sea water, aqua regia, and chlorine."
    )

# Generated at 2022-06-23 17:49:04.392219
# Unit test for function decode
def test_decode():
    assert decode(b'VGhpcyBpcyBhIGJhc2U2NCBlbmNvZGVkIHN0cmluZy4=')[0] == 'This is a base64 encoded string.'


# Generated at 2022-06-23 17:49:12.940164
# Unit test for function register
def test_register():
    """Test for register()."""
    register()
    codecs.getdecoder(NAME)

    # Test that the codec can be found.
    encoder = codecs.getdecoder(NAME)
    assert encoder is not None
    assert encoder.__name__ == NAME
    assert 'decoder' in str(encoder)

    # Test that the decoder can be found.
    decoder = codecs.getencoder(NAME)
    assert decoder is not None
    assert decoder.__name__ == NAME
    assert 'encoder' in str(decoder)


# pylint: disable=W0613

# Generated at 2022-06-23 17:49:16.296061
# Unit test for function encode
def test_encode():
    txt = '''\
        QmFzZSA2NCBEZWNvZGVkIFRleHQ=
    '''

    assert encode(txt)[0] == b'Base 64 Decoded Text'


# Generated at 2022-06-23 17:49:23.491890
# Unit test for function encode
def test_encode():
    """Unit test for the function encode."""
    text_input = (
        """\
        A3qPds6VbUQEB1VC7c1zw==
        """
    )

    result, _ = encode(text_input)

    assert result == b'\x00\x01\x02\x03'

    assert result == b'\x00\x01\x02\x03'

    assert result == b'\x00\x01\x02\x03'

    assert result == b'\x00\x01\x02\x03'

    assert result == b'\x00\x01\x02\x03'



# Generated at 2022-06-23 17:49:25.609894
# Unit test for function encode
def test_encode():
    # Unit test for function encode()
    from . import codecs_ as codecs
    register()
    codecs.encode()



# Generated at 2022-06-23 17:49:31.666772
# Unit test for function decode
def test_decode():
    # Test that the decode maps the given bytes to the base64 characters
    # and returns a string.
    assert decode(b"\x01\x00\x10") == ("AQEBAQ==", 3)

    # Test that the decode raises an error if the given bytes is not
    # equal to base64 character.
    with pytest.raises(UnicodeEncodeError):
        decode(b"\x01\x00\x11")

register()

# Generated at 2022-06-23 17:49:36.001136
# Unit test for function decode
def test_decode():
    input = 'MjAwOjMwOjMxOjAxOjAyOjAz'
    from base64 import b64decode
    result = b64decode(input + '\n')
    assert(result == b'200:30:31:01:02:03')



# Generated at 2022-06-23 17:49:40.787147
# Unit test for function encode
def test_encode():
    from string import ascii_letters
    from numpy import random
    from base64 import b64encode

    for _ in range(1000):
        text = ''.join([
            ascii_letters[int(random.rand() * len(ascii_letters))]
            for _ in range(int(random.rand() * 1000))
        ])
        assert encode(text)[0] == b64encode(text.encode('utf-8')).upper()



# Generated at 2022-06-23 17:49:52.182127
# Unit test for function encode
def test_encode():
    """
    Test the encode function
    """
    assert encode('') == (b'', 0)

    assert encode('a') == (b'YQ==', 1)
    assert encode('ab') == (b'YWI=', 2)
    assert encode('abc') == (b'YWJj', 3)
    assert encode('abcd') == (b'YWJjZA==', 4)
    assert encode('abcde') == (b'YWJjZGU=', 5)
    assert encode('abcdef') == (b'YWJjZGVm', 6)
    assert encode('abcdefg') == (b'YWJjZGVmZw==', 7)
    assert encode('abcdefgh') == (b'YWJjZGVmZ2g=', 8)
    assert encode

# Generated at 2022-06-23 17:49:55.504481
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    assert codecs.getdecoder(NAME.encode('utf-8')) is not None



# Generated at 2022-06-23 17:50:00.601446
# Unit test for function encode
def test_encode():
    # Arrange
    # Act
    exp_bytes = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    exp_len = 8
    act_bytes, act_len = encode('AAAAAA==')
    # Assert
    assert act_bytes == exp_bytes, (act_bytes, exp_bytes)
    assert act_len == exp_len, (act_len, exp_len)



# Generated at 2022-06-23 17:50:07.474541
# Unit test for function encode
def test_encode():
    """Test the encode function."""


# Generated at 2022-06-23 17:50:17.182786
# Unit test for function encode
def test_encode():
    assert encode('U2hvdw==', errors='strict') == (b'Show', 4)
    assert encode('dGhpcyBpcyBhIGxvdw==', errors='strict') == (b'this is a low', 14)
    assert encode('dGhpcyBpcyBhIGxvd2VzdA==', errors='strict') == (b'this is a lowest', 16)
    assert encode('RW5jb2RlIHRoaXM=', errors='strict') == (b'Encode this', 12)
    assert encode('RGVjb2RlIHRoaXM=', errors='strict') == (b'Decode this', 12)
    assert encode('Q2hlY2sgaXQ=', errors='strict') == (b'Check it', 9)

# Generated at 2022-06-23 17:50:27.928771
# Unit test for function decode

# Generated at 2022-06-23 17:50:32.625600
# Unit test for function register
def test_register():
    # Try to get the 'b64' decoder.  This should fail because we have
    # not register the 'b64' codec.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the 'b64' codec.
    register()

    # Try to get the 'b64' decoder.  This should work because we have
    # not register the 'b64' codec.
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:50:36.981311
# Unit test for function encode
def test_encode():
    orig = b'Hello, World!'
    b64_orig = base64.b64encode(orig)
    text_orig = b64_orig.decode('utf-8')

    out, _ = encode(text_orig)

    assert orig == out
    assert type(out) == bytes



# Generated at 2022-06-23 17:50:45.919109
# Unit test for function register
def test_register():
    import base64 as _base64
    import codecs as _codecs
    import codecs_b64 as _codecs_b64

    _codecs_b64.register()

    data = b'\x00\x01'
    encoded_bytes = _base64.b64encode(data)
    encoded_str = encoded_bytes.decode('utf-8')

    decoded_str = _codecs.decode(encoded_str, NAME)
    assert data == decoded_str

    assert encoded_str == _codecs.encode(data, NAME)


register()

# Generated at 2022-06-23 17:50:51.167601
# Unit test for function encode
def test_encode():
    """Unit test for ``encode`` function."""
    assert encode('U3lzdGVt') == (b'System', 6)
    assert encode('TmFt\nZQ==') == (b'Name', 4)
    assert encode('TWljcm9zb2Z0') == (b'Microsoft', 9)



# Generated at 2022-06-23 17:50:58.095435
# Unit test for function encode
def test_encode():
    assert b'\x01\x02\x03' == encode('AQID')
    assert len(b'AQID') == encode('AQID')[1]
    assert b'\x0f\xcf\x0f\xc7\x1f\xde\x07\xe3\xf7\xbe\x1b\xee\xbb\x7f\xaf' \
        b'\xe7\x7b\xbd\x5b' == encode('+/v7+/v7/f3/f/3/v/9/v7/P3/P/3/z/3/v7/P3/')

# Generated at 2022-06-23 17:51:08.345783
# Unit test for function encode
def test_encode():
    """Encode a string of characters."""
    assert encode('aG9sYQ==')[0].decode('utf-8') == 'hola'
    assert encode(b'aG9sYQ==')[0].decode('utf-8') == 'hola'
    assert encode('c29tZSBydWxl\ncyBhcmUgZGVj\nb25kZWQ=')[0].decode('utf-8') == 'some rules are deconded'
    assert encode(b'c29tZSBydWxl\ncyBhcmUgZGVj\nb25kZWQ=')[0].decode('utf-8') == 'some rules are deconded'
    # assert encode('c29tZSBydWxlcyBhcmU

# Generated at 2022-06-23 17:51:18.889470
# Unit test for function decode
def test_decode():
    assert decode(b'\xa0')[0] == 'gA=='
    assert decode(b'\xa0', 'strict')[0] == 'gA=='
    assert decode(b'\xa0', errors='ignore')[0] == 'gA=='
    assert decode(b'\xa0', errors='replace')[0] == 'gA=='
    assert decode(b'\xa0', errors='surrogateescape')[0] == 'gA=='
    assert decode(b'\xa0', errors='surrogatepass')[0] == 'gA=='
    assert decode(b'\xa0', errors='xmlcharrefreplace')[0] == 'gA=='
    assert decode(b'\xa0', errors='strict')[1] == 1

# Generated at 2022-06-23 17:51:30.540603
# Unit test for function register
def test_register():
    """Test the function :func:`register()`"""
    # Registers all of the builtin 'codecs' and all of the builtin
    # 'encodings'
    codecs.register(codecs.search_function)

    # Get the b64 codec
    b64_codec = codecs.lookup(NAME)   # type: ignore

    # Test the b64 codec with bytes.
    test_bytes = b'This is a test'
    decoded_bytes, _ = b64_codec.encode(test_bytes)
    assert decoded_bytes == b'VGhpcyBpcyBhIHRlc3Q='

    # Test the b64 codec with a string.
    test_string = 'This is a test'

# Generated at 2022-06-23 17:51:42.157568
# Unit test for function encode
def test_encode():
    # Test with short, clean input.
    arg = 'SGVsbG8sIFdvcmxkIQ=='
    expect = (b'Hello, World!', len(arg))
    assert encode(arg) == expect

    # Test with long, multi-line, indented input.
    arg = """
        QWxhZGRpbjpvcGVuIHNlc2FtZQ==
        QWxhZGRpbjpvcGVuIHNlc2FtZQ==
        QWxhZGRpbjpvcGVuIHNlc2FtZQ==
        QWxhZGRpbjpvcGVuIHNlc2FtZQ==
    """

# Generated at 2022-06-23 17:51:51.496908
# Unit test for function decode
def test_decode():
    """Unit test cases for function _decode."""

# Generated at 2022-06-23 17:52:02.973770
# Unit test for function encode
def test_encode():
    """Test that the encode() function is working properly."""
    from base64 import b64encode
    from io import BytesIO

    test_string = 'this is a test string'
    test_string_bytes = test_string.encode('utf-8')
    test_string_bytes_b64 = b64encode(test_string_bytes)
    test_string_bytes_b64_str = test_string_bytes_b64.decode('utf-8')

# Generated at 2022-06-23 17:52:05.788975
# Unit test for function register
def test_register():
    """Test registering of the ``b64`` codec."""
    # Assert that the codec is not registered.

# Generated at 2022-06-23 17:52:12.537323
# Unit test for function encode
def test_encode():
    assert encode('Zg==') == (b'f', 4)
    assert encode('Zm8=') == (b'fo', 4)
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('Zm9vYg==') == (b'foob', 8)
    assert encode('Zm9vYmE=') == (b'fooba', 8)
    assert encode('Zm9vYmFy') == (b'foobar', 8)

# Generated at 2022-06-23 17:52:18.326201
# Unit test for function register
def test_register():
    """Confirms that the ``b64`` codec is not currently registered."""
    codecs_register = codecs.register  # type: ignore
    codecs.register = None

    try:
        register()
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'The b64 is not registered with Python.'
    finally:
        codecs.register = codecs_register



# Generated at 2022-06-23 17:52:20.627073
# Unit test for function decode
def test_decode():
    assert decode(b'abc') == ('YWI=', 3)

#Unit test for function encode

# Generated at 2022-06-23 17:52:31.796247
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'abcdefghij') == ('YWJjZGVmZ2hpag==', 10)

# Generated at 2022-06-23 17:52:41.335950
# Unit test for function encode
def test_encode():
    """Test encode()."""
    # pylint: disable=C0326
    # pylint: disable=E1101
    assert encode('YW55IGNhcm5hbCBwbGVhc3VyZQ==') == (
        b"any carnal pleasure.",
        24
    )

    assert encode(
        'YW55IGNhcm5hbCBwbGVhc3VyZQ==\n'
        '\n'
        'dGhlIG1pbmQ=\n'
        '\n'
        'aXMgc3VyZSBh\n'
        '\n'
        'bGU='
    ) == (
        b"any carnal pleasure.the mindis sure a\nble",
        68
    )
