

# Generated at 2022-06-23 17:42:47.846763
# Unit test for function decode
def test_decode():
    """Test the function ``decode``."""
    # pylint: disable=W0612
    # pylint: disable=W0613
    text_bytes = b"YWJjZA=="

    # Decode the input bytes and expected bytes
    b64_codec = codecs.getdecoder(NAME)
    decoded_text, decoded_len = b64_codec(text_bytes, "ignore")
    expected_text = "abcd"

    # Test that the output of the function matches the expected bytes.
    assert expected_text == decoded_text



# Generated at 2022-06-23 17:42:54.848970
# Unit test for function encode
def test_encode():
    input_str = '\n'.join(
        (
            'Ij48P3BocCBlY2hvICJIZWxsbyBXb3JsZCI7ID8+Pg==',
        )
    )
    output_bytes = b'<!--?php echo "Hello World"; ?-->'
    assert encode(input_str)[0] == output_bytes



# Generated at 2022-06-23 17:42:55.703570
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:42:57.169341
# Unit test for function decode
def test_decode():
    assert decode(b'abcd') == ('YWJjZA==', 4)


# Generated at 2022-06-23 17:43:02.455480
# Unit test for function decode
def test_decode():
    input_data = b'This is some data to test the b64 codec.'
    expected = (
        'VGhpcyBpcyBzb21lIGRhdGEgdG8gdGVzdCB0aGUgYjY0IGNvZGVjLg==',
        len(input_data)
    )
    try:
        output = decode(input_data)
    except:
        output = (None, None)
    assert expected == output



# Generated at 2022-06-23 17:43:07.367521
# Unit test for function encode
def test_encode():
    """Test encode"""
    # Good data
    assert encode("YQ==") == (b'a', 4)
    assert encode("YWI=") == (b'ab', 4)
    assert encode("YWJj") == (b'abc', 4)
    assert encode("YWJjZA==") == (b'abcd', 8)

    # Bad data
    try:
        encode("bad")
        raise AssertionError("Should have raise UnicodeEncodeError")
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-23 17:43:18.836974
# Unit test for function encode
def test_encode():
    """Unit test for function :obj:`encode`."""
    # Test for a valid base64 character string.
    assert encode('VWZUVG9sYXJzIGlzIHBlYWNl')[0] == b'Tahars is peace'

    # Test for a valid base64 character string with trailing padding '='.
    assert encode('VWZUVG9sYXJzIGlzIHBlYWNl=')[0] == b'Tahars is peace'

    # Test for a valid base64 character string with two trailing padding
    # '='.
    assert encode('VWZUVG9sYXJzIGlzIHBlYWNl==')[0] == b'Tahars is peace'

    # Test for a valid base64 character string with a new line character.
    assert encode

# Generated at 2022-06-23 17:43:25.150323
# Unit test for function decode
def test_decode():
    """Test function 'decode'."""
    assert decode(b'\x01\x02\x03\x04') == ('AQIDBA==', 4)
    assert decode(b'\x01\x02\x03\x04', '') == ('AQIDBA==', 4)
    assert decode(b'AQIDBA==') == ('AQIDBA==', 8)



# Generated at 2022-06-23 17:43:38.122912
# Unit test for function encode
def test_encode():
    print("Testing encode")
    assert encode('SGVsbG8sIHdvcmxk') == b'Hello, world'
    assert encode('d2FyZG1lZXQ') == b'waremeet'
    assert encode('d2FyZG1lZXQg') == b'waremeet '
    assert encode('YW55IGFyYml0cmFyeQ==') == b'any arbitrary'
    assert encode('YW55IGFyYml0cmFy') == b'any arbitrary'
    assert encode('YW55IGFyYml0cmFz') == b'any arbitrary'
    assert encode('YW55IGFyYml0cmFu') == b'any arbitrary'
    assert encode('YW55IGFyYml0cmF0') == b'any arbitrary'


# Generated at 2022-06-23 17:43:41.767540
# Unit test for function encode
def test_encode():
    "Ensure the encode function returns the correct bytes"
    encoded = encode('aGVsbG8sIHdvcmxk')
    assert(encoded[0] == b'hello, world')



# Generated at 2022-06-23 17:43:50.336023
# Unit test for function encode
def test_encode():
    encoded_bytes, _ = encode("Menarche hürriyet tatyana niacinamide nigrifacient \
        mikado schwengel thermoluminescence supertrooper verstehe")
    assert encoded_bytes == b"TWVuYXJjaGUgaMOocmzdHlldCB0YXR5YW5hIG5pYWNpbmFtaWRlIG5pZ3JpZmFjaWVudCBtaWthZG8gc2Nod2VuZ2VsIHRoZXJtb2x1bWluZXNzZSBzdXBlcnRyb29wZXIgdmVyc3RlaGUK"
    assert encode("")[0] == b""

# Generated at 2022-06-23 17:44:02.339426
# Unit test for function encode
def test_encode():
    """Test encode function"""
    assert encode('') == (b'', 0)
    assert encode('=') == (b'', 1)
    assert encode('====') == (b'', 4)
    assert encode('SGVsbG8gV29ybGQ') == (b'Hello World', 14)
    assert encode('SGVsbG8gV29y\nbGQ') == (b'Hello World', 14)
    try:
        assert encode('SGVsbG8gV29ybGQ\r')
    except UnicodeEncodeError as e:
        assert 'is not a proper bas64 character string' in str(e)

# Generated at 2022-06-23 17:44:04.691003
# Unit test for function decode
def test_decode():
    assert decode(bytes([65, 65, 65]), 'strict') == ('QUFB', 3)


# Generated at 2022-06-23 17:44:07.983866
# Unit test for function register
def test_register():
    """Unit test for 'register'"""
    from b64_codec.test_b64 import test_register
    test_register()



# Generated at 2022-06-23 17:44:13.017862
# Unit test for function decode
def test_decode():
    data = decode(b'c3RyaW5n')
    assert data[0] == 'string'
    assert data[1] == 5
    data = decode(b'c3RyaW5n', 'utf-8')
    assert data[0] == 'string'
    assert data[1] == 5



# Generated at 2022-06-23 17:44:21.967954
# Unit test for function encode
def test_encode():
    assert b'Man is distinguished' == encode(
        'TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1dCBieSB0aGlz'
    )[0]
    assert b'Man is d' == encode(
        'TWFuIGlzIGQ'
    )[0]
    assert b'abc' == encode(
        'YWJj'
    )[0]
    assert b'abcdef' == encode(
        'YWJjZGVm'
    )[0]
    assert b'Man is di+/' == encode(
        'TWFuIGlzIGRpwrjDg8OcwrvDp8KA'
    )[0]


# Generated at 2022-06-23 17:44:30.900050
# Unit test for function encode
def test_encode():
    # Test against known value
    def encode_decode(inp):
        return base64.b64decode(base64.b64encode(inp)).decode()  # type: ignore
    assert encode("aGk=")[0] == encode_decode("aGk="), "Failed test 1"
    assert encode("YWJj")[0] == encode_decode("YWJj"), "Failed test 2"
    # Test spaces and end lines
    assert encode("YWJj")[0] == encode(" a b c ")[0], "Failed test 3"
    assert encode("YWJj")[0] == encode(" a\n b\nc ")[0], "Failed test 4"

# Generated at 2022-06-23 17:44:32.697350
# Unit test for function decode
def test_decode():
    assert decode(b'YmFzZTY0Cg==') == ('base64\n', 8)


# Generated at 2022-06-23 17:44:36.795053
# Unit test for function register
def test_register():
    """
    Unit test for function register
    """
    try:
        codecs.getencoder(NAME)  # type: ignore
    except LookupError:
        register()
        codecs.getencoder(NAME)  # type: ignore




# Generated at 2022-06-23 17:44:41.702287
# Unit test for function encode
def test_encode():
    in_string: str
    out_string: str
    in_string = "hola como estas"
    out_string = base64.b64encode(in_string.encode('utf-8'))
    out_string = out_string.decode('utf-8')
    assert encode(in_string) == (out_string, len(in_string))


# Generated at 2022-06-23 17:44:43.421071
# Unit test for function encode
def test_encode():
    test_case = '''
    Zm9vYmFyIGFnb3M=
    '''
    assert encode(test_case)[0] == b'foobar agos'

register()

# Generated at 2022-06-23 17:44:54.097828
# Unit test for function encode
def test_encode():
    def _test(text, expected):
        actual = encode(text)[0]
        assert expected == actual

    _test(
        'TGlubmVzIHBl',
        b'GlubmVzIHBl'
    )
    _test(
        '\nTGlubmVzIHBl',
        b'GlubmVzIHBl'
    )
    _test(
        '\n    TGlubmVzIHBl',
        b'GlubmVzIHBl'
    )
    _test(
        '\n    TGlubmVzIHBl\n',
        b'GlubmVzIHBl'
    )

# Generated at 2022-06-23 17:44:55.623285
# Unit test for function register
def test_register():
    """Unit test for register()."""
    register()
    assert NAME in codecs.getdecoder(NAME)()

# Generated at 2022-06-23 17:45:06.421327
# Unit test for function register
def test_register():
    """Unit testing for function 'register'."""
    import sys
    import os.path
    import test_b64_codec

    # Find out the name of the file in which this function is defined
    this_file_path = os.path.normpath(os.path.abspath(__file__))

    # This gets the parent directory of the file that defines this function.
    this_dir_path = os.path.dirname(this_file_path)

    # Now find out the name of the directory that is a sibling of the
    # directory in which this file is defined.
    parent_dir_path = os.path.normpath(os.path.join(this_dir_path, '..'))

    # Append the directory that is a sibling of the directory in which
    # this file is defined to the system path.
   

# Generated at 2022-06-23 17:45:13.287251
# Unit test for function encode
def test_encode():
    s = """
    SGVsbG8sIFdvcmxkIQ==
    SGVsbG8sIFdvcmxkIQ==
    QWJjZA==
    QWJjZA==
    """
    b = b'Hello, World!'
    d = encode(s)
    assert d[0] == b
    assert d[1] == len(s)


# Generated at 2022-06-23 17:45:19.041735
# Unit test for function register
def test_register():

    # Unit Test:
    #   Confirm that the 'b64' codec is successfully registered
    #   with Python.
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:45:23.564572
# Unit test for function encode
def test_encode():
    assert encode('SSdtIG5vdCBhIGNoYXJhY3Rlcg==') == (b'It is not a character', 27)
    assert encode('WW91IGFyZSBhIGNvaW4=') == (b'You are a coin', 17)
    assert encode('Tm8sIHdhcyBzZXZlcmFsIHdvcmxkcy4=') == (b'No, was several worlds.', 25)



# Generated at 2022-06-23 17:45:35.241713
# Unit test for function register
def test_register():
    """Unit test for register()"""
    import codecs

    # Verify that the 'base64_string' codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'{NAME!r} codec should not be registered prior to calling '
            f'register()'
        )

    # Register the 'base64_string' codec.
    register()

    # Verify that the 'base64_string' codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'{NAME!r} codec should be registered after calling register()'
        )



# Generated at 2022-06-23 17:45:37.203506
# Unit test for function register
def test_register():

    # Unit test: Does the codec get registered?
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:45:44.184242
# Unit test for function decode
def test_decode():   # type: () -> None
    """Test the decode function."""

    def check_encode(
            data: bytes,
            expected: str,
    ) -> None:
        """Test the encode function with the given ``data`` and ``expected``.

        Args:
            data (bytes): Bytes to be encoded
            expected (str): The expected value of the encoded bytes
        """
        _, count = encode(data)
        assert count == len(data)

        decoded_str, _ = decode(data)
        assert decoded_str == expected

    # Valid base64 characters
    check_encode(b'a', 'YQ==')
    check_encode(b'ab', 'YWI=')
    check_encode(b'abc', 'YWJj')

# Generated at 2022-06-23 17:45:46.502578
# Unit test for function decode
def test_decode():
    assert decode(b'YWJj') == ('abc', 4)
    assert decode(b'YWJjZGU=') == ('abcde', 8)


# Generated at 2022-06-23 17:45:50.528196
# Unit test for function encode
def test_encode():
    """Unit test for function :py:func:`encode`."""
    assert encode(
        'dGhpcyBpcyBhIHN0cmluZw=='
    ) == (b'this is a string', 19)

    assert encode(
        'this is a string'
    ) == (b'this is a string', 14)


# Generated at 2022-06-23 17:45:53.974054
# Unit test for function encode
def test_encode():
    encoded_bytes = b'SXQgbWlrZSB0aGUgY2Fycmlhbg==\n'
    text_str = 'It make the carrier'
    assert encode(text_str) == (encoded_bytes, len(text_str))


# Generated at 2022-06-23 17:45:57.831497
# Unit test for function register
def test_register():
    """Test if the ``b64`` codec has been registered."""
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-23 17:46:05.258352
# Unit test for function decode
def test_decode():
    """Tests for function decode"""
    # pylint: disable=W0612,C0116
    from unittest.mock import patch

    # Encode the given 'data' as a base64 string.
    data = b'\x01\x02\x03\x04\x05\x06\x07\x08'
    base64_str = base64.b64encode(data).decode('ascii')

    # Decode the base64 string 'base64_str' into the original 'data'.
    data_decoded = decode(base64_str.encode('utf-8'))[0]

    # Verify that the decoded string is the same as the original data
    assert data_decoded == base64_str



# Generated at 2022-06-23 17:46:08.864993
# Unit test for function decode
def test_decode():
    assert decode(codecs.encode('Hello, world', 'b64')) == ('SGVsbG8sIHdvcmxk', 13)


# Generated at 2022-06-23 17:46:15.267035
# Unit test for function encode
def test_encode():
    test_str = '\n'.join([
        'YW55IGNhcm5hbCBwbGVhc3VyZS4=',
        'YXBwbGU=',
        'YmFzZTY0IGlzIGdvb2Q=',
        'Ym9va2VyIHdvcmxk'
    ])
    expected = b'any carnal pleasure.\napple\nbase64 is good\nbooker world'
    actual, length = encode(test_str)
    assert actual == expected
    assert length == len(test_str)


# Generated at 2022-06-23 17:46:25.837633
# Unit test for function decode
def test_decode():
    decoded = decode(b'MTIzNA==')
    assert decoded[0] == 'MTIzNA=='


if __name__ == '__main__':
    register()
    decode_test = codecs.getdecoder(NAME)

    print('text to decode:', end=' ')
    print('abc')

    print(decode_test('abc'))

    print('text to decode:', end=' ')
    print('YWJj')

    print(decode_test('YWJj'))

    print('text to decode:', end=' ')
    print('YWJj')

    print(decode_test('YWJj'))

    print('text to decode:', end=' ')
    print('ABCDEFGHIJ')


# Generated at 2022-06-23 17:46:33.109725
# Unit test for function register
def test_register():  # pragma: no cover
    """Unit test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:46:42.725524
# Unit test for function register
def test_register():
    # noinspection PyProtectedMember
    prev = codecs.__package__._SearchFunctions.pop(NAME, None)
    try:
        register()
        assert codecs.getdecoder(NAME)
    finally:
        if prev:
            codecs.__package__._SearchFunctions[NAME] = prev
            # noinspection PyProtectedMember
            codecs.__package__._codecs_loaded = False
    codecs.__package__._SearchFunctions.pop(NAME)  # Explicitly remove it.
    assert NAME not in codecs.__package__._SearchFunctions



# Generated at 2022-06-23 17:46:47.444959
# Unit test for function decode
def test_decode():
    test_decode_1 = b'123456'
    test_decode_output_1 = b'MTIzNDU2'
    test_decode_output = decode(test_decode_1)
    print('Test decode 1 input:', test_decode_1)
    print('Test decode 1 expected:', test_decode_output_1)
    print('Test decode 1 actual:', test_decode_output)
    assert test_decode_output[0] == test_decode_output_1.decode('utf-8')


# Generated at 2022-06-23 17:46:58.562733
# Unit test for function register
def test_register():
    """Test the function register"""
    from pprint import pformat
    from test_support import TestSupport

    ts = TestSupport()

    ts.log_header("Testing register")

    ts.log_msg(
        "Check if the 'b64' codec is already registered.  "
        "If it is then unregister it."
    )
    registered = codecs.getencoder(NAME)
    if registered:
        codecs.unregister(registered)

    ts.log_msg("Check if the 'b64' codec is registered.")
    registered = codecs.getencoder(NAME)
    if registered:
        ts.log_msg("The 'b64' codec is already registered.")
    else:
        ts.log_msg("The 'b64' codec is not registered.")

# Generated at 2022-06-23 17:47:09.680915
# Unit test for function encode
def test_encode():

    assert encode('') == (b'', 0)
    assert encode('TWFu') == (b'Man', 4)
    assert encode('TWFuIQ==') == (b'Man!', 6)
    assert encode('TWFuIQ') == (b'Man!', 6)
    assert encode('TWFuIQ===') == (b'Man!', 6)
    assert encode('TWFuIQ===\n') == (b'Man!', 6)
    assert encode('TWFuIQ===\n\n\n') == (b'Man!', 6)
    assert encode('TWFuIQ===\n  \n\n') == (b'Man!', 6)
    assert encode('TWFuIQ===\n  \n\n') == (b'Man!', 6)

# Generated at 2022-06-23 17:47:20.641888
# Unit test for function encode
def test_encode():
    # Unit test for function encode
    # This is a test of the encode() function.

    # Test case 1
    input_str = "This string is not base64"
    try:
        encoded_bytes, _ = encode(input_str)
        assert False, "The encode() function did not raise an Exception"
    except UnicodeEncodeError:
        pass
    else:
        assert False, "The encode() function raised an Exception"

    # Test case 2
    input_str = "This string is not base64"

# Generated at 2022-06-23 17:47:33.313749
# Unit test for function encode
def test_encode():
    """Test the encode function."""
    from random import randrange as rnd
    from random import choice as chs
    from string import ascii_letters, digits

    # Create a list of random strings to encode.

# Generated at 2022-06-23 17:47:41.570050
# Unit test for function decode
def test_decode():
    """Test the given input for function decode."""

# Generated at 2022-06-23 17:47:52.784120
# Unit test for function encode
def test_encode():
    """Test the ``encode()`` function."""
    assert encode(b'abcABC') == (b'YWJjQUJD', 6)
    assert encode(b'abC') == (b'YWJDXA==', 4)
    assert encode(b'ab') == (b'YWI=', 3)
    assert encode(b'a') == (b'YQ==', 2)
    assert encode('') == (b'', 1)
    assert encode(b'\x00\xf0\x99\xa0\xa0') == (b'AHNlYyCs', 8)
    assert encode(b'\x00\xf0\x99\xa0\xa0', 'strict') == (b'AHNlYyCs', 8)

# Generated at 2022-06-23 17:47:56.831066
# Unit test for function decode
def test_decode():
    """Unit test for function decode()."""
    decode_test_input = "Tm9uY2VlU2VjdXJl"
    decode_test_output ="NonceSecure"
    assert decode(decode_test_input) == (decode_test_output, len(decode_test_input)), "decode() is not giving correct output"


# Generated at 2022-06-23 17:47:59.082396
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert NAME in codecs.getencoders()
    assert NAME in codecs.getdecoders()

# Generated at 2022-06-23 17:48:10.154487
# Unit test for function register
def test_register():
    """Test for the function register."""
    assert isinstance(decode, codecs.Codec)
    assert isinstance(encode, codecs.Codec)
    assert isinstance(decode, codecs.StreamReader)
    # noinspection PyUnusedLocal
    assert isinstance(encode, codecs.StreamWriter)
    assert isinstance(encode, codecs.IncrementalEncoder)
    assert isinstance(decode, codecs.IncrementalDecoder)


if __name__ == '__main__':
    register()
    # Unit test for function decode

# Generated at 2022-06-23 17:48:16.787593
# Unit test for function decode
def test_decode():
    """Samples for testing the function ``decode``."""

    unit_test_str = (
        '''
        4oCT8oOTkA==
        '''
    )

    result_str = (
        '''
        漢語
        '''
    )

    assert decode(unit_test_str)[0] == result_str



# Generated at 2022-06-23 17:48:19.283160
# Unit test for function decode
def test_decode():
    assert decode(b'YWJj')[0] == 'YWJj', 'test_decode: 1'



# Generated at 2022-06-23 17:48:25.972221
# Unit test for function encode
def test_encode():
    # Setup
    d = '''
        eyJ0ZXN0Ijoic3RyaW5nIn0KCg==
    '''.lstrip()

    # Exercise
    result, size = encode(d)

    # Verify
    assert result == b'{"test":"string"}\n\n'
    assert size == len(d)



# Generated at 2022-06-23 17:48:28.294701
# Unit test for function encode
def test_encode():
    '''Test that the function encode works'''
    assert(encode(b'SGVsbCBtZQ==') == (b'Hello me', 11))


# Generated at 2022-06-23 17:48:32.285726
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    codecs.getincrementalencoder(NAME)
    codecs.getincrementaldecoder(NAME)


if __name__ == '__main__':
    # Run unit tests
    test_register()

# Generated at 2022-06-23 17:48:33.542269
# Unit test for function register
def test_register():
    from pytest import raises
    codecs.register(_get_codec_info)  # type: ignore
    with raises(TypeError):
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-23 17:48:41.348489
# Unit test for function encode
def test_encode():
    """Test the base64 encoding function
    """
    assert encode('Zm9vZGFzaA==') == (b'foodasha', 8)
    assert encode('Zm9vZGFzaGJhcg==') == (b'foodashbar', 10)
    assert encode('Zm9vZGFzaGJhcg==\n') == (b'foodashbar', 10)
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'', 0)
    assert encode('\n\n\n') == (b'', 0)
    assert encode('Zm9vZGFzaA==\n') == (b'foodasha', 8)
    assert encode('\nZm9vZGFzaA==\n') == (b'foodasha', 8)
   

# Generated at 2022-06-23 17:48:52.916427
# Unit test for function encode
def test_encode():
    """Unit test for the encode() function.
    """
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 10)
    assert encode('') == (b'', 0)
    assert encode('YQ==') == (b'a', 4)
    assert encode('Zg==') == (b'f', 4)
    assert encode('aGVsbG8gd29ybGQh') == (b'hello world!', 16)
    assert encode('dGhlIHNhbXBsZSBq\nc2UgZ2VuZXJhdG9yIGFn\nYWlu') == (
        b'the sample js\x00e\x00 generator again',
        43
    )

# Generated at 2022-06-23 17:48:55.226233
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'\x00\x01\x02\x03') == ('AAECAw==', 4)

register()

# Generated at 2022-06-23 17:48:58.568431
# Unit test for function register
def test_register():
    register()
    assert NAME == 'b64'
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None


# Function register is run as part of loading this module.
test_register()

# Generated at 2022-06-23 17:49:01.563393
# Unit test for function encode
def test_encode():
    assert encode(
        """
                SGVsbG8sIEdvb2RieWUu
            """) == (b'Hello, Goodbye.', 27)



# Generated at 2022-06-23 17:49:12.512986
# Unit test for function register
def test_register():
    """Test the register function."""
    # Unregister and re-register the 'b64' codec
    try:
        codecs.unregister(NAME)
    except LookupError:
        pass
    register()
    assert NAME in codecs.registered_incremental_encoders  # type: ignore
    # codecs.incremental_decoders
    # codecs.lookup(NAME)
    # test_codec_info = codecs.CodecInfo(
    #     name=NAME,
    #     decode=decode,  # type: ignore[arg-type]
    #     encode=encode,  # type: ignore[arg-type]
    # )
    # assert codecs.lookup(NAME) == test_codec_info  # type: ignore



# Generated at 2022-06-23 17:49:16.416567
# Unit test for function decode
def test_decode():
    """Unit test for :func:`~b64.decode`"""
    assert decode(b'hello', '') == ('aGVsbG8=', 5)
    assert decode(b'big bcae', '') == ('YmlnIGJjYWU=', 8)



# Generated at 2022-06-23 17:49:23.884153
# Unit test for function decode
def test_decode():
    # assert isinstance(b64, codecs)
    res, _ = codecs.getdecoder('b64')(
        data=b'\x1B\x1A\x1B',
        errors='strict'
    )
    assert res == '+P4='

    res, _ = codecs.getdecoder('b64')(
        data=b'\x1B',
        errors='strict'
    )
    assert res == 'Ew=='

    res, _ = codecs.getdecoder('b64')(
        data=b'\x1B\x1A',
        errors='strict'
    )
    assert res == '+Pg='



# Generated at 2022-06-23 17:49:28.476218
# Unit test for function decode
def test_decode():
    data = b'\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'
    result = decode(data)
    assert result == ('8P/////w8=', len(data))


# Generated at 2022-06-23 17:49:37.546649
# Unit test for function decode
def test_decode():
    # Test the basic decoding of a string
    expected_str_0: str = 'Hello world!'
    expected_int_0: int = 12
    t_0: Tuple[str, int] = decode(b'SGVsbG8gd29ybGQh')

    assert t_0[0] == expected_str_0
    assert t_0[1] == expected_int_0
    # Test the basic decoding of a string that is wrapped over 2 lines.
    expected_str_1: str = """Hello
            World!"""
    expected_int_1: int = 25
    test_str_1: str = """SGVsbG8KICAgICAgV29ybGQh"""
    t_1: Tuple[str, int] = decode(test_str_1)


# Generated at 2022-06-23 17:49:46.073095
# Unit test for function register
def test_register():
    """Unit test for function ``register``"""
    from copy import copy
    import sys

    original_modules = copy(sys.modules)
    try:
        register()

        # Ensure that the codec is registered.
        assert NAME in codecs.encode('', NAME)[0].decode('utf-8')
    finally:
        # Remove the 'sys.modules' keys that were added by the register
        # function.
        # pylint: disable=protected-access
        sys.modules = {
            x: sys.modules[x]
            for x in original_modules
            if x in sys.modules
        }



# Generated at 2022-06-23 17:49:52.607471
# Unit test for function encode
def test_encode():
    to_encode = '''\
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Phasellus laoreet nisl et tristique mollis.
'''
    expected_encoded = (
        b"TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGF"
        b"kaXBpc2NpbmcgZWxpdC4KUGhhc2VsbHVzIGxhb3JlZXQgbmlzbCBldC"
        b"B0cmlzdGlxdWUgbW9sbGlzLgo="
    )
    encoded_str, _length = encode(to_encode)
    encoded

# Generated at 2022-06-23 17:49:55.140947
# Unit test for function register
def test_register():
    """Test the function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:50:02.488385
# Unit test for function decode
def test_decode():
    """Unit test for the decode function."""

# Generated at 2022-06-23 17:50:13.867475
# Unit test for function register
def test_register():
    """Test that the ``b64`` codec is registered with Python."""
    import sys
    import types

    # Clear the 'sys.modules' cache.
    _ = sys.modules.pop(NAME, None)  # type: ignore[arg-type]
    _ = sys.modules.pop('b64', None)  # type: ignore[arg-type]

    # Import the 'b64' module.
    import b64
    assert b64.__name__ == 'b64'  # type: ignore[attr-defined]

    # Confirm that a 'b64' codec is not registered with Python.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert (
            str(e) ==
            f'unknown encoding: {NAME!r}'
        )

# Generated at 2022-06-23 17:50:21.068247
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    from unittest.mock import Mock

    def _mock_decode(data, errors):
        """Mock the decode method."""
        return (data, len(data))

    def _mock_encode(text, errors):
        """Mock the encode method."""
        return (text, len(text))

    codecs.register(Mock(return_value=Mock(decode=_mock_decode,
                                           encode=_mock_encode)))

    ex_data = b'\xE3\x81\x82\xE3\x82\x84\xE3\x82\x86'
    ex_len = 7

    ret_tpl = decode(ex_data, 'strict')


# Generated at 2022-06-23 17:50:30.989270
# Unit test for function decode

# Generated at 2022-06-23 17:50:37.315783
# Unit test for function register
def test_register():
    # Try to get the decoder for the 'u8' codec.
    # This should raise a LookupError
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    #
    # Register the 'u8' codec then try to get the decoder for the
    # 'u8' codec.  This should not raise a LookupError.
    #
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:50:40.270938
# Unit test for function register
def test_register():
    """Test call to register()"""
    register()
    assert codecs.lookup_error('b64') is UnicodeEncodeError


__all__ = ('register', 'test_register')

# Generated at 2022-06-23 17:50:49.461944
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # function sys.getrefcount will not count the reference that is being
    # passed to the function.  Therefore we will call sys.getrefcount twice
    # with the same parameter to get the count of the object.  Then we can
    # just check to see if the count of the object was increased by 1.
    b64_ref_count = sys.getrefcount(NAME)
    register()
    b64_ref_count2 = sys.getrefcount(NAME)
    assert b64_ref_count + 1 == b64_ref_count2



# Generated at 2022-06-23 17:50:57.882654
# Unit test for function encode

# Generated at 2022-06-23 17:50:59.725754
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)


# Generated at 2022-06-23 17:51:01.596617
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        # This should never happen
        print('Error: Unable to find codec', NAME)


# Generated at 2022-06-23 17:51:04.866268
# Unit test for function register
def test_register():
    """Unit test for function register
    """
    codecs.register(_get_codec_info)
    utf8 = codecs.getdecoder('b64')
    utf8('test1')


# Generated at 2022-06-23 17:51:15.496822
# Unit test for function decode
def test_decode():
    """unit test for the decode function."""
    assert decode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=') == ('abcdefghijklmnopqrstuvwxyz', 44)
    assert decode(b'ZHVtbXkyMDE4LXRlc3Rpbmc=') == ('dummy2018-testing', 22)
    assert decode(b'ZHVtbXkyMDE4LXRlc3Rpbmc=\n') == ('dummy2018-testing', 22)
    assert decode(b'\nZHVtbXkyMDE4LXRlc3Rpbmc=\n') == ('dummy2018-testing', 22)

# Generated at 2022-06-23 17:51:24.299234
# Unit test for function decode
def test_decode():
    assert codecs.decode('YQ==', 'b64') == b'a'
    assert codecs.decode('YWI=', 'b64') == b'ab'
    assert codecs.decode('YWJj', 'b64') == b'abc'
    assert codecs.decode('YWJjZA==', 'b64') == b'abcd'
    assert codecs.decode('YWJjZGU=', 'b64') == b'abcde'
    assert codecs.decode('YWJjZGVm', 'b64') == b'abcdef'
    assert codecs.decode('YWJjZGVmZw==', 'b64') == b'abcdefg'

# Generated at 2022-06-23 17:51:33.857118
# Unit test for function decode
def test_decode():
    """Test the function 'decode'."""
    result_str = decode(b'the brown fox jumps over the lazy dog')[0]
    exp_result = 'dGhlIGJyb3duIGZveCBqdW1wcyBvdmVyIHRoZSBsYXp5IGRvZw=='
    assert result_str == exp_result

    data = b'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='
    result_str = decode(data)[0]

# Generated at 2022-06-23 17:51:41.324000
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    cases = [
        ('dGVzdCB0ZXN0', 'test test'),
        (b'dGVzdCB0ZXN0', 'test test'),
        (b'test test', 'dGVzdCB0ZXN0'),
    ]

    for case in cases:
        input_data, expected_output = case

        output, length = decode(input_data, errors='strict')
        assert output == expected_output
        assert length == len(input_data)


# Generated at 2022-06-23 17:51:50.865740
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""

    def do_test(
            text: _STR,
            expected_bytes: _ByteString
    ) -> None:
        """Encode the given ``text`` and compare the result to the
        expected bytes.
        """
        # Encode the given 'text'.
        encoded_bytes, _ = encode(text)

        # Compare the encoded bytes to the expected bytes.
        assert encoded_bytes == expected_bytes

    text_input = '''\
    abcdefghijklmnopqrstuvwxyz
    ABCDEFGHIJKLMNOPQRSTUVWXYZ
    1234567890
    +/
    '''
    text_bytes = text_input.encode('utf-8')
    expected_bytes = base64.b64decode(text_bytes)
   

# Generated at 2022-06-23 17:52:00.981359
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(b'abc')[0] == 'YWJj'
    assert decode(b'abcdef')[0] == 'YWJjZGVm'
    assert decode(b'abcdefgh')[0] == 'YWJjZGVmZ2g='
    assert decode(b'abcdefghij')[0] == 'YWJjZGVmZ2hpag=='
    assert decode(b'abcdefghijk')[0] == 'YWJjZGVmZ2hpag=='
    assert decode(b'abcdefghijkl')[0] == 'YWJjZGVmZ2hpamts'
        

# Generated at 2022-06-23 17:52:10.517536
# Unit test for function encode
def test_encode():
    assert encode('AA==') == (b'\x00', 4)
    assert encode('AAA=') == (b'\x00\x00', 4)
    assert encode('AAAA') == (b'\x00\x00\x00', 4)
    assert encode('AAAAAQ==') == (b'\x00\x00\x00\x00', 8)
    assert encode('cHdk') == (b'pwd', 4)
    assert encode('dG90YWwgdG90YWwgdG90YWwgdG90YWw=') == (b'total total total total', 28)
    assert encode('Cg==') == (b'\n', 4)

# Generated at 2022-06-23 17:52:13.212628
# Unit test for function encode
def test_encode():
    text = "dGl0bGU6IGFydGljbGU="
    out, len_ = encode(text)
    assert out == "dGl0bGU6IGFydGljbGU="


# Generated at 2022-06-23 17:52:14.991697
# Unit test for function decode
def test_decode():
    assert decode(b'SGVsbG8K')[0] == 'Hello\n'


# Generated at 2022-06-23 17:52:22.812346
# Unit test for function decode

# Generated at 2022-06-23 17:52:34.619068
# Unit test for function register
def test_register():
    import sys
    if NAME not in codecs.__all__:
        register()
        assert sys.modules[__name__] == codecs.lookup(NAME)
    else:
        assert sys.modules[__name__] == codecs.lookup(NAME)


if __name__ == '__main__':
    # Unit test this module.
    import unittest

    class TestB64Codec(unittest.TestCase):
        """Unit tests for the b64 codec.
        """

        def test_b64_codec_register(self):
            """Test the register function."""
            test_register()

# Generated at 2022-06-23 17:52:42.293058
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('YQ==', 1)
    assert decode(b'ab') == ('YWI=', 2)
    assert decode(b'abc') == ('YWJj', 3)
    assert decode(b'abcd') == ('YWJjZA==', 4)
    assert decode(b'abcde') == ('YWJjZGU=', 5)
    assert decode(b'abcdef') == ('YWJjZGVm', 6)
    assert decode(b'abcdefg') == ('YWJjZGVmZw==', 7)
    assert decode(b'abcdefgh') == ('YWJjZGVmZ2g=', 8)
    assert decode(b'abcdefghi') == ('YWJjZGVmZ2hp', 9)