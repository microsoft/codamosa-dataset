

# Generated at 2022-06-23 17:42:50.478993
# Unit test for function encode
def test_encode():
    assert b'\x00\x00' == encode('AA==')[0]
    assert b'\x00\x00' == encode('AA==')[0]

# Generated at 2022-06-23 17:42:59.962920
# Unit test for function decode
def test_decode():
    """Testing the function decode."""
    # Test simple conversion
    assert decode(b'asdf')[0] == 'YXNkZg=='

    # Test input with whitespace
    assert decode(b'asdf asdf')[0] == 'YXNkZiBhc2Rm'
    assert decode(b'asdf\nasdf')[0] == 'YXNkZgphc2Rm'
    assert decode(b'asdf\tasdf')[0] == 'YXNkZgphc2Rm'
    assert decode(b'asdf\rasdf')[0] == 'YXNkZgphc2Rm'

    # Test that an empty byte string returns an empty string
    assert decode(b'')[0] == ''



# Generated at 2022-06-23 17:43:11.716636
# Unit test for function encode
def test_encode():
    # Test 1
    assert encode('aaaaaaaaa') == (
        b'\x03\x03\x03\x03\x03\x03\x03\x03\x03',
        9
    )

    # Test 2
    assert encode('a a a a a a a a a') == (
        b'\x0D\x0D\x0D\x0D\x0D\x0D\x0D\x0D\x0D',
        18
    )

    # Test 3
    assert encode('a aa a aa a aa a aa') == (
        b'\x03\x03\x03\x0D\x03\x03\x03\x0D\x03',
        18
    )

    # Test 4

# Generated at 2022-06-23 17:43:23.361072
# Unit test for function encode
def test_encode():
    assert encode("AQAB") == (b"\x01\x00\x01", 4)
    assert encode("AAAAAQAB") == (b"\x00\x01\x00\x01", 6)
    assert encode("YWJj") == (b"abc", 4)
    assert encode("YWJjZGU=") == (b"abcde", 4)
    assert encode("YWJjZGVm") == (b"abcdef", 4)
    assert encode("YWJjZGVmZw==") == (b"abcdefg", 4)
    assert encode("YWJjZGVmZ2g=") == (b"abcdefgh", 4)
    assert encode("YWJjZGVmZ2hp") == (b"abcdefghi", 4)

# Generated at 2022-06-23 17:43:31.145381
# Unit test for function register
def test_register():
    """Test the ``register`` function."""
    import sys
    import types  # type: ignore

    def _assert_register(name: _STR):
        # Assert that the codec exists in the codecs dictionary.
        assert name in codecs.__dict__
        # Assert that the codec exists in the sys.modules dictionary.
        assert name in sys.modules
        # Assert that the codec type is a 'ModuleType'.
        assert isinstance(codecs.__dict__[name], types.ModuleType)


# Generated at 2022-06-23 17:43:36.086538
# Unit test for function decode
def test_decode():
    encoded_str = 'SGVsbG8gV29ybGQh'
    data_str = 'Hello World!'
    data_bytes = bytes(data_str, encoding='utf8')
    returned_str, _ = decode(data_bytes)
    assert returned_str == encoded_str


# Generated at 2022-06-23 17:43:42.729281
# Unit test for function encode
def test_encode():
    assert encode("Hello World")[0] == b"SGVsbG8gV29ybGQ="
    assert encode("Hello World")[1] == 11
    assert encode("This is a test string")[0] == b"VGhpcyBpcyBhIHRlc3Qgc3RyaW5n"
    assert encode("This is a test string")[1] == 25
    assert encode("Meh")[0] == b"TWVo"
    assert encode("Meh")[1] == 3


# Generated at 2022-06-23 17:43:45.870211
# Unit test for function encode
def test_encode():
    # Do not perform any tests if this module is being built to run the
    # registration function.
    if NAME != '__main__':
        import doctest
        doctest.testmod()



# Generated at 2022-06-23 17:43:54.228077
# Unit test for function decode
def test_decode():
    # Test:
    #     Arguments:
    #         data (bytes or bytearray or memoryview): Bytes to be converted
    #             to a string of base64 characters.
    #         errors (str or :obj:`~UserString`): Not used.  This argument exists
    #         to meet the interface requirements.  Any value given to this
    #         argument is ignored.
    #
    #     Returns:
    #         str: of base64 Characters
    #         int: the number of the given ``data`` bytes consumed.

    # Test that the decode function returns the correct output
    assert decode(b'test') == ('dGVzdA==', 4)

    # Test that the decode function returns the correct output when
    # the input data is a bytearray

# Generated at 2022-06-23 17:43:58.866793
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)


_ENCODER_NAME = 'utf-8'
_DECODER_NAME = 'utf-8'


# noinspection PyUnusedLocal

# Generated at 2022-06-23 17:44:03.398556
# Unit test for function register
def test_register():
    import sys

    def _run_test(obj=None):
        if obj is None:
            assert codecs.getdecoder(NAME) is not None
        else:
            codecs.register(obj)  # type: ignore

    _run_test()
    _run_test(lambda x: None)
    sys.stdout.write('\n')



# Generated at 2022-06-23 17:44:15.318829
# Unit test for function decode
def test_decode():
    from b64codec import b64
    assert('\n' == b64.decode(b'Cg==')[0])
    assert('\n' == b64.decode(b'\nCg==\n')[0])
    assert('\n' == b64.decode(b'\n    Cg==\n')[0])
    assert('\n' == b64.decode(b'\n    \n\tCg==\n')[0])
    assert('\n' == b64.decode(b'\n    Cg==   \n   ')[0])
    assert(b'\n' == b64.encode('\n')[0])

# Generated at 2022-06-23 17:44:26.749875
# Unit test for function encode
def test_encode():
    """Run unit test for encode function."""

# Generated at 2022-06-23 17:44:32.586513
# Unit test for function register
def test_register():
    """Test function :func:`register()`."""
    # Register the codec.
    register()

    # Verify the codec is in the codec map
    codec = codecs.getdecoder(NAME)
    assert codec is not None

# Generated at 2022-06-23 17:44:42.418836
# Unit test for function encode
def test_encode():
    inStr = 'Hey Joe, Whats up?'
    inStr64 = 'SGV5IEpvZSwgV2hhdHMgdXA/'
    out_str, len_str = encode(inStr, 'strict')
    out_str64, len_str64 = encode(inStr64, 'strict')
    out_str_fail, len_str_fail = encode('', 'strict')


    assert base64.b64encode(out_str_fail) == b''
    assert len_str_fail == 0
    assert out_str == b'Hey Joe, Whats up?'
    assert out_str64 == b'Hey Joe, Whats up?'
    assert len_str == len(inStr)
    assert len_str64 == len(inStr64)



# Generated at 2022-06-23 17:44:49.860623
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    expect = b'\x8dv\x81s\xe4\x04\xe6'
    actual = encode("uLjXkMfQ6J3e6Q==")
    assert expect == actual[0]

    expect = b'\x8dv\x81s\xe4\x04\xe6\x00\x00'
    actual = encode("uLjXkMfQ6J3e6Q")
    assert expect == actual[0]

    expect = b'\x8dv\x81s\xe4\x04\xe6\x00\x00'
    actual = encode(" uLjXkMfQ6J3e6Q")
    assert expect == actual[0]


# Generated at 2022-06-23 17:44:54.063838
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode``."""
    from b64_codec.tests.test_data import data_to_encode, encoded_data
    # noinspection PyTypeChecker
    assert decode(data_to_encode) == (encoded_data, len(data_to_encode))


# Generated at 2022-06-23 17:45:05.217258
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)  # type: ignore


if __name__ == '__main__':
    register()
    assert NAME == 'b64'
    # plaintext = "Mark Twain"


# Generated at 2022-06-23 17:45:09.065374
# Unit test for function encode
def test_encode():
    string_b64 = 'BC/=='
    string_bytes = encode(string_b64)
    assert string_bytes[0] == b'\x03'
    assert string_bytes[1] == 1



# Generated at 2022-06-23 17:45:14.996141
# Unit test for function register
def test_register():
    """Unit test for function register."""

    # Reset the registry.
    del codecs.registry._codec_registry[NAME]

    # Verify that the codec is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Verify the codec is registered
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:45:15.851849
# Unit test for function register
def test_register():
    codecs.lookup(NAME)


# Generated at 2022-06-23 17:45:17.884929
# Unit test for function register
def test_register():
    """Test the 'register' function."""
    # Register the codec.
    register()

    # Confirm the codec can be found.
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:45:25.188857
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test for handling the end of line as just a newline
    assert encode('Zm9vYmFy') == (b'foobar', 8)
    # Test for handling the end of line as a CR LF
    assert encode('Zm9vYmFyCg==') == (b'foobar', 10)
    # Test for handling the end of line as a CR
    assert encode('Zm9vYmFyDQ==') == (b'foobar', 10)
    # Test for handling the end of line CR or LF
    assert encode('Zm9vYmFyDQo=') == (b'foobar', 11)
    # Test for handling an empty input
    assert encode('') == (b'', 0)
    # Test for handling an input with indenting

# Generated at 2022-06-23 17:45:26.714085
# Unit test for function register
def test_register():
    """Unit test for function register."""
    _test_register()



# Generated at 2022-06-23 17:45:29.729671
# Unit test for function register
def test_register():
    """Test registering the encoding with Python."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:45:39.619635
# Unit test for function encode
def test_encode():
    """Test that the ``encode`` function properly decodes base64 strings.
    """
    test_str = str(UserString('\n'.join([
        '',
        ' U2lnbmF0dXJlIFRlc3QgU3RyaW5nIC0tLS0tLS0tLS0tLS0tLS0tLX4=',
        '',
    ])))

# Generated at 2022-06-23 17:45:43.032158
# Unit test for function register
def test_register():
    """Unit tests for the register function."""
    import doctest
    from . import b64
    results = doctest.testmod(b64)
    assert results.failed == 0



# Generated at 2022-06-23 17:45:52.073052
# Unit test for function register
def test_register():
    # get a reference to the b64 codec if it is registered.
    codec_obj = codecs.lookup(NAME)
    register()

    # If the codec was not registered before, the following will error.
    codecs.lookup(NAME)

    # The above can error if the codec was registered before.
    # So, unregister the b64 codec and register it again.
    codecs.unregister(codec_obj)
    register()



# Generated at 2022-06-23 17:46:02.841638
# Unit test for function register
def test_register():
    """Test the function register()."""
    codecs.register(register)

# Generated at 2022-06-23 17:46:08.504840
# Unit test for function decode
def test_decode():
    """Test the encoding of bytes into base64 character string."""
    encoded = codecs.getencoder(NAME)
    assert encoded(b'\x00\x01\x02\x03'.hex()) == (
        'AAECAwQ=',
        8
    )
    assert encoded(b'\x00\x01\x02\x03\x04\x05\x06\x07'.hex()) == (
        'AAECAwQFBgc=',
        12
    )



# Generated at 2022-06-23 17:46:16.154242
# Unit test for function decode

# Generated at 2022-06-23 17:46:26.329886
# Unit test for function register
def test_register():
    """Unit test for function register."""
    def _test_encode(text: _STR) -> str:
        """Helper function for testing the encode function."""
        encoded_bytes, _ = encode(text)
        return encoded_bytes.decode('utf-8')

    def _test_decode(text: _STR) -> bytes:
        """Helper function for testing the decode function."""
        return decode(text)[0].encode('utf-8')

    # Encode the following text
    text = '''\
    TmV3IHBl5iZQ==
    '''

    # Try decoding the text as a raw string
    err_txt = text
    try:
        decode(text)
    except UnicodeEncodeError as e:
        err_txt = e.reason

# Generated at 2022-06-23 17:46:37.269026
# Unit test for function encode
def test_encode():
    text = 'ZW5jb2RlIG1lLic='
    encoded_bytes = encode(text)[0]
    expected = b'encode me.'
    assert encoded_bytes == expected, (
        f"{encoded_bytes!r} != {expected!r}"
    )

    text = 'ZW5jb2RlIG1lLmE'
    with raises(UnicodeEncodeError):
        encode(text)

    text = 'ZW5jb2RlIG1lLmFwcGVuZCBhIHdlc3Q='
    encoded_bytes = encode(text)[0]
    expected = b'encode me.append a west'
    assert encoded_bytes == expected, (
        f"{encoded_bytes!r} != {expected!r}"
    )



# Generated at 2022-06-23 17:46:39.948783
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) == _get_codec_info(NAME)



# Generated at 2022-06-23 17:46:43.595102
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        print(f'{NAME} codec not registered: {e}')
        assert False
    else:
        assert True

# Unit tests for function encode.

# Generated at 2022-06-23 17:46:53.339993
# Unit test for function decode
def test_decode():
    assert decode(b'YQ==')[0] == 'a'
    assert decode(b'YWI=')[0] == 'ab'
    assert decode(b'YWJj')[0] == 'abc'
    assert decode(b'\nYWJj\n')[0] == 'abc'
    assert decode(b'YWJj\n')[0] == 'abc'
    assert decode(b'\nYWJj')[0] == 'abc'
    assert decode(b'Y\nW\nJ\nj\n')[0] == 'abc'




# Generated at 2022-06-23 17:46:56.436590
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-23 17:47:00.523073
# Unit test for function register
def test_register():
    """Unit test for function ``register``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('The codec is already registered with the '
                        'codecs package.')
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:47:11.680185
# Unit test for function register
def test_register():
    #
    # Setup
    #
    codecs_registry = dict(codecs.__dict__)
    #
    # Test
    #
    register()
    #
    # Cleanup
    #
    for k, v in codecs.__dict__.items():
        if k not in codecs_registry:
            del codecs.__dict__[k]
        else:
            codecs.__dict__[k] = codecs_registry[k]


if __name__ == '__main__':
    # Register this codec with Python so that it is available.
    register()
    # Run unit tests.
    test_register()
    assert NAME in codecs.__dict__
    assert codecs.__dict__[NAME] is not None  # pragma: no cover

# Generated at 2022-06-23 17:47:18.234903
# Unit test for function encode
def test_encode():
    """Unit test of the encode function."""
    import io
    from .base64_test_data import BASE64_TEST_DATA

    for test_val in BASE64_TEST_DATA:
        dat, _ = encode(test_val.text_input)
        out = io.BytesIO()
        base64.encode(io.BytesIO(test_val.dat), out, add_newline=False)
        result = bytes(out.getvalue())
        assert result == dat


# Generated at 2022-06-23 17:47:20.070829
# Unit test for function register
def test_register():
    register()  # pragma no cover


codecs.register(_get_codec_info)



# Generated at 2022-06-23 17:47:21.254156
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()

# Generated at 2022-06-23 17:47:33.809598
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""

    from typing import Any, Dict

    def print_header(msg: str) -> None:
        """Print a header for a test section"""
        print(f'{msg:60}', end='')

    def print_result(func: Any, desc: str, actual: Any, expected: Any) -> None:
        """Compare Expected vs Actual and print results"""

# Generated at 2022-06-23 17:47:35.904027
# Unit test for function decode
def test_decode():
    assert b'\x00\x01\x02\x03\x04\x05\x06' == decode('AAECAwQFBgc')[0]


# Generated at 2022-06-23 17:47:37.703984
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-23 17:47:50.012319
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    # Test with a valid string.
    text_input = '''
                bT0geW91ciBvd24gcmlkLCBub3Qgb25seSBvdXIgcmlkLg0KDQpJIGdpdmUg
                eW91IHRoZSBwZXJtaXNzaW9uIHRvIGJlIGF3ZXNvbWUuDQoNCkl0J3MgaW4gdG
                hpbmdzIG9mIG1vcmUgdGhhbiBmb2N1cywgY2VydGFpbiB0aGF0IG9uY2UgeW9
                1IGtub3cgdGhleSBhcHBlYXIuDQo=
                '''

# Generated at 2022-06-23 17:47:52.384559
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codec = codecs.getdecoder(NAME)
    assert hasattr(codec, 'decode')
    assert hasattr(codec, 'encode')



# Generated at 2022-06-23 17:47:58.896308
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # pylint: disable=W0212
    codecs._cache.clear()
    register()
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, f'Unable to get decoder for {NAME}'
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, f'Unable to get encoder for {NAME}'

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:48:08.314011
# Unit test for function register
def test_register():
    """Test the register method this module."""

    # Unregister the codec.  This doesn't fail if the codec is not yet
    # registered.
    try:
        codecs.unregister(NAME)
    except LookupError:
        pass

    # Check that the codec is not registered
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Check that the codec is registered.
    codecs.getdecoder(NAME)

    # Test that it is a no-op to register the codec again
    register()

# Generated at 2022-06-23 17:48:15.430076
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', len('dGVzdA=='))
    assert encode('dGVzdA==\n') == (b'test', len('dGVzdA==\n'))
    assert encode('dGVzdA==\n ') == (b'test', len('dGVzdA==\n '))


# Generated at 2022-06-23 17:48:20.435300
# Unit test for function register
def test_register():
    # Reset the codecs, so that we can test register().
    codec_info = codecs.lookup(NAME)
    codecs.unregister(codec_info)

    # Test that 'b64' is not registered
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codecs
    register()

    # Test that 'b64' is registered
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-23 17:48:30.922798
# Unit test for function register
def test_register():
    REGISTERED_CODECS = tuple(
        codecs.lookup(NAME)
        for NAME in codecs.__dict__['_cache']
        if isinstance(codecs.__dict__['_cache'][NAME], codecs.CodecInfo)
    )
    assert NAME not in REGISTERED_CODECS

    # Register the codec.
    register()

    # Confirm that the codec registered.
    REGISTERED_CODECS = tuple(
        codecs.lookup(NAME)
        for NAME in codecs.__dict__['_cache']
        if isinstance(codecs.__dict__['_cache'][NAME], codecs.CodecInfo)
    )
    assert NAME in REGISTERED_CODECS



# Generated at 2022-06-23 17:48:39.433265
# Unit test for function register
def test_register():  # pylint: disable=too-many-statements
    """Unit test for function register."""
    # Make sure the codec is not already registered.
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{NAME} is already registered')

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'{NAME} is already registered')

    # Register the codec.
    codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-23 17:48:45.709137
# Unit test for function encode
def test_encode():
    """Unit test for the encode function."""
    assert encode('AQI=')[0] == b'Mo'
    assert encode('AQI=')[1] == 4
    try:
        encode('AQI')
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('Encoding an invalid base64 string should raise an exception.')



# Generated at 2022-06-23 17:48:53.544559
# Unit test for function register
def test_register():
    """Exercise register()"""
    register()
    # Exercise the codec.
    codecs.decode(b'AQIDBAU=', NAME)
    codecs.encode(b'Hello World!', NAME)

    # Test an invalid codec
    raises(LookupError, codecs.decode, b'AQIDBAU=', '__cannot_exist__')
    raises(TypeError, codecs.encode, b'Something', '__cannot_exist__')


# Generated at 2022-06-23 17:49:00.540902
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`encode`"""
    # Get the function to be tested
    function = encode

    # Testing the identity encoding case.
    test_str = 'abcdefghijklmnopqrstuvwxyz'
    expected = b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    out, consumed = function(test_str)
    msg = f'{test_str!r} -> {out!r} == {expected!r}'
    assert out == base64.b64encode(test_str.encode('utf-8')), msg
    assert consumed == len(test_str), msg

    # Test a new string with str type
    test_str = '0123456789'

# Generated at 2022-06-23 17:49:11.878625
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('A') == (b'', 0)
    assert encode('AA') == (b'', 0)
    assert encode('AAA') == (b'', 0)
    assert encode('AAAA') == (b'', 0)
    assert encode('AAAAA') == (b'', 0)
    assert encode('AAAAAA') == (b'', 0)
    assert encode('AAAAAAA') == (b'', 0)
    assert encode('AAAAAAAA') == (b'', 0)
    assert encode('AAAAAAAAA') == (b'', 0)
    assert encode('AAAAAAAAAA') == (b'', 0)
    assert encode('AAAAAAAAAAA') == (b'', 0)
    assert encode('AAAAAAAAAAAA') == (b'', 0)

# Generated at 2022-06-23 17:49:19.287315
# Unit test for function encode
def test_encode():
    assert(encode("c2VuZCBzb21lIG1vbmV5IHRvIG1lIGdvb2Q=")[0]
           == b"Send some money to me good")
    assert(encode("SGVsbG8gd29ybGQ=")[0] == b"Hello world")
    assert(encode("WmVybyBieXRlcw==")[0] == b"Zero bytes")
    assert(encode("")[0] == b"")
    assert(encode("c2VuZCBzb21lIG1vbmV5IHRvIG1lIGdvb2Q=")[1] == 33)
    assert(encode("SGVsbG8gd29ybGQ=")[1] == 16)

# Generated at 2022-06-23 17:49:30.520823
# Unit test for function encode
def test_encode():          # pragma: no cover
    from pprint import pprint as ppr
    from b64codec import encode
    import hashlib
    data = (
        'H4sIAAAAAAAA/wAAAAAAAAAANAFyAAHpBtq3OAAAAA='
    )

# Generated at 2022-06-23 17:49:39.924982
# Unit test for function decode
def test_decode():
    assert decode(bytes(b'\x00')) == ('AA==', 1)
    assert decode(bytes(b'\x01')) == ('AQ==', 1)
    assert decode(bytes(b'\x02')) == ('Ag==', 1)
    assert decode(bytes(b'\x03')) == ('Aw==', 1)
    assert decode(bytes(b'\x04')) == ('BA==', 1)
    assert decode(bytes(b'\x05')) == ('BQ==', 1)
    assert decode(bytes(b'\x06')) == ('Bg==', 1)
    assert decode(bytes(b'\x07')) == ('Bw==', 1)
    assert decode(bytes(b'\x08')) == ('CA==', 1)

# Generated at 2022-06-23 17:49:48.317790
# Unit test for function encode
def test_encode():
    # Test a simple case
    text_input = '''Some test text.
    This text can span across many lines.
    And be indented any number of spaces.'''
    _, length = encode(text_input)
    assert length == len(text_input)
    # Test the case where the text is not a
    # string of base64 characters.
    text_input = text_input[:-5] + 'A' * 7
    try:
        # noinspection PyStatementEffect
        encode(text_input)
        assert False, 'Expected an exception to be raised.'
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-23 17:49:59.609666
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('Z') == (b'f', 1)
    assert encode('ZA') == (b'fY', 2)
    assert encode('ZAB') == (b'fYQ', 3)
    assert encode('ZABC') == (b'fYQg', 4)
    assert encode('ZABCD') == (b'fYQgv', 5)
    assert encode('ZABCDE') == (b'fYQgv4', 6)
    assert encode('ZABCDEF') == (b'fYQgv4A', 7)
    assert encode('ZABCDEFG') == (b'fYQgv4BH', 8)
    assert encode('ZABCDEFGH') == (b'fYQgv4BHd', 9)



# Generated at 2022-06-23 17:50:01.295746
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()

# Generated at 2022-06-23 17:50:08.534100
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    assert decode(b'a') == ('YQ==', 1)
    assert decode(b'b') == ('Yg==', 1)
    assert decode(b'ab') == ('YWI=', 2)
    assert decode(b'abc') == ('YWJj', 3)
    assert decode(b'\x01\x02\x03') == ('AQID', 3)



# Generated at 2022-06-23 17:50:17.728213
# Unit test for function encode
def test_encode():
    input_text = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAH0lEQVQ4jWNg"
        "GCN8OHaBgYGBgYGBgYGBgYGBgYGBge0/0AQAajg/8zR8GAAAAAElFTkSuQmCC"
    )

# Generated at 2022-06-23 17:50:19.241588
# Unit test for function register
def test_register():
    register()


# Initialize Python runtime codec registry
register()



# Generated at 2022-06-23 17:50:25.435088
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'The {NAME} codec should have not have been registered.'
        )
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'{e}')
    else:
        pass

# Generated at 2022-06-23 17:50:33.315093
# Unit test for function decode
def test_decode():
    assert decode(b'wq==')[0] == 'a'
    assert decode(b'1AbdvTjT')[0] == 'A12345'
    assert decode(b'DQ==')[0] == 'A'
    assert decode(b'Zg==')[0] == 'f'
    assert decode(b'Zm9v')[0] == 'foo'
    assert decode(b'Zm9vYg==')[0] == 'foob'
    assert decode(b'Zm9vYmE=')[0] == 'fooba'
    assert decode(b'Zm9vYmFy')[0] == 'foobar'
    assert decode(b'AAAAAA==')[0] == 'AAAAAA'

# Generated at 2022-06-23 17:50:43.738972
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode(
        '\n'.join(
            [
                '\t\t   ',
                'VGhpcyBpcyBhIHRlc3Q=',
                '\tICBhbmQgSSBsaWtlIGl0',
                '\n    ',
            ]
        )
    ) == b'This is a test\nand I like it'
    # Test with an invalid base64 character.

# Generated at 2022-06-23 17:50:45.173275
# Unit test for function register
def test_register():
    """Test function register"""
    register()

# Generated at 2022-06-23 17:50:46.028122
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__

# Generated at 2022-06-23 17:50:48.662083
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:50:56.688260
# Unit test for function encode

# Generated at 2022-06-23 17:51:00.563064
# Unit test for function register
def test_register():
    """Test the :obj:`~b64.register` function."""
    # Test that the codec is not already registered.
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:51:01.123524
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 17:51:04.043114
# Unit test for function encode
def test_encode():
    assert encode('QmFzZTY0IHRlc3Q=').decode('utf-8') == 'Base64 test'
    print('Passed encode test')


# Generated at 2022-06-23 17:51:14.643595
# Unit test for function decode
def test_decode():
    assert (
        decode(b' \n\t\r\n 1\n 2\n\t3\n\r1\r2\r3\r')
        == ('\n\t\r\n 1\n 2\n\t3\n\r1\r2\r3\r', 12)
    )

    assert (
        decode(b'\n\t\r\n 1\n 2\n\t3\n\r1\r2\r3\r')
        == ('\n\t\r\n 1\n 2\n\t3\n\r1\r2\r3\r', 12)
    )

    assert (
        decode(b'  ')
        == ('', 2)
    )


# Generated at 2022-06-23 17:51:21.900471
# Unit test for function decode
def test_decode():
    """Test the function ``decode``"""
    data = b'\xFB'
    out, _ = decode(data)
    assert out == '+w=='

    data = bytes(range(256))
    out, _ = decode(data)

# Generated at 2022-06-23 17:51:23.476310
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__


# Generated at 2022-06-23 17:51:33.328772
# Unit test for function encode

# Generated at 2022-06-23 17:51:43.250311
# Unit test for function encode
def test_encode():
    """Unit tests for function encode."""
    from docutils.nodes import Text
    from docutils.transforms import Transform

    class TestTransform(Transform):
        """Transform for testing."""

        default_priority = 500

        def apply(self, **kwargs):
            """Create a unicode node with text from stdout."""
            text = Text('b64', '')   # type: ignore
            text.name = 'unicode'
            text.rawsource = encode(text.astext())[0]
            self.document.append(text)

    # Add the TestTransform to the list of transforms.
    TestTransform.default_priority += 1
    Transform.transform_factory().add('Test', TestTransform)


# Generated at 2022-06-23 17:51:47.659181
# Unit test for function encode
def test_encode():
    assert encode('YQ==')[0] == b'a'
    assert encode('YWI=')[0] == b'ab'
    assert encode('YWJj')[0] == b'abc'
    assert encode('YWJjZA==')[0] == b'abcd'


# Generated at 2022-06-23 17:51:54.427603
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    # Create a collection of test inputs.

# Generated at 2022-06-23 17:52:05.144957
# Unit test for function decode
def test_decode():
    # Test the case where the input is empty.
    assert decode(b'') == ('', 0)

    # Test the case for a single byte.
    assert decode(b'o') == ('b3A=', 1)

    # Test the case for two bytes.
    assert decode(b'oA') == ('b3AO', 2)

    # Test the case for three bytes.
    assert decode(b'oAU') == ('b3AQVQ=', 3)

    # Test the case for four bytes.
    assert decode(b'oAUq') == ('b3AQVXE=', 4)

    # Test the case for more than four bytes.
    assert decode(b'oAUq!') == ('b3AQVXEI', 5)

test_decode()

# Generated at 2022-06-23 17:52:15.272479
# Unit test for function decode
def test_decode():
    def check(
            data_input: Union[str, bytes, bytearray],
            data_expected: str,
            length_expected: int
    ) -> None:
        """Check that a given ``data_input`` bytes is properly converted into
        ``data_expected`` string.

        Args:
            data_input (bytes or bytearray or memoryview): Bytes to be
                converted to a string of base64 characters.
            data_expected (str): The expected converted string.
            length_expected (int): The number of the given ``data_input``
                bytes consumed by the :meth:`~base64.Codec.decode` method.
        """
        data_decoded, length_decoded = decode(data_input)

        assert(data_decoded == data_expected)

# Generated at 2022-06-23 17:52:19.786544
# Unit test for function register
def test_register():
    test_name = 'b64'
    try:
        codecs.getdecoder(test_name)
        raise AssertionError(
            f'Registration for {test_name} should have failed.'
        )
    except LookupError:
        pass
    register()
    _ = codecs.getdecoder(test_name)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:52:25.740251
# Unit test for function encode
def test_encode():
    assert encode('\n') == (b'', 1)
    assert encode('\n \n ') == (b'', 1)
    assert encode(' \n ') == (b'', 1)
    assert encode('foo') == (b'Zm9v', 3)
    assert encode('foo bar') == (b'Zm9vIGJhcg==', 9)

# Generated at 2022-06-23 17:52:37.060480
# Unit test for function decode
def test_decode():
    from random import randint
    from random import choice
    from functools import reduce


# Generated at 2022-06-23 17:52:39.346687
# Unit test for function register
def test_register():
    """Test the :obj:`.register` function."""
    codecs.lookup(NAME)


if __name__ == '__main__':

    test_register()

# Generated at 2022-06-23 17:52:47.488022
# Unit test for function encode
def test_encode():
    print(encode('NjM='))
    print(encode('NjM'))
    print(encode('NjM'))

    print(encode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='))
    print(encode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo'))
    print(encode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo'))

