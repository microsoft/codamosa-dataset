

# Generated at 2022-06-23 17:42:48.746433
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""

# Generated at 2022-06-23 17:42:52.097917
# Unit test for function decode
def test_decode():
    assert decode(b'\xd2\x92\xa3\xd5\xdaw\x85') == ('5D6U5a6U5om/', 6)


# Generated at 2022-06-23 17:42:53.872192
# Unit test for function register
def test_register():
    """Test for function register"""
    register()
    assert codecs.getencoder(NAME)



# Generated at 2022-06-23 17:43:02.435871
# Unit test for function decode
def test_decode():
    """
    Test the ``b64`` codec against the "standard" :func:`base64.b64encode`.

    The only difference between the encodings is that the encoding output
    of the ``b64`` codec is text containing only ASCII characters.  The
    output of :func:`base64.b64encode` contains UTF-8 characters.
    """
    # Assert that the 'b64' codec returns the same data as the
    # base64.b64encode function for the known test cases.

# Generated at 2022-06-23 17:43:05.933457
# Unit test for function register
def test_register():
    """Test function register"""
    register()

    actual = codecs.getdecoder(NAME)  # type: ignore

    assert NAME in repr(actual)
    assert NAME == actual.__name__



# Generated at 2022-06-23 17:43:11.580878
# Unit test for function encode
def test_encode():
    line = "S2V2ZW4gY2FuIHF1aXQgYW5kIHNheSBhIGdvb2QgYnV0IGhlciBtaW5k"
    data, _ = encode(line)
    assert data == b"Seven can quit and say a good but her mind"



# Generated at 2022-06-23 17:43:12.823526
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:43:17.066573
# Unit test for function decode
def test_decode():
    """Test the function decode."""
    data = b'12345abcde'
    expected = 'MTIzNDVhYmNkZQ==\n'
    actual = decode(data)
    assert expected == actual[0]
    assert len(data) == actual[1]



# Generated at 2022-06-23 17:43:27.935604
# Unit test for function encode
def test_encode():
    """This function tests the ``encode`` function."""
    # Test adding noise to a b64 string
    result = encode("Hello world")
    assert result == (b'SGVsbG8gd29ybGQ=', 11)


    # Test adding noise to a b64 string
    result = encode("Hello world, my name is ARI")
    assert result == (b'SGVsbG8gd29ybGQsIG15IG5hbWUgaXMgQVJJ', 29)

    # Test adding noise to a b64 string
    result = encode("Base64 is the standard!")
    assert result == (b'QmFzZTY0IGlzIHRoZSBzdGFuZGFyZCE=', 23)

    # Test adding noise to a b64 string

# Generated at 2022-06-23 17:43:33.074980
# Unit test for function decode
def test_decode():
    # pylint: disable=W0621
    bs = b"I love to eat ice cream"
    result = decode(bs)
    assert result == "SSBsb3ZlIHRvIGVhdCBpY2UgY3JlYW0="


# Generated at 2022-06-23 17:43:37.152905
# Unit test for function encode
def test_encode():
    text_input = '''
'''
    text_str = '''
'''
    text_bytes = text_str.encode('utf-8')
    out = base64.decodebytes(text_bytes)
    assert encode(text_input) == (out, len(text_input))



# Generated at 2022-06-23 17:43:47.698304
# Unit test for function encode
def test_encode():
    """Unit test for function :func:`encode`."""
    from pytest import approx, raises

    register()

    # Test that the 'b64' codec encode function can handle simple
    # encodings.
    s = 'Hello World!'
    assert encode(s)[0] == b'SGVsbG8gV29ybGQh'

    # Test that the 'b64' codec encode function can handle encodings
    # with spaces.
    s = 'SGVsbG8gV29ybGQh'
    assert encode(s)[0] == b'SGVsbG8gV29ybGQh'

    # Test the 'b64' codec encode function can handle input that spans
    # multiple lines.

# Generated at 2022-06-23 17:43:54.330181
# Unit test for function encode

# Generated at 2022-06-23 17:44:04.338567
# Unit test for function encode
def test_encode():
    """Test the encode"""

    # Test a simple call
    data = 'a'
    value = encode(data)
    assert value == (b'YQ==', 1)

    # Test a simple call
    data = 'ab'
    value = encode(data)
    assert value == (b'YWI=', 2)

    # Test a simple call
    data = 'abc'
    value = encode(data)
    assert value == (b'YWJj', 3)

    # Test a simple call
    data = 'abcd'
    value = encode(data)
    assert value == (b'YWJjZA==', 4)

    # Test a simple call
    data = 'a' * 40
    value = encode(data)

# Generated at 2022-06-23 17:44:04.947800
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 17:44:11.938717
# Unit test for function decode
def test_decode():
    """Test the function ``decode``.
    """
    #
    # Test encode of bytearray
    #
    input = bytearray([127, 128, 255])
    expected_output = b'fjw='
    expected_consumed = 3
    output, consumed = decode(input)
    assert consumed == expected_consumed
    assert output == expected_output



# Generated at 2022-06-23 17:44:23.303760
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    assert decode(b'TDD', '') == ('VERU', 3)
    assert decode(b'TDD', 'utf-16') == ('VERU', 3)

# Generated at 2022-06-23 17:44:27.305285
# Unit test for function register
def test_register():
    """Test function register()"""

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(
            'The codecs.getdecoder() function failed to find the '
            'b64 codec.'
        ) from e


# pylint: disable=C0103

# Generated at 2022-06-23 17:44:31.768363
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8=')[0] == 'hello'
    assert decode(b'aGVsbG8=')[1] == 8


# Generated at 2022-06-23 17:44:41.894594
# Unit test for function register
def test_register():
    import os

    register()
    codecs.lookup(NAME)   # No error.

    # A second call to register should have no effect.
    register()
    codecs.lookup(NAME)  # No error.

    # A codec should be unregisterable.
    assert not os.environ.get(
        'DONT_UNREGISTER',
        False
    ), 'Codec should be unregisterable'

    codecs.unregister(NAME)
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'Codec {NAME} should not be registerable'
        )

    # A codec should be unregisterable *even* after register is called again.
    register()
    codecs.lookup(NAME) 

# Generated at 2022-06-23 17:44:44.750588
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-23 17:44:46.515877
# Unit test for function register
def test_register():
    """
    >>> register()
    """



# Generated at 2022-06-23 17:44:50.748201
# Unit test for function register
def test_register(): # type: ignore
    from io import StringIO
    from typing import TextIO
    from unittest import TestCase

    class _TestRegister(TestCase):
        def test_register(self):
            register()
            codecs.getdecoder(NAME)
            codecs.getencoder(NAME)

    return _TestRegister



# Generated at 2022-06-23 17:44:54.475797
# Unit test for function decode
def test_decode():
    assert decode(b'') ==  ('', 0)
    assert decode(b'AAAA') == ('QUFB', 4)
    assert decode(b'AAAA', 'strict') == ('QUFB', 4)



# Generated at 2022-06-23 17:45:01.130228
# Unit test for function decode
def test_decode():
    # Arrange
    data = b'Hello World\nThis is a test string\n'

    # Act
    text, consumed = decode(data)

    # Assert
    assert text == 'SGVsbG8gV29ybGQKVGhpcyBpcyBhIHRlc3Qgc3RyaW5nCg=='
    assert consumed == len(data)



# Generated at 2022-06-23 17:45:05.501037
# Unit test for function decode
def test_decode():
    """Test the function decode."""
    for i in range(200):
        s = base64.standard_b64encode(bytes([i]))
        assert decode(base64.standard_b64encode(bytes([i])))[0] == s.decode('utf-8')


# Generated at 2022-06-23 17:45:07.139773
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # Should not raise a LookupError.


# Generated at 2022-06-23 17:45:17.817888
# Unit test for function register
def test_register():  # pylint: disable=W0108
    """Unit test for function ``register``."""
    import os
    import shutil
    import sys
    from unittest.mock import patch
    from pathlib import Path
    import codecs as _codecs   # pylint: disable=W0622
    from test.support import EnvironmentVarGuard
    import b64
    TEST_DIR = Path(__file__).parent
    # pylint: disable=W0212
    b64 = sys.modules['b64']
    CODEC_PATH = Path(b64.__file__).parent
    codec_name = b64.NAME
    # Remove the ``b64.pyc`` file if present.
    (CODEC_PATH / f'{codec_name}.pyc').unlink(missing_ok=True)

# Generated at 2022-06-23 17:45:25.172511
# Unit test for function encode
def test_encode():
    """Test the encode function
    """
    assert encode(
        'aGVsbG8=\n'
    ) == (b'hello', 8)
    assert encode(
        'U3RhbmRhcmQgdGV4dCBjb252ZXJ0ZWQgdG8gQmFzZTY0IGlzIGJlbG93LgoK'
        'V2UnbGwgdGVzdCB0aGUgJ2Jhcg==\n'
    ) == (
        b"Standard text converted to Base64 is below.\n\nWe'll test "
        b'the "bar"',
        101
    )
    assert encode(
        'aGVsbG8=\n',
    ) == (b'hello', 8)

# Generated at 2022-06-23 17:45:36.457473
# Unit test for function register
def test_register():  # type: ignore
    """Unit test for the ``register`` function."""
    import sys
    from unittest import TestCase
    from unittest.mock import patch

    def _get_codec_info(name: str) -> Optional[codecs.CodecInfo]:  # type: ignore
        return None

    class TestRegister(TestCase):
        def setUp(self) -> None:
            self._sys_modules = sys.modules

        def test_register(self) -> None:
            from importlib import reload
            from typing import Any, Callable, Dict, NoReturn
            from io import StringIO
            from codecs import (
                getdecoder,
                getencoder,
                getincrementaldecoder,
                getincrementalencoder,
            )


# Generated at 2022-06-23 17:45:44.579760
# Unit test for function register
def test_register():
    """Verify that the ``b64`` codec is registered with Python."""
    # pylint: disable=import-outside-toplevel
    import codecs
    from . import b64
    # Remove the 'b64' codec if it is currently registered
    try:
        codecs.lookup(b64.NAME)
    except LookupError:
        pass
    else:
        codecs.lookup(b64.NAME)

    # Register the 'b64' codec
    b64.register()
    codecs.lookup(b64.NAME)

# Generated at 2022-06-23 17:45:55.784143
# Unit test for function decode
def test_decode():
    """
    Tests for function decode.

    Tests include:
        str        : input
        bytes or bytearray or memoryview : input
        str errors : input

    :return:
    """
    # Unit tests for function decode
    # Unit tests for single byte input
    test_byte_str1 = '\u0048'
    test_byte_str2 = '\u0068'
    assert decode(test_byte_str1.encode('raw_unicode_escape')) == ('SAAA', 1)
    assert decode(test_byte_str2.encode('raw_unicode_escape')) == ('aAAA', 1)

    # Unit tests for multi-byte (3 byte) input
    test_byte_str3 = '\u0048\u0068\u0065'
    test_byte_str4

# Generated at 2022-06-23 17:46:04.585861
# Unit test for function register
def test_register():
    """Test the register() function."""
    from pytest import raises
    from .test_encoder import NAME as _NAME
    try:
        codecs.getdecoder('b64')
        codecs.getencoder('b64')
    except LookupError:
        with raises(LookupError):
            codecs.getdecoder(_NAME)
        with raises(LookupError):
            codecs.getencoder(_NAME)

    register()

    assert NAME in str(codecs.lookup('b64'))
    codecs.getdecoder(_NAME)
    codecs.getencoder(_NAME)


# Init the register() function to make the codec available.
register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:46:14.945309
# Unit test for function register
def test_register():
    import sys
    import os

    def _get_file_encoding():
        # Python 2 and 3 have different names of the file encoding
        # attribute.  This is a work around to find the names of
        # the file attribute.
        return sys.stdout.encoding

    def _get_file_name():
        return sys.stdout.name

    def _get_encoding_name(encoding):
        return encoding.name

    def _register():
        register()
        return sys.stdout.encoding

    def _b64_name():
        return _get_encoding_name(_get_file_encoding())


# Generated at 2022-06-23 17:46:25.563410
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhcw==') == (b'any carnal pleas', 26)
    assert encode('YW55IGNhcm5hbCBwbGVhc3U=') == (b'any carnal pleasu', 27)
    assert encode('YW55IGNhcm5hbCBwbGVhc3Vy') == (b'any carnal pleasur', 28)
    assert encode('YW55IGNhcm5hbCBwbGVhcw') == (b'any carnal pleas', 25)
    assert encode('YW55IGNhcm5hbCBwbGVhc3U=') == (b'any carnal pleasu', 27)

    # Test that a blank lines is passed through.

# Generated at 2022-06-23 17:46:35.229323
# Unit test for function encode
def test_encode():
    from utils import _create_str
    pk_text = "eW91IGFyZSBiZWF1dGlmdWw="
    pk_bytes = b'you are beautiful'
    pk_len = len(pk_text)
    assert encode(pk_text) == (pk_bytes, pk_len)

    pk_text2 = _create_str(f"{pk_text}\n")
    assert encode(pk_text2) == (pk_bytes, pk_len)

    pk_text3 = _create_str(f"   \t{pk_text}\n")
    assert encode(pk_text3) == (pk_bytes, pk_len)


# Generated at 2022-06-23 17:46:44.078316
# Unit test for function encode
def test_encode():
    """
    The test_encode() function is a unit test for the encode() function.
    """
    assert encode('A')[0] == b'A'
    assert encode('a')[0] == b'a'
    assert encode('AA')[0] == b'AA'
    assert encode('aa')[0] == b'aa'
    assert encode('AAA')[0] == b'AAA'
    assert encode('aaa')[0] == b'aaa'
    assert encode(3) is None
    assert encode(3.14) is None



# Generated at 2022-06-23 17:46:51.250146
# Unit test for function decode
def test_decode():  # pragma: no cover
    import random
    import string
    for _ in range(100):
        inputs = bytes(tuple(  # type: ignore
            random.randint(0, 255) for _ in range(random.randint(1, 1024))
        ))
        expected = base64.b64encode(inputs)
        assert decode(inputs)[0].encode('utf-8') == expected



# Generated at 2022-06-23 17:46:55.234306
# Unit test for function register
def test_register():
    codecs.register = Mock(wraps=codecs.register)
    register()
    codecs.register.assert_called_once()
    codecs.register.assert_called_with(_get_codec_info)



# Generated at 2022-06-23 17:46:57.972189
# Unit test for function register
def test_register():
    """Register the b64 codec and verify it is registered."""
    register()
    codecs.getdecoder(NAME)


# pylint: disable=W0613

# Generated at 2022-06-23 17:47:09.606254
# Unit test for function decode

# Generated at 2022-06-23 17:47:11.218917
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)  # Should not raise

# Generated at 2022-06-23 17:47:13.554726
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:47:22.827224
# Unit test for function decode
def test_decode():
    """Test the decode function."""

# Generated at 2022-06-23 17:47:23.976730
# Unit test for function encode
def test_encode():
    actual = encode('abc')
    expected = (b'YWJj', 3)
    assert actual == expected



# Generated at 2022-06-23 17:47:29.834749
# Unit test for function register
def test_register():
    """Testing function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    raise Exception(
        f'{__file__:s} is not a standalone python program.  Do not run '
        'this python file directly.'
    )

# Generated at 2022-06-23 17:47:37.969470
# Unit test for function encode

# Generated at 2022-06-23 17:47:50.087855
# Unit test for function decode
def test_decode():
    print('Testing decode')
    assert decode(b'YWJj') == ('abc', 4)
    assert decode(b'Zg') == ('f', 2)
    assert decode(b'aA',) == ('\x00', 1)
    assert decode(b'Zm8=') == ('fo', 4)
    assert decode(b'Zm9v') == ('foo', 4)
    assert decode(b'Zm9vQQ==') == ('foo\x00', 8)
    assert decode(b'Zm9vYg==') == ('foob', 8)
    assert decode(b'Zm9vYmE=') == ('fooba', 8)
    assert decode(b'Zm9vYmFy') == ('foobar', 8)

# Generated at 2022-06-23 17:47:53.728511
# Unit test for function register
def test_register():
    """Check the ``register`` function."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None

# Generated at 2022-06-23 17:47:55.730359
# Unit test for function decode
def test_decode():
    assert decode(b'QUJD') == ('ABC', 3)
    assert decode(b'?@?') == ('?@?', 3)



# Generated at 2022-06-23 17:48:04.684251
# Unit test for function encode
def test_encode():
    """Tests for encoding text into bytes."""
    assert encode('aW5wdXQ6') == (b'input:', 7)
    assert encode('\naW5wdXQ6') == (b'input:', 7)
    assert encode('\n\n\n\naW5wdXQ6') == (b'input:', 7)
    assert encode('\n\n\n\naW5\n\n\n\nwdXQ6') == (b'input:', 7)
    assert encode('\n\n\n\naW5\n\n\n\nwdXQw') == (b'input0', 7)

# Generated at 2022-06-23 17:48:07.860218
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:48:11.159054
# Unit test for function register
def test_register():
    """Test successful registration of the b64 codec."""
    register()
    codecs.getdecoder(NAME)

register()

# Generated at 2022-06-23 17:48:20.461966
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    # pylint: disable=W0612
    assert decode(b'YQ==') == ('a', 3)
    assert decode(b'YWI=') == ('ab', 4)
    assert decode(b'YWJj') == ('abc', 4)
    assert decode(b'YWJjZA==') == ('abcd', 8)
    assert decode(b'YWJjZGU=') == ('abcde', 8)
    assert decode(b'YWJjZGVm') == ('abcdef', 8)
    assert decode(b'YWJjZGVmZw==') == ('abcdefg', 12)
    assert decode(b'YWJjZGVmZ2g=') == ('abcdefgh', 12)

# Generated at 2022-06-23 17:48:31.462251
# Unit test for function decode
def test_decode():
    assert 'aA==' == decode(b'a')[0]
    assert 'aA==' == decode(b'a', 'strict')[0]
    assert 'aA==' == decode(memoryview(b'a'))[0]
    assert 'aA==' == decode(bytes(b'a'))[0]
    assert 'aA==' == decode(bytearray(b'a'))[0]

    assert 'aA==' == decode(b'a')[0]
    assert 'aA==' == decode(b'a', 'strict')[0]
    assert 'aA==' == decode(memoryview(b'a'))[0]
    assert 'aA==' == decode(bytes(b'a'))[0]
    assert 'aA==' == decode

# Generated at 2022-06-23 17:48:37.436519
# Unit test for function encode
def test_encode():
    """Test the function :func:`encode`."""
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)

    # Leading and trailing whitespace is allowed
    assert encode('\nYQ==\n') == (b'a', 6)
    assert encode(' YQ== ') == (b'a', 7)
    assert encode('\tYQ==\t') == (b'a', 7)
    assert encode('\nYQ==\n') == (b'a', 6)
    assert encode('\tYQ==\n') == (b'a', 7)

# Generated at 2022-06-23 17:48:42.029709
# Unit test for function decode
def test_decode():
    """Test the decode function"""
    assert decode(b'Man')[0] == 'TWFu'
    assert decode(b'Ma')[0] == 'TWE='
    assert decode(b'M')[0] == 'TQ=='



# Generated at 2022-06-23 17:48:43.981802
# Unit test for function decode
def test_decode():
    assert(decode(b'abc') == ('YWJj', 3))


# Generated at 2022-06-23 17:48:45.320436
# Unit test for function register
def test_register():
    """Test register()"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:48:56.201635
# Unit test for function encode

# Generated at 2022-06-23 17:49:06.119041
# Unit test for function register
def test_register():
    # Force unregister
    codecs.unregister(NAME)
    try:
        codecs.getencoder(NAME)
    except LookupError:
        # Already unregistered
        pass
    else:
        # Should never get here
        assert False

    # Register
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        # Should never get here
        assert False
    else:
        # Success
        pass

    # Unregister
    codecs.unregister(NAME)
    try:
        codecs.getencoder(NAME)
    except LookupError:
        # Already unregistered
        pass
    else:
        # Should never get here
        assert False



# Generated at 2022-06-23 17:49:14.231876
# Unit test for function decode
def test_decode():
    """Unit test for function `decode`."""
    _in_bytes = b'\x00\xff\xaa\x55\x01\x02\x55\xa5\xab\x10\x20\x30\x40'
    _out_str = 'AA/vAEBpAFt/w=='
    _len = len(_in_bytes)
    _dec = codecs.decode(_in_bytes, NAME)[0]
    _dec_len = codecs.decode(_in_bytes, NAME)[1]

    assert _out_str == _dec
    assert _len == _dec_len



# Generated at 2022-06-23 17:49:21.555008
# Unit test for function decode
def test_decode():
    assert decode(b'\x00\x01\x02\x03\x04\x05\x06\x07') == (
        'AAECAwQFBgcL',
        8
    )
    assert decode(b'\x00\x01\x02\x03\x04\x05\x06"') == (
        'AAECAwQFBgcI',
        8
    )
    assert decode(b'\x00\x01\x02\x03\x04\x05\x06)') == (
        'AAECAwQFBgcJ',
        8
    )


# Generated at 2022-06-23 17:49:32.192261
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Test encode"""

# Generated at 2022-06-23 17:49:34.380172
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:49:42.106668
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVmZw==') == (b'abcdefg', 12)
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 12)
    assert encode('YWJjZGVmZ2hp') == (b'abcdefghi', 12)


#

# Generated at 2022-06-23 17:49:53.403929
# Unit test for function register
def test_register():
    """Test the functionality of module function register."""
    import sys
    try:
        del sys.modules['b64']
    except KeyError:
        pass
    try:
        import b64
    except ImportError:
        raise AssertionError(
            'B64 codec must be importable without registering it first.'
        )
    del sys.modules['b64']

    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    # Registering twice should not raise an exception
    register()
    return


if __name__ == '__main__':
    import sys
    import unittest
    sys.path.append('..')
    from fpe import Base64Coder


# Generated at 2022-06-23 17:49:57.266908
# Unit test for function decode
def test_decode():
    assert decode(
        b"aGVsbG8="
    ) == (
        'hello',
        4
    )
    assert decode(
        b"aGVsbG8="
    ) == (
        'hello',
        4
    )



# Generated at 2022-06-23 17:50:05.440345
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    # Make sure the registration happens
    register()

    # Make sure that an empty string is returned when no bytes are given
    out = decode(b'', '')
    assert out == ('', 0)

    # Make sure that basic base64 bytes are converted to their base64
    # characters
    data = b'U3d6'
    out = decode(data, '')
    assert out == ('U3d6', len(data))

    # 1-byte UTF-8 characters
    data = bytes([65])
    out = decode(data, '')
    assert out == ('QQ==', len(data))

    # 2-byte UTF-8 characters
    data = bytes([65, 65])
    out = decode(data, '')
    assert out == ('QUE=', len(data))



# Generated at 2022-06-23 17:50:07.747829
# Unit test for function decode
def test_decode():
    assert decode(b'abcd') == ('YWJjZA==', 4)


# Generated at 2022-06-23 17:50:17.366361
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    # Type checking
    try:
        encode(None)
    except TypeError as err:
        assert "('" in str(err)
        assert "not NoneType'>" in str(err)
        assert "not 'str'" in str(err)

    try:
        encode(1)
    except TypeError as err:
        assert "('" in str(err)
        assert "not NoneType'>" in str(err)
        assert "not 'str'" in str(err)

    try:
        encode([])
    except TypeError as err:
        assert "('" in str(err)
        assert "not NoneType'>" in str(err)
        assert "not 'str'" in str(err)

    # Valid text
    text = 'Hello World'
    out

# Generated at 2022-06-23 17:50:27.365649
# Unit test for function register
def test_register():
    """Unit test for function register"""
    from unittest.mock import patch

    with patch('codecs.register', return_value=None) as register_patch, \
            patch('codecs.getdecoder') as get_decoder_patch:
        register()
        assert register_patch.call_count == 1
        assert get_decoder_patch.call_count == 1

    with patch('codecs.register', return_value=None) as register_patch, \
            patch('codecs.getdecoder', side_effect=LookupError) as get_decoder_patch:
        register()
        assert register_patch.call_count == 1
        assert get_decoder_patch.call_count == 1


# Generated at 2022-06-23 17:50:38.376552
# Unit test for function decode

# Generated at 2022-06-23 17:50:40.305042
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:50:51.812701
# Unit test for function decode
def test_decode():
    """Test the 'decode' function."""
    assert decode(b'dGVzdA==')[0] == 'dGVzdA=='
    assert decode(b'dGVzdA==\n')[0] == 'dGVzdA=='
    assert decode(b'dGVzdA   ==\n')[0] == 'dGVzdA=='
    assert decode(b'dGVzdA==\n\n')[0] == 'dGVzdA=='
    assert decode(b'dGVzdA==\n\ndGVzdA==\n')[0] == 'dGVzdA==dGVzdA=='
    assert decode(b'\ndGVzdA==\n')[0] == 'dGVzdA=='

# Generated at 2022-06-23 17:50:59.214333
# Unit test for function encode
def test_encode():
    test = 'r/wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww'
    out = encode(test)

# Generated at 2022-06-23 17:51:09.015524
# Unit test for function encode
def test_encode():
    # Run encode with a string of base64 characters 'YWJz'.
    text = 'YWJz'
    result = encode(text)
    assert b'abc' == result[0]
    assert 3 == result[1]

    # Run encode with a string of base64 characters on multiple lines.
    text = 'eHl6Cg'
    result = encode(text)
    assert b'xyz\n' == result[0]
    assert 3 == result[1]

    # Run encode with a string of base64 characters that are indented.
    text = '\tyWJz\n'
    result = encode(text)
    assert b'abc' == result[0]
    assert 3 == result[1]

    # Run encode with a string of base64 characters that are indented
    # and on multiple lines.

# Generated at 2022-06-23 17:51:12.803358
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # Should not raise exception
    codecs.getencoder(NAME)  # Should not raise exception



# Generated at 2022-06-23 17:51:15.365987
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    assert NAME == codecs.lookup(NAME).name  # type: ignore


# Generated at 2022-06-23 17:51:19.032624
# Unit test for function decode
def test_decode():
    result, bytes_used = decode(b'c2VjcmV0')
    assert result == 'secret'
    assert bytes_used == 8


# Generated at 2022-06-23 17:51:24.522167
# Unit test for function decode
def test_decode():
    """Unit test for function :py:func:`decode`"""
    assert 'aGVsbG8=' == decode(b'hello')[0]
    assert "aGVsbG8=\nYm95" == decode(b"hello\nboy")[0]


# Generated at 2022-06-23 17:51:28.046823
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    x = 'Dette er en test'
    r = codecs.encode(x.encode(),'b64')
    assert decode(r)[0] == x


# Generated at 2022-06-23 17:51:36.175493
# Unit test for function encode

# Generated at 2022-06-23 17:51:38.705028
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGVmZ2g=') == (b'abcdefgh', 8)



# Generated at 2022-06-23 17:51:48.678382
# Unit test for function encode
def test_encode():
    assert encode('dGVzdGluZw==') == (b'testing', len('dGVzdGluZw=='))
    assert encode('dGVzdGluZw==\n') == (b'testing', len('dGVzdGluZw=='))

    assert encode('dmVyeSBsb25nIHRlc3Qgc3RyaW5n') == (
        b'very long test string',
        len('dmVyeSBsb25nIHRlc3Qgc3RyaW5n')
    )

    assert encode('\ndmVyeSBsb25nIHRlc3Qgc3RyaW5n') == (b'very long test string', 33)

    # Check that there can be whitespace anywhere in text.

# Generated at 2022-06-23 17:51:51.193554
# Unit test for function encode
def test_encode():
    assert encode("YW55IGNhcm5hbCBwbGVhc3VyZQ==") == b"any carnal pleasure"


# Generated at 2022-06-23 17:51:51.707051
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 17:52:00.490768
# Unit test for function decode
def test_decode():
    assert decode(b'1') == ('MQ==', 1)
    assert decode(b'12') == ('MTI=', 2)
    assert decode(b'123') == ('MTIz', 3)
    assert decode(b'1234') == ('MTIzNA==', 4)
    assert decode(b'12345') == ('MTIzNDU=', 5)
    assert decode(b'123456') == ('MTIzNDU2', 6)
    assert decode(b'1234567') == ('MTIzNDU2Nw==', 7)


# Generated at 2022-06-23 17:52:04.584766
# Unit test for function encode
def test_encode():
    """test_encode"""
    text = 'Mw==\n'
    expected_bytes = b'1'
    assert encode(text) == (expected_bytes, len(text))

    text = 'Mw==\n'
    expected_bytes = b'1'
    assert encode(text)[0] == expected_bytes


# Generated at 2022-06-23 17:52:14.912103
# Unit test for function register
def test_register():
    # pylint: disable=W0612,R0201
    def local_decode(
            data: _ByteString,
            errors: _STR = 'strict'
    ) -> Tuple[str, int]:
        return b'', 0

    def local_encode(
            text: _STR,
            errors: _STR = 'strict'
    ) -> Tuple[bytes, int]:
        return b'', 0

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'Could not find {NAME} decoder')

    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError(f'Could not find {NAME} encoder')

    # Try registering the same codec again

# Generated at 2022-06-23 17:52:22.812349
# Unit test for function encode

# Generated at 2022-06-23 17:52:34.620934
# Unit test for function register
def test_register():  # type: ignore
    """ Unit test for function register."""
    from pylint.checkers.utils import RemapError
    from astroid.builder import AstroidBuilder

    register()
    codecs.lookup(NAME)
    codecs.lookup_error(NAME)
    codecs.lookup_error('strict')
    codecs.encode(b'foo', NAME)
    codecs.encode(b'foo', NAME, 'strict')
    codecs.encode(b'foo', NAME, 'ignore')
    codecs.encode(b'foo', NAME, 'replace')
    codecs.encode(b'foo', NAME, 'xmlcharrefreplace')
    codecs.encode(b'foo', NAME, 'backslashreplace')

# Generated at 2022-06-23 17:52:36.845763
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    # The codecs module should have the name registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:52:42.556718
# Unit test for function encode
def test_encode():
    test_string = '''
        ABCDEFGHIJKLMNOPQRSTUVWXYZ
        abcdefghijklmnopqrstuvwxyz
        0123456789'''
    test_bytes = (
        b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5'
        b'ejAxMjM0NTY3ODk='
    )
    assert encode(test_string)[0] == test_bytes
    assert encode(test_string)[1] == len(test_string)
