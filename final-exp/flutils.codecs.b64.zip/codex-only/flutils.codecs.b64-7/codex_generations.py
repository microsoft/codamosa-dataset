

# Generated at 2022-06-23 17:42:42.111692
# Unit test for function decode
def test_decode():
    assert decode(b'aGVsbG8gd29ybGQ=') == ('hello world', 12)



# Generated at 2022-06-23 17:42:47.570941
# Unit test for function register
def test_register():
    import sys
    import unittest

    class RegistrationTests(unittest.TestCase):
        def test_codec_is_registered(self):
            register()
            self.assertIn(NAME, codecs.getdecoder(NAME))

        def test_codec_registration_is_idempotent(self):
            register()
            register()

    unittest.main(argv=sys.argv[:1], exit=False)

# Generated at 2022-06-23 17:42:58.768358
# Unit test for function encode

# Generated at 2022-06-23 17:43:02.123672
# Unit test for function decode
def test_decode():
    try:
        decoded = decode(
            data=b'\xde\xad\xbe\xef',
            errors='strict',
        )
    except Exception as e:
        raise e
    assert decoded[0] == '3q2+7w=='



# Generated at 2022-06-23 17:43:04.430159
# Unit test for function decode
def test_decode():
    # pylint: disable=R0201,W0621
    from . import codec_common   # noqa: F401
    codec_common.super_decode(NAME)


# Generated at 2022-06-23 17:43:10.525696
# Unit test for function encode
def test_encode():

    # Test simple string.
    text = 'Hello World'
    expected_out = b'SGVsbG8gV29ybGQ=\n'
    expected_length = 12
    actual_output = b'SGVsbG8gV29ybGQ='
    actual_length = len(actual_output)
    assert actual_output == base64.b64encode(text.encode())
    assert actual_length == expected_length
    assert actual_output == expected_out

    # Test text with white space.
    text_ws = """
    \t
    Hello\t
    World\t
    """
    expected_out_ws = b'SGVsbG8gV29ybGQ=\n'
    expected_length_ws = 12

# Generated at 2022-06-23 17:43:11.230336
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-23 17:43:12.823187
# Unit test for function register
def test_register():
    """Unit test for register"""
    codecs.lookup(NAME)

# Generated at 2022-06-23 17:43:24.347599
# Unit test for function decode
def test_decode():
    """Run unit tests for decode."""

    # Unit test for function decode.  See
    # testing/test_b64.py/test_decode()
    # for additional unit tests.
    assert decode(bytes([0x00])) == ('AA==', 1)
    assert decode(bytes([0x01])) == ('AQ==', 1)
    assert decode(bytes([0x01, 0x01])) == ('AQE=', 2)
    assert decode(bytes([0x01, 0x02])) == ('AQIA', 2)
    assert decode(bytes([0x01, 0x02, 0x03])) == ('AQID', 3)
    assert decode(bytes([4, 3, 2, 1])) == ('BAuD', 4)

# Generated at 2022-06-23 17:43:36.389593
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`."""
    register()
    try:
        try:
            codecs.getencoder(NAME)
        except LookupError as e:
            raise AssertionError(f'{NAME} encoder not registered: {e}')
        try:
            codecs.getdecoder(NAME)
        except LookupError as e:
            raise AssertionError(f'{NAME} encoder not registered: {e}')
    finally:
        del codecs.encode_codec_map[NAME]
        del codecs.decode_codec_map[NAME]



# Generated at 2022-06-23 17:43:46.519621
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 4)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YWJjZA==') == (b'abcd', 8)
    assert encode('YWJjZGU=') == (b'abcde', 8)
    assert encode('YWJjZGVm') == (b'abcdef', 8)
    assert encode('YWJjZGVm\nZ2g=\n') == (b'abcdefgh', 14)
    assert encode('YWJjZGVm\ng2g=\n') == (b'abcdefgh', 14)


# Generated at 2022-06-23 17:43:48.767713
# Unit test for function encode
def test_encode():
    assert encode('a')[0] == b'\x00'



# Generated at 2022-06-23 17:43:54.797038
# Unit test for function decode
def test_decode():
    """ Test the ``decode`` function and function ``encode`` as they are used
    as one function.  In these tests the returned ``int`` is ignored.
    """

    # pylint: disable=C0325
    # pylint: disable=C0326
    # pylint: disable=C0301
    # pylint: disable=W0612
    # pylint: disable=C0103
    assert decode(b'AAAA')[0] == 'QUFB'
    assert decode(b'AAAA\n')[0] == 'QUFB'
    assert decode(b'AAAA\n')[0] == 'QUFB'
    assert decode(b' AAAA')[0] == 'QUFB'
    assert decode(b'\nAAAA')[0] == 'QUFB'

# Generated at 2022-06-23 17:43:59.785391
# Unit test for function decode
def test_decode():
    assert decode(b'\xf0\x9f\x98\x81') == ('8J+YgA==', 3)
    assert decode(b'\xf0\x9f\x98\x81\xf0\x9f\x92\xa9') == ('8J+YsO2', 6)

# Generated at 2022-06-23 17:44:06.520887
# Unit test for function encode
def test_encode():
    """Test the encode function.

    If the encode function is working correctly, then the decoded
    output is the same as the input.  This test ensures that this is
    the case.
    """
    # Define a test string that contains a number of lines.
    original_text = r"""
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    Donec et neque quis velit euismod lobortis.
Integer pulvinar nibh sit amet lorem dapibus, vitae faucibus
    elit congue.
"""
    # Encode the test string.
    encoded_input, num_encoded_bytes = encode(original_text)

    # Decode the encoded bytes.
    decoded_output, num_decoded_bytes = decode(encoded_input)



# Generated at 2022-06-23 17:44:11.151610
# Unit test for function register
def test_register():  # pragma: no cover
    """Ensure the ``b64`` codec is registered with Python."""
    register()

    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:44:15.841889
# Unit test for function encode
def test_encode():
    """Encode test"""
    assert encode(text='YmFy') == (b'bar', 4)



# Generated at 2022-06-23 17:44:27.158533
# Unit test for function decode
def test_decode():
    """
    Test the decode() function
    """
    # pylint: disable=R0904
    # Test the decoding of a simple string
    assert decode(b'Blockchain') == ('QmxvY2tjaGFpbg==', 10)

    # Test the decoding of a string with special characters
    assert decode(b'Blockchain\n') == ('QmxvY2tjaGFpbg0K', 11)

    # Test the decoding of a string with multi byte characters
    assert decode(b'\xa1\xb1\xc1\xd1\xe1\xf1') == ('75+9qu+9vQ==', 6)

    # Test the decoding of a string with multi byte characters

# Generated at 2022-06-23 17:44:31.765465
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Could not register codec'


register()

# Generated at 2022-06-23 17:44:36.072226
# Unit test for function decode
def test_decode():
    decode('AQ')
    decode('AQI')
    decode('AQID')
    decode('AQIDBA')
    decode('AQIDBAU')
    decode('AQIDBAUG')
    decode('AQIDBAUGBwg')



# Generated at 2022-06-23 17:44:37.955081
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:44:43.723112
# Unit test for function encode

# Generated at 2022-06-23 17:44:48.430791
# Unit test for function decode
def test_decode():
    assert decode(b'hello world') == ('aGVsbG8gd29ybGQ=', 11)
    assert decode(b'aGVsbG8gd29ybGQ=') == ('hello world', 16)



# Generated at 2022-06-23 17:44:55.581155
# Unit test for function register
def test_register():
    """Test that the 'b64' codec is registered with Python."""
    # pylint: disable=C0103,W0108
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(f'The "{NAME}" codec is not registered with Python.')



# Generated at 2022-06-23 17:45:06.448608
# Unit test for function encode

# Generated at 2022-06-23 17:45:17.010742
# Unit test for function encode
def test_encode():
    # pylint: disable=protected-access
    # Test given a string is returned with the same string.
    codec = BASE64Codec()
    assert codec.encode('hello') == 'SSdtIGdyZXk=\n'
    assert codec.decode('SSdtIGdyZXk=\n') == b'h\xcf\xaall\xcf\xbe'
    assert codec.encode('\xe2\x98\x83') == '4oyJ'
    assert codec.decode('4oyJ') == b'\xe2\x98\x83'
    assert codec.encode('\0') == 'AA==\n'
    assert codec.decode('AA==\n') == b'\0'


test_encode()

# Generated at 2022-06-23 17:45:24.787327
# Unit test for function encode

# Generated at 2022-06-23 17:45:36.372826
# Unit test for function decode
def test_decode():
    assert decode(b'Y3lkYXRlcg==') == ('cydater', 8)
    assert decode(b'Y3lkYXRlcg==\n') == ('cydater', 8)
    assert decode(b'Y3lkYXRlcg==\r') == ('cydater', 8)
    assert decode(b'Y3lkYXRlcg==\r\n') == ('cydater', 8)
    assert decode(b'Y3lkYXRlcg==\n\n') == ('cydater', 8)
    assert decode(b'Y3lkYXRlcg==\n\n\n') == ('cydater', 8)
    assert decode(b'Y3lkYXRlcg==\n\n\n\n')

# Generated at 2022-06-23 17:45:40.948097
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.lookup(NAME) == _get_codec_info(NAME)  # type: ignore



# Generated at 2022-06-23 17:45:43.607307
# Unit test for function register
def test_register():
    """Test the :func:`register()` function."""
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None



# Generated at 2022-06-23 17:45:47.584856
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()

    # Register the codec again to test for a duplicate key error.
    with pytest.raises(KeyError) as err:
        codecs.register(_get_codec_info)  # type: ignore
    assert 'b64' == str(err.value)

# Generated at 2022-06-23 17:45:54.022092
# Unit test for function register
def test_register():
    # codecs already registered
    # pylint: disable=redefined-outer-name
    import codecs
    NAME = __name__.split('.')[-1]
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # verify that the b64 codec is registered
        codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'b64 codec not registered.  Is "register()" called?'
        )
    codecs.lookup(NAME)  # type: ignore

# Generated at 2022-06-23 17:46:02.432645
# Unit test for function decode
def test_decode():
    bytes_ = bytearray(b'abcd')
    print(decode(bytes_))
    assert decode(bytes_) == ('YWJjZA==', 4)
    bytes_ = bytearray(b'abcd')
    print(decode(bytes_))
    assert decode(bytes_) == ('YWJjZA==', 4)
    bytes_ = [97, 98, 99, 100]
    print(decode(bytes_))
    assert decode(bytes_) == ('YWJjZA==', 4)



# Generated at 2022-06-23 17:46:06.005944
# Unit test for function register
def test_register():
    """Test function register."""
    from sys import modules

    try:
        del modules[__name__]
    except KeyError:
        pass
    register()
    assert NAME in codecs.__all__, f'The codec name: {NAME!r} is not ' \
                                    f'registered.'

# Generated at 2022-06-23 17:46:08.070725
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:46:13.580338
# Unit test for function encode
def test_encode():
    test_string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'
    assert encode(test_string) ==\
        (b'TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdA==', 52)



# Generated at 2022-06-23 17:46:18.551700
# Unit test for function encode
def test_encode():
    """Ensure all whitespace is ignored."""
    assert encode('dGVzdA==', 'strict') == (b'test', 6)
    assert encode('dG\tV\nZ\rT\taA\t==\n', 'strict') == (b'test', 15)



# Generated at 2022-06-23 17:46:20.335632
# Unit test for function decode
def test_decode():
    assert decode(b'ABCDE') == ('QUJDREU=', 5)


# Generated at 2022-06-23 17:46:23.233419
# Unit test for function register
def test_register():
    """Unit test for function register."""
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Register the codec
register()

# Generated at 2022-06-23 17:46:26.292042
# Unit test for function decode
def test_decode():
    """Unit test of function decode"""
    t = '''
        MTIzNDU2Nzg5MAo=
    '''
    assert decode(t)[0] == '1234567890\n'



# Generated at 2022-06-23 17:46:32.550490
# Unit test for function decode
def test_decode():
    assert decode(b'TWFu') == ('Man', 4)
    assert decode(b'TWE=') == ('Ma', 4)
    assert decode(b'TQ==') == ('M', 4)



# Generated at 2022-06-23 17:46:35.141720
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


# Generated at 2022-06-23 17:46:42.680221
# Unit test for function decode
def test_decode():
    """Test ``codecs.decode`` with the ``b64`` decoder."""
    actual = ''.join(map(chr, range(256)))
    # The original string of ascii characters
    expected = ''.join(map(chr, range(256)))
    actual_bytes = codecs.encode(actual, 'b64')
    assert actual_bytes.decode('utf-8') == expected



# Generated at 2022-06-23 17:46:48.551080
# Unit test for function decode
def test_decode():
    # Python 3.7.3  Mac OS 64 bit
    # python3.7 -m unittest test_b64.TestDecode
    from b64 import decode
    from binascii import Error as BinasciiError

    class TestDecode(unittest.TestCase):
        """Use Unit Test to verify the 'decode' function."""
        def test_encode_basic(self):
            """Basic tests of the 'decode' function."""
            self.assertEqual(('\n', 1), decode(b'Cg=='))
            self.assertEqual(('\n', 1), decode(b'Cg==\n', 'ignore'))
            self.assertEqual(('\t', 1), decode(b'CQ=='))

# Generated at 2022-06-23 17:46:57.225589
# Unit test for function decode
def test_decode():
    import unittest

    class TestCodecDecode(unittest.TestCase):
        def test_empty(self):
            self.assertEqual(decode(bytearray()), ('', 0))

        def test_single_byte(self):
            self.assertEqual(decode(b'A'), ('QQ==', 1))

        def test_multi_bytes(self):
            self.assertEqual(decode(b'ABCDEFG'), ('QUJDREVGRw==', 7))

    unittest.main()


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-23 17:47:04.441045
# Unit test for function decode
def test_decode():
    """
    Unit tests for function decode
    """
    src = 'YWFhYQ=='
    expected = 'aaaa'
    actual = decode(src)
    assert expected == actual

    src = 'YWFhYQ'
    expected = 'aaaa'
    actual = decode(src)
    assert expected == actual

    src = 'YWFhYQ'
    expected = 'aaaa'
    actual = decode(src)
    assert expected == actual

    src = 'YQ==='
    expected = 'a'
    actual = decode(src)
    assert expected == actual

    src = 'YQ=='
    expected = 'a'
    actual = decode(src)
    assert expected == actual

    src = 'YQ='
    expected = 'a'
    actual = decode(src)
    assert expected == actual



# Generated at 2022-06-23 17:47:07.579117
# Unit test for function register
def test_register():
    """Test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:47:10.838903
# Unit test for function encode
def test_encode():
    """
    Unit test for function ``encode``
    """
    assert encode('YWJj\ndGVzdA==') == (b'abctest', 10)

# Generated at 2022-06-23 17:47:21.572784
# Unit test for function encode
def test_encode():
    assert b'\xbf' == encode('//8=').__next__() # last 3 bits of 'y'
    assert b'\x9c' == encode('_w==').__next__() # last 2 bits of 'y'
    assert b'\x9d' == encode('-w==').__next__() # last 2 bits of 'z'
    assert b'test' == encode('dGVzdA==').__next__()
    assert b'\xef\xbb\xbf' == encode('//8=\nF').__next__() # BOM
    assert b'YQ==' == encode('\nY\nQ\t==').__next__() # BOM

# Generated at 2022-06-23 17:47:33.849418
# Unit test for function register
def test_register():
    """Unit test for register"""
    # Create a list of codec names.
    # Remove the 'b64' codec name if it exists.
    codec_names = codecs.__dict__.get('_cache', [])[:]
    try:
        codec_names.remove('b64')
    except ValueError:
        pass

    # Register the 'b64' codec.
    register()

    # Get the new codec names.
    new_names = codecs.__dict__.get('_cache', [])[:]

    # Check to see if the 'b64' codec was added.
    assert 'b64' in new_names

    # Check to see if any other codecs were added.
    # If there are other codecs names than the original codecs,
    # then an error has occurred.

# Generated at 2022-06-23 17:47:36.844213
# Unit test for function encode
def test_encode():
    decode_err = 1
    decode_err_msg = (
        'b64',
        '#@*!#@$%@#$%@',
        0,
        9,
        f'"{decode_err_msg}" is not a proper bas64 character string'
    )
    assert encode(decode_err), decode_err_msg

# Generated at 2022-06-23 17:47:38.379033
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:47:50.125976
# Unit test for function decode
def test_decode():
    assert decode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=')[0] == 'abcdefghijklmnopqrstuvwxyz'
    assert decode(b'c2VtaWwgZ2VzIGxhIGdhemVz')[0] == 'semil ges la ghezes'
    assert decode(b'RnJhbmsgQ2hvd2Z1bCB3YXMgaGVyZS4=')[0] == 'Frank Chowderful was here.'
    assert decode(b'UXVpdCBjaA==')[0] == 'Quit ch'
    assert decode(b'Q2hvY29sYXRlCg==')[0] == 'Chocolate\n'


# Generated at 2022-06-23 17:47:58.468588
# Unit test for function encode

# Generated at 2022-06-23 17:48:08.572465
# Unit test for function register
def test_register():
    """Test the ``register`` function in :mod:`text_data_encoder.b64`."""
    from text_data_encoder.b64 import decode
    from text_data_encoder.b64 import encode
    from text_data_encoder.b64 import register
    register()  # Register the b64 codec.
    decoder_func = codecs.getdecoder(NAME)
    encoder_func = codecs.getencoder(NAME)
    assert decoder_func == decode
    assert encoder_func == encode
    assert codecs.CodecInfo.__name__ != codecs.getencoder(NAME).__class__.__name__

# Generated at 2022-06-23 17:48:13.379992
# Unit test for function encode
def test_encode():
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 6)


# Generated at 2022-06-23 17:48:21.705842
# Unit test for function decode
def test_decode():
    # pylint: disable=line-too-long
    """Tests the function encode against a known good output to make sure that
    the function does what it is supposed to do."""
    known_good_in = (
        '''
        A string that contains many base64 characters.
        '''
    )
    known_good_out = (
        'QSBzdHJpbmcgdGhhdCBjb250YWlucyBtYW55IGJhc2U2NCBjaGFyYWN0ZXJzLg=='
    )
    known_good_mod = codecs.encode(known_good_in, "b64")
    assert known_good_mod == known_good_out
    assert codecs.decode(known_good_mod, "b64") == known_good_

# Generated at 2022-06-23 17:48:27.537365
# Unit test for function decode
def test_decode():
    """Test the function `decode` for proper operation.

    This test runs a series of test cases through the given
    function. A description of the expected operation of this
    function is given above.

    Raises:
        AssertionError: If any of the test cases fail
    """
    decode_test_cases = (
        (
            b'Aw==',
            'AA=='
        ),
        (
            b'\xff',
            '//8='
        ),
        (
            b'\xff\xff',
            '////'
        ),
        (
            b'\xff\xff\xff',
            '/////w=='
        ),
    )
    for data, expect in decode_test_cases:
        assert decode(data)[0] == expect

# Generated at 2022-06-23 17:48:33.914408
# Unit test for function decode
def test_decode():
    """Test the 'decode' function."""
    from .constants import DATA_BYTES
    for byte_data in [DATA_BYTES, bytearray(DATA_BYTES)]:
        for num_bytes in range(1, len(DATA_BYTES)):
            for offset in range(len(DATA_BYTES) + 1):
                try:
                    offset_data = byte_data[offset:]
                    _, decoded_length = decode(offset_data[:num_bytes])
                    assert num_bytes == decoded_length
                except UnicodeEncodeError:
                    pass



# Generated at 2022-06-23 17:48:35.973608
# Unit test for function register
def test_register():
    """Test the register function."""
    register()

    # Test module global is set as expected.
    assert _codec_info == codecs.lookup(NAME)

    # Test calling function again will do nothing.
    register()


# Generated at 2022-06-23 17:48:47.996126
# Unit test for function register
def test_register():  # noqa: D103
    """Test function register()."""

    # pylint: disable=W0612
    # pylint: disable=W0613
    # noinspection PyUnusedLocal
    def getcodec(name):
        pass

    codecs_getdecoder = codecs.getdecoder
    codecs.getdecoder = getcodec
    import sys as _sys
    sys_modules = _sys.modules
    old_codec_reg = sys_modules['codecs']._registry  # type: ignore

# Generated at 2022-06-23 17:48:57.912832
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import unittest
    import sys
    try:
        codecs.getdecoder(NAME)
        sys_has_b64_codec = True
    except LookupError:
        sys_has_b64_codec = False

    class TestRegister(unittest.TestCase):
        """Unit test for function register."""
        def test_codec_name(self):
            """Unit test for function register.  Test ``sys.codecs`` has
            ``b64`` codec name.
            """
            self.assertNotIn(NAME, sys.modules[__name__].__dict__)
            register()
            self.assertIn(NAME, sys.modules[__name__].__dict__)

# Generated at 2022-06-23 17:49:05.151915
# Unit test for function encode
def test_encode():
    # Assert that the expected text bytes are returned
    assert encode('YWJj') == (b'abc', 4)

    # Assert that the optional whitespace and indentation is removed
    assert encode("YWJj\n      \n") == (b'abc', 4)

    # Assert that text that is not proper base64 raises an error
    try:
        encode('Y W J j')
        raise RuntimeError('Should have thrown an exception')
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-23 17:49:15.149722
# Unit test for function decode
def test_decode():
    input_str = 'ZmlzaDo6a2x2eGRxbGtvbWZjbG5ibXR2Z2Vkb21iYmZuYmRzY3RhZ3V3'
    expected_no_errors = 'fish::kl2xdqlkomfcnbnmtuvgedombbfnbdsctaguu'
    assert decode(input_str)[0] == expected_no_errors
    assert decode(input_str, 'ignore')[0] == expected_no_errors
    assert decode(input_str, 'replace')[0] == expected_no_errors
    assert decode(input_str, 'backslashreplace')[0] == expected_no_errors
    assert decode(input_str, 'xmlcharrefreplace')[0] == expected_no_errors
    no_errors_expected_

# Generated at 2022-06-23 17:49:23.706769
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    # Test one character
    assert decode(b'a') == ('YQ==', 1)
    assert decode(b'b') == ('Yg==', 1)

    # Test a pair of bytes
    assert decode(b'0 ') == ('MCA=', 2)
    assert decode(b'a0') == ('YTQ=', 2)

    # Test random character pairs
    assert decode(b'\n,') == ('Ciw=', 2)
    assert decode(b'..') == ('Li4=', 2)
    assert decode(b'\t\x16') == ('CgE2', 2)
    assert decode(b',\x08') == ('LCA4', 2)

# Generated at 2022-06-23 17:49:28.701344
# Unit test for function decode
def test_decode():
    from binascii import a2b_base64, b2a_base64
    data = b'Hello, world!'

    x = decode(a2b_base64(b2a_base64(data)))
    print(x)
    assert x == ('SGVsbG8sIHdvcmxkIQ==', 17)



# Generated at 2022-06-23 17:49:36.039381
# Unit test for function register
def test_register():
    """Verify that register() function works as expected."""
    # Unit test for function register
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            'The b64 codec is registered before the test.'
        )
    # Verify that the codec is now registered.
    try:
        register()
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'The b64 codec is not registered after the test.'
        )

# Generated at 2022-06-23 17:49:39.546628
# Unit test for function encode
def test_encode():
    # Given a string with the standard base64 decoding.
    data = 'YWJjZA=='

    # When the given string is encoded.
    out = b64_codec.encode(data)

    # Then the output is a correctly encoded bytes object.
    assert out == (b'abcd', 4)



# Generated at 2022-06-23 17:49:50.303567
# Unit test for function register
def test_register():
    """Verify that the register function does register a codec."""

    # Check for the codec we are about to register
    codecs.lookup(NAME)
    # The codecs module has been patched by another test, but not removed.
    # Patch the codecs module so that this function succeeds.
    codecs.lookup = _get_codec_info
    try:
        # The original version of codecs.lookup should raise a KeyError
        # because it can't find the 'b64' codec.
        codecs.lookup(NAME)
        assert False
    except LookupError:
        pass
    register()
    result = codecs.lookup(NAME)
    assert result.name == NAME
    assert result.encode == encode
    assert result.decode == decode

# Generated at 2022-06-23 17:49:54.051734
# Unit test for function decode
def test_decode():
    # Test decoding from bytes
    expected = "SGVsbG8="
    actual = decode(b"Hello")[0]
    assert actual == expected


# Generated at 2022-06-23 17:50:00.760318
# Unit test for function decode
def test_decode():
    import unittest

    class Test(unittest.TestCase):
        def test_decode(self):
            self.assertEqual(
                decode(b'aGVsbG8='),
                ('hello', 8)
            )
            self.assertEqual(
                decode(b'Q/KdXy6U=',),
                ('/]b$\n', 8)
            )

        def test_decode_error(self):
            with self.assertRaises(UnicodeEncodeError):
                decode(b'Not Base64')

    unittest.main()


# Generated at 2022-06-23 17:50:12.552599
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function."""
    # Good test case with single line:
    input_bytes = b'aGVsbG8gd29ybGQ='
    expected = 'hello world'
    assert expected == decode(input_bytes)[0]

    # Good test case with multiple lines:
    input_bytes = b'''
    a
    GVs
    bG8
     gw
    9yb
    GQ=
    '''.strip().replace(b'\n', b'')
    expected = 'hello world'
    assert expected == decode(input_bytes)[0]

    # Bad test case with padding
    input_bytes = b'aGVsbG8gd29ybGQ'
    expected = 'hello world'

# Generated at 2022-06-23 17:50:17.546256
# Unit test for function decode
def test_decode():
    """Function to test function decode.

    Argument:
        N/A

    Returns:
        str: Test result.

    """
    given = b'I am a string'
    result = decode(given)
    expected = (
        'SSBhbSBhIHN0cmluZw==',
        len(given)
    )
    assert result == expected
    return 'test_decode passed'



# Generated at 2022-06-23 17:50:28.338929
# Unit test for function encode
def test_encode():
    """Test function encode."""

# Generated at 2022-06-23 17:50:34.876960
# Unit test for function register
def test_register():
    """Validate that the ``b64`` codec can be registered with Python."""
    register()

    # Validate that the codec was registered successfully by attempting
    # to retrieve the codec and using it to decode bytes.
    decoder = codecs.getdecoder(NAME)   # type: ignore
    assert decoder is not None
    assert decoder(b'foo') == ('Zm9v', 3)



# Generated at 2022-06-23 17:50:36.776962
# Unit test for function register
def test_register():
    """Unit test for function register()."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:50:48.489559
# Unit test for function decode
def test_decode():
    """Unit test for the decode function in this module."""
    assert decode(b'0KbQtdC90LjQtNCw0YbQuNC4') == ('你好，世界', 20)
    assert decode(b'0KbQtdC90LjQtNCw0YbQuNC4=') == ('你好，世界', 20)
    assert decode(b'0KbQtdC90LjQtNCw0YbQuNC4==') == ('你好，世界', 20)
    assert decode(b'0Y_QtdC90LjQtNCw0YbQuNC4') == ('他好，世界', 20)

# Generated at 2022-06-23 17:50:49.973852
# Unit test for function decode
def test_decode():
    # A unit test for function 'decode'
    assert decode(b"aaaaa") == ('YWFhYWE=', 5) and decode(b"aaaa") == ('YWFh', 4) and decode(b"aa\na") == ('YWFhYQ==', 4)
test_decode()


# Generated at 2022-06-23 17:50:58.206802
# Unit test for function encode
def test_encode():
    """Unit test for :func:`~b64.encode`."""
    # pylint: disable=E1101
    assert encode('abcdefgh') == (b'abcdefgh', 8)
    assert encode('ab+cd/fg=') == (b'\xab\xcd\xef\x10', 8)
    assert encode('ab/cd==') == (b'\xab\xcd\x00', 6)
    assert encode('ab/cd==  ') == (b'\xab\xcd\x00', 6)

    # Test the ' ' stripping
    assert encode('ab\nc d\r\n  \t=\n=') == (b'\xab\xcd\x00', 6)

    # Test for UnicodeEncodeErrors raised when given bad characters

# Generated at 2022-06-23 17:51:00.823029
# Unit test for function register
def test_register():
    """Test function register."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:51:11.668926
# Unit test for function encode

# Generated at 2022-06-23 17:51:14.728250
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 14)
    assert encode('dGhlIHdvcmxk') == (b'the world', 12)

# Generated at 2022-06-23 17:51:21.923818
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('', 'strict') == (b'', 0)
    assert encode('aGVsbG8=', 'strict') == (b'hello', 6)
    assert encode('YWJj\nZGVm') == (b'abcd', 8)

    with pytest.raises(
            UnicodeEncodeError,
            match='b64: "aGVsbG8" is not a proper bas64 character string: '
            'Invalid character in Base64'
    ) as excinfo:
        encode("aGVsbG8")
        assert excinfo.offset == 5

# Generated at 2022-06-23 17:51:23.475166
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-23 17:51:28.620069
# Unit test for function encode
def test_encode():
    """Test the encode function.
    """
    # Test the encode function.
    assert encode('YQ==') == (b'a', 3)
    assert encode('YWI=') == (b'ab', 4)
    assert encode('YWJj') == (b'abc', 4)
    assert encode('YW Jj') == (b'abc', 6)



# Generated at 2022-06-23 17:51:36.559835
# Unit test for function decode
def test_decode():
    """Test the function `decode()`."""
    print('\n' * 3)
    print('=' * 79)
    print(f'Testing {__file__}')
    print('Decode test')

    # pylint: disable=W0621
    # noinspection PyShadowingNames
    def expected_decode(
            encoded_str: _STR,
            data: _ByteString
    ) -> None:
        """Check that the given string decodes to the given bytes.

        Args:
            encoded_str (str or :obj:`UserString`): The string to be
                decoded.
            data (bytes or bytearray or memoryview): The expected bytes.
        """
        decoded_str, decoded_size = decode(data)
        assert decoded_size == len(data)
       

# Generated at 2022-06-23 17:51:41.724724
# Unit test for function decode
def test_decode():
    """Test the function decode()"""
    assert decode(b'b64:ZW1pZGFz')[0] == 'emidas'
    assert decode(b'b64:Z3JlZW5nbGFuZHM=')[0] == 'greenlands'
    assert decode(b'b64:ZG9vZGVz')[0] == 'doodes'
    assert decode(b'b64:eG9yYW1pYw==')[0] == 'xorama'
    assert decode(b'b64:c3RhaG4=')[0] == 'stahn'
    assert decode(b'b64:c2FnYXJl')[0] == 'sagare'

# Generated at 2022-06-23 17:51:44.305309
# Unit test for function encode
def test_encode():
    assert encode('QQ==', errors='strict') == (b'A', 4)
    assert encode('QUFB', errors='strict') == (b'AAA', 4)


# Generated at 2022-06-23 17:51:47.042617
# Unit test for function encode
def test_encode():
    txt = "aGVsbG8gdGhlcmU="
    b = encode(txt)
    assert b[0] == b'hello there'


# Generated at 2022-06-23 17:51:54.131609
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode
    """
    # Decode example input from the doc string.
    data = b'\x00\x00\x00'
    expected = 'AAAA'
    expected_length = len(data)
    act_result = decode(data=data)
    act_result_str, act_result_length = act_result
    assert expected == act_result_str
    assert expected_length == act_result_length

    # Decode example input from the doc string.
    data = b'\x7e\x7e\x7e'
    expected = '~~~~'
    expected_length = len(data)
    act_result = decode(data=data)
    act_result_str, act_result_length = act_result
    assert expected == act_result_str
    assert expected

# Generated at 2022-06-23 17:51:59.970156
# Unit test for function register
def test_register():
    """Test the function register"""
    # pylint: disable=R0201
    # pylint: disable=W0212
    for _ in ():
        register()
        codecs.register(_get_codec_info)
    codecs.register(codecs.CodecInfo('spam'))  # type: ignore


# Generated at 2022-06-23 17:52:03.887485
# Unit test for function decode
def test_decode():
    assert decode(bytes([0x01, 0x02, 0x03, 0x04])) == ('AQIDBA==', 4)
    assert decode(bytes([0x00, 0x01, 0x02, 0x03, 0x04])) == ('AAECAw==', 5)



# Generated at 2022-06-23 17:52:14.347946
# Unit test for function encode
def test_encode():
    """Test function encode of module b64"""

# Generated at 2022-06-23 17:52:21.520231
# Unit test for function encode
def test_encode():
    assert encode(
        '''\
        c2FtcGxl
        a2V5
        AAAA
        a2V5
        IGZv
        ciBleGFt
        cGxl
        '''
    ) == (b'examplekey\x00\x00\x00examplefor\n', 135)
    assert encode(
        '''\
        c2FtcGxl
        a2V5
        AAAA
        a2V5
        IGZv
        ciBleGFt
        cGxl
        ''',
        errors='replace'
    ) == (b'examplekey\x00\x00\x00examplefor\n', 135)   # type: ignore

# Generated at 2022-06-23 17:52:33.562795
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        codecs.getdecoder(NAME)
        success = True
    except LookupError:
        success = False
    assert success



# Generated at 2022-06-23 17:52:37.149174
# Unit test for function decode
def test_decode():
    assert decode(b'U3RyaW5ncyBhcmUgY29uc2lzdGVudGx5IGxvbmc=') == \
        ('Strings are consistently long', 50)



# Generated at 2022-06-23 17:52:46.591637
# Unit test for function decode
def test_decode():
    """
    """
    codecs.register(_get_codec_info)
    assert '>' == decode(b'>')[0]
    assert '>>>==' == decode(b'>>>=')[0]
    assert '>>>>===?' == decode(b'>>>>=?=')[0]
    assert '>>>>>====+' == decode(b'>>>>>==+')[0]
    assert '>>>>>>=====, ' == decode(b'>>>>>>=,=')[0]
    assert '>>>>>>>======0' == decode(b'>>>>>>>=0=')[0]
    assert '>>>>>>>>=======4' == decode(b'>>>>>>>>4=')[0]
    assert '>>>>>>>>>========8' == decode(b'>>>>>>>>8=')[0]