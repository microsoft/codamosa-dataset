

# Generated at 2022-06-23 17:42:45.247556
# Unit test for function encode
def test_encode():
    """Test function encode."""
    # Test enocde with good input.
    assert ''.encode('b64') == b''
    assert 'a'.encode('b64') == b'YQ=='
    assert 'aa'.encode('b64') == b'YWE='
    assert 'aaa'.encode('b64') == b'YWFh'
    assert 'aaaa'.encode('b64') == b'YWFhYQ=='

    assert encode('a') == (b'Lg==', 1)
    assert encode('aa') == (b'YWE=', 2)

    # Test encode with bad input.

# Generated at 2022-06-23 17:42:57.055040
# Unit test for function decode
def test_decode():
    """Unit test of decode function."""

# Generated at 2022-06-23 17:43:03.195687
# Unit test for function decode
def test_decode():
    """Test the ``decode`` function.
    """
    # Test the 'encode' function.
    test_data_str = 'abc'
    test_data_bytes = test_data_str.encode('utf-8')
    test_data_encoded = base64.b64encode(test_data_bytes).decode('utf-8')
    assert test_data_encoded == 'YWJj'
    assert decode(test_data_bytes) == decode(test_data_str) == \
        (test_data_encoded, 3)



# Generated at 2022-06-23 17:43:05.889854
# Unit test for function register
def test_register():
    """Test to make sure the ``b64`` codec is registered with Python."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:43:17.360216
# Unit test for function decode
def test_decode():
    """Run unit tests for the decode function."""

# Generated at 2022-06-23 17:43:23.615499
# Unit test for function decode
def test_decode():
    for b in [
            b'',
            b'\x00',
            b'\xff',
            b'\x00\x00',
            b'\xdb\u4a4b\ufffd\xff'
    ]:
        s = decode(b)[0]
        assert decode(s.encode('utf8'))[0] == s


# Generated at 2022-06-23 17:43:28.972407
# Unit test for function decode
def test_decode():
    msg = (
        'YWxpY2UuIFNvLCBpZiB5b3UgaGF2ZSBhbiBhY2Nlc3MtY29kZSwgeW91IGNhbiBp'
        'Z25vcmUgdGhpcyBtZXNzYWdlLg=='
    )
    data = msg.encode('utf-8')
    assert decode(data)[0] == msg


# Generated at 2022-06-23 17:43:42.505165
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function of the ``b64`` codec."""
    assert encode("") == (b"", 0)
    assert encode("AA==") == (b"\x00", 4)
    assert encode("AAA=") == (b"\x00\x00", 4)
    assert encode("AAAA") == (b"\x00\x00\x00", 4)
    assert encode("AAAB") == (b"\x00\x00\x01", 4)
    assert encode("AQ==") == (b"\x10", 4)
    assert encode("aQ==") == (b"\x90", 4)
    assert encode("Zg==") == (b"\xf4", 4)
    assert encode("/g==") == (b"\xf8", 4)

# Generated at 2022-06-23 17:43:47.309882
# Unit test for function register
def test_register():  # noqa pylint: disable=W0613
    """Test function register()"""
    register()
    try:
        # To test register we simply try to get the codec for the
        # b64 codec.  If this does not raise an exception then the
        # codec is registered and the test passed.
        codecs.getdecoder(NAME)
    except LookupError:
        raise

# Generated at 2022-06-23 17:43:52.316010
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise LookupError(f'{NAME} is already registered.')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise LookupError(f'{NAME} could not be registered.')
    else:
        pass



# Generated at 2022-06-23 17:44:01.377214
# Unit test for function encode
def test_encode():
    sample_input = '''dGVzdA=='''
    expected = b'test'
    result = decode(sample_input, 'strict')
    assert(result == expected)
    sample_input = '''
        dGVzdA=
        ='''
    expected = b'test'
    result = decode(sample_input, 'strict')
    assert(result == expected)
    sample_input = '''dGVzdA
        =
        ='''
    expected = b'test'
    result = decode(sample_input, 'strict')
    assert(result == expected)


# Generated at 2022-06-23 17:44:14.476733
# Unit test for function encode

# Generated at 2022-06-23 17:44:20.568952
# Unit test for function decode
def test_decode():
    ## Test 1
    test_data = b'12345'
    expected = 'MTIzNDU='
    result = decode(test_data)
    assert result == (expected, len(test_data))

    ## Test 2
    test_data = b'ABCDEFG'
    expected = 'QUJDREVGRw=='
    result = decode(test_data)
    assert result == (expected, len(test_data))

    ## Test 3
    test_data = b''
    expected = ''
    result = decode(test_data)
    assert result == (expected, len(test_data))



# Generated at 2022-06-23 17:44:30.762625
# Unit test for function encode
def test_encode():
    assert encode("YQ==") == (b"a",4)
    assert encode("YWI=") == (b"ab",4)
    assert encode("YWJj") == (b"abc",4)
    assert encode("eWFjYw==") == (b'yac',8)
    assert encode("yWFjYw==") == (b'ya\xc3\xa7',8)
    assert encode("wqFjYw==") == (b'ya\xc3\xa7',8)
    assert encode("cWFjYw==") == (b'ya\xc3\xa7',8)
    assert encode("") == (b"",0)
    assert encode("YWI") == (b"ab",4)

# Generated at 2022-06-23 17:44:35.242533
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    data = '''dGhpcyBpcyBhIHRlc3Q=

ICAgICA=

ICAgICAgICAg'''
    assert encode(data) == (b'this is a test', len(data))

# Generated at 2022-06-23 17:44:44.190872
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    expected = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,'
    expected += ' sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'


# Generated at 2022-06-23 17:44:51.168978
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # Use a bare except clause because a LookupError exception is not
    # generated within this function.  The exception is generated in
    # Python's built-in module 'codecs.py' during the call to
    # codecs.register.
    try:
        codecs.register(_get_codec_info)
    except:
        pass
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:44:55.852914
# Unit test for function decode
def test_decode():
    input_bytes = b'\x00\x00\x00\x00'
    actual_result, consumed_bytes = decode(input_bytes)
    expected_result = 'AAAA'
    assert actual_result == expected_result, \
        f'{actual_result!r} != {expected_result!r}'



# Generated at 2022-06-23 17:45:02.272446
# Unit test for function register
def test_register():
    """Unit test to register the ``b64`` codec with Python and verify
    that the codec is registered."""
    try:
        codecs.getdecoder(NAME)
        is_registered = True
    except LookupError:
        is_registered = False
    register()
    assert is_registered == False
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:45:10.626630
# Unit test for function encode
def test_encode():
    assert decode(b'QQ==') == ('A', 3)
    assert decode(b'QQ') == ('A', 2)
    assert decode(b'Q') == ('A', 1)
    assert decode(b'QQ=') == ('A', 2)
    assert decode(b'QQ==') == ('A', 3)
    assert decode(b'A') == ('A', 1)
    assert decode(b'AAA') == ('A', 3)
    assert decode(b'QQ==') == ('A', 3)
    assert decode(b'QQ==') == ('A', 3)


# Generated at 2022-06-23 17:45:11.708355
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 17:45:21.046531
# Unit test for function encode
def test_encode():
    assert encode('c3VyZS4=') == (b'\x83\x85\x93\x93', 8)
    assert encode('c3VyZS4') == (b'\x83\x85\x93\x93', 7)
    assert encode('c3VyZS4', errors='ignore') == (b'\x83\x85\x93\x93', 7)
    assert encode('c3VyZS4=\n') == (b'\x83\x85\x93\x93', 8)
    assert encode('c3VyZS4\n') == (b'\x83\x85\x93\x93', 7)

# Generated at 2022-06-23 17:45:29.883532
# Unit test for function register
def test_register():
    import sys
    import os.path

    name = __file__
    basedir = os.path.dirname(os.path.abspath(name))
    codecs_dir = os.path.dirname(basedir)
    sys.path.insert(0, codecs_dir)
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    # Unit test for function register
    test_register()

# Generated at 2022-06-23 17:45:39.730922
# Unit test for function decode
def test_decode():
    """Test function decode"""
    # Test bytes input
    text_input = b'aGVsbG8gd29ybGQ='
    result_bytes, length_bytes = decode(text_input)
    assert result_bytes == 'hello world'
    assert length_bytes == 14

    # Test memory view input
    text_input = memoryview(b'aGVsbG8gd29ybGQ=')
    result_bytes, length_bytes = decode(text_input)
    assert result_bytes == 'hello world'
    assert length_bytes == 14

    # Test bytearray input
    text_input = bytearray(b'aGVsbG8gd29ybGQ=')
    result_bytes, length_bytes = decode(text_input)
    assert result_bytes == 'hello world'


# Generated at 2022-06-23 17:45:48.292440
# Unit test for function encode
def test_encode():
    str_raw = '''
        MTIzNDU2Nzg5QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9w
        cXJzdHV2d3h5ejAxMjM0NTY3ODkrLw==
    '''
    bytes_expected = b'123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    bytes_actual, _ = encode(str_raw)
    assert bytes_actual == bytes_expected



# Generated at 2022-06-23 17:45:50.712516
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    input_data = bytes([77, 97, 110])
    out_data, _ = decode(input_data)
    assert out_data == 'TWFu'



# Generated at 2022-06-23 17:45:59.412985
# Unit test for function decode
def test_decode():
    """Test the function :func:`b64.decode` with expected values."""
    assert decode(b'this should be b64 encoded') == (
        'dGhpcw==',
        23
    )
    assert decode(b"this should be b64 encoded") == (
        'dGhpcw==',
        23
    )
    assert decode(b"this should be b64 encoded\n") == (
        'dGhpcw==',
        23
    )
    assert decode(b"\nthis should be b64 encoded") == (
        'dGhpcw==',
        23
    )
    assert decode(b"\n\nthis should be b64 encoded") == (
        'dGhpcw==',
        23
    )

# Generated at 2022-06-23 17:46:01.306058
# Unit test for function encode
def test_encode():
    """Test encode using the doctest examples"""
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-23 17:46:05.057460
# Unit test for function register
def test_register():
    """Unit test for function register"""
    codecs.register(lambda name: codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=lambda x, y: (b'', 0),  # type: ignore[arg-type]
        decode=lambda x, y: ('', 0),  # type: ignore[arg-type]
    ))

    # Registering again should not do anything.
    register()

# Generated at 2022-06-23 17:46:15.029554
# Unit test for function encode
def test_encode():
    """Basic unit-test for the ``encode`` function."""
    # Valid inputs
    assert encode('') == (b'', 0)
    assert encode('Zg==') == (b'f', 4)
    assert encode('Zm8=') == (b'fo', 4)
    assert encode('Zm9v') == (b'foo', 4)
    assert encode('Zm9vYg==') == (b'foob', 8)
    assert encode('Zm9vYmE=') == (b'fooba', 8)
    assert encode('Zm9vYmFy') == (b'foobar', 8)

    # Invalid inputs

# Generated at 2022-06-23 17:46:25.644522
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""

# Generated at 2022-06-23 17:46:30.500568
# Unit test for function register
def test_register():
    import codecs

    # Remove any existing registrations for the base64 codec.
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        del codecs.decode_error_registry[NAME]
        del codecs.encode_error_registry[NAME]
        del codecs.register_error[NAME]

    register()
    assert codecs.lookup(NAME)
    del codecs.decode_error_registry[NAME]
    del codecs.encode_error_registry[NAME]
    del codecs.register_error[NAME]

# Generated at 2022-06-23 17:46:37.715284
# Unit test for function decode
def test_decode():
    text = '''
            MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEx
            MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEx
            MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEx
            MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEx
            MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEx
        '''

# Generated at 2022-06-23 17:46:42.035854
# Unit test for function register
def test_register():
    """Test the function ``register``."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)



# Generated at 2022-06-23 17:46:44.556436
# Unit test for function decode
def test_decode():
    assert decode(b'\x03\x02\xff') == ('AO7/', 3)
    assert decode(b'\x07\x02\xff') == ('AOj/', 3)



# Generated at 2022-06-23 17:46:56.286251
# Unit test for function encode
def test_encode():
    """Test the function 'encode'."""
    # Test that the function properly encodes a 'str' input into bytes.
    text = """aGVsbG8gd29ybGQh"""
    text_bytes, consumed = encode(text)
    assert text_bytes.decode('utf-8') == 'hello world!'
    assert consumed == len(text)

    # Test that the function properly encodes a UserString input into
    # bytes.
    text = UserString('aGVsbG8gd29ybGQh')
    text_bytes, consumed = encode(text)
    assert text_bytes.decode('utf-8') == 'hello world!'
    assert consumed == len(text)

    # Test that the function handles extra whitespace in the input
    # correctly.

# Generated at 2022-06-23 17:46:59.512745
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=') == b'hello world'
    assert encode('aGVsbG9Ad29ybGQ=') == b'hello@world'


# Generated at 2022-06-23 17:47:10.348106
# Unit test for function encode
def test_encode():
    """Test the 'encode' function"""

# Generated at 2022-06-23 17:47:17.219809
# Unit test for function decode
def test_decode():
    assert (decode(b'This is a test string,')) == ('VGhpcyBpcyBhIHRlc3Qgc3RyaW5nLA==', 32)
    assert (decode(b'This is a test string')) == ('VGhpcyBpcyBhIHRlc3Qgc3RyaW5n', 32)



# Generated at 2022-06-23 17:47:21.447662
# Unit test for function decode
def test_decode():
    assert decode(b"\x01\x02\x03") == ('AQID', 3)
    assert decode(b"\x01\x02") == ('AQI=', 2)
    assert decode(b"\x01") == ('AQ==', 1)
    assert decode(b"") == ('', 0)



# Generated at 2022-06-23 17:47:33.809016
# Unit test for function decode

# Generated at 2022-06-23 17:47:36.712500
# Unit test for function register
def test_register():
    """Test the function register."""
    register()

    # Ensure the codec is properly registered.
    try:
        _ = codecs.getdecoder(NAME)  # noqa: F841
    except LookupError:
        assert False, 'codec not registered'


# Generated at 2022-06-23 17:47:39.237162
# Unit test for function decode
def test_decode():
    """Test decode"""
    _ = decode(b'U29tZUJhc2U2NCBkYXRhOmJ5dGVz', 'strict')


# Generated at 2022-06-23 17:47:47.288448
# Unit test for function decode
def test_decode():
    assert decode(b'hello world') == ('aGVsbG8gd29ybGQ=', 11)
    assert decode(b'\x00') == ('AAA=', 1)
    assert decode(b'\x00\x00') == ('AAAA', 2)
    assert decode(b'\x00\x00\x00') == ('AAAAAA==', 3)
    assert decode(b'\x00\x00\x00\x00') == ('AAAAAAAA', 4)


# Generated at 2022-06-23 17:47:52.428807
# Unit test for function decode
def test_decode():
    assert decode(b'AQID') == ('AQID', 4)
    assert decode(b'U1ld') == ('SMy', 4)
    assert decode(b'A\nQ\nI\nD') == ('AQID', 4)
    assert decode(b'U\n1\nl\nd') == ('SMy', 4)
    assert decode(b'U\n1\n\nl\n\nd') == ('SMy', 4)



# Generated at 2022-06-23 17:48:02.109007
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(b'') == ('', 0)
    assert decode(b'\x01') == ('AQ==', 1)
    assert decode(b'\x01\x02') == ('AQI=', 2)
    assert decode(b'\x01\x02\x03') == ('AQID', 3)
    assert decode(b'\x01\x02\x03\x04') == ('AQIDBA==', 4)
    assert decode(b'\x01\x02\x03\x04\x05') == ('AQIDBAU=', 5)
    assert decode(b'\x01\x02\x03\x04\x05\x06') == ('AQIDBAUG', 6)

# Generated at 2022-06-23 17:48:13.118693
# Unit test for function decode

# Generated at 2022-06-23 17:48:16.433975
# Unit test for function register
def test_register():
   """Test Function register."""
   import sys
   import codecs
   sys.path.insert(0, '.')
   register()
   codecs.getdecoder(NAME)


register()

# Generated at 2022-06-23 17:48:22.929601
# Unit test for function decode
def test_decode():
    """Check the return values of the decode function is correct"""
    assert len(decode(b'test', 'errors')) == 2
    assert decode(b'test', 'errors') == ('dGVzdA==', 4)
    assert decode(b'test ', 'errors') == ('dGVzdA', 4)
    assert decode(b'test\n', 'errors') == ('dGVzdA', 4)
    assert decode(b'test\n\t', 'errors') == ('dGVzdA', 4)
    assert decode(b'test\n~', 'errors') == ('dGVzdA==', 4)
    assert decode(b'\n\ntest\n\t', 'errors') == ('dGVzdA', 4)

# Generated at 2022-06-23 17:48:32.130996
# Unit test for function encode
def test_encode():
    """Test for the ``encode`` function."""
    # Test for empty inputs
    assert ''.encode(NAME) == b''
    # Test for standard inputs
    assert 'dGVzdA=='.encode(NAME) == b'test'
    assert 'Zm9v'.encode(NAME) == b'foo'
    assert 'YmFy'.encode(NAME) == b'bar'
    # Test for custom inputs
    assert 'aHR0cHM6Ly9naXRodWIuY29tL1F1YWxpdHlJbXBvcnRzL3NlcGFyYXRlZC14' \
            'eXp6eQ=='.encode(NAME) == \
        b'https://github.com/QualityImports/separated-xyzzz'
   

# Generated at 2022-06-23 17:48:35.488863
# Unit test for function decode
def test_decode():
    expected = 'eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9'
    actual = decode(b'{"sub":"1234567890","name":"John Doe","admin":true}')
    assert actual[0] == expected
    assert actual[1] == len(b'{"sub":"1234567890","name":"John Doe","admin":true}')


# Generated at 2022-06-23 17:48:47.584949
# Unit test for function decode
def test_decode():

    # Unit test for function decode.

    # Sanity test: ensure that the codec is registered before testing.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        import sys
        import os
        pyver_list = (f'{ver}' for ver in sys.version_info)
        py_ver = '.'.join(pyver_list)

# Generated at 2022-06-23 17:48:50.153365
# Unit test for function register
def test_register():
    """Test function register"""
    register()
    data = codecs.getdecoder(NAME)
    assert data



# Generated at 2022-06-23 17:48:52.145634
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    raise NotImplementedError



# Generated at 2022-06-23 17:48:59.948533
# Unit test for function decode
def test_decode():

    test_data = (
        (b'0', 'MA'),
        (b'A', 'QQ'),
        (b'\x00', 'AA'),
        (b'ABCD', 'QUJDRA'),
        (b'abcd', 'YWJjZA'),
        (b'0123456789', 'MDEyMzQ1Njc4OQ')
    )

    for test_case in test_data:
        decoded_data, bytes_consumed = decode(test_case[0])
        assert bytes_consumed == len(test_case[0])
        assert decoded_data == test_case[1]

        decoded_data, bytes_consumed = decode(bytearray(test_case[0]))
        assert bytes_consumed == len(test_case[0])


# Generated at 2022-06-23 17:49:11.427984
# Unit test for function encode
def test_encode():
    """Unit test for function encode()"""
    import unittest
    class TestEncode(unittest.TestCase):
        """Test Encode"""
        def test_encode_with_no_spaces(self):
            """Test encode with no spaces."""
            text = 'I am a boy and I love my mummy'
            expected = b'SSBhbSBhIGJveSBhbmQgSSBsb3ZlIG15IG11bW15'
            actual, length = encode(text)
            self.assertEqual(actual, expected)
            self.assertEqual(length, len(text))

        def test_encode_with_spaces(self):
            """Test encode with spaces."""
            text = 'I am a boy and I love my mummy'

# Generated at 2022-06-23 17:49:20.383121
# Unit test for function encode
def test_encode():
    assert encode('YW55IGNhcm5hbCBwbGVhcw==') == \
        b'any carnal pleas'
    assert encode('YW55IGNhcm5hbCBwbGVhcw=') == \
        b'any carnal pleas'
    assert encode('YW55IGNhcm5hbCBwbGVhcw') == \
        b'any carnal pleas'
    assert encode('YW55IGNhcm5hbCBwbGVhc3U=') == \
        b'any carnal pleasu'
    assert encode('YW55IGNhcm5hbCBwbGVhc3U') == \
        b'any carnal pleasu'

# Generated at 2022-06-23 17:49:31.235262
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    import codecs
    from importlib import reload
    from sys import modules

    from coders.b64 import register

    try:
        reload(modules[__name__])  # type: ignore
        register()

        codecs.getdecoder(NAME)
    except Exception as e:
        fmt = 'Failed to load the {0!r} codec: {1!s}'
        msg = fmt.format(NAME, e)
        raise Exception(msg) from e


# Run the register() function if this file is run as a script
if __name__ == '__main__':
    # Run the unittest.
    test_register()

    # This codec is not intended to ever be run as a script.  If it is,
    # then one of the main reasons would

# Generated at 2022-06-23 17:49:36.377706
# Unit test for function decode
def test_decode():
    """ Test decode function.

    Test that decode function gives expected result.
    """
    result, length = decode(b'\x82\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    assert len(result) == 24
    assert length == 10
    assert result == 'goABeQ==\n'


# Generated at 2022-06-23 17:49:41.085939
# Unit test for function decode
def test_decode():
    # Test decode of simple strings
    assert decode(b'\x06\x00\x00\x00Mah\x00\x00\x00\x00\x00')[0] == 'BWFoAA=='
    # Test decode of complicated strings
    assert decode(
        b'\x06\x00\x00\x00Mah\x00\x00\x00\x08\x00\x00\x00aaaaaaaa'
    )[0] == 'BWFoAAAAAAAAAAAAAA=='


# Generated at 2022-06-23 17:49:46.069171
# Unit test for function decode
def test_decode():
    """Test decode function."""
    data = b'hello world'
    text = str(base64.b64encode(data), 'utf-8')
    text_str, _ = decode(data, errors='ignore')  # type: ignore
    assert text == text_str  # type: ignore
    return



# Generated at 2022-06-23 17:49:47.347243
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)

# Generated at 2022-06-23 17:49:58.701440
# Unit test for function decode
def test_decode():
    print('test decode')

# Generated at 2022-06-23 17:50:06.454985
# Unit test for function encode

# Generated at 2022-06-23 17:50:16.468199
# Unit test for function decode
def test_decode():
    assert decode(b'ZWxlIG9mZiBhbHRvIHNhc2h1ZA==') == ('ele off altos cashuza', 24)
    assert decode(b'anlsaW5rIHVwIGRyaW5r') == ('alink up drink', 16)
    assert decode(b'YWxsIGp1c3QgYmF1ZCBhbmQgdW5kZXJzdGFuZA==') == (
        'all just baud and understand', 32
    )
    assert decode(b'd2hlbiB0aGUgZ3JpbGwgdGFrZXMgb3Zlcg==') == (
        'when the grill takes over', 24
    )

# Generated at 2022-06-23 17:50:27.270270
# Unit test for function decode
def test_decode():
    # Call decode with a bytes object.
    test_bytes = b'\x00\x01\x02\x03\x04'
    test_str, consumed = decode(test_bytes)
    assert consumed == len(test_bytes)
    assert test_str == 'AAECAwQ='

    # Call codecs.decode with the "b64" codec.
    test_str = codecs.decode(test_bytes, 'b64')
    assert test_str == 'AAECAwQ='

    # Call codecs.decode with the "base64_codec" codec.
    test_str = codecs.decode(test_bytes, NAME)
    assert test_str == 'AAECAwQ='

    # Call codecs.decode with the "base64_codec.base64_codec" codec.


# Generated at 2022-06-23 17:50:35.164510
# Unit test for function encode

# Generated at 2022-06-23 17:50:36.363967
# Unit test for function register
def test_register():
    register()
    codec = codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:50:38.612869
# Unit test for function encode
def test_encode():
    assert encode('\n') == (b'', 1)
    assert encode('  TWFu  ') == (b'Man', 10)



# Generated at 2022-06-23 17:50:50.261647
# Unit test for function encode
def test_encode():
    s = '''DGhpcyBpcyBhIHRlc3Qgb2YgdGhlIGJhc2U2NCBlbmNvZGUgYW5kIGRlY29kZSBzdHJ1
        Y3R1cmUgZm9yIHRoZSAiYjY0IiBjb2RlYy4gVGhpcyBpcyBhIG5vcm1hbCB0ZXN0IHN0
        ci4='''
    t = ''' This is a test of the base64 encode and decode structure for the "b64" codec.
    This is a normal test str.'''
    b = t.strip().split()[0]

    t = b64.encode(s).replace(b'\n', b'')
    assert t

# Generated at 2022-06-23 17:50:55.910343
# Unit test for function decode
def test_decode():
    """Test that the decode function properly decodes a
    base64 string into bytes.
    """
    data = "Rm9vYmFy"
    data_bytes = bytes([
        0x46, 0x6f, 0x6f, 0x62, 0x61, 0x72
    ])
    decoded_tuple = decode(data)
    decoded_bytes = decoded_tuple[0].encode('utf-8')
    assert len(decoded_bytes) == len(data_bytes)
    assert decoded_bytes == data_bytes



# Generated at 2022-06-23 17:51:00.421807
# Unit test for function decode
def test_decode():
    assert decode(b'AQIDBAUGBwgJCgsMDQ4PEA==')[0] == '\x01\x02\x03\x04\x05\x06\x07\x08'



# Generated at 2022-06-23 17:51:11.150300
# Unit test for function decode
def test_decode():
    def _run_test(
            data_bytes: bytes,
            expected_str: str
    ) -> None:
        actual_str, _ = decode(data_bytes)
        if expected_str != actual_str:
            raise RuntimeError(
                f'\n'
                f' Failed test:\n'
                f'  data            = {data_bytes!r}\n'
                f'  expected_str    = {expected_str!r}\n'
                f'  actual_str      = {actual_str!r}\n'
            )

    _run_test(b'aGVsbG8gV29ybGQh\n', 'hello World!\n')
    _run_test(b'VGVzdGluZyAxMjM0\n', 'Testing 1234\n')


# Generated at 2022-06-23 17:51:15.366225
# Unit test for function register
def test_register():
    # pylint: disable=C0103
    # pylint: disable=W0212

    # Register the codec
    register()

    # The register function should register it only once.
    register()

    # Do we have a b64 codec.
    codecs.encode('test', 'b64')

# Generated at 2022-06-23 17:51:19.700361
# Unit test for function encode
def test_encode():
    """Run doctests for the function ``encode``."""
    # pylint: disable=C0115
    import doctest
    doctest.testmod(
        optionflags=doctest.IGNORE_EXCEPTION_DETAIL
    )

# Generated at 2022-06-23 17:51:31.107173
# Unit test for function encode
def test_encode():
    assert encode('aGVsbG8gd29ybGQ=')[0] == b'aGVsbG8gd29ybGQ='
    assert encode('c3RyaW5nIGhhbmRsZQ==')[0] == b'c3RyaW5nIGhhbmRsZQ=='
    assert encode('cG9zdGdyZXM=')[0] == b'cG9zdGdyZXM='
    assert encode('aW50bA==')[0] == b'aW50bA=='
    assert encode('dGltZXN0YW1w')[0] == b'dGltZXN0YW1w'

# Generated at 2022-06-23 17:51:36.531985
# Unit test for function register
def test_register():
    """Test for function 'register'."""
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)

    register()
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:51:38.710421
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:51:48.678389
# Unit test for function encode
def test_encode():
    assert bytes(b'abc') == encode(
        (
            'YWJj'
        ),
    )
    assert bytes(b'abc') == encode(
        (
            'YWJj'
        ),
    )
    assert bytes(b'abcd') == encode(
        (
            'YWJjZA=='
        ),
    )
    assert bytes(b'abcde') == encode(
        (
            'YWJjZGU='
        ),
    )
    assert bytes(b'abcdef') == encode(
        (
            'YWJjZGVm'
        ),
    )
    assert bytes(b'a' * 255) == encode(
        (
            'YW' * 127 + 'Y'
        ),
    )

# Generated at 2022-06-23 17:51:51.521420
# Unit test for function register
def test_register():
    """Register the ``b64`` codec."""
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


# Generated at 2022-06-23 17:51:55.848850
# Unit test for function decode
def test_decode():
    #pylint: disable=W1401
    """Base64 Decode Unit Testing"""
    string_input = "dGVzdA=="
    decode_result, _ = decode(string_input)
    assert decode_result == "test"


# Generated at 2022-06-23 17:52:00.653759
# Unit test for function encode
def test_encode():
    """Test the ``encode`` function."""
    import sys
    import os

    # pylint: disable=no-member
    assert len(sys.argv) == 2
    data_path: str = sys.argv[1]
    assert os.path.exists(data_path)

    test_data: _STR = open(data_path, 'rb').read()

    # Check that we can encode the test data with base64.
    assert (
        test_data == b64.encode(b64.encode(test_data)[0])[0]
    )

    # Check that we can encode the test data with our encode function.
    assert test_data == encode(encode(test_data)[0])[0]

    # Check that the encode function works with UserStrings.

# Generated at 2022-06-23 17:52:03.492928
# Unit test for function register
def test_register():
    """Test the :func:`~b64_codec.register` function."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:52:07.143880
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None
    assert decoder[0] is decode
    assert decoder[1] is encode

# Generated at 2022-06-23 17:52:12.207152
# Unit test for function register
def test_register():
    """Test that the codec has been registered."""
    assert NAME not in codecs.__dict__['_cache']
    assert NAME not in codecs.__dict__['_unknown_encoding_error']
    register()
    assert NAME in codecs.__dict__['_cache']
    assert NAME in codecs.__dict__['_unknown_encoding_error']



# Generated at 2022-06-23 17:52:19.949852
# Unit test for function encode
def test_encode():
    # pylint: disable=W0603
    # noinspection PyUnresolvedReferences
    """
    Unit test for function 'encode'

    """
    global codecs
    codecs = __import__('codecs')
    global base64
    base64 = __import__('base64')

    # pylint: disable=C1801
    def custom_error_handler(exception):
        """
        Custom error handler for codecs.
        """
        return exception.start, exception.end

    codecs.register_error('test-error-handler', custom_error_handler)
    register()

    assert codecs.getdecoder(NAME) is not None

    # Test case 0 - simple
    text_string = 'SGVsbG8gV29ybGQh'

# Generated at 2022-06-23 17:52:28.575964
# Unit test for function encode
def test_encode():
    """Test the function with known inputs and outputs."""
    assert encode('SGVsbG8sIFdvcmxkIQ==') == (b'Hello, World!', 16)
    assert encode('VGhpcyBpcyBh') == (b'This is a', 11)
    assert encode('IHNhbXBsZSBiYXNlNjQKICAg') == (b'sample base64\n    ', 20)
    assert encode('ICAgIHN0cmluZw==') == (b'    string', 11)



# Generated at 2022-06-23 17:52:39.270566
# Unit test for function decode
def test_decode():
    """Test the decode() function.

    Decode, with a 20 byte size limit, each string input, of base64
    characters, into the expected base64 bytes output.

    Returns:
        None
    """