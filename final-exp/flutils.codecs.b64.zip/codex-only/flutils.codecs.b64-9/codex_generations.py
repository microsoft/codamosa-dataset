

# Generated at 2022-06-23 17:42:50.374575
# Unit test for function encode
def test_encode():
    assert encode('YmFzZTY0') == (b'base64', 6)
    assert encode('YmFzZTY0\n') == (b'base64', 6)
    assert encode('YmFzZTY0\r\n') == (b'base64', 6)
    assert encode('YmFzZTY0\r') == (b'base64', 6)
    assert encode('\tYmFzZTY0\n\t') == (b'base64', 6)
    assert encode('YmFzZTY0\n\n') == (b'base64', 6)
    assert encode('YmFzZTY0\n\n\n') == (b'base64', 6)

# Generated at 2022-06-23 17:42:54.366716
# Unit test for function decode
def test_decode():
    assert(decode(data=b'\x01\x02\x03', errors=None)[0] == 'AQID')
    assert(decode(data=b'\x01\x02\x03', errors=None)[1] == 3)



# Generated at 2022-06-23 17:43:00.119095
# Unit test for function register
def test_register():
    from io import StringIO
    output_stream = StringIO()
    old_stdout = sys.stdout
    sys.stdout = output_stream
    codecs.register(lambda name: None)
    codecs.register(_get_codec_info)
    sys.stdout = old_stdout
    assert output_stream.getvalue() == 'Codec __main__.b64 is already registered, ' \
                                       'but should be registered by calling ' \
                                       'register.\n'

# Generated at 2022-06-23 17:43:11.717253
# Unit test for function encode
def test_encode():
    assert encode('YW55Cg==')[0] == b'any\n'
    assert encode('YW55\nCg==')[0] == b'any\n'
    assert encode('YW55\n\nCg==')[0] == b'any\n'
    assert encode('YW55\nCg==\n')[0] == b'any\n'
    assert encode('YW55\nCg==\n\n')[0] == b'any\n'
    assert encode('YW55Cg==\n\n')[0] == b'any\n'
    assert encode('YW55Cg==   \n\n')[0] == b'any\n'

# Generated at 2022-06-23 17:43:16.137561
# Unit test for function register
def test_register():
    """Test for the function register."""
    register()
    assert codecs.lookup(NAME) is not None   # type: ignore
    assert codecs.lookup_error('b64') is not None   # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:43:27.145187
# Unit test for function encode
def test_encode():
    """Unit test for function `encode`."""
    assert encode('') == (b'', 0)

    line_1 = 'SGVsbG8sIHdvcmxkIQ=='
    assert encode(line_1) == (b'Hello, world!', len(line_1))

    line_2 = 'SSdtIGtpbGxpbmcgeW91ciBzcGVlY2gu' \
             'IEkgYW0gSSdtIGtpbGxpbmcgeW91ciBmcmVl' \
             'aHdvcmsu'

    assert encode(line_2) == (
        b"I'm killing your speech. I am I'm killing "
        b"your freehworku",
        len(line_2)
    )


# Generated at 2022-06-23 17:43:29.217374
# Unit test for function decode
def test_decode():
    result = decode(b'\x01\x02\x03')
    assert result[0] == 'AQID'
    assert result[1] == 3


# Generated at 2022-06-23 17:43:32.249359
# Unit test for function decode
def test_decode():
    assert decode(b'abc') == ('YWJj', 3)


# Generated at 2022-06-23 17:43:44.090705
# Unit test for function encode
def test_encode():
    """Unit-test :py:func:`~encode` using :py:mod:`unittest`."""
    import unittest

    class TestEncode(unittest.TestCase):
        """Test the function :py:func:`~encode`"""

        def test_input_is_a_string(self) -> None:
            """Test that the given ``text` is a string."""
            text = 'Hello'
            out, _ = encode(text)
            self.assertEqual(out, b'SGVsbG8=')

        def test_input_is_a_user_string(self) -> None:
            """Test that the given ``text`` is a :obj:`UserString`."""
            text = UserString('Hello')
            out, _ = encode(text)

# Generated at 2022-06-23 17:43:48.836586
# Unit test for function register
def test_register():
    """Test for function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:43:51.584395
# Unit test for function register
def test_register():
    """Test the :func:`register` function."""
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'{NAME} not registered with Python: {e}'
        )


# Generated at 2022-06-23 17:43:55.834562
# Unit test for function register
def test_register():
    """Test function register()."""
    register()
    assert isinstance(codecs.getencoder(NAME), codecs.CodecInfo)
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)



# Generated at 2022-06-23 17:44:02.734026
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==')[0] == b'test'
    assert encode('Zm9v\nYmFy\n')[0] == b'foobar'
    assert encode('cXVpcGU=\n')[0] == b'quipe'
    assert encode('R0lG\nOw==\n\n')[0] == b'GIF'
    assert encode('IyMj==\n')[0] == b'###'



# Generated at 2022-06-23 17:44:14.705023
# Unit test for function encode
def test_encode():
    """Test the encode function

    Returns:
        :obj:`str`: The encoded string.
    """

# Generated at 2022-06-23 17:44:26.154214
# Unit test for function decode

# Generated at 2022-06-23 17:44:33.544598
# Unit test for function decode
def test_decode():
    assert decode(b'Zm9vYmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9v YmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9v YmFy ') == ('Zm9vYmFy', 8)
    assert decode(b' Zm9v YmFy ') == ('Zm9vYmFy', 8)
    assert decode(b' Zm9v YmFy') == ('Zm9vYmFy', 8)
    assert decode(b'Zm9v YmFy') == ('Zm9vYmFy', 8)

# Generated at 2022-06-23 17:44:39.745931
# Unit test for function decode
def test_decode():
    assert decode(b'abc') == ('YWJj', 3)
    assert decode(b'a\nbc') == ('YWJj', 4)
    assert decode(b'a\n\n\nbc') == ('YWJj', 7)
    assert decode(b'a\rb\rc') == ('YWJj', 7)

# Unit Test for function encode

# Generated at 2022-06-23 17:44:46.852476
# Unit test for function register
def test_register():
    register()
    if codecs.getdecoder(NAME):
        import io
        import unittest

        class CodecTest(unittest.TestCase):
            def test_encode(self):
                """Test the encode function."""
                text = ('aGVsbG8gd29ybGQ=\n'
                        'aGVsbG8gd29ybGQ=')
                out = b'hello world'
                self.assertEqual(
                    codecs.encode(text, NAME),
                    (out, len(text)),
                    'The encode function is not working properly.'
                )

            def test_decode(self):
                """Test the decoder function."""
                text = b'hello world'
                out = 'aGVsbG8gd29ybGQ='

# Generated at 2022-06-23 17:44:55.304858
# Unit test for function decode
def test_decode():
    '''
    Unit test for function decode
    :return:
    '''
    # create an instance of the dummy CodecInfo class
    codec_info = codecs.CodecInfo(
        name='b64',
        encode=encode,
        decode=decode,
        incrementalencoder=None,
        incrementaldecoder=None,
        streamreader=codecs.StreamReader,
        streamwriter=codecs.StreamWriter
    )
    # register the above instance
    codecs.register(lambda name: codec_info if name == 'b64' else None)

    # encode input string in base64 encoding
    test_str = 'A string encoded in base64 format'
    encoder_handle = codecs.getencoder('b64')
    encoded_bytes, encoded_len = encoder_handle(test_str)

# Generated at 2022-06-23 17:45:06.184413
# Unit test for function encode
def test_encode():
    # encode: type: ignore[misc]
    assert encode('A') == (b'1', 1)
    assert encode('QQ') == (b'Mw', 2)
    assert encode('AAA') == (b'BQA=', 3)
    assert encode('QQQ') == (b'M88=', 3)
    assert encode('AAAA') == (b'BQAAA==', 4)
    assert encode('QQQQ') == (b'M88D', 4)

    # encode: type: ignore[misc]
    try:
        encode('\x00')
    except UnicodeEncodeError as e:
        assert e.reason == 'b64'
        assert e.object == '\x00'
        assert e.start == 0
        assert e.end == 1

# Generated at 2022-06-23 17:45:17.088751
# Unit test for function register
def test_register():  # pylint: disable=R0915
    from base64 import b64encode
    from base64 import b64decode

    register()
    codecs.register(_get_codec_info)

    IN_STR = 'Hello World!'
    IN_STR = IN_STR.encode('utf-8')
    ENCODED = b64encode(IN_STR)
    ENCODED = ENCODED.decode('utf-8')
    ENCODED_LINES = '\n'.join(
        ENCODED[i:i+80]
        for i in range(0, len(ENCODED), 80)
    )

    try:
        OUT_BYTES = ENCODED_LINES.encode(NAME)
    except UnicodeEncodeError as e:
        raise e



# Generated at 2022-06-23 17:45:24.522302
# Unit test for function decode
def test_decode():
    assert(decode(b'MA==')== ('MQ==',3))
    assert(decode(b'MA')== ('MQ',2))
    assert(decode(b'MA=')== ('MQ',2))
    assert(decode(b'M')== ('M',1))
    assert(decode(b'MAZ==')== ('MQE=',4))
    assert(decode(b'MAZ')== ('MQE',3))
    assert(decode(b'MAZ=')== ('MQE',3))
    assert(decode(b'MAZA==')== ('MQZB',4))
    assert(decode(b'MAZA')== ('MQZB',4))
    assert(decode(b'MAZA=')== ('MQZB',4))

# Generated at 2022-06-23 17:45:28.936616
# Unit test for function register
def test_register():
    """Test function b64_codec.register."""
    register()
    assert NAME in codecs.getdecoder('b64')
    assert NAME in codecs.getencoder('b64')

# Unit tests for function decode

# Generated at 2022-06-23 17:45:33.839528
# Unit test for function register
def test_register():
    """Test the function 'register()'"""
    try:
        codecs.getdecoder(NAME)  # type: ignore
    except LookupError:
        register()
        decoder = codecs.getdecoder(NAME)  # type: ignore
        assert decoder is not None



# Generated at 2022-06-23 17:45:42.050377
# Unit test for function encode
def test_encode():
    from unittest.mock import patch


# Generated at 2022-06-23 17:45:43.031702
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 17:45:51.453394
# Unit test for function encode

# Generated at 2022-06-23 17:46:02.660771
# Unit test for function decode
def test_decode():
    import collections
    import io
    import string
    import unittest

    b64 = codecs.getencoder(NAME)
    text_in = ''.join(string.printable)
    data_expected = text_in.encode('utf-8')
    text_encoded, _ = b64(text_in)

    decode_obj = codecs.getdecoder(NAME)
    text_decoded, length = decode_obj(text_encoded)
    assert text_decoded == text_in
    assert length == len(text_encoded)

    buffer_ = io.BytesIO(text_encoded)
    text_decoded_2, length2 = decode_obj(buffer_)
    assert text_decoded == text_in
    assert length == len(text_encoded)



# Generated at 2022-06-23 17:46:04.252478
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-23 17:46:11.290446
# Unit test for function register
def test_register():
    """Test the register function."""
    decode_func = codecs.getdecoder(NAME)
    assert decode_func(b'SGVsbG8gd29ybGQhCg==') == ('Hello world!\n', 12)
    assert decode_func(b'ZG9uZQo=') == ('done\n', 6)
    assert decode_func(b'') == ('', 0)
    assert decode_func(b'=') == ('', 1)
    assert decode_func(b'=\n') == ('\n', 2)
    assert decode_func(b'A') == ('', 1)
    assert decode_func(b'AA') == ('', 2)
    assert decode_func(b'AAA') == ('', 3)
    assert decode_func(b'AAAA') == ('', 4)

# Generated at 2022-06-23 17:46:23.449141
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('AA==') == (b'\x00', 4)
    assert encode('AAA=') == (b'\x00\x00', 4)
    assert encode('AAAA') == (b'\x00\x00\x00', 4)
    assert encode('AAA') == (b'\x00\x00', 3)
    assert encode('QQ==') == (b'\x12', 4)
    assert encode('QQ') == (b'\x12', 2)
    assert encode('Qg==') == (b',', 4)
    assert encode('Qg') == (b',', 2)
    assert encode('Qu8=') == (b'!', 4)
    assert encode('Qu8') == (b'!', 3)

# Generated at 2022-06-23 17:46:30.526665
# Unit test for function encode
def test_encode():
    assert encode('YWJj') == (b'abc', 4)
    assert encode('ZW5jb2Rl') == (b'encode', 6)
    assert encode('ZGVjb2Rl') == (b'decode', 6)
    assert encode('aGVsbG8gd29ybGQ=') == (b'hello world', 11)
    assert encode('bm90IGEgYmFzZTY0IHN0cmluZw==') == (b'not a base64 string', 18)
    assert encode('ZW5jb2RlZCBzdHJpbmc=') == (b'encoded string', 13)

# Generated at 2022-06-23 17:46:42.338099
# Unit test for function decode

# Generated at 2022-06-23 17:46:43.256857
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 17:46:46.512538
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:46:48.802977
# Unit test for function register
def test_register():
    """Test :meth:`register`."""
    codecs.getdecoder(NAME)


del codecs

register()

# Generated at 2022-06-23 17:46:59.635579
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('dGhpcyBpcyBhIHRlc3Q=') == (b'this is a test', 18)
    assert encode('AQIDBA==') == (b'\x01\x02\x03\x04', 8)
    assert encode('dGhlIHNhbXBsZSBub25jZQ==') == (b'the sample nonce', 20)
    assert encode('ZGVmYXVsdA==') == (b'default', 8)
    assert encode('YWJjZA==') == (b'abcd', 4)
    assert encode('YWJjZA=') == (b'abcd', 4)
    assert encode('YWJjZGU=') == (b'abcde', 5)



# Generated at 2022-06-23 17:47:10.448298
# Unit test for function encode
def test_encode():
    assert encode('A' * 78) ==(b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
                               b'AAAAAAAAAAAAAAAAAAAA', 77)
    assert encode('A' * 77) ==(b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
                               b'AAAAAAAAAAAAAAAAAAA=', 76)
    assert encode('A' * 76) ==(b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
                               b'AAAAAAAAAAAAAAAAAA==', 75)
    assert encode('A' * 75) ==(b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
                               b'AAAAAAAAAAAAAAAAA', 74)
    assert encode('A' * 74) ==(b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
                               b'AAAAAAAAAAAAAAAA', 73)
    assert encode('A' * 73) ==(b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
                               b'AAAAAAAAAAAAAAA=', 72)

# Generated at 2022-06-23 17:47:15.305512
# Unit test for function decode
def test_decode():
    """Test the decode function."""
    assert decode(b'\x01\x01') == ('AQE=', 2)
    assert decode(b'\x01\x01') == ('AQE=', 2)
    assert decode(b'\x01\x01\x01') == ('AQU=', 3)

# Generated at 2022-06-23 17:47:23.334076
# Unit test for function encode
def test_encode():
    """Unit test for function :py:func:`.encode`."""
    import io
    import os

    from . import io_encode

    # Load the test data from the 'test_encode.txt' file in the
    # package folder.
    with open(os.path.join(os.path.dirname(__file__), 'test_encode.txt')) as f:
        data = f.read()
    (input_txt, expected) = data.strip().split(sep='|')
    input_txt = input_txt.replace('\n', '\r\n')
    expected = expected.replace('\r\n', '\n')
    with io.BytesIO() as buf:
        with io_encode.EncodedStdout(buf, 'b64') as stdout:
            print

# Generated at 2022-06-23 17:47:34.553047
# Unit test for function decode
def test_decode():
    """
    Test 'decode' function
    """
    import os
    import unittest

    class TestDecode(unittest.TestCase):
        """
        Test decode function
        """

        def setUp(self):
            """
            Common setup for all decode tests
            """
            # pylint: disable=protected-access
            codecs._g_codecs.pop(NAME, None)
            register()

        def test_success_example(self):
            """
            Test encode example code from documentation example.
            """
            data = b'\x14\xfb\x9c\x03\xd9\x7e'
            out = codecs.decode(data, NAME)
            self.assertEqual(out, 'FPucA9l+')


# Generated at 2022-06-23 17:47:38.190463
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # No error is raised when the b64 codec is already registered.
    register()
    # pylint: disable=W0212
    # noinspection PyProtectedMember
    assert NAME in codecs._cache  # type: ignore

# Generated at 2022-06-23 17:47:43.861467
# Unit test for function decode
def test_decode():

    output = "SGVsbG8sIFdvcmxkIQ==".encode("utf-8")
    text_input = "Hello, World!".encode("utf-8")
    assert output == decode(text_input)[0].encode("utf-8")



# Generated at 2022-06-23 17:47:49.616521
# Unit test for function decode
def test_decode():
    """Test function decode()"""
    assert decode(b'aGVsbG8=') == ('hello', 8)
    assert decode(b'aGVsbG8=\n') == ('hello', 9)
    assert decode(b'\naGVsbG8=\n') == ('hello', 11)
    assert decode(b'\n\naGVsbG8=\n\n') == ('hello', 13)



# Generated at 2022-06-23 17:47:55.985580
# Unit test for function decode
def test_decode():
    """Test that the ``decode()`` function works as expected."""
    assert decode(b'\x00\x00\x00\x00') == ('AAAAAA', 4)
    assert decode(b'\x00\x01\x02\x03') == ('AQIDBA', 4)
    assert decode(b'\x00\x00\x00\x00', 'ignore') == ('AAAAAA', 4)
    assert decode(b'\x00\x01\x02\x03', 'ignore') == ('AQIDBA', 4)



# Generated at 2022-06-23 17:47:57.847891
# Unit test for function decode
def test_decode():

    data = codecs.encode(b"Hello World", 'utf-8')
    assert decode(data)[0] == "Hello World"


# Generated at 2022-06-23 17:48:00.607102
# Unit test for function register
def test_register(): # type: ignore
    """"""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:48:10.493861
# Unit test for function encode
def test_encode():
    """Test the encoding of base64 strings of all possible lengths."""
    # test the empty string case.
    test_str = ''
    test_bytes, _ = encode(test_str)
    assert len(test_bytes) == 0
    assert type(test_bytes) is bytes

    # test the single character case.
    test_str = 'A'
    test_bytes, _ = encode(test_str)
    assert len(test_bytes) == 1
    assert test_bytes[0] == 0

    # test a small case.
    test_str = 'Zg=='
    test_bytes, _ = encode(test_str)
    assert len(test_bytes) == 1
    assert test_bytes[0] == ord('f')

    # test a large case.

# Generated at 2022-06-23 17:48:19.481294
# Unit test for function register
def test_register():
    # pylint: disable=W0612
    from pytest import raises as assert_raises

    register()
    x = 'aGVsbG8='
    y = b'hello'
    assert x == decode(y)[0]
    assert y == encode(x)[0]
    with assert_raises(Error) as failure:
        encode('_test_')
    assert failure.typename == 'UnicodeEncodeError'
    with assert_raises(Error) as failure:
        encode('_test_')
    assert failure.typename == 'UnicodeEncodeError'

if __name__ == '__main__':
    register()

# Generated at 2022-06-23 17:48:28.004495
# Unit test for function register
def test_register():
    """Unit test for function register."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise AssertionError(f'{NAME} is not registered')
        else:
            raise AssertionError(f'{NAME} is not registered')
    else:
        raise AssertionError(f'{NAME} is already registered')


register()

# Generated at 2022-06-23 17:48:34.738762
# Unit test for function decode
def test_decode():  # pragma: no cover
    """Unit test for function encode."""
    assert decode(b'h') == ('aA==', 1)
    assert decode(b'h\x8a') == ('aa==', 1)
    assert decode(b'\x8ah') == ('aE=', 1)
    assert decode(b'\x8a\x8a') == ('aGg=', 2)
    assert decode(b'\x8a\x8a\x8a') == ('aGg=', 2)
    assert decode(b'\x8a\x8a\x8a', 'ignore') == ('aGg=', 3)



# Generated at 2022-06-23 17:48:41.967552
# Unit test for function decode
def test_decode():
    """Test that the ``b64`` codec is working."""
    # Test decode for different sample inputs
    assert decode(b'\x00\x01') == ('AAE=', 2)
    assert decode(b'\x00\x01\x02') == ('AAEC', 3)
    assert decode(b'\x00\x01\x02\x03') == ('AAECAw==', 4)
    assert decode(b'\x00\x01\x02\x03\x04') == ('AAECAwQ=', 5)
    assert decode(b'\x00\x01\x02\x03\x04\x05') == ('AAECAwQF', 6)

# Generated at 2022-06-23 17:48:51.716090
# Unit test for function register
def test_register():
    """
    Test the unit test itself.
    """
    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'Expected that codec {NAME} is available for decoding, but got '
            f'{e}'
        )
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise AssertionError(
            f'Expected that codec {NAME} is available for encoding, but got '
            f'{e}'
        )
    codecs.lookup(NAME)



# Generated at 2022-06-23 17:48:54.217148
# Unit test for function register
def test_register():
    """Verify the b64 codec is registered."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:49:00.881433
# Unit test for function decode
def test_decode():
    data = b'Man is distinguished, not only by his reason, but by this ' \
           b'singular passion from other animals, which is a lust of the ' \
           b'mind, that by a perseverance of delight in the continued and ' \
           b'indefatigable generation of knowledge, exceeds the short vehemence ' \
           b'of any carnal pleasure.'

# Generated at 2022-06-23 17:49:03.586983
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder('b64') is not None
    assert codecs.getencoder('b64') is not None

# Generated at 2022-06-23 17:49:12.586923
# Unit test for function decode
def test_decode():
    """Test the decode function with various input values."""
    # Test: bytes not in base64 character format.
    assert decode(b'Hello World') == ('SGVsbG8gV29ybGQ=', len(b'Hello World'))

    # Test: base64 encoded bytes.
    assert decode(b'SGVsbG8gV29ybGQ=') == ('SGVsbG8gV29ybGQ=', len(b'Hello World'))

    # Test: 'data' parameter that are not bytes.
    assert decode('Hello World') == ('SGVsbG8gV29ybGQ=', 11)



# Generated at 2022-06-23 17:49:19.741541
# Unit test for function decode
def test_decode():
    """Test the encode function of the ``b64`` codec with tests from
    base64.
    """
    t = base64.standard_b64encode
    assert t(b'') == b''
    assert decode(b'') == ('', 0)
    assert t(b'\x00') == b'AA=='
    assert decode(b'\x00') == ('AA==', 1)
    assert t(b'\x00\x00') == b'AAA='
    assert decode(b'\x00\x00') == ('AAA=', 2)
    assert t(b'\x00\x00\x00') == b'AAAA'
    assert decode(b'\x00\x00\x00') == ('AAAA', 3)

# Generated at 2022-06-23 17:49:23.971100
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()


if __name__ == '__main__':
    test_register()

# vim: set ts=4 sts=4 sw=4 tw=79:

# Generated at 2022-06-23 17:49:32.333365
# Unit test for function decode
def test_decode():
    input_data = b'T\xf8\xeb\x1e\xf4\xf9\xef\xfc\x05\xa2\xdf\xef\x1f\x1b\x1d\x9f'
    output = 'VPD///8K/f7/4w=='
    output_bytes = b'VPD///8K/f7/4w=='
    assert decode(input_data) == (output, len(input_data))
    assert encode(output) == (output_bytes, len(output))
    print('all tests successful')


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-23 17:49:35.572918
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    text = 'YmJjMTIz'
    expected = b'abc123'
    result = encode(text)
    assert result[0] == expected


# Generated at 2022-06-23 17:49:37.057678
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:49:40.535805
# Unit test for function register
def test_register():
    """Test :func:`register`."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


__all__ = [
    'decode',
    'encode',
    'NAME',
    'test_register',
]

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:49:48.944904
# Unit test for function decode
def test_decode():
    """Test the function :func:`~encoding.b64.decode`."""
    text = "hello, world"
    expected_str = "base64:aGVsbG8sIHdvcmxk"
    actual_str = decode(text.encode('utf-8'))[0]
    assert actual_str == expected_str
    text = 'hell\no,\n world'
    expected_str = "base64:aGVsbCx3b3JsZA=="
    actual_str = decode(text.encode('utf-8'))[0]
    assert actual_str == expected_str


# Generated at 2022-06-23 17:49:59.945070
# Unit test for function encode
def test_encode():
    assert encode('YWJjZGU='), b'abcde'
    assert encode('QQ=='), b'A'
    assert encode('QUJC'), b'ABC'
    assert encode('QUJDRA=='), b'ABCD'
    assert encode('='), b''
    assert encode('QQ') == b'A'
    assert encode('QQ=') == b'A'
    assert encode('QQ==') == b'A'
    assert encode('QQq') == b'A'
    assert encode('QQq') == b'A'
    assert encode('QQqq') == b'A'
    assert encode('QQqq') == b'A'
    assert encode('QQqqq') == b'A'
    assert encode('QQqqq') == b'A'

    # Bad characters raises

# Generated at 2022-06-23 17:50:07.230151
# Unit test for function encode
def test_encode():
    input_string = '''
        SGVsbG8sIHdvcmxkIQ==
        QWxlcnQ6IEJhc2U2NCBkZWNvZGluZyBmYWlsZWQ=
        QWxlcnQ6IEJhc2U2NCBlbmNvZGluZyBmYWlsZWQ=
    '''
    b64 = encode(input_string)
    gold = b'Hello, world!'
    assert b64 == gold

    input_string = '''
    VU5BTUlUWVBFRCBFUlJPUjogQmFzZTY0IGRlY29kaW5nIGZhaWxlZA==
    '''

# Generated at 2022-06-23 17:50:17.026935
# Unit test for function encode
def test_encode():
    """Test the :func:`encode` function with different inputs."""
    # Test encode with a simple string.
    out, _ = encode('a')
    assert out == b'YQ=='

    # Test encode with a string that contains a newline and extra
    # spaces.
    out, _ = encode('a\n  ')
    assert out == b'YQ=='

    # Test encode of a multi-line string.
    out, _ = encode('a\nb\nc')
    assert out == b'YQpi\nYw=='

    # Test encode a multi-line string with indenting.
    text = 'a\n  b\nc\n  d'
    out, _ = encode(text)
    assert out == b'YQpi\nYwpiZA=='

    # Test

# Generated at 2022-06-23 17:50:27.795534
# Unit test for function decode
def test_decode():
    assert decode(b'\xaa\x55\x00\x55\x04\xaa\x04') == ('qVMAAQM=' ,7)
    assert decode(b'\x00\x55\x04\xaa\x04') == ('AAIDAA==' ,5)
    assert decode(b'\x55\x04\xaa\x04') == ('VBQMAA==' ,4)
    assert decode(b'\xaa\x04') == ('BA0=' ,2)
    assert decode(b'\x04\xaa\x04') == ('AQM=' ,3)
    assert decode(b'\x00\x55\x04\xaa\x04\x00') == ('AAIDAAAD' ,6)

# Generated at 2022-06-23 17:50:34.662404
# Unit test for function register
def test_register():
    # Restore the original state of the 'b64' codec.
    codecs.lookup_error(NAME)

    assert codecs.lookup_error(NAME)

    register()

    try:
        codecs.lookup_error(NAME)
    except LookupError as e:
        m = e.__str__()
        assert m.startswith(f'No codec lookup for name b64')



# Generated at 2022-06-23 17:50:45.609950
# Unit test for function decode

# Generated at 2022-06-23 17:50:52.125250
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    empty_str = ''.encode()

    for d in [b'', b'\x00', b'\xff']:
        assert decode(d) == (base64.b64encode(d).decode(), len(d))

    assert decode(empty_str) == ('', 0)

    assert decode(None) == (
        base64.b64encode(empty_str).decode(),
        0
    )



# Generated at 2022-06-23 17:50:59.415163
# Unit test for function encode

# Generated at 2022-06-23 17:51:02.314110
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    assert codecs.lookup(NAME)


# Decode the given base64 characters into bytes.

# Generated at 2022-06-23 17:51:08.260533
# Unit test for function register
def test_register():
    assert not _get_codec_info(NAME)

    # Register the codec and test that it is now available.
    register()
    assert _get_codec_info(NAME).name == NAME

if __name__ == "__main__":
    assert not _get_codec_info(NAME)

    # Register the codec and test that it is now available.
    register()
    assert _get_codec_info(NAME).name == NAME

    test_register()

# Generated at 2022-06-23 17:51:18.826573
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'', 1)
    assert encode('ab') == (b'', 1)
    assert encode('abc') == (b'', 2)
    assert encode('abcd') == (b'', 3)
    assert encode('abcde') == (b'', 4)
    assert encode('abcdef') == (b'', 5)
    assert encode('ab c') == (b'', 1)
    assert encode('ab c ') == (b'', 1)
    assert encode('\nab\ncd\n') == (b'', 2)
    assert encode('\n  ab\n  cd\n  ') == (b'', 2)
    assert encode('\n\n\n  ab\n  cd\n    \n') == (b'', 2)

# Generated at 2022-06-23 17:51:30.494474
# Unit test for function encode
def test_encode():
    """Test the 'encode' function"""


# Generated at 2022-06-23 17:51:42.157172
# Unit test for function encode
def test_encode():
    assert encode('dGVzdA==') == (b'test', 6)
    assert encode('dGVzdA==\n') == (b'test', 6)
    assert encode('\r\n\tdGVzdA==\r\n') == (b'test', 6)
    assert encode('\r\n\tdGVzdA==\r\n test') == (b'test', 6)
    assert encode("\r\n\tdGVzdA==\r\n\n test") == (b'test', 6)
    assert encode("\rdGVzdA==\r\t") == (b'test', 6)
    assert encode("\t\r\n# dGVzdA==\r\n\n\n") == (b'test', 6)

# Generated at 2022-06-23 17:51:45.776750
# Unit test for function register
def test_register():
    """Unit test - Register the b64 codec."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

test_register()

# Generated at 2022-06-23 17:51:50.493544
# Unit test for function decode
def test_decode():
        base64_str_orig = 'SGVsbG8gV29ybGQh'
        testdata = codecs.decode(base64_str_orig, 'base64')
        base64_str_encoded = 'b64'
        test_str = codecs.decode(base64_str_orig, base64_str_encoded)
        assert(testdata == test_str)


# Generated at 2022-06-23 17:52:01.723082
# Unit test for function encode

# Generated at 2022-06-23 17:52:06.835465
# Unit test for function register
def test_register():
    """Register the ``b64`` codec with Python."""
    import sys
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        sys.modules[__name__].register()

__all__ = [
    'b64',
    'encode',
    'decode',
]

# Generated at 2022-06-23 17:52:10.808673
# Unit test for function register
def test_register():
    """Unit test for function register"""
    # Try to register the function
    register()

    # Verify the codec was registered
    codecs.getencoder(NAME)  # type: ignore
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-23 17:52:14.869616
# Unit test for function register
def test_register():
    register()
    # Extract the codec info from the codecs system and return
    # just the 'decode' function.
    assert NAME == 'b64'
    assert codecs.getdecoder(NAME)[1] is decode  # type: ignore


# Generated at 2022-06-23 17:52:21.864639
# Unit test for function decode
def test_decode():
    assert decode(b'abcdefghijklmnopqrstuvwxyz')[0] == 'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='
    assert decode(b'ABCDEFGHIJKLMNOPQRSTUVWXYZ')[0] == 'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo='
    assert decode(b'0123456789')[0] == 'MDEyMzQ1Njc4OQ=='
    assert decode(b'@&$#')[0] == 'JCYk'



# Generated at 2022-06-23 17:52:33.460168
# Unit test for function encode

# Generated at 2022-06-23 17:52:41.843041
# Unit test for function decode

# Generated at 2022-06-23 17:52:43.825477
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""
    assert decode(bytes([98, 97]))[0] == 'YmE='

# Generated at 2022-06-23 17:52:47.116704
# Unit test for function encode
def test_encode():
    """Unit test for Encoder function."""
    text = '''
       YQ==
       YWI=
       YWJj
       '''
    assert encode(text) == (b'ab', 8)
    assert encode(text)[0] == b'ab'

