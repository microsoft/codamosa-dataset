

# Generated at 2022-06-25 20:55:23.725703
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    assert isinstance(user_0, str)
    assert 'home' in user_0


# Generated at 2022-06-25 20:55:26.658365
# Unit test for constructor of class Path
def test_Path():
    '''
    Tests Path constructor
    '''
    path_0 = Path()



# Generated at 2022-06-25 20:55:30.037546
# Unit test for constructor of class Path
def test_Path():
    """Unit test for class Path."""
    path = Path()
    path.random.seed(0)
    assert path.home() == '/home'
    path.random.seed(12)
    assert path.project_dir() == '/home/bryanna/Dev/Python/majestic'

# Generated at 2022-06-25 20:55:31.335528
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)



# Generated at 2022-06-25 20:55:40.770057
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert path_0.home() == '/home'
    assert path_0.user() == '/home/jasmine'
    assert path_0.users_folder() == '/home/george/Desktop'
    assert path_0.dev_dir() == '/home/shawn/Development/Livescript'
    assert path_0.project_dir() == '/home/shawn/Development/Livescript/nimbostratus'

    path_1 = Path('win32')
    assert path_1.home() == 'C:\\Users'
    assert path_1.user() == 'C:\\Users\\Wanda'
    assert path_1.users_folder() == 'C:\\Users\\Lynwood\\Favorites'

# Generated at 2022-06-25 20:55:42.178745
# Unit test for constructor of class Path
def test_Path():
    assert Path('linux').platform == 'linux'

# Generated at 2022-06-25 20:55:44.290624
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    last_user = None
    for i in range(10):
        user = path_0.user()
        assert user != last_user


# Generated at 2022-06-25 20:55:51.251994
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path()
    print("str(path_1._pathlib_home) => {}".format(str(path_1._pathlib_home)))
    print("path_1.home() => {}".format(path_1.home()))
    print("path_1.root() => {}".format(path_1.root()))
    print("path_1.user() => {}".format(path_1.user()))
    print("path_1.dev_dir() => {}".format(path_1.dev_dir()))
    print("path_1.project_dir() => {}".format(path_1.project_dir()))
    print()

###############################################################################


# Generated at 2022-06-25 20:55:55.170750
# Unit test for constructor of class Path
def test_Path():
    p = Path('win32')
    assert str(p._pathlib_home) == 'C:\\Users'
    p = Path('linux')
    assert str(p._pathlib_home) == '/home'
    p = Path('darwin')
    assert str(p._pathlib_home) == '/Users'
    p = Path(None)
    assert str(p._pathlib_home) == '/Users'


# Generated at 2022-06-25 20:55:57.503113
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_path = path_0.user()
    print("The user path is " + user_path)
