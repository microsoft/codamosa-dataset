

# Generated at 2022-06-25 20:55:22.650119
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.root() == "/"
    assert p._pathlib_home == Path("/home")
    assert p.home() == "/home"
    assert p.user() == "/home/oretha"
    assert p.project_dir() == "/home/sherrell/Development/Falcon/spoonbill"
    assert p.dev_dir() == "/home/bernita/Development/Scala"
    assert p.users_folder() == "/home/shirl/Pictures"



# Generated at 2022-06-25 20:55:26.616527
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result = path_0.user()
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_Path_user()

# Generated at 2022-06-25 20:55:28.503316
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path()
    path_2 = Path('linux')
    # Wrong platform
    path_3 = Path('None')



# Generated at 2022-06-25 20:55:34.110070
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    i = 0
    while i < 100:
        user = path_0.user()
        # assert True, 'Тест не пройден, ожидаемое условие не было получено'
        assert isinstance(user, str), 'Тест не пройден, ожидаемый тип результата теста не соответствует полученному'
        i += 1


# Generated at 2022-06-25 20:55:37.241078
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.user() == '/home/hongru'
    assert path.users_folder() == '/home/albertha/Pictures'
    assert path.project_dir() == '/home/albertha/Development/Ruby/mantissa'

# Generated at 2022-06-25 20:55:39.619986
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.seed(0)
    result_user = path_0.user()
    assert result_user == '/home/oretha'


# Generated at 2022-06-25 20:55:40.769222
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert path_0


# Generated at 2022-06-25 20:55:43.140460
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()

    assert path_0.platform == sys.platform
    assert path_0._pathlib_home != ""

# Generated at 2022-06-25 20:55:45.127316
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()
    assert path_0.user() is not None


# Generated at 2022-06-25 20:55:50.542310
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path('linux')
    assert path_1.platform == 'linux'


# Generated at 2022-06-25 20:55:57.657602
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path(platform='linux')
    assert path_0.user() == '/home/olyvia'


# Generated at 2022-06-25 20:55:59.322854
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert len(path_0.user()) == 4 or len(path_0.user()) == 5


# Generated at 2022-06-25 20:56:05.887149
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.seed(0)
    assert str(path_0.user()) == '/home/Shawn'
    path_1 = Path()
    path_1.seed(1)
    assert str(path_1.user()) == '/home/Taneka'
    path_2 = Path()
    path_2.seed(2)
    assert str(path_2.user()) == '/home/Nancy'
    path_3 = Path()
    path_3.seed(3)
    assert str(path_3.user()) == '/home/Virgil'
    path_4 = Path()
    path_4.seed(4)
    assert str(path_4.user()) == '/home/Sherika'
    path_5 = Path()
    path_5.seed(5)


# Generated at 2022-06-25 20:56:07.655363
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert type(str(path_1.user())) is str


# Generated at 2022-06-25 20:56:09.166022
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()


# Generated at 2022-06-25 20:56:11.570542
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert path_1.user() in ["/home/lavelle", "/home/sherrell"]


# Generated at 2022-06-25 20:56:13.472082
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert(re.match('/(home|Users)/[^/]+', path_0.user()))


# Generated at 2022-06-25 20:56:14.577461
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:56:16.793965
# Unit test for method user of class Path
def test_Path_user():
    # Test class exists
    assert Path

    # Test method exists
    assert Path.user

    # Test output is str
    assert isinstance(Path.user(Path()), str)


# Generated at 2022-06-25 20:56:17.878294
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())


# Generated at 2022-06-25 20:56:28.297769
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result = path_0.user()
    assert result in ['/home/taneka', '/home/oretha', '/home/kimberely', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-25 20:56:30.504790
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert path_1.user() == '/home/anjelica'


# Generated at 2022-06-25 20:56:32.567501
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_1.random.seed(1)
    assert path_1.user() == '/home/miguel'


# Generated at 2022-06-25 20:56:34.349376
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user = path_0.user()
    assert len(user) >= 4 and len(user) <= 20


# Generated at 2022-06-25 20:56:37.719105
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    try:
        users = list(map(lambda x: path.user(), range(100)))
        assert len(set(users)) > 80
    except:
        err = sys.exc_info()[0]
        print('ERROR: ' + str(err))


# Generated at 2022-06-25 20:56:39.976053
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    result_Path_user = p.user()
    print(result_Path_user)
    assert result_Path_user is not None


# Generated at 2022-06-25 20:56:42.303504
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result_0 = path_0.user()
    assert result_0 is not None
    assert result_0



# Generated at 2022-06-25 20:56:47.532650
# Unit test for method user of class Path
def test_Path_user():
    import unittest
    class TestUser(unittest.TestCase):
        def test_user_0(self):
            # test Path class user method
            path_0 = Path()
            path_0._pathlib_home = PurePosixPath('/home/ABC')
            path_0._set_seed(2)
            self.assertEqual(path_0.user(), '/home/ABC/Pam')
    unittest.main()



# Generated at 2022-06-25 20:56:48.630829
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()

# Generated at 2022-06-25 20:56:49.413819
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/orlando'


# Generated at 2022-06-25 20:57:05.640816
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() in ['C:/Users/Test', '/home/Test']
    assert path_0.user() == path_0.user()


# Generated at 2022-06-25 20:57:06.759229
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/taneka'


# Generated at 2022-06-25 20:57:09.174624
# Unit test for method user of class Path
def test_Path_user():
    _rng = Generator(_seed=0)
    path = Path(platform='linux', random_generator=_rng)
    assert path.user() == '/home/hadrian'


# Generated at 2022-06-25 20:57:10.553941
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    assert path.user() == '/home/kirstie'


# Generated at 2022-06-25 20:57:13.697859
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()
    count = 0
    for i in range(100):
        tmp_0 = path_0.user()
        tmp_1 = path_1.user()
        if tmp_0 == tmp_1:
            count += 1
    assert count < 20

# Generated at 2022-06-25 20:57:14.891128
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform = sys.platform)
    assert not path.user() == ''

# Generated at 2022-06-25 20:57:17.598356
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path_users = []
    for i in range(100):
        path_users.append(path.user())
    assert len(path_users) == len(set(path_users))

# Generated at 2022-06-25 20:57:19.243256
# Unit test for method user of class Path
def test_Path_user():
    for _ in range(100):
        p = Path()
        assert p.user() != None


# Generated at 2022-06-25 20:57:27.333940
# Unit test for method user of class Path
def test_Path_user():
    # get a Path Class object
    p = Path()

    # call the method user() of the Path class
    user_name = p.user()

    # Assert all details of the home, user and subdirectory
    home = str(p._pathlib_home)
    # Get the last splitted element of the path string
    user = user_name.split(home)[-1].strip(home)
    # Get the subdirectory after the user's name
    sub_dir = user_name.split(home)[-1].strip(home).split(user)[-1].strip(user)
    # Assert all details
    assert(home == '/home')
    assert(user in ['oretha', 'taneka', 'sherrell', 'sherika'])

# Generated at 2022-06-25 20:57:29.590654
# Unit test for method user of class Path
def test_Path_user():
    for i in range(0,10):
        path = Path()
        path.user()


# Generated at 2022-06-25 20:58:00.857219
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    list = []
    # Loop that run method user and store the result in a list
    for i in range(0, 100):
        list.append(path.user())
        # Check if all results are unique
        # check if list is set(list) is true
    assert len(list) == len(set(list))


# Generated at 2022-06-25 20:58:02.869289
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert len(path_0.user()) > 0

# Generated at 2022-06-25 20:58:03.960249
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in USERNAMES


# Generated at 2022-06-25 20:58:06.621854
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.providers.path import Path
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-25 20:58:10.446876
# Unit test for method user of class Path
def test_Path_user():
    for i in range(100):
        # Checking if the returned value contain the given string
        assert 'home' in Path().user()
        # Checking if the returned value is a String
        assert isinstance(Path().user(), str)
        # Checking if the returned value is not empty
        assert Path().user() is not ''


# Generated at 2022-06-25 20:58:11.440158
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:58:13.235275
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user_path = path.user()
    print(user_path)
    assert user_path == str(path._pathlib_home / 'John')

# Generated at 2022-06-25 20:58:14.549593
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user, str)


# Generated at 2022-06-25 20:58:15.962992
# Unit test for method user of class Path
def test_Path_user():
    pathGeneric = Path()
    print("\nTesting user of class Path")
    print("-------------------------")
    print("user = %s" % pathGeneric.user())


# Generated at 2022-06-25 20:58:16.870502
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)


# Generated at 2022-06-25 20:59:20.949826
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/sherrell'


# Generated at 2022-06-25 20:59:29.365691
# Unit test for method user of class Path

# Generated at 2022-06-25 20:59:30.883057
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    assert user_0 == '/home/franco'


# Generated at 2022-06-25 20:59:33.063333
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/reann'


# Generated at 2022-06-25 20:59:33.695155
# Unit test for method user of class Path
def test_Path_user():
    for i in range(0, 10):
        test_case_0()

# Generated at 2022-06-25 20:59:37.879143
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform = 'win32')
    assert path.user().startswith('C:\\Users')
    path = Path(platform = 'win64')
    assert path.user().startswith('C:\\Users')
    path = Path(platform = 'linux')
    assert path.user().startswith('/home')
    path = Path(platform = 'darwin')
    assert path.user().startswith('/Users')


# Generated at 2022-06-25 20:59:40.691871
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0._pathlib_home = PureWindowsPath('C:/Users')
    path_0.random.choice = lambda x: 'oretha'
    result = path_0.user()
    assert result == 'C:\\Users\\Oretha'


# Generated at 2022-06-25 20:59:42.406046
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    temp = None
    for i in range(100):
        temp = path_0.user()
        assert(temp.startswith("/home"))


# Generated at 2022-06-25 20:59:44.716694
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/oretha'

# Generated at 2022-06-25 20:59:45.730940
# Unit test for method user of class Path
def test_Path_user():
    m = Path()
    n = m.user()
    assert m.user() == n