

# Generated at 2022-06-25 20:55:19.670597
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/jimmie'


# Generated at 2022-06-25 20:55:25.873770
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    path_1 = Path('linux')
    path_2 = Path('darwin')
    path_3 = Path('win32')
    path_4 = Path('win64')

    path_linux = Path('linux')
    path_darwin = Path('darwin')
    path_win32 = Path('win32')
    path_win64 = Path('win64')
    path_linux.seed(1)
    path_darwin.seed(1)
    path_win32.seed(1)
    path_win64.seed(1)
    assert path_linux.root() == '/'
    assert path_darwin.root() == '/'
    assert path_win32.root() == 'C:\\'
    assert path_win64.root() == 'C:\\'

    path

# Generated at 2022-06-25 20:55:27.473834
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert("/home" in result)


# Generated at 2022-06-25 20:55:28.969066
# Unit test for constructor of class Path
def test_Path():
    # Unit test for method home
    assert Path().home() == '/home'


# Generated at 2022-06-25 20:55:30.465137
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())


# Generated at 2022-06-25 20:55:36.314156
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert path_0.__class__.__name__ == 'Path'
    assert path_0._pathlib_home.__class__.__name__ == 'PureWindowsPath' or \
           path_0._pathlib_home.__class__.__name__ == 'PurePosixPath'
    assert hasattr(path_0, '__init__')


# Generated at 2022-06-25 20:55:37.491195
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-25 20:55:43.975025
# Unit test for method user of class Path

# Generated at 2022-06-25 20:55:45.001939
# Unit test for constructor of class Path
def test_Path():
    test_case_0()

# Generated at 2022-06-25 20:55:48.956124
# Unit test for constructor of class Path
def test_Path():
    # Test 1
    path_0 = Path()
    # Test 2
    path_1 = Path(platform='linux')
    # Test 3
    path_2 = Path(platform='darwin')
    # Test 4
    path_3 = Path(platform='win32')
    # Test 5
    path_4 = Path(platform='win64')
    pass
