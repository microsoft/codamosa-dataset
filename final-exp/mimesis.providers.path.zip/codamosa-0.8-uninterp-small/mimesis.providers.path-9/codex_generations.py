

# Generated at 2022-06-25 20:55:25.365642
# Unit test for method user of class Path
def test_Path_user():
    # Test case 0
    path_0 = Path()
    path_0.seed(0)
    assert path_0.user() == '/home/kathlene'
    assert path_0.user() == '/home/jenice'
    assert path_0.user() == '/home/reynalda'
    assert path_0.user() == '/home/louella'
    assert path_0.user() == '/home/katherin'
    assert path_0.user() == '/home/jeraldine'
    assert path_0.user() == '/home/krystle'
    assert path_0.user() == '/home/tena'
    assert path_0.user() == '/home/taren'
    assert path_0.user() == '/home/krishna'



# Generated at 2022-06-25 20:55:26.919816
# Unit test for constructor of class Path
def test_Path():
    """Testing constructor of class Path"""
    path_0 = Path()
    assert path_0


# Generated at 2022-06-25 20:55:28.461395
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform='linux')
    dir = path.home()
    assert dir == '/home'


# Generated at 2022-06-25 20:55:30.144323
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert (path_0.user()) == "\\home\\shakira"


# Generated at 2022-06-25 20:55:34.135071
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/ocean'
    path_1 = Path('darwin')
    assert path_1.user() == '/Users/flora'


# Generated at 2022-06-25 20:55:34.935728
# Unit test for constructor of class Path
def test_Path():
    try:
        test_case_0()
    except Exception:
        return False
    else:
        return True

# Generated at 2022-06-25 20:55:36.210072
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()


# Generated at 2022-06-25 20:55:37.740300
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path("linux")
    assert str(path_0.home()) == '/home'


# Generated at 2022-06-25 20:55:39.003898
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert type(p.home()) is str



# Generated at 2022-06-25 20:55:45.131236
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()
    path_2 = Path()
    path_3 = Path()
    path_4 = Path()
    path_5 = Path()
    path_6 = Path()
    path_7 = Path()
    path_8 = Path()
    path_9 = Path()
    path_10 = Path()
    path_11 = Path()
    path_12 = Path()
    path_13 = Path()
    path_14 = Path()
    path_15 = Path()
    path_16 = Path()
    path_17 = Path()
    path_18 = Path()
    path_19 = Path()
    path_20 = Path()
    path_21 = Path()
    path_22 = Path()
    path_23 = Path()
    path_24 = Path()