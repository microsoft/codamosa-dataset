

# Generated at 2022-06-25 20:55:19.670644
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()


# Generated at 2022-06-25 20:55:20.908470
# Unit test for constructor of class Path
def test_Path():
#     assert test_case_0.platform == 'linux'
    assert True

# Generated at 2022-06-25 20:55:31.090577
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()

# Generated at 2022-06-25 20:55:40.507202
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    for i in range(5):
        result = provider.user()
        assert isinstance(result,str)
        assert len(result) > 0
        assert isinstance(result,str)
        assert len(result) == len(str(Path(platform='linx')._pathlib_home.parent))+1+len(result.split('/')[-1])
        assert isinstance(result,str)
        assert len(result) == len(str(Path(platform='darwin')._pathlib_home.parent))+1+len(result.split('/')[-1])
        assert isinstance(result,str)
        assert len(result) == len(str(Path(platform='win32')._pathlib_home.parent))+1+len(result.split('/')[-1])
       

# Generated at 2022-06-25 20:55:42.938855
# Unit test for constructor of class Path
def test_Path():
    # Testing if an error will be raised if an incorrect platform is given
    path_0 = Path('randomPlatform')


# Generated at 2022-06-25 20:55:45.566464
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.random.seed(0)
    result_0 = path_0.users_folder()
    assert result_0 == '/home/gaston/Pictures'


# Generated at 2022-06-25 20:55:51.940445
# Unit test for constructor of class Path
def test_Path():
    assert len(Path(platform="linux").home()) >= 0
    assert len(Path(platform="darwin").home()) >= 0
    assert len(Path(platform="win32").home()) >= 0
    assert len(Path(platform="win64").home()) >= 0


# Generated at 2022-06-25 20:55:56.552823
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.Meta.name == 'path'
    path.random.choice(USERNAMES) == path.user()

# Generated at 2022-06-25 20:55:57.973593
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_1.user()


# Generated at 2022-06-25 20:56:00.134317
# Unit test for constructor of class Path
def test_Path():
    # Test initialization of class Path
    path_0 = Path()

    assert isinstance(path_0, Path)
    assert isinstance(path_0.random, BaseProvider)

