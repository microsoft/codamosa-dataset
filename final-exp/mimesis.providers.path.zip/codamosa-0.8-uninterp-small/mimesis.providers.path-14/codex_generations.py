

# Generated at 2022-06-25 20:55:21.105476
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/gladys', '/home/wendie']


# Generated at 2022-06-25 20:55:22.767219
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert type(path_0.user()) == str

# Generated at 2022-06-25 20:55:24.533802
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/dianne'



# Generated at 2022-06-25 20:55:27.129267
# Unit test for constructor of class Path
def test_Path():
    try:
        # Path()
        # TODO
        assert False
    except:
        print("test Path() fails")


# Generated at 2022-06-25 20:55:30.684751
# Unit test for constructor of class Path
def test_Path():
    assert sys.platform == test_case_0().platform
    # Test for pathlib instance, because it's private,
    # we need to test it with the help of public method
    assert (PureWindowsPath if 'win' in sys.platform
            else PurePosixPath) == type(test_case_0()._pathlib_home)


# Generated at 2022-06-25 20:55:38.161852
# Unit test for constructor of class Path
def test_Path():
    str = input()
    path = Path(str)
    print('\n')
    print('The platform is: ', path.platform)
    print('The home directory is: ', path.home())
    print('The root directory is: ', path.root())
    print('The username is: ', path.user())
    print('The user folder is: ', path.users_folder())
    print('The development folder is: ', path.dev_dir())
    print('The project folder is: ', path.project_dir())
    
#test_case_0()
#test_Path()

# Generated at 2022-06-25 20:55:39.584571
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-25 20:55:41.627229
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert len(path_1.user()) == 20 


# Generated at 2022-06-25 20:55:43.097281
# Unit test for constructor of class Path
def test_Path():
    # test Path.__init__()
    assert test_case_0() == None


# Generated at 2022-06-25 20:55:44.250229
# Unit test for method user of class Path
def test_Path_user():
    path_user = Path()
    path_user.user()


# Generated at 2022-06-25 20:55:47.289819
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:55:52.700146
# Unit test for method user of class Path

# Generated at 2022-06-25 20:56:03.440292
# Unit test for constructor of class Path
def test_Path():
    # Create object of class Path
    path_1 = Path()
    # assertEqual() that a random path is returned by the method root()
    assert path_1.root() == '/'
    # assertEqual() that a path is returned by the method home()
    assert path_1.home() == '/home'
    # assertEqual() that a path is returned by the method user()
    assert path_1.user() == '/home/oretha'
    # assertEqual() that a path is returned by the method users_folder()
    assert path_1.users_folder() == '/home/taneka/Pictures'
    # assertEqual() that a path is returned by the method dev_dir()
    assert path_1.dev_dir() == '/home/sherrell/Development/Python'
    # assertEqual() that a

# Generated at 2022-06-25 20:56:05.932034
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert len(path_0.user()) > 0
    assert len(path_0.user().split('/')) == 3


# Generated at 2022-06-25 20:56:15.044932
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in ['\\home\\kimberli', '\\home\\sharyn', '\\home\\edison', '\\home\\tuyet', '\\home\\tara', '\\home\\florencio', '\\home\\tish', '\\home\\tawna', '\\home\\tierra', '\\home\\krystina']

# Generated at 2022-06-25 20:56:16.370401
# Unit test for method user of class Path
def test_Path_user():
    for _ in range(0,10):
        assert isinstance(Path().user(), str)


# Generated at 2022-06-25 20:56:23.123145
# Unit test for method user of class Path

# Generated at 2022-06-25 20:56:25.555370
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert str(path_0._pathlib_home / 'oretha') == path_0.user()


# Generated at 2022-06-25 20:56:27.441459
# Unit test for constructor of class Path
def test_Path():
    validation = Path()
    assert type(validation) == Path


# Generated at 2022-06-25 20:56:34.680109
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    # assert isinstance(path.__str__(), str)
    # assert isinstance(path.random, Random)
    # assert isinstance(path.datetime, DatetimeTime)
    # assert isinstance(path.seed, Seed)
    # assert isinstance(path.text, Text)
    # assert isinstance(path.__repr__(), str)
    # assert isinstance(path.__doc__, str)
    # assert isinstance(path._platform, str)
    # assert isinstance(path._pathlib_home, PurePath)


# Generated at 2022-06-25 20:56:47.400056
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()
    path_2 = Path()
    assert (isinstance(path_0.user(), str))
    assert (isinstance(path_1.user(), str))
    assert (isinstance(path_2.user(), str))
    assert (path_0.user() != path_1.user())
    assert (path_0.user() != path_2.user())
    assert (path_1.user() != path_2.user())
    assert (path_0.user() != path_0.user())
    assert (path_1.user() != path_1.user())
    assert (path_2.user() != path_2.user())


# Generated at 2022-06-25 20:56:50.766765
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    # You can add here your custom test
    assert(len(path_0.user()) == 16)
    assert(str(path_0.user()).startswith('/home/'))
    assert(str(path_0.user()).count('/') == 3)



# Generated at 2022-06-25 20:56:51.693283
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:56:53.760729
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert path_1.user() in '/home/cieran', \
        'Should be true, because path_1.user() should be equal to /home/cieran'


# Generated at 2022-06-25 20:56:55.504567
# Unit test for method user of class Path
def test_Path_user():
    # Unit test for method user in class Path
    # Using static input "linux2"
    path_0 = Path()
    assert path_0.user() == "/home/taneka"


# Generated at 2022-06-25 20:57:00.353603
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    res = path_0.user()
    print("\n#### Test user ####\n")
    print("Result: " + res)


# Generated at 2022-06-25 20:57:01.669632
# Unit test for method user of class Path
def test_Path_user():
    myPath = Path()
    print("USER =>", myPath.user())


# Generated at 2022-06-25 20:57:03.108736
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == str(Path()._pathlib_home / 'oretha')

# Generated at 2022-06-25 20:57:03.821866
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user()


# Generated at 2022-06-25 20:57:09.136365
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
    print(path_0.user())
   

# Generated at 2022-06-25 20:57:21.614028
# Unit test for method user of class Path
def test_Path_user():
    # Assign
    path_0 = Path()
    if sys.platform == "win32":
        result = path_0.user() == "/home/Edra"
    elif sys.platform == "linux":
        result = path_0.user() == "/home/shaneka"
    elif sys.platform == "darwin":
        result = path_0.user() == "/home/taneka"



# Generated at 2022-06-25 20:57:28.492900
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    str_0 = path_0.user()
    assert len(str_0) >= 1
    # Test for case when home dir is empty
    path_1 = Path()
    str_1 = path_1.user()
    assert len(str_1) >= 1
    # Test for case when home dir is '/home'
    path_2 = Path()
    str_2 = path_2.user()
    assert len(str_2) >= 1
    # Test for case when home dir is '/Users'
    path_3 = Path()
    str_3 = path_3.user()
    assert len(str_3) >= 1



# Generated at 2022-06-25 20:57:31.718333
# Unit test for method user of class Path
def test_Path_user():
    path = Path("Linux")
    assert len(path.user()) == 15
    assert path.user().startswith("/home/")
    assert path.user().endswith("/")


# Generated at 2022-06-25 20:57:33.380241
# Unit test for method user of class Path
def test_Path_user():
    path = Path()

    # Check for type of return value
    assert isinstance(path.user(), str)


# Generated at 2022-06-25 20:57:35.145244
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())


# Generated at 2022-06-25 20:57:36.655450
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert type(path_1.user()) == str

# Generated at 2022-06-25 20:57:37.630996
# Unit test for method user of class Path
def test_Path_user():
    assert isinstance(Path().user(), str)


# Generated at 2022-06-25 20:57:39.945290
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/deedee'  # Test #0


# Generated at 2022-06-25 20:57:43.126281
# Unit test for method user of class Path
def test_Path_user():
    path0 = Path()
    assert "root" not in path0.user()
    assert "users" not in path0.user()
    assert "home" not in path0.user()
    assert "Development" not in path0.user()


# Generated at 2022-06-25 20:57:45.113691
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in ["/home/oretha", "/home/rupert", "/home/taneka", "/home/sherrell"]


# Generated at 2022-06-25 20:58:06.512785
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    # Expected value:
    #   '/home/alline'

    path.seed(2)
    output_0 = path.user()
    assert output_0 == '/home/alline'

    path.seed(72)
    output_1 = path.user()
    assert output_1 == '/home/alline'


# Generated at 2022-06-25 20:58:07.840885
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/oretha'


# Generated at 2022-06-25 20:58:11.108027
# Unit test for method user of class Path
def test_Path_user():
    path = Path()

    data = []

    for i in range(100):
        data.append(path.user())

    print('Print data of method user of class Path')
    print(data)

test_case_0()

test_Path_user()

# Generated at 2022-06-25 20:58:12.662985
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert type(path_1.user()) is str
    assert "/home/" in path_1.user()


# Generated at 2022-06-25 20:58:17.909458
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path('linux')
    assert path_1.user() == '/home/verdell'
    assert path_1.user() == '/home/felipa'
    path_2 = Path('darwin')
    assert path_2.user() == '/Users/pok'
    path_3 = Path('win32')
    assert path_3.user() == 'C:\\Users\\serena'
    with pytest.raises(KeyError):
        path_4 = Path('some_unknown_platform')
    path_5 = Path('win64')
    assert path_5.user() == 'C:\\Users\\jerlene'


# Generated at 2022-06-25 20:58:24.694296
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    assert user_0 == '/home/oralee'
    path_1 = Path()
    user_1 = path_1.user()
    assert user_1 == '/home/fiona'
    path_2 = Path()
    user_2 = path_2.user()
    assert user_2 == '/home/teressa'
    path_3 = Path()
    user_3 = path_3.user()
    assert user_3 == '/home/deedee'
    path_4 = Path()
    user_4 = path_4.user()
    assert user_4 == '/home/lizzie'

# Generated at 2022-06-25 20:58:26.426495
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    assert isinstance(user_0, str)


# Generated at 2022-06-25 20:58:29.699593
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)
    assert isinstance(Path().user(), str)
    assert isinstance(Path().user(seed=25), str)
    assert Path().user(seed=25) == '/home/kandis/'


# Generated at 2022-06-25 20:58:30.627760
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-25 20:58:31.755556
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
