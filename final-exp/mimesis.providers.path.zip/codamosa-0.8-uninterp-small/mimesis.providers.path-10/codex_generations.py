

# Generated at 2022-06-25 20:55:19.670571
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert isinstance(path_0, type(Path())) is True


# Generated at 2022-06-25 20:55:20.909262
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:55:21.822957
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:55:22.611741
# Unit test for constructor of class Path
def test_Path():
    test_case_0()

# Generated at 2022-06-25 20:55:27.260866
# Unit test for method user of class Path
def test_Path_user():
    from hypothesis import given
    from hypothesis.strategies import text

    path_0 = Path()

    @given(text())
    def test_user(str_0):
        assert isinstance(
            path_0.user(),
            str
        ) == True

# Generated at 2022-06-25 20:55:28.775022
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    path = p.user()
    assert len(path) > 0


# Generated at 2022-06-25 20:55:30.465348
# Unit test for constructor of class Path
def test_Path():
    Path()



# Generated at 2022-06-25 20:55:31.694163
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())


# Generated at 2022-06-25 20:55:40.843223
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    path_1 = Path('linux')
    path_2 = Path('darwin')
    path_3 = Path('win32')
    path_4 = Path('win64')

    assert path_0.platform is sys.platform
    assert isinstance(path_0._pathlib_home, PureWindowsPath)

    assert path_1.platform == 'linux'
    assert isinstance(path_1._pathlib_home, PurePosixPath)

    assert path_2.platform == 'darwin'
    assert isinstance(path_2._pathlib_home, PurePosixPath)

    assert path_3.platform == 'win32'
    assert isinstance(path_3._pathlib_home, PureWindowsPath)

    assert path_4.platform == 'win64'

# Generated at 2022-06-25 20:55:41.504286
# Unit test for constructor of class Path
def test_Path():
    test_case_0()

# Generated at 2022-06-25 20:55:51.383569
# Unit test for method user of class Path

# Generated at 2022-06-25 20:55:55.887985
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    for _ in range(10):
        path_1.user()


# Generated at 2022-06-25 20:56:03.864226
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()

# Generated at 2022-06-25 20:56:06.054448
# Unit test for method user of class Path
def test_Path_user():
    test_path = Path()
    test_result = test_path.user()
    assert isinstance(test_result, str)


# Generated at 2022-06-25 20:56:08.814744
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    str_user = path_0.user()
    print("User : ", str_user)
    assert str_user == '/home/taneka'


# Generated at 2022-06-25 20:56:10.391065
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/oretha'


# Generated at 2022-06-25 20:56:12.367419
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert type(path_0.user()) is str


# Generated at 2022-06-25 20:56:14.504190
# Unit test for method user of class Path
def test_Path_user():
    for x in range(0, 10):
        path_1 = Path()
        value = path_1.user()
        print(value)



# Generated at 2022-06-25 20:56:21.626491
# Unit test for method user of class Path
def test_Path_user():
    '''
    Randomly chosen user paths
    "user": {
                "linux": "/home/felipa",
                "darwin": "/Users/kim",
                "win32": "C:\\Users\\jeannetta",
                "win64": "C:\\Users\\lizzette"
            }
    '''
    path_0 = Path('linux')
    assert path_0.user() in ["/home/felipa", "/home/felipa", "/home/felipa"]
    assert path_0.user() in ["/home/felipa", "/home/felipa", "/home/felipa"]
    path_1 = Path('darwin')

# Generated at 2022-06-25 20:56:23.586945
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())
    print(p.user())
    print(p.user())
    print(p.user())
    print(p.user())
