

# Generated at 2022-06-25 20:55:19.708829
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() != path_0.user()


# Generated at 2022-06-25 20:55:22.365125
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()
    #assert path_0.user() != ''
    assert path_0.user() != None
    assert len(path_0.user()) != 0
    assert type(path_0.user()) == str


# Generated at 2022-06-25 20:55:31.565071
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path()
    assert path_1.platform == "linux"
    assert path_1._pathlib_home == PurePosixPath('home')
    path_2 = Path(platform="win32")
    assert path_2.platform == "win32"
    assert path_2._pathlib_home == PureWindowsPath('home')
    path_3 = Path(platform="win64")
    assert path_3.platform == "win64"
    assert path_3._pathlib_home == PureWindowsPath('home')
    path_4 = Path(platform="darwin")
    assert path_4.platform == "darwin"
    assert path_4._pathlib_home == PurePosixPath('home')
    # Test that it fail with any other platform

# Generated at 2022-06-25 20:55:38.005873
# Unit test for constructor of class Path
def test_Path():
    """
    This function is used to test methods in the class Path
    """
    # Test constructor of class Path
    path_0 = Path("linux")
    assert path_0.platform == "linux"
    path_0 = Path("darwin")
    assert path_0.platform == "darwin"
    path_0 = Path("win32")
    assert path_0.platform == "win32"
    path_0 = Path("win64")
    assert path_0.platform == "win64"


# Generated at 2022-06-25 20:55:39.724310
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == path_0.user()


# Generated at 2022-06-25 20:55:40.998520
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert path_0.platform == sys.platform, 'path_0 has invalid platform'

# Generated at 2022-06-25 20:55:42.314388
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    path_1 = Path(platform='win32')
    path_2 = Path(platform='win64')


# Generated at 2022-06-25 20:55:47.848835
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert path_0.platform == 'win64'
    assert path_0._pathlib_home == 'C:\\Users'
    path_1 = Path('linux')
    assert path_1.platform == 'linux'
    assert path_1._pathlib_home == '/home'
    path_2 = Path('win32')
    assert path_2.platform == 'win32'
    assert path_2._pathlib_home == 'C:\\Users'


# Generated at 2022-06-25 20:55:50.072398
# Unit test for constructor of class Path
def test_Path():
    assert path_0.platform == 'linux'
    assert path_0._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-25 20:55:51.227095
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user = path_0.user()
    assert user != ""
