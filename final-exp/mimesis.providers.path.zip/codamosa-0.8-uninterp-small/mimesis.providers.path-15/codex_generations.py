

# Generated at 2022-06-25 20:55:19.670535
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result = path_0.user()
    assert result == '/home/latashia'


# Generated at 2022-06-25 20:55:30.873569
# Unit test for method user of class Path
def test_Path_user():
    """Test user method of class Path"""

# Generated at 2022-06-25 20:55:34.811665
# Unit test for method user of class Path
def test_Path_user():
    test_path = Path()
    test_path._set_seed(1)
    assert test_path.user() == '/home/morgan'


# Generated at 2022-06-25 20:55:36.480981
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/samatha'


# Generated at 2022-06-25 20:55:37.707788
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() != ''


# Generated at 2022-06-25 20:55:40.559277
# Unit test for method user of class Path
def test_Path_user():
    def foo(n):
        path_foo = Path()
        print(path_foo.user())
        if path_foo.user() not in USERNAMES:
            print(path_foo.user())
    foo(100)


# Generated at 2022-06-25 20:55:42.614182
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == "/home/fredia"


# Generated at 2022-06-25 20:55:43.770052
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in USERNAMES


# Generated at 2022-06-25 20:55:45.125534
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())



# Generated at 2022-06-25 20:55:50.542522
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert isinstance(path_0, Path)



# Generated at 2022-06-25 20:55:54.635185
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()

# Generated at 2022-06-25 20:55:57.168843
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    for _ in range(10):
        path_0.user()


# Generated at 2022-06-25 20:55:58.529158
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert (path.root() == '/')



# Generated at 2022-06-25 20:55:59.435343
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform == sys.platform


# Generated at 2022-06-25 20:56:00.554513
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)


# Generated at 2022-06-25 20:56:03.806328
# Unit test for method user of class Path
def test_Path_user():
    # Arrange
    path = Path()

    # Act
    results = [path.user() for _ in range(10)]

    # Assert
    for result in results:
        assert isinstance(result, str)


# Generated at 2022-06-25 20:56:06.916650
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path()
    assert path_1.platform == 'linux'

    path_2 = Path('win64')
    assert path_2.platform == 'win64'



# Generated at 2022-06-25 20:56:08.453161
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/julianna'

# Generated at 2022-06-25 20:56:15.304825
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    # test paths
    assert path_0.root() != path_0.home()
    assert path_0.user() != path_0.users_folder()
    assert path_0.users_folder() != path_0.dev_dir()
    assert path_0.dev_dir() != path_0.project_dir()
    # test common paths
    assert path_0.home() != path_0.root()
    assert path_0.users_folder() != path_0.project_dir()
    assert path_0.dev_dir() != path_0.root()

# Generated at 2022-06-25 20:56:16.060696
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
