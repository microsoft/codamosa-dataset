

# Generated at 2022-06-25 20:55:21.106522
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() in ['/home/dale', '/home/karisa', '/home/danae', '/home/jeramie', '/home/rhona']


# Generated at 2022-06-25 20:55:21.994942
# Unit test for constructor of class Path
def test_Path():
    path_object = Path(platform="win32")



# Generated at 2022-06-25 20:55:23.463860
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() is not None


# Generated at 2022-06-25 20:55:29.082372
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() in ('/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika', '/home/yasmine', '/home/antoinette', '/home/renaldo', '/home/lorenza', '/home/jacinta', '/home/jami')


# Generated at 2022-06-25 20:55:30.812975
# Unit test for constructor of class Path
def test_Path():
    a = Path()
    assert a is not None


# Generated at 2022-06-25 20:55:33.289808
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()

    assert isinstance(path_0.user(), str)

    return


# Generated at 2022-06-25 20:55:35.431274
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert "home" in path_0.user()
    assert len(path_0.user()) > 5


# Generated at 2022-06-25 20:55:36.973512
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)


# Generated at 2022-06-25 20:55:40.257080
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert type(path.home()) == str
    assert type(path.root()) == str
    assert type(path.user()) == str
    assert type(path.users_folder()) == str
    assert type(path.dev_dir()) == str
    assert type(path.project_dir()) == str

# Generated at 2022-06-25 20:55:40.845532
# Unit test for constructor of class Path
def test_Path():
    assert Path()

# Generated at 2022-06-25 20:55:45.644910
# Unit test for method user of class Path
def test_Path_user():
   print("\nTest - Path.user()")
   path_0 = Path()
   print("Random choice from : " + str(USERNAMES))
   print("Example : " + path_0.user())


# Generated at 2022-06-25 20:55:47.067009
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/douglass'


# Generated at 2022-06-25 20:55:49.132288
# Unit test for method user of class Path
def test_Path_user():
    # Instantiate the class
    path_0 = Path()
    # Check that the method is of the expected type
    assert isinstance(path_0.user(), str)


# Generated at 2022-06-25 20:55:50.963378
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    result = p.user()
    assert isinstance(result, str) and \
        len(result) > 2 and '/' in result

# Generated at 2022-06-25 20:55:53.040108
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()
    path_2 = Path()
    for i in range(4):
        path_0.user() == path_1.user() == path_2.user()



# Generated at 2022-06-25 20:55:58.411267
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == "/home/julianne"
    path_1 = Path()
    assert path_1.user() == "/home/rebecka"


# Generated at 2022-06-25 20:55:59.635326
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)


# Generated at 2022-06-25 20:56:00.746914
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in USERNAMES


# Generated at 2022-06-25 20:56:01.807700
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user()


# Generated at 2022-06-25 20:56:02.872180
# Unit test for method user of class Path
def test_Path_user():
    assert len(Path().user()) > 0


# Generated at 2022-06-25 20:56:06.201319
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/lazaro'


# Generated at 2022-06-25 20:56:09.516948
# Unit test for method user of class Path
def test_Path_user():
    # Unit test for method user of class Path
    path_0 = Path()
    # Testing...
    print(path_0.user())

##    result = path_0.user()
##    assert(result in USERNAMES)
##    
##    assert True


# Generated at 2022-06-25 20:56:11.609770
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == str(Path()._pathlib_home / 'Bethany')


# Generated at 2022-06-25 20:56:12.832658
# Unit test for method user of class Path
def test_Path_user():
    value = Path().user()
    assert isinstance(value, str)


# Generated at 2022-06-25 20:56:14.015777
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user()


# Generated at 2022-06-25 20:56:14.951980
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == "/home/oretha"


# Generated at 2022-06-25 20:56:17.148381
# Unit test for method user of class Path
def test_Path_user():
    # arrange
    path = Path()
    expected = '/home/florencio'

    # act
    actual = path.user()

    # assert
    assert actual == expected


# Generated at 2022-06-25 20:56:18.817830
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.random.choice(USERNAMES)
    user = user.capitalize()
    assert path.user() == '/home/' + user + '/'


# Generated at 2022-06-25 20:56:20.115163
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:56:28.565653
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.random.seed(0)
    user_0 = path_0.user()
    assert user_0 == "\\home\\jaylon"

    path_1 = Path()
    path_1.random.seed(1)
    user_1 = path_1.user()
    assert user_1 == "\\home\\shakira"

    path_2 = Path()
    path_2.random.seed(2)
    user_2 = path_2.user()
    assert user_2 == "\\home\\pablo"

    path_3 = Path()
    path_3.random.seed(3)
    user_3 = path_3.user()
    assert user_3 == "\\home\\francisco"

    path_4 = Path()

# Generated at 2022-06-25 20:56:38.522905
# Unit test for method user of class Path
def test_Path_user():
    import os
    import re
    import unittest

    dirname = "test_Path_user"

    def cleanup():
        try:
            os.rmdir(dirname)
        except:
            return

    class Test(unittest.TestCase):
        def test_user_0(self):
            path = Path()
            user = path.user()
            m = re.search('/home/.*', user)
            self.assertTrue(m)

    # cleanup()
    # os.mkdir(dirname)
    # os.chdir(dirname)
    unittest.main(verbosity=2)
    # cleanup()

# Generated at 2022-06-25 20:56:40.878205
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()
    assert path_0.user() != ''
    assert path_0.user() != None


# Generated at 2022-06-25 20:56:42.063524
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()



# Generated at 2022-06-25 20:56:43.868356
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result = path_0.user()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:56:46.290872
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    expected_result_0 = '/home/oretha'
    result_0 = path_0.user()
    assert result_0 == expected_result_0


# Generated at 2022-06-25 20:56:47.994827
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    pth = path_0.user()
    assert pth != ""

# Generated at 2022-06-25 20:56:48.995160
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for _ in range(100):
        assert type(path.user()) == str


# Generated at 2022-06-25 20:56:50.595155
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert path_1.user() in ['\\home\\oretha', '/home/oretha']


# Generated at 2022-06-25 20:56:51.547747
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/jenni'


# Generated at 2022-06-25 20:56:52.431786
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())
