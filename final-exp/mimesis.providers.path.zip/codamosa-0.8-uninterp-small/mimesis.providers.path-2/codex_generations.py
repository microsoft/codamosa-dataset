

# Generated at 2022-06-25 20:55:18.460873
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()



# Generated at 2022-06-25 20:55:19.774156
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0_str = path_0.user()

# Generated at 2022-06-25 20:55:21.993712
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    results = [path.user() for _ in range(10)]
    home_dir = path.home()
    for result in results:
        assert home_dir in result


# Generated at 2022-06-25 20:55:23.146704
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())


# Generated at 2022-06-25 20:55:25.768414
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform


# Generated at 2022-06-25 20:55:27.003763
# Unit test for method user of class Path
def test_Path_user():
    assert  Path.user(Path()) == Path().user()


# Generated at 2022-06-25 20:55:30.313242
# Unit test for constructor of class Path
def test_Path():
    path = Path('win32')
    assert str(path._pathlib_home) == r'C:\Users'
    path = Path('linux')
    assert str(path._pathlib_home) == '/home'
    path = Path()
    assert str(path._pathlib_home) == '/home'


# Generated at 2022-06-25 20:55:34.809176
# Unit test for method user of class Path
def test_Path_user():
    assert Path()._pathlib_home.parent == PurePosixPath('/')
    assert Path('win32')._pathlib_home.parent == PureWindowsPath('C:/')


# Generated at 2022-06-25 20:55:37.186194
# Unit test for method user of class Path
def test_Path_user():
    """Test Path user method"""
    test_path = Path()
    test_result = test_path.user()
    assert isinstance(test_result, str)


# Generated at 2022-06-25 20:55:39.847841
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    random_user = path_0.user()
    assert random_user.startswith(path_0.home())
    assert len(random_user.split(path_0.home())) == 2