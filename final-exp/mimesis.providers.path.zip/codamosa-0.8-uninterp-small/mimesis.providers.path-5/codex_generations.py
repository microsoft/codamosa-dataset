

# Generated at 2022-06-25 20:55:19.670618
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/oretha'



# Generated at 2022-06-25 20:55:25.716378
# Unit test for method user of class Path
def test_Path_user():
    users = ['dovie', 'rosella', 'porsha', 'laree', 'dana', 'mayola',
             'wilhemina', 'toshia', 'eden', 'mandy', 'natisha', 'neomi',
             'bryon', 'lorine', 'tyrel', 'tonja', 'kris', 'vivien',
             'yessenia', 'mia', 'davida', 'lynsey', 'elene', 'victoria',
             'amado', 'tonie', 'revonda', 'lidia', 'ernestine', 'jodie',
             'richie', 'jamika']
    test_0 = Path()
    for i in range(50):
        assert(test_0.user() in users)


# Generated at 2022-06-25 20:55:29.822059
# Unit test for method user of class Path
def test_Path_user():
    
    path_0 = Path()
    path_user = path_0.user()

    # test if path_user is well formated
    assert str.startswith(path_user, '/home/')
    parts = path_user.split('/')
    assert len(parts) == 3
    assert path_user.endswith(parts[-1])
    


# Generated at 2022-06-25 20:55:31.406761
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert 'oretha' in path_0.user()


# Generated at 2022-06-25 20:55:33.386761
# Unit test for constructor of class Path
def test_Path():
    test_case_0()

# Test for root() method

# Generated at 2022-06-25 20:55:35.042381
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()


# Generated at 2022-06-25 20:55:37.241028
# Unit test for method user of class Path
def test_Path_user():
    test_obj = Path()
    test_result = test_obj.user()
    assert isinstance(test_result, str)


# Generated at 2022-06-25 20:55:38.146659
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()



# Generated at 2022-06-25 20:55:39.581952
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert not 'mimesis' in path_0.user()


# Generated at 2022-06-25 20:55:45.416386
# Unit test for constructor of class Path
def test_Path():

    path_1 = Path()
    if path_1.platform != sys.platform:
        raise Exception('test_Path: path_1.platform: ' + path_1.platform +
                        ' != sys.platform: ' + sys.platform)

    path_2 = Path('win32')
    if path_2.platform != 'win32':
        raise Exception('test_Path: path_2.platform: ' + path_2.platform +
                        ' != "win32"')

    path_3 = Path('win64')
    if path_3.platform != 'win64':
        raise Exception('test_Path: path_3.platform: ' + path_3.platform +
                        ' != "win64"')

    path_4 = Path('linux')

# Generated at 2022-06-25 20:55:50.357627
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user = path_0.user()
    assert isinstance(user, str)
    assert isinstance(user, str)
    assert isinstance(user, str)
    assert isinstance(user, str)
    assert isinstance(user, str)
    assert isinstance(user, str)


# Generated at 2022-06-25 20:55:52.106245
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    u = path_0.user()
    assert isinstance(u, str)
    assert u.startswith("/home")


# Generated at 2022-06-25 20:55:57.618200
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    # Assert that the string contains a forward slash and a character
    assert re.search(re.compile(r'\/\w+'), path_0.user()) is not None


# Generated at 2022-06-25 20:55:59.242090
# Unit test for method user of class Path
def test_Path_user():
    new_instance = Path()
    assert new_instance.user() == '/home/marcellus'


# Generated at 2022-06-25 20:56:05.867183
# Unit test for method user of class Path
def test_Path_user():
    assert [Path().user() for i in range(10)] == [
        '/home/edna',
        '/home/gema',
        '/home/pat',
        '/home/pat',
        '/home/pat',
        '/home/pat',
        '/home/pat',
        '/home/pat',
        '/home/pat',
        '/home/pat',
    ]
    assert [Path().user() for i in range(10)] == [
        '/home/marget',
        '/home/taneka',
        '/home/coretta',
        '/home/coretta',
        '/home/coretta',
        '/home/coretta',
        '/home/coretta',
        '/home/coretta',
        '/home/coretta',
        '/home/coretta',
    ]

# Generated at 2022-06-25 20:56:07.986673
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()
    assert path_0.user() == path_1.user()


# Generated at 2022-06-25 20:56:08.853894
# Unit test for method user of class Path
def test_Path_user():
    assert len(Path().user())


# Generated at 2022-06-25 20:56:09.984991
# Unit test for method user of class Path
def test_Path_user():
    with pytest.raises(NotImplementedError):
        Path().user()

# Generated at 2022-06-25 20:56:13.149941
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() in USERNAMES

if __name__ == "__main__":
    try:
        test_Path_user()
    except:
        pass

# Generated at 2022-06-25 20:56:15.149999
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert (path_0.user() != path_0.user())
    assert (isinstance(path_0.user(),str))


# Generated at 2022-06-25 20:56:27.627597
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path(platform='win32')
    path_0 = Path('win32')
    path_0 = Path()
    path_0.user()
    for i in range(100):
        # check root
        assert path_0._pathlib_home.parent == PureWindowsPath('/')
        assert isinstance(path_0._pathlib_home, PureWindowsPath)
        # check home
        assert path_0._pathlib_home == PureWindowsPath('/home')
        assert isinstance(path_0._pathlib_home, PureWindowsPath)
        # check user
        assert isinstance(path_0.user(), str)
        assert isinstance(path_0._pathlib_home, PureWindowsPath)
        # check users_folder
        assert isinstance(path_0.users_folder(), str)

# Generated at 2022-06-25 20:56:29.515941
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    print(path_0.user())


# Generated at 2022-06-25 20:56:30.656857
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() != 'anjelica'


# Generated at 2022-06-25 20:56:31.777039
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert type(path_0.user()) == str

# Generated at 2022-06-25 20:56:34.824383
# Unit test for method user of class Path
def test_Path_user():
    # Create instance of class Path
    path_0 = Path()
    # Get path from function user of class Path
    result = path_0.user()
    # Assert result is instance of class PurePosixPath
    assert isinstance(result,str)


# Generated at 2022-06-25 20:56:36.929993
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)
    assert len(str(path_0.user())) > 0
    

# Generated at 2022-06-25 20:56:39.791994
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    paths = [p.user() for i in range(1000)]
    assert all([isinstance(path,str) for path in paths])
    assert len(set(paths)) >= len(paths) // 2


# Generated at 2022-06-25 20:56:48.373756
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    # Unit test for method home of class Path
    test_case_0_expected = '/home/eldora'
    test_case_0_given = path_0.user()
    assert test_case_0_expected == test_case_0_given
    test_case_1_expected = '/home/cammy'
    test_case_1_given = path_0.user()
    assert test_case_1_expected == test_case_1_given
    test_case_2_expected = '/home/linsey'
    test_case_2_given = path_0.user()
    assert test_case_2_expected == test_case_2_given
    test_case_3_expected = '/home/eldora'
    test_case_3_given = path_0

# Generated at 2022-06-25 20:56:50.285066
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert (path_0.user().endswith(path_0.random.choice(USERNAMES).lower())) 


# Generated at 2022-06-25 20:56:55.671371
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == "/home/julie"
    assert path_0.user() == "/home/daphine"
    assert path_0.user() == "/home/lian"
    assert path_0.user() == "/home/matthew"
    assert path_0.user() == "/home/tommy"
    assert path_0.user() == "/home/thomas"
    assert path_0.user() == "/home/shannon"
    assert path_0.user() == "/home/kristi"
    assert path_0.user() == "/home/christopher"
    assert path_0.user() == "/home/david"

