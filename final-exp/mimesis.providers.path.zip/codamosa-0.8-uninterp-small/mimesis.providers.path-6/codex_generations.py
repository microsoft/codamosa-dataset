

# Generated at 2022-06-25 20:55:20.185312
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform='linux')
    dir_path = ["/root", "/", "/usr"]
    path_value = path.root()
    assert path_value not in dir_path
    assert path_value not in dir_path

# Generated at 2022-06-25 20:55:26.149201
# Unit test for method user of class Path
def test_Path_user():
    '''
    Tests single call of method user of class Path
    '''
    #Initialize required variable
    path = Path()
    #Perform Single Call
    result = path.user()
    #Assert result
    assert isinstance(result, str)

# Generated at 2022-06-25 20:55:27.724158
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(type(path.user()))
    print(path.user())


# Generated at 2022-06-25 20:55:29.493129
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    str_0 = path_0.user()
    assert str_0 == '/home/clelia'

# Generated at 2022-06-25 20:55:35.519304
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    # TODO: check if path_0 is instance of str or pathlib.Path
    str_0 = path_0.project_dir()
    path_1 = Path()
    str_1 = path_1.project_dir()
    print("str_0",str_0)
    print("str_1",str_1)
    assert str_0 != str_1

# Generated at 2022-06-25 20:55:42.547624
# Unit test for constructor of class Path
def test_Path():
    # Creates Path object
    path_1 = Path()
    # Creates Path object
    path_2 = Path()
    # Asserts that path_1 has a different object identity than path_2
    assert path_1 is not path_2
    # Asserts that both objects have the same class Path
    assert type(path_1) == type(path_2)
    # Asserts that both objects have the same class name "Path"
    assert path_1.__class__.__name__ == path_2.__class__.__name__
    # Asserts that the class of path_1 has the same class name "Path"
    assert Path.__name__ == path_1.__class__.__name__

# Generated at 2022-06-25 20:55:44.331439
# Unit test for method user of class Path
def test_Path_user():
    test_0 = Path().user()
    assert len(test_0) > 0, 'method user of class Path has not worked'


# Generated at 2022-06-25 20:55:46.300586
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    str_0 = path_0.user()
    assert str_0 == 'Users/'


# Generated at 2022-06-25 20:55:48.706161
# Unit test for constructor of class Path
def test_Path():
    path_ = Path()
    path_str = path_.project_dir()

    assert (isinstance(path_, Path))
    assert (isinstance(path_str, str))


# Generated at 2022-06-25 20:55:49.721945
# Unit test for constructor of class Path
def test_Path():
    try:
        test_case_0()
        test_case_1()
    except:
        assert False

# Generated at 2022-06-25 20:55:56.514501
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    for i in range(100):
        assert type(path_0.user()) is str


# Generated at 2022-06-25 20:56:01.416146
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p.Meta.name, str)
    assert isinstance(p.Meta.name, str)
    assert (p._pathlib_home.parent)
    assert (p._pathlib_home)
    assert (p.home())
    assert (p.user())
    assert (p.users_folder())
    assert (p.dev_dir())
    assert (p.project_dir())

# Generated at 2022-06-25 20:56:02.768902
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert isinstance(path_1.user(), str)


# Generated at 2022-06-25 20:56:04.786484
# Unit test for method user of class Path
def test_Path_user():
    path_object = Path()
    user = path_object.user()
    assert isinstance(user, str)


# Generated at 2022-06-25 20:56:11.173610
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert "Path" == path.Meta.name
    assert pathTester(path.root(), '/')
    assert pathTester(path.home(), '/home')
    assert pathTester(path.dev_dir(), '/home/arnita/Development/Python')
    assert pathTester(path.project_dir(), '/home/arnita/Development/Python/dichroic')
    assert pathTester(path.users_folder(), '/home/arnita/Pictures')


# Generated at 2022-06-25 20:56:12.532545
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-25 20:56:16.731239
# Unit test for constructor of class Path
def test_Path():
    assert (Path.root()=='/')
    assert (Path.home()=='/home')
    assert (Path.user()==Path.home())
    assert (Path.users_folder()==(Path.home()+'/'+Path.random.choice(FOLDERS)))
    assert (Path.dev_dir()==(Path.home()+'/'+Path.random.choice(['Development', 'Dev'])+'/'+Path.random.choice(PROGRAMMING_LANGS)))
    assert (Path.project_dir()==(Path.home()+'/'+Path.random.choice(['Development', 'Dev'])+'/'+Path.random.choice(PROJECT_NAMES)))
    print('Unit Test Passed.')

# Main Function

# Generated at 2022-06-25 20:56:18.090791
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    r = p.user()
    assert r is not None


# Generated at 2022-06-25 20:56:23.327813
# Unit test for method user of class Path
def test_Path_user():
    # Test 1:
    path_0 = Path()
    t = 0
    for i in range(1, 1000):
        d = path_0.user()
        if (
            d == '/home/oretha' or d == 'C:\\Users\\oretha'
            or d == '/home/taneka' or d == 'C:\\Users\\taneka'
            or d == '/home/sherrell' or d == 'C:\\Users\\sherrell'
            or d == '/home/sherika' or d == 'C:\\Users\\sherika'
        ):
            t += 1
    assert t <= 100


# Generated at 2022-06-25 20:56:27.073758
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None
    assert path.platform is not None
    assert path.random is not None
    assert path._pathlib_home is not None


# Generated at 2022-06-25 20:56:32.603745
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert  '/home/%s' % p.random.choice(USERNAMES) in p.user()


# Generated at 2022-06-25 20:56:33.743295
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:56:35.218265
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    res = path_0.user()
    print(res)


# Generated at 2022-06-25 20:56:36.379074
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert(path is not None)



# Generated at 2022-06-25 20:56:37.521337
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-25 20:56:46.016861
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()

# Generated at 2022-06-25 20:56:48.336316
# Unit test for constructor of class Path
def test_Path():
    # Here we create an object of class Path
    path_0 = Path()
    assert isinstance(path_0, Path)
    assert isinstance(path_0, BaseProvider)

# Generated at 2022-06-25 20:56:49.098548
# Unit test for constructor of class Path
def test_Path():
    assert(Path()) is not None


# Generated at 2022-06-25 20:56:51.458688
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in [str(x) for x in Path()._pathlib_home.iterdir()] \
        if 'win' in Path().platform \
        else Path().user() in str(Path()._pathlib_home)

# Generated at 2022-06-25 20:56:52.935533
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() not in ['/home/nikia', '/home/beverlee']
    

# Generated at 2022-06-25 20:57:05.443969
# Unit test for constructor of class Path
def test_Path():
    pth = Path(platform='linux')

    assert pth.home() == '/home'
    assert pth.root() == '/'
    assert pth.user() == '/home/isaura'
    assert pth.users_folder() == '/home/fredia/Pictures'
    assert pth.dev_dir() == '/home/larita/Development/Scala'
    assert pth.project_dir() == '/home/larita/Development/Scala/project_name'

# Generated at 2022-06-25 20:57:06.570492
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert(path_0.platform in PLATFORMS.keys())


# Generated at 2022-06-25 20:57:08.184583
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    assert isinstance(path_0, Path)


# Generated at 2022-06-25 20:57:09.176584
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user()


# Generated at 2022-06-25 20:57:14.680738
# Unit test for constructor of class Path
def test_Path():
    # Constructor call
    path = Path()
    # Check for method home
    assert path.home()
    # Check for method root
    assert path.root()
    # Check for method user
    assert path.user()
    # Check for method users_folder
    assert path.users_folder()
    # Check for method dev_dir
    assert path.dev_dir()
    # Check for method project_dir
    assert path.project_dir()


# Test module
if __name__ == '__main__':
    test_case_0()
    test_Path()

# Generated at 2022-06-25 20:57:16.084625
# Unit test for constructor of class Path
def test_Path():
    p1 = Path()
    assert p1.platform == "linux"

# Generated at 2022-06-25 20:57:20.241138
# Unit test for constructor of class Path
def test_Path():
    from mimesis.enums import Platform
    from pytest import raises
    for case in [
        # Test case for constructor of class Path
        (
            'Error: case for constructor of class Path',
            # args
            {
                'platform': None
            },
            # expected
            raises(ValueError)
        )
    ]:
        yield run_case, case



# Generated at 2022-06-25 20:57:21.655328
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    val = path.user()
    assert isinstance(val, str) == True


# Generated at 2022-06-25 20:57:30.623787
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    print("path_0.Meta.name = " + path_0.Meta.name)
    print("path_0.Meta.pretty_name = " + path_0.Meta.pretty_name)
    print("path_0.random = " + str(path_0.random))
    print("path_0.platform = " + path_0.platform)
    print("path_0._pathlib_home = " + str(path_0._pathlib_home))
    print("path_0.root() = " + path_0.root())
    print("path_0.home() = " + path_0.home())
    print("path_0.user() = " + path_0.user())
    print("path_0.users_folder() = " + path_0.users_folder())

# Generated at 2022-06-25 20:57:33.311069
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert_0 = path_0.user()
    assert assert_0.startswith('/home')
    assert assert_0.endswith('/')
    assert len(assert_0) > 6


# Generated at 2022-06-25 20:57:54.446974
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)


# Generated at 2022-06-25 20:57:58.378489
# Unit test for method user of class Path
def test_Path_user():

    p = Path()

    # The length of the path should be greater than or equal to 5
    assert(len(p.user()) >= 5)

    # The path must contain the home directory
    assert(p.home() in p.user())

    # The path must end with the username
    assert(p.user().split('/')[-1] in p.user())


# Generated at 2022-06-25 20:57:59.650751
# Unit test for method user of class Path
def test_Path_user():
   path_0 = Path()
   result = path_0.user()
   assert len(result) > 0


# Generated at 2022-06-25 20:58:07.344029
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    username_0 = path_0.random.choice(USERNAMES)
    username_1 = path_0.random.choice(USERNAMES)
    path_0._pathlib_home /= username_0
    path_1 = Path()
    path_1._pathlib_home /= username_1
    user_0 = path_0.user()
    user_1 = path_1.user()
    assert user_0 == username_0
    assert user_1 == username_1

# Generated at 2022-06-25 20:58:08.337352
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_1.user()


# Generated at 2022-06-25 20:58:10.521871
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    # Check type just for method user
    assert isinstance(path_0.user(), str)


# Generated at 2022-06-25 20:58:11.538294
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_0.user()


# Generated at 2022-06-25 20:58:14.275369
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)
    assert path_0.user() != ''
    assert len(path_0.user()) > 0
    assert path_0.user().endswith('/') == False


# Generated at 2022-06-25 20:58:15.207946
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in ('/Users/oretha','/home/oretha')

# Generated at 2022-06-25 20:58:16.289813
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/laural'


# Generated at 2022-06-25 20:58:55.161843
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in [
        '/home/michaela',
        '/home/deedee',
        '/home/latasha',
        '/home/lashon',
        '/home/corey',
        '/home/cordelia',
        '/home/jody',
        '/home/tana',
        '/home/tisha',
        '/home/tamra',
    ]

# Generated at 2022-06-25 20:58:57.574728
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/root'


# Generated at 2022-06-25 20:58:58.964029
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)


# Generated at 2022-06-25 20:59:01.710735
# Unit test for method user of class Path
def test_Path_user():
    for _ in range(100):
        path_0 = Path()
        user_0 = path_0.user()
        pos_1 = user_0.rfind('/')
        user_1 = user_0[pos_1:]
        print(user_1)
        print(user_1[1:])
        assert user_1[1:].lower() in USERNAMES


# Generated at 2022-06-25 20:59:02.874727
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    assert user_0 == '/home/joshua'


# Generated at 2022-06-25 20:59:05.546579
# Unit test for method user of class Path
def test_Path_user():
    for i in range(100):
        a=Path()
        b=a.user()
        assert isinstance(b, str)


# Generated at 2022-06-25 20:59:06.706015
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()


# Generated at 2022-06-25 20:59:08.573176
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    paths = set()
    for count in range(1000):
        paths.add(path_1.user())
    assert(len(paths) == len(USERNAMES)) # Check for collision


# Generated at 2022-06-25 20:59:16.114204
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    test_case_0()

# Generated at 2022-06-25 20:59:17.985548
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random = True
    path.seed = 0
    assert path.user() == '/home/oretha'
