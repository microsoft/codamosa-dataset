

# Generated at 2022-06-25 20:55:21.619913
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    path_1 = Path()
    user_1 = path_1.user()
    assert user_0 != user_1


# Generated at 2022-06-25 20:55:25.606029
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()

    path_user_0 = path_0.user()
    path_user_1 = path_0.user()
    path_user_2 = path_0.user()



# Generated at 2022-06-25 20:55:27.176489
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert isinstance(path_0.user(), str)



# Generated at 2022-06-25 20:55:31.390175
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    out = path.user()
    
    try:
        assert type(out) is str
    except AssertionError:
        print(
            'Failed: test_Path_user: generate a random user.\n'
            f'Expecting "str", got "{type(out)}".')
    else:
        print(
            'Passed: test_Path_user: generate a random user.\n')


# Generated at 2022-06-25 20:55:33.804049
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0._Path__user()
    print(user_0)

# Generated at 2022-06-25 20:55:35.570501
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert path_1.user() == '/home/taneka'


# Generated at 2022-06-25 20:55:37.093301
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/juana'


# Generated at 2022-06-25 20:55:39.165219
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user, str) and 'home' in user and '/' in user


# Generated at 2022-06-25 20:55:40.545973
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert str(path.user()) == str(path._pathlib_home / 'Oretha')

# Generated at 2022-06-25 20:55:43.258675
# Unit test for method user of class Path
def test_Path_user():
    test_path = Path()
    theUser = test_path.user()
    correct_theUser = '/home/tia'
    assert theUser == correct_theUser


# Generated at 2022-06-25 20:55:48.679863
# Unit test for method user of class Path
def test_Path_user():
    # Create a Path instance
    path_0 = Path()
    # Get the user path
    assert path_0.user() == '/home/blanca'


# Generated at 2022-06-25 20:55:50.269974
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = Path()

    assert path_0.user() != path_1.user()


# Generated at 2022-06-25 20:55:51.784137
# Unit test for method user of class Path
def test_Path_user():
    # Arrange
    path = Path()

    # Act
    result = path.user()

    # Assert
    assert type(result) == str

# Generated at 2022-06-25 20:55:56.203757
# Unit test for method user of class Path
def test_Path_user():
    actual = Path().user()
    expected = '/home/oretha'
    assert actual == expected


# Generated at 2022-06-25 20:56:04.056607
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_2 = Path(platform='linux')
    path_3 = Path(platform='darwin')
    path_4 = Path(platform='win32')
    path_5 = Path(platform='win64')
    # Test user method of class Path with platform='linux'
    assert len(path_2.user()) == 13
    assert path_2.user().startswith('/home/')
    assert path_2.user().endswith('/')

# Generated at 2022-06-25 20:56:13.675734
# Unit test for method user of class Path
def test_Path_user():
    import pytest
    import unittest.mock as mock

    path_0 = Path()

    with mock.patch("mimesis.Path._Path__len_list") as mock_path_0__len_list:
        with mock.patch("mimesis.Path._Path__random") as mock_path_0__random:
            with mock.patch("mimesis.Path.random") as mock_path_0_random:
                with mock.patch("mimesis.BaseProvider.random") as mock_path_0_BaseProvider_random:
                    with mock.patch("mimesis.Path.__init__") as mock_path_0___init__:
                        assert path_0.user() == "/home/Claudelle"
                        assert mock_path_0__len_list.call_count == 0
                        assert mock_path

# Generated at 2022-06-25 20:56:15.044789
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/taneka'


# Generated at 2022-06-25 20:56:16.971095
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(
        p.user(),
        str
    )
    assert len(p.user()) > 0


# Generated at 2022-06-25 20:56:17.948727
# Unit test for method user of class Path
def test_Path_user():
    result = Path().user()
    assert(type(result) == str)


# Generated at 2022-06-25 20:56:19.264242
# Unit test for method user of class Path
def test_Path_user():
    with Path() as path:
        result = path.user()
    assert isinstance(result, str)
