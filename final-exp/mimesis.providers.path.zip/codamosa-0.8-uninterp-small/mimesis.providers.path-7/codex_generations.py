

# Generated at 2022-06-25 20:55:21.227578
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    assert path_0.user() == '/home/oretha'


# Generated at 2022-06-25 20:55:30.038725
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = path_0
    path_2 = path_0

    # Case 0
    path_0.random = lambda: 0.0
    result_0 = path_0.user()
    assert result_0 == '/home/brittani'

    # Case 1
    path_1.random = lambda: 0.2
    result_1 = path_1.user()
    assert result_1 == '/home/ciara'

    # Case 2
    path_2.random = lambda: 0.4
    result_2 = path_2.user()
    assert result_2 == '/home/margaret'



# Generated at 2022-06-25 20:55:30.937933
# Unit test for method user of class Path
def test_Path_user():
    user_0 = Path().user()


# Generated at 2022-06-25 20:55:33.749027
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path()
    assert path_1.platform != None
    assert path_1._pathlib_home != None


# Generated at 2022-06-25 20:55:35.516868
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    assert path_1.user() == '/home/oretha'


# Generated at 2022-06-25 20:55:36.397990
# Unit test for constructor of class Path
def test_Path():
    assert Path() is not None


# Generated at 2022-06-25 20:55:38.510567
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()

    assert(isinstance(path_0.user(), str))
    assert(path_0.user().startswith('/home/'))


# Generated at 2022-06-25 20:55:42.152151
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in ['\\Users\\zita', '/home/oretha']
    assert Path().user() in ['\\Users\\zita', '/home/oretha']
    assert Path().user() in ['\\Users\\zita', '/home/oretha']
    assert Path().user() in ['\\Users\\zita', '/home/oretha']


# Generated at 2022-06-25 20:55:43.971690
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()

    assert isinstance(user, str)
    assert len(user) > 0

# Generated at 2022-06-25 20:55:46.569533
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print("path:")
    print("type:", type(path))
    print("home:", path.home())
    print("\n")
    return 0



# Generated at 2022-06-25 20:55:51.451293
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    path_1 = Path('linux')
    path_2 = Path('darwin')
    path_3 = Path('win32')
    path_4 = Path('win64')

    assert path_0 is not None
    assert path_1 is not None
    assert path_2 is not None
    assert path_3 is not None
    assert path_4 is not None



# Generated at 2022-06-25 20:55:56.436963
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result = path_0.user()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:55:57.347192
# Unit test for method user of class Path
def test_Path_user():
    assert (Path().user())


# Generated at 2022-06-25 20:56:04.132790
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in ['/home/carmine', '/home/louis', '/home/debra',
                             '/home/taneka', '/home/leonora', '/home/allen',
                             '/home/joshua', '/home/luci', '/home/shanika',
                             '/home/maxwell', '/home/bryant',
                             '/home/Carmine', '/home/Louis', '/home/Debra',
                             '/home/Taneka', '/home/Leonora',
                             '/home/Allen', '/home/Joshua', '/home/Luci',
                             '/home/Shanika', '/home/Maxwell',
                             '/home/Bryant']


# Generated at 2022-06-25 20:56:05.456255
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-25 20:56:07.694788
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    path_1 = path_0.user()
    assert path_1 == '/home/felice'


# Generated at 2022-06-25 20:56:08.894189
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_1.user()


# Generated at 2022-06-25 20:56:12.285322
# Unit test for constructor of class Path
def test_Path():
    path_0 = Path()
    path_1 = Path('win64')
    path_2 = Path('linux')
    path_3 = Path('win32')
    path_4 = Path('darwin')


# Generated at 2022-06-25 20:56:14.127588
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    user_0 = path_0.user()
    assert(isinstance(user_0, str))


# Generated at 2022-06-25 20:56:15.784254
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    
    user = path.user()
    user1 = path.user()

    assert user == user1
