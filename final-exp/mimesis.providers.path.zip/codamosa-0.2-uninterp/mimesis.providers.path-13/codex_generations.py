

# Generated at 2022-06-17 22:42:23.151403
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(USERNAMES) in path.user()

# Generated at 2022-06-17 22:42:28.385836
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform \
                                     else PurePosixPath()
    assert p._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:30.383030
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:35.391813
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform else PurePosixPath()
    assert path._pathlib_home == PureWindowsPath() / PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:37.160680
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:42:38.806907
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:41.287706
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:42.613340
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-17 22:42:44.336258
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:45.999548
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:51.476219
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:54.532205
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/sherika'


# Generated at 2022-06-17 22:42:57.172563
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:03.976319
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
        else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:43:08.156707
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:09.910803
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:16.086647
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']
    path = Path('win32')
    assert path.platform == 'win32'
    assert path._pathlib_home.parent == PureWindowsPath('\\')
    assert path._pathlib_home.name == PLATFORMS['win32']['home']


# Generated at 2022-06-17 22:43:20.272873
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(PLATFORMS[sys.platform]['home']) == path._pathlib_home


# Generated at 2022-06-17 22:43:23.941571
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath(PLATFORMS[sys.platform]['home'])


# Generated at 2022-06-17 22:43:25.982385
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'
