

# Generated at 2022-06-17 22:42:20.337432
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:22.537295
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:25.974971
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:27.452222
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-17 22:42:28.660452
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home != None


# Generated at 2022-06-17 22:42:30.692979
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:37.656563
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')
    path = Path('win32')
    assert path.platform == 'win32'
    assert path._pathlib_home.parent == PureWindowsPath('C:\\')
    assert path._pathlib_home == PureWindowsPath('C:\\Users')


# Generated at 2022-06-17 22:42:40.063993
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath()
    assert path._pathlib_home == PurePosixPath()


# Generated at 2022-06-17 22:42:44.264563
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()

# Generated at 2022-06-17 22:42:47.965184
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform \
                                      else PurePosixPath()
    assert p._pathlib_home.name == PLATFORMS[sys.platform]['home']
