

# Generated at 2022-06-17 22:42:20.738015
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:22.047567
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:24.310944
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:29.616249
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:34.308858
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:36.182911
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:41.544472
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:46.615800
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                            else PurePosixPath()
    assert p._pathlib_home / PLATFORMS[sys.platform]['home'] == PureWindowsPath() if 'win' in sys.platform \
                            else PurePosixPath()


# Generated at 2022-06-17 22:42:48.275807
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:49.778309
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:42:55.587422
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:58.346932
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:08.579316
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')
    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.user() == '/home/oretha'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.dev_dir() == '/home/sherrell/Development/Python'
    assert path.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-17 22:43:10.251895
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:13.938177
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform \
                                                           else PurePosixPath()
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:15.260025
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:18.066954
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:19.883329
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:23.175731
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:23.992853
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None


# Generated at 2022-06-17 22:43:31.271067
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:32.654915
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:43:38.315872
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:42.323342
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:44.539845
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:46.394701
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:51.063858
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                           else PurePosixPath()

# Generated at 2022-06-17 22:43:55.732009
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path.home()


# Generated at 2022-06-17 22:43:58.475111
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:00.910730
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'

# Generated at 2022-06-17 22:44:22.996381
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:25.526204
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:27.161563
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:29.204199
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:31.101797
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:32.506263
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:34.852320
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:44:37.184683
# Unit test for method user of class Path
def test_Path_user():
    # Test for method user of class Path
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:40.427843
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:44:41.587302
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-17 22:45:05.520301
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:08.142188
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:10.871353
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:12.488329
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:13.937200
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:15.403912
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:17.804708
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert path.user() != ''


# Generated at 2022-06-17 22:45:19.447549
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:21.004144
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:22.368704
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:04.831989
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:06.561829
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:08.104705
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:09.268695
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:10.281651
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:13.745529
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:46:15.349157
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:17.021159
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:19.220942
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:20.441739
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:44.711590
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:47:45.656063
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:47.481965
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:48.890569
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:49.986484
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:47:51.469300
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:54.553629
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:57.272734
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'

# Generated at 2022-06-17 22:47:59.831849
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:48:02.388083
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:50:51.676623
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/sherika'


# Generated at 2022-06-17 22:50:55.415826
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:50:57.845999
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:51:00.281868
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:51:02.373586
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:51:03.930170
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:51:05.389797
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:51:06.738379
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/sherika'


# Generated at 2022-06-17 22:51:08.707237
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:51:10.982802
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'
