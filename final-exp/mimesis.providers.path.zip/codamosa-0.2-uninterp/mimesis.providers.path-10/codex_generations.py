

# Generated at 2022-06-17 22:42:16.227994
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:21.137530
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                           else PurePosixPath()
    assert p._pathlib_home / PLATFORMS[sys.platform]['home'] == p._pathlib_home


# Generated at 2022-06-17 22:42:27.599059
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()

# Generated at 2022-06-17 22:42:32.672172
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:37.952366
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform \
                                                           else PurePosixPath()
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:40.006364
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-17 22:42:41.969826
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:46.310485
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                 else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:50.760462
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:42:58.001051
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                 else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:43:05.195500
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:43:07.581479
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:43:10.877763
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:43:14.178038
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:16.554885
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:19.358263
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:21.110665
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:23.558223
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:43:25.676151
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:29.543294
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:43:41.914234
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                            else PurePosixPath()

# Generated at 2022-06-17 22:43:44.179320
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:51.248892
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                               else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == \
           PureWindowsPath() / PLATFORMS[sys.platform]['home'] if 'win' in sys.platform \
           else PurePosixPath() / PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:56.354127
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == PureWindowsPath('C:\\Users') if 'win' in sys.platform else PurePosixPath('/home')


# Generated at 2022-06-17 22:43:58.899221
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:00.945180
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:09.898384
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'
    assert p.user() == '/home/oretha'

# Generated at 2022-06-17 22:44:11.376700
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:14.531141
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:44:20.050113
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p.random.choice(FOLDERS) in p.users_folder()
    assert p.random.choice(PROJECT_NAMES) in p.project_dir()
    assert p.random.choice(PROGRAMMING_LANGS) in p.dev_dir()
    assert p.random.choice(USERNAMES) in p.user()
    assert p.random.choice(FOLDERS) in p.users_folder()
    assert p.random.choice(PROJECT_NAMES) in p.project_dir()
    assert p.random.choice(PROGRAMMING_LANGS) in p.dev_dir()
    assert p.random.choice(USERNAMES) in p.user()

# Generated at 2022-06-17 22:44:39.215255
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:44:42.996635
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:44:45.534230
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                             else PurePosixPath()

# Generated at 2022-06-17 22:44:49.196062
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:44:50.660767
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:52.011624
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:54.792772
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:57.383506
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:05.230714
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                 else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:45:09.364276
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == 'home'


# Generated at 2022-06-17 22:45:41.749364
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:43.709886
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:45.403435
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:46.807414
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:48.663849
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha' or user == 'C:\\Users\\oretha'


# Generated at 2022-06-17 22:45:51.029018
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:54.271557
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:57.194382
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:46:02.283589
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:46:04.691675
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:03.323789
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:04.444678
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:05.842291
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'

# Generated at 2022-06-17 22:47:08.855019
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:10.319333
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:47:12.221926
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:47:13.847761
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:15.439316
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:16.980295
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:18.094034
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-17 22:49:13.234498
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:16.890796
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:49:18.511467
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:20.086506
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:21.676771
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:23.240610
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:24.331173
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:25.315753
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:49:26.698799
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:29.349486
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'
