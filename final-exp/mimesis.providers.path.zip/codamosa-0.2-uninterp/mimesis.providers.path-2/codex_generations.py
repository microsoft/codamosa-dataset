

# Generated at 2022-06-17 22:42:17.994317
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:42:22.836509
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()

# Generated at 2022-06-17 22:42:25.440418
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:27.266231
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:29.310874
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:33.964769
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:36.685622
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:38.046874
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-17 22:42:41.819332
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parts[0] == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:43.539278
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:50.933713
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform \
                                                       else PurePosixPath()
    assert p._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:53.114047
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:43:01.835189
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()

# Generated at 2022-06-17 22:43:04.706009
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:43:06.380495
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:08.729927
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:10.878872
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)
    assert p.user() == '/home/oretha'

# Generated at 2022-06-17 22:43:12.847145
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:14.366060
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:16.304528
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parts[0] == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:21.708349
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:25.576724
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:43:27.854183
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:31.040189
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:34.867316
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == PureWindowsPath() / PLATFORMS[sys.platform]['home'] if 'win' in sys.platform else PurePosixPath() / PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:37.289844
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:42.464357
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                             else PurePosixPath()

# Generated at 2022-06-17 22:43:50.270110
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == \
        PureWindowsPath() / PLATFORMS[sys.platform]['home'] if 'win' in sys.platform \
        else PurePosixPath() / PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:51.699752
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:55.511408
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:44:06.778403
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.parent == PurePosixPath('/')
    assert p._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:44:11.118118
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p.random.choice(FOLDERS) in p.users_folder()
    assert p.random.choice(PROJECT_NAMES) in p.project_dir()
    assert p.random.choice(PROGRAMMING_LANGS) in p.dev_dir()
    assert p.random.choice(USERNAMES) in p.user()

# Generated at 2022-06-17 22:44:16.636252
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()

# Generated at 2022-06-17 22:44:17.764324
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:19.917766
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:22.557654
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:25.902702
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:30.426321
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform \
                                                           else PurePosixPath()
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:44:32.795206
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:44:35.370970
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:54.311405
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:55.594652
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:58.113585
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:01.004991
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:04.709231
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:06.917593
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:09.412055
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:11.372501
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:12.973540
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:14.498705
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:42.250068
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:45:44.637998
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:45:45.809845
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'


# Generated at 2022-06-17 22:45:47.159544
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:48.448193
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:50.851251
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:54.009411
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:58.050820
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user in ['/home/oretha', 'C:\\Users\\oretha']


# Generated at 2022-06-17 22:46:02.052318
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:04.580844
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:02.147424
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:03.527350
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:04.804803
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:09.052914
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:47:10.482671
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:47:12.373051
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:47:14.022221
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:15.580371
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:17.701207
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:47:19.010630
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:11.479545
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:12.553412
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:13.732080
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:16.767243
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:18.384535
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:19.993128
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:22.352804
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:49:24.269773
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:25.450769
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:26.546482
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'
