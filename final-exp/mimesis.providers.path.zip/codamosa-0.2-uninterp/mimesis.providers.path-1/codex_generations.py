

# Generated at 2022-06-17 22:42:19.414655
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                               else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:22.555963
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:27.662249
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home == PureWindowsPath() if 'win' in sys.platform else PurePosixPath()
    assert p._pathlib_home == PureWindowsPath() / PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:30.813329
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(USERNAMES) in path.user()
    assert path.random.choice(FOLDERS) in path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) in path.project_dir()

# Generated at 2022-06-17 22:42:32.671858
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:35.184928
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:37.017496
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:38.686809
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:41.287558
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:43.790363
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:48.204519
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:49.678794
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:42:50.978406
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:53.191907
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:42:55.427011
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:42:58.106924
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:01.134944
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:03.591748
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:05.244650
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:07.626537
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:13.182176
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:16.046700
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:43:19.066556
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:20.822824
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:23.270816
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:43:24.932955
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:26.640548
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:28.439098
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:29.936372
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:31.499166
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:41.822028
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:44.084332
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:43:45.929984
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:47.611737
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:50.835972
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user, str)
    assert user.startswith('/home')


# Generated at 2022-06-17 22:43:53.898763
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:56.722790
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:59.255139
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:01.143319
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-17 22:44:02.782101
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:19.845880
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:44:21.629368
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-17 22:44:25.108085
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:26.798149
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:28.853853
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:30.459976
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:44:31.564004
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:33.840205
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:35.075435
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-17 22:44:38.829895
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:45:13.635372
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:15.119498
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:17.318724
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:18.308833
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:19.945399
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:45:21.112272
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'


# Generated at 2022-06-17 22:45:22.529170
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:24.962846
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:26.400862
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:27.878114
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:39.687544
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:46:41.447554
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:46:43.767353
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:44.893720
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:46.648544
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:48.623295
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:49.760146
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:51.425393
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:46:54.786083
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:57.317303
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:18.894138
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:20.130069
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:49:21.705339
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:23.249086
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:24.952139
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:26.143076
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:27.960294
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:30.927847
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:32.315968
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:33.671688
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'
