

# Generated at 2022-06-17 22:42:18.876330
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PureWindowsPath() if 'win' in sys.platform else PurePosixPath()
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:21.327783
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:23.372403
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:26.734345
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:42:28.797282
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:30.799383
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:34.562382
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent.name == 'home'
    assert path._pathlib_home.name == 'oretha'


# Generated at 2022-06-17 22:42:35.984878
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/sherika'

# Generated at 2022-06-17 22:42:39.122571
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:42:43.973112
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:51.449188
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                               else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:42:54.532002
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:42:59.757764
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-17 22:43:04.707359
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:08.156614
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == 'home'


# Generated at 2022-06-17 22:43:11.847985
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.parent == PurePosixPath('/')
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:16.107044
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in sys.platform \
                                else PurePosixPath()
    assert path._pathlib_home / PLATFORMS[sys.platform]['home'] == path._pathlib_home


# Generated at 2022-06-17 22:43:19.115276
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:20.868677
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:26.294197
# Unit test for constructor of class Path
def test_Path():
    # Test for constructor of class Path
    path = Path()
    assert path is not None
    assert path.platform == sys.platform
    assert path._pathlib_home is not None
    assert path._pathlib_home.parent is not None
    assert path._pathlib_home.parent.name == ''
    assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:35.466191
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']


# Generated at 2022-06-17 22:43:37.371456
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:40.834218
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.name == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-17 22:43:42.822564
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:44.981129
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/taneka'


# Generated at 2022-06-17 22:43:46.860935
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:49.156865
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:43:50.699251
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:53.772636
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:43:56.577317
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:16.357022
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:17.438804
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'

# Generated at 2022-06-17 22:44:19.734432
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:21.863049
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:25.284444
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:26.961885
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'

# Generated at 2022-06-17 22:44:29.011416
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:30.607054
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:44:31.762137
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'

# Generated at 2022-06-17 22:44:34.119370
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:09.115515
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:11.172190
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:12.774189
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:45:14.201887
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:15.000849
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:16.827202
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-17 22:45:18.279859
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:19.909697
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:21.401210
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:45:22.715840
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:25.591795
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-17 22:46:26.362157
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'

# Generated at 2022-06-17 22:46:27.250096
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:29.603725
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:30.492997
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:31.381209
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:33.976453
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:35.117156
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)


# Generated at 2022-06-17 22:46:37.377231
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:46:39.827123
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:48:51.741394
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:48:54.219462
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:48:57.719614
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-17 22:49:00.548442
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:03.926825
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']

# Generated at 2022-06-17 22:49:06.459832
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:08.043371
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:09.320694
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:10.423056
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-17 22:49:11.533585
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'
