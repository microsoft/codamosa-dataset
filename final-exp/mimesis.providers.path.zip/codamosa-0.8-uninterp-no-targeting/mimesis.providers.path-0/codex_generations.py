

# Generated at 2022-06-21 16:20:37.488881
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""

    path = Path()
    result = path.dev_dir()
    assert len(result) >= 0

# Generated at 2022-06-21 16:20:39.262976
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-21 16:20:42.326782
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    path_ = Path()
    assert path_.root() == '/'


# Generated at 2022-06-21 16:20:42.971181
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/taneka'

# Generated at 2022-06-21 16:20:45.748769
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    answer = str(path._pathlib_home / path.user() / path.random.choice(FOLDERS))
    assert answer == path.users_folder()


# Generated at 2022-06-21 16:20:47.790464
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert re.match(r'/home/\w+/Development/\w+/\w+', p.project_dir())



# Generated at 2022-06-21 16:20:48.969190
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root()


# Generated at 2022-06-21 16:20:50.629571
# Unit test for method home of class Path
def test_Path_home():
    path = Path()

    # Test home method
    assert path.home() == '/home'


# Generated at 2022-06-21 16:20:52.867812
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None


# Generated at 2022-06-21 16:20:54.344603
# Unit test for method user of class Path
def test_Path_user():
    p = Path()

    assert(p.user())


# Generated at 2022-06-21 16:20:57.988324
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home().split("\\")[-1] in ['home', 'Home', 'HOME']


# Generated at 2022-06-21 16:21:00.157292
# Unit test for method home of class Path
def test_Path_home():
    assert set([x.split('/')[3] for x in [Path().home() for x in range(10)]]) == set(['home'])


# Generated at 2022-06-21 16:21:04.585948
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    expect_results = ("/",)
    actual_results = set()
    for _ in range(20):
        actual_results.add(p.root())

    if actual_results == expect_results:
        print(True)
    else:
        print(False)


# Generated at 2022-06-21 16:21:08.439502
# Unit test for method root of class Path
def test_Path_root():
    import mimesis
    from pprint import pprint
    provider = mimesis.Generic('path')
    pprint(provider.path.root())
    pprint(provider.path.root())
    pprint(provider.path.root())


# Generated at 2022-06-21 16:21:10.080529
# Unit test for method root of class Path
def test_Path_root():
    test_Path = Path()
    test_Path.seed(0)
    assert test_Path.root() == '/'


# Generated at 2022-06-21 16:21:11.538262
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    provider = Path()
    path = provider.dev_dir()
    return path


# Generated at 2022-06-21 16:21:14.831457
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import Platform
    from mimesis.providers import Path
    for platform in Platform:
        path = Path(platform=platform)
        assert path.root() == PLATFORMS[platform]['root']
        assert path.home() == PLATFORMS[platform]['home']

# Generated at 2022-06-21 16:21:16.636688
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()
    print("Done!")

# Generated at 2022-06-21 16:21:17.988436
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    # result = path.root()
    # assert result == '/'
    # assert isinstance(result, str)


# Generated at 2022-06-21 16:21:18.884572
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    a.users_folder()


# Generated at 2022-06-21 16:21:35.332714
# Unit test for method dev_dir of class Path

# Generated at 2022-06-21 16:21:40.172632
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert path.user()
    assert isinstance(path.user(), str)
    assert path.user()
    assert isinstance(path.user(), str)
    assert path.user()
    assert isinstance(path.user(), str)
    assert path.user()


# Generated at 2022-06-21 16:21:41.346362
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-21 16:21:45.160569
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    home_path = Path().home()
    dev_dir = Path().dev_dir()
    with open('home_dir.txt', 'w') as file:
        file.write(home_path)
        file.write('\n\n')
        file.write(dev_dir)


# Generated at 2022-06-21 16:21:49.336421
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform = 'linux')
    path1 = Path(platform = 'win32')
    assert path is not None
    assert path1 is not None


# Generated at 2022-06-21 16:21:52.543031
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    obj = Path(__name__)
    print(obj.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-21 16:21:59.040095
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Arrange
    count = 2000
    path = Path()
    # Act
    result = [path.users_folder() for _ in range(0, count)]
    # Assert
    for i in result:
        assert i == '/home/nelda/Pictures' or i == '/home/ortiz/Pictures' or i == '/home/lee/Pictures' or i == '/home/pina/Pictures' or i == '/home/olga/Pictures' or i == '/home/gloria/Pictures' or i == '/home/olga/Pictures' or i == '/home/jordan/Pictures' or i == '/home/horton/Pictures' or i == '/home/beverley/Pictures'



# Generated at 2022-06-21 16:22:01.440590
# Unit test for method home of class Path
def test_Path_home():
    test_Path = Path("win32")
    his_home = test_Path.home()
    print(his_home)


# Generated at 2022-06-21 16:22:03.315008
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    # print (path.users_folder())


# Generated at 2022-06-21 16:22:09.004293
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    PLATFORMS = {'linux': {'home': '/home'},
                 'win32': {'home': 'C:\\Users'},
                 'win64': {'home': 'C:\\Users'}}

    p = Path(platform='linux')
    assert p.dev_dir().startswith('/home')
    p = Path(platform='win32')
    assert p.dev_dir().startswith('C:\\Users')
    p = Path(platform='win64')
    assert p.dev_dir().startswith('C:\\Users')
    return True