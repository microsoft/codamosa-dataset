

# Generated at 2022-06-21 16:20:35.481712
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    result = p.users_folder()
    assert result == '/home/julio/Pictures'


# Generated at 2022-06-21 16:20:38.634464
# Unit test for method root of class Path
def test_Path_root():
    """Testing method root of class Path"""
    Path().root()

# Generated at 2022-06-21 16:20:39.906458
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())



# Generated at 2022-06-21 16:20:41.377473
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for _ in range(10):
        print(path.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-21 16:20:44.610681
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path()

    obj.random.seed(0)
    result = obj.dev_dir()
    assert result == '/home/taneka/Development/Python'

# Generated at 2022-06-21 16:20:45.395940
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert isinstance(p.home(), str)



# Generated at 2022-06-21 16:20:46.551223
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert(p.home() == '/home')


# Generated at 2022-06-21 16:20:48.661667
# Unit test for method root of class Path
def test_Path_root():
    """Testing root method of class Path"""
    pass

# Generated at 2022-06-21 16:20:50.728995
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.random.seed(1)
    assert p.user() == '/home/sherika'


# Generated at 2022-06-21 16:20:54.957110
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    path = p.users_folder()
    assert isinstance(path, str)
    assert path.startswith('/home/') or path.startswith('/Users/')
# end of code for method users_folder of class Path

# Generated at 2022-06-21 16:20:58.585632
# Unit test for method user of class Path
def test_Path_user():
    x = Path().user()
    assert x == '/home/taneka'


# Generated at 2022-06-21 16:21:05.453326
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    from mimesis.typing import DataType
    path = Path()
    assert isinstance(path.root(), str)

    path_linux = Path(platform=Platform.LINUX)
    root_linux = path_linux.root()
    assert isinstance(path_linux.root(), str)
    assert path_linux.random.choice(PROGRAMMING_LANGS) in root_linux

    path_windows = Path(platform=Platform.WINDOWS)
    assert isinstance(path_windows.root(), str)
    assert path_windows.random.choice(USERNAMES) in path_windows.root()

    root_str = str(path.serializer(data_type=DataType.PASCAL_CASE))

# Generated at 2022-06-21 16:21:07.187785
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir() == '/home/keisha/Development/C#'
    print('Test for method dev_dir of class Path is OK.\n')


# Generated at 2022-06-21 16:21:08.820973
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path."""
    p = Path()
    assert str(PurePosixPath('/home/kiersten/Documents')) == p.users_folder()

# Generated at 2022-06-21 16:21:10.312394
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path"""
    path = Path()
    root = path.root()


# Generated at 2022-06-21 16:21:12.250587
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    actual = p.root()

    expected = '/'
    assert actual == expected



# Generated at 2022-06-21 16:21:14.310509
# Unit test for constructor of class Path
def test_Path():
    path = Path()

    path.platform = 'linux'
    assert path.platform == 'linux'

    path.platform = 'win32'
    assert path.platform == 'win32'

# Generated at 2022-06-21 16:21:15.888660
# Unit test for method home of class Path
def test_Path_home():
    # Create an instance of a class
    obj = Path()
    # Test the method
    assert obj.home() == '/home'


# Generated at 2022-06-21 16:21:16.600436
# Unit test for method home of class Path
def test_Path_home():
    pass


# Generated at 2022-06-21 16:21:17.724870
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    print(p.home()) # test_Path_home


# Generated at 2022-06-21 16:21:22.541783
# Unit test for method home of class Path
def test_Path_home():
    path_home = Path().home()
    assert isinstance(path_home, str)
    assert path_home is not ""



# Generated at 2022-06-21 16:21:23.570350
# Unit test for method root of class Path
def test_Path_root():
    result = Path().root()
    assert result == "/"


# Generated at 2022-06-21 16:21:25.707897
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.platform = 'linux'
    s = path.dev_dir()
    assert 'Linux' in s


# Generated at 2022-06-21 16:21:28.105140
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert path.random.choice(root) == root


# Generated at 2022-06-21 16:21:29.525267
# Unit test for constructor of class Path
def test_Path():
    assert Path()


# Generated at 2022-06-21 16:21:31.670635
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ["/home/oretha", "/home/micah", "/home/alize"]


# Generated at 2022-06-21 16:21:42.507179
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("Unit test for method project_dir of class Path")
    expected_results = ['/home/Gisela/Development/Python/monitor',
                        '/home/nadine/Development/Falcon/monitor',
                        '/home/kathe/Development/Golang/monitor',
                        '/home/leontine/Development/Flask/monitor',
                        '/home/kathey/Development/Python/monitor']
    results = []
    path = Path(platform='darwin')
    for i in range(5):
        path.seed(i)
        results.append(path.project_dir())
    assert results == expected_results, "test_Path_project_dir failed"

if __name__ == "__main__":
    test_Path_project_dir()
    print("All tests passed")

# Generated at 2022-06-21 16:21:43.939807
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print (p.user())


# Generated at 2022-06-21 16:21:46.998772
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Check a user's folder path
    p = Path('linux')
    assert p.users_folder() == '/home/emelia/Documents' or \
        p.users_folder() == '/home/chang/Pictures' or \
        p.users_folder() == '/home/albert/Videos' or \
        p.users_folder() == '/home/jonathon/Music'

# Generated at 2022-06-21 16:21:49.814682
# Unit test for method home of class Path
def test_Path_home():
    m = Path().home()
    assert m == '/home'
