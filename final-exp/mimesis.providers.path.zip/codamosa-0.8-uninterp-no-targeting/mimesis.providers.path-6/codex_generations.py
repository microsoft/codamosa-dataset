

# Generated at 2022-06-21 16:20:33.672108
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Given
    path = Path(platform='linux')

    # When
    path_to_dev_dir = path.dev_dir()

    # Then
    assert path_to_dev_dir == '/home/adelia/Development/Java'

# Generated at 2022-06-21 16:20:41.570174
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())
    print(a.users_folder())

# Generated at 2022-06-21 16:20:43.576380
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-21 16:20:45.691859
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user[0:6] == '/Users'


# Generated at 2022-06-21 16:20:47.172782
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.seed(1)
    assert path.root() == '/'


# Generated at 2022-06-21 16:20:49.573003
# Unit test for method home of class Path
def test_Path_home():
    instance = Path()
    result = instance.home()
    assert isinstance(result,str)


# Generated at 2022-06-21 16:20:51.374541
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(100):
        print(Path().project_dir())
        print()

# Generated at 2022-06-21 16:20:55.926356
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert 'Path' == path.__class__.__name__
    assert 'user' == path.user.__name__
    assert 'home' in path.user.__name__
    assert 'oretha' in path.user.__name__

# Generated at 2022-06-21 16:20:57.162712
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path('darwin')
    print(path.dev_dir())

# Generated at 2022-06-21 16:20:57.826659
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())
