

# Generated at 2022-06-21 16:20:29.161871
# Unit test for method home of class Path
def test_Path_home():
    assert isinstance(Path().home(), str)
    assert len(Path().home()) > 0


# Generated at 2022-06-21 16:20:33.329391
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Given a Path object
    p = Path()

    # When a call is made to users_folder
    result = p.users_folder()

    # Then a random path to user's folders should be returned
    assert isinstance(result, (str))

# Generated at 2022-06-21 16:20:37.962067
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    try:
        path = Path()
        result = path.users_folder()
        assert (result != "")
        assert isinstance(result, str) == True
        print (result)
    except Exception as e:
        print ("test_Path_users_folder test failed!")
        print (e)
        assert False


# Generated at 2022-06-21 16:20:39.587445
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-21 16:20:45.583209
# Unit test for constructor of class Path
def test_Path():
    from mimesis.providers.path import Path

    p = Path('linux')
    assert p.platform == 'linux'
    assert p._pathlib_home == PurePosixPath('/home')
    p = Path('win32')
    assert p.platform == 'win32'
    assert p._pathlib_home == PureWindowsPath('C:/Users')


# Generated at 2022-06-21 16:20:47.056290
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/' or Path().root() == 'C:\\'


# Generated at 2022-06-21 16:20:48.832727
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())

# Generated at 2022-06-21 16:20:50.084057
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/annamae'

# Generated at 2022-06-21 16:20:51.649087
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-21 16:20:56.098002
# Unit test for method user of class Path
def test_Path_user():
    for i in range(10):
        p = PureWindowsPath()
        p /= PLATFORMS['windows']['home']
        p /= Path().user()
        path = 'C:\\Users\\' + Path().user()[8:]
        assert path == str(p)

# Generated at 2022-06-21 16:20:59.655465
# Unit test for constructor of class Path
def test_Path():
    """
    test the path class constructor
    """
    p = Path()

    assert p

# Generated at 2022-06-21 16:21:01.550322
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    to_home = path.home()
    res = to_home.split('/')
    print(res)


# Generated at 2022-06-21 16:21:03.923290
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# test_Path_users_folder()

# Generated at 2022-06-21 16:21:04.981304
# Unit test for method user of class Path
def test_Path_user():
    for i in range(100):
        print(Path().user())


# Generated at 2022-06-21 16:21:08.854885
# Unit test for method user of class Path
def test_Path_user():
    # Set up the Provider
    p = Path()
    # Create a function to check the result
    def check(value):
        return isinstance(value, str)
    # Check the output of the Provider
    assert check(p.user())

# Generated at 2022-06-21 16:21:10.350273
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    for i in range(0, 1000):
        assert(p.users_folder())

# Generated at 2022-06-21 16:21:12.156881
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.home()
    path.users_folder()
    path.dev_dir()
    path.project_dir()

# Generated at 2022-06-21 16:21:13.640958
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path.dev_dir() == '/home/niesha/Development/Ruby'


# Generated at 2022-06-21 16:21:14.932644
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    obj = Path()
    assert obj.project_dir() != ''

# Generated at 2022-06-21 16:21:16.227943
# Unit test for constructor of class Path
def test_Path():
    assert Path()
    assert Path('linux')
    assert Path('linux').platform == 'linux'
