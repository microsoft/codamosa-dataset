

# Generated at 2022-06-21 16:20:33.088265
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    r = path.root()
    assert r is not None


# Generated at 2022-06-21 16:20:34.646006
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-21 16:20:37.373581
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.generator = False
    assert path.random.choice(USERNAMES) == path._pathlib_home.parts[-1]

# Generated at 2022-06-21 16:20:39.163681
# Unit test for constructor of class Path
def test_Path():
    # Create an object Path
    assert Path() != None


# Generated at 2022-06-21 16:20:42.719981
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    alt_path = Path()
    alt_path.random.seed(42)
    assert alt_path.dev_dir() == '/home/ronna/Dev/Ruby'

# Generated at 2022-06-21 16:20:43.838023
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())
    return


# Generated at 2022-06-21 16:20:44.894203
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root()=='/'


# Generated at 2022-06-21 16:20:45.687423
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-21 16:20:46.965871
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.home())
    print(p.users_folder())
    print(p.dev_dir())

# Generated at 2022-06-21 16:20:58.292139
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import os
    from pathlib import PureWindowsPath, PurePosixPath
    from mimesis.builtins import Platform

    # Test PosixPath
    path = 'home/devloper/Development'
    path_posix = PurePosixPath(*path.split('/'))
    path_posix_path = str(path_posix)
    path_posix_dir = path_posix_path.split(os.sep)[-1]

    path_path_posix = Path(platform='linux', seed=0).dev_dir()
    path_dir_posix = path_path_posix.split(os.sep)[-1]

    assert path_dir_posix == path_posix_dir
    assert path_path_posix == path_posix_path

    # Test WindowsPath
    path

# Generated at 2022-06-21 16:21:01.967113
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-21 16:21:10.860829
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for function dev_dir of class Path"""
    p = Path().dev_dir()

# Generated at 2022-06-21 16:21:11.688193
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())



# Generated at 2022-06-21 16:21:13.569871
# Unit test for constructor of class Path
def test_Path():
    """test_Path() -> None

    :return: None
    """
    path = Path()
    assert path is not None



# Generated at 2022-06-21 16:21:15.683587
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('win32')

    print(p.project_dir())
    assert p.project_dir() == 'C:\\Users\\Cherelle\\Development\\Haskell\\rebate'

# Generated at 2022-06-21 16:21:17.955291
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"


# Generated at 2022-06-21 16:21:19.945309
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.random.choice(FOLDERS))
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())

test_Path()

# Generated at 2022-06-21 16:21:20.745047
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p=Path()
    print(p.dev_dir())

# Generated at 2022-06-21 16:21:24.693389
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert p is not None
    assert p._pathlib_home == PurePosixPath('/home')
    assert p.platform == 'linux'

    p = Path('darwin')
    assert p._pathlib_home == PurePosixPath('/home')
    assert p.platform == 'darwin'

    p = Path('win32')
    assert p._pathlib_home == PureWindowsPath('C:/Users')
    assert p.platform == 'win32'

    p = Path('win64')
    assert p._pathlib_home == PureWindowsPath('C:/Users')
    assert p.platform == 'win64'


# Generated at 2022-06-21 16:21:26.950428
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for i in range(100):
        print(Path().users_folder())
