

# Generated at 2022-06-21 16:20:39.707682
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == '/home/janyce/Development/Go/zealot'

    # python -c "import mimesis; mimesis.random.seed(0); print(mimesis.Path().project_dir())"
    # /home/shanta/Development/Elixir/boast

    # python -c "import mimesis; mimesis.random.seed(1); print(mimesis.Path().project_dir())"
    # /home/kimberely/Dev/Rust/boast

    # python -c "import mimesis; mimesis.random.seed(2); print(mimesis.Path().project_dir())"
    # /home/rose/Development/Elixir/boast

    # python -c "import mimesis; mimesis.

# Generated at 2022-06-21 16:20:40.658193
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert type(Path().dev_dir()) is str

# Generated at 2022-06-21 16:20:49.563259
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from random import choice
    from pathlib import PureWindowsPath
    platforms = ['darwin', 'win32', 'win64', 'linux']

    # Test for Linux & MacOS
    for p in platforms[:2]:
        path = Path(platform=p)
        if 'linux' in p:
            pathlib_home = PurePosixPath()
        else:
            pathlib_home = PureWindowsPath()
        pathlib_home /= PLATFORMS[p]['home']
        user = choice(USERNAMES)
        user = user.lower()
        pathlib_home = pathlib_home / user / 'Development'
        dev_dir = path.dev_dir()
        dev_dir = pathlib_home.parent / dev_dir.split('/')[-1]

        assert path.project_dir() == str

# Generated at 2022-06-21 16:20:53.929607
# Unit test for method home of class Path
def test_Path_home():
    name = 'HOMEPATH'
    value = 'C:\\Users\\oren'
    PLATFORMS['win32']['home'] = value
    path = Path()
    user = path.home()
    assert user == value

# Generated at 2022-06-21 16:20:59.377989
# Unit test for constructor of class Path
def test_Path():
    m = Path()
    assert m.Meta.name == 'path'
    assert m.platform == sys.platform
    assert str(m.user()) != '/home/oretha'
    assert str(m.users_folder()) != '/home/taneka/Pictures'
    assert str(m.dev_dir()) != '/home/sherrell/Development/Python'
    assert str(m.project_dir()) != '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-21 16:21:00.484303
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert "/home/katia" == p.user()

# Generated at 2022-06-21 16:21:03.811232
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    assert path.root() == '/'
    assert path.root() == path.root()


# Generated at 2022-06-21 16:21:04.923513
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str) is True, \
        "Path.user() failed!"

# Generated at 2022-06-21 16:21:07.320878
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert "/home/jaycee/Development/Mozart" in path.dev_dir()

# Generated at 2022-06-21 16:21:07.918497
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None

# Generated at 2022-06-21 16:21:13.788447
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    test_path_1 = u'/home/ashleigh/Development/Python/Alfred'
    test_path_2 = u'C:\\Users\\Santos\\Development\\JavaScript\\Emelda'
    print(path.project_dir())
    assert test_path_1 == path.project_dir() or test_path_2


# Generated at 2022-06-21 16:21:15.650015
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    assert Path().user() == '/home/cesar'
    assert Path().user().startswith('/home')


# Generated at 2022-06-21 16:21:18.641232
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    j = Path()
    path = j.users_folder()
    assert isinstance(path, str)
    assert path.startswith('/home')


# Generated at 2022-06-21 16:21:19.281629
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-21 16:21:22.909594
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert_value = '/home'
    result = path.home()
    assert assert_value == result, '\nassert_value = " %s "\nresult = " %s "' % (assert_value, result)


# Generated at 2022-06-21 16:21:24.134626
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    assert Path().dev_dir() == '/home/oralee/Development/Golang/Bazaar'

# Generated at 2022-06-21 16:21:25.658793
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    #print(path.root())


# Generated at 2022-06-21 16:21:27.707490
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    assert path.user() == '/home/sherrell'


# Generated at 2022-06-21 16:21:32.004481
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    mimesis_path = Path()
    path = mimesis_path.user()
    print(path)
    assert isinstance(path, str)
    assert "home" in path


# Generated at 2022-06-21 16:21:33.391459
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    _path = Path()
    _pattern = re.compile(r'^/home/[a-zA-Z]+/[A-Za-z]+')
    assert re.match(_pattern, _path.users_folder())

# Generated at 2022-06-21 16:21:39.555906
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    path = Path(platform='linux')
    assert isinstance(path, Path)

# Generated at 2022-06-21 16:21:41.448746
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(0, 19):
        path.users_folder()
        assert True


# Generated at 2022-06-21 16:21:43.264448
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-21 16:21:45.158923
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    root_path = path.root()
    assert root_path == '/'


# Generated at 2022-06-21 16:21:49.335623
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    result = p.user()
    assert result == p.user()
    assert result != p.user()
    assert result != p.user()

# Generated at 2022-06-21 16:21:51.489906
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert type(path.project_dir()) == str


# Generated at 2022-06-21 16:21:52.971972
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()


# Generated at 2022-06-21 16:21:54.322101
# Unit test for method home of class Path
def test_Path_home():
    """Test Path.home
    """
    assert Path().home()



# Generated at 2022-06-21 16:21:55.898745
# Unit test for method home of class Path
def test_Path_home():
    assert len(Path().home()) == len("/home/monty")
    assert Path().home() == "/home/monty"


# Generated at 2022-06-21 16:22:03.854609
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    
    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.user() == '/home/oretha'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.dev_dir() == '/home/sherrell/Development/Python'
    assert path.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-21 16:22:13.524172
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform


# Generated at 2022-06-21 16:22:14.874181
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path
    assert path.Meta.name == 'path'

# Generated at 2022-06-21 16:22:15.820292
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None

# Generated at 2022-06-21 16:22:17.840970
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath('Users')

# Generated at 2022-06-21 16:22:19.108677
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-21 16:22:21.856710
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    Path.home(path) == str(PureWindowsPath() / PLATFORMS['win32']['home']) \
    or Path.home(path) == str(PurePosixPath() / PLATFORMS['linux']['home'])


# Generated at 2022-06-21 16:22:24.267661
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-21 16:22:25.541528
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-21 16:22:27.339007
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    path = Path('linux')
    assert 'home' in path.dev_dir()

# Generated at 2022-06-21 16:22:30.281826
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())
    file = open('test.txt', 'w')
    file.write(path.users_folder())
    file.close()

# Generated at 2022-06-21 16:22:47.647215
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for i in range(0, 100000):
        assert str(path._pathlib_home / path.user())[:6] == '/home/'

# Generated at 2022-06-21 16:22:54.465383
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # test with default dirs, default platform
    dir_path = Path().users_folder()
    assert isinstance(dir_path, str)
    assert dir_path.startswith('/home')
    assert '/Pictures' in dir_path or '/Music' in dir_path

    # test with custom dir, default platform
    dir_path = Path().users_folder(dirs=['Music'])
    assert isinstance(dir_path, str)
    assert '/Music' in dir_path

    # test with default dirs, custom platform
    dir_path = Path(platform='darwin').users_folder()
    assert isinstance(dir_path, str)
    assert dir_path.startswith('/Users')

    # test with custom dirs, custom platform
    dir_path = Path(platform='darwin').users_folder

# Generated at 2022-06-21 16:22:55.712137
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/home/oretha'


# Generated at 2022-06-21 16:23:01.865918
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Gender
    from mimesis.builtins import Datetime
    user = 'Nicolle'
    gender = Gender.FEMALE.value
    dt = Datetime()
    dt.seed(user+gender)
    path = Path('linux', seed=user+gender)
    for i in range(10):
        assert path.users_folder() == '/home/'+user+'/'+path.random.choice(FOLDERS)

# Generated at 2022-06-21 16:23:05.013074
# Unit test for method root of class Path
def test_Path_root():
    print("\n Test method root of class Path...")
    path = Path()
    assert path.root() in ['/', 'C:\\']
    print("OK")


# Generated at 2022-06-21 16:23:07.568278
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path."""
    path = Path()
    assert path.users_folder() == '/home/genoveva/Downloads'


# Generated at 2022-06-21 16:23:08.334903
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-21 16:23:09.593773
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-21 16:23:10.953590
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-21 16:23:14.382159
# Unit test for method home of class Path
def test_Path_home():
    x = Path()
    result = x.home()
    print(result)
    assert result is not None
    assert result != ''
