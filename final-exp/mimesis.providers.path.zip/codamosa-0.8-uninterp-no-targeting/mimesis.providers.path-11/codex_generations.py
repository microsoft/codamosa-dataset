

# Generated at 2022-06-21 16:20:34.427769
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())


# Generated at 2022-06-21 16:20:36.417466
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    assert(isinstance(result, str))

# Generated at 2022-06-21 16:20:38.811582
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-21 16:20:40.875699
# Unit test for method home of class Path
def test_Path_home():
    pathlib = Path(platform='win64')
    assert pathlib.home() == "C:\\Users"


# Generated at 2022-06-21 16:20:45.423355
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # As params you can use a string directly, or a callable that returns a string
    # the string can be a datetime format string or anything you want
    p = Path(platform="linux")
    print(p.dev_dir())

# Generated at 2022-06-21 16:20:46.270038
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-21 16:20:49.709635
# Unit test for method user of class Path
def test_Path_user():
    from random import randint

    platform = ['linux', 'darwin', 'win32', 'win64'][randint(0, 3)]
    path = Path(platform)
    if platform == 'win32' or platform == 'win64':
        assert path.user() == str(PureWindowsPath(r'C:\Users\Paulette'))
    else:
        assert path.user() == '/home/ramon'



# Generated at 2022-06-21 16:20:50.733375
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())

# Generated at 2022-06-21 16:20:54.255102
# Unit test for method root of class Path
def test_Path_root():
    # Init
    Path = Path('linux')
    # Run test
    result = Path.root()
    # Assert
    assert result == '/'

# Generated at 2022-06-21 16:20:55.973476
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()
    print(path.users_folder())
