

# Generated at 2022-06-21 16:20:28.568087
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test Path.project_dir method"""
    path = Path(platform='linux')
    assert path.project_dir() == '/home/lakiesha/Development/Python/demonetized'

# Generated at 2022-06-21 16:20:30.837067
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # todo implement unit tests
    return True

# Generated at 2022-06-21 16:20:32.762808
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    path = Path()
    assert path.root() == "/"


# Generated at 2022-06-21 16:20:34.646578
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    res = p.users_folder()
    assert 'home' in res

# Generated at 2022-06-21 16:20:36.617504
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()
    print(path.dev_dir())

# Generated at 2022-06-21 16:20:38.046043
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.__repr__()
    path.__str__()


# Generated at 2022-06-21 16:20:43.220546
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pt = Path()
    for i in range(0, 1000):
        path = pt.users_folder()
        assert path[0] == '/'
        assert path[1:6] == 'home'
        assert path[7:10] in FOLDERS


# Generated at 2022-06-21 16:20:45.340856
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for i in range(20):
        p = Path()
        res = p.dev_dir()
        print(res)


# Generated at 2022-06-21 16:20:46.512904
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() is not None


# Generated at 2022-06-21 16:20:48.122845
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/yvette/Development/Python'

# Test for method project_dir of class Path

# Generated at 2022-06-21 16:21:00.628032
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    user_path = Path().users_folder()
    if "\\" in user_path:
        assert(user_path.split("\\")[-1] in FOLDERS)
        if len(user_path.split("\\")) > 2:
            assert(user_path.split("\\")[-2] == "home" or user_path.split("\\")[-2] == "Users")
            assert(user_path.split("\\")[0] == "C:")
        else:
            assert(user_path.split("\\")[-1] == "home" or user_path.split("\\")[-1] == "Users")
            assert(user_path.split("\\")[0] == "C:")

# Generated at 2022-06-21 16:21:10.489268
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    path = Path()

    person_1 = Person('en', gender=Gender.MALE)
    user_1 = path.user()
    assert user_1 == '/home/' + person_1.username().lower()

    person_2 = Person('en', gender=Gender.FEMALE)
    user_2 = path.user()
    assert user_2 == '/home/' + person_2.username().lower()

    path = Path(platform='win32')

    person_3 = Person('en', gender=Gender.MALE)
    user_3 = path.user()
    assert user_3 == 'C:\\Users\\' + person_3.username().capitalize()


# Generated at 2022-06-21 16:21:12.629573
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.Meta.name == 'path'
    assert p.platform is sys.platform
    assert isinstance(p._pathlib_home, PurePosixPath)

# Generated at 2022-06-21 16:21:13.822733
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    repo = p.root()
    return repo


# Generated at 2022-06-21 16:21:14.870178
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    dev_dir = Path().dev_dir()
    print(dev_dir)

# Generated at 2022-06-21 16:21:18.743553
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p1 = Path()
    p2 = Path()
    p3 = Path()
    p4 = Path()
    p5 = Path()
    p6 = Path()
    
    print(p1.users_folder())
    print(p2.users_folder())
    print(p3.users_folder())
    print(p4.users_folder())
    print(p5.users_folder())
    print(p6.users_folder())
    assert True

# Generated at 2022-06-21 16:21:19.688061
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert len(path.dev_dir()) > 0

# Generated at 2022-06-21 16:21:20.686057
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    print(a.users_folder())

test_Path_users_folder()

# Generated at 2022-06-21 16:21:21.286067
# Unit test for method root of class Path
def test_Path_root():
    print(Path().root())


# Generated at 2022-06-21 16:21:22.775709
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pp = Path()
    for i in range(0,10):
        path = pp.users_folder()
        assert type(path) == str
        print("\n{}".format(path))
