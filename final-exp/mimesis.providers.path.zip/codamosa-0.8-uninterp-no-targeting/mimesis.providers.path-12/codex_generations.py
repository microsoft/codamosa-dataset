

# Generated at 2022-06-21 16:20:31.799244
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert str(p) == "<Path (en)>"

# Generated at 2022-06-21 16:20:33.848110
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis import Path
    path = Path()
    for i in range(50):
        print(path.project_dir())


# Generated at 2022-06-21 16:20:35.524067
# Unit test for constructor of class Path
def test_Path():
    assert Path('win32').platform == 'win32'


# Generated at 2022-06-21 16:20:39.164376
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == '/home/lynn/Documents'


# Generated at 2022-06-21 16:20:43.264720
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # first argument is the platform type
    # i.e. 'linux', 'darwin', 'win32', 'win64'
    p = Path('win32')
    print(p.dev_dir())


# Generated at 2022-06-21 16:20:50.050180
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform='linux')
    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.dev_dir() == '/home/sherrell/Development/Python'
    assert path.project_dir() == '/home/sherika/Development/Falcon/mercenary'
    path = Path(platform='darwin')
    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.dev_dir() == '/home/sherrell/Development/Python'
    assert path.project_dir() == '/home/sherika/Development/Falcon/mercenary'
    path = Path

# Generated at 2022-06-21 16:21:00.233022
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    count = 1000

    # Python 3.6
    path = Path('win32', seed=0)
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.users_folder() == '/home/taneka/Pictures'

    # Python 3.8
    path = Path('win32', seed=0)
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.users_folder() == '/home/taneka/Pictures'
    assert path.users_folder() == '/home/taneka/Pictures'

# Generated at 2022-06-21 16:21:03.044783
# Unit test for constructor of class Path
def test_Path():
	test_Path = Path()
	assert test_Path.platform == sys.platform
	assert test_Path._pathlib_home is not None


# Generated at 2022-06-21 16:21:06.308882
# Unit test for method home of class Path
def test_Path_home():
    import random
    import string
    import time
    import datetime
    random.seed(datetime.datetime.now())
    result = Path(platform=PLATFORMS['linux'])
    d = str(result.home())
    assert d == '/home'


# Generated at 2022-06-21 16:21:07.366800
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    a = p.users_folder()
    print(a)

