

# Generated at 2022-06-21 16:20:27.234051
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/camelia'


# Generated at 2022-06-21 16:20:31.625020
# Unit test for constructor of class Path
def test_Path():
    path = Path()

    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())

# Generated at 2022-06-21 16:20:32.841549
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    print(a.users_folder())

# Generated at 2022-06-21 16:20:34.429043
# Unit test for method user of class Path
def test_Path_user():
    p=Path()
    print(p.user())


# Generated at 2022-06-21 16:20:36.417592
# Unit test for method home of class Path
def test_Path_home():
    p = Path(platform = 'linux')
    assert p.home() == '/home'


# Generated at 2022-06-21 16:20:44.565964
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from random import choice
    from pathlib import PurePosixPath
    from os import path, environ
    path_obj = Path()
    root = PurePosixPath() / 'home'
    while True:
        file_path = path_obj.users_folder()
        if path.exists(file_path):
            break
    assert file_path.startswith(str(root))
    assert len(file_path.split(path.sep)) == 3


# Generated at 2022-06-21 16:20:46.270447
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(100):
        print(path.users_folder())


# Generated at 2022-06-21 16:20:48.205717
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-21 16:20:50.219516
# Unit test for method root of class Path
def test_Path_root():
    print(Path().root())
    print(Path().root())
    print(Path().root())
    print(Path().root())

# Generated at 2022-06-21 16:20:51.868788
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-21 16:20:56.141166
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    x = Path().dev_dir()
    assert type(x) is str

# Generated at 2022-06-21 16:20:57.373518
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()


# Generated at 2022-06-21 16:20:58.307941
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.home())

# Generated at 2022-06-21 16:21:00.412298
# Unit test for method home of class Path
def test_Path_home():
    '''
    Returns path to user home directory
    '''
    path = Path()
    home = path.home()
    assert home == '/home'
    

# Generated at 2022-06-21 16:21:01.234695
# Unit test for constructor of class Path
def test_Path():
    assert Path()
    pass

# Generated at 2022-06-21 16:21:04.442176
# Unit test for method home of class Path
def test_Path_home():
    path = Path(platform='darwin')
    x = path.home()
    assert str(type(x)) == "<class 'str'>"


# Generated at 2022-06-21 16:21:05.709967
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_folder = Path()
    print(path_folder.users_folder())

# Generated at 2022-06-21 16:21:10.632558
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p_dir = p.project_dir()
    p_dir_parts = p_dir.split('/')
    assert len(p_dir_parts) == 6
    assert p_dir_parts[0] == '/'
    assert p_dir_parts[1] == 'home'
    assert p_dir_parts[4] == 'Development'
    assert p_dir_parts[5] != 'mercenary'

# Generated at 2022-06-21 16:21:11.766780
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p=Path()
    print(p.dev_dir())


# Generated at 2022-06-21 16:21:12.956491
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.random
