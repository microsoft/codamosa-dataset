

# Generated at 2022-06-21 16:20:35.789202
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    '''
    Test method users_folder of class Path
    '''

    p = Path()
    path = p.users_folder()
    assert(path[0] != '/' and path[-1] != '/')


# Generated at 2022-06-21 16:20:39.586969
# Unit test for method root of class Path
def test_Path_root():
    path = Path(platform = 'linux')
    assert str(path._pathlib_home.parent) == path.root()


# Generated at 2022-06-21 16:20:44.397085
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(10):
        try:
            p = Path("win32")
            #print(p.project_dir())
        except:
            print("Impossible de générer des noms de projet")

test_Path_project_dir()

# Generated at 2022-06-21 16:20:45.202815
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-21 16:20:50.730063
# Unit test for constructor of class Path
def test_Path():
    # Input
    p = Path("linux")
    # Output
    assert isinstance(p, Path)
    assert isinstance(p._random, random.Random)
    assert isinstance(p._datetime, datetime.datetime)
    assert isinstance(p._text, mimesis.providers.text.Text)
    assert isinstance(p._numbers, mimesis.providers.numbers.Numbers)
    # Assertions
    assert p.platform == 'linux'

# Generated at 2022-06-21 16:20:54.605721
# Unit test for constructor of class Path
def test_Path():
    """Test the constructor of class Path"""
    path = Path('win32')
    assert path.platform == 'win32'
    assert path._pathlib_home == PureWindowsPath('C:/Users')


# Generated at 2022-06-21 16:20:56.642990
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/marisha/Development/Lua'

# Unit test method project_dir of class Path

# Generated at 2022-06-21 16:20:59.225321
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    x = p.user()
    y = str(p._pathlib_home / p.random.choice(USERNAMES).capitalize())
    assert x == y


# Generated at 2022-06-21 16:21:00.376011
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.pathlib_home
    path.platform

# Generated at 2022-06-21 16:21:01.661246
# Unit test for constructor of class Path
def test_Path():
    assert isinstance(Path().Meta.name, str)
    assert isinstance(Path().Meta.provider, str)