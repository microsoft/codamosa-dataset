

# Generated at 2022-06-21 16:20:32.453296
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()
    assert path.users_folder() == "/home/dusty/Music" or "/home/tereasa/Music"

# Generated at 2022-06-21 16:20:33.673404
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-21 16:20:35.877905
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path(platform='linux')
    print(path.dev_dir())


# Generated at 2022-06-21 16:20:39.213534
# Unit test for constructor of class Path
def test_Path():
    class_ = Path()
    assert class_.Meta.name == 'path'


# Generated at 2022-06-21 16:20:40.565373
# Unit test for method home of class Path
def test_Path_home():
    objPath = Path()
    print(objPath.home())


# Generated at 2022-06-21 16:20:43.576809
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for _ in range(100):
        path = Path()
        assert path.project_dir()

# Generated at 2022-06-21 16:20:44.182227
# Unit test for constructor of class Path
def test_Path():
    assert Path()


# Generated at 2022-06-21 16:20:45.202308
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert home.startswith('/home')


# Generated at 2022-06-21 16:20:46.212977
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:20:47.362677
# Unit test for method home of class Path
def test_Path_home():
    assert type(Path.home) == str


# Generated at 2022-06-21 16:20:50.922779
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    print(dev_dir)


# Generated at 2022-06-21 16:20:53.693853
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    for i in range(1000):
        res = p.project_dir()
        assert True

# Generated at 2022-06-21 16:20:58.162992
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())
    print(p.root())
    print(p.home())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    print(p.system_dir())

if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-21 16:20:59.031482
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-21 16:21:02.681522
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    path = Path()
    user = path.user()
    person = Person('ru')
    person.seed(123456)
    user_format = person.user_name(gender=Gender.FEMALE).capitalize()
    assert user == '/home/Marissa'



# Generated at 2022-06-21 16:21:04.550050
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert type(p.root()) is str
    assert len(p.root()) > 1


# Generated at 2022-06-21 16:21:09.030649
# Unit test for method user of class Path
def test_Path_user():
    assert Path('linux').user() in '/home/maxim'
    assert Path('darwin').user() in '/home/rosalee'
    assert Path('win32').user() in 'C:/Users/Johnnie'
    assert Path('win64').user() in 'C:/Users/Johnnie'

# Generated at 2022-06-21 16:21:10.274829
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())



# Generated at 2022-06-21 16:21:13.342232
# Unit test for constructor of class Path
def test_Path():
    path = Path("linux")
    assert path.platform == 'linux'
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path._pathlib_home.parts[-1] == PLATFORMS['linux']['home']


# Generated at 2022-06-21 16:21:19.016801
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Testing method project_dir of class Path."""
    assert Path('linux').project_dir() == '/home/julisa/Development/Swift/pitch'
    assert Path('darwin').project_dir() == '/Users/dalila/Development/CSS/app'
    assert Path('win32').project_dir() == 'C:\\Users\\valerie/Development/Ruby/dialect'
    assert Path('win64').project_dir() == 'C:\\Users\\damia/Development/PHP/holdup'