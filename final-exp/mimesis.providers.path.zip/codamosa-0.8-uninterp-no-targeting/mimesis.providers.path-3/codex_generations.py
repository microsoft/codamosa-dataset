

# Generated at 2022-06-21 16:20:34.296766
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(100):
        x = Path()
        y = x.project_dir()
        if y != None:
            print(y)
        else:
            print("Failed")

test_Path_project_dir()


# Generated at 2022-06-21 16:20:37.064434
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    for i in range(100):
        print(p.dev_dir())

if __name__ == '__main__':
    test_Path_dev_dir()

# Generated at 2022-06-21 16:20:38.915677
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path.users_folder() != Path.users_folder()


# Generated at 2022-06-21 16:20:39.876150
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-21 16:20:42.165828
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-21 16:20:44.760566
# Unit test for constructor of class Path
def test_Path():
    path = Path('linux')
    assert path.random is not None
    assert path.platform == 'linux'
    assert path._pathlib_home == PurePosixPath('/home')

    path = Path('win32')
    assert path._pathlib_home == PureWindowsPath('C:\\Users')



# Generated at 2022-06-21 16:20:45.530874
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert type(p.project_dir()) == str

# Generated at 2022-06-21 16:20:48.123208
# Unit test for constructor of class Path
def test_Path():
    # Unit test for attribute
    path = Path()
    platform = path.platform

    # Unit test for constructor
    assert path.seed is None
    assert platform in ['linux', 'darwin', 'win32', 'win64']



# Generated at 2022-06-21 16:20:51.375445
# Unit test for method user of class Path
def test_Path_user():
    for platform in PLATFORMS.keys():
        p = Path(platform=platform)
        user = p.user()
        a = user.split('/')
        assert a[-1] in USERNAMES


# Generated at 2022-06-21 16:20:54.437093
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Platform
    path = Path(platform = Platform.MACOS)
    print(path.users_folder())

# Generated at 2022-06-21 16:20:58.333478
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for home metho"""
    assert Path().home() == "/home"



# Generated at 2022-06-21 16:21:03.582997
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from os import path

    # Create instance of class Path
    path = Path()

    # value of the path to development directory
    value = path.dev_dir()
    
    # value of the path to home directory
    home = path.home()

    print(value)

    # Check if the path exists
    assertion = path.exists(value)

    # Check if the path starts with home
    assertion = path.startswith(value, home)

# Generated at 2022-06-21 16:21:04.923340
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.home())


if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-21 16:21:07.114765
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.Meta.name == 'path' and path.Meta.providers == ('file',)
    path = Path(platform='linux')
    assert path.platform == 'linux'


# Generated at 2022-06-21 16:21:09.407573
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Path::dev_dir()"""
    path = Path()
    dev_dir = path.dev_dir()
    if not dev_dir:
        raise AssertionError("Empty result")
    if not isinstance(dev_dir, str):
        raise AssertionError("Wrong type of returned value")

# Generated at 2022-06-21 16:21:10.423175
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() is not None

# Generated at 2022-06-21 16:21:17.721921
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Arrange
    path = Path()

    # Act
    actual = path.users_folder()

    # Assert

# Generated at 2022-06-21 16:21:18.592598
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()


# Generated at 2022-06-21 16:21:19.927359
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert result == "/home/brendan"

# Generated at 2022-06-21 16:21:21.541127
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test for Path.users_folder()."""
    path = Path()
    users_folder = path.users_folder()
    assert "/home" in users_folder
    assert "/" in users_folder

# Generated at 2022-06-21 16:21:29.181758
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())
    # output /home/corazon/Videos


# Generated at 2022-06-21 16:21:31.078827
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for i in range(10):
        print(Path().dev_dir())


# Generated at 2022-06-21 16:21:33.537209
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-21 16:21:37.022889
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    root = path.root()
    if sys.platform == 'win32':
        assert root == 'C:\\'
    else:
        assert root == '/'


# Generated at 2022-06-21 16:21:38.000534
# Unit test for method root of class Path
def test_Path_root():
    for i in range(100):
        p = Path()
        #print(p.root())


# Generated at 2022-06-21 16:21:40.007671
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    for i in range(10):
        print(p.project_dir())


# Generated at 2022-06-21 16:21:42.212396
# Unit test for method users_folder of class Path
def test_Path_users_folder():

    path = Path()
    path.home()
    path.users_folder()
    path.dev_dir()
    path.project_dir()

# Generated at 2022-06-21 16:21:45.057938
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    test = path.dev_dir()
    print(test)
    assert isinstance(test, str) == True

if __name__ == '__main__':
    test_Path_dev_dir()

# Generated at 2022-06-21 16:21:46.081461
# Unit test for method root of class Path
def test_Path_root():
    print(Path().root())


# Generated at 2022-06-21 16:21:48.962182
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    assert '/home/jaleesa' == p.user()

# Generated at 2022-06-21 16:21:59.827709
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert type(p.platform) is str

# Generated at 2022-06-21 16:22:03.495553
# Unit test for method home of class Path
def test_Path_home():
    field_name = "home" 
    # Method to test
    testPath = Path()
    testPath.home()
    # Unit test
    assert field_name in dir(testPath)
    
    

# Generated at 2022-06-21 16:22:08.006590
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.providers.path import Path
    path = Path()
    path_to_project = path.project_dir()
    if 'bin' in path_to_project or 'scripts' in path_to_project:
        return True
    else:
        return False

# Test for path to project
if test_Path_project_dir():
    print("test_Path_project_dir ok")

# Generated at 2022-06-21 16:22:17.230582
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    code = """
    from mimesis.enums import Gender
    from mimesis.providers.path import Path
    manager = Path.__dict__
    func = manager['users_folder']
    generator = func(manager['_Path__self'], Gender.MALE)
    assert isinstance(generator, str)
    assert generator != manager['users_folder'](manager['_Path__self'], Gender.FEMALE)
    """
    result, number = doctest.testmod(verbose=False)

    assert result == TestResults.SUCCESS
    assert number == 1

# Generated at 2022-06-21 16:22:19.187587
# Unit test for method root of class Path
def test_Path_root():
    path = Path()

    assert isinstance(path.root(), str)
    assert path.root() != ''


# Generated at 2022-06-21 16:22:22.958487
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    test_Path = Path('linux')
    windows_result = 'C:\\Users\\dashawn\\Python\\mimesis\\docs'
    linux_result = '/home/elenore/Development/C'
    assert (windows_result in [test_Path.dev_dir() for i in range(10)])
    assert (linux_result in [test_Path.dev_dir() for i in range(10)])


# Generated at 2022-06-21 16:22:24.455075
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_mapper = Path('win32')
    dev_dir = path_mapper.dev_dir()
    assert dev_dir == "C:\\Users\\sherika\\Development\\Ruby"

# Generated at 2022-06-21 16:22:27.030844
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.builtins import PathField
    from mimesis.enums import FieldCode
    for i in range(1, 10):
        path = Path()

# Generated at 2022-06-21 16:22:28.218002
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    my_path = path.project_dir()

    assert len(my_path) > 0

# Generated at 2022-06-21 16:22:33.150841
# Unit test for constructor of class Path
def test_Path():
    # Unit test for constructor of class Path
    path = Path()
    assert path.__class__.__name__ == "Path"
    assert path.__class__.Meta.name == "path"

    path = Path(platform = "win32")
    assert path.__class__.__name__ == "Path"
    assert path.__class__.Meta.name == "path"
