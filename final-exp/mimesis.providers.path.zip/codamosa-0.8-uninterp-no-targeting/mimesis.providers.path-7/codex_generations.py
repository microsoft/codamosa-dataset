

# Generated at 2022-06-21 16:20:34.297512
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path, "Error in Path()"


# Generated at 2022-06-21 16:20:35.568153
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-21 16:20:39.541649
# Unit test for method root of class Path
def test_Path_root():
    """Test for method Path.root."""
    path = Path()
    assert (path.root() == "/")


# Generated at 2022-06-21 16:20:42.942314
# Unit test for constructor of class Path
def test_Path():
    _p = Path()
    result = str(_p._pathlib_home)
    assert result == '/home', "Assertion error: wrong home path"

# Generated at 2022-06-21 16:20:43.851157
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.platform

# Generated at 2022-06-21 16:20:45.441388
# Unit test for constructor of class Path
def test_Path():
    """
    Test the constructor of class Path.
    """
    from mimesis.enums import Platform
    path = Path(platform=Platform.DARWIN)
    assert isinstance(path, Path)


# Generated at 2022-06-21 16:20:56.055189
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/Users/jacqualyn/Dev/Python'
    assert path.dev_dir() == '/Users/vince/Dev/Django'
    assert path.dev_dir() == '/Users/marlen/Development/Go'
    assert path.dev_dir() == '/home/taneka/Dev/C'
    assert path.dev_dir() == '/home/cristopher/Dev/C++'
    assert path.dev_dir() == '/home/katina/Development/Ruby'
    assert path.dev_dir() == '/home/josue/Dev/PHP'
    assert path.dev_dir() == '/home/tam/Development/Java'
    assert path.dev_dir() == '/home/rozella/Development/Rust'
    assert path.dev

# Generated at 2022-06-21 16:20:58.989722
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    Path_obj = Path()
    expected_result = '/Users/sherrell/Dev/Python'
    dev_dir_method_result = Path_obj.dev_dir()
    assert dev_dir_method_result == expected_result


# Generated at 2022-06-21 16:21:05.063532
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from argparse import ArgumentParser
    from mimesis.builtins import path
    from utils import parse_arguments, console_output

    parser = ArgumentParser()
    parser.add_argument('-p', '--platform', type=str, required=False,
                        choices=path.PLATFORMS.keys(),
                        help='Desired platform (e.g: linux, darwin, win32, etc).')
    parser.add_argument('-s', '--seed', type=str,
                        help='Provide a seed to repeat the test.')
    args = vars(parser.parse_args())
    result = parse_arguments(args, path.Path)
    console_output(result, 'users_folder')

# Generated at 2022-06-21 16:21:07.758418
# Unit test for method home of class Path
def test_Path_home():
    actual_result = Path(platform="linux").home()
    expected_result = "/home"
    assert actual_result == expected_result


# Generated at 2022-06-21 16:21:14.559337
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert isinstance(path.project_dir(), str)



# Generated at 2022-06-21 16:21:15.664219
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():  
    path_gen = Path()
    print(path_gen.dev_dir())


# Generated at 2022-06-21 16:21:20.361031
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    '''
    def dev_dir(self) -> str:
        Generate a random path to development directory.

        :return: Path.

        :Example:
            /home/sherrell/Development/Python
    '''
    path = Path()
    path.random.seed(0)
    assert path.dev_dir() == '/home/dascoli/Dev/Go'

# Generated at 2022-06-21 16:21:25.702261
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path,Path)
    assert isinstance(path.root(),str)
    assert isinstance(path.home(),str)
    assert isinstance(path.user(),str)
    assert isinstance(path.users_folder(),str)
    assert isinstance(path.dev_dir(),str)
    assert isinstance(path.project_dir(),str)

# Generated at 2022-06-21 16:21:27.703101
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    test=Path.users_folder()
    print(test)
    assert len(test) > 0


# Generated at 2022-06-21 16:21:33.493834
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    a = path.project_dir()
    print(a)
    b = path.dev_dir()
    print(b)
    c = path.users_folder()
    print(c)

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-21 16:21:34.732151
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-21 16:21:36.185223
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-21 16:21:37.334356
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-21 16:21:39.297100
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())

# Generated at 2022-06-21 16:21:52.585654
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test method Path.users_folder."""
    path = Path(platform='linux')
    assert path.users_folder() == '/home/taneka/Pictures'

# Generated at 2022-06-21 16:21:54.424901
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    #path.users_folder()
    print(path.users_folder())


# Generated at 2022-06-21 16:21:55.416403
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-21 16:21:58.068825
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

test_Path_project_dir()

# Generated at 2022-06-21 16:22:00.406830
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root()

# # Unit test for method home of class Path

# Generated at 2022-06-21 16:22:03.272329
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform = 'linux')
    assert path.platform == 'linux'
    assert path.generator == 'path'

# Generated at 2022-06-21 16:22:10.620539
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    # Test to generate path on Windows
    path = Path(platform='win32')
    assert path.platform == 'win32'
    assert path.random.choice(FOLDERS) in path.users_folder()
    # Test to generate path on macOS
    path = Path(platform='darwin')
    assert path.platform == 'darwin'
    assert str(path._pathlib_home) == '/Users'
    assert path.random.choice(FOLDERS) in path.users_folder()
    # Test to generate path on Linux
    path = Path(platform='linux')
    assert path.platform == 'linux'
    assert str(path._pathlib_home) == '/home'
    assert path.random.choice(FOLDERS) in path.users_folder()


# Unit test

# Generated at 2022-06-21 16:22:12.921794
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root()


# Generated at 2022-06-21 16:22:13.897152
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-21 16:22:15.180356
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() != Path().home()
