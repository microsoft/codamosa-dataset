

# Generated at 2022-06-21 16:20:33.130148
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range(100):
        assert ('\'' + '\\' + p.user() + '\'') == '\'' + p.user() + '\''


# Generated at 2022-06-21 16:20:35.393033
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()
    # /home/porsha/Development/Python/mimesis

# Generated at 2022-06-21 16:20:37.412438
# Unit test for constructor of class Path
def test_Path():
    h = Path()
    assert h.random.choice(USERNAMES) in h.user()

# Test for root

# Generated at 2022-06-21 16:20:40.343789
# Unit test for method home of class Path
def test_Path_home():
    print("\n\nUnit test for method home of class Path")
    path = Path(platform = 'linux')
    print(path.home())


# Generated at 2022-06-21 16:20:42.987610
# Unit test for method user of class Path
def test_Path_user():
    c = Path()
    assert c.user() == '/home/oretha'

# Generated at 2022-06-21 16:20:45.023784
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path().dev_dir()
    assert isinstance(path, str)
    assert path == 'C:\\Users\\wilhelmina\\development\\Java' or path == '/home/ericka/dev/C++'


# Generated at 2022-06-21 16:20:46.908783
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis import Person

    p = Person('en')
    path = Path(p.username())

    print('home = ', path.home())
    print('users_folder = ', path.users_folder())



# Generated at 2022-06-21 16:20:51.994233
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Setup the data
    path=Path()
    expected=path.project_dir()
    platform=PLATFORMS[sys.platform]['home']
    home=path._pathlib_home

    # Assert that the expected is true
    assert (PurePath(expected).parts[0] == home)

# Generated at 2022-06-21 16:20:54.161350
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-21 16:20:54.737167
# Unit test for constructor of class Path
def test_Path():
    pass

# Generated at 2022-06-21 16:20:59.147681
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """
    Unit test for method dev_dir of class Path
    """
    path = Path()
    path.dev_dir()


# Generated at 2022-06-21 16:21:01.966222
# Unit test for method root of class Path
def test_Path_root():
    assert Path(platform='win32').root() == 'C:\\'
    assert Path(platform='win64').root() == 'C:\\'
    assert Path(platform='linux').root() == '/'
    assert Path(platform='darwin').root() == '/'


# Generated at 2022-06-21 16:21:03.228198
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    assert result == '/'


# Generated at 2022-06-21 16:21:05.865425
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    obj = Path()
    d = obj.project_dir()
    print("d:", d)
    pass

if __name__ == "__main__":
    test_Path_project_dir()
    pass

# Generated at 2022-06-21 16:21:08.927835
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.random.seed(0)
    assert p.dev_dir() == "/home/oretha/Dev/Ruby"


# Generated at 2022-06-21 16:21:09.869646
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print(Path().dev_dir())


# Generated at 2022-06-21 16:21:14.731733
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print('Unit test for method project_dir of class Path')
    path = Path()
    print('Testing if result is a string:', end=' ')
    print(isinstance(path.project_dir(), str)) # TODO: assert isinstance
    print('Testing if result is not empty:', end=' ')
    print(not path.project_dir() == '') # TODO: assert not == ''

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-21 16:21:17.035383
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path_ = Path()
    path_.random.seed(0)
    X = list(path_.repeat(1, path_.project_dir))
    assert X == ['/home/dorethea/Development/C/toughen']

# Generated at 2022-06-21 16:21:18.572111
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    root = p.root()
    assert type(root) is str
    assert root == '/'
    print("Testing Path_root(): ", root)


# Generated at 2022-06-21 16:21:20.423531
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Platform
    path = Path(platform=Platform.MACOS)
    print(path.users_folder())
    return
