

# Generated at 2022-06-21 16:20:28.759763
# Unit test for constructor of class Path
def test_Path():
    #TODO: Make the test
    pass

# Generated at 2022-06-21 16:20:33.010030
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    list_of_paths = []
    for i in range(100):
        path = Path().dev_dir()
        list_of_paths.append(path)
        # print(path)
    assert 1 == 1


# Generated at 2022-06-21 16:20:35.653553
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('linux')
    #users_folder() method
    assert path.users_folder() == "/home/oretha/Music"


# Generated at 2022-06-21 16:20:39.497432
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    x = Path()
    for _ in range(20):
        x.users_folder()

test_Path_users_folder()

# Generated at 2022-06-21 16:20:42.718861
# Unit test for constructor of class Path
def test_Path():
    # check if constructor is working fine
    pth = Path()
    assert isinstance(pth, Path)

# Unit tests for method 'root'

# Generated at 2022-06-21 16:20:44.054446
# Unit test for method home of class Path
def test_Path_home():
    loc = Path(platform='win32')
    print(loc.home())


# Generated at 2022-06-21 16:20:46.423992
# Unit test for method root of class Path
def test_Path_root():
    """Test for method root of class Path."""
    p = Path()
    p.seed(42)
    assert p.root() == '/'


# Generated at 2022-06-21 16:20:49.073247
# Unit test for method root of class Path
def test_Path_root():
    print("\nUnit test for method root of class Path")
    platform = sys.platform
    root = Path(platform=platform).root()
    if root == '':
        assert 0, "Method root of class Path is not working!"
    else:
        print("Method root of class Path is working.")


# Generated at 2022-06-21 16:20:52.462962
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    expected_result = '/home/taneka/Development/Python/numerate'
    actual_result = p.project_dir()
    assert actual_result == expected_result

# Generated at 2022-06-21 16:20:53.120900
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print("Project Name:", p.project_dir())