

# Generated at 2022-06-12 02:06:29.084052
# Unit test for method user of class Path
def test_Path_user():
    pl = Path()
    path = pl.user()
    assert isinstance(path, str)
    assert 'home' in path
    assert path.startswith('/')

# Generated at 2022-06-12 02:06:31.053187
# Unit test for constructor of class Path
def test_Path():
    assert Path("linux") is not None
    assert Path("darwin") is not None
    assert Path("win32") is not None
    assert Path("win64") is not None


# Generated at 2022-06-12 02:06:34.148281
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert (path.platform is not None), "Path platform is not set"
    assert (path.random is not None), "Path random is not set"

# Generated at 2022-06-12 02:06:37.290881
# Unit test for method user of class Path
def test_Path_user():
    instance = Path()
    result = instance.user()
    assert isinstance(result, str) and result.count('/') == 2

# Generated at 2022-06-12 02:06:38.744814
# Unit test for constructor of class Path
def test_Path():
    print("\n")
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-12 02:06:40.260943
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert "linux" in path.platform

# Generated at 2022-06-12 02:06:41.663981
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/shawnna'

# Generated at 2022-06-12 02:06:42.944918
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-12 02:06:43.800000
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform == sys.platform

# Generated at 2022-06-12 02:06:50.901665
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.builtins import EN
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    random = EN()
    internet = Internet(random)
    person = Person(random)
    path = Path(random=random)
    full_name = person.full_name(gender=Gender.FEMALE)
    username = internet.user_name(full_name)
    result = path.user()
    assert result == '/home/' + username.lower(), 'Should be equal'



# Generated at 2022-06-12 02:06:54.251752
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert type(path.user()) == str


# Generated at 2022-06-12 02:06:55.535103
# Unit test for method user of class Path
def test_Path_user():
    # A random path to user directory
    assert Path.user()


# Generated at 2022-06-12 02:06:57.376493
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    print(user)
    assert user


# Generated at 2022-06-12 02:06:59.399767
# Unit test for method user of class Path
def test_Path_user():
    p = Path().user()
    assert isinstance(p, str)

# Generated at 2022-06-12 02:07:01.036639
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())  # No Assertion
"""
/home/mariela

"""


# Generated at 2022-06-12 02:07:01.895927
# Unit test for method user of class Path
def test_Path_user():
    a = Path(platform='linux')
    assert a.user() in ['/home/luciano', '/home/tambra']


# Generated at 2022-06-12 02:07:03.139725
# Unit test for method user of class Path
def test_Path_user():
    a=Path()
    print(a.user())


# Generated at 2022-06-12 02:07:04.728544
# Unit test for method user of class Path
def test_Path_user():
    # pylint: disable=protected-access
    assert Path()._pathlib_home.exists()


# Generated at 2022-06-12 02:07:05.579130
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() != ''

# Generated at 2022-06-12 02:07:06.414059
# Unit test for method user of class Path
def test_Path_user():
    mimesis.path.Path().user()
    'C:\\Users\\Rand'

# Generated at 2022-06-12 02:07:09.944784
# Unit test for method user of class Path
def test_Path_user():
    user = Path().user()
    print(user)


# Generated at 2022-06-12 02:07:11.521993
# Unit test for method user of class Path
def test_Path_user():
    # generator = Path()
    # user = generator.user()
    # print("user: ", user)
    # assert user == '/home/reginia'
    True


# Generated at 2022-06-12 02:07:15.380003
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    # 현재 시점에서는 직접 값을 넣어줬지만,
    # 시점이 달라지면 테스트 케이스가 깨질 수 있음
    assert p.user() == '/home/taneka'


# Generated at 2022-06-12 02:07:17.884911
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert 'oretha' == path.user().split('/')[-1]

# Generated at 2022-06-12 02:07:22.432677
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    testLocale = Locale.ENGLISH.value
    testPlatform = 'darwin'
    testGender = Gender.FEMALE.value
    
    testPath = Path(testPlatform)
    testPerson = Person(testLocale)
    testPerson.gender = testGender

    assert testPerson.full_name() in testPath.user()

# Generated at 2022-06-12 02:07:23.838464
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == "/home/taneka"



# Generated at 2022-06-12 02:07:24.915961
# Unit test for method user of class Path
def test_Path_user():
    random = Random()
    path = Path(random)
    path.user()

# Generated at 2022-06-12 02:07:27.412231
# Unit test for method user of class Path
def test_Path_user():

    path = Path('win32')
    print(path.user())

    path = Path()
    print(path.user())



# Generated at 2022-06-12 02:07:27.854439
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user()

# Generated at 2022-06-12 02:07:28.643743
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/desiree'