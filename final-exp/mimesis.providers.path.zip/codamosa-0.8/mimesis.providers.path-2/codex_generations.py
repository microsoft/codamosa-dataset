

# Generated at 2022-06-12 02:06:29.657899
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    a = path.user()
    assert isinstance(a, str)
    assert len(a) > 0


# Generated at 2022-06-12 02:06:32.208876
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-12 02:06:33.540311
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() != p.user()


# Generated at 2022-06-12 02:06:38.221724
# Unit test for method user of class Path
def test_Path_user():
    names = ['oralee', 'johnette', 'erick', 'kasey', 'brant', 'shakera', 'cordelia', 'donna', 'danelle', 'dan']
    assert Path().user() in names


# Generated at 2022-06-12 02:06:47.708071
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    # 1
    r_1 = provider.user()
    assert isinstance(r_1, str), 'Method user of class Path does not return a str object'
    assert r_1 == '/home/oretha' or r_1 == 'C:\\Users\\oretha', 'Method user of class Path does not return the correct value'
    # 2
    r_2 = provider.user()
    assert isinstance(r_2, str), 'Method user of class Path does not return a str object'
    assert r_2 == '/home/oretha' or r_2 == 'C:\\Users\\oretha', 'Method user of class Path does not return the correct value'
    # 3
    r_3 = provider.user()

# Generated at 2022-06-12 02:06:50.359135
# Unit test for method user of class Path
def test_Path_user():
    lang = Path('linux')
    assert len(lang.user()) == 13
    assert lang.user().startswith('/home/')
    assert lang.user().endswith('.html')


# Generated at 2022-06-12 02:06:52.463099
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    path = Path()
    assert (path.user() in path.user() for _ in range(1000))

# Generated at 2022-06-12 02:06:56.741649
# Unit test for method user of class Path
def test_Path_user():
    """Return a path to user directory.

    :return: Path to user.

    :Example:
        /home/ossie
    """

    _path = Path()

    assert _path.user() == "/opt/users/green/home/ossie"



# Generated at 2022-06-12 02:06:59.497075
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user,str)
    assert '/home' in user


# Generated at 2022-06-12 02:07:01.116220
# Unit test for method user of class Path
def test_Path_user():
    result = Path().user()
    assert result == '/home/oretha'


# Generated at 2022-06-12 02:07:05.730434
# Unit test for method user of class Path
def test_Path_user():
    '''Method to Unit test class Path method user'''
    # Initlializing Path class object
    path_obj = Path()
    # Prints path to user
    print(path_obj.user())


# Generated at 2022-06-12 02:07:06.552726
# Unit test for method user of class Path
def test_Path_user():
    Path().user()


# Generated at 2022-06-12 02:07:07.647400
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'


# Generated at 2022-06-12 02:07:08.727944
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-12 02:07:09.830838
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert result != ''

# Generated at 2022-06-12 02:07:11.179806
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == "/home/jeremiah"


# Generated at 2022-06-12 02:07:13.072617
# Unit test for method user of class Path
def test_Path_user():
    assert 'oretha' in Path().user()


# Generated at 2022-06-12 02:07:14.163782
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert type(path.user()) == str


# Generated at 2022-06-12 02:07:15.342287
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() != '', "Path().user() is null"


# Generated at 2022-06-12 02:07:16.775100
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == "/home/taneka" or "/home/oretha" or "/home/sherika" or "/home/sherrell" or "/home/chaya"


# Generated at 2022-06-12 02:07:27.859880
# Unit test for method user of class Path
def test_Path_user():
    print("Testing method user of class Path.")

    for i in range(0, 10):
        path = Path()
        user = str(path.user())
        if not user.startswith('/') or user.count('/') != 2:
            print("Error: user does not match path of home directory.")
            return -1
        index = user.index('/')
        folderHome = user[1:index]
        if folderHome != "home":
            print("Error: user does not match path of home directory.")
            return -1
        index = user.index('/', index + 1)
        userName = user[index+1:]
        if userName.capitalize() not in USERNAMES:
            print("Error: userName not matching username list.")
            return -1

    print("Test passed.")
    return 0



# Generated at 2022-06-12 02:07:29.702510
# Unit test for method user of class Path
def test_Path_user():
    p = Path("linux")
    for i in range(0, 10):
        print(p.user()) # None of the users in test result are in the USERNAMES list


# Generated at 2022-06-12 02:07:31.292566
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())


# Generated at 2022-06-12 02:07:33.120226
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)
    assert p.user() in ['/home/oretha','/home/taneka']

# Generated at 2022-06-12 02:07:35.426974
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    user = path.user()
    assert isinstance(user, str)
    assert user != ''


# Generated at 2022-06-12 02:07:37.890907
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-12 02:07:39.822063
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(0)
    assert path.user() == '/home/katharina'


# Generated at 2022-06-12 02:07:42.340078
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    assert True

# Generated at 2022-06-12 02:07:43.465884
# Unit test for method user of class Path
def test_Path_user():
    p=Path()
    assert p.user().find('/')==0

# Generated at 2022-06-12 02:07:45.986849
# Unit test for method user of class Path
def test_Path_user():
    user_list = []
    path = Path()
    for i in range(0, 30):
        user_list.append(path.user())
    assert len(user_list) == 30
    assert len(set(user_list)) == 30

# Generated at 2022-06-12 02:07:53.981828
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user()

# Generated at 2022-06-12 02:07:56.484227
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == "/home/taneka"


# Generated at 2022-06-12 02:07:58.104004
# Unit test for method user of class Path
def test_Path_user():
    p=Path()
    user = p.user()


# Generated at 2022-06-12 02:08:00.333867
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    result = p.user()
    assert result is not None
    assert len(result) > 0


# Generated at 2022-06-12 02:08:11.069741
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path.

    Test method user of class Path by comparing the results of
    random.choice of the USERNAMES, capitalizing the choice and
    joining it with the /home/ if the platform is 'win' or with the
    /home if the platform is not 'win'.
    """
    from mimesis.builtins import platform
    import random
    import unittest
    from unittest.mock import patch, Mock

    class TestPath(unittest.TestCase):
        """Tests for the class Path."""

# Generated at 2022-06-12 02:08:12.574776
# Unit test for method user of class Path
def test_Path_user():
    test_object = Path()
    test_result = test_object.user()
    assert 'home' in test_result

# Generated at 2022-06-12 02:08:15.813753
# Unit test for method user of class Path
def test_Path_user():
    test_class=Path
    test_instance=test_class()
    test_function=test_instance.user
    expected_result=None
    actual_result=test_function()
    assert expected_result != actual_result

# Generated at 2022-06-12 02:08:19.606797
# Unit test for method user of class Path
def test_Path_user():
    tmppath = Path()
    tmppath.seed(25)
    assert tmppath.user() == "/home/carl"
    assert tmppath.user() != "/home/leonora"


# Generated at 2022-06-12 02:08:21.529235
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range(10**3):
        result = p.user()
    assert result


# Generated at 2022-06-12 02:08:22.411685
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/jesse'

# Generated at 2022-06-12 02:08:39.610128
# Unit test for method user of class Path
def test_Path_user():
    expected_path = '/home/lesha'
    path = Path()
    actual_path = path.user()
    assert actual_path == expected_path, 'path.user() returns wrong path'

# Generated at 2022-06-12 02:08:41.484019
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range(10):
        print(p.user())


# Generated at 2022-06-12 02:08:45.386183
# Unit test for method user of class Path
def test_Path_user():
    # pylint: disable=W0612
    provider = Path()
    test_path = provider.user()
    path_root = test_path[:test_path.find('/') + 1]
    assert path_root in ("C:\\", "/")


# Generated at 2022-06-12 02:08:47.155088
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert ((path.user() == '/home/oretha') or (path.user() == '/Users/oretha'))

# Generated at 2022-06-12 02:08:49.061396
# Unit test for method user of class Path
def test_Path_user():
    path_0 = Path()
    result=path_0.user()
    assert isinstance(result, str)


# Generated at 2022-06-12 02:08:54.229351
# Unit test for method user of class Path
def test_Path_user():
    path_linux = Path()
    path_windows = Path('win32')
    user_linux = path_linux.user()
    user_windows = path_windows.user()
    user_linux_exp = '/home/hae'
    user_windows_exp = 'C:\\Users\\hae'
    assert user_linux == user_linux_exp
    assert user_windows == user_windows_exp

# Generated at 2022-06-12 02:08:56.480132
# Unit test for method user of class Path
def test_Path_user():
    # code...
    path = Path()
    print(path.user())


# Generated at 2022-06-12 02:08:58.672233
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)

# Generated at 2022-06-12 02:09:00.729852
# Unit test for method user of class Path
def test_Path_user():
    print("Testing Path.user()")
    path = Path()
    print(path.user())
    print(path.user())
    print(path.user())

#------------------------------------------------------------------

# Generated at 2022-06-12 02:09:04.135777
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import DataType
    p = Path(platform='linux')
    paths = p.user()
    p.seed(41)
    for _ in range(100):
        assert p.random.choice(USERNAMES, data_type=DataType.USERNAME) in paths
