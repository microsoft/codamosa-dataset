

# Generated at 2022-06-12 02:06:30.616553
# Unit test for method user of class Path
def test_Path_user():
    path_provider = Path()
    result = path_provider.user()
    if 'win' in path_provider.platform:
        assert result.startswith('C:\\Users\\')
    else:
        assert result.startswith('/home/')

# Generated at 2022-06-12 02:06:38.145223
# Unit test for constructor of class Path
def test_Path():
    os_type = sys.platform
    path = Path(platform = os_type)

    assert path != None
    assert path._pathlib_home != None
    assert path._pathlib_home.parent != None
    assert path._pathlib_home.parent.parent != None

    if os_type == "linux" or os_type == "darwin":
        assert path.platform == os_type
        assert path._pathlib_home.parent == PurePosixPath('/')
        assert path._pathlib_home.parent.parent == PurePosixPath('/')
    elif os_type == "win32" or os_type == "win64":
        assert path.platform == os_type
        assert path._pathlib_home.parent == PureWindowsPath('')
        assert path._pathlib_home.parent.parent == PureWindows

# Generated at 2022-06-12 02:06:47.656174
# Unit test for method user of class Path
def test_Path_user():
    print("\n" + "#" * 3 + " " + "class Path" + " " + "#" * 3 + "\n")

    print("\t" + "Test method Path.user()")

    base = Path()
    print("\t\t" + "base.user() = " + base.user())
    base = Path("darwin")
    print("\t\t" + "base.user() = " + base.user())
    base = Path("win32")
    print("\t\t" + "base.user() = " + base.user())
    base = Path("win64")
    print("\t\t" + "base.user() = " + base.user())


# Generated at 2022-06-12 02:06:54.193814
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert str(path._pathlib_home).startswith('/home')
    path = Path('darwin')
    assert path.platform == 'darwin'
    assert str(path._pathlib_home).startswith('/Users')
    path = Path('win32')
    assert path.platform == 'win32'
    assert str(path._pathlib_home).startswith('C:\\Users')


# Generated at 2022-06-12 02:06:56.409588
# Unit test for constructor of class Path
def test_Path():
    a = Path('linux')
    assert a.platform == 'linux'
    assert a._pathlib_home == PurePosixPath('/home')

# Generated at 2022-06-12 02:06:58.680190
# Unit test for method user of class Path
def test_Path_user():
    mimesis = Path()
    result = mimesis.user()
    print(result)


# Generated at 2022-06-12 02:07:05.138374
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.data import USERNAMES
    from mimesis.enums import Gender
    path = Path()
    user = path.user()
    assert user in USERNAMES or user.capitalize() in USERNAMES
    path_ = Path(gender=Gender.MALE)
    user = path_.user()
    assert user in USERNAMES or user.capitalize() in USERNAMES
    path__ = Path(gender=Gender.FEMALE)
    user = path__.user()
    assert user in USERNAMES or user.capitalize() in USERNAMES


# Generated at 2022-06-12 02:07:13.331779
# Unit test for method user of class Path
def test_Path_user():
# Create a mock pathlib.Path object
    def mock_pathlib_home():
        return 'C:\\Users'
    Path._pathlib_home = mock_pathlib_home()
# Generate a random path to user
    result = Path().user()
    assert result in "C:\\Users\\Shaneka"
# Create a mock pathlib.Path object
    def mock_pathlib_home():
        return '\\home\\'
    Path._pathlib_home = mock_pathlib_home()
# Generate a random path to user
    result = Path().user()
    assert result in "\\home\\cecil"
    assert result not in "C:\\Users\\Shaneka"


# Generated at 2022-06-12 02:07:18.429578
# Unit test for constructor of class Path
def test_Path():
    provider = Path(platform='win32', seed=104)
    print(provider.root())
    print(provider.home())
    print(provider.user())
    print(provider.users_folder())
    print(provider.dev_dir())
    print(provider.project_dir())


if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-12 02:07:19.347972
# Unit test for method user of class Path
def test_Path_user():
    r = Path()
    r.user()