

# Generated at 2022-06-12 02:06:26.097944
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    users = [p.user() for i in range(10)]
    print(users)


# Generated at 2022-06-12 02:06:28.409898
# Unit test for method user of class Path
def test_Path_user():
    p=Path()
    assert len(p.user()) >= 8
    assert len(p.user()) <= 15


# Generated at 2022-06-12 02:06:31.520280
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='win32')
    print(p.project_dir())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())


if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-12 02:06:35.557475
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""

    # pylint: disable=line-too-long
    path = Path(platform='linux')
    assert path.platform == 'linux'
    assert path._pathlib_home == PurePosixPath('home')
    assert path._pathlib_home.parent != PurePosixPath('home/')


# Generated at 2022-06-12 02:06:39.445070
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.drive == ''
    assert p._pathlib_home.parts[-1] == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-12 02:06:42.501022
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    user = path.user()
    assert user.startswith("/home/")
    assert user != "/home/"


# Generated at 2022-06-12 02:06:44.756543
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/victor' or path.user() == '/home/vickie' 


# Generated at 2022-06-12 02:06:47.301855
# Unit test for method user of class Path
def test_Path_user():
    seed=0
    for i in range(10):
        path = Path()
        path.random.seed(seed)
        assert path.user() == "/home/toshia"
        seed += 1


# Generated at 2022-06-12 02:06:49.998324
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.root()
    p.home()
    p.user()
    p.users_folder()
    p.dev_dir()
    p.project_dir()



# Generated at 2022-06-12 02:06:56.824096
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p.platform, str)
    assert isinstance(p._pathlib_home, PurePosixPath)
    assert isinstance(p._pathlib_home.parent, PurePosixPath)

    q = Path(platform='win32')
    assert isinstance(q.platform, str)
    assert isinstance(q._pathlib_home, PureWindowsPath)
    assert isinstance(q._pathlib_home.parent, PureWindowsPath)
