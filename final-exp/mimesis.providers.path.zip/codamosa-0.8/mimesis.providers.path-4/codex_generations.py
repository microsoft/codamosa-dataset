

# Generated at 2022-06-12 02:06:31.646771
# Unit test for method user of class Path
def test_Path_user():
    path_provider = Path()
    assert path_provider.user() == '/home/oretha'
    path_provider = Path('win32')
    assert path_provider.user() == 'C:\\Users\\Sherita'
    return True


# Generated at 2022-06-12 02:06:34.838257
# Unit test for method user of class Path
def test_Path_user():
    # path = Path()
    # print(path.user())
    for i in range(1):
        path = Path()
        print(path.user())

if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-12 02:06:37.251048
# Unit test for method user of class Path
def test_Path_user():
    for i in range(10):
        print(Path().user())


# Generated at 2022-06-12 02:06:39.096179
# Unit test for method user of class Path
def test_Path_user():
    os.system("cd .. && pytest tests/test_path.py::test_Path_user")


# Generated at 2022-06-12 02:06:41.823602
# Unit test for method user of class Path
def test_Path_user():
    path = Path('win32')
    assert path.user() == str(path._pathlib_home / 'Oretha')



# Generated at 2022-06-12 02:06:43.605069
# Unit test for method user of class Path
def test_Path_user():
    path=Path()
    assert (path.user() == str(path._pathlib_home / 'oretha'))


# Generated at 2022-06-12 02:06:46.443559
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert len(result) > 0
    assert result != None
    assert result != ""
    assert result != " "
    assert result != "   "

# Generated at 2022-06-12 02:06:48.780805
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed()
    assert path.user() == '/home/sherika'
test_Path_user()


# Generated at 2022-06-12 02:06:49.965003
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() is not None
    print(path.user())



# Generated at 2022-06-12 02:06:53.107343
# Unit test for method user of class Path
def test_Path_user():
    # given
    path = Path()
    # when
    result = path.user()
    # then
    assert isinstance(result, str)
    assert len(str.split(result, '/')) == 3
