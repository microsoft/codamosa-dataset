

# Generated at 2022-06-12 02:06:35.038132
# Unit test for constructor of class Path
def test_Path():
    """Test class Path and it's methods."""
    path = Path(platform='linux')
    assert path.random.choice(FOLDERS) in path.root()  # test root method
    assert path.random.choice(FOLDERS) in path.home()  # test home method
    assert path.random.choice(USERNAMES) in path.dev_dir()  # test dev_dir method
    assert path.random.choice(PROGRAMMING_LANGS) in path.dev_dir()  # test dev_dir method
    assert path.random.choice(PROGRAMMING_LANGS) in path.users_folder()  # test users_folder method

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-12 02:06:39.540711
# Unit test for constructor of class Path
def test_Path():
    from mimesis.exceptions import NonEnumerableError
    path = Path()
    user = path.user()
    print(user)
    assert(user)
    assert(path.home())
    assert(path.dev_dir())
    assert(path.project_dir())

# Generated at 2022-06-12 02:06:41.386544
# Unit test for constructor of class Path
def test_Path():
    obj = Path()
    print("test_Path", obj)


# Generated at 2022-06-12 02:06:44.371519
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    users = []
    for i in range(0, 100):
        users.append(path.user())
    print(users)


# Generated at 2022-06-12 02:06:45.531463
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)



# Generated at 2022-06-12 02:06:52.465213
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from pathlib import PureWindowsPath

    russian_male = RussiaSpecProvider(gender=Gender.MALE)
    path = Path(platform='windows')

    user = russian_male.username()
    user_uppercase = user.capitalize()
    user_lowcase = user.lower()
    assert path.user() == str(PureWindowsPath('C:') / 'Users' / user_uppercase)
    assert path.user() == str(PureWindowsPath('C:') / 'Users' / user_lowcase)

# Generated at 2022-06-12 02:07:00.019813
# Unit test for constructor of class Path
def test_Path():

    def __eq(actual: str, expected: str):
        assert str(actual) == str(expected)

    path = Path()
    __eq(path.root(), '/')
    __eq(path.home(), '/home')
    __eq(path.users_folder(), '/home/taneka/Pictures')
    __eq(path.dev_dir(), '/home/sherrell/Development/Python')
    __eq(path.project_dir(), '/home/sherika/Development/Falcon/mercenary')

# Generated at 2022-06-12 02:07:08.289046
# Unit test for constructor of class Path
def test_Path():
    from mimesis.enums import Platform
    p = Path()
    print(p.user())
    print(p.home())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    p = Path(platform=Platform.WINDOWS)
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    p = Path(platform=Platform.WINDOWS)
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())

# Generated at 2022-06-12 02:07:15.982854
# Unit test for method user of class Path
def test_Path_user():
    """Execute a unit test for method user of class Path."""
    # Given test case data
    data = [
        ('linux', '/home/river'),
        ('darwin', '/home/sean'),
        ('win32', 'C:\\Users\\marijo'),
        ('win64', 'C:\\Users\\marizza'),
        ('bad_platform', 'C:\\Users\\bad_platform')
    ]
    # Loop over the test cases
    for platform, user in data:
        # Given a Path instance
        path = Path(platform=platform)
        # When the a random user is generated
        result = path.user()
        # Then the result should be one of the users
        assert result == user

# Generated at 2022-06-12 02:07:23.959597
# Unit test for method user of class Path
def test_Path_user():
    # Test with platform Windows
    p = Path('win32')
    user = p.user()
    if user.startswith("C:\\Users\\") and len(user.split("\\")) == 3:
        print("Metodo user del Path con el sistema operativo Windows correcto")
    else:
        print("Error en metodo user del Path con el sistema operativo Windows")
    # Test with platform Linux
    p = Path('linux')
    user = p.user()
    if user.startswith("/home/") and len(user.split("/")) == 3:
        print("Metodo user del Path con el sistema operativo Linux correcto")
    else:
        print("Error en metodo user del Path con el sistema operativo Linux")
