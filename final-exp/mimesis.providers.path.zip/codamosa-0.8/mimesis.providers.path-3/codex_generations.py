

# Generated at 2022-06-12 02:06:34.731164
# Unit test for method user of class Path

# Generated at 2022-06-12 02:06:37.622774
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    assert 'home' in path.user()


# Generated at 2022-06-12 02:06:38.916704
# Unit test for method user of class Path
def test_Path_user():
    gen = Path()
    print(gen.user())


# Generated at 2022-06-12 02:06:41.611217
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert isinstance(result, str)
    assert len(result) > 1

# Generated at 2022-06-12 02:06:43.934232
# Unit test for method user of class Path
def test_Path_user():
    paths = Path()
    user = paths.user()
    assert isinstance(user, str)


# Generated at 2022-06-12 02:06:53.244476
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema
    from mimesis.providers.path import Path

    path = Path(platform='linux')

    names = {"male": [], "female": []}
    for i in range(100):
        schema = Schema(FIELDS=[Field('user', provider=Path, gender=Gender.MALE)])
        names["male"].append(schema.create()['user'])

        schema = Schema(FIELDS=[Field('user', provider=Path, gender=Gender.FEMALE)])
        names["female"].append(schema.create()['user'])

    def assert_contains(s, sub, container):
        assert s.count(sub) == container.count(sub)


# Generated at 2022-06-12 02:06:56.011102
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    expected_value = '/home/sherika'
    value = path.user()
    assert value == expected_value

# Generated at 2022-06-12 02:07:00.623766
# Unit test for method user of class Path
def test_Path_user():
    a = Path('linux')
    b = Path('darwin')
    c = Path('win32')
    d = Path('win64')
    print(a.user())
    print(b.user())
    print(c.user())
    print(d.user())


# Generated at 2022-06-12 02:07:02.069730
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert not path.user() == None
    assert type(path.user()) == str
    print("Path().user(): Success")


# Generated at 2022-06-12 02:07:03.683315
# Unit test for method user of class Path
def test_Path_user():
    import sys
    p = Path(platform=sys.platform)
    assert len(p.user()) > 0