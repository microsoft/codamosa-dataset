

# Generated at 2022-06-12 02:06:37.314874
# Unit test for constructor of class Path
def test_Path():
    # Unit test without giving any platform value
    p1 = Path()
    assert isinstance(p1, Path)

    # Unit test giving platform value as linux
    p2 = Path('linux')
    assert isinstance(p2, Path)

    # Unit test giving platform value as darwin
    p3 = Path('darwin')
    assert isinstance(p3, Path)

    # Unit test giving platform value as win32
    p4 = Path('win32')
    assert isinstance(p4, Path)

    # Unit test giving platform value as win64
    p5 = Path('win64')
    assert isinstance(p5, Path)

    # Unit test giving platform value as freebsd
    p6 = Path('freebsd')
    assert isinstance(p6, Path)

    # Unit test giving platform value as openbs

# Generated at 2022-06-12 02:06:42.708863
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform in PLATFORMS.keys()
    assert Path('win32').platform == 'win32'
    assert Path('win64').platform == 'win64'
    assert Path('linux').platform == 'linux'
    assert Path('darwin').platform == 'darwin'
    assert Path('junk').platform in PLATFORMS.keys()


# Generated at 2022-06-12 02:06:47.300602
# Unit test for method user of class Path
def test_Path_user():
    print("Testing test_Path_user")
    test_class = Path()
    for i in range(30):
        print(test_class.user())
    if sys.platform.startswith('win'):
        assert test_class.user().startswith('\\home')
    else:
        assert test_class.user().startswith('/home')


# Generated at 2022-06-12 02:06:48.602467
# Unit test for method user of class Path
def test_Path_user():
    res = Path().user()
    assert res == '/Users/stacie'

# Generated at 2022-06-12 02:06:49.784771
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/shers'


# Generated at 2022-06-12 02:06:50.734917
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-12 02:06:51.961562
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform


# Generated at 2022-06-12 02:06:56.300973
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


# Generated at 2022-06-12 02:06:57.618584
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-12 02:07:06.934782
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.enums import ProgrammingLanguage
    from mimesis.enums import Specialization
    from mimesis.enums import TextType
    from mimesis.enums import UserStatus
    from mimesis.enums import OperatingSystem
    from mimesis.providers.os import OS
    from mimesis.providers.internet.http import HTTP
    from mimesis.providers.internet.tech import Tech
    from mimesis.providers.internet.user_agent import UserAgent
    from mimesis.providers.internet.network import Network
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.finance import Finance