

# Generated at 2022-06-12 02:06:28.372322
# Unit test for method user of class Path
def test_Path_user():
    print("method user")


# Generated at 2022-06-12 02:06:30.758768
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/bernice'
    assert p.user() == '/home/cosimo'
    assert p.user() == '/home/oretha'

# Generated at 2022-06-12 02:06:36.542265
# Unit test for method user of class Path
def test_Path_user():
    # Create and initialize object of class Path
    path = Path(platform='linux')

    # Create a list of user names
    users = [
        path.user() for _ in range(1000)
    ]

    # Assertions
    assert len(users) == 1000
    assert all(user.startswith('/home/') for user in users)

    p = Path(platform="linux")
    assert all(
        len(p.user().split('/')) == 3
        for _ in range(100)
    )

# Generated at 2022-06-12 02:06:39.401583
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(2)
    root_path_2 = '/home/jedidiah'
    assert path.user() == root_path_2


# Generated at 2022-06-12 02:06:41.386965
# Unit test for method user of class Path
def test_Path_user():
    path_user = Path()
    assert isinstance(path_user.user(), str)

# Generated at 2022-06-12 02:06:48.914626
# Unit test for method user of class Path

# Generated at 2022-06-12 02:06:50.257565
# Unit test for method user of class Path
def test_Path_user():
    a = Path()
    assert type(a.user()) == str
    assert len(a.user()) >= 3

# Generated at 2022-06-12 02:06:53.109333
# Unit test for method user of class Path
def test_Path_user():
    """Test the method user of class Path."""
    path = Path()
    user = path.user()

    if user is None:
        raise Exception('test_Path_user: user is None')



# Generated at 2022-06-12 02:06:57.000069
# Unit test for method user of class Path
def test_Path_user():
    print("\nusertest")
    platform = 'linux'
    p = Path(platform)
    print(p.user())
    assert(type(Path(platform).user()).__name__ == 'str')


# Generated at 2022-06-12 02:06:59.398851
# Unit test for method user of class Path
def test_Path_user():
    """Generate random user."""
    path = Path('linux')
    print(path.user())


# Generated at 2022-06-12 02:07:03.486761
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)


# Generated at 2022-06-12 02:07:05.966126
# Unit test for method user of class Path
def test_Path_user():
    from mimesis import Person
    person = Person("es")
    p = Path("linux")
    user = p.user()
    assert user == "/home/" + person.username("es").lower()


# Generated at 2022-06-12 02:07:08.300866
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform = 'linux')
    assert path.user() in FOLDERS


# Generated at 2022-06-12 02:07:15.716837
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(42)
    assert path.user() == '/home/brande'
    assert path.user() == '/home/johnetta'
    assert path.user() == '/home/kristine'
    assert path.user() == '/home/nichol'
    assert path.user() == '/home/eldora'
    assert path.user() == '/home/brendan'
    assert path.user() == '/home/danial'
    assert path.user() == '/home/tani'
    assert path.user() == '/home/tracy'
    assert path.user() == '/home/claudia'

# Generated at 2022-06-12 02:07:21.459546
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    assert Path().user() == '/home/cassy'
    assert Path('win32').user() == 'C:\\Users\\Maxie'
    assert Path('win64').user() == 'C:\\Users\\Alison'
    assert Path('darwin').user() == '/Users/anissa'
    assert Path('linux').user() == '/home/kelvin'


# Generated at 2022-06-12 02:07:23.633141
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender

    p = Path()
    assert 'home/' in p.user()


# Generated at 2022-06-12 02:07:25.485789
# Unit test for method user of class Path
def test_Path_user():
    # Given
    path = Path()

    # When
    path = path.user()

    # Then
    assert path == '/home/noreen'



# Generated at 2022-06-12 02:07:27.006456
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert str(p.user()) == str(p.user())

# Generated at 2022-06-12 02:07:28.522522
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    t = Path()
    assert t.user() == '/home/cary'

# Generated at 2022-06-12 02:07:29.572798
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
