

# Generated at 2022-06-12 02:06:26.369862
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform is sys.platform



# Generated at 2022-06-12 02:06:28.023919
# Unit test for method user of class Path
def test_Path_user():
    path_ = Path()
    path_.user()


# Generated at 2022-06-12 02:06:29.840776
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.dev_dir() == '/home/sherika/Development/Falcon/mercenary'

test_Path()

# Generated at 2022-06-12 02:06:31.703857
# Unit test for method user of class Path
def test_Path_user():
    for i in range(20):
        assert Path().user()




# Generated at 2022-06-12 02:06:33.165470
# Unit test for method user of class Path
def test_Path_user():
    string = 'user'
    assert Path().user() == string

# Generated at 2022-06-12 02:06:35.193370
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.Meta.name == 'path'
    assert p.platform == sys.platform

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-12 02:06:38.482719
# Unit test for constructor of class Path
def test_Path():
    print("\ntest Path.__init__")
    path = Path()
    assert path.platform in ['linux', 'darwin', 'win32', 'win64']


# Generated at 2022-06-12 02:06:40.349983
# Unit test for method user of class Path
def test_Path_user():
    # localhost:5000/api/path/user
    # >> /home/devon
    pass


# Generated at 2022-06-12 02:06:42.450176
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user, str)
    assert len(user) > 0


# Generated at 2022-06-12 02:06:43.366257
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user()

# Generated at 2022-06-12 02:06:50.204884
# Unit test for method user of class Path
def test_Path_user():
    # Init Path
    path = Path()
    print(path.user())


# Generated at 2022-06-12 02:06:55.914309
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path(platform='linux')
    assert path_1.user() == '/home/bennie'
    assert path_1.user() == '/home/samara'
    assert path_1.user() == '/home/raymundo'
    assert path_1.user() == '/home/cortney'
    assert path_1.user() == '/home/bobbie'

# Generated at 2022-06-12 02:06:59.822023
# Unit test for method user of class Path
def test_Path_user():
    
    path = Path()
    assert isinstance(path, Path) is True
    
    us = path.user()
    assert isinstance(us, str) is True
    print('Path.user() test successful!\n')



# Generated at 2022-06-12 02:07:02.717547
# Unit test for method user of class Path
def test_Path_user():
    for i in range(10):
        p = Path().user()
        if p.count('/') == 3:
            print(p)
            break
    else:
        raise AssertionError('"/home/<user>" is excepted.')

# Generated at 2022-06-12 02:07:05.923684
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.builtins import US_EN
    from mimesis.providers.path import Path

    t = US_EN(seed=1)
    p = Path('linux', t.seed)
    res = p.user()
    assert res == '/home/leanne'

# Generated at 2022-06-12 02:07:07.897311
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    print('user:', user)

if __name__=="__main__":
    test_Path_user()

# Generated at 2022-06-12 02:07:09.206504
# Unit test for method user of class Path
def test_Path_user():

    test = Path()
    assert type(test.user()) == str

# Generated at 2022-06-12 02:07:10.562870
# Unit test for method user of class Path
def test_Path_user():
    return True

if __name__ == '__main__':
    print(Path().user())

# Generated at 2022-06-12 02:07:20.593867
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()

# Generated at 2022-06-12 02:07:26.242125
# Unit test for method user of class Path
def test_Path_user():
    path_linux = Path('linux')
    path_macOS = Path('darwin')
    path_win32 = Path('win32')
    path_win64 = Path('win64')
    #print('linux: ' + str(path_linux.user()))
    #print('macOS: ' + str(path_macOS.user()))
    #print('win32: ' + str(path_win32.user()))
    #print('win64: ' + str(path_win64.user()))


# Generated at 2022-06-12 02:07:38.600482
# Unit test for method user of class Path
def test_Path_user():
    actual = Path().user()
    expected = '/home/oretha'
    assert actual == expected, f'Should be {expected}, got {actual}'

# Generated at 2022-06-12 02:07:42.510925
# Unit test for method user of class Path
def test_Path_user():
    """
    Test for Path_user
    :return:
    """

    p=Path()
    ret=p.user()
    print("ret=%s"%(ret,))
    pass


# Generated at 2022-06-12 02:07:45.532104
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    p = Person('en')
    assert p.gender == Gender.MALE
    assert p.gender == Gender.FEMALE

    print('Path.user() => {0}'.format(p.gender))


# Generated at 2022-06-12 02:07:48.172076
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range(10):
        home = p.user()
        assert home == '/home/oretha' or home == 'C:\\Users\\Oswald'

# Generated at 2022-06-12 02:07:50.008682
# Unit test for method user of class Path
def test_Path_user():
    """Example of unit test for Path#user."""
    p = Path()
    p.seed(1)
    assert p.user() == '/home/cody'

# Generated at 2022-06-12 02:07:51.742759
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    assert str(path.user()) == '/home/oretha'

# Generated at 2022-06-12 02:07:55.366136
# Unit test for method user of class Path
def test_Path_user():
    # Correct
    user1 = Path(platform='linux').user()
    user2 = Path(platform='darwin').user()
    user3 = Path(platform='win32').user()
    user4 = Path(platform='win64').user()
    # Error
    user5 = Path(platform='linux').user()
    assert user1 == '/home/kamilah'
    assert user2 == '/home/jarrett'
    assert user3 == '\\home\\sang'
    assert user4 == '\\home\\leonor'
    assert user5 != user1


# Generated at 2022-06-12 02:07:58.209098
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""

    path = Path()
    user = path.user()

    assert user
    assert len(user) > 0
    assert isinstance(user, str)


# Generated at 2022-06-12 02:07:59.551942
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert type(path.user()) == str

# Generated at 2022-06-12 02:08:04.727429
# Unit test for method user of class Path
def test_Path_user():
    from pathlib import PurePosixPath, PureWindowsPath

    platform = 'linux'
    users = USERNAMES
    _pathlib_home = PurePosixPath()
    _pathlib_home /= PLATFORMS[platform]['home']

    user = users[0].lower()
    expect = str(_pathlib_home / user)

    result = expect
    assert result == expect