

# Generated at 2022-06-12 02:06:28.410295
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    """
        Test the method user of class Path
        Test random user
    """
    print(path.user())


# Generated at 2022-06-12 02:06:29.126042
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path
    path = Path('linux')
    assert path

# Generated at 2022-06-12 02:06:32.974866
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print("path.root() = ", path.root())
    print("path.home() = ", path.home())
    print("path.user() = ", path.user())
    print("path.users_folder() = ", path.users_folder())
    print("path.dev_dir() = ", path.dev_dir())
    print("path.project_dir = ", path.project_dir())


# Generated at 2022-06-12 02:06:35.617574
# Unit test for method user of class Path
def test_Path_user():
    """Test for Path.user()"""
    from mimesis.builtins import EN

    p = Path(locale=EN)
    assert isinstance(p.user(), str)
    assert len(p.user()) > 0


# Generated at 2022-06-12 02:06:38.788357
# Unit test for constructor of class Path
def test_Path():
    path = Path()

    assert isinstance(path, Path)
    assert isinstance(path.random, random.Random)

# Define tests for class Path

# Generated at 2022-06-12 02:06:40.634143
# Unit test for method user of class Path
def test_Path_user():
    user = Path().user()
    assert user != ""
    assert user is not None
    

# Generated at 2022-06-12 02:06:44.445274
# Unit test for constructor of class Path
def test_Path():
    # Path object
    path = Path()
    # Unit test
    assert isinstance(path, Path), 'Path object is not an instance of class Path'

# Unit test method root of Path object

# Generated at 2022-06-12 02:06:45.932483
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""
    path = Path()
    assert isinstance(path, Path)

# Generated at 2022-06-12 02:06:47.528283
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    actual = path.user()
    expected = "C:/Users/User"
    assert actual == expected

# Generated at 2022-06-12 02:06:49.184581
# Unit test for constructor of class Path
def test_Path():
    sp = Path(platform='linux')
    assert sp.platform == 'linux'


# Generated at 2022-06-12 02:06:52.556171
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == "/home/mai"

# Generated at 2022-06-12 02:06:56.463579
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path._pathlib_home = PurePosixPath('/home')
    path.random.choice = lambda d: 'sherika'
    assert path.user() == '/home/sherika'



# Generated at 2022-06-12 02:07:03.306049
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    
    path = Path()
    path.random.seed(0)
    result = path.user()
    assert result =='/home/james'
    
    path.random.seed(0)
    result = path.user(gender=Gender.MALE)
    assert result == '/home/james'
    
    path.random.seed(0)
    result = path.user(gender=Gender.FEMALE)
    assert result == '/home/james'
    

# Generated at 2022-06-12 02:07:05.846872
# Unit test for method user of class Path
def test_Path_user():
  from mimesis.enums import Platform
  from mimesis.builtins import Path
  path = Path(platform=Platform.ANDROID)
  print(path.user())


# Generated at 2022-06-12 02:07:09.463350
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    u = p.user()
    assert isinstance(u, str), "Should be of type <str>"
    assert u.startswith('/'), "Should be a path"
    assert u.endswith('/'), "Should end with /"
    assert u.count('/') == 3, "Should be 3"


# Generated at 2022-06-12 02:07:14.277784
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    list_paths = []
    for _ in range(0,1000):
        current_path = path.user()
        assert '..' not in current_path and '/home/' in current_path
        if current_path not in list_paths:
            list_paths.append(current_path)
    assert len(list_paths) > 500


# Generated at 2022-06-12 02:07:15.791743
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    # Assertion
    assert path.user() != ''


# Generated at 2022-06-12 02:07:18.849436
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    assert (user.startswith("/home"))


# Generated at 2022-06-12 02:07:20.285011
# Unit test for method user of class Path
def test_Path_user():
    """Test user method."""
    assert Path().user() == '/home/earlean'


# Generated at 2022-06-12 02:07:21.295304
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()

# Generated at 2022-06-12 02:07:25.975167
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/marline'

# Generated at 2022-06-12 02:07:27.948851
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    expected = '/home/yajaira'
    actual = path.user()
    assert actual == expected

# Generated at 2022-06-12 02:07:29.250892
# Unit test for method user of class Path
def test_Path_user():
    d = Path()
    users = set()

    for x in range(100):
        users.add(d.user())

    assert len(users) >= len(USERNAMES)

# Generated at 2022-06-12 02:07:31.417511
# Unit test for method user of class Path
def test_Path_user():
    path_object = Path()
    assert path_object.user().startswith('/home')

# Generated at 2022-06-12 02:07:32.925061
# Unit test for method user of class Path
def test_Path_user():
    for i in range(10):
        sample = Path().user()
        assert sample != ''
        print(sample)

# Generated at 2022-06-12 02:07:34.058165
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()


# Generated at 2022-06-12 02:07:43.429785
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    assert path.user() == '/home/edward'
    assert path.user() == '/home/michael'
    assert path.user() == '/home/bryan'
    assert path.user() == '/home/jason'
    path = Path('win32')
    assert path.user() == 'C:\\Users\\Joseph'
    assert path.user() == 'C:\\Users\\Howard'
    assert path.user() == 'C:\\Users\\George'
    assert path.user() == 'C:\\Users\\Marie'


# Generated at 2022-06-12 02:07:44.676255
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == str(PureWindowsPath()/'Users' / 'Kiersten')

# Generated at 2022-06-12 02:07:45.862521
# Unit test for method user of class Path
def test_Path_user():
    for i in range(10):
        print(Path().user())

# Generated at 2022-06-12 02:07:46.995210
# Unit test for method user of class Path
def test_Path_user():
    """Test method user."""
    obj = Path()
    res = obj.user()
    assert len(res) > 0