

# Generated at 2022-06-12 02:06:33.588751
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import OperatingSystem
    from mimesis.builtins import Path
    from mimesis.builtins import Text
    import mimesis.utils as u

    # pylint: disable=redefined-outer-name
    user_map = {'win32': 'Amado',
                'win64': 'Antoine',
                'linux': 'Arcelia',
                'darwin': 'Ashton'}

    platform = u.get_platform()
    if platform not in ('win32', 'win64', 'linux', 'darwin'):
        raise ValueError('Invalid platform')
    if platform == 'win32' and not u.is_32bit():
        t = Text('en')
        raise ValueError(f'Incorrect platform: {t.fake.text(100)}')


# Generated at 2022-06-12 02:06:35.630939
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-12 02:06:38.440838
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert(p._pathlib_home / p.random.choice(USERNAMES)).is_dir()


# Generated at 2022-06-12 02:06:40.305887
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/aaliyah'



# Generated at 2022-06-12 02:06:42.378827
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    res = path.user()
    assert res in ['/home/taneka', '/home/oretha']

# Generated at 2022-06-12 02:06:43.287339
# Unit test for constructor of class Path
def test_Path():
    Path()


# Generated at 2022-06-12 02:06:49.271856
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    home_path = p._pathlib_home
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    # Expected output /home/taneka
    # Expected output /home/taneka/Pictures
    # Expected output /home/taneka/Development/Python
    # Expected output /home/taneka/Development/Python/mercenary


# Generated at 2022-06-12 02:06:50.474741
# Unit test for constructor of class Path
def test_Path():
    p = Path("win32")
    assert p is not None

# Generated at 2022-06-12 02:06:51.678592
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    print(user)

# Generated at 2022-06-12 02:06:54.396374
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'
    assert Path().user() == '/home/rashida'
