

# Generated at 2022-06-12 02:06:29.007149
# Unit test for constructor of class Path
def test_Path():
    # init the class, no input
    class_path = Path()
    # call the class to generate return
    class_path.root()

# Generated at 2022-06-12 02:06:30.183069
# Unit test for method user of class Path
def test_Path_user():
    path = Path()

# Generated at 2022-06-12 02:06:30.800292
# Unit test for method user of class Path
def test_Path_user():
    assert True

# Generated at 2022-06-12 02:06:32.607295
# Unit test for constructor of class Path
def test_Path():
    p = Path()


# Generated at 2022-06-12 02:06:34.803524
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user_path = path.user()
    assert user_path in ['/home/oretha', 'C:\\Users\\ORETHA']


# Generated at 2022-06-12 02:06:39.540966
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    p = Path()
    p.seed(123456789)
    assert p.user() == '/home/brook'
    p.gender = Gender.FEMALE
    assert p.user() == '/home/fawn'


# Generated at 2022-06-12 02:06:41.386486
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())



# Generated at 2022-06-12 02:06:42.704544
# Unit test for constructor of class Path
def test_Path():
    path = Path('linux')
    assert path


# Generated at 2022-06-12 02:06:45.294007
# Unit test for method user of class Path
def test_Path_user():
    # test_Path_user
    path = Path()
    user = path.user()
    assert (user is not None)
    assert (isinstance(user, str))


# Generated at 2022-06-12 02:06:50.323226
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for _ in range(10):
        print(p.user())
# Output:
# /home/oretha
# /home/davina
# /home/keeley
# /home/taneka
# /home/lavette
# /home/lavette
# /home/taneka
# /home/deedee
# /home/sherica
# /home/deedee


# Generated at 2022-06-12 02:06:57.618660
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert type(p.root()) == str
    assert type(p.home()) == str
    assert type(p.user()) == str
    assert type(p.users_folder()) == str
    assert type(p.dev_dir()) == str
    assert type(p.project_dir()) == str

test_Path()

# Generated at 2022-06-12 02:06:59.583430
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform

# Generated at 2022-06-12 02:07:05.217120
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender

    p = Path(platform='win32')
    print(p.user())
    # Out: C:\Users\devon
    p2 = Path(platform='win32')
    p2.seed(2)
    p2.random.seed_locale('ru', gender=Gender.FEMALE)
    print(p2.user())
    # Out: C:\Users\Каратанский


# Generated at 2022-06-12 02:07:07.540947
# Unit test for method user of class Path
def test_Path_user():
    path_object = Path()
    path_object.random.sample(USERNAMES, 2)
    assert path_object._pathlib_home / path_object._pathlib_home.name


# Generated at 2022-06-12 02:07:09.404605
# Unit test for constructor of class Path
def test_Path():
    path1 = Path()
    assert path1.platform == sys.platform
    path2 = Path('darwin')
    assert path2.platform == 'darwin'



# Generated at 2022-06-12 02:07:14.980984
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path"""
    from pathlib import PurePosixPath
    from mimesis.data import USERNAMES
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    userProvider = Person('en')
    pathObj = Misc('en')
    pathObj.gender = Gender.MALE
    pathObj.userInstance = userProvider

    i = 0
    while i < 10:
        pathString = str(pathObj.path.user())
        pathString_splited = pathString.split('/')
        pathString_splited[0] = 'x'
        pathString_splited = '/'.join(pathString_splited)
        pathList = PurePosixPath(pathString_splited).parts



# Generated at 2022-06-12 02:07:18.158918
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, BaseProvider)
    assert isinstance(p._pathlib_home, PurePosixPath)


# Generated at 2022-06-12 02:07:19.462068
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())

# Generated at 2022-06-12 02:07:21.360058
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    print(user)
    # '/home/camille'


# Generated at 2022-06-12 02:07:22.722197
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user, object)

