

# Generated at 2022-06-12 02:06:27.982815
# Unit test for method user of class Path
def test_Path_user():
    print("Testing method user from class Path")
    r = Path()
    r_user = str(r.user())
    print("Result: ", r_user)
    print("Expected: ", "/home/Edwards")


# Generated at 2022-06-12 02:06:33.718449
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert type(path.user()) is str
    assert '/home/' in path.user()
    assert '/home/' not in Path(platform='win32').user()
    assert path.user() != path.user()
    # Test upper character for Linux, MacOS and Windows
    for platform in ['linux', 'darwin', 'win32', 'win64']:
        path = Path(platform=platform)
        assert path.user() != path.user()
    # Test upper character for Linux, MacOS and Windows
    path = Path(platform='win32')
    assert path.user().split('\\')[-1].istitle()


# Generated at 2022-06-12 02:06:37.409859
# Unit test for method user of class Path
def test_Path_user():
    class TestPath(Path):
        class Meta: pass
    p = TestPath()
    assert callable(TestPath.user)
    assert isinstance(p.user(), str)

# Generated at 2022-06-12 02:06:42.014030
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='linux')
    result = p.dev_dir()
    assert result == '/home/terrence/Development/Ruby'
    p = Path(platform='darwin')
    result = p.dev_dir()
    assert result == '/home/jeraldine/Dev/Python'

# Generated at 2022-06-12 02:06:44.794830
# Unit test for method user of class Path
def test_Path_user():
  provider = Path(platform='win32')
  path = provider.user()
  print(path, type(path))
  assert path == 'C:\\Users\\Sallie'


# Generated at 2022-06-12 02:06:46.318484
# Unit test for method user of class Path
def test_Path_user():
    p=Path("linux")
    a=p.user()
    assert a


# Generated at 2022-06-12 02:06:48.865562
# Unit test for constructor of class Path
def test_Path():
  p = Path('linux')
  print(p.home())
  print(p.user())
  print(p.users_folder())
  print(p.dev_dir())
  print(p.project_dir())


if __name__ == '__main__':
  test_Path()

# Generated at 2022-06-12 02:06:52.797128
# Unit test for constructor of class Path
def test_Path():
    # Create instance of class Path
    path = Path()
    # Test type of returned value
    assert isinstance(path, Path),\
        'The returned value should be of type "Path"'
    # Test type of returned value
    assert isinstance(path.platform, str),\
        'The returned value should be of type "str"'
    # Test type of returned value
    assert isinstance(path._pathlib_home, PurePath),\
        'The returned value should be of type "PurePath"'


# Generated at 2022-06-12 02:06:55.349885
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert any(p.user() == "/home/cinzia" for i in range(1))


# Generated at 2022-06-12 02:06:57.232616
# Unit test for constructor of class Path
def test_Path():
    """Test the constructor of class Path."""
    assert isinstance(Path(), Path)

