

# Generated at 2022-06-12 02:06:29.567453
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import SpecialCharacter
    gl = Path(platform='linux')
    b = gl.user()
    c = gl.random.choice(USERNAMES)
    c = c.lower()
    assert b == '/home/' + c
    assert b == '/home/' + c + SpecialCharacter.SLASH.value

# Generated at 2022-06-12 02:06:36.255872
# Unit test for constructor of class Path
def test_Path():
    if sys.platform == "linux" or sys.platform == "linux2":
       path = Path()
       assert isinstance(path,Path)
       assert path.platform == "linux"
    elif sys.platform == "darwin":
       path = Path()
       assert isinstance(path,Path)
       assert path.platform == "darwin"
    elif sys.platform == "win32":
       path = Path()
       assert isinstance(path,Path)
       assert path.platform == "win32"
    else:
       raise ValueError("Platform not supported")


# Generated at 2022-06-12 02:06:38.482358
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    path = Path()
    path.user() == '/home/oretha'


# Generated at 2022-06-12 02:06:39.401787
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform == sys.platform


# Generated at 2022-06-12 02:06:40.554757
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.home())

# Generated at 2022-06-12 02:06:42.704249
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert type(result) is str


# Generated at 2022-06-12 02:06:45.611626
# Unit test for method user of class Path
def test_Path_user():
    path = Path()  # Default platform
    path.seed(42)  # Use a fixed seed
    result = path.user()
    expected = '/home/tammera'
    assert result == expected


# Generated at 2022-06-12 02:06:47.893773
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    assert user.startswith('/home/')
    assert user.count('/') == 2


# Generated at 2022-06-12 02:06:50.592360
# Unit test for method user of class Path
def test_Path_user():
    path_provider = Path()
    s = path_provider.user()
    assert s != ''
    assert type(s) is str
    assert 'home' in s


# Generated at 2022-06-12 02:06:53.330570
# Unit test for method user of class Path
def test_Path_user():
    """assert that a string is returned"""
    from mimesis.builtins import Path
    path = Path()
    result = path.user()
    assert type(result) == str


# Generated at 2022-06-12 02:06:58.849018
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert isinstance(result, str)
    assert re.match('/home/.*', result)

# Generated at 2022-06-12 02:07:00.231909
# Unit test for method user of class Path
def test_Path_user():
    u = Path().user()
    print(u)


# Generated at 2022-06-12 02:07:03.852514
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform in PLATFORMS
    assert isinstance(path._pathlib_home, PureWindowsPath) or isinstance(path._pathlib_home, PurePosixPath)
    assert isinstance(path.random, self._get_random_type())



# Generated at 2022-06-12 02:07:05.375029
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert type(user) is str


# Generated at 2022-06-12 02:07:06.523105
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == "linux"

# Generated at 2022-06-12 02:07:08.728030
# Unit test for method user of class Path
def test_Path_user():
    from pprint import pprint
    path = Path()
    for i in range(10):
        pprint(path.user())

if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-12 02:07:18.430212
# Unit test for method user of class Path
def test_Path_user():
    from mimesis import Generic
    from mimesis.enums import Platform

    g = Generic()
    # Linux
    p = g._path.user()
    assert type(p) == str
    assert len(p.split('/')) == 3
    assert p.split('/')[2] in g.user_name().lower()

    # macOS
    p = g._path.user(platform=Platform.MACOS)
    assert len(p.split('/')) == 3
    assert p.split('/')[2] in g.user_name().lower()

    # Windows
    p = g._path.user(platform=Platform.WINDOWS)
    assert len(p.split('\\')) == 3
    assert p.split('\\')[2] in g.user_name().capitalize()

# Unit test

# Generated at 2022-06-12 02:07:23.933746
# Unit test for constructor of class Path
def test_Path():
    assert Path('linux') is not None
    assert Path('linux').platform == 'linux'
    assert Path('windows').platform == 'windows'
    assert Path('darwin').platform == 'darwin'
    assert Path('win32').platform == 'win32'
    assert Path('win64').platform == 'win64'
    assert Path('freebsd') is not None
    assert Path('freebsd').platform == 'freebsd'
    assert Path('netbsd') is not None
    assert Path('netbsd').platform == 'netbsd'
    assert Path('openbsd') is not None
    assert Path('openbsd').platform == 'openbsd'

# Generated at 2022-06-12 02:07:25.242746
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path) and path.platform == sys.platform

# Generated at 2022-06-12 02:07:27.216089
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert str(path._pathlib_home) == 'home'


# Generated at 2022-06-12 02:07:32.013476
# Unit test for method user of class Path
def test_Path_user():
    from pprint import pprint
    path = Path()
    pprint(path.user())

# Generated at 2022-06-12 02:07:34.921788
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p1 = Path('win32')
    for i in range(100):
        assert(p.user().startswith('/home/'))
        assert(p1.user().startswith('C:\\Users\\'))

# Generated at 2022-06-12 02:07:38.885549
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())
    #assert Path().user() in ['/home/devora', '/home/rosetta', '/home/jennifer']


# Generated at 2022-06-12 02:07:48.264246
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/taneka'
    assert p.user() == '/home/johna'
    assert p.user() == '/home/fawn'
    assert p.user() == '/home/benita'
    assert p.user() == '/home/alane'
    assert p.user() == '/home/michele'
    assert p.user() == '/home/gertrud'
    assert p.user() == '/home/deneen'
    assert p.user() == '/home/olene'
    assert p.user() == '/home/thad'
    assert p.user() == '/home/emerson'
    assert p.user() == '/home/keri'
    assert p.user() == '/home/kimbery'
    assert p.user()

# Generated at 2022-06-12 02:07:48.957553
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/danielle'

# Generated at 2022-06-12 02:07:50.317423
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    user = path.user()
    assert len(user) > 0


# Generated at 2022-06-12 02:07:52.124407
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform = 'win32')
    path.random.seed(945)
    user = path.user()
    assert user == 'C:\\Users\\oliver'


# Generated at 2022-06-12 02:07:53.195026
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    result = p.user()
    assert result == '/home/oretha'


# Generated at 2022-06-12 02:07:55.700047
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/arnoldo'


# Generated at 2022-06-12 02:07:57.649829
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '/Users/sherrell'