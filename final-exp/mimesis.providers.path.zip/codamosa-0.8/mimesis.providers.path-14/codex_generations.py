

# Generated at 2022-06-12 02:06:29.408727
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert len(p.user()) == 9


# Generated at 2022-06-12 02:06:30.620417
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)


# Generated at 2022-06-12 02:06:34.768384
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Platform
    path_linux = Path(platform=Platform.LINUX)
    print(path_linux.user())
    path_win = Path(platform=Platform.WINDOWS)
    print(path_win.user())


# Generated at 2022-06-12 02:06:37.211385
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/sharyn' 


# Generated at 2022-06-12 02:06:38.307024
# Unit test for method user of class Path
def test_Path_user():
    Path(platform='linux').user()


# Generated at 2022-06-12 02:06:40.174421
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    r = p.user()
    print(r)



# Generated at 2022-06-12 02:06:42.975215
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    username = str(p._pathlib_home.parent.joinpath(USERNAMES[0]))
    assert p.user() == username

# Generated at 2022-06-12 02:06:44.849661
# Unit test for method user of class Path
def test_Path_user():
    path_instance = Path()
    user = path_instance.user()
    assert user == '/home/oretha'

# Generated at 2022-06-12 02:06:45.688549
# Unit test for constructor of class Path
def test_Path():
    path = Path()


# Generated at 2022-06-12 02:06:49.402985
# Unit test for constructor of class Path
def test_Path():
    import mimesis.exceptions
    path = Path()
    assert path.platform == "linux"
    assert path.random
    assert path._pathlib_home == "/home"
    with mimesis.exceptions.UnsupportedPlatformError:
        path = Path(platform="macos")

# Generated at 2022-06-12 02:06:53.160347
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    path = Path()
    assert path is not None

# Generated at 2022-06-12 02:07:01.335543
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert len(path.user()) > 0
    assert isinstance(path.user(platform='linux'), str)
    assert len(path.user(platform='linux')) > 0
    assert isinstance(path.user(platform='win32'), str)
    assert len(path.user(platform='win32')) > 0
    assert isinstance(path.user(platform='win64'), str)
    assert len(path.user(platform='win64')) > 0
# END test_Path_user


# Generated at 2022-06-12 02:07:03.934365
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    assert p.user() == '/home/oretha'

    p = Path('win32')
    assert p.user() == 'C:\\Users\\Tanesha'



# Generated at 2022-06-12 02:07:05.136551
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-12 02:07:06.592044
# Unit test for method user of class Path
def test_Path_user():
    path_instance = Path()
    assert path_instance.user() == '/home/billye'


# Generated at 2022-06-12 02:07:08.552909
# Unit test for constructor of class Path
def test_Path():
    print(Path())


# Generated at 2022-06-12 02:07:09.735315
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert issubclass(p.__class__, Path)

# Generated at 2022-06-12 02:07:11.108728
# Unit test for method user of class Path
def test_Path_user():
    result1 = Path().user()
    result2 = Path().user()
    assert result1 != result2


# Generated at 2022-06-12 02:07:12.597864
# Unit test for constructor of class Path
def test_Path():
    path = Path('darwin')


# Generated at 2022-06-12 02:07:14.702455
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == 'linux'
    path = Path('win32')
    assert path.platform == 'win32'
