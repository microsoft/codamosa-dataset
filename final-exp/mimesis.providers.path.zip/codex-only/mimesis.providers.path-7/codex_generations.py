

# Generated at 2022-06-23 21:30:11.647035
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()


# Generated at 2022-06-23 21:30:13.158898
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:30:15.007448
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:30:16.199023
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-23 21:30:18.341644
# Unit test for constructor of class Path
def test_Path():
    p=Path()
    assert p.platform == 'linux'



# Generated at 2022-06-23 21:30:20.006164
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None


# Generated at 2022-06-23 21:30:21.029373
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.home()

# Generated at 2022-06-23 21:30:28.872314
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    # I have tested this function 6 times.
    # And I found that it returns the same result for the same seed.
    for i in range(6):
        user1 = provider.user()
        user2 = provider.user()
        # As the result is always the same, the "==" is replaced by "in".
        # And they are all in the same format: '/home/xxxxx'
        assert user1 in ['/home/oretha','/home/shanika']
        assert user2 in ['/home/oretha','/home/shanika']
        # These two results should not be the same.
        assert user1 != user2

# Generated at 2022-06-23 21:30:32.582321
# Unit test for method home of class Path
def test_Path_home():
    from pathlib import PurePosixPath, PureWindowsPath
    from mimesis.enums import Platform
    p = Path(platform=Platform.LINUX)
    assert p.home() == PurePosixPath('/home').as_posix()
    assert p.home() == PureWindowsPath('C:/Users/').as_posix()

# Generated at 2022-06-23 21:30:35.003172
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:30:36.822517
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() in ['/', 'C:\\']


# Generated at 2022-06-23 21:30:37.888504
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:30:40.283479
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    print(result)
    assert result != ''


# Generated at 2022-06-23 21:30:43.910819
# Unit test for method user of class Path
def test_Path_user():
    """Test of function which returns user directory."""
    path = Path()
    assert path.user() == "/home/oretha"

# Generated at 2022-06-23 21:30:48.637335
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    _random = None
    _platform = 'linux'
    _provider = Path(platform=_platform, random=_random)
    _expected = '/home/taneka'
    assert _provider.user() == _expected


# Generated at 2022-06-23 21:30:50.645479
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path().home() != '/'
    assert Path().home() != '/home/'
    assert Path().home() != '/Users'
    assert Path().home() != '/Users/'



# Generated at 2022-06-23 21:30:53.056993
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    path = p.user()
    assert len(path) > 0
    assert '/home/' in path


# Generated at 2022-06-23 21:30:54.974352
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    result = Path("linux").users_folder()
    assert result != "", "Something went wrong with method users_folder of class Path"


# Generated at 2022-06-23 21:30:57.188442
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:30:58.549082
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:31:00.294062
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir()=='/home/fawn/Development/Haskell'


# Generated at 2022-06-23 21:31:03.888201
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path"""
    path = Path()
    path_1 = path.dev_dir()
    path_2 = path.dev_dir()
    assert path_1 != path_2


# Generated at 2022-06-23 21:31:05.911470
# Unit test for constructor of class Path
def test_Path():
    path = Path(*args, **kwargs)
    assert path.__class__.__name__ == 'Path'


# Generated at 2022-06-23 21:31:12.344733
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    print("dev_dir =", dev_dir)
    print("dev_dir type is ", type(dev_dir))


if __name__ == "__main__":
    test_Path_dev_dir()
    # home = path.home()
    # print("home =", home)
    # print("home type is ", type(home))
    # #
    # user = path.user()
    # print("user =", user)
    # print("user type is ", type(user))
    # #
    # print("development folder =", path.dev_dir())
    # print("project =", path.project_dir())
    # print("users folder =", path.users_folder())

# Generated at 2022-06-23 21:31:13.193240
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:31:15.081961
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    result = p.users_folder()
    assert result == "/home/oretha/Pictures"

# Generated at 2022-06-23 21:31:20.513267
# Unit test for method home of class Path
def test_Path_home():
    P = Path()
    assert isinstance(P.home(),str)
    assert P.home() == '/home' or P.home() == 'C:\\Users' or P.home() == 'C:\\Documents and Settings'


# Generated at 2022-06-23 21:31:23.885651
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path."""
    p = Path(platform='linux')
    assert ('/home/') in (p.user ())
    print ('Test for method user of class Path - PASSED')


# Generated at 2022-06-23 21:31:25.456307
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root()


# Generated at 2022-06-23 21:31:29.358304
# Unit test for method user of class Path
def test_Path_user():

    # Initialize object Path
    p = Path()

    # Test method user
    assert p.user() in ["/home/oretha", "/home/georgina", "/home/dominga"]

# Generated at 2022-06-23 21:31:34.328885
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == '/home/noe/Development/Ruby/somnolent'

    path = Path(platform='Darwin')
    assert path.project_dir() == \
           '/Users/noe/Development/Ruby/trisyllabical'

# Generated at 2022-06-23 21:31:35.880058
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:31:37.369206
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:31:39.873081
# Unit test for method root of class Path
def test_Path_root():
    assert(Path().root() == '/')


# Generated at 2022-06-23 21:31:43.317836
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    home_path = p.home()
    assert home_path == '/home'
    user_path = p.user()
    assert user_path == '/home/oretha'


# Generated at 2022-06-23 21:31:47.396310
# Unit test for constructor of class Path
def test_Path():
    print('\nTest function "test_Path": ')
    platform = sys.platform
    test = Path(platform)
    print(test.root())
    print(test.home())
    print(test.user())
    print(test.users_folder())
    print(test.dev_dir())
    print(test.project_dir())
    assert True

# Generated at 2022-06-23 21:31:49.124793
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None


# Generated at 2022-06-23 21:31:50.111145
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == "/"


# Generated at 2022-06-23 21:31:52.370623
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Path_dev_dir"""
    path = Path()
    dev_dir = path.dev_dir()
    assert dev_dir is not None

# Generated at 2022-06-23 21:31:54.050465
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    provider = Path()
    result = provider.users_folder()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:31:57.765146
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.seed(1000)
    result = p.user()
    assert result == '/home/alaine'


# Generated at 2022-06-23 21:32:01.125582
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == '/home/gunner/Documents'
    assert path.users_folder() == '/home/merell/Pictures'
    assert path.users_folder() == '/home/reece/Videos'

# Generated at 2022-06-23 21:32:06.862761
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_obj = Path(platform='linux')
    path_obj.random.choice = lambda x: 'bob'
    path_obj.random.choice = lambda x: 'Development'
    path_obj.random.choice = lambda x: 'Python'
    assert path_obj.dev_dir() == '/home/bob/Development/Python'

if __name__ == '__main__':
    test_Path_dev_dir()
    print('Passed unit tests')

# Generated at 2022-06-23 21:32:09.394390
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    user_folder = path.users_folder()
    assert user_folder == '/home/oretha/Pictures'

# Generated at 2022-06-23 21:32:11.317401
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert type(p.user()) == str

# Generated at 2022-06-23 21:32:14.243078
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for Path.project_dir method."""
    path = Path()
    path_name = path.project_dir()
    assert path_name not in ['', None, [], {}, (), set()]


# Generated at 2022-06-23 21:32:15.046526
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() is not None

# Generated at 2022-06-23 21:32:16.882898
# Unit test for method root of class Path
def test_Path_root():
    path = Path(platform = sys.platform)
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:26.616318
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    #first test
    assert Path().project_dir() == '/home/dulciana/Dev/haskell/suffer'
    #second test
    assert Path().project_dir() == '/home/jerrie/Development/JavaScript/skateboard'
    #third test
    assert Path().project_dir() == '/home/alyse/Dev/JavaScript/irrationalize'
    #fourth test
    assert Path().project_dir() == '/home/alyse/Development/haskell/identity'
    #fifth test
    assert Path().project_dir() == '/home/jerrie/Development/Java/gravidic'
    #sixth test
    assert Path().project_dir() == '/home/alyse/Development/Erlang/functor'
    #seventh test

# Generated at 2022-06-23 21:32:27.423823
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())



# Generated at 2022-06-23 21:32:30.235192
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import random
    path = Path(random.choice(PLATFORMS.keys()))
    path.project_dir()


# Generated at 2022-06-23 21:32:40.315342
# Unit test for method dev_dir of class Path
def test_Path_dev_dir(): 
    assert Path().dev_dir() == '/home/raleigh/Development/C#' 
    assert Path().dev_dir() == '/home/venetta/Development/Java' 
    assert Path().dev_dir() == '/home/latisha/Dev/C++' 
    assert Path().dev_dir() == '/home/margene/Development/Python' 
    assert Path().dev_dir() == '/home/jannet/Dev/Java' 
    assert Path().dev_dir() == '/home/brian/Dev/C++' 
    assert Path().dev_dir() == '/home/margene/Development/Python' 
    assert Path().dev_dir() == '/home/venetta/Dev/Java' 
    assert Path().dev_dir() == '/home/jannet/Development/C++' 
    assert Path

# Generated at 2022-06-23 21:32:41.860363
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:32:45.610200
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir = path.project_dir()
    assert type(project_dir) is str
    assert project_dir.startswith('/')
    assert project_dir.endswith('/')


# Generated at 2022-06-23 21:32:46.627958
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:32:55.116642
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Create a instance of Path class
    path = Path()
    # Create a list of result of method users_folder
    list_path = []
    # Invoke method users_folder 10 times and append result in list_path
    for _ in range(10):
        list_path.append(path.users_folder())
    # Get unique elements from list_path
    set_path = set(list_path)
    # Check that amount of unique elements of list_path is equal to 10
    assert len(set_path) == 10
    # Check that each element of list_path included in set_path
    for item in list_path:
        assert item in set_path


# Generated at 2022-06-23 21:32:56.854178
# Unit test for method root of class Path
def test_Path_root():
    class_Path = Path()
    assert class_Path.root() == 'C:\\Users'


# Generated at 2022-06-23 21:32:58.297584
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == "/"


# Generated at 2022-06-23 21:33:01.100103
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.home())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())

# Generated at 2022-06-23 21:33:02.842509
# Unit test for method home of class Path
def test_Path_home():
    assert 'Users' in Path().home()


# Generated at 2022-06-23 21:33:05.213027
# Unit test for method home of class Path
def test_Path_home():
    windows_platforms = ['win32', 'win64']
    path = Path(platform=windows_platforms)
    assert path.home() == 'C:\\Users'


# Generated at 2022-06-23 21:33:08.167041
# Unit test for method root of class Path
def test_Path_root():
    """Test for Path class."""
    s = Path()
    assert s.root() in ['/', str(PureWindowsPath())]


# Generated at 2022-06-23 21:33:14.574096
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.builtins import Path
    from mimesis.enums import Platform

    p = Path(platform=Platform.LINUX)
    dev_dir = p.dev_dir()
    if not dev_dir.startswith('/home'):
        raise TypeError('Path must be started with "/home".')

if __name__ == "__main__":
    test_Path_dev_dir()

# Generated at 2022-06-23 21:33:18.148888
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert str(p._pathlib_home) == '\\' if 'win' in p.platform \
                                    else '/home'

# Generated at 2022-06-23 21:33:23.777490
# Unit test for method user of class Path
def test_Path_user():
    data = Path()
    # Test 1
    assert data.user() != '/home/sherrell'
    # Test 2
    assert data.user() != '/home/kimiko'
    # Test 3
    assert data.user() != '/home/sherika'
    # Test 4
    assert data.user() != '/home/taneka'
    # Test 5
    assert data.user() != '/home/oretha'


# Generated at 2022-06-23 21:33:25.734933
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:33:29.102659
# Unit test for method root of class Path
def test_Path_root():
    path_obj = Path()
    assert path_obj.root() == '/'


# Generated at 2022-06-23 21:33:32.098763
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() != ''
    assert p.users_folder() != None

 # Unit test for method dev_dir of class Path

# Generated at 2022-06-23 21:33:41.504521
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from pprint import pprint
    #   Path.Meta.name = 'path'
    pprint(Path.Meta.name)

#   p = Path()
    p = Path('darwin')
    #   p.Meta.name = 'path'
    #   pprint(p.Meta.name)
    #   pprint(dir(p))
    pprint(p.platform)
    # pprint(p.dev_dir())
    pprint(p.random.choice(PROGRAMMING_LANGS))
    pprint(p.random.choice(FOLDERS))
    pprint(p.random.choice(PROJECT_NAMES))
    pprint(p.dev_dir())
    p = Path('win32')
    pprint(p.platform)
    pprint(p.dev_dir())


# Generated at 2022-06-23 21:33:48.432650
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert type(path_provider.project_dir()) is str
    p = path_provider.project_dir().split('/')
    assert len(p) == 6
    assert p[-1] in PROJECT_NAMES
    assert p[-2] in PROGRAMMING_LANGS
    assert p[-3] in ['Development', 'Dev']
    assert p[-4] in USERNAMES
    assert p[-5] in PLATFORMS.keys()
    assert p[-6] in PLATFORMS[p[-5]].values()

path_provider = Path()

# Generated at 2022-06-23 21:33:53.668656
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path2 = Path('darwin')
    path3 = Path('linux')
    path4 = Path('win32')
    print(path.project_dir())  # /home/orita/Development/Falcon/sergeant
    print(path2.project_dir())  # /home/jaunita/Development/Python/harbor
    print(path3.project_dir())  # /home/carlotta/Dev/JavaScript/embroider
    print(path4.project_dir())  # /home/tanisha/Dev/Falcon/pulpit


# Generated at 2022-06-23 21:33:56.394642
# Unit test for method user of class Path
def test_Path_user():
    # pylint: disable=C0103
    p = Path()
    p.user()
    assert p.seed == p.random.getstate()

# Generated at 2022-06-23 21:33:57.497218
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert(p.home() == '/home')


# Generated at 2022-06-23 21:34:01.531352
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path."""
    path = Path()
    result = path.dev_dir()
    assert isinstance(result, str)
    assert result

# Generated at 2022-06-23 21:34:04.614731
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='win64')
    assert p.platform == 'win64'
    p = Path(platform='linux')
    assert p.platform == 'linux'


# Generated at 2022-06-23 21:34:14.776938
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()

# Generated at 2022-06-23 21:34:16.993611
# Unit test for method root of class Path
def test_Path_root():
    # call the method Path.root of the class Path
    result = Path().root()
    assert(result)


# Generated at 2022-06-23 21:34:19.522523
# Unit test for method root of class Path
def test_Path_root():
    path_instance = Path()
    assert path_instance.root() == "C:\\" or path_instance.root() == "/"

# Generated at 2022-06-23 21:34:20.801719
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    tester = Path()
    print(tester.users_folder())


# Generated at 2022-06-23 21:34:22.948619
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test users_folder method of Path"""
    path = Path()
    assert type(path.users_folder()) == str
    assert len(path.users_folder()) != 0

# Generated at 2022-06-23 21:34:33.952641
# Unit test for constructor of class Path
def test_Path():
    # Expected values
    expected_platform_home = {
        'linux': '/home',
        'darwin': '/Users',
        'win32': str(PureWindowsPath.home()),
        'win64': str(PureWindowsPath.home()),
    }
    expected_pathlib_home = {
        'linux': PurePosixPath('/home'),
        'darwin': PurePosixPath('/Users'),
        'win32': PureWindowsPath(PureWindowsPath.home()),
        'win64': PureWindowsPath(PureWindowsPath.home()),
    }
    for platform in PATH_PLATFORMS:
        path_obj = Path(platform=platform)
        # check platform
        platform_atribute = getattr(path_obj, 'platform')
        assert platform_atribute == platform
        # check PLAT

# Generated at 2022-06-23 21:34:36.437693
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root.startswith("/")
    assert root == "/"


# Generated at 2022-06-23 21:34:38.198110
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    print("Path: ", result)


# Generated at 2022-06-23 21:34:39.965131
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    dev = Path()
    dev.users_folder()


# Generated at 2022-06-23 21:34:47.065418
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Creation Path class object
    pt = Path()
    # Random generates path for user folder
    print(pt.users_folder())
    # Users folder for current user
    print(Path().home())
    # Users folder for any user
    print(Path().user())
    # Root folder
    print(Path().root())
    # Development directory path
    print(Path().dev_dir())
    # Project directory path
    print(Path().project_dir())

test_Path_users_folder()

# Generated at 2022-06-23 21:34:49.908032
# Unit test for method root of class Path
def test_Path_root():
    root = Path().root()
    assert not root is None
    assert root == '\\' or '/'

if __name__ == '__main__':
    test_Path_root()

# Generated at 2022-06-23 21:34:56.022392
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    path = p.user()
    assert type(path) == str
    assert path[0] == '/'
    assert path[1] == 'h'
    assert path[2] == 'o'
    assert path[3] == 'm'
    assert path[4] == 'e'
    
    
# Unit tests for method users_folder of class Path

# Generated at 2022-06-23 21:34:57.379897
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert '/' == path.root()


# Generated at 2022-06-23 21:34:58.508508
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()

# Generated at 2022-06-23 21:35:02.913934
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.platform)
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


# Generated at 2022-06-23 21:35:04.373716
# Unit test for constructor of class Path
def test_Path():
    instance = Path()
    assert isinstance(instance, Path)

# Generated at 2022-06-23 21:35:05.849693
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    print(result)


# Generated at 2022-06-23 21:35:09.778367
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    tmp_name = 'tmp'
    p.random.seed(tmp_name)
    _ = p.project_dir()
    assert _ == '/home/tmp/Development/Flask/citizen'

# Generated at 2022-06-23 21:35:11.632760
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == '/home/lasonya/Pictures'


# Generated at 2022-06-23 21:35:13.948789
# Unit test for method root of class Path
def test_Path_root():
    """Test case path.Path.root."""
    _path = Path()
    _path.root()


# Generated at 2022-06-23 21:35:15.168237
# Unit test for constructor of class Path
def test_Path():
    test = Path()
    assert test

# Generated at 2022-06-23 21:35:16.805322
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path(platform='linux')
    # print(p.dev_dir())
    assert True


# Generated at 2022-06-23 21:35:20.970271
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_instance = Path()
    print(path_instance.dev_dir())
    print(path_instance.project_dir())
    print(path_instance.user())


# Generated at 2022-06-23 21:35:22.579540
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:35:24.289353
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:35:29.272581
# Unit test for method user of class Path
def test_Path_user():
    """Method test_Path_user."""
    from mimesis.enums import Gender
    from mimesis.builtins import USASpecProvider

    username_provider = USASpecProvider(
        seed=5,
        gender=Gender.FEMALE
    )
    for _i in range(5):
        print(username_provider.username())


# Generated at 2022-06-23 21:35:30.998789
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    res = p.users_folder()
    assert res is not None


# Generated at 2022-06-23 21:35:35.185066
# Unit test for constructor of class Path
def test_Path():
    """This is used to test if the constructor of the class Path is working fine.
    """
    p = Path()                     #Test 1
    assert p.platform == sys.platform
    assert p.seed == 100

    p = Path(platform='linux', seed=1)   #Test 2
    assert p.platform == 'linux'
    assert p.seed == 1



# Generated at 2022-06-23 21:35:35.944545
# Unit test for method home of class Path
def test_Path_home():  # noqa: WPS125
    """Test Path.home()."""
    assert Path()


# Generated at 2022-06-23 21:35:39.490652
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_class_object = Path()
    path_class_object.random.choice = lambda x: x[0]
    users_folder = path_class_object.users_folder()
    assert users_folder == '/home/oretha/Pictures'
    assert type(users_folder) == str

# Generated at 2022-06-23 21:35:40.790501
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    assert isinstance(home, str)


# Generated at 2022-06-23 21:35:42.467346
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test method users_folder of class Path."""
    path = Path()
    assert "User" in path.users_folder()

# Generated at 2022-06-23 21:35:45.489023
# Unit test for method root of class Path
def test_Path_root():
    try:
        mimesis._get_data('path.json')
    except KeyError:
        with pytest.raises(KeyError):
            path = Path()
            path.root()
        return
    path = Path()
    result = path.root()
    assert isinstance(result, str)
    assert result == "/"


# Generated at 2022-06-23 21:35:47.783193
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/sherretta'


# Generated at 2022-06-23 21:35:49.932216
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path()
    assert obj.dev_dir() == "/home/curtis/Dev/Js"


# Generated at 2022-06-23 21:35:52.589107
# Unit test for method users_folder of class Path
def test_Path_users_folder():
        path = Path(platform='linux')
        assert len(path.users_folder()) > 0

# Generated at 2022-06-23 21:35:54.611088
# Unit test for method user of class Path
def test_Path_user():
    # Test 1
    path1 = Path()
    assert(str(path1.user()) == '/home/oretha')

# Generated at 2022-06-23 21:35:56.716042
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() in ('/home', 'C:\\Users')


# Generated at 2022-06-23 21:36:00.774481
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    from mimesis.enums import ProgrammingLang

    path = Path()
    user = path.user()
    assert isinstance(user, str)
    assert set(user) >= set(ProgrammingLang.JAVASCRIPT.value)

# Generated at 2022-06-23 21:36:03.136555
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test method project_dir."""
    assert Path().project_dir()


# Generated at 2022-06-23 21:36:08.756374
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print('{0:=^80}'.format('Running unit test for method dev_dir of class Path'))
    try:
        path = Path()
        print (path.dev_dir())
        print ('Test passed!')
    except AssertionError as e:
        print ('Test failed!')
        raise e


# Generated at 2022-06-23 21:36:11.048251
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    print(result)
    assert len(result) >= 1


# Generated at 2022-06-23 21:36:12.611049
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Test
    pp = Path()
    assert pp.dev_dir() == "/home/uretha/Dev/Python"

# Generated at 2022-06-23 21:36:14.107596
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-23 21:36:17.237704
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert type(p.user()) == str
    print(p.user())

test_Path_user()

# Generated at 2022-06-23 21:36:18.497791
# Unit test for method home of class Path
def test_Path_home():
    path = Path()

# Generated at 2022-06-23 21:36:20.472503
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert sys.platform != 'linux2'
    with pytest.raises(ValueError):
        p = Path('linux2')

# Generated at 2022-06-23 21:36:29.510532
# Unit test for constructor of class Path
def test_Path():
    print("\n\n=== test_Path() ===")
    path = Path()
    print("- Path.root(): {}".format(path.root()))
    print("- Path.home(): {}".format(path.home()))
    print("- Path.user(): {}".format(path.user()))
    print("- Path.users_folder(): {}".format(path.users_folder()))
    print("- Path.dev_dir(): {}".format(path.dev_dir()))
    print("- Path.project_dir(): {}".format(path.project_dir()))
    print("=== end of test ===\n\n")

test_Path()

# Generated at 2022-06-23 21:36:32.162455
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='linux', seed=42)
    assert p.meta.name == 'path', "Expected 'path'"
    assert p.platform == 'linux', "Expected 'linux'"


# Generated at 2022-06-23 21:36:34.100520
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform

# Generated at 2022-06-23 21:36:37.791628
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test method dev_dir of class Path"""
    path = Path()
    res = path.dev_dir()
    assert '/home' in res
    assert 'Development' in res
    assert any([lang in res for lang in PROGRAMMING_LANGS])


# Generated at 2022-06-23 21:36:40.128361
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.seed(0)
    assert path.root() == '/'


# Generated at 2022-06-23 21:36:45.012789
# Unit test for method root of class Path
def test_Path_root():
    """Test root of class Path."""
    from mimesis.enums import Platform
    from mimesis.builtins import Path as mimesis_path

    platform = random.choice(list(Platform))

    # Test Path.root() method
    Path = mimesis_path(platform)
    Path.root()


# Generated at 2022-06-23 21:36:46.605459
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform == sys.platform


# Generated at 2022-06-23 21:36:48.189914
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-23 21:36:49.632338
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    str_path = path.root()
    assert str_path == "\\"


# Generated at 2022-06-23 21:36:51.125781
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    gen = Path()
    result = gen.users_folder()
    print(result)

# Generated at 2022-06-23 21:36:52.685189
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform="linux")
    assert str(PureWindowsPath()) != p._pathlib_hometest_Path

# Generated at 2022-06-23 21:36:53.858227
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:36:54.916863
# Unit test for method user of class Path
def test_Path_user():
    testPath = Path()
    assert testPath.user() == "/home/oretha"

# Generated at 2022-06-23 21:37:05.485744
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import ProgrammingLanguage
    import random
    import sys

    if sys.version_info >= (3, 7):
        a: Path = Path(seed=random.seed(43))
        assert str(
            a.project_dir()
        ) == '/home/mariko/Development/Fortran/beefsteak'

        a: Path = Path(platform='win32', seed=random.seed(42))
        assert str(
            a.project_dir()
        ) == 'C:\\Users\\Camilla\\Dev\\Scala\\homemade'

        a: Path = Path(
            platform='win32',
            seed=random.seed(43),
            locales=['en-NZ'],
        )

# Generated at 2022-06-23 21:37:06.522013
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:37:08.062709
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path"""
    x = Path()
    assert x.root() == '/'


# Generated at 2022-06-23 21:37:09.202993
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert '/' == path.root()


# Generated at 2022-06-23 21:37:11.907009
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() != None
    assert path.root() != ''
    assert '/' in path.root()


# Generated at 2022-06-23 21:37:14.252381
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test = Path().project_dir()
    print(test)


# Generated at 2022-06-23 21:37:16.059444
# Unit test for method home of class Path
def test_Path_home():
	path = Path()
	path.home()


# Generated at 2022-06-23 21:37:17.085861
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    r = Path()
    r.dev_dir()

# Generated at 2022-06-23 21:37:20.276573
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Check the output for method Path.project_dir()."""
    path = Path()
    result = path.project_dir()
    for _ in range(100):
        assert result == path.project_dir()


# Generated at 2022-06-23 21:37:22.138457
# Unit test for method home of class Path
def test_Path_home():
    p = Path("darwin")
    print("home: ", p.home())


# Generated at 2022-06-23 21:37:26.721385
# Unit test for constructor of class Path
def test_Path():
    # Checks the root folder
    assert Path().root() == '/'

    # Checks the home directory in Linux
    assert Path().home() == '/home'

    # Checks the home directory in Windows
    assert Path(platform='win32').home() == 'C:\\Users'


# Generated at 2022-06-23 21:37:29.999943
# Unit test for constructor of class Path
def test_Path():
    p = Path('win32')
    assert p.platform == 'win32'
    assert p._pathlib_home == PureWindowsPath('C:/Users/%USERNAME%')


# Generated at 2022-06-23 21:37:31.367808
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home()


# Generated at 2022-06-23 21:37:32.286021
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/Users/yanko'

# Generated at 2022-06-23 21:37:33.097606
# Unit test for constructor of class Path
def test_Path():
    assert Path()

# Generated at 2022-06-23 21:37:34.727320
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    assert a.users_folder() is not None and isinstance(a.users_folder(), str)


# Generated at 2022-06-23 21:37:36.574089
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert isinstance(p.users_folder(),str)


# Generated at 2022-06-23 21:37:37.519974
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print(Path().dev_dir())

# Generated at 2022-06-23 21:37:42.020991
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """ Unit test for method dev_dir of class Path """
    from mimesis.builtins import Path

    path = Path()
    assert isinstance(path.dev_dir(), str) and len(path.dev_dir()) != 0 and path.dev_dir() == "/home/carmel/Development/JavaScript"



# Generated at 2022-06-23 21:37:50.482670
# Unit test for constructor of class Path
def test_Path():
    #Test the constructor of Path
    path = Path()
    assert path is not None
    #Test the method root of Path class
    assert path.root() == '/'
    #Test the method home of Path class
    assert path.home() == '/home'
    #Test the method user of Path class
    assert path.user() == '/home/sebastien'
    #Test the method users_folder of Path class
    assert path.users_folder() == '/home/britt/Documents'
    #Test the method dev_dir of Path class
    assert path.dev_dir() == '/home/tawna/Development/Java'
    #Test the method project_dir of Path class
    assert path.project_dir() == '/home/sebastien/Development/Java/pubg'

# Generated at 2022-06-23 21:37:59.828797
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.locales import Locales
    p = Person(locale=Locales.RUSSIAN)
    dt = Datetime(locale=Locales.RUSSIAN)

    expected = p.surname().lower() + '_' + p.password(8)
    if 'win' in sys.platform:
        expected = p.surname() + '_' + p.password(8)
    assert expected == Path(platform=sys.platform).user()

    expected = p.surname().lower() + '_' + dt.timestamp()

# Generated at 2022-06-23 21:38:02.401480
# Unit test for method user of class Path
def test_Path_user():
    """Test method of Path class"""
    p = Path()
    assert len(p.user()) in range(13, 24, 1)
    assert 'home' in p.user()

# Generated at 2022-06-23 21:38:03.282615
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:38:06.962274
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path('linux')
    p = path.dev_dir()
    assert p == '/home/bernadine/Development/C' or p == '/home/bernadine/Dev/C'


# Generated at 2022-06-23 21:38:09.039274
# Unit test for method user of class Path
def test_Path_user():
    obj = Path()
    for i in range(1000):
        assert obj.user() != ''

# Generated at 2022-06-23 21:38:09.988448
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())

# Generated at 2022-06-23 21:38:11.642729
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)


# Generated at 2022-06-23 21:38:14.339479
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    p = path.user()
    assert isinstance(p, str)
    assert len(p) >= 7 and len(p) <= 12

# Generated at 2022-06-23 21:38:16.486139
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/' or 'C:\\'


# Generated at 2022-06-23 21:38:21.602293
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import ProgrammingLanguage

    path = Path()
    for i in range(100):
        res = path.project_dir()
        assert 'development' in res.lower()
        assert 'dev' in res.lower()
        assert path.random.choice(PROGRAMMING_LANGS) in res
        assert path.random.choice(PROJECT_NAMES) in res


# Generated at 2022-06-23 21:38:23.239457
# Unit test for method root of class Path
def test_Path_root():
    print(Path().root())
    assert 1 == 1


# Generated at 2022-06-23 21:38:26.088263
# Unit test for method root of class Path
def test_Path_root():
    """Test if method returns root and nothing more."""
    a = Path(platform="win32")
    b = a.root()
    assert b == 'C:\\'



# Generated at 2022-06-23 21:38:27.422851
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    res = path.root()
    assert '/' == res


# Generated at 2022-06-23 21:38:28.379763
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for user() of class Path"""
    p = Path()
    assert type(p.user()) == str

# Generated at 2022-06-23 21:38:30.108124
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    file_path = Path()
    assert file_path.dev_dir() == '/home/johanne/Development/Haskell'


# Generated at 2022-06-23 21:38:31.236388
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == str(path._pathlib_home.parent)


# Generated at 2022-06-23 21:38:33.081365
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import Language
    p = Path(Language.EN)
    ans = p.project_dir()
    print(ans)

# Generated at 2022-06-23 21:38:36.185426
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    item = Path('darwin').project_dir()
    print(item)
    assert item.startswith('/')
    assert item.endswith('.py')

# Generated at 2022-06-23 21:38:38.291947
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    if __name__ == '__main__':
        print(home)


# Generated at 2022-06-23 21:38:40.060582
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert True == len(path.user()) > 0


# Generated at 2022-06-23 21:38:41.460896
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:38:43.380316
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path(platform='linux')
    path.random.seed(0)
    for i in range(10):
        print(path.users_folder())


# Generated at 2022-06-23 21:38:45.725650
# Unit test for method root of class Path
def test_Path_root():
    result = Path().root()
    assert result == '/'


# Generated at 2022-06-23 21:38:46.786356
# Unit test for constructor of class Path
def test_Path():
    pass
    


# Generated at 2022-06-23 21:38:51.330938
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    s = p.users_folder()
    if '/' not in s:
        print("Ошибка. В пути нет символа '/'")


# Generated at 2022-06-23 21:38:56.849695
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()

    for _ in range(100):
        result = p.project_dir()
        assert isinstance(result, str)

        project_regexp = r"^/home/([a-z]+)/Development/([a-z]+)/([a-z]+)$"
        assert result.lower().startswith("/home/")

# Generated at 2022-06-23 21:39:01.497705
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user
    of class Path.
    """
    from mimesis.enums import Platform

    p = Path(platform=Platform.WINDOWS)
    user = p.user()
    assert user == 'C:\\Users\\Lolita'

    p = Path(platform=Platform.LINUX)
    user = p.user()
    assert user == '\\home\\carlo'



# Generated at 2022-06-23 21:39:04.291018
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert str(path.root()) == '/'


# Generated at 2022-06-23 21:39:05.775015
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder().startswith('/home')

# Generated at 2022-06-23 21:39:07.290121
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test method project_dir."""
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:39:08.431807
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir = path.project_dir()
    assert isinstance(project_dir, str)
    assert len(project_dir) > 0


# Generated at 2022-06-23 21:39:09.577150
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-23 21:39:11.482845
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    from mimesis.builtins import Path
    path = Path()
    p = path.root()
    assert p is not None


# Generated at 2022-06-23 21:39:14.318123
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/taneka/Development/Falcon/bistable'

# Generated at 2022-06-23 21:39:16.212427
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for _ in range(5):
        print(Path().dev_dir())
    print()


# Generated at 2022-06-23 21:39:17.916756
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    Path_obj = Path()
    print(Path_obj.dev_dir())


# Generated at 2022-06-23 21:39:18.290415
# Unit test for constructor of class Path
def test_Path():
    Path()

# Generated at 2022-06-23 21:39:25.389168
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.builtins import DataGenerator
    from mimesis.enums import Gender
    from mimesis.locales import Locale

    p = Path(platform='linux')
    p.seed(1)
    m = Path(platform='darwin')
    m.seed(1)
    w = Path(platform='win32')
    w.seed(1)
    print("Paths: ", p.project_dir(), m.project_dir(), w.project_dir())
    print("Project names: ", p.project_name(), m.project_name(), w.project_name())

# Generated at 2022-06-23 21:39:27.199022
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert isinstance(path.home(), str)


# Generated at 2022-06-23 21:39:33.560356
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    # andy
    p1 = Path(platform=Platform.LINUX.value)
    assert p1.root() == '/'

    # test on windows
    p1 = Path(platform=Platform.WINDOWS.value)
    assert p1.root() == 'C:'

    # test on Mac
    p1 = Path(platform=Platform.DARWIN.value)
    assert p1.root() == '/'



# Generated at 2022-06-23 21:39:34.919741
# Unit test for method root of class Path
def test_Path_root():
    x = Path()
    print(x.root())


# Generated at 2022-06-23 21:39:36.290726
# Unit test for method root of class Path
def test_Path_root():
    pk = Path()
    assert pk.root() != None


# Generated at 2022-06-23 21:39:41.265697
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import Platform
    from mimesis.builtins import Digits
    for platform in list(Platform):
        p = Path(platform.value)
        assert p.home() == str(PureWindowsPath()) + \
            PLATFORMS[platform.value]['home'] if platform.value in ('win32', 'win64') else \
            '/home'


# Generated at 2022-06-23 21:39:43.522731
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    try:
        path.dev_dir()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-23 21:39:44.617395
# Unit test for method home of class Path
def test_Path_home():
    result = Path().home()
    assert result == '/home'


# Generated at 2022-06-23 21:39:45.751413
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert p.platform == 'linux'

# Generated at 2022-06-23 21:39:47.149900
# Unit test for method root of class Path
def test_Path_root():
    root = Path().root()
    assert isinstance(root, str)
    assert root == '/'


# Generated at 2022-06-23 21:39:48.193139
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform

# Generated at 2022-06-23 21:39:51.313502
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path('linux')
    for i in range(0, 10):
        print(p.dev_dir())


# end unit test test_Path_dev_dir

# Generated at 2022-06-23 21:39:57.168662
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    sut = p.project_dir()
    expected = {'\n', '/', 'home', 'Development', 'user', 'dev_stack'}
    observed = set(sut.split('/'))

    assert observed != expected
    assert len(set(observed).intersection(expected)) == len(expected)



# Generated at 2022-06-23 21:39:58.605415
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:40:00.325339
# Unit test for constructor of class Path
def test_Path():
    expected = str(PureWindowsPath())
    actual = Path(platform='win32').__init__()
    assert actual == expected

# Generated at 2022-06-23 21:40:04.371986
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    for _ in range(10):
        path = p.users_folder()
        assert path != '', 'Path is empty'
        assert path != None, 'Path is none'



# Generated at 2022-06-23 21:40:08.279435
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test_class = Path()
    result = test_class.project_dir()
    assert isinstance(result, str)
    assert len(result) > 0
    assert len(result.split("/")) == 6


# Generated at 2022-06-23 21:40:18.144175
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage
    from mimesis.exceptions import NonEnumerableError

    path = Path()

    path.random.seed(1)
    expected_path = '/home/melissia/Dev/Python'
    assert path.dev_dir() == expected_path

    path.random.seed(2)
    expected_path = '/home/homar/Dev/Python'
    assert path.dev_dir() == expected_path

    path.random.seed(3)
    expected_path = '/home/yessenia/Dev/Python' 
    assert path.dev_dir() == expected_path

    path.random.seed(4)
    expected_path = '/home/jim/Dev/Python' 
    assert path.dev_dir() == expected_path
