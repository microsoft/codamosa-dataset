

# Generated at 2022-06-23 21:30:17.824661
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path(platform = 'win32')
    print(p.project_dir())

# Unittest
if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:30:21.384753
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Gender
    path = Path()
    pf = path.users_folder()
    assert isinstance(pf, str)
    assert len(pf) > 5

# Generated at 2022-06-23 21:30:22.974234
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user()


# Generated at 2022-06-23 21:30:24.918542
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())
# /home/sherika/Pictures


# Generated at 2022-06-23 21:30:26.804689
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    obj = Path()
    assert len(Path.users_folder(obj)) != 0

# Generated at 2022-06-23 21:30:27.983335
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert type(p) is Path

# Generated at 2022-06-23 21:30:31.335459
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)
    assert 'User@123' not in p.user()
    assert '/' in p.user()
    assert p.Meta.name == 'path'

# Generated at 2022-06-23 21:30:35.307546
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('linux')
    s = path.users_folder()
    assert isinstance(s, str)
    assert len(s) > 0

# Generated at 2022-06-23 21:30:42.032562
# Unit test for constructor of class Path
def test_Path():
    # result = Path().platform
    # print(result)

    # result = Path().root()
    # print(result)

    # result = Path().home()
    # print(result)
    #
    # result = Path().user()
    # print(result)

    # result = Path().users_folder()
    # print(result)

    # result = Path().dev_dir()
    # print(result)

    result = Path().project_dir()
    print(result)

# Generated at 2022-06-23 21:30:50.448370
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    if sys.platform == 'darwin':
        path = Path(platform = 'darwin')
        assert path.dev_dir() == '/Users/ahmad/Dev/Ruby'
    elif sys.platform == 'linux':
        path = Path(platform = 'linux')
        assert path.dev_dir() == '/home/harkirat/Development/PHP'
    elif sys.platform == 'win32':
        path = Path()
        assert path.dev_dir() == 'C:\\Users\\aisha\\Dev\\PHP'


# Generated at 2022-06-23 21:30:51.725575
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() != ''



# Generated at 2022-06-23 21:30:53.134244
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:30:56.474633
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    random = RussiaSpecProvider()
    random.seed(0)
    data = random.path.user()
    assert data == '/home/taneka'



# Generated at 2022-06-23 21:30:57.601440
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:31:07.447452
# Unit test for constructor of class Path
def test_Path():
    """Test for constructor."""
    # Expected values for 'win32' platform
    expected_win32 = (
        'C:\\',
        'C:\\Users',
        'C:\\Users\\Katharyn',
        'C:\\Users\\Katharyn\\Pictures',
        'C:\\Users\\Katharyn\\Development\\C',
        'C:\\Users\\Katharyn\\Development\\C\\saltwater',
    )
    path = Path('win32')
    assert path.root() == expected_win32[0]
    assert path.home() == expected_win32[1]
    assert path.user() == expected_win32[2]
    assert path.users_folder() == expected_win32[3]
    assert path.dev_dir() == expected_win32[4]

# Generated at 2022-06-23 21:31:08.689219
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:19.294757
# Unit test for constructor of class Path
def test_Path():
    from mimesis.enums import Platform
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path.platform, str)
    assert path.platform == sys.platform
    path = Path(platform=Platform.WIN32)
    assert path.platform == Platform.WIN32
    path = Path(platform=Platform.WINDOWS)
    assert path.platform == Platform.WINDOWS
    path = Path(platform=Platform.WINDOWS)
    assert path.platform == Platform.WINDOWS
    path = Path(platform=Platform.LINUX)
    assert path.platform == Platform.LINUX
    path = Path(platform=Platform.LINUX)
    assert path.platform == Platform.LINUX
    path = Path(platform=Platform.DARWIN)
    assert path.platform == Platform.DARWIN

# Generated at 2022-06-23 21:31:21.947247
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())
    print(path.dev_dir())
    
    

# Generated at 2022-06-23 21:31:23.703614
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    obj = Path()
    print(obj.user())


# Generated at 2022-06-23 21:31:25.612802
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path.project_dir()
    print(p)
    assert True


# Generated at 2022-06-23 21:31:32.001154
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Initialize class Path
    path = Path()
    # Get path to user's folder
    users_folder = path.users_folder()

    # Testing
    # Path to user's folder must be string
    assert isinstance(users_folder, str)
    # Testing
    # Path to user's folder must be like /home/taneka/Pictures
    assert users_folder == '/home/taneka/Pictures'

# Generated at 2022-06-23 21:31:34.072646
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

# Generated at 2022-06-23 21:31:36.000715
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/tiffani/Dev/flask/evergreen'

# Generated at 2022-06-23 21:31:41.489105
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit tests for method project_dir."""
    global path
    path = Path()
    ret = path.project_dir()
    # Format returned: /home/staci/Development/Rust/transgressor
    # Check if '/' is a part of ret
    assert '/' in ret
    

# Generated at 2022-06-23 21:31:42.512396
# Unit test for method home of class Path
def test_Path_home():
    Path().home()

# Generated at 2022-06-23 21:31:48.628951
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    path = Path()
    rus = RussiaSpecProvider(gender=Gender.FEMALE)
    assert 'Development' in path.project_dir()
    assert 'Python' in path.project_dir()
    assert rus.surname() in path.project_dir()

# Generated at 2022-06-23 21:31:49.766682
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    assert result is not None
    assert isinstance(result, str)


# Generated at 2022-06-23 21:31:51.256866
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:31:53.443543
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform is not None
    assert path._pathlib_home is not None

# Unit test fo method root()

# Generated at 2022-06-23 21:31:54.951037
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    assert True is not False

# Generated at 2022-06-23 21:31:59.686480
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    # home in unix-like system
    assert (path.home() == path._pathlib_home.as_posix()) or \
        (path.home() == path._pathlib_home.as_windows())

# Generated at 2022-06-23 21:32:03.312203
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    seed = 1
    path = Path("linux", seed=seed)
    dev_dir = path.dev_dir()
    assert dev_dir == '/home/brenton/Development/Swift'
    assert path.Meta.name == 'path'


# Generated at 2022-06-23 21:32:05.792575
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    user = p.user()
    dev_dir = p.dev_dir()
    stack = dev_dir.split('/')[-1]
    assert str(user) in dev_dir
    assert str(stack) in dev_dir

# Generated at 2022-06-23 21:32:07.085516
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    result = Path.dev_dir()
    assert result != None


# Generated at 2022-06-23 21:32:10.109514
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:32:13.551187
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == str(PureWindowsPath('C:\\Users\\Lakiesha\\Dev\\C\\gloomy') or PurePosixPath('/home/leonia/dev/haskell/gleaming'))


# Generated at 2022-06-23 21:32:15.305526
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:32:17.154421
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == "/" # Result: '/'


# Generated at 2022-06-23 21:32:22.640712
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() == '/home/taneka/Pictures'
    assert Path().users_folder() == '/home/dionna/Documents'
    assert Path().users_folder() == '/home/carmen/Pictures'
    assert Path().users_folder() == '/home/giuseppe/Music'
    assert Path().users_folder() == '/home/josh/Documents'


# Generated at 2022-06-23 21:32:24.650609
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import pytest
    path = Path()
    expected = [str]
    assert isinstance(path.project_dir(), str)

# Generated at 2022-06-23 21:32:26.937729
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    home = path.home()
    assert isinstance(path.user(), str)
    assert home not in path.user()

# Generated at 2022-06-23 21:32:31.812942
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
#    print(path.users_folder())
    mypath = path.users_folder()
    mypathlib = PurePosixPath(mypath)
#    print(mypathlib.parts)
    assert len(mypathlib.parts) == 4
#    return 1


# Generated at 2022-06-23 21:32:35.863959
# Unit test for constructor of class Path
def test_Path():
    provider = Path(platform='linux')
    print(provider.root())
    print(provider.home())
    print(provider.user())
    print(provider.users_folder())
    print(provider.dev_dir())
    print(provider.project_dir())

# test_Path()

# Generated at 2022-06-23 21:32:38.907285
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path(platform="linux")
    assert str(PurePosixPath("/home/clementine/Development/C#/dreamer")) == p.project_dir()

# Generated at 2022-06-23 21:32:43.909260
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Generates a string that contains a path to a random user's folder."""
    path = Path()
    print("\nPath to user's folder:", path.users_folder())
    print("\nPath to user's folder:", path.users_folder())
    print("\nPath to user's folder:", path.users_folder())
    print("\nPath to user's folder:", path.users_folder(), end='\n\n')


# Generated at 2022-06-23 21:32:47.425824
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pattern = re.compile(r'[/][a-z]*[/][a-z]*[s]{1}[/][a-z]*')
    result = Path().users_folder()
    assert re.search(pattern, result)


# Generated at 2022-06-23 21:32:48.674704
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/olivia'


# Generated at 2022-06-23 21:32:50.132127
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home()


# Generated at 2022-06-23 21:32:52.378238
# Unit test for constructor of class Path
def test_Path():
    from doctest import testmod
    pt = testmod(optionflags=1)
    assert pt.failed == 0, f"Failed: {pt.failed}, Attempted: {pt.attempted}"

# Generated at 2022-06-23 21:32:54.510536
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """TestPath: Test method users_folder."""
    gen = Path()
    result = gen.users_folder()
    assert isinstance(result, str)
    assert "/" in result
    assert "C:" not in result



# Generated at 2022-06-23 21:33:02.142273
# Unit test for constructor of class Path
def test_Path():
    context = Path()
    user = context.user()
    assert user == '/home/oretha'
    home_dir = context.home()
    assert home_dir == '/home'
    project_dir = context.project_dir()
    assert project_dir == '/home/sherika/Development/Falcon/mercenary'
    dev_dir = context.dev_dir()
    assert dev_dir == '/home/sherrell/Development/Python'
    users_folder = context.users_folder()
    assert users_folder == '/home/taneka/Pictures'

# Generated at 2022-06-23 21:33:03.195579
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    unit_Path = Path()
    print(unit_Path.project_dir())

# Generated at 2022-06-23 21:33:04.512609
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'

# Generated at 2022-06-23 21:33:07.139784
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    res = p.users_folder()
    assert res



# Generated at 2022-06-23 21:33:08.280540
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert len(Path().project_dir()) > 0

# Generated at 2022-06-23 21:33:20.292964
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import OperatingSystems
    from mimesis.exceptions import NonEnumerableError

    # Test 1
    test1 = Path(OperatingSystems.LINUX)
    assert test1.home() == '/home'

    # Test 2
    test2 = Path(OperatingSystems.WINDOWS)
    assert test2.home() == 'C:\\Users'

    # Test 3
    test3 = Path(OperatingSystems.LINUX)
    assert test3.home() != '/home1'

    # Test 4
    test4 = Path(OperatingSystems.WINDOWS)
    assert test4.home() != 'C:\\Users1'

    # Test 5
    with open('test.txt', 'w') as f:
        f.write('test')

# Generated at 2022-06-23 21:33:22.633950
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path(platform = 'win32')
    print(p.project_dir())

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:33:25.389588
# Unit test for constructor of class Path
def test_Path():
  path = Path()
  assert path.__class__.__name__ == 'Path'
  assert path.__doc__ is not None
  assert path.Meta.__name___ == 'path'


# Generated at 2022-06-23 21:33:29.589938
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p != None
    #assert p.platform == 'linux'
    assert p.platform == os.name

# Generated at 2022-06-23 21:33:31.653134
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:33:33.149765
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"


# Generated at 2022-06-23 21:33:35.116488
# Unit test for method root of class Path
def test_Path_root():
    import random
 
    random.seed(0)
    p = Path()
    assert p.root() == '/'
 

# Generated at 2022-06-23 21:33:38.825899
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    platform = 'win32'
    p = Path(platform)
    assert p.root() == str(PureWindowsPath().parent) and platform == 'win32'

# Generated at 2022-06-23 21:33:42.781778
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='linux')
    assert p.root() == '/', 'Should be "/"'
    assert p.home() == '/home', 'Should be "/home"'
    assert p.user() == '/home/lura', 'Should be "/home/lura"'
    assert len(p.users_folder()) == 18, 'Should be 18'
    assert len(p.dev_dir()) == 27, 'Should be 27'
    assert len(p.project_dir()) == 45, 'Should be 45'

# Generated at 2022-06-23 21:33:44.396160
# Unit test for constructor of class Path
def test_Path():
    # Test class constructor
    p = Path()
    # Test class generator
    p.home()

# Generated at 2022-06-23 21:33:47.652340
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


test_Path()

# Generated at 2022-06-23 21:33:50.054267
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() in '/home/sherrell/Development/Python', \
    'test_Path_dev_dir(): Path().dev_dir() != /home/sherrell/Development/Python'

# Generated at 2022-06-23 21:33:50.850808
# Unit test for method root of class Path
def test_Path_root():
    assert Path.root(Path())


# Generated at 2022-06-23 21:33:53.403432
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path('linux')
    assert path.project_dir() == '/home/kishore/Development/Batchfile/showcase'


# Generated at 2022-06-23 21:33:59.211546
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    # check whether an attribute _pathlib_home is initilized
    assert p._pathlib_home
    # check whether the attribute "_pathlib_home" is an instance of PureWindowsPath or PurePosixPath
    assert isinstance(p._pathlib_home, PureWindowsPath) or isinstance(p._pathlib_home, PurePosixPath)


# Generated at 2022-06-23 21:34:00.398913
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:34:03.900544
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('linux')
    result = p.users_folder()
    assert type(result) == str
    assert result in p.random.choice(FOLDERS)

# Generated at 2022-06-23 21:34:10.574434
# Unit test for method home of class Path
def test_Path_home():
    assert Path.Meta.name == 'path'
    p = Path(platform='win32')
    assert p.home() == 'C://Users'
    assert p.user() == 'C://Users/Ezekiel'
    assert p.users_folder() == 'C://Users/Andy/Music'
    assert p.dev_dir() == 'C://Users/Andy/Dev/Rust'
    assert p.project_dir() == 'C://Users/Andy/Dev/JavaScript/apod'

# Generated at 2022-06-23 21:34:13.732184
# Unit test for method root of class Path
def test_Path_root():
    # path is a Path
    path = Path()
    # root is a str
    root = path.root()
    # compare types
    assert isinstance(root, str)
    # compare
    assert root == '/home'


# Generated at 2022-06-23 21:34:16.399274
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.random.seed(0)
    assert path.users_folder() == '/home/taneka/Pictures'

# Generated at 2022-06-23 21:34:18.466368
# Unit test for method root of class Path
def test_Path_root():
    Path = Path()
    str = Path.root()
    print(str)


# Generated at 2022-06-23 21:34:19.173868
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path = Path("linux")

# Generated at 2022-06-23 21:34:20.771712
# Unit test for constructor of class Path
def test_Path():
    # pylint: disable=no-member
    path = Path()
    assert path._pathlib_home is not None
    assert path.platform is not None

# Generated at 2022-06-23 21:34:22.811270
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Instantiate the class
    path = Path()
    # Generate a random path to project directory
    result = path.project_dir()
    # Print the result
    print(result)


# Generated at 2022-06-23 21:34:24.020218
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print("\n" + path.dev_dir() + "\n")


# Generated at 2022-06-23 21:34:26.091071
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path._pathlib_home == PurePosixPath('/home')

# Generated at 2022-06-23 21:34:28.854403
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    project_path = p.project_dir()
    print (project_path)

# Test case: expected value is a string

# Generated at 2022-06-23 21:34:32.512848
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import mimesis
    p = mimesis
    timestamp = p.datetime.datetime.now()
    generator = p.Path('linux')
    paths = generator.project_dir()
    print(paths)


# Generated at 2022-06-23 21:34:34.005786
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:34:36.072700
# Unit test for method user of class Path
def test_Path_user():
    x = Path()
    y = x.user()
    print(y)


# Generated at 2022-06-23 21:34:38.243385
# Unit test for method user of class Path
def test_Path_user():
    """Test Path.user."""

    from mimesis.providers.path import Path
    p = Path()

    assert p.user()

# Generated at 2022-06-23 21:34:40.016456
# Unit test for constructor of class Path
def test_Path():
    paths = Path()
    assert paths.platform == sys.platform

# Generated at 2022-06-23 21:34:43.205461
# Unit test for method user of class Path
def test_Path_user():
    obj = Path()
    results = obj.user()
    result = '/home/gregg'
    assert results == result


# Generated at 2022-06-23 21:34:45.403658
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert 'home' in path.user()
    assert path.user()[-1].isalpha()


# Generated at 2022-06-23 21:34:48.552218
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("\n")
    assert Path().dev_dir() == '/home/julie/Dev/Python'
    assert Path().project_dir() != '/home/julie/Dev/Python'
    assert Path().dev_dir() != '/home/julie/Dev/Python'
    print("test_Path_dev_dir: ", Path().dev_dir())
    print("test_Path_project_dir: ", Path().project_dir())


test_Path_dev_dir()

# Generated at 2022-06-23 21:34:55.070785
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # path = PureWindowsPath()
    # path /= 'home'
    # print(path)
    # print(sys.platform)
    path = Path(sys.platform)
    value = path.project_dir()
    print(value)
    assert isinstance(value, str)


if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:34:56.820833
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root().__eq__("/") == True


# Generated at 2022-06-23 21:34:57.809497
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert(Path().project_dir() != "")

# Generated at 2022-06-23 21:35:01.568757
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_instance = Path()
    for i in range(100):
        print(path_instance.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()
    exit(0)

# Generated at 2022-06-23 21:35:02.960512
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(1000):
        print(Path().project_dir())

# Generated at 2022-06-23 21:35:04.471090
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/zoraida/Development/Erlang'

# Generated at 2022-06-23 21:35:05.918498
# Unit test for method home of class Path
def test_Path_home():
    dp = Path()
    assert dp.home() == "/home"


# Generated at 2022-06-23 21:35:08.979335
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    p = Path()
    print(p.home())



# Generated at 2022-06-23 21:35:12.898123
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import Platform
    path = Path(platform=Platform.WINDOWS)
    c_dir = path.home()
    assert path._pathlib_home == 'C:\\Users'
    assert c_dir == 'C:\\Users'


# Generated at 2022-06-23 21:35:16.129777
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root == str(PurePosixPath().parent) \
        or root == str(PureWindowsPath().parent)

# Generated at 2022-06-23 21:35:25.136396
# Unit test for method user of class Path
def test_Path_user():
    # TODO: Unit test for method user of class Path
    from pathlib import PurePosixPath, PureWindowsPath
    path1 = PurePosixPath()
    path2 = PureWindowsPath()
    path1 /= '/home'
    path2 /= 'C:\\Users'
    test_paths = [path1.parent, path2.parent]
    print(test_paths)
    test_path = '/home'
    assert str(path1) == test_path, print(str(path1), test_path)


# Generated at 2022-06-23 21:35:30.011685
# Unit test for constructor of class Path
def test_Path():
    # path = Path('linux')
    # print(path.root())
    # print(path.home())
    # print(path.user())
    # print(path.users_folder())
    # print(path.dev_dir())
    print(Path('linux').project_dir())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:35:32.365911
# Unit test for method home of class Path
def test_Path_home():
    """Test method for home.

    Should return:
        /home
    """
    provider = Path()
    print(provider.home())


# Generated at 2022-06-23 21:35:34.528853
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path"""
    path = Path()
    result = path.users_folder()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:35:35.714166
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-23 21:35:36.512339
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())

# Generated at 2022-06-23 21:35:40.586451
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method Path.root()."""
    from hashlib import md5

    path = Path(seed=0)
    root = path.root()
    result = md5(root.encode())
    assert result.hexdigest() == '3d6caa7e5769cfbce4e4fc4bc4fbe7bf'


# Generated at 2022-06-23 21:35:42.001951
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    assert type(result) is str


# Generated at 2022-06-23 21:35:44.517796
# Unit test for method home of class Path
def test_Path_home():
    example_1 = '/home'
    example_2 = '/Users'
    assert Path('linux').home() == example_1
    assert Path('darwin').home() == example_2
    assert Path('win32').home() == example_1
    assert Path('win64').home() == example_1


# Generated at 2022-06-23 21:35:48.004845
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path)
    for i in range(10):
        print(path.dev_dir())

test_Path_dev_dir()

# Generated at 2022-06-23 21:35:49.210929
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == "/home"


# Generated at 2022-06-23 21:35:54.803431
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.dev_dir())
    print(p.project_dir())
    print(p.users_folder())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:36:02.362321
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.builtins.path import Path
    # Path.dev_dir is a function in Path with no arguments.
    assert callable(Path.dev_dir)
    # This is a test of random return values.
    # Every time the test is run, a different value is returned.
    assert Path().dev_dir() in [
        '/home/rawley/Development/C#',
        '/home/coby/Development/C',
        '/home/dion/Dev/JavaScript',
        '/home/aurora/Dev/C++',
        '/home/sherrell/Development/Python',
    ]

# Generated at 2022-06-23 21:36:06.466448
# Unit test for method root of class Path
def test_Path_root():
    """Result of method root must return a string
    with root path.
    """
    path = Path()
    result = path.root()
    assert isinstance(result, str)
    assert result != ''



# Generated at 2022-06-23 21:36:09.068057
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Create provider
    provider = Path()

    # Generate a random path
    result = provider.dev_dir()

    # Show result in terminal
    print(result)



# Generated at 2022-06-23 21:36:10.950327
# Unit test for method root of class Path
def test_Path_root():
    path = Path(platform='darwin')
    assert path.root() == '/'



# Generated at 2022-06-23 21:36:12.537525
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(20):
        print(Path().project_dir())


# Generated at 2022-06-23 21:36:14.072851
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert 'a' in path.root()


# Generated at 2022-06-23 21:36:16.750495
# Unit test for method user of class Path
def test_Path_user():
    """See if Path.user works properly."""
    s = Path()
    for i in range(10):
        print(s.user())


# Generated at 2022-06-23 21:36:20.197986
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.random import Random
    test_seed = 13579
    random = Random(test_seed)
    path = Path(random=random)
    result = path.user()
    assert result == '/home/sylvia', 'Expected : /home/sylvia'

# Generated at 2022-06-23 21:36:21.979365
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert type(path.root()) == str
    assert path.root() in ['\\', '/']


# Generated at 2022-06-23 21:36:25.522452
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    from mimesis import path
    
    p = path.Path()
    p.random.seed(0)
    result = p.user()
    assert result == '/home/taneka'

# Generated at 2022-06-23 21:36:28.104942
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    path = p.users_folder()
    assert type(path) == str
    print(path)


# Generated at 2022-06-23 21:36:31.994316
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_test = Path()
    path_test.platform = 'linux'
    path_test._pathlib_home = PurePosixPath()
    path_test._pathlib_home /= PLATFORMS['linux']['home']
    assert path_test.dev_dir()

# Generated at 2022-06-23 21:36:38.146529
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform="linux")
    assert path.platform == "linux"
    assert path._pathlib_home == PurePosixPath('/home')

    path = Path(platform="darwin")
    assert path.platform == "darwin"
    assert path._pathlib_home == PurePosixPath('/Users')

    path = Path(platform="win32")
    assert path.platform == "win32"
    assert path._pathlib_home == PureWindowsPath('C:\\Users')

    path = Path(platform="win64")
    assert path.platform == "win64"
    assert path._pathlib_home == PureWindowsPath('C:\\Users')

# Generated at 2022-06-23 21:36:40.472259
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())
# test_Path_project_dir()

# Generated at 2022-06-23 21:36:42.306974
# Unit test for method home of class Path
def test_Path_home():
    from .path import Path
    p = Path()
    assert p.home() == "/home"

# Generated at 2022-06-23 21:36:45.964593
# Unit test for constructor of class Path
def test_Path():
    print(Path())
    print(Path(platform='win32'))
    print(Path(platform='darwin'))
    print(Path(platform='linux'))


# Generated at 2022-06-23 21:36:51.628523
# Unit test for constructor of class Path
def test_Path():
    print("\n# Path")
    paths = Path()
    print("Root: ", paths.root())
    print("Home: ", paths.home())
    print("User: ", paths.user())
    print("Users folder: ", paths.users_folder())
    print("Dev dir: ", paths.dev_dir())
    print("Project dir: ", paths.project_dir())

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:36:58.267394
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    x_platform = path.random.choice(['linux', 'darwin', 'win32', 'win64'])
    path = Path(x_platform)
    x_platform = path.random.choice(['linux', 'darwin', 'win32', 'win64'])
    path = Path(x_platform)
    x_platform = path.random.choice(['linux', 'darwin', 'win32', 'win64'])
    path = Path(x_platform)
    path = Path('linux')
    path = Path('darwin')
    path = Path('win32')
    path = Path('win64')


# Generated at 2022-06-23 21:37:00.071250
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    path = p.home()
    assert path == '/home'


# Generated at 2022-06-23 21:37:02.025738
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    res = path.users_folder()
    print (res)


# Generated at 2022-06-23 21:37:03.835757
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'



# Generated at 2022-06-23 21:37:05.171695
# Unit test for constructor of class Path
def test_Path():
    assert Path() != None
    assert Path('linux') != None


# Generated at 2022-06-23 21:37:06.149571
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())

# Generated at 2022-06-23 21:37:08.062554
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    p = Path(platform='linux')
    assert p.root() == '/'


# Generated at 2022-06-23 21:37:08.980823
# Unit test for constructor of class Path
def test_Path():
    mypath = Path()
    assert isinstance(mypath, Path)

# Generated at 2022-06-23 21:37:09.841853
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    pass


# Generated at 2022-06-23 21:37:13.627100
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    temp = Path()
    assert temp.project_dir() == "/home/pamela/Development/Django/coddington"


# Generated at 2022-06-23 21:37:18.577531
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender

    path = Path('linux')

    field = Field('path.project_dir')
    schema = Schema(path, gender=Gender.FEMALE)
    #print(schema.create(field))
    assert schema.create(field) != None

# Generated at 2022-06-23 21:37:20.190336
# Unit test for method root of class Path
def test_Path_root():
    assert len(Path().root()) > 0 


# Generated at 2022-06-23 21:37:22.933258
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_provider = Path(platform='linux')
    result = path_provider.dev_dir()
    assert result == '/home/lorene/Development/Python'


# Generated at 2022-06-23 21:37:25.357670
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    result = p.home()
    assert result == '/home'


# Generated at 2022-06-23 21:37:27.235987
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    for i in range(50):
        print(p.project_dir())



# Generated at 2022-06-23 21:37:33.555726
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    results = {
        'linux': ('/home/carolynn/Pictures',),
        'darwin': ('/home/ginette/Pictures',),
        'win32': ('/home/julieann/Pictures',),
        'win64': ('/home/margy/Pictures',),
    }
    for platform in results.keys():
        path.platform = platform
        assert results[platform] == (path.users_folder(),)



# Generated at 2022-06-23 21:37:35.629243
# Unit test for method root of class Path
def test_Path_root():
    p = Path('darwin')
    print(p.root())

# Generated at 2022-06-23 21:37:36.849499
# Unit test for method project_dir of class Path
def test_Path_project_dir():
  p=Path()
  assert p.project_dir()=='/home/kimberlie/Development/Python/catalyst'

# Generated at 2022-06-23 21:37:44.879953
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    seed = 2525
    n = 5
    path = Path(platform='linux', seed=seed)
    dev_dir = path.dev_dir()
    assert dev_dir == '/home/rubie/Development/React'
    dev_dir = path.dev_dir()
    assert dev_dir == '/home/long/Dev/Python'
    dev_dir = path.dev_dir()
    assert dev_dir == '/home/antonietta/Dev/C++'
    dev_dir = path.dev_dir()
    assert dev_dir == '/home/elvina/Development/Python'
    dev_dir = path.dev_dir()
    assert dev_dir == '/home/hong/Development/Php'


# Generated at 2022-06-23 21:37:45.790672
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())

# Generated at 2022-06-23 21:37:47.534336
# Unit test for constructor of class Path
def test_Path():
    provider = Path()
    assert isinstance(provider, Path)

# Unit tests for methods of class Path

# Generated at 2022-06-23 21:37:57.721136
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    ''' Test for project_dir, this method generate a random path to project directory '''
    path = Path('linux')
    path1 = Path('darwin')
    path2 = Path('win32')
    path3 = Path('win64')
    paths = [path.project_dir(), path1.project_dir(), path2.project_dir(), path3.project_dir()]
    assert isinstance(paths, list) == True
    assert paths[0] != paths[1]
    assert paths[0] != paths[2]
    assert paths[0] != paths[3]
    assert paths[1] != paths[2]
    assert paths[1] != paths[3]
    assert paths[2] != paths[3]
    assert 'Development' in paths[0]
    assert 'Dev' in paths[1]


# Generated at 2022-06-23 21:38:00.465186
# Unit test for method user of class Path
def test_Path_user():
    path = Path('win32')
    print('user: ' + path.user())


# Generated at 2022-06-23 21:38:02.596228
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(str(p.project_dir()))


# Generated at 2022-06-23 21:38:04.190233
# Unit test for method root of class Path
def test_Path_root():
    path = Path('win32')
    assert path.root() == 'C:\\'


# Generated at 2022-06-23 21:38:07.810528
# Unit test for constructor of class Path
def test_Path():
    # Path()
    p = Path()
    print(p.home())
    print(p.user())
    print(p.dev_dir())
    print(p.project_dir())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:38:17.354995
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from datetime import datetime
    from mimesis.exceptions import NonEnumerableError

    seed = datetime.now()
    print(seed)
    path = Path()

    # Wrong platform exception.
    path.platform = 'wrong_platform'
    try:
        path.project_dir()
    except NonEnumerableError as e:
        print(e)

    # Correct platform.
    path.platform = 'linux'
    result = path.project_dir()
    print(result)

    # Wrong platform.
    path.platform = 'wrong_platform'
    try:
        path.project_dir()
    except NonEnumerableError as e:
        print(e)

test_Path_project_dir()

# Generated at 2022-06-23 21:38:19.026261
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:38:20.861699
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    project_dir = p.project_dir()
    print(project_dir)


# Generated at 2022-06-23 21:38:22.108639
# Unit test for constructor of class Path
def test_Path():
    assert Path() is not None


# Generated at 2022-06-23 21:38:24.786424
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/hatty'
    assert Path().user() == '/home/mishelle'
    assert Path().user() == '/home/gaile'


# Generated at 2022-06-23 21:38:26.455722
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test method project_dir of class Path."""
    pth = Path()
    print(pth.project_dir())


# Generated at 2022-06-23 21:38:27.693765
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/oreatha/Dev/Ruby'



# Generated at 2022-06-23 21:38:28.513686
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() is not None

# Generated at 2022-06-23 21:38:29.716608
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:38:31.935069
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    a = path.users_folder()
    assert len(a) > 0
    assert a is not None

# Generated at 2022-06-23 21:38:42.044080
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert (callable(path.users_folder) == True)
    assert (callable(path.dev_dir) == True)
    assert (callable(path.project_dir) == True)
    assert (callable(path.home) == True)
    assert (callable(path.user) == True)
    assert (path.root() in ['/', '\\'])
    assert (path.home() in ['/home', '/Users', 'C:\\Users'])
    assert (isinstance(path.home(), str))
    assert (isinstance(path.root(), str))
    assert (isinstance(path.user(), str))
    assert (isinstance(path.users_folder(), str))
    assert (isinstance(path.dev_dir(), str))

# Generated at 2022-06-23 21:38:45.725470
# Unit test for method root of class Path
def test_Path_root():
    return
    paths = Path()
    res = []
    for i in range(0, 100):
        res.append(paths.root())
    # print(res)


# Generated at 2022-06-23 21:38:46.786532
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert (path)

# Generated at 2022-06-23 21:38:50.025028
# Unit test for method home of class Path
def test_Path_home():
    path_generator = Path()
    home_dir = path_generator.home()
    assert str(home_dir) is not None


# Generated at 2022-06-23 21:38:51.583317
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    print(p.home())


# Generated at 2022-06-23 21:38:54.288983
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == '/home/sherika/Development/Flask/caring'

# Generated at 2022-06-23 21:38:56.035096
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == '/home/oretha/Pictures'


# Generated at 2022-06-23 21:38:57.795889
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    print('\nhome: ', home)



# Generated at 2022-06-23 21:39:00.299935
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    project_dir = path.project_dir()
    print(project_dir)

# Generated at 2022-06-23 21:39:10.764887
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # test 1
    x = Path(*['win32'])
    assert (str(x.dev_dir()) == 'C:\\Users\\user\\Dev\\Java')
    # test 2
    x = Path(*['linux'])
    assert (str(x.dev_dir()) == '/home/user/Development/Java')
    # test 3
    x = Path(*['win32'])
    assert (str(x.dev_dir()) == 'C:\\Users\\user\\Dev\\Python')
    # test 4
    x = Path(*['linux'])
    assert (str(x.dev_dir()) == '/home/user/Development/Cpp')
    # test 5
    x = Path(*['win32'])
    assert (str(x.dev_dir()) == 'C:\\Users\\user\\Dev\\C#')


# Generated at 2022-06-23 21:39:13.501784
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.builtins import Path
    p = Path()
    result = p.users_folder()
    assert result

# Generated at 2022-06-23 21:39:15.620075
# Unit test for method root of class Path
def test_Path_root():
    a = Path(platform='linux', seed=None)
    assert a.root() == '/'


# Generated at 2022-06-23 21:39:18.432622
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    mimesis_path = Path()
    assert mimesis_path.project_dir() == "/home/dianna/Development/Go/emissary"

test_Path_project_dir()


# Generated at 2022-06-23 21:39:20.212281
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    def foo():
        path = Path()
        project_dir = path.random.choice(PROJECT_NAMES)
        return project_dir.is_dir()

    assert foo() is True

# Generated at 2022-06-23 21:39:23.479533
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert (path.users_folder() == '/home/alvera/Pictures/')
    assert (path.users_folder() == '/home/alvera/Pictures/')


# Generated at 2022-06-23 21:39:24.658646
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/home'


# Generated at 2022-06-23 21:39:28.206288
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir = path.project_dir()
    print("Path.project_dir: %s\n" % project_dir)
    
test_Path_project_dir()

# Generated at 2022-06-23 21:39:30.514542
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'
    pass


# Generated at 2022-06-23 21:39:31.493577
# Unit test for method root of class Path
def test_Path_root():
    Path().root()


# Generated at 2022-06-23 21:39:32.223216
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:39:35.354248
# Unit test for method home of class Path
def test_Path_home():
    """Test for method home() of class Path."""

# Generated at 2022-06-23 21:39:37.759827
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print('Path project_dir:',path.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:39:39.735871
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    path = p.project_dir()
    assert isinstance(path, str)
    assert path.find('/') >= 0

# Generated at 2022-06-23 21:39:41.430936
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    random_platform = 'win32'
    path = Path(platform=random_platform)
    path.project_dir()

# Generated at 2022-06-23 21:39:43.659811
# Unit test for constructor of class Path
def test_Path():
    # Check that user folder will be included in path
    p = Path()
    path = p.project_dir()
    user = p.user()
    assert user in path

# Unit tests for method root()

# Generated at 2022-06-23 21:39:45.004077
# Unit test for method root of class Path
def test_Path_root():
    path_provider = Path()
    assert path_provider.root() == '/'


# Generated at 2022-06-23 21:39:47.283062
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir() of class Path."""
    platform = 'linux'
    path = Path(platform)
    assert path.dev_dir() == '/home/ernestine/Dev/Vala'


# Generated at 2022-06-23 21:39:48.557988
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    folder = path.users_folder()
    assert folder != None


# Generated at 2022-06-23 21:40:00.148215
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform=sys.platform)
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
    path.user()
   

# Generated at 2022-06-23 21:40:01.587079
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert path.platform == sys.platform


# Generated at 2022-06-23 21:40:05.092053
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    assert len(dev_dir)>0
    
test_Path_dev_dir()

# Generated at 2022-06-23 21:40:08.602906
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/home'
    assert path.root() == '/home'
    assert path.root() == '/home'
    assert path.root() == '/home'


# Generated at 2022-06-23 21:40:10.454024
# Unit test for constructor of class Path
def test_Path():
    """
    Initialize the global variables
    """
    global path
    path = Path()


# Generated at 2022-06-23 21:40:16.498896
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user in [
        '/home/jaime',
        '/home/kerrie',
        '/home/kirstie',
        '/home/krystin',
        '/home/michell',
        '/home/tammera',
        '/home/tawanda',
        '/home/tia',
        '/home/toney',
        '/home/torri',
    ]