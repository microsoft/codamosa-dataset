

# Generated at 2022-06-23 21:30:11.456143
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:30:14.424435
# Unit test for method user of class Path
def test_Path_user():
    user = Path()
    assert isinstance(user, Path)
    assert user.user()
    print(user.user())



# Generated at 2022-06-23 21:30:22.583525
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage
    p = Path()
    p.random.seed(0)

    assert p.dev_dir() == '/home/ronald/Dev/CoffeeScript'
    assert p.dev_dir() == '/home/shoshana/Dev/CoffeeScript'
    assert p.dev_dir() == '/home/luz/Development/Scala'
    assert p.dev_dir() == '/home/corene/Development/CoffeeScript'
    assert p.dev_dir() == '/home/claribel/Development/CoffeeScript'
    assert p.dev_dir() == '/home/tressie/Dev/Scala'
    assert p.dev_dir() == '/home/brigid/Development/JavaScript'

# Generated at 2022-06-23 21:30:23.884604
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:30:28.631664
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path1 = Path(platform='linux')
    path2 = Path(platform='darwin')
    path3 = Path(platform='win32')
    path4 = Path(platform='win64')
    assert str(path._pathlib_home.parent) == path.root()
    assert str(path._pathlib_home.parent) == path1.root()
    assert str(path._pathlib_home.parent) == path2.root()
    assert str(path._pathlib_home.parent) == path3.root()
    assert str(path._pathlib_home.parent) == path4.root()

if __name__ == "__main__":
    test_Path_root()

# Generated at 2022-06-23 21:30:34.840343
# Unit test for method user of class Path
def test_Path_user():
    p = Path()

# Generated at 2022-06-23 21:30:36.669341
# Unit test for method home of class Path
def test_Path_home():
    path = Path('darwin')
    p = '/Users'
    assert path.home() == p


# Generated at 2022-06-23 21:30:45.043994
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Initialize an object of class Path
    path = Path()
    # Get the random path of user's folders
    path_users_folder = path.users_folder()
    print(path_users_folder)
    # The rest of the code is just to print the result in a pretty way
    # We get the user's name from the path
    user = path_users_folder.split('/')[-2]
    # We get the name of the folder from the path
    folder = path_users_folder.split('/')[-1]
    if path.platform == 'win32' or path.platform == 'win64':
        print('\nUser:')
        print('\t- Name:', user.capitalize())
        print('\t- Folder:')
        print('\t\t- Name:', folder)
   

# Generated at 2022-06-23 21:30:45.722246
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())



# Generated at 2022-06-23 21:30:46.835306
# Unit test for method root of class Path
def test_Path_root():
    path = Path(platform = 'linux')
    assert '/' == path.root()


# Generated at 2022-06-23 21:30:49.534434
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    a = Path()
    result = a.dev_dir()
    assert result == 'C:\\Users\\oretha\\Development\\Batchfile'

# Generated at 2022-06-23 21:30:50.852411
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root()


# Generated at 2022-06-23 21:30:52.528087
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:30:53.335151
# Unit test for method user of class Path
def test_Path_user():
    x = Path(platform='linux')
    print(x.user())


# Generated at 2022-06-23 21:30:54.896152
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert type(root) == str
    

# Generated at 2022-06-23 21:30:57.086975
# Unit test for method root of class Path
def test_Path_root():
    assert len(Path().root()) > 0


# Generated at 2022-06-23 21:30:58.845444
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_obj = Path()
    print(path_obj.users_folder())


# Generated at 2022-06-23 21:31:01.707378
# Unit test for method home of class Path
def test_Path_home():
    a = Path()
    b = str(a.home())
    assert any(b == c for c in ['/home', 'C:\\Users']) == True


# Generated at 2022-06-23 21:31:03.459028
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root == '/'


# Generated at 2022-06-23 21:31:04.381962
# Unit test for constructor of class Path
def test_Path():
    assert Path.__init__

# Generated at 2022-06-23 21:31:07.938142
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    def test1(number):
        p = Path()
        v = []
        i = 0
        while i < number:
            r = p.users_folder()
            if r not in v:
                v.append(r)
                print(r)
                i += 1
    return test1(3)

# Generated at 2022-06-23 21:31:10.095774
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-23 21:31:12.297483
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path('win32')
    print(path.dev_dir())


# Generated at 2022-06-23 21:31:13.712313
# Unit test for method root of class Path
def test_Path_root():
	test_class = Path()
	result = test_class.root()
	assert (result[0] == 'C' or result[0] == '/')


# Generated at 2022-06-23 21:31:15.868109
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    path = p.dev_dir()
    assert "home" in path
    assert "Pictures" in path



# Generated at 2022-06-23 21:31:19.004992
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('linux')
    print("users_folder: ", p.users_folder())
    assert p.users_folder() != None


# Generated at 2022-06-23 21:31:22.534314
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for function project_dir of class Path."""
    p = Path()
    pd = p.project_dir()
    print(pd)
    assert isinstance(pd, str) is True


# Generated at 2022-06-23 21:31:24.197549
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path().project_dir()
    assert path == '/home/sherika/Development/Falcon/chili'

# Generated at 2022-06-23 21:31:25.995317
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    x = path.project_dir()
    assert isinstance(x, str)

# Generated at 2022-06-23 21:31:31.628246
# Unit test for constructor of class Path
def test_Path():
    platform = sys.platform
    path = Path(platform)
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() if 'win' in platform else PurePosixPath()
    assert path._pathlib_home == PureWindowsPath() / PLATFORMS[platform]['home']

# Unit tests for method root

# Generated at 2022-06-23 21:31:40.141434
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    r"""
    Test method project_dir of class Path.
    Input:
    Output:
    """
    path = Path()
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())

# Generated at 2022-06-23 21:31:46.646957
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # tests ['/home/hong/Documents', '/home/jamey/Pictures']
    from mimesis.enums import OperatingSystem
    from mimesis.providers.base import Context
    from random import Random
    random = Random(666)
    ctx = Context(operating_system=OperatingSystem.LINUX,
                  random=random)
    path = Path(platform='linux', ctx=ctx)
    print(path.users_folder())

# Generated at 2022-06-23 21:31:47.815177
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:51.594608
# Unit test for method home of class Path
def test_Path_home():
    try:
        p = Path()
        p.home()
    except:
        print("test_Path_home: FAIL")
        return False
    else:
        print("test_Path_home: PASS")
        return True


# Generated at 2022-06-23 21:31:54.047074
# Unit test for method root of class Path
def test_Path_root():
    """ Unit test for method root of class Path """
    path = Path(platform='Darwin')
    result = path.root()
    assert result == '/'


# Generated at 2022-06-23 21:31:58.293904
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert(isinstance(p.users_folder(), str)) is True
    print("users_folder : ", p.users_folder())


# Generated at 2022-06-23 21:32:00.808709
# Unit test for method user of class Path
def test_Path_user():
    p1 = Path()
    assert p1.user() == '/home/tangela' or p1.user() == 'C:\\Users\\DELPHIA'

# Generated at 2022-06-23 21:32:02.079533
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert(str(p.users_folder()) == "/home/kittie/Documents")

# Generated at 2022-06-23 21:32:03.352391
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:32:05.739818
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()

    path = p.users_folder()
    assert isinstance(path, str)
    assert path.startswith('/home/')



# Generated at 2022-06-23 21:32:07.444966
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p = Path(platform='win32')
    p = Path(platform='win64')

# Generated at 2022-06-23 21:32:10.407384
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.seed(1)
    root = path.root()
    print(root)


# Generated at 2022-06-23 21:32:12.257118
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    assert isinstance(path.user(), str)

# Generated at 2022-06-23 21:32:15.933116
# Unit test for method home of class Path
def test_Path_home():
    path = Path(platform='darwin')
    home = path.home()
    home = str(home)
    assert isinstance(home, str)


# Generated at 2022-06-23 21:32:18.260553
# Unit test for method root of class Path
def test_Path_root():
    objPath = Path(platform='linux')
    assert type(objPath) == Path
    assert objPath.root() == '/'


# Generated at 2022-06-23 21:32:19.623515
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert 'Meta' in str(p)

# Generated at 2022-06-23 21:32:21.472086
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    result = Path().project_dir()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:32:22.811668
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:32:24.111605
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() != None


# Generated at 2022-06-23 21:32:25.410590
# Unit test for method home of class Path
def test_Path_home():
    instance = Path()
    assert 'home' in instance.home()


# Generated at 2022-06-23 21:32:32.149792
# Unit test for constructor of class Path
def test_Path():
    class TestPath:
        def __init__(self, platform: str = sys.platform,
                     *args, **kwargs) -> None:
            """Initialize attributes.

            Supported platforms: 'linux', 'darwin', 'win32', 'win64'.

            :param platform: Required platform type.
            """
            # super().__init__(*args, **kwargs)
            self.platform = platform
            self._pathlib_home = PureWindowsPath() if 'win' in platform \
                                 else PurePosixPath()
            self._pathlib_home /= PLATFORMS[platform]['home']

        # class Meta:
        #     """Class for metadata."""
        #
        #     name = 'path'


# Generated at 2022-06-23 21:32:34.113826
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == "C:/Users/User/Development/JavaScript/gangster"

# Generated at 2022-06-23 21:32:42.876511
# Unit test for constructor of class Path
def test_Path():
    assert Path('linux').user() == '/home/josue'
    assert Path('win32').user() == 'C:\\Users\\josie'
    assert Path().random.choice(PROGRAMMING_LANGS) == 'C#'
    assert Path('linux').random.choice(PROGRAMMING_LANGS) == 'C#'
    assert Path('win32').random.choice(PROGRAMMING_LANGS) == 'C#'
    assert Path('win64').random.choice(PROGRAMMING_LANGS) == 'C#'


# Generated at 2022-06-23 21:32:44.790187
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    r = p.home()
    assert r != 'home'


# Generated at 2022-06-23 21:32:48.490825
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    tmp = Path('win32', seed=0)
    tmp1 = Path('win64', seed=0)
    assert tmp.project_dir() == 'C:\\Users\\Pansy\\Development\\R\\ease'
    assert tmp1.project_dir() == 'C:\\Users\\Pansy\\Development\\R\\ease'

# Generated at 2022-06-23 21:32:49.538151
# Unit test for method home of class Path
def test_Path_home():
    wp = Path()
    print(wp.home())

# Generated at 2022-06-23 21:32:51.787901
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    # assert isinstance(p.dev_dir(), str)
    # print(p.dev_dir())

# Generated at 2022-06-23 21:32:53.257791
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method path of class Path."""
    p = Path()
    assert p.user() in '/home/oretha'

# Generated at 2022-06-23 21:32:55.750436
# Unit test for method root of class Path
def test_Path_root():
    """Unit test that generates a path using the  method root."""
    path = Path(seed=12345)
    assert path.root() == '/'



# Generated at 2022-06-23 21:32:57.115339
# Unit test for method root of class Path
def test_Path_root():
    _Path = Path()
    print(_Path.root())


# Generated at 2022-06-23 21:32:59.882722
# Unit test for method users_folder of class Path
def test_Path_users_folder():
        path = Path()
        path.random.seed(25)
        assert path.users_folder() == '/home/lucinda/Documents'


# Generated at 2022-06-23 21:33:03.570289
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert hasattr(path, 'pathlib_home')
    assert hasattr(path, 'platform')
    assert hasattr(path, '_pathlib_home')
    assert hasattr(path, '_pathlib_home')


# Generated at 2022-06-23 21:33:04.866187
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'


# Generated at 2022-06-23 21:33:08.495900
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class."""
    p = Path('win32')
    path = p.project_dir()
    print(path)



# Generated at 2022-06-23 21:33:11.779531
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_generator = Path(platform='linux')
    p = path_generator.users_folder()
    assert '/home/' in p
    assert True


# Generated at 2022-06-23 21:33:13.853102
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    with open('path.txt', 'w') as f:
        for i in range(0,10):
            f.write(str(Path().project_dir()) + '\n')
    print("Function Path.project_dir() was tested and .txt file was written")

# Generated at 2022-06-23 21:33:16.257612
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test method dev_dir of class Path."""
    path = Path()
    result = path.dev_dir()
    assert "home" in result

# Generated at 2022-06-23 21:33:18.922045
# Unit test for method home of class Path
def test_Path_home():
    a = Path()
    print("\nPath().home() : ", a.home())
    assert a.home() != None


# Generated at 2022-06-23 21:33:19.713349
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
  path = Path()
  print(path.dev_dir())

# Generated at 2022-06-23 21:33:20.994525
# Unit test for method user of class Path
def test_Path_user():
    a=Path()
    print(a.user())


# Generated at 2022-06-23 21:33:21.910961
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:33:23.229702
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:33:30.558713
# Unit test for constructor of class Path
def test_Path():
    """ This is the main function to test set of functions and classes """
    # Create a dictionary
    platform = sys.platform
    args =  "1"
    kwargs = {'test':'test'}
    path = Path(platform, *args, **kwargs)
    print(path)
    assert callable(getattr(path, 'platform', None))
    assert callable(getattr(path, '_pathlib_home', None))
    assert callable(getattr(path, 'root', None))
    assert callable(getattr(path, 'home', None))
    assert callable(getattr(path, 'user', None))
    assert callable(getattr(path, 'users_folder', None))
    assert callable(getattr(path, 'dev_dir', None))

# Generated at 2022-06-23 21:33:33.111141
# Unit test for constructor of class Path
def test_Path():
    x = Path('linux')
    assert x.platform == 'linux'
    assert x.Meta.name == 'path'


# Generated at 2022-06-23 21:33:34.619472
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('linux')
    assert p.users_folder() == '/home/keiko/Desktop'

# Generated at 2022-06-23 21:33:35.413560
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    return Path().users_folder()


# Generated at 2022-06-23 21:33:37.830463
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path"""
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:33:44.785403
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    p = Path()
    assert p is not None
    assert p.platform == sys.platform
    assert p._pathlib_home.as_posix() == '/home/geoffrey'
    if sys.platform == 'win32' or sys.platform == 'win64':
        p = Path('win32')
        assert p is not None
        assert p.platform == 'win32'
        assert p._pathlib_home.as_posix() == 'C:\\Users\\reba'


# Generated at 2022-06-23 21:33:45.683409
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())


# Generated at 2022-06-23 21:33:48.458451
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    a=Path()
    print("a.dev_dir() ", a.dev_dir())
    assert callable(a.dev_dir)



# Generated at 2022-06-23 21:33:53.142593
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    print("\nPath.dev_dir() is:")
    print( dev_dir )
    assert dev_dir == '/home/sherrell/Development/Python'


# Generated at 2022-06-23 21:33:54.579523
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())
    pass

# Generated at 2022-06-23 21:33:55.257026
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/quincy'

# Generated at 2022-06-23 21:34:03.212818
# Unit test for method user of class Path
def test_Path_user():
    path = Path()

    path.random.seed(112234)
    assert path.user() == '/home/darron'

    path.random.seed(112235)
    assert path.user() == '/home/brandi'

    path.random.seed(112236)
    assert path.user() == '/home/charline'

    path.random.seed(112237)
    assert path.user() == '/home/cordia'

    path.random.seed(112238)
    assert path.user() == '/home/ashley'

    path.random.seed(112264)
    assert path.user() == '/Users/Gudrun'

    path.random.seed(112265)
    assert path.user() == '/Users/Devona'

    path.random.seed(112266)
    assert path.user

# Generated at 2022-06-23 21:34:05.094889
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    test_dict = {}
    assert test_dict.get(path.users_folder()) == None
    test_dict[path.users_folder()] = True
    assert test_dict.get(path.users_folder()) == True


# Generated at 2022-06-23 21:34:05.904921
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()


# Generated at 2022-06-23 21:34:06.492846
# Unit test for constructor of class Path
def test_Path():
    p = Path()

# Generated at 2022-06-23 21:34:08.208517
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    #assert path.root() == ...


# Generated at 2022-06-23 21:34:11.312826
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("\n")
    path = Path()
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())


# Generated at 2022-06-23 21:34:13.730373
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    path = p.project_dir()
    print(path)

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:34:16.007506
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert type(path.home()) is str
    assert len(path.home()) > 0

# Generated at 2022-06-23 21:34:18.416253
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='win32')
    path.user()
    # We got here, so the method didn't raise
    assert True


# Generated at 2022-06-23 21:34:19.357616
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.home())

# Generated at 2022-06-23 21:34:21.670713
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path(platform='linux')
    assert path.project_dir() != '/home/sherika/Development/Falcon/mercenary'
    

# Generated at 2022-06-23 21:34:24.035147
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    for i in range(0, 5):
        st = str(p.project_dir())
        assert st.endswith('/Development/Falcon/mercenary')


# Generated at 2022-06-23 21:34:27.636509
# Unit test for constructor of class Path
def test_Path():
    sut = Path()
    assert sut._platform == 'darwin'
    assert sut._pathlib_home == PurePosixPath(PLATFORMS['darwin']['home'])


# Generated at 2022-06-23 21:34:38.286213
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.providers.path import Path
    from mimesis.generators import datetime

    datetime = datetime(datetime_format='%d/%m/%Y')
    generated_folders = []

    for i in range(1000):
        generated_folders.append(Path().users_folder())

    assert generated_folders[0] == '/home/toney/Documents/' + \
        datetime.datetime_timestamp() + '.txt'

    assert generated_folders[1] == '/home/darnell/Pictures/' + \
        datetime.datetime_timestamp() + '.png'
#
# print(Path().users_folder())
# print(Path().dev_dir())
# print(Path().project_dir())

# Generated at 2022-06-23 21:34:41.736253
# Unit test for method home of class Path
def test_Path_home():
    path_obj = Path()
    home_path = path_obj.home()
    assert home_path == '/home'


# Generated at 2022-06-23 21:34:43.620267
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path = path.project_dir()
    print(path)


# Generated at 2022-06-23 21:34:45.358935
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() in ["/home", "C:\\Users" ]


# Generated at 2022-06-23 21:34:54.361843
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    p = Path()
    names = [p.user() for i in range(100)]
    for name in names:
        user_name = name.split('/')[-1]
        assert user_name in USERNAMES, \
            f"user -> Testing user_name failed: {user_name} is not in USERNAMES"

    # Gender testing
    p = Path(random_data_type=Gender.MALE)
    names = [p.user() for i in range(100)]
    for name in names:
        user_name = name.split('/')[-1]
        assert user_name in USERNAMES, \
            f"user -> Testing user_name failed: {user_name} is not in USERNAMES"

# Generated at 2022-06-23 21:34:56.992146
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    path = Path()
    assert path.project_dir() == '/home/Development/Python/mercenary'

# Generated at 2022-06-23 21:35:00.277708
# Unit test for constructor of class Path
def test_Path():

    main_1 = Path()
    main_1.platform = 'linux'
    assert main_1.platform == 'linux'

    assert main_1.Meta.name == 'path'


# Generated at 2022-06-23 21:35:02.221347
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/phillip/Dev/Django'

# Generated at 2022-06-23 21:35:07.723105
# Unit test for constructor of class Path
def test_Path():
    """Unit test for Path"""
    p = Path()
    print('p.root() =', p.root())
    print('p.home() =', p.home())
    print('p.user() =', p.user())
    print('p.users_folder() =', p.users_folder())
    print('p.dev_dir() =', p.dev_dir())
    print('p.project_dir() =', p.project_dir())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:35:18.536294
# Unit test for constructor of class Path
def test_Path():
	
	# create instance of Path
	# print instance
	print()
	path = Path()
	print(path)
	print()

	# create root dir
	# print root dir
	print()
	root_dir = path.root()
	print('root_dir:', root_dir)
	print()

	# create home dir
	# print home dir
	print()
	home_dir = path.home()
	print('home_dir:', home_dir)
	print()

	# create user dir
	# print user dir 
	print()
	user_dir = path.user()
	print('user_dir:', user_dir)
	print()

	# create user's folder
	# print user's folder
	print()
	users_folder = path.users_folder()

# Generated at 2022-06-23 21:35:20.873840
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    result = p.root()
    assert (result == '/')


# Generated at 2022-06-23 21:35:30.453685
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.random.seed(0) # default seed
    assert p.dev_dir() == '/home/cristine/Development/C#'
    p.random.seed(1)
    assert p.dev_dir() == '/home/cristine/Development/C++'
    p.random.seed(2)
    assert p.dev_dir() == '/home/cristine/Development/Haskell'
    p.random.seed(3)
    assert p.dev_dir() == '/home/cristine/Development/Clojure'
    p.random.seed(4)
    assert p.dev_dir() == '/home/cristine/Development/PHP'
    p.random.seed(5)
    assert p.dev_dir() == '/home/cristine/Development/Ruby'

# Generated at 2022-06-23 21:35:32.874341
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/cammie/Development/JavaScript'


# Generated at 2022-06-23 21:35:34.839723
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == '/home/tish/Development/Rust/Mimesis'

# Generated at 2022-06-23 21:35:37.796914
# Unit test for method root of class Path
def test_Path_root():
    test_path = Path()
    assert test_path.root() == '/' \
        or test_path.root() == 'C:\\' \
        or test_path.root() == 'D:\\'


# Generated at 2022-06-23 21:35:38.859867
# Unit test for method project_dir of class Path
def test_Path_project_dir(): 
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:35:40.875084
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path(platform='linux')
    s = p.users_folder()
    assert s == '/home/louie/Pictures'


# Generated at 2022-06-23 21:35:44.467372
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    parameter = Path(platform='linux')
    results = parameter.project_dir()
    assert isinstance(results, str)
    assert results == '/home/daija/Development/Rust/vapor'


# Generated at 2022-06-23 21:35:46.247839
# Unit test for method user of class Path
def test_Path_user():
    for i in range(10):
        print(Path().user())


# Generated at 2022-06-23 21:35:52.722642
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    size = 3
    path = Path()
    expected_paths = [
        str(Path()._pathlib_home / 'berenice' / 'Pictures'),
        str(Path()._pathlib_home / 'jessika' / 'Movies'),
        str(Path()._pathlib_home / 'marcelina' / 'Pictures'),
    ]
    actual_paths = []
    for _ in range(size):
        actual_paths.append(path.users_folder())
    assert actual_paths == expected_paths

# Generated at 2022-06-23 21:35:55.582104
# Unit test for method home of class Path
def test_Path_home():

    # -----------------------
    # TEST EXECUTION
    # -----------------------
    from mimesis.enums import Platform
    path = Path(platform=Platform.MAC_OS.value)
    result = path.home()

    # -----------------------
    # VERIFYING RESULTS
    # -----------------------
    assert result == '/Users'



# Generated at 2022-06-23 21:35:57.730038
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test method dev_dir."""
    p = Path()
    path = p.dev_dir()
    assert isinstance(path, str)
    assert path.startswith('/home/')

# Generated at 2022-06-23 21:35:59.290702
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p._pathlib_home = PurePosixPath('/home/')
    p.seed(0)
    assert str(p.dev_dir()) == '//home/cheyenne/Development/Golang'


# Generated at 2022-06-23 21:36:06.837058
# Unit test for method user of class Path
def test_Path_user():
  path = Path()
  print(path.home())
  print(path.user())
  print(path.users_folder())
  print(path.dev_dir())
  print(path.project_dir())

#  print(path.user())
#  print(path.user())
#  print(path.user())
#  print(path.user())
#  print(path.user())


# Command line
# python3.6 -c 'import _path; _path.test_Path_user()'

# Home
# /home
# /home/oretha
# /home/taneka/Pictures
# /home/sherrell/Development/Python
# /home/sherika/Development/Falcon/mercenary


test_Path_user()

# Generated at 2022-06-23 21:36:08.466083
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print ("project_dir: %s" % p.project_dir())

# Generated at 2022-06-23 21:36:09.953353
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:36:20.554302
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    from random import seed
    from string import digits
    from string import ascii_uppercase

    # Input data
    valid_platform = ['linux', 'darwin', 'win32', 'win64']
    # Perform test
    for _ in range(100):
        seed(sum(map(ord, 'test_Path_root')))
        platform = ''.join(
            [
                valid_platform[
                    seed(sum(map(ord, digits + ascii_uppercase))) %
                    len(valid_platform)
                ]
            ]
        )
        path_instance = Path(platform=platform)
        path_instance.root()
        path_instance.home()
        path_instance.user()
        path_instance.users_folder()
        path_

# Generated at 2022-06-23 21:36:22.054786
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() != ''


# Generated at 2022-06-23 21:36:26.797985
# Unit test for constructor of class Path
def test_Path():
    testpath = Path()
    assert testpath.root() == '/'
    assert testpath.home() == '/home'
    assert testpath.dev_dir() != ''
    assert testpath.project_dir() != ''
    assert testpath.home() == '/home'
    assert testpath.users_folder() != ''

# Generated at 2022-06-23 21:36:28.073304
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()

# Generated at 2022-06-23 21:36:29.363759
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert 'home' in path.user()


# Generated at 2022-06-23 21:36:37.424777
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path(platform = 'linux').dev_dir() == "/home/mann/Development/Lisp"
    assert Path(platform = 'linux').dev_dir() == "/home/mimi/Dev/Ada"
    assert Path(platform = 'linux').dev_dir() == "/home/mathilda/Development/JavaScript"
    assert Path(platform = 'linux').dev_dir() == "/home/stephan/Development/Java"
    assert Path(platform = 'linux').dev_dir() == "/home/clay/Development/Python"
    assert Path(platform = 'linux').dev_dir() == "/home/bernardine/Dev/Mira"
    assert Path(platform = 'linux').dev_dir() == "/home/sueann/Dev/SmallTalk"

# Generated at 2022-06-23 21:36:38.734264
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:36:41.970006
# Unit test for constructor of class Path
def test_Path():
    test = Path()
    print(test.root())
    print(test.home())
    print(test.user())
    print(test.users_folder())
    print(test.dev_dir())
    print(test.project_dir())

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:36:43.802555
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'



# Generated at 2022-06-23 21:36:46.160455
# Unit test for method user of class Path
def test_Path_user():
    """Test user method of class Path."""
    path = Path()
    path.home()
    path.user()

# Generated at 2022-06-23 21:36:48.097125
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() not in [None,""]


# Generated at 2022-06-23 21:36:49.227023
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:36:50.836649
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:36:53.700324
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())

# Generated at 2022-06-23 21:37:00.306664
# Unit test for method user of class Path
def test_Path_user():
    p = Path(platform='win32')
    h = str(PureWindowsPath())
    assert p.user() == h + '\\' + 'Dell' or p.user() == h + '\\' + 'Accer' or p.user() == h + '\\' + 'Acer' or p.user() == h + '\\' + 'Dell' or p.user() == h + '\\' + 'Asus' or p.user() == h + '\\' + 'Apple' or p.user() == h + '\\' + 'Samsung' or p.user() == h + '\\' + 'Sony' or p.user() == h + '\\' + 'Lenovo' or p.user() == h + '\\' + 'Toshiba'

# Generated at 2022-06-23 21:37:01.404462
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/sherika'

# Generated at 2022-06-23 21:37:03.255474
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()


# Generated at 2022-06-23 21:37:04.710928
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.Meta.name == 'path'
    assert True

# Generated at 2022-06-23 21:37:06.326672
# Unit test for method root of class Path
def test_Path_root():
    import sys
    path = Path(platform=sys.platform)
    assert "/" == path.root()

# Generated at 2022-06-23 21:37:07.565033
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    p.home()


# Generated at 2022-06-23 21:37:09.886413
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path('linux').project_dir() != Path('darwin').project_dir()
    assert Path('win32').project_dir() != Path('win64').project_dir()


# Generated at 2022-06-23 21:37:20.560317
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.providers.personal import Personal
    # Gender: 'male'
    path = Path()
    p = Personal(platform='linux', gender=Gender.MALE)
    assert path.user() == '/home/' + p.username()
    # Gender: 'female'
    path = Path()
    p = Personal(platform='linux', gender=Gender.FEMALE)
    assert path.user() == '/home/' + p.username()
    # Gender: 'unknown'
    path = Path()
    p = Personal(platform='linux', gender=Gender.UNKNOWN)
    assert path.user() == '/home/' + p.username()

# Generated at 2022-06-23 21:37:26.771868
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # create a Path object
    path = Path()
    # assert that Path object's attribute dev_dir is callable
    assert callable(path.dev_dir)
    # assert that the return value of a method is of type str
    assert isinstance(path.dev_dir(), str)
    # assert that the return value is of length greater than 0
    assert len(path.dev_dir()) > 0


# Generated at 2022-06-23 21:37:28.803486
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('linux')
    for i in range(10):
        p.users_folder()


# Generated at 2022-06-23 21:37:31.368790
# Unit test for method user of class Path
def test_Path_user(): # tests are run in alphabetical order, which is why we need to prefix with test
    p = Path('linux')
    assert p.user() == '/home/ashlie'

# Generated at 2022-06-23 21:37:32.346488
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(5):
        print(Path().project_dir())

# Generated at 2022-06-23 21:37:39.276017
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    from mimesis.exceptions import NonEnumerableError
    instance = Path()
    assert instance.root() == '/'
    instance = Path(platform=Platform.WINDOWS)
    assert instance.root() == 'C:\\'
    try:
        instance = Path(platform='hello world!')
        instance.root()
    except NonEnumerableError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:37:46.825309
# Unit test for constructor of class Path
def test_Path():
    print('Testing Path class')
    print('Testing constructor')
    path = Path()
    assert (path is not None)
    print('Testing property home')
    assert (path.home().startswith('/home'))
    print('Testing property user')
    assert (path.user().startswith('/home/'))
    print('Testing method users_folder')
    assert (path.users_folder().startswith('/home/'))
    print('Testing method dev_dir')
    assert (path.dev_dir().startswith('/home/'))
    print('Testing method project_dir')
    assert (path.project_dir().startswith('/home/'))

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:37:49.211912
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.random._randrange = lambda _, __: 0
    assert path.dev_dir() == '/home/sherrell/Development/Python'


# Generated at 2022-06-23 21:37:54.244296
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path = Path()
    assert path.home() == r'C:\Users\Dalton'  # for Windows
    path = Path('linux')
    assert path.home() == r'/home'
    path = Path('darwin')
    assert path.home() == r'/Users'

# Generated at 2022-06-23 21:37:56.299581
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    dev_dir = Path().dev_dir()
    assert dev_dir.startswith('/home'), 'dev_dir() test failed'

# Generated at 2022-06-23 21:38:00.661965
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/julio/Development/Ruby'
    assert Path().dev_dir() == '/home/luciano/Development/PyTorch'


# Generated at 2022-06-23 21:38:02.396360
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform


# Generated at 2022-06-23 21:38:03.704716
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert (path.root() == '/')


# Generated at 2022-06-23 21:38:05.995000
# Unit test for method home of class Path
def test_Path_home():
    path = Path('test platform')

    actual = path.home()
    expected = '/home'

    assert actual == expected

# Generated at 2022-06-23 21:38:08.910331
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('linux')
    for _ in range(10):
        print(p.users_folder())


# Generated at 2022-06-23 21:38:09.896521
# Unit test for method root of class Path
def test_Path_root():
    assert 1


# Generated at 2022-06-23 21:38:11.935297
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    dev_dir = Path().dev_dir()
    print(dev_dir)


# Generated at 2022-06-23 21:38:14.914509
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root is not None
    assert isinstance(root, str)
    assert len(root) != 0


# Generated at 2022-06-23 21:38:17.178320
# Unit test for constructor of class Path
def test_Path():
    from mimesis.enums import Platform

    path = Path(Platform.LINUX)
    test_output = path.project_dir()
    assert isinstance(test_output, str)


# Generated at 2022-06-23 21:38:22.950640
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.providers.datetime import Datetime
    datetime = Datetime(seed=42)
    path_test_instance = Path(platform='linux', seed=42)
    path_test_instance.random.set_state(datetime.seed_state)
    user_path = str(path_test_instance.user())
    assert user_path == '/home/agustin'


# Generated at 2022-06-23 21:38:24.416352
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/chandra'


# Generated at 2022-06-23 21:38:26.606022
# Unit test for method user of class Path
def test_Path_user():
    # Create a Path object
    path = Path()
    print("User Folder: ", path.user())



# Generated at 2022-06-23 21:38:28.811282
# Unit test for method root of class Path
def test_Path_root():
    """
    test for method root of class Path
    """
    x = Path()
    res = x.root()
    assert len(res) > 0



# Generated at 2022-06-23 21:38:32.921540
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    '''
    Method to test the method project_dir of class Path

    :return: True if the test is successful, False otherwise
    '''
    path = Path()
    if path.project_dir() == '/home/sherika/Development/Falcon/mercenary':
        return True
    return False


# Generated at 2022-06-23 21:38:35.759100
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    result = path.root()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:38:37.591026
# Unit test for method root of class Path
def test_Path_root():
    p = Path(platform='win32')
    assert p.root() == '\\'


# Generated at 2022-06-23 21:38:39.048882
# Unit test for method root of class Path
def test_Path_root():
    assert '\\' in Path('win64').root()


# Generated at 2022-06-23 21:38:41.231011
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    t=Path()
    output=t.project_dir()
    assert output=="/home/gef/development/python/capital"

# Generated at 2022-06-23 21:38:44.062808
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    

# Generated at 2022-06-23 21:38:45.918099
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Setup
    p = Path()

    # Exercise
    result = p.dev_dir()

    # Verify
    assert isinstance(result, str)


# Generated at 2022-06-23 21:38:48.608893
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    metpy = Path()
    ans = metpy.dev_dir()
    assert isinstance(ans,str),'Result must be as type str'


# Generated at 2022-06-23 21:38:51.684367
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    _path = Path(platform='win32')
    path = _path.users_folder()
    assert isinstance(path, str)
    assert path.startswith(_path._pathlib_home.parent)

# Generated at 2022-06-23 21:38:57.471246
# Unit test for method root of class Path
def test_Path_root():
    assert isinstance(Path().root(), str)
    assert isinstance(Path(platform='linux').root(), str)
    assert isinstance(Path(platform='darwin').root(), str)
    assert isinstance(Path(platform='win32').root(), str)
    assert isinstance(Path(platform='win64').root(), str)

    # Unit test for method home of class Path

# Generated at 2022-06-23 21:39:00.454561
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("Testing method dev_dir of class Path:")
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:39:01.688362
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('posix')
    print(path.users_folder())

# Generated at 2022-06-23 21:39:05.733540
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    method_Path_project_dir = Path().project_dir()
    expected_Path_project_dir = '/home/sharice/Dev/Python/unemotional'


# Generated at 2022-06-23 21:39:07.759908
# Unit test for method user of class Path
def test_Path_user():
    # print((Path()).user())
    NotImplemented

#  Unit test for method users_folder of class Path

# Generated at 2022-06-23 21:39:09.793305
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path._pathlib_home.parent == PurePosixPath(PLATFORMS['linux']['home'])

# Generated at 2022-06-23 21:39:19.186796
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform='win32')
    assert path.platform in PLATFORMS
    assert path._pathlib_home == PureWindowsPath('C:\\Users')
    assert path.home() == 'C:\\Users'

    path = Path(platform='linux')
    assert path.platform in PLATFORMS
    assert path._pathlib_home == PurePosixPath('/home')
    assert path.home() == '/home'

    path = Path(platform='darwin')
    assert path.platform in PLATFORMS
    assert path._pathlib_home == PurePosixPath('/Users')
    assert path.home() == '/Users'



# Generated at 2022-06-23 21:39:20.380105
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:39:24.620323
# Unit test for method home of class Path
def test_Path_home():
    assert isinstance(Path().home(), str)
    assert isinstance(Path('linux').home(), str)
    assert isinstance(Path('darwin').home(), str)
    assert isinstance(Path('win32').home(), str)
    assert isinstance(Path('win64').home(), str)



# Generated at 2022-06-23 21:39:29.859795
# Unit test for method home of class Path
def test_Path_home():
    assert Path(platform='linux').home() == '/home'
    assert Path(platform='darwin').home() == '/Users'
    assert Path(platform='win32').home() == 'C:\\Users'
    assert Path(platform='win64').home() == 'C:\\Users'


# Generated at 2022-06-23 21:39:31.870828
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('linux','y','z')
    assert path.users_folder()=='/home/z/Pictures'    
    

# Generated at 2022-06-23 21:39:40.871930
# Unit test for constructor of class Path
def test_Path():
    tests = {'win': ['C:\\', 'C:\\Users', 'C:\\Users\\kayleigh', \
            'C:\\Users\\kayleigh\\Pictures', \
            'C:\\Users\\kayleigh\\Development\\Python', \
            'C:\\Users\\kayleigh\\Development\\Python\\mercenary']
            }
    for platform in tests.keys():
        p = Path(platform=platform)
        assert p.root() == tests[platform][0]
        assert p.home() == tests[platform][1]
        assert p.user() == tests[platform][2]
        assert p.users_folder() == tests[platform][3]
        assert p.dev_dir() == tests[platform][4]
        assert p.project_dir() == tests[platform][5]

# Generated at 2022-06-23 21:39:42.799953
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test users_folder method of class Path."""
    path = Path()
    assert path.users_folder()


# Generated at 2022-06-23 21:39:44.467839
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    paths = Path()
    assert paths.project_dir() == '/home/sherika/Development/Flask/mercenary'

# Generated at 2022-06-23 21:39:46.962776
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    result = provider.user()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:39:48.948532
# Unit test for constructor of class Path
def test_Path():
    t = Path()
    assert t.platform in PLATFORMS.keys()
    assert t.platform in {'linux', 'darwin', 'win32', 'win64'}

# Generated at 2022-06-23 21:39:50.674831
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)


# Generated at 2022-06-23 21:39:52.605748
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:39:56.656958
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == "C:\\Users\\admin"
    assert path.home() == "C:\\Users\\admin"
    assert path.home() == "C:\\Users\\admin"


# Generated at 2022-06-23 21:40:02.112401
# Unit test for method user of class Path
def test_Path_user():
    path_provider = Path()
    home_path = path_provider.home()
    # Path to home directory must be end with "/"
    assert home_path[-1] == '/'
    # Assert that generated path is equal with path to home directory +
    # name of user
    user_name = USERNAMES[0]
    user_path = path_provider.user()
    assert user_path == home_path + user_name



# Generated at 2022-06-23 21:40:05.469868
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    mimesis_path = Path()
    assert mimesis_path.project_dir() == '/home/gittel/Development/PHP/tusk'



# Generated at 2022-06-23 21:40:07.159371
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:40:09.648770
# Unit test for method home of class Path
def test_Path_home():
    # GIVEN
    p = Path()
    # WHEN
    result = p.home()
    # THEN
    assert result in FOLDERS