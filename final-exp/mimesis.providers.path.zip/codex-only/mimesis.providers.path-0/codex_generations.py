

# Generated at 2022-06-23 21:30:21.120723
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Initialize Path class
    path = Path()
    # Generate a random path to project directory
    path_project_dir = path.project_dir()
    print(path_project_dir)
#test_Path_project_dir()


# Generated at 2022-06-23 21:30:24.468225
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """
    Unit test for method project_dir of class Path
    """
    path = Path('linux')
    print(path.project_dir())
    # /home/megane/Development/Go/Echo


# Generated at 2022-06-23 21:30:27.228522
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    result = provider.home()
    assert result == '/home'


# Generated at 2022-06-23 21:30:28.776588
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/heide'

# Generated at 2022-06-23 21:30:30.734218
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    l = Path(platform='linux')
    # assert l.users_folder() == "/home/cariaso/Pictures"
    print("users_folder: {}".format(l.users_folder()))


# Generated at 2022-06-23 21:30:34.951372
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""

    tmp_p = Path()

    for _ in range(100):
        print(tmp_p.project_dir())

# Generated at 2022-06-23 21:30:36.793883
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-23 21:30:39.022838
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Gender
    p = Path
    path = p.users_folder()
    print(path)


# Generated at 2022-06-23 21:30:41.197853
# Unit test for method home of class Path
def test_Path_home():
    """Test method home of class Path."""
    path = Path()
    assert path.home() == 'C:\\Users'


# Generated at 2022-06-23 21:30:45.187835
# Unit test for constructor of class Path
def test_Path():
    # pathlib_home = PureWindowsPath()
    # pathlib_home /= PLATFORMS[platform]['home']
    # str(self._pathlib_home)
    pass

# Generated at 2022-06-23 21:30:45.861514
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert bool(path.user())

# Generated at 2022-06-23 21:30:47.921393
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert(path.home() == str(path._pathlib_home))

# Generated at 2022-06-23 21:30:50.095302
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    path = Path()
    assert not path.project_dir()


# Generated at 2022-06-23 21:30:51.266038
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.random.seed(0)
    assert path.home() == '/home'


# Generated at 2022-06-23 21:30:52.519677
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root().__str__() == "/"


# Generated at 2022-06-23 21:30:56.341840
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path_provider = Path('linux')
    project_dir = path_provider.project_dir()
    assert isinstance(project_dir, str)
    assert '/' in project_dir
    assert project_dir.startswith('/home/')
    assert project_dir.endswith('Development/Falcon/mercenary')

# Generated at 2022-06-23 21:30:59.429717
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path = Path()
    result = path.home()
    assert (result != '')
    assert (type(result) == str)
    assert (result != None)


# Generated at 2022-06-23 21:31:01.890879
# Unit test for method root of class Path
def test_Path_root():
    """Test the method root() of class Path.
    """
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:31:07.243796
# Unit test for constructor of class Path
def test_Path():
    import pdb; pdb.set_trace()
    p = Path(platform='linux')
    print("root:", p.root())
    print("home:", p.home())
    print("user:", p.user())
    print("users_folder:", p.users_folder())
    print("dev_dir:", p.dev_dir())
    print("project_dir:", p.project_dir())


# Generated at 2022-06-23 21:31:18.142182
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    pp = Path()
    p = pp.dev_dir()
    assert '/home/sherika/Development/Python' in p
    pp = Path('linux')
    p = pp.dev_dir()
    assert '/home/sherika/Development/Python' in p
    pp = Path('linux')
    p = pp.dev_dir()
    assert '/home/sherika/Development/Python' in p
    pp = Path('darwin')
    p = pp.dev_dir()
    assert '/Users/sherika/Development/Python' in p
    pp = Path('win32')
    p = pp.dev_dir()
    assert 'C:\\Users\\sherika\\Development\\Python' in p
    pp = Path('win64')
    p = pp.dev_dir()

# Generated at 2022-06-23 21:31:21.430593
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    folder = Path().users_folder()
    print('\n')
    print('test_Path_users_folder: ')
    print(folder)


# Generated at 2022-06-23 21:31:28.878095
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    from mimesis.enums import Gender
    p = Path(platform='linux')
    assert p.user() in ['/home/oretha', '/home/sherrell', '/home/taneka', '/home/sherika',
                        '/home/jeanice']
    p = Path(platform='linux', gender=Gender.FEMALE)
    assert p.user() in ['/home/taneka', '/home/sherika', '/home/jeanice']
    p = Path(platform='linux', gender=Gender.MALE)
    assert p.user() in ['/home/oretha', '/home/sherrell', '/home/taneka']
    p = Path(platform='win32')

# Generated at 2022-06-23 21:31:31.628122
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path()
    dev_dir = obj.dev_dir()
    assert dev_dir == "/home/leina/Development/Javascript"

# Generated at 2022-06-23 21:31:36.453277
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test: method project_dir of class Path."""
    pp = Path('win32')
    a = pp.project_dir()
    b = pp.project_dir()
    print('a =', a)
    print('b =', b)
    if a!=b:
        raise Exception


# Generated at 2022-06-23 21:31:37.798853
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())

# Generated at 2022-06-23 21:31:40.428288
# Unit test for constructor of class Path
def test_Path():
    platform = 'linux'
    path = Path(platform)
    assert path.platform == 'linux'


# Generated at 2022-06-23 21:31:51.172005
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from os.path import isdir, join
    from random import seed
    from string import ascii_lowercase

    for platform in PLATFORMS:
        seed(0)
        provider = Path(platform=platform)

        for i in range(100):
            path = provider.dev_dir()
            assert isdir(path)

            if 'win' in platform:
                assert path.split('\\')[-1].isalnum()
            else:
                assert path.split('/')[-1].isalnum()

            assert len(path.split('/')) >= 4

            if 'win' in platform:
                assert path.split('\\')[1] in ascii_lowercase
            else:
                assert path.split('/')[1] in ascii_lowercase



# Generated at 2022-06-23 21:31:52.563214
# Unit test for method users_folder of class Path
def test_Path_users_folder():
        obj = Path(platform='linux')
        print(obj.users_folder())

# Generated at 2022-06-23 21:31:55.422728
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.path import Path
    from mimesis.providers.path import PATH_PROVIDER
    path = Path(platform='win32')
    assert PATH_PROVIDER.dev_dir() == path.dev_dir()

# Generated at 2022-06-23 21:31:58.069179
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)

# Generated at 2022-06-23 21:31:59.178725
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for x in range(0, 100):
        print(Path().project_dir())

# Generated at 2022-06-23 21:32:01.710672
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path = Path()
    result = path.home()
    assert result == '/home'


# Generated at 2022-06-23 21:32:06.632912
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    if sys.platform == "linux" or sys.platform == "linux2":
        assert (path.home() == "/home")
    elif sys.platform == "darwin":
        assert (path.home() == "/Users")
    elif sys.platform == "win32" or sys.platform == "win64":
        assert (path.home() == "C:\\Users")


# Generated at 2022-06-23 21:32:08.331560
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-23 21:32:10.211092
# Unit test for method root of class Path
def test_Path_root():
    result = Path().root()
    assert result == '/'


# Generated at 2022-06-23 21:32:14.673513
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    value1 = "C:\\Users\\pierre\\Documents"
    value2 = "D:\\Users\\pierre\\Documents"
    value3 = "D:\\UserNames\\pierre\\Documents"
    value4 = "D:\\UserNames\\pierre"

    assert (len(value1) == len(value2) == len(value3)  > len(value4))

# Generated at 2022-06-23 21:32:17.288636
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    inst = Path()
    res = inst.dev_dir()
    assert isinstance(res, str)
    assert res == '/home/sal/Development/C'

# Generated at 2022-06-23 21:32:18.506935
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())

# Generated at 2022-06-23 21:32:20.677462
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    i = 0
    while i<=100:
        result = Path().dev_dir()
        print(result)
        i+=1


# Generated at 2022-06-23 21:32:22.087006
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:32:23.406166
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())



# Generated at 2022-06-23 21:32:26.119184
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    dev = path.dev_dir()
    project = path.random.choice(PROJECT_NAMES)
    assert path.project_dir() == str(path._pathlib_home / dev / project)

# Generated at 2022-06-23 21:32:28.270379
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())
    print(path.users_folder())
    print(path.users_folder())


# Generated at 2022-06-23 21:32:31.708674
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()

    result = '/home/' in dev_dir
    expected = True
    assert result == expected


# Generated at 2022-06-23 21:32:34.462792
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.random.seed(1)
    assert p.project_dir() == '/home/okemah/Development/JavaScript/mercenary'


# Generated at 2022-06-23 21:32:36.663575
# Unit test for method root of class Path
def test_Path_root():
    path_obj = Path(platform='linux')
    print(path_obj.root())


# Generated at 2022-06-23 21:32:39.184513
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    result = provider.home()
    print(result)
    assert result
    assert isinstance(result, str)

# Generated at 2022-06-23 21:32:40.099847
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert(path.home())

# Generated at 2022-06-23 21:32:47.654334
# Unit test for method user of class Path
def test_Path_user():
    import random
    from mimesis.enums import Gender
    usernames = ['oretha', 'taneka', 'sherrell', 'sherika']
    home = '/home'

    class TestPath:
        class TestRandom:
            class TestChoice:
                def __init__(self, choice):
                    self.choice = choice

                def __call__(self, items):
                    self.items = items
                    if self.choice in ['oretha', 'taneka', 'sherrell', 'sherika']:
                        return self.choice
                    else:
                        raise ValueError("{} is not in list".format(self.choice))

        def __init__(self, p):
            self.platform = p

        def __getattr__(self, item):
            if item == 'random':
                return self.TestRandom

# Generated at 2022-06-23 21:32:54.336825
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import SpecialFolder
    from mimesis.builtins import Special
    from pathlib import WindowsPath, PosixPath
    s = Special()
    assert isinstance(Path().users_folder(), str)
    for f in FOLDERS:
        assert s.special_folder(SpecialFolder.WINDOWS) / f in Path('win32').users_folder()
    for f in FOLDERS:
        assert PosixPath("/home") / s.username() / f in Path('linux').users_folder()


# Generated at 2022-06-23 21:32:55.663216
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()


# Generated at 2022-06-23 21:32:57.921239
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    path = p.dev_dir()
    print(path)


# Generated at 2022-06-23 21:32:59.421725
# Unit test for method home of class Path
def test_Path_home():
    """Test method."""
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:33:01.353073
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user in USERNAMES


# Generated at 2022-06-23 21:33:03.380396
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    print(result)


# Generated at 2022-06-23 21:33:07.487398
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("\n=== test_Path_dev_dir ===")

    path_object = Path()
    result = path_object.dev_dir()
    print("result = ", result)

    assert (result == "/home/sherika/Development/Python")


# Generated at 2022-06-23 21:33:19.624503
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    result = p.user()

# Generated at 2022-06-23 21:33:20.872340
# Unit test for method user of class Path
def test_Path_user():
    result = Path().user()
    expected = '/home/' + USERNAMES[result.split('/')[2]]
    assert result == expected

# Generated at 2022-06-23 21:33:22.161246
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Init object
    path = Path()
    # Execute method
    result = path.users_folder()

    # Assert
    assert result is not None

# Generated at 2022-06-23 21:33:23.853580
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    meta = Path.Meta
    assert meta.name == 'path'
    path = Path()
    assert type(path.dev_dir()) is str
    assert len(path.dev_dir()) > 0

# Generated at 2022-06-23 21:33:28.912349
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.root() == '/'
    assert p.home() == '/home'
    assert p.home() == '/home'
    assert p.user() == '/home/oretha'
    assert p.users_folder() == '/home/taneka/Pictures'
    assert p.dev_dir() == '/home/sherrell/Development/Python'
    assert p.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:33:39.187080
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    '''
    def users_folder(self) -> str:
        """Generate a random path to user's folders.

        :return: Path.

        :Example:
            /home/taneka/Pictures
        """
        user = self.user()
        folder = self.random.choice(FOLDERS)
        return str(self._pathlib_home / user / folder)
    '''
    import pandas as pd
    from mimesis.enums import Gender
    p = Path(platform = 'darwin')
    df = pd.DataFrame(columns = ['users_folder'])
    for i in range(1000):
        df.loc[i] = [p.users_folder()]
    print(df)


# Generated at 2022-06-23 21:33:42.136433
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.root()
    path.home()
    path.user()
    path.users_folder()
    path.dev_dir()
    path.project_dir()

# Generated at 2022-06-23 21:33:44.042228
# Unit test for method root of class Path
def test_Path_root():
    instance = Path()
    result = instance.root()
    assert isinstance(result, str)
    assert '/' in result


# Generated at 2022-06-23 21:33:52.161468
# Unit test for method dev_dir of class Path

# Generated at 2022-06-23 21:33:54.438529
# Unit test for method user of class Path
def test_Path_user():
    results = [Path().user() for x in range(10)]
    print(results)
    assert(len(results) == 10)

# Generated at 2022-06-23 21:33:55.577428
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert(Path().dev_dir() == 'C:\\Users\\username\\Documents\\Ruby')


# Generated at 2022-06-23 21:33:57.679370
# Unit test for method user of class Path
def test_Path_user():
    paths = Path()
    user = paths.user()
    assert user == "/home/taneka"


# Generated at 2022-06-23 21:34:01.223504
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir()=="/home/elka/Dev/Python"


# Generated at 2022-06-23 21:34:03.286720
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    users_folder = p.users_folder()
    print(users_folder)


# Generated at 2022-06-23 21:34:04.047205
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/richmond'

# Generated at 2022-06-23 21:34:06.301029
# Unit test for constructor of class Path
def test_Path():
    """A class test."""
    import doctest
    doctest.testmod(extraglobs={'path': Path()})

# Generated at 2022-06-23 21:34:09.217659
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test for method users_folder of class Path."""
    path = Path('linux')
    assert path.users_folder() == '/home/michal/Pictures'


# Generated at 2022-06-23 21:34:10.677373
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert type(path.home()) == str


# Generated at 2022-06-23 21:34:12.392115
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    assert home == '/home'



# Generated at 2022-06-23 21:34:15.611284
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert isinstance(path.home(), str)
    assert isinstance(path.root(), str)
    assert isinstance(path.project_dir(), str)
    assert isinstance(path.users_folder(), str)

# Generated at 2022-06-23 21:34:16.945328
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.Meta.name

# Generated at 2022-06-23 21:34:19.470884
# Unit test for method home of class Path
def test_Path_home():
    pth = Path()
    path = pth.home()
    assert isinstance(path, str)
    assert path == '/home'


# Generated at 2022-06-23 21:34:20.398988
# Unit test for method home of class Path
def test_Path_home():
    assert Path.home() == '/home'

# Generated at 2022-06-23 21:34:21.629148
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    assert result == '/home'


# Generated at 2022-06-23 21:34:23.414593
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home' or Path().home() == r'C:\Users' or Path().home() == 'C:/Users'


# Generated at 2022-06-23 21:34:24.859470
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    provider = Path()
    project_dir = provider.project_dir()
    assert project_dir != ""

# Generated at 2022-06-23 21:34:27.850459
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    provider = Path()
    assert provider.root() == '\\'


# Generated at 2022-06-23 21:34:30.383595
# Unit test for method root of class Path
def test_Path_root():
    """Test Path.root()."""
    path = Path()
    assert path.root() == '/'

#Unit test for method home of class Path

# Generated at 2022-06-23 21:34:38.611351
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import unittest
    # Bootstrap the class
    path = Path()

    # Creating a class
    class PathPathlibTestCase(unittest.TestCase):
        """Testing it."""

        def test_users_folder(self):
            """Testing users_folder method of class Path."""
            self.assertIsInstance(path.users_folder(), str)
            self.assertIn('/home/', path.users_folder())
            self.assertIn(
                path.random.choice(FOLDERS),
                path.users_folder(),
            )

    # Run the test
    unittest.main()

# Generated at 2022-06-23 21:34:41.361576
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/home'


# Generated at 2022-06-23 21:34:45.606594
# Unit test for method root of class Path
def test_Path_root():
    """Test the method 'root' of class 'Path'.

    Test data: {'/home/sherika/Documents/Development/Python/Mimesis/tests'}
    Returned data: {'/'}
    """

    p = Path(platform = 'linux')
    assert p.root() == '/'


# Generated at 2022-06-23 21:34:47.939324
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    # print(dev_dir)
    return dev_dir


# Generated at 2022-06-23 21:34:51.803944
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test project_dir method of class Path"""
    print('\n' + '#' * 3 + ' Unit test for method project_dir of class Path ' + '#' * 3)
    print('\n Unit test for method project_dir of class Path {}'.format('.'*60))
    print(Path().project_dir())

test_Path_project_dir()


# Generated at 2022-06-23 21:34:52.945301
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    pass
    

# Generated at 2022-06-23 21:34:54.679203
# Unit test for method user of class Path
def test_Path_user():
    actual = Path().user()
    assert isinstance(actual, str)

# Generated at 2022-06-23 21:34:55.965588
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    p = Path(platform='linux')
    p.seed(0)
    assert p.root() == '/'

# Generated at 2022-06-23 21:34:58.607570
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    obj = Path()
    print(obj.project_dir())
    #return obj.project_dir()
test_Path_project_dir()


# Generated at 2022-06-23 21:35:01.825109
# Unit test for method user of class Path
def test_Path_user():
    # TODO: Finish this test
    path = Path('win32')
    print(path.user())


if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-23 21:35:03.579461
# Unit test for method home of class Path
def test_Path_home():
    path_home = Path().home()
    assert type(path_home) == str
    assert not path_home == ""

# Generated at 2022-06-23 21:35:06.253418
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path(platform='darwin')
    current_path = p.project_dir()
    expected = '/home/charles/Development/Python/Astral'

    assert current_path == expected

# Generated at 2022-06-23 21:35:09.464368
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

if __name__ == '__main__':
    test_Path_users_folder()

# Generated at 2022-06-23 21:35:13.638859
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()

# Generated at 2022-06-23 21:35:15.758733
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print("\nPath.project_dir: ", path.project_dir())


# Generated at 2022-06-23 21:35:17.351280
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    assert path.user() != ''


# Generated at 2022-06-23 21:35:21.161963
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj_Path = Path()
    str_tmp = obj_Path.dev_dir()
    type_str_tmp = type(str_tmp)
    assert type_str_tmp == str

# Generated at 2022-06-23 21:35:24.206979
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:35:25.674146
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:35:30.147798
# Unit test for constructor of class Path
def test_Path():
    """This is a unit test of the class Path"""
    obj = Path()
    # Call methods that return path string to get the desired result
    pathstr = obj.project_dir()
    print(pathstr)

if __name__ == "__main__":
    # This is the main function which will invoke unit test 
    test_Path()

# Generated at 2022-06-23 21:35:30.849703
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:35:31.915073
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.providers.path import Path
    path = Path()
    assert (path.users_folder())


# Generated at 2022-06-23 21:35:33.124472
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert len(p.users_folder()) == 53

# Generated at 2022-06-23 21:35:34.608047
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path().dev_dir()
    assert len(path.split('/')) == 5


# Generated at 2022-06-23 21:35:35.326266
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
	from mimesis.enums import Gender
	print(Path().dev_dir())


# Generated at 2022-06-23 21:35:37.250711
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    p = path.user()
    print(p)
    assert p is not None


# Generated at 2022-06-23 21:35:38.458857
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    #print(result)

# Generated at 2022-06-23 21:35:43.602472
# Unit test for method root of class Path
def test_Path_root():
    # 1st test
    result = Path().root()
    assert(result == '/')
    
    # 2nd test
    result = Path('linux').root()
    assert(result == '/')

    # 3rd test
    result = Path('win32').root()
    assert(result == '/')

    # 4th test
    result = Path('win64').root()
    assert(result == '/')

    # 5th test
    result = Path('darwin').root()
    assert(result == '/')


# Generated at 2022-06-23 21:35:46.347432
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    k = Path('linux')
    assert k.root() == '/'


# Generated at 2022-06-23 21:35:49.491060
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    path = Path()
    path.random.seed(10)
    assert path.root() == '/'



# Generated at 2022-06-23 21:35:56.613600
# Unit test for method user of class Path
def test_Path_user():
    """
    Test for Path.user
    """
    from mimesis.enums import OperatingSystem
    platform = {
            'Linux': 'linux',
            'macOS': 'darwin',
            'Windows': 'win32',
            }[str(OperatingSystem.LINUX)]
    path = Path(platform)
    result = path.user()
    assert type(result) == str


# Generated at 2022-06-23 21:36:04.611390
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path._pathlib_home == PureWindowsPath('C:/Users')
    assert path.platform == 'win32'

    path = Path('linux')
    assert path._pathlib_home == PurePosixPath('/home')
    assert path.platform == 'linux'

    path = Path('darwin')
    assert path._pathlib_home == PurePosixPath('/Users')
    assert path.platform == 'darwin'

    path = Path('win32')
    assert path._pathlib_home == PureWindowsPath('C:/Users')
    assert path.platform == 'win32'

    path = Path('win64')
    assert path._pathlib_home == PureWindowsPath('C:/Users')
    assert path.platform == 'win64'

# Generated at 2022-06-23 21:36:07.397451
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == '/home/taneka/Development/python/nimble'

# Generated at 2022-06-23 21:36:13.640742
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import OperatingSystem
    from mimesis.builtins import StandardLibrary
    from mimesis.data import FOLDERS

    path_generator = Path(OperatingSystem.LINUX)
    assert path_generator.user() == '/home/' + StandardLibrary.choice(USERNAMES).lower()

    path_generator = Path(OperatingSystem.WINDOWS)
    assert path_generator.user() == r'C:\Users\\' + StandardLibrary.choice(FOLDERS).capitalize()


# Generated at 2022-06-23 21:36:15.594047
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == "/home/orena/Development/Rust/symbiont"

# Generated at 2022-06-23 21:36:17.044820
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:36:19.029914
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert 'home' in path.project_dir()
    assert 'Development' in path.project_dir()

# Generated at 2022-06-23 21:36:21.285320
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path."""
    p = Path()
    assert isinstance(p.users_folder(), str)


# Generated at 2022-06-23 21:36:27.407402
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Test 1
    path_1 = Path()
    test_1 = path_1.project_dir()
    print(test_1)

    # Test 2
    path_2 = Path(platform='win32')
    test_2 = path_2.project_dir()
    print(test_2)

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:36:31.994327
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.random.choice(PROJECT_NAMES) in p.project_dir()
    assert p.random.choice(FOLDERS) in p.users_folder()
    assert p.random.choice(PROGRAMMING_LANGS) in p.dev_dir()
    assert p.random.choice(USERNAMES) in p.user()

# Generated at 2022-06-23 21:36:34.012027
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:36:35.640795
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())
# Вывод: /home/lala/Music


# Generated at 2022-06-23 21:36:37.273310
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    x = p.project_dir()
    assert(type(x) == str)

# Generated at 2022-06-23 21:36:41.468307
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == '/home/mel/Development/C/lox'
    assert path.project_dir() == '/home/jovan/Development/Lua/fork'
    assert path.project_dir() == '/home/elaine/Development/JavaScript/tremor'

# Generated at 2022-06-23 21:36:42.520936
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())

# Generated at 2022-06-23 21:36:48.720046
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Test :
    path = Path()
    dev_dir = path.dev_dir()
    project = path.random.choice(PROJECT_NAMES)
    path_project = str(path._pathlib_home / dev_dir / project)

    path_projet_test = path.project_dir()

    assert path_projet_test == path_project

# Generated at 2022-06-23 21:36:50.519251
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path

    :return:
    """
    p = Path()
    p.root()


# Generated at 2022-06-23 21:36:52.060375
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    assert Path().user() == '/home/taneka'

# Generated at 2022-06-23 21:36:54.140804
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'
    assert Path('win32').root() == 'C:\\'
    assert Path('win64').root() == 'C:\\'


# Generated at 2022-06-23 21:36:54.916947
# Unit test for method root of class Path
def test_Path_root():
	pass


# Generated at 2022-06-23 21:36:56.253008
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.home()
    return path

# Generated at 2022-06-23 21:36:59.845513
# Unit test for method home of class Path
def test_Path_home():

    path_instance = Path()
    path = path_instance.home()

    # assert type(path) == str
    assert path.__class__ == str
    # assert 'home' in path
    assert 'home' in path


# Generated at 2022-06-23 21:37:03.306395
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    my_path = Path()
    assert my_path.dev_dir() != ''
    assert my_path.dev_dir() is not None
    assert my_path.dev_dir() is str


# Generated at 2022-06-23 21:37:05.848289
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for Path.root()."""
    seed(0)

    for _ in range(100):
        assert Path().root() == '/'


# Generated at 2022-06-23 21:37:10.843573
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test case for Path().users_folder()."""
    p = Path()
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())
    print(p.users_folder())


# Generated at 2022-06-23 21:37:17.969296
# Unit test for constructor of class Path
def test_Path():
    """Tests for the constructor of class Path"""
    path = Path()
    assert isinstance(path._pathlib_home, PurePosixPath) is True
    path = Path(platform='win32')
    assert isinstance(path._pathlib_home, PureWindowsPath) is True
    path = Path(platform='win64')
    assert isinstance(path._pathlib_home, PureWindowsPath) is True


# Generated at 2022-06-23 21:37:21.733638
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    from mimesis.builtins import FieldNameProvider
    a = Path()
    p = Path(Platform.WINDOWS)
    assert a.root() == '/'
    assert p.root() == 'C:\\'


# Generated at 2022-06-23 21:37:23.204924
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'

# Generated at 2022-06-23 21:37:25.664728
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(10):
        print(Path.project_dir())


# Generated at 2022-06-23 21:37:29.085123
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print("###### This is a test for Path.users_folder() #######")
    domain = Path()
    for i in range(100):
        print(domain.users_folder())


# Generated at 2022-06-23 21:37:31.677172
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    users = set()
    for i in range(1000):
        users.add(p.user())
    assert len(users) == 1000

# Generated at 2022-06-23 21:37:32.836076
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/' 


# Generated at 2022-06-23 21:37:37.398066
# Unit test for method root of class Path
def test_Path_root():
    # Test function with default parameters
    assert Path().root() == '/', 'Unit test failed'
    # Test function with parameter platform = 'linux'
    assert Path('linux').root() == '/', 'Unit test failed'
    # Test function with parameter platform = 'win32'
    assert Path('win32').root() == 'C:\\', 'Unit test failed'
    # Test function with parameter platform != 'linux', != 'win32'
    assert Path('win64').root() == 'C:\\', 'Unit test failed'


# Generated at 2022-06-23 21:37:39.275536
# Unit test for method home of class Path
def test_Path_home():
    """Function for testing home."""
    p = Path()
    assert len(p.home()) > 0



# Generated at 2022-06-23 21:37:40.625713
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:37:45.751072
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path._pathlib_home, PureWindowsPath) or isinstance(path._pathlib_home, PurePosixPath)
    assert str(path._pathlib_home) == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-23 21:37:47.105672
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())


# Generated at 2022-06-23 21:37:48.551549
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = PLATFORMS[sys.platform]['home']
    assert p.home() == home

# Generated at 2022-06-23 21:37:52.048314
# Unit test for method root of class Path
def test_Path_root():
    seed = 0
    path = Path(platform="win32", seed=seed)
    path = path.root()
    assert path == "C:\\"


# Generated at 2022-06-23 21:37:53.519409
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert isinstance(Path().project_dir(), str)


# Generated at 2022-06-23 21:37:55.664169
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert 'home/' in path.user()

# TODO: test for method users_folder of class Path

# Generated at 2022-06-23 21:38:00.984481
# Unit test for method user of class Path
def test_Path_user():
    class TestPath:
        def setup(self):
            self.path = Path()

        def test_user(self):
            assert self.path.user() not in ['', None]
    
    test = TestPath()
    test.setup()
    test.test_user()

# Generated at 2022-06-23 21:38:03.134361
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/miquel/Development/Python/applicative'


# Generated at 2022-06-23 21:38:05.212082
# Unit test for method users_folder of class Path
def test_Path_users_folder():
  path = Path()
  print(path.users_folder())

# Generated at 2022-06-23 21:38:11.049261
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    random = path.random
    random.choice = lambda seq: seq[0]

    USERNAMES = ['oretha', 'taneka', 'sherrell', 'sherika']
    path._pathlib_home = PurePosixPath('/home')

    assert path.user() == '/home/oretha'

    path._pathlib_home = PureWindowsPath('C:\\Users\\')
    USERNAMES = ['OrethA', 'TanekA', 'SherrelL', 'SherikA']

    assert path.user() == 'C:\\Users\\OrethA'


# Generated at 2022-06-23 21:38:13.679756
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(10):
        print(path.users_folder())

if __name__ == '__main__':
    test_Path_users_folder()

# Generated at 2022-06-23 21:38:15.852694
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    print(dev_dir)

# Generated at 2022-06-23 21:38:18.770794
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    path = Path()
    root = path.root()
    assert type(root) is str
    assert len(root) > 0


# Generated at 2022-06-23 21:38:20.250426
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    #print(path.project_dir())


# Generated at 2022-06-23 21:38:23.188978
# Unit test for method home of class Path
def test_Path_home():
    """Test for method home of class Path."""
    from os import path
    expected = path.join(path.expanduser('~'), '')
    path = Path()
    assert path.home() == expected



# Generated at 2022-06-23 21:38:24.490095
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    assert result

# Generated at 2022-06-23 21:38:26.219738
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-23 21:38:28.769467
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test for method project_dir of class Path."""
    p = Path()
    a = p.project_dir()
    assert isinstance(a, str)
    print(a)



# Generated at 2022-06-23 21:38:30.191579
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # ensure that it return a string
    assert isinstance(Path().project_dir(), str)


# Generated at 2022-06-23 21:38:33.121882
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()
    # print(p.project_dir())
    # print(p.users_folder())

# Test for method home of class Path

# Generated at 2022-06-23 21:38:41.185221
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    # Test root()
    assert path.root() == '/'
    # Test home()
    assert path.home() == '/home'
    # Test user()
    assert path.user() == '/home/oretha'
    # Test users_folder()
    assert path.users_folder() == '/home/taneka/Pictures'
    # Test dev_dir()
    assert path.dev_dir() == '/home/sherrell/Development/Python'
    # Test project_dir()
    assert path.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:38:43.711355
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    path = Path()
    assert path.project_dir() == "/home/dovie/Development/Go/journey"

# Generated at 2022-06-23 21:38:44.850484
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert isinstance(p.home(), str)


# Generated at 2022-06-23 21:38:46.352629
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert '/' == path.root()


# Generated at 2022-06-23 21:38:53.579188
# Unit test for constructor of class Path
def test_Path():
    # unit test for Path
    p = Path().project_dir()
    print(p)
    # unit test for Path
    p = Path().dev_dir()
    print(p)
    # unit test for Path
    p = Path().users_folder()
    print(p)
    # unit test for Path
    p = Path().user()
    print(p)
    # unit test for Path
    p = Path().home()
    print(p)
    # unit test for Path
    p = Path().root()
    print(p)

test_Path()

# Generated at 2022-06-23 21:38:55.698916
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    print(result)
    assert result
assert len(result) == 25


# Generated at 2022-06-23 21:38:57.073662
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/Development/React/Sorella'

# Generated at 2022-06-23 21:38:59.713269
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user.startswith("/Users")
    assert user.endswith("_user")

# Unit tests for method users_folder of class Path

# Generated at 2022-06-23 21:39:00.947481
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'



# Generated at 2022-06-23 21:39:02.394233
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test Path.users_folder()."""
    assert Path().users_folder()


# Generated at 2022-06-23 21:39:06.188743
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for i in range(3):
        print(path.project_dir())

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:39:07.548278
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:39:09.614129
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == '/home/mabelle/Dev/nodejs/mabelle'

# Generated at 2022-06-23 21:39:11.887886
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert 'home' in path.project_dir()
    assert 'Development' in path.project_dir()


# Generated at 2022-06-23 21:39:14.066135
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:39:15.670769
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:39:16.664345
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path


# Generated at 2022-06-23 21:39:19.022472
# Unit test for constructor of class Path
def test_Path():
    """
    """
    random_platform = random.choice(list(platfor_data.keys()))
    assert Path(random_platform).platform == random_platform



# Generated at 2022-06-23 21:39:19.879624
# Unit test for method user of class Path
def test_Path_user():
    return Path().user()


# Generated at 2022-06-23 21:39:24.463335
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Setup
    path = Path()
    # Exercise
    path_to_folder = path.dev_dir()
    # Verify
    assert isinstance(path_to_folder, str) is True, \
        f"expected {path_to_folder} to be of type {str}, but got {type(path_to_folder)}"


# Generated at 2022-06-23 21:39:30.793099
# Unit test for method user of class Path
def test_Path_user():
    user_path = Path().user()
    assert type(user_path) == str
    assert PLATFORMS['linux']['home'] in user_path
    assert PLATFORMS['darwin']['home'] in user_path
    assert PLATFORMS['win32']['home'] in user_path
    assert PLATFORMS['win64']['home'] in user_path


# Generated at 2022-06-23 21:39:40.166934
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p1 = Path()
    p2 = Path()
    p3 = Path()
    p4 = Path()
    p5 = Path()
    p6 = Path()
    p7 = Path()
    p8 = Path()
    p9 = Path()
    p10 = Path()
    p11 = Path()
    p12 = Path()
    for i in range(100):
        print(p1.users_folder())
        print(p2.users_folder())
        print(p3.users_folder())
        print(p4.users_folder())
        print(p5.users_folder())
        print(p6.users_folder())
        print(p7.users_folder())
        print(p8.users_folder())
        print(p9.users_folder())

# Generated at 2022-06-23 21:39:41.208482
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() is not None


# Generated at 2022-06-23 21:39:45.364378
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path._pathlib_home.parts[-1] == 'home'

    path = Path(platform='win32')
    assert isinstance(path._pathlib_home, PureWindowsPath)
    assert path._pathlib_home.parts[-1] == 'Users'


# Generated at 2022-06-23 21:39:46.776133
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform = 'win32')
    print("type of p = ", type(p))

test_Path()

# Generated at 2022-06-23 21:39:48.419137
# Unit test for method home of class Path
def test_Path_home():
    obj = Path()
    assert type(obj.home()) == str
    assert len(obj.home()) > 0


# Generated at 2022-06-23 21:39:50.438133
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for i in range(10):
        print(Path().users_folder())


# Generated at 2022-06-23 21:39:54.859746
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Execute the method
    result = Path(platform='linux').dev_dir()
    # Assert the result
    assert result == '/home/oretha/Development/Ruby'



# Generated at 2022-06-23 21:39:55.823426
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print (Path().project_dir())

# Generated at 2022-06-23 21:39:58.361550
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import random
    random.seed(23847)
    path = Path(platform='linux')
    assert path.dev_dir() == '/home/vivienne/Dev/React'

# Generated at 2022-06-23 21:40:05.949399
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""
    from mimesis.data import PLATFORMS
    from mimesis.enums import SupportOS
    from mimesis.providers.base import BaseProvider
    expected_methods = ['__init__', 'Meta', 'root', 'home', 'user', 'users_folder', 'dev_dir', 'project_dir']
    expected_attrs = ['platform', '_pathlib_home', 'random']
    p = Path()
    assert p.random is not None
    assert hasattr(p, "platform") and isinstance(p.platform, str) and p.platform in PLATFORMS
    assert hasattr(p, "_pathlib_home") and isinstance(p._pathlib_home, type(PureWindowsPath() if 'win' in p.platform else PurePosixPath()))

# Generated at 2022-06-23 21:40:09.543831
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import Platform
    p = Path(platform=Platform.LINUX)
    r1 = p.home()
    assert r1 == '/home', 'Test for method home of class Path fail'

# Generated at 2022-06-23 21:40:12.708879
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    user_path = Path(platform = 'linux').users_folder()
    #As there is no way to know in advance what the function will return, it is not possible to test it
    assert True == True

# Generated at 2022-06-23 21:40:15.877897
# Unit test for method user of class Path
def test_Path_user():
    test = Path()
    user = test.user()
    assert isinstance(user, str)
    assert user.startswith('/')
    assert 'win32' in user
    assert 'win64' in user


# Generated at 2022-06-23 21:40:17.398247
# Unit test for method root of class Path
def test_Path_root():
    Path = Path()
    root = Path.root()
    print(root)
