

# Generated at 2022-06-23 21:30:20.650793
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    myPath = Path()
    dirPath = myPath._pathlib_home / 'home/sherrell/Development/Python'
    assert str(dirPath) == myPath.dev_dir()


# Generated at 2022-06-23 21:30:22.272009
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:30:23.533442
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert len(path.dev_dir()) > 0

# Generated at 2022-06-23 21:30:26.258539
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert len(p.user()) > 0


# Generated at 2022-06-23 21:30:28.253260
# Unit test for method home of class Path
def test_Path_home():
    path = Path('linux')
    assert str(path.home()) == '/home'



# Generated at 2022-06-23 21:30:30.272170
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert type(home) is str


# Generated at 2022-06-23 21:30:33.766236
# Unit test for method home of class Path
def test_Path_home():
    from pathlib import PurePosixPath, PureWindowsPath

    p = PurePosixPath()

    if p.name:
        print("true")
    else:
        print("false")

# Generated at 2022-06-23 21:30:35.709458
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:30:37.927939
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    b = a.users_folder()
    print("Successfully execute method users_folder")
    print(b)


# Generated at 2022-06-23 21:30:40.902595
# Unit test for method home of class Path
def test_Path_home():     
    # Test if method home of class Path returns a path to home folder
    path = Path()
    assert 'home' in path.home()

# Generated at 2022-06-23 21:30:43.965550
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == r'C:\Users\Taneka\Documents\Development\Node.js'


# Generated at 2022-06-23 21:30:48.302586
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'
    print('Method name: {name}'.format(name=path.root.__name__))
    print('Output: {out}'.format(out=path.root()))


# Generated at 2022-06-23 21:30:51.468157
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import os

    p = Path()
    for i in range(10):
        print('The following path is generated from method dev_dir of class Path: ' + p.dev_dir())
        os.system('dir ' + str(p.dev_dir()))

# Generated at 2022-06-23 21:30:52.853108
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    t = Path()
    print(t.users_folder())

# Generated at 2022-06-23 21:30:56.003077
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path(platform='linux', seed=42)
    users_folder_list = []
    for i in range(500):
        users_folder_list.append(p.users_folder())
    assert len(set(users_folder_list)) == len(users_folder_list)

# Generated at 2022-06-23 21:30:57.165723
# Unit test for method user of class Path
def test_Path_user():
    p = Path();
    print(p.user())

# Generated at 2022-06-23 21:31:01.609771
# Unit test for constructor of class Path
def test_Path():
    # pylint: disable=line-too-long
    assert str(Path()) == '/'
    assert str(Path('win32')) == 'C:\\'
    assert str(Path('win32', seed=5)) == 'C:\\'
    assert Path().platform == sys.platform


# Generated at 2022-06-23 21:31:04.469068
# Unit test for method root of class Path
def test_Path_root():
    """Test Path.root() method.

    :return: True if test passed, else False.
    """
    obj = Path()
    assert obj.root() == '/'
    return True


# Generated at 2022-06-23 21:31:09.166576
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    path1 = Path(platform='darwin')
    path2 = Path(platform='win32')
    path3 = Path(platform='win64')
    user1 = path.user()
    user2 = path1.user()
    user3 = path2.user()
    user4 = path3.user()
    assert user1 != user2 and user2 != user3 and user3 != user4

# Generated at 2022-06-23 21:31:14.987721
# Unit test for method home of class Path
def test_Path_home():
    """Test for home of class Path"""
    path = Path()
    home = path.home()
    if path.platform == 'linux2':
        assert home == '/home'
    elif path.platform == 'darwin':
        assert home == '/Users'
    elif path.platform == 'win32' or path.platform == 'win64':
        assert home == 'C:\\Users'

# Generated at 2022-06-23 21:31:26.781022
# Unit test for method home of class Path
def test_Path_home():
    from random import randint
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Iso3166SubdivisionType
    from mimesis.builtins import Address
    from mimesis.builtins import Person
    from mimesis.builtins import Text
    from mimesis.builtins import Address
    from mimesis.builtins import Datetime
    from app import Person_app
    from app import Address_app
    from app import Text_app
    from app import Path_app
    from app import Datetime_app

    a = Path(platform='darwin')
    print(a.root())
    print(a.home())
    print(a.user())
    print(a.users_folder())
    print(a.dev_dir())

# Generated at 2022-06-23 21:31:35.347916
# Unit test for constructor of class Path
def test_Path():
    from mimesis.enums import Platform
    assert Path(platform=Platform.LINUX).platform == 'linux'
    assert Path(platform=Platform.MACOS).platform == 'darwin'
    assert Path(platform=Platform.WINDOWS).platform == 'win32'
    assert Path(platform=Platform.WINDOWS_64).platform == 'win64'
    assert '\\' in Path(platform=Platform.WINDOWS)._pathlib_home
    assert '/' in Path(platform=Platform.LINUX)._pathlib_home


# Generated at 2022-06-23 21:31:38.691155
# Unit test for method home of class Path
def test_Path_home():
    expected_result = str(PureWindowsPath().joinpath('home'))
    path = Path(platform='win32')
    assert path.home() == expected_result


# Generated at 2022-06-23 21:31:41.339864
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

if __name__ == '__main__':
    test_Path_dev_dir()

# Generated at 2022-06-23 21:31:44.146018
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert str(p.root()) == "/"


# Generated at 2022-06-23 21:31:46.297045
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    output = Path().dev_dir()
    print('[test_Path_dev_dir] output = ' + output)
    assert len(output) > 0

# Generated at 2022-06-23 21:31:47.863533
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'



# Generated at 2022-06-23 21:31:49.570117
# Unit test for method root of class Path
def test_Path_root():
    _test = Path()
    print(_test.root())



# Generated at 2022-06-23 21:31:52.610999
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home_test = p.home()
    assert home_test != ''
    assert home_test.split('/')[-1] == 'home'


# Generated at 2022-06-23 21:31:53.576943
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:32:01.121758
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path.dev_dir(Path('win32')) == r'C:\Users\user\Development\Rust'
    assert Path.dev_dir(Path('linux')) == '/home/user/Development/Java'
    assert Path.dev_dir(Path('darwin')) == '/Users/user/Development/C'
    assert Path.dev_dir(Path('win64')) == r'C:\Users\user\Development\Cobol'


# Generated at 2022-06-23 21:32:02.927402
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    for i in range(10):
        print(p.project_dir())

# Generated at 2022-06-23 21:32:05.658008
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    project_dir = 'C:\\Users\\Shane\\Development\\Tornado\\revival'
    path = Path(platform='win32')
    assert path.project_dir() == project_dir

# Generated at 2022-06-23 21:32:07.305447
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    # assert path.users_folder() == expected 
    pass


# Generated at 2022-06-23 21:32:10.308940
# Unit test for method users_folder of class Path
def test_Path_users_folder():
	users_folder = Path().users_folder()
	assert type(users_folder) is str
	assert len(users_folder) > 0


# Generated at 2022-06-23 21:32:12.831596
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    value = path.project_dir()
    print(f"value = {value}")
    assert "_" in value


# Generated at 2022-06-23 21:32:15.254846
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    a.users_folder()


# Generated at 2022-06-23 21:32:18.413344
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    path = Path()
    assert(path.platform == sys.platform)
    assert(isinstance(path._pathlib_home, PurePosixPath))


# Generated at 2022-06-23 21:32:21.810396
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    # Testing if the method generate only linux path
    for i in range(len(PLATFORMS)):
        print(path.users_folder())
    print(PLATFORMS)


# Generated at 2022-06-23 21:32:30.011384
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    my_Path = Path()
    my_Path.random.seed(0)
    list_of_dev_dirs = []
    for i in range(10):
        dev_dir = my_Path.dev_dir()
        list_of_dev_dirs.append(dev_dir)

# Generated at 2022-06-23 21:32:31.201275
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() != None


# Generated at 2022-06-23 21:32:34.023359
# Unit test for method home of class Path
def test_Path_home():
    """Test the method home of class Path."""
    p = Path()
    assert 'win' in p.platform
    assert p.home() == 'C:\\Users'


# Generated at 2022-06-23 21:32:45.565938
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import Language
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import GenericSpecProvider
    from mimesis.builtins.system import System
    obj = Path()
    obj.random.seed(1)
    ru = RussiaSpecProvider()
    ru.seed(1)
    en = USASpecProvider()
    en.seed(1)
    ge = GenericSpecProvider()
    ge.seed(1)
    sys = System()
    sys.seed(1)

# Generated at 2022-06-23 21:32:49.830450
# Unit test for method home of class Path
def test_Path_home():
    path_gen = Path()
    platform = sys.platform
    assert len(path_gen.home()) > 1
    assert path_gen.home().startswith(path_gen._pathlib_home.parent)


# Generated at 2022-06-23 21:32:53.407863
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    '''
    Test method project_dir of class Path
    Output:
    /home/ilyana/Development/Javascript/three
    '''
    mimesis_path = Path(platform='linux')
    print(mimesis_path.project_dir())



# Generated at 2022-06-23 21:32:55.210302
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

test_Path_dev_dir()

# Generated at 2022-06-23 21:32:56.576266
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:32:58.397822
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """."""
    path = Path()
    a = path.users_folder()
    return path.users_folder()

# Generated at 2022-06-23 21:33:02.144284
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path"""
    from mimesis.enums import OS
    path = Path(OS.CYGWIN)
    assert path.dev_dir() == '/home/elodie/Dev/C++'

# Generated at 2022-06-23 21:33:03.334304
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.root()

# Generated at 2022-06-23 21:33:07.560164
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    list_dir = p.users_folder().split('/')
    assert len(list_dir) == 3
    assert list_dir[0] == ''
    assert list_dir[1] == 'home'
    assert list_dir[2] in FOLDERS
    assert list_dir[2] == p.random.choice(FOLDERS)

# Generated at 2022-06-23 21:33:09.513804
# Unit test for constructor of class Path
def test_Path():
    path = Path(*args, **kwargs)
    assert path != None

# Generated at 2022-06-23 21:33:11.474868
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user_path = p.user()
    assert isinstance(user_path, str)

# Generated at 2022-06-23 21:33:14.409246
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir()."""
    path = Path()
    dev_dir = path.dev_dir()
    assert isinstance(dev_dir, str)

# Generated at 2022-06-23 21:33:16.765685
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    c = Path()
    print(c.users_folder())

if __name__ == '__main__':
    test_Path_users_folder()

# Generated at 2022-06-23 21:33:22.447377
# Unit test for method root of class Path
def test_Path_root():
    print("\nUnit test for method root of class Path")
    p = Path()
    p.seed(1)
    print("\nTest case #1: ", p.root())
    p.seed(2)
    print("Test case #2: ", p.root())
    p.seed(3)
    print("Test case #3: ", p.root())
    # Unit test for method home of class Path


# Generated at 2022-06-23 21:33:24.567978
# Unit test for method user of class Path
def test_Path_user():
    obj = Path('win32')
    assert obj.user() == 'C:\\Users\\Terese'


# Generated at 2022-06-23 21:33:29.539533
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    path = p.project_dir()
    print(path)

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:33:36.489675
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from datetime import datetime
    from mimesis.enums import TimeZone

    seed = datetime.now()
    timezone = TimeZone.US_PACIFIC
    Path_seed = Path(seed=seed, timezone=timezone)
    Path_seed.dev_dir()
# dev_dir() == 'C:\\Users\\kenneth\\Development\\Python'

    Path_platform = Path(platform='win64')
    Path_platform.dev_dir()
# dev_dir() == 'C:\\Users\\nathalie\\Dev\\Ruby'


# Generated at 2022-06-23 21:33:38.825837
# Unit test for method home of class Path
def test_Path_home():
    path = Path('linux')
    res = path.home()
    assert res == '/home'


# Generated at 2022-06-23 21:33:40.608422
# Unit test for method user of class Path
def test_Path_user():
    # unit test
    # Generate  a random number of users:
    path = Path()
    path.user()

# Generated at 2022-06-23 21:33:42.053089
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"



# Generated at 2022-06-23 21:33:43.323271
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert type(p.user()) == str

# Generated at 2022-06-23 21:33:46.888509
# Unit test for method users_folder of class Path
def test_Path_users_folder():
  # create an instance of class Path
  path = Path('linux')
  print('\n### test_Path_users_folder() ###')
  print(path.users_folder())


# Generated at 2022-06-23 21:33:48.468306
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ('/home/oretha', '/Users/oretha')

# Generated at 2022-06-23 21:33:50.188405
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:33:52.220912
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # obj = Path()
    # result = obj.users_folder()
    # assert result.startswith(str(obj._pathlib_home.parent) + '/')
    pass


# Generated at 2022-06-23 21:33:55.806247
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    users_folder_result = Path().users_folder()
    users_folder_expect = "/home/tai/Pictures"
    assert(users_folder_result == users_folder_expect)

# Generated at 2022-06-23 21:33:58.265769
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == '/home/royce/Development/C#/.NET/iBold'

# Generated at 2022-06-23 21:34:00.317297
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:34:03.227197
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    test_instance = Path()
    for i in range(10):
        assert str(test_instance.users_folder()) == test_instance.users_folder()

# Generated at 2022-06-23 21:34:05.400729
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == str(PureWindowsPath() / 'C:\\Users' if 'win32' in
                              str(sys.platform) else '\\home')


# Generated at 2022-06-23 21:34:06.444468
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:34:07.747788
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()

# Generated at 2022-06-23 21:34:10.077490
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    gen = Path()
    result = gen.root()
    assert result == "/"


# Generated at 2022-06-23 21:34:11.201534
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == '/home/oretha/Pictures'


# Generated at 2022-06-23 21:34:12.889153
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    path = Path()
    assert isinstance(path, Path)

# Generated at 2022-06-23 21:34:21.297664
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path = Path(platform=sys.platform)
    # Value must be a str
    assert isinstance(path.home(), str)
    # Type must be PurePosixPath or PureWindowsPath
    assert isinstance(PurePosixPath(path.home()), PurePosixPath) \
        or isinstance(PureWindowsPath(path.home()), PureWindowsPath) \
        and len(path.home()) > 0
    # Value must start with '/'
    assert path.home().startswith('/')


# Generated at 2022-06-23 21:34:25.155687
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert type(path.project_dir()).__name__ == 'str', 'Expected string, got %s' % type(path.project_dir()).__name__
    assert path.project_dir() == '/Users/sherika/Development/Falcon/mercenary', 'Expected string, got %s' % path.project_dir()


# Generated at 2022-06-23 21:34:27.323979
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:34:33.679167
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.random.seed(7)
    assert str(p.dev_dir()) == '/home/savanna/Development/Haskell'
    assert str(p.dev_dir()) == '/home/bryant/Development/C'
    assert str(p.dev_dir()) == '/home/taneka/Dev/JavaScript'
    assert str(p.dev_dir()) == '/home/marlene/Dev/Python'
    assert str(p.dev_dir()) == '/home/oretha/Development/PHP'
    assert str(p.dev_dir()) == '/home/sherrell/Development/Java'
    p.random.seed(10)
    assert str(p.dev_dir()) == '/home/fredia/Development/Ruby'

# Generated at 2022-06-23 21:34:35.764514
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    for _ in range(10):
        assert p.root() == '/'


# Generated at 2022-06-23 21:34:37.247537
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == "/home/joshua"


# Generated at 2022-06-23 21:34:38.264114
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    pass



# Generated at 2022-06-23 21:34:39.660060
# Unit test for method home of class Path
def test_Path_home():
    Path().home()


# Generated at 2022-06-23 21:34:42.374009
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:34:46.227220
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)
    assert isinstance(p, BaseProvider)
    assert isinstance(p._pathlib_home, PurePosixPath)
    assert 'home' in str(p._pathlib_home)


# Generated at 2022-06-23 21:34:47.734360
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""
    print(Path())


# Generated at 2022-06-23 21:34:49.637730
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_obj = Path()
    assert path_obj.users_folder().__contains__('/home/')

# Generated at 2022-06-23 21:34:51.693365
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:34:56.774874
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert callable(path.root)
    assert callable(path.home)
    assert callable(path.user)
    assert callable(path.users_folder)
    assert callable(path.dev_dir)
    assert callable(path.project_dir)


# Generated at 2022-06-23 21:35:00.022595
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert '\\' not in str(p._pathlib_home)
    assert 'home' in str(p._pathlib_home) 


# Generated at 2022-06-23 21:35:01.479463
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-23 21:35:03.221923
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.dev_dir()
    assert p.project_dir()



# Generated at 2022-06-23 21:35:05.400925
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-23 21:35:06.618803
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    assert provider.home() == '/home'


# Generated at 2022-06-23 21:35:10.284042
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(0, 100):
        path.users_folder()
    assert path.users_folder() is not None


# Generated at 2022-06-23 21:35:12.546024
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == '/home/alec/Development/JavaScript/machiavellian'



# Generated at 2022-06-23 21:35:20.450542
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p._pathlib_home, PurePosixPath), 'assert that pathlib_home is an instance of PurePosixPath'
    assert p._pathlib_home.name == 'home', 'assert that name of pathlib_home is home'

    p = Path(platform='darwin')
    assert isinstance(p._pathlib_home, PurePosixPath), 'assert that pathlib_home is an instance of PurePosixPath'
    assert p._pathlib_home.name == 'home', 'assert that name of pathlib_home is home'

    p = Path(platform='linux')
    assert isinstance(p._pathlib_home, PurePosixPath), 'assert that pathlib_home is an instance of PurePosixPath'

# Generated at 2022-06-23 21:35:22.053349
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.random != None
    

# Generated at 2022-06-23 21:35:23.730866
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:35:27.095169
# Unit test for method user of class Path
def test_Path_user():
    # When
    result = Path().user()

    # Then
    assert result in ['/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika']
assert test_Path_user()

# Generated at 2022-06-23 21:35:29.318168
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    result = path.user()
    assert result == '/home/wilfredo'

# Generated at 2022-06-23 21:35:30.138715
# Unit test for method user of class Path
def test_Path_user():
    p = Path();
    print(p.user())


# Generated at 2022-06-23 21:35:30.892935
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:35:32.834302
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home.parent != p._pathlib_home


# Generated at 2022-06-23 21:35:34.006864
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == "/home"


# Generated at 2022-06-23 21:35:37.809364
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Generate a random path to user's folders.

    :return: Path.

    :Example:
        /home/taneka/Pictures
    """
    mock_platform = 'linux'
    path_gen = Path(platform=mock_platform)
    assert path_gen.users_folder() == "C:/Users/taneka/Pictures"


# Generated at 2022-06-23 21:35:38.938850
# Unit test for method root of class Path
def test_Path_root():
    a = Path()
    print(a.root())


# Generated at 2022-06-23 21:35:45.393922
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/rusty/Development/JavaScript'
    assert Path().dev_dir() == '/home/taneka/Development/Ruby'
    assert Path().dev_dir() == '/home/sherika/Development/Python'
    assert Path().dev_dir() == '/home/reiko/Dev/Ruby'
    assert Path().dev_dir() == '/home/taneka/Dev/Ruby'
    assert Path().dev_dir() == '/home/sherrell/Dev/Python'
    assert Path().dev_dir() == '/home/sherika/Development/Java'
    assert Path().dev_dir() == '/home/taneka/Development/Java'
    assert Path().dev_dir() == '/home/oretha/Development/Python'

# Generated at 2022-06-23 21:35:49.895508
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from pathlib import PurePosixPath
    path = Path(platform='linux')
    user = path.user()
    folder = path.random.choice(FOLDERS)
    assert str(PurePosixPath(path._pathlib_home) / user / folder) == path.users_folder()

# Generated at 2022-06-23 21:35:54.366709
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert str(path._pathlib_home) == '/home'

    path = Path('win32')
    assert str(path._pathlib_home) == 'C:\\Users'


# Generated at 2022-06-23 21:35:59.715120
# Unit test for method user of class Path
def test_Path_user():
    path1 = Path(platform='linux')
    path2 = Path(platform='win32')
    path3 = Path(platform='win64')
    assert path1.user() == '/home/katya'
    assert path2.user() == 'C:\\Users\\jannie'
    assert path3.user() == 'C:\\Users\\joetta'

# Generated at 2022-06-23 21:36:04.406093
# Unit test for constructor of class Path
def test_Path():
    
    # Python code path
    python_code_path = Path.project_dir(Path())

    # Print python code path
    print('Path: ' + str(python_code_path))

# Run unit test
if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:36:07.947894
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    assert result == '/home'
    assert result is not None
    assert result is not ''


# Generated at 2022-06-23 21:36:10.266562
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    platform='darwin'
    path = Path(platform)
    paths = set()

    for i in range(10000):
        paths.add(path.dev_dir())

    print(paths)

# Generated at 2022-06-23 21:36:14.091473
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path(platform='win32')
    assert path.users_folder() == '/Users/Dawn/Downloads' or \
            path.users_folder() == '/Users/Dawn/Documents' or \
            path.users_folder() == '/Users/Dawn/Pictures' or \
            path.users_folder() == '/Users/Dawn/Movies'


# Generated at 2022-06-23 21:36:15.482274
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Method test_Path_dev_dir is a unit test for method dev_dir of class Path."""
    assert Path().dev_dir()

# Generated at 2022-06-23 21:36:19.727523
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder()+'\n')
    print(Path().users_folder()+'\n')
    print(Path().users_folder()+'\n')
    print(Path().users_folder()+'\n')
    print(Path().users_folder()+'\n')

test_Path_users_folder()

# Generated at 2022-06-23 21:36:22.468609
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/opt'
    assert Path().home() == '/opt'


# Generated at 2022-06-23 21:36:24.288539
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

test_Path_project_dir()

# Generated at 2022-06-23 21:36:27.535077
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    i = 0
    while i < 10:
        assert path.user() != path.user()
        i += 1



# Generated at 2022-06-23 21:36:29.189035
# Unit test for method home of class Path
def test_Path_home():
    path_ = Path()
    result = path_.home()
    assert result == "/home"


# Generated at 2022-06-23 21:36:32.658206
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    # Initializing the class
    path = Path()

    # Geting a random home
    home = path.home()

    # Assert 'home' with a random home
    assert home in ['/home', '/Users']


# Generated at 2022-06-23 21:36:34.849377
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    Path_test = Path()
    assert Path_test.dev_dir() is not None

# Generated at 2022-06-23 21:36:36.784438
# Unit test for constructor of class Path
def test_Path():
    """Unit testing for constructor of class Path."""

    assert Path().platform == sys.platform


# Unit tests

# Generated at 2022-06-23 21:36:38.407966
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    res = p.user()
    assert res != p.user()


# Generated at 2022-06-23 21:36:41.536257
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    for i in range(100):
        path_home = path.home()
        assert isinstance(path_home, str)
        assert len(path_home) > 1


# Generated at 2022-06-23 21:36:44.195777
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Create object
    path = Path()
    assert path.users_folder() == '/home/pearlene/Pictures'


# Generated at 2022-06-23 21:36:46.606729
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert 'Pictures' in path.users_folder()


# Generated at 2022-06-23 21:36:48.909304
# Unit test for method root of class Path
def test_Path_root():
    __temp = Path()
    __res = __temp.root()
    assert type(__res) == str and __res


# Generated at 2022-06-23 21:36:52.058913
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""

    path = Path()
    # Verify format
    assert isinstance(path.project_dir(), str)
    # Verify data
    assert path.project_dir().startswith(path.home())

# Generated at 2022-06-23 21:36:59.565032
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    generator = Path()
    example = generator.project_dir()

# Generated at 2022-06-23 21:37:06.762233
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path.random, type(path.random))
    assert isinstance(path._pathlib_home, type(path._pathlib_home))
    assert isinstance(path.root(), str)
    assert isinstance(path.home(), str)
    assert isinstance(path.user(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.dev_dir(), str)
    assert isinstance(path.project_dir(), str)

# Generated at 2022-06-23 21:37:08.553434
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.builtins import CommandLine

    path = Path()
    cli = CommandLine()
    assert cli.run('ls {}'.format(path.user())).ok



# Generated at 2022-06-23 21:37:09.678971
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:37:11.648455
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

# Generated at 2022-06-23 21:37:15.613767
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('win32')
    print(path.users_folder())


if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-23 21:37:16.128864
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.user()

# Generated at 2022-06-23 21:37:17.969347
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    path = p.dev_dir()
    assert path == '/home/ted/Development/Haskell'

# Generated at 2022-06-23 21:37:23.422628
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.platform
    if 'win' in path.platform:
        assert path.home() == 'C:\\Users'
    else:
        assert path.home() == '/home'
    if 'win' in path.platform:
        assert path.root() == 'C:\\'
    else:
        assert path.root() == '/'
    assert path.user() is not None
    assert path.users_folder() is not None
    assert path.dev_dir() is not None
    assert path.project_dir() is not None

# Generated at 2022-06-23 21:37:25.914722
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

test_Path_project_dir()

# Generated at 2022-06-23 21:37:28.033887
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/dorthea/Development/C++/nylon'

# Generated at 2022-06-23 21:37:28.992838
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())


# Generated at 2022-06-23 21:37:31.113666
# Unit test for method home of class Path
def test_Path_home():
    s = Path()
    result = s.home()
    print("Path home:", result)
    assert result is not None


# Generated at 2022-06-23 21:37:32.721424
# Unit test for method root of class Path
def test_Path_root():
    """Test Path.root().
    """
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:37:35.672610
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test class Path"""
    path_ = Path('win32')
    assert path_.project_dir() == 'C:\\Users\\Shin\\Dev\\Go\\imperative'
    path_ = Path('darwin')
    assert path_.project_dir() == '/Users/peggy/Development/Go/testify'

# Generated at 2022-06-23 21:37:36.849712
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    #print(path.project_dir())
    print(path.project_dir())
    assert True

# Generated at 2022-06-23 21:37:38.663925
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(100):
        print(Path("linux").project_dir())
        print(Path("win32").project_dir())
        print(Path("win64").project_dir())
        print("-----------------------------------------------------")

# Generated at 2022-06-23 21:37:40.037040
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-23 21:37:42.147953
# Unit test for method root of class Path
def test_Path_root():
    a = Path()
    b = a.root()
    if b in a.root():
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:37:45.404986
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert 'win' in p._pathlib_home.as_posix()

# Generated at 2022-06-23 21:37:48.635622
# Unit test for method root of class Path
def test_Path_root():
    # Tests the method `root` of class `Path`
    # Arrange
    platform = 'linux'
    path = Path(platform=platform)
    expected = '/'
    # Act
    actual = path.root()
    # Assert
    assert actual == expected


# Generated at 2022-06-23 21:37:50.939989
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    f = Path('win32')
    print(f.dev_dir())

# Generated at 2022-06-23 21:37:52.332127
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)


# Generated at 2022-06-23 21:37:53.769474
# Unit test for method root of class Path
def test_Path_root():
    m = Path('linux')
    assert m.root() == '/'



# Generated at 2022-06-23 21:37:55.058917
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:37:56.380693
# Unit test for method root of class Path
def test_Path_root():
    r = Path()
    print(r.root())
    

# Generated at 2022-06-23 21:37:59.402418
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert isinstance(p.home(), str)
    assert p.home().startswith("/")

# Generated at 2022-06-23 21:38:00.983318
# Unit test for method user of class Path
def test_Path_user():
    language = Path()
    print(language.home())
    print(language.user())

# Generated at 2022-06-23 21:38:04.667421
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    # path.seed(42)
    users = []
    for i in range(0, 10):
        users.append(path.user())
    print(users)


if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-23 21:38:07.249037
# Unit test for method root of class Path
def test_Path_root():
    assert Path('linux').root() == '/'
    assert Path('win32').root() == 'C:\\'
    assert Path('darwin').root() == '/'

# Generated at 2022-06-23 21:38:08.866034
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('win32')
    print(p.project_dir())

# Generated at 2022-06-23 21:38:09.855408
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert p is not None

# Generated at 2022-06-23 21:38:12.670386
# Unit test for constructor of class Path
def test_Path():
    assert Path()
    assert Path('darwin')
    assert Path('linux')
    assert Path('win32')
    assert Path('win64')


# Generated at 2022-06-23 21:38:14.193738
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    _path = Path()
    assert len(_path.dev_dir()) != 0

# Generated at 2022-06-23 21:38:18.230217
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
	# Create a new instance of class Path
	pathGenerator = Path("linux")
	# Call function dev_dir of class Path
	randomPath = pathGenerator.dev_dir()
	print("\nThe generated path is: ", randomPath)


# Generated at 2022-06-23 21:38:21.467945
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    x = Path()
    y = x.users_folder()
    print(y)

if __name__ == "__main__":
    x = Path()
    y = x.users_folder()
    print(y)

# Generated at 2022-06-23 21:38:23.034282
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    result = p.users_folder()
    assert result is not None


# Generated at 2022-06-23 21:38:24.266196
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""
    p = Path()

# Generated at 2022-06-23 21:38:27.822100
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Object initiazation
    path_obj = Path()
    # Generate random path to development directory
    random_path = path_obj.dev_dir()
    # Print the value generated
    print(random_path)


# Generated at 2022-06-23 21:38:28.518645
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:38:30.342279
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    path = Path(platform='win64')
    assert path.root() == 'C:\\'


# Generated at 2022-06-23 21:38:31.136812
# Unit test for constructor of class Path
def test_Path():
    f = Path()
    assert isinstance(f, Path)


# Generated at 2022-06-23 21:38:32.683596
# Unit test for method root of class Path
def test_Path_root():
    obj = Path()
    assert obj.root() in ['/', 'C:\\', 'D:\\']


# Generated at 2022-06-23 21:38:41.041044
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path('linux').dev_dir() == '/home/darlena/Development/Perl'
    assert Path('darwin').dev_dir() == '/Users/johnnie/Development/JavaScript'
    assert Path('win32').dev_dir() == 'C:\\Users\\isadora\\Dev\\C#'
    assert Path('win32').dev_dir() == 'C:\\Users\\isadora\\Dev\\C#'
    assert Path('win64').dev_dir() == 'C:\\Users\\jasmin\\Dev\\JavaScript'
    assert Path('win64').dev_dir() == 'C:\\Users\\jasmin\\Dev\\JavaScript'

# Generated at 2022-06-23 21:38:42.711850
# Unit test for method root of class Path
def test_Path_root():
    # Test for method root of class Path
    expected_root = '/'
    path = Path()
    root = path.root()
    assert root == expected_root

# Generated at 2022-06-23 21:38:43.982759
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:38:45.828822
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for _ in range(50):
        print(path.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:38:55.662123
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    #first try
    path = Path()
    assert path.dev_dir() == '/home/conrad/Development/Haskell'
    #second try
    assert path.dev_dir() == '/home/georgia/Dev/Perl'
    #third try
    assert path.dev_dir() == '/home/jodi/Development/JavaScript'
    #fourth try
    assert path.dev_dir() == '/home/dixie/Dev/PHP'
    #fifth try
    assert path.dev_dir() == '/home/noriko/Development/Python'
    #sixth try
    assert path.dev_dir() == '/home/hal/Dev/Java'
    #seventh try
    assert path.dev_dir() == '/home/dixie/Development/C++'
    #eighth try
    assert path.dev

# Generated at 2022-06-23 21:38:58.863717
# Unit test for constructor of class Path
def test_Path():
    """Test PATH constructor."""
    platform = sys.platform
    path = Path(platform)
    assert path.platform == platform
    assert str(path._pathlib_home) == '/home'


# Unit tests for method root()

# Generated at 2022-06-23 21:39:02.050742
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


# Generated at 2022-06-23 21:39:06.818715
# Unit test for constructor of class Path
def test_Path():
    p = Path()

    assert isinstance(p.platform, str)
    assert p.platform == sys.platform
    assert isinstance(p._pathlib_home, PureWindowsPath)
    assert p._pathlib_home.parent == PureWindowsPath('\\')

    p = Path('linux')

    assert isinstance(p.platform, str)
    assert p.platform == 'linux'
    assert isinstance(p._pathlib_home, PurePosixPath)
    assert p._pathlib_home.parent == PurePosixPath('/')



# Generated at 2022-06-23 21:39:08.489129
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path,Path)

# Generated at 2022-06-23 21:39:10.163533
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    # print(result)
    assert result is not None


# Generated at 2022-06-23 21:39:12.152422
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert type(p.home()) == str

# Generated at 2022-06-23 21:39:14.171197
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert "\\" not in home

# Generated at 2022-06-23 21:39:15.713995
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    prueba = Path()
    prueba.dev_dir()


# Generated at 2022-06-23 21:39:16.354581
# Unit test for constructor of class Path
def test_Path():
    p=Path()

# Generated at 2022-06-23 21:39:18.046532
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    instance = Path()
    assert str(instance._pathlib_home) in instance.project_dir()

# Generated at 2022-06-23 21:39:20.594044
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    instance = Path('linux')
    sut = instance.project_dir()
    assert sut.startswith('/home')
    assert sut.count('/') == 5


# Generated at 2022-06-23 21:39:22.848894
# Unit test for method root of class Path
def test_Path_root():
    # Init object
    path = Path()
    print(path.root())



# Generated at 2022-06-23 21:39:23.728636
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in list_paths


# Generated at 2022-06-23 21:39:25.454894
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    random_path = path.users_folder()
    print(random_path)
    assert isinstance(random_path, str)

# Generated at 2022-06-23 21:39:35.976341
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.random.seed(0)
    assert path.dev_dir() == '/home/clarisa/Development/C++'
    path.random.seed(1)
    assert path.dev_dir() == '/home/clarisa/Dev/Ruby'
    path.random.seed(2)
    assert path.dev_dir() == '/home/lela/Development/Java'
    path.random.seed(3)
    assert path.dev_dir() == '/home/lela/Dev/Python'
    path.random.seed(4)
    assert path.dev_dir() == '/home/lela/Dev/C++'
    path.random.seed(5)
    assert path.dev_dir() == '/home/juliana/Development/Python'

# Generated at 2022-06-23 21:39:37.303550
# Unit test for method user of class Path
def test_Path_user():
    platform = sys.platform
    p = Path(platform)
    print(p.user())

# Generated at 2022-06-23 21:39:38.684187
# Unit test for method home of class Path
def test_Path_home():
  w = Path()
  assert w.home() == str(w._pathlib_home)

# Generated at 2022-06-23 21:39:42.784988
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() in ['/home/taneka/Dev/Python',
                              '/home/maisha/Dev/Python',
                              '/home/shayla/Development/Python',
                              '/home/sherrell/Dev/Python',
                              '/Users/sherika/Dev/Python',
                              '/Users/sherika/Development/Python']

# Generated at 2022-06-23 21:39:45.556198
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for Path.home
    
    
    Args:
        None
    
    Returns:
        None

    Raises:
        None
    """

    path = Path()
    path.home() # /home


# Generated at 2022-06-23 21:39:47.315576
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    desired_path = "/home/leona"
    generated_path = Path().user()
    assert generated_path == desired_path

# Generated at 2022-06-23 21:39:49.115949
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    # Example:
    # Path.dev_dir(): /home/shay/Development/Angular
    print(path.dev_dir())

# Generated at 2022-06-23 21:39:53.003089
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.random.seed(1)
    assert path.home() == '/home'
    assert path.home() == '/home'
    assert path.home() == '/home'


# Generated at 2022-06-23 21:39:55.215551
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:39:57.322555
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path()
    path = obj.dev_dir()
    assert path == '/home/kamilah/Development/Go'

# Generated at 2022-06-23 21:39:58.934581
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir = path.project_dir()
    print(project_dir)


# Generated at 2022-06-23 21:39:59.889478
# Unit test for constructor of class Path
def test_Path():
	assert Path.__init__(Path())

# Generated at 2022-06-23 21:40:01.077471
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert len(path.root()) > 0


# Generated at 2022-06-23 21:40:09.935633
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    my_path = Path()
    result = my_path.dev_dir()
    print(result)
    if result.find('/home') != 0:
        print('Error Path home: ', result)
    if result.find('/Development') > 1:
        print('Error Path Development: ', result)
    if result.find('Python') < 0:
        print('Error Path Python: ', result)
    if result.find('/home') == 0 and result.find('/Development') > 1 and result.find('Python') < 0:
        print('Ok Path dev_dir')

# Generated at 2022-06-23 21:40:10.911074
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    Path().project_dir()

# Generated at 2022-06-23 21:40:13.656802
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert p
    assert p.platform == 'linux'
    assert p._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-23 21:40:15.345226
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'


# Generated at 2022-06-23 21:40:17.290844
# Unit test for method root of class Path
def test_Path_root():
    for i in range(100):
        assert len(Path().root()) == 1
        assert Path().root()[0] == '/'
