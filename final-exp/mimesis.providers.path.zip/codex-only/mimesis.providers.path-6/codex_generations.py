

# Generated at 2022-06-23 21:30:20.141229
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    p = Path('win32')
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())



# Generated at 2022-06-23 21:30:22.233915
# Unit test for method project_dir of class Path
def test_Path_project_dir():
  path = Path()
  res = path.project_dir()
  assert res


# Generated at 2022-06-23 21:30:23.488401
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:30:29.875318
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.project_dir(), str)
    assert isinstance(path.dev_dir(), str)
    assert isinstance(path.user(), str)
    assert isinstance(path.home(), str)
    assert isinstance(path.root(), str)

# Generated at 2022-06-23 21:30:34.104689
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev1 = path.dev_dir()
    dev2 = path.dev_dir()
    if dev1 == dev2:
        print ('Success')
    else:
        print ('Fail')


# Generated at 2022-06-23 21:30:37.126969
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(100):
        path = Path()
        result = path.project_dir()
        if result:
            print(result)
    return True

# Generated at 2022-06-23 21:30:41.815711
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Gender
    home = '/home/nisha'
    x = Path()
    x.random.seed(0)
    x.random.choice = lambda x: home
    x.random.choice = lambda x: Gender.MALE.value
    p = x.users_folder()
    assert p == '/home/nisha/Pictures'

# Generated at 2022-06-23 21:30:45.546863
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home/sherrell'
    assert path.home() == '/home/cristal'


# Generated at 2022-06-23 21:30:48.142634
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path.

    :return:
    """
    assert Path().root() == '/'


# Generated at 2022-06-23 21:30:50.271445
# Unit test for method user of class Path
def test_Path_user():
    generator = Path()
    user = generator.user()

    # Check if user is a string
    assert isinstance(user, str)


# Generated at 2022-06-23 21:30:51.903557
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    assert result == '/'


# Generated at 2022-06-23 21:30:52.942057
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() is not None

# Generated at 2022-06-23 21:30:54.267773
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'



# Generated at 2022-06-23 21:30:58.402366
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    r = path.root()
    assert isinstance(r, str)
    assert r
    assert r[0] == '/'


# Generated at 2022-06-23 21:31:02.031059
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()
    print(path.dev_dir())
    print(path.project_dir())

if __name__ == '__main__':
    test_Path_dev_dir()

# Generated at 2022-06-23 21:31:03.795986
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path._pathlib_home, PurePosixPath)

# Generated at 2022-06-23 21:31:09.200082
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import pathlib
    from random import choice
    from platform import system
    from mimesis.providers.path import Path
    p = Path(platform=system())
    assert isinstance(p.project_dir(), str)
    assert isinstance(pathlib.Path(p.project_dir()), pathlib.PurePath)
    for i in range(10):
        assert pathlib.Path(p.project_dir()).drive == choice(pathlib.Path(p.project_dir()).parents).drive

# Generated at 2022-06-23 21:31:13.296252
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p1 = Path('linux')
    p2 = Path('darwin')
    p3 = Path('win32')
    p4 = Path('win64')
    p5 = Path('linux', seed=10)


# Generated at 2022-06-23 21:31:15.869039
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() is not None
    assert path.root() is not ''
    assert type(path.root()) is str

# Generated at 2022-06-23 21:31:19.428948
# Unit test for constructor of class Path
def test_Path():
    assert Path()
    assert Path('linux')
    assert Path('darwin')
    assert Path('win32')
    assert Path('win64')


# Generated at 2022-06-23 21:31:21.640542
# Unit test for method home of class Path
def test_Path_home():
    # p = Path()
    # assert p.home() == '/home'
    pass



# Generated at 2022-06-23 21:31:27.302033
# Unit test for method user of class Path
def test_Path_user():
    # Unit test for method user of class Path
    print('===============')
    print('Testing "user"')
    print('-> Init')
    p = Path()
    print('-> Run')
    res = p.user()
    print('-> Result: ' + res)
    print('-> Boolean')
    assert 'oretha' in res
    assert 'home' in res
    print('===============')
    print('/Testing "user"')
    print('===============\n')


# Generated at 2022-06-23 21:31:31.095520
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    target = Path()
    path = target.dev_dir()
    str1 = '/home/paula/Development/Java'
    assert path == str1 or path != str1
    return path

# Generated at 2022-06-23 21:31:32.051678
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:35.594965
# Unit test for method root of class Path
def test_Path_root():
    provider = Path()
    assert isinstance(provider.root(), str)
    assert provider.root()
    assert "/" == provider.root()



# Generated at 2022-06-23 21:31:36.204232
# Unit test for constructor of class Path
def test_Path():
    Path()

# Generated at 2022-06-23 21:31:39.982115
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Tests the users_folder method of class Path.

    """
    path = Path()
    assert isinstance(path.users_folder(), str)



# Generated at 2022-06-23 21:31:42.362601
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert p != None
    assert p.platform != ""
    assert p._pathlib_home != None


# Generated at 2022-06-23 21:31:43.826185
# Unit test for method root of class Path
def test_Path_root():
    path = Path('linux')
    assert path.root() == '/'

# Generated at 2022-06-23 21:31:45.929456
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    lang = "Python"
    path = Path()
    path.dev_dir()
    assert lang in path.dev_dir()


# Generated at 2022-06-23 21:31:46.933565
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'

# Generated at 2022-06-23 21:31:48.109685
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path), 'Path() raised TypeError'

# Unit tests for method root

# Generated at 2022-06-23 21:31:49.672100
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == str(path._pathlib_home / \
                                     path.dev_dir() / \
                                     path.random.choice(PROJECT_NAMES))

# Generated at 2022-06-23 21:31:51.593055
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == '/home/rolando/Pictures'

# Generated at 2022-06-23 21:31:52.985844
# Unit test for method root of class Path
def test_Path_root():
    provider = Path()
    assert provider.root() == '/'



# Generated at 2022-06-23 21:31:54.874058
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print('Path.project_dir() is {}'.format(path.project_dir()))


# Generated at 2022-06-23 21:31:55.912347
# Unit test for method home of class Path
def test_Path_home():
   p = Path()
   print(p.home())

# Generated at 2022-06-23 21:32:05.051167
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.home() in ['/home', 'C:\\Users']
    assert p.user() in ['/home/oretha', 'C:\\Users\\oretha']
    assert p.dev_dir() in ['/home/oretha/Development/Python', 'C:\\Users\\oretha\\Development\\Python']
    assert p.project_dir() in ['/home/oretha/Development/Python/jalopy', 'C:\\Users\\oretha\\Development\\Python\\jalopy']
    assert p.users_folder() in ['/home/oretha/Pictures', 'C:\\Users\\oretha\\Pictures']

# Generated at 2022-06-23 21:32:06.678601
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    folder = p.users_folder()
    assert folder in FOLDERS

# Generated at 2022-06-23 21:32:13.090535
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    myPath = Path()
    for x in range(0, 1000):
        path = myPath.project_dir()
        print(path)
        assert path.find("/home/") != -1
        assert path.find("/Development/") != -1
        assert path.find("/Python/") != -1
        assert path.find("/mercenary") != -1
        assert path.find("/") == 0



# Generated at 2022-06-23 21:32:16.650394
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    p = Path()
    assert p.dev_dir() == "/home/taneka/Dev/Fortran"

# Generated at 2022-06-23 21:32:19.763929
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    f = Path("/home/sherika/Development/Falcon/mercenary")
    assert f.project_dir() == "home/sherika/Development/Falcon/mercenary"

# Generated at 2022-06-23 21:32:21.621512
# Unit test for method user of class Path
def test_Path_user():
    user_test = Path()
    assert type(user_test.user()) == str


# Generated at 2022-06-23 21:32:25.406634
# Unit test for method user of class Path
def test_Path_user():
    """Method for testing class Path"""
    path = Path(platform='linux')
    expected_user_path = '/home/brianne'
    assert path.home() == '/home', 'Home path is incorrect.'
    assert path.user() == expected_user_path, 'User path is incorrect.'

test_Path_user()

# Generated at 2022-06-23 21:32:27.186935
# Unit test for method user of class Path
def test_Path_user():
	path = Path()
	a = path.user()
	print(a)



# Generated at 2022-06-23 21:32:29.600097
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert isinstance(
        Path().dev_dir(),
        str
    )


# Generated at 2022-06-23 21:32:31.145675
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()



# Generated at 2022-06-23 21:32:33.562715
# Unit test for method root of class Path
def test_Path_root():
    """Test for method root of class Path."""
    obj = Path()
    assert isinstance(obj.root(), str)


# Generated at 2022-06-23 21:32:36.396434
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test method project_dir."""
    app = Path()
    path = app.project_dir()
    assert path == "/home/madelaine/Development/Dart/therion"

# Generated at 2022-06-23 21:32:38.959248
# Unit test for method user of class Path
def test_Path_user():
    a=Path()
    assert a.user()[:6] == '/home/' or 'C:\\Users\\'


# Generated at 2022-06-23 21:32:40.184726
# Unit test for constructor of class Path
def test_Path():
    path = Path().dev_dir()
    print(path)

# Generated at 2022-06-23 21:32:41.370610
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() in ['c:\\Users', '/home']

# Generated at 2022-06-23 21:32:45.811962
# Unit test for method project_dir of class Path
def test_Path_project_dir():

    import os

    p = Path(platform=os.name)
    dev_dir = p.dev_dir()
    project_dir = p.project_dir().replace(dev_dir, '')
    assert project_dir.startswith('/')

    dev_dir = p.dev_dir()
    project_dir = p.project_dir().replace(dev_dir, '')
    assert project_dir.startswith('/')

# Generated at 2022-06-23 21:32:54.928600
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    output1 = p.home()
    output2 = p.user()
    output3 = p.users_folder()
    output4 = p.dev_dir()
    output5 = p.project_dir()
    assert isinstance(output1, str)
    assert isinstance(output2, str)
    assert isinstance(output3, str)
    assert isinstance(output4, str)
    assert isinstance(output5, str)
    assert len(output1) > 0
    assert len(output2) > 0
    assert len(output3) > 0
    assert len(output4) > 0
    assert len(output5) > 0

# Generated at 2022-06-23 21:32:57.841340
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Arrange
    path = Path()
    # Act
    result = path.users_folder()
    # Assert
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:33:00.200527
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test to validate method project_dir of class Path.
    """
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:33:01.251309
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/home'

# Generated at 2022-06-23 21:33:02.983979
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert not p.platform == 'windows'

# Generated at 2022-06-23 21:33:05.336302
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test of dev_dir method in class Path."""
    p = Path(platform='linux')
    assert p.dev_dir() == '/home/teresia/Dev/Java'

# Generated at 2022-06-23 21:33:10.431694
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())

# test_Path()

# Generated at 2022-06-23 21:33:12.407390
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() != None
    return path.home()


# Generated at 2022-06-23 21:33:14.087275
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:33:15.624738
# Unit test for method home of class Path
def test_Path_home():
    # p = Path()
    # print(p.home())
    assert True

# Generated at 2022-06-23 21:33:17.900331
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    result = p.home()
    print(result)


# Generated at 2022-06-23 21:33:27.148345
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import SpecialChars
    from random import Random
    from sys import platform
    from mimesis.providers.path import Path
    from mimesis.data import (
        FOLDERS,
        PLATFORMS,
        PROGRAMMING_LANGS,
        PROJECT_NAMES,
        USERNAMES,
    )
    from mimesis.providers.base import BaseProvider
    """Initialize attributes.
    Supported platforms: 'linux', 'darwin', 'win32', 'win64'."""
    platform = platform
    path = Path(platform)
    path.random = Random(125)
    """Generate a random user.
    :return: Path to user.
    :Example:
        /home/oretha"""
    assert path.user() == '/home/oretha'

#

# Generated at 2022-06-23 21:33:30.810160
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'
    assert p.root() == '/'
    assert type(p.root()) == str


# Generated at 2022-06-23 21:33:34.072162
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    path = p.users_folder()
    result = p._pathlib_home.parent.joinpath(path)
    print(result)
    assert isinstance(path, str)


# Generated at 2022-06-23 21:33:34.550565
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    pass

# Generated at 2022-06-23 21:33:35.312106
# Unit test for constructor of class Path
def test_Path():
    pass


# Generated at 2022-06-23 21:33:40.322201
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert Path.__name__ == "Path"

    assert p.Meta.name == "path"

    assert p.home()

    assert p.root()

    assert p.user()

    assert p.users_folder()

    assert p.dev_dir()

    assert p.project_dir()

# Generated at 2022-06-23 21:33:42.093788
# Unit test for method root of class Path
def test_Path_root():
    path = Path('win32')
    assert path.root() == 'C:\\'


# Generated at 2022-06-23 21:33:45.310515
# Unit test for method user of class Path
def test_Path_user():
    """Test for Path.user."""
    path = Path()
    assert '/home/kali' == path.user()


# Generated at 2022-06-23 21:33:51.044169
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p1 = Path()
    s = p1.project_dir()
    assert isinstance(s, str)
    l1 = s.split("/")
    assert l1[0] == ''
    assert l1[1] == 'home'
    assert l1[3] == 'Development'
    assert l1[4] == 'Python'
    assert l1[5] != ''

# Generated at 2022-06-23 21:33:52.975111
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(10):
        current_path = Path(platform="win32")
        project_dir = current_path.project_dir()
        assert project_dir
        print(project_dir)

# Generated at 2022-06-23 21:33:56.161207
# Unit test for constructor of class Path
def test_Path():
    # Given
    a = Path()
    # When
    actual = a.platform
    # Then
    expected = 'linux'
    assert actual == expected


# Generated at 2022-06-23 21:33:57.214131
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert 'python' in path.project_dir().lower()

# Generated at 2022-06-23 21:34:00.360394
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test for method users_folder of a class Path."""
    path = Path()
    
    users_folder = path.users_folder()
    result = not users_folder in path.home()
    assert result


# Generated at 2022-06-23 21:34:03.226263
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home()
    assert path.home()
    assert path.home()


# Generated at 2022-06-23 21:34:04.238826
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:34:10.077284
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/tonisha', '/home/daniella', '/home/kimberlie', '/home/cory', '/home/ali', '/home/nerissa', '/home/tianna', '/home/tarah', '/home/magdalen', '/home/tameka', '/home/luisa', '/home/danae', '/home/tai']

# Generated at 2022-06-23 21:34:11.070599
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    x = Path()
    x.project_dir()

# Generated at 2022-06-23 21:34:14.483086
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    # Test if the returned path contains a string with the format: /home
    assert p.users_folder() != ''
    assert p.users_folder() == str(p._pathlib_home / 'Sherika' / \
                                   'Music')


# Generated at 2022-06-23 21:34:16.464336
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for _ in range(50):
        print(Path().dev_dir())


# Generated at 2022-06-23 21:34:17.408860
# Unit test for constructor of class Path
def test_Path():
    p = Path()


# Generated at 2022-06-23 21:34:19.522725
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    for _ in range(10):
        print(p.users_folder())


# Generated at 2022-06-23 21:34:22.122436
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    # We don't test the home because it can be different
    # depending on the machine used to run the tests.
    assert isinstance(path.home(), str) == True


# Generated at 2022-06-23 21:34:25.085824
# Unit test for method users_folder of class Path
def test_Path_users_folder():

    # Providers
    path = Path()

    # Generate a random path to user's folders
    path_to_users_folder = path.users_folder()
    print("Random path to users folder: ", path_to_users_folder)
    # /home/sherrell/Pictures

    return



# Generated at 2022-06-23 21:34:29.555839
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    if 'win' in p.platform:
        assert p._pathlib_home == PureWindowsPath('C:\\Users')
    else:
        assert p._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-23 21:34:39.543352
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    seed(1)
    cases = []
    for i in range(10):
        case = Path().dev_dir()
        cases.append(case)
    expected = [
        '/home/weston/Development/Haskell',
        '/home/shayla/Development/Ruby',
        '/home/annalee/Development/C++',
        '/home/denese/Development/Java',
        '/home/katheryn/Development/Python',
        '/home/erika/Development/Letterpress',
        '/home/hassan/Development/Java',
        '/home/hassan/Development/Haskell',
        '/home/kyra/Development/Haskell',
        '/home/katheryn/Dev/Python'
        ]
    assert cases == expected


# Generated at 2022-06-23 21:34:42.279531
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() not in {"/home/vinita"}


# Generated at 2022-06-23 21:34:49.280939
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    from mimesis.path import Path

    # Test for Windows
    path = Path(platform=Platform.WINDOWS)
    assert str(path.root()) == 'C:\\'

    # Test for Linux
    path = Path(platform=Platform.LINUX)
    assert str(path.root()) == '/'

    # Test for OS X / macOS
    path = Path(platform=Platform.OSX)
    assert str(path.root()) == '/'


# Generated at 2022-06-23 21:34:52.477994
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    print(home)
    assert home == '/home'


# Generated at 2022-06-23 21:34:57.474170
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import random
    seed = random.randint(0, sys.maxsize)
    random.seed(seed)
    p = Path(platform=sys.platform)
    project_dir = p.project_dir()
    assert(project_dir)
    print("Seed for \"Path_project_dir\": " + str(seed))


# Generated at 2022-06-23 21:35:07.039783
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("\nunit test for Path.project_dir()\n")
    print("Testing Path.project_dir() in the current environment:")
    provider = Path()
    print(provider.project_dir())
    print("Testing Path.project_dir() for 'linux':")
    provider = Path('linux')
    print(provider.project_dir())
    print("Testing Path.project_dir() for 'darwin':")
    provider = Path('darwin')
    print(provider.project_dir())
    print("Testing Path.project_dir() for 'win32':")
    provider = Path('win32')
    print(provider.project_dir())
    print("Testing Path.project_dir() for 'win64':")
    provider = Path('win64')
    print(provider.project_dir())
test

# Generated at 2022-06-23 21:35:11.481366
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print("Test Path.users_folder")
    path = Path()
    result = path.users_folder()
    print(result)
    assert (str(type(result)) == "<class 'str'>" and "home" in result)


# Generated at 2022-06-23 21:35:19.448588
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    from mimesis.builtins import Path
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Platform

    p = Path()
    assert p() != p()
    assert p.platform in Platform.__members__.keys()
    assert p.root().startswith('/')

    p = Path(platform=Platform.WINDOWS)
    assert p() != p()
    assert p.platform == Platform.WINDOWS
    assert p.root().startswith('C:\\')

    with pytest.raises(NonEnumerableError):
        p = Path(platform='invalid')
        p.home()


# Generated at 2022-06-23 21:35:20.573433
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p=Path()
    p.dev_dir()

# Generated at 2022-06-23 21:35:24.720502
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    args = (
        'linux',
    )
    path = Path(*args)
    expected = '/home/brittny/Development/PHP/flamboyant'
    actual = path.project_dir()
    assert actual == expected

# Generated at 2022-06-23 21:35:34.311297
# Unit test for method user of class Path
def test_Path_user():
    '''Unit test for method user of class Path'''
    from mimesis.builtins import RussianSpecProvider
    from pathlib import Path
    import pytest

    Path_obj = Path(platform='linux', seed=None)
    path_obj_ru = Path(platform='linux', seed=None, 
        cls=RussianSpecProvider)
    user_path_expected = '/home/oretha'
    user_path_ru_expected = '/home/федор'

    user_path_expected_win = 'C:\\Users\\ORE'
    user_path_ru_expected_win = 'C:\\Users\\ФЕДОР-СТОЯН'

    assert Path_obj.user() == user_path_expected
    assert path_obj_ru.user

# Generated at 2022-06-23 21:35:36.397237
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-23 21:35:38.661020
# Unit test for method home of class Path
def test_Path_home():
    # Test variable for method home of class Path
    path = Path('win32').home()
    assert path != Path('win32').home()

# Generated at 2022-06-23 21:35:40.406113
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for i in range(100):
        user = path.user()
        assert (not user.isalpha())

# Generated at 2022-06-23 21:35:41.438634
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert isinstance(path.project_dir(), str)

# Generated at 2022-06-23 21:35:43.883219
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/salome/Development/JavaScript/underscore'

# Generated at 2022-06-23 21:35:51.700530
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from random import Random
    from mimesis.random import RandomGenerator
    from mimesis.providers.path import Path

    seed = 42
    random = Random(seed)
    rg = RandomGenerator(random)
    p = Path(rg)

    for _ in range(5):
        assert p.users_folder() == '/home/gabriel/Videos'

    random.seed(seed)
    rg.seed(seed)
    p = Path(rg)

    for _ in range(5):
        assert p.users_folder() == '/home/melani/Music'

# Generated at 2022-06-23 21:35:53.973623
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p._pathlib_home


# Generated at 2022-06-23 21:35:56.512249
# Unit test for method user of class Path
def test_Path_user():
	p = Path()
	assert isinstance(p.home(), str)
	assert isinstance(p.user(), str)


# Generated at 2022-06-23 21:35:58.654539
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    print(user)
    assert isinstance(user, str)


# Generated at 2022-06-23 21:36:00.479546
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    print(users_folder)


# Generated at 2022-06-23 21:36:02.695395
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    #print(path.project_dir())


# Generated at 2022-06-23 21:36:05.039459
# Unit test for method project_dir of class Path
def test_Path_project_dir():
        from mimesis import Path
        p = Path()
        project_dir = p.project_dir()
        print(project_dir)


# Generated at 2022-06-23 21:36:08.467493
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir_example = '/home/sherika/Development/Falcon/mercenary'
    assert path.project_dir() == project_dir_example

# Generated at 2022-06-23 21:36:09.953696
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:36:13.318356
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    for i in range(500):
        assert '/home' in path.user()


# Generated at 2022-06-23 21:36:14.896835
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()
    # returns '/'/


# Generated at 2022-06-23 21:36:18.798245
# Unit test for method home of class Path
def test_Path_home():
    """Unit test to verify the method home of class Path."""
    test_home = Path().home()
    assert len(test_home) > 0
    assert test_home in ["/home", "C:\\Users"]



# Generated at 2022-06-23 21:36:25.300238
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == 'linux'
    assert p.root() == '/'
    assert p.home() == '/home'
    assert p.user() == '/home/user'
    assert p.users_folder() == '/home/user/Pictures'
    assert p.dev_dir() == '/home/user/Development/Python'
    assert p.project_dir() == '/home/user/Development/Python/Project'

# Generated at 2022-06-23 21:36:27.955701
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() == "C:\\Users\\modesto\\Development\\Python\\custody"

# Generated at 2022-06-23 21:36:30.284806
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    print(result)
    assert str(type(result)) == "<class 'str'>"


# Generated at 2022-06-23 21:36:31.220221
# Unit test for constructor of class Path
def test_Path():
    assert Path() is not None

# Generated at 2022-06-23 21:36:34.285272
# Unit test for method user of class Path
def test_Path_user():
    x = Path("linux")
    y1 = x.user()
    print(y1)
    y2 = x.user()
    print(y2)
    y3 = x.user()
    print(y3)


# Generated at 2022-06-23 21:36:36.566026
# Unit test for method root of class Path
def test_Path_root():
    test1 = Path()
    assert test1.root() == '/'
    print("test_Path_root... PASSED")


# Generated at 2022-06-23 21:36:38.184031
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    result = p.users_folder()
    assert result is not None


# Generated at 2022-06-23 21:36:40.510299
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    assert result == '/home/roni/Development/Python'

# Generated at 2022-06-23 21:36:42.010846
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())



# Generated at 2022-06-23 21:36:43.851145
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    a = Path()
    print(a.dev_dir())

# Generated at 2022-06-23 21:36:45.610716
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:36:51.693020
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() != "/home/winifred/Projects"
    assert path.users_folder() != "/home/kenisha/Music"
    assert path.users_folder() != "/home/lourdes/Videos"

    assert path.users_folder() == "/home/winifred/Projects" or path.users_folder() == "/home/kenisha/Music" or path.users_folder() == "/home/lourdes/Videos"

# Generated at 2022-06-23 21:36:53.177900
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())

if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-23 21:36:53.931316
# Unit test for constructor of class Path
def test_Path():
    assert Path()

# Generated at 2022-06-23 21:36:55.058079
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)

# Generated at 2022-06-23 21:36:58.007939
# Unit test for method home of class Path
def test_Path_home():
    # GIVEN
    seed = 0
    platform = sys.platform
    path = Path(seed=seed, platform=platform)
    # WHEN
    result = path.home()
    # THEN
    assert result == '/home'


# Generated at 2022-06-23 21:37:00.424912
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    dev_dir = Path().dev_dir()
    print(dev_dir)
    assert dev_dir is not None


# Generated at 2022-06-23 21:37:02.026109
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.dev_dir()


# Generated at 2022-06-23 21:37:05.299777
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Method project_dir of class Path"""

    from mimesis import Path

    path = Path()

    assert isinstance(path.project_dir(), str)
    assert path.project_dir() != ''


# Generated at 2022-06-23 21:37:06.589705
# Unit test for method root of class Path
def test_Path_root():
    Path_ = Path()
    assert Path_.root() == '/'
    

# Generated at 2022-06-23 21:37:08.147082
# Unit test for method user of class Path
def test_Path_user():
    for i in range(100):
        a = Path().user()
        print("user: ", a)


# Generated at 2022-06-23 21:37:10.574743
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    # assert p.home() == "C:\\Users\\kathryn"
    # assert p.home() == "\\home\\sherrilla"
    assert p.home() == "/home"


# Generated at 2022-06-23 21:37:12.301152
# Unit test for method root of class Path
def test_Path_root():
    Path()
    print(Path.root())

# Generated at 2022-06-23 21:37:14.304534
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:37:16.885035
# Unit test for method root of class Path
def test_Path_root():
    _Path = Path()
    expected = str(_Path._pathlib_home.parent)
    assert _Path.root() == expected


# Generated at 2022-06-23 21:37:21.035226
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())

    # Override platform
    path = Path(platform='mac')


# Generated at 2022-06-23 21:37:32.166126
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
   

# Generated at 2022-06-23 21:37:35.629782
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    st = p.project_dir()
    str1 = '/home/aubrey/Development/Django/Web'
    assert(st == str1)

# Generated at 2022-06-23 21:37:36.661619
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()

# Generated at 2022-06-23 21:37:38.534072
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path().users_folder()
    assert a == '/home/jaimie/Downloads'

# Generated at 2022-06-23 21:37:46.568565
# Unit test for method root of class Path
def test_Path_root():
    p = Path('win32')
    assert p.root()== 'C:\\'
    assert p.home() == 'C:\\Users'
    assert p.user() == 'C:\\Users\\MARVIN'
    assert p.users_folder() == 'C:\\Users\\MARVIN\\Documents'
    assert p.dev_dir() == 'C:\\Users\\MARVIN\\Documents\\Ruby'
    assert p.project_dir() == 'C:\\Users\\MARVIN\\Documents\\Ruby\\Fobber'
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # print(str(p._pathlib_home.parent))
    # print(str(p._path

# Generated at 2022-06-23 21:37:48.149424
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    for _ in range(4):
        print(path.dev_dir())

# Generated at 2022-06-23 21:37:50.792961
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    res = p.root()
    assert res == '/'


# Generated at 2022-06-23 21:37:52.239195
# Unit test for constructor of class Path
def test_Path():
    """Test Path constructor"""
    path = Path()
    print(path.home())

# Generated at 2022-06-23 21:37:55.144105
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    x = path.users_folder()
    assert x != None
    assert isinstance(x, str) == True
    assert len(x) > 0
    print(x)


# Generated at 2022-06-23 21:38:03.373577
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.random.seed(0)

    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.user() == '/home/carmella'
    assert path.users_folder() == '/home/kiley/Pictures'
    assert path.dev_dir() == '/home/carmella/Development/Perl'
    assert path.project_dir() == '/home/carmella/Development/Perl/cloudy'

# Generated at 2022-06-23 21:38:06.298290
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    user = path.user()
    assert user in path.users_folder()

test_Path_home()

# Generated at 2022-06-23 21:38:12.328975
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath('C:\\Users')
    path = Path(platform='linux')
    assert path.platform == 'linux'
    assert path._pathlib_home == PurePosixPath('/home')


# Unit tests for constructor of Path.root

# Generated at 2022-06-23 21:38:14.243782
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert isinstance(path.users_folder(), str)


# Generated at 2022-06-23 21:38:16.432548
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert type(path.dev_dir()) in [str]


# Generated at 2022-06-23 21:38:18.496491
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    result = p.project_dir()
    print(result)
    assert(result[0] == '/')


# Generated at 2022-06-23 21:38:20.345300
# Unit test for method home of class Path
def test_Path_home():
    """Method that tests method home."""
    assert Path.home() == '/home'


# Generated at 2022-06-23 21:38:22.954512
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    assert users_folder
    assert isinstance(users_folder, str)

# Unit tests for method project_dir of class Path

# Generated at 2022-06-23 21:38:27.240750
# Unit test for method user of class Path
def test_Path_user():
    print("\ntest_Path_user")
    # initialize class using default settings
    gen = Path()
    # set seed
    seed = 42
    gen.seed(seed)
    # generate a random user
    print("seed: %d" % seed)
    user = gen.user()
    print("user: %s" % user)
    # expected result
    expected = '/home/agueda'
    assert user == expected


# Generated at 2022-06-23 21:38:28.445379
# Unit test for method root of class Path
def test_Path_root():
    root = Path().root()
    print("root: ", root)


# Generated at 2022-06-23 21:38:30.879329
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    from mimesis.providers.path import Path
    path_instance = Path()
    assert path_instance.project_dir() == '/home/abdullah/Development/Python/nine_to_five'


# Generated at 2022-06-23 21:38:32.723770
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    x = Path()
    assert type(x.project_dir()) == str
    assert len(x.project_dir()) > 1

# Generated at 2022-06-23 21:38:34.017394
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    tmp = Path()
    tmp.users_folder()


# Generated at 2022-06-23 21:38:38.861071
# Unit test for method home of class Path
def test_Path_home():
    test = Path()
    for i in range(0, 100):
        assert len(test.home()) >= 6
        assert test.home()[1] == "/"
        assert test.home()[-1] == "/"
        assert test.home()[0] == "/"


# Generated at 2022-06-23 21:38:40.644515
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() in ['\\','/']


# Generated at 2022-06-23 21:38:41.998700
# Unit test for constructor of class Path
def test_Path():
    a = Path(platform='linux')
    assert a.platform == 'linux'

# Generated at 2022-06-23 21:38:43.228418
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:38:44.595872
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path != None


# Generated at 2022-06-23 21:38:46.737133
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    home = path.home()
    assert(home is not None)


# Generated at 2022-06-23 21:38:48.655833
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == 'C:\\Users\\keila'

# Generated at 2022-06-23 21:38:57.604947
# Unit test for constructor of class Path
def test_Path():
    # action
    path = Path()
    root = path.root()
    home = path.home( )
    user = path.user()
    users_folder = path.users_folder()
    dev_dir = path.dev_dir()
    project_dir = path.project_dir()

    # result
    assert root == '/'
    assert home in ['/home', '/Users']
    assert users_folder in ['/home/taneka/Pictures', '/Users/taneka/Pictures']
    assert user in ['/home/oretha', '/Users/oretha']
    assert dev_dir in ['/home/sherrell/Development/Python', '/Users/sherrell/Development/Python']

# Generated at 2022-06-23 21:39:00.259325
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # GIVEN
    paths = Path()

    # WHEN
    assert re.match(r'^/home/\w+/Development/\w+/\w+', paths.project_dir()) is not None

# Generated at 2022-06-23 21:39:01.443256
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:39:04.205974
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:39:06.937318
# Unit test for method user of class Path
def test_Path_user():
    assert Path("linux").user() == '/home/prince'
    assert Path("darwin").user() == '/home/keli'
    assert Path("win32").user() == '\\home\\marlin'
    assert Path("win64").user() == '\\home\\kimmy'


# Generated at 2022-06-23 21:39:08.081927
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print("project dir: " + path.project_dir())


# Generated at 2022-06-23 21:39:09.500707
# Unit test for method home of class Path
def test_Path_home():
    print('Test method home of class Path:')
    path = Path()
    print(path.home())
    print('-'*100)


# Generated at 2022-06-23 21:39:10.738260
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    foo = Path('linux').project_dir()
    print(foo)

test_Path_project_dir()

# Generated at 2022-06-23 21:39:12.551561
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir() != ""

# Generated at 2022-06-23 21:39:15.100058
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(100):
        print(path.users_folder())


# Generated at 2022-06-23 21:39:17.563740
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert len(p.project_dir()) >= 2  # project_dir() should return a string of 2 or more characters
        

# Generated at 2022-06-23 21:39:19.295191
# Unit test for constructor of class Path
def test_Path():
    """Test Path constructor."""
    p = Path()
    actual_output = p.platform
    desired_output = sys.platform
    assert actual_output == desired_output



# Generated at 2022-06-23 21:39:22.218149
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == '/home/jane/Pictures' or p.users_folder() == '/home/cathleen/Pictures'

# Generated at 2022-06-23 21:39:23.571476
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    p=Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:39:24.240868
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())

# Generated at 2022-06-23 21:39:31.928000
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.data import FOLDERS
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.path import Path
    from mimesis.utils import random_datetime
    base = BaseProvider()
    path = Path()

    result = path.users_folder()
    result_elements = result.split('/')

    assert isinstance(result, str)
    assert result_elements[-1] in FOLDERS
    assert len(result_elements) == 4



# Generated at 2022-06-23 21:39:35.446654
# Unit test for constructor of class Path
def test_Path():
    path = Path('linux')
    assert path.root() == '/'
    assert path.home() == '/home'
    assert path.user() != ''
    assert path.users_folder() != ''
    assert path.dev_dir() != ''
    assert path.project_dir() != ''

# Generated at 2022-06-23 21:39:38.617807
# Unit test for method users_folder of class Path
def test_Path_users_folder():

    platform = sys.platform
    p = Path(platform)
    u1 = p.users_folder()
    u2 = p.users_folder()
    print(u1)
    print(u2)
    assert u1 != u2

# Generated at 2022-06-23 21:39:42.055613
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    home_expect = str(PureWindowsPath() / 'home') if 'win' in sys.platform \
                  else str(PurePosixPath() / 'home')
    assert home == home_expect

# Generated at 2022-06-23 21:39:45.479159
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    assert isinstance(dev_dir, str)
    assert '/home/' in dev_dir
    assert '/Development/' in dev_dir
    assert '/Python/' in dev_dir
    assert len(dev_dir) > 23


# Generated at 2022-06-23 21:39:47.194178
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    actual = Path().project_dir()
    expected = '/home/taneka/Development/Python/mimesis'
    assert actual == expected


# Generated at 2022-06-23 21:39:47.956387
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:39:50.630263
# Unit test for method home of class Path
def test_Path_home():
    """Test method home of class Path."""
    pathName = Path("linux")
    result = pathName.home()
    assert result == '/home'


# Generated at 2022-06-23 21:39:53.001326
# Unit test for method user of class Path
def test_Path_user():
    for i in range(50):
        a = Path()
        print(a.user())



# Generated at 2022-06-23 21:39:55.216626
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert len(path.user()) >= 7


# Generated at 2022-06-23 21:39:56.257769
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path('linux').users_folder() == '/home/lashaunda/Pictures'

# Generated at 2022-06-23 21:39:58.461102
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    print(dev_dir)
    return


# Generated at 2022-06-23 21:40:00.537575
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    expected = '/home'
    assert result == expected


# Generated at 2022-06-23 21:40:02.537044
# Unit test for method user of class Path
def test_Path_user():
    print("\n{}".format(Path().user()))


# Generated at 2022-06-23 21:40:04.476952
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()
    return True

# Generated at 2022-06-23 21:40:08.386698
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.seed(0)
    output = path.home()
    assert output == '/home'
    path.seed(1)
    output = path.home()
    assert output == '/home'



# Generated at 2022-06-23 21:40:09.842102
# Unit test for method user of class Path
def test_Path_user():
    assert Path.user(Path()) == '/home/oretha'



# Generated at 2022-06-23 21:40:11.423515
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    p_users_folder = p.users_folder()
    assert p_users_folder == '/home/taneka/Pictures'
    print(p_users_folder)
    

# Generated at 2022-06-23 21:40:13.945059
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:40:15.253000
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())