

# Generated at 2022-06-23 21:30:14.447039
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()

# Generated at 2022-06-23 21:30:20.488381
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    dev_dir = p.dev_dir()
    project_dir = p.project_dir()
    if user:
        print(user)
    else:
        print('The path to the user is not created')
    if dev_dir:
        print(dev_dir)
    else:
        print('The path to the dev directory is not created')
    if project_dir:
        print(project_dir)
    else:
        print('The path to the project is not created')
    
test_Path_user()

# Generated at 2022-06-23 21:30:23.487702
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    if Path().users_folder() in \
            ['/bin/linux', '/bin/darwin', '/bin/win32', '/bin/win64']:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:30:24.756009
# Unit test for constructor of class Path
def test_Path():
    path=Path()
    assert path.home()!=None

# Generated at 2022-06-23 21:30:26.759822
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path().dev_dir()
    assert isinstance(p, str)

# Generated at 2022-06-23 21:30:28.352527
# Unit test for constructor of class Path
def test_Path():
    pathObj = Path()
    assert pathObj.platform is not None

# Generated at 2022-06-23 21:30:30.354573
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj=Path()
    assert obj.dev_dir() == '/home/christiane/Development/Io'

# Generated at 2022-06-23 21:30:31.482126
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == "/home"


# Generated at 2022-06-23 21:30:35.057678
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/reid/Development/C'


# Generated at 2022-06-23 21:30:36.068477
# Unit test for method home of class Path
def test_Path_home():
    print(Path().home())


# Generated at 2022-06-23 21:30:39.427066
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("Test method dev_dir of class Path ...")
    path = Path()
    print("path.dev_dir() = ", path.dev_dir())
    print("Test method dev_dir of class Path [DONE]")


# Generated at 2022-06-23 21:30:40.941103
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:30:46.815113
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path('linux').home() == '/home'
    assert Path('darwin').home() == '/Users'
    assert Path('win32').home() == 'C:\\Users'
    assert Path('win64').home() == 'C:\\Users'


# Generated at 2022-06-23 21:30:48.346864
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    while(True):
        print (Path().project_dir())
        input()

# Generated at 2022-06-23 21:30:49.631849
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    for i in range(10):
        assert path.home() in ['/home', 'C:/Users']


# Generated at 2022-06-23 21:30:50.765053
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root().replace('\\', '/') == '/'


# Generated at 2022-06-23 21:30:53.135084
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    # assert isinstance(path.root(), str)
    print(path.root())


# Generated at 2022-06-23 21:31:03.123220
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Initialize attributes
    _method_name = 'project_dir'
    _class_name = 'Path'
    _platform = 'linux'
    _args = []
    _kwargs = {}
    _obj = Path(_platform, *_args, **_kwargs)
    # Get expected result
    _expected = _obj.random.choice(FOLDERS)
    # Get actual result
    _actual = getattr(_obj, _method_name)()
    # Compare
    assert _actual == _expected, 'Object: {}; Method: {}; Actual Result: {}; Expected Result: {}'.format(_class_name, _method_name, _actual, _expected)

# Generated at 2022-06-23 21:31:04.107489
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:05.026283
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:09.328198
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import SpecialWord
    path = Path()
    result = path.home()
    if path.platform == SpecialWord.LINUX.value:
        assert result == '/home'
    elif path.platform == SpecialWord.DARWIN.value:
        assert result == '/Users'
    elif path.platform == SpecialWord.WINDOWS.value:
        assert result == 'C:\\Users'

# Generated at 2022-06-23 21:31:11.742547
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    result = provider.home()
    print(result)



# Generated at 2022-06-23 21:31:12.180798
# Unit test for constructor of class Path
def test_Path():
    print(Path())

# Generated at 2022-06-23 21:31:14.186601
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pth = Path()
    assert isinstance(pth.users_folder(), str)

# Generated at 2022-06-23 21:31:15.893094
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for _ in range(10):
        path_ = path.users_folder()
        assert len(path_) > 0

# Generated at 2022-06-23 21:31:17.608968
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    f = Path()
    print(f.project_dir())


# Generated at 2022-06-23 21:31:21.578080
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.builtins import Path
    from mimesis.enums import Platform
    p1 = Path(platform = Platform.WINDOWS)
    p2 = Path(platform = Platform.LINUX)
    assert p1.home() == 'C:\\Users'
    assert p2.home() == '/home'

# Generated at 2022-06-23 21:31:23.366790
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == r'C:\Users\Administrator\Development\JavaScript\fountain'

# Generated at 2022-06-23 21:31:24.702685
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() == '/home/taneka/Pictures'

# Generated at 2022-06-23 21:31:26.872089
# Unit test for method home of class Path
def test_Path_home():
    path = Path() # instance of class Path
    assert path.home() == "/home"


# Generated at 2022-06-23 21:31:29.132332
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:31:35.880337
# Unit test for method user of class Path
def test_Path_user():
    assert Path._user() in ['/home/karin',
                            '/home/wilhemina',
                            '/home/florinda',
                            '/home/taylor',
                            '/home/terrance',
                            '/home/shakira',
                            '/home/elsie',
                            '/home/dolly',
                            '/home/abbey',
                            '/home/carina']


# Generated at 2022-06-23 21:31:39.144847
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == "/home/lelah/Dev/RUBY"


# Generated at 2022-06-23 21:31:41.248668
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    mimesis = Path()
    result = mimesis.project_dir()
    print(result)  # /home/tameika/Development/Python/turtle
    return result

# Generated at 2022-06-23 21:31:43.498625
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    expected = '/home/taneka/Dev/Python/flask'
    actual = p.dev_dir()

    assert expected == actual

# Generated at 2022-06-23 21:31:44.471967
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir()

# Generated at 2022-06-23 21:31:45.825616
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)


# Generated at 2022-06-23 21:31:46.844906
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    Path.users_folder(Path)


# Generated at 2022-06-23 21:31:49.865623
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # create an instance of class Path
    path = Path('win32')
    # print the result of method dev_dir of class Path
    print(path.dev_dir())


# Generated at 2022-06-23 21:31:50.957585
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    dir = p.project_dir()
    assert p.platform in dir


# Generated at 2022-06-23 21:31:52.320039
# Unit test for method root of class Path
def test_Path_root():
    provider = Path()
    root = provider.root()
    assert root == '/'
    assert isinstance(root, str)


# Generated at 2022-06-23 21:31:54.327564
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    res = path.user()
    assert res == "/home/elva" or res == r"C:\Users\leatrice"


# Generated at 2022-06-23 21:31:56.060902
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:32:00.223240
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    obj = path.user(max_chars=10)
    assert isinstance(obj, str)
    assert obj.startswith('/home/')
    assert len(obj) == 11

# Generated at 2022-06-23 21:32:01.660666
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:32:03.467816
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    Path().project_dir()
# Output: /home/kimberly/Dev/Perl/derisive


# Generated at 2022-06-23 21:32:04.527469
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    return Path().project_dir()
print(test_Path_project_dir())

# Generated at 2022-06-23 21:32:07.354182
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p1 = Path()
    p2 = Path()
    path1 = p1.users_folder()
    path2 = p2.users_folder()
    assert path1 != path2


# Generated at 2022-06-23 21:32:09.101909
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.dev_dir()


# Generated at 2022-06-23 21:32:12.547196
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    path = p.users_folder()
    assert isinstance(path, str)
    assert path != ''
    assert path.count('/') > 1



# Generated at 2022-06-23 21:32:16.979177
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """
    Test dev_dir function of class Path.
    """
    path_obj = Path()
    dev_dir = path_obj.dev_dir()
    assert dev_dir == '/home/matthew/Dev/Go'

# Generated at 2022-06-23 21:32:18.955378
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert isinstance(home, str)


# Generated at 2022-06-23 21:32:20.302906
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None

# Generated at 2022-06-23 21:32:21.721898
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:32:23.811942
# Unit test for method user of class Path
def test_Path_user():
    """Testing method user of class Path."""
    b = Path()
    for i in range(100):
        print(b.user())


# Generated at 2022-06-23 21:32:31.002344
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import ProgrammingLanguage
    from mimesis.providers.filesystem import FileSystem

    file_system = FileSystem()

    for i in range(10):
        path_to_project = file_system.path.project_dir()

        # check if path to project is contained in user directory
        user_dir = file_system.path.user()
        assert user_dir in path_to_project

        # check if path to project is contained in development directory
        development_dir = file_system.path.dev_dir()
        assert development_dir in path_to_project

        # check if path to project ends with project name
        project_name = file_system.file.project_name()
        assert path_to_project.endswith(project_name)

# Generated at 2022-06-23 21:32:37.843635
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print("Generate a root dir path:")
    print(path.root())
    print("Generate a home path:")
    print(path.home())
    print("Generate a random path to user folders:")
    print(path.users_folder())
    print("Generate a random path to development directory:")
    print(path.dev_dir())
    print("Generate a random path to project directory:")
    print(path.project_dir())

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:32:39.360043
# Unit test for method home of class Path
def test_Path_home():
  path = Path()
  assert path.home() == '/home'



# Generated at 2022-06-23 21:32:44.637044
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.platform = 'linux'
    assert p.Meta.name == 'path'
    p.Meta.name == 'path'
    assert p._pathlib_home == PurePosixPath('/home')
    p._pathlib_home == PurePosixPath('/home')
    p.platform = 'win32'
    assert p._pathlib_home == PureWindowsPath('C:/Home')
    p._pathlib_home == PureWindowsPath('C:/Home')


# Generated at 2022-06-23 21:32:45.702179
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() is not None

# Generated at 2022-06-23 21:32:56.273993
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    # Default platform
    p = Path()
    user = p.user()
    assert isinstance(user, str)
    assert '/' in user, 'Path must have a delimiter.'
    assert user.endswith('/'), 'Path must have a delimiter at the end.'

    # Linux
    p = Path('linux')
    user = p.user()
    assert isinstance(user, str)
    assert '/' in user, 'Path must have a delimiter.'
    assert user.endswith('/'), 'Path must have a delimiter at the end.'

    # MacOS
    p = Path('darwin')
    user = p.user()
    assert isinstance(user, str)
    assert '/' in user, 'Path must have a delimiter.'
    assert user

# Generated at 2022-06-23 21:32:58.041901
# Unit test for method root of class Path
def test_Path_root():
    result = Path().root()
    assert result in ['/', 'C:\\Users']


# Generated at 2022-06-23 21:33:04.246570
# Unit test for method home of class Path
def test_Path_home(): 
    import datetime 
    import pytest 
    from mimesis.enums import Gender 
    seed = datetime.datetime(2020, 1, 1) 
    path = Path(seed=seed) 
    str_value = path.home() 
    type_of_str_value = type(str_value) 
    assert type_of_str_value is str 
    assert str_value == '/home' 


# Generated at 2022-06-23 21:33:10.696950
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.dev_dir() == '/home/Keesha/Development/Python'
    assert p.project_dir() == '/home/Keesha/Development/Python/Dot-com'
    assert p.home() == '/home'
    assert p.user() == '/home/yuette'
    assert p.root() == '/'

# Generated at 2022-06-23 21:33:13.159267
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test for method users_folder of class Path."""
    path = Path()
    # print(path.users_folder())


# Generated at 2022-06-23 21:33:17.289895
# Unit test for constructor of class Path
def test_Path():
    """Test Path."""
    assert Path()
    assert Path(platform='linux')
    assert Path(platform='darwin')
    assert Path(platform='win32')
    assert Path(platform='win64')


# Generated at 2022-06-23 21:33:19.378825
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    path = p.project_dir()
    print(path)
    assert True

# Generated at 2022-06-23 21:33:21.418847
# Unit test for method home of class Path
def test_Path_home():
    file_path = Path().home() # Create a file path
    return file_path
# path generated is /home


# Generated at 2022-06-23 21:33:23.456231
# Unit test for method root of class Path
def test_Path_root():
    Path().root() == str(PurePosixPath('/')) or str(PureWindowsPath('C:\\'))


# Generated at 2022-06-23 21:33:24.826408
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert type(path.user()) == str

# Generated at 2022-06-23 21:33:28.885777
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.providers.path import Path
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:33:31.852942
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert isinstance(home, str)
    assert home is not ''
    assert home[0] == '/'


# Generated at 2022-06-23 21:33:33.277035
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # p = Path()
    # print(p.dev_dir())
    assert Path().dev_dir() == '/home/elizabath/Development/Javascript'


# Generated at 2022-06-23 21:33:34.540384
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())


# Generated at 2022-06-23 21:33:35.601415
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:33:39.891722
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test of method users_folder of class Path."""
    p = Path()
    folders = list(set(p.users_folder() for i in range(5000)))
    assert len(folders) == len(FOLDERS)


# Generated at 2022-06-23 21:33:41.451875
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test for users_folder method of class Path.

    :return: Path.
    """
    p = Path()
    print(p.users_folder())



# Generated at 2022-06-23 21:33:42.533796
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()

# Generated at 2022-06-23 21:33:44.112301
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert isinstance(p.users_folder(), str)


# Generated at 2022-06-23 21:33:45.468543
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:33:47.584605
# Unit test for method root of class Path
def test_Path_root():
    pathTest = Path
    assert pathTest.Meta.name == 'path'
    assert pathTest.root() in ['/']


# Generated at 2022-06-23 21:33:49.120601
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert type(path.project_dir()) == str


# Generated at 2022-06-23 21:33:51.476587
# Unit test for method user of class Path
def test_Path_user():
    """Test for Path.user() method."""
    assert Path().user()



# Generated at 2022-06-23 21:33:53.771544
# Unit test for method user of class Path
def test_Path_user():
    user = Path('win32').user()
    assert user == 'C:\\Users\\mozes', 'unexpected user name'

# Generated at 2022-06-23 21:33:54.948028
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p


# Generated at 2022-06-23 21:33:56.655782
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert isinstance(p.users_folder(), str)

# Generated at 2022-06-23 21:33:57.962247
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/dierdre/Dev/Python'

# Generated at 2022-06-23 21:34:00.470895
# Unit test for method home of class Path
def test_Path_home():
    obj = Path()
    result = obj.home()
    assert result == '/home'


# Generated at 2022-06-23 21:34:01.863165
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    x = Path()
    y = x.project_dir()
    print(y)
    # assert len(y) > 10


# Generated at 2022-06-23 21:34:04.833941
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()
    print(path.home())
    '''結果: /home'''


# Generated at 2022-06-23 21:34:06.251706
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() != Path().project_dir()

# Generated at 2022-06-23 21:34:08.361563
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path.project_dir(Path) == '/home/malcom/Development/C/edify'

# Generated at 2022-06-23 21:34:09.869462
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() != Path().users_folder()


# Generated at 2022-06-23 21:34:11.263598
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()


# Generated at 2022-06-23 21:34:16.909673
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Category
    from mimesis.integrity import Field
    from mimesis.providers.files import Files
    from mimesis.providers.filesystem import Filesystem

    path = Path()
    assert path.users_folder() in Filesystem().folders()
    assert path.users_folder() in Files().folders()

    user_folder = path.users_folder()
    assert len(Field.check_field(user_folder, Category.PATH)) == 0

# Generated at 2022-06-23 21:34:19.007866
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    assert p.user() == "/home/sandee"


# Generated at 2022-06-23 21:34:20.746962
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path()
    path.user()


# Generated at 2022-06-23 21:34:21.964808
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:34:24.261071
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_path = path.dev_dir()
    print(dev_path)
    print(type(dev_path))
    assert isinstance(dev_path, str)


# Generated at 2022-06-23 21:34:26.473583
# Unit test for method root of class Path
def test_Path_root():
    obj = Path(platform='linux')
    assert obj.root() == '/'


# Generated at 2022-06-23 21:34:28.119370
# Unit test for method root of class Path
def test_Path_root():
    p=Path("/")
    assert p == "/"


# Generated at 2022-06-23 21:34:30.232735
# Unit test for method root of class Path
def test_Path_root():
    provider = Path()
    assert len(provider.root()) >= len(provider.home())


# Generated at 2022-06-23 21:34:32.193037
# Unit test for method root of class Path
def test_Path_root():
    data = Path()
    result = data.root()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:34:35.131400
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range(1,50):
        print(p.user())

# Generated at 2022-06-23 21:34:37.060310
# Unit test for method home of class Path
def test_Path_home():
    path1 = Path()
    path1.home()
    assert path1 is not None


# Generated at 2022-06-23 21:34:38.073809
# Unit test for method user of class Path
def test_Path_user(): assert isinstance(Path().user(), str)


# Generated at 2022-06-23 21:34:40.571429
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    print(root)


# Generated at 2022-06-23 21:34:41.995745
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == "/"


# Generated at 2022-06-23 21:34:44.698648
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.providers.path import Path
    path_obj = Path()
    print(path_obj.dev_dir()) # /home/rossi/Development/NodeJS

# Generated at 2022-06-23 21:34:48.827354
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    if p.platform == 'linux' or 'darwin':
        assert p.root() == '/'
    if p.platform == 'windows' or 'win64':
        assert p.root() == 'C:\\'


# Generated at 2022-06-23 21:34:51.367262
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    for i in range(10):
        print(path.dev_dir())

# Generated at 2022-06-23 21:34:53.000676
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:34:55.166737
# Unit test for method user of class Path
def test_Path_user():
    user = Path().user()
    assert '/home/sherika' == user


# Generated at 2022-06-23 21:34:58.098911
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    global path_dev_dir
    path_dev_dir = "/home/sherrell/Development/Python"
    assert(Path.dev_dir() == path_dev_dir)

 

# Generated at 2022-06-23 21:35:00.700173
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    file_path = path.users_folder()
    assert(isinstance(file_path, str)) is True


# Generated at 2022-06-23 21:35:03.176882
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    regex = re.compile('/home/[a-z]+/Pictures')
    assert regex.match(path.users_folder())

# Generated at 2022-06-23 21:35:05.360301
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path('win32')
    p.random.seed(0)
    path = p.dev_dir()
    return path


# Generated at 2022-06-23 21:35:06.979314
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())  # return: /home/oretha


# Generated at 2022-06-23 21:35:09.365939
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root


# Generated at 2022-06-23 21:35:10.437809
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:35:17.161514
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() in ['/home/oretha', '/home/kati', '/home/jayde', '/home/shanel', '/home/taneka', '/home/stacy', '/home/clifford', '/home/denis', '/home/daryl', '/home/araf', '/home/stacey', '/home/vinnie', '/home/shayla', '/home/christy', '/home/ralph', '/home/zephania']


# Generated at 2022-06-23 21:35:19.672367
# Unit test for method user of class Path
def test_Path_user():
    p=Path()
    assert type(p.user()) is str 


# Generated at 2022-06-23 21:35:21.716418
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    res = path.home()
    assert path.home() == res
    


# Generated at 2022-06-23 21:35:23.944252
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    path = provider.user()
    assert isinstance(path, str)


# Generated at 2022-06-23 21:35:25.378576
# Unit test for method root of class Path
def test_Path_root():
    # Checking if the root directory name is '/'
    assert Path().root() == '/'

# Generated at 2022-06-23 21:35:27.965550
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for _ in range(10):
        user = path.user()
        assert isinstance(user, str)
        assert user != ''


# Generated at 2022-06-23 21:35:29.686025
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    print(users_folder)


# Generated at 2022-06-23 21:35:39.529208
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    provider = Path()
    result = provider.users_folder()
    assert result in [
        '/home/clare/Music',
        '/home/jeffrey/Pictures',
        '/home/leonidas/Documents',
        '/home/makayla/Videos',
        '/home/taneka/Pictures',
        '/home/elouise/Music',
        '/home/oretha/Pictures',
        '/home/taneka/Videos',
        '/home/elouise/Documents',
        '/home/oretha/Documents',
        '/home/taneka/Music',
        '/home/jerilyn/Pictures',
        '/home/oretha/Music',
        '/home/taneka/Documents',
        '/home/jerilyn/Music',
    ]
    assert result != '/home/oretha/Pictures'

# Generated at 2022-06-23 21:35:41.088793
# Unit test for method home of class Path
def test_Path_home():
    pc = Path()
    assert type(pc.home()) == str
    assert len(pc.home()) > 0


# Generated at 2022-06-23 21:35:52.136322
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    list_result = []
    for i in range(100):
        list_result.append(p.users_folder())
    if 'linux' in sys.platform:
        assert list_result[0] == '/home/darnell/Music'
        assert list_result[1] == '/home/hiram/Pictures'
        assert list_result[2] == '/home/kelvin/Videos'
        assert list_result[3] == '/home/carlos/Pictures'
        assert list_result[4] == '/home/kirk/Documents'
        assert list_result[5] == '/home/darnell/Pictures'
        assert list_result[6] == '/home/darnell/Documents'

# Generated at 2022-06-23 21:35:54.996110
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    for i in range(10):
        print(p.users_folder())

if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-23 21:35:57.911627
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    path = Path()
    assert '/home/oretha/Development/Java/sundial' == path.project_dir()

# Generated at 2022-06-23 21:35:58.496253
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.home()

# Generated at 2022-06-23 21:36:00.648642
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    print(users_folder)
    return users_folder


# Generated at 2022-06-23 21:36:02.744406
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:36:06.856789
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('linux')
    result = p.project_dir()
    print(result)
    assert result != ''

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:36:07.927599
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() != None


# Generated at 2022-06-23 21:36:10.496351
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    assert isinstance(result, str)
    assert result != None
    assert len(result) != 0
    assert result == '/home/sidney/Dev/C++/quasar'

# Generated at 2022-06-23 21:36:12.154573
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root == '/'


# Generated at 2022-06-23 21:36:12.932564
# Unit test for constructor of class Path
def test_Path():
    Path()

# Generated at 2022-06-23 21:36:14.666464
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())

# Generated at 2022-06-23 21:36:18.276317
# Unit test for method user of class Path
def test_Path_user():
    paths = Path()
    users = []
    for _ in range(1, 5):
        users.append(paths.user())
    print(users)
    assert len(users) == 4
    assert users[0] == '/Users/mellissa'


# Generated at 2022-06-23 21:36:20.596108
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert isinstance(result, str)
    assert result == '/home/oretha'



# Generated at 2022-06-23 21:36:22.470214
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert type(path.root()) == str


# Generated at 2022-06-23 21:36:24.289068
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p =  Path()
    assert len(p.project_dir()) > 5


# Generated at 2022-06-23 21:36:27.907277
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    project_dir = Path().project_dir()
    print("project_dir:", project_dir)
    assert project_dir == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:36:30.237392
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == r"/home/coy/Development/PHP"
    assert Path().dev_dir() == r"/home/genesis/Development/C"

# Generated at 2022-06-23 21:36:32.658092
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("Generate a random path to development directory.")
    global p
    p = Path()
    for i in range(4):
        print(p.dev_dir())


# Generated at 2022-06-23 21:36:34.499518
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert len(path.root()) == 1


# Generated at 2022-06-23 21:36:37.142122
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    a = Path(platform = 'win32')
    print(a.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:36:40.508927
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    l = []
    for i in range(100):
        s = p.users_folder()
        l.append(s)
    return len(set(l)) == 100

# Generated at 2022-06-23 21:36:42.010316
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:36:42.908933
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:36:47.445528
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("Start to test method project_dir of class Path:")
    path = Path()
    print(path.project_dir())
    print(path.project_dir())
    print(path.project_dir())



# Generated at 2022-06-23 21:36:49.978115
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:36:52.523114
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None
    assert type(p) == Path
    assert p._pathlib_home is not None
    assert type(p._pathlib_home) == PurePosixPath or PureWindowsPath

# Generated at 2022-06-23 21:36:53.371386
# Unit test for constructor of class Path
def test_Path():
    print(Path())

# Generated at 2022-06-23 21:36:54.519917
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir() == '/home/sherrell/Development/Python'

# Generated at 2022-06-23 21:36:55.843549
# Unit test for method home of class Path
def test_Path_home():
    assert len(Path().home()) >= 5



# Generated at 2022-06-23 21:36:57.490494
# Unit test for method home of class Path
def test_Path_home():
    # Test case:
    # Create an object
    path = Path()
    assert isinstance(path.home(), str)


# Generated at 2022-06-23 21:36:59.313307
# Unit test for constructor of class Path
def test_Path():
    test = Path(platform=sys.platform)
    assert test != None

# Generated at 2022-06-23 21:37:09.129776
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

if __name__ == '__main__':
    # Unit test for method project_dir of class Path
    print(test_Path_project_dir.__doc__)
    print(test_Path_project_dir())
    # Unit test for method  dev_dir of class Path
    print(Path.dev_dir.__doc__)
    print(Path().dev_dir())
    # Unit test for method  users_folder of class Path
    print(Path.users_folder.__doc__)
    print(Path().users_folder())
    # Unit test for method  user of class Path
    print(Path.user.__doc__)
    print(Path().user())
    # Unit test for method  home of class Path

# Generated at 2022-06-23 21:37:11.387531
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert all(isinstance(x, str) for x in p.root())


# Generated at 2022-06-23 21:37:14.202078
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.__class__.__name__ == 'Path'


# Generated at 2022-06-23 21:37:19.119122
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage
    path = Path()
    result = path.dev_dir()
    assert result[:result.find("Py")] == "/home/sherley/Development/P"
    assert path.dev_dir(stack=ProgrammingLanguage.PHP)[-4:] == "PHP/"

# Generated at 2022-06-23 21:37:20.153764
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:37:21.053034
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p


# Generated at 2022-06-23 21:37:25.966272
# Unit test for method home of class Path
def test_Path_home():
    """Test method home of class Path."""
    from mimesis.enums import Platform
    from pathlib import Path
    # Expected: PureWindowsPath('C:\\Users')
    homer = Path(Platform.WINDOWS.value)
    assert homer.home() == 'C:\\Users'


# Generated at 2022-06-23 21:37:27.678194
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:37:30.683007
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    folder = Path().users_folder()
    assert (PurePosixPath(folder) or PureWindowsPath(folder)).is_absolute()
    assert len(folder.split('/')) >= 3


# Generated at 2022-06-23 21:37:32.644267
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    try:
        Path().root()
    except TypeError as e:
        raise

# Generated at 2022-06-23 21:37:34.292707
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/earnest/Development/Ruby'


# Generated at 2022-06-23 21:37:35.980736
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:37:37.356899
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())
    assert path.root() == "/" or path.root() == "\\"


# Generated at 2022-06-23 21:37:39.991233
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    dev_dir = path.dev_dir()
    project_dir = path.project_dir()
    assert dev_dir in project_dir

# Generated at 2022-06-23 21:37:41.769616
# Unit test for method user of class Path
def test_Path_user():
    if __name__ == '__main__':
        print(Path().user())



# Generated at 2022-06-23 21:37:43.260633
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert isinstance(root, str)


# Generated at 2022-06-23 21:37:45.234922
# Unit test for constructor of class Path
def test_Path():
    pass

# Generated at 2022-06-23 21:37:47.679254
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    assert isinstance(dev_dir, str)
    assert len(dev_dir) > 0
    assert dev_dir == dev_dir.lower()


# Generated at 2022-06-23 21:37:49.664112
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    assert path.user() == '/home/nisha'

# Generated at 2022-06-23 21:37:51.174163
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:37:55.663516
# Unit test for constructor of class Path
def test_Path():
    from mimesis.data import PLATFORMS

    PLATFORMS_KEYS_LIST = list(PLATFORMS.keys())
    for platform in PLATFORMS_KEYS_LIST:
        try:
            Path(platform)
        except:
            raise Exception('Error in constructor, platform : ' + platform)

# Generated at 2022-06-23 21:38:03.620537
# Unit test for constructor of class Path
def test_Path():
    # Different constructors of Path class
    path = Path()
    assert isinstance(path, Path)
    path = Path(platform='linux')
    assert isinstance(path, Path)
    path = Path(platform='darwin')
    assert isinstance(path, Path)
    path = Path(platform='win32')
    assert isinstance(path, Path)
    path = Path(platform='win64')
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:38:05.995055
# Unit test for method user of class Path
def test_Path_user():
    obj = Path()
    for x in range(0, 10):
        print(obj.user())


# Generated at 2022-06-23 21:38:10.458666
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""
    with Path() as p:
        assert p.platform is sys.platform
        assert isinstance(p.platform, str)
        assert isinstance(p._pathlib_home, PurePosixPath)


# Generated at 2022-06-23 21:38:14.141962
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert path.user() != ''
    assert len(path.user()) > 1
    assert path.user().count('/') == 2


# Generated at 2022-06-23 21:38:17.871483
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path._pathlib_home.parts == ('', 'home')


# Generated at 2022-06-23 21:38:19.155251
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    a = p.project_dir()
    print(a)

# Generated at 2022-06-23 21:38:25.187890
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage
    i = 0
    while i < 10000:
        path_tool = Path()
        p = path_tool.dev_dir()
        if p.endswith(ProgrammingLanguage.PYTHON.value):
            if p.startswith(PLATFORMS['win32']['home']):
                assert '\\' in p
            else:
                assert '/' in p
            assert path_tool._pathlib_home.parts[0] in p
            i += 1


# Generated at 2022-06-23 21:38:27.614797
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(10):
        assert Path().project_dir() == '/home/arnoldo/Dev/Django/nucleator'


# Generated at 2022-06-23 21:38:28.224027
# Unit test for method home of class Path
def test_Path_home():
    assert len(Path().home()) > 0

# Generated at 2022-06-23 21:38:29.402087
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/taneka'

# Generated at 2022-06-23 21:38:32.269996
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.dev_dir() == str(p._pathlib_home / p.user() / 'Development' / p.random.choice(PROGRAMMING_LANGS))

# Generated at 2022-06-23 21:38:33.741556
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    obj = Path()
    sample = obj.project_dir()
    assert isinstance(sample,str)

# Generated at 2022-06-23 21:38:38.861167
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.debug(True)

    assert p.home() is not None
    assert p.user() is not None
    assert p.users_folder() is not None
    assert p.dev_dir() is not None
    assert p.project_dir() is not None
    assert p.root() is not None

# Generated at 2022-06-23 21:38:39.869680
# Unit test for method home of class Path
def test_Path_home():
    Path.home()


# Generated at 2022-06-23 21:38:43.026414
# Unit test for method home of class Path
def test_Path_home():
    assert Path('darwin').home() == '/home'
    assert Path('linux').home() == '/home'
    assert Path('win32').home() == 'C:\\Users'
    assert Path('win64').home() == 'C:\\Users'

# Generated at 2022-06-23 21:38:45.307169
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:38:46.351975
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:38:49.598872
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.__class__.__name__ == 'Path'


# Test for method root of class Path

# Generated at 2022-06-23 21:38:52.059386
# Unit test for method root of class Path
def test_Path_root():
    p = Path('linux')
    assert p.root() == '/'
    # AssertionError: '/' != ''


# Generated at 2022-06-23 21:39:00.587711
# Unit test for method dev_dir of class Path
def test_Path_dev_dir(): # type: ignore
    from mimesis.data import PROGRAMMING_LANGS
    p = Path()
    prog_langs = [
        prog_lang.lower() for prog_lang in PROGRAMMING_LANGS
    ]
    user = p.user()
    folder = p.random.choice(['Development', 'Dev'])
    stack = p.random.choice(PROGRAMMING_LANGS)
    dev_dir = "/" + user + "/" + folder + "/" + stack

    assert dev_dir in p.dev_dir()
    assert len(p.dev_dir().split('/')) == 4



# Generated at 2022-06-23 21:39:04.770270
# Unit test for constructor of class Path
def test_Path():
    class Meta:
        name = 'path'
    path_obj = Path()
    assert path_obj.__class__.Meta.name == 'path'
    assert path_obj.platform != None


# Generated at 2022-06-23 21:39:07.209127
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    for i in range(0, 100):
        assert p.dev_dir() == "/home/michaella/Development/JavaScript"


# Generated at 2022-06-23 21:39:11.326010
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Testing for method users_folder of class Path
    """
    path = Path()
    for i in range(100):
        assert path.users_folder() # check that it is not null
        assert path.users_folder()[0] == '\\' or path.users_folder()[0] == '/' # check that it starts with \ or /



# Generated at 2022-06-23 21:39:14.215578
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    test_path = Path()
    test_path.user()
    test_path.users_folder()


# Generated at 2022-06-23 21:39:16.123580
# Unit test for method user of class Path
def test_Path_user():
    user = Path().user()
    assert user, isinstance(user, str)


# Generated at 2022-06-23 21:39:25.421644
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Initializing Path object with the platform is windows
    path = Path(platform = 'win32')
    for i in range(10):
        # Path to development directory will be generated
        path_dev_dir = path.dev_dir()
        print(path_dev_dir)
        # Path will be changed to the parent path 
        path_parent = path_dev_dir.rsplit('/', 1)[0]
        print(path_parent)
        # Path will be changed to the parent path of the parent path
        path_grandpa = path_parent.rsplit('/', 1)[0]
        print(path_grandpa)
        # Checking if 'Development' folder is in path_grandpa

# Generated at 2022-06-23 21:39:27.197090
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    gen = Path()
    print(gen.project_dir())


# Generated at 2022-06-23 21:39:29.577679
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    print(result)


# Generated at 2022-06-23 21:39:38.966835
# Unit test for method project_dir of class Path

# Generated at 2022-06-23 21:39:41.467592
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    size = 0
    result = [-1]
    for i in range(size):
        result.append(Path.users_folder())
    print(result)


if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-23 21:39:43.156271
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert '/home/michiko/Development/Python' == p.dev_dir()


# Generated at 2022-06-23 21:39:44.359447
# Unit test for method home of class Path
def test_Path_home():
    """Test method home of class Path."""
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:39:45.516035
# Unit test for method project_dir of class Path
def test_Path_project_dir():
     a = Path().project_dir()
     print(a)

# Generated at 2022-06-23 21:39:46.314602
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert path.project_dir()

# Generated at 2022-06-23 21:39:47.406037
# Unit test for constructor of class Path
def test_Path():
    path_obj = Path()
    assert path_obj != None


# Generated at 2022-06-23 21:39:48.191189
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()

# Generated at 2022-06-23 21:39:50.156777
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert('/Development/Python/titanium' in path.project_dir())

# Generated at 2022-06-23 21:39:52.608613
# Unit test for method home of class Path
def test_Path_home():
    data = ['/', '/home']
    assert Path().home() in data


# Generated at 2022-06-23 21:39:55.215300
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    assert result != ''



# Generated at 2022-06-23 21:39:58.112544
# Unit test for method user of class Path
def test_Path_user():
    a = Path('linux')
    print(a.user())
    print(a.dev_dir())
    print(a.project_dir())
    print(a.home())
    print(a.root())

# Generated at 2022-06-23 21:40:00.238807
# Unit test for method home of class Path
def test_Path_home():
    """Checking function path.home()."""
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:40:01.843849
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert len(path.dev_dir()) > 0

# Generated at 2022-06-23 21:40:03.993360
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform="win32")
    assert p is not None


# Generated at 2022-06-23 21:40:06.220777
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.home())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:40:08.176004
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:40:10.504696
# Unit test for method root of class Path
def test_Path_root():
    # Initialization of class Path with the argument None
    p = Path(None)
    print(p.root())


# Generated at 2022-06-23 21:40:12.164410
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:40:14.199439
# Unit test for method home of class Path
def test_Path_home():
    from pathlib import Path
    p = Path()
    path = str(p.home())
    assert Path(path).is_dir()
