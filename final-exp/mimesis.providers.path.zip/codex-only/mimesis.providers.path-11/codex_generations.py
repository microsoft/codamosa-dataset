

# Generated at 2022-06-23 21:30:10.620457
# Unit test for method home of class Path
def test_Path_home():
    from random import randint
    from mimesis import Path
    assert Path().home()


# Generated at 2022-06-23 21:30:13.777547
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    assert dev_dir.find('/home/') == 0

# Generated at 2022-06-23 21:30:14.962003
# Unit test for method root of class Path
def test_Path_root():
    print(Path().root())


# Generated at 2022-06-23 21:30:18.246425
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    _path = Path() 
    if _path.project_dir() == "/home/sherika/Development/Falcon/mercenary":
        print("\033[1;32m OK!\033[1;m")
    else:
        print("\033[1;31m NO.\033[1;m")

# Generated at 2022-06-23 21:30:19.904651
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:30:23.362118
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    cf = {'token_hex':lambda : 'test'}
    p = Path(seed=1, random=cf)
    res = p.project_dir()
    assert res == "/home/Users/Development/Python/test"

# Generated at 2022-06-23 21:30:25.588211
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    assert isinstance(users_folder, str)
    assert '/' in users_folder
    print(users_folder)

# Generated at 2022-06-23 21:30:27.822875
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    assert users_folder is not None

# Generated at 2022-06-23 21:30:30.599906
# Unit test for method root of class Path
def test_Path_root():
    """
    Test method root of class Path
    """
    result = Path().root()
    assert isinstance(result, str)
    assert result == "/"


# Generated at 2022-06-23 21:30:33.874468
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import mimesis
    path = mimesis.Path()
    output = path.project_dir()
    assert path.dev_dir() in output

# Generated at 2022-06-23 21:30:34.649665
# Unit test for method home of class Path
def test_Path_home():
    #
    assert Path.home(Path()) == '/home'

# Generated at 2022-06-23 21:30:39.526709
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    p = Path()
    ans = p.project_dir()
    assert type(ans) == str
    assert len(ans) >= len(p._pathlib_home)
    assert ans[:len(p._pathlib_home)] == str(p._pathlib_home)

# Generated at 2022-06-23 21:30:46.557327
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path._pathlib_home == PurePosixPath('/home')
    assert isinstance(path._pathlib_home, PurePosixPath)
    path = Path(platform='win32')
    assert path._pathlib_home == PureWindowsPath('C:\\Users')
    assert isinstance(path._pathlib_home, PureWindowsPath)
    path = Path(platform='win64')
    assert path._pathlib_home == PureWindowsPath('C:\\Users')
    assert isinstance(path._pathlib_home, PureWindowsPath)
    path = Path(platform='linux')
    assert path._pathlib_home == PurePosixPath('/home')
    assert isinstance(path._pathlib_home, PurePosixPath)
    path = Path(platform='darwin')
    assert path._pathlib

# Generated at 2022-06-23 21:30:47.937310
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:30:48.818409
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:30:57.811172
# Unit test for method root of class Path
def test_Path_root():
    # Test Path(platform='linux')
    path = Path(platform='linux')
    r = path.root()
    sys.platform = 'linux'
    assert r == '/'
    # Test Path(platform='darwin')
    path = Path(platform='darwin')
    r = path.root()
    sys.platform = 'darwin'
    assert r == '/'
    # Test Path(platform='win32')
    path = Path(platform='win32')
    r = path.root()
    sys.platform = 'win32'
    assert r == 'C:\\'
    # Test Path(platform='win64')
    path = Path(platform='win64')
    r = path.root()
    sys.platform = 'win32'
    assert r == 'C:\\'



# Generated at 2022-06-23 21:30:59.962364
# Unit test for method user of class Path
def test_Path_user():
    """
    Test that method 'user' returns path string
    """
    assert len(Path().user()) > 0
# test_Path_user


# Generated at 2022-06-23 21:31:03.555224
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for i in range(5):
        assert Path('linux').dev_dir()
        assert Path('darwin').dev_dir()
        assert Path('win32').dev_dir()
        assert Path('win64').dev_dir()


# Generated at 2022-06-23 21:31:06.495925
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert bool(path.home()) == True
    assert isinstance(path.home(), str) == True
    assert len(path.home()) > 8 == True


# Generated at 2022-06-23 21:31:12.099374
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    if p.platform == 'win32':
        assert p.home() == 'C:\\Users'
        assert p.project_dir().startswith('C:\\Users\\')
    else:
        assert p.home() == '/home'
        assert p.project_dir().startswith('/home/')

# Generated at 2022-06-23 21:31:13.987209
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    assert len(result) > 0

# Generated at 2022-06-23 21:31:15.075755
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print(Path().dev_dir())


# Generated at 2022-06-23 21:31:21.273298
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.root()
    p.home()
    p.user()
    p.users_folder()
    p.dev_dir()
    p.project_dir()
    p.get_locale()
    p.seed()
    p.reset_seed()

# Generated at 2022-06-23 21:31:23.153662
# Unit test for method user of class Path
def test_Path_user():
    id = Path()
    result = id.user()
    assert result == '/home/latonya'


# Generated at 2022-06-23 21:31:25.129150
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir()[:5] == '/home'


# Generated at 2022-06-23 21:31:26.622877
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path=Path()
    assert 'home' in path.users_folder()

# Generated at 2022-06-23 21:31:30.639893
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path(platform = 'linux')
    path.random.choice = lambda x: x[-1]
    assert path.dev_dir() == '/home/sherrell/Development/Python'


# Generated at 2022-06-23 21:31:32.062250
# Unit test for method user of class Path
def test_Path_user():
	path = Path()
	assert isinstance(path.user(), str)


# Generated at 2022-06-23 21:31:34.178025
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert(path.root() == '/')

# Generated at 2022-06-23 21:31:35.757944
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:31:46.030980
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    path.platform == 'linux'
    assert path._pathlib_home.as_posix() == PLATFORMS['linux']['home']
    path.platform == 'darwin'
    assert path._pathlib_home.as_posix() == PLATFORMS['darwin']['home']
    path.platform == 'win32'
    assert path._pathlib_home.as_posix() == PLATFORMS['win32']['home']
    path.platform == 'win64'
    assert path._pathlib_home.as_posix() == PLATFORMS['win64']['home']


# Generated at 2022-06-23 21:31:47.985725
# Unit test for method root of class Path
def test_Path_root():
    expected_output = '/'
    output = Path().root()
    assert output == expected_output


# Generated at 2022-06-23 21:31:48.793003
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/Development/Python/falcon'

# Generated at 2022-06-23 21:31:54.715166
# Unit test for constructor of class Path
def test_Path():
    # pylint: disable=unsubscriptable-object
    assert Path(platform='linux').Meta.name == 'path'
    assert Path(platform='darwin').Meta.name == 'path'
    assert Path(platform='win32').Meta.name == 'path'
    assert Path(platform='win64').Meta.name == 'path'
    assert Path(platform='windows').Meta.name == 'path'
    assert Path(platform='Windows').Meta.name == 'path'


# Generated at 2022-06-23 21:31:58.392003
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() != ''
    assert isinstance(p.home(), str)



# Generated at 2022-06-23 21:32:00.147311
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test for method project_dir of class Path."""
    p = Path('darwin')
    for _ in range(10):
        print(p.project_dir())


# Generated at 2022-06-23 21:32:03.776743
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.root())
    print(path.home())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


test_Path()

# Generated at 2022-06-23 21:32:06.132318
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    p.random.set_seed(1)
    users_folder = p.users_folder()
    assert users_folder == '/home/lulu/Documents'

# Generated at 2022-06-23 21:32:08.185723
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    gen = Path()
    result = gen.dev_dir()
    print(result)


# Generated at 2022-06-23 21:32:11.747451
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    root = path.root()
    assert isinstance(root, str)
    assert len(root) > 0


# Generated at 2022-06-23 21:32:13.551913
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert isinstance(path.root(), str)
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:14.518258
# Unit test for constructor of class Path
def test_Path():
    p = Path("linux")


# Generated at 2022-06-23 21:32:17.507882
# Unit test for constructor of class Path
def test_Path():

    path = Path(platform='linux')

    # Check that we have all fields specified in the constructor
    assert path.platform != None
    assert path._pathlib_home != None
    assert path.random != None

# Generated at 2022-06-23 21:32:25.860636
# Unit test for constructor of class Path
def test_Path():
    from mimesis.data import FOLDERS, PLATFORMS, PROGRAMMING_LANGS, \
        PROJECT_NAMES, USERNAMES
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.path import Path

    path = Path(platform=PLATFORMS['linux']['home'])

    assert path.platform == PLATFORMS['linux']['home']
    assert isinstance(path, Path)
    assert isinstance(path, BaseProvider)

    assert 'linux' in str(path._pathlib_home)
    assert 'home' in str(path._pathlib_home)


# Generated at 2022-06-23 21:32:27.424155
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    # print(path.root())
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:30.606837
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for i in range(1000):
        p = Path()
        users_folder = p.users_folder()

        assert(users_folder !="")


# Generated at 2022-06-23 21:32:35.364571
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.builtins import Path
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    person = Person(gender=Gender.MALE)
    path = Path(platform="linux")
    assert path.user() in ['/home/' + person.username()]


# Generated at 2022-06-23 21:32:37.221688
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path.project_dir() == '/home/genesis/Development/TypeScript/cyborg'

# Generated at 2022-06-23 21:32:41.194874
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    res = path.home()
    assert isinstance(res, str)
    assert res
    assert len(res) == len(path.random.choice(PLATFORMS).get('home')) + 5


# Generated at 2022-06-23 21:32:43.008694
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor."""
    assert Path()


# Generated at 2022-06-23 21:32:45.294940
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.platform == sys.platform
    assert p.home() == '/Users/'


# Generated at 2022-06-23 21:32:48.569052
# Unit test for method user of class Path
def test_Path_user():
    # Instantiate class with the system platform
    newPath = Path()
    # Generate a random path
    result = newPath.user()
    # Get the path parent
    result = result.split("/")[-1].capitalize()
    # Check if it's in the list of username
    assert result in USERNAMES

# Generated at 2022-06-23 21:32:54.787801
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert len(Path().project_dir()) > 0


if __name__ == '__main__':
    # Unit test for method project_dir of class Path
    print(test_Path_project_dir())
    # import itertools
    # i = 0
    # for x in itertools.islice(Path().project_dir(), 0, 5):
    #     print(x)
    #     i += 1
    # print(i)
    # print(Path().project_dir())
    # print(Path().__doc__)
    # print(Path().root())
    # print(Path().home())
    # print(Path().user())
    # print(Path().users_folder())
    # print(Path().dev_dir())
    pass

# Generated at 2022-06-23 21:32:56.892447
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    assert user.endswith('/oretha')


# Generated at 2022-06-23 21:33:07.022255
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:33:09.920808
# Unit test for method root of class Path
def test_Path_root():
    "Unit test for method root of class Path"
    p=Path()
    assert type(p.root())==str


# Generated at 2022-06-23 21:33:19.425868
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print('\nMethod users_folder of class Path')
    users_folders = [
        '/home/micha',
        '/home/natalie',
        '/home/loni',
        '/home/elmo',
        '/home/latonya',
        '/home/cyndy',
        '/home/maragaret',
        '/home/randell',
        '/home/deshawn',
        '/home/lottie',
        '/home/asuncion',
        '/home/louella',
    ]
    path = Path()
    assert path.users_folder() in users_folders


# Generated at 2022-06-23 21:33:20.461771
# Unit test for method user of class Path
def test_Path_user():
    _user = Path().user()
    assert isinstance(_user, str) and len(_user) > 0


# Generated at 2022-06-23 21:33:21.509960
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    for i in range(100):
        print(p.project_dir())

# Generated at 2022-06-23 21:33:23.915974
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path(platform='darwin')
    result = path.users_folder()

    assert isinstance(result, str)
    assert result != ''


# Generated at 2022-06-23 21:33:27.025861
# Unit test for method root of class Path
def test_Path_root():
    pl = Path()
    res = pl.root()
    assert res == 'C:\\' or res == '/'

# Generated at 2022-06-23 21:33:29.891475
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.platform
    path.Meta
    assert path._pathlib_home


# Generated at 2022-06-23 21:33:39.832602
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.builtins import Path, Person
    from mimesis.enums import Gender
    from pathlib import Path as PurePath

    p = Path()
    p2 = Person(Gender.MALE)
    p3 = Person(Gender.FEMALE)

    for i in range(10):
        u = p.users_folder()
        print(u)
        assert PurePath(u).exists()
        assert ((PurePath(u).parts[2] == p2.username() and (PurePath(u).parts[3] in FOLDERS)) or
                (PurePath(u).parts[2] == p3.username() and (PurePath(u).parts[3] in FOLDERS)))


# Generated at 2022-06-23 21:33:41.606701
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    print(result)


# Generated at 2022-06-23 21:33:43.576247
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    result = path.root()
    assert result == '/'



# Generated at 2022-06-23 21:33:45.255076
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:33:47.126382
# Unit test for method home of class Path
def test_Path_home():
    path = Path('darwin')
    assert path.home() == "/Users"



# Generated at 2022-06-23 21:33:49.001620
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())
    assert path.dev_dir() is not None


# Generated at 2022-06-23 21:33:52.223669
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.users_folder())
    print(path.project_dir())

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:33:53.373641
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    print(user)



# Generated at 2022-06-23 21:34:01.547575
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """This method is use to test Path.project_dir()."""
    path = Path("linux")
    assert path.project_dir() == "/home/johnathan/Dev/Python/lumberjack"
    path = Path("darwin")
    assert path.project_dir() == "/Users/hortense/Development/Ruby/overcharge"
    path = Path("win32")
    assert path.project_dir() == "C:\\Users\\barrie\\dev\\Java\\lumberjack"
    path = Path("win64")
    assert path.project_dir() == "C:\\Users\\maryam\\Development\\javascript\\overcharge"


# Generated at 2022-06-23 21:34:02.746154
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() != ""


# Generated at 2022-06-23 21:34:06.488425
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_generator = Path()
    generated_value = path_generator.users_folder()
    assert generated_value is not None and isinstance(generated_value, str)
test_Path_users_folder()


# Generated at 2022-06-23 21:34:12.254001
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of class Path."""
    # Unit test using pytest
    path = Path()
    user = path.user()
    pathlib_home = PureWindowsPath() if 'win' in sys.platform else PurePosixPath()
    pathlib_home /= PLATFORMS[sys.platform]['home']
    assert pathlib_home / path.random.choice(USERNAMES) == user

# Generated at 2022-06-23 21:34:15.466311
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    assert type(user) == str


# Generated at 2022-06-23 21:34:17.721303
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    dir = p.project_dir()
    print(dir)
    assert dir.startswith('/')


# Generated at 2022-06-23 21:34:21.130410
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test for method project_dir of class Path."""
    platform = 'win32'
    p = Path(platform)
    assert '\\home\\' in p.project_dir()
    assert p.project_dir().endswith('\\mercenary')

# Generated at 2022-06-23 21:34:22.322968
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path("linux")
    print(path.project_dir())


# Generated at 2022-06-23 21:34:23.147393
# Unit test for method user of class Path
def test_Path_user():
    pass


# Generated at 2022-06-23 21:34:24.859579
# Unit test for method root of class Path
def test_Path_root():
    path_provider = Path()
    result = path_provider.root()
    assert len(result) != 0


# Generated at 2022-06-23 21:34:27.006707
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:34:29.555625
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path.platform, str)


# Generated at 2022-06-23 21:34:31.865875
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


if __name__ == '__main__':
    test_Path_home()

# Generated at 2022-06-23 21:34:33.793635
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/taneka'


# Generated at 2022-06-23 21:34:35.445398
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert isinstance(path.root(), str)


# Generated at 2022-06-23 21:34:38.066758
# Unit test for method user of class Path
def test_Path_user():
    print('testing method user of class Path')
    path = Path()
    user = path.user()
    assert 'home' in user
    assert '/' in user


# Generated at 2022-06-23 21:34:49.099859
# Unit test for constructor of class Path
def test_Path():
    """Test for class Path"""
    path = Path()
    for i in range(10):
        assert True == issubclass(PurePosixPath, type(path._pathlib_home))
        assert True == issubclass(PurePosixPath, type(path.home()))
        assert True == issubclass(PurePosixPath, type(path.root()))
        assert True == issubclass(PurePosixPath, type(path.users_folder()))
        assert True == issubclass(PurePosixPath, type(path.user()))
        assert True == issubclass(PurePosixPath, type(path.dev_dir()))
        assert True == issubclass(PurePosixPath, type(path.project_dir()))

# Generated at 2022-06-23 21:34:51.312275
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    result = Path().users_folder()
    assert result != None


# Generated at 2022-06-23 21:34:52.946427
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert len(path.user()) >= 6

# Generated at 2022-06-23 21:34:55.114987
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert path.platform == sys.platform

# Generated at 2022-06-23 21:34:57.282491
# Unit test for method home of class Path
def test_Path_home():
    pathObject = Path()
    homePath = pathObject.home()
    assert(homePath == "/home")


# Generated at 2022-06-23 21:35:04.571490
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import ProgrammingLanguage

    path = Path(platform="linux")
    dev_dir = path.dev_dir()
    dev_dir = dev_dir.split('/')
    stack = dev_dir[-1]

    project = path.project_dir()
    project = project.split('/')

    assert project[1] == dev_dir[1]
    assert project[2] == dev_dir[2]
    assert project[3] == stack
    assert project[4] in PROJECT_NAMES


# Generated at 2022-06-23 21:35:06.022408
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user().endswith(('.com', '.net', '.info'))


# Generated at 2022-06-23 21:35:07.025997
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'



# Generated at 2022-06-23 21:35:11.067394
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # create a Path object
    path = Path()
    # get the path
    path.users_folder() # gives a random path
    # /home/taneka/Pictures


# Generated at 2022-06-23 21:35:12.497388
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"


# Generated at 2022-06-23 21:35:16.517300
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.home())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:35:19.280652
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:35:20.400153
# Unit test for method home of class Path
def test_Path_home():
    p = Path("linux")
    assert p.home() == "/home"


# Generated at 2022-06-23 21:35:25.258622
# Unit test for constructor of class Path
def test_Path():
    #p = Path()
    p = Path(platform = 'win32')
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    print(p.__dict__)

# Generated at 2022-06-23 21:35:34.532299
# Unit test for method user of class Path
def test_Path_user():
    import os
    import unittest
    from mimesis import Path

    class TestPath(unittest.TestCase):

        platform = os.name

        def setUp(self):
            self.path = Path(platform=self.platform)

        def test_user(self):
            path = self.path.user()
            self.assertIsInstance(path, str)
            self.assertRegex(path, self.path._pathlib_home / '[a-z]+')

        @unittest.skipUnless(os.name == 'nt', 'These tests run only on Windows')
        def test_user_win(self):
            path = self.path.user()
            self.assertRegex(path, self.path._pathlib_home / '[A-Z]+')

    unittest.main()

# Generated at 2022-06-23 21:35:42.843482
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from unittest import TestCase
    from mimesis.enums import SpecialFolder
    from mimesis.builtins import Paths

    class _TestPaths(TestCase):

        def setUp(self):
            self.path = Path()

        def test_users_folder(self):
            result = self.path.users_folder()
            self.assertTrue(result)

        def test_user(self):
            result = self.path.user()
            self.assertTrue(result)

        def test_home(self):
            result = self.path.home()
            self.assertTrue(result)

        def test_root(self):
            result = self.path.root()
            self.assertTrue(result)

        def test_dev_dir(self):
            result = self.path.dev_dir()


# Generated at 2022-06-23 21:35:45.475103
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    p = Path()
    p.root() == '/'


# Generated at 2022-06-23 21:35:52.885514
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert '/home' in str(path._pathlib_home)

    path = Path('linux')
    assert path.platform == 'linux'
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert '/home' in str(path._pathlib_home)

    path = Path('darwin')
    assert path.platform == 'darwin'
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert '/home' in str(path._pathlib_home)

    path = Path('win32')
    assert path.platform == 'win32'
    assert isinstance(path._pathlib_home, PureWindowsPath)

# Generated at 2022-06-23 21:35:56.306695
# Unit test for constructor of class Path
def test_Path():
    """Unit test for class Path."""
    path = Path()
    assert path.random is not None
    assert path.random.random is not None
    assert path.platform is not None



# Generated at 2022-06-23 21:35:58.839842
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path2 = Path(platform='win64')
    print(path.user())
    print(path2.user())


# Generated at 2022-06-23 21:36:00.648786
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Platform
    a = Path(Platform.LINUX)
    print(a.user())

# Generated at 2022-06-23 21:36:02.741661
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '\\'


# Generated at 2022-06-23 21:36:06.856709
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)
    assert isinstance(p._seed, int)
    assert p._seed == p.random.seed
    assert p._platform == "linux"


# Generated at 2022-06-23 21:36:07.927223
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:36:10.232808
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    print(users_folder)
    print(type(users_folder))
    assert isinstance(users_folder, str) == True


# Generated at 2022-06-23 21:36:13.873255
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random.choice(FOLDERS) == path.users_folder()
    assert path.random.choice(PROGRAMMING_LANGS) == path.dev_dir()
    assert path.random.choice(PROJECT_NAMES) == path.project_dir()

# Generated at 2022-06-23 21:36:15.827419
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:36:18.732306
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    random_dev_dir = p.dev_dir()
    assert isinstance(random_dev_dir, str)
    assert random_dev_dir == p.dev_dir()


# Generated at 2022-06-23 21:36:19.702755
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home().startswith('/home')

# Generated at 2022-06-23 21:36:22.902899
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    h = p.home()
    assert h == '/home' or h == 'C:\\Users'


# Generated at 2022-06-23 21:36:26.797369
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method Path.project_dir()."""
    path = Path()
    path_ = '/home/marget/Development/Go/bounty'
    assert path.project_dir() == path_


# Generated at 2022-06-23 21:36:28.793918
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() in ['/home/oretha', '/home/taneka', '/home/sherrell']


# Generated at 2022-06-23 21:36:30.752195
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/tomasina' or '/home/delma' or '/home/lavonda'


# Generated at 2022-06-23 21:36:33.621844
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    if sys.platform.startswith("linux") or sys.platform.startswith("darwin"):
        assert path.root() == "/"
    elif sys.platform.startswith("win"):
        assert path.root() == "C:"


# Generated at 2022-06-23 21:36:37.568753
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    
    user = path.user()
    assert isinstance(user, str), 'Invalid type user: %s' % type(user)
    assert ',' not in user and '/' not in user, 'Incorrect user: %s' % user




# Generated at 2022-06-23 21:36:38.501943
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    return path

# Generated at 2022-06-23 21:36:40.467518
# Unit test for method root of class Path
def test_Path_root():
  assert Path(platform = 'linux').root() == '/'


# Generated at 2022-06-23 21:36:42.651116
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print (path.__dict__)
    res = path.user()
    print (res)


# Generated at 2022-06-23 21:36:44.967424
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis import Path
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:36:46.607092
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:36:48.142328
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert 'mercenary' in p.project_dir()

# Generated at 2022-06-23 21:36:52.222546
# Unit test for method user of class Path
def test_Path_user():
    """Test assertion for Path.user().
    """
    p = Path()
    assert p._pathlib_home.name == 'home'
    home = p.home()
    user = p.user()
    print("Home:", home)
    print("User:", user)
    assert home in user
    assert p._pathlib_home.name in user


# Generated at 2022-06-23 21:36:54.617187
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    platform = sys.platform
    path = Path(platform)
    folder = path.project_dir()
    # Return whether the first path is an ancestor of the second path
    assert PurePosixPath(folder).is_absolute()

# Generated at 2022-06-23 21:36:57.540777
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert True == isinstance(p.platform, str)
    assert True == isinstance(p._pathlib_home, PurePosixPath)
    assert 'mimesis.' not in str(p.random)


# Generated at 2022-06-23 21:37:04.139757
# Unit test for method user of class Path
def test_Path_user():
    user_value = Path().user()
    assert user_value in [
        '/Users/malka',
        '/home/fletcher',
        '/home/kim',
        '/Users/kelly',
        '/home/royce',
        '/Users/leann',
        '/home/rodolfo',
        '/home/lizzie',
        '/home/lynda',
        '/Users/effie'
    ]

# Generated at 2022-06-23 21:37:05.487785
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:37:08.745497
# Unit test for method user of class Path
def test_Path_user():
    class Test_Path:
        def test_user(self):
            path = Path('linux')
            path.random.seed(4334)
            assert path.user() == '/home/jeraldine'
    Test_Path().test_user()


# Generated at 2022-06-23 21:37:14.303741
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(1000):   
        p = Path()
        s =  p.project_dir()
        assert len(s.split("/")) == 6, "Error: Path not generated correctly"
        # print(s)
        # print(len(s.split("/")))


# Generated at 2022-06-23 21:37:16.060234
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:37:17.060303
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    provider = Path()
    for i in range(0, 10):
        print(provider.users_folder())



# Generated at 2022-06-23 21:37:18.844257
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Test for method project_dir of class Path
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:37:20.072901
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()

# Generated at 2022-06-23 21:37:22.281327
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.seed(0)
    for i in range(0, 20):
        print(p.user())


# Generated at 2022-06-23 21:37:31.026799
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import hashlib
    obj = Path()
    obj.seed(seed=112233)
    path = obj.users_folder()
    assert path == '/home/tollie/Documents', f'Failed test_Path_users_folder(): is {path}'
    assert hashlib.sha224(path.encode()).hexdigest() == '23a1453d5c64dc858f65b7e1d35ebc5ddf8f4cc4c76a1b4a4f4d2b2a', f'Failed test_Path_users_folder(): is {path}'


# Generated at 2022-06-23 21:37:33.835531
# Unit test for method user of class Path
def test_Path_user():
    path_instance = Path()
    path_instance._pathlib_home = PureWindowsPath()
    path_instance._pathlib_home /= "user"
    assert path_instance.user() == str(path_instance._pathlib_home / "user")

# Generated at 2022-06-23 21:37:34.861929
# Unit test for constructor of class Path
def test_Path():
    assert Path()

# Unit tests for method root of class Path

# Generated at 2022-06-23 21:37:36.347683
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.random is not None
    assert p.datetime is not None
    assert p.platform is not None

# Generated at 2022-06-23 21:37:38.949272
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test method users_folder of class Path."""
    p = Path()
    result = p.users_folder()
    assert type(result) is str


# Generated at 2022-06-23 21:37:43.392714
# Unit test for method home of class Path
def test_Path_home():
    test1 = Path('win32')
    a = test1.home()
    assert a == 'C:\\Users'

    test2 = Path('linux')
    b = test2.home()
    assert b == '/home'

    test3 = Path('darwin')
    c = test3.home()
    assert c == '/Users'


# Generated at 2022-06-23 21:37:46.003661
# Unit test for method user of class Path
def test_Path_user():
    x = Path()
    print(x.user())     

test_Path_user()

# Generated at 2022-06-23 21:37:47.392898
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert '/home/taneka' == path.user()

# Generated at 2022-06-23 21:37:48.485791
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()


# Generated at 2022-06-23 21:37:51.272084
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    # Result: '/home/oretha'


# Generated at 2022-06-23 21:37:52.626587
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert type(p.user()) is str


# Generated at 2022-06-23 21:37:56.618137
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    res_names = []
    p = Path()
    for _ in range(100):
        res_names.append(p.project_dir())

    assert len(set(res_names)) == 100
    assert all([type(name) is str for name in res_names])


# Generated at 2022-06-23 21:37:59.257410
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert isinstance(p.root(),str)

# Generated at 2022-06-23 21:38:00.848905
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == 'test_user'


# Generated at 2022-06-23 21:38:05.081743
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform

    for i in [1, 10, 100, 1000]:
        assert p.__init__(sys.platform) == None

    for platform in ['linux', 'darwin', 'win32', 'win64']:
        assert p.__init__(platform) == None



# Generated at 2022-06-23 21:38:06.575227
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home()


# Generated at 2022-06-23 21:38:09.500087
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())
path_generator = Path()
print(dir(path_generator))

print(path_generator.project_dir())

# Generated at 2022-06-23 21:38:11.503116
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()

    assert p.project_dir() == '/home/taneka/Dev/Korn/hacker'

# Generated at 2022-06-23 21:38:16.538144
# Unit test for constructor of class Path
def test_Path(): 
    path = Path()
    assert path.platform == 'linux'
    assert path.random.choice(USERNAMES) in USERNAMES
    assert path.dev_dir()
    assert path.project_dir()
    assert path.user()
    assert path.home()
    assert path.root()
    assert path.users_folder()

# Generated at 2022-06-23 21:38:18.276309
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    #print(path.root())
    assert path.root() == '/'


# Generated at 2022-06-23 21:38:21.510385
# Unit test for method root of class Path
def test_Path_root():
    """Test for method root of class Path."""
    path = Path()
    root_dir = path.root()
    assert (root_dir == '/' if 'linux' in sys.platform else 'C:/')


# Generated at 2022-06-23 21:38:23.070627
# Unit test for method home of class Path
def test_Path_home():
    path_ = Path()
    home = path_.home()
    assert type(home) is str


# Generated at 2022-06-23 21:38:25.912839
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    p = Path(platform='linux')
    path1 = p.root()
    assert path1 == '/'


# Generated at 2022-06-23 21:38:26.905337
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    Path().project_dir()


# Generated at 2022-06-23 21:38:33.324905
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    mime = {
        'linux': '/home/estelle/Música',
        'darwin': '/home/edra/Downloads',
        'win32': r'C:\Users\maris\Music',
        'win64': r'C:\Users\maris\Documents'
    }
    faked = Path().users_folder()
    assert faked.count('/') == 3 or faked.count('\\') == 3
    if sys.platform in mime:
        assert faked == mime[sys.platform]
    else:
        print(sys.platform)


# Generated at 2022-06-23 21:38:34.615767
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    x = path.home()
    assert isinstance(x, str)


# Generated at 2022-06-23 21:38:36.690163
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home
    assert path._pathlib_home / 'test' == PurePosixPath('/home/test')
    #assert path.root() == PurePosixPath('/')

# Generated at 2022-06-23 21:38:42.261805
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    # Python:
    assert path.dev_dir() == '/home/harley/Dev/Python'
    # C++:
    path = Path('win64')
    assert path.dev_dir() == 'C:\\Users\\Lera\\development\\C++'
    # Java:
    path = Path('darwin')
    assert path.dev_dir() == '/Users/Kailee/Dev/Java'


# Generated at 2022-06-23 21:38:43.418271
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'

# Generated at 2022-06-23 21:38:45.778031
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir() == p.dev_dir()

# Generated at 2022-06-23 21:38:48.506033
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    path = Path(platform='linux')
    path.project_dir()

# Generated at 2022-06-23 21:38:51.029437
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.set_seed(1000)
    assert path.users_folder() == '/home/taneka/Pictures'

# Generated at 2022-06-23 21:38:53.052236
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    assert result == '/home'


# Generated at 2022-06-23 21:38:54.006678
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:38:55.805583
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/taneka'


# Generated at 2022-06-23 21:38:58.606198
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home == PureWindowsPath() \
        if 'win' in sys.platform else PurePosixPath()


# Generated at 2022-06-23 21:39:00.546711
# Unit test for method root of class Path
def test_Path_root():
    """Test for method root of class Path."""
    assert Path().root() == str(Path()._pathlib_home.parent)


# Generated at 2022-06-23 21:39:02.316430
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.seed(0)
    p.dev_dir() == '/home/zula/Development/C'

# Generated at 2022-06-23 21:39:04.596958
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:39:06.068143
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:39:07.248652
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('linux')
    print(p.users_folder())

# Generated at 2022-06-23 21:39:08.193064
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(0)
    assert path.user() == '/Users/percell'


# Generated at 2022-06-23 21:39:10.943043
# Unit test for method home of class Path
def test_Path_home():
    path = Path('linux')
    home = path.home()
    assert home == '/home'


if __name__ == '__main__':
    test_Path_home()

# Generated at 2022-06-23 21:39:13.178174
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:39:15.672975
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    p.random.seed(9)
    assert p.users_folder() == '/home/tinika/Music'

# Generated at 2022-06-23 21:39:17.887815
# Unit test for method root of class Path
def test_Path_root():
    '''
    Path method root
    '''
    p = Path('linux')
    assert p.root() == '/'
    assert p.home() == '/home'
    assert p.root() != '//'


# Generated at 2022-06-23 21:39:18.770959
# Unit test for constructor of class Path
def test_Path():
    assert isinstance(Path(),Path)

# Generated at 2022-06-23 21:39:20.295611
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

test_Path_dev_dir()

# Generated at 2022-06-23 21:39:21.875685
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print(Path().dev_dir())

# Generated at 2022-06-23 21:39:24.424144
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    p = Path()
    assert p.random.choice([p.root() for i in range(1000)]) in ['/', 'C:\\']


# Generated at 2022-06-23 21:39:35.006834
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    str = p.dev_dir()
    print(str)
    if str.find('/') == -1:
        str = str.replace('\\', '/')
    if str.endswith('\\'):
        str = str[0:-1]
    arr = str.split('/')
    if len(arr) < 5:
        print('wrong length: ' + str(len(arr)))
        return False
    if arr[0] != '':
        print('not begin with /: ' + p.dev_dir())
        return False
    # test for randomness, not be sure there is no duplicated value in arr
    if len(set(arr)) != len(arr):
        print('not random: ' + str)
        return False
    return True


# Generated at 2022-06-23 21:39:35.784926
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'



# Generated at 2022-06-23 21:39:37.802578
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    root = p.root()
    print(root)
    assert root is not None


# Generated at 2022-06-23 21:39:39.735240
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.random.seed(0)
    assert path.users_folder() == '/home/kaitlyn/Desktop'

# Generated at 2022-06-23 21:39:41.430394
# Unit test for method root of class Path
def test_Path_root():
    print("test_Path_root")
    assert len(Path().root()) == 1


# Generated at 2022-06-23 21:39:43.701167
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    res = p.project_dir()
    print("** project_dir() == ", res)
    assert res == '/home/terese/Development/Lisp/thompson'


# Generated at 2022-06-23 21:39:45.066115
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path(platform="linux")
    print(p.dev_dir())


# Generated at 2022-06-23 21:39:46.056497
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert isinstance(path.home(), str)


# Generated at 2022-06-23 21:39:47.573342
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(1)
    assert path.user() == '/home/kristopher'


# Generated at 2022-06-23 21:39:48.685934
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:39:52.605704
# Unit test for method root of class Path
def test_Path_root():
    p_obj = Path()
    assert isinstance(p_obj.root(), str), 'String expected'
    assert len(p_obj.root()) > 0, 'Non-empty string expected'


# Generated at 2022-06-23 21:39:54.810715
# Unit test for method root of class Path
def test_Path_root():
    print('Root dir:', Path(platform='linux').root())


# Generated at 2022-06-23 21:39:56.836201
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    # print(path.dev_dir())
    assert '/home/sherrell/Development/Python' == path.dev_dir()

# Generated at 2022-06-23 21:39:59.849509
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path(platform='linux')
    assert isinstance(path.user(), str)
    assert path.user() == '/home/yoko'


# Generated at 2022-06-23 21:40:11.133813
# Unit test for constructor of class Path
def test_Path():
    from mimesis import Generic
    from mimesis.enums import Platform
    from mimesis.providers.filesystem import Path
    import platform
    import re

    path_provider = Path()

    # Test constructors with different platform argument
    path_provider = Path(platform=Platform.LINUX)
    assert(path_provider.Meta.name == 'path')
    assert(re.match('/home/\w+/Pictures', path_provider.users_folder()) is not None)
    path_provider = Path(platform=Platform.WINDOWS)
    assert(re.match('C:\\Users\\\w+\\Pictures', path_provider.users_folder()) is not None)

    path_provider = Path(platform='linux')
    assert(path_provider.Meta.name == 'path')