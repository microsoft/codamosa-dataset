

# Generated at 2022-06-23 21:30:13.653041
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path(platform='linux')
    expected_project_dir = '/home/leonia/Development/Python/the-english-patient'
    
    assert path.project_dir() == expected_project_dir

# Generated at 2022-06-23 21:30:15.518188
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path('linux').users_folder() == '/home/karon/Pictures'


# Generated at 2022-06-23 21:30:18.280512
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert type(root) == str


# Generated at 2022-06-23 21:30:20.358165
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for _ in range(10):
        path.user()



# Generated at 2022-06-23 21:30:21.744252
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:30:25.353781
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path at module mimesis.
    """
    print("Unit test for method home of class Path at module mimesis.")
    paths = Path()
    print(paths.home())
    print("End test")


# Generated at 2022-06-23 21:30:27.490540
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() # "/home/sherika/Development/Python"


# Generated at 2022-06-23 21:30:30.061847
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print('\ntest_Path_users_folder: ')
    print(p.users_folder())



# Generated at 2022-06-23 21:30:31.107147
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()



# Generated at 2022-06-23 21:30:35.058219
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() is not None
    assert isinstance(p.users_folder(), str) is True


# Generated at 2022-06-23 21:30:36.244144
# Unit test for method user of class Path
def test_Path_user():
    test = Path()
    t1 = test.user()
    assert t1 == '/home/oretha'

# Generated at 2022-06-23 21:30:38.078452
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    l = Path().users_folder()
    assert type(l) == str


# Generated at 2022-06-23 21:30:40.066586
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user"""
    path = Path()
    assert path.user()


# Generated at 2022-06-23 21:30:43.857782
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    # assert path.home() == '/home'
    assert path.home() == 'C:\\Users'

# Generated at 2022-06-23 21:30:47.283538
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    users = set()
    for _ in range(10):
        user = path.user()
        assert user not in users
        users.add(user)

# Generated at 2022-06-23 21:30:50.318170
# Unit test for method user of class Path
def test_Path_user():
    check = Path(platform='win32')
    assert check.user() == PureWindowsPath(PLATFORMS['win32']['home'] + '/' + 'Drusilla')


# Generated at 2022-06-23 21:30:51.947062
# Unit test for method root of class Path
def test_Path_root():
    d = Path()
    res = d.root()
    assert res == '/'


# Generated at 2022-06-23 21:30:54.102042
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_generator = Path()
    path = path_generator.dev_dir()
    print(path)
    assert(True)



# Generated at 2022-06-23 21:30:56.782068
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    assert type(result) is str


# Generated at 2022-06-23 21:30:58.159783
# Unit test for constructor of class Path
def test_Path():
    p = Path("linux")
    assert p is not None


# Generated at 2022-06-23 21:30:59.527214
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert len(p.users_folder()) > 0

# Generated at 2022-06-23 21:31:01.609654
# Unit test for method root of class Path
def test_Path_root():
    path = Path('darwin')
    # result: '/'
    print(path.root())


# Generated at 2022-06-23 21:31:03.362673
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    path = p.user()
    assert path == '/home/tamara'

# Generated at 2022-06-23 21:31:04.984705
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == "/home/debby"


# Generated at 2022-06-23 21:31:05.951284
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.user()

# Generated at 2022-06-23 21:31:07.670829
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for _ in range(10):
        a = path.user()
        # assert a.startswith('/home/')
        assert a.count(PLATFORMS['linux']['home'])>0


# Generated at 2022-06-23 21:31:10.212264
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.home())
    print(path.root())
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


# Generated at 2022-06-23 21:31:12.449814
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    result = path.user()
    assert result is not None


# Generated at 2022-06-23 21:31:16.520215
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    cwd = 'C:\\Users\\'
    cwd_linux = '/home/'
    test_Path = Path('win32')
    test_Path_dev_dir_result = test_Path.dev_dir()

    assert cwd in test_Path_dev_dir_result


# Generated at 2022-06-23 21:31:17.278211
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.user())

# Generated at 2022-06-23 21:31:19.513418
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for i in range (1,10):
        print(Path().users_folder())


# Generated at 2022-06-23 21:31:23.327211
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    res = p.project_dir()
    assert(str(res) == res)
    assert(len(res) >= 5)
    assert res == "C:\\Users\\asd\\Development\\PHP\\nentori"

# Generated at 2022-06-23 21:31:24.657546
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:31:36.734415
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    expected = ["/home/hong/Development/Java",
                "/home/kurt/Development/Java",
                "/home/desire/Development/Python",
                "/home/sherri/Development/Python",
                "/home/shalon/Development/C++",
                "/home/shalon/Development/C++",
                "/home/carol/Development/Java",
                "/home/crista/Development/Python",
                "/home/jene/Development/C++",
                "/home/elle/Development/Java",
                "/home/rorie/Development/C++",
                "/home/christal/Development/Java",
                "/home/jayson/Development/Java",
                "/home/annice/Development/Python",
                "/home/lucas/Development/Python"]

# Generated at 2022-06-23 21:31:40.545631
# Unit test for method home of class Path
def test_Path_home():
    """Test method home in Path class
    
    :return:
    """
    print(str(Path().home()))
    assert Path().home() is not None


# Generated at 2022-06-23 21:31:44.067385
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # given
    path = Path()

    # action
    result = path.project_dir()

    # expect
    assert result != '/home/user/dev_dir/project', "expected 'project' directory"


# Generated at 2022-06-23 21:31:49.421586
# Unit test for constructor of class Path
def test_Path():
    # Arrange
    expected_path_home = '/home'
    expected_path_root = '/'
    # Act
    path = Path()
    path_home = path.home()
    path_root = path.root()
    # Assert
    assert path_home == expected_path_home
    assert path_root == expected_path_root

# Generated at 2022-06-23 21:31:51.353983
# Unit test for constructor of class Path
def test_Path():
    # pathlib.Path().home()
    assert Path().home() == "/home"

    # pathlib.Path().home()
    assert Path(platform="win32").home() == "C:\\Users"

# Generated at 2022-06-23 21:31:52.677969
# Unit test for method project_dir of class Path
def test_Path_project_dir():
	path = Path()
	assert path.project_dir().startswith("/home")


# Generated at 2022-06-23 21:31:54.128514
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    pprint(p.home())
    pprint('/home')


# Generated at 2022-06-23 21:31:56.567003
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    #print(path.users_folder())
    assert len(path.users_folder()) > 0

# Generated at 2022-06-23 21:31:59.638228
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert 'Pictures' in path.users_folder()
    assert 'taneka' in path.users_folder()


# Generated at 2022-06-23 21:32:09.792698
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test the method dev_dir of class Path."""
    path_1 = Path()
    assert path_1.dev_dir() == str(PurePosixPath('/home/felisha/Development/C'))
    assert path_1.dev_dir() == str(PurePosixPath('/home/kristie/Development/C#'))
    assert path_1.dev_dir() == str(PurePosixPath('/home/oralee/Development/C#'))
    assert path_1.dev_dir() == str(PurePosixPath('/home/karole/Development/Java'))
    assert path_1.dev_dir() == str(PurePosixPath('/home/paz/Development/Python'))

# Generated at 2022-06-23 21:32:11.795881
# Unit test for constructor of class Path
def test_Path():
    p = Path("linux")
    assert isinstance(p, Path) == True


# Generated at 2022-06-23 21:32:13.048459
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert isinstance(p.home(), str)



# Generated at 2022-06-23 21:32:15.758695
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    assert isinstance(dev_dir, str)

# Generated at 2022-06-23 21:32:18.495832
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path."""
    path = Path(platform='linux')
    assert path.dev_dir() == '/home/eliza/Dev/Java'

# Generated at 2022-06-23 21:32:19.494649
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())

# Generated at 2022-06-23 21:32:22.771746
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    expected_result = '/home'
    assert isinstance(path.home(), str) and path.home() != '' and path.home() == expected_result



# Generated at 2022-06-23 21:32:25.496443
# Unit test for method home of class Path
def test_Path_home():
  """Testing method home of class Path"""
  path = Path()
  home = path.home()
  print('home: {}'.format(home))
  return home == '/home'


# Generated at 2022-06-23 21:32:26.740773
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None


# Generated at 2022-06-23 21:32:29.468616
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path = Path()
    home = path.home()
    assert home



# Generated at 2022-06-23 21:32:31.401777
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    mypath = Path("linux")
    print("path is "+mypath.project_dir())

    return True

# Generated at 2022-06-23 21:32:32.694873
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    Path().users_folder()


# Generated at 2022-06-23 21:32:35.658031
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(0,100):
        path = Path()
        home = path.home()
        res = path.project_dir()
        assert home in res

# Generated at 2022-06-23 21:32:37.094008
# Unit test for method user of class Path
def test_Path_user():
    result = Path(platform="linux").user()
    assert result


# Generated at 2022-06-23 21:32:38.958413
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    temp = Path()
    assert isinstance(temp.users_folder(), str)

# Generated at 2022-06-23 21:32:40.228082
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:32:43.566693
# Unit test for constructor of class Path
def test_Path():
    # Initialize attributes
    platform = sys.platform
    path = Path(platform)
    
    # Test methods
    assert path.root()
    assert path.home()
    assert path.user()
    assert path.users_folder()
    assert path.dev_dir()
    assert path.project_dir()

# Generated at 2022-06-23 21:32:45.832211
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Function that test class Path"""
    PATH = Path()
    print("PATH.project_dir() =", PATH.project_dir())

# Generated at 2022-06-23 21:32:48.119239
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:32:49.527285
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None

# Generated at 2022-06-23 21:32:52.989601
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    
    """test_Path_users_folder(provider, idx)
    Parameters:
    provider: object
    idx: random.random()"""
    
    
    
    
    
    
    
    
    
    
    
    for i in range(0, 101):
        provider = Path()
        idx = random.random()
        result = provider.users_folder()
        print(result)
        

# Generated at 2022-06-23 21:32:54.345634
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert re.search(r'^(?:/home)$', path.home())


# Generated at 2022-06-23 21:32:56.806860
# Unit test for method home of class Path
def test_Path_home():
    home = Path().home()
    assert home not in [None, ""]
    assert isinstance(home, str)

## Unit test for method user of class Path

# Generated at 2022-06-23 21:32:58.648714
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() in ["/home", "C:\\Users"]


# Generated at 2022-06-23 21:33:00.645160
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/bethanie/Development/C#'

# Generated at 2022-06-23 21:33:03.158207
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    #print(path.dev_dir())
    assert path.dev_dir() == '/home/sherrell/Development/Python'

# Generated at 2022-06-23 21:33:04.823561
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'

##### Unit test for method home of class Path

# Generated at 2022-06-23 21:33:07.139928
# Unit test for constructor of class Path
def test_Path():
    print(Path.__init__.__doc__)


# Generated at 2022-06-23 21:33:10.134325
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Set the seed
    path = Path()
    path.seed(42)

    # Generate a random path
    project_dir = path.project_dir()

    # Assert
    # This is an example, the results do not change with each run
    assert project_dir == '/home/carie/Dev/Python/mercenary'

# Generated at 2022-06-23 21:33:17.396254
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """
    Test whether the method users_folder of calss Path return a random path to user's folder
    
    Assertion: if the method returns a random path to user's folder, return True
    """
    path = Path()
    path_users_folder = path.users_folder()
    user = path._pathlib_home / path.user()
    folder = path.random.choice(FOLDERS)
    assert path_users_folder == str(user / folder)

# Generated at 2022-06-23 21:33:20.246819
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path_obj = Path()
    result = path_obj.home()
    assert type(result) is str


# Generated at 2022-06-23 21:33:24.826431
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Create obj of class Path
    obj = Path('linux')
    # Create empty set for check result
    my_set = set()
    # Run method project_dir() of class Path and add result to set
    for _ in range(100):
        my_set.add(obj.project_dir())
    # Check
    assert len(my_set) == 100

# Generated at 2022-06-23 21:33:30.251078
# Unit test for method root of class Path
def test_Path_root():
    test_path = Path()
    test_path.random.seed(1)
    assert test_path.root() in ['/', 'C:\\', 'C:\\Windows']


# Generated at 2022-06-23 21:33:32.234300
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path1 = Path()
    assert path1.root() == path.root()



# Generated at 2022-06-23 21:33:34.118852
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Test the method project_dir of class Path
    assert Path().project_dir() is not None

# Generated at 2022-06-23 21:33:35.170571
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())
    assert True

# Generated at 2022-06-23 21:33:37.503533
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    home_folder = path.users_folder()
    return home_folder


# Generated at 2022-06-23 21:33:39.938706
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == str(PurePosixPath() / "home" / "taneka" / "Pictures")

# Generated at 2022-06-23 21:33:41.742999
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("Path.dev_dir()")
    print(Path().dev_dir())

# Generated at 2022-06-23 21:33:47.317821
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print( p.root())
    print( p.home())
    print( p.user())
    print( p.users_folder())
    print( p.dev_dir())
    print( p.project_dir())

if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-23 21:33:48.881860
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    res = p.users_folder()
    print(res)

# Generated at 2022-06-23 21:33:50.270323
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:33:53.562351
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    generator = Path()
    result = generator.dev_dir()
    assert isinstance(result, str)
    assert result.startswith('/')


# Generated at 2022-06-23 21:33:56.656207
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test for method project_dir of class Path"""
    print(Path().project_dir())

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:34:00.399843
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import OperatingSystem
    path = Path(platform=OperatingSystem.LINUX)
    path_home_example = '/home'
    for i in range(10):
        assert path.home() == path_home_example


# Generated at 2022-06-23 21:34:02.387280
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.dev_dir()


# Generated at 2022-06-23 21:34:04.516324
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert home == '/home'


# Generated at 2022-06-23 21:34:14.690689
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test for method project_dir of class Path"""
    p = Path()
    for _ in range(10):
        print(p.project_dir())

# Generated at 2022-06-23 21:34:16.159772
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:34:17.774546
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:34:19.709058
# Unit test for method root of class Path
def test_Path_root():
    # Arrange
    p = Path()
    expected ='/'
    actual = p.root()
    # Action
    assert actual == expected


# Generated at 2022-06-23 21:34:23.956195
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    path = Path(locale='en')
    gender = Gender.MALE
    assert(path.random.seed(123))
    assert(path.user()) == '/home/yvonne'
    path2 = Path(locale='en', gender=gender)
    assert(path2.random.seed(123))
    assert(path2.user()) == '/home/yvonne'


# Generated at 2022-06-23 21:34:24.923003
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:34:27.482735
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    for x in range(0, 10):
        path.dev_dir()



# Generated at 2022-06-23 21:34:30.848701
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    path = Path(platform=Platform.LINUX)
    actual = path.root()
    expected = '/'
    assert actual == expected


# Generated at 2022-06-23 21:34:34.534302
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    users_folder = p.users_folder()
    print(users_folder)
    print(type(users_folder))
    assert users_folder
    assert type(users_folder) == str


# Generated at 2022-06-23 21:34:35.811754
# Unit test for method home of class Path
def test_Path_home():
    return Path().home()


# Generated at 2022-06-23 21:34:38.438872
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path(platform='win32')
    path = p.project_dir()
    print(path)

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:34:40.963637
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'



# Generated at 2022-06-23 21:34:42.135859
# Unit test for method user of class Path
def test_Path_user():
    Path().user()


# Generated at 2022-06-23 21:34:44.401776
# Unit test for constructor of class Path
def test_Path():
    pathObj = Path()
    assert pathObj.platform in ['linux', 'darwin', 'win32', 'win64']


# Generated at 2022-06-23 21:34:45.369730
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.seed(0)
    assert p.root() == '/home'


# Generated at 2022-06-23 21:34:46.770763
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()

    users_folder = path.users_folder()

    assert len(users_folder) > 0
    assert users_folder[0] == "/"

# Generated at 2022-06-23 21:34:48.668397
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path('win64')
    assert 'Development' in p.dev_dir() or 'Dev' in p.dev_dir()
    p = Path('darwin')
    assert 'Development' in p.dev_dir() or 'Dev' in p.dev_dir()


# Generated at 2022-06-23 21:34:52.309215
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    res = path.users_folder()
    assert type(res) is str
    assert res[0:6] == '/home/'


# Generated at 2022-06-23 21:34:55.375436
# Unit test for constructor of class Path
def test_Path():
    """A test to make sure the initialization of the object was ok."""
    path = Path()
    assert path._pathlib_home == PurePosixPath('/home')


# Generated at 2022-06-23 21:34:57.521582
# Unit test for constructor of class Path
def test_Path():
    assert Path()
    assert Path().random
    assert Path().datetime
    assert Path().platform
    assert Path().platform == sys.platform



# Generated at 2022-06-23 21:34:59.040275
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'



# Generated at 2022-06-23 21:35:01.524663
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert isinstance(path.root(), str)
    assert path.root() == '/'
    

# Generated at 2022-06-23 21:35:02.913356
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert len(path.home()) == 6


# Generated at 2022-06-23 21:35:04.795619
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    # Assert for method root
    assert not None is path.root()

# Generated at 2022-06-23 21:35:15.221756
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    # test root
    temp = path.root()
    assert temp == '/'
    # test home
    temp = path.home()
    assert temp == '/home'
    # test user
    temp = path.user()
    assert temp == '/home/oretha'
    # test users_folder
    temp = path.users_folder()
    assert temp == '/home/taneka/Pictures'
    # test dev_dir
    temp = path.dev_dir()
    assert temp == '/home/sherrell/Development/Python'
    # test project_dir
    temp = path.project_dir()
    assert temp == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:35:16.885313
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # TODO: Don't forget to implement a unit test for method users_folder of class Path
    pass

# Generated at 2022-06-23 21:35:24.551783
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    value = p.project_dir()
    # Check if the value is a string
    assert isinstance(value, str), "The value is not a string."
    # Check if the value is a valid path of the platform (linux, darwin, win32, win64)
    assert pathlib.Path(value).exists(), "The path is not valid."



# Generated at 2022-06-23 21:35:28.295286
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_tester = Path()
    result = path_tester.dev_dir()
    assert isinstance(result, str)
    assert len(result) > 0
#if __name__ == "__main__":
#    test_Path_dev_dir()

# Generated at 2022-06-23 21:35:31.093407
# Unit test for constructor of class Path
def test_Path():
    random_path = Path(platform='win32')
    assert random_path.platform == 'win32'
    assert str(random_path._pathlib_home) == 'C:\\Users'


# Generated at 2022-06-23 21:35:34.352542
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == str(path._pathlib_home/'Gloria')


# Generated at 2022-06-23 21:35:42.677816
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # test0
    path = Path()
    assert path.project_dir() == '/home/venita/Development/Nim/restless'
    # test1
    path = Path()
    assert path.project_dir() == '/home/adriene/Development/JavaScript/scrappy'
    # test2
    path = Path()
    assert path.project_dir() == '/home/joseph/Development/JavaScript/chrome'
    # test3
    path = Path()
    assert path.project_dir() == '/home/brett/Development/Python/deviant'
    # test4
    path = Path()
    assert path.project_dir() == '/home/craig/Development/JavaScript/initiative'
    # test5
    path = Path()

# Generated at 2022-06-23 21:35:53.061527
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    user = provider.user()

# Generated at 2022-06-23 21:35:54.464572
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='win32')
    assert p != None


# Generated at 2022-06-23 21:35:57.765123
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range(1000):
        user = p.user()
        assert user.startswith('/home')
        assert user.count('/') == 2


# Generated at 2022-06-23 21:35:59.597319
# Unit test for method home of class Path
def test_Path_home():
    from datetime import datetime, timezone
    from mimesis.enums import Gender

    path = Path()
    path.seed(datetime.now(timezone.utc), Gender.MALE)

    home = path.home()
    assert isinstance(home, str)


# Generated at 2022-06-23 21:36:01.853863
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    try:
        assert Path().user() == '/home/oretha'
    except AssertionError:
        print(Path().user())


# Generated at 2022-06-23 21:36:04.031861
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())


if __name__ == "__main__":
    test_Path_users_folder()

# Generated at 2022-06-23 21:36:08.350844
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import Platform
    p = Path(platform=Platform.LINUX)
    p.seed(1)
    assert p.root() == '/'
    assert len(p.root()) > 0


# Generated at 2022-06-23 21:36:09.363378
# Unit test for method root of class Path
def test_Path_root():
    """Test Path.root()."""
    path = Path()
    assert path.root() is not None


# Generated at 2022-06-23 21:36:11.236050
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/georgianne/Development/Ruby/land-race'

# Generated at 2022-06-23 21:36:18.640244
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # -----
    # Should return a random path in the users folder.
    # -----
    p = Path()
    path = p.users_folder()
    if '/home/' in path:
        path = path[5:]
    #print(path)
    assert 'some-user-name' in path, True
    # -----
    # Should return a random path in the users folder.
    # -----
    p = Path('win64')
    path = p.users_folder()
    if '/Users/' in path:
        path = path[5:]
    #print(path)
    assert 'Some-User-Name' in path, True

# Generated at 2022-06-23 21:36:19.088988
# Unit test for method root of class Path
def test_Path_root():
    assert True;

# Generated at 2022-06-23 21:36:21.648011
# Unit test for method user of class Path
def test_Path_user():
    assert isinstance(Path().user(), str)
    assert Path().user() != Path().user()


# Generated at 2022-06-23 21:36:22.685259
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:36:26.567400
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    display(HTML('<strong>' + str(result) + '</strong>'))
    assert result != None, 'Erro: Method home of class Path not working correctly'


# Generated at 2022-06-23 21:36:30.669691
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import mimesis
    import json
    path_ = mimesis.Path(seed=123)
    assert path_.users_folder() == '/home/bheeman/Pictures'
    pr = json.loads(json.dumps(path_))
    assert pr['users_folder']() == '/home/bheeman/Pictures'

# Generated at 2022-06-23 21:36:32.695489
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import random
    print(Path(random.choice(['linux', 'win32', 'darwin', 'win64'])).dev_dir())

# Generated at 2022-06-23 21:36:34.543750
# Unit test for method root of class Path
def test_Path_root():
    path = Path()

    assert path.root() == '/'



# Generated at 2022-06-23 21:36:40.662363
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert(p.project_dir().startswith('/'))
    assert('/' in p.project_dir())
    # assert('=' not in p.project_dir()) # assert false 
    # assert('\'' not in p.project_dir()) # assert false
    # assert(' ' not in p.project_dir()) # assert false
    # assert('\\' not in p.project_dir()) # assert false

# Generated at 2022-06-23 21:36:51.721198
# Unit test for method dev_dir of class Path

# Generated at 2022-06-23 21:36:55.470738
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root().startswith("/home"), "Path.root() failed"
    path = Path("win32")
    assert path.root().startswith("C:\\Users"), "Path.root() failed"
    assert path.root().endswith("\\"), "Path.root() failed"


# Generated at 2022-06-23 21:36:59.770441
# Unit test for method users_folder of class Path
def test_Path_users_folder():

    Path_users_folder_results = []
    for i in range(0, 100):
        Path_users_folder_result = Path().users_folder()
        Path_users_folder_results.append(Path_users_folder_result)

    assert type(Path_users_folder_results[0]) is str
    assert len(Path_users_folder_results) == 100
    assert len(Path_users_folder_results) == len(set(Path_users_folder_results))

# Generated at 2022-06-23 21:37:01.128400
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"


# Generated at 2022-06-23 21:37:05.343695
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.enums import OperatingSystem
    path = Path(platform=OperatingSystem.LINUX)
    for i in range(10):
        assert len(str(path.root())) > 0
        assert str(path.root()) == '/'


# Generated at 2022-06-23 21:37:12.488841
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import re, os
    path = Path()
    path_str = path.dev_dir()
    # Check if the return is of type string
    assert isinstance(path_str, str)
    # Check if the path is valid windows path
    assert re.match(r"([a-zA-Z]:)?(\\[a-zA-Z0-9 _.-]+)*\\?", path_str)

    path_str2 = path.dev_dir()
    assert path_str != path_str2

    # Check if the path is valid Posix path
    path = Path(platform="darwin")
    assert os.path.isabs(path.dev_dir())
    path = Path(platform="linux")
    assert os.path.isabs(path.dev_dir())
    # Check if the path is valid windows path
   

# Generated at 2022-06-23 21:37:14.304992
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert(path.platform == sys.platform)

# Generated at 2022-06-23 21:37:16.059839
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:37:19.390261
# Unit test for method root of class Path
def test_Path_root():
    obj = Path()
    #         Expected value, number of time repeat process
    for i in range(0,10):
        result = obj.root()
        print('Root: ',result)
        assert type(result) is str


# Generated at 2022-06-23 21:37:20.970225
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    f = p.project_dir()
    print(f)


# Generated at 2022-06-23 21:37:26.825032
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.platform = 'darwin'
    result = path.dev_dir()
    for p in PROJECT_NAMES:
        if p in result:
            print("TEST PASSED " + result + " has in his path the project " + p)
            return
    assert False, "TEST FAILED " + result + " has not in his path a project name"

# Generated at 2022-06-23 21:37:28.852404
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    for i in range(100):
        print(path.dev_dir())


# Generated at 2022-06-23 21:37:29.520000
# Unit test for method user of class Path
def test_Path_user():
    return True

# Generated at 2022-06-23 21:37:32.327348
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""

    path = Path(platform='linux')
    expected = '/home/leatrice'
    result = path.user()
    assert result == expected


# Generated at 2022-06-23 21:37:33.444238
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"

# Generated at 2022-06-23 21:37:35.080420
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    return path


# Generated at 2022-06-23 21:37:36.526411
# Unit test for method home of class Path
def test_Path_home():
    home = Path().home()

    assert 'home' in home

# Generated at 2022-06-23 21:37:45.192170
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from unittest import TestCase

    class TestPath_dev_dir(TestCase):
        def setUp(self):
            setattr(TestCase, 'assertNotIn', self.myAssertNotIn)
            setattr(TestCase, 'assertIn', self.myAssertIn)
            setattr(TestCase, 'assertRaises', self.myAssertRaises)

        def test_linux(self):
            p = Path('linux')
            path = p.dev_dir()
            self.assertIn('/home', path)
            self.assertIn('Development', path)
            self.assertIn('Go', path)
            path = p.dev_dir()
            self.assertIn('/home', path)
            self.assertIn('Development', path)
            self.assertIn('Scala', path)


# Generated at 2022-06-23 21:37:47.622903
# Unit test for method project_dir of class Path
def test_Path_project_dir():
   assert Path().project_dir() == '/home/hong/Development/JavaScript/TimeCutter'

print(Path().project_dir())


# Generated at 2022-06-23 21:37:51.373267
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path.
    """
    path = Path()
    print(path.project_dir())
    assert path.project_dir() not in ('', None)


# Generated at 2022-06-23 21:37:53.206259
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    generated_path = path.users_folder()
    print(generated_path)


# Generated at 2022-06-23 21:37:54.922430
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:37:56.578294
# Unit test for method home of class Path
def test_Path_home():
    path_instance = Path()
    assert path_instance.home() == "/home"


# Generated at 2022-06-23 21:37:59.605054
# Unit test for method root of class Path
def test_Path_root():
    path = Path(platform='linux')
    assert path.root() == '/'


# Generated at 2022-06-23 21:38:01.258992
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:38:03.035228
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:38:04.227296
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert isinstance(path.root(), str)


# Generated at 2022-06-23 21:38:10.198076
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import random
    from mimesis.builtins import Seed
    random.seed(400)
    seed_instance = Seed(400)
    p = Path(platform='linux', seed=seed_instance)
    assert p.project_dir() == '/home/mabell/Development/PHP/Slim/Slim'
    # run 200 times to check if the sequences are deterministic
    for i in range(200):
        assert p.project_dir() == '/home/mabell/Development/PHP/Slim/Slim'


# Generated at 2022-06-23 21:38:17.011687
# Unit test for constructor of class Path
def test_Path():
    # Create instance of class Path()
    path_test = Path()
    # Check that variable platform is equal to the output of sys.platform
    assert (path_test.platform == sys.platform)
    # Assign the output of pathlib_home to variable home
    home = path_test._pathlib_home
    # Check that variable home is equal to the output of pathlib_home
    assert (home == path_test._pathlib_home)
    

# Generated at 2022-06-23 21:38:19.436774
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform="darwin")
    assert p.platform == "darwin"
    assert p._pathlib_home == PurePosixPath('/Users')

# Generated at 2022-06-23 21:38:27.570381
# Unit test for constructor of class Path
def test_Path():
    #assert Path().random.choice([1,2,3]) == 2
    #assert Path().random.choice([1,2,3]) != 2
    assert Path().random.choice([True,False]) == True
    assert Path().random.choice([True,False]) != True
    assert Path().random.choice(['a','b','c']) == 'a'
    assert Path().random.choice(['a','b','c']) != 'a'
    assert Path().random.choice([1,2,3]) != 1
    assert Path().random.choice([1,2,3]) == 1
    assert Path().random.choice([1,2,3]) != 1
    assert Path().random.choice([1,2,3]) == 1
    assert Path().random.choice([1,2,3]) != 1

# Generated at 2022-06-23 21:38:28.995173
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    instance = Path()
    assert instance.project_dir() == '/home/becki/Development/Django/mercenary'


# Generated at 2022-06-23 21:38:34.201101
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import random
    path = Path()
    my_seed = random.randint(0, 10000000)
    my_platform = random.choice(list(PLATFORMS.keys()))
    path = Path(platform=my_platform)
    path.seed(my_seed)
    print(path.dev_dir())
    # Output: /home/emilio/Dev/Valag
    path.seed(my_seed)
    print(path.dev_dir())
    # Output: /home/emilio/Dev/Valag
    path.seed(my_seed)
    print(path.dev_dir())
    # Output: /home/emilio/Dev/Valag


# Generated at 2022-06-23 21:38:37.503244
# Unit test for method root of class Path
def test_Path_root():
    # Preparation
    mock_platform = 'linux'
    path = Path(platform=mock_platform)
    # check
    assert path.root() == '/'


# Generated at 2022-06-23 21:38:40.492786
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("\nTest of method project_path of class Path: ")
    path = Path(platform = 'linux')
    print(path.project_dir())

test_Path_project_dir()

# Generated at 2022-06-23 21:38:41.818804
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert home


# Generated at 2022-06-23 21:38:43.943765
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert path.platform == 'linux'
    assert path.seed == None


# Generated at 2022-06-23 21:38:46.475872
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None
    path = Path(platform='linux')
    assert path is not None
    path = Path(platform='linux', seed=0)
    assert path is not None
    path = Path(seed=0)
    assert path is not None


# Generated at 2022-06-23 21:38:48.357057
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    c = Path()
    print(c.dev_dir())

# Generated at 2022-06-23 21:38:52.759679
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    lang = ['python']
    assert PLATFORMS['linux']['home'] in Path().dev_dir()
    assert PLATFORMS['linux']['home'] in Path().dev_dir()
    assert any(lang in Path().dev_dir() for lang in lang)
    assert any(lang in Path().dev_dir() for lang in lang)

# Generated at 2022-06-23 21:38:56.082825
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from os import path
    p = Path()
    dir = p.dev_dir()
    # print(dir)
    assert path.exists(dir)


# Generated at 2022-06-23 21:39:01.485956
# Unit test for method root of class Path
def test_Path_root():
    global p, method_name
    p = Path("linux")
    method_name = 'Path.root()'
    print("Testing Method " + method_name)
    if not p.root() == "/":
        print("Test Failed with result of: " + p.root())
        return False
    else:
        print("Test passed")
        return True


# Generated at 2022-06-23 21:39:05.558349
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("Test for Path")
    x = Path()
    for i in range(10):
        print(x.project_dir())
    return x.project_dir()

# Generated at 2022-06-23 21:39:07.596950
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    SUT = Path()
    val = SUT.project_dir()
    assert type(val) == str


# Generated at 2022-06-23 21:39:09.062476
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())
    

# Generated at 2022-06-23 21:39:10.331608
# Unit test for constructor of class Path
def test_Path():
    print("Testing Path")
    path = Path()
    assert isinstance(path.random, BaseProvider)



# Generated at 2022-06-23 21:39:12.152184
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path("linux")
    print(path.dev_dir())


# Generated at 2022-06-23 21:39:17.022156
# Unit test for method user of class Path
def test_Path_user():
    assert Path('/home/').user() == '/home/brenda'
    assert Path('/home/').user() == '/home/melony'
    assert Path('/home/').user() == '/home/danika'
    assert Path('/home/').user() == '/home/laquanda'

# Generated at 2022-06-23 21:39:18.346815
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    print(p.home())


# Generated at 2022-06-23 21:39:19.880223
# Unit test for method project_dir of class Path
def test_Path_project_dir():
	p = Path()
	for i in range(0,10):
		print(p.project_dir())

# Generated at 2022-06-23 21:39:22.132449
# Unit test for constructor of class Path
def test_Path():
    pathObject = Path.__init__(Path)
    return pathObject
    

# Generated at 2022-06-23 21:39:24.009582
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p._pathlib_home, PureWindowsPath) or isinstance(p._pathlib_home, PurePosixPath)

# Generated at 2022-06-23 21:39:25.326239
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert(isinstance(p.user(), str))

# Generated at 2022-06-23 21:39:34.709751
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.Meta.name == 'path'
    assert isinstance(path.random.choice(['Development', 'Dev']), str)
    assert isinstance(path.random.choice(PROGRAMMING_LANGS), str)
    assert isinstance(path.random.choice(PROJECT_NAMES), str)
    assert isinstance(path.random.choice(PLATFORMS['win32']['home']), str)
    assert isinstance(path.random.choice(FOLDERS), str)
    assert isinstance(path.random.choice(USERNAMES), str)
    assert isinstance(path.random.choice(PLATFORMS), dict)


# Generated at 2022-06-23 21:39:35.779603
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())



# Generated at 2022-06-23 21:39:38.924179
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())
    print(p.dev_dir())
    print(p.users_folder())
    print(p.user())
    print(p.home())
    print(p.root())

# Generated at 2022-06-23 21:39:40.094879
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print("Path generated: ", p.user())


# Generated at 2022-06-23 21:39:41.349094
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:39:42.925192
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/taneka/Development/Python'

# Generated at 2022-06-23 21:39:43.792383
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.home())

# Generated at 2022-06-23 21:39:44.874227
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    class_path = Path()
    print(class_path.dev_dir())

# Generated at 2022-06-23 21:39:47.856957
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    d = Path()
    assert d.user() in ('/home/oretha', '/home/taneka', '/home/sherrell', '/home/sherika')


# Generated at 2022-06-23 21:39:49.116587
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    result = Path().project_dir()
    assert result == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:39:53.003001
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print('Path.project_dir(): ', '\n')
    for i in range(0, 1):
        path = Path()
        print('   ', path.project_dir(), '\n')

# Generated at 2022-06-23 21:39:55.602500
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/stonewall/Development/Golang'


# Generated at 2022-06-23 21:39:56.880629
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:39:57.965014
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print(Path().project_dir())

# Generated at 2022-06-23 21:40:00.621218
# Unit test for method user of class Path
def test_Path_user():
    """Test method 'user' of class 'Path'."""
    p = Path()
    assert p.user() == "/home/brittanny"


# Generated at 2022-06-23 21:40:01.844499
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/dannette'

# Generated at 2022-06-23 21:40:04.837814
# Unit test for method root of class Path
def test_Path_root():
    # Setup
    provider = Path()
    # Exercise
    string = provider.root()
    # Verify
    assert string == "/home"


# Generated at 2022-06-23 21:40:07.315093
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() in ['/', 'C:\\', 'D:\\']


# Generated at 2022-06-23 21:40:09.449677
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    Path()
    assert Path.dev_dir(Path) == Path.dev_dir(Path)

# Generated at 2022-06-23 21:40:10.501456
# Unit test for method home of class Path
def test_Path_home():
    pass
