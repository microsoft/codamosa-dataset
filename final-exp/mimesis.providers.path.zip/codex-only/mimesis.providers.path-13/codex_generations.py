

# Generated at 2022-06-23 21:30:15.930606
# Unit test for method home of class Path
def test_Path_home():
    # Initializing Path class
    path = Path()
    home = path.home()
    # Checking the result
    assert type(home) is str
    if 'win' in path.platform:
        assert len(home) == 6
        assert home == 'C:\\Users'
    else:
        assert len(home) == 5
        assert home == '/home'

# Generated at 2022-06-23 21:30:22.532992
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    random_number = random.randint(1, 100)
    random_platform = random.choice(['linux', 'darwin', 'win32', 'win64'])
    p = Path(random_platform)

    for i in range(random_number):
        assert p.users_folder() == str(p._pathlib_home.joinpath(p.user(), p.random.choice(FOLDERS)))


# Generated at 2022-06-23 21:30:23.838438
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert not None == path.project_dir()


# Generated at 2022-06-23 21:30:26.937985
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert len(path.home()) == 5
    assert len(path.root()) == 1
    assert len(path.users_folder()) == 11
    assert len(path.dev_dir()) == 17
    assert len(path.project_dir()) == 21

# Generated at 2022-06-23 21:30:28.507567
# Unit test for constructor of class Path
def test_Path():
    path = Path('darwin')
    assert path.root() == '/'

# Generated at 2022-06-23 21:30:31.112788
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in ['/home/tuyet', '/home/garth', '/home/kristal']


# Generated at 2022-06-23 21:30:32.887953
# Unit test for method root of class Path
def test_Path_root():
    print(Path().root())

# Generated at 2022-06-23 21:30:35.560442
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert isinstance(p.root(), str) == True


# Generated at 2022-06-23 21:30:37.976144
# Unit test for constructor of class Path
def test_Path():
    provider = Path()
    assert provider.pathlib_home == Path().pathlib_home
    assert provider.platform == sys.platform

# Generated at 2022-06-23 21:30:42.773393
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import ProgrammingLang
    path = Path(platform='linux')
    for _ in range(20):
        assert path.project_dir() == f"/home/maryln/Development/{path.random.choice(list(ProgrammingLang)).value}/{path.random.choice(PROJECT_NAMES)}"

# Generated at 2022-06-23 21:30:46.718099
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    path = Path()
    assert "C:" in path.root() if path.platform == "win32" else path.root() == "/"


# Generated at 2022-06-23 21:30:49.803951
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    # str
    assert isinstance(path.project_dir(), str)
    assert bool(path.project_dir())
    assert len(path.project_dir()) > 0

# Generated at 2022-06-23 21:30:52.463194
# Unit test for method home of class Path
def test_Path_home():
    path_home = Path().home()
    assert path_home.startswith(
        "/" if sys.platform != "win32" else "C:\\Users",
    )


# Generated at 2022-06-23 21:30:55.500873
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path."""
    path = Path()
    user = path.user()
    assert user in ['/home/sherrell', '/home/taneka', '/home/oretha',
                    '/home/sherika']

# Generated at 2022-06-23 21:30:57.340332
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert 1 == 1

# Generated at 2022-06-23 21:30:58.695782
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    pathObj = Path()
    print(pathObj.project_dir())

# Generated at 2022-06-23 21:31:00.438562
# Unit test for method home of class Path
def test_Path_home():
    f = Path('linux')
    assert f.home() == '/home'


# Generated at 2022-06-23 21:31:02.166565
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    pathTool = Path()
    print(pathTool.project_dir())


# Generated at 2022-06-23 21:31:03.555106
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:31:05.151627
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    file = "05_path"
    assert "-rw-rw-r--" in open(file).read()

# Generated at 2022-06-23 21:31:07.973267
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    # print(path.home())
    assert isinstance(path.home(), str)


# Generated at 2022-06-23 21:31:13.005549
# Unit test for constructor of class Path
def test_Path():
    """Unit test for Path"""
    p = Path()
    print("Constructor ==> ", p)
    print("Documentation ==> ", Path.__doc__)
    print("Meta ==> ", p.Meta)
    print("Meta ==> ", p.Meta.name)


# Generated at 2022-06-23 21:31:13.399353
# Unit test for constructor of class Path
def test_Path():
    Path()

# Generated at 2022-06-23 21:31:19.441779
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.platform == sys.platform
    assert path.home() is not None

if __name__ == "__main__":
    path = Path()
    print("home: ", path.home())
    print("root: ", path.root())
    print("user: ", path.user())
    print("users_folder: ", path.users_folder())
    print("dev_dir: ", path.dev_dir())
    print("project_dir: ", path.project_dir())

# Generated at 2022-06-23 21:31:23.113790
# Unit test for method home of class Path
def test_Path_home():
    p = Path('linux')
    path = p.home()
    assert PurePosixPath(path) == PurePosixPath('/home')
    assert path == '/home'



# Generated at 2022-06-23 21:31:24.433450
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:31:25.613576
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:31:27.014735
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    mimesis = Path()
    assert mimesis.dev_dir()

# Generated at 2022-06-23 21:31:30.233182
# Unit test for constructor of class Path
def test_Path():
    # test Init method
    a = Path()
    assert a.platform == sys.platform
    assert a._pathlib_home == PureWindowsPath('/home')

# Generated at 2022-06-23 21:31:38.864058
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import Platform
    import os
    import platform

    os_platform = platform.system().lower()
    x = Path(platform = os_platform)
    y = Path(platform = "win32")

    assert x.platform.lower() == os_platform
    assert y.platform.lower() == Platform.WINDOWS

    assert x.home() == os.path.join(os.path.expanduser("~"))
    assert y.home() == os.path.join(os.path.expanduser("~"))

    assert x.home() == str(x._pathlib_home)
    assert y.home() == str(y._pathlib_home)

test_Path_home()


# Generated at 2022-06-23 21:31:40.919074
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    result = provider.home()
    print(result)
    
    

# Generated at 2022-06-23 21:31:45.443577
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # pathlib_home / user / development_folder / stack
    # /home / sherika / Development / Falcon

    path = Path(platform='win32').project_dir()
    assert path == 'C:\\Users\\tonisha\\Development\\Haskell\\Mimesis'

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:31:46.935501
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform

# Generated at 2022-06-23 21:31:48.564109
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == "/home/daphine/Development/Python"
    assert path.dev_dir() == "/home/jennie/Development/Java"

# Generated at 2022-06-23 21:31:51.636574
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_path = path.project_dir()
    assert project_path.startswith("/home") or project_path.startswith("C:"), "Path should start with /home or C:"

# Generated at 2022-06-23 21:31:53.402007
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    result = Path("linux").dev_dir()
    assert result == '/home/alfonso/dev/python'

# Generated at 2022-06-23 21:31:54.573339
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path("linux")
    print(p.project_dir())

# Generated at 2022-06-23 21:31:56.562990
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home()


# Generated at 2022-06-23 21:31:58.878223
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())


# Generated at 2022-06-23 21:32:00.223212
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() == '/home/taneka/Pictures'

# Generated at 2022-06-23 21:32:02.047144
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method 'root' of class 'Path' """
    assert Path().root() == '/'


# Generated at 2022-06-23 21:32:02.747949
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.seed(0)
    assert path.user() == '/home/jefferey'

# Generated at 2022-06-23 21:32:04.653667
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    u = p.user()
    assert isinstance(u, str) is True and len(u) > 0

# Generated at 2022-06-23 21:32:11.610228
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    # Check that the result is not empty, and that the result is a string
    assert (p.user() != "")
    assert (isinstance(p.user(), str))
    # Check that the result is a path in the home folder
    assert (p.user()[:5] == "/home")
    # Check that the result matches the expected format
    assert ("/home/" + p.random.choice(USERNAMES) in p.user())


# Generated at 2022-06-23 21:32:14.164767
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path_obj = Path()
    project_dir = path_obj.project_dir()
    print(project_dir)

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:32:16.605683
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    print('Root:', result)
    assert len(result) > 0


# Generated at 2022-06-23 21:32:20.927623
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    paths = Path('linux')
    result = paths.users_folder()
    assert result.startswith('/home'), f"must starts with '/home'"
    assert 'Pictures' in result, f"must have 'Pictures' in '{result}'"
    print(result)


# Generated at 2022-06-23 21:32:22.991016
# Unit test for method user of class Path
def test_Path_user():
    """Unit tests for Path.user."""
    path = Path()
    assert path.user() == '/home/natosha'


# Generated at 2022-06-23 21:32:26.029012
# Unit test for method user of class Path
def test_Path_user():
    """Test for the user.

    1. the result should be the same as str(self._pathlib_home / user) when
        user = 'oretha', self._pathlib_home=/home
    2. the result should be the same as str(self._pathlib_home / user) when
        user = 'vania', self._pathlib_home=/home
    3. the result should be the same as str(self._pathlib_home / user) when
        user = 'hlavacek', self._pathlib_home=/home
    """
    user = Path().user()
    assert user == '/home/oretha' or user == '/home/vania' or user == '/home/hlavacek'

# Generated at 2022-06-23 21:32:29.308447
# Unit test for method user of class Path
def test_Path_user():
    pts = Path()
    path = pts.user()
    #path_create = PurePath(path)
    path_create = path
    assert path_create.is_dir() == False



# Generated at 2022-06-23 21:32:31.607025
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path('linux')
    result = path.project_dir()
    assert len(result.split('/')) == 5

# Generated at 2022-06-23 21:32:34.713726
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    print(p.user())
    print(p.user())
    print(p.user())
    print(p.user())
    print(p.user())


# Generated at 2022-06-23 21:32:39.802362
# Unit test for method home of class Path
def test_Path_home():
    # Create instance of class Path
    path = Path()
    for i in range(10):
        assert not path.home() is None
        # Test for string type
        assert isinstance(path.home(), str)
        # Test for pure posix path
        assert isinstance(path.home(), PurePosixPath)
        # Test for path to home dir
        assert path.home() == "/home"



# Generated at 2022-06-23 21:32:42.886201
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    l = []
    for i in range(1000000):
        l.append(p.users_folder())
    print(len(set(l)))



# Generated at 2022-06-23 21:32:44.196895
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:46.438417
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:32:47.873478
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert len(Path().project_dir()) == 53

# Generated at 2022-06-23 21:32:56.486484
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import datetime
    from pathlib import PureWindowsPath
    
    #pathlib_home = PureWindowsPath('C:\\Users\\Eric')
    print("test_Path_project_dir")
    p = Path()
    p.random.seed(datetime.datetime.now())
    dev_dir = p.dev_dir()
    print("dev_dir: "+dev_dir)
    project_dir = p.project_dir()
    print("project_dir: "+project_dir)
    project_dir2 = p.project_dir()
    print("project_dir2: "+project_dir2)
    assert dev_dir in project_dir
    assert dev_dir in project_dir2



# Generated at 2022-06-23 21:33:06.683847
# Unit test for method user of class Path
def test_Path_user():
    p = Path()

# Generated at 2022-06-23 21:33:08.745897
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print('Path.root()\t=', path.root())


# Generated at 2022-06-23 21:33:09.407847
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.root()


# Generated at 2022-06-23 21:33:11.086061
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == Path().user()

# Generated at 2022-06-23 21:33:13.560285
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_provider = Path()
    assert not path_provider.dev_dir().__contains__('/')



# Generated at 2022-06-23 21:33:18.101768
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    P_users_folder = Path().users_folder()
    assert P_users_folder[0] == '/'
    assert P_users_folder[1] == '/'
    assert P_users_folder.split('/')[-1] in FOLDERS


# Generated at 2022-06-23 21:33:20.514005
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    provider = Path()
    print(provider.users_folder())


if __name__ == '__main__':
    test_Path_users_folder()

# Generated at 2022-06-23 21:33:26.610947
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    def check_return(return_value):
        assert isinstance(return_value, str)
        assert return_value.startswith('/home/')
        assert return_value.endswith('/mercenary')
        assert return_value.count('/') == 5

    path = Path(seed = 1234)
    return_value = path.project_dir()
    check_return(return_value)

    path = Path(seed = 1234)
    return_value = path.project_dir()
    check_return(return_value)

# Generated at 2022-06-23 21:33:28.999555
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

# Generated at 2022-06-23 21:33:30.862630
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print('\nПапка пользователя:', path.users_folder())


# Generated at 2022-06-23 21:33:32.901666
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:33:35.556293
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test = Path()
    project_dir = test.project_dir()
    assert (
        '/home/dorene/Development/Python' in project_dir and
        'mercenary' in project_dir
    )

# Generated at 2022-06-23 21:33:39.441936
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    root = p.root()
    if 'win' in p.platform:
        assert root == 'C:\\'
    else:
        assert root == '/'


# Generated at 2022-06-23 21:33:42.010604
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pathObj = Path()
    path = pathObj.users_folder()
    assert path == '/home/noe/Music' or path == 'C:\\Users\\noe\\Music'

# Generated at 2022-06-23 21:33:43.623407
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    result = Path().users_folder()
    assert result == '/home/taneka/Pictures'



# Generated at 2022-06-23 21:33:47.316688
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    foo = Path()
    # home = foo.home()
    # users_folder = foo.users_folder()
    dev_dir = foo.dev_dir()
    # assert home
    # assert users_folder
    assert dev_dir

# Generated at 2022-06-23 21:33:49.659253
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    pl = Path()
    print("\nPath.dev_dir():",pl.dev_dir())


# Generated at 2022-06-23 21:33:53.718023
# Unit test for method user of class Path
def test_Path_user():
    path = Path('win32')
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())

# test_Path_user()

# Generated at 2022-06-23 21:33:57.532461
# Unit test for method home of class Path
def test_Path_home():
    """Test for method home of class Path."""
    path_generator = Path()
    for _ in range(100):
        assert path_generator.home() == '/home'


# Generated at 2022-06-23 21:34:01.123280
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() in (
        "/",
        "C:/",
    )


# Generated at 2022-06-23 21:34:03.226321
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for i in range(0,10):
        p = Path()
        p.users_folder()


# Generated at 2022-06-23 21:34:04.235119
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(str(path.user()))

# Generated at 2022-06-23 21:34:06.101435
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path('win32')
    print(p.users_folder())
    assert True


# Generated at 2022-06-23 21:34:08.157335
# Unit test for method root of class Path
def test_Path_root():
   path = Path()
   root = path.root()
   assert root == '/'


# Generated at 2022-06-23 21:34:10.078581
# Unit test for method root of class Path
def test_Path_root(): 
    provider = Path()
    result = provider.root()
    assert result == '/home'

# Generated at 2022-06-23 21:34:11.001299
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'


# Generated at 2022-06-23 21:34:16.403066
# Unit test for method user of class Path
def test_Path_user():
    """Test case for method user of class Path."""
    p = Path()
    for _ in range(100):
        user = p.user()
        assert isinstance(user, str)
        assert user
        assert user.lower() == user
        assert user.startswith(p.home())


# Generated at 2022-06-23 21:34:18.863085
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path = path.root()
    assert path == '/' or path == 'C:\\'


# Generated at 2022-06-23 21:34:21.229103
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path"""
    from mimesis.enums import Platform
    assert Path(platform=Platform.LINUX).home() == '/home'
    assert Path(platform=Platform.LINUX).home() is not '/tmp'

# Generated at 2022-06-23 21:34:23.032761
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())
    # Output: /home/sherrell/Development/Python



# Generated at 2022-06-23 21:34:24.418064
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    res = path.user()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:34:29.176319
# Unit test for method root of class Path
def test_Path_root():
    print('Method root start...')

    # Create instance of class
    path = Path()

    # Tests
    print(path.root())
    print(path.root())
    print(path.root())

    print('Method root end...')



# Generated at 2022-06-23 21:34:30.640124
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())

# Generated at 2022-06-23 21:34:33.476938
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    _0 = Path()
    _1 = Path()
    for _ in range(100):
        assert _0.project_dir() == _1.project_dir()


# Generated at 2022-06-23 21:34:36.384772
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home_path = p.home()
    print(home_path)

if __name__ == '__main__':
    test_Path_home()

# Generated at 2022-06-23 21:34:39.116116
# Unit test for method root of class Path
def test_Path_root():
    """Unittest for method root of class Path"""
    # arrange
    p = Path()
    # act
    result = p.root()
    # assert
    assert len(result) == 1


# Generated at 2022-06-23 21:34:43.250018
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # print('{0:=<40}'.format('-'))
    for i in range(1, 10):
        test = Path()
        print(test.dev_dir())

test_Path_dev_dir()

# Generated at 2022-06-23 21:34:45.086153
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

test_Path_dev_dir()

# Generated at 2022-06-23 21:34:45.904121
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:34:48.464380
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    path = p.home()
    expected = r'/home'
    assert path == expected


# Generated at 2022-06-23 21:34:50.308772
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path_provider = Path()
    for i in range(0, 100):
        print(path_provider.users_folder())


# Generated at 2022-06-23 21:34:52.365187
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:34:55.013052
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    assert home
    assert isinstance(home, str)


# Generated at 2022-06-23 21:34:56.408101
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform



# Generated at 2022-06-23 21:34:58.192529
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    result = p.home()

    assert result == '/home'


# Generated at 2022-06-23 21:35:05.222377
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    current_platform = sys.platform
    path1 = Path()
    path2 = Path('win32')
    path3 = Path('win64')
    path4 = Path('linux')
    path5 = Path('darwin')
    assert path1._pathlib_home == path4._pathlib_home
    assert path2._pathlib_home == PureWindowsPath('C:\\Users')
    assert path3._pathlib_home == PureWindowsPath('C:\\Users')
    assert path4._pathlib_home == PurePosixPath('/home')
    assert path5._pathlib_home == PurePosixPath('/Users')
    assert path1.platform == current_platform
    assert path2.platform == 'win32'
    assert path3.platform == 'win64'
   

# Generated at 2022-06-23 21:35:07.265413
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    for i in range(0, 1):
        print(p.users_folder())


# Generated at 2022-06-23 21:35:18.387888
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/lavette/Development/Typescript'
    assert Path().dev_dir() == '/home/lynn/Dev/Ruby'
    assert Path().dev_dir() == '/home/sherika/Development/Scala'
    assert Path().dev_dir() == '/home/sherrell/Development/Fortran'
    assert Path().dev_dir() == '/home/porsha/Dev/Ruby'
    assert Path().dev_dir() == '/home/lavette/Development/Scala'
    assert Path().dev_dir() == '/home/sherika/Development/COBOL'
    assert Path().dev_dir() == '/home/lynn/Dev/Ruby'
    assert Path().dev_dir() == '/home/lynn/Development/Python'
    assert Path().dev_dir

# Generated at 2022-06-23 21:35:20.258817
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    actual = path.user()
    assert actual == '/home/oretha'

# Generated at 2022-06-23 21:35:25.177792
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path.

    :return: True if function is correct, otherwise False.
    """
    path_instance = Path("win32")

    return isinstance(path_instance.random, random.Random) and \
        isinstance(path_instance.tokenizer, Tokenizer)


# Generated at 2022-06-23 21:35:34.930325
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test method dev_dir of class Path.

    :return: True if test passed else False.
    :rtype: bool
    """
    from pathlib import PureWindowsPath

    # Init object path with custom home(pathlib object)
    home = PureWindowsPath()
    home /= PLATFORMS["win64"]["home"]
    home /= 'home'
    home /= 'boris'

    path = Path(platform='win64', seed=101)
    path._pathlib_home = home

    (p1, p2, p3, p4) = ('/home/boris', '/Development', '/Python', '/osaka')
    dev_dir = path.dev_dir()


# Generated at 2022-06-23 21:35:36.657898
# Unit test for constructor of class Path
def test_Path():

    assert Path()
    #assert Path("linux")
    #assert Path("win32")
    #assert Path("win64")


# Generated at 2022-06-23 21:35:38.011803
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root =='/'


# Generated at 2022-06-23 21:35:39.340177
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for i in range(10):
        print(path.user())


# Generated at 2022-06-23 21:35:40.731239
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for _ in range(10):
        print(path.project_dir())

# Generated at 2022-06-23 21:35:43.009883
# Unit test for method user of class Path
def test_Path_user():
    # create instance with testable methods
    path = Path();
    # call method user()
    # check that method is correct
    assert path.user() == "/home/Jimbo";


# Generated at 2022-06-23 21:35:45.186780
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    path = p.user()
    assert isinstance(path, str)

# Generated at 2022-06-23 21:35:49.035123
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())
    # /home/taneka/Development/Falcon/mercenary

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:35:51.739447
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    print(result)


# Generated at 2022-06-23 21:35:52.745323
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:35:54.865277
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    import platform

    sys_platform = platform.system()
    path = Path(sys_platform)
    result = path.project_dir()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:35:57.024180
# Unit test for method root of class Path
def test_Path_root():
    path_provider = Path()
    assert path_provider.root() == '/'


# Generated at 2022-06-23 21:35:58.740424
# Unit test for method root of class Path
def test_Path_root():
    expected = "/"
    generated = Path().root()

    assert(expected == generated)


# Generated at 2022-06-23 21:36:03.539988
# Unit test for method home of class Path
def test_Path_home():
    """Test case for method home of class Path."""
    path = Path()
    results = []
    for _ in range(0, 100):
        results.append(str(path.home()))
    assert len(results) != 0
    for i in results:
        print(i)
    return results

# Generated at 2022-06-23 21:36:07.623324
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())
    print(p.dev_dir())
    print(p.dev_dir())
    print(p.dev_dir())


# Generated at 2022-06-23 21:36:09.068007
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)

# Generated at 2022-06-23 21:36:12.034008
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    '''
    Test Path.project_dir() method
    '''
    units = ['linux', 'darwin', 'win32', 'win64']
    for unit in units:
        Path(platform=unit)

# Generated at 2022-06-23 21:36:13.363193
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:36:15.689659
# Unit test for method home of class Path
def test_Path_home():
    _obj = Path()
    _output = _obj.home()
    assert isinstance(_output, str) and len(_output) > 0


# Generated at 2022-06-23 21:36:17.455889
# Unit test for method home of class Path
def test_Path_home():
    path = Path(sys.platform)
    assert isinstance(path.home(), str)

# Generated at 2022-06-23 21:36:24.101880
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path."""
    path = Path()
    print(path.dev_dir()) # /home/hiram/Development/Golang
    print(path.dev_dir()) # /home/lazaro/Development/JavaScript
    print(path.dev_dir()) # /home/marc/Development/Rust
    print(path.dev_dir()) # /home/jasmine/Development/Python
    print(path.dev_dir()) # /home/korey/Development/Python
    print(path.dev_dir()) # /home/daniell/Development/Ruby


# Generated at 2022-06-23 21:36:26.797382
# Unit test for method root of class Path
def test_Path_root():
    path_ = Path()
    assert len(path_.root()) > 0
    assert path_.root() in PLATFORMS.values()


# Generated at 2022-06-23 21:36:30.965548
# Unit test for method home of class Path
def test_Path_home():
  from pathlib import PurePosixPath, PureWindowsPath
  from mimesis.enums import OperatingSystem
  from mimesis.providers.path import Path
  path = Path(platform=OperatingSystem.WINDOWS)
  assert str(PureWindowsPath()) == path.home()
  # assert str(PurePosixPath()/"home") == path.home()

# Generated at 2022-06-23 21:36:33.127114
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method 'dev_dir' of class 'Path'"""
    path = Path()
    print(path.dev_dir())



# Generated at 2022-06-23 21:36:35.771856
# Unit test for constructor of class Path
def test_Path():
    # Set valid platform
    path = Path(platform='linux')

    assert isinstance(path._pathlib_home, PurePosixPath)



# Generated at 2022-06-23 21:36:37.055064
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:36:39.711131
# Unit test for constructor of class Path
def test_Path():
    """Test Path() class constructor."""
    obj = Path()
    assert isinstance(obj._pathlib_home, PurePosixPath)



# Generated at 2022-06-23 21:36:40.727622
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())


test_Path_users_folder()

# Generated at 2022-06-23 21:36:46.802959
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path(platform = 'linux')
    t_path = path.dev_dir()
    assert t_path.find(PLATFORMS['linux']['home']) != -1
    assert t_path.find('Development') != -1
    assert t_path.find('.py') == -1
    # Unit test for method home of class Path

# Generated at 2022-06-23 21:36:48.720128
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())
    return


# Generated at 2022-06-23 21:36:50.853047
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

if __name__ == "__main__":
    test_Path_project_dir()
    print("Everything passed")

# Generated at 2022-06-23 21:36:52.065705
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/sherika/Dev/Python'

# Generated at 2022-06-23 21:36:54.448688
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    word = Path().dev_dir()
    print("\n{} =  {}".format("Path().dev_dir()", word))
    assert word == '/home/taneka/Development/Python'


# Generated at 2022-06-23 21:36:56.430791
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('linux')
    project_dir = p.project_dir()
    # print(project_dir)
    assert isinstance(project_dir, str)

# Generated at 2022-06-23 21:36:58.926445
# Unit test for method root of class Path
def test_Path_root():
    provider = Path()
    assert provider.root() == '/'

if __name__ == "__main__":
    test_Path_root()

# Generated at 2022-06-23 21:37:01.452905
# Unit test for constructor of class Path
def test_Path():
    print("Testing Path:")
    p = Path()
    assert p.platform == sys.platform
    assert 'Path' in p.Meta.name
    

# Generated at 2022-06-23 21:37:03.306350
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert 'Development' in path.project_dir()

# Generated at 2022-06-23 21:37:06.541617
# Unit test for method user of class Path
def test_Path_user():
    # check for Path.user()
    path = Path(platform=PLATFORMS['linux']['name'])
    path.random.seed(106) # setting the random seed
    assert path.user() == '/home/taneka'

# Generated at 2022-06-23 21:37:08.104459
# Unit test for method home of class Path
def test_Path_home():
    tester = Path()
    result = tester.home()
    assert result == '/home'


# Generated at 2022-06-23 21:37:09.240116
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-23 21:37:10.749981
# Unit test for constructor of class Path
def test_Path():
    instance = Path() # pass
    assert isinstance(instance, Path)


# Generated at 2022-06-23 21:37:17.136973
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_provider = Path()
    print(path_provider.root())
    print(path_provider.home())
    print(path_provider.user())
    print(path_provider.users_folder())
    print(path_provider.dev_dir())
    print(path_provider.project_dir())

# Generated at 2022-06-23 21:37:18.371896
# Unit test for method users_folder of class Path
def test_Path_users_folder():
	path = Path()
	print(path.users_folder())


# Generated at 2022-06-23 21:37:20.037642
# Unit test for method home of class Path
def test_Path_home():
	a = Path(platform = 'linux')
	assert a.home() == '/home'


# Generated at 2022-06-23 21:37:26.118477
# Unit test for constructor of class Path
def test_Path():
	path_provider = Path()
	print(path_provider.user())
	print(path_provider.users_folder())
	print(path_provider.dev_dir())
	print(path_provider.project_dir())
	print(path_provider.dev_dir())
	print(path_provider.project_dir())

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:37:28.659333
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert str(path) == 'Path()'
    assert repr(path) == 'Path()'


# Generated at 2022-06-23 21:37:36.745431
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    test_path = Path()
    test_path.dev_dir() == '/home/colby/Development/Python'
    test_path.dev_dir() == '/home/jeanie/Development/Django'
    test_path.dev_dir() == '/home/eura/Development/React'
    test_path.dev_dir() == '/home/raymon/Dev/Python'
    test_path.dev_dir() == '/home/filiberto/Dev/Flask'
    test_path.dev_dir() == '/home/shalon/Dev/React'
    test_path.dev_dir() == '/home/james/Development/Python'
    test_path.dev_dir() == '/home/rayna/Development/React'

# Generated at 2022-06-23 21:37:38.071375
# Unit test for method user of class Path
def test_Path_user():
    path = Path('win32')
    path.home()
    path.user()

# Generated at 2022-06-23 21:37:40.784634
# Unit test for constructor of class Path
def test_Path():
    p = Path('win32')
    assert p.platform == 'win32'

# Generated at 2022-06-23 21:37:42.206104
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert len(p.root()) > 1


# Generated at 2022-06-23 21:37:47.664782
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test Path.project_dir method."""
    p = Path()
    path = p.project_dir()
    assert isinstance(path, str)
    assert 'home/' in path
    assert '/Development/' in path
    assert '/' in path[-1]
    assert path[0] == '/'


# Generated at 2022-06-23 21:37:49.626268
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform

# Generated at 2022-06-23 21:37:51.561131
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == "/home/ashlie/Documents"

# Generated at 2022-06-23 21:37:53.818451
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path"""
    path = Path()
    assert path.home() == '/home' # OK

# Generated at 2022-06-23 21:37:55.048384
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() != Path().user()


# Generated at 2022-06-23 21:37:57.292936
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    directories = [Path(platform = 'linux').users_folder() for i in range(100)]
    for directory in directories:
        print(directory)


# Generated at 2022-06-23 21:38:00.515182
# Unit test for constructor of class Path
def test_Path():
    mu = Path()
    s = mu.__sizeof__()
    print(s)
    assert mu is not None


# Generated at 2022-06-23 21:38:02.594782
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == '/home/taneka/Pictures'


# Generated at 2022-06-23 21:38:05.086399
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(1):
        pathObj = Path()
        print(pathObj.project_dir())


# Generated at 2022-06-23 21:38:06.209978
# Unit test for constructor of class Path
def test_Path():
    assert Path().Meta.name == 'path'

# Generated at 2022-06-23 21:38:08.965012
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # returns /home/tinisha/Dev/Flask
    p = Path()
    p.dev_dir()



# Generated at 2022-06-23 21:38:10.317173
# Unit test for method user of class Path
def test_Path_user():
    p=Path()
    print(p.user())


# Generated at 2022-06-23 21:38:11.983736
# Unit test for method user of class Path
def test_Path_user():
    user = Path().user()
    assert type(user) == str


# Generated at 2022-06-23 21:38:13.471416
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    file_path = Path.users_folder()
    assert file_path != None

# Generated at 2022-06-23 21:38:15.584747
# Unit test for method home of class Path
def test_Path_home():
    path = Path(platform='linux')
    home_path = path.home()
    assert type(home_path) == str

# Generated at 2022-06-23 21:38:17.401520
# Unit test for method user of class Path
def test_Path_user():
    """Test for method 'user' in class 'Path'."""
    path = Path()
    assert (path.user())

# Generated at 2022-06-23 21:38:21.239448
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    L = [p.users_folder() for i in range(1000)]
    s = set(L)
    assert len(L) == len(s), 'probleme avec Path.users_folder()'


# Generated at 2022-06-23 21:38:22.834479
# Unit test for constructor of class Path
def test_Path():
    pp = Path()
    assert pp.random is not None and pp.datetime is not None and pp.platform is not None

# Generated at 2022-06-23 21:38:23.833661
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() is not None

# Generated at 2022-06-23 21:38:26.000988
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    temp = path.root()
    assert temp is not None


# Generated at 2022-06-23 21:38:27.538344
# Unit test for method user of class Path
def test_Path_user():
    Path(platform='linux').user()
    assert Path(platform='linux').user() == '/home/micaela'


# Generated at 2022-06-23 21:38:29.053382
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    assert Path().root() == "/"


# Generated at 2022-06-23 21:38:29.841435
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == "/"


# Generated at 2022-06-23 21:38:31.076675
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert True


# Generated at 2022-06-23 21:38:32.598704
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert '/home' in p.home()

test_Path_home()


# Generated at 2022-06-23 21:38:35.409212
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.builtins import EN
    p = Path('win64')
    for _ in range(10):
        print(p.project_dir())


# Generated at 2022-06-23 21:38:37.632956
# Unit test for method home of class Path
def test_Path_home():
    test_home_path = Path()
    generated_home_path = test_home_path.home()
    assert generated_home_path == '/home'

# Generated at 2022-06-23 21:38:40.251897
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(4):
        path = Path()
        print(path.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:38:43.026655
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for Method 'user' of Class 'Path'"""
    path = Path()
    path.seed(0)
    exp = '/home/gertie'
    act = path.user()
    assert act == exp

# Generated at 2022-06-23 21:38:49.936209
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert str(p.project_dir()) in ["/home/user/AppData/Local/Temp/GnuObjectiveC/Iubyf",
                                    "/home/user/.npm/_npx/16086/bin/gulp-cli.cmd",
                                    "/home/user/.nvm/versions/node/v8.7.0/bin/npm"]

# Generated at 2022-06-23 21:38:51.902638
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    home = provider.home()
    assert  home == '/home'


# Generated at 2022-06-23 21:38:55.405231
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert type(p.project_dir()) == str
    assert p.project_dir() != p.project_dir() # UNIT TEST


# Generated at 2022-06-23 21:38:57.162233
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for i in range(100):
        x = Path()
        print(x.dev_dir())

# Generated at 2022-06-23 21:38:58.436839
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    assert p.user() == '/home/geneva'

# Generated at 2022-06-23 21:39:00.343438
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from Path import Path
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:39:01.872065
# Unit test for method home of class Path
def test_Path_home():
    for i in range(20):
        assert (Path().home()) == '/home'


# Generated at 2022-06-23 21:39:05.647462
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dir = path.dev_dir()
    assert isinstance(dir, str)
    assert dir != ''


# Generated at 2022-06-23 21:39:06.517102
# Unit test for constructor of class Path
def test_Path():
    assert (Path()).Meta.name=='path'

# Generated at 2022-06-23 21:39:08.832362
# Unit test for method user of class Path
def test_Path_user():
    """Test Path.user()
    """
    p = Path(platform='darwin')
    assert len(p.user()) > 0


# Generated at 2022-06-23 21:39:19.515997
# Unit test for constructor of class Path
def test_Path():
    if (Path().platform == 'linux2'):
        assert Path().root() == '/'
        assert Path().home() == '/home'
        assert Path().user() == '/home/marc'
        assert Path().users_folder() == '/home/marc/Pictures'
        assert Path().dev_dir() == '/home/marc/Dev/Ruby'
        assert Path().project_dir() == '/home/marc/Dev/Ruby/silverfish'
    elif (Path().platform == 'darwin'):
        assert Path().root() == '/'
        assert Path().home() == '/Users'
        assert Path().user() == '/Users/scott'
        assert Path().users_folder() == '/Users/scott/Pictures'
        assert Path().dev_dir() == '/Users/scott/Dev/Python'
       

# Generated at 2022-06-23 21:39:22.132648
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test Path.dev_dir method."""
    for i in range(10):
        print(Path().dev_dir())


# Generated at 2022-06-23 21:39:23.006076
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:39:25.898825
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    from pathlib import PureWindowsPath
    user_path = path.user()
    user = PureWindowsPath(user_path).last()
    if user not in USERNAMES:
        raise ValueError("{} not in {}".format(user, USERNAMES))

# Generated at 2022-06-23 21:39:36.376445
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    id = 'a4c9a957-4ad6-40ef-ba1d-f8be097b7c00'
    path = Path()
    print("\nВызов path.dev_dir() с реальным UUID:")
    print("UUID установлен в значение: ", id)
    path.seed(id)
    print("Полученное значение: ", path.dev_dir())
    print("Значение без передачи UUID: ", path.dev_dir())


# Generated at 2022-06-23 21:39:37.303700
# Unit test for constructor of class Path
def test_Path():
    p = Path() # noqa

# Generated at 2022-06-23 21:39:38.661861
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:39:39.908166
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    print(a.users_folder())

# Generated at 2022-06-23 21:39:42.553918
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    try:
        path=Path()
        print(path.project_dir())
    except Exception as e:
        print('Error:', e)
    finally:
        print('End')


# Generated at 2022-06-23 21:39:49.306827
# Unit test for constructor of class Path
def test_Path():
    path = Path('darwin')
    assert type(path.root()) == str
    assert len(path.root()) != 0
    assert type(path.home()) == str
    assert len(path.home()) != 0
    assert type(path.user()) == str
    assert len(path.user()) != 0
    assert type(path.users_folder()) == str
    assert len(path.users_folder()) != 0
    assert type(path.dev_dir()) == str
    assert len(path.dev_dir()) != 0
    assert type(path.project_dir()) == str
    assert len(path.project_dir()) != 0

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:39:51.416658
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:39:53.440910
# Unit test for method root of class Path
def test_Path_root():
    path_obj = Path()
    result = path_obj.root()
    assert result == '/'


# Generated at 2022-06-23 21:39:56.656348
# Unit test for method user of class Path
def test_Path_user():
    # Create instance of class 'Path'
    path = Path()
    # Check that result of method 'user' is path to user
    assert path.user() in path.home()

# Generated at 2022-06-23 21:39:58.946089
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    for i in range(100):
        path = Path.dev_dir(p)
        print(path)

# Generated at 2022-06-23 21:39:59.929548
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pt = Path()
    pt.users_folder()

# Generated at 2022-06-23 21:40:01.955885
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


# Generated at 2022-06-23 21:40:03.401738
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()

# Generated at 2022-06-23 21:40:06.221123
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() != None
    print('test_Path_project_dir PASSED')

test_Path_project_dir()


# Generated at 2022-06-23 21:40:12.800089
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for n in range(1000):
        test = Path()
        project_dir = test.project_dir()
        print(n, project_dir)
        #print(type(project_dir))
        #print(f'{project_dir.__dir__()}')
        #print(f'{project_dir.__str__}')
        #print(f'{project_dir.capitalize()}')
    return True
