

# Generated at 2022-06-23 21:30:26.797457
# Unit test for method user of class Path

# Generated at 2022-06-23 21:30:29.875153
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p_users_folder = Path().users_folder()
    # print(p_users_folder)
    assert p_users_folder != ''


# Generated at 2022-06-23 21:30:31.186060
# Unit test for method home of class Path
def test_Path_home():
    obj = Path()
    path = obj.home()
    assert(path != None)



# Generated at 2022-06-23 21:30:37.975501
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Gender
    path = Path()
    users_folder = path.users_folder() # generate a pseudo-random users folder
    print(users_folder)
    user = path.user() # generate a pseudo-random user
    print(user)
    assert users_folder == '/Users/karylaboss/Library' # should be the same


# Generated at 2022-06-23 21:30:41.922004
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())
    print(p.home())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())
    p = Path()

# Generated at 2022-06-23 21:30:45.188324
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    result = p.root()
    assert result in ['/', 'C:\\']


# Generated at 2022-06-23 21:30:47.726541
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path('win32')
    print(obj.dev_dir())
    assert obj.dev_dir()



# Generated at 2022-06-23 21:30:49.534666
# Unit test for method user of class Path
def test_Path_user():
    assert Path(platform='linux').user() == r'/home/georgie'


# Generated at 2022-06-23 21:30:52.217969
# Unit test for method user of class Path
def test_Path_user():
    p1 = Path()
    assert p1.user() == "/home/randal"
    # user = self.random.choice(USERNAMES)
    # user = user.capitalize() if 'win' in self.platform else user.lower()
    # return str(self._pathlib_home / user)





# Generated at 2022-06-23 21:30:54.347608
# Unit test for constructor of class Path
def test_Path():
    test_path = Path()
    test_platform = sys.platform
    assert test_path.platform == test_platform


# Generated at 2022-06-23 21:30:55.295012
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None

# Generated at 2022-06-23 21:30:57.911991
# Unit test for method home of class Path
def test_Path_home():
    path_home = Path().home()
    assert path_home == '/home'


# Generated at 2022-06-23 21:30:58.895968
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())


# Generated at 2022-06-23 21:31:02.889101
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_obj = Path()
    path = path_obj.dev_dir()
    assert path_obj.platform in path
    assert "\\" not in path
    assert path.count("/") == 4
    assert path.endswith("/")
    

# Generated at 2022-06-23 21:31:04.243608
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    #test
    path = Path()
    path.users_folder()

# Generated at 2022-06-23 21:31:06.756476
# Unit test for method root of class Path
def test_Path_root():
    # Local instance of Path
    path = Path()
    # Test an object type
    assert type(path.root()) is str
    assert path.root() == '/'


# Generated at 2022-06-23 21:31:07.692251
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:11.571927
# Unit test for constructor of class Path
def test_Path():
    """Unit test for all methods of Path class"""
    p = Path()
    assert p.root() == '/'
    assert p.home() == '/home'
    assert p.user() == '/home/oretha'
    assert p.users_folder() == '/home/taneka/Pictures'
    assert p.dev_dir() == '/home/sherrell/Development/Python'
    assert p.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:31:14.406734
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    p = Path()
    user = p.user()
    assert user == '/home/oretha'



# Generated at 2022-06-23 21:31:16.321013
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    print(path.root())


# Generated at 2022-06-23 21:31:18.029331
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert 'home' in path.home()


# Generated at 2022-06-23 21:31:26.281175
# Unit test for method home of class Path
def test_Path_home():
    # Test type return Path.home()
    assert isinstance(Path().home(), str)
    # Test frequent home folder
    d = {'win32': '\\Users', 'win64': '\\Users', 'linux': '\\home',
         'darwin': '\\Users'}
    assert d[sys.platform] in Path().home()
    # Test with param platform linux
    d = {'win32': '\\Users', 'win64': '\\Users', 'linux': '\\home',
         'darwin': '\\Users'}
    assert d['linux'] in Path(platform='linux').home()


# Generated at 2022-06-23 21:31:28.966936
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    users_folder = p.users_folder()
    assert users_folder != ''

# Generated at 2022-06-23 21:31:37.861494
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Instantiate Path()
    path = Path()
    for _ in range(10):
        path.users_folder()
        # print(path.users_folder())
    # ['C:\\Users\\taneka\\Pictures', 'C:\\Users\\teressa\\Pictures', 'C:\\Users\\lilly\\Pictures', 'C:\\Users\\lilly\\Pictures', 'C:\\Users\\monique\\Pictures', 'C:\\Users\\isela\\Pictures', 'C:\\Users\\melvin\\Pictures', 'C:\\Users\\lilly\\Pictures', 'C:\\Users\\taneka\\Pictures', 'C:\\Users\\isela\\Pictures']


# Generated at 2022-06-23 21:31:43.350802
# Unit test for method user of class Path
def test_Path_user():
    """Testing Path.user
    
    It should return a path '/home/shera'
    """
    # GIVEN
    p = Path()
    # WHEN
    actual = p.user()
    # THEN
    assert actual[:7] == '/home/'
    assert len(actual) > 7


# Generated at 2022-06-23 21:31:46.085363
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()
    # Expected result: /home/bethel/Development/Js
    # Actual result: /home/bethel/Development/Java

# Generated at 2022-06-23 21:31:47.622051
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert len(path.project_dir()) > 0

# Generated at 2022-06-23 21:31:51.391737
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    platform = sys.platform
    path = Path(platform)
    project_dir = path.project_dir()
    assert project_dir != None
    assert isinstance(project_dir,str)
    assert len(project_dir) > 0


# Generated at 2022-06-23 21:31:53.353653
# Unit test for method root of class Path
def test_Path_root():
    i = Path()
    root = i.root()
    assert isinstance(root, str) == True
    assert type(root) == str
    assert root == '/'


# Generated at 2022-06-23 21:31:54.495371
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:31:59.163698
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/britta/Development/Django/cliquish' or Path().project_dir() == '/home/janeen/Development/PHP/noteable'

# Generated at 2022-06-23 21:32:01.527315
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.enums import OperatingSystems
    from mimesis.providers.path import Path

    data = Path.project_dir
    assert data(os = OperatingSystems.WINDOWS) == Path.project_dir()


# Generated at 2022-06-23 21:32:03.223998
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert 'taneka' in path.users_folder()


# Generated at 2022-06-23 21:32:04.458867
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())

# Generated at 2022-06-23 21:32:06.178131
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('linux')
    for i in range(10):
        print(p.project_dir())

# Generated at 2022-06-23 21:32:09.049066
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert type(path.root()) == str
    assert path.root()[:1] == '/'
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:11.412089
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print("Path to dir: ", path.project_dir())


# Generated at 2022-06-23 21:32:19.949468
# Unit test for constructor of class Path
def test_Path():
    print()
    print("Testing constructor of class Path...")
    print()
    path = Path()
    print("path = Path()")
    print("print(path)")
    print()
    print(path)
    print()
    print("path.root()")
    print(path.root())
    print()
    print("path.home()")
    print(path.home())
    print()
    print("path.user()")
    print(path.user())
    print()
    print("path.users_folder()")
    print(path.users_folder())
    print()
    print("path.dev_dir()")
    print(path.dev_dir())
    print()
    print("path.project_dir()")
    print(path.project_dir())
    print()

# Generated at 2022-06-23 21:32:22.183031
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path,Path)
    assert path.__class__.__name__ == 'Path'


# Generated at 2022-06-23 21:32:23.493271
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:32:24.781010
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:32:26.075893
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform


# Generated at 2022-06-23 21:32:27.825779
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # test Path.project_dir()
    assert Path().project_dir() == "/home/taneka/Development/C#/tangy"

# Generated at 2022-06-23 21:32:29.920793
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:32:32.597893
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:33.932596
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()


# Generated at 2022-06-23 21:32:39.262179
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    project_dir = Path(sys.platform).project_dir()

    result = "C:\\Users\\mjs\\Development\\Ruby\\mimesis"
    if sys.platform.startswith('win'):
        assert result == project_dir
    else:
        assert "/home/mjs/Development/Ruby/mimesis" == project_dir

# Generated at 2022-06-23 21:32:40.524473
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform

# Generated at 2022-06-23 21:32:42.293966
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()
    assert path.users_folder() == '/home/brittany/Documents'

# Generated at 2022-06-23 21:32:44.289521
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(10):
        print('Path.project_dir(): ', Path().project_dir())

# Generated at 2022-06-23 21:32:45.521543
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:32:46.763788
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    f = Path()
    assert(f.project_dir())

# Generated at 2022-06-23 21:32:48.289448
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:50.183434
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path()
    # assert assert_equal(obj.dev_dir(), '/home/lanette/Development/Swift')

# Generated at 2022-06-23 21:32:51.555129
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'

# Generated at 2022-06-23 21:32:53.850393
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir() is not None
    assert p.dev_dir() is not ''
    assert p.dev_dir() is not []



# Generated at 2022-06-23 21:32:55.659992
# Unit test for constructor of class Path
def test_Path():
    """
    Test constructor of class Path
    :return:
    """
    path = Path()
    str(path)

# Generated at 2022-06-23 21:32:57.018867
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    a = Path()
    a.dev_dir()


# Generated at 2022-06-23 21:32:58.904184
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    assert home is not None


# Generated at 2022-06-23 21:33:01.304419
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    test_Path_dev_dir.result = Path().dev_dir()
    return test_Path_dev_dir.result



# Generated at 2022-06-23 21:33:03.378846
# Unit test for constructor of class Path
def test_Path():
    """Test for Path class."""
    paths = Path()
    assert paths is not None
    assert paths.platform is not None

# Generated at 2022-06-23 21:33:05.044106
# Unit test for method home of class Path
def test_Path_home():
    platform = sys.platform
    path = Path(platform)
    assert path.home() == '/home'

# Generated at 2022-06-23 21:33:11.544532
# Unit test for method home of class Path
def test_Path_home():
    platform = sys.platform
    # Assert that home is equal to "/"
    assert Path(platform).home() == "/home"
    # Assert that home is equal to "/Users"
    assert Path("darwin").home() == "/Users"
    # Assert that home is equal to "C:\Users"
    assert Path("win32").home() == "C:\\Users"

# Generated at 2022-06-23 21:33:13.108095
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.__doc__)

# Generated at 2022-06-23 21:33:15.568164
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    # TODO: Add test for PosixPath and WindowsPath.

# Generated at 2022-06-23 21:33:17.447220
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:33:20.339536
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    t = Path()
    p = t.user()
    assert "home" in p


# Generated at 2022-06-23 21:33:21.247996
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:33:22.538363
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:33:23.869796
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == 'C:\\Users\\Tester'

# Generated at 2022-06-23 21:33:36.207183
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    x = Path()
    y = x.project_dir()

# Generated at 2022-06-23 21:33:38.111967
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:33:39.097975
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    assert isinstance(home, str)


# Generated at 2022-06-23 21:33:41.738941
# Unit test for method user of class Path
def test_Path_user():
    p1 = Path()
    p2 = Path('win32')
    print(p1.user())
    print(p2.user())


# Generated at 2022-06-23 21:33:43.023845
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print (path.dev_dir())


# Generated at 2022-06-23 21:33:45.931215
# Unit test for method home of class Path
def test_Path_home():
    a = Path(platform="darwin")
    b = a.home()
    assert b == "/Users"
    assert isinstance(b, str)

# Generated at 2022-06-23 21:33:52.654270
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(100):
        path = Path()
        project_dir = path.project_dir()
        if not path.platform == 'win32':
            assert project_dir.startswith('/home/')
        else:
            assert project_dir.startswith('C:\\Users\\')
        assert project_dir.endswith('/' + path.random.choice(PROJECT_NAMES))
        assert (path.random.choice(PROGRAMMING_LANGS)
                in project_dir.split('/'))
        assert (path.random.choice(['Development', 'Dev'])
                in project_dir.split('/'))
test_Path_project_dir()

# Generated at 2022-06-23 21:33:54.533286
# Unit test for method root of class Path
def test_Path_root():
    path_provider = Path()
    assert path_provider.root() == '/'


# Generated at 2022-06-23 21:33:59.082534
# Unit test for constructor of class Path
def test_Path():
    provider = Path('win32')
    print(provider.platform)
    print(provider.root())
    print(provider.home())
    print(provider.user())
    print(provider.user())
    print(provider.users_folder())
    print(provider.users_folder())
    print(provider.dev_dir())
    print(provider.dev_dir())
    print(provider.project_dir())
    print(provider.project_dir())

# Generated at 2022-06-23 21:34:01.228273
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p_dir = p.project_dir()
    assert '/home/' in p_dir
    assert '/Development/' in p_dir
    assert 'Python' in p_dir
    assert '/' in p_dir


# Generated at 2022-06-23 21:34:05.141597
# Unit test for constructor of class Path
def test_Path():
    path_1 = Path()
    assert isinstance(path_1, Path)

    path_2 = Path('linux')
    assert isinstance(path_2, Path)
    assert path_2.platform == 'linux'


# Generated at 2022-06-23 21:34:06.542101
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())
    

# Generated at 2022-06-23 21:34:14.071693
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from mimesis.enums import Gender
    from mimesis.data import PLATFORMS
    p = Path(platform='win32', seed=42)
    p.random.choices = lambda x, y: x
    x = p.users_folder()
    assert x == 'C:\\Users\\Ryan\\Videos'
    p = Path(platform='linux', seed=42)
    p.random.choices = lambda x, y: x
    x = p.users_folder()
    assert x == '/home/monique/Desktop'


# Generated at 2022-06-23 21:34:16.159638
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path"""
    assert Path().root() == '/'


# Generated at 2022-06-23 21:34:19.007860
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(1)
    res = path.user()
    exp = '/home/josh'
    assert res == exp

# Generated at 2022-06-23 21:34:20.087606
# Unit test for constructor of class Path
def test_Path():
    for platform in PLATFORMS:
        Path(platform)


# Generated at 2022-06-23 21:34:22.005538
# Unit test for method home of class Path
def test_Path_home():
    # Initialize object
    path = Path()

    # Test
    assert path.home() == '/home'


# Generated at 2022-06-23 21:34:23.452314
# Unit test for method home of class Path
def test_Path_home():
    p = Path('linux')
    assert p.home() == '/home'


# Generated at 2022-06-23 21:34:25.348167
# Unit test for constructor of class Path
def test_Path():
  test_platform = sys.platform
  target = Path(test_platform)
  assert len(target.platform) != 0
  assert len(target._pathlib_home) != 0


# Generated at 2022-06-23 21:34:27.057341
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform == sys.platform

# Generated at 2022-06-23 21:34:30.140774
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # create class of Path
    class_path = Path()
    # call method
    method_return = class_path.users_folder()
    # check method_return is str
    return method_return
# >>> /home/taneka/Pictures


# Generated at 2022-06-23 21:34:35.237203
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    control_list = ["/Users/fionnulatheis/Development/Java",
                    "/Users/fionnulatheis/Dev/Java",
                     "/Users/fionnulatheis/Development/JavaScript"]
    for _ in range(100):
        assert Path().dev_dir() in control_list


# Generated at 2022-06-23 21:34:36.694337
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/jina'

# Generated at 2022-06-23 21:34:42.325568
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    users_folder = p.users_folder()
    first = users_folder.split("/")[-2]
    second = users_folder.split("/")[-1]
    assert (first in USERNAMES) and (second in FOLDERS)


# Generated at 2022-06-23 21:34:44.257927
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    print(result)


# Generated at 2022-06-23 21:34:46.432423
# Unit test for method root of class Path
def test_Path_root():
    root_path = Path()
    # root_path.seed(12345)
    assert root_path.root() == "/"


# Generated at 2022-06-23 21:34:49.356075
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path(platform='linux')
    #print(path.users_folder())
    #output: /home/gracie/Downloads
    pass


# Generated at 2022-06-23 21:34:51.591281
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None


# Generated at 2022-06-23 21:34:53.865169
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.Meta.name == 'path'
    assert path.platform == sys.platform

# Generated at 2022-06-23 21:34:58.556321
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.dev_dir() is not None
    assert p.project_dir() is not None
    assert p.users_folder() is not None
    assert p.user() is not None
    assert p.home() is not None
    assert p.root() is not None
    assert p.Meta.name == 'path'

# Generated at 2022-06-23 21:35:00.651927
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    print(root)


# Generated at 2022-06-23 21:35:01.953478
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:35:04.617624
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_path = path.project_dir()
    assert type(project_path) == str, "type(project_path) != str"

# Generated at 2022-06-23 21:35:06.753786
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    user_list = user.split('/')
    assert len(user_list) == 3

# Generated at 2022-06-23 21:35:11.987721
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """
    Test for method users_folder of class Path
    """
    path = Path()
    folders = []
    for i in range(0, 10):
        folders.append(path.users_folder())
    assert len(folders) == 10
    assert isinstance(folders[0], str)

# Generated at 2022-06-23 21:35:13.839197
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())

# Generated at 2022-06-23 21:35:16.559026
# Unit test for method root of class Path
def test_Path_root():
    print("Testing Path class method 'root': ")
    p = Path()
    print("Path: ", p.root())
    print("Testing complete\n")


# Generated at 2022-06-23 21:35:23.501215
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    assert Path().root() == '/'
    assert Path(platform='darwin').root() == '/'
    assert Path(platform='linux').root() == '/'
    assert Path(platform='win32').root() == 'C:/'
    assert Path(platform='win64').root() == 'C:/'


# Generated at 2022-06-23 21:35:25.007237
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert (Path('linux').dev_dir().startswith('/home') == True)

# Generated at 2022-06-23 21:35:26.387222
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'

# Generated at 2022-06-23 21:35:27.151456
# Unit test for method home of class Path
def test_Path_home():
    print(Path().home())


# Generated at 2022-06-23 21:35:30.094575
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    project_dir = p.project_dir()
    print(project_dir)
    assert project_dir is not None
    assert len(project_dir) > 0

# Generated at 2022-06-23 21:35:32.066097
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'
    assert path.home() != '/roooot'


# Generated at 2022-06-23 21:35:35.752458
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    try:
        for _ in range(1000):
            path.dev_dir()
    except Exception as e:
        assert False, "{}".format(e)


# Generated at 2022-06-23 21:35:39.646471
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    Path_obj = Path(platform="linux2")
    assert Path_obj.users_folder() in ['/home/kari/Music',
                                       '/home/kamilah/Music',
                                       '/home/michale/Music',
                                       '/home/leota/Music',
                                       '/home/david/Music',
                                       '/home/nolan/Music']



# Generated at 2022-06-23 21:35:50.137915
# Unit test for method user of class Path
def test_Path_user():
    """."""
    #Get list of all expected values
    expectedValues = ['\\home\\aaron', '\\home\\aba', '\\home\\abbey', '\\home\\abbie', '\\home\\abbi', '\\home\\abdul', '\\home\\aubrey', '\\home\\audra', '\\home\\audrey', '\\home\\augusta']
    #Get list of all actual values
    actualValues = []
    for i in range(0,10):
        user = Path().user()
        actualValues.append(user)
        print(actualValues)
    for i in range(0,10):
        if expectedValues[i] == actualValues[i]:
            print("Passed")
        else:
            print("Failed")


# Generated at 2022-06-23 21:35:52.751452
# Unit test for method user of class Path
def test_Path_user():
    tmp = Path('linux')
    assert tmp.user() == '/home/viva'

# Generated at 2022-06-23 21:35:54.842905
# Unit test for method home of class Path
def test_Path_home():
    # Test
    path = Path()
    # Check
    assert isinstance(path, Path)
    assert isinstance(path.home(), str)


# Generated at 2022-06-23 21:35:57.371044
# Unit test for method user of class Path
def test_Path_user():
    gen = Path()

    # Minimal verification that function is working correctly
    assert gen.user().startswith('/')



# Generated at 2022-06-23 21:35:59.065619
# Unit test for method root of class Path
def test_Path_root():
    path = Path(platform = sys.platform)
    assert path.root() == '/'



# Generated at 2022-06-23 21:36:08.029660
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import Platform
    from mimesis.path import Path
    p = Path("linux")
    print("This is p's dev path:", p.dev_dir())
    print("This is p's project path:", p.project_dir())
    print("This is p's root path:", p.root())
# output:
# This is p's dev path: /home/sherika/Development/Python
# This is p's project path: /home/sherika/Development/Falcon/mercenary
# This is p's root path: /

# Generated at 2022-06-23 21:36:09.764995
# Unit test for method home of class Path
def test_Path_home():
    x = Path()
    output = x.home()
    assert output == str(PureWindowsPath('/c/Users'))


# Generated at 2022-06-23 21:36:16.477847
# Unit test for method root of class Path
def test_Path_root():
    p = Path('linux')
    assert p.root() == '/'
    p = Path('linux2')
    assert p.root() == '/'
    p = Path('darwin')
    assert p.root() == '/'
    p = Path('win32')
    assert p.root() == 'C:\\'
    p = Path('win64')
    assert p.root() == 'C:\\'
    # Work on other platform
    p = Path('linux3')
    assert p.root() == '/'



# Generated at 2022-06-23 21:36:18.922655
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root()."""
    path = Path()
    assert str in [type(path.root()) for _ in range(100)]
    assert path.root.__doc__ is not None


# Generated at 2022-06-23 21:36:22.617300
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.home()
    path.root()
    path.user()
    path.users_folder()
    path.dev_dir()
    path.project_dir()

# Generated at 2022-06-23 21:36:24.040898
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:36:26.377388
# Unit test for constructor of class Path
def test_Path():
    """Unit test for method Path."""
    path = Path()
    print(path.home())

# Generated at 2022-06-23 21:36:29.408252
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()
    assert users_folder in ("/home/taneka/Pictures", "/home/sherrell/Pictures", "/home/sherika/Pictures")


# Generated at 2022-06-23 21:36:32.533833
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for dev_dir method of class Path."""
    path_obj = Path()
    path_obj.random.seed(42)
    assert path_obj.dev_dir() == '/home/sherrell/Development/Python'


# Generated at 2022-06-23 21:36:34.441192
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print("Testing method dev_dir of class Path")
    assert Path().dev_dir() != ''
    print("PASSED")


# Generated at 2022-06-23 21:36:38.145552
# Unit test for method home of class Path
def test_Path_home():
    assert Path("linux").home() == '/home'
    assert Path("darwin").home() == '/home'
    assert Path("win32").home() == 'C:\\Users'
    assert Path("win64").home() == 'C:\\Users'


# Generated at 2022-06-23 21:36:40.129920
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:36:42.224315
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder_path = path.users_folder()
    assert users_folder_path not in ["", None]


# Generated at 2022-06-23 21:36:44.869918
# Unit test for method project_dir of class Path
def test_Path_project_dir():
	for i in range(100):
		p = Path()
		print(p.project_dir())


# Generated at 2022-06-23 21:36:48.240392
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    p = Path()
    root = p.root()
    assert root == '/' or root == 'C:\\'


# Generated at 2022-06-23 21:36:53.620496
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from pathlib import PosixPath, WindowsPath
    from pyrant.exceptions import PyrantTypeError
    
    mimesis = Path()
    path = mimesis.dev_dir()
    if sys.platform in ['linux', 'darwin']:
        assert type(path) == PosixPath
    elif sys.platform in ['win32', 'win64']:
        assert type(path) == WindowsPath
    else:
        raise PyrantTypeError(message="Unknown platform")


# Generated at 2022-06-23 21:36:54.754356
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    obj = Path()
    assert obj.users_folder().startswith(obj.home())

# Generated at 2022-06-23 21:37:00.365687
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    for gender in Gender:
        p = Person(gender=gender)
        for platform in PLATFORMS:
            u = Internet(platform, locale=p.locale)
            path = Path(locale=p.locale, platform=platform)
            x = path.user()
            assert u.user_name() in x, (x, u.user_name())
            assert PLATFORMS[platform]['home'] in x, (x, PLATFORMS[platform]['home'])

# Generated at 2022-06-23 21:37:02.330522
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == str(PureWindowsPath().parent)
    

# Generated at 2022-06-23 21:37:06.629927
# Unit test for method user of class Path
def test_Path_user():
    # define the expected result
    expected = '/home/oretha'
    # create an instance of the class Path
    path = Path('linux')
    # get the result of the method user of the class Path
    result = path.user()
    # assert the expected result equals the result
    assert expected == result
    

# Generated at 2022-06-23 21:37:08.521186
# Unit test for method home of class Path
def test_Path_home():
    path_home=Path.home()
    assert isinstance(path_home,str)
    print(path_home)


# Generated at 2022-06-23 21:37:10.604441
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    foo = Path()
    project_dir = foo.project_dir()
    assert isinstance(project_dir, str)
    assert project_dir
    assert len(project_dir) > 0


# Generated at 2022-06-23 21:37:12.721581
# Unit test for method root of class Path
def test_Path_root():
    assert Path.root() != None


# Generated at 2022-06-23 21:37:14.106654
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path"""
    p = Path()
    p.random.seed(0)
    assert p.users_folder() == '/home/loura/Pictures'


# Generated at 2022-06-23 21:37:15.856908
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert isinstance(path.users_folder(), str)

# Generated at 2022-06-23 21:37:20.239918
# Unit test for method user of class Path
def test_Path_user():
    assert Path(platform='linux').user() == '/home/misty'
    assert Path(platform='darwin').user() == '/Users/merlyn'
    assert Path(platform='win32').user() == 'C:/Users/louie'
    assert Path(platform='win64').user() == 'C:/Users/neta'


# Generated at 2022-06-23 21:37:21.342848
# Unit test for constructor of class Path
def test_Path():
    path=Path()


# Generated at 2022-06-23 21:37:23.153940
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert isinstance(path.home(), str)
    

# Generated at 2022-06-23 21:37:28.325848
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    path = Path(platform='linux')
    assert isinstance(path.user(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.dev_dir(), str)
    assert isinstance(path.project_dir(), str)

# Generated at 2022-06-23 21:37:31.761623
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    for i in range (10):
        assert p.user() == str(PureWindowsPath('C:\\Users')/'user' or PurePosixPath('/home')/'user')


# Generated at 2022-06-23 21:37:33.176239
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:37:34.930441
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'



# Generated at 2022-06-23 21:37:38.765242
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Run test and get results
    results = list()
    for i in range(100):
        results.append(Path().dev_dir())
    # Check if results are unique
    assert len(set(results)) == 100, 'Path().dev_dir() does not produce unique results'

# Generated at 2022-06-23 21:37:41.347053
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path."""
    p = Path()
    path = p.user()
    assert isinstance(path, str)


# Generated at 2022-06-23 21:37:44.319159
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path._pathlib_home == PurePosixPath('/home')
    assert isinstance(path.platform, str)


# Generated at 2022-06-23 21:37:52.141360
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for _ in range(0, 100):
        path_to_project = path.project_dir()
        assert isinstance(path_to_project, str)
        if 'win' in path.platform:
            assert '\\' in path_to_project
        else:
            assert '/' in path_to_project
        assert path.randgen.is_valid_path(path_to_project) is True
        path_to_project_tokens = path_to_project.split('/') if path.platform == 'linux' else path_to_project.split('\\')
        assert path_to_project_tokens[0] == path.home()

# Generated at 2022-06-23 21:37:54.015152
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    for i in range(10):
        assert p.home() != ''


# Generated at 2022-06-23 21:37:55.752159
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert type(root) == str


# Generated at 2022-06-23 21:38:00.314651
# Unit test for method users_folder of class Path
def test_Path_users_folder(): 
    """Generate a random path to user's folders.

    :return: Path.

    :Example:
        /home/taneka/Pictures
    """
    assert Path.users_folder() == ""

# Generated at 2022-06-23 21:38:02.396685
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    print('path.root():', result)


# Generated at 2022-06-23 21:38:04.731542
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    for i in range(1000):
        assert("Dev" in p.dev_dir())


# Generated at 2022-06-23 21:38:06.621265
# Unit test for method user of class Path
def test_Path_user():
    p1 = Path('linux')
    assert p1.user() == "/home/marcelino"


# Generated at 2022-06-23 21:38:09.161167
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    testPath = Path()
    for i in range(1, 100):
        assert type(testPath.users_folder()) == str


# Generated at 2022-06-23 21:38:11.549924
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    #user = p.user()
    #assert user == '/home/oretha'
    assert p.root() == '/'

# Generated at 2022-06-23 21:38:13.825865
# Unit test for method root of class Path
def test_Path_root():
    """ Test of method root of class Path"""
    path = Path()
    assert type(path.root()) is str, "Error type"



# Generated at 2022-06-23 21:38:16.773281
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    provider = Path()
    result = provider.project_dir()
    assert isinstance(result, str)
    assert not len(result) == 0


# Generated at 2022-06-23 21:38:18.140542
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    # print(path.user())


# Generated at 2022-06-23 21:38:21.382248
# Unit test for method project_dir of class Path
def test_Path_project_dir():

    for _ in range(10):
        path = Path()
        project_dir = path.project_dir()
        assert isinstance(project_dir, str)
        assert project_dir.startswith(path.dev_dir())



# Generated at 2022-06-23 21:38:23.585319
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path_result = path.project_dir()
    print(path_result)
    print(type(path_result))
    assert(isinstance(path_result, str) == True)
    assert(path_result == "/home/ronny/Development/D/big-top")


# Generated at 2022-06-23 21:38:26.088283
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert 'Pictures' == path.users_folder().split('/')[-1]


# Generated at 2022-06-23 21:38:28.091421
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import re
    p = Path()
    path = p.users_folder()
    print(path)
    assert re.match(r'/home/\w+/\w+', path)

# Generated at 2022-06-23 21:38:28.758753
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path, path.root()

# Generated at 2022-06-23 21:38:30.126468
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test method dev_dir of class Path"""
    p = Path()
    assert(isinstance(p.dev_dir(), str))


# Generated at 2022-06-23 21:38:32.056973
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    p = Path()
    assert isinstance(p.home(), str)

# Generated at 2022-06-23 21:38:39.536265
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_2 = Path('linux')
    path_3 = Path('win32')
    path_4 = Path('win64')
    path_5 = Path('darwin')
    print('path_1.user():', path_1.user())
    print('path_2.user():', path_2.user())
    print('path_3.user():', path_3.user())
    print('path_4.user():', path_4.user())
    print('path_5.user():', path_5.user())


# Generated at 2022-06-23 21:38:40.945363
# Unit test for method home of class Path
def test_Path_home():
    p = Path()

    assert str(p._pathlib_home) == '/home'

# Generated at 2022-06-23 21:38:42.611848
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == '/home/lida/Music'

# Generated at 2022-06-23 21:38:45.549382
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Path.dev_dir()
    assert Path().dev_dir() == '/home/magnolia/Development/Java'

# Generated at 2022-06-23 21:38:48.266072
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for dev_dir method."""
    p = Path()
    assert len(str(p.dev_dir()))



# Generated at 2022-06-23 21:38:49.843397
# Unit test for constructor of class Path
def test_Path():
    Path('linux')


# Generated at 2022-06-23 21:38:54.288985
# Unit test for method home of class Path
def test_Path_home():
    # Initialize class Path
    path1 = Path(platform='darwin')
    # Call function home
    home1 = path1.home()
    # Check that the result equal expected value
    assert home1 == '/Users', "Home directory for darwin platform"

# Generated at 2022-06-23 21:38:59.965072
# Unit test for constructor of class Path
def test_Path():
    from mimesis.builtins import path_module
    p = Path(platform='linux')
    assert p.platform == 'linux'
    assert p._pathlib_home == PurePosixPath('home')

    p = Path(platform='win32')
    assert p.platform == 'win32'
    assert p._pathlib_home == PureWindowsPath('C:\\Users')

    q = path_module.Path(platform='win64')
    assert q.platform == 'win64'

# Generated at 2022-06-23 21:39:02.081320
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir() == str(p._pathlib_home / p.dev_dir() / p.random.choice(PROJECT_NAMES))

# Generated at 2022-06-23 21:39:05.332931
# Unit test for method home of class Path
def test_Path_home():
    p = Path(platform='linux')
    assert p.home() == '/home'


# Generated at 2022-06-23 21:39:06.040051
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()

# Generated at 2022-06-23 21:39:08.368591
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user in ['/home/oretha', 'c:/Users/oretha']

# Generated at 2022-06-23 21:39:11.129701
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p=Path()
    a=p.dev_dir()
    print(a)
if __name__ == '__main__':
    test_Path_dev_dir()

# Generated at 2022-06-23 21:39:14.991628
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """
    Test method users_folder of class Path
    """
    p = Path()
    assert p.users_folder() == 'c:\\Users\luciano\\Documentos'

# Generated at 2022-06-23 21:39:17.065398
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'
    assert path.platform == 'linux'


# Generated at 2022-06-23 21:39:18.728592
# Unit test for method root of class Path
def test_Path_root():
    provider = Path()
    result_1 = provider.root()
    print(result_1)


# Generated at 2022-06-23 21:39:19.922180
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 21:39:21.530040
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:39:24.147944
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert isinstance(path.user(), str)
    assert isinstance(path.home(), str)
    assert isinstance(path.root(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.dev_dir(), str)
    assert isinstance(path.project_dir(), str)

# Generated at 2022-06-23 21:39:27.962998
# Unit test for method root of class Path
def test_Path_root():
    # test for path of Windows
    p = Path('win32')
    assert p.root() == 'C:\\'
    # test for path of Linux
    p = Path('Linux')
    assert p.root() == '/'
    # test for path of MacOS
    p = Path('MacOS')
    assert p.root() == '/'


# Generated at 2022-06-23 21:39:30.280486
# Unit test for method root of class Path
def test_Path_root():
    Path_obj = Path()
    assert type(Path_obj.root()) is str


# Generated at 2022-06-23 21:39:31.974071
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path('linux')
    assert path.dev_dir() == '/home/cristina/Development/VBScript'

# Generated at 2022-06-23 21:39:33.291836
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

# Generated at 2022-06-23 21:39:33.746427
# Unit test for constructor of class Path
def test_Path():
    pass

# Generated at 2022-06-23 21:39:35.383826
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('linux')
    res = path.users_folder()
    print(res)
    res = path.users_folder()
    print(res)


# Generated at 2022-06-23 21:39:40.737657
# Unit test for method home of class Path
def test_Path_home():
    # Test the method home with different languages.
    path = Path(platform='linux')
    assert path.home() == '/home'

    path = Path(platform='darwin')
    assert path.home() == '/Users'
    
    path = Path(platform='win32')
    assert path.home() == 'C:\\Users'

    path = Path(platform='win64')
    assert path.home() == 'C:\\Users'


# Generated at 2022-06-23 21:39:45.247856
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.user() == str(p._pathlib_home / p.random.choice(USERNAMES).lower())
    p = Path('linux', seed=123)
    assert p.home() == str(p._pathlib_home)
    p = Path('linux')
    assert p.home() == str(p._pathlib_home)

# Unit tests for root() method of class Path

# Generated at 2022-06-23 21:39:48.941065
# Unit test for constructor of class Path
def test_Path():
    global Path
    #Path = Path(platform='darwin')
    Path = Path(platform='win32')
    # print(Path.root())
    # print(Path.home())
    # print(Path.user())
    # print(Path.users_folder())
    # print(Path.dev_dir())
    print(Path.project_dir())

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:39:50.103372
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test = Path()
    print(test.project_dir())
# test_Path_project_dir()

# Generated at 2022-06-23 21:39:52.555623
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user()

    from platform import system
    p = Path(system())

# Generated at 2022-06-23 21:39:53.540885
# Unit test for method user of class Path
def test_Path_user():
    assert 3 == 3


# Generated at 2022-06-23 21:39:55.736440
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)



# Generated at 2022-06-23 21:39:57.471406
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path('linux').project_dir() == "/home/jesus/Development/Ruby/crosby"

# Generated at 2022-06-23 21:40:00.007508
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert type(path.project_dir()) == str
    print("\nTest project_dir method of class Path: " + path.project_dir())


# Generated at 2022-06-23 21:40:02.018050
# Unit test for method user of class Path
def test_Path_user():
    import random
    import sys
    random.seed(sys.version_info)
    res = Path().user()
    assert res == '/home/oretha'

# Generated at 2022-06-23 21:40:04.528679
# Unit test for method user of class Path
def test_Path_user():
  instance = Path()
  result = instance.user()
  assert result == '/home/krystin'

# Generated at 2022-06-23 21:40:06.315704
# Unit test for method user of class Path
def test_Path_user():
    """Unit testing for method user of class Path"""
    path = Path()
    path.user()

# Generated at 2022-06-23 21:40:08.279556
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:40:09.403276
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    assert path.root() == '/'



# Generated at 2022-06-23 21:40:12.987038
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())
    print(p.project_dir())
    print(p.project_dir())
    print(p.project_dir())
    print(p.project_dir())

# Generated at 2022-06-23 21:40:16.140668
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path('linux')
    dev_dir = path.dev_dir()
    #print(dev_dir)
    assert 'Development' in dev_dir

if __name__ == '__main__':
    test_Path_dev_dir()

# Generated at 2022-06-23 21:40:16.709459
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    pass