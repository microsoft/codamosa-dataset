

# Generated at 2022-06-23 21:30:15.890821
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:30:21.477988
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    path = Path()
    person = Person()

    user_list = [path.user() for _ in range(10)]
    expected = [person.username(gender=Gender.MALE).lower() for _ in range(10)]

    assert user_list == expected

# Generated at 2022-06-23 21:30:23.745890
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    result = path.dev_dir()
    assert result == "/Users/taneka/Development/Python"


# Generated at 2022-06-23 21:30:26.541978
# Unit test for method root of class Path
def test_Path_root():
    # Initializations for the unit test
    path = Path(platform='linux')

    # Execution of the unit test
    result = path.root()

    # Verification of the unit test result
    assert result == '/'


# Generated at 2022-06-23 21:30:28.146269
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    pack = Path()
    print(pack.dev_dir())

# Generated at 2022-06-23 21:30:29.002078
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:30:31.187256
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:30:34.622733
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert 'home' in path.users_folder()


# Generated at 2022-06-23 21:30:36.893275
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())
    assert path.users_folder() != None


# Generated at 2022-06-23 21:30:38.333521
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/maudie'


# Generated at 2022-06-23 21:30:40.663028
# Unit test for method root of class Path
def test_Path_root():
    print()
    path = Path()
    print(path.root())
# /


# Generated at 2022-06-23 21:30:43.967316
# Unit test for method home of class Path
def test_Path_home():
    p = Path(platform='win32')
    print(p.home())

if __name__ == '__main__':
    test_Path_home()

# Generated at 2022-06-23 21:30:51.641097
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path.platform == sys.platform

    path = Path('darwin')
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path.platform == 'darwin'

    path = Path('win32')
    assert isinstance(path._pathlib_home, PureWindowsPath)
    assert path.platform == 'win32'


# Unit tests for method root

# Generated at 2022-06-23 21:30:54.142226
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    for i in range(1000):
        root = p.root()
        assert len(root) == 1
        assert root[0] == "/"



# Generated at 2022-06-23 21:30:57.239114
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    assert type(result) is str and len(result) > 0


# Generated at 2022-06-23 21:30:58.993112
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.random.choice(FOLDERS) in path.users_folder()

# Generated at 2022-06-23 21:31:00.011888
# Unit test for constructor of class Path
def test_Path():
    Path(platform='linux')

# Generated at 2022-06-23 21:31:02.488925
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert ("/home/sherika/Pictures" == path.users_folder())


# Generated at 2022-06-23 21:31:04.199277
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='linux')
    assert path.user() == '/home/oretha'

# Generated at 2022-06-23 21:31:06.430002
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder().startswith('/home')
    assert Path().users_folder().endswith('Pictures')



# Generated at 2022-06-23 21:31:07.692499
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    a = Path()
    assert len(a.project_dir())!=0

# Generated at 2022-06-23 21:31:08.916638
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for _ in range(10):
        assert isinstance(path.user(), str)


# Generated at 2022-06-23 21:31:12.254383
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path(platform='win32')
    result = path.root()
    assert result != path.home()



# Generated at 2022-06-23 21:31:14.710691
# Unit test for method home of class Path
def test_Path_home():
    """check the result of method home of class Path"""
    path = Path()
    assert path.home() == "/home"


# Generated at 2022-06-23 21:31:15.949248
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    print(p.home())


# Generated at 2022-06-23 21:31:17.645170
# Unit test for method home of class Path
def test_Path_home():
    import platform
    provider = Path(platform='win32')
    result = provider.home()
    assert result == 'C:\\'


# Generated at 2022-06-23 21:31:19.217797
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir() is not None

# Generated at 2022-06-23 21:31:21.430802
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert isinstance(p.root(), str)
    assert p.root() == "/"

# Generated at 2022-06-23 21:31:22.891318
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:31:24.197424
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert len(p.dev_dir()) > 0

# Generated at 2022-06-23 21:31:25.729579
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:31:27.114122
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)



# Generated at 2022-06-23 21:31:28.860585
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:31:33.502363
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage

    path = Path()
    dev_dir = path.dev_dir()
    file_extension = ProgrammingLanguage.get_extension_by_name(path._stack)
    assert dev_dir[-len(file_extension):] == file_extension



# Generated at 2022-06-23 21:31:35.512919
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-23 21:31:37.002050
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)

# Generated at 2022-06-23 21:31:40.373282
# Unit test for constructor of class Path
def test_Path():
    """Test for constructor of class Path."""
    p = Path()
    assert isinstance(p, Path)
    assert p.platform == sys.platform

# Generated at 2022-06-23 21:31:42.313220
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.__dict__)
    assert p


# Generated at 2022-06-23 21:31:45.978326
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert 'Development' in path.dev_dir()
    assert 'Dev' in path.dev_dir()
    assert '/Development/' in path.dev_dir()
    assert '/Dev/' in path.dev_dir()


# Generated at 2022-06-23 21:31:47.522626
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform

# Generated at 2022-06-23 21:31:51.305346
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test project_dir method of class Path."""
    p = Path()
    x = (p._pathlib_home / "Development" / "Python" / "mimesis")
    assert p.project_dir() == str(x)


# Generated at 2022-06-23 21:31:52.703846
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert '/home/' in p.project_dir()

# Generated at 2022-06-23 21:31:55.571526
# Unit test for method home of class Path
def test_Path_home():
    # Initialization of generator
    path = Path(platform='linux')
    # Generation of data
    data = path.home()
    # Verification of type
    assert isinstance(data, str)


# Generated at 2022-06-23 21:31:58.391737
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:31:59.732523
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    _path = Path()
    _path.dev_dir()


# Generated at 2022-06-23 21:32:10.109755
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)
    assert isinstance(path.users_folder(), str)

# Generated at 2022-06-23 21:32:12.038413
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/taneka/Development/JavaScript'


# Generated at 2022-06-23 21:32:16.575212
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root == str(PureWindowsPath().parent if 'win' in sys.platform else PurePosixPath().parent)
    assert type(root) == str


# Generated at 2022-06-23 21:32:18.510446
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    path.seed(0)
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:20.724808
# Unit test for method root of class Path
def test_Path_root():
    """
    :return: Test result
    """
    result = Path().root()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:32:22.812060
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    print(user)
    assert user == '/home/eddie'


# Generated at 2022-06-23 21:32:24.110921
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print(path.root())

# Generated at 2022-06-23 21:32:25.690790
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    for i in range(20):
        print(provider.user())

# Generated at 2022-06-23 21:32:27.424062
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root == '/'


# Generated at 2022-06-23 21:32:31.197770
# Unit test for constructor of class Path
def test_Path():
    a = Path()
    assert isinstance(a, Path)
    common_path = a.user() + '/' + a.random.choice(FOLDERS)
    assert a.users_folder() == common_path

# Generated at 2022-06-23 21:32:37.634049
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert 'Development' in Path().dev_dir()
    assert 'Dev' in Path().dev_dir()
    assert '/home' in Path().dev_dir()
    assert '/home' in Path().dev_dir()
    assert 'Python' in Path().dev_dir()
    assert 'JavaScript' in Path().dev_dir()
    assert 'Java' in Path().dev_dir()
    assert 'PHP' in Path().dev_dir()
    assert 'Ruby' in Path().dev_dir()


# Generated at 2022-06-23 21:32:39.435523
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    a = Path()
    dev_dir = a.dev_dir()
    print(dev_dir)


# Generated at 2022-06-23 21:32:41.012660
# Unit test for method home of class Path
def test_Path_home():
    x = Path()
    x.home()
    print("x.home()")

# Generated at 2022-06-23 21:32:42.445315
# Unit test for constructor of class Path
def test_Path():
    from mimesis import path
    assert(isinstance(path, Path))


# Generated at 2022-06-23 21:32:43.567593
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert isinstance(p.user(), str)


# Generated at 2022-06-23 21:32:44.673993
# Unit test for method home of class Path
def test_Path_home():
    assert(Path().home() == '/home')


# Generated at 2022-06-23 21:32:48.022238
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path."""
    provider = Path()
    assert provider.users_folder() in [
        '/home/aurelia/Pictures',
        '/home/aurelia/Desktop',
        '/home/aurelia/Documents',
        '/home/aurelia/Music',
        '/home/aurelia/Videos'
    ]

# Generated at 2022-06-23 21:32:49.428853
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:32:53.870321
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path"""
    from pathlib import Path # python 3 library
    PATH = Path(Path(__file__).parent, 'data/platforms.json')
    p = Path(platform='linux',data_dir=str(PATH.parent))
    user_folder = p.users_folder()
    assert user_folder == "/home/dana/Videos" or user_folder == "/home/dana/Music" or user_folder == "/home/dana/Pictures"


# Generated at 2022-06-23 21:32:56.806702
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test method Path.users_folder."""
    p = Path()
    val1 = p.users_folder()
    val2 = p.users_folder()
    assert val1 != val2

# Generated at 2022-06-23 21:33:00.856797
# Unit test for constructor of class Path
def test_Path():
    """Test for constructor of class Path"""
    assert Path() is not None
    assert Path(platform='linux') is not None
    assert Path(platform='darwin') is not None
    assert Path(platform='win32') is not None
    assert Path(platform='win64') is not None

# Generated at 2022-06-23 21:33:05.889595
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path"""
    path = Path()
    assert 'home' in path.dev_dir()
    assert 'Development' in path.dev_dir()
    assert len(path.dev_dir()) <= path.random.randint(1, 25) # noqa: S001
    assert isinstance(path.dev_dir(), str)


# Generated at 2022-06-23 21:33:08.691757
# Unit test for method root of class Path
def test_Path_root():
    p = Path(platform = 'linux')
    print(p.root())
    assert p.root() == '/'


# Generated at 2022-06-23 21:33:13.259619
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test method project_dir of class Path"""
    path = Path()
    assert path.project_dir()
    assert path.project_dir()
    assert path.project_dir()
    assert path.project_dir()
    assert path.project_dir()


# Generated at 2022-06-23 21:33:15.724333
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    p.home()
    assert p.home() in ['/home', 'C:\\Users']


# Generated at 2022-06-23 21:33:18.002801
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    print(root)


# Generated at 2022-06-23 21:33:20.423912
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    # users_folder method
    result = path.users_folder()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:33:25.927993
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print("Testing method project_dir of class Path")
    print("Test 1: Path.project_dir() should return a string.")
    assert isinstance(p.project_dir(), str), f"{p.project_dir()} is not a string"
    print("Test 2: Path.project_dir() should not return a string of length 0.")
    assert len(p.project_dir()) > 0, "Method Path.project_dir() returned a string of length 0."
    print("Test 3: Path.project_dir() should return a string of length > 0.")
    assert len(p.project_dir()) > 0, "Method Path.project_dir() returned a string of length 0."
    print("Test 4: Path.project_dir() should return a string starting with /.")

# Generated at 2022-06-23 21:33:30.044927
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert len(path.users_folder()) != 0
    assert len(path.users_folder().split('/')) == 4


# Generated at 2022-06-23 21:33:31.209776
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:33:31.855399
# Unit test for method user of class Path
def test_Path_user():
    assert 1 >= 1

# Generated at 2022-06-23 21:33:34.458204
# Unit test for method root of class Path
def test_Path_root():
    result = Path().root()
    assert isinstance(result, str) and len(result) > 0
    #assert result in ['C:/Users', '/home']



# Generated at 2022-06-23 21:33:35.525186
# Unit test for method root of class Path
def test_Path_root():
    t = Path()
    assert t.root() != ''

# Generated at 2022-06-23 21:33:40.191043
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('linux')
    for i in range(20):
        print("i=%d, path=%s" % (i, path.users_folder()))

if __name__ == '__main__':
    test_Path_users_folder()

# Generated at 2022-06-23 21:33:42.378180
# Unit test for constructor of class Path
def test_Path():
    path_provider = Path()
    # Test for os.name
    assert path_provider.platform == sys.platform


# Generated at 2022-06-23 21:33:43.948787
# Unit test for method home of class Path
def test_Path_home():
    a = Path()
    f = '/Users/yiwang' 
    assert(a.home() == f)

# Generated at 2022-06-23 21:33:45.687753
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:33:49.948935
# Unit test for method user of class Path
def test_Path_user():
    """Test for method user of class Path"""
    path = Path()
    assert path.user() in [
        '/home/kamilah',
        '/home/lane',
        '/home/noelia',
        '/home/candida',
    ]
    

# Generated at 2022-06-23 21:33:51.047039
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:33:52.936510
# Unit test for constructor of class Path
def test_Path():
    assert eval('Path().__class__.__name__') ==  'Path'
    assert eval('Path().__class__.__bases__[0].__name__') == 'BaseProvider'


# Generated at 2022-06-23 21:33:54.388095
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == "/"


# Generated at 2022-06-23 21:33:56.218327
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('linux')
    assert type(p.project_dir()) == str
    assert p.project_dir() == '/home/adella/Development/Dart/ignition'

# Generated at 2022-06-23 21:33:57.834404
# Unit test for constructor of class Path
def test_Path():
    test_platform = 'win32'
    test_path = Path(platform=test_platform)
    assert test_path.platform == test_platform


# Generated at 2022-06-23 21:34:00.550656
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert path.users_folder() == "/home/randi/Pictures"
    assert path.users_folder() == "/home/krystin/Pictures"


# Generated at 2022-06-23 21:34:01.350036
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    o = Path()
    r = o.project_dir()
    assert r is not None

# Generated at 2022-06-23 21:34:04.461448
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    class Meta:
        name = 'path'
    PP = Path(platform=sys.platform, seed=0)
    # output : /home/ned


# Generated at 2022-06-23 21:34:05.912310
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert isinstance(p.root(), str)


# Generated at 2022-06-23 21:34:06.927952
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())


# Generated at 2022-06-23 21:34:10.317256
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    dev_dir = Path().dev_dir()
    print("dev_dir: {}".format(dev_dir))

if __name__ == "__main__":
    test_Path_dev_dir()

# Generated at 2022-06-23 21:34:11.695936
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)

# Generated at 2022-06-23 21:34:13.384340
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    return root == '/'


# Generated at 2022-06-23 21:34:16.251944
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    lst = [p.user() for i in range(0,10)]
    print(lst)


# Generated at 2022-06-23 21:34:17.612774
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()


# Generated at 2022-06-23 21:34:20.355761
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    test = Path()
    result = test.users_folder()
    assert isinstance(result, str)
    assert len(result) >= 4


# Generated at 2022-06-23 21:34:22.551496
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    path = Path()
    assert isinstance(path, Path)

# Unit tests for methods of class Path

# Generated at 2022-06-23 21:34:23.676109
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:34:24.492173
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:34:36.279472
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import Platform
    path_win = Path(Platform.WINDOWS)
    root = path_win.home()
    assert root == path_win._pathlib_home
    path_linux = Path(Platform.LINUX)
    root = path_linux.home()
    assert root == path_linux._pathlib_home
    path_mac = Path(Platform.DARWIN)
    root = path_mac.home()
    assert root == path_mac._pathlib_home
    path_64 = Path(Platform.WINDOWS_64)
    root = path_64.home()
    assert root == path_64._pathlib_home
    path_32 = Path(Platform.WINDOWS_32)
    root = path_32.home()
    assert root == path_32._pathlib_home

# Generated at 2022-06-23 21:34:44.368458
# Unit test for constructor of class Path
def test_Path():
    p1 = Path()
    p2 = Path('linux')
    p3 = Path('win32')
    p4 = Path('darwin')
    assert p1.Meta.name == 'path'
    assert p2.Meta.name == 'path'
    assert p3.Meta.name == 'path'
    assert p4.Meta.name == 'path'
    assert p1.platform == sys.platform
    assert p2.platform == 'linux'
    assert p3.platform == 'win32'
    assert p4.platform == 'darwin'
    assert p1._pathlib_home == PLATFORMS[sys.platform]['home']
    assert p2._pathlib_home == PLATFORMS['linux']['home']

# Generated at 2022-06-23 21:34:45.759728
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:34:50.380677
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    user = path.user()
    folder = path.random.choice(['Development', 'Dev'])
    stack = path.random.choice(PROGRAMMING_LANGS)
    route = path._pathlib_home / user / folder / stack
    assert str(route) == path.dev_dir(), 'Incorrect path'

# Generated at 2022-06-23 21:34:52.035678
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:34:54.279465
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path("win32")
    print(p.dev_dir())


# Generated at 2022-06-23 21:34:55.777416
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    t = Path()
    print(t.users_folder())

# Generated at 2022-06-23 21:34:58.407133
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for _ in range(10):
        path = Path.users_folder()
        assert isinstance(path, str)
        assert path.startswith('/home')


# Generated at 2022-06-23 21:34:59.585068
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert (Path().dev_dir() in FOLDERS)

# Generated at 2022-06-23 21:35:02.961434
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert (path.dev_dir() == '/home/marjie/Dev/Go') or \
           (path.dev_dir() == 'C:\\Users\\michaella\\Development\\JavaScript')

# Generated at 2022-06-23 21:35:06.574801
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)
    assert hasattr(p, 'Meta')
    assert isinstance(p.Meta, type)
    assert p.platform == sys.platform
    assert isinstance(p._pathlib_home, PurePosixPath)


# Generated at 2022-06-23 21:35:09.418988
# Unit test for constructor of class Path
def test_Path():
    """Testing constructor for class path"""
    path = Path()
    assert path.platform == sys.platform


# Generated at 2022-06-23 21:35:16.392388
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == str(PureWindowsPath() if 'win' in sys.platform
                           else PurePosixPath() )

    p = Path('win32')
    assert p.root() == str(PureWindowsPath())

    p = Path(['win32'])
    assert p.root() == str(PureWindowsPath())

    p = Path('linux')
    assert p.root() == str(PurePosixPath())


# Generated at 2022-06-23 21:35:17.664716
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.project_dir()

# Generated at 2022-06-23 21:35:21.074774
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    res = path.dev_dir()
    actual = type(res)
    expected = str
    assert actual == expected

# Generated at 2022-06-23 21:35:24.444997
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.random.seed(1)
    r = p.user()
    assert r == '/home/oretha'


# Generated at 2022-06-23 21:35:27.557261
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())


# Generated at 2022-06-23 21:35:32.494041
# Unit test for constructor of class Path
def test_Path():
    """Test constructor of class Path."""
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home.drive == ''
    assert path._pathlib_home.anchor == ''
    assert path._pathlib_home.parents == ('',)
    assert path._pathlib_home.parts == ('', PLATFORMS[sys.platform]['home'])


# Generated at 2022-06-23 21:35:33.689169
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == "/"



# Generated at 2022-06-23 21:35:39.515235
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print("\nThe first value is generated using the method project_dir() of class Path")
    path_provider = Path()
    path = path_provider.project_dir()
    print(path)
    print("The second value is generated using the method project_dir() of class Path")
    path_provider = Path()
    path = path_provider.project_dir()
    print(path)
    print("The third value is generated using the method project_dir() of class Path")
    path_provider = Path()
    path = path_provider.project_dir()
    print(path)


# Generated at 2022-06-23 21:35:40.823248
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert (path.project_dir() in path.PROJECT_NAMES)

# Generated at 2022-06-23 21:35:42.177054
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() is not None


# Generated at 2022-06-23 21:35:44.102275
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:35:46.395166
# Unit test for method root of class Path
def test_Path_root():
    cout = Path()
    a = cout.root()
    print(a)


# Generated at 2022-06-23 21:35:48.299387
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None


# Generated at 2022-06-23 21:35:50.169502
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path(platform='linux')
    directory = path.dev_dir()
    expected_directory = "/home/orlando/Development/Perl"
    assert directory == expected_directory

# Generated at 2022-06-23 21:35:54.562598
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()

    # Check length of home
    assert home.length() == 5

    # Check type of home
    assert type(home) is str


# Generated at 2022-06-23 21:35:57.074301
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path(platform='linux')
    assert 'linux' in path.platform
    assert path.users_folder() is not ''


# Generated at 2022-06-23 21:35:59.670221
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test_path = Path()
    test_path.random.seed(0)
    assert test_path.project_dir() == "/home/domingo/Dev/dotnet/grit"

# Generated at 2022-06-23 21:36:01.579398
# Unit test for method user of class Path
def test_Path_user():
    import mimesis
    p = mimesis.Path()
    sample = p.user()
    print(sample)


# Generated at 2022-06-23 21:36:12.538042
# Unit test for method user of class Path
def test_Path_user():
    from sys import platform
    from pathlib import PureWindowsPath, PurePosixPath
    from mimesis.data import PLATFORMS, USERNAMES
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.path import Path

    class Meta:
        """Class for metadata."""

        name = 'path'

    def random_choice(self, items: list) -> Any:
        """Get a random item from a list.

        :param items: List of items.
        :return: Item.
        """
        return 'oretha'

    # Create object of class BaseProvider
    base_provider = BaseProvider()
    # Create object of class Path
    path = Path(platform='linux')
    # Create attribute choice of object path
    path.choice = random_choice
    # Create attribute _meta

# Generated at 2022-06-23 21:36:14.062984
# Unit test for method root of class Path
def test_Path_root():
    tmp0 = Path().root()
    assert tmp0


# Generated at 2022-06-23 21:36:17.175595
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage
    path = Path()
    project = path.dev_dir()
    assert project.startswith('/home/')
    assert '/Development/' in project


# Generated at 2022-06-23 21:36:25.096558
# Unit test for method user of class Path
def test_Path_user():
    from hypothesis import given
    from hypothesis.strategies import characters, one_of, text
    from re import compile
    from string import ascii_lowercase, digits

    alphabet = one_of(
        characters(min_codepoint=0x41, max_codepoint=0x5A),  # upper
        characters(min_codepoint=0x61, max_codepoint=0x7A),  # lower
    )
    valid_user = compile(r'^/home/[\w][\w-]{0,}$')
    valid_user_win = compile(r'^C:/Users/[\w][\w-]{0,}$')


# Generated at 2022-06-23 21:36:27.453585
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path"""
    path = Path()
    assert isinstance(path.home(), str)

# Generated at 2022-06-23 21:36:29.450488
# Unit test for constructor of class Path
def test_Path():
    """Test for constructor of class Path"""
    path = Path()
    assert path is not None
    assert isinstance(path, Path)

# Generated at 2022-06-23 21:36:31.605681
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    assert path.root() == '/'



# Generated at 2022-06-23 21:36:32.493756
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/Users'

# Generated at 2022-06-23 21:36:34.672474
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    print(dev_dir)


# Generated at 2022-06-23 21:36:36.262348
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    tPath = Path()
    assert len(tPath.dev_dir()) > 0

# Generated at 2022-06-23 21:36:37.183913
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:36:38.454560
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == 'C:\\Users\\oretha\\Development\\Java'

# Generated at 2022-06-23 21:36:41.569402
# Unit test for method home of class Path
def test_Path_home():
    '''
    Test method home of class Path
    '''
    path = Path()
    home = path.home()
    assert type(home) is str
    assert len(home) > 0


# Generated at 2022-06-23 21:36:43.803201
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir().endswith('/Development/Falcon/swift-core')

# Generated at 2022-06-23 21:36:49.416570
# Unit test for method user of class Path
def test_Path_user():
    import os
    p = Path()
    p._seed = '1'
    u = p.user()
    assert u == str(PureWindowsPath(r'C:\Users\Oretha'))
    os.environ['HOME'] = ''
    p = Path()
    assert p._pathlib_home == PurePosixPath('/home')
# test_Path_user()

# Generated at 2022-06-23 21:36:51.240872
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == 'linux'
    assert isinstance(p._pathlib_home, PurePosixPath)


# Generated at 2022-06-23 21:36:52.481794
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert (p.dev_dir().endswith('Python'))

# Generated at 2022-06-23 21:36:54.310560
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.random.seed(5)
    assert path.user() == Path.user(path) == '/home/donald'

# Generated at 2022-06-23 21:36:55.620108
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    a = Path()
    print(a.users_folder())


# Generated at 2022-06-23 21:36:57.814398
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.random.seed(12345678)
    assert path.users_folder() == '/home/dillon/Videos'

# Generated at 2022-06-23 21:36:59.666026
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:37:09.418960
# Unit test for method root of class Path
def test_Path_root():
    root = Path().root()

# Generated at 2022-06-23 21:37:13.946390
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    # print(path._pathlib_home)
    print(path.dev_dir())
    print(path.dev_dir())
    print(path.dev_dir())


# Generated at 2022-06-23 21:37:16.108552
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for i in range(10):
        print(path.project_dir())

# Generated at 2022-06-23 21:37:16.904988
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:37:18.302893
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:37:19.529076
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.user()

# Generated at 2022-06-23 21:37:20.775249
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/oretha'

# Generated at 2022-06-23 21:37:30.885077
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    random_sys_plat = Path()
    random_path = random_sys_plat._pathlib_home
    assert 'linux' in str(random_path) or 'darwin' in str(random_path) or \
           'win' in str(random_path)

    linux_path = Path('linux')
    assert 'linux' in str(linux_path._pathlib_home)

    mac_path = Path('darwin')
    assert 'darwin' in str(mac_path._pathlib_home)

    win_path = Path('win32')
    assert 'win' in str(win_path._pathlib_home)


# Generated at 2022-06-23 21:37:32.206127
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    print( path.root() )


# Generated at 2022-06-23 21:37:33.628918
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    res = path.dev_dir()
    assert 'Python' in res

# Generated at 2022-06-23 21:37:35.281332
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() != None

# Generated at 2022-06-23 21:37:36.245406
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:37:37.567662
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print('p path:', p)

# Generated at 2022-06-23 21:37:46.008972
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """"Test for method users_folder of class Path"""
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.person import Person
    p = Person(locale='ru', gender=Gender.FEMALE)
    p.add_provider(RussiaSpecProvider)
    # Создание класса
    path = Path()
    # Присвоение значения атрибуту провайдера
    path._user = p
    # Присвоение значения атрибуту platform

# Generated at 2022-06-23 21:37:47.796644
# Unit test for method user of class Path
def test_Path_user():
    l = Path(platform='linux')
    assert l.user() == '/home/britney'


# Generated at 2022-06-23 21:37:50.787664
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root
    print('path.root() =', root)


# Generated at 2022-06-23 21:37:52.189443
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    test = Path()
    print(test.users_folder())


# Generated at 2022-06-23 21:37:52.822125
# Unit test for constructor of class Path
def test_Path():
    path = Path()

# Generated at 2022-06-23 21:37:55.007489
# Unit test for method users_folder of class Path
def test_Path_users_folder():
        path = Path('linux')
        assert path.users_folder() == "home/taneka/Pictures"


# Generated at 2022-06-23 21:38:00.897804
# Unit test for method home of class Path
def test_Path_home():
    from mimesis.enums import SpecialFolder
    from mimesis.path import Path
    import os
    path = Path()
    home = os.path.join(os.path.expanduser("~"), SpecialFolder.home.value)
    assert path.home() == home


# Generated at 2022-06-23 21:38:03.038255
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()
    assert(p.platform == platform)

# Generated at 2022-06-23 21:38:03.928644
# Unit test for method home of class Path
def test_Path_home():
    print(Path().home())

# Generated at 2022-06-23 21:38:08.193753
# Unit test for method user of class Path
def test_Path_user():
    import os
    import re
    import getpass
    path = Path()
    example = path.user()
    username = getpass.getuser()
    pattern = re.compile(r"^/home\/{name}".format(name=username))
    print(example)
    if pattern.match(example):
        print(example)
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:38:10.985125
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
	# initialized the class 
	paths = Path()

	#assert that path is a string
	assert isinstance(paths.dev_dir(), str)


# Generated at 2022-06-23 21:38:15.123845
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    print('[unit test] dev_dir: ', dev_dir)

if __name__ == "__main__":
    # unit test for method dev_dir of class Path
    test_Path_dev_dir()

# Generated at 2022-06-23 21:38:18.815143
# Unit test for method home of class Path
def test_Path_home():
    """Method home of class Path"""
    from mimesis.enums import Platform
    from mimesis.builtins import PlatformSpecifier
    platform = Platform.LINUX.value
    path = Path(platform)
    assert path.home() == '/home'



# Generated at 2022-06-23 21:38:20.311508
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    project_dir = p.project_dir()


# Generated at 2022-06-23 21:38:22.228062
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert ('/home/' in p.users_folder())
    assert ('/home/' in p.user())


# Generated at 2022-06-23 21:38:23.732161
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert Path().project_dir() == '/home/dawn/Development/Django/luminary'

# Generated at 2022-06-23 21:38:25.542166
# Unit test for constructor of class Path
def test_Path():
    """Test for Path class"""
    path = Path()
    path.users_folder()

# Generated at 2022-06-23 21:38:27.905895
# Unit test for method user of class Path
def test_Path_user():
    Language = Path()
    path = Language.user()
    assert isinstance(path, str)


if __name__ == '__main__':
    test_Path_user()

# Generated at 2022-06-23 21:38:29.134707
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert isinstance(path.home(), str)

# Generated at 2022-06-23 21:38:31.602288
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.seed(0)
    assert path.project_dir() == '/home/adrian/Dev/CPython/hypersplenia'

# Generated at 2022-06-23 21:38:33.120534
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform

# Unit tests for method root() of class Path

# Generated at 2022-06-23 21:38:34.181972
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.user() != ""

# Generated at 2022-06-23 21:38:37.459796
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    if str(path._pathlib_home) == '/home':
        print('Test case passed!')
    else:
        print('Test case failed!')


# Generated at 2022-06-23 21:38:39.677976
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir() == '/home/napoleon/Development/C#'


# Generated at 2022-06-23 21:38:42.528915
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class path."""
    gen = Path()
    p = gen.dev_dir()
    print(p)
    assert isinstance(p, str)



# Generated at 2022-06-23 21:38:43.381376
# Unit test for constructor of class Path
def test_Path():
    provider = Path()
    assert provider is not None

# Generated at 2022-06-23 21:38:44.911296
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    assert result != ''
    print(result)

# Generated at 2022-06-23 21:38:46.786476
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert(path.home().__class__ == str)

# Generated at 2022-06-23 21:38:48.706038
# Unit test for method home of class Path
def test_Path_home():
    assert type(Path().home()) == str


# Generated at 2022-06-23 21:38:51.220907
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    assert Path(sys.platform).home() == '/home'



# Generated at 2022-06-23 21:38:55.581123
# Unit test for method user of class Path
def test_Path_user():
    path1 = Path()
    path2 = Path()
    path1.seed(0)
    path2.seed(0)
    assert path1.user() == '/home/oretha'
    assert path2.user() == '/home/oretha'

# Generated at 2022-06-23 21:38:58.733217
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path.random is not None
    assert path.datetime is not None
    assert path.secure_token is not None
    assert path._pathlib_home is not None


# Generated at 2022-06-23 21:39:01.300704
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    if not path.project_dir():
        print("Error Path.project_dir")
    print(path.project_dir())

# test_Path_project_dir()

# Generated at 2022-06-23 21:39:08.111066
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    #print(p.user())
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)
    assert (p.user() is not None)

# Generated at 2022-06-23 21:39:09.862611
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test_path = Path()
    test_project_dir = test_path.project_dir()
    assert test_project_dir is not None

# Generated at 2022-06-23 21:39:11.353174
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    assert '/home' in result
    assert 'Development' in result

# Generated at 2022-06-23 21:39:13.859540
# Unit test for method user of class Path
def test_Path_user():
  path = Path()
  user = path.user()
  assert type(user) == str

# Generated at 2022-06-23 21:39:19.063540
# Unit test for method home of class Path
def test_Path_home():
    #
    # Test the function home
    provider = Path()
    output = provider.home()
    assert len(output) > 0
    assert 'home' in output
    #
    # Test the function home after change the argument platform
    provider = Path(platform='win32')
    output = provider.home()
    assert len(output) > 0
    assert 'Users' in output


# Generated at 2022-06-23 21:39:20.948709
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == str(p._pathlib_home / '/Users/SomeUser/Music')


# Generated at 2022-06-23 21:39:29.368254
# Unit test for method root of class Path
def test_Path_root():

    #Вызов метода для массива объектов
    def check(platform):
        path = Path(platform)
        return path.root()

    #Вызов метода для конкретного объекта
    def check_platform(platform):
        path = Path(platform)
        return path.root()

    #Проверка линукс платформы
    assert check_platform('linux') == "/"

    #Проверка дарвин платформ

# Generated at 2022-06-23 21:39:30.691326
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/sherika'

# Generated at 2022-06-23 21:39:31.662656
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    assert len(Path().project_dir()) < 255

# Generated at 2022-06-23 21:39:34.040632
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path"""
    path = Path(platform="win32")
    # print(path.users_folder())


# Generated at 2022-06-23 21:39:35.765229
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import doctest
    doctest.testmod()
    assert True == True


# Generated at 2022-06-23 21:39:38.220164
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    path = Path('linux')
    p = path.project_dir()

    # print(p)

    assert p is not ''

# Generated at 2022-06-23 21:39:40.094564
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    i = 0
    while i < 10:
        path = Path()
        print(path.project_dir())
        i += 1


# Generated at 2022-06-23 21:39:42.560440
# Unit test for constructor of class Path
def test_Path():
    mimesis_path = Path()
    platform = 'linux'
    path = PurePosixPath()
    path /= PLATFORMS[platform]['home']
    assert (mimesis_path._pathlib_home == path)

# Generated at 2022-06-23 21:39:45.098836
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == str(PureWindowsPath() / 'home' if 'win' in path.platform else PurePosixPath() / 'home')

if __name__ == '__main__':
    test_Path_home()

# Generated at 2022-06-23 21:39:48.829814
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    USER_FOLDERS = [
        '/home/cristen/Documents',
        '/home/nettie/Downloads',
        '/home/ronnie/Pictures',
        '/home/hong/Music',
        '/home/trudie/Videos'
    ]
    p = Path()
    for i in range(5):
        assert p.users_folder() in USER_FOLDERS


# Generated at 2022-06-23 21:39:56.255606
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Test for linux platform
    path = Path('linux')
    assert path.users_folder() == "/home/roselyn/Pictures"
    # Test for windows platform
    path = Path('win32')
    assert path.users_folder() == "C:/Users/Roselyn/Videos"
    # Test for mac platform
    path = Path('darwin')
    assert path.users_folder() == "/Users/Roselyn/Downloads"

# Generated at 2022-06-23 21:39:58.849481
# Unit test for method root of class Path
def test_Path_root():
    """Unit tests of method ``root`` of class ``Path``."""
    path = 'c:\\Users'
    assert len(path) == len(Path().root())


# Generated at 2022-06-23 21:40:01.727341
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    users = []
    for i in range(1000):
        user = p.user()
        users.append(user)
        assert "/home" in user
        assert type(user) == str



# Generated at 2022-06-23 21:40:03.084686
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert 'dev_dir' in dir(Path)

# Generated at 2022-06-23 21:40:09.079002
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    pro_dir = '/home/sherika/Development/Falcon/mercenary'
    assert p.project_dir() == pro_dir, "'{}' is not '{}'".format(p.project_dir(), pro_dir)
        
if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:40:11.890322
# Unit test for method home of class Path
def test_Path_home():
    paths = Path(platform='linux')
    generated_home = paths.home()
    assert generated_home in ('/home', '/home/')


# Generated at 2022-06-23 21:40:13.210558
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform


# Generated at 2022-06-23 21:40:14.918417
# Unit test for method root of class Path
def test_Path_root():
    p = Path(sys.platform)
    result = p.root()
    assert result != ''
