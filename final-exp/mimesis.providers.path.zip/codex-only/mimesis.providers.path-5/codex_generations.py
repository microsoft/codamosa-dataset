

# Generated at 2022-06-23 21:30:10.533948
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:30:15.689979
# Unit test for method user of class Path
def test_Path_user():
    """Make sure the function returns a path to the user's folder."""
    from mimesis.enums import Platform
    platform = str(Platform.MAC_OS)
    p = Path(platform)
    user = p.user()
    result = user
    assert result == '/Users/taneka'

# Generated at 2022-06-23 21:30:21.428285
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    user = Path().random.choice(USERNAMES)
    folder = Path().random.choice(FOLDERS)
    user_folder = Path()._pathlib_home / user / folder
    project = Path().random.choice(PROJECT_NAMES)
    assert str(Path().random.choice(PROJECT_NAMES)) == str(user_folder / project)

# Generated at 2022-06-23 21:30:28.461403
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import ProgrammingLanguage
    from mimesis.enums import Platform

    p = Path(platform=Platform.LINUX)
    for i in range(100):
        project_dir = p.dev_dir()
        assert '/home/' in project_dir
        programming_stack = p.random.choice(PROGRAMMING_LANGS)
        if programming_stack == ProgrammingLanguage.PYTHON:
            assert '/home/' in project_dir
        else:
            assert '/home/' not in project_dir


# Generated at 2022-06-23 21:30:30.104977
# Unit test for method user of class Path
def test_Path_user():
    assert Path(platform='linux').user() in '/home/oretha'

# Generated at 2022-06-23 21:30:36.068582
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.enums import Platform
    import os

    PATH = '/home/beata/Dev/C#'
    p = Path()
    p.platform = Platform.LINUX
    assert os.path.isdir(PATH.split('/')[0]) == True
    assert p.dev_dir() == PATH


# Generated at 2022-06-23 21:30:37.878787
# Unit test for method user of class Path
def test_Path_user():
  test_Path_obj = Path()
  print(test_Path_obj.user())


# Generated at 2022-06-23 21:30:42.506490
# Unit test for method home of class Path
def test_Path_home():

    # Obtain an instance of the class Path
    path = Path()

    # Generate a home path
    path_generated = path.home()

    # Check that the generated home is an str and it's not empty
    assert isinstance(path_generated, str) and len(path_generated) > 0

    # Check that the generated home starts with a slash
    assert path_generated.startswith("/")



# Generated at 2022-06-23 21:30:48.302667
# Unit test for constructor of class Path
def test_Path():
    """
    GIVEN a Path class
    WHEN a Path instance is created
    THEN check the pathlib_home, _seed and _random attributes, and platform
    """
    path = Path()
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path.platform == sys.platform

# Unit tests for methods of class Path

# Generated at 2022-06-23 21:30:51.123744
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    seed = 101
    seq_length = 10
    path = Path(seed=seed)
    assert len(set(path.users_folder() for _ in range(seq_length))) == seq_length

# Generated at 2022-06-23 21:30:53.209507
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    n = 5
    [print(path.dev_dir()) for i in range(n)]


# Generated at 2022-06-23 21:30:56.002592
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.random.seed(5) # /home/kaitlin/Development/NodeJS/liquorice
    assert path.project_dir() == '/home/kaitlin/Development/NodeJS/liquorice'

# Generated at 2022-06-23 21:30:59.818626
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    d = p.dev_dir()
    assert isinstance(d, str), f"Returned type is {type(d).__name__}, expected str."
    assert d != "", "Returned an empty string."



# Generated at 2022-06-23 21:31:01.567556
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:31:07.804260
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test method dev_dir of class Path."""
    path = Path(platform='linux')
    assert path.dev_dir() == '/home/maribeth/Development/Ruby'
    assert path.dev_dir() == '/home/alena/Dev/Java'
    assert path.dev_dir() == '/home/dion/Development/Python'
    assert path.dev_dir() == '/home/elenor/Development/JavaScript'
    assert path.dev_dir() == '/home/josef/Dev/PHP'



# Generated at 2022-06-23 21:31:10.996830
# Unit test for constructor of class Path
def test_Path():
    try:
        print(Path("a"))
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:31:12.150010
# Unit test for method user of class Path
def test_Path_user():
    print(Path.user())


# Generated at 2022-06-23 21:31:17.753404
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path0 = Path()
    dev_dir_path = path0.dev_dir()
    project_dir_path = path0.project_dir()
    print('dev_dir_path: ' + dev_dir_path)
    print('project_dir_path: ' + project_dir_path)
    assert dev_dir_path in project_dir_path
    assert 'Development' in project_dir_path
    assert '/home' in project_dir_path


# Generated at 2022-06-23 21:31:19.582549
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(10):
        print(Path().project_dir())


# Generated at 2022-06-23 21:31:22.665252
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path(platform='linux')
    print(p.project_dir())

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:31:25.334729
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == 'darwin'
    path = Path(platform='darwin')
    assert path.platform == 'darwin'


# Generated at 2022-06-23 21:31:26.721971
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert len(path.user()) > 0


# Generated at 2022-06-23 21:31:31.146773
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    output = path.root()
    assert output == '/' or output == 'c:\\'
    assert output != ''
    assert output != '\\'
    assert output != '/home'


# Generated at 2022-06-23 21:31:34.381105
# Unit test for method home of class Path
def test_Path_home():
    random = Path()
    home = random.home()
    assert(home == "/home")
    assert(all(x in home for x in home))


# Generated at 2022-06-23 21:31:40.163392
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == 'linux'
    assert type(p._pathlib_home) == PurePosixPath
    assert str(p._pathlib_home) == '/home'

    p = Path(platform='win32')
    assert p.platform == 'win32'
    assert type(p._pathlib_home) == PureWindowsPath
    assert str(p._pathlib_home) == 'C:\\Users'

    # Test platform error
    try:
        p = Path(platform='asd')
    except KeyError as e:
        assert str(e) == '\'Unknown platform: asd\'.'


# Generated at 2022-06-23 21:31:42.985391
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.seed(0)
    assert path.dev_dir() == "/home/kory/Development/Ruby"

# Generated at 2022-06-23 21:31:45.877439
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Test for class method users_folder."""
    p = Path(platform='linux')
    p.seed(0)
    assert p.users_folder() == '/home/claribel/Pictures'


# Generated at 2022-06-23 21:31:47.823489
# Unit test for method home of class Path
def test_Path_home():
    """Test class Path method home"""
    p = Path()
    p.home()


# Generated at 2022-06-23 21:31:50.307523
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()
# Output:
# /home/sherika/Development/PyPy/peddler

# Generated at 2022-06-23 21:31:53.840259
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)
    assert isinstance(p.random, BaseProvider)
    assert str(type(p.random)) == "<class 'mimesis.providers.base.BaseProvider'>"
    assert type(p.random).__name__ == 'BaseProvider'
    assert str(type(p)) == "<class 'mimesis.providers.path.Path'>"
    assert type(p).__name__ == 'Path'
    assert p.platform == sys.platform
    assert str(p._pathlib_home) == PLATFORMS[sys.platform]['home']


# Generated at 2022-06-23 21:31:56.856121
# Unit test for method root of class Path
def test_Path_root():
    root = Path().root()
    assert True == isinstance(root, str)
    assert True == root.startswith('/')


# Generated at 2022-06-23 21:31:58.926461
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:32:01.456530
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path('linux')
    path = p.dev_dir()
    print(path)
    # Out: /home/anita/Development/Java'


# Generated at 2022-06-23 21:32:03.857474
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path_user = path.user()
    print (path_user) 
    assert isinstance(path_user, str)


# Generated at 2022-06-23 21:32:04.631963
# Unit test for method home of class Path
def test_Path_home():
    print(Path().home())


# Generated at 2022-06-23 21:32:06.401524
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()
    assert path.project_dir() != 'None'

# Generated at 2022-06-23 21:32:08.476892
# Unit test for method root of class Path
def test_Path_root():
    """Test Root."""
    assert Path().root() == Path().root()


# Generated at 2022-06-23 21:32:10.799883
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert str(p._pathlib_home).find('home') != -1

# Generated at 2022-06-23 21:32:12.547272
# Unit test for method root of class Path
def test_Path_root():
    p = Path(platform='linux')
    assert p.root() == '/'

# Generated at 2022-06-23 21:32:20.223848
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p._pathlib_home, (PureWindowsPath, PurePosixPath))
    assert isinstance(p.platform, str)
    assert isinstance(p.root(), str)
    assert isinstance(p.home(), str)
    assert isinstance(p.user(), str)
    assert isinstance(p.users_folder(), str)
    assert isinstance(p.dev_dir(), str)
    assert isinstance(p.project_dir(), str)
    return True

# Generated at 2022-06-23 21:32:22.044025
# Unit test for method user of class Path
def test_Path_user():
    # initialize class
    path = Path()
    # invoke user
    print(path.user())


# Generated at 2022-06-23 21:32:23.710201
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    value = path.home()
    assert value=='/home'


# Generated at 2022-06-23 21:32:25.002368
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform


# Generated at 2022-06-23 21:32:26.522357
# Unit test for method user of class Path
def test_Path_user():
    print("\nMethod user:")
    path = Path()
    result = path.user()
    print(result)



# Generated at 2022-06-23 21:32:28.115824
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert '/home/' in user


# Generated at 2022-06-23 21:32:33.021565
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    # assert type(root) == str
    # assert root in PLATFORMS[path.platform]['root']
    assert root == PLATFORMS[path.platform]['root']


# Generated at 2022-06-23 21:32:35.042006
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    p.seed(0)
    assert p.user() == '/home/taneka'


# Generated at 2022-06-23 21:32:37.747758
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    result = path.project_dir()
    assert isinstance(result, str)
        

# Generated at 2022-06-23 21:32:41.569117
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path, BaseProvider)
    assert hasattr(path, 'Meta')
    for x in ('root', 'home', 'user', 'users_folder', 'dev_dir', 'project_dir'):
        assert hasattr(path, x)

# Generated at 2022-06-23 21:32:47.301093
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    data = ['\\Users\\Samatha','/home/oretha',
            '\\Users\\Miguel','/home/kristan',
            '\\Users\\Merlin','/home/dasia',
            '\\Users\\Zoa','/home/freida',
            '\\Users\\Ignacio','/home/jospeh',
            '\\Users\\Dede','/home/oretha',
            '\\Users\\Marse'
             ]
    for x in range(0,10):
        gen = path.user()
        assert gen in data



# Generated at 2022-06-23 21:32:48.524585
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    p.home() == '/home'


# Generated at 2022-06-23 21:32:50.473140
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(0, 1000):
        path.users_folder()


# Generated at 2022-06-23 21:32:51.830920
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert len(path.users_folder()) > 0

# Generated at 2022-06-23 21:32:53.021173
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    path = p.home()
    assert(path in ['/home', 'C:\\Users'])

# Generated at 2022-06-23 21:32:55.165866
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test that method project_dir of class Path works correctly."""
    path = Path()
    value = path.project_dir()
    assert value is not None

# Generated at 2022-06-23 21:32:56.530775
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir()


# Generated at 2022-06-23 21:32:57.538927
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())

# Generated at 2022-06-23 21:32:58.953384
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:33:00.948814
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert home == '/home'


# Generated at 2022-06-23 21:33:03.071252
# Unit test for method user of class Path
def test_Path_user():
    a = Path(platform='linux')
    assert a.user() == '/home/felice'



# Generated at 2022-06-23 21:33:06.135450
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()
    print("Path.users_folder():", path.users_folder())
    print("Path.users_folder():", path.users_folder())
test_Path_users_folder()


# Generated at 2022-06-23 21:33:07.773944
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert type(p.home()) == str


# Generated at 2022-06-23 21:33:16.359900
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path_obj = Path()
    home_path = path_obj.home()
    user_name = path_obj.random.choice(USERNAMES)
    user_name = user_name.lower()
    print(user_name)
    project_name = path_obj.random.choice(PROJECT_NAMES)
    project_path = home_path + "/" + user_name + "/Development/Python/" + project_name
    print(project_path)
    print(path_obj.project_dir())
    assert path_obj.project_dir() == project_path

# Generated at 2022-06-23 21:33:20.776944
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())


# Generated at 2022-06-23 21:33:26.234006
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Create an instance of class Path
    path = Path()
    # Call method users_folder
    users_folder = path.users_folder();
    # If users_folder is a string, then the first test is passed
    if isinstance(users_folder, str):
        # Print the string of users_folder
        print(users_folder)
    else:# If users_folder is not a string, then the first test is failed
        print("users_folder is not a string")


# Generated at 2022-06-23 21:33:35.937708
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # тестирование конкретного метода - пример
    expected_result = "/home/dana/Pictures"
    # system_platform = 'linux'
    # объект provider
    provider = Path()
    # вызов метода у provider
    actual_result = provider.users_folder()
    # сравнение результата с ожидаемым
    assert actual_result == expected_result

# Generated at 2022-06-23 21:33:37.615545
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:33:41.238862
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    home1 = provider.home()
    home2 = provider.home()
    assert isinstance(home1, str)
    assert isinstance(home2, str)
    assert home1 == home2


# Generated at 2022-06-23 21:33:43.280854
# Unit test for method user of class Path
def test_Path_user():
    from mimesis import Path
    p = Path()
    assert p.user() is not None and p.user() != ''


# Generated at 2022-06-23 21:33:46.887875
# Unit test for method user of class Path
def test_Path_user():
    results = []
    provider = Path('linux')
    for i in range(1, 10):
        results.append(provider.user())
    assert len(set(results)) == 10



# Generated at 2022-06-23 21:33:48.469019
# Unit test for constructor of class Path
def test_Path():
    assert Path().platform == sys.platform
    assert Path().platform != 'win64'


# Generated at 2022-06-23 21:33:57.182656
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir = path.project_dir()
    print("Path: " + project_dir)
    assert project_dir == "/home/Myrtice/Dev/Flask/my_project" or \
        project_dir == "/home/Karie/Dev/Flask/my_project" or \
        project_dir == "/home/Myrtice/Dev/Flask/my_project" or \
        project_dir == "/home/Myrtice/Dev/Flask/my_project"


# Generated at 2022-06-23 21:33:58.671963
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform="linux")
    user = path.user()
    assert user.startswith('/home')


# Generated at 2022-06-23 21:33:59.935409
# Unit test for method user of class Path
def test_Path_user():
    path = Path(platform='win32')
    assert path.user() == 'C:\\Users\\Lennie'

# Generated at 2022-06-23 21:34:00.941312
# Unit test for method root of class Path
def test_Path_root():
    assert Path()

# Generated at 2022-06-23 21:34:04.046130
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.home()
    p.user()
    p.users_folder()
    p.dev_dir()
    p.project_dir()

# Generated at 2022-06-23 21:34:06.672242
# Unit test for constructor of class Path
def test_Path():
	path = Path()
	assert path.platform == sys.platform
	assert path._pathlib_home.name == PLATFORMS[sys.platform]['home']
	

# Generated at 2022-06-23 21:34:10.078348
# Unit test for constructor of class Path
def test_Path():
    print("Start test for Constructor of class Path")
    test_path = Path()
    assert type(test_path) == Path
    print("Done test for Constructor of class Path.")


# Generated at 2022-06-23 21:34:11.001172
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print (p.root())


# Generated at 2022-06-23 21:34:13.068602
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:34:16.568720
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    ret = path.user()
    assert isinstance(ret, str)
    assert ret.startswith('/home/')


# Generated at 2022-06-23 21:34:19.056713
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import mimesis
    path = Path()
    for i in range(1000):
        assert 'Pictures' in path.users_folder()

# Generated at 2022-06-23 21:34:21.129832
# Unit test for method home of class Path
def test_Path_home():
    home = Path().home()
    assert isinstance(home, str)
    assert len(home) > 0


# Generated at 2022-06-23 21:34:22.387826
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    assert result == '/'


# Generated at 2022-06-23 21:34:23.526667
# Unit test for method home of class Path
def test_Path_home():
    home = Path().home()
    assert '/home' in home


# Generated at 2022-06-23 21:34:24.534240
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'



# Generated at 2022-06-23 21:34:27.428254
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(0,5):
        print(path.users_folder())


# Generated at 2022-06-23 21:34:29.123536
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert len(str(path.project_dir())) > 10

# Generated at 2022-06-23 21:34:32.353013
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    # print(path.project_dir())
    # print(path.root())


if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:34:34.693131
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    for i in range(100):
        assert len(p.dev_dir()) > 0


# Generated at 2022-06-23 21:34:38.284635
# Unit test for method users_folder of class Path
def test_Path_users_folder():
  from pprint import pprint
  from itertools import islice
  p = Path()
  # get 5 elements from users_folder of object p
  pprint(list(islice(iter(p.users_folder), 5)))


# Generated at 2022-06-23 21:34:42.187202
# Unit test for method user of class Path
def test_Path_user():
    # Initialize Path class
    path = Path()
    # Call method user
    result = path.user()
    # Check that result is not None
    assert result is not None

# Generated at 2022-06-23 21:34:43.297268
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'

# Generated at 2022-06-23 21:34:45.085397
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    assert path.user() == '/home/samara'


# Generated at 2022-06-23 21:34:48.874513
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Given
    path = Path()
    path.random.seed(0)
    # When
    actual = path.project_dir()
    # Then
    assert actual == '/home/josiah/Dev/Python/mercenary'

# Generated at 2022-06-23 21:34:54.783125
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # GIVEN an instance of class Path
    platform = 'linux'
    seed = 8
    path = Path(platform, seed)

    # WHEN method users_folder is called
    result = path.users_folder()

    # THEN it should return a string with expected value
    assert result == '/home/broderick/Downloads'



# Generated at 2022-06-23 21:34:56.991854
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path=Path()
    a=path.users_folder()
    print(a)

test_Path_users_folder()

# Generated at 2022-06-23 21:34:58.505066
# Unit test for method user of class Path
def test_Path_user():
    assert Path.user() == Path().user()
    

# Generated at 2022-06-23 21:35:02.915605
# Unit test for constructor of class Path
def test_Path():
    p1 = Path()
    p2 = Path(platform='win32')
    print(p1.home())
    print(p2.home())
    assert p1.user() is not None
    assert p2.user() is not None

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:35:04.794234
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    tmp = Path()
    a = tmp.project_dir()
    assert isinstance(a, str)

# Generated at 2022-06-23 21:35:06.262942
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for i in range(100):
        path.project_dir()


# Generated at 2022-06-23 21:35:09.877839
# Unit test for constructor of class Path
def test_Path():
    filepath = "/home/user/Documents/file.txt"
    assert '/home/user' in filepath
    assert 'Documents' in filepath
    assert 'file.txt' in filepath

# Generated at 2022-06-23 21:35:12.547804
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project_dir = path.project_dir()
    assert project_dir is not None
    assert type(project_dir) is str

# Generated at 2022-06-23 21:35:19.943917
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    a = path.users_folder()
    assert path._pathlib_home in a
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()
    assert path._pathlib_home in path.users_folder()

# Generated at 2022-06-23 21:35:22.754474
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == "linux"
    assert p._pathlib_home == PurePosixPath() / "home"


# Generated at 2022-06-23 21:35:24.469877
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print('user:', p.user())


# Generated at 2022-06-23 21:35:25.860190
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    print('home:',p.home())


# Generated at 2022-06-23 21:35:27.671369
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path(platform="win32")
    assert 'C:' in path.dev_dir()


# Generated at 2022-06-23 21:35:30.093569
# Unit test for constructor of class Path
def test_Path():
    path = Path(platform='win32')
    assert path.platform == 'win32'
    assert path._pathlib_home == PureWindowsPath('C:\\Users')

# Generated at 2022-06-23 21:35:30.933670
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    result = path.root()
    assert result == '/'


# Generated at 2022-06-23 21:35:34.502089
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Initialize Path
    pa = Path()
    # Call a function which will be tested
    dev_dir = pa.dev_dir()
    # Check if result is valid
    assert dev_dir.startswith(PLATFORMS['win32']['home'])
    # Call a function which will be tested
    dev_dir = pa.dev_dir()
    # Check if result is valid
    assert dev_dir.startswith(PLATFORMS['darwin']['home'])
    # Call a function which will be tested
    dev_dir = pa.dev_dir()
    # Check if result is valid
    assert dev_dir.startswith(PLATFORMS['linux']['home'])

# Generated at 2022-06-23 21:35:36.566521
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.project_dir())


if __name__ == '__main__':
    test_Path_users_folder()

# Generated at 2022-06-23 21:35:40.114875
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Generate the provider
    provider = Path(platform = 'linux')

    # Check for the result
    if provider.users_folder() == '/home/sherika/Pictures':
        print('Test for method users_folder of class Path is OK')
    else:
        print('Test for method users_folder of class Path is FAILED')


# Generated at 2022-06-23 21:35:41.379684
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/oretha'


# Generated at 2022-06-23 21:35:43.267036
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test Path.dev_dir()."""
    path = Path()
    path.dev_dir()
    print("TestPath.dev_dir() OK")


# Generated at 2022-06-23 21:35:46.499257
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    # print("path.dev_dir()=", path.dev_dir())
    assert True == isinstance(path.dev_dir(), str)

# Generated at 2022-06-23 21:35:48.879526
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    obj = Path()
    assert obj.users_folder() == "C:\\Users\\Public\\Documents"


# Generated at 2022-06-23 21:35:52.672604
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path._seed, int)
    assert isinstance(path._random, random.Random)
    assert isinstance(path.platform, str)
    assert callable(path.root)
    assert callable(path.home)
    assert callable(path.user)
    assert callable(path.users_folder)
    assert callable(path.dev_dir)
    assert callable(path.project_dir)


# Generated at 2022-06-23 21:35:57.420574
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None
    assert 'linux' in path.platform
    assert path.random is not None
    assert isinstance(path, Path)
    assert isinstance(path._pathlib_home, PurePosixPath)

if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:35:58.743048
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/oretha'


# Generated at 2022-06-23 21:35:59.851579
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())

# Generated at 2022-06-23 21:36:02.926804
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    x = path.root()
    assert len(x)>1

## Unit test for method home of class Path

# Generated at 2022-06-23 21:36:13.494893
# Unit test for constructor of class Path
def test_Path():
    assert Path.__init__(Path, platform="linux")
    assert Path.__init__(Path, platform="darwin")
    assert Path.__init__(Path, platform="win32")
    assert Path.__init__(Path, platform="win64")

    assert Path.__init__(Path, platform="linux", seed=0)
    assert Path.__init__(Path, platform="darwin", seed=0)
    assert Path.__init__(Path, platform="win32", seed=0)
    assert Path.__init__(Path, platform="win64", seed=0)

    assert Path.__init__(Path, platform="linux", locale="en-GB")
    assert Path.__init__(Path, platform="darwin", locale="en")

# Generated at 2022-06-23 21:36:14.723376
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())

# Generated at 2022-06-23 21:36:16.475752
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for Path.root"""
    assert Path().root == Path().root()


# Generated at 2022-06-23 21:36:17.487172
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path


# Generated at 2022-06-23 21:36:18.407481
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()

# Generated at 2022-06-23 21:36:21.062219
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Creating the object of class Path
    path = Path()
    user_folder = path.users_folder()
    # Printing the user folder path
    print(user_folder)

test_Path_users_folder()

# Generated at 2022-06-23 21:36:22.564399
# Unit test for method root of class Path
def test_Path_root():
    Provider = Path()
    print(Provider.root())


# Generated at 2022-06-23 21:36:27.407238
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Function to test users_folder method of class Path."""
    path = Path()
    example = path.users_folder()
    assert bool(re.match(r'^(/home/[a-zA-Z]+)/', example)) is True
    print(example)


# Generated at 2022-06-23 21:36:28.706664
# Unit test for method root of class Path
def test_Path_root():
    test = Path()
    assert test.root() == "/"

# Generated at 2022-06-23 21:36:32.798865
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(10):
        user_folder = path.users_folder()
        assert path.home() in user_folder, f"For {user_folder}"
        assert any(
            folder in user_folder for folder in FOLDERS
        ), f"For {user_folder}"


# Generated at 2022-06-23 21:36:41.895316
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    person = Person('en')

    # Case 1:
    # A person has gender = female
    # And platform = 'linux'
    person.gender = Gender.FEMALE
    platform = 'linux'
    path = Path(platform)
    assert path.user() == '/home/' + person.username()

    # Case 2:
    # A person has gender = male
    # And platform = 'win32'
    person.gender = Gender.MALE
    platform = 'win32'
    path = Path(platform)
    assert path.user() == 'C:/Users/' + person.username()


# Generated at 2022-06-23 21:36:43.516509
# Unit test for method root of class Path
def test_Path_root():
    a = Path()
    assert a.root() == '/'

# Generated at 2022-06-23 21:36:47.543909
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    test_cases = ['/home', '/Users', 'C:\\Users', 'C:\\Users\\']
    for test_case in test_cases:
        assert p.home() == test_case


# Generated at 2022-06-23 21:36:49.081435
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    name = Path()
    print(name.project_dir())

# Generated at 2022-06-23 21:36:50.603697
# Unit test for constructor of class Path
def test_Path():
    path_provider = Path()
    user_path = path_provider.user()
    assert user_path

# Generated at 2022-06-23 21:36:53.779202
# Unit test for method root of class Path
def test_Path_root():
    mimesis_path = Path()
    path_1 = str(PureWindowsPath('C:\Windows'))
    path_2 = str(PurePosixPath('/'))
    assert mimesis_path.root() in (path_1, path_2)



# Generated at 2022-06-23 21:36:55.210620
# Unit test for method users_folder of class Path
def test_Path_users_folder(): 
    print(Path().users_folder())
    # --> /home/sherrell/Pictures


# Generated at 2022-06-23 21:36:57.280119
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    f_name = path.user()
    assert len(f_name) >= 1
    print(f_name)


# Generated at 2022-06-23 21:37:00.203390
# Unit test for method user of class Path
def test_Path_user():
    u = Path()
    p = u.user()
    assert p.startswith('/home/') or p.startswith('C:\\Users\\')


# Generated at 2022-06-23 21:37:02.906151
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert root == '/' or root == 'C:\\'


# Generated at 2022-06-23 21:37:05.089085
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    p.random.seed(0)
    assert p.home() == '/home' 


# Generated at 2022-06-23 21:37:06.370356
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:37:13.054894
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()

# Generated at 2022-06-23 21:37:14.147942
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:37:18.302405
# Unit test for method home of class Path
def test_Path_home():
    """
    Tests for method home of class Path
    """
    path = Path()
    if sys.platform == 'win32':
        assert path.home() == 'C:\\Users'
    else:
        assert path.home() == '/home'

# Generated at 2022-06-23 21:37:19.993604
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform='linux')
    assert p.__class__.__name__ == 'Path'


# Generated at 2022-06-23 21:37:21.451916
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:37:26.347658
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    # Initializing all needed objects
    path = Path()
    path._pathlib_home = PurePosixPath('/home')

    # After all actions path.project_dir() must be string
    assert isinstance(path.project_dir(), str)


# Generated at 2022-06-23 21:37:27.620106
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path


# Generated at 2022-06-23 21:37:30.628377
# Unit test for method user of class Path
def test_Path_user():
    # Initialization
    platform = sys.platform
    path = Path(platform)
    # Test
    user = path.user()
    # Assertion
    assert user != ""


# Generated at 2022-06-23 21:37:33.519662
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.platform == sys.platform
    assert path._pathlib_home is not None
    assert path.__init__('win32') is None
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:37:43.117854
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    # output of home() method
    assert path.home() == "/home"
    # output of users_folder() method
    assert path.users_folder() == "/home/diedra/Downloads"
    # output of dev_dir() method
    assert path.dev_dir() == "/home/reta/Dev/Ruby"
    # output of project_dir() method
    assert path.project_dir() == "/home/ramona/Dev/React.js/wolf"
    # output of root() method
    assert path.root() == "/"
    # output of user() method
    assert path.user() == "/home/francesco"
    # output of class Path
    assert str(path) == "<Path>"

# Generated at 2022-06-23 21:37:45.759403
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
	path = Path()
	print(path.dev_dir())


# Generated at 2022-06-23 21:37:47.487364
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert(user == '/home/derek')

# Generated at 2022-06-23 21:37:48.308044
# Unit test for method user of class Path
def test_Path_user():
    print(Path().user())


# Generated at 2022-06-23 21:37:50.605128
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert("/home/oralee" == path.user())

# Generated at 2022-06-23 21:37:52.819043
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path().home() == Path().home()    # make sure the value is constant


# Generated at 2022-06-23 21:37:58.119161
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """ Check that method users_folder return a path like '/home/taneka/Pictures' """
    # Create a Path object
    p = Path()
    # Check that the value returned by method users_folder is a string
    assert isinstance(p.users_folder(), str)
    # Check that the value returned by method users_folder is a path like '/home/taneka/Pictures'
    assert p.users_folder() == '/home/taneka/Pictures'


# Generated at 2022-06-23 21:38:01.850510
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path) and isinstance(p, BaseProvider) == True
    p = Path('linux')
    assert p.platform == 'linux'


# Generated at 2022-06-23 21:38:05.540661
# Unit test for constructor of class Path
def test_Path():
    # pylint: disable=protected-access
    path = Path()
    assert isinstance(path, Path)
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert path._pathlib_home.parts == ('/', 'home', )
    assert path.platform == sys.platform



# Generated at 2022-06-23 21:38:07.530941
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    ret = path.users_folder()
    assert (ret in FOLDERS) is True


# Generated at 2022-06-23 21:38:09.401643
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

test_Path_users_folder()

# Generated at 2022-06-23 21:38:13.418943
# Unit test for method home of class Path
def test_Path_home():
    import pytest
    path = Path()
    home = path.home()
    assert "home" in home
    assert "/home" in home
    home = path.home()
    assert "home" in home
    assert "/home" in home


# Generated at 2022-06-23 21:38:15.123362
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert str(path.home()) == "/home"

# Generated at 2022-06-23 21:38:16.584347
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == Path().home()


# Generated at 2022-06-23 21:38:17.961301
# Unit test for constructor of class Path
def test_Path():
    assert Path('win64') is not None


# Generated at 2022-06-23 21:38:27.575631
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path.
    This function test each possible values of the method users_folder, by checking if it's in the list
    of expected values.
    """
    path = Path()
    values = []
    test_result = True
    for i in range (1,10):
        values.append(path.users_folder())
    for (i, value) in enumerate(values):
        if value not in FOLDERS:
            test_result = False
            print("Error with path.users_folder(). At i = " + str(i))
    if test_result :
        print("All values are in FOLDERS")

# Generated at 2022-06-23 21:38:29.157568
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    assert Path().dev_dir() == '/home/janice/Development/Groovy'

# Generated at 2022-06-23 21:38:29.958303
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:38:31.855060
# Unit test for method home of class Path
def test_Path_home():
    p = Path('linux')
    assert p.home() == '/home' # nosec


# Generated at 2022-06-23 21:38:36.986926
# Unit test for constructor of class Path
def test_Path():
    path = Path('linux')
    # TODO: Uncomment after new version is released
    #assert path.platform == 'linux'
    assert path

if __name__ == "__main__":
    path = Path('linux')
    print(path.home())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())

# Generated at 2022-06-23 21:38:39.916914
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    path_generator = Path()
    print("Project dir is: %s" % path_generator.project_dir())


# Generated at 2022-06-23 21:38:41.689258
# Unit test for method home of class Path
def test_Path_home():
    print(Path().home())

if __name__ == '__main__':
    test_Path_home()

# Generated at 2022-06-23 21:38:44.137127
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    # AssertionError: '/home' != '/'
    print(p.home())
    print(p.root())


# Generated at 2022-06-23 21:38:46.210656
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:38:47.598656
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:38:49.703811
# Unit test for method home of class Path
def test_Path_home():
    """Test for method home of class Path."""
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:38:51.693908
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path(platform='linux')
    print(p.dev_dir())



# Generated at 2022-06-23 21:38:57.840873
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import path_mimesis
    # Set up
    path_mimesis.providers.path.Path.random.seed(1)
    expected = "/Users/mickie78/Music"

    # Exercise
    actual = path_mimesis.providers.path.Path.users_folder(path_mimesis.providers.path.Path)

    # Verify
    assert actual == expected


# Generated at 2022-06-23 21:39:00.136538
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())

# Generated at 2022-06-23 21:39:00.988080
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'



# Generated at 2022-06-23 21:39:02.432716
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

test_Path_project_dir()

# Generated at 2022-06-23 21:39:05.332036
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print("Random users folder: {}".format(p.users_folder()))


# Generated at 2022-06-23 21:39:12.827304
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()

# Generated at 2022-06-23 21:39:15.144633
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() in ["/","C:\\" ]


# Generated at 2022-06-23 21:39:19.351545
# Unit test for method user of class Path
def test_Path_user():
    print ("test_Path_user")
    # Initialize Path object
    p1 = Path()
    # Generate 10 users
    for i in range(10):
        print(p1.user())
    # Generate a user of a platform
    p2 = Path(platform='win32')
    print(p2.user())


# Generated at 2022-06-23 21:39:20.550962
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()


# Generated at 2022-06-23 21:39:23.130001
# Unit test for method home of class Path
def test_Path_home():
    """Test for method home of class Path."""
    instance = Path()
    assert isinstance(instance.home(), str)


# Generated at 2022-06-23 21:39:25.244574
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.seed(4)
    # p.seed_instance()
    # p.seed()
    assert p.root() == '/'



# Generated at 2022-06-23 21:39:26.930369
# Unit test for method home of class Path
def test_Path_home():
    PATH = Path()
    assert PATH.home() == '/home'



# Generated at 2022-06-23 21:39:29.720189
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    result = p.users_folder()
    assert len(result) > 0
    assert FOLDERS in result

# Generated at 2022-06-23 21:39:31.437726
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    project = path.project_dir()
    assert project[:7] == '/home/'

# Generated at 2022-06-23 21:39:32.821987
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert 'Development' in path.dev_dir()


# Generated at 2022-06-23 21:39:35.264982
# Unit test for method root of class Path
def test_Path_root():
    test_path = Path()
    path_root = test_path.root()
    assert isinstance(path_root, str)
    assert path_root == '/'


# Generated at 2022-06-23 21:39:36.584810
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:39:41.182573
# Unit test for method user of class Path
def test_Path_user():
    print()
    a = Path('linux')
    print(a.user())
    print()
    b = Path('win32')
    print(b.user())
    print()
    c = Path('win64')
    print(c.user())
    print()
    d = Path('darwin')
    print(d.user())
    print()

# Generated at 2022-06-23 21:39:44.385603
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())
    # p.random.seed(1)
    # print(p.users_folder())
    # p.random.seed(2)
    # print(p.users_folder())


# Generated at 2022-06-23 21:39:48.419000
# Unit test for constructor of class Path
def test_Path():
    from mimesis.enums import Platform
    assert Path(platform=Platform.DARWIN, seed=123456789)
    assert Path(platform=Platform.LINUX, seed=123456789)
    assert Path(platform=Platform.WINDOWS, seed=123456789)


# Generated at 2022-06-23 21:39:50.453427
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert str(path.home()) == '/home'


# Generated at 2022-06-23 21:40:01.445870
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # pylint: disable=C0103
    from mimesis.enums import Gender

    # The following creates a Path instance with a specified random seed for
    # reproducible results. The seed function of random.seed() expects an
    # integer value, so it is necessary to convert the string 'mimesis'
    # to its integer representation with the ord() function.
    p = Path(random_seed=ord('mimesis'))

    # There are two possible values, so this code should always return the
    # second value (i.e., /home/duane/Images)
    assert p.users_folder() == '/home/duane/Images'

    # After changing the random seed, the following call should return the
    # first possible value.
    p.set_random_seed(ord('mimesis2'))
    assert p

# Generated at 2022-06-23 21:40:05.370539
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Initialization of object
    obj = Path('linux')
    # Testing method
    result = obj.users_folder()
    assert result == '/home/rosana/Pictures'


# Generated at 2022-06-23 21:40:10.545765
# Unit test for method home of class Path
def test_Path_home():
    # Test for Linux
    path = Path('linux')
    assert path.home() == '/home'

    # Test for MacOS
    path = Path('darwin')
    assert path.home() == '/Users'

    # Test for Windows
    path = Path('win32')
    assert path.home() == 'C:/Users'
