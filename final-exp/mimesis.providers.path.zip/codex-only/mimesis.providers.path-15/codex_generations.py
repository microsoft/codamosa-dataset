

# Generated at 2022-06-23 21:30:13.073869
# Unit test for method root of class Path
def test_Path_root():
    instance = Path()
    assert isinstance(instance.root(), str)

# Generated at 2022-06-23 21:30:16.315664
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path."""
    path = Path()
    dev_dir = path.dev_dir()
    assert type(dev_dir) == str


# Generated at 2022-06-23 21:30:21.875458
# Unit test for method root of class Path
def test_Path_root():
    from mimesis.builtins.path import Path
    from mimesis.enums import Platform
    path = Path(platform = Platform.LINUX)
    assert path.root() == '/'
    assert path.root() != ''
    assert path.root() != './'
    assert path.root() != './home'


# Generated at 2022-06-23 21:30:24.602621
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Call method dev_dir
    result = Path('linux').dev_dir()
    assert isinstance(result, str)
    assert result == "/home/sherrell/Development/Python"
    assert result == Path('linux').dev_dir()

# Generated at 2022-06-23 21:30:30.018947
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.root() == '/'
    assert p.home() == '/home'
    assert p.dev_dir() == '/home/sherrell/Development/Python'
    assert p.project_dir() == '/home/sherika/Development/Falcon/mercenary'

# Generated at 2022-06-23 21:30:33.817664
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert re.match(r'^(?i)(/home/)(.*)(/Development/)(.*)(/)(.*)$', path.project_dir())


# Generated at 2022-06-23 21:30:34.962862
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/marin/Dev/Golang'

# Generated at 2022-06-23 21:30:36.155684
# Unit test for method home of class Path
def test_Path_home():
    a = Path(platform='linux')
    assert a.home() == '/home'


# Generated at 2022-06-23 21:30:37.585113
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert isinstance(p,BaseProvider)


# Generated at 2022-06-23 21:30:39.704668
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    res = "C:\\Users\\oretha\\Dev\\go"
    assert p.dev_dir() == res

# Generated at 2022-06-23 21:30:41.773750
# Unit test for method user of class Path
def test_Path_user():
    p = Path('linux')
    for i in range(100):
        res = p.user()
        assert len(res) > 0

# Generated at 2022-06-23 21:30:47.919802
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    _Path = Path(platform='linux')
    for i in range(100):
        res = _Path.users_folder()
        _Path._pathlib_home.parent = PurePosixPath('/')
        _Path._pathlib_home.parts = ('home', )
        assert res == '/home/shakia/Pictures'


# Generated at 2022-06-23 21:30:50.089940
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test method project_dir of class Path"""
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:30:51.726413
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    for i in range(10):
        print(Path().dev_dir())


# Generated at 2022-06-23 21:30:52.767670
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    p.project_dir()

# Generated at 2022-06-23 21:30:54.740619
# Unit test for method user of class Path
def test_Path_user():
    p = Path(*(1,),**{})
    path = p.user()
    assert path.startswith('/home')


# Generated at 2022-06-23 21:31:01.147361
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())
# 'C:\\Users\\user\\Development\\Android'
# '/home/nichelle/Dev/Java'
# '/home/arlean/Development/Python'
# '/home/porsha/Dev/C++'
# '/home/vinnie/Dev/Swift'
# '/home/zaneta/Development/AppleScript'


# Generated at 2022-06-23 21:31:02.489247
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert p.dev_dir()


# Generated at 2022-06-23 21:31:04.898812
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/sherika' or p.user() == 'C:\\Users\\sherika'


# Generated at 2022-06-23 21:31:10.597115
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    from mimesis.enums import Gender
    from mimesis.localization import en

    provider = Path(en, platform='win32')
    user = provider.user()
    assert user
    assert provider._pathlib_home in user
    dev_dir = provider.dev_dir()
    assert dev_dir
    assert provider._pathlib_home in dev_dir
    assert user in dev_dir
    project_dir = provider.project_dir()
    assert project_dir
    assert user in project_dir
    # Case 1: user is man
    assert provi

# Generated at 2022-06-23 21:31:13.296107
# Unit test for method root of class Path
def test_Path_root():
    assert Path(platform = 'win32').root() == Path(platform = 'win64').root() == Path(platform = 'linux').root()

# Generated at 2022-06-23 21:31:15.163369
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert isinstance(root, str)


# Generated at 2022-06-23 21:31:19.736073
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    root = p.root()
    assert str(type(root)) == "<class 'str'>"
    assert len(root) > 1
    assert root == '/'
# End


# Generated at 2022-06-23 21:31:27.802366
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user = p.user()
    assert user in [
        '/home/oretha',
        '/home/oretha/Documents',
        '/home/oretha/Pictures',
        '/home/oretha/Documents/Video',
        '/home/oretha/Documents/Audio',
        '/home/oretha/Documents/Photo',
    ]
    p = Path('win32')
    user = p.user()
    assert user in [
        'C:\\Users\\Lonna',
        'C:\\Users\\Lonna\\Documents',
        'C:\\Users\\Lonna\\Documents\\Video',
        'C:\\Users\\Lonna\\Documents\\Audio',
        'C:\\Users\\Lonna\\Documents\\Photo',
        'C:\\Users\\Lonna\\Pictures',
    ]

#

# Generated at 2022-06-23 21:31:29.635345
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:31:32.967622
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    print('Testing method project_dir of class Path')
    pathProvider = Path()
    for i in range(10):
        print(pathProvider.project_dir());
    print('\n')




# Generated at 2022-06-23 21:31:34.802610
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    assert len(path.project_dir()) > 0

# Generated at 2022-06-23 21:31:38.432108
# Unit test for method user of class Path
def test_Path_user():
    test_path = Path()
    test_user = test_path.user()
    expected_user = '/home/rakisha'
    assert test_user == expected_user


# Generated at 2022-06-23 21:31:41.680324
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user, str)
    assert user.startswith(path.home())


# Generated at 2022-06-23 21:31:43.104952
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert type(path.root()) is str


# Generated at 2022-06-23 21:31:44.816935
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    assert Path.project_dir()

# Generated at 2022-06-23 21:31:47.985594
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert(home in ['C:','C:\\','C:\\Users','Users','Users/','C:/Users','/home'])


# Generated at 2022-06-23 21:31:49.183197
# Unit test for method home of class Path
def test_Path_home():
    """Check Path.home method."""
    path = Path()
    assert path.home() == '/home'



# Generated at 2022-06-23 21:31:54.046465
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    import random
    import warnings
    warnings.simplefilter("ignore")

    # Seed used in random.random()
    random.seed(1)

    print("test_Path_users_folder()")

    obj = Path("win32")

    # Call method
    result = obj.users_folder()

    # Check result
    assert result == "/Users/joni/Desktop", result

# Generated at 2022-06-23 21:31:57.765656
# Unit test for method user of class Path
def test_Path_user():
    provider = Path()
    user = provider.user()
    # print(user)
    assert len(user) > 0


# Generated at 2022-06-23 21:31:59.637770
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    p.home()
# Out : '/home'


# Generated at 2022-06-23 21:32:00.991085
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    pass



# Generated at 2022-06-23 21:32:02.046355
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    path.project_dir()

# Generated at 2022-06-23 21:32:03.556882
# Unit test for method users_folder of class Path
def test_Path_users_folder():

    assert Path().users_folder() == "/home/oretha/Pictures"


# Generated at 2022-06-23 21:32:04.317684
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:32:14.557519
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    import random
    import string
    from mimesis.builtins import FileExtension
    from mimesis.providers.datetime import Datetime

    class Path2(Path):
        def __init__(self, platform, seed = ''):
            self.seed = seed
            self.random = random.Random(seed)
            super().__init__(platform)

        def seed_random(self, seed = ''):
            if seed == '':
                seed =  self.seed
            self.random.seed(seed)

    user_name = 'user'
    # For Codewars platform
    p = Path2('linux', user_name)

    # Print dev_dir
    print(p.dev_dir())
    # Print project_dir
    print(p.project_dir())
    # Print some random file in project_

# Generated at 2022-06-23 21:32:16.835775
# Unit test for method home of class Path
def test_Path_home():
    provider = Path()
    result = provider.home()
    assert isinstance(result, str)
    assert result == '/home'



# Generated at 2022-06-23 21:32:19.944130
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.home()
    path.root()
    path.user()
    path.users_folder()
    path.project_dir()
    path.dev_dir()

# Generated at 2022-06-23 21:32:22.269938
# Unit test for method user of class Path
def test_Path_user():
    P = Path()
    path = P.user()
    print(path)
    assert path == '/home/oretha'
    

# Generated at 2022-06-23 21:32:27.650312
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.providers.path import Path
    person = Person('en')
    person.seed(2)
    person.gender = Gender.MALE
    path = Path()
    path.seed(2)
    path.platform = 'darwin'
    actual = path.user()
    expected = '/Users/Herman'
    assert actual == expected



# Generated at 2022-06-23 21:32:29.832674
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:32:34.022969
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.typing import Callable
    from mimesis.providers.path import Path
    path = Path()
    assert callable(path.user)
    assert isinstance(path.user(), str)
    assert len(path.user()) > 0


# Generated at 2022-06-23 21:32:35.714967
# Unit test for method user of class Path
def test_Path_user():
    assert Path.user('/home/') == '/home/oretha'


# Generated at 2022-06-23 21:32:42.189694
# Unit test for constructor of class Path
def test_Path():
    """Unit tests for class Path."""
    p = Path('win32')
    assert isinstance(p, Path)
    assert p.platform == 'win32'
    assert isinstance(p._pathlib_home, PureWindowsPath)
    p = Path('linux')
    assert isinstance(p, Path)
    assert p.platform == 'linux'
    assert isinstance(p._pathlib_home, PurePosixPath)


# Generated at 2022-06-23 21:32:43.925009
# Unit test for method user of class Path
def test_Path_user():
    assert Path('linux') == '/home/sherika', 'Test for method Path user()'

# Generated at 2022-06-23 21:32:50.528306
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.seed(21)
    ans = "/"
    assert ans == p.root()
    p.seed(23)
    ans = "/"
    assert ans == p.root()
    p.seed(21)
    ans = "/"
    assert ans == p.root()
    p.seed(25)
    ans = "/"
    assert ans == p.root()
    p.seed(20)
    ans = "/"
    assert ans == p.root()
    p.seed(26)
    ans = "/"
    assert ans == p.root()
    p.seed(20)
    ans = "/"
    assert ans == p.root()
    p.seed(22)
    ans = "/"
    assert ans == p.root()



# Generated at 2022-06-23 21:32:51.764115
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path_test = path.users_folder()
    assert len(path_test) > 0

# Generated at 2022-06-23 21:32:52.725232
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == "/home"


# Generated at 2022-06-23 21:32:55.375390
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    from pprint import pprint
    # Instantiate Path class
    path = Path()
    # Get a random path to user's folders.
    result = path.users_folder()
    # Print the result.
    pprint(result)

if __name__ == "__main__":
    # Run unit test.
    test_Path_users_folder()

# Generated at 2022-06-23 21:33:00.531056
# Unit test for method root of class Path
def test_Path_root():
    from pathlib import PurePosixPath, PureWindowsPath
    from mimesis.providers.path import Path
    import sys
    platform = sys.platform
    obj = Path(platform)
    assert isinstance(obj.root(),str)
    assert obj.root() == str(PureWindowsPath().parent) or obj.root() == str(PurePosixPath().parent)


# Generated at 2022-06-23 21:33:03.068769
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    res = path.home()
    print(res)
    assert res == "C:\\Users"


# Generated at 2022-06-23 21:33:06.449100
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path."""
    path_test = Path()
    path_test.seed(0)
    assert path_test.dev_dir() == str(PurePosixPath('/home/rebeca/Development/Fortran'))

# Generated at 2022-06-23 21:33:11.062148
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    obj = Path('win32')
    assert obj.dev_dir() == '/home/sherrell/Development/Python'

    obj = Path('win64')
    assert obj.dev_dir() == '/home/sherrell/Development/Python'


# Generated at 2022-06-23 21:33:15.360842
# Unit test for constructor of class Path
def test_Path():
    p = Path('dawin');
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())

# Generated at 2022-06-23 21:33:18.921977
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for _ in range(100):
        path = Path()
        # print(path.project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:33:21.207251
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.random.seed(123)
    assert path.users_folder() == '/home/geraldine/Music'

# Generated at 2022-06-23 21:33:23.962800
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()

    assert(isinstance(user, str))
    assert(user.count('/') > 1)
    assert(len(user) > 0)

# Generated at 2022-06-23 21:33:27.081798
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert isinstance(Path().dev_dir(), str)
    assert Path().dev_dir().startswith("/home/")

# Generated at 2022-06-23 21:33:29.941736
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    p.home()
    p.project_dir()



# Generated at 2022-06-23 21:33:35.675226
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:33:38.776333
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    user1 = p.user()
    user2 = p.user()
    assert user1 == user2

# Generated at 2022-06-23 21:33:40.190936
# Unit test for method home of class Path
def test_Path_home():
    gen = Path()
    assert gen.home() == '/home'


# Generated at 2022-06-23 21:33:42.380797
# Unit test for method home of class Path
def test_Path_home():
    test_instance = Path()
    test_value = test_instance.home()
    assert(test_value == '/home')


# Generated at 2022-06-23 21:33:44.717334
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert type(Path().users_folder()) == str


# Generated at 2022-06-23 21:33:46.298960
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    #print(p.user())
    assert True



# Generated at 2022-06-23 21:33:50.645270
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    expected_returned_value = '/home/oretha/Development/Rails'
    actual_returned_value = path.dev_dir()
    if actual_returned_value != expected_returned_value:
        raise Exception(
            'Expected %s, but got %s' % (expected_returned_value, actual_returned_value)
        )
    print('Pass')

# Generated at 2022-06-23 21:33:53.347854
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p1 = p.dev_dir()
    p2 = p.dev_dir()
    assert p1 == p2

# Generated at 2022-06-23 21:34:02.525814
# Unit test for method users_folder of class Path

# Generated at 2022-06-23 21:34:05.089037
# Unit test for method user of class Path
def test_Path_user():
    sut = Path()
    result = sut.user()
    assert result in ["/home/oretha","/Users/oretha"]


# Generated at 2022-06-23 21:34:08.362439
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    expected = str('/')
    assert_equal(path.root(), expected, msg="Expected {} but got {}".format(expected, path.root()))


# Generated at 2022-06-23 21:34:08.943869
# Unit test for method home of class Path
def test_Path_home():
    assert (Path().home() == '/home')
#

# Generated at 2022-06-23 21:34:09.599727
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    t=Path()
    print(t.dev_dir())


# Generated at 2022-06-23 21:34:11.413259
# Unit test for method home of class Path
def test_Path_home():
    fileProvider = Path()
    res = fileProvider.home()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:34:14.328370
# Unit test for method root of class Path
def test_Path_root():
    assert(str(Path.root()) == '/')


# Generated at 2022-06-23 21:34:15.911024
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert len(p.user()) > 0

# Generated at 2022-06-23 21:34:18.315958
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    head = ['Python']
    tail = ['Development', 'Dev']
    assert Path.dev_dir(Path) == head + tail

# Generated at 2022-06-23 21:34:18.962674
# Unit test for constructor of class Path
def test_Path():
    Path()

# Generated at 2022-06-23 21:34:20.308493
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())



# Generated at 2022-06-23 21:34:21.548054
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    x = Path()
    Path.dev_dir(x)

# Generated at 2022-06-23 21:34:22.517821
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:34:23.636401
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() == '/home/taren/Pictures'



# Generated at 2022-06-23 21:34:26.420672
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    t = Path('win32')
    assert t.dev_dir() == 'C:\\Users\\ИвановИван\\Development\\Ruby'

# Generated at 2022-06-23 21:34:27.638373
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:34:31.456565
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Tested method invocation
    test = Path().dev_dir()
    # Tested method result
    compare = '/home/julietta/Development/JavaScript'
    # Test verification
    print(test)
    assert test == compare


# Generated at 2022-06-23 21:34:33.847084
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    instance = Path('linux')
    result = instance.dev_dir()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:34:34.935906
# Unit test for constructor of class Path
def test_Path():
    p = Path('linux')
    assert p is not None
    p = Path('win32')
    assert p is not None


# Generated at 2022-06-23 21:34:37.663616
# Unit test for method home of class Path
def test_Path_home():
    """Test for Path.home."""
    path = Path()
    home = path.home()
    assert type(home) is str
    assert len(home) > 0



# Generated at 2022-06-23 21:34:39.413032
# Unit test for method root of class Path
def test_Path_root():
    instance = Path()
    assert instance.root() == "/"


# Generated at 2022-06-23 21:34:42.187496
# Unit test for method home of class Path
def test_Path_home():
    t = Path(platform='linux')

    output = t.home()
    assert output == '/home'


# Generated at 2022-06-23 21:34:46.481042
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir()"""
    print("\nStart test for method dev_dir()")
    expected ='/home/genoveva/Development/Python'
    result = Path().dev_dir()
    assert result == expected
    print('method dev_dir() works perfectly')


# Generated at 2022-06-23 21:34:48.215972
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == 'linux'



# Generated at 2022-06-23 21:34:49.869988
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None

if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:34:56.406629
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() in [
        '/home/alfred',
        '/home/herbert',
        '/home/merrie',
        '/home/cornell',
        '/home/stephnie',
        '/home/francoise',
        '/home/severo',
        '/home/laree',
        '/home/lili',
        '/home/leslie']

# Generated at 2022-06-23 21:35:00.983193
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # GIVEN
    obj = Path()
    # WHEN
    result = obj.dev_dir()
    # THEN
    assert isinstance(result, str)
    assert 'Development' in result or 'Dev' in result
    assert 'Python' in result or 'Ruby' in result or 'Java' in result

# Generated at 2022-06-23 21:35:05.712633
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p is not None
    assert p.Meta.name == 'path'
    assert p.dev_dir() is not None
    assert p.home() is not None
    assert p.project_dir() is not None
    assert p.root() is not None
    assert p.user() is not None
    assert p.users_folder() is not None

# Generated at 2022-06-23 21:35:06.570505
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()

# Generated at 2022-06-23 21:35:10.231797
# Unit test for method user of class Path
def test_Path_user():
    # Arrange
    method = Path().user

    # Act
    test = method()

    # Assert
    assert '/home/' in test


# Generated at 2022-06-23 21:35:12.088845
# Unit test for constructor of class Path
def test_Path():
    """Test for class Path"""
    P = Path()
    assert P.platform == sys.platform


# Generated at 2022-06-23 21:35:15.018091
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    assert dev_dir[:10] == '/home/sherl'

# Generated at 2022-06-23 21:35:17.306598
# Unit test for method home of class Path
def test_Path_home():
    """Test method home()."""
    path = Path()
    # print(path.home())
    assert len(path.home()) != 0


# Generated at 2022-06-23 21:35:19.924709
# Unit test for method home of class Path
def test_Path_home():
    myclass = Path()
    assert myclass.home() == '/home'

# Generated at 2022-06-23 21:35:21.343580
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert 'home' in p.users_folder()

# Generated at 2022-06-23 21:35:26.543332
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert isinstance(path.users_folder(), str)
    assert len(path.users_folder().split('/')) == 3
    path = Path(platform='win32')
    assert isinstance(path.users_folder(), str)
    assert len(path.users_folder().split('\\')) == 3


# Generated at 2022-06-23 21:35:27.675848
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())


# Generated at 2022-06-23 21:35:29.873690
# Unit test for method root of class Path
def test_Path_root():
    path_ = Path()
    root = path_.root()
    assert isinstance(root, str)
    assert len(root) > 1
    

# Generated at 2022-06-23 21:35:31.193196
# Unit test for method root of class Path
def test_Path_root():
    Path_obj = Path()
    assert Path_obj.root() == '/'


# Generated at 2022-06-23 21:35:35.103342
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path.user() == '/home/' +path.random.choice(USERNAMES)
    assert path.dev_dir() == '/home/'+path.random.choice(USERNAMES)+'/Development/'+path.random.choice(PROGRAMMING_LANGS)
    assert path.users_folder() == '/home/'+path.random.choice(USERNAMES)+'/'+path.random.choice(FOLDERS)
    assert path.home() == '/home'
    assert path.root() == '/'
    assert path.project_dir() == '/home/'+path.random.choice(USERNAMES)+'/Development/'+path.random.choice(PROGRAMMING_LANGS)+'/'+path.random.choice(PROJECT_NAMES)

# Generated at 2022-06-23 21:35:36.372122
# Unit test for method root of class Path
def test_Path_root():
    assert Path('linux').root() == '/'
    assert Path('win32').root() == 'C:\\'

# Generated at 2022-06-23 21:35:38.581282
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert path.dev_dir()
    assert path.dev_dir()
    assert path.dev_dir()
    print(path.dev_dir())

# Generated at 2022-06-23 21:35:39.412601
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/tayler'

# Generated at 2022-06-23 21:35:42.574672
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    # Arrange
    path = Path()

    # Act
    result = path.user()

    # Assert
    assert result.startswith('/home/') or result.startswith('C:\\Users\\')


# Generated at 2022-06-23 21:35:47.701797
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    '''
    Testing of method project_dir of class Path
    '''
    assert Path().project_dir() == ('/home/malisa/Development/Django/'
                                    'nosy') or ('/home/latrice/Development/'
                                                'Ruby/brassy')

# Generated at 2022-06-23 21:35:49.932078
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert isinstance(root, str)
    assert root == '/'


# Generated at 2022-06-23 21:35:52.534093
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:35:54.171601
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:35:59.021697
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    assert path.user() == '/home/nikki'
    user = path.random.choice(USERNAMES)
    user = user.capitalize() if 'win' in path.platform else user.lower()
    assert path.user() == f'/home/{user}'

# Unit testing for method users_folder of class Path

# Generated at 2022-06-23 21:36:04.741889
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result = path.home()
    assert result == '/home'
    assert isinstance(result, str) 
    assert result != path.root()
    assert result != path.user()
    assert result != path.dev_dir()
    assert result != path.users_folder()
    assert result != path.project_dir()


# Generated at 2022-06-23 21:36:07.487890
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert user == '\\home\\oretha'


# Generated at 2022-06-23 21:36:10.571229
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    unit_test_1 = Path(platform='linux')
    path_1 = "/home/yolando/Development/PHP"
    assert unit_test_1.dev_dir() == path_1


# Generated at 2022-06-23 21:36:11.914445
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-23 21:36:12.888885
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() == '/home'


# Generated at 2022-06-23 21:36:16.520808
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert 'Development' in Path().dev_dir()
    assert '~' not in Path().dev_dir()
    assert '/' in Path().dev_dir()
    assert '\\' not in Path().dev_dir()


# Generated at 2022-06-23 21:36:19.639357
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    for i in range(10):
        print(p.dev_dir())
        if "Development" in p.dev_dir():
            print("pass")
        else:
            print("fail")


# Generated at 2022-06-23 21:36:20.886601
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder() == '/home/beverlee/Pictures'

# Generated at 2022-06-23 21:36:23.689463
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for i in range(0,10):
        print(Path().project_dir())

if __name__ == '__main__':
    test_Path_project_dir()

# Generated at 2022-06-23 21:36:26.752596
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path('linux')
    assert path.users_folder() in path.user()
    print('test_Path_users_folder passes')


# Generated at 2022-06-23 21:36:28.023976
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() == '/home/taneka'

# Generated at 2022-06-23 21:36:30.022709
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert (True
            if p.random.choice(USERNAMES) in p.user()
            else False)

# Generated at 2022-06-23 21:36:32.451182
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path"""
    os = Path()
    result = os.user()
    assert result == '/home/taneka'


# Generated at 2022-06-23 21:36:34.054082
# Unit test for method home of class Path
def test_Path_home():
    result = Path().home()
    assert(result == '/home' or result == 'C:\\Users')



# Generated at 2022-06-23 21:36:38.146550
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from pathlib import Path
    from mimesis.enums import Gender

    mimesis = Path(platform='linux')
    p = mimesis.dev_dir()
    assert Path(p).exists() == False
    assert Path(Path.home() + '/' + \
                mimesis.random.choice(['Development', 'Dev']) + '/' + \
                mimesis.random.choice(PROGRAMMING_LANGS)).exists() == False



# Generated at 2022-06-23 21:36:40.467345
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    result_str = path.home()
    assert result_str == '/home'


# Generated at 2022-06-23 21:36:42.307516
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()

    print(path.users_folder())
    # /home/cory/Music


# Generated at 2022-06-23 21:36:52.768716
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():

    import os
    from mimesis.enums import Gender
    from mimesis.path import Path
    from mimesis.person import Person

    p = Person('en')
    # p.seed(1)

    path = Path()
    path.seed(1)

    r = None
    for i in range(20):
        if p.random.choice(Gender.MALE) == Gender.MALE:
            username = p.username()
        else:
            username = p.email(p.username(domain='example.com'), user_type='email')
        # print(username)
        r = path.dev_dir()
        # print(r)
        if os.path.isdir(r):
            break

    assert r == "/home/alejandro/Development/Ruby"

# Generated at 2022-06-23 21:36:54.566378
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path."""
    p = Path(platform='linux')
    assert p
    assert p.platform == 'linux'

# Generated at 2022-06-23 21:36:56.178485
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')
    result = path.user()
    assert result == '/home/sherika'

# Generated at 2022-06-23 21:36:58.574701
# Unit test for method root of class Path
def test_Path_root():
    """Test method root of class Path."""
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:37:00.653075
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    result = path.users_folder()
    print(result) # => /home/cordell/Pictures


# Generated at 2022-06-23 21:37:03.002388
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user."""
    p = Path()
    assert isinstance(p.user(), str)

# Generated at 2022-06-23 21:37:05.172324
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    s = path.users_folder()
    assert 'home' in s
    assert 'Pictures' in s

# Generated at 2022-06-23 21:37:06.454446
# Unit test for method user of class Path
def test_Path_user():
    path_1 = Path()
    path_1.user()


# Generated at 2022-06-23 21:37:09.277885
# Unit test for method home of class Path
def test_Path_home():
    a = Path()
    count = 0
    for i in range(1, 1000):
        count = count + (a.home() == "/home")
    print("The method home of class Path works for 1000 valid values!!")



# Generated at 2022-06-23 21:37:11.598695
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    for _ in range(10):
        print(Path().project_dir())



# Generated at 2022-06-23 21:37:13.994452
# Unit test for method home of class Path
def test_Path_home():
    _pt = Path()
    assert _pt.home() == '/home'

# Generated at 2022-06-23 21:37:16.159550
# Unit test for method home of class Path
def test_Path_home():
    p = Path('win32', seed=23)
    assert p.home() == 'C:\\Users'

# Generated at 2022-06-23 21:37:18.751367
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # Gets instance of class Path
    p = Path()
    # Output of class attribute project_dir
    print(p.project_dir())

test_Path_project_dir()

# Generated at 2022-06-23 21:37:20.360374
# Unit test for method home of class Path
def test_Path_home():
    p = Path('win32')
    assert p.home() == 'C:\\Users'


# Generated at 2022-06-23 21:37:22.234912
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    platform = 'darwin'
    p = Path(platform)
    assert p.project_dir() is not None

# Generated at 2022-06-23 21:37:24.873819
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    assert type(dev_dir) is str


# Generated at 2022-06-23 21:37:34.083628
# Unit test for constructor of class Path
def test_Path():
    p=Path()
    p.user()
    p.home()
    p.root()
    p.dev_dir()
    p.users_folder()
    p.project_dir()
    return True

test_Path()


'''
print(PureWindowsPath())
print(PurePosixPath())
print(PureWindowsPath().parent)
print(PurePosixPath().parent)
print(PureWindowsPath().parent.parent)
print(PurePosixPath().parent.parent)
print(PureWindowsPath().parent.parent.parent)
print(PurePosixPath().parent.parent.parent)
print(PureWindowsPath().parent.parent.parent.parent)
print(PurePosixPath().parent.parent.parent.parent)

'''

# Generated at 2022-06-23 21:37:35.362828
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    users_folder = Path().users_folder()
    assert isinstance(users_folder, str)

# Generated at 2022-06-23 21:37:44.437239
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    # input
    from mimesis.enums import ProgrammingLang
    from mimesis.providers import ProgrammingLanguage
    pl = ProgrammingLanguage()
    stack = pl.get_all(ProgrammingLang)

    import random
    from mimesis.enums import Gender
    from mimesis.providers import Person
    person = Person('en')
    person.gender = Gender.MALE
    person.seed(1234)
    n = random.randint(100, 10000)

    import sys
    p = Path(platform=sys.platform)
    p.random.seed(1234)

# Generated at 2022-06-23 21:37:46.538745
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    project_dir = Path().project_dir()
    lis = project_dir.split('/')
    assert project_dir.count('/') >= 2
    assert len(lis[-1]) > 0


# Generated at 2022-06-23 21:37:47.824347
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:37:51.271569
# Unit test for method home of class Path
def test_Path_home():
    """Test Path.home method."""
    from mimesis.builtins import Path
    p_path = Path('linux').home()
    assert p_path == '/home'

# Generated at 2022-06-23 21:37:53.869561
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    p = path.project_dir()
    print(p)
    assert p in path._pathlib_home
    assert '/' in p


# Generated at 2022-06-23 21:37:55.049057
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert path is not None


# Generated at 2022-06-23 21:37:58.789831
# Unit test for method home of class Path
def test_Path_home():
    """Test Path.home() method."""
    path_ = Path()
    # assert path_.home() == '/home'



# Generated at 2022-06-23 21:38:00.757433
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    folder = Path().users_folder()
    print(f"users_folder => {folder}")


# Generated at 2022-06-23 21:38:04.226717
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Initialize a local variable for the class Path with parameter C
    C = Path(platform="win32")
    # Assign the local value to path_dev
    path_dev = C.dev_dir()
    return path_dev


# Generated at 2022-06-23 21:38:07.527234
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print(path.users_folder())
    print(path.dev_dir())
    print(path.home())
    print(path.root())
    print(path.user())
    print(path.project_dir())

# Generated at 2022-06-23 21:38:09.401253
# Unit test for method root of class Path
def test_Path_root():
    dir = Path().root()
    assert dir == '/'
    assert type(dir) == str


# Generated at 2022-06-23 21:38:11.410011
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert path.home() in ['C:/Users', '/home']


# Generated at 2022-06-23 21:38:14.091053
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    result1 = p.users_folder()
    result2 = p.users_folder()
    assert len(result1) != 0
    assert result1 != result2

# Generated at 2022-06-23 21:38:21.172492
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path."""
    assert Path().users_folder() in ['/Users/diedre/Movies',
                                     '/home/marianela/Music',
                                     '/Users/salvatore/Pictures',
                                     '/home/elaina/Pictures',
                                     '/Users/lacey/Pictures',
                                     '/home/tiffaney/Public',
                                     '/home/taneisha/Desktop',
                                     '/home/tanya/Desktop',
                                     ]


# Generated at 2022-06-23 21:38:24.299896
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path"""
    path = Path()
    for sample_size in range(100):
        result = path.project_dir()
        assert result in ("/home/sherrell/Development/Python/donkey",)


# Generated at 2022-06-23 21:38:26.513880
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())
    return path.dev_dir()


# Generated at 2022-06-23 21:38:36.185384
# Unit test for constructor of class Path
def test_Path():
    print("Testing Path class")
    print("\tdefault path")
    path = Path()
    print("\t\tpath.root() = " + path.root())
    print("\t\tpath.home() = " + path.home())
    print("\t\tpath.user() = " + path.user())
    print("\t\tpath.users_folder() = " + path.users_folder())
    print("\t\tpath.dev_dir() = " + path.dev_dir())
    print("\t\tpath.project_dir() = " + path.project_dir())
    print("\twin32 path")
    path = Path(platform='win32')
    print("\t\tpath.root() = " + path.root())

# Generated at 2022-06-23 21:38:37.464758
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.random.choice(FOLDERS))

# Generated at 2022-06-23 21:38:40.109974
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('win32')
    path = p.project_dir()
    res = '/home/mildred/Development/Php/environmental'
    assert path == res

# Generated at 2022-06-23 21:38:41.134833
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    path.dev_dir()

# Generated at 2022-06-23 21:38:45.427194
# Unit test for method user of class Path
def test_Path_user():
    # get at most 10 random users
    for i in range(10):
        print(Path().user())

    # get at most 10 random users with english locale
    for i in range(10):
        print(Path('en').user())

    # get at most 10 random users with russian locale
    for i in range(10):
        print(Path('ru').user())


# Generated at 2022-06-23 21:38:47.599336
# Unit test for method user of class Path
def test_Path_user():
    for i in range(0, 5):
        path = Path()
        print(path.user())


# Generated at 2022-06-23 21:38:50.497486
# Unit test for method user of class Path
def test_Path_user():
    """Unit test to check if method user is working fine."""
    from mimesis.path import Path
    a = Path()
    assert len(a.user()) > 0

# Generated at 2022-06-23 21:38:55.075280
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert str(PurePath(path.dev_dir()).parent).find('Development') != -1
    assert str(PurePath(path.dev_dir()).parts[-1]) in PROGRAMMING_LANGS

# Generated at 2022-06-23 21:39:03.725869
# Unit test for constructor of class Path
def test_Path():
    from random import getrandbits
    from sys import platform
    from . import path
    from .pathlib import Path as MimesisPath
    from .pathlib import PurePath

    seed = getrandbits(32)
    seed_string = str(seed)

    path_1 = path.Path(seed=seed)
    path_2 = path.Path(seed=seed_string)

    assert path_1 is not None
    assert path_1._random_local is not None
    assert isinstance(path_1._random_local, type(path_2._random_local))
    assert path_1.platform == platform
    assert isinstance(path_1._pathlib_home, PurePath)

    assert path_2 is not None
    assert path_2._random_local is not None

# Generated at 2022-06-23 21:39:08.488810
# Unit test for constructor of class Path
def test_Path():
    p = Path(platform="linux")
    print(p.root())
    print(p.home())
    print(p.user())
    print(p.users_folder())
    print(p.dev_dir())
    print(p.project_dir())


if __name__ == "__main__":
    test_Path()

# Generated at 2022-06-23 21:39:09.695524
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()

# Generated at 2022-06-23 21:39:15.165710
# Unit test for method user of class Path
def test_Path_user():
    from pprint import pprint
    from random import randint
    from mimesis.enums import SpecialChar
    from mimesis.builtins import USASpecialChar
    special_char = USASpecialChar()
    lista = []
    for i in range(100):
        user = Path().user()
        list_user = user.split('/')[-1].lower().split(special_char.get_char(SpecialChar.SPACE))
        if len(list_user) == 1:
            list_user = list_user[0].split('.')
        if not len(list_user) == 2:
            lista.append(list_user)
    pprint(lista)

# Generated at 2022-06-23 21:39:17.243113
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for _ in range(10):
        #print(str(path.user()))
        assert path.user()


# Generated at 2022-06-23 21:39:18.897117
# Unit test for constructor of class Path
def test_Path():
    import sys
    p = Path(platform=sys.platform)
    assert p._pathlib_home is not None

# Generated at 2022-06-23 21:39:20.086105
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:39:20.989817
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    p.dev_dir()

# Generated at 2022-06-23 21:39:23.890134
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    for i in range(4):
        print(path.project_dir())

if __name__ == "__main__":
    test_Path_project_dir()

# Generated at 2022-06-23 21:39:25.315392
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root().startswith('/') or ':\\'


# Generated at 2022-06-23 21:39:28.300833
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    instance = Path()
    project = instance.project_dir()
    assert project.startswith("/home")

#Unit test for method dev_dir of class Path

# Generated at 2022-06-23 21:39:31.662752
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print("test_Path_users_folder")
    path = Path()
    assert path.users_folder() == '/home/mariana/Pictures'
    print("Test passed")


# Generated at 2022-06-23 21:39:33.057808
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())
    assert path.project_dir() == "/home/abdel/Development/Go/shovel"

# Generated at 2022-06-23 21:39:35.524275
# Unit test for constructor of class Path
def test_Path():
    obj = Path()
    obj.root()
    obj.home()
    obj.user()
    obj.users_folder()
    obj.dev_dir()
    obj.project_dir()

# Generated at 2022-06-23 21:39:36.640850
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    print(p.home())


# Generated at 2022-06-23 21:39:41.224394
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    my_env = {"test": "test_Path_users_folder"}
    path_obj = Path(seed=5, local_data=my_env)
    print(path_obj.users_folder())
    path_obj2 = Path(seed=5, local_data=my_env)
    print(path_obj2.users_folder())



# Generated at 2022-06-23 21:39:42.898187
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    c = 0
    while c < 10:
        print(p.user())
        c += 1


# Generated at 2022-06-23 21:39:44.385404
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    root = path.root()
    assert isinstance(root, str)


# Generated at 2022-06-23 21:39:45.658052
# Unit test for method root of class Path
def test_Path_root():
    pass
    # path = Path()
    # print(path.home())


# Generated at 2022-06-23 21:39:47.363791
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    Path = Path()
    assert Path.project_dir() == "/home/alena/Development/PowerShell/tenderness"


# Generated at 2022-06-23 21:39:48.761416
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    print(dev_dir)


# Generated at 2022-06-23 21:39:50.488798
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path('linux')
    print(p.project_dir())

# Generated at 2022-06-23 21:39:56.746699
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Initialization of a Path object
    path_obj = Path('linux')
    # Call method dev_dir of object path_obj
    result = path_obj.dev_dir()
    # Display result
    print("rand_dev_dir: " + result)

test_Path_dev_dir()

# Function implementation for method users_folder of class Path

# Generated at 2022-06-23 21:40:00.104749
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print('path.user() = {}'.format(path.user()))
    path2 = Path('linux')
    print('path2.user() = {}'.format(path2.user()))


# Generated at 2022-06-23 21:40:01.552357
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    paths = Path()
    assert isinstance(paths.users_folder(), str)


# Generated at 2022-06-23 21:40:13.342966
# Unit test for constructor of class Path
def test_Path():
    BASE = "path"
    path = Path()
    # test _seed
    assert type(path._seed) is int
    # test data
    assert path.providers == {}
    assert path._data == {}
    assert path.locales_data == {}
    assert path.platform == "linux"
    # test Meta
    assert path.Meta.name == "path"
    # test methods
    # uid
    assert path.uid[0] == "0"
    assert path.uid[1] == "1"
    assert path.uid[2] == "2"
    # code
    assert path.code(mask="###-###", digit="0")[0] == "000-000"
    assert path.code(mask="###-###", digit="9")[0] == "999-999"