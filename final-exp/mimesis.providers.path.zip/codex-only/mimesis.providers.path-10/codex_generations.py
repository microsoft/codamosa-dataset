

# Generated at 2022-06-23 21:30:12.309698
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    pass


# Generated at 2022-06-23 21:30:14.467870
# Unit test for method root of class Path
def test_Path_root():
    assert Path("linux").root() == "/"

# Generated at 2022-06-23 21:30:16.392907
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    assert 'linux' in path.platform
    assert path.random is not None
    assert path.datetime is not None

# Generated at 2022-06-23 21:30:18.623185
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'

# Generated at 2022-06-23 21:30:21.831568
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == sys.platform
    assert p.pathlib_home == p._pathlib_home
    assert p.platform in PLATFORMS.keys()


# Generated at 2022-06-23 21:30:25.049595
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    """Unit test for method users_folder of class Path"""
    p=Path()
    p1=p.users_folder()
    p2=p.users_folder()
    assert(p1 != p2)


# Generated at 2022-06-23 21:30:33.804802
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path('win32')

# Generated at 2022-06-23 21:30:36.410760
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test_path = Path()
    test_path_project_dir = test_path.project_dir()
    assert 'Development' in test_path_project_dir
    assert 'Python' in test_path_project_dir
    assert 'flock' in test_path_project_dir

# Generated at 2022-06-23 21:30:38.619710
# Unit test for method home of class Path
def test_Path_home():
    bin_path = Path().home()
    print(bin_path)
    assert bin_path is not None


# Generated at 2022-06-23 21:30:39.600571
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())

# Generated at 2022-06-23 21:30:43.358564
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """
    Check that method dev_dir of class Path returns a path
    """

    p = Path()
    p.random.seed(0)
    assert p.dev_dir() == '/home/meridith/Development/Python'
    #assert p.dev_dir() == '/home/meridith/Development/Python'


# Generated at 2022-06-23 21:30:44.838909
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()

# Generated at 2022-06-23 21:30:47.438123
# Unit test for method home of class Path
def test_Path_home():
    """Unit test for method home of class Path."""
    p = Path()
    result = p.home()
    assert result is not None



# Generated at 2022-06-23 21:30:50.844820
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    dev_dir = p.dev_dir()
    print(dev_dir)

    assert(type(dev_dir) is str) 
    assert(len(dev_dir) > 0)


# Generated at 2022-06-23 21:30:52.118598
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:30:53.915476
# Unit test for method root of class Path
def test_Path_root():
    """Test method of class Path"""
    assert Path().root() == '/'


# Generated at 2022-06-23 21:30:57.609253
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home_path = path.home()
    assert(home_path == '/home')
    print("Path home: " + home_path)


# Generated at 2022-06-23 21:30:59.770207
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    dev_dir = Path().dev_dir()
    assert dev_dir == '/home/taneka/Development/Python'


# Generated at 2022-06-23 21:31:02.259435
# Unit test for method user of class Path
def test_Path_user():
    x = Path()
    x.random.seed(1)
    assert x.user() == '/home/oretha'


# Generated at 2022-06-23 21:31:04.394632
# Unit test for method home of class Path
def test_Path_home():
    """Test method home() of class Path."""
    p = Path()
    assert isinstance(p.home(), str)


# Generated at 2022-06-23 21:31:05.429571
# Unit test for method root of class Path
def test_Path_root():
    Created_Path = Path()
    assert Created_Path.root() == '/'


# Generated at 2022-06-23 21:31:07.464352
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    path.user()
    assert True


# Generated at 2022-06-23 21:31:18.327422
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    x = Path(platform='linu', seed=0)
    assert x.dev_dir() == '/home/xander/Development/D'
    assert x.dev_dir(seed=0) == '/home/xander/Development/D'

    x = Path(platform='linux', seed=0)
    assert x.dev_dir() == '/home/brionna/Dev/Clojure'
    assert x.dev_dir(seed=0) == '/home/brionna/Dev/Clojure'

    x = Path(platform='darwin', seed=0)
    assert x.dev_dir() == '/Users/yasmin/Dev/Racket'
    assert x.dev_dir(seed=0) == '/Users/yasmin/Dev/Racket'

    x = Path(platform='win32', seed=0)


# Generated at 2022-06-23 21:31:20.354618
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())


# Generated at 2022-06-23 21:31:22.665785
# Unit test for method root of class Path
def test_Path_root():
    """Unit test for method root of class Path."""
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:31:23.977991
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert "home" in p.users_folder()

# Generated at 2022-06-23 21:31:27.864705
# Unit test for method home of class Path
def test_Path_home():
    home_path = Path("win32").home()
    assert type(home_path) == str and home_path == "C:\\Users"

    home_path = Path("linux").home()
    assert type(home_path) == str and home_path == "/home"

    home_path = Path("darwin").home()
    assert type(home_path) == str and home_path == "/home"


# Generated at 2022-06-23 21:31:31.392466
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    sp = Path()
    for i in range(1000):
        path = sp.project_dir()
        assert path and type(path) == str and len(path) >= 13 and len(path) <= 100

# Generated at 2022-06-23 21:31:34.280886
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == "/usr/home" or p.home() == "C:/Users"


# Generated at 2022-06-23 21:31:45.664507
# Unit test for method user of class Path

# Generated at 2022-06-23 21:31:47.236295
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:31:49.766682
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    #th=path.home()
    assert path.__class__.__name__ == "Path"


# Generated at 2022-06-23 21:31:51.325607
# Unit test for constructor of class Path
def test_Path():
    '''
    This test will execute the constructor for the class Path
    '''
    path = Path()
    assert path is not None


# Generated at 2022-06-23 21:31:52.346203
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())

# Generated at 2022-06-23 21:31:53.723414
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    assert p.users_folder() == "/home/eve/Pictures"


# Generated at 2022-06-23 21:31:55.713534
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    print("Path.users_folder(): ", path.users_folder())


# Generated at 2022-06-23 21:31:58.539331
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print(p.root())


# Generated at 2022-06-23 21:32:00.576219
# Unit test for method user of class Path
def test_Path_user():
    generator = Path()
    generated_name = generator.user()
    assert isinstance(generated_name, str)


# Generated at 2022-06-23 21:32:02.389806
# Unit test for method root of class Path
def test_Path_root():
    """Test Path's method root"""
    p = Path()
    assert p.root() is not None


# Generated at 2022-06-23 21:32:04.301977
# Unit test for method home of class Path
def test_Path_home():
    custom_path = Path(platform='linux')
    root = custom_path.home()

    assert(root == "/home")



# Generated at 2022-06-23 21:32:05.913559
# Unit test for constructor of class Path
def test_Path():
    path_ = Path(platform='linux')
    result = path_.user()
    assert result.startswith('/home/')


# Generated at 2022-06-23 21:32:07.219751
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:32:11.941885
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    assert Path().dev_dir() == '/home/julianna/Development/Python'
    assert Path().dev_dir() == '/home/luba/Development/Ruby'
    assert Path().dev_dir() == '/home/julianna/Dev/Python'
    

# Generated at 2022-06-23 21:32:15.488864
# Unit test for method user of class Path
def test_Path_user():
    path_obj = Path()
    user1 = path_obj.user()
    user2 = path_obj.user()
    assert user1 != user2


# Generated at 2022-06-23 21:32:25.449523
# Unit test for constructor of class Path
def test_Path():
    print('Test for constructor of Path class')
    import sys
    print("sys.platform: {}".format(sys.platform))
    path_common = Path()
    print("path_common.platform: {}".format(path_common.platform))
    path_common_1 = Path("linux")
    print("path_common_1.platform: {}".format(path_common_1.platform))
    path_common_2 = Path("darwin")
    print("path_common_2.platform: {}".format(path_common_2.platform))
    path_common_3 = Path("win32")
    print("path_common_3.platform: {}".format(path_common_3.platform))
    path_common_4 = Path("win64")

# Generated at 2022-06-23 21:32:30.026714
# Unit test for method user of class Path
def test_Path_user():
    print("\nTesting method <user> of class <Path>...")
    import mimesis
    import mimesis.enums
    import os
    path = mimesis.Path()
    home_dir = path.home()
    assert os.path.isdir(home_dir)
    user = path.user()
    assert os.path.isdir(user)
    assert user.startswith(home_dir)
    print("Ok!")


# Generated at 2022-06-23 21:32:32.003393
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p1 = Path()
    print('project_dir()', p1.project_dir())



# Generated at 2022-06-23 21:32:33.805710
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    for i in range(100):
        print(p.users_folder())


# Generated at 2022-06-23 21:32:34.718290
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():    
    assert len(Path().dev_dir()) > 0

# Generated at 2022-06-23 21:32:36.469106
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path."""
    p = Path()
    assert p.user() == '/home/melvin'


# Generated at 2022-06-23 21:32:38.976552
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    dev_dir = path.dev_dir()
    assert isinstance(dev_dir, str)


# Generated at 2022-06-23 21:32:40.889159
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert len(path.users_folder()) > 0
    assert type(path.users_folder()) is str


# Generated at 2022-06-23 21:32:46.494902
# Unit test for method user of class Path
def test_Path_user():
    """
    """
    import os
    import pathlib
    # init the tested class
    path_provider = Path()
    # get the target function
    target_function = path_provider.user
    # call the function
    actual_result = target_function()
    # get the expected result
    home_folder = pathlib.Path.home()
    expected_result = os.path.join(str(home_folder), path_provider.random.choice(USERNAMES))
    # compare the actual result with the expected result
    assert actual_result == expected_result


# Generated at 2022-06-23 21:32:48.978804
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert isinstance(path.dev_dir(), str)
    assert path.dev_dir() != ''


# Generated at 2022-06-23 21:32:50.469027
# Unit test for method home of class Path
def test_Path_home():
    x = Path()
    assert isinstance(x.home(), str)

# Generated at 2022-06-23 21:32:52.844786
# Unit test for method user of class Path
def test_Path_user():

    test = Path('linux')
    test.random.choice = lambda x: x[0]
    assert test.user() == '/home/oretha'



# Generated at 2022-06-23 21:32:53.697906
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    print(p.project_dir())


# Generated at 2022-06-23 21:32:55.524715
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    home = path.home()
    assert '/home' == home



# Generated at 2022-06-23 21:32:58.470850
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert Path().users_folder().startswith('/home')
    assert Path('win32').users_folder().startswith('C:\\Users')


# Generated at 2022-06-23 21:33:01.843724
# Unit test for method user of class Path
def test_Path_user():
    """Test Path.user()."""
    path = Path()
    users = set(path.user() for _ in range(1000))
    assert len(users) == len(USERNAMES)


# Generated at 2022-06-23 21:33:04.116528
# Unit test for method home of class Path
def test_Path_home():
    ret = Path().home()
    assert ret and isinstance(ret, str), 'test_Path_home error'
    print('test_Path_home ok')

# Generated at 2022-06-23 21:33:05.580128
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:33:07.340371
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p._pathlib_home == PurePosixPath('/home')
    assert p.platform == 'linux'

# Generated at 2022-06-23 21:33:12.396322
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.builtins import FileSystem

    path = Path('win32')
    dev_dir = path.dev_dir()

    print ("Path: ", dev_dir)

    file_system = FileSystem('win32')
    assert file_system.folder_path(dev_dir)



# Generated at 2022-06-23 21:33:23.320710
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.platform == 'win64'
    assert p._pathlib_home == "C:\\Users"
    p = Path('win32')
    assert p._pathlib_home == "C:\\Documents and Settings"
    p = get_random_path()
    assert p.platform in ('win64', 'win32', 'darwin', 'linux')
    assert p._pathlib_home in ('C:\\Users', 'C:\\Documents and Settings',
                            '/Users', '/home')
    assert p.root() in ('C:\\', '/')
    assert p.home() in ('C:\\Users', '/home')
    assert p.users_folder() in ('C:\\Users\\UserName\\Pictures',
                            '/home/UserName/Pictures')
    assert p.dev_dir()

# Generated at 2022-06-23 21:33:24.283324
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    a = Path()
    a.project_dir()

# Generated at 2022-06-23 21:33:29.102400
# Unit test for constructor of class Path
def test_Path():
    """Create a instance of class Path.

    :return: Instance of Path.
    """
    path = Path()
    assert isinstance(path, Path)


# Generated at 2022-06-23 21:33:31.209745
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    instance = Path()
    result = instance.dev_dir()
    print(result)
    assert result


# Generated at 2022-06-23 21:33:33.149410
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    for _ in range(0,10):
        print(Path().users_folder())


# Generated at 2022-06-23 21:33:34.692725
# Unit test for method root of class Path
def test_Path_root():
    path_class = Path()
    assert path_class.root() == '/'



# Generated at 2022-06-23 21:33:37.171233
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    classpath = Path()
    assert type(classpath.dev_dir()) is str
    assert classpath.dev_dir()


# Generated at 2022-06-23 21:33:38.825300
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'


# Generated at 2022-06-23 21:33:40.608877
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() in ["/home", "/Users"]


# Generated at 2022-06-23 21:33:44.657071
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    res = path.users_folder()
    assert path.root() in res # check root dir
    assert path.home() in res # check home path
    assert 'Pictures' in res or 'Documents' in res # check folder
    assert path.random.choice(USERNAMES) in res # check username

# Generated at 2022-06-23 21:33:45.563779
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    assert isinstance(Path().users_folder(), str)

# Generated at 2022-06-23 21:33:46.722009
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    p.root()


# Generated at 2022-06-23 21:33:48.228925
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    print(p.project_dir())

# Generated at 2022-06-23 21:33:49.379757
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root()



# Generated at 2022-06-23 21:33:57.822841
# Unit test for constructor of class Path
def test_Path():
    # assert Path.__doc__ is not None
    # assert Path.__init__.__doc__ is not None
    path = Path()
    assert path is not None
    assert path.platform is not None
    assert path._pathlib_home is not None
    assert path.user() is not None
    assert path.users_folder() is not None
    assert path.dev_dir() is not None
    assert path.project_dir() is not None
    assert path.home() is not None
    assert path.root() is not None

test_Path()

# Generated at 2022-06-23 21:34:00.418157
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    assert len(path.dev_dir()) > 0


# Generated at 2022-06-23 21:34:11.882440
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    method = Path().project_dir
    assert method() == '/home/horacio/Dev/matlab/caring'
    assert method() == '/home/sherika/Development/Falcon/uncommon'
    assert method() == '/home/griselda/Dev/ruby/catastrophe'
    assert method() == '/home/taneka/Development/Haskell/bygone'
    assert method() == '/home/sherrell/Development/COBOL/solar'
    assert method() == '/home/griselda/Dev/php/recurrent'
    assert method() == '/home/taneka/Development/Java/dispatcher'
    assert method() == '/home/oretha/Dev/befitting'
    assert method() == '/home/monica/Development/Erlang/torpor'

# Generated at 2022-06-23 21:34:14.378865
# Unit test for method root of class Path
def test_Path_root():
    assert Path().root() == '/'


# Generated at 2022-06-23 21:34:16.349739
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    #print(p.dev_dir())
    assert 5 == 5


# Generated at 2022-06-23 21:34:20.000249
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    p.random.seed(1)
    users_folder = p.users_folder()
    print(users_folder)
    assert str(users_folder) == '/home/jame/Music'


# Generated at 2022-06-23 21:34:21.255356
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert len(path.home()) > 0

# Generated at 2022-06-23 21:34:23.376139
# Unit test for method home of class Path
def test_Path_home():
    p = Path('linux')
    assert p.home() == '/home'

    p = Path('win32')
    assert p.home() == 'C:\\Users'

# Generated at 2022-06-23 21:34:25.084454
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path_provider = Path()
    project_dir_path = path_provider.project_dir()
    print(project_dir_path)


# Generated at 2022-06-23 21:34:28.690276
# Unit test for method home of class Path
def test_Path_home():
    """test_Path_home"""
    from mimesis.enums import Platform
    path = Path(platform=Platform.LINUX)
    print(path.home())



# Generated at 2022-06-23 21:34:31.004987
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    path = p.user()
    assert isinstance(path, str)
    return path


# Generated at 2022-06-23 21:34:32.515461
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert isinstance(path.home(), str)

# Generated at 2022-06-23 21:34:34.006051
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    assert p.root() == '/'



# Generated at 2022-06-23 21:34:39.658036
# Unit test for constructor of class Path
def test_Path():
    """Unit test for constructor of class Path"""
    assert Path() is not None
    assert Path('linux') is not None
    assert Path('linux') is not None
    assert Path('darwin') is not None
    assert Path('win32') is not None
    assert Path('win64') is not None
    assert Path('') is not None
    assert Path('win') is not None
    assert Path('other_platform') is not None


# Generated at 2022-06-23 21:34:42.373637
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    # Create new Provider Path
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-23 21:34:44.007660
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.home()
    path.user()
    path.users_folder()
    path.dev_dir()
    path.project_dir()

# Generated at 2022-06-23 21:34:44.785111
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    print(path.dev_dir())

# Generated at 2022-06-23 21:34:46.572129
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    lvl1 = path.user()
    assert lvl1[0] == '/'


# Generated at 2022-06-23 21:34:48.108506
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    '''
    Testing method dev_dir of class Path
    '''
    pathlib = Path()
    print(pathlib.dev_dir())


# Generated at 2022-06-23 21:34:49.792651
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path = Path()
    res = path.dev_dir()
    assert type(res) == str


# Generated at 2022-06-23 21:34:51.864827
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    print(p.user())



# Generated at 2022-06-23 21:34:58.603559
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    if sys.platform.startswith('win'):
        path = PureWindowsPath(PLATFORMS[sys.platform]['paths'])
    else:
        path = PurePosixPath(PLATFORMS[sys.platform]['paths'])

    s = Path().users_folder()
    path2 = path.joinpath(s.split('/')[-2], s.split('/')[-1])
    assert s == str(path2)

# Generated at 2022-06-23 21:35:02.313926
# Unit test for constructor of class Path
def test_Path():
    """Tests for Path.

    1. Tests that all constructors and methods exist.
    2. Tests that all str methods return strings
    """
    obj = Path()
    assert dir(obj) and len(dir(obj))


# Generated at 2022-06-23 21:35:03.580364
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    print(p.dev_dir())


# Generated at 2022-06-23 21:35:04.745759
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    print(Path().users_folder())


# Generated at 2022-06-23 21:35:05.909055
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    path.home()


# Generated at 2022-06-23 21:35:08.978724
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert type(path.root()) == str
    assert path.root() == '/'


# Generated at 2022-06-23 21:35:15.994264
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    from mimesis.providers.path import Path

    # Create object
    path = Path()

    # Generate random project dir
    for i in range(0,100):
        result = path.project_dir()
        assert result is not None, u"Result must be a string"
        assert isinstance(result, str), u"Result must be a string"

    # Print result
    print(result)
    # /home/sherika/Development/Falcon/mercenary

# Generated at 2022-06-23 21:35:20.420368
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    _ = p.home()
    _ = p.home()
    _ = p.home()
    _ = p.home()
    _ = p.home()


# Generated at 2022-06-23 21:35:22.389304
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert p.user() != None
    assert p.user() is not None


# Generated at 2022-06-23 21:35:26.106506
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    result = set()
    for i in range(1, 100):
        temp = Path.build().project_dir()
        assert isinstance(temp, str)
        result.add(temp)
    assert len(result) > 10

# Generated at 2022-06-23 21:35:28.344567
# Unit test for method root of class Path
def test_Path_root():
    """Test method Path.root."""
    p = Path()
    p.seed(0)
    assert p.root() == '/'


# Generated at 2022-06-23 21:35:29.317722
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    p.users_folder()

# Generated at 2022-06-23 21:35:34.268090
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    obj = Path()
    result = obj.project_dir()
    assert result == 'C:\\Users\\vijas\\Development\\Perl\\enclosure' or result == \
        '/home/luba/Development/Rust/musicality' or result == \
        '/home/herschel/Development/Dart/crenelation'

# Generated at 2022-06-23 21:35:36.009521
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    p = Path()
    assert isinstance(p.dev_dir(), str)


# Generated at 2022-06-23 21:35:39.090908
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    root = p.root()
    assert True == isinstance(root, str)
    assert len(root.split('/')) == 4
    assert ' ' not in root
    assert '\n' not in root
    assert ':' not in root


# Generated at 2022-06-23 21:35:49.776199
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    users_folder = path.users_folder()

# Generated at 2022-06-23 21:35:52.804168
# Unit test for method home of class Path
def test_Path_home():
    api = Path()
    res = api.home()
    assert res == '/home'


# Generated at 2022-06-23 21:35:54.675232
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    assert len(p.user()) == 18
    # /home/marlena
    assert p.user() == '/home/marlena'


# Generated at 2022-06-23 21:35:56.408545
# Unit test for constructor of class Path
def test_Path():
    path = Path('linux')
    assert path.platform == 'linux'



# Generated at 2022-06-23 21:35:59.805513
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    # Create an instance of class Path
    path = Path()
    # Call method dev_dir of class Path
    print(path.dev_dir())
    # Expected output: /home/sherrier/Development/Python
    return None


# Generated at 2022-06-23 21:36:06.813450
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path_win = Path('win32')

    assert path.platform == sys.platform
    assert path_win.platform == 'win32'
    assert isinstance(path._pathlib_home, PurePosixPath)
    assert isinstance(path_win._pathlib_home, PureWindowsPath)


# Unit tests for methods of class Path

# Generated at 2022-06-23 21:36:08.150991
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() == '/'


# Generated at 2022-06-23 21:36:09.322157
# Unit test for method root of class Path
def test_Path_root():
    provider = Path('windows')
    assert provider.root() == '\\'

# Generated at 2022-06-23 21:36:10.822199
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    mp = Path()
    print(mp.project_dir())


# Generated at 2022-06-23 21:36:13.002706
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print(Path.dev_dir(Path()))
    print(Path.dev_dir(Path()))
    print(Path.dev_dir(Path()))


# Generated at 2022-06-23 21:36:15.780737
# Unit test for method user of class Path
def test_Path_user():
    """Test method user of Class Path.
    """
    path = Path()
    user_path = path.user()
    assert user_path
    assert '/' in user_path

# Generated at 2022-06-23 21:36:17.575272
# Unit test for method root of class Path
def test_Path_root():
    from pprint import pprint
    path = Path()
    pprint(path.root())


# Generated at 2022-06-23 21:36:20.241338
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    paths = []
    for _ in range(10):
        paths.append(p.project_dir())

    assert all(isinstance(x, str) for x in paths)


# Generated at 2022-06-23 21:36:21.438270
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/taneka'


# Generated at 2022-06-23 21:36:31.580516
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    print(Path("win32").dev_dir()) # Выводит путь к директории с учетом местоположения домашней папки
    print(Path("linux").dev_dir()) # Выводит путь к директории с учетом местоположения домашней папки
    print(Path("linux").project_dir()) # Выводит путь к директ

# Generated at 2022-06-23 21:36:35.074421
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """
    Test that Path.dev_dir returns a directory with the name of a language in
    it
    """
    path = Path()
    directory = path.dev_dir()
    assert directory != ""
    assert directory.split("/")[3] in PROGRAMMING_LANGS


# Generated at 2022-06-23 21:36:42.674465
# Unit test for method user of class Path
def test_Path_user():
    assert Path('linux').user() == Path('linux').home()+'/'+random.choice(USERNAMES)   #Testing linux Path
    # print("Linux Path: " + Path('linux').user())
    
    assert Path('darwin').user() == Path('darwin').home()+'/'+random.choice(USERNAMES) #Testing darwin Path
    # print("Darwin Path: " + Path('darwin').user())
    
    assert Path('win32').user() == Path('win32').home()+'\\'+random.choice(USERNAMES).lower() #Testing win32 Path
    # print("Windows Path: " + Path('win32').user())


# Generated at 2022-06-23 21:36:46.803008
# Unit test for method home of class Path
def test_Path_home():
    """Test for method Path.home."""
    for i in range(100):
        actual = (Path().home()).strip()
        expected = '/home'
        assert actual == expected


# Generated at 2022-06-23 21:36:49.464309
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert 'home' in path.home()
    assert path.home() == 'C:\\Users' or path.home() == '/home'


# Generated at 2022-06-23 21:36:54.869891
# Unit test for constructor of class Path
def test_Path():
    print("Test for Path class started")
    assert Path().platform == sys.platform
    assert Path().platform != 'win32'
    assert Path().platform != 'win64'
    assert Path(platform='linux').platform == 'linux'
    assert Path(platform='darwin').platform == 'darwin'
    assert Path(platform='win32').platform == 'win32'
    assert Path(platform='win64').platform == 'win64'
    print("Test for Path class finished successfully")


# Generated at 2022-06-23 21:36:56.811000
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert isinstance(path.root(),str)
    assert path.root() != ''


# Generated at 2022-06-23 21:37:00.511256
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    provider = Path()
    result = provider.users_folder()
    print(result)
    assert (result != ''), "Ошибка: строка пустая"


# Generated at 2022-06-23 21:37:03.688374
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    my_path = Path()
    print(my_path.project_dir())
    # => /home/sherika/Development/Falcon/mercenary


# Generated at 2022-06-23 21:37:04.565661
# Unit test for method user of class Path
def test_Path_user():
    unit = Path()
    assert unit.user() is not None


# Generated at 2022-06-23 21:37:08.216552
# Unit test for method user of class Path
def test_Path_user():
    u1 = Path().user()
    assert u1 == "\\Users\\Dalila" or u1 == "/home/dalila"
    u2 = Path('linux').user()
    assert u2 == "/home/dalila"
    u3 = Path('win32').user()
    assert u3 == "\\Users\\dalila" or u3 == "\\Users\\Dalila"

if __name__ == "__main__":
    test_Path_user()

# Generated at 2022-06-23 21:37:10.151177
# Unit test for method user of class Path
def test_Path_user():
    """Unit test for method user of class Path.
    """
    provider = Path()
    
    assert type(provider.user()) == str


# Generated at 2022-06-23 21:37:16.981375
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    assert Path().project_dir() == Path('linux').project_dir()
    assert Path().project_dir() == Path('darwin').project_dir()
    assert Path().project_dir() == Path('win32').project_dir()
    assert Path().project_dir() == Path('win64').project_dir()

# Generated at 2022-06-23 21:37:19.163448
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Test for method project_dir of class Path"""
    path = Path()
    assert isinstance(path.project_dir(), str)


# Generated at 2022-06-23 21:37:21.452185
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    assert (path.home() == '/home')
    assert (type(path.home()) is str)


# Generated at 2022-06-23 21:37:32.448254
# Unit test for method user of class Path
def test_Path_user():
    from pathlib import PurePosixPath, PureWindowsPath
    from mimesis.data import (
        FOLDERS,
        PLATFORMS,
        PROGRAMMING_LANGS,
        PROJECT_NAMES,
        USERNAMES,
    )
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.path import Path

    def root(self) -> str:
        """Generate a root dir path.

        :return: Root dir.

        :Example:
            /
        """
        return str(self._pathlib_home.parent)

    def user(self) -> str:
        """Generate a random user.

        :return: Path to user.

        :Example:
            /home/oretha
        """
        user = self.random.choice(USERNAMES)

# Generated at 2022-06-23 21:37:42.896612
# Unit test for constructor of class Path
def test_Path():
    if sys.platform == 'linux':
        path_linux = Path()
        assert str(path_linux.home()) == '/home'
        assert str(path_linux.root()) == '/'
        assert str(path_linux.user()) == '/home/priscilla'
        assert str(path_linux.project_dir()) == '/home/angelita/Python/django/results'
    elif sys.platform == 'win32':
        path_win = Path()
        assert str(path_win.home()) == 'C:\\Users'
        assert str(path_win.root()) == 'C:'
        assert str(path_win.user()) == 'C:\\Users\\tammera'
        assert str(path_win.project_dir()) == 'C:\\Users\\ryann\\Dev\\drupal\\bugfinder'

# Generated at 2022-06-23 21:37:46.173086
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    home = p.home()
    assert type(home) == str
    assert home[0] == '/'

# Generated at 2022-06-23 21:37:48.184586
# Unit test for method root of class Path
def test_Path_root():
    """Unit test method for "Path" class method "root"."""
    assert Path().root() == '/'


# Generated at 2022-06-23 21:37:52.817022
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    path.Meta.name
    assert path.platform == sys.platform
    assert path._pathlib_home.is_absolute() is True
    assert str(path._pathlib_home) == PLATFORMS[path.platform]['home']


# Generated at 2022-06-23 21:37:56.771587
# Unit test for constructor of class Path
def test_Path():
    path = Path()
    print(path.home())

    print(path.user())
    print(path.users_folder())
    print(path.dev_dir())
    print(path.project_dir())


if __name__ == '__main__':
    test_Path()

# Generated at 2022-06-23 21:38:01.072223
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Test for method dev_dir of class Path"""
    path = Path()
    dev_dir = path.dev_dir()
    assert dev_dir == "/home/lelia/dev/django"

# Generated at 2022-06-23 21:38:02.839889
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path = Path()
    print(path.project_dir())

# Generated at 2022-06-23 21:38:06.109454
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    array_Path_users_folder = ['Pictures', 'Музыка', 'Видео', 'Desktop']
    p = Path('linux')
    #print(p.users_folder())
    assert p.users_folder().split('/')[-1] in array_Path_users_folder


# Generated at 2022-06-23 21:38:09.763356
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    path = Path()
    print(path.dev_dir())
    # /home/stephania/Development/PHP



# Generated at 2022-06-23 21:38:13.010587
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    p = Path()
    assert p.dev_dir() == "/home/renya/Development/Python"
    assert p.project_dir() == "/home/renya/Development/Python/mimesis"


# Generated at 2022-06-23 21:38:22.994716
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import Gender
    from mimesis.enums import Gender
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import USASpecProvider

# Generated at 2022-06-23 21:38:26.641687
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    """Unit test for method dev_dir of class Path."""
    path = Path()
    assert isinstance(path.dev_dir(), str)
    assert path.dev_dir().startswith(path.home())


# Generated at 2022-06-23 21:38:27.573571
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home() == '/home'


# Generated at 2022-06-23 21:38:28.402818
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert p.Meta.name == "path"


# Generated at 2022-06-23 21:38:31.524147
# Unit test for method home of class Path
def test_Path_home():
    p = Path()
    assert p.home().startswith('/home/')\
        or p.home().startswith('/Users/')\
        or p.home().startswith('/')


# Generated at 2022-06-23 21:38:36.986405
# Unit test for method user of class Path
def test_Path_user():
    from mimesis.enums import SpecialChar

    path = Path(platform='linux')

    user = path.user()
    assert 'home' in user
    assert user.endswith(SpecialChar.SLASH.value)

    path = Path(platform='win32')
    user = path.user()
    assert 'Users' in user
    assert user.endswith(SpecialChar.SLASH.value)

# Generated at 2022-06-23 21:38:39.581249
# Unit test for method user of class Path
def test_Path_user():
    # unit test for method user of class Path
    path = Path(platform=sys.platform)
    assert path.user() == str(path._pathlib_home / 'pedro')

# Generated at 2022-06-23 21:38:41.731984
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    path1 = Path()
    s = path1.project_dir()
    assert 'Development' in s
    assert 'Python' in s


# Generated at 2022-06-23 21:38:42.984640
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:38:46.020488
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    assert len(path.users_folder()) > 0 and isinstance(path.users_folder(), str)


# Generated at 2022-06-23 21:38:47.976263
# Unit test for method home of class Path
def test_Path_home():
    assert Path().home() == '/home'


# Generated at 2022-06-23 21:38:49.357915
# Unit test for method root of class Path
def test_Path_root():
    _path = Path()

# Generated at 2022-06-23 21:38:50.707940
# Unit test for method user of class Path
def test_Path_user():
    assert Path().user() == '/home/domitila'

# Generated at 2022-06-23 21:38:55.121781
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    path_object = Path()
    path_value = path_object.dev_dir()
    print(path_value, type(path_value), sep='\n')


if __name__ == "__main__":
    test_Path_dev_dir()

# Generated at 2022-06-23 21:38:57.252219
# Unit test for method home of class Path
def test_Path_home():
    # Given
    path = Path()

    # When
    home = path.home()

    # Then
    assert home == '/home'


# Generated at 2022-06-23 21:39:00.259000
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    '''
    Ensure that generated value fits the pattern.
    '''
    assert re.match(r'(/home/.+/Dev.*/.+/.+)|(C:\.*\\.*)', Path().project_dir())


# Generated at 2022-06-23 21:39:03.556150
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    """Unit test for method project_dir of class Path."""
    from os.path import sep
    p = Path()
    assert sep in p.project_dir()

# Generated at 2022-06-23 21:39:06.710577
# Unit test for method project_dir of class Path
def test_Path_project_dir():
    test_path = Path()
    assert test_path.project_dir() == "/home/development/python/jupiter"
    assert type(test_path.project_dir()) == str



# Generated at 2022-06-23 21:39:08.364344
# Unit test for method home of class Path
def test_Path_home():
    path = Path('linux')
    print(path.home())


# Generated at 2022-06-23 21:39:09.210134
# Unit test for constructor of class Path
def test_Path():
    assert Path() is not None


# Generated at 2022-06-23 21:39:10.462503
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    x = Path('win32')
    y = x.dev_dir()
    print(y)

# Generated at 2022-06-23 21:39:13.085859
# Unit test for method user of class Path
def test_Path_user():
    p = Path()
    result = p.user()
    assert result == '/home/oretha'

# Generated at 2022-06-23 21:39:14.905060
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    for i in range(10):
        path.users_folder()

# Generated at 2022-06-23 21:39:15.989917
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    path = Path()
    path.users_folder()



# Generated at 2022-06-23 21:39:17.919839
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    for user in [path.user() for i in range(10)]:
        assert user.find('home') == 0
        assert user.find('/') == len('home')

# Generated at 2022-06-23 21:39:25.639076
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.directory.en import Directory

    provider = Path()
    dev_dir = provider.dev_dir()
    assert dev_dir

    # Testing extra arguments
    try:
        dev_dir = provider.dev_dir(5)
    except NonEnumerableError:
        pass

    # Testing with default pattern
    patterns = {'home': provider.home(),
                'dev': 'Development',
                'stack': provider.random.choice(PROGRAMMING_LANGS)}
    directory = Directory()
    path = directory.path(**patterns)
    assert path == dev_dir



# Generated at 2022-06-23 21:39:27.466328
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    print(path.user())


# Generated at 2022-06-23 21:39:29.425459
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    p = Path()
    print(p.users_folder())


# Generated at 2022-06-23 21:39:36.586266
# Unit test for method root of class Path
def test_Path_root():
    import sys
    from pathlib import PureWindowsPath
    from pathlib import PurePosixPath

    assert Path('linux').root() == str(PurePosixPath('/'))
    assert Path('darwin').root() == str(PurePosixPath('/'))
    assert Path('win32').root() == str(PureWindowsPath('\\'))
    assert Path('win64').root() == str(PureWindowsPath('\\'))
    assert Path('win32').root() == str(PureWindowsPath('\\'))
    assert Path('win64').root() == str(PureWindowsPath('\\'))


# Generated at 2022-06-23 21:39:37.909238
# Unit test for method user of class Path
def test_Path_user():
    p=Path('linux')
    assert(p.user()=='/home/genevieve')

# Generated at 2022-06-23 21:39:39.444050
# Unit test for method root of class Path
def test_Path_root():
    path = Path()
    assert path.root() in ['/', 'C:\\']


# Generated at 2022-06-23 21:39:43.177773
# Unit test for method home of class Path
def test_Path_home():
    from random import seed
    seed(1) # seed random number generator
    path = Path()
    for x in range(10):
    #    print(path.home())
        assert isinstance(path.home(), str) == True
        assert path.home() in ['/home', '/Users'] == True


# Generated at 2022-06-23 21:39:45.439717
# Unit test for method user of class Path
def test_Path_user():
    path = Path()
    user = path.user()
    assert isinstance(user, str)
    assert user[:5] == '/home' or user[1:6] == '\\home'

# Generated at 2022-06-23 21:39:46.540653
# Unit test for method user of class Path
def test_Path_user():
    assert Path('win32').user() == 'C:\\Users\\Raphael'

# Generated at 2022-06-23 21:39:48.954861
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    r = path.home()
    assert isinstance(r, str), "Return value should be a string"
    assert r[-5:] == r'/home', "Return value should be '/home' "


# Generated at 2022-06-23 21:39:50.675439
# Unit test for method home of class Path
def test_Path_home():
    path = Path()
    print(path.home())


# Generated at 2022-06-23 21:39:53.001396
# Unit test for method users_folder of class Path
def test_Path_users_folder():
    _path = Path()
    _folder = _path.users_folder()
    print(_folder)

# Generated at 2022-06-23 21:39:53.836029
# Unit test for constructor of class Path
def test_Path():
    p = Path()
    assert isinstance(p, Path)

# Generated at 2022-06-23 21:39:58.461110
# Unit test for method user of class Path
def test_Path_user():
    """Test the method user() of class Path.

    The method user() returns a path to the user's directory.
    """
    path = Path()
    path_to_usr = path.user()
    assert (path_to_usr[0] == '/' or path_to_usr[0] == 'c')

# Generated at 2022-06-23 21:40:00.400362
# Unit test for method user of class Path
def test_Path_user():
    print(Path('win32').user()) # /home/Myrtie


# Generated at 2022-06-23 21:40:02.196638
# Unit test for method root of class Path
def test_Path_root():
    p = Path()
    print (p.root())


# Generated at 2022-06-23 21:40:09.231367
# Unit test for method dev_dir of class Path
def test_Path_dev_dir():
    instance = Path()
    assert isinstance(instance.dev_dir(), str)
    assert isinstance(instance.dev_dir(), str)
    assert isinstance(instance.dev_dir(), str)
    assert isinstance(instance.dev_dir(), str)
    assert isinstance(instance.dev_dir(), str)
    assert isinstance(instance.dev_dir(), str)
    assert isinstance(instance.dev_dir(), str)


# Generated at 2022-06-23 21:40:10.679461
# Unit test for constructor of class Path

# Generated at 2022-06-23 21:40:19.905919
# Unit test for method user of class Path
def test_Path_user():
    path = Path('linux')