

# Generated at 2022-06-12 17:25:02.996227
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    if os.name == 'nt':
        return
    assert FourTubeIE() is not None


# Generated at 2022-06-12 17:25:05.075740
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:25:16.654673
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')

    webpage = PornTubeIE._download_webpage(url, display_id)

# Generated at 2022-06-12 17:25:19.950139
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE(PornerBrosIE._VALID_URL)
    
    assert isinstance(x, FourTubeBaseIE)
    assert isinstance(x, InfoExtractor)


# Generated at 2022-06-12 17:25:24.921498
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for code, ie in (
        ('4tube', FourTubeIE),
        ('fux', FuxIE),
        ('porntube', PornTubeIE),
        ('pornerbros', PornerBrosIE),
    ):
        ie()._build_url_result(code, code, code, 'video')

# Generated at 2022-06-12 17:25:27.159287
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print ('Testing FuxIE constructor')
    fux_ie = FuxIE()
    print ('FuxIE constructor executed successfully')

# Generated at 2022-06-12 17:25:28.677662
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

# Generated at 2022-06-12 17:25:36.678457
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    ie = PornerBrosIE()
    porner_bros = ie._real_extract(url)
    assert porner_bros['id'] == '181369'
    assert porner_bros['title'] == 'Skinny brunette takes big cock down her anal hole'
    assert porner_bros['uploader'] == 'PornerBros HD'
    assert porner_bros['uploader_id'] == 'pornerbros-hd'
    assert porner_bros['upload_date'] == '20130130'
    assert porner_bros['duration'] == 1224

# Generated at 2022-06-12 17:25:37.850916
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:25:38.599756
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    z = PornTubeIE()

# Generated at 2022-06-12 17:25:55.727314
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Create an object
    fuxObject=FuxIE();

    # Check if object is an instance of InfoExtractor
    print(isinstance(fuxObject,InfoExtractor));
    # Print the test cases
    print(fuxObject._TESTS);
    # Print the valid URL
    print(fuxObject._VALID_URL);

# test_FuxIE();

# Generated at 2022-06-12 17:25:58.967689
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert obj._download_webpage

# Generated at 2022-06-12 17:26:08.743521
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:26:10.173054
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import _test_fourtube
    _test_fourtube.test_FourTubeIE()



# Generated at 2022-06-12 17:26:16.882436
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    with open("tests/test.html") as file:
        data = file.read()
        ie = FourTubeIE("test.html", data)
        assert ie.config._TKN_HOST == "token.4tube.com"
        assert ie.config._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'



# Generated at 2022-06-12 17:26:17.480582
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:26:18.959560
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeIE = FourTubeBaseIE();
    assert(fourTubeIE.IE_NAME == "4tube")

# Generated at 2022-06-12 17:26:19.787967
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p is not None

# Generated at 2022-06-12 17:26:22.799570
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE()._TKN_HOST is not None)

# Generated at 2022-06-12 17:26:32.139918
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    # check for True
    assert re.compile(_VALID_URL).match('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    # check for False
    assert not re.compile(_VALID_URL).match('https://www.not-a-real-url.com/videos/video_7089759')

# Generated at 2022-06-12 17:26:59.769306
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369", {'skip_download': True})
    ie.extract("https://www.porntube.com/embed/181369")

# Generated at 2022-06-12 17:27:01.244340
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    x = FourTubeIE()
    assert isinstance(x, FourTubeIE)

# Generated at 2022-06-12 17:27:03.009355
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test is written, but can't be run.
    PornerBrosIE._download_webpage
    assert True is not False


# Generated at 2022-06-12 17:27:07.016994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    obj = FourTubeIE().match()(url)

# Generated at 2022-06-12 17:27:12.687619
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Use a short time out so that this test doesn't take too long to run
    import socket
    socket.setdefaulttimeout(5)

    url = 'http://www.4tube.com/videos/93843/hot-blonde-romina-loves-doggy-style-sex-in-her-first-anal-scene'
    info = FourTubeIE()._real_extract(url)
    assert info['id'] == '93843'
    assert info['title'] == 'Hot blonde Romina loves doggy style sex in her first anal scene'

# Generated at 2022-06-12 17:27:13.473913
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()

# Generated at 2022-06-12 17:27:25.886461
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-12 17:27:37.086168
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    m = FourTubeIE()
    assert m._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert m._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert m._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:27:44.769038
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    web_scraper = FourTubeIE()
    assert web_scraper.IE_NAME == "4tube"
    assert web_scraper._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert web_scraper._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert web_scraper._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-12 17:27:47.664736
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-12 17:29:00.054963
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE('abc', {})
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:29:07.699035
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE()
    assert info_extractor.IE_NAME == "4tube"
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert info_extractor._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert info_extractor._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:29:13.786519
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test = FourTubeIE()
    assert test._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:29:18.659511
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert ( PornerBrosIE(None)._VALID_URL ==
            r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    )

# Generated at 2022-06-12 17:29:21.595168
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    # check derived class is created, not base class
    assert isinstance(instance, FourTubeIE)


# Generated at 2022-06-12 17:29:23.989119
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE(FourTubeBaseIE)
    assert isinstance(ie, FourTubeBaseIE) and isinstance(ie, FuxIE)

# Generated at 2022-06-12 17:29:29.839623
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Check if PornTubeIE.constructor call initializes correctly
    porn_tube_ie = PornTubeIE('www.porntube.com')._VALID_URL
    assert porn_tube_ie == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)',\
        "PornTubeIE._VALID_URL not properly initialized"

# Generated at 2022-06-12 17:29:37.976790
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Test extraction of 4tube.com/videos/video_id url"""
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-12 17:29:44.385971
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pbie = PornerBrosIE()
    assert pbie._TKN_HOST == 'token.pornerbros.com'
    assert pbie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pbie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'


# Generated at 2022-06-12 17:29:44.983871
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    return FourTubeBaseIE

# Generated at 2022-06-12 17:31:17.946676
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-12 17:31:24.952345
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Constructor of class FourTubeIE should handle 4tube.com URLs
    try:
        FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    except Exception:
        # Exception indicates that FourTubeIE was unable to handle 4tube.com URL
        assert False
        return
    # If we are here, FourTubeIE was able to handle 4tube.com URL
    assert True



# Generated at 2022-06-12 17:31:25.691043
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()



# Generated at 2022-06-12 17:31:35.342113
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._download_webpage.__doc__ == 'Download a webpage.'
    assert obj._extract_formats.__doc__ == 'Extract formats from URL.'

# Generated at 2022-06-12 17:31:37.078484
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._TESTS[0]['info_dict']['timestamp'] == 1388361660

# Generated at 2022-06-12 17:31:43.593144
# Unit test for constructor of class FuxIE
def test_FuxIE():
    unit = FuxIE()
    assert unit._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert unit._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert unit._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:31:49.895165
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME == 'Fux'
    assert fux.URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux.VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux.TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:31:51.656799
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:31:53.007307
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:31:55.868421
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test constructor with valid input.
    test = FourTubeIE()
    # Test constructor with invalid input.
    if test:
        raise TypeError("FourTubeIE can only be used for extracting videos from websites.")
