

# Generated at 2022-06-12 17:25:05.309909
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    obj = {}
    obj.update(ie)
    assert obj['IE_NAME'] == '4tube'
    obj2 = {}
    obj2.update(ie)
    assert obj2['IE_NAME'] == '4tube'

# Generated at 2022-06-12 17:25:06.398868
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # should not raise exception
    FourTubeIE()

# Generated at 2022-06-12 17:25:18.023771
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Initialization of class FuxIE.
    """
    ie = FuxIE()
    test_url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    test_video_id = "195359"
    test_uploader = "alenci2342"
    test_uploader_id = "alenci2342"
    test_title = "Awesome fucking in the kitchen ends with cum swallow"
    test_categories = [u'Amateur', u'Blowjobs', u'Cumshots', u'Cum Swallowing', u'Ebony', u'HD']
    test_timestamp = 1388361660
    test_duration = 289
    test_view_count = int
    test_like_count = int

# Generated at 2022-06-12 17:25:22.798228
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.ie_key() == 'PornerBros'
    assert ie.ie_name() == 'PornerBros'
    assert not ie.working()


# Generated at 2022-06-12 17:25:32.950953
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Instantiation of class with params
    ie = PornTubeIE()

    # --- Testing _download_webpage method ---
    # This method download webpage and return
    # a string which is webpage source
    webpage = ie._download_webpage(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        '7089759')

    # Testing if method is returning a string
    assert isinstance(webpage, str)

    # --- Testing _parse_json method ---

# Generated at 2022-06-12 17:25:34.100301
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()._PORN_TUBE_TEST()

# Generated at 2022-06-12 17:25:39.332657
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    data = {"link": "link", "id": 1, "thumbnail": "thumbnail", "duration": 10}
    video = Video(data)
    assert video.video_id == data['id']
    assert video.thumbnail == data['thumbnail']
    assert video.duration == data['duration']

    assert video.stream_link == data['link']

# Generated at 2022-06-12 17:25:40.546115
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE is not None

# Generated at 2022-06-12 17:25:42.078893
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()

# Generated at 2022-06-12 17:25:43.637503
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-12 17:26:01.953989
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FourTubeIE()
    f.IE_NAME = 'Fux'
    f.ie_key = 'Fux'
    return f

# Generated at 2022-06-12 17:26:03.199977
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = FuxIE()
    assert IE.IE_NAME == '4tube'

# Generated at 2022-06-12 17:26:04.069890
# Unit test for constructor of class FuxIE
def test_FuxIE():
    t = FuxIE()

# Generated at 2022-06-12 17:26:12.659293
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    data = {
        'url': 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'info_dict': {
            'id': '7089759',
            'ext': 'mp4',
            'title': 'Teen couple doing anal',
            'uploader': 'Alexy',
            'uploader_id': '91488',
            'upload_date': '20150606',
            'timestamp': 1433595647,
            'duration': 5052,
            'view_count': int,
            'like_count': int,
            'age_limit': 18,
        },
        'params': {
            'skip_download': True,
        },
    }

# Generated at 2022-06-12 17:26:13.109402
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-12 17:26:15.935713
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()

    assert(str(i) == '<__main__.FourTubeBaseIE object at 0x7f1f4a4a7d30>')


# Generated at 2022-06-12 17:26:18.161340
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert 'PornerBrosIE' in globals()
    ie_obj = PornerBrosIE()
    assert isinstance(ie_obj, PornerBrosIE)

# Generated at 2022-06-12 17:26:23.976962
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    initializer = PornTubeIE(url='https://www.porntube.com/embed/7089759')
    assert initializer.IE_NAME == 'PornTube'
    assert initializer._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert initializer._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert initializer._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:26:25.667021
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert isinstance(PornerBrosIE, type(PornTubeIE))

# Generated at 2022-06-12 17:26:27.027892
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-12 17:26:58.617492
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:27:03.572361
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, FourTubeBaseIE)
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-12 17:27:04.917043
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:27:09.073361
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE()
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-12 17:27:14.576895
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie.suitable('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black') == False
    assert ie.suitable('https://www.4tube.com/embed/209733') == False
    assert ie.suitable('https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black') == False

# Generated at 2022-06-12 17:27:15.782906
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    a=FourTubeIE()
    print(a)

test_FourTubeIE()

# Generated at 2022-06-12 17:27:17.179097
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    object = FourTubeBaseIE()
    assert object._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-12 17:27:27.411132
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p._match_id(PornTubeIE._VALID_URL)
    assert p._match_id(PornTubeIE._URL_TEMPLATE)
    assert p._match_id('https://m.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert p._match_id('https://www.porntube.com/embed/181369')

# Generated at 2022-06-12 17:27:29.480106
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._URL_TEMPLATE is None
    assert ie._TKN_HOST is None

# Generated at 2022-06-12 17:27:30.907711
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._extract_formats

# Generated at 2022-06-12 17:28:47.160600
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert ie.IE_NAME == '4tube'



# Generated at 2022-06-12 17:28:48.945353
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:28:50.683426
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    # TODO: Test more assertions
    assert ie.IE_NAME == '4tube:pornerbros'

# Generated at 2022-06-12 17:29:00.307733
# Unit test for constructor of class FuxIE
def test_FuxIE():
    info_extractor = FuxIE()
    assert info_extractor.ie_key() == 'Fux'
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert info_extractor._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert info_extractor._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:29:02.735354
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Init
    obj = PornerBrosIE()

    # Check class
    assert obj.__class__.__name__ == "PornerBrosIE"

# Generated at 2022-06-12 17:29:04.257439
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # test constructor
    assert issubclass(FourTubeIE, InfoExtractor)



# Generated at 2022-06-12 17:29:12.655840
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # A sample to verify if the constructor of PornTubeIE is working.
    print("######## Check if constructor of class PornTubeIE is working")
    print("######## If the following info is printed, means the constructor is working!")
    print("######## ========")
    ie = PornTubeIE()
    print("######## ========")
    assert(ie != None)
    # If the following info is printed, means the constructor is working!
    # ========
    # <class '__main__.PornTubeIE'>
    # <class '__main__.PornTubeIE'>
    # ========


# Generated at 2022-06-12 17:29:16.585217
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    FourTubeBaseIE(url)

# Generated at 2022-06-12 17:29:17.539485
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass


# Generated at 2022-06-12 17:29:25.652730
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-12 17:32:28.417791
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    # TODO: modify this after you create your own ie
    ie = FourTubeIE("FourTubeIE");
    assert ie is not None
    pass

# Generated at 2022-06-12 17:32:31.045912
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for name in ['4Tube', 'Fux', 'PornTube', 'PornerBros']:
        exec("class Test" + name + "IE(unittest.TestCase):\n    def test_" + name + "_ie(self):\n        " + name + "IE()")
        locals()["Test" + name + "IE"]()

# Generated at 2022-06-12 17:32:33.725068
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE.IE_NAME == 'PornerBros'

# Generated at 2022-06-12 17:32:34.887476
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    assert obj.IE_NAME == '4tube'

# Generated at 2022-06-12 17:32:35.979283
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert(FuxIE() != None)


# Generated at 2022-06-12 17:32:37.085302
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Test unit for class FuxIE
    """
    pass


# Generated at 2022-06-12 17:32:37.858138
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()
    FuxIE()

# Generated at 2022-06-12 17:32:43.989833
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import requests
    from requests.auth import HTTPDigestAuth
    x = FourTubeIE()
    print(x._download_json('https://token.4tube.com/705957/desktop/480+720+1080', 'test',
                           data=b'', headers={'Origin': 'https://www.4tube.com',
                                              'Referer': 'https://www.4tube.com/videos/705957/big-ass-brazilian-escort'}))
    # print(x._download_json('https://m.4tube.com/m-token/705957/desktop/480+720+1080', 'test',
    #                        data=b''))

# Generated at 2022-06-12 17:32:47.091599
# Unit test for constructor of class FuxIE
def test_FuxIE():
    val = FuxIE(FuxIE._download_webpage, "[{'key': 'test'}]")
    assert val is not None

# Generated at 2022-06-12 17:32:47.821722
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()