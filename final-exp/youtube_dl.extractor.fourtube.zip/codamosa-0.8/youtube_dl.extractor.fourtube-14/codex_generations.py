

# Generated at 2022-06-12 17:25:02.904696
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie_FourTubeIE = FourTubeIE()
    assert ie_FourTubeIE.IE_NAME == '4tube'

# Generated at 2022-06-12 17:25:07.781190
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.ie_key() == 'PornerBros'

    # Unit test for constructor of class FourTubeBaseIE
    ie_fourtube = FourTubeBaseIE()
    assert ie_fourtube.ie_key() == 'FourTube'



# Generated at 2022-06-12 17:25:19.211532
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:25:22.129825
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    # the following line should not raise any exception
    print(ie)

# Generated at 2022-06-12 17:25:23.309959
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:25:24.878681
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-12 17:25:34.502860
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-12 17:25:40.166704
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')
    assert ie._TKN_HOST == 'token.4tube.com'

    ie = FourTubeBaseIE('Fux')
    assert ie._TKN_HOST == 'token.fux.com'

    ie = FourTubeBaseIE('PornTube')
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:25:43.175096
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE(): 
    ie = FourTubeIE()
    ie._extract_formats(url, video_id, media_id, sources)

# Generated at 2022-06-12 17:25:44.865357
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _PornTubeIE = PornTubeIE()


# Generated at 2022-06-12 17:26:01.507833
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:26:02.491044
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    print(obj)

# Generated at 2022-06-12 17:26:03.098763
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:26:06.714641
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:26:12.915174
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    constructor = FourTubeIE
    assert constructor.__name__ == "FourTubeIE"
    assert constructor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert constructor._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert constructor._TKN_HOST == 'token.4tube.com'
    assert constructor.IE_NAME == "4tube"

# Generated at 2022-06-12 17:26:14.601480
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    print("PornTubeIE")
    objIE = PornTubeIE()
    objIE.print_info()

# Generated at 2022-06-12 17:26:15.974806
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    module = PornerBrosIE()
    assert module.IE_NAME == '4tube'

# Generated at 2022-06-12 17:26:22.745893
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test case for videos with channel
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    ie = PornTubeIE(PornTubeIE._downloader)
    info = ie._real_extract(url)
    assert info['uploader'] == 'Exploited College Girls'
    assert info['uploader_id'] == '665'
    assert info['channel'] == 'Exploited College Girls'
    assert info['channel_id'] == '665'
    # Test case for videos without channel
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    ie = PornTubeIE(PornTubeIE._downloader)
    info = ie._real_extract(url)
   

# Generated at 2022-06-12 17:26:26.910730
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        assert PornTubeIE()
    except:
        assert False, "Failed: Cannot create PornTubeIE object"
    else:
        assert True, "Success: PornTubeIE object created"


# Generated at 2022-06-12 17:26:27.522277
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-12 17:26:57.116116
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    print(i)

# Generated at 2022-06-12 17:27:05.573037
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    fuxIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    fuxIE._URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    fuxIE._TKN_HOST = 'token.fux.com'
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux

# Generated at 2022-06-12 17:27:06.888039
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)

# Generated at 2022-06-12 17:27:14.778979
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    class MyTestCase(unittest.TestCase):
        def test_constructor(self):
            ie = PornerBrosIE()
            self.assertEqual(ie._VALID_URL,
                             r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
            self.assertEqual(ie._URL_TEMPLATE,
                             'https://www.pornerbros.com/videos/video_%s')
            self.assertEqual(ie._TKN_HOST,
                             'token.pornerbros.com')

# Generated at 2022-06-12 17:27:26.256081
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Constructor of class FourTubeIE shouldn't raise an exception
    FourTubeIE(FourTubeIE.IE_NAME, FourTubeIE.IE_DESC)
    # Constructor of class FuxIE shouldn't raise an exception
    FuxIE(FuxIE.IE_NAME, FuxIE.IE_DESC)
    # Constructor of class PornTubeIE shouldn't raise an exception
    PornTubeIE(PornTubeIE.IE_NAME, PornTubeIE.IE_DESC)
    # Constructor of class PornerBrosIE shouldn't raise an exception
    PornerBrosIE(PornerBrosIE.IE_NAME, PornerBrosIE.IE_DESC)


# Generated at 2022-06-12 17:27:27.268954
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:27:28.254799
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert isinstance(FourTubeBaseIE, type)

# Generated at 2022-06-12 17:27:30.013953
# Unit test for constructor of class FuxIE
def test_FuxIE():
    inst = FuxIE()
    assert hasattr(inst, '_TKN_HOST')

# Generated at 2022-06-12 17:27:30.997677
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	FourTubeIE(FourTubeIE.ie_key())

# Generated at 2022-06-12 17:27:39.421088
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE()
    assert instance.IE_NAME == '4tube'
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert instance._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert instance._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:28:51.152004
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    obj = PornerBrosIE()
    assert isinstance(obj, PornerBrosIE)


# Generated at 2022-06-12 17:28:51.899704
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-12 17:28:54.388100
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    f = FourTubeBaseIE(url)
    assert f._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:28:56.830852
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie is not None

# Generated at 2022-06-12 17:29:05.494252
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[1]['url'] == url

# Generated at 2022-06-12 17:29:07.200613
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert issubclass(PornerBrosIE, InfoExtractor)



# Generated at 2022-06-12 17:29:12.681374
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert instance.name == 'PornTube'
    assert instance._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert instance._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'

# Generated at 2022-06-12 17:29:20.407758
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    '''
    In this test the only relevant is to test that the constructors does not fail.
    The rest of the tests are in the derivative classes.
    '''
    # When
    FourTubeIE()
    PornTubeIE()
    FuxIE()
    PornerBrosIE()

    # Then
    assert FourTubeIE()._TESTS
    assert PornTubeIE()._TESTS
    assert FuxIE()._TESTS
    assert PornerBrosIE()._TESTS

# Generated at 2022-06-12 17:29:22.684007
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert str(FuxIE) == '<class \'youtube_dl.extractor.fux.FuxIE\'>'

# Generated at 2022-06-12 17:29:31.651337
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Unit test for class FourTubeBaseIE
    s = FourTubeBaseIE()
    v_id = '209733' # id for dummy video /videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black
    m_id = '484870' # determined media id by js
    s_list = ['720', '480', '240'] # list of sources, determined by js
    v_url = 'https://www.4tube.com/videos/{}/video'.format(v_id)
    t_url = 'https://token.4tube.com/{}/desktop/{}'.format(m_id, '+'.join(s_list))

# Generated at 2022-06-12 17:32:24.164247
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("FourTubeBaseIE")
    if isinstance(ie, InfoExtractor):
        test_FourTubeBaseIE.passed = True
    else:
        test_FourTubeBaseIE.passed = False


# Generated at 2022-06-12 17:32:25.003742
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    yt = PornTubeIE()
    assert isinstance(yt, PornTubeIE)

# Generated at 2022-06-12 17:32:30.601175
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    token_url = ie._extract_formats('https://www.porntube.com/videos/teen-couple-doing-anal_7089759', '7089759', '336443', ['1080', '720', '480', '360', '240'])

# Generated at 2022-06-12 17:32:35.691269
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeIE()._real_extract('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    FuxIE()._real_extract('https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow')
    PornTubeIE()._real_extract('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    PornerBrosIE()._real_extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:32:40.748717
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    # Check only main properties
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:32:45.867100
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeIE = FourTubeBaseIE('FourTubeIE')
    fourTubeIE = FourTubeBaseIE('FuxIE')
    fourTubeIE = FourTubeBaseIE('PornTubeIE')
    fourTubeIE = FourTubeBaseIE('PornerBrosIE')
    fourTubeIE = FourTubeBaseIE('FourTubeIE', 'FourTubeBaseIE')
    FourTubeIE('FuxIE', 'FourTubeBaseIE')
    FourTubeIE('PornTubeIE', 'FourTubeBaseIE')
    FourTubeIE('PornerBrosIE', 'FourTubeBaseIE')

# Generated at 2022-06-12 17:32:48.311380
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    IE = FourTubeBaseIE()
    assert IE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:32:50.022160
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-12 17:32:50.505151
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:32:53.856650
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = "https://www.fux.com/videos/squirting-teen-ballerina-ecg_1331406"
    fux_ie = FuxIE(url)
    print(fux_ie.extract())
    