

# Generated at 2022-06-12 17:25:08.641158
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None, None)
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-12 17:25:13.862792
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    #pylint: disable=no-member
    ie = PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert ie.__class__.__name__ == PornerBrosIE.__name__

# Generated at 2022-06-12 17:25:25.219794
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:25:26.799852
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert(x.IE_NAME == 'PornTube')

# Generated at 2022-06-12 17:25:33.207628
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE._VALID_URL = re.compile(r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
    PornerBrosIE._URL_TEMPLATE = '%s'
    PornerBrosIE._TKN_HOST = 'token.pornerbros.com'
    PornerBrosIE()



# Generated at 2022-06-12 17:25:37.542157
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:25:38.945003
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE(), FuxIE)


# Generated at 2022-06-12 17:25:40.546899
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-12 17:25:48.659888
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(FourTubeIE._downloader)._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE(FuxIE._downloader)._TKN_HOST == 'token.fux.com'
    assert FourTubeBaseIE(PornerBrosIE._downloader)._TKN_HOST == 'token.pornerbros.com'
    assert FourTubeBaseIE(PornTubeIE._downloader)._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:25:50.956455
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Create an instance of class FourtubeBaseIE
    instance = FourTubeBaseIE()

    # Verify that the constructor did not fail
    assert(instance is not None)

# Generated at 2022-06-12 17:26:11.882144
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .fourtube import FourTubeBaseIE

    test_class = FourTubeBaseIE

    class TestIE(test_class):
        IE_NAME = 'FourTubeBaseIE'
        _VALID_URL = ''
        _URL_TEMPLATE = ''
        _TKN_HOST = ''

    ie = TestIE('TestFourTubeBaseIE')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_URL_TEMPLATE')
    assert hasattr(ie, '_TKN_HOST')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_search_regex')

# Generated at 2022-06-12 17:26:14.848957
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	assert FourTubeIE('test', 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', '209733') == 1

# Generated at 2022-06-12 17:26:16.283840
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():  # noqa: F811
    PornTubeIE('porntube')



# Generated at 2022-06-12 17:26:17.742110
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
        assert True
    except:
        assert False

# Generated at 2022-06-12 17:26:18.615803
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj

# Generated at 2022-06-12 17:26:23.810290
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._VALID_URL.match('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert FourTubeIE()._VALID_URL.match('https://www.4tube.com/embed/209733')
    assert FourTubeIE()._VALID_URL.match('http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-12 17:26:24.676487
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:26:26.909904
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # as long as this class is not initialized, nothing happens
    assert FourTubeBaseIE is not None


# Generated at 2022-06-12 17:26:28.285842
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-12 17:26:28.924980
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()

# Generated at 2022-06-12 17:27:11.395944
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from ..compat import compat_urllib_parse_urlparse
    i = InfoExtractor({'IE_NAME': 'FourTubeBaseIE', '_VALID_URL': r'a.*b'})
    assert isinstance(i, FourTubeBaseIE)

    class MyIE(FourTubeBaseIE):
        _TEST = {
            'url': 'http://foo/x/y/z',
            'info_dict': {'id': 'z'}
        }
        _VALID_URL = r'(?P<base>http://foo)(?P<p1>/x)(?P<p2>/y)(?P<id>/z)'

    i = MyIE({'IE_NAME': 'MyIE'})
    assert isinstance(i, FourTubeBaseIE)

# Generated at 2022-06-12 17:27:12.757121
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    new_fourtubeie = FourTubeIE()
    assert new_fourtubeie != None


# Generated at 2022-06-12 17:27:23.221894
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie.IE_NAME == '4tube'
    assert ie.VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie.URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie.TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:27:26.639396
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    assert isinstance(obj._TKN_HOST, compat_str)



# Generated at 2022-06-12 17:27:27.642152
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    return PornerBrosIE()._TKN_HOST

# Generated at 2022-06-12 17:27:29.740145
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from . import FuxIE
    assert FuxIE(FuxIE.ie_key())._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:27:41.230327
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import xml.etree.ElementTree as ET
    import unittest

    class MockResponse():
        def __init__(self, url, content, headers):
            self.url = url
            self.content = content
            self.headers = headers

        def geturl(self):
            return self.url
        
        def read(self):
            return self.content
        
        # Just need the below two methods in the mapping
        # of Responds.getheader(...) to Responds.headers[<key>]
        # A little bit weird if use a dict
        # Just for mocking the getheader(...) method
        def getheader(self, key, default=None):
            return self.headers[key]

        def getheaders(self):
            return self.headers


# Generated at 2022-06-12 17:27:44.020360
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor

    class FourTubeBaseIE(InfoExtractor):

        _VALID_URL = r'your_regex_here'
        _URL_TEMPLATE = 'http://url_template.com/%s/video'
        _TKN_HOST = 'token.host.com'

    return FourTubeBaseIE

# Generated at 2022-06-12 17:27:53.436883
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-12 17:28:01.241232
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:29:16.911274
# Unit test for constructor of class FuxIE
def test_FuxIE():
    s = 'https://www.fux.com'
    a = FuxIE(s)
    assert a == s


# Generated at 2022-06-12 17:29:18.347577
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()
    assert inst is not None

# Generated at 2022-06-12 17:29:19.370492
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()
    return

# Generated at 2022-06-12 17:29:23.289649
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # This test is not intended to be used to test this class
    # The purpose of this test is to make sure to create a class instance
    # that otherwise can't be instantiated due to its missing library dependency
    FuxIE()

# Generated at 2022-06-12 17:29:30.195802
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_name = 'PornerBrosIE'
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    _URL_TEMPLATE = 'https://www.pornerbros.com/videos/video_%s'
    _TKN_HOST = 'token.pornerbros.com'
    return class_name, _VALID_URL, _URL_TEMPLATE, _TKN_HOST

# Generated at 2022-06-12 17:29:32.391416
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test if fourtube.py can be loaded
    assert 'FourTubeIE' in globals()


# Generated at 2022-06-12 17:29:34.562625
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import requests
    try:
        obj = PornTubeIE()
    except requests.exceptions.MissingSchema:
        pass
        # print('Invalid url')


# Generated at 2022-06-12 17:29:35.376828
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-12 17:29:41.182718
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_object = FourTubeIE()
    assert test_object.ie_key() == "4tube"
    assert test_object.ie_name() == "4tube"
    assert test_object._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test_object._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test_object._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:29:42.684755
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
# end of test

# Generated at 2022-06-12 17:32:54.551936
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE is not None
    return PornTubeIE


# Generated at 2022-06-12 17:33:01.440450
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from youtube_dl.downloader.common import FileDownloader
    import os.path
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Retrieve test video and metadata
    params = {'outtmpl': os.path.join(temp_dir, "%(id)s.%(ext)s")}
    fd = FileDownloader({'logger': test_FourTubeIE.__name__}, params)
    result = fd.download([test_FourTubeIE.__name__])
    assert result == 0, "Could not download video file"

    # Clean up
    import shutil
    shutil.rmtree(temp_dir)

# Generated at 2022-06-12 17:33:09.769160
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    class_ = globals()['FourTubeIE']
    class_(4)._download_webpage('a', 'b')
    class_(4)._extract_formats('a', 'b', 'c', 'd')
    class_(4)._real_extract('a')
    class_(4)._parse_json('a', 'b')
    class_(4)._search_regex('a', 'b', 'c')
    class_(4)._html_search_regex('a', 'b', 'c')
    class_(4)._html_search_meta('a', 'b')

# Generated at 2022-06-12 17:33:13.302004
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-12 17:33:16.409582
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, PornerBrosIE)
    assert isinstance(ie, FourTubeBaseIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:33:20.872779
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:33:23.180518
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    title = instance._html_search_meta('name', "test")
    assert(title == None)

# Generated at 2022-06-12 17:33:24.492671
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:33:36.273252
# Unit test for constructor of class FuxIE
def test_FuxIE():
    channels_url = 'https://www.fux.com/channels'
    channels_page_html = '''
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<div><a href="https://www.fux.com/channel/5/hot-moms-teach-sex">Hot Moms Teach Sex</a></div>
</body>
</html>
'''
    channels_page = compat_str(channels_page_html)


# Generated at 2022-06-12 17:33:36.991768
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    constructor = PornTubeIE()