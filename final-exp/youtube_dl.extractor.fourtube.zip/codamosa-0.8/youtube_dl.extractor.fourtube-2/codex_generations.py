

# Generated at 2022-06-12 17:25:02.626762
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'FuxIE'


# Generated at 2022-06-12 17:25:09.968074
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # test that the base object is constructed
    fourTubeBaseIE = FourTubeBaseIE()
    # check that the base object has the wanted fields
    assert('_TKN_HOST' in dir(fourTubeBaseIE))
    assert('_VALID_URL' in dir(fourTubeBaseIE))
    assert('_URL_TEMPLATE' in dir(fourTubeBaseIE))
    assert('_TESTS' in dir(fourTubeBaseIE))


# Generated at 2022-06-12 17:25:11.151729
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:25:14.885365
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    _TEST = {
        'url': 'https://www.pornerbros.com/embed/181369',
        'only_matching': True,
    }
    PornerBrosIE()._real_extract(_TEST['url'])

# Generated at 2022-06-12 17:25:25.902484
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-12 17:25:35.314688
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print("Testing FuxIE")
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    assert(FuxIE._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?")

# Generated at 2022-06-12 17:25:41.579520
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import extractor
    from .constructor import IE_DESC

    for ie in IE_DESC:
        if ie['id'] in ('4tube', 'fux', 'porntube', 'pornerbros'):
            ie['class']._download_webpage = lambda self, url: url
            info_extractor = extractor.gen_extractor(ie)
            assert hasattr(info_extractor, '_TKN_HOST')

# Generated at 2022-06-12 17:25:45.358857
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Not raise ValueError with nonexistent URL
    assert FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow') is not None

# Generated at 2022-06-12 17:25:46.737974
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE(FuxIE._VALID_URL)

# Generated at 2022-06-12 17:25:47.424805
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:26:03.278763
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-12 17:26:11.752860
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube', 'https://www.4tube.com/embed/181369', '181369')
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

    ie = FuxIE('Fux', 'https://www.fux.com/embed/181369', '181369')
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

    ie = PornTubeIE('PornTube', 'https://www.porntube.com/embed/181369', '181369')
    assert ie._

# Generated at 2022-06-12 17:26:13.045043
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_PornerBrosIE = PornerBrosIE()

# Generated at 2022-06-12 17:26:14.366617
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE(), FuxIE)


# Generated at 2022-06-12 17:26:16.527559
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Pass
    assert FourTubeIE() is not None
    # Fail
    assert FourTubeIE(example_url="None") is None

# Generated at 2022-06-12 17:26:29.243841
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE=='https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:26:30.219369
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-12 17:26:31.612818
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        assert PornerBrosIE()
    except TypeError:
        assert False

# Generated at 2022-06-12 17:26:33.164358
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Instantiate an instance of class PornTubeIE
    PornTubeIE()

# Generated at 2022-06-12 17:26:36.724509
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance.IE_NAME == 'pornerbros'
    assert instance._TKN_HOST == 'token.pornerbros.com'
    assert instance._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-12 17:27:10.358141
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # create object of class FourTubeBaseIE
    obj = FourTubeBaseIE()
    # function _download_webpage
    # pass url and video id to download webpage
    webpage = obj._download_webpage(
        'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
        'a')

    # function _search_regex
    # pass pattern and webpage to search and return result
    result = obj._search_regex(
        r'<meta[^>]+itemprop="interactionCount"[^>]+content="UserPlays:([0-9,]+)">',
        webpage, 'view count', default=None)

    # function _html_search_regex
    # pass pattern and webpage to search and

# Generated at 2022-06-12 17:27:18.002804
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import you_get
    import json
    import re

    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    _, info = you_get.extractors.porntube(url)
    print(json.dumps(info))
    data = info['data']['page']['video']
    assert data['id'] == '7089759'
    assert data['title'] == 'Teen couple doing anal'
    assert data['uploader'] == 'Alexy'
    assert data['uploader_id'] == '91488'
    assert data['upload_date'] == '20150606'
    assert data['timestamp'] == 1433595647
    assert data['duration'] == 5052

# Generated at 2022-06-12 17:27:21.752812
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert(instance._TESTS == [])


# Generated at 2022-06-12 17:27:33.934721
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    Simple test case to check if PornTubeIE works. This test case is not that
    important but it's always useful to have it.
    """
    import inspect
    from urllib.request import urlopen
    from urllib.error import HTTPError

    class TestPornTubeIE(PornTubeIE):
        _test_url = 'https://www.porntube.com/videos/beautiful-sex-of-a-couple-on-bed_7089760'

        def _real_extract(self, url):
            real_extract = inspect.getargspec(super(TestPornTubeIE, self)._real_extract)

# Generated at 2022-06-12 17:27:40.344861
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    downloader = PornerBrosIE()
    assert downloader._match_id(url) == ('181369', 'skinny-brunette-takes-big-cock-down-her-anal-hole')

# Generated at 2022-06-12 17:27:46.347986
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    input_URL = "https://www.4tube.com/videos/273710/teen-gets-fucked-for-the-first-time"
    # Expected value for instance of class
    output_class = FourTubeBaseIE
    # Expected value for return of function _real_extract
    output_real_extract = {'title': 'Teen gets fucked for the first time',
                           'id': '273710'}
    # Expected value for return of function _extract_formats

# Generated at 2022-06-12 17:27:53.652783
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    ie = PornTubeIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert re.match(ie._VALID_URL, url)



# Generated at 2022-06-12 17:27:54.803778
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TESTS[0] == FourTubeIE._TESTS[0]

# Generated at 2022-06-12 17:27:58.372450
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Arrange
    fux_ie = FuxIE('input_url')

    # Act
    fux_ie.ie_name

    # Assert
    assert fux_ie.ie_name == '4tube'

# Generated at 2022-06-12 17:28:08.920485
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Tests with valid urls
    test_video_valid1 = FuxIE.test_info_dict('''http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow''')
    assert(test_video_valid1['age_limit'] == 18)
    assert(test_video_valid1['categories'] != [])
    assert(test_video_valid1['duration'] == 289)
    assert(test_video_valid1['ext'] == 'mp4')
    assert(test_video_valid1['id'] == '195359')
    assert(test_video_valid1['like_count'] == test_video_valid1['like_count'])
    assert(test_video_valid1['timestamp'] == 1388361660)

# Generated at 2022-06-12 17:29:21.547358
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE("https://www.porntube.com/embed/7089759")



# Generated at 2022-06-12 17:29:22.778669
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(FourTubeBaseIE)

# Generated at 2022-06-12 17:29:23.808294
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    return PornerBrosIE()

# Generated at 2022-06-12 17:29:32.469816
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test import get_testdata_directory
    from .common import InfoExtractor

    def _build_request(*args, **kwargs):
        return {
            'path': args[5],
            'method': args[6],
            'headers': args[7],
            'data': args[8]
        }

    pt = PornTubeIE(None)
    pt._download_webpage = lambda *args, **kwargs: open(
        get_testdata_directory() + '/porntube.html').read()
    pt._download_json = _build_request
    assert pt._downloader.urlopen == InfoExtractor._download_webpage

    res = pt._real_extract('https://www.porntube.com/embed/7089759')
    assert res['id'] == '7089759'

# Generated at 2022-06-12 17:29:33.735078
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-12 17:29:34.614738
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE();


# Generated at 2022-06-12 17:29:35.408272
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()



# Generated at 2022-06-12 17:29:42.099207
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    new_ie = PornTubeIE()
    assert hasattr(new_ie, '_TESTS')

# Generated at 2022-06-12 17:29:48.912877
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test unicode input
    # assert(FourTubeBaseIE('FourTubeBaseIE')._VALID_URL == 'https?://(?:www\.)?4tube\.com/videos/\d+')
    assert(FourTubeBaseIE('FourTubeBaseIE')._VALID_URL == 'https?://(?:www\.|m\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(FourTubeBaseIE('FourTubeBaseIE')._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(FourTubeBaseIE('FourTubeBaseIE')._TKN_HOST == 'token.4tube.com')

    # Test str input
    # assert(Four

# Generated at 2022-06-12 17:29:52.141442
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    t = FourTubeBaseIE('m.fourtube.com', 'm', 'm')
    assert t.IE_NAME == '4tube'
    assert t._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:33:06.219452
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-12 17:33:09.020768
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:33:12.808885
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-12 17:33:16.156704
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('http://www.pornerbros.com/videos/hottest-celebrity-jennifer-aniston-nude-sex-videos_173742')
    assert ie is not None

# Generated at 2022-06-12 17:33:23.029409
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-12 17:33:23.764105
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE()
    assert inst

# Generated at 2022-06-12 17:33:24.775575
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert len(FourTubeBaseIE()._TESTS) > 0

# Generated at 2022-06-12 17:33:26.132925
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    object = PornerBrosIE()

# Generated at 2022-06-12 17:33:31.175182
# Unit test for constructor of class FuxIE
def test_FuxIE():
	u = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
	assert u.IE_NAME == '4tube'

# Generated at 2022-06-12 17:33:32.355834
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()