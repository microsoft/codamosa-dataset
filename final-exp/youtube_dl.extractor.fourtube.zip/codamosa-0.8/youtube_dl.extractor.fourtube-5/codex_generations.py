

# Generated at 2022-06-12 17:25:04.164329
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base_class = FourTubeBaseIE()
    assert base_class._URL_TEMPLATE is None
    assert base_class._TKN_HOST is None
    assert base_class._VALID_URL is None

# Generated at 2022-06-12 17:25:06.203587
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    instance._parse_json('{"moo":"moo"}', 'bla')

# Generated at 2022-06-12 17:25:07.453673
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)

# Generated at 2022-06-12 17:25:08.218094
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-12 17:25:17.497948
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE(Downloader)
    # assert fuxIE.name == '4tube'
    assert fuxIE._TKN_HOST == 'token.fux.com'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-12 17:25:19.803088
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE() 
    assert fuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:25:20.792237
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:25:22.657579
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    repr(FourTubeIE())

# Generated at 2022-06-12 17:25:32.878889
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'http://m.fux.com/video/251261'
    video_id = '251261'
    mobj = re.match(FuxIE._VALID_URL, url)
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') is None
    assert mobj.group('kind') == 'm'

    assert FuxIE._URL_TEMPLATE % video_id == 'https://www.fux.com/video/%s/video' % video_id
    assert FuxIE._TKN_HOST == 'token.fux.com'

    # Test 4tube constructor

# Generated at 2022-06-12 17:25:39.243862
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert re.match(FourTubeIE._VALID_URL, 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert re.match(FourTubeIE._VALID_URL, 'https://www.4tube.com/embed/209733')
    assert re.match(FourTubeIE._VALID_URL, 'https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert re.match(FourTubeIE._VALID_URL, 'https://m.4tube.com/embed/209733')

# Generated at 2022-06-12 17:26:07.149507
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
     private_constructor = FourTubeBaseIE._TEST

# Generated at 2022-06-12 17:26:07.999918
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE("FourTubeBaseIE")

# Generated at 2022-06-12 17:26:09.870033
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE('PornerBrosIE', 'http://www.pornerbros.com/')
    assert instance.IE_NAME == 'PornerBrosIE'

# Generated at 2022-06-12 17:26:19.109321
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    # Functionality of _extract_formats is tested with the test video
    # URL above, so do not test here.
    test = PornerBrosIE(unittest.TestCase())
    test.assertEqual(test._VALID_URL,
                     r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')

# Generated at 2022-06-12 17:26:20.213937
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_ie = PornerBrosIE()

# Generated at 2022-06-12 17:26:22.038083
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:26:27.106450
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    infoextractor_unit_test(FourTubeBaseIE, [])
    infoextractor_unit_test(FuxIE, [])
    infoextractor_unit_test(PornTubeIE, [])
    infoextractor_unit_test(PornerBrosIE, [])

# Generated at 2022-06-12 17:26:30.611283
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x._TKN_HOST == 'tkn.porntube.com'
    assert x._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-12 17:26:31.973825
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert isinstance(instance, FourTubeIE)

# Generated at 2022-06-12 17:26:38.061781
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE._downloader, PornerBrosIE._VALID_URL)
    PornerBrosIE(PornerBrosIE._downloader, PornerBrosIE._VALID_URL, PornerBrosIE._TKN_HOST)
    PornerBrosIE(PornerBrosIE._downloader, PornerBrosIE._VALID_URL, PornerBrosIE._URL_TEMPLATE)

# Generated at 2022-06-12 17:27:40.325568
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert isinstance(instance, PornerBrosIE)
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert instance._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-12 17:27:42.057193
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class FuxFaker(FuxIE):
        pass
    fux_ie = FuxFaker()
    assert fux_ie is not None

# Generated at 2022-06-12 17:27:53.024987
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.external import ExternalFD

# Generated at 2022-06-12 17:28:00.634034
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Arrange
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow' + '#asd'
    # Act
    fux_ie = FuxIE()
    # Assert
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))'
    assert fux_ie._match_id(url) == '195359'
    assert fux_ie._display_id == 'awesome-fucking-kitchen-ends-cum-swallow'


# Generated at 2022-06-12 17:28:06.372461
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x = FourTubeBaseIE()
    assert x._URL_TEMPLATE == '%s/videos/%%s/video'
    assert x._TKN_HOST == 'token.4tube.com'
    assert x._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:28:12.639557
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == "4tube"
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:28:13.457355
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-12 17:28:14.072165
# Unit test for constructor of class FuxIE
def test_FuxIE():
    global FuxIE
    FuxIE()

# Generated at 2022-06-12 17:28:17.060278
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:28:20.576396
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE(FuxIE)
        FourTubeIE(PornTubeIE)
        FourTubeIE(PornerBrosIE)
    except Exception:
        # TODO: Just testing instantiation, the following Error(s) is(are) not important
        error = "Can't instantiate abstract class FourTubeIE"
        print(error)

# Generated at 2022-06-12 17:29:31.766425
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == 'porntube'
    assert ie.IE_DESC == 'PornTube'

# Generated at 2022-06-12 17:29:34.002256
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    ie = PornTubeIE()
    assert ie.IE_NAME == 'porntube'

# Generated at 2022-06-12 17:29:37.326673
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE()
    assert a._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
test_PornTubeIE()

# Generated at 2022-06-12 17:29:39.875694
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(PornerBrosIE._VALID_URL, {})


# Generated at 2022-06-12 17:29:45.318103
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    mobj = re.match(PornerBrosIE._VALID_URL, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert mobj is not None
    video_id, display_id = mobj.group('id', 'display_id')
    assert display_id == 'skinny-brunette-takes-big-cock-down-her-anal-hole'
    assert video_id == '181369'



# Generated at 2022-06-12 17:29:48.076140
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL



# Generated at 2022-06-12 17:29:56.914411
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ..utils import TestConductor
    from .test_common import _get_testdata_stream
    from .common import InfoExtractor
    from .pornhub import PornHubIE

    test_conductor = TestConductor(1, 'PornTubeIE Test')
    test_conductor.set_context({'extractor_inits_done': 1})
    test_conductor.start()
    extractor = PornTubeIE(test_conductor, test_conductor.request_callback(PornHubIE))
    extractor.initialize()
    result = extractor.extract(test_conductor.request_callback(PornHubIE))

# Generated at 2022-06-12 17:30:03.373411
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Check to make sure url is the same when url is passed through and out of the constructor
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    test = PornTubeIE(PornTubeIE.ie_key())
    assert test.suitable(url)
    assert url == test.url_result(url)['url']

# Generated at 2022-06-12 17:30:10.610037
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import json

# Generated at 2022-06-12 17:30:11.575308
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE("Fux", True)
    return "hello"

# Generated at 2022-06-12 17:33:30.339548
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._real_extract("http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")

# Generated at 2022-06-12 17:33:32.038178
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()

# Generated at 2022-06-12 17:33:33.322294
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
   ie = FourTubeBaseIE()
   assert(ie is not None)

# Generated at 2022-06-12 17:33:34.672025
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE({}, {})

# Generated at 2022-06-12 17:33:37.619180
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class_ = globals()['FuxIE']
    obj = class_({'extractor': 'Fux'})
    assert isinstance(obj, class_)
    obj = class_(None)
    assert isinstance(obj, class_)

# Generated at 2022-06-12 17:33:39.567820
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    t = FourTubeBaseIE()
    c = t.test()
    c['test'] = 1

test_FourTubeBaseIE()

# Generated at 2022-06-12 17:33:41.708788
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()
    assert i._TKN_HOST
    assert i._VALID_URL
    assert i._URL_TEMPLATE
    assert i._TESTS

# Generated at 2022-06-12 17:33:42.494516
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()


# Generated at 2022-06-12 17:33:43.024866
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:33:45.165316
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from . import testsize
    testsize.UnitTest.test_class_constructor(PornerBrosIE)