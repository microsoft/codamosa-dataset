

# Generated at 2022-06-12 17:25:03.536482
# Unit test for constructor of class FuxIE
def test_FuxIE(): assert FuxIE._TESTS.__len__() > 0

# Generated at 2022-06-12 17:25:04.606517
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE();

# Generated at 2022-06-12 17:25:06.605919
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Instantiate object
    PornerBrosIE()
    # Assert return-value
    assert True

# Generated at 2022-06-12 17:25:07.468491
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	pass

# Generated at 2022-06-12 17:25:09.247317
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-12 17:25:10.929412
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-12 17:25:15.100126
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Constructor should be able to be called with no arguments
    FuxIE()
    # Constructor should accept strings as well as unicode
    FuxIE(u'Fux')
    assert FuxIE().IE_NAME == 'Fux'


# Generated at 2022-06-12 17:25:17.088273
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None)._TKN_HOST == 'token.fourtube.com'

# Generated at 2022-06-12 17:25:22.082722
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._TESTS[0], 'Test dictionary cannot be empty'
    assert FourTubeIE._TESTS[0]['url'], 'URL must not be empty'
    assert FourTubeIE._TESTS[0]['md5'], 'MD5 must not be empty'

# Generated at 2022-06-12 17:25:23.256868
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE
    FourTubeBaseIE

# Generated at 2022-06-12 17:25:41.823839
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()

# Generated at 2022-06-12 17:25:44.195635
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(FourTubeBaseIE.ie_key())._TKN_HOST is not None

# Generated at 2022-06-12 17:25:45.812261
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    a = FourTubeIE;
    assert(a == FourTubeIE)

# Generated at 2022-06-12 17:25:54.631829
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # test1, correct url, no category
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    url_id = '7089759'
    # expected, video_id and display_id
    display_id = None
    video_data = PornTubeIE._extract_url_info(url, url_id)
    assert video_data['video_id'] == url_id
    assert video_data['display_id'] == display_id

    # test2, correct url, with category
    url = 'https://www.porntube.com/videos/Squirting-Teen-Ballerina-ECG_1331406'
    url_id = '1331406'
    # expected, video_id and display_id

# Generated at 2022-06-12 17:26:03.200524
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    m = PornerBrosIE()
    assert re.match(r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)', m._VALID_URL)
    assert m._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert m._TKN_HOST == 'token.pornerbros.com'
    assert m.IE_NAME == 'pornerbros'

# Generated at 2022-06-12 17:26:08.679753
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for ie in (
        FourTubeIE(),
        FuxIE(),
        PornTubeIE(),
        PornerBrosIE(),
    ):
        assert ie.get_id('https://www.4tube.com/videos/242565001/cumming_over_and_over') == '242565001'
        assert ie.get_id('https://www.fux.com/videos/242565001/cumming_over_and_over') == '242565001'
        assert ie.get_id('https://www.porntube.com/videos/cumming_over_and_over_242565001') == '242565001'

# Generated at 2022-06-12 17:26:11.494680
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Simply call the constructor with expected arguments to make sure
    #   it throws no errors, etc
    # Use the 'PornTubeIE' as the base class is not important
    #   (all the others have the same constructor)
    PornTubeIE(None, 'http://www.example.com')



# Generated at 2022-06-12 17:26:14.574465
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    '''
    This is a test function to verify that PornerBrosIE works.
    '''
    a = PornerBrosIE('PornerBrosIE')
    b = PornerBrosIE('PornerBrosIE', 5)
    assert(a.get_num() == 0 and b.get_num() == 5)
    a.set_num(5)
    assert(a.get_num() == 5)

# Generated at 2022-06-12 17:26:22.475224
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.IE_NAME == '4tube'

    obj._TKN_HOST = 'token.4tube.com'
    obj._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    obj._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    mobj = re.match(obj._VALID_URL,
           'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    kind, video_id,

# Generated at 2022-06-12 17:26:24.085032
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE();

# Generated at 2022-06-12 17:26:58.886381
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-12 17:26:59.792605
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert (FuxIE() is not None)

# Generated at 2022-06-12 17:27:08.483041
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert(ie._TKN_HOST == "token.4tube.com")
    ie = FuxIE()
    assert(ie._TKN_HOST == "token.fux.com")
    ie = PornTubeIE()
    assert(ie._TKN_HOST == "tkn.porntube.com")
    ie = PornerBrosIE()
    assert(ie._TKN_HOST == "token.pornerbros.com")
    return

# Generated at 2022-06-12 17:27:09.402443
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:27:09.994127
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')

# Generated at 2022-06-12 17:27:12.894838
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_URL_TEMPLATE')
    assert hasattr(ie, '_TKN_HOST')

# Generated at 2022-06-12 17:27:23.770209
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test a 4tube URL
    FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

    # Test a fux URL
    FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

    # Test a porntube URL
    PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

    # Test a pornerbros URL
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:27:29.196027
# Unit test for constructor of class FuxIE
def test_FuxIE():
	info_extractor = FuxIE()
	result = info_extractor.extract(
		"http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
	assert result["title"] == "Awesome fucking in the kitchen ends with cum swallow"

# Generated at 2022-06-12 17:27:36.797123
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'



# Generated at 2022-06-12 17:27:38.312878
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()
    assert i.IE_NAME == '4tube'

# Generated at 2022-06-12 17:29:05.827149
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    inst = PornTubeIE()
    assert inst._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert inst._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert inst._TESTS[0]['md5'] == 'ca72da2c2a73f81c488e1dce69be6ddf'
    assert inst._TESTS[0]['info_dict']['id'] == '7089759'

# Generated at 2022-06-12 17:29:08.807174
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
   FourTubeBaseIE('4tube')
   FourTubeBaseIE('Fux')
   FourTubeBaseIE('PornTube')
   FourTubeBaseIE('PornerBros')

# Generated at 2022-06-12 17:29:10.045550
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	ie = FourTubeIE()

# Generated at 2022-06-12 17:29:13.661362
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    expected = PornTubeIE._download_webpage(url,None)
    assert expected == 'https://www.porntube.com/embed/1331406'


# Generated at 2022-06-12 17:29:14.330246
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-12 17:29:16.205055
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE.__name__ is not None

# Generated at 2022-06-12 17:29:20.756892
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert re.search(FourTubeBaseIE._VALID_URL, "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")


# Generated at 2022-06-12 17:29:25.619468
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FourTubeBaseIE(InfoExtractor):
        IE_NAME = '4tube'
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/videos/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:29:34.336242
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """ test_FourTubeBaseIE.py """
    # pylint: disable=line-too-long

# Generated at 2022-06-12 17:29:38.596957
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-12 17:33:08.534796
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE(None, None)._TKN_HOST == 'token.4tube.com'
    assert FuxIE(None, None)._TKN_HOST == 'token.fux.com'
    assert PornTubeIE(None, None)._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(None, None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:33:09.491423
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-12 17:33:14.209666
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_instance = FuxIE()
    assert fux_instance._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-12 17:33:15.403019
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()

# Generated at 2022-06-12 17:33:24.865440
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:33:36.363814
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # In the following url, encoding is used. That's why we used
    # "compat_urllib_parse_unquote" in _real_extract function of class PornerBrosIE.
    url = 'https://www.pornerbros.com/videos/video_181369'

# Generated at 2022-06-12 17:33:41.211210
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    def test_factory(ie):
        return ie._VALID_URL

    ie = FourTubeBaseIE(test_factory)
    assert ie._VALID_URL == FourTubeBaseIE._VALID_URL
    assert ie._URL_TEMPLATE == FourTubeBaseIE._URL_TEMPLATE
    assert ie._TKN_HOST == FourTubeBaseIE._TKN_HOST
    assert ie.__name__ == ie.IE_NAME

# Generated at 2022-06-12 17:33:47.894387
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL.startswith("(?i)https?://(?:(?P<kind>www|m)\.|token\.fux\.com/v)")
    assert FuxIE._URL_TEMPLATE.startswith("https://www.fux.com/video/")
    assert FuxIE._TKN_HOST.startswith("token.fux.com")

    assert FuxIE._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert FuxIE._URL_TEMPLATE == "https://www.fux.com/video/%s/video"


# Generated at 2022-06-12 17:33:49.828122
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert(isinstance(ie, PornerBrosIE))

# Generated at 2022-06-12 17:33:55.309132
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    test_obj = FourTubeIE()
    test_obj._extract_formats(test_url, 209733, '209733', ['480', '720'])