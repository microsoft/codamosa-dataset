

# Generated at 2022-06-12 17:25:05.031929
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie_fux = ie.IE_NAME
    assert ie_fux == '4tube'

# Generated at 2022-06-12 17:25:06.204294
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print(FourTubeBaseIE)


# Generated at 2022-06-12 17:25:13.025245
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Sample url
    url = 'http://www.4tube.com/videos/69850/busty-blonde-tina-kay-gets-facial-from-mick-blue'

    # Test constructor without a downloader
    ie = FourTubeIE()
    ie.downloader = None
    ie.url = url
    assert ie.url == url and ie.downloader == None and ie.video_id == '69850'


# Generated at 2022-06-12 17:25:17.144000
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE(PornerBrosIE._downloader, test_url)

# Generated at 2022-06-12 17:25:19.950537
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_match import test_match
    test_match(PornerBrosIE, ['https://www.pornerbros.com/embed/181369'])

# Generated at 2022-06-12 17:25:22.939622
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .youtube import YoutubeIE
    assert PornTubeIE.IE_NAME == YoutubeIE.IE_NAME

# Generated at 2022-06-12 17:25:29.055509
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    res = ie._parse_json('{"a": "b"}', "json_id")
    assert res["a"] == "b", "_parse_json fails to parse simple json"

    try:
        ie._parse_json('{}', "json_id", transform_source=lambda x: y)
        assert False, "transform_source function not found"
    except NameError:
        pass

    try:
        ie._parse_json('{}', "json_id", transform_source=lambda x: int(x))
    except ValueError:
        assert False, "_parse_json fails to transform source"

# Generated at 2022-06-12 17:25:36.909382
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_dict = PornTubeIE()._real_extract(
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert info_dict['id'] == '1331406'
    assert info_dict['uploader'] == 'Exploited College Girls'
    assert info_dict['channel'] == 'Exploited College Girls'
    assert info_dict['formats'][0]['url'] == 'https://cdn-e1.porntube.com/videos/flv/1331406/20/2.flv?s=lj9fdm749hq3qfwjw0nx&e=1541703000'

# Generated at 2022-06-12 17:25:39.104512
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    result = FourTubeBaseIE.__new__(FourTubeBaseIE)
    assert isinstance(result, FourTubeBaseIE)



# Generated at 2022-06-12 17:25:50.344206
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    a = FourTubeBaseIE()
    assert a._TKN_HOST == 'token.4tube.com'
    assert a._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    b = FourTubeIE()
    assert b._TKN_HOST == 'token.4tube.com'
    assert b._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    c = FuxIE()
    assert c._TKN_HOST == 'token.fux.com'
    assert c._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    d = PornTubeIE()
    assert d._TKN_HOST == 'tkn.porntube.com'
   

# Generated at 2022-06-12 17:26:06.442374
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE().extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-12 17:26:12.645609
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # TODO: use test cases from other classes

    # test url
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

    # try to access youtube video from it
    i = FuxIE()
    assert i.suitable(url)

    # define test result

# Generated at 2022-06-12 17:26:15.764276
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import shutil
    shutil.rmtree('testfolder', ignore_errors=True)
    ie = FourTubeBaseIE()
    ie.extract('https://www.porntube.com/embed/7089759')


# Generated at 2022-06-12 17:26:20.605723
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FuxIE()

    assert f._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert f._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert f._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:26:22.087186
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert 1 == 1

# Generated at 2022-06-12 17:26:31.179027
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    youtube_ie = FourTubeIE()
    # Constructor of class YouTubeBaseInfoExtractor
    #   (self, downloader=None, download_warning=True, ie_key=None, **kwargs)
    #   (self, ie_key=None, downloader=None, **kwargs)
    #   (self, ie_key=None, **kwargs)
    #   (self, downloader=None, **kwargs)
    assert youtube_ie.downloader is None
    assert youtube_ie.ie_key == 'FourTube'
    assert youtube_ie.download_warning == True


# Generated at 2022-06-12 17:26:33.111194
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
     ie = FourTubeIE()
     assert isinstance(ie, FourTubeIE), 'Wrong constructor being instantiated'

# Generated at 2022-06-12 17:26:35.423966
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:26:44.211431
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Create a mock extractor object
    c = FourTubeBaseIE()
    # Run the tests
    assert c._extract_formats("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369", 181369, "asdf", ["123", "456"])
    assert c._parse_json("{\"test\": \"this_is_a_test\"}", "")
    assert c._search_regex("1337", "(1337)", "is_a_match")
    assert c._parse_json("[123, 456]", "")
    assert c._search_regex("1337", "(1337)", "is_a_match")

# Generated at 2022-06-12 17:26:45.169220
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()

# Generated at 2022-06-12 17:27:14.976620
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "https://www.porntube.com/videos/video_1331406"
    info_dict = PornTubeIE()._real_extract(url)
    assert info_dict["title"] == "Squirting Teen Ballerina on ECG"

# Generated at 2022-06-12 17:27:18.331151
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE()._real_initialize()
    PornerBrosIE()._real_extract(url)



# Generated at 2022-06-12 17:27:20.819260
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeIE()

# Generated at 2022-06-12 17:27:32.857292
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """ Unit test for class PornTubeIE """

    import os
    import sys
    import unittest

    sys.path.append(os.path.join(sys.path[0], os.path.pardir, 'bin'))
    from YTD.utility import extract_webpage_content

    # Test to verify the validity of a valid PornTubeIE Url
    class TestPornTubeIEValidUrls(unittest.TestCase):

        # Test to verify the return value of extract_webpage_content for a valid PornTubeIE Url
        def test_extract_webpage_content(self):
            from YTD.bin.arguments import parsing
            from YTD.bin.options import extract_options


# Generated at 2022-06-12 17:27:36.604845
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    if isinstance(PornTubeIE(), PornTubeIE):
        print('yes')
    else:
        print('no')

test_PornTubeIE()

# Generated at 2022-06-12 17:27:38.129177
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("FourTube")
    assert isinstance(ie, FourTubeIE)


# Generated at 2022-06-12 17:27:41.645400
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from ..extractor import _instantiate_extractor
    _instantiate_extractor(FuxIE, 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    _instantiate_extractor(PornTubeIE, 'https://www.porntube.com/embed/7089759')

# Generated at 2022-06-12 17:27:44.292395
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Empty run
    pass

# Generated at 2022-06-12 17:27:45.175717
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE

# Generated at 2022-06-12 17:27:49.471966
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert_equal(obj._VALID_URL, None)
    assert_equal(obj._URL_TEMPLATE, None)
    assert_equal(obj._TKN_HOST, None)
    assert_equal(obj._TESTS, [])

# Generated at 2022-06-12 17:29:07.380116
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    FakePornTubeIE = type('FakePornTubeIE', (PornTubeIE,), {'_VALID_URL': r'%s'})
    expected = [
        'https://www.porntube.com/embed/7089759',
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406',
        'https://www.porntube.com/videos/video_1331406',
        'https://www.porntube.com/videos/video_7089759',
    ]
    assert expected == list(FakePornTubeIE()._VALID_URL_RE.findall(
        ' '.join(expected)))

# Generated at 2022-06-12 17:29:08.515954
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE({})

# Generated at 2022-06-12 17:29:09.238558
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():

    # init FourTubeIE
    FourTubeIE()

# Generated at 2022-06-12 17:29:13.652836
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ip = FourTubeIE('www.4tube.com')
    assert ip.IE_NAME == '4tube'
    assert ip._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ip._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ip._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:29:14.766835
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert callable(FuxIE)

# Generated at 2022-06-12 17:29:20.839154
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:29:30.388700
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = (
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    test_video_id = '181369'
    test_display_id = 'skinny-brunette-takes-big-cock-down-her-anal-hole'
    test_title = 'Skinny brunette takes big cock down her anal hole'
    test_uploader = 'PornerBros HD'
    test_timestamp = 1359527401
    test_duration = 1224
    test_like_count = None
    test_dislike_count = None
    test_categories = None
    test_age_limit = 18
    test_view_count = int

    test_video = Por

# Generated at 2022-06-12 17:29:36.293266
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == "4tube"
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:29:42.835851
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test for init of class FourTubeBaseIE
    obj_FourTubeBaseIE = FourTubeBaseIE()
    assert obj_FourTubeBaseIE is not None
    assert hasattr(obj_FourTubeBaseIE, '_TKN_HOST') and isinstance(obj_FourTubeBaseIE._TKN_HOST, compat_str)
    assert hasattr(obj_FourTubeBaseIE, '_VALID_URL') and isinstance(obj_FourTubeBaseIE._VALID_URL, compat_str)

# Generated at 2022-06-12 17:29:43.872817
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE._download_webpage()

# Generated at 2022-06-12 17:32:47.780162
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert re.match(FourTubeBaseIE._VALID_URL, "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert re.match(FourTubeBaseIE._VALID_URL, "https://www.4tube.com/embed/209733")
    assert re.match(FourTubeBaseIE._VALID_URL, "https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

# Generated at 2022-06-12 17:32:48.665133
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-12 17:32:50.582221
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(PornerBrosIE.__name__)._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-12 17:32:59.375827
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pti = PornTubeIE()
    assert pti.IE_NAME == 'PornTube'
    assert pti._VALID_URL == \
        r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pti._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pti._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:33:02.383377
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)
    assert callable(FourTubeBaseIE._extract_formats)


# Generated at 2022-06-12 17:33:04.980370
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance.IE_NAME == 'pornerbros'

# Generated at 2022-06-12 17:33:08.009305
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    PornTubeIE()._real_extract(url)

# Generated at 2022-06-12 17:33:08.889357
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie

# Generated at 2022-06-12 17:33:14.347598
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie = FuxIE('test')
    ie = FuxIE(test='test')
    ie = FuxIE(test='test', ie_keywords='test')

# Generated at 2022-06-12 17:33:17.941933
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    return FuxIE._TESTS[0]['url']
