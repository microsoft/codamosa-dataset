

# Generated at 2022-06-12 17:25:12.812818
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Simple unit test to check if the constructor of class FourTubeIE is working as expected
    """

    url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    result = FourTubeIE()._real_extract(url)

    assert result["id"] == "209733"
    assert result["title"] == "Hot Babe Holly Michaels gets her ass stuffed by black"
    assert result["uploader"] == "WCP Club"
    assert result["uploader_id"] == "wcp-club"
    assert result["upload_date"] == "20131031"
    assert result["timestamp"] == 1383263892
    assert result["duration"] == 583

# Generated at 2022-06-12 17:25:24.463287
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    # Initialize an instance of class FourTubeBaseIE
    # and assign it to global variable "f"
    f = FourTubeBaseIE()

    # Test the _extract_formats() method of FourTubeBaseIE
    # by passing in a sample URL and a sample video ID
    f._extract_formats('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
                       '209733')
    
    # Test the _real_extract() method of FourTubeBaseIE
    # by passing in a sample URL

# Generated at 2022-06-12 17:25:28.188993
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('PornerBrosIE', 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:25:31.054354
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'
    assert ie.IE_DESC == 'PornerBros'

# Generated at 2022-06-12 17:25:32.274301
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME == '4tube'

# Generated at 2022-06-12 17:25:38.633826
# Unit test for constructor of class FuxIE
def test_FuxIE():
    '''
    Constructor of class FuxIE
    '''
    # Test suites are independent, so redirect output to null
    # Avoid writing countless empty lines to the console
    import sys
    try:
            # redirect all output to /dev/null
            sys.stdout = open('/dev/null', 'w')
            sys.stderr = open('/dev/null', 'w')
            x = FuxIE()
    finally:
            # reset redirects
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__


# Generated at 2022-06-12 17:25:49.241073
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video = PornTubeIE()._parse_json(PornTubeIE()._search_regex(
        r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        PornTubeIE()._download_webpage('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'),
        'data', group='value'), '1331406')['page']['video']
    assert video['title'] == 'Squirting Teen Ballerina on ECG'
    assert video['channel']['name'] == 'Exploited College Girls'
    assert video['user']['username'] == 'Exploited College Girls'

# Generated at 2022-06-12 17:25:57.354940
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    IE = FourTubeBaseIE.construct_class('4tube', '4tube.com')
    assert isinstance(IE(), FourTubeIE)
    IE = FourTubeBaseIE.construct_class('4tube', 'token.4tube.com')
    assert isinstance(IE(), FourTubeIE)
    IE = FourTubeBaseIE.construct_class('fux', 'fux.com')
    assert isinstance(IE(), FuxIE)
    IE = FourTubeBaseIE.construct_class('porntube', 'porntube.com')
    assert isinstance(IE(), PornTubeIE)
    IE = FourTubeBaseIE.construct_class('pornerbros', 'pornerbros.com')
    assert isinstance(IE(), PornerBrosIE)

# Generated at 2022-06-12 17:26:04.309745
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.params['domain'] == 'www.pornerbros.com'
    assert ie._VALID_URL == PornerBrosIE._VALID_URL
    assert ie._URL_TEMPLATE == PornerBrosIE._URL_TEMPLATE
    assert ie._TKN_HOST == PornerBrosIE._TKN_HOST
    assert ie._TESTS == PornerBrosIE._TESTS


# Generated at 2022-06-12 17:26:06.912527
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._TESTS
    assert obj._VALID_URL
    assert obj._URL_TEMPLATE
    assert obj._TKN_HOST



# Generated at 2022-06-12 17:26:32.974894
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest

    class FuxIETest(unittest.TestCase):
        @staticmethod
        def _get_url():
            return 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

        def test_is_FuxIE(self):
            url = self._get_url()

            self.assertIsInstance(FuxIE._get_info_extractor_by_url(url), FuxIE)

        def test_title(self):
            url = self._get_url()

            ie = FuxIE._get_info_extractor_by_url(url)
            info_dict = ie._real_extract(url)


# Generated at 2022-06-12 17:26:40.572457
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Constructor of class FourTubeBaseIE, that takes two mandatory
    # arguments, such as name and ie_key, and one optional argument
    # called ie_key
    ie = FourTubeBaseIE('4tube', '4Tube')

    # Test for name of IE
    if ie.ie_key == '4Tube':
        print('ie_key is correct')
    else:
        print('ie_key is wrong')

    # Test for ie_key of IE
    if ie.name == '4tube':
        print('name is correct')
    else:
        print('name is wrong')

    # Test for _VALID_URL property of IE

# Generated at 2022-06-12 17:26:43.803086
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .test_fourtube_ie import FourTubeIE
    assert FourTubeIE('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-12 17:26:47.928356
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test valid URL
    FourTubeIE._VALID_URL = "http://www.4tube.com/videos/123"
    test_url = "http://www.4tube.com/videos/123"
    ie = FourTubeIE(test_url)

# Test valid URL
test_FourTubeIE()

# Generated at 2022-06-12 17:26:48.719657
# Unit test for constructor of class FuxIE
def test_FuxIE():
    a = FuxIE()

# Generated at 2022-06-12 17:26:49.971522
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'



# Generated at 2022-06-12 17:26:58.062334
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie1 = FuxIE()
    assert ie1._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie1._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie1._TKN_HOST == 'token.fux.com'
    assert_raises(AssertionError, FuxIE, _VALID_URL='www.fux.com')
    assert_raises(AssertionError, FuxIE, _URL_TEMPLATE='https://www.fux.com/video/%s/videos')
    assert_ra

# Generated at 2022-06-12 17:27:08.866020
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-12 17:27:13.375055
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'FuxIE'
    assert FuxIE.__doc__ == ''
    assert FuxIE.__module__ == '__main__'
    assert FuxIE.IE_DESC == 'Fux'
    assert FuxIE.IE_NAME == 'Fux'
    assert FuxIE.IE_VERSION == '0.0.1'
    assert FuxIE._TKN_HOST == 'token.fux.com'
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:27:22.084559
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Create a FourTubeBaseIE instance
    ie = FourTubeBaseIE("FourTubeBaseIE")
    # Check the name
    name = ie.ie_key()
    assert name == "FourTubeBaseIE"
    # Check the URL
    url = ie.working_url("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert url == "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"

# Generated at 2022-06-12 17:27:40.619404
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:27:41.531762
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test = FourTubeIE()
    test.suite()

# Generated at 2022-06-12 17:27:48.916424
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-12 17:27:49.853895
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE()


# Generated at 2022-06-12 17:27:51.626151
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
    except:
        assert False, 'Constructor of PornTubeIE raises an exception'


# Generated at 2022-06-12 17:27:52.494755
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('Fux', 'Fux', 'fux')



# Generated at 2022-06-12 17:28:00.326282
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()

# Generated at 2022-06-12 17:28:03.482080
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # A test case for the constructor of class FourTubeIE.
    #
    # The test case is expected to pass, so no assertions are raised.
    # If any assertion is raised, the test case fails
    #
    fourtube_ie = FourTubeIE()

# Generated at 2022-06-12 17:28:11.176241
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    from ..compat import (compat_urlparse, compat_urllib_parse_unquote,
                          compat_b64decode)
    from ..utils import (unified_timestamp, str_or_none,
                         int_or_none, url_or_none, parse_duration)
    from ..compat import compat_str

    url = 'http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = InfoExtractor(url)

    kind = ie._VALID_URL(url).group('kind')
    video_id = ie._VALID_URL(url).group('id')

# Generated at 2022-06-12 17:28:11.820130
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()


# Generated at 2022-06-12 17:28:55.389541
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:29:03.110697
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    test_url_embed = "https://www.porntube.com/embed/7089759"
    # In case of normal url
    url_regex = PornTubeIE._VALID_URL
    m = re.match(url_regex, test_url)
    assert(m is not None)
    # In case of embed url
    m = re.match(url_regex, test_url_embed)
    assert(m is not None)

# Generated at 2022-06-12 17:29:11.398590
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test constructor of class FuxIE
    from . import FuxIE
    assert FuxIE.__name__ == 'FuxIE'
    # Test Base class
    assert issubclass(FuxIE, FourTubeBaseIE)
    # Test whether Base class is not direct base
    assert not FuxIE.__bases__[0] == FourTubeBaseIE
    # Test FourTubeBaseIE as an indirect base class
    assert FuxIE.__mro__[1] == FourTubeBaseIE


# Generated at 2022-06-12 17:29:14.094104
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._real_extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-12 17:29:20.548552
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    my_instance = PornerBrosIE()
    assert my_instance.IE_NAME == 'PornerBrosIE'
    assert my_instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-12 17:29:21.788217
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-12 17:29:25.285992
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    with PornerBrosIE() as ie:
        ie.extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:29:26.030745
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert(ie)

# Generated at 2022-06-12 17:29:27.716379
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print("Running test for FourTubeIE constructor.")
    assert FourTubeIE.IE_NAME == '4tube'

# Generated at 2022-06-12 17:29:36.287581
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    o = PornerBrosIE()
    assert o.__class__.__name__ == "PornerBrosIE"
    assert  PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert  PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert  PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:31:09.452242
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('', '', '')
    assert 'FourTubeBaseIE' in str(ie)

# Generated at 2022-06-12 17:31:18.754507
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	ie = PornTubeIE()
	assert(ie._VALID_URL != None)
	assert(ie.IE_NAME != None)
	assert(ie._TESTS != None)
	assert(ie._TKN_HOST != None)
	assert(ie._URL_TEMPLATE != None)
	assert(ie._download_webpage != None)
	assert(ie._extract_formats != None)
	assert(ie._html_search_meta != None)
	assert(ie._html_search_regex != None)
	assert(ie._parse_json != None)
	assert(ie._search_regex != None)
	assert(ie._real_extract != None)
	assert(ie._sort_formats != None)
	assert(ie._TESTS != None)

# Generated at 2022-06-12 17:31:20.138479
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()



# Generated at 2022-06-12 17:31:22.480532
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.name == '4tube'
    assert ie.supported_ie == ['4tube.com']

# Generated at 2022-06-12 17:31:28.879339
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test initialization of FourTubeIE
    _TESTS = [
        {'kind': 'm.', 'display_id': '', 'id': '209733'},
        {'kind': '', 'display_id': 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', 'id': '209733'},
        {'kind': '', 'display_id': '', 'id': '209733'}
    ]
    for test in _TESTS:
        r = FourTubeIE('')
        r._VALID_URL = re.sub(r'(?P<kind>www|m)\.', '(?P<kind>%s)' % test['kind'], r._VALID_URL)  # noqa: E501
        r._VAL

# Generated at 2022-06-12 17:31:32.287507
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
        PornerBrosIE('https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:31:35.635372
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f = FourTubeBaseIE()
    f._download_webpage(None, None, None)
    f._search_regex(None, None, None, None, None)
    f._extract_formats(None, None, None, None)

# Generated at 2022-06-12 17:31:42.916271
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert obj._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:31:43.667017
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)

# Generated at 2022-06-12 17:31:45.570407
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    object = FourTubeBaseIE()

    assert object._VALID_URL == None
    assert object._TESTS == None
    assert object._TKN_HOST == None



# Generated at 2022-06-12 17:34:49.014665
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    assert issubclass(FourTubeBaseIE, InfoExtractor)