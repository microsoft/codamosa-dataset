

# Generated at 2022-06-12 17:25:07.788236
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    tfn = FourTubeBaseIE._TKN_HOST
    assert(FourTubeBaseIE._TKN_HOST == tfn)
    FourTubeBaseIE._TKN_HOST = 'token.pornerbros.com'
    assert(FourTubeBaseIE._TKN_HOST != tfn)
    FourTubeBaseIE._TKN_HOST = tfn

# Generated at 2022-06-12 17:25:15.306660
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert ie.IE_NAME == 'PornTube'
    assert ie.age_limit == 18


# Generated at 2022-06-12 17:25:17.377270
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(FourTubeBaseIE().IE_NAME, FourTubeBaseIE()._VALID_URL)

# Generated at 2022-06-12 17:25:22.939626
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    res = FourTubeBaseIE(None)

    assert res.IE_NAME is not None
    assert res._VALID_URL is not None
    assert res._URL_TEMPLATE is not None
    assert res._TKN_HOST is not None
    assert res._TESTS is not None

# Generated at 2022-06-12 17:25:23.985734
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

# Generated at 2022-06-12 17:25:25.045164
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert 1 == 1

test_FourTubeIE()

# Generated at 2022-06-12 17:25:29.210241
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE('http://www.fux.com/videos/awesome-fucking-kitchen-ends-cum-swallow')
    assert ie.__name__ == 'Fux'
    assert ie.IE_NAME == 'Fux'


# Generated at 2022-06-12 17:25:30.650620
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBros')


# Generated at 2022-06-12 17:25:35.012562
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # PornerBrosIE() is supposed to be the constructor of class PornerBrosIE
    obj = PornerBrosIE()
    # Assert the constructor method is the right one
    assert isinstance(obj, PornerBrosIE)
    # Assert the same is true for the class itself
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-12 17:25:46.561660
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie, FourTubeBaseIE)
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert ie._TESTS

# Generated at 2022-06-12 17:26:08.559853
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_input_url="https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    test_output_id="195359"
    test_output_title="Awesome fucking in the kitchen ends with cum swallow"

    #check if the input and output id and title match
    assert(FuxIE._VALID_URL == test_input_url)
    assert(test_output_id in FuxIE._TESTS[0]['info_dict'])
    assert(test_output_title in FuxIE._TESTS[0]['info_dict'])

# Generated at 2022-06-12 17:26:10.711286
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    assert(ie.HOST);
    assert(ie.IE_NAME);
    assert(ie.VALID_URL);
    assert(ie.TKN_HOST);

# Generated at 2022-06-12 17:26:19.934257
# Unit test for constructor of class FuxIE
def test_FuxIE():
    if hasattr(FuxIE, '_VALID_URL'):
        print('test_FuxIE()')

    print(FuxIE._VALID_URL)

    try:
        mobj = re.match(FuxIE._VALID_URL, 'https://www.fux.com/video/195360/teen-tight-pussy')
        print(mobj.group('id'))
        print(mobj.group('display_id'))
    except:
        pass

    try:
        mobj = re.match(FuxIE._VALID_URL, 'https://www.fux.com/embed/195360')
        print(mobj.group('id'))
        print(mobj.group('display_id'))
    except:
        pass


# Generated at 2022-06-12 17:26:30.867349
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor

    vid = '209733'
    url = 'http://www.4tube.com/videos/%s/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black' % vid
    instances = [
        FourTubeIE(),
        FuxIE(),
        PornTubeIE(),
        PornerBrosIE()
    ]

    for ie in instances:
        info_dict = ie._real_extract(url)
        assert info_dict['id'] == vid
        assert info_dict['title'] is not None
        assert info_dict['duration'] is not None

# Generated at 2022-06-12 17:26:31.592669
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-12 17:26:33.152413
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE('Lk') == FourTubeIE('Lk')

# Generated at 2022-06-12 17:26:34.733875
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()()
    except Exception as e:
        assert False, e

# Generated at 2022-06-12 17:26:36.741756
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import InfoExtractor
    assert isinstance(FuxIE, type(InfoExtractor))

# Generated at 2022-06-12 17:26:39.442047
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    fuxie = FuxIE(test_url)

# Generated at 2022-06-12 17:26:41.410784
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:27:15.635720
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.extract('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')

# Generated at 2022-06-12 17:27:16.160174
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-12 17:27:21.177374
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Check if PornerBrosIE is successfully initialized.
    """
    from youtube_dl.extractor import get_info_extractor

    ie = get_info_extractor("PornerBros")
    assert isinstance(ie, PornerBrosIE)

# Generated at 2022-06-12 17:27:28.199726
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE._download_json = lambda s, url: {'results': [{'id': 1}], 'next': None}
    FourTubeBaseIE._real_initialize()
    assert FourTubeBaseIE._downloader.cache.load('fC1xZrlSU2P3tHwoJtDCRg')['results'][0]['id'] == 1

# Generated at 2022-06-12 17:27:29.879060
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert isinstance(ie, PornTubeIE)


# Generated at 2022-06-12 17:27:31.929785
# Unit test for constructor of class FuxIE
def test_FuxIE():
	from . import FuxIE
	fux_ie = FuxIE()
	assert fux_ie.ie_key() == 'Fux'

# Generated at 2022-06-12 17:27:43.229397
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(FourTubeIE, '4tube')
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

    ie = FourTubeBaseIE(FuxIE, 'fux')
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:27:44.421402
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)

# Generated at 2022-06-12 17:27:47.173261
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-12 17:27:48.611362
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:29:04.532872
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:29:06.414269
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE()
    assert inst.IE_NAME == '4tube'

# Generated at 2022-06-12 17:29:07.011880
# Unit test for constructor of class FuxIE
def test_FuxIE():
    Fux()

# Generated at 2022-06-12 17:29:09.493383
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:29:12.213912
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    ie = InfoExtractor('FourTube', 'http://www.4tube.com/')
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-12 17:29:14.395455
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
     FuxIE._TESTS[0]
     print (FuxIE._TESTS)
    except:
     print ('Error')

# Generated at 2022-06-12 17:29:18.525888
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE('www.pornerbros.com')
    # Test whether PornerBrosIE('www.pornerbros.com') is an object of class FourTubeBaseIE
    assert obj.__class__ == FourTubeBaseIE

# Generated at 2022-06-12 17:29:21.378700
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE()
    assert inst._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-12 17:29:23.431144
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-12 17:29:24.061339
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE

# Generated at 2022-06-12 17:32:29.823396
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = ('https://www.4tube.com/videos/209733/'
           'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    i = FourTubeIE()
    i.extract(url)

# Generated at 2022-06-12 17:32:30.760269
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_base_ie = FourTubeBaseIE()
    test_base_ie

# Generated at 2022-06-12 17:32:35.113014
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    assert pornerbros.IE_NAME == 'pornerbros'
    assert pornerbros._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerbros._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerbros._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:32:37.824091
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/embed/7089759'
    pti = PornTubeIE._build_extractor(url)

    assert 'PornTube' in repr(pti)
    assert pti._VALID_URL == PornTubeIE._VALID_URL

# Generated at 2022-06-12 17:32:40.180441
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        from . import code_test
        code_test.test_class_constructor(FourTubeIE)
    except ImportError:
        import sys
        sys.stderr.write("ERROR: Failed to run integration tests\n")

# Generated at 2022-06-12 17:32:41.390776
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == 'porntube'

# Generated at 2022-06-12 17:32:48.497724
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    constructor = FourTubeIE.constructor
    # Don't use the class' constructor, but the global one instead
    try:
        FourTubeIE.constructor = globals()['FourTubeIE']
        # The first of the _TESTS instances is used to test the constructor
        testInst = FourTubeIE._TESTS[0]
        # Create an instance of FourTubeIE
        instance = constructor(testInst)
        # Check if each attribute of the _TESTS instance is equal to comparable attributes of the instance
        assert testInst['url'] == instance.url
        assert testInst['only_matching'] == instance.only_matching
        assert testInst['info_dict']['id'] == instance.video_id

    finally:
        # Restore the original constructor
        FourTubeIE.constructor = constructor

# Generated at 2022-06-12 17:32:49.383475
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('', '')

# Generated at 2022-06-12 17:32:53.065789
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    mobj = re.match(FourTubeBaseIE._VALID_URL,
                    'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert mobj.group('kind') == 'www'

# Generated at 2022-06-12 17:33:01.024721
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'