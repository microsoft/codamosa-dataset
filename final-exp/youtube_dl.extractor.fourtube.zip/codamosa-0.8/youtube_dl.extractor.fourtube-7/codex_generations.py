

# Generated at 2022-06-12 17:25:04.886107
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-12 17:25:09.910834
# Unit test for constructor of class FuxIE
def test_FuxIE():
    '''
    Unit test for constructor of class FuxIE
    '''
    fux_ie = FuxIE()
    assert fux_ie._TKN_HOST == fux_ie._VALID_URL
    assert fux_ie._URL_TEMPLATE == fux_ie._VALID_URL

# Generated at 2022-06-12 17:25:21.980406
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_cases = [
        ('nsfw.4tube.com', 'nsfw.4tube.com'), ('4tube.com', 'token.4tube.com'),
        ('nsfw.fux.com', 'nsfw.fux.com'), ('fux.com', 'token.fux.com'),
        ('nsfw.porntube.com', 'nsfw.porntube.com'), ('porntube.com', 'tkn.porntube.com'),
        ('nsfw.pornerbros.com', 'nsfw.pornerbros.com'), ('pornerbros.com', 'token.pornerbros.com'),
        ('pornerbros.xxx', None), ('anything', None)
    ]

# Generated at 2022-06-12 17:25:23.860939
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj.IE_NAME == '4tube'



# Generated at 2022-06-12 17:25:26.963380
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # test for constructor of class PornTubeIE
    porntube_ie = PornTubeIE()
    assert porntube_ie
    assert porntube_ie.IE_NAME == '4tube'

# Generated at 2022-06-12 17:25:35.882826
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test empty params
    assert FourTubeBaseIE()

    # Test correct params
    assert FourTubeBaseIE(
        'http://www.4tube.com',
        'http://www.4tube.com/videos/1',
        {'id': '1'})

    # Test wrong params types
    try:
        assert FourTubeBaseIE(0,
                              'http://www.4tube.com/videos/1',
                              {'id': '1'})
        assert False, "Expected TypeError exception"
    except TypeError:
        pass
    try:
        assert FourTubeBaseIE('http://www.4tube.com',
                              0,
                              {'id': '1'})
        assert False, "Expected TypeError exception"
    except TypeError:
        pass

# Generated at 2022-06-12 17:25:37.501784
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert instance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:25:39.020377
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for ie in (FourTubeIE(), FuxIE(), PornTubeIE(), PornerBrosIE()):
        assert ie._TKN_HOST != None
        assert ie._TESTS != None

# Generated at 2022-06-12 17:25:44.405676
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from . import _test_parse_json
    from .common import InfoExtractor
    from ..utils import (
        ExtractorError,
        float_or_none,
        int_or_none,
        parse_duration,
        str_or_none,
        try_get,
        unified_timestamp,
        url_or_none,
    )
    from ..compat import (
        compat_b64decode,
        compat_urlparse,
    )
    from ..jsinterp import JSInterpreter
    from ..aes import (
        aes_cbc_decrypt,
        aes_key_gen,
        key_hex_to_bin,
    )
    from .common import url_basename


# Generated at 2022-06-12 17:25:45.218882
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from . import PornTubeIE
    youtube_ie = PornTubeIE()

# Generated at 2022-06-12 17:26:04.915948
# Unit test for constructor of class FuxIE
def test_FuxIE():
    #print('test_FuxIE')
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    fuxIE = FuxIE()
    info_dict = fuxIE._real_extract(url)
    #print(info_dict)


# Generated at 2022-06-12 17:26:05.551867
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:26:06.890705
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    for x in dir(FourTubeBaseIE):
        assert hasattr(instance, x)


# Generated at 2022-06-12 17:26:07.773790
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f_FourTubeBaseIE = FourTubeBaseIE()

# Generated at 2022-06-12 17:26:11.249026
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Create and instance of FuxIE.
    f = FuxIE()

    # Check that FuxIE is an FourTubeBaseIE child class
    assert issubclass(FuxIE, FourTubeBaseIE)

    # Check that f is an FuxIE object
    assert isinstance(f, FuxIE)


# Generated at 2022-06-12 17:26:12.578278
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE()


# Generated at 2022-06-12 17:26:16.039775
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # test url is valid and class can be created
    assert(FourTubeIE.suitable('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'))


# Generated at 2022-06-12 17:26:18.285865
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(
        PornerBrosIE._create_ie_instance())._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:26:18.996079
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()


# Generated at 2022-06-12 17:26:20.585930
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import ytdl.extractor.fourtube
    return ytdl.extractor.fourtube.FourTubeIE()


# Generated at 2022-06-12 17:26:51.353027
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert(isinstance(instance, PornTubeIE))

# Generated at 2022-06-12 17:26:54.317380
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Class PornerBrosIE is a subclass of class FourTubeBaseIE,
    # so we just need to check if the constructor of class PornerBrosIE
    # will call the constructor of class FourTubeBaseIE, i.e.,
    # check if the following line will call the constructor of class FourTubeBaseIE
    PornerBrosIE(None)



# Generated at 2022-06-12 17:27:01.909112
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        if __name__ == '__main__':
            import sys
            if len(sys.argv) == 2:
                url = sys.argv[1]
                result = PornerBrosIE()._real_extract(url)
                for key in result:
                    print('{} : {}'.format(key, result[key]))
                sys.exit(0)
        print('Pass parameter "URL"')
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_FourTubeBaseIE()

# Generated at 2022-06-12 17:27:05.242922
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_test = PornerBrosIE()
    assert class_test._TKN_HOST == 'token.pornerbros.com', 'Test OK'

# Generated at 2022-06-12 17:27:10.970763
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert(isinstance(ie, FourTubeBaseIE))
    assert(isinstance(ie, InfoExtractor))
    assert(hasattr(ie, '_VALID_URL'))
    assert(hasattr(ie, '_TKN_HOST'))
    assert(hasattr(ie, '_TESTS'))
    assert(hasattr(ie, '_extract_formats'))
    assert(hasattr(ie, '_real_extract'))

# Generated at 2022-06-12 17:27:12.896288
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """ Basic unit test for FuxIE. """
    # Assert class creation.
    assert FuxIE(FuxIE.ie_key())



# Generated at 2022-06-12 17:27:15.449742
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    return PornTubeIE()._download_webpage(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        '7089759', 'Downloading webpage')


# Generated at 2022-06-12 17:27:28.578369
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-12 17:27:29.567809
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()

# Generated at 2022-06-12 17:27:30.998011
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('FuxIE', 'FuxIE')


# Generated at 2022-06-12 17:28:45.672778
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # The test instance should be an instance of class FourTubeIE.
    test = FourTubeIE()
    assert test.__class__.__name__ == "FourTubeIE"

# Generated at 2022-06-12 17:28:51.208629
# Unit test for constructor of class FuxIE
def test_FuxIE():
    video = FuxIE()
    assert video.IE_NAME == '4tube'
    assert video._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert video._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert video._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:28:52.801387
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:28:56.022786
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert isinstance(FourTubeBaseIE(), FourTubeBaseIE)

# Generated at 2022-06-12 17:29:05.399440
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .generic import try_get
    from .utils import extract_attributes, parse_duration
    t = FuxIE()
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    webpage = t._download_webpage(url, '195359')
    video = t._parse_json(t._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1', webpage, 'data', group='value'), '195359', transform_source=lambda x: compat_urllib_parse_unquote(compat_b64decode(x).decode('utf-8')))['page']['video']
    video_id = video['videoId']

# Generated at 2022-06-12 17:29:06.736079
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-12 17:29:08.339425
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE == type(PornTubeIE(None))

# Generated at 2022-06-12 17:29:12.439942
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ret = {
        'id': '1',
        '_type': 'url_transparent',
        'url': 'https://fux.com/embed/1',
        'display_id': '1',
        'ie_key': 'Fux'
    }
    assert FuxIE._extract_url(FuxIE._VALID_URL, webpage=None) == ret
    assert FuxIE._extract_url(FuxIE._VALID_URL, webpage=FuxIE._VALID_URL) == ret

# Generated at 2022-06-12 17:29:13.946082
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_obj = PornerBrosIE()
    assert test_obj

# Generated at 2022-06-12 17:29:18.799725
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    ie._download_json("http://token.4tube.com/12345678/desktop/720p", "12345678", headers={"Origin": "https://www.4tube.com", "Referer": "https://www.4tube.com/videos/12345678"})

# Generated at 2022-06-12 17:32:10.364735
# Unit test for constructor of class FuxIE
def test_FuxIE():
    util.test_constructor(FuxIE)

# Generated at 2022-06-12 17:32:16.233059
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video = FourTubeIE()._real_extract(
        'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert video['id'] == '209733'
    assert video['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert video['uploader'] == 'WCP Club'
    assert video['uploader_id'] == 'wcp-club'
    assert video['timestamp'] == 1383263892
    assert video['duration'] == 583
    assert video['view_count'] > 0
    assert video['like_count'] > 0
    assert video['age_limit'] == 18

# Generated at 2022-06-12 17:32:17.096521
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert repr(FuxIE()) != repr(FourTubeIE())


# Generated at 2022-06-12 17:32:22.743956
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ..extractor.tests.test_common import FakeYDL
    from ..extractor.common import InfoExtractor
    from ..compat import ElementTree as etree
    # Provided by: https://github.com/rg3/youtube-dl/pull/14366

# Generated at 2022-06-12 17:32:24.423182
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('FourTube')
    FourTubeIE('FourTube')
    FuxIE('Fux')
    PornTubeIE('Porntube')
    PornerBrosIE('PornerBros')

# Generated at 2022-06-12 17:32:25.664610
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	try:
		PornerBrosIE()._TKN_HOST
	except:
		print("Test of PornerBrosIE failed")

# Generated at 2022-06-12 17:32:31.282593
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four = FourTubeIE()

    assert(four._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(four._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(four._TKN_HOST == 'token.4tube.com')
    assert(four._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-12 17:32:33.176396
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print(FourTubeIE()._VALID_URL)
    print(FourTubeIE._TESTS[0]['url'])
    assert FourTubeIE()._VALID_URL == FourTubeIE._TESTS[0]['url']


# Generated at 2022-06-12 17:32:34.709776
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Tests FourTubeBaseIE constructor
    # Expects correct initialization of class variables
    FourTubeBaseIE('FourTubeBaseIE')

# Generated at 2022-06-12 17:32:41.965184
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    import unittest.mock

    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    class TestPornerBrosIE(unittest.TestCase):
        def test_instance_creation(self):
            clazz = PornerBrosIE(
                unittest.mock.MagicMock(), None, unittest.mock.MagicMock(
                    return_value=unittest.mock.MagicMock()))
            clazz.proto = 'https'
            with unittest.mock.patch('hashlib.md5') as mock_md5:
                instance = clazz._construct_url(url, None)
                self.assertE