

# Generated at 2022-06-12 17:25:04.446086
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-12 17:25:05.147213
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:25:08.192871
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL
    assert ie._URL_TEMPLATE
    assert ie._TKN_HOST
    assert ie._TESTS

# Generated at 2022-06-12 17:25:12.703349
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Would throw NotImplementedError when executing the class constructor
    # of class FourTubeBaseIE.
    try:
        FourTubeBaseIE()
    except NotImplementedError:
        pass
    else:
        raise Exception('Failed to throw NotImplementedError')

# Generated at 2022-06-12 17:25:13.061967
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:25:13.633333
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    4 == 2 + 2



# Generated at 2022-06-12 17:25:14.364831
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:25:15.455995
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-12 17:25:17.551206
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE("FourTubeBaseIE")
    assert type(i) == FourTubeBaseIE


# Generated at 2022-06-12 17:25:19.109837
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE(None)
    assert isinstance(ie, FuxIE)

# Generated at 2022-06-12 17:25:54.477864
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert hasattr(ie, "_VALID_URL")
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert hasattr(ie, "_TESTS")

# Generated at 2022-06-12 17:25:56.309471
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:26:03.914822
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_object = FourTubeIE()
    assert test_object.IE_NAME == '4tube'
    assert test_object.IE_DESC == '4Tube'
    assert test_object.generate_extractors() == [FourTubeIE]
    assert test_object._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:26:04.875336
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE()

# Generated at 2022-06-12 17:26:06.197449
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    # Check class fields
    assert (instance._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-12 17:26:09.685794
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    
test_FuxIE()


# Generated at 2022-06-12 17:26:14.724559
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._TESTS[0]['url'] == fuxIE._VALID_URL
    assert fuxIE._TESTS[0]['info_dict']['id'] == fuxIE._VALID_URL
    assert fuxIE._TESTS[0]['info_dict']['ext'] == fuxIE._VALID_URL



# Generated at 2022-06-12 17:26:16.527005
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert(FourTubeBaseIE()._TKN_HOST == 'token.4tube.com')

# Generated at 2022-06-12 17:26:29.158230
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    info_dict = {
            'id': '195359',
            'ext': 'mp4',
            'title': 'Awesome fucking in the kitchen ends with cum swallow',
            'uploader': 'alenci2342',
            'uploader_id': 'alenci2342',
            'upload_date': '20131230',
            'timestamp': 1388361660,
            'duration': 289,
            'view_count': int,
            'like_count': int,
            'categories': list,
            'age_limit': 18,
        }
    result = FuxIE()._real_extract(fux_url)

# Generated at 2022-06-12 17:26:30.867518
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    plumber = PornTubeIE()
    assert plumber.IE_NAME == 'porntube'

# Generated at 2022-06-12 17:27:03.315569
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    testTube = FourTubeBaseIE()

# Generated at 2022-06-12 17:27:08.696972
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    FuxIE(url)
    FuxIE.suitable(url)
    FuxIE.ie_key()
    FuxIE._WORKING = False
    FuxIE._WORKING = True


# Generated at 2022-06-12 17:27:09.605003
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE


# Generated at 2022-06-12 17:27:11.125161
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE('www.fux.com')
    assert FuxIE('m.fux.com')

# Generated at 2022-06-12 17:27:19.823283
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .pornhub import PornHubIE
    from .tube8 import Tube8IE
    from .tube8 import Tube8EmbedIE
    from .xhamster import XHamsterIE
    from .xhamster import XHamsterEmbedIE

    _PORN_TUBE_CLASSES = (
        PornHubIE,
        XHamsterIE,
        XHamsterEmbedIE,
        Tube8IE,
        Tube8EmbedIE,
        PornTubeIE,
    )

# Generated at 2022-06-12 17:27:29.431370
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.IE_NAME = 'test'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:27:33.616484
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    public = FourTubeIE()
    print(public.IE_NAME)
    print(public.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'))

# Generated at 2022-06-12 17:27:37.451866
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    IE = PornerBrosIE()
    assert IE.get_url() == 'https://www.pornerbros.com/embed/181369'
    assert IE.get_id() == '181369'
    assert IE.get_host() == 'token.pornerbros.com'

# Generated at 2022-06-12 17:27:38.011154
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-12 17:27:46.847441
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    fux_ie = FuxIE()
    assert fux_ie._VALID_URL == fux_ie.ie._VALID_URL
    assert fux_ie._URL_TEMPLATE == fux_ie.ie._URL_TEMPLATE
    assert fux_ie._TKN_HOST == fux_ie.ie._TKN_HOST
    assert fux_ie._TESTS == fux_ie.ie._TESTS

# Generated at 2022-06-12 17:29:10.252135
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url='https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    FourTubeIE()._TKN_HOST
    FourTubeIE()._URL_TEMPLATE
    FourTubeIE().exclude()
    FourTubeIE()._download_webpage(url, video_id='')


# Generated at 2022-06-12 17:29:11.789386
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x.IE_NAME == 'porntube'

# Generated at 2022-06-12 17:29:12.611569
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i = PornerBrosIE()

# Generated at 2022-06-12 17:29:14.138688
# Unit test for constructor of class FuxIE
def test_FuxIE():
	FuxIE()._extract_formats(None, None, None, None);

# Generated at 2022-06-12 17:29:16.347332
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('http://www.porntube.com/embed/7089759')

# Generated at 2022-06-12 17:29:17.672826
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert 'FuxIE' == ie.ie_key()

# Generated at 2022-06-12 17:29:18.659322
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourtube_base_ie = FourTubeBaseIE()

# Generated at 2022-06-12 17:29:29.075613
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FourTubeBaseIE_test(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?(?P<site>\w+)\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.%s.com/videos/video_%%s'
        _TKN_HOST = 'token.%s.com'

# Generated at 2022-06-12 17:29:32.111076
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'

test_FourTubeIE()

# Generated at 2022-06-12 17:29:32.991542
# Unit test for constructor of class FuxIE
def test_FuxIE():
    m = FuxIE()
    assert m != None

# Generated at 2022-06-12 17:32:41.465943
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    # Passing url of the current class_name
    obj2 = PornerBrosIE(url)
    obj_url = obj.url
    obj_url2 = obj2.url
    # Check if both are equal
    assert obj_url == obj_url2



# Generated at 2022-06-12 17:32:43.956191
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._VALID_URL is not None
    assert FourTubeBaseIE._URL_TEMPLATE is not None
    assert FourTubeBaseIE._TKN_HOST is not None
    assert FourTubeBaseIE._TESTS is not None

# Generated at 2022-06-12 17:32:46.163128
# Unit test for constructor of class FuxIE
def test_FuxIE():
	url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
	fuxIE = FuxIE(url)
	assert fuxIE is not None


# Generated at 2022-06-12 17:32:47.099504
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('a', 'b', 'c')

# Generated at 2022-06-12 17:32:47.847315
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass

# Generated at 2022-06-12 17:32:52.161081
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:32:57.546367
# Unit test for constructor of class FuxIE
def test_FuxIE():
	
	if FuxIE.__module__=='__main__':
		test_url="http://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow"
		pattern="http://www.fux.com/video/(?P<id>\d+)/video"
		cls=FuxIE
		cls.check_url()
		cls.extract_info()
	else:
		assert False

# Generated at 2022-06-12 17:33:02.687590
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTubeIE = FourTubeIE()
    assert 'FourTubeBaseIE' == fourTubeIE.__class__.__bases__[0].__name__
    assert 'r\'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?\'' == str(fourTubeIE._VALID_URL)
    assert 'FourTubeIE.IE_NAME' == fourTubeIE.IE_NAME

# Generated at 2022-06-12 17:33:11.721853
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Needed to suppress error messages in case of test failures
    """
    import sys
    class ErrorWriter(object):
        def write(self, line):
            pass
    sys.stderr = ErrorWriter()
    # Test initialization with valid URL
    pt = FourTubeBaseIE('http://pt.com')
    # Test initialization with invalid URL
    fourTubeBase = FourTubeBaseIE('http://wwww.pornhub.com')
    test = fourTubeBase._real_extract('http://wwww.pornhub.com')
    # Test initialization with too long URL

# Generated at 2022-06-12 17:33:13.635329
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie_unit_test(PornerBrosIE)