

# Generated at 2022-06-12 17:25:06.860606
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:25:14.561582
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:25:15.670203
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
    assert f is not None

# Generated at 2022-06-12 17:25:24.694476
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.__bases__ == (FourTubeBaseIE,)
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'
    assert PornTubeIE._TESTS

# Generated at 2022-06-12 17:25:32.234348
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # given
    instance = PornerBrosIE()

    # then
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert instance._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert instance._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-12 17:25:35.885856
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE("FuxIE")._TKN_HOST == "token.fux.com"
    assert FuxIE("FuxIE")._URL_TEMPLATE == "https://www.fux.com/video/%s/video"


# Generated at 2022-06-12 17:25:44.585958
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:25:45.993062
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE('', {})



# Generated at 2022-06-12 17:25:50.869739
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constructor = globals()['FourTubeBaseIE']
    extracted_info = constructor()._real_extract(
        'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert (extracted_info['view_count'] > 0)
    assert (extracted_info['like_count'] > 0)

# Generated at 2022-06-12 17:25:51.762994
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()

# Generated at 2022-06-12 17:26:08.649932
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    obj = ie._FuxIE__download_webpage
    assert obj.__name__ == '_download_webpage'

# Generated at 2022-06-12 17:26:09.388111
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:26:10.235031
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(SimulatedIE())

# Generated at 2022-06-12 17:26:13.731831
# Unit test for constructor of class FuxIE
def test_FuxIE():
	ie = FuxIE()
	assert ie._TKN_HOST == 'token.fux.com'
	assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'


# Generated at 2022-06-12 17:26:15.764143
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    e = FourTubeIE()
    e = FuxIE()
    e = PornTubeIE()
    e = PornerBrosIE()

# Generated at 2022-06-12 17:26:22.548913
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
        Unit tests for constructor of class FourTubeBaseIE
    """
    # Test 1: Assert if the url is valid.
    url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    fourTube = FourTubeIE(FakeInfoExtractor(), {})
    fourTube._VALID_URL = r'http://www\.4tube\.com/'
    valid_url = fourTube._VALID_URL_TEST(url)
    assert (valid_url)
    # Test 2: assert if the url is invalid

# Generated at 2022-06-12 17:26:24.206104
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE({})



# Generated at 2022-06-12 17:26:28.909883
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-12 17:26:31.302454
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    #create test object
    testObj = PornTubeIE()

    #test that test object is instance of InfoExtractor
    assert isinstance(testObj, InfoExtractor)

# Generated at 2022-06-12 17:26:40.722379
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(FourTubeBaseIE.ie_key())

    assert ie.ie_key() == '4tube'
    assert ie.ie_key() in ie.gen_extractors()

    assert re.match(ie._VALID_URL, 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert re.match(ie._VALID_URL, 'https://www.4tube.com/embed/209733')
    assert not re.match(ie._VALID_URL, 'https://www.4tube.com/categories')

# Generated at 2022-06-12 17:27:13.927844
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for cls in (FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE):
        assert cls.__name__ in globals()

# Generated at 2022-06-12 17:27:14.975320
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .cmdline import main
    main(IE=FuxIE)

# Generated at 2022-06-12 17:27:16.423097
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
        assert True
    except AttributeError:
        assert False

# Generated at 2022-06-12 17:27:18.002475
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .test_download import test_template
    test_template(FuxIE, {})


# Generated at 2022-06-12 17:27:22.705322
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.download("https://www.4tube.com/videos/3305245/hot-newcomer-alice-way")

# Generated at 2022-06-12 17:27:24.748093
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    m = PornerBrosIE()

# Generated at 2022-06-12 17:27:27.642950
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE("url")
    assert fux_ie._TKN_HOST == "token.fux.com"

# Generated at 2022-06-12 17:27:30.861922
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    fuxIE = FuxIE(url)
    assert fuxIE.url == url

# Generated at 2022-06-12 17:27:42.217466
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    string = "[1544444444, [[\"http:\\\\/\\\\/cdn01.media.4tube.com\\/media\\/videos\\/240000\\/242078.mp4\", \"720\"], [\"http:\\\\/\\\\/cdn01.media.4tube.com\\/media\\/videos\\/240000\\/242078.mp4\", \"480\"], [\"http:\\\\/\\\\/cdn01.media.4tube.com\\/media\\/videos\\/240000\\/242078.mp4\", \"360\"], [\"http:\\\\/\\\\/cdn01.media.4tube.com\\/media\\/videos\\/240000\\/242078.mp4\", \"240\"]]]"
    data = ie._parse_json(string, "242078")

# Generated at 2022-06-12 17:27:45.105266
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE()
    assert class_.__name__ == 'PornTube'

# Generated at 2022-06-12 17:29:04.796888
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-12 17:29:07.810692
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE([])
    assert(isinstance(ie, InfoExtractor))
    assert(ie.IE_NAME == '4tube')


# Generated at 2022-06-12 17:29:10.252734
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie.IE_DESC == 'FourTube'

# Generated at 2022-06-12 17:29:12.681154
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        # Check that the constructor of class PornerBrosIE successfully instantiates without error
        assert PornerBrosIE()

    except:
        assert False

# Generated at 2022-06-12 17:29:14.646947
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # check whether the constructor returns an instance of class FuxIE
    assert isinstance(FuxIE(), FuxIE)

# Generated at 2022-06-12 17:29:17.984526
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    assert(obj.IE_NAME == '4tube')
    assert(obj._TKN_HOST == 'token.fux.com')

# Generated at 2022-06-12 17:29:19.705007
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(FourTubeBaseIE)._VALID_URL == PornTubeIE._VALID_URL

# Generated at 2022-06-12 17:29:25.333314
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Unit test for constructor of class PornerBrosIE"""
    instance = PornerBrosIE()
    assert(instance.name == 'PornerBros')
    assert(instance.ie_key == 'PornerBros')
    assert(instance.host == 'pornerbros.com')
    assert(instance.age_limit == 18)



# Generated at 2022-06-12 17:29:30.090807
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    sender = FourTubeIE()
    assert sender._TKN_HOST == 'token.4tube.com'
    assert sender._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert sender._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert sender._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-12 17:29:33.735252
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    # Test the constructor
    ie.extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:32:52.655515
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_cases = [
        {'url': 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'},
        {'url': 'https://www.porntube.com/embed/7089759'},
        {'url': 'https://m.porntube.com/videos/teen-couple-doing-anal_7089759'}
    ]
    for test_case in test_cases:
        assert PornTubeIE(test_case)._VALID_URL == \
                'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'


# Generated at 2022-06-12 17:32:53.584737
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE.__name__

# Generated at 2022-06-12 17:33:01.419701
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert hasattr(FuxIE, '_TESTS')
    assert hasattr(FourTubeBaseIE, '_VALID_URL')
    assert hasattr(FourTubeBaseIE, '_URL_TEMPLATE')
    assert hasattr(FourTubeBaseIE, '_TKN_HOST')
    assert hasattr(PornTubeIE, '_TESTS')
    assert hasattr(PornerBrosIE, '_TESTS')
    assert hasattr(FourTubeBaseIE, 'IE_NAME')
    assert hasattr(FourTubeBaseIE, '_VALID_URL')
    assert hasattr(FourTubeBaseIE, '_URL_TEMPLATE')
    assert hasattr(FourTubeBaseIE, '_TKN_HOST')

# Generated at 2022-06-12 17:33:02.553849
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-12 17:33:10.154640
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # The PornerBrosIE class is a subclass of FourTubeBaseIE
    # and thus has the same constructor signature
    ie = PornerBrosIE(None, None)
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert PornerBrosIE.__name__ == 'PornerBrosIE'
    assert PornerBrosIE.__doc__ is not None
    assert hasattr(ie, '_TKN_HOST')
    assert hasattr(ie, '_URL_TEMPLATE')

# Generated at 2022-06-12 17:33:13.943891
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    assert(FourTubeIE.__name__ == "FourTubeIE")


# Generated at 2022-06-12 17:33:20.733073
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    e = FourTubeBaseIE()
    assert e._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert e._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert e._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-12 17:33:25.298112
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except NameError as e:
        # If the exception is not what we expect, then we have a real problem
        assert 'PornerBrosIE' == e.args[0].split()[0]
        print('Oops, PornerBrosIE could not be created')
    else:
        print('PornerBrosIE was created')

test_PornerBrosIE()

# Generated at 2022-06-12 17:33:28.536456
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Simulate no exception raised by class FourTubeBaseIE
    assert FourTubeBaseIE(FourTubeIE)

# Generated at 2022-06-12 17:33:29.237318
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pass