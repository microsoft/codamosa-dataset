

# Generated at 2022-06-12 17:25:12.650613
# Unit test for constructor of class FuxIE
def test_FuxIE():
    data = """<button data-quality="720p" data-id="12345" data-token="abcdef" data-filename="The%20Video%20Title%20-%201234">720p</button>"""
    assert FuxIE._TKN_HOST == "token.fux.com"
    assert FuxIE._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:25:14.240960
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    assert ie


# Generated at 2022-06-12 17:25:15.777016
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()._download_json('http://example.com/')

# Generated at 2022-06-12 17:25:17.868883
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    d = FourTubeIE()
    assert d.IE_NAME == '4tube'


# Generated at 2022-06-12 17:25:27.661560
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-12 17:25:34.353996
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    video = FuxIE().url_result(url)
    assert video.display_id == 'awesome-fucking-kitchen-ends-cum-swallow'
    assert video.id == '195359'
    assert video.title == 'Awesome fucking in the kitchen ends with cum swallow'
    assert video.uploader == 'alenci2342'
    assert video.uploader_id == 'alenci2342'

# Generated at 2022-06-12 17:25:40.158204
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    config = {'api_url_tpl': 'http://example.com/api/'}
    ie = FourTubeIE(config)
    assert ie._build_url('http://foo/bar/') == 'http://example.com/api/foo/bar/'
    ie = FourTubeIE()
    assert ie._build_url('http://foo/bar/') == 'http://foo/bar/'

# Generated at 2022-06-12 17:25:41.821519
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
	FourTubeBaseIE();


# Generated at 2022-06-12 17:25:49.364652
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE({})
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:25:54.244874
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-12 17:26:24.608646
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()

# Generated at 2022-06-12 17:26:27.458171
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie = PornTubeIE("http://www.porntube.com/embed/7089759")

# Generated at 2022-06-12 17:26:29.036045
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test constructor of class FourTubeBaseIE
    FourTubeBaseIE()


# Generated at 2022-06-12 17:26:33.837992
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """ The test to check the instance of class FourTubeBaseIE """
    a = FourTubeBaseIE()
    assert a._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:26:35.059096
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().ie_key() == 'Fux'

# Generated at 2022-06-12 17:26:43.975495
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    # Make sure we're testing the right class
    assert(i.__class__.__name__ == 'PornTubeIE')
    # Make sure the _TESTS variable exists
    assert(i._TESTS)
    # Make sure it's a list
    assert(isinstance(i._TESTS, list))
    # Make sure the list is not empty
    assert(i._TESTS)
    # Make sure the list contains dicts
    # Only the first dict will be tested:
    assert(isinstance(i._TESTS[0], dict))
    # Make sure the mandatory keys are present in the dict
    # Only the first dict will be tested:
    assert('url' in i._TESTS[0])
    # Check if the url starts with http

# Generated at 2022-06-12 17:26:51.951050
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-12 17:26:52.670433
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE() == 'FuxIE'

# Generated at 2022-06-12 17:26:53.945482
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtubeIE = FourTubeIE()
    assert fourtubeIE.IE_NAME == '4tube'

# Generated at 2022-06-12 17:27:00.784581
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()
    assert i._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert i._TKN_HOST == 'token.4tube.com'
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-12 17:28:05.132885
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Set up the arguments for the test
    yt_main_page_url     = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    #yt_embed_page_url    = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    #yt_mobile_page_url   = "https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"

    # Instantiate the class with the arguments
    test_yt_ie = PornerBrosIE()

    # Call the function


# Generated at 2022-06-12 17:28:09.670284
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    try:
        unittest.TestCase.assertIsNotNone
    except AttributeError:
        unittest.TestCase.assertIsNotNone = unittest.TestCase.assertNotEqual

    unittest.TestCase.assertIsNotNone(
        PornerBrosIE._VALID_URL,
        'PornerBrosIE._VALID_URL is not valid')
    print(PornerBrosIE._VALID_URL)

# Generated at 2022-06-12 17:28:11.021276
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()
    FourTubeBaseIE()
    PornTubeIE()
    PornerBrosIE()
    FourTubeIE()

# Generated at 2022-06-12 17:28:16.059777
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import determine_ext, gdata, scte, streamable, vidme

    FourTubeIE._ALLOW_EMBED_PREFERRED = True

    FourTubeIE._ALLOW_EMBED_MAP = {
        'vidme': vidme.VidmeIE,
    }

    FourTubeIE._ALLOW_EMBED_MAP.update({
        ie.ie_key(): ie for ie in (
            gdata.GooglePlusIE,
            streamable.StreamableIE,
            scte.SCTEIE,
        )
    })
    FourTubeIE._ALLOW_EMBED = FourTubeIE._ALLOW_EMBED_MAP.keys()

    FourTubeIE._TEMPLATE_URL = 'https://www.4tube.com/videos/{id}/video'
   

# Generated at 2022-06-12 17:28:17.019495
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(69)

# Generated at 2022-06-12 17:28:17.790197
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None, {})

# Generated at 2022-06-12 17:28:19.477170
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestClass(FourTubeBaseIE):
        _VALID_URL = r'(?P<id>\d+)'
    TestClass()

# Generated at 2022-06-12 17:28:20.329755
# Unit test for constructor of class FuxIE
def test_FuxIE():
		FuxIE()._URL_TEMPLATE

# Generated at 2022-06-12 17:28:21.635701
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:28:25.746997
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    PornerBrosIE('https://www.pornerbros.com/embed/181369')
    PornerBrosIE('https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-12 17:29:37.794989
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:29:42.257446
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    instance = PornTubeIE()
    result_for_url = instance._real_extract(url)
    assert(result_for_url['id'] == '7089759')

# Generated at 2022-06-12 17:29:43.642182
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    n = PornerBrosIE()



# Generated at 2022-06-12 17:29:53.666581
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ft = FourTubeIE()
    access_key = 'YXBpX2tleT0xMzUxMjU1ODIwMjg5NzExMzAwMA=='
    # Check is oauth_token_secret OK
    oauth_token_secret = ft._b64encode('oauth_token_secret=4b950f841d1fbc996e4c87ce99df4215')
    assert(oauth_token_secret == access_key)
    # Decode base64 OK?
    access_key_decoded = ft._b64decode(access_key)
    assert(access_key_decoded == 'api_key=13512558202897113000')



# Generated at 2022-06-12 17:29:54.481869
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-12 17:29:56.163417
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    t = PornerBrosIE()

# Generated at 2022-06-12 17:30:01.082072
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert fourtubeIE == FourTubeIE
    assert fuxIE == FuxIE
    assert porntubeIE == PornTubeIE
    assert pornerbrosIE == PornerBrosIE

# Generated at 2022-06-12 17:30:02.056834
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:30:03.161154
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE('PornTube')
    assert obj is not None

# Generated at 2022-06-12 17:30:10.436061
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-12 17:31:56.937596
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE(4)

    try:
        assert(isinstance(info_extractor, InfoExtractor))
    except AssertionError:
        print("test_FourTubeIE failed")


# Generated at 2022-06-12 17:31:58.457645
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(PornTubeIE.ie_key(), PornTubeIE.ie_key()).ie_key() == PornTubeIE.ie_key()

# Generated at 2022-06-12 17:32:05.177177
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Test constructor of class PornerBrosIE."""
    test_class = "PornerBros"

# Generated at 2022-06-12 17:32:06.077486
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'


# Generated at 2022-06-12 17:32:10.223477
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        import tests.test_utils
    except ImportError:
        pass
    else:
        tests.test_utils.initialize()
        tests.test_utils.inject_mock('download_json', 'download_json')
        # This test function has side-effect and should be run only once
        test_FourTubeBaseIE.__test__ = False
        test_FourTubeBaseIE()


# Generated at 2022-06-12 17:32:15.887338
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Basic test cases to see if FourTubeIE is constructed properly
    """

    tt = FourTubeIE()

    assert tt.IE_NAME == '4tube'
    assert tt._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert tt._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert tt._TKN_HOST == 'token.4tube.com'
    assert tt._TESTS is not None

# Generated at 2022-06-12 17:32:16.356361
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:32:20.666759
# Unit test for constructor of class FuxIE
def test_FuxIE():
  fuxIE = FuxIE()

  assert fuxIE._TKN_HOST == 'token.fux.com'
  assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
  assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
  assert fuxIE.ie_key() == 'Fux'

# Generated at 2022-06-12 17:32:26.051313
# Unit test for constructor of class FuxIE
def test_FuxIE():
    constr = FuxIE()
    assert constr.IE_NAME == '4tube'
    assert constr.IE_DESC == '4Tube and Fux'
    assert constr.VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert constr.URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert constr.TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:32:27.115683
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    inst = PornTubeIE()
    assert inst.IE_NAME == '4tube'
