

# Generated at 2022-06-12 17:25:08.246092
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # (str) -> None
    """Unit test for constructor of class PornerBrosIE"""
    # assert eval('PornerBrosIE._VALID_URL')
    # assert eval('PornerBrosIE._URL_TEMPLATE')
    # assert eval('PornerBrosIE._TKN_HOST')
    # assert eval('PornerBrosIE._TESTS')
    print("Unit test for PornerBrosIE passed!")



# Generated at 2022-06-12 17:25:09.639508
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()

# Generated at 2022-06-12 17:25:10.834284
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    e=FourTubeIE()
    e.IE_NAME

# Generated at 2022-06-12 17:25:12.863373
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/embed/181369')

# Generated at 2022-06-12 17:25:14.024608
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    m = PornerBrosIE()


# Generated at 2022-06-12 17:25:25.330153
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE(None)
    assert ie.IE_NAME == '4tube:fux'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-12 17:25:26.201747
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)

# Generated at 2022-06-12 17:25:35.537361
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    ie_fux = FuxIE()
    ie_porntube = PornTubeIE()
    ie_pornerbros = PornerBrosIE()
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie_fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-12 17:25:46.915671
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    o = FourTubeIE()
    string = r'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    s = o.extract(string)
    assert s['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert s['id'] == 'WCP Club'
    assert s['uploader'] == 'WCP Club'
    assert s['uploader_id'] == 'wcp-club'
    assert s['upload_date'] == '20131031'
    assert s['timestamp'] == 1383263892
    assert s['duration'] == 583
    assert s['view_count'] == int
    assert s['like_count'] == int

# Generated at 2022-06-12 17:25:51.724006
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	assert PornTubeIE._TESTS[0]['url'] == "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
	assert PornTubeIE._TESTS[0]['info_dict']['id'] == "7089759"
	assert PornTubeIE._TESTS[0]['info_dict']['ext'] == "mp4"
	assert PornTubeIE._TESTS[0]['info_dict']['title'] == "Teen couple doing anal"
	assert PornTubeIE._TESTS[0]['info_dict']['uploader'] == "Alexy"
	assert PornTubeIE._TESTS[0]['info_dict']['uploader_id'] == "91488"

# Generated at 2022-06-12 17:26:09.811029
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .common import ExtractorError
    from .common import compat_str
    instance = InfoExtractor(compat_str('FourTubeBaseIE'))
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:26:18.731945
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TESTS == TestCase._TESTS
    TestCase._TESTS = {}

    TestCase.register_ie(FourTubeBaseIE)
    TestCase.register_ie(FourTubeIE)
    TestCase.register_ie(FuxIE)
    TestCase.register_ie(PornTubeIE)
    TestCase.register_ie(PornerBrosIE)
    TestCase.register_ie(PornerBrosIE)

    suite = unittest.TestSuite()
    for testcase in TestCase._TESTS.values():
        suite.addTest(unittest.makeSuite(testcase))

    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-12 17:26:19.774834
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == ie._VALID_URL

# Generated at 2022-06-12 17:26:22.325789
# Unit test for constructor of class FuxIE
def test_FuxIE():
	pass



# Generated at 2022-06-12 17:26:28.910120
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == PornerBrosIE._VALID_URL
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:26:35.710644
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_downloader import get_testcases, get_testcase_exception

    # Since PornTubeIE extends FourTubeBaseIE, we only need test it once

# Generated at 2022-06-12 17:26:36.704013
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE

# Generated at 2022-06-12 17:26:40.907794
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE(5)
    assert i != None
    # unit test for url_or_none function
    url = url_or_none(5)
    assert url == None
    url = url_or_none('https://www.porntube.com/embed/7089759')
    assert url =='https://www.porntube.com/embed/7089759'

# Generated at 2022-06-12 17:26:42.546724
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 17:26:43.607230
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(None)

# Generated at 2022-06-12 17:27:19.418634
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-12 17:27:29.196573
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_instance = PornerBrosIE()
    assert test_instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert test_instance._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert test_instance._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:27:29.604772
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:27:29.976349
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:27:31.325893
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    t = FourTubeBaseIE()
    assert t is not None

# Generated at 2022-06-12 17:27:33.612755
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(FuxIE._download_webpage, FuxIE._search_regex)

# Generated at 2022-06-12 17:27:34.317585
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:27:35.937579
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:27:39.290789
# Unit test for constructor of class FuxIE
def test_FuxIE():
    global fuxIE
    fuxIE = FuxIE('FuxIE', {'ie': 'Fux'}, 'Fux')
    assert fuxIE.ie_key() == 'Fux'


# Generated at 2022-06-12 17:27:45.609680
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE("https://www.porntube.com/embed/7089759")
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:29:01.897337
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-12 17:29:03.841730
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE('test_FourTubeBaseIE', 'test_FourTubeBaseIE')
    except:
        pass

# Generated at 2022-06-12 17:29:05.593986
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:29:09.495313
# Unit test for constructor of class FuxIE
def test_FuxIE():
    constructor = FuxIE._get_class_for_kind('www')
    assert constructor.__name__ == 'FuxIE'

    FuxIE._get_class_for_kind('m')
    assert constructor.__name__ == 'FuxIE'

# Generated at 2022-06-12 17:29:10.182725
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:29:13.965056
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    result = PornTubeIE()._extract_urls(url, False)
    assert result == ['7089759']

if __name__ == '__main__':
    # test_PornTubeIE()
    pass

# Generated at 2022-06-12 17:29:18.842338
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert 'porntube.com' in ie._VALID_URL
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:29:23.522964
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.get_tkn_host() == 'token.fux.com'
    assert fux.get_url_template() == 'https://www.fux.com/video/%s/video'


# Generated at 2022-06-12 17:29:25.241389
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Test if the constructor doesn't crash"""
    # No error should be returned
    FuxIE()

# Generated at 2022-06-12 17:29:25.931395
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:32:30.628908
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    if __name__ == '__main__':
        from . import _test_fourtube_baseie
        _test_fourtube_baseie.run()

# Generated at 2022-06-12 17:32:33.049300
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('http://www.porntube.com/')

# Generated at 2022-06-12 17:32:35.700490
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE(None, None)
    assert obj._TKN_HOST == 'token.fux.com'
    assert obj._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-12 17:32:37.554782
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import pornhub
    print("testing PornTubeIE")
    if not pornhub.__name__ == '__main__':
        from . import pornhub
        print("testing PornTubeIE")
    if pornhub.__name__ == '__main__':
        print("testing PornTubeIE")

# Generated at 2022-06-12 17:32:38.191143
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('url')

# Generated at 2022-06-12 17:32:38.984805
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(True)

# Generated at 2022-06-12 17:32:50.210376
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test with URL
    try:
        # Create instance of FourTubeIE
        inst = FourTubeIE("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
        assert inst.ie_key() == "4tube"
        assert inst.ie_url() == "4tube.com"
        assert inst.ie_name() == "4tube"
        assert inst.ie_description() == "4tube.com"
    except:
        assert False, "Error instantiating FourTubeIE from URL"

    # Test with ID

# Generated at 2022-06-12 17:32:52.530956
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    const = PornerBrosIE()
    print(const.__class__.__name__)
    print(const._VALID_URL)


# Generated at 2022-06-12 17:32:55.516406
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    print(ie._PORN_TUBE_HOST)
    print(ie._search_regex)

# Generated at 2022-06-12 17:33:02.751914
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # test case input
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

    # exptected result