

# Generated at 2022-06-12 17:25:13.178161
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-12 17:25:15.154747
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == 'fux'


# Generated at 2022-06-12 17:25:17.143180
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    print(x.__class__.__name__)

# Generated at 2022-06-12 17:25:24.180291
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = FuxIE()
    assert(IE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(IE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video')
    assert(IE._TKN_HOST == 'token.fux.com')
    assert(IE.ie_key() == 'Fux')
    assert(IE.ie_name() == 'fux')
    assert(IE.ie_desc() == 'fux.com')


# Generated at 2022-06-12 17:25:33.987502
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.suitable('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    ie.suitable('https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    ie.suitable('https://www.4tube.com/embed/209733')
    ie.suitable('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    ie.suitable('https://www.4tube.com/videos/209733')

# Unit

# Generated at 2022-06-12 17:25:41.200866
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():

        url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
        pt_ie = PornTubeIE()
        webpage = pt_ie._download_webpage(url, "display_id")
        video_data = pt_ie._parse_json(
            pt_ie._search_regex(
                r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
                webpage, 'data', group='value'), "video_id",
            transform_source=lambda x: compat_urllib_parse_unquote(
                compat_b64decode(x).decode('utf-8')))['page']['video']
        assert video_data['mediaId'] == "4772840"


# Generated at 2022-06-12 17:25:43.776884
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-12 17:25:45.857705
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()
    assert inst._TKN_HOST == "token.pornerbros.com"

# Generated at 2022-06-12 17:25:46.827972
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-12 17:25:48.317732
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert('PornerBrosIE' in globals())


# Generated at 2022-06-12 17:26:23.960456
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()

# Generated at 2022-06-12 17:26:25.172057
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-12 17:26:27.027392
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()._extract_formats(None, None, None, None)

# Generated at 2022-06-12 17:26:32.075325
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for test in FourTubeIE._TESTS:
        video_url = test['url']
        video_id = test['info_dict']['id']
        media_id = test['info_dict']['title']
        sources = test['info_dict']['uploader']
        formats = test['info_dict']['uploader_id']
        timestamp = test['info_dict']['timestamp']
        duration = test['info_dict']['duration']
        like_count = test['info_dict']['like_count']
        view_count = test['info_dict']['view_count']
        categories = test['info_dict']['categories']
        thumbnail = test['info_dict']['thumbnail']
        age_limit = test['info_dict']['age_limit']

# Generated at 2022-06-12 17:26:37.807558
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-12 17:26:43.573975
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    yt_ie = FourTubeIE()
    assert yt_ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert yt_ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-12 17:26:51.619126
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_url = "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    test_video_id = "209733"
    test_media_id = "8624201"
    test_sources = ["360", "480", "720", "1080"]
    test_pattern = re.compile(r'https?://(?:www\.)?4tube\.com/(?:embed/)?(?P<id>\d+)')

# Generated at 2022-06-12 17:26:52.340441
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-12 17:27:01.679319
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeBaseIE._VALID_URL == \
        r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-12 17:27:03.203128
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE



# Generated at 2022-06-12 17:27:37.372874
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    params = {'url': 'https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
              'only_matching': True}
    PornerBrosIE()._real_extract(**params)

# Generated at 2022-06-12 17:27:39.420373
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test = PornerBrosIE()
    assert test._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:27:40.072780
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-12 17:27:40.847503
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test = PornTubeIE()

# Generated at 2022-06-12 17:27:42.514664
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:27:43.754080
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'


# Generated at 2022-06-12 17:27:48.713093
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBase = FourTubeBaseIE()
    assert fourTubeBase._VALID_URL is None
    assert fourTubeBase._URL_TEMPLATE is None
    assert fourTubeBase._TKN_HOST is None
    assert fourTubeBase._TESTS == []

# Generated at 2022-06-12 17:27:54.348169
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Create an instance of PornerBrosIE
    _instance = PornerBrosIE()
    # Check that it is a FourTubeBaseIE
    assert isinstance(_instance, FourTubeBaseIE)
    # Check that constuctor sets correct params
    assert _instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert _instance._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'



# Generated at 2022-06-12 17:27:56.028629
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__bases__ == (InfoExtractor,)

# Generated at 2022-06-12 17:28:02.827314
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    PornerBrosIE is a subclass of FourTubeBaseIE and the only difference
    is in the following function call,
    self._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        webpage, 'data', group='value').
    """
    porner_bros_instance = PornerBrosIE()

# Generated at 2022-06-12 17:29:21.961654
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from . import PornerBrosIE
    PornerBrosIE('PornerBrosIE', 'PornerBrosIE.py', '4')

# Generated at 2022-06-12 17:29:27.486867
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE._TKN_HOST = 'token.4tube.com'
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeBaseIE._VALID_URL, url)
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    FourTubeBaseIE._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    # from here, it gets into _real_extract()
    # but the call to _download_webpage() and _search_regex()
    # fails. for this test, we will create the webpage and video variables
   

# Generated at 2022-06-12 17:29:36.062111
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from youtube_dl.extractor import SearchInfoExtractor
    from youtube_dl.tests.test_search_extractor_common import fake_output_py
    from youtube_dl.utils import std_headers
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.extractor.common import InfoExtractor

    # Variables for passing to constructor of FourTubeIE
    ie_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeIE(ie_url)

    # We are testing FourTubeIE, so dummy url should match regex

# Generated at 2022-06-12 17:29:38.246454
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    if (fuxIE == None):
        raise AssertionError("IT'S NOTHING")

# Generated at 2022-06-12 17:29:43.018870
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    expected_id  = '209733'
    video_id = FourTubeBaseIE()._match_id(url)
    assert video_id == expected_id

# Generated at 2022-06-12 17:29:50.604186
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb = PornerBrosIE()
    assert pb._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pb._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pb._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:29:58.612874
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    if not hasattr(test_FourTubeBaseIE, 'test_class'):
        test_FourTubeBaseIE.test_class = FourTubeBaseIE
    if not hasattr(FourTubeBaseIE, '_download_webpage'):
        FourTubeBaseIE._download_webpage = lambda self, *args, **kwargs: None
    if not hasattr(FourTubeBaseIE, '_search_regex'):
        FourTubeBaseIE._search_regex = lambda self, *args, **kwargs: 'test_value'
    if not hasattr(FourTubeBaseIE, '_html_search_meta'):
        FourTubeBaseIE._html_search_meta = lambda self, *args, **kwargs: 'test_value'
    if not hasattr(FourTubeBaseIE, '_parse_json'):
        FourTubeBase

# Generated at 2022-06-12 17:30:01.118423
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-12 17:30:03.255547
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('http://www.4tube.com/embed/209733')

# Generated at 2022-06-12 17:30:10.506537
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-12 17:33:37.139084
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from youtube_dl.utils import parse_duration

    # Test no exception thrown
    info_dict = {}
    ie = FourTubeIE(None)
    ie._process_info(info_dict)

    # Test except thrown for missing duration
    info_dict['duration'] = None
    try:
        ie._process_info(info_dict)
    except:
        pass
    else:
        raise Exception('assertion failed')

    # Test except not thrown with duration
    info_dict['duration'] = parse_duration('12:34')
    try:
        ie._process_info(info_dict)
    except:
        raise Exception('assertion failed')

# Generated at 2022-06-12 17:33:40.399237
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxFile = FuxIE()
    assert(fuxFile._TKN_HOST == 'token.fux.com')
    fuxFile = FuxIE("fux")
    assert(fuxFile._TKN_HOST == 'token.fux.com')

# Generated at 2022-06-12 17:33:41.840251
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
        The constructor can be called without errors
    """
    PornTubeIE()


# Generated at 2022-06-12 17:33:42.770307
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-12 17:33:46.017321
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None)._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE(None)._TKN_HOST == 'token.4tube.com'
    assert FuxIE(None)._TKN_HOST == 'token.fux.com'
    assert PornTubeIE(None)._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-12 17:33:52.587004
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test whether passing a 4tube.com link creates the right object
    FourTubeBaseIE('FourTubeBaseIE', FourTubeIE, ['https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'])
    # Test whether passing a fux.com link creates the right object
    FourTubeBaseIE('FourTubeBaseIE', FuxIE, ['https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'])
    # Test whether passing a porntube.com link creates the right object
    FourTubeBaseIE('FourTubeBaseIE', PornTubeIE, ['https://www.porntube.com/embed/7089759'])
    # Test whether passing a pornerb

# Generated at 2022-06-12 17:33:54.975675
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert any([isinstance(ie, FourTubeBaseIE) for ie in InfoExtractor._ies])

# Generated at 2022-06-12 17:33:56.971483
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert type(FourTubeIE('FourTube')) == FourTubeIE



# Generated at 2022-06-12 17:34:00.117725
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        obj = FourTubeIE()
    except Exception:
        assert False, "Constructor of class FourTubeIE threw Exception"


# Generated at 2022-06-12 17:34:05.306949
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    potential_constructors = [PornerBrosIE]
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    for IE in potential_constructors:
        ie = IE()
        if ie.suitable(url) and ie.IE_NAME in url:
            assert ie.IE_NAME == 'pornerbros'