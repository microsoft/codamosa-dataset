

# Generated at 2022-06-24 12:16:15.223967
# Unit test for constructor of class FuxIE
def test_FuxIE():
    core = InfoExtractor()
    tester = FuxIE(core)
    assert tester._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:16:18.774283
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie is not None


# Generated at 2022-06-24 12:16:20.340476
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == 'generic'

# Generated at 2022-06-24 12:16:21.765535
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornTubeIE('video/181369') == PornerBrosIE

# Generated at 2022-06-24 12:16:30.344537
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import unittest
    from . import PornTubeIE

    class PornTubeIETest(unittest.TestCase):
        def test_constructor(self):
            url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
            (ie, video_id) = PornTubeIE._extract_url_info(url)
            self.assertEqual(ie.name, 'PornTube')
            self.assertEqual(video_id, '7089759')

    test_suite = unittest.TestSuite()
    test_suite.addTests(unittest.makeSuite(PornTubeIETest))
    return test_suite



# Generated at 2022-06-24 12:16:31.634583
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:16:32.156620
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-24 12:16:34.192856
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE("https://www.pornerbros.com/videos/pretty-black-girl-takes-a-dick-in-the-bathroom_155918")


# Generated at 2022-06-24 12:16:35.553319
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()



# Generated at 2022-06-24 12:16:36.819446
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-24 12:16:46.035205
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    global tokens
    global sources
    global FourTubeIE
    global FuxIE
    global PornTubeIE
    global PornerBrosIE
    global media_id
    global FourTubeBaseIE
    global video_id
    global urls
    global FourTubeIE
    global FuxIE
    global PornTubeIE
    global PornerBrosIE
    global media_id
    global FourTubeBaseIE
    global video_id
    global urls
    global FourTubeIE
    global FuxIE
    global PornTubeIE
    global PornerBrosIE
    global media_id
    global FourTubeBaseIE
    global video_id
    global urls

# Generated at 2022-06-24 12:16:46.897817
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-24 12:16:48.295980
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE, FourTubeBaseIE)


# Generated at 2022-06-24 12:16:55.587556
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test Firefox emulation with no proxy.
    # (proxy_* fields are not available in compat.strptime)
    emu = 'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0'
    with compat_urllib_request.urlopen(
            # Default timeout: 15 seconds
            compat_urllib_request.Request(FourTubeBaseIE._TEST_URL, headers={'User-Agent': emu})) as res:
        # Check if User-Agent is as expected on server.
        assert emu.split(' ')[0] == res.info().get_all('Server')[0].split(' ')[0]
    # Test Firefox emulation with proxy.

# Generated at 2022-06-24 12:16:56.257476
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()

# Generated at 2022-06-24 12:17:02.009940
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # create dummy file from which input data is parsed
    from io import BytesIO
    from subprocess import call
    import urllib
    import json
    import re

    test_url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    search_string = "%22_181369"
    search_string_2 = "%22_1"
    # this is actually the webpage of the test_url

# Generated at 2022-06-24 12:17:03.017238
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert(FourTubeBaseIE != None)

# Generated at 2022-06-24 12:17:04.094310
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FuxIE.ie_key())

# Generated at 2022-06-24 12:17:14.790482
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Args:
    #   ie: The class of the InfoExtractor to be tested
    #   video_id: id of video to download
    #   expected_data: expected result of the _extract_formats method
    def test_FourTubeBaseIE_extract_formats(ie, video_id, expected_data):
        fake_token_url = ('https://%s/fake_media_id/desktop/' % ie._TKN_HOST) + '+'.join(expected_data.get('sources'))
        expected_result = expected_data.get('formats')

        # Mock the _download_webpage and _extract_formats method
        def _download_webpage(*args, **kwargs):
            return expected_data.get('data')


# Generated at 2022-06-24 12:17:16.549956
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.IE_NAME = 'Generic'
    assert ie.IE_NAME == 'Generic'

# Generated at 2022-06-24 12:17:20.283930
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    'Test for an entry point of class FourTubeBaseIE'
    assert 'FourTubeBaseIE' in globals()
    assert 'FourTubeIE' in globals()
    assert 'FuxIE' in globals()
    assert 'PornTubeIE' in globals()
    assert 'PornerBrosIE' in globals()

# Generated at 2022-06-24 12:17:29.977264
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert(ie.IE_NAME == "4tube")
    assert(ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(ie._TKN_HOST == 'token.4tube.com')

# Generated at 2022-06-24 12:17:31.176465
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:17:36.072690
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('https://www.pornerbros.com/embed/181369')
    # init_url
    assert ie.init_url == 'https://www.pornerbros.com/videos/video_181369'
    # video_id
    assert ie.video_id == '181369'

# Generated at 2022-06-24 12:17:44.906408
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f4i = FourTubeBaseIE()
    assert f4i._TKN_HOST == 'token.4tube.com'
    assert f4i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert f4i._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert f4i.IE_DESC == '4Tube'
    assert f4i.IE_NAME == '4tube'

# Generated at 2022-06-24 12:17:53.768296
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE.__dict__['_TKN_HOST'] = 'token.fux.com'
    ins = FuxIE()
    assert ins._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ins._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'


# Generated at 2022-06-24 12:17:56.661317
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    assert YoutubeIE.__bases__ == (InfoExtractor,)
    assert FourTubeBaseIE.__bases__ == (InfoExtractor,)

# Generated at 2022-06-24 12:17:57.942313
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:18:02.565306
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-24 12:18:12.269989
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()

    ie = PornTubeIE(ydl)
    assert ie.IE_NAME == 'PornTube'
    assert ie.ie._VALID_URL == PornTubeIE._VALID_URL
    assert ie.ie._URL_TEMPLATE == PornTubeIE._URL_TEMPLATE
    assert ie.ie._TKN_HOST == PornTubeIE._TKN_HOST
    assert PornTubeIE._TESTS == ie.ie._TESTS
    assert PornTubeIE._TKN_HOST == ie.ie._TKN_HOST

# Generated at 2022-06-24 12:18:19.660381
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x._ENCRYPTION_KEY == '4tB64NnbkDFpE9oZ'
    assert x._CSRF_TOKEN_FETCH_PATH == '/csrf_token'
    assert x._TKN_HOST == 'tkn.porntube.com'
    assert x._TKN_PATH == '%s/%sp'
    assert x._PROTOCOL == 'https'
    assert x._FORMAT_KEYS[0] == 'url'
    assert x._FORMAT_KEYS[7] == 'format_id'
    assert x._FORMAT_KEYS[12] == 'resolution'
    return

# Generated at 2022-06-24 12:18:20.597042
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()
    # constructor test not as a unit test?

# Generated at 2022-06-24 12:18:33.222140
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_format_url = 'https://f001.4tube.com/%s/%s/%s.mp4'
    test_token_url = 'https://token.4tube.com/xW8c6q3/desktop/720.480.360.240.144'
    test_json = '{"720":{"token":"%s"},"480":{"token":"%s"},"360":{"token":"%s"},"240":{"token":"%s"},"144":{"token":"%s"}}'

# Generated at 2022-06-24 12:18:34.182459
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from  youtube_dl.extractor import PornTubeIE
    porn_tube_ie = PornTubeIE()

# Generated at 2022-06-24 12:18:36.569858
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.IE_NAME == 'fux'
    ie.IE_DESC == 'fux.com'

# Generated at 2022-06-24 12:18:38.427116
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Testing using a fake video
    # If this test fails, then new video need to be added
    x = PornTubeIE._real_extract('https://www.porntube.com/embed/7089759')
    assert x['id'] == '7089759'


# Generated at 2022-06-24 12:18:47.185421
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestTubeBaseIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?testtube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.testtube.com/videos/video_%s'
        _TKN_HOST = 'token.testtube.com'

    url = 'https://www.testtube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie = TestTubeBaseIE()
    mobj = ie._VALID_URL_RE.match(url)

# Generated at 2022-06-24 12:18:47.798520
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-24 12:18:58.139576
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_cases = [
        ('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
         '6516c8ac63b03de06bc8eac14362db4f'),
        ('https://www.4tube.com/embed/209733',
         '6516c8ac63b03de06bc8eac14362db4f')
    ]
    for url, md5 in test_cases:
        ie = FourTubeIE(None, {}, url)

# Generated at 2022-06-24 12:19:07.475886
# Unit test for constructor of class FuxIE
def test_FuxIE():
    #Arrange
    fuxIE = FuxIE()

    #Assert
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'
    assert fuxIE.IE_NAME == '4tube'

# Generated at 2022-06-24 12:19:08.806537
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-24 12:19:09.456256
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:19:10.908433
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    a = FourTubeIE();

# Generated at 2022-06-24 12:19:12.553774
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_obj = FourTubeBaseIE()
    assert test_obj._TKN_HOST == None

# Generated at 2022-06-24 12:19:13.752831
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Unit test for class FourTubeIE"""
    ie = FourTubeIE()

# Generated at 2022-06-24 12:19:24.558078
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:19:26.682573
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE()._VALID_URL == FourTubeIE._VALID_URL)


# Generated at 2022-06-24 12:19:27.332625
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-24 12:19:30.281399
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()._init(FourTubeBaseIE(), None)
    assert isinstance(instance, FourTubeIE)
    assert isinstance(instance, FourTubeBaseIE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:19:31.717037
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(FourTubeBaseIE())._WORKING = True


# Generated at 2022-06-24 12:19:32.456789
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:19:43.116541
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-24 12:19:48.996376
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    out = PornerBrosIE()
    assert out.IE_NAME == 'PornerBros'
    assert out._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:19:51.584150
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
        Make sure that FourTubeBaseIE's constructor is working fine
    """
    the_ie = FourTubeBaseIE()
    assert the_ie._VALID_URL is None

# Generated at 2022-06-24 12:20:01.817877
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    FourTubeBaseIE.register_ie('PornerBros', PornerBrosIE)
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE()._real_initialize()
    info_dict = PornerBrosIE()._real_extract(url)
    assert info_dict['id'] == '181369'
    assert info_dict['title'] == 'Skinny brunette takes big cock down her anal hole'
    assert info_dict['uploader'] == 'PornerBros HD'
    assert info_dict['uploader_id'] == 'pornerbros-hd'
    assert info_dict['timestamp'] == 1359527401
    assert info_

# Generated at 2022-06-24 12:20:03.218010
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()
    print('PornTubeIE constructor test passed')


# Generated at 2022-06-24 12:20:08.796258
# Unit test for constructor of class FuxIE
def test_FuxIE():
    video_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fux_ie = FuxIE(FuxIE.ie_key())
    info = fux_ie.extract(video_url)

    assert len(info['formats']) == 1
    assert info['formats'][0]['format_id'] == '720p'

# Generated at 2022-06-24 12:20:10.663587
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(FourTubeBaseIE.ie_key())
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:20:20.426279
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    # test if the 'https://www.4tube.com/videos/209733/video' is generated
    # with the expected id 209733 (same as in the url)
    assert ie._url_for_id(209733) == 'https://www.4tube.com/videos/209733/video'
    # test the correct validation
    assert ie.suitable(url)
    # test the correct extraction of the 'id'
    assert ie._id_from_url(url) == '209733'

# Generated at 2022-06-24 12:20:22.041733
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:24.074662
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test
    try:
        FourTubeIE()
    except Exception as e:
        print(str(e))

# Generated at 2022-06-24 12:20:31.945890
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE().suitable('https://www.porntube.com/embed/7089759') is True
    PornTubeIE().suitable('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406') is True
    PornTubeIE().suitable('https://m.porntube.com/videos/teen-couple-doing-anal_7089759') is True
    PornTubeIE().suitable('https://www.porntube.com/videos/teen-couple-doing-anal_7089759') is True
    PornTubeIE().suitable('http://www.youtube.com/watch?v=BaW_jenozKc') is False

# Unit Test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:20:35.714897
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from ytdl.extractor.FuxIE import FuxIE
    extractor = FuxIE()
    print(extractor)
    assert extractor != None


# Generated at 2022-06-24 12:20:39.997310
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
        PornTubeIE.suite()
    except:
        import traceback
        traceback.print_exc()
        raise



# Generated at 2022-06-24 12:20:46.205522
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    for url in ('https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
                'https://www.porntube.com/embed/7089759',
                'https://m.porntube.com/videos/teen-couple-doing-anal_7089759'):
        PornTubeIE(PornTubeIE._VALID_URL, url)

# Generated at 2022-06-24 12:20:47.441812
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    dir(PornerBrosIE)
    obj = PornerBrosIE()

# Generated at 2022-06-24 12:20:49.529915
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Verify not a subclass of FourTubeIE
    assert not issubclass(FuxIE, FourTubeIE)

# Generated at 2022-06-24 12:20:52.499574
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:54.087529
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    assert i.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:56.393564
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE is not None

# Generated at 2022-06-24 12:20:57.590189
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-24 12:20:58.976276
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE();

# Generated at 2022-06-24 12:21:00.849031
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:05.969314
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extract = FourTubeBaseIE
    assert info_extract._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert info_extract._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert info_extract._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:08.588464
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert issubclass(FuxIE, InfoExtractor)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(FuxIE, object)


# Generated at 2022-06-24 12:21:20.735502
# Unit test for constructor of class FuxIE
def test_FuxIE():
    '''Test case for FuxIE'''
    video_url = 'https://www.fux.com/video/184927/awesome-fucking-with-an-amazing-teen'
    Fux_ie = FuxIE()._real_extract(video_url)

    assert Fux_ie['title'] == 'Awesome fucking with an amazing teen'

    '''
    The uploader name is not available in the page source, so we can
    assign this value to the uploader variable.
    '''
    assert Fux_ie['uploader'] == Fux_ie['uploader']
    assert Fux_ie['timestamp'] == 1406918784
    assert Fux_ie['duration'] == 239
    assert Fux_ie['like_count'] == int
    assert Fux_ie['age_limit']

# Generated at 2022-06-24 12:21:25.390283
# Unit test for constructor of class FuxIE
def test_FuxIE():
    a = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert a.url == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    assert a.ie_key() == 'Fux'



# Generated at 2022-06-24 12:21:27.801925
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'

# Generated at 2022-06-24 12:21:29.523440
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube = PornTubeIE()
    assert 'PornTube' in str(porn_tube)


# Generated at 2022-06-24 12:21:31.051528
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:21:36.445028
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    # assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:50.986504
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE().get_url_info('https://www.pornerbros.com/videos/too-cute-blonde-in-lingerie-gets-fucked-by-her-man_221026') == ('https://www.pornerbros.com/videos/too-cute-blonde-in-lingerie-gets-fucked-by-her-man_221026', False)
    assert PornerBrosIE().get_url_info('https://www.pornerbros.com/videos/video_221026') == ('https://www.pornerbros.com/videos/video_221026', True)

# Generated at 2022-06-24 12:22:01.776239
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor = FourTubeBaseIE()
    assert info_extractor.name == '4tube'
    assert info_extractor.ie_key() == '4tube'
    assert info_extractor.host == '4tube.com'

    info_extractor = FuxIE()
    assert info_extractor.name == 'fux'
    assert info_extractor.ie_key() == 'fux'
    assert info_extractor.host == 'fux.com'

    info_extractor = PornTubeIE()
    assert info_extractor.name == 'porntube'
    assert info_extractor.ie_key() == 'porntube'
    assert info_extractor.host == 'porntube.com'

    info_extractor = PornerBrosIE()
    assert info_extractor.name

# Generated at 2022-06-24 12:22:02.907311
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-24 12:22:11.217222
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros = PornerBrosIE()
    assert porner_bros._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert porner_bros._TESTS[0]['info_dict']['age_limit'] == 18 
    assert porner_bros._TESTS[1]['only_matching'] == True
    assert porner_bros._TESTS[2]['only_matching'] == True
    

# Generated at 2022-06-24 12:22:12.420405
# Unit test for constructor of class FuxIE
def test_FuxIE():

    #create instance
    FuxIE()

# Generated at 2022-06-24 12:22:15.975264
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie = PornTubeIE()
    ie = FuxIE()

# Generated at 2022-06-24 12:22:17.754366
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.limits is None

# Generated at 2022-06-24 12:22:25.378355
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """Test creation of PornTubeIE class object."""
    # Test with a valid URL
    porn_tube = PornTubeIE('PornTube')
    assert porn_tube.name == 'PornTube'
    assert porn_tube.ie_key() == 'PornTube'
    assert porn_tube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert porn_tube._TKN_HOST == 'tkn.porntube.com'
    assert porn_tube.IE_NAME == 'PornTube'

# Generated at 2022-06-24 12:22:26.325069
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()

# Generated at 2022-06-24 12:22:33.405257
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE("http://flv.pornerbros.com/videos_screenshots/100048/14/2/preview.mp4", None)
    url = ie.get_url("http://www.pornerbros.com/videos_screenshots/100048/14/2/preview.mp4", None)
    assert url == "http://www.pornerbros.com/videos/hot-babe-gets-a-hard-cock-in-her-ass_100048"

# Generated at 2022-06-24 12:22:36.408722
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    PornTubeIE()._real_extract(url)

# Generated at 2022-06-24 12:22:37.942863
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import sys
    sys.stderr.write("Test for pornhub constructor")

# Generated at 2022-06-24 12:22:38.638037
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-24 12:22:46.027435
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE == FourTubeBaseIE.construct_class(
        FourTubeBaseIE._TKN_HOST)
    assert FuxIE == FourTubeBaseIE.construct_class(FuxIE._TKN_HOST)
    assert PornTubeIE == FourTubeBaseIE.construct_class(PornTubeIE._TKN_HOST)
    assert PornerBrosIE == FourTubeBaseIE.construct_class(PornerBrosIE._TKN_HOST)

# Generated at 2022-06-24 12:22:47.459224
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    (FourTubeIE._TESTS[0])



# Generated at 2022-06-24 12:22:48.416264
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:22:51.066854
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    #Arrange
    import unittest
    from .FourTubeIE import FourTubeIE
    
    #Act
    fourtube = FourTubeIE()
    #Assert
    assert(fourtube is not None)

# Generated at 2022-06-24 12:22:52.740571
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE._VALID_URL, PornerBrosIE.IE_NAME)

# Generated at 2022-06-24 12:22:58.361312
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:23:05.231872
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import youtube_dl as yt
    ie = yt.extractor.PornTubeIE()
    assert ie.ie_key() == 'PornTube'
    assert ie.IE_NAME == 'PornTube'
    assert ie.ie._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'

# Generated at 2022-06-24 12:23:06.369704
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:23:10.617963
# Unit test for constructor of class FuxIE
def test_FuxIE():
    info = FuxIE()._call_api('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert info['id'] == '195359'


# Generated at 2022-06-24 12:23:11.826794
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:23:13.222871
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()
    assert test is not None

# Generated at 2022-06-24 12:23:25.354495
# Unit test for constructor of class FuxIE
def test_FuxIE():
    _V = FuxIE._VALID_URL
    assert re.match(_V, 'http://www.fux.com/video/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert re.match(_V, 'http://m.fux.com/video/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert re.match(_V, 'http://www.fux.com/video/209733/')
    assert re.match(_V, 'http://www.fux.com/video/209733')
    assert re.match(_V, 'https://www.fux.com/embed/209733')

# Generated at 2022-06-24 12:23:26.973806
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.IE_NAME == "4tube"

# Generated at 2022-06-24 12:23:36.151352
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Return True for valid video URL and False for invalid video URL.
    """
    obj = FourTubeIE()
    video1 = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    video2 = 'http://www.4tube.com/videos/abc/xyz'
    video3 = 'http://www.4tube.com/videos/209733'
    video4 = 'http://www.4tube.com/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-24 12:23:37.375467
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p.IE_NAME == 'PornTube'


# Generated at 2022-06-24 12:23:40.559920
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    for url in ['https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
                'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406']:
        x = PornTubeIE()
        y = x._real_extract(url)
        assert y['id']

# Generated at 2022-06-24 12:23:45.302869
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE._TESTS[0]['url'] == "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"


# Generated at 2022-06-24 12:23:55.794799
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test empty constructor
    test_obj = FourTubeBaseIE()
    assert(test_obj != None)
    print("Empty constructor passed")

    # Test constructor with url parameter
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    test_obj = FourTubeBaseIE(url)
    assert(test_obj != None)
    print("Constructor with url passed")

    # Test constructor with url and ie_key parameters
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie_key = 'PornerBros'
    test_obj = FourTubeBase

# Generated at 2022-06-24 12:24:06.432340
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    for url in [
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    ]:
        result = PornTubeIE()._real_extract(url)
        assert result['id'] == '7089759' or result['id'] == '1331406'
        assert result['uploader_id'] == '91488' or result['uploader_id'] == '665'
        assert result['timestamp'] == 1433595647 or result['timestamp'] == 1379685485
        assert result['duration'] == 5052 or result['duration'] == 851
        assert result['view_count'] == int
        assert result['like_count']

# Generated at 2022-06-24 12:24:15.296793
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    def _encode_callback(params):
        return compat_b64encode(compat_urllib_parse_urlencode(params).encode('utf-8'))

    def _downloader(params):
        return '{"page":{"video":{"title":"foo","mediaId":0,"encodings":[{"height":480},{"height":360}],"masterThumb":"https://example.com/thumbnail.jpg","user":{"username":"bar","id":42},"channel":{"name":"Baz","id":666},"likes":1,"dislikes":2,"playsQty":3,"durationInSeconds":4,"publishedAt":"2015-06-06T12:04:07+0000"}}}'

    ie = PornTubeIE()
    ie._download_json = _downloader

# Generated at 2022-06-24 12:24:18.254413
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)
    assert isinstance(ie, FourTubeBaseIE)
    assert ie._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:24:30.039368
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:24:30.884449
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.get_url()

# Generated at 2022-06-24 12:24:31.521705
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pass

# Generated at 2022-06-24 12:24:40.176523
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(['http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'])

# Generated at 2022-06-24 12:24:48.580485
# Unit test for constructor of class FuxIE
def test_FuxIE():
    t = FuxIE()
    t._TKN_HOST
    t._TESTS
    t._URL_TEMPLATE
    t._VALID_URL
    t._download_webpage
    t._extract_formats
    t._html_search_meta
    t._html_search_regex
    t._parse_json
    t._real_extract
    t._search_regex
    t._sort_formats
    t.IE_DESC
    t.IE_NAME
    t.test

# Generated at 2022-06-24 12:24:49.272186
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:24:57.697158
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FakeInfoExtractor(FourTubeBaseIE):
        IE_NAME = 'fake_name'
        _VALID_URL = r'https?://(?:www\.)?faux\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.faux.com/videos/video_%s'
        _TKN_HOST = 'token.faux.com'

        @property
        def _TEST(self):
            # This is to ensure that _TEST is defined as a class property
            return '_TEST'

    ie = FakeInfoExtractor()
    assert ie._TEST == '_TEST'
    assert ie.IE_NAME == 'fake_name'
    assert ie._VAL

# Generated at 2022-06-24 12:24:58.326369
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:25:01.924408
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME in [e.IE_NAME for e in gen_extractors()]
    assert ie.IE_NAME not in [e.IE_NAME for e in gen_extractors(False)]

# Generated at 2022-06-24 12:25:12.307278
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE._VALID_URL = r'https?:\/\/(?:(?P<kind>www|m)\.)?fux\.com\/(?:video|embed)\/(?P<id>\d+)(?:\/(?P<display_id>[^/?#&]+))?'
    FuxIE._URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    FuxIE._TKN_HOST = 'token.fux.com'
    assert re.match(FuxIE._VALID_URL, "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert re.match(FuxIE._VALID_URL, "https://www.fux.com/embed/195359")


# Generated at 2022-06-24 12:25:18.777389
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    a = PornerBrosIE("url", "kid", "title")
    assert a.ie_key() == "url"
    assert a.ie_key() == "kid"
    assert a.ie_key() == "title"

    a.add_ie("url", "kid", "title")
    assert a.ie_key("url") == "url"
    assert a.ie_key("kid") == "kid"
    assert a.ie_key("title") == "title"
    assert a._ADD_IE_TO_REGISTRY("url", "kid", "title")


# Generated at 2022-06-24 12:25:26.433491
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornTubeIE = PornTubeIE();
    try:
        pornTubeIE.IE_NAME
    except:
        assert False, "Can't access to IE_NAME"
    assert (pornTubeIE.IE_NAME == 'PornTube'), "IE_NAME is not valid"
    
    try:
        pornTubeIE._VALID_URL
    except:
        assert False, "Can't access to _VALID_URL"
    assert (pornTubeIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'), "VALID_URL is not valid"
    

# Generated at 2022-06-24 12:25:27.180058
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-24 12:25:31.633120
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Instantiate the object
    obj = FourTubeIE()

    # Check if required attributes are present
    assert all([hasattr(obj, a) for a in ['_VALID_URL', '_URL_TEMPLATE', '_TKN_HOST', '_TESTS']])

# Generated at 2022-06-24 12:25:37.564458
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?(?:4tube|fux|porntube|pornerbros)\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._TKN_HOST == 'token.(?:4tube|fux|porntube|pornerbros).com'

# Generated at 2022-06-24 12:25:42.010975
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	import sys
	from youtube_dl.utils import *
	from youtube_dl.downloader import *
	from youtube_dl.extractor import *
#	sys.exit()

	class DummyIE(FourTubeBaseIE):
		@classmethod
		def suitable(cls, url):
			return True

		@classmethod
		def working(cls):
			return True

	ie = DummyIE()
	assert ie.extract('hFZNGgTn4s4') == None


test_FourTubeIE()


# Generated at 2022-06-24 12:25:43.103238
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    t = PornerBrosIE()
    assert t._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:25:53.000180
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:25:54.890833
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TKN_HOST == "tkn.porntube.com"


# Generated at 2022-06-24 12:26:03.447961
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE(): 
    import unittest
    import PornTubeIE
    import FourTubeIE

    class TestFourTubeIE(unittest.TestCase):
        def setUp(self):
            self.FourTubeIE = FourTubeIE.FourTubeIE()
            self.PornTubeIE = PornTubeIE.PornTubeIE()

        # Tests if constructor works
        def test_constructor(self):
            self.assertIsNotNone(self.FourTubeIE)
            self.assertIsNotNone(self.PornTubeIE)
    
    unittest.main()

# Generated at 2022-06-24 12:26:07.311140
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:26:08.092660
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:26:19.397141
# Unit test for constructor of class FourTubeBaseIE