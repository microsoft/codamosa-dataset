

# Generated at 2022-06-24 12:16:26.297762
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest, inspect

    class PornerBrosIETest(unittest.TestCase):
        def setUp(self):
            self.ie = PornerBrosIE()

            def assertNotRegexp(first, second):
                raise self.assertRaisesRegexp(AssertionError, self._assertNotRegex)

            self._assertNotRegex = self.assertNotRegexp
            self.assertNotRegexp = assertNotRegexp

        def test_constructor(self):
            self.assertEqual(self.ie.ie_key(), 'PornerBros')
            self.assertEqual(self.ie.IE_NAME, 'PornerBros')
            self.assertEqual(self.ie.IE_DESC, 'PornerBros.com videos')

            base

# Generated at 2022-06-24 12:16:29.979755
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # This is just a Unit test for the constructor of class FourTubeIE.
    # The actual tests are in test_4tube.py
    # To see the actual tests:
    #   python -c "import test_4tube; test_4tube.main()"
    FourTubeIE('FourTube')


# Generated at 2022-06-24 12:16:31.165147
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    result = PornTubeIE()._real_initialize()
    assert result == 1

# Generated at 2022-06-24 12:16:35.880887
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie.IE_NAME == '4tube'
    

# Generated at 2022-06-24 12:16:45.072915
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    IE = FourTubeBaseIE()

# Generated at 2022-06-24 12:16:46.086135
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	return PornerBrosIE()

# Generated at 2022-06-24 12:16:48.119927
# Unit test for constructor of class FuxIE
def test_FuxIE():
	fuxIE = FuxIE()
	assert fuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:16:49.628632
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert FourTubeBaseIE() != None

# Generated at 2022-06-24 12:16:52.771559
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Test constructor of class PornerBrosIE
    """
    print("\nStart test\n")
    pm = PornerBrosIE()
    print("\nTest OK\n")
    return


# Generated at 2022-06-24 12:17:03.798172
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fuxIE = FuxIE()
    # Assert that the URL matches the regex
    regex_obj = re.compile(fuxIE._VALID_URL)
    m = regex_obj.match(url)
    assert m is not None
    # Assert that the URL is not a duplicate of PornTube
    pornTubeIE = PornTubeIE()
    pornTube_regex_obj = re.compile(pornTubeIE._VALID_URL)
    m = pornTube_regex_obj.match(url)
    assert m is None
    # Assert that the URL is not a duplicate of FourTube
    fourTubeIE = FourTubeIE()
    fourTube_regex_

# Generated at 2022-06-24 12:17:04.825894
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    return PornTubeIE()._TESTS[0]

# Generated at 2022-06-24 12:17:06.168305
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class XI(FourTubeBaseIE):
        pass
    a = XI()

# Generated at 2022-06-24 12:17:07.713648
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except Exception as e:
        assert e

# Generated at 2022-06-24 12:17:09.622770
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # This should not raise any exception
    FourTubeBaseIE()

# Generated at 2022-06-24 12:17:12.562595
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        assert FourTubeIE(None)
    except Exception as e:
        print(e)
        print("Unable to create instance of class FourTubeIE")

# Generated at 2022-06-24 12:17:13.572763
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test = FuxIE()

# Generated at 2022-06-24 12:17:15.108389
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test case is an instance of class PornerBrosIE
    assert isinstance(PornerBrosIE(), PornerBrosIE)

# Generated at 2022-06-24 12:17:18.994549
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import json
    from .PornTubeIE import PornTubeIE
    testObj = PornTubeIE()
    testString = '{"result": "SUCCESS", "data": {}}'
    result = testObj._parse_json(testString, '12345')
    assert(result == json.loads(testString))

# Generated at 2022-06-24 12:17:21.621766
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:www|m)\.pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:17:31.944788
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBase = FourTubeBaseIE
    # Test if the class correctly returns its class name
    assert fourTubeBase.getClass().__name__ == "FourTubeBaseIE"
    # Test if the class correctly returns its URL template
    assert fourTubeBase._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video"
    # Test if the class correctly returns its token host
    assert fourTubeBase._TKN_HOST == "token.4tube.com"
    # Test if the class correctly returns its valid URL
    assert fourTubeBase._VALID_URL == r"https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
   

# Generated at 2022-06-24 12:17:39.708664
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    global PornerBrosIE
    pornerbrosIE = PornerBrosIE()
    assert pornerbrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerbrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerbrosIE._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-24 12:17:49.748168
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test missing site info
    class TestTubeIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?testtube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.testtube.com/videos/video_%s'
        _TKN_HOST = 'token.testtube.com'

    try:
        TestTubeIE.suitable('https://www.testtube.com/videos/video_123')
        assert False
    except ExtractorError as e:
        err_msg = str(e)
        assert 'Missing site info' in err_msg
        assert 'TESTTUBE' in err_msg

# Generated at 2022-06-24 12:17:51.568301
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    fux.IE_NAME = 'NONE'
    fux.IE_DESC = 'NONE'
    assert fux.IE_NAME == 'NONE'
    assert fux.IE_DESC == 'NONE'

# Generated at 2022-06-24 12:17:54.726002
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._real_extract(url='https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:17:58.079577
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	fourtube = FourTubeIE()
	test = fourtube._TESTS[0]['url']
	print(fourtube._VALID_URL)
	print(test)
	print(re.match(fourtube._VALID_URL, test))

# Generated at 2022-06-24 12:18:04.128065
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_result = PornTubeIE()
    assert test_result.IE_NAME == 'porntube'


# Generated at 2022-06-24 12:18:05.184623
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie = FourTubeBaseIE()


# Generated at 2022-06-24 12:18:14.842933
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test scenario when 'kind' is not matched in _VALID_URL regex
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    ie = FourTubeIE('4tube:video', _VALID_URL)
    # Test scenario when 'kind' is matched in _VALID_URL regex
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:18:15.521590
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    print(ie)

# Generated at 2022-06-24 12:18:16.797257
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__doc__ == FourTubeBaseIE.__doc__

# Generated at 2022-06-24 12:18:20.693329
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

test_cases = [
    # Unit tests for constructor of class FourTubeIE
    (FourTubeIE, None),
    
    # Unit tests for constructor of class PornTubeIE
    (PornTubeIE, None),
    
    # Unit tests for constructor of class PornerBrosIE
    (PornerBrosIE, None),
]


# Generated at 2022-06-24 12:18:30.288444
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    print(FourTubeIE()._valid_url(url, ''))
    url = 'https://www.porntube.com/embed/7089759'
    print(PornTubeIE()._valid_url(url, ''))
    url = 'https://www.pornerbros.com/embed/181369'
    print(PornerBrosIE()._valid_url(url, ''))

# Generated at 2022-06-24 12:18:33.588329
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    print(obj.IE_NAME)
    print(obj._VALID_URL)
    print(obj._TKN_HOST)

# Generated at 2022-06-24 12:18:37.168546
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("FourTubeBaseIE", "4tube", "4tube.com")
    assert ie.name == "FourTubeBaseIE"
    assert ie.ie_key == "4tube"
    assert ie.host == "4tube.com"

# Generated at 2022-06-24 12:18:38.619254
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    print(pornerbros)

# Generated at 2022-06-24 12:18:47.044585
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # init all of the important values and then test
    # that the init method works
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeBaseIE(url)

    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:18:59.370003
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE("http://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow")
    fux_ie._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    fux_ie._URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    fux_ie._TKN_HOST = 'token.fux.com'

# Generated at 2022-06-24 12:19:00.661313
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'FuxIE'



# Generated at 2022-06-24 12:19:08.408266
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.suitable('4tube.com/embed/209733')
    ie.suitable('4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie.suitable('4tube.com/video/209733') == False
    assert ie.suitable('4tube.com/videos/209733') == False
    assert ie.suitable('4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black/') == False
    assert ie.suitable('4tube.com/videos/209733') == False


# Generated at 2022-06-24 12:19:09.037243
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:19:10.576239
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE is not None

# Generated at 2022-06-24 12:19:11.198282
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-24 12:19:17.966652
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:19:26.912128
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    if not hasattr(PornerBrosIE, '_download_webpage'):
        return
    ie = PornerBrosIE('http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    webpage = ie._download_webpage('http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    # Test PornerBrosIE constructor
    assert isinstance(ie, PornerBrosIE)
    assert isinstance(webpage, str)

# Generated at 2022-06-24 12:19:30.558909
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE._download_webpage = lambda self, url, video_id: url
    assert PornTubeIE()._download_webpage(
        'https://www.porntube.com/embed/7089759', '7089759') == 'https://www.porntube.com/embed/7089759'

# Generated at 2022-06-24 12:19:33.410325
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('4tube')
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-24 12:19:37.119089
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()._real_extract(
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:19:45.740759
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import pytest
    from youtube_dl.utils import ExtractorError
    with pytest.raises(ExtractorError) as excinfo:
        FuxIE().suitable('http://www.fux.com/video')
    assert str(excinfo.value) == 'Invalid URL: <urlopen error unknown url type: http>'
    with pytest.raises(ExtractorError) as excinfo:
        FuxIE().suitable('http://www.fux.com/video/')
    assert str(excinfo.value) == 'Invalid URL: <urlopen error unknown url type: http>'
    with pytest.raises(ExtractorError) as excinfo:
        FuxIE().suitable('http://www.fux.com/video/asdf')

# Generated at 2022-06-24 12:19:47.774708
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_pornhub_ie = PornTubeIE()


# Generated at 2022-06-24 12:19:55.162238
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    mobj = re.match(PornerBrosIE._VALID_URL, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    video_id, display_id = mobj.group('id', 'display_id')
    fourtube_ie = PornerBrosIE(PornerBrosIE._VALID_URL, None)
    return mobj, video_id, display_id, fourtube_ie

# Generated at 2022-06-24 12:20:01.077725
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE("https://www.porntube.com/embed/7089759")
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:20:09.656274
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ..jsinterp import JSInterpreter
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    webpage = download_webpage(url, '7089759')
    video = unescapeHTML(search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1', webpage, 'data', group='value'))
    data = compat_urllib_parse_unquote(b64decode(video).decode('utf-8'))
    JSInterpreter(data).extract_function('eval("(" + {} + ")")')

# Generated at 2022-06-24 12:20:10.779479
# Unit test for constructor of class FuxIE
def test_FuxIE():
	test = FuxIE()

# Generated at 2022-06-24 12:20:16.160798
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """Test PornTubeIE constructor."""
    # test instantiation
    try:
        PornTubeIE()
    except Exception:
        assert False
    # test params
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:20:18.350314
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(PornTubeIE.ie_key())._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:20:23.210369
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    ie._TKN_HOST = 'token.4tube.com'
    ie._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:20:28.118081
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_PornTubeIE import PornTubeIE
    from .test_PornTubeIE import PornTubeIE


__all__ = [
    'FourTubeIE', 'FuxIE', 'PornTubeIE', 'PornerBrosIE', 'test_PornTubeIE']

if __name__ == '__main__':
    test_PornTubeIE()

# Generated at 2022-06-24 12:20:31.599585
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:20:34.037278
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_class = FourTubeBaseIE({})
    assert isinstance(test_class, InfoExtractor)

# Generated at 2022-06-24 12:20:44.141689
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    um = {}
    parameters = {}
    parameters['tokens'] = [
        'h265-720p',
        'h265-540p',
        'h265-360p',
        'mp4-1080p',
        'mp4-720p',
        'mp4-540p',
        'mp4-360p',
        'webm-1080p',
        'webm-720p',
        'webm-540p',
        'webm-360p',
    ]
    parameters['_VALID_URL'] = FourTubeIE._VALID_URL
    parameters['_TKN_HOST'] = FourTubeIE._TKN_HOST
    parameters['_URL_TEMPLATE'] = FourTubeIE._URL_TEMPLATE


# Generated at 2022-06-24 12:20:48.989924
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE().IE_NAME == '4tube'

# Generated at 2022-06-24 12:21:01.871178
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxie = FuxIE()
    assert fuxie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:21:03.893045
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._VALID_URL
    assert FourTubeBaseIE._URL_TEMPLATE
    assert FourTubeBaseIE._TKN_HOST

# Generated at 2022-06-24 12:21:07.616955
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Test if the video is uploaded."""
    ie = FourTubeIE()
    ie.download("http://www.4tube.com/videos/239925/sunny-leone-and-sophia-santi-naughty-lesbians-in-the-pool")

# Generated at 2022-06-24 12:21:08.477610
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    return FourTubeIE()._TEST

# Generated at 2022-06-24 12:21:09.461566
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)

# Generated at 2022-06-24 12:21:10.422045
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE('PornTube') == PornTubeIE()

# Generated at 2022-06-24 12:21:11.601232
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Unit test for constructor of class FuxIE
    """
    FuxIE()

# Generated at 2022-06-24 12:21:14.628476
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()._real_extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:21:21.561125
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # download_webpage() will raise exceptions in videos with no token
    try:
        PornTubeIE()._download_webpage(
            'https://www.porntube.com/videos/teens-swallowing-dick-from-two-crazy-men_7879141',
            '7879141',
            'Downloading player JS',
        )
    except ValueError:
        pass

# Generated at 2022-06-24 12:21:24.564262
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # For this test we just check for a non failing instantiation.
    # Testing the methods that actually do the work is covered by
    # the test cases for the specific subclasses.
    ie = FourTubeBaseIE(None)
    ok_(ie is not None)

# Generated at 2022-06-24 12:21:26.097473
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-24 12:21:32.519958
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)"

# Generated at 2022-06-24 12:21:39.350059
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        obj = PornTubeIE()
    except:
        obj = PornTubeIE()
        # Test for the case that when list of rules is empty
        if not obj.rules():
            print('The rules of PornTubeIE is empty!')
        # Test for the case that the first rule has no request_url
        if not obj.rules()[0].request_url:
            print('The rules of PornTubeIE has no request_url!')
        # Test for the case that the rules is not in order
        for i in range(len(obj.rules())-1):
            if obj.rules()[i].request_url > obj.rules()[i+1].request_url:
                print('The rules of PornTubeIE is not in order!')
        # Test for the case that there is no url_result

# Generated at 2022-06-24 12:21:40.620171
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(None)



# Generated at 2022-06-24 12:21:49.400375
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test code to extract the video format and quality of a video
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    video = PornerBrosIE._download_webpage(url, None) # Fetch a webpage
    result = PornerBrosIE._search_regex(r'<button[^>]+data-quality=(["\'])(.+?)\1',
        video, 'initialization parameters') # Search the page for the initialization parameters
    print(result)



# Generated at 2022-06-24 12:21:50.613316
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_obj = FourTubeBaseIE()
    assert test_obj

# Generated at 2022-06-24 12:21:52.233823
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(None)._extract_formats('', '', '', '')



# Generated at 2022-06-24 12:21:53.173537
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE(), FuxIE)

# Generated at 2022-06-24 12:21:54.107535
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE({})
    assert instance

# Generated at 2022-06-24 12:22:01.427002
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    ie = PornTubeIE()
    assert ie._TKN_HOST == 'tkn.porntube.com'
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:22:04.327245
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()

    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'



# Generated at 2022-06-24 12:22:05.231606
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert issubclass(FuxIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:22:07.237641
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeIE._TESTS == FourTubeBaseIE._TESTS



# Generated at 2022-06-24 12:22:15.960013
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:22:26.692769
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    testIe = FourTubeIE()
    assert testIe.IE_NAME == '4tube'
    assert testIe._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert testIe._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert testIe._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:22:28.654317
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Not a test for a website
    pass

# Generated at 2022-06-24 12:22:37.588385
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('www.4tube.com')
    assert ie._TKN_HOST == 'token.4tube.com'

    ie = FourTubeBaseIE('www.fux.com')
    assert ie._TKN_HOST == 'token.fux.com'

    ie = FourTubeBaseIE('www.porntube.com')
    assert ie._TKN_HOST == 'tkn.porntube.com'

    ie = FourTubeBaseIE('www.pornerbros.com')
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:22:40.135046
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test if 'FourTubeBaseIE' can be initialized
    FourTubeIE()
    # Test if 'FourTubeIE' can be initialized
    FuxIE()

# Generated at 2022-06-24 12:22:42.291481
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance.IE_NAME == 'PornerBros'


# Generated at 2022-06-24 12:22:50.540859
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    except:
        assert False, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369 not supported'
    assert True, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369 supported'


# Generated at 2022-06-24 12:22:59.547567
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE.IE_NAME == '4tube'
    assert FourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:23:08.901469
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._extract_formats.__code__.co_argcount == 4
    assert FourTubeBaseIE._real_extract.__code__.co_argcount == 2
    assert FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:23:10.065638
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    object = FourTubeBaseIE()
    assert object


# Generated at 2022-06-24 12:23:11.681958
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Program must not crash if create the object with empty arguments.
    FourTubeBaseIE()

# Generated at 2022-06-24 12:23:15.169346
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """ Create an instance of PornerBrosIE with PornerBrosIE._TESTS[0]. """
    pornerbros_ie = PornerBrosIE() # pylint: disable=abstract-class-instantiated


# Generated at 2022-06-24 12:23:23.443788
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ftIE = FourTubeIE()
    result = ftIE.extract(url)
    print("\nresult: " + str(result))
    assert result['id'] == '209733'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'


# Generated at 2022-06-24 12:23:26.222176
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from ytdl.extractor.fourtube import FourTubeIE
    x = FourTubeIE()
    assert x is not None

# Generated at 2022-06-24 12:23:27.526590
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i = PornerBrosIE()

# Generated at 2022-06-24 12:23:29.033205
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test = PornTubeIE()
    assert isinstance(test, PornTubeIE)

# Generated at 2022-06-24 12:23:30.940448
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        from .jp import JPIE
    except ImportError:
        JPIE = None
    return JPIE

# Generated at 2022-06-24 12:23:34.149269
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ex = FourTubeIE()
    assert ex.__class__.__name__ == 'FourTubeIE'
    assert ex.ie_key() == '4tube'
    assert ex.info_dict.__class__.__name__ == 'dict'



# Generated at 2022-06-24 12:23:35.081118
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pass


# Generated at 2022-06-24 12:23:43.716123
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE()
    assert i.IE_NAME == '4tube'
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert i._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert i._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:23:47.282978
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE(None)
    assert ie.IE_NAME == '4tube'
    assert ie.value_dict['TKN_HOST'] == 'token.4tube.com'


# Generated at 2022-06-24 12:23:52.840994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test1 = FourTubeIE()._VALID_URL
    test2 = FourTubeIE().IE_NAME
    assert test1 == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test2 == '4tube'

# Generated at 2022-06-24 12:23:57.058716
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base = FourTubeBaseIE()
    assert base._VALID_URL == None
    assert base._URL_TEMPLATE == None
    assert base._TKN_HOST == None
    assert base._TESTS == []
    assert base.IE_DESC == 'Internal class for 4tube, fux and porntube'
    assert base.__name__ == 'FourTubeBaseIE'
    assert base.LOGGABLE_NAME == '4tube-base'

# Generated at 2022-06-24 12:24:01.598031
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_name = "PornTubeIE"
    # check if class is defined
    BDSup2SubPP.com.rubor.de.ADDON.VIDEO.SERVICES.extractor.common.class_exists(class_name)
    assert True


# Generated at 2022-06-24 12:24:03.116240
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:04.566783
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Testing PornerBrosIE"""
    PornerBrosIE()

# Generated at 2022-06-24 12:24:07.649589
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        obj_fourtube = FourTubeIE()
        print("Creating object of class FourTubeIE Successful")
    except:
        print("Error while creating object of class FourTubeIE")
        assert False



# Generated at 2022-06-24 12:24:08.952540
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    one_to_test = PornerBrosIE()
    assert isinstance(one_to_test, FourTubeBaseIE) is True

# Generated at 2022-06-24 12:24:16.872621
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'
    # Test that PornerBros shows up correctly as PornerBros and not FourTube
    assert ie.IE_DESC == 'PornerBros'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-24 12:24:17.687809
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p.IE_NAME == 'PornTube'

# Generated at 2022-06-24 12:24:19.865056
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-24 12:24:24.396800
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('Test', 'test', 'Test')
    assert ie._VALID_URL == None
    assert ie._URL_TEMPLATE == None
    assert ie._TKN_HOST == None

# Generated at 2022-06-24 12:24:25.594969
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:24:28.709932
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    pornerbros.add_ie(PornerBrosIE.ie_key(), PornerBrosIE)
    return pornerbros

# Generated at 2022-06-24 12:24:29.645218
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:30.658704
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:24:32.745340
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FourTubeIE()
    ie = FuxIE()
    ie = PornTubeIE()
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:24:33.646752
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Pass
    return PornTubeIE()

# Generated at 2022-06-24 12:24:35.162448
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:24:43.839104
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    obj = FourTubeIE()
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._VALID_URL in url
    assert obj._TKN_HOST in url
    assert obj._URL_TEM

# Generated at 2022-06-24 12:24:45.319936
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:24:49.255860
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ..test import get_testcases
    cases = get_testcases('PornTubeIE')
    for case in cases:
        print(case['url'])
        res = PornTubeIE()._real_extract(case['url'])
        print(res)

# Generated at 2022-06-24 12:24:54.942166
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Check whether the constructor of PornTubeIE class is working
    # properly by calling it with valid url.
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    porn_tube_ie = PornTubeIE()
    porn_tube_ie.extract(url)

# Generated at 2022-06-24 12:24:56.735164
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except Exception as e:
        raise (e)
        return 1
    return 0

# Generated at 2022-06-24 12:25:05.023729
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._TESTS[0]['url'] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    assert PornerBrosIE._TES

# Generated at 2022-06-24 12:25:07.429658
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
        ie = PornTubeIE()
        ie1 = PornTubeIE('porntube')
        ie2 = PornTubeIE('PornTube')
        assert ie != ie1
        assert ie == ie2

# Generated at 2022-06-24 12:25:08.922902
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'FuxIE'

# Generated at 2022-06-24 12:25:10.986378
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Unit test for FourTubeIE"""
    info_extractor = FourTubeIE(None)
    info_extractor.suitable([])

# Generated at 2022-06-24 12:25:14.031472
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x.IE_NAME == 'porntube'
    assert x.IE_DESC == 'PornTube.com'

# Generated at 2022-06-24 12:25:16.965716
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    params = {
        'skip_download': True,
    }
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    PornTubeIE._download_webpage(url, None, params)

# Generated at 2022-06-24 12:25:23.155610
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()
    video_url = fourtube._VALID_URL
    mobj = re.match(fourtube._VALID_URL, video_url)
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    #test webpage download
    webpage = fourtube._download_webpage(video_url, video_id)

# Generated at 2022-06-24 12:25:27.245368
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:25:37.178316
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:25:38.983463
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('http://www.pornerbros.com/embed/181369')

# Generated at 2022-06-24 12:25:46.071969
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    ie = PornTubeIE()
    assert ie._TKN_HOST == 'tkn.porntube.com'
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:25:47.110560
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:25:48.130860
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()

# Generated at 2022-06-24 12:25:49.137316
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	fourTubeIE = FourTubeIE()

# Generated at 2022-06-24 12:25:55.350706
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    blob = FuxIE(url)._download_webpage(url, None)

# Generated at 2022-06-24 12:26:07.180441
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    kwargs = {
        'IE_NAME': '4tube',
        '_VALID_URL': re.compile(r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'),
        '_URL_TEMPLATE': 'https://www.4tube.com/videos/%s/video',
        '_TKN_HOST': 'token.4tube.com'
    }
    extractor = FourTubeBaseIE(**kwargs)
    assert(extractor.IE_NAME == '4tube')
    assert(isinstance(extractor._VALID_URL, re._pattern_type))

# Generated at 2022-06-24 12:26:08.325086
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._TKN_HOST

# Generated at 2022-06-24 12:26:12.067106
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    # test constructor with url
    PornTubeIE(url)


# Generated at 2022-06-24 12:26:13.270562
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()



# Generated at 2022-06-24 12:26:16.110156
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    __import__('sys').modules['PornTubeIE'] = PornTubeIE
    for url in PornTubeIE._TESTS:
        PornTubeIE(url=url['url'])