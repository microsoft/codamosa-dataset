

# Generated at 2022-06-24 12:16:14.286087
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:16:19.650069
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()
    assert porn_tube_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert porn_tube_ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert porn_tube_ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:16:22.313326
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com', 'PornerBrosIE requires specific _TKN_HOST'

# Generated at 2022-06-24 12:16:25.979929
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    PornerBrosIE(PornerBrosIE._VALID_URL, url)

# Generated at 2022-06-24 12:16:34.035100
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    ie.IE_NAME = "fake"
    ie.VALID_URL = "fake"
    ie.URL_TEMPLATE = "fake"
    ie.TKN_HOST = "fake"
    ie.TESTS = "fake"
    # These fields should be overridden by the constructor and should be the same for all fourtube IEs
    assert ie.VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?(?P<kind>4tube|fux|porntube|pornerbros)\.com/(?:videos/(?P<display_id>[^/]+)_|embed/|videos/|embed/)(?P<id>\d+)(?:/(?P=display_id))?'
    assert ie.URL_TEM

# Generated at 2022-06-24 12:16:37.999176
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for cls in [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]:
        assert cls._VALID_URL.startswith(r'https?://(?:(?P<kind>www|m)\.)?')
        assert cls._URL_TEMPLATE.startswith('https://www.')
        assert cls._TKN_HOST.endswith('.com')

# Generated at 2022-06-24 12:16:39.757598
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE(None)
    assert fux.IE_NAME == '4tube'



# Generated at 2022-06-24 12:16:40.386415
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()

# Generated at 2022-06-24 12:16:44.432170
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'
    assert fux_ie.IE_NAME == '4tube'


# Generated at 2022-06-24 12:16:45.543529
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .. import YoutubeIE
    assert issubclass(YoutubeIE, InfoExtractor)
    assert issubclass(FourTubeBaseIE, YoutubeIE)

# Generated at 2022-06-24 12:16:47.552283
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:16:49.515736
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert isinstance(instance, FourTubeBaseIE)


# Generated at 2022-06-24 12:16:50.523389
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-24 12:16:51.542731
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-24 12:16:52.473724
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:17:01.995682
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Try to create class instance with an invalid url
    for url in ['http://google.com/', 'http://google.com/video.php?id=abc']:
        try:
            class_instance = FourTubeBaseIE(url)
            class_instance.test()
        except Exception as e:
            assert type(e) == AssertionError
    # Try to create class instance with a valid url
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    class_instance = FourTubeBaseIE(url)
    class_instance.test()

# Generated at 2022-06-24 12:17:03.897035
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.__class__.__name__ == 'FourTubeBaseIE'

# Generated at 2022-06-24 12:17:05.573183
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._parse_json(ie._URL_TEMPLATE % 'test', 'test')

# Generated at 2022-06-24 12:17:09.882809
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_ie_3 = FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert test_ie_3.IE_NAME == '4tube'


# Generated at 2022-06-24 12:17:17.304979
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ft = FourTubeIE()
    with open("/home/tushar/PycharmProjects/pytube/test/test_urls_4tube.json", "r") as f:
        for url in f:
            url = url.strip()
            print("Testing: ", url)
            result = ft.suitable(url)
            assert result, "URL: {} doesn't match".format(url)
            url = url.replace("http", "https")
            result = ft.suitable(url)
            assert result, "URL: {} doesn't match".format(url)


# Generated at 2022-06-24 12:17:18.315989
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'

# Generated at 2022-06-24 12:17:22.342037
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:17:23.204928
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-24 12:17:24.337954
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie

# Generated at 2022-06-24 12:17:27.037591
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE(FourTubeBaseIE)._VALID_URL == FourTubeBaseIE._VALID_URL
    

# Generated at 2022-06-24 12:17:28.022776
# Unit test for constructor of class FuxIE
def test_FuxIE():
    myTest = FuxIE()

# Generated at 2022-06-24 12:17:29.420681
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Invoke the constructor of the PornTubeIE class
    PornTubeIE()

# Generated at 2022-06-24 12:17:36.888603
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    test_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    test_id = '195359'

    info, found = ie.match(test_url)
    assert(found)
    assert(info['id'] == test_id)

    ie = FuxIE().init(test_url, {})
    assert(ie.video_id == test_id)
    assert(ie.display_id == test_id)
    assert(ie.url == test_url)

# Generated at 2022-06-24 12:17:44.868865
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE('http://m.fux.com/embed/195359')
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:17:46.521975
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test = PornerBrosIE()._TESTS
    return test[0]['url']

# Generated at 2022-06-24 12:17:47.571619
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-24 12:17:50.646238
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test if the constructor was called
    assert hasattr(FourTubeIE, "__init__")

# Generated at 2022-06-24 12:17:52.127257
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:17:53.379113
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(None)

# Generated at 2022-06-24 12:18:03.122171
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_id = '209733'
    media_id = '626267'
    sources = ['1080', '720', '480', '360', '240', '144']

    # Test _extract_formats method
    formats = FourTubeBaseIE()._extract_formats(None, video_id, media_id, sources)
    assert formats[0]['resolution'] == '1080p'
    assert formats[0]['format_id'] == '1080p'
    assert formats[0]['quality'] == 1080
    assert formats[1]['resolution'] == '720p'
    assert formats[1]['format_id'] == '720p'
    assert formats[1]['quality'] == 720
    assert formats[2]['resolution'] == '480p'

# Generated at 2022-06-24 12:18:05.135483
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube', 'www.porntube.com')

# Generated at 2022-06-24 12:18:08.970579
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:18:11.054807
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    path = 'm.'
    PornerBrosIE = PornerBrosIE(PornerBrosIE)
    return PornerBrosIE

# Generated at 2022-06-24 12:18:16.526421
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._parse_json(ie._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1', 'pornhub_data', 'data', group='value'),'7247036', transform_source=lambda x: compat_urllib_parse_unquote(compat_b64decode(x).decode('utf-8')))['page']['video']


# Generated at 2022-06-24 12:18:24.867816
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME == '4tube'
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:18:32.454683
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # PornerBrosIE(FourTubeBaseIE):
    # FourTubeBaseIE
    # _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    # _URL_TEMPLATE = 'https://www.pornerbros.com/videos/video_%s'
    # _TKN_HOST = 'token.pornerbros.com'

    a = PornerBrosIE("PornerBrosIE(FourTubeBaseIE)")
    b = FourTubeBaseIE("FourTubeBaseIE")

    assert a == b
    assert a._VALID_URL == b._VALID_URL
    assert a._URL_

# Generated at 2022-06-24 12:18:42.738607
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Unit test needs to validate that this constructor of PornTubeIE
    # does not raise an exception if the regex in the constructor
    # finds a match in the URL it is passed.
    #
    # If the regex does not find a match, then the code will attempt
    # to load the regular expression "INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1"
    # from the webpage https://www.porntube.com/videos/teen-couple-doing-anal_7089759
    #
    # This will throw an exception because the webpage does not contain
    # a match for this regular expression.
    _ = PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-24 12:18:43.842361
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:18:45.653728
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    b = PornerBrosIE("12")
    assert b.IE_NAME == "PornerBros"
    assert b._TESTS[0]['info_dict']['id'] == "181369"

# Generated at 2022-06-24 12:18:46.858309
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	i = FourTubeIE()
	j = FourTubeIE()
	print(i == j)

# Generated at 2022-06-24 12:18:51.173298
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE._download_webpage('https://www.porntube.com/videos/video_7089759', '7089759')

# Generated at 2022-06-24 12:18:53.465283
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    print(obj._TKN_HOST)


# Generated at 2022-06-24 12:18:58.754391
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE('http://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert isinstance(i, PornTubeIE)
    i = PornTubeIE('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert isinstance(i, PornTubeIE)
    print(i)

# Generated at 2022-06-24 12:19:00.056505
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(None).ie_key() == 'Fux'

# Generated at 2022-06-24 12:19:04.768975
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()
    match = re.match(test._VALID_URL, 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert match.group('id'), 'Should return the Video ID'

# Generated at 2022-06-24 12:19:05.985556
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:19:06.945090
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    c = FourTubeBaseIE()

# Generated at 2022-06-24 12:19:15.779879
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("m.porntube.com", "181369", "skinny-brunette-takes-big-cock-down-her-anal-hole")
    assert ie._TKN_HOST == 'tkn.porntube.com',\
        "FourTubeBaseIE._TKN_HOST is initialized incorrectly"
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)',\
        "FourTubeBaseIE._VALID_URL is initialized incorrectly"

# Generated at 2022-06-24 12:19:26.486175
# Unit test for constructor of class FuxIE
def test_FuxIE():
	f = FuxIE
	assert f._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
	assert f._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
	assert f._TKN_HOST == 'token.fux.com'
	assert f._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
	assert f._TESTS[0]['info_dict']['id'] == '195359'
	assert f._TES

# Generated at 2022-06-24 12:19:27.831353
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TESTS[0]['url'] == PornTubeIE._VALID_URL


# Generated at 2022-06-24 12:19:29.461704
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-24 12:19:36.508332
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class FuxIE_test(FuxIE):
        def _extract_formats(self, url, video_id, media_id, sources):
            return []

        def _real_extract(self, url):
            return self.test("url")

    verdict = FuxIE_test().test("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert verdict['id'] == '195359'
    assert verdict['title'] == 'Awesome fucking in the kitchen ends with cum swallow'
    assert verdict['uploader'] == 'alenci2342'
    assert verdict['uploader_id'] == 'alenci2342'
    assert verdict['upload_date'] == '20131230'
    assert verdict['timestamp'] == 1388361660


# Generated at 2022-06-24 12:19:37.654509
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:19:41.301913
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    url = 'http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    assert ie.suitable(url)

# Generated at 2022-06-24 12:19:52.197042
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestIE(FourTubeBaseIE):
        IE_NAME = 'TestIE'
        _VALID_URL = r'http://test.com/(?P<kind>www|m)/(?P<id>\d+)'
        _URL_TEMPLATE = 'http://test.com/%s/%s'
        _TKN_HOST = 'test.com'
    testie = TestIE()
    assert testie._TKN_HOST == 'test.com'
    assert testie._TKNGEN_URL == 'https://' + testie._TKN_HOST + '/token/generate'
    assert testie._VALID_URL == r'http://test.com/(?P<kind>www|m)/(?P<id>\d+)'
    assert testie._URL_TEMPL

# Generated at 2022-06-24 12:19:53.546561
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().get_IE_name() == 'Fux'

# Generated at 2022-06-24 12:19:56.600379
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    '''
    Unit test for constructor of class FourTubeBaseIE
    '''
    instance = FourTubeBaseIE(FourTubeBaseIE.__name__, 'FourTubeBaseIE')
    assert isinstance(instance, FourTubeBaseIE)

# Generated at 2022-06-24 12:19:58.591179
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:01.869867
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._VALID_URL == \
        r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:20:04.974139
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'https://www.pornerbros.com/embed/181369'
    test_instance = FourTubeBaseIE.suitable(url)
    assert isinstance(test_instance, PornerBrosIE)



# Generated at 2022-06-24 12:20:13.628085
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('m.porntube.com')
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

    ie = FourTubeBaseIE('embed.porntube.com')
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

    ie = FourTubeBaseIE('www.fux.com')
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:20:22.931496
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE()
    assert info_extractor.IE_NAME == '4tube'
    assert info_extractor.IE_DESC == '4Tube.com'
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert info_extractor._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert info_extractor._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:31.559876
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    ie = FourTubeBaseIE('fux')

# Generated at 2022-06-24 12:20:33.196375
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:20:43.595204
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'
    assert FourTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE()._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:48.826954
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE('4tube', '4tube.com')
    assert isinstance(obj, InfoExtractor)
    assert isinstance(obj, FourTubeBaseIE)
    assert obj.ie_key() == '4tube'
    assert obj.ie_name() == '4tube'
    assert obj.ie_id() == '4tube.com'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj.IE_NAME == '4tube'
    assert obj.ie_desc() == '4tube'
    assert obj.ie_version() == '1'
    assert obj.ie_

# Generated at 2022-06-24 12:20:50.214593
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()

# Generated at 2022-06-24 12:21:02.725396
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Unit test for constructor of class FourTubeIE
    """
    fourtube_ie = FourTubeIE()
    assert fourtube_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourtube_ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert fourtube_ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:04.015291
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:21:13.690334
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = 'https://www.pornerbros.com/embed/181369'
    ie = PornerBrosIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._VALID_URL == PornerBrosIE._VALID_URL
    assert ie._URL_TEMPLATE == PornerBrosIE._URL_TEMPLATE
    assert ie._

# Generated at 2022-06-24 12:21:18.797841
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from . import youtube_dl
    result = youtube_dl.extractor.FuxIE()._real_extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:21:21.076095
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Init
    FuxIE = FuxIE()
    # Check if it's valid
    assert FuxIE == FuxIE

# Generated at 2022-06-24 12:21:26.345961
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:21:37.409698
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for url in ['http://www.4tube.com/videos/205106/busty-and-beautiful-blond-teen-sucks-and-fucks-for-cash']:
        video = FourTubeIE()._real_extract(url)
        assert video['id'] == '205106'
        assert video['title'] == 'Busty and beautiful blond teen sucks and fucks for cash'
        assert video['uploader'] == 'Naughty America'
        assert video['uploader_id'] == 'naughty-america'
        assert video['timestamp'] == 1385273732
        assert video['duration'] == 592
        assert video['view_count'] > 1
        assert video['like_count'] > 1
        assert video['categories'][0] == 'Amateur'

# Generated at 2022-06-24 12:21:39.448866
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb = PornerBrosIE(None)
    assert pb.IE_NAME == 'PornerBros'

# Generated at 2022-06-24 12:21:46.170929
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        import pytube
    except ImportError:
        pytube = None

    if not pytube:
        return

    yt = pytube.YouTube("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    print("yt =", yt)
    # videos = yt.get_videos()
    # print("videos =", videos)
    # print("yt.videos =", yt.videos)

    # for v in videos:
    #    print("v =", v)
    #    print("v.extension =", v.extension)
    #    print("v.resolution =", v.resolution)
    #    print("v.title =", v.title)
    #    print

# Generated at 2022-06-24 12:21:46.872875
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:21:48.641107
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.__class__.__name__ == "FourTubeBaseIE"

# Generated at 2022-06-24 12:21:53.173516
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    s = FourTubeBaseIE()
    assert s.__class__ == FourTubeBaseIE
    assert s._VALID_URL == None
    assert s._TESTS == []
    assert s._TKN_HOST == None
    assert s._URL_TEMPLATE == None
    assert s._downloader == None
    assert s.IE_NAME == None
    assert s._real_extract == None

# Generated at 2022-06-24 12:22:00.459576
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    t = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert t._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert t._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert t._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:22:05.153485
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie.VALID_URL == ''
    assert ie.URL_TEMPLATE == ''
    assert ie.TKN_HOST == ''
    assert ie.TESTS == []
    

# Generated at 2022-06-24 12:22:07.533580
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .pornerbros import PornerBrosIE
    p = PornerBrosIE()
    assert p is not None


# Generated at 2022-06-24 12:22:08.945669
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Unit test for constructor of class FuxIE"""
    FuxIE(instance=0)

# Generated at 2022-06-24 12:22:14.266207
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()._VALID_URL == PornerBrosIE._VALID_URL
    assert PornerBrosIE()._URL_TEMPLATE == PornerBrosIE._URL_TEMPLATE
    assert PornerBrosIE()._TKN_HOST == PornerBrosIE._TKN_HOST
    assert PornerBrosIE()._TESTS == PornerBrosIE._TESTS

# Generated at 2022-06-24 12:22:17.029031
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    infoExtractor = FourTubeBaseIE()
    assert infoExtractor._VALID_URL is None

# Generated at 2022-06-24 12:22:21.502599
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE('http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    print(ie.result)
    assert ie.result == 1
    assert ie.title == 'Awesome fucking in the kitchen ends with cum swallow'


# Generated at 2022-06-24 12:22:25.900626
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ins = PornerBrosIE('http://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert ins._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ins._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:22:28.594174
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(PornTubeIE.ie_key())

# Generated at 2022-06-24 12:22:36.253556
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .test_common import FakeYDL
    from .test_common import FakeHttpServer
    
    # Start server
    server = FakeHttpServer()
    server.start() 
    
    # Create fake downloader
    downloader = FakeYDL({'http_proxy': server.server_address[0] + ':' + str(server.server_address[1])})
    
    FourTubeIE()._real_initialize(downloader)
    
    # Stop server
    server.stop()

# Generated at 2022-06-24 12:22:47.651734
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()

# Generated at 2022-06-24 12:22:54.584978
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'
    assert ie.TKN_HOST == 'token.fux.com'
    assert ie.URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:22:55.677914
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()

# Generated at 2022-06-24 12:22:56.672508
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()
    PornTubeIE()

# Generated at 2022-06-24 12:22:58.077945
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == 'fux'

# Generated at 2022-06-24 12:23:02.097297
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == "token.fux.com"



# Generated at 2022-06-24 12:23:10.128681
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    matching_urls = [
        "http://www.4tube.com/embed/209733",
        "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black",
    ]
    nonmatching_urls = [
        "http://www.4tube.com/tags/",
    ]
    ie = FourTubeIE()
    for url in matching_urls:
        assert ie.suitable(url), url
    for url in nonmatching_urls:
        assert not ie.suitable(url), url

# Generated at 2022-06-24 12:23:17.702091
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE
    from .test_FuxIE import FuxIE

# Generated at 2022-06-24 12:23:19.162429
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().ie_key() == 'Fux'

# Generated at 2022-06-24 12:23:22.804280
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.ie_key() == '4tube'
    assert ie.ie_name() == '4tube'
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:23:33.166061
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestIE(FourTubeBaseIE):
        IE_NAME = '4tube.test'
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.4tubetest.com/videos/%s/video'
        _TKN_HOST = 'token.4tube.test'

# Generated at 2022-06-24 12:23:38.831410
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:23:39.972209
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ph = PornerBrosIE()
    assert ph


# Generated at 2022-06-24 12:23:50.934052
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import json
    import os

    # Load example data
    example_data_file = os.path.join(os.path.dirname(__file__), "__data__", "porntube.json")
    with open(example_data_file, 'r') as example_data_file:
        example_data = example_data_file.read()

    # Parse example data
    video = json.loads(example_data)
    videoinfo = video['page']['video']

    # Check for parsed data
    assert(videoinfo['title'] == 'Squirting Teen Ballerina on ECG')
    assert(videoinfo['mediaId'] == '1331406')
    assert([15] == [e['height'] for e in videoinfo['encodings']])

# Generated at 2022-06-24 12:23:51.770915
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie is not None

# Generated at 2022-06-24 12:23:53.602609
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("url")
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:23:57.462671
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import FuxIE

    test_list = [{'url': 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow',
                  'md5': '6516c8ac63b03de06bc8eac14362db4f'}]

    f = FuxIE.FuxIE()
    f.test(test_list)

# Generated at 2022-06-24 12:24:01.649689
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()._download_webpage('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', '209733', fatal=False)

# Generated at 2022-06-24 12:24:07.638580
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie_obj = PornTubeIE()
    dict_obj = dict()
    assert ie_obj.IE_NAME == 'PornTube'
    assert ie_obj._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert ie_obj._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie_obj._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:24:08.887501
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:24:09.576127
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:24:11.681017
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_case = FourTubeIE()
    result = str(test_case)
    print(result)
    assert('FourTubeIE' in result)

# Generated at 2022-06-24 12:24:16.198003
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('token.4tube.com', 'FourTubeBaseIE')
    if ie is not None:
        raise AssertionError('The constructor of class FourTubeIE is broken.')


# Generated at 2022-06-24 12:24:17.125289
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie

# Generated at 2022-06-24 12:24:28.446214
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbrosIE = PornerBrosIE()
    assert pornerbrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert pornerbrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerbrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:24:35.951706
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_class = PornerBrosIE()

    assert test_class.IE_NAME == 'pornerbros'
    assert test_class._VALID_URL == 'https?://(?:(?P<kind>www|m)\.?)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert test_class._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

    assert test_class._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:24:44.452746
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert ie.name == "4tube"
    assert ie.valid_url("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert ie.valid_url("http://www.4tube.com/embed/209733")
    assert ie.valid_url("https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

# Generated at 2022-06-24 12:24:47.720658
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:24:55.695521
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None, 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:24:57.433550
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert(fux.ie_key() == 'Fux')

# Generated at 2022-06-24 12:24:59.419260
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE('create_extractors', 'FourTube', {})
    assert isinstance(instance, FourTubeBaseIE)


# Generated at 2022-06-24 12:25:07.355367
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black') == {
        'id': '209733',
        'ext': 'mp4',
        'title': 'Hot Babe Holly Michaels gets her ass stuffed by black',
        'uploader': 'WCP Club',
        'uploader_id': 'wcp-club',
        'upload_date': '20131031',
        'timestamp': 1383263892,
        'duration': 583,
        'view_count': int,
        'like_count': int,
        'categories': list,
        'age_limit': 18,
    }


# Generated at 2022-06-24 12:25:08.834060
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    p = PornerBrosIE()
    assert p is not None

# Generated at 2022-06-24 12:25:09.484310
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:25:16.969436
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test for several class of videos
    ie = FourTubeBaseIE()
    assert ie._TESTS[0].get('info_dict').get('id') == '209733'

    ie = FuxIE()
    assert ie._TESTS[0].get('info_dict').get('id') == '195359'

    ie = PornTubeIE()
    assert ie._TESTS[0].get('info_dict').get('id') == '7089759'

    ie = PornerBrosIE()
    assert ie._TESTS[0].get('info_dict').get('id') == '181369'

# Generated at 2022-06-24 12:25:18.395769
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'

# Generated at 2022-06-24 12:25:21.334168
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._VALID_URL.find('porntube.com') != -1
    assert isinstance(PornTubeIE(InfoExtractor()), PornTubeIE)


# Generated at 2022-06-24 12:25:22.709849
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
  porn_tube_ie = PornTubeIE()

# Generated at 2022-06-24 12:25:23.894783
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-24 12:25:26.236018
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == FourTubeIE()._VALID_URL


# Generated at 2022-06-24 12:25:27.415227
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie

# Generated at 2022-06-24 12:25:28.124095
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:25:32.403505
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_dict = PornTubeIE()._real_extract('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert info_dict['uploader'] == 'Exploited College Girls'
    assert info_dict['channel'] == 'Exploited College Girls'

# Generated at 2022-06-24 12:25:36.665331
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:25:47.645889
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        import requests
        import requests.exceptions
    except ImportError:
        class requests:
            class exceptions:
                class ReqestException(Exception):
                    pass
    except RuntimeError:
        # Skipped because of not being compatible with python 3.4
        return
    import six
    import webbrowser
    import threading
    import time
    import urllib3
    import json
    import base64
    import sys
    import os
    import socket
    import urllib
    import urllib.parse
    import urllib.request
    import urllib.error

    # Create an object of class PornTubeIE.
    # Here, pass an object of class requests.
    PornTubeIE_object = PornTubeIE(requests)

    # Store the value of the variable '_VALID_URL' of

# Generated at 2022-06-24 12:25:49.310756
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE is not None


# Generated at 2022-06-24 12:25:51.710332
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTubeIE = FourTubeIE()
    assert fourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:25:59.141075
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print('Running test for FourTubeBaseIE')
    if not hasattr(FourTubeBaseIE, 'IE_NAME'):
        print('\tCannot run test for FourTubeBaseIE without IE_NAME set')
        return
    if not hasattr(FourTubeBaseIE, '_VALID_URL'):
        print('\tCannot run test for FourTubeBaseIE without _VALID_URL set')
        return
    if not hasattr(FourTubeBaseIE, '_URL_TEMPLATE'):
        print('\tCannot run test for FourTubeBaseIE without _URL_TEMPLATE set')
        return
    if not hasattr(FourTubeBaseIE, '_TESTS'):
        print('\tCannot run test for FourTubeBaseIE without _TESTS set')
        return

# Generated at 2022-06-24 12:26:02.354931
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    if PornTubeIE._downloader is None:
        PornTubeIE._downloader = PornTubeIE._prepare_downloader()
    from ..downloader import PornTubeIE
    test = PornTubeIE({})


# Generated at 2022-06-24 12:26:11.452309
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert (pornerBrosIE.__class__.__name__ == "PornerBrosIE")
    assert (pornerBrosIE.IE_NAME == "PornerBros")
    assert (pornerBrosIE._TKN_HOST == "token.pornerbros.com")
    assert (pornerBrosIE._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)")
    assert (pornerBrosIE._URL_TEMPLATE == "https://www.pornerbros.com/videos/video_%s")

# Generated at 2022-06-24 12:26:20.993244
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pb = PornTubeIE()
    assert pb._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pb._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pb._TKN_HOST == 'tkn.porntube.com'
    assert pb._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'