

# Generated at 2022-06-24 12:16:15.391133
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()

# Generated at 2022-06-24 12:16:27.544373
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    video_id = '209733'
    url = 'https://www.4tube.com/videos/%s/video'
    token_url = 'https://token.4tube.com/%s/desktop/%s'

    class testFourTubeBaseIE(FourTubeBaseIE):
        _TKN_HOST = 'token.4tube.com'
        _URL_TEMPLATE = url
    _ = testFourTubeBaseIE(testFourTubeBaseIE.ie_key())
    
    sources = ['480', '720']
    token_url = token_url %(video_id, '+'.join(sources))
    #print (token_url)
    assert(token_url == 'https://token.4tube.com/209733/desktop/480+720')

# Generated at 2022-06-24 12:16:27.996622
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:16:30.210041
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    t = FourTubeBaseIE()
    t.test()
    t = FuxIE()
    t.test()
    t = PornTubeIE()
    t.test()
    t = PornerBrosIE()
    t.test()

# Generated at 2022-06-24 12:16:32.543168
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    obj = FuxIE(url)
    assert obj.url == url, obj.url

# Generated at 2022-06-24 12:16:34.817847
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:16:40.388665
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # test when display_id is None
    class_name = PornerBrosIE
    valid_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    video_id = '181369'
    display_id = None

    try:
        class_name(None, None)
    except TypeError as e:
        # there are 4 args, the constructor should require 2
        assert re.search('4 for 2', str(e))
    else:
        # if the class_name's constructor does not match the above, it won't throw the expected error
        assert False

    obj = class_name(valid_url, None)
    

# Generated at 2022-06-24 12:16:42.074121
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test if class FourTubeBaseIE is defined
    assert 'FourTubeBaseIE' in globals()

# Generated at 2022-06-24 12:16:45.754720
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .extractors.generic import YoutubeIE

    ie = FourTubeBaseIE()
    assert ie.ie_key() == '4tube'
    assert ie.SUCCESS == 'ok'
    assert ie.FAILURE == 'fail'


# Generated at 2022-06-24 12:16:47.025076
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:16:48.024250
# Unit test for constructor of class FuxIE
def test_FuxIE():
   assert FuxIE is not None


# Generated at 2022-06-24 12:16:49.604015
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeIE('FourTube', '4tube')



# Generated at 2022-06-24 12:16:50.343166
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:17:01.231395
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class MyFourTubeBaseIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?myurl\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.myurl.com/videos/video_%s'
        _TKN_HOST = 'token.myurl.com'
        IE_NAME = '4tube:my'

# Generated at 2022-06-24 12:17:02.224553
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE("FourTubeIE")

# Generated at 2022-06-24 12:17:12.998750
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)
    # Test from_id
    assert FourTubeBaseIE._from_id('https://www.porntube.com/videos/videos') == 'https://www.porntube.com/videos/videos'
    assert FourTubeBaseIE._from_id('https://www.porntube.com/embed/videos') == 'https://www.porntube.com/embed/videos'
    assert FourTubeBaseIE._from_id('https://www.porntube.com/videos/videos/videos') == 'https://www.porntube.com/videos/videos'
    assert FourTubeBaseIE._from_id('https://www.porntube.com/embed/videos/videos') == 'https://www.porntube.com/embed/videos'
    assert FourTube

# Generated at 2022-06-24 12:17:14.707318
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # create an instance of FuxIE
    fux = FuxIE()
    assert fux.IE_NAME == '4tube'

# Generated at 2022-06-24 12:17:18.315637
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE(None)
    obj.suitable('http://www.4tube.com/embed/209733')
    obj.suitable('http://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')

# Generated at 2022-06-24 12:17:22.711782
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "https://www.porntube.com/videos/anal-slut-julie-skyhigh-double-stuffed_2046376"

    expected_title = "Anal Slut Julie Skyhigh Double Stuffed"
    expected_video_id = "2046376"

    extracted = PornTubeIE._real_extract(PornTubeIE(), url)
    # print(extracted)

    assert extracted["title"] == expected_title
    assert extracted["id"] == expected_video_id

# Generated at 2022-06-24 12:17:23.902673
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()

# Generated at 2022-06-24 12:17:24.592649
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-24 12:17:31.176671
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # This test is required because
    # PornerBros's web service return wrong value
    # with respect to the document.
    # https://www.pornerbros.com/support/help.php/helppage/Porn_JSON_API/
    porner_bros_ie = PornerBrosIE()
    porner_bros_ie._download_webpage(
        'https://www.pornerbros.com/videos/video_181369', '181369')


# Generated at 2022-06-24 12:17:35.078921
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    class PornerBrosIETest(unittest.TestCase):
        def runTest(self):
            self.assertIsInstance(PornerBrosIE(), PornerBrosIE)
    PornerBrosIETest().runTest()

# Generated at 2022-06-24 12:17:41.589416
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_obj = FourTubeIE()
    assert test_obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test_obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test_obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:17:53.187594
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    file_url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    webpage = 'https://www.porntube.com/embed/7089759'
    numbers = b'123'

    assert str(FourTubeBaseIE) == '<class \'__main__.FourTubeBaseIE\'>'
    assert FourTubeBaseIE._VALID_URL
    assert FourTubeBaseIE._URL_TEMPLATE
    assert FourTubeBaseIE._TKN_HOST

    f = FourTubeBaseIE()

    assert f._extract_formats(file_url, '1331406', '7089759', '123')
    assert f._real_extract(webpage)['id'] == '7089759'


# Generated at 2022-06-24 12:17:54.978978
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    inst = PornTubeIE()
    assert inst.IE_NAME == 'PornTube'

# Generated at 2022-06-24 12:17:59.945920
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..utils import opts
    from youtube_dl.extractor.common import InfoExtractor
    from .common import _common_4tube_tests
    for x, y in opts.items():
        opts[x] = None
    assert not y
    ie = InfoExtractor()
    ie._sort_formats = lambda a, b: []
    _common_4tube_tests(ie)

# Generated at 2022-06-24 12:18:06.664445
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE._TKN_HOST == 'token.fux.com'
    assert FuxIE._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'


# Generated at 2022-06-24 12:18:08.123729
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert isinstance(ie, PornTubeIE)

# Generated at 2022-06-24 12:18:14.742802
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTube = FourTubeIE()
    assert fourTube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourTube._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert fourTube._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:18:18.959053
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:18:23.384182
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert(instance.IE_NAME == '4tube')
    assert(instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(instance._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(instance._TKN_HOST == 'token.4tube.com')



# Generated at 2022-06-24 12:18:35.645166
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:18:36.672320
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE(), FourTubeBaseIE)


# Generated at 2022-06-24 12:18:38.573091
# Unit test for constructor of class FuxIE
def test_FuxIE():
    global FuxIE
    FuxIE('https://www.fux.com/video/195359')

# Generated at 2022-06-24 12:18:42.949978
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    construct_FourTubeBaseIE = FourTubeBaseIE()
    for i in range(1, len(FourTubeBaseIE.__dict__), 2):
        assert construct_FourTubeBaseIE.__dict__[list(FourTubeBaseIE.__dict__.keys())[i]] == list(FourTubeBaseIE.__dict__.values())[i]

# Generated at 2022-06-24 12:18:54.098939
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test example 1
    requests.get('http://www.4tube.com/embed/209733').content
    req = requests.get('http://www.4tube.com/embed/209733')
    HTML = req.content
    match = re.search(
        r'<meta[^>]+itemprop="interactionCount"[^>]+content="UserPlays:([0-9,]+)">',
        HTML)
    match = eval(str(req.content).replace('\t','').replace('\n','').replace('\r','').replace('  ','').replace('  ','').replace('  ',''))
    yaml = yaml.dump(match)
    yaml = yaml.replace(str(match),str(match).replace('{','\{'))
    yaml = y

# Generated at 2022-06-24 12:18:59.594026
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
  test_instance = PornTubeIE()
  assert test_instance._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
  assert test_instance._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
  assert test_instance._TKN_HOST == 'tkn.porntube.com'
  assert test_instance.IE_NAME == 'PornTube'
  assert test_instance._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'


# Generated at 2022-06-24 12:19:08.441193
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.__name__ == 'PornTubeIE'
    ie = PornTubeIE(PornTubeIE.ie_key())
    assert ie.IE_NAME == 'PornTubeIE'
    assert ie._VALID_URL.startswith('https?://(?:(?P<kind>www|m)\.)?porntube\.com/')
    assert ie._URL_TEMPLATE.startswith('https://www.porntube.com/videos/video_')
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-24 12:19:11.789730
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    pornTube = PornTubeIE()
    assert pornTube._real_extract(url)

# Generated at 2022-06-24 12:19:12.461044
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    #Should not raise exception
    PornTubeIE()

# Generated at 2022-06-24 12:19:13.348573
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    result = PornerBrosIE()

# Generated at 2022-06-24 12:19:16.584668
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Unit test for constructor of class FourTubeBaseIE
    """
    IE = FourTubeBaseIE()
    assert IE.IE_NAME == '4tube'

# Generated at 2022-06-24 12:19:22.618340
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    video_id = '195359'
    display_id = 'awesome-fucking-kitchen-ends-cum-swallow'
    fuxIE = FuxIE(url, display_id)
    assert fuxIE.video_id == video_id
    assert fuxIE.display_id == display_id

# Generated at 2022-06-24 12:19:32.097112
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:19:42.927845
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from youtube_dl.utils import HEADRequest
    from youtube_dl.compat import compat_urllib_parse_urlencode, compat_str, compat_urllib_parse_unquote
    from ..utils import fake_urlretrieve, fake_urlopen
    from youtube_dl.extractor import get_info_extractor, gen_extractors_by_id
    from youtube_dl.utils import parse_duration
    import time, random, socket
    import os

# Generated at 2022-06-24 12:19:44.635150
# Unit test for constructor of class FuxIE
def test_FuxIE():
    '''
    Create an instance of FuxIE
    '''
    fuxie = FuxIE()

# Generated at 2022-06-24 12:19:45.605221
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('FourTube')

# Generated at 2022-06-24 12:19:49.293344
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    ie = InfoExtractor(FourTubeBaseIE._VALID_URL)
    assert isinstance(ie, FourTubeBaseIE)


# Generated at 2022-06-24 12:19:50.700529
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    print(type(obj))

# Generated at 2022-06-24 12:19:52.484491
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
   assert PornTubeIE(None, None)._TKN_HOST == "tkn.porntube.com"

# Generated at 2022-06-24 12:19:56.408118
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE();
    assert ie._VALID_URL is None
    assert ie._URL_TEMPLATE is None
    assert ie._TKN_HOST is None
    assert ie._TESTS is None



# Generated at 2022-06-24 12:20:00.590756
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import sys
    import os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    from ytdl.extractor import PornTubeIE
    PornTubeIE()

# Generated at 2022-06-24 12:20:02.552970
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
    except:
        assert False, 'FuxIE instantiated failed'
    assert True


# Generated at 2022-06-24 12:20:09.728552
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # new class requires 4 arguments for initialization, so we check if it
    # raises an exception if the number of arguments is different.
    unsupported_number_of_arguments = [
        {},
        {'1': '1', '2': '2'},
        {'1': '1', '2': '2', '3': '3'},
        {'1': '1', '2': '2', '3': '3', '4': '4', '5': '5'},
    ]
    import sys
    from youtube_dl import youtube_dl
    for argument in unsupported_number_of_arguments:
        try:
            PornTubeIE(argument)
        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            print(exc_type)

# Generated at 2022-06-24 12:20:17.885506
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_ie = FourTubeIE()
    assert fourtube_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourtube_ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert fourtube_ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:20:22.562320
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """test 
    
    Arguments:
        test {PornTubeIE} -- test PornTubeIE 
    """
    obj = PornTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    
    

# Generated at 2022-06-24 12:20:24.655862
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-24 12:20:26.874013
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert(obj is not None)
    assert(type(obj) == PornerBrosIE)


# Generated at 2022-06-24 12:20:31.949463
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_fux = FuxIE()
    assert(test_fux._VALID_URL==r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(test_fux._URL_TEMPLATE=='https://www.fux.com/video/%s/video')
    assert(test_fux._TKN_HOST=='token.fux.com')

# Generated at 2022-06-24 12:20:43.122532
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    sites = [
        (FourTubeIE('4tube'), '4tube.com'),
        (FuxIE('fux'), 'fux.com'),
        (PornerBrosIE('pornerbros'), 'pornerbros.com'),
        (PornTubeIE('porntube'), 'porntube.com'),
    ]

    # Check that each site has different _VALID_URL and _TKN_HOST
    valid_urls = set()
    tkn_hosts = set()
    for instance, domain in sites:
        url = instance._VALID_URL
        valid_urls.add(url)

        tkn_host = instance._TKN_HOST
        tkn_hosts.add(tkn_host)

        # Check that each site's _VALID_URL matches the domain appended


# Generated at 2022-06-24 12:20:44.651874
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie is not None

# Generated at 2022-06-24 12:20:45.964670
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    x = FourTubeIE()
    assert x._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:46.791930
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:47.968780
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj

# Generated at 2022-06-24 12:20:49.483240
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # FourTubeBaseIE()
    pass


# Generated at 2022-06-24 12:20:58.773070
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    c = FourTubeBaseIE(
        type='IE_TYPE',
        ie_key='IE_KEY',
        name='IE_NAME',
        ie_id='IE_ID',
        gen_extractors=False,
    )
    assert c.name == 'IE_NAME'
    assert c._ies == [{
        'type': 'IE_TYPE',
        'ie_key': 'IE_KEY',
        'name': 'IE_NAME',
        'ie_id': 'IE_ID',
    }]

# Generated at 2022-06-24 12:21:03.318523
# Unit test for constructor of class FuxIE
def test_FuxIE():
    sub_class = FuxIE('Fux', True)
    assert sub_class.IE_NAME == 'fux'
    assert sub_class._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert sub_class._TKN_HOST == 'token.fux.com'



# Generated at 2022-06-24 12:21:04.099943
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:21:05.223209
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBros', 80)

# Generated at 2022-06-24 12:21:08.434282
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeIE()
    ie.extract(url)

# Generated at 2022-06-24 12:21:20.501604
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # It might be better to make a simple test case here, but this part is not
    # so complicated, so I suggest that we use it as a unit test.
    f = FuxIE()
    # Test for _VALID_URL
    assert f._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    # Test for _URL_TEMPLATE
    assert f._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    # Test for _TKN_HOST
    assert f._TKN_HOST == 'token.fux.com'
    # Test for _T

# Generated at 2022-06-24 12:21:25.090832
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()

# Generated at 2022-06-24 12:21:27.165562
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:21:28.401366
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:21:35.028936
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._real_extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    #FuxIE()._real_extract('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    #PornTubeIE()._real_extract('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

test_FuxIE()

# Generated at 2022-06-24 12:21:36.329610
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:21:38.202993
# Unit test for constructor of class FuxIE
def test_FuxIE():
    unit = FuxIE()


# Generated at 2022-06-24 12:21:45.693334
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    def test_inner():
        assert PornerBrosIE._TKN_HOST == "token.pornerbros.com"
        assert PornerBrosIE._URL_TEMPLATE == "https://www.pornerbros.com/videos/video_%s"
        assert PornerBrosIE._VALID_URL ==  "https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)"
        url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-24 12:21:50.950152
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import types
    constructor = types.FunctionType(FuxIE.__bases__[0].__init__.__code__, {}, name="__init__", argdefs=FuxIE.__init__.__defaults__, closure=FuxIE.__init__.__closure__)
    a = FuxIE(constructor, "id", {})
    assert a.IE_NAME == "4tube"

# Generated at 2022-06-24 12:21:52.582917
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:54.194523
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """ Unit test for FuxIE Class
    """

    foo = FuxIE()
    foo.IE_NAME

# Generated at 2022-06-24 12:22:00.532283
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    PornTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    PornerBrosIE("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    assert True

# Generated at 2022-06-24 12:22:11.677879
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE
    ie.IE_NAME = '4tube'
    ie.IE_DESC = '4tube'
    ie.FILE_SUFFIX = 'mp4'
    ie.WEBPAGE_URL_TEM = 'http://www.4tube.com/videos/%s/video'
    ie.TKN_HOST = 'token.4tube.com'
    ie.WEBPAGE_URL_TEM = 'http://www.4tube.com/videos/%s/video'
    ie._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)'
    ie.CREDENTIALS = []
    ie.IE_NAME = '4tube'
    ie

# Generated at 2022-06-24 12:22:16.761604
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_extractor = PornTubeIE()
    # Test if initialization works
    assert info_extractor._VALID_URL.match('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert info_extractor._VALID_URL.match('https://www.porntube.com/embed/1331406')
    assert info_extractor._VALID_URL.match('https://m.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')



# Generated at 2022-06-24 12:22:17.830201
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_info = PornerBrosIE()

# Generated at 2022-06-24 12:22:21.551072
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._VALID_URL is None
    assert obj._URL_TEMPLATE is None
    assert obj._TKN_HOST is None
    assert obj._TESTS == []



# Generated at 2022-06-24 12:22:23.733438
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    contructor = PornTubeIE()
    assert isinstance(contructor, PornTubeIE)

# Generated at 2022-06-24 12:22:25.420284
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    P = PornTubeIE(None)
    assert P.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-24 12:22:27.909583
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    f = PornerBrosIE()
    assert f._TKN_HOST == "token.pornerbros.com"

# Generated at 2022-06-24 12:22:29.780343
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()
    FuxIE()
    PornerBrosIE()
    FourTubeIE()

# Generated at 2022-06-24 12:22:31.578833
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_porner_bros = PornerBrosIE()

# Generated at 2022-06-24 12:22:32.903787
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()



# Generated at 2022-06-24 12:22:40.280211
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print("Unit test for constructor of class FourTubeBaseIE")
    ie = FourTubeBaseIE()
    ie._TKN_HOST = 'token.4tube.com'
    ie._extract_formats('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
                        '209733', '1094104', ['720', '480', '360'])
    print("Test successful.")
    return True

# Generated at 2022-06-24 12:22:45.111764
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test if the constructor raises a ValueError if no url was provided
    url = None
    try:
        PornTubeIE(url)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected constructor to raise ValueError if no url was provided.')


# Generated at 2022-06-24 12:22:46.735192
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBros')

# Generated at 2022-06-24 12:22:58.219964
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    video_url = "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    expected_title = "Hot Babe Holly Michaels gets her ass stuffed by black"

    info_extractor = FourTubeBaseIE()

    parsed_url = compat_urlparse.urlparse(video_url)
    webpage = info_extractor._download_webpage(video_url, parsed_url.path)
    title = info_extractor._html_search_meta('name', webpage)

    assert expected_title == title

# Generated at 2022-06-24 12:23:02.987310
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(1, {'name': '2'})('http://example.com')


# Integration test for porntube.com
# (that requires authentication and cookies)

# Generated at 2022-06-24 12:23:05.393733
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:23:17.391358
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from ytdl.extractor.common import InfoExtractor
    from ytdl.downloader.common import FileDownloader
    from ytdl.downloader.http import HttpRequest
    from ytdl.utils import sizeof_fmt
    from ytdl.ytdl import Ytdl

    class DummyYtdl(Ytdl):
        def __init__(self):
            super(DummyYtdl, self).__init__()
            self._ies = {'YOUTUBE': FourTubeIE}

# Generated at 2022-06-24 12:23:19.316475
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractors = [FourTubeIE]
    assert FourTubeIE.ie_key() == '4tube'

# Generated at 2022-06-24 12:23:31.236900
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert obj._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert obj._TESTS[0]['info_dict']['id'] == '7089759'
    assert obj._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert obj._TESTS[0]['info_dict']['title'] == 'Teen couple doing anal'

# Generated at 2022-06-24 12:23:32.084705
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

# Generated at 2022-06-24 12:23:34.745750
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:23:35.657606
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE.suite()

# Generated at 2022-06-24 12:23:42.378535
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-24 12:23:43.878258
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert hasattr(ie, "_VALID_URL")

# Generated at 2022-06-24 12:23:54.617074
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-24 12:23:57.123307
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        IE = PornTubeIE()
    except Exception as e:
        print('Exception', e)
        assert False


# Generated at 2022-06-24 12:24:01.699457
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:24:03.602083
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Construction of an instance of class FuxIE must not fail
    fetcher = FuxIE()

# Generated at 2022-06-24 12:24:07.173375
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:24:08.716598
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406', '', '', '', '', '')

# Generated at 2022-06-24 12:24:11.497361
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL is not None
    assert ie._TKN_HOST is not None
    assert ie._URL_TEMPLATE is not None

# Generated at 2022-06-24 12:24:19.109224
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert(ie.IE_NAME == '4tube')
    assert(ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(ie._TKN_HOST == 'token.4tube.com')
    assert(len(ie._TESTS) == 3)

# Generated at 2022-06-24 12:24:21.339132
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:24:21.748419
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:27.275166
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import BaseInfoExtractor
    from .youtube import YoutubeIE
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(FuxIE, BaseInfoExtractor)
    assert not issubclass(FuxIE, YoutubeIE)
    assert FuxIE.IE_NAME == '4tube:fux'



# Generated at 2022-06-24 12:24:29.887577
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE('https://www.porntube.com/embed/7089759')
    except TypeError:
        pass

# Generated at 2022-06-24 12:24:31.275597
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:24:32.657949
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    assert FourTubeIE  # silence pyflakes

# Generated at 2022-06-24 12:24:34.303302
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornerBrosIE()
    assert(ie.IE_NAME == 'pornerbros')

# Generated at 2022-06-24 12:24:35.512904
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    assert i.ie_key() == 'PornTube'

# Generated at 2022-06-24 12:24:36.145709
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:24:40.877775
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:46.366805
# Unit test for constructor of class FuxIE
def test_FuxIE():
    a = FuxIE()
    assert a._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert a._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert a._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:24:57.568825
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:59.952337
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:25:02.733926
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_IE = FuxIE()
    assert fux_IE.IE_NAME == '4tube'

# Generated at 2022-06-24 12:25:09.688264
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """ run some basic tests to see if the test class runs as intended """
    
    # Test the url structure for the PornTubeIE class
    test_url = "https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406"
    test_url_info = {"id": "1331406",
                     "display_id": "squirting-teen-ballerina-ecg",
                     "kind": "www"}
    assert(PornTubeIE._match_id(test_url) == test_url_info)

# Generated at 2022-06-24 12:25:10.510693
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE({})


# Generated at 2022-06-24 12:25:12.940235
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test for constructor of class FuxIE
    FuxIE("https://www.fux.com/video/247350/saved-by-the-cock")

# Generated at 2022-06-24 12:25:16.825746
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie._VALID_URL == ""
    assert ie._TESTS == []
    assert ie._TKN_HOST == ""
    assert ie._URL_TEMPLATE == ""
    
# No code for PornhubIE yet


# Generated at 2022-06-24 12:25:17.774792
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    handler = FourTubeBaseIE()

# Generated at 2022-06-24 12:25:22.456659
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:25:26.625188
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()._real_extract("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

# Generated at 2022-06-24 12:25:36.813480
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    # get instance of class FourTubeIE
    ie = FourTubeIE()
    # initialize with argument url
    ie.initialize(url)

# Generated at 2022-06-24 12:25:40.558136
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    '''
    Test constructor
    '''
    # TODO >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # Test is incomplete and therefore skipped
    import unittest
    raise unittest.SkipTest('FourTubeBaseIE.__init__ not tested yet.')

# Generated at 2022-06-24 12:25:42.568987
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()



# Generated at 2022-06-24 12:25:43.222304
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:25:47.454316
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._VALID_URL == PornTubeIE._VALID_URL
    assert ie._URL_TEMPLATE == PornTubeIE._URL_TEMPLATE
    assert ie._TKN_HOST == PornTubeIE._TKN_HOST


# Generated at 2022-06-24 12:25:52.632047
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test with an invalid URL
    with pytest.raises(ExtractorError):
        FourTubeIE()._real_initialize('invalid')
    # Test with a valid URL
    FourTubeIE()._real_initialize('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-24 12:25:54.614444
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:25:58.672779
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:26:06.264657
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie.VALID_URL == 'https?://(?:(?P<kind>www|m)\.?)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie.URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie.TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:26:11.155042
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie._VALID_URL == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'


# Generated at 2022-06-24 12:26:12.950013
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE();
    fuxIE._TESTS[0]

# Generated at 2022-06-24 12:26:13.996669
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:26:16.282309
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
