

# Generated at 2022-06-24 12:16:15.177893
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-24 12:16:16.668706
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
        assert True
    except:
        assert False


# Generated at 2022-06-24 12:16:27.910486
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert isinstance(ie, PornTubeIE)
    assert isinstance(ie, FourTubeBaseIE)
    # TODO: This should be the assert URL, but it's wrong
    # url = 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert ie.suitable(url) == True
    # TODO: This should return true, but it's not the correct URL
    # url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_1813

# Generated at 2022-06-24 12:16:28.602020
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:16:31.691668
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE("https://www.porntube.com/videos/xxx_1234567")
    obj_clone = PornTubeIE("https://www.porntube.com/videos/xxx_1234567")
    assert(obj == obj_clone)

# Generated at 2022-06-24 12:16:38.090129
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

    assert ie.IE_NAME == "4tube"
    assert len(ie._TESTS) == 3
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie.__dict__.get("_TKN_HOST") == "token.4tube.com"

# Generated at 2022-06-24 12:16:42.362216
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie._TKN_HOST == 'token.pornerbros.com'
    assert pornerbros_ie._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'

# Generated at 2022-06-24 12:16:43.307668
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # create the test object
    PornerBrosIE()

# Generated at 2022-06-24 12:16:52.447253
# Unit test for constructor of class FuxIE
def test_FuxIE():
    temp = FuxIE()
    assert temp._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert temp._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert temp._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:16:53.804382
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()
    PornerBrosIE("test")

# Generated at 2022-06-24 12:17:03.708481
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    success = False
    video_id = '7089759'
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_%s' % video_id
    title = PornTubeIE()._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        PornTubeIE()._download_webpage(url, video_id), 'data', group='value')
    title = PornTubeIE()._parse_json(title, video_id)['page']['video']['title']
    success = (title == 'Teen couple doing anal')
    return success

# Generated at 2022-06-24 12:17:07.498540
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fmt = 'http://www.fux.com/embed/' + ('%d'%i for i in range(10))
    for url in fmt:
        assert url == FuxIE._VALID_URL
    assert_raises(TypeError, FuxIE._VALID_URL)

# Generated at 2022-06-24 12:17:09.414511
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    print(instance)

# Generated at 2022-06-24 12:17:12.748818
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        fourTubeIE = FourTubeIE()
        print(fourTubeIE._TKN_HOST)
    except:
        print("exception")
        sys.exit()


# Generated at 2022-06-24 12:17:17.006548
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    result_1 = FourTubeBaseIE._build_token_url('www.foo.com', 'bar/baz', ['a', 'b'])
    expected_1 = 'https://bar/baz/desktop/a+b'
    assert result_1 == expected_1

    result_2 = FourTubeBaseIE._build_token_url('foo.com', 'bar/baz', ['a', 'b'])
    expected_2 = 'https://bar/baz/desktop/a+b'
    assert result_2 == expected_2

# Generated at 2022-06-24 12:17:28.713979
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Time of creation of the video
    timestamp = 1388361660
    # MD5 hash of file
    md5 = '1b0ad20b96056c7a134e560a59b7d46b'
    assert FuxIE(None).timestamp_to_unix_time(timestamp) == datetime(2014, 1, 1, 8, 41, 0)
    assert FuxIE(None).timestamp_to_unix_time(100000000000000) == datetime(2001, 9, 9, 1, 46, 40)
    assert FuxIE(None).md5_hash_file(md5) == md5

# Generated at 2022-06-24 12:17:35.242197
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test class constructor
    ie = PornerBrosIE()
    assert ie
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    assert ie._TES

# Generated at 2022-06-24 12:17:42.398119
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print("Running unit test for constructor of class FourTubeIE")
    test_class = FourTubeIE()
    assert(test_class._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(test_class._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(test_class._TKN_HOST == 'token.4tube.com')

# Generated at 2022-06-24 12:17:45.531269
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    assert obj._TKN_HOST == "token.fux.com"
    obj = PornTubeIE()
    assert obj._TKN_HOST == "tkn.porntube.com"
    obj = PornerBrosIE()
    assert obj._TKN_HOST == "token.pornerbros.com"

# Generated at 2022-06-24 12:17:46.522644
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

# Generated at 2022-06-24 12:17:59.586658
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_object = FourTubeBaseIE()

# Generated at 2022-06-24 12:18:00.205531
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:18:02.852168
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Should be able to initialize instance of class FourTubeIE
    """
    for cls in [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]:
        cls()

# Generated at 2022-06-24 12:18:05.379835
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:18:15.000460
# Unit test for constructor of class FuxIE

# Generated at 2022-06-24 12:18:20.605586
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'

# Generated at 2022-06-24 12:18:22.782899
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        # Unfortunately, this is the only way to know if a class has been
        # implemented as an abstract class or not :/
        instance = FourTubeBaseIE()
    except TypeError:
        return True
    except Exception:
        return False
    else:
        return False

# Generated at 2022-06-24 12:18:35.489476
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    # test constructor return value
    ie = FourTubeIE()
    assert isinstance(ie, FourTubeBaseIE)

    mobj = re.match(FourTubeBaseIE._VALID_URL, url)
    assert mobj is not None
    assert mobj.group('id') is not None
    assert mobj.group('display_id') is not None
    assert mobj.group('kind') is not None

    # test constructor parameter
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == FourTubeBaseIE._VALID_URL
    assert ie._URL_TEMPL

# Generated at 2022-06-24 12:18:36.569803
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-24 12:18:40.407583
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TESTS[0]['info_dict']['title'] == 'Awesome fucking in the kitchen ends with cum swallow'
    assert ie._TESTS[1]['only_matching'] == True
    

# Generated at 2022-06-24 12:18:41.764457
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test = FuxIE()
    test.__init__()


# Generated at 2022-06-24 12:18:42.230020
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:18:43.129695
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert PornHubIE()._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:18:51.435466
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # To check if the constructor of the parent class has been invoked
    test = FourTubeIE()
    assert test._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert test._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video"
    assert test._TKN_HOST == "token.4tube.com"
    assert True

# Generated at 2022-06-24 12:18:54.073817
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # pass an empty dict for network connection
    PornTubeIE({})._extract_formats('', '', '', [])

# Generated at 2022-06-24 12:18:55.619918
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    unit = PornerBrosIE()
    assert(unit is not None)



# Generated at 2022-06-24 12:18:57.380785
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    _obj = FourTubeBaseIE()
    assert _obj._TKN_HOST == "token.4tube.com"

# Generated at 2022-06-24 12:18:58.365950
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()



# Generated at 2022-06-24 12:19:05.322261
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert hasattr(FourTubeIE, '_TKN_HOST')
    assert hasattr(FourTubeIE, '_URL_TEMPLATE')
    fourtubie = FourTubeIE()
    assert fourtubie.IE_NAME == '4tube'
    assert fourtubie._TKN_HOST == 'token.4tube.com'
    assert fourtubie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-24 12:19:10.096955
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    fields = ['_VALID_URL', '_URL_TEMPLATE', '_TKN_HOST']
    for f in fields:
        if not hasattr(PornTubeIE, f):
            raise ValueError('%s must contain field %s' % (PornTubeIE.__name__, f))
        if not getattr(PornTubeIE, f):
            raise ValueError('%s must contain non-empty string in %s' % (PornTubeIE.__name__, f))

    # Test that PornerBrosIE is a subclass of PornTubeIE
    if not issubclass(PornerBrosIE, PornTubeIE):
        raise ValueError('PornerBrosIE must be a subclass of PornTubeIE')

    # Test that PornerBrosIE has no attribute _VALID_URL

# Generated at 2022-06-24 12:19:19.280416
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    video_id_example = 181369
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_%s'

    instance = PornerBrosIE()

    # Test for attribute _VALID_URL
    mobj = re.match(instance._VALID_URL, url % video_id_example)
    assert(mobj is not None)

    # Test for attribute _URL_TEMPLATE
    assert(instance._URL_TEMPLATE % video_id_example == url % video_id_example)

    # Test for attribute _TKN_HOST
    assert(instance._TKN_HOST == 'token.pornerbros.com')

    # Test for attribute _TESTS

# Generated at 2022-06-24 12:19:29.548355
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:19:40.077903
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Test FuxIE constructor.

    Assert that FuxIE.
    _VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    _URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    _TKN_HOST == 'token.fux.com'
    """
    fux = FuxIE()

# Generated at 2022-06-24 12:19:51.485062
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTube = FourTubeIE()
    assert fourTube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:19:53.906624
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:19:55.047614
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie

# Generated at 2022-06-24 12:19:56.179126
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:05.485630
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert 'www.4tube.com' in FourTubeIE._download_json.__func__.__globals__['_NETRC_MACHINE']
    assert 'token.4tube.com' in FourTubeIE._download_json.__func__.__globals__['_NETRC_MACHINE']
    assert 'm.4tube.com' in FourTubeIE._download_json.__func__.__globals__['_NETRC_MACHINE']
    assert 'www.4tube.com' in FourTubeIE._download_webpage.__func__.__globals__['_NETRC_MACHINE']
    assert 'www.4tube.com' in FourTubeIE._download_webpage.__func__.__globals__['_TOKEN_HOST']

# Generated at 2022-06-24 12:20:06.495429
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:09.653706
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369', '181369')


# Generated at 2022-06-24 12:20:11.505450
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Check the constructor of FuxIE.
    _ = FuxIE('https://www.fux.com/embed/195359')


# Generated at 2022-06-24 12:20:17.563279
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert(not PornerBrosIE.ie_key() == FourTubeIE.ie_key())
    assert(not PornerBrosIE.ie_key() == FuxIE.ie_key())
    assert(not PornerBrosIE.ie_key() == PornTubeIE.ie_key())
    assert(not PornerBrosIE._TKN_HOST == FourTubeIE._TKN_HOST)
    assert(not PornerBrosIE._TKN_HOST == FuxIE._TKN_HOST)
    assert(not PornerBrosIE._TKN_HOST == PornTubeIE._TKN_HOST)
    assert(not PornerBrosIE._URL_TEMPLATE == FourTubeIE._URL_TEMPLATE)

# Generated at 2022-06-24 12:20:30.439842
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ut = FourTubeBaseIE()
    assert ut.IE_NAME == '4tube'
    assert ut._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ut._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ut._TKN_HOST == 'token.4tube.com'

    fu = FuxIE()
    assert fu.IE_NAME == 'fux'

# Generated at 2022-06-24 12:20:33.448823
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
    except:
        assert False, "Constructor of class PornTubeIE failed"

# Generated at 2022-06-24 12:20:34.839624
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:20:37.942341
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Tests that constructor raises an error when the required parameters are not given
    with pytest.raises(TypeError):
        FourTubeBaseIE()



# Generated at 2022-06-24 12:20:43.011481
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._VALID_URL
    assert obj._URL_TEMPLATE
    assert obj._TKN_HOST
    assert '4tube' in obj._TESTS
    assert 'fux' in obj._TESTS
    assert 'porntube' in obj._TESTS
    assert 'pornerbros' in obj._TESTS

# Generated at 2022-06-24 12:20:45.072467
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    You must import this module to execute the test because of the
    creation of an instance of FourTubeIE.
    """
    fourtube = FourTubeIE()

# Generated at 2022-06-24 12:20:45.859755
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    temp = PornTubeIE()

# Generated at 2022-06-24 12:20:52.213932
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    FourTubeIE()._TKN_HOST
    FourTubeIE._TESTS
    FourTubeIE.IE_NAME
    FourTubeIE.ie_key()
    FourTubeIE._VALID_URL
    FourTubeIE.THUMB_URL_TEMPLATE
    FourTubeIE.CANONICAL_URL_TEMPLATE

# Generated at 2022-06-24 12:20:52.945031
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:20:54.518287
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert '4tube' == FourTubeIE.ie_key()


# Generated at 2022-06-24 12:20:58.084433
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE(None, None, None)
    except Exception as ex:
      # class FourTubeBaseIE should have a constructor
      # that takes three arguments
      raise ex

# Generated at 2022-06-24 12:21:07.863705
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
        #test 1
        my_test1 = PornerBrosIE({'ext': '.mp4', 'id': '181369', 'title': 'Skinny brunette takes big cock down her anal hole', 'uploader': 'PornerBros HD', 'uploader_id': 'pornerbros-hd'})
        assert(my_test1.get_id()=='181369')
        assert(my_test1.get_title()=='Skinny brunette takes big cock down her anal hole')

        #test 2
        my_test2 = PornerBrosIE({'tags': ['Teen', 'Brunette', 'Anal', 'Big_Dick', 'HD', 'PornerBros HD']})

# Generated at 2022-06-24 12:21:17.779265
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_object = PornerBrosIE("https://www.pornerbros.com/videos/video_181369")
    assert test_object._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert test_object._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert test_object._TKN_HOST == 'token.pornerbros.com'
    return test_object

# Generated at 2022-06-24 12:21:22.711830
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    #noinspection PyUnresolvedReferences
    from youtube_dl.utils import youtube_dl_fourtube
    #noinspection PyUnresolvedReferences
    from youtube_dl.extractor.fourtube import FourTubeBaseIE

    # Test for constructor of class FourTubeIE
    assert(isinstance(youtube_dl_fourtube.FourTubeIE(), FourTubeBaseIE))



# Generated at 2022-06-24 12:21:37.138490
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Description:
        Test function for the Fux class.

    """
    # Initialize the class
    fux_ie = FuxIE()

    # Check the URL template
    assert fux_ie._URL_TEMPLATE == "https://www.fux.com/video/%s/video"

    # Check the URL host
    assert fux_ie._TKN_HOST == "token.fux.com"

    # Check the URL regular expression
    assert re.match(fux_ie._VALID_URL, 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

    # Check the format list

# Generated at 2022-06-24 12:21:41.441708
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()

# Generated at 2022-06-24 12:21:47.059061
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # If a parameter url is passed and it is a valid url,
    # then it should create an object of class FourTubeIE
    assert FourTubeIE(url='http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-24 12:21:56.754149
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()

# Generated at 2022-06-24 12:22:03.458446
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.suitable('http://www.porntube.com/videos/natural-japanese-teen-gets-nasty-fucked_707601')
    assert ie.suitable('https://www.porntube.com/embed/7089759')
    assert ie.suitable('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-24 12:22:06.992466
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST is not None
    assert FourTubeBaseIE._URL_TEMPLATE is not None
    assert FourTubeBaseIE._VALID_URL is not None

# Generated at 2022-06-24 12:22:08.018389
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _test_class(PornTubeIE)

# Generated at 2022-06-24 12:22:11.758554
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-24 12:22:15.649159
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE(FourTubeBaseIE)._VALID_URL == FourTubeBaseIE._VALID_URL

# Generated at 2022-06-24 12:22:22.754720
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class DummyIE(FourTubeBaseIE):
        IE_NAME = '4tube'
        _VALID_URL = r'4tube'

    # smoke test
    DummyIE()._download_webpage('http://www.4tube.com', 'fake_id')
    DummyIE()._extract_formats('http://www.4tube.com', 'fake_id', 'fake_media_id', ['1080', '720', '480', '360'])

# Generated at 2022-06-24 12:22:24.857504
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE(FourTubeIE.ie_key())
    assert (obj.ie_key() == '4tube')


# Generated at 2022-06-24 12:22:29.453033
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeIE()
    FuxIE()
    PornTubeIE()
    PornerBrosIE()

# Generated at 2022-06-24 12:22:31.720149
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        placeholder = FourTubeIE()
    except Exception as e:
        raise e

# Generated at 2022-06-24 12:22:36.961381
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    title = 'Teen couple doing anal'
    video_id = '7089759'
    media_id = '7089759'
    sources = ['720', '480', '240']
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    formats = ie._extract_formats(url, video_id, media_id, sources)
    #print(formats)

    assert(formats[0]['resolution'] == '720p')

# Generated at 2022-06-24 12:22:48.283660
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from ..core import InfoExtractor
    from ..downloader import HTTPDownloader
    from ..downloader.common import FileDownloader

    url = 'https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-24 12:23:01.083915
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()

# Generated at 2022-06-24 12:23:01.690715
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()

# Generated at 2022-06-24 12:23:07.591275
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:23:19.529464
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    _FourTubeIE = FourTubeIE()

    class test_FourTubeIE(type(FourTubeIE)):
        def _extract_formats(self, url, video_id, media_id, sources):
            self.sources = sources
            return [{'url': 'http://example.com/123.mp4'}]
    _FourTubeIE.__class__ = test_FourTubeIE

    _FourTubeIE._real_extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert _FourTubeIE.sources == ['720', '480', '360']


# Generated at 2022-06-24 12:23:31.417051
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    object_FourTubeIE = FourTubeIE('FourTubeIE')
    assert object_FourTubeIE.IE_NAME == '4tube'
    assert object_FourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert object_FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert object_FourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:23:40.077762
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE("PornerBrosIE", "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    assert ie.valid_url == "https://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)"
    assert ie._URL_TEMPLATE == "https://www.pornerbros.com/videos/video_%s"
    assert ie._TKN_HOST == "token.pornerbros.com"

# Generated at 2022-06-24 12:23:45.960492
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourtubeIE = FourTubeBaseIE()
    fourtubeIE._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    fourtubeIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:23:48.301967
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except:
        assert False


# Generated at 2022-06-24 12:23:57.068497
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie.IE_NAME == 'Fux'
    assert ie.IE_DESC == 'Fux'
    assert ie.__name__ == 'FuxIE'
    assert ie.age_limit == 18


# Generated at 2022-06-24 12:23:57.799300
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    x = FourTubeIE()

# Generated at 2022-06-24 12:23:58.580966
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()

# Generated at 2022-06-24 12:23:59.649851
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print (FourTubeIE)

# Generated at 2022-06-24 12:24:02.759999
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.ie_key() == 'Fux'
    assert ie.ie_name() == 'Fux'
    assert ie.ie_desc() == 'Fux: Porn Videos'

# Generated at 2022-06-24 12:24:04.175024
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:24:05.306403
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:24:06.195416
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:24:07.421570
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test = PornTubeIE()
    test._search_regex

# Generated at 2022-06-24 12:24:16.157052
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Simple test for FuxIE
    """
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    instance = FuxIE()
    instance._download_webpage(url, "test")

# Generated at 2022-06-24 12:24:27.226262
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    FourTubeBaseIE._TKN_HOST = 'token.4tube.com'
    FourTubeBaseIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    # when test, call the extract function in class without object
    info = FourTubeBaseIE._real_extract("https://www.4tube.com/embed/209733", None)
    print(json.dumps(info))
    print("Test end")

# When test, call the extract function in class without object

# Generated at 2022-06-24 12:24:37.091808
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .tests.test_pornhub import (
        PornHubPagesIE, PornHubPlaylistIE, PornHubUserVideosIE)

    from .tests.test_porntube import PornTubePlaylistIE

    from .tests import playlists_tests

    for ie_name in ('PornHub', 'PornTube'):
        for playlist_test in playlists_tests:
            if playlist_test['info_dict']['_type'] == ie_name:
                playlist_test['info_dict']['_type'] = ie_name + 'Playlist'


# Generated at 2022-06-24 12:24:39.796312
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
    except:
        print("FuxIE - Unit test failed")
    else:
        print("FuxIE - Unit test passed")


# Generated at 2022-06-24 12:24:40.722078
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    return FourTubeIE({})

# Generated at 2022-06-24 12:24:43.563526
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert(fux_ie.IE_NAME == '4tube')

# Generated at 2022-06-24 12:24:44.918767
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()
    assert i

# Generated at 2022-06-24 12:24:46.363065
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test constructor of class PornTubeIE
    i = PornTubeIE()
    assert i

# Generated at 2022-06-24 12:24:47.625264
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None, None)

# Generated at 2022-06-24 12:24:48.675226
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    example = PornTubeIE()

# Generated at 2022-06-24 12:24:58.753226
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    assert FuxIE()._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE()._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert FuxIE()._TESTS[0]['url'] == url

# Generated at 2022-06-24 12:25:03.781404
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-24 12:25:07.900336
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        ie = FourTubeBaseIE()
        assert False
    except Exception:
        assert True
    try:
        ie = FuxIE()
        assert False
    except Exception:
        assert True
    try:
        ie = PornTubeIE()
        assert False
    except Exception:
        assert True
    try:
        ie = PornerBrosIE()
        assert False
    except Exception:
        assert True

# Generated at 2022-06-24 12:25:11.862880
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FuxIE()
    assert f.IE_NAME == 'fux'
    assert f.IE_DESC == 'Fux'
    assert f.__name__ == 'FuxIE'
    assert f.__module__ == 'fux'

# Generated at 2022-06-24 12:25:19.916255
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # This test is meant to cover the case of when INITIALSTATE
    # doesn't contain the expected video ID
    downloader = PornTubeIE()
    url = 'https://www.porntube.com/embed/173545'
    webpage = downloader._download_webpage(url, '173545')
    pattern = PornTubeIE._VALID_URL
    mobj = re.match(pattern, url)
    video_id, display_id = mobj.group('id', 'display_id')


# Generated at 2022-06-24 12:25:22.291910
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux
    assert type(fux) is FuxIE 


# Generated at 2022-06-24 12:25:33.394308
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	# Create a new instance of class PornTubeIE
	video = PornTubeIE()
	# Create a new instance of class FourTubeBaseIE
	video2 = FourTubeBaseIE()
	# Get a test video
	video_id = 209733
	# Get the video url
	url = video._URL_TEMPLATE % video_id
	# Get the video name
	title_name = video._TEST[0]['info_dict']['title']
	# Get the video duration
	duration = video._TEST[0]['info_dict']['duration']
	# Get the video formats
	formats = video._TEST[0]['info_dict']['formats']
	# Get the video categries
	categories = video._TEST[0]['info_dict']['categories']
	#

# Generated at 2022-06-24 12:25:35.211829
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # does not test anything special
    FourTubeBaseIE(InfoExtractor)._real_extract('http://example.com')

# Generated at 2022-06-24 12:25:46.286575
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_func = lambda x: None
    test_func.__name__ = 'test_func'
    video_id = 'id'
    media_id = 'media_id'
    sources = ['720', '480', '360']
    url = 'https://www.4tube.com/videos/id'

    ie = FourTubeBaseIE()
    ie.suitable(url)
    ie.extract(url)
    ie._extract_formats = test_func
    ie._real_extract(url)
    assert ie.IE_NAME == '4Tube'

# Generated at 2022-06-24 12:25:55.641850
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    b = PornerBrosIE(PornerBrosIE.ie_key())
    assert b.name == "pornerbros"
    assert b.ie_key() == "PornerBros"
    assert b.ie_key() == "pornerbros"
    assert b.ie_key() == "pornerbros.com"
    assert b.ie_key() == "PornerBrosIE"
    assert b.ie_key() == "4TubeBase"
    assert PornerBrosIE.ie_key() == "PornerBros"
    assert PornerBrosIE.ie_key() == "pornerbros"
    assert PornerBrosIE.ie_key() == "pornerbros.com"

# Generated at 2022-06-24 12:26:00.366221
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert isinstance(ie, FourTubeIE)

# Generated at 2022-06-24 12:26:01.556992
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE is not None

# Generated at 2022-06-24 12:26:02.845978
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:26:09.575762
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test to see if the constructor of FourTubeIE is working
    import unittest
    import logging
    class FourTubeIETest(unittest.TestCase):
        def test_constructor_params(self):
            try:
                FourTubeIE(None, None)
            except:
                self.fail('test constructor FourTubeIE failed')
    suite = unittest.TestLoader().loadTestsFromTestCase(FourTubeIETest)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 12:26:13.145950
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert 'https://www.fux.com' in fux.http_headers['Referer']
    assert fux.IE_NAME == 'www.fux.com'

# Generated at 2022-06-24 12:26:16.177182
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_utils import get_testdata_file
    data = get_testdata_file('pornerbros_video.json', module_name=__name__)
    video = PornerBrosIE()._parse_json(data, '1')['page']['video']
    assert video['title'] == 'Skinny brunette takes big cock down her anal hole'
    assert video['durationInSeconds'] == 1224

