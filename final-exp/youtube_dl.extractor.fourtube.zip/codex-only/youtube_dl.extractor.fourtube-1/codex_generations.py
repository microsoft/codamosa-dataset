

# Generated at 2022-06-24 12:16:17.203179
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'
    assert FuxIE._TKN_HOST == 'token.fux.com'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    return None

# Generated at 2022-06-24 12:16:27.955619
# Unit test for constructor of class FuxIE
def test_FuxIE():
    parsed_url = compat_urlparse.urlparse('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert FuxIE.suitable('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow') == True
    assert FuxIE.suitable('https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369') == False

# Generated at 2022-06-24 12:16:34.608307
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:16:35.252271
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:16:38.476427
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = FuxIE()
    ie.extract(url)


# Generated at 2022-06-24 12:16:39.115200
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:16:45.304726
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST == "token.4tube.com"
    assert FourTubeBaseIE._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video"  # NOQA
    assert FourTubeBaseIE._VALID_URL == r"https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"  # NOQA

# Generated at 2022-06-24 12:16:53.714437
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constructor = lambda url: FourTubeBaseIE()._real_initialize(url)
    q = {'token.pornerbros.com': 'https://token.pornerbros.com/181369/desktop/720p',
         'token.fux.com': 'https://token.fux.com/195359/desktop/720p',
         'token.4tube.com': 'https://token.4tube.com/209733/desktop/720p',
         'tkn.porntube.com': 'https://tkn.porntube.com/7089759/desktop/720p'}
    # use this to check the stability of network
    for i in q:
        a = q[i]
        b = constructor(a)['url']
        assert a == b

# Generated at 2022-06-24 12:17:04.825252
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test constructor of class FourTubeBaseIE"""
    # Test the case insensitivity of the class name
    ie_name = 'FourTube'
    # pylint: disable=invalid-name
    ie = globals()[ie_name + 'IE']()
    # pylint: enable=invalid-name
    assert ie._VALID_URL == (r'https?://(?:(?P<kind>www|m)\.)?' + ie_name.lower() +
        r'\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert ie._URL_TEMPLATE == 'https://www.%s.com/videos/%%s/video' % ie_name.lower()
    assert ie._TKN_HOST

# Generated at 2022-06-24 12:17:14.834373
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    "This is a unit test for class FourTubeBaseIE"
    from . import (
        FourTubeBaseIE,
        FourTubeIE,
        FuxIE,
        PornTubeIE,
        PornerBrosIE,
    )

    # First test for constructor
    instance1 = FourTubeIE()
    assert(isinstance(instance1, FourTubeBaseIE))

    # Second test for constructor
    instance2 = FuxIE()
    assert(isinstance(instance2, FourTubeBaseIE))

    # Third test for constructor
    instance3 = PornTubeIE()
    assert(isinstance(instance3, FourTubeBaseIE))

    # Fourth test for constructor
    instance4 = PornerBrosIE()
    assert(isinstance(instance4, FourTubeBaseIE))

# Generated at 2022-06-24 12:17:16.976664
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert isinstance(x,PornerBrosIE)==True


# Generated at 2022-06-24 12:17:22.129352
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    parsed_url = compat_urlparse.urlparse(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    kwargs = {
        'username': 'username',
        'password': 'password',
    }
    PornTubeIE.__base__.__init__(PornTubeIE, parsed_url, **kwargs)
    assert PornTubeIE.IE_NAME == 'porntube'
    assert PornTubeIE.IE_DESC == 'PornTube'


# Generated at 2022-06-24 12:17:23.454453
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE() != None


# Generated at 2022-06-24 12:17:24.579577
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornTube = PornTubeIE()

# Generated at 2022-06-24 12:17:33.427470
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # no view count (!)
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    expected_info = {'id': '181369', 'ext': 'mp4', 'title': 'Skinny brunette takes big cock down her anal hole', 'uploader': 'PornerBros HD', 'uploader_id': 'pornerbros-hd', 'upload_date': '20130130', 'timestamp': 1359527401, 'duration': 1224, 'view_count': int, 'categories': list, 'age_limit': 18}
    assert(PornerBrosIE._real_extract(PornerBrosIE(), url) == expected_info)

# Generated at 2022-06-24 12:17:39.671425
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.ie_key() == 'PornerBros'
    assert ie.ie_name() == 'PornerBros.com'
    _VALID_URL = ie._VALID_URL
    assert _VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:17:41.201988
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert isinstance(ie, FourTubeBaseIE)


# Generated at 2022-06-24 12:17:51.828649
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .common import InfoExtractor
    from .extractor.common import ExtractorError
    i = InfoExtractor(PornerBrosIE)
    url = 'https://www.pornerbros.com/embed/181369'
    assert i._VALID_URL == PornerBrosIE._VALID_URL
    assert i._TKN_HOST == PornerBrosIE._TKN_HOST
    assert i._URL_TEMPLATE == PornerBrosIE._URL_TEMPLATE
    assert i._TESTS == PornerBrosIE._TESTS
    se = PornerBrosIE()
    try:
       se.suitable(url)
    except ExtractorError:
       pass
    assert i.suitable(url)

# Generated at 2022-06-24 12:17:53.710100
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
    assert f


# Generated at 2022-06-24 12:18:04.110508
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie_FourTubeBaseIE = FuxIE()

    # Check pattern
    # _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie_FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    
    # Check pattern
    # _URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    assert ie_FourTubeBaseIE._URL

# Generated at 2022-06-24 12:18:13.849277
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    videos = [
        FourTubeIE('https://www.4tube.com/videos/20043/hot-teen-loves-to-suck-dick').playlist_result()[0],
        FourTubeIE('http://www.4tube.com/videos/20043/hot-teen-loves-to-suck-dick').playlist_result()[0],
        FourTubeIE('https://m.4tube.com/videos/20043/hot-teen-loves-to-suck-dick').playlist_result()[0]
    ]

    assert videos[0]['title'] == "Hot teen loves to suck dick"
    assert videos[1]['title'] == "Hot teen loves to suck dick"
    assert videos[2]['title'] == "Hot teen loves to suck dick"


# Generated at 2022-06-24 12:18:20.275374
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE.__module__ = 'test_FuxIE'
    fux_ie = FuxIE()
    # Verify class variables

# Generated at 2022-06-24 12:18:22.960088
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except Exception as e:
        print(e)
        print("Unit test failed")
        return False
    return True


# Generated at 2022-06-24 12:18:27.269228
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie_list = [FourTubeIE(), FuxIE(), PornTubeIE(), PornerBrosIE()]
    for ie in ie_list:
        test_data = ie._TESTS[0]['url']
        assert ie._match_id(test_data)

# Generated at 2022-06-24 12:18:39.441955
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	from sunyoulist import PornTubeIE
	from pprint import pprint
	from copy import copy
	from six.moves.urllib.parse import unquote
	import base64
	
	try:
		from json import loads
	except ImportError:
		from simplejson import loads

	def transform_source(x):
		return unquote(base64.b64decode(x).decode('utf-8'))
	url='https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_7089759'
	id='7089759'
	webpage=PornTubeIE._download_webpage(None,id,id,None,url)

# Generated at 2022-06-24 12:18:47.841533
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    def _real_extract(self, url):
        mobj = re.match(self._VALID_URL, url)
        video_id, display_id = mobj.group('id', 'display_id')

        webpage = self._download_webpage(url, display_id)

        video = self._parse_json(
            self._search_regex(
                r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
                webpage, 'data', group='value'), video_id,
            transform_source=lambda x: compat_urllib_parse_unquote(
                compat_b64decode(x).decode('utf-8')))['page']['video']

        title = video['title']
        media_id = video

# Generated at 2022-06-24 12:18:51.173358
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except:
        assert False


# Generated at 2022-06-24 12:19:01.446805
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Standard unit test setup for FourTubeBaseIE
    input_url = 'https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    expected_md5sum = '6516c8ac63b03de06bc8eac14362db4f'

# Generated at 2022-06-24 12:19:04.419839
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    class TestClass(FourTubeBaseIE):
        pass

    assert TestClass.IE_NAME == 'TestClass'


# Generated at 2022-06-24 12:19:06.734683
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """ test whether the constructor of class FuxIE is OK """
    instance = FuxIE()
    assert True


# Generated at 2022-06-24 12:19:08.762313
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = PornTubeIE._URL_TEMPLATE % '12345'
    assert PornTubeIE._VALID_URL.match(url)

# Generated at 2022-06-24 12:19:16.882945
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
    	import unittest
    except ImportError as e:
    	import sys
    	sys.stderr.write('Error: The unittest module is required to run this test.\n')
    	sys.exit(1)
    try:
    	import pafy
    except ImportError as e:
    	import sys
    	sys.stderr.write('Error: The pafy module is required to run this test.\n')
    	sys.exit(1)
    import pornhub
    try:
        getpass
    except:
        import sys
        sys.stderr.write(
            'Error: The getpass module is required to run this test.\n')
        sys.exit(1)
    from contextlib import contextmanager


# Generated at 2022-06-24 12:19:18.241016
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE(None, None)
    assert ie

# Generated at 2022-06-24 12:19:25.282930
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:19:27.008277
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.url is not None


# Generated at 2022-06-24 12:19:31.303955
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:19:37.890472
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube')

# Generated at 2022-06-24 12:19:39.144797
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert type(ie) == FourTubeIE
    

# Generated at 2022-06-24 12:19:41.132287
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()



# Generated at 2022-06-24 12:19:43.979291
# Unit test for constructor of class FuxIE
def test_FuxIE():
    result = FuxIE()._real_extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

    assert result



# Generated at 2022-06-24 12:19:45.389553
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('4tube', '4tube')


# Generated at 2022-06-24 12:19:48.705082
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # pylint: disable=no-member
    FuxIE._TESTS[0]['expected_formats'] = ['480p', '720p']

# Generated at 2022-06-24 12:19:54.232051
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info = PornTubeIE()._real_extract(
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert 'Exploited College Girls' == info.get('channel')
    assert '665' == info.get('channel_id')


# Generated at 2022-06-24 12:20:02.972799
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:20:04.252710
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test constructor, making sure it doesn't crash
    PornTubeIE('PornTube')

# Generated at 2022-06-24 12:20:05.180740
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()

# Generated at 2022-06-24 12:20:08.071418
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        ftb = FourTubeBaseIE()
        print("FourTubeBaseIE constructor ok.")
        print(ftb.__class__.__name__)
    except Exception as e:
        print("FourTubeBaseIE constructor failed.")
        print(str(e))


# Generated at 2022-06-24 12:20:09.801813
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert 'fux' in globals()
    assert 'porntube' in globals()
    assert 'pornerbros' in globals()

# Generated at 2022-06-24 12:20:11.562803
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube = PornTubeIE()
    assert porntube.IE_NAME == 'PornTube'

# Generated at 2022-06-24 12:20:18.923099
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE._TKN_HOST == 'token.fux.com'
    

# Generated at 2022-06-24 12:20:20.195217
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    super(PornerBrosIE, PornerBrosIE).__init__()

# Generated at 2022-06-24 12:20:21.452740
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:22.732660
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_extractor = PornTubeIE()
    assert info_extractor


# Generated at 2022-06-24 12:20:25.978457
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:20:28.506264
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Simple test for using constructor to initialize class
    try:
        _ = PornerBrosIE()
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-24 12:20:32.092694
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBros','TKN_HOST','TESTS','VALID_URL','URL_TEMPLATE','Porner Bros','PornerBros')

# Generated at 2022-06-24 12:20:34.085259
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
  ie = FourTubeIE()
  assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:44.171239
# Unit test for constructor of class FuxIE
def test_FuxIE():
    i = FuxIE() 

# Generated at 2022-06-24 12:20:44.905691
# Unit test for constructor of class FuxIE
def test_FuxIE():
    _ = FuxIE._TESTS[0]

# Generated at 2022-06-24 12:20:56.674816
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TESTS['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert PornTubeIE()._TESTS['info_dict'] == {'id': '7089759', 'ext': 'mp4',
                                                'title': 'Teen couple doing anal',
                                                'uploader': 'Alexy', 'duration': 5052,
                                                'timestamp': 1433595647, 'upload_date': '20150606',
                                                'uploader_id': '91488', 'age_limit': 18, 'view_count': int,
                                                'like_count': int, 'categories': list}
    assert PornTubeIE()._TESTS['params'] == {'skip_download': True}

# Generated at 2022-06-24 12:20:58.180693
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, object)

# Generated at 2022-06-24 12:21:02.446216
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TESTS[0]['url'] == PornTubeIE._VALID_URL
    assert PornTubeIE._TESTS[1]['url'] != PornTubeIE._VALID_URL
    assert PornTubeIE._TESTS[2]['url'] != PornTubeIE._VALID_URL

# Generated at 2022-06-24 12:21:03.345045
# Unit test for constructor of class FuxIE
def test_FuxIE():
	ie = FuxIE()
	assert ie.IE_NAME in ie.ie_key()

# Generated at 2022-06-24 12:21:05.291875
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornTubeIE = PornTubeIE()
    assert(str(pornTubeIE.__class__) == "<class 'youtube_dl.extractor.porntube.PornTubeIE'>")

# Generated at 2022-06-24 12:21:08.234963
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE('http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert ie.IE_NAME == '4tube.com'

# Generated at 2022-06-24 12:21:13.496077
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    video_id = '209733'
    display_id = ''
    url = 'http://www.4tube.com/videos/%s/%s' % (video_id, display_id)
    ie = FourTubeBaseIE(url)
    assert ie.video_id == video_id
    assert ie.display_id == display_id

# Generated at 2022-06-24 12:21:17.252705
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Test that FourTubeIE constructor doesn't raise an exception.
    """
    test_FourTubeIE = FourTubeIE()
    assert test_FourTubeIE != ""


# Generated at 2022-06-24 12:21:26.719776
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE('https://www.porntube.com/video/fat-indian-bimbo-gets-her-tight-pussy-pounded_7051275')._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTube

# Generated at 2022-06-24 12:21:35.255490
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .generic_constructor_tests import _generic_test_constructor
    _generic_test_constructor(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        PornTubeIE)

    _generic_test_constructor(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        PornTubeIE, 'https://www.porntube.com/embed/7089759')

    _generic_test_constructor(
        'https://m.porntube.com/videos/teen-couple-doing-anal_7089759',
        PornTubeIE)

# Generated at 2022-06-24 12:21:36.504120
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().IE_NAME == '4tube'

# Generated at 2022-06-24 12:21:43.245717
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert getattr(instance, '_TKN_HOST') == 'tkn.porntube.com'

# Generated at 2022-06-24 12:21:44.459100
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:21:48.501845
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_downloader import TestDownloader
    from .test_common import _TEST_CASES
    
    for test_case in _TEST_CASES:
        yield test_PornerBrosIE_test_case, test_case


# Generated at 2022-06-24 12:21:49.057359
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:21:55.960272
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class_ = FuxIE
    url = 'https://www.fux.com/embed/195359'
    ie = class_(url)

    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:22:04.326271
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_obj = PornTubeIE()
    assert test_obj.IE_NAME is not None
    assert test_obj._VALID_URL is not None
    assert test_obj._URL_TEMPLATE is not None
    assert test_obj._TKN_HOST is not None
    assert test_obj._TESTS is not None
    assert test_obj.suitable(test_obj._TESTS[0]['url']) is not True
    assert test_obj.IE_NAME == '4tube'

# Generated at 2022-06-24 12:22:05.459284
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(None)._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:22:10.730661
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._VALID_URL.startswith('https://(?:(?P')
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'


# Generated at 2022-06-24 12:22:12.947022
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    classname = obj.__class__.__name__
    assert obj.IE_NAME == classname

# Generated at 2022-06-24 12:22:16.522909
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    Test to check if you can construct object of PornTubeIE.
    """
    PornTubeIE()


# Generated at 2022-06-24 12:22:17.804698
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()

# Generated at 2022-06-24 12:22:18.695853
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 12:22:20.481118
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    print(dir(instance))
    print(PornTubeIE()._TKN_HOST)


# Generated at 2022-06-24 12:22:22.893459
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
        assert False, "Unit test for class FourTubeIE failed"
    except:
        assert True


# Generated at 2022-06-24 12:22:23.567287
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:22:33.210700
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()
    assert inst.IE_NAME == "pornerbros.com"
    assert inst._VALID_URL == r"https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)"

# Generated at 2022-06-24 12:22:37.892904
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
       PornerBrosIE("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    except AttributeError: # This happens when unit testing fails
       return False
    return True



# Generated at 2022-06-24 12:22:39.861672
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.IE_NAME
    ie._VALID_URL
    ie._TKN_HOST
    ie._TESTS
    ie._URL_TEMPLATE
    ie._TKN_HOST

# Generated at 2022-06-24 12:22:40.608171
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:22:43.710355
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """ 
    Test constructor of:
    class FuxIE(FourTubeBaseIE):
    """
    FuxIE("FuxIE")


# Generated at 2022-06-24 12:22:53.404901
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:23:00.325204
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    print(fux)
    print(fux._download_webpage)
    print(fux._html_search_regex)
    print(fux._parse_json)
    print(fux._search_regex)
    print(fux._extract_formats)
    print(fux._sort_formats)
    print(fux._download_json)

# Generated at 2022-06-24 12:23:04.763577
# Unit test for constructor of class FuxIE
def test_FuxIE(): 
	print("IN TEST")
	url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
	fux_ie = FuxIE()
	fux_ie.extract(url)

# Generated at 2022-06-24 12:23:05.964098
# Unit test for constructor of class FuxIE
def test_FuxIE():
    h = FuxIE()


test_FuxIE()

# Generated at 2022-06-24 12:23:08.099495
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except TypeError as e:
        assert 'abstract' in str(e)

# Generated at 2022-06-24 12:23:12.844417
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test that FuxIE inherits from FourTubeBaseIE
    assert issubclass(FuxIE,FourTubeBaseIE)
    # Test that FuxIE inherits from InfoExtractor
    assert issubclass(FuxIE, InfoExtractor)


# Generated at 2022-06-24 12:23:18.107382
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print("\n============================================================")
    print("Testing Constructor . . .")
    print("============================================================")
    for ie in [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]:
        ie_instance = ie()
        print(type(ie_instance))
    print("============================================================")


# Generated at 2022-06-24 12:23:22.098268
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE('FourTubeIE', '4tube', '.com', {}, {})
        FourTubeBaseIE('FuxIE', 'fux', '.com', {}, {})
        FourTubeBaseIE('PornTubeIE', 'porntube', '.com', {}, {})
        FourTubeBaseIE('PornerBrosIE', 'pornerbros', '.com', {}, {})
        print('Test successful.')
    except Exception as e:
        print('Test failed with error: ' + str(e))

test_FourTubeBaseIE()

# Generated at 2022-06-24 12:23:25.149665
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    constructor_test(FourTubeIE)


# Generated at 2022-06-24 12:23:31.230262
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    error_msg = 'Unit test for constructor of class PornTubeIE failed'
    assert PornTubeIE.__doc__.strip().startswith(PornTubeIE.IE_NAME), error_msg
    assert hasattr(PornTubeIE, '_VALID_URL'), error_msg
    assert hasattr(PornTubeIE, '_URL_TEMPLATE'), error_msg
    assert hasattr(PornTubeIE, '_TKN_HOST'), error_msg
    assert hasattr(PornTubeIE, '_TESTS'), error_msg

# Generated at 2022-06-24 12:23:34.485006
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # As we cannot create an instance of class FourTubeBaseIE, we check if its constructor works
    try:
        FourTubeBaseIE("FourTubeBaseIE")
    except NameError as e:
        assert False, "Failed to instantiate class FourTubeBaseIE"

# Generated at 2022-06-24 12:23:37.375695
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.PornerBros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE()._real_extract(url)

# Generated at 2022-06-24 12:23:43.878009
# Unit test for constructor of class FuxIE
def test_FuxIE():
    inst = FuxIE(None)
    assert inst._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
    assert inst._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert inst._TKN_HOST == "token.fux.com"

# Generated at 2022-06-24 12:23:45.460499
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()
    PornTubeIE()
    PornerBrosIE()

# Generated at 2022-06-24 12:23:46.915374
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:23:54.021010
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.get_media_id('http://www.porntube.com/embed/7089759') == '7089759'
    assert ie.get_media_id('https://www.porntube.com/videos/teen-couple-doing-anal_7089759') == '7089759'
    assert ie.get_media_id('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406') == '1331406'

# Generated at 2022-06-24 12:23:55.344988
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:23:56.924175
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE._downloader, PornerBrosIE._VALID_URL)
    assert True

# Generated at 2022-06-24 12:24:04.679944
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE()
    assert a.IE_NAME == 'PornTube'
    assert a.IE_DESC == 'PornTube'
    assert a._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert a._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-24 12:24:07.085065
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.ie_key() == 'Fux'
    assert ie.ie_name() == 'fux.com'


# Generated at 2022-06-24 12:24:11.544001
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # https://github.com/ytdl-org/youtube-dl/issues/10972
    from .fux import FuxIE
    fux = FuxIE()
    # Check that constructor doesn't throw an exception
    fux.get_info(
        'http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:24:16.875587
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie = PornerBrosIE()
    ie._download_webpage(url, '181369')

# Generated at 2022-06-24 12:24:18.154165
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        dummy_FourTubeBaseIE = FourTubeBaseIE()
    except:
        assert False

# Generated at 2022-06-24 12:24:29.940832
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    file_path = '/path/to/test_file'
    tkn_host = 'token.4tube.com'
    info_extractor = FourTubeBaseIE()
    # All of the constructor's attributes are 'protected'.
    # Constructors of subclasses are able to access these with 'self.<attr_name>'.
    # We can access them with 'info_extractor.<attr_name>'.
    info_extractor._downloader.params.update({'noprogress': True, 'nopart': True})
    info_extractor._TKN_HOST = tkn_host

    # Test _download_webpage

# Generated at 2022-06-24 12:24:34.420898
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test for initialization
    pornTube_ie = PornTubeIE()
    # Test for name
    assert pornTube_ie.IE_NAME == 'porntube'
    # Test for URLs
    assert pornTube_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornTube_ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pornTube_ie._TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-24 12:24:39.937065
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.IE_NAME == 'fux'
    assert FuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:24:51.638316
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # test for FourTubeIE
    try:
        FourTubeIE()
    except ValueError:
        print("FourTubeIE constructor test FAILED!")
    else:
        print("FourTubeIE constructor test PASSED!")
    # test for FuxIE
    try:
        FuxIE()
    except ValueError:
        print("FuxIE constructor test FAILED!")
    else:
        print("FuxIE constructor test PASSED!")
    # test for PornTubeIE
    try:
        PornTubeIE()
    except ValueError:
        print("PornTubeIE constructor test FAILED!")
    else:
        print("PornTubeIE constructor test PASSED!")
    # test for PornerBrosIE

# Generated at 2022-06-24 12:24:58.365739
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

    ie = PornTubeIE()
    assert ie._TKN_HOST == 'tkn.porntube.com'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

    ie = PornerBrosIE()

# Generated at 2022-06-24 12:25:01.670110
# Unit test for constructor of class FuxIE
def test_FuxIE():
    
    # Constructor
    fux = FuxIE()
    
    # Check extraction method
    print(fux.IE_NAME)
    assert fux.IE_NAME == '4tube'

# Generated at 2022-06-24 12:25:02.848746
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:25:04.842779
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert isinstance(PornTubeIE(), InfoExtractor)


# Generated at 2022-06-24 12:25:11.271613
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Unit test for constructor of class PornerBrosIE:
    """
    # Test all cases of initialization of the class
    ie = PornerBrosIE()
    # Test function _real_extract with url = None
    url = None
    url_attr = "url"
    url_attr_not_set = (hasattr(ie, url_attr) == False)
    assert url_attr_not_set, "Attribute %(url_attr)s of class %(cls)s should not be setted before extract method" \
                             % {'url_attr': url_attr, 'cls': PornerBrosIE.__name__}

# Generated at 2022-06-24 12:25:18.522467
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie.IE_DESC == 'PornerBros, Fux and PornTube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TK

# Generated at 2022-06-24 12:25:24.528810
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    parsed_url = compat_urlparse.urlparse(url)
    token_url = 'https://%s/%s/desktop/%s' % ('token.4tube.com', '209733', '+'.join(['1080', '720', '480', '360', '240']))

    parsed_url2 = compat_urlparse.urlparse(token_url)

# Generated at 2022-06-24 12:25:34.298433
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """These are for use with offline testing
    For online testing, use the various tests in the JSON files
    """
    ie = FourTubeIE()
    ie.download_webpage = lambda *a, **k: read_data('%s.html' % a[1])
    ie.get_urls_from_webpage = lambda *a, **k: [""]
    ie.get_video_from_url = lambda *a, **k: {'url': ''}
    ie.get_video_info = lambda *a, **k: {}
    # there's a lot more tests in test_youtube, but I suspect that only
    # get_urls_from_webpage and get_video_from_url should need to be overwritten
    return ie

# Generated at 2022-06-24 12:25:37.383360
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # FourTubeBaseIE can only be instantiated from its subclasses
    try: FourTubeBaseIE()
    except Exception as e:
        assert 'can only be instantiated from its subclasses' in repr(e)

# Generated at 2022-06-24 12:25:38.401942
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE(None, None)

# Generated at 2022-06-24 12:25:49.268581
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:25:51.509012
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('FourTube', 'www.4tube.com')
    FourTubeIE('FourTube', 'm.4tube.com')


# Generated at 2022-06-24 12:25:58.111817
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
  ie = FourTubeIE()
  assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
  assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
  assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:25:59.896486
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE().extract_info('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-24 12:26:02.214584
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test if an instance of PornTubeIE was successfully created
    # (so, test if the site is NOT blacklisted)
    PornTubeIE()

# Generated at 2022-06-24 12:26:11.610053
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest
    class Test_FuxIE(unittest.TestCase):

        def setUp(self):
            self.td = TestData()
            self.s = Test_FuxIE.s
            self.td['kwargs']['video_id'] = Test_FuxIE.video_id
            self.td['kwargs']['url'] = Test_FuxIE.url
            self.td['kwargs']['display_id'] = Test_FuxIE.display_id

        def test_init(self):
            self.s.assertTrue(self.td['got_results'])


# Generated at 2022-06-24 12:26:12.260798
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:26:22.290667
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import os
    import sys
    import unittest

    from .common import avx_download

    from . import jsunittest
    from . import ExtractorTestCase

    def setUpModule():
        jsunittest.setup_module()

    def tearDownModule():
        jsunittest.teardown_module()

    class FourTubeIETest(ExtractorTestCase):
        class FakeHeadRequest(unittest.TestCase):

            def __init__(self, url, status=200, headers={}):
                super(FourTubeIE.test_FourTubeIE.FourTubeIETest.FakeHeadRequest, self).__init__()
                self.url = url
                self.status = status
                self.headers = headers

            def __enter__(self):
                return self
