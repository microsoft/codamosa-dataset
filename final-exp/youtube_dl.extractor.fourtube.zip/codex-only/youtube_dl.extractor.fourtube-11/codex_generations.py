

# Generated at 2022-06-24 12:16:24.511976
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    assert x._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert x._TKN_HOST == 'token.pornerbros.com'
    assert x._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:16:26.671769
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    a = FourTubeBaseIE('FourTubeBaseIE', 'www.4tube.com')
    assert a._TESTS == []

# Generated at 2022-06-24 12:16:28.712680
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test that PornerBrosIE's constructor does not raise an exception
    pornerbros_ie = PornerBrosIE()

# Generated at 2022-06-24 12:16:29.448714
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass



# Generated at 2022-06-24 12:16:36.508144
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie.video_id = '209733'
    ie.display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie.webpage = 'FAKE WEBPAGE'
    ie.player_js = 'FAKE PLAYER JS'
    ie.params_js = 'FAKE PARAMETERS'
    ie.media_id = 'FAKE MEDIA ID'
    ie.sources = [1,2,3]

# Generated at 2022-06-24 12:16:38.568536
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # need to test, otherwise coverage is missing
    f = FuxIE()
    assert isinstance(f, FuxIE)



# Generated at 2022-06-24 12:16:39.565225
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE() is not None

# Generated at 2022-06-24 12:16:41.269030
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # pylint: disable=protected-access
    assert FourTubeBaseIE._TESTS == []

# Generated at 2022-06-24 12:16:42.239221
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert isinstance(PornTubeIE(), PornTubeIE)

# Generated at 2022-06-24 12:16:43.179763
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert "PornerBrosIE" in globals()

# Generated at 2022-06-24 12:16:50.349326
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(FourTubeBaseIE.ie_key())._TKN_HOST == 'token.4tube.com'
    assert FuxIE(FuxIE.ie_key())._TKN_HOST == 'token.fux.com'
    assert PornTubeIE(PornTubeIE.ie_key())._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(PornerBrosIE.ie_key())._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:17:00.838893
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
   #Url to test
   url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"

   #List with info of video
   info_items = [
       'id',
       'title',
       'ext',
       'categories',
       'age_limit',
       'upload_date'
   ]

   #Constructor to test
   ie = PornerBrosIE()
   #Get Youtube video
   video_info = ie._real_extract(url)

   #Assert
   assert video_info != None, 'No video extracted'
   assert all(item in video_info for item in info_items), 'No all video info items'

# Generated at 2022-06-24 12:17:03.342994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Test constructor of class FourTubeIE
    """
    fourTube = FourTubeIE()
    # Check if constructor is working properly
    assert fourTube is not None


# Generated at 2022-06-24 12:17:12.623058
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inputs = ['https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
              'https://www.4tube.com/embed/209733',
              'https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black']
    assert(FourTubeIE().suitable(inputs[0]))
    assert(FourTubeIE().suitable(inputs[1]))
    assert(FourTubeIE().suitable(inputs[2]))


# Generated at 2022-06-24 12:17:13.482526
# Unit test for constructor of class FuxIE
def test_FuxIE():
    currentClass = FuxIE(None)

# Generated at 2022-06-24 12:17:14.514309
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE(None, None);

# Generated at 2022-06-24 12:17:15.246829
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test = PornTubeIE()
    assert test

# Generated at 2022-06-24 12:17:22.435062
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Get PornerBrosIE instance
    pbIE = PornerBrosIE()
    
    # Get PornerBrosIE._VALID_URL
    valid_url = pbIE._VALID_URL
    print('VALID URL: ' + str(valid_url))
    
    # Get PornerBrosIE._URL_TEMPLATE
    url_template = pbIE._URL_TEMPLATE
    print('URL TEMPLATE: ' + str(url_template))
    
    # Get PornerBrosIE._TKN_HOST
    tkn_host = pbIE._TKN_HOST
    print('TKN HOST: ' + str(tkn_host))


# Generated at 2022-06-24 12:17:24.162638
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().IE_NAME == '4tube'


# Generated at 2022-06-24 12:17:25.317435
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE

# Generated at 2022-06-24 12:17:26.167545
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    return PornerBrosIE(None)



# Generated at 2022-06-24 12:17:29.577072
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ft_extractor = FourTubeIE(url)
    assert ft_extractor is not None

# Generated at 2022-06-24 12:17:34.515157
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE.__init__(IE_NAME = '4tube')
    FourTubeBaseIE.__init__(IE_NAME = 'fux')
    FourTubeBaseIE.__init__(IE_NAME = 'porntube')
    FourTubeBaseIE.__init__(IE_NAME = 'pornerbros')



# Generated at 2022-06-24 12:17:40.666701
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import sys
    import unittest

    def setUp(self):
        self.ptube_ie = PornTubeIE()

    def test_constructor(self):
        assert self.ptube_ie.protocols == ['http']

    suite = unittest.TestSuite()
    suite.addTest(unittest.FunctionTestCase(test_PornTubeIE))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-24 12:17:45.721692
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test non-JSON video
    test_arg = 'https://www.4tube.com/videos/217212/naughty-girl-gets-deep-penetration'
    fourtube_ie = FourTubeIE()
    fourtube_ie._download_webpage(test_arg, 'Downloading bogus HTML')
    assert fourtube_ie._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'


# Generated at 2022-06-24 12:17:47.089410
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print(FourTubeIE()._URL_TEMPLATE)


# Generated at 2022-06-24 12:18:00.110766
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # assert True
    fourtube_test = FourTubeIE()
    assert fourtube_test.IE_NAME == '4tube'
    assert fourtube_test._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourtube_test._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert fourtube_test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:18:01.158812
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('FourTube', True)


# Generated at 2022-06-24 12:18:04.146573
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .dummy_test import dummy_test_constructor
    dummy_test_constructor(FourTubeIE)
    dummy_test_constructor(FuxIE)
    dummy_test_constructor(PornTubeIE)
    dummy_test_constructor(PornerBrosIE)

# Generated at 2022-06-24 12:18:14.763505
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ..utils import ExtractorError
    from datetime import datetime

# Generated at 2022-06-24 12:18:15.466477
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert 'fux' in globals()

# Generated at 2022-06-24 12:18:17.023061
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.IE_NAME
    ie._VALID_URL


# Generated at 2022-06-24 12:18:18.918486
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Asserts that a porn_tube instance has been created
    PornTubeIE()

# Generated at 2022-06-24 12:18:23.945516
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_extractor = PornTubeIE()
    test_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    extracted_info = info_extractor._real_extract(test_url)

    assert extracted_info['id'] == '7089759'
    assert extracted_info['ext'] == 'mp4'
    assert extracted_info['title'] == 'Teen couple doing anal'
    assert extracted_info['uploader'] == 'Alexy'
    assert extracted_info['uploader_id'] == '91488'
    assert extracted_info['upload_date'] == '20150606'
    assert extracted_info['timestamp'] == 1433595647
    assert extracted_info['duration'] == 5052
    assert extracted_info['view_count'] == int


# Generated at 2022-06-24 12:18:27.534032
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TKN_HOST')
    assert hasattr(ie, '_TESTS')



# Generated at 2022-06-24 12:18:29.503863
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-24 12:18:37.523443
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import base64
    assert PornTubeIE._parse_json(base64.b64decode('IlVTRVI=')).decode('utf-8') == 'USER'
    assert PornTubeIE._parse_json(base64.b64decode('W0J5dGVzXQ==')).decode('utf-8') == 'Bytes'
    assert PornTubeIE._parse_json(base64.b64decode('W1tCeXRlc11d')).decode('utf-8') == '[Bytes]'

# Generated at 2022-06-24 12:18:39.790188
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()
    assert fourTubeBaseIE._TKN_HOST == "token.4tube.com"

# Generated at 2022-06-24 12:18:40.920333
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-24 12:18:41.549493
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:18:42.009562
# Unit test for constructor of class FuxIE
def test_FuxIE():
	FuxIE()

# Generated at 2022-06-24 12:18:46.694175
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/embed/195359'
    fux = FuxIE()
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'
    assert fux._TESTS is not None


# Generated at 2022-06-24 12:18:58.117363
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    proto = 'http://'
    host = 'foo.bar/'
    path = 'video/1/'
    id = '1'
    sources = ['2', '3']

    src = proto + host + 'videos/' + path
    token_url = proto + 'token.' + host[:-1] + '/' + id + '/desktop/' + '%2B'.join(sources)

    assert ie.FourTubeBaseIE._TKN_HOST == 'token.4tube.com'

    # sign is 1

# Generated at 2022-06-24 12:18:59.501365
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fb = FourTubeBaseIE()
    assert fb is not None

# Generated at 2022-06-24 12:19:03.467178
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:19:10.779708
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    payload = {}

# Generated at 2022-06-24 12:19:11.693906
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert repr(FourTubeIE()) != ''


# Generated at 2022-06-24 12:19:15.113685
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert (p._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')

# Generated at 2022-06-24 12:19:18.011267
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    m = PornTubeIE()

    assert(m is not None)
    assert(m._VALID_URL == PornTubeIE._VALID_URL)

# Generated at 2022-06-24 12:19:23.003170
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    # unit test for constructor of class PornTubeIE
    pornTube_ie = PornTubeIE()
    result = pornTube_ie._real_extract(url)
    print(result)
    assert result['title'] is not None

# Generated at 2022-06-24 12:19:23.667366
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)


# Generated at 2022-06-24 12:19:24.294985
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass

# Generated at 2022-06-24 12:19:27.838969
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE('https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert fux.ie_key() == 'Fux'



# Generated at 2022-06-24 12:19:29.186271
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('')
    print(ie)


# Generated at 2022-06-24 12:19:30.120074
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base = FourTubeBaseIE('test')
    assert isinstance(base, InfoExtractor)

# Generated at 2022-06-24 12:19:31.386340
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:19:42.250553
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:19:53.025888
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test case for search of title and description of the video
    # http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black
    # The expected title is "Hot Babe Holly Michaels gets her ass stuffed by black"
    search_title = "Hot Babe Holly Michaels gets her ass stuffed by black"
    search_description = "Hot Babe Holly Mich..."
    test_url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"

    # Create an instance of FourTubeIE
    fourTubeIE = FourTubeIE()

    # Get information of the video
    info = fourTubeIE._extract_info(test_url)



# Generated at 2022-06-24 12:20:03.170842
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:09.481351
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:11.939460
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Just to check if the constructor of PornTubeIE is implemented properly
    porn_tube_ie = PornTubeIE()
    if porn_tube_ie.name == "PornTube":
        assert True

# Generated at 2022-06-24 12:20:21.834347
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test for class FourTubeIE with an example URL
    example_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    webpage = '<!doctype html>...<script id="playerembed" src="//player.4tube.com/js/embed.js"></script>...<script>...Token({...});</script>...</html>'
    expected_title = 'Hot Babe Holly Michaels gets her ass stuffed by black'
    expected_thumbnail = 're:^https?://.*\.jpg$'
    expected_duration = 583
    expected_uploader = 'WCP Club'
    expected_upload_date = '20131031'
    expected_view_count = int
    expected

# Generated at 2022-06-24 12:20:30.176649
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import re
    import unittest
    #from test_4tube_ie import FourTubeIE
    
    class Test4TubeIE(unittest.TestCase):
        def setUp(self):
            self.test1_video_id = '209733'
            self.test1_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
            self.test2_url = 'https://www.4tube.com/embed/209733'
            self.test3_url = 'http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
            self.test4_url

# Generated at 2022-06-24 12:20:32.398232
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME == '4tube'

# Generated at 2022-06-24 12:20:33.259361
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE("abc")
    assert fux_ie

# Generated at 2022-06-24 12:20:33.905349
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-24 12:20:36.467981
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:20:45.055989
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    test_info_dict = {
        'id': '7089759',
        'ext': 'mp4',
        'title': 'Teen couple doing anal',
        'uploader': 'Alexy',
        'uploader_id': '91488',
        'upload_date': '20150606',
        'timestamp': 1433595647,
        'duration': 5052,
        'view_count': int,
        'like_count': int,
        'age_limit': 18,
    }

    # Check parsing with unit test of class _real_extract
    assert(PornTubeIE()._real_extract(url) == test_info_dict)

# Generated at 2022-06-24 12:20:56.995196
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor

    class FourTubeBaseIE(InfoExtractor):
        _URL_TEMPLATE = 'http://www.4tube.com/videos/%s/video'
        _VALID_URL = r'http://www.4tube.com/videos/(?P<id>\d+)/video'
        _TKN_HOST = 'token.4tube.com'

    def _extract_formats(url, video_id, media_id, sources):
        token_url = 'http://%s/%s/desktop/%s' % (
            FourTubeBaseIE._TKN_HOST, media_id, '+'.join(sources))

        parsed_url = compat_urlparse.urlparse(url)

# Generated at 2022-06-24 12:20:59.279934
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    object_video = PornerBrosIE()
    print(isinstance(object_video, PornerBrosIE))

# Generated at 2022-06-24 12:21:01.526861
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE(): ie = FourTubeIE('FourTubeIE - Test', 'foobar123'); assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:10.098366
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._TESTS[0]['url'] ==  "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    assert fuxIE._TESTS[0]['info_dict']['id'] == "195359"
    assert fuxIE._TESTS[0]['info_dict']['title'] == "Awesome fucking in the kitchen ends with cum swallow"
    assert fuxIE._TESTS[0]['info_dict']['uploader'] == "alenci2342"
    assert fuxIE._TESTS[0]['info_dict']['uploader_id'] == "alenci2342"

# Generated at 2022-06-24 12:21:12.244513
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()
    PornTubeIE()
    PornerBrosIE()

# Generated at 2022-06-24 12:21:23.498248
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    page = PornTubeIE()._download_webpage(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

    x = re.search(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
                page, 'data', group='value')

    k = re.split('["\']', x.group())
    value = k[1]

    parse_value = compat_urllib_parse_unquote(
                compat_b64decode(value).decode('utf-8'))


# Generated at 2022-06-24 12:21:27.255483
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..test import get_testcases

    for test_data in get_testcases('4tube'):
        test_obj = FourTubeBaseIE(test_data['url'])
        assert test_obj._VALID_URL == test_data['valid_url']
        assert test_obj._TKN_HOST == test_data['token_host']

# Generated at 2022-06-24 12:21:32.867669
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    from .fourtube import FourTubeIE
    from .porntube import PornTubeIE
    from .fux import FuxIE
    from .pornerbros import PornerBrosIE

    instance = InfoExtractor(FourTubeIE.ie_key())
    assert isinstance(
        instance,
        (FourTubeIE, PornTubeIE, FuxIE, PornerBrosIE)
    )

# Generated at 2022-06-24 12:21:33.901143
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    x = FourTubeIE()

# Generated at 2022-06-24 12:21:35.405216
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None, None, None)

# Generated at 2022-06-24 12:21:36.161955
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()

# Generated at 2022-06-24 12:21:38.046347
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()


# Generated at 2022-06-24 12:21:43.714995
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._TKN_HOST == 'token.pornerbros.com'

test_PornerBrosIE()

# Generated at 2022-06-24 12:21:49.640795
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    with open("test_FourTube.txt") as f:
        assert ie._VALID_URL == f.readline().rstrip()
        assert ie._URL_TEMPLATE == f.readline().rstrip()
        assert ie._TKN_HOST == f.readline().rstrip()
        assert ie._TESTS == eval(f.readline().rstrip())
    pass

# Generated at 2022-06-24 12:22:00.139353
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # test for URL not matching
    with pytest.raises(RegexNotFoundError):
        FourTubeBaseIE("http://www.porntube.com/maxwell")._real_extract("http://www.porntube.com/maxwell")
    # test for successful extraction

# Generated at 2022-06-24 12:22:08.956267
# Unit test for constructor of class FuxIE
def test_FuxIE():
    a = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert a._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert a._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert a._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:22:10.548012
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	p = PornTubeIE()

# Generated at 2022-06-24 12:22:11.859041
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE();
    assert inst.IE_NAME == '4tube'

# Generated at 2022-06-24 12:22:13.104200
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except TypeError:
        pass

# Generated at 2022-06-24 12:22:15.389802
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._real_initialize()

# Generated at 2022-06-24 12:22:17.065424
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:20.269553
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._match_id("https://www.porntube.com/embed/123456") == "123456"
    assert ie._match_id("https://www.porntube.com/videos/video_123456") == "123456"

# Generated at 2022-06-24 12:22:23.078757
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test FourTubeBaseIE constructor"""
    from youtube_dl.extractor.fourtube import FourTubeBaseIE
    _ = FourTubeBaseIE(u'test')

# Generated at 2022-06-24 12:22:24.418416
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    return FourTubeIE({'IE_NAME': '4tube'})


# Generated at 2022-06-24 12:22:26.066955
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE
    # Test known info by FeedLoader
    # Test invalid video URL
    class_.suite()

# Generated at 2022-06-24 12:22:35.551975
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE(): # Function name must start with letter 'test' to be considered a unit test
    from . import PornTubeIE # Import the class to be tested

    print("\nStarting unit test for PornTubeIE class...")
    # Check the "class" variable of PornTubeIE (i.e. PornTubeIE.class)

# Generated at 2022-06-24 12:22:47.030248
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()
    assert fourTubeBaseIE.IE_NAME == '4tube'
    assert fourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tubex\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourTubeBaseIE._URL_TEMPLATE == 'https://www.xfourtube.com/videos/%s/video'
    assert fourTubeBaseIE._TKN_HOST == 'token.xfourtube.com'

# Generated at 2022-06-24 12:22:48.015702
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:22:49.310383
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert (FourTubeIE() != None)


# Generated at 2022-06-24 12:22:58.368163
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert not hasattr(FuxIE, '_TKN_HOST')
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._VALID_URL == re.compile(r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:23:01.999886
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    Simple unit test for constructor of class PornTubeIE
    """
    PornTubeIE('porntube')

# Generated at 2022-06-24 12:23:07.524259
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    mobj = re.match(FourTubeBaseIE._VALID_URL, "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    if kind == 'm' or not display_id:
        url = FourTubeBaseIE._URL_TEMPLATE % video_id
    print(url)

# Generated at 2022-06-24 12:23:11.248736
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Unit test for constructor of class FourTubeBaseIE"""
    result = FourTubeBaseIE(4)
    assert result.ie_key() == '4tube'


# Generated at 2022-06-24 12:23:13.034460
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBrosIE', '4tube')


# Generated at 2022-06-24 12:23:24.648081
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import json
    video_id = 7089759
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    data = '''INITIALSTATE = "%s";
    var countryCode = 'US',
    should_redirect_to_https = false,
    from_embed = false;
    App.bootstrap(window, document, countryCode, should_redirect_to_https, from_embed);
    '''
    try:
        data = data % json.loads(
            compat_b64decode(PornTubeIE()._download_webpage(url, None, note='Downloading the webpage', fatal=False)).decode('utf-8')
        )['page']['video']['mthumb']
    except:
        data = None

# Generated at 2022-06-24 12:23:33.617203
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():

    import sys
    import os
    import json
    import tempfile
    import shutil

    # Save to tmp directory
    old_path = os.getcwd()
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Create the fake file
    fake_file = open("__init__.py", "w")
    fake_file.close()
    fake_file = open("common.py", "w")
    fake_file.close()

    # Add to path
    sys.path.append(tmp_dir)

    from .common import InfoExtractor
    from .pornerbros import PornerBrosIE
    assert(InfoExtractor is not None)
    assert(PornerBrosIE is not None)


# Generated at 2022-06-24 12:23:34.746311
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None, None)


# Generated at 2022-06-24 12:23:41.420931
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class DummyFourTubeBaseIE(FourTubeBaseIE):
        IE_NAME = '4tube:Dummy'
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
        _TKN_HOST = 'token.4tube.com'

# Generated at 2022-06-24 12:23:42.589512
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj_PornTubeIE = PornTubeIE()

# Generated at 2022-06-24 12:23:44.561332
# Unit test for constructor of class FuxIE
def test_FuxIE():
    x = FuxIE()
    assert x.IE_NAME == '4tube:fux'

# Generated at 2022-06-24 12:23:47.709681
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FuxIE._downloader)._TKN_HOST == 'token.fux.com', 'FuxIE constructor test failed'

# Generated at 2022-06-24 12:23:49.674142
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    tryit = PornTubeIE(None, None)
    tryit._parse_json('{}', 'dummy')

# Generated at 2022-06-24 12:23:58.637523
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE("test", "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black", {})
    FourTubeIE("test", "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black", {})
    FuxIE("test", "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow", {})
    PornTubeIE("test", "https://www.porntube.com/videos/teen-couple-doing-anal_7089759", {})

# Generated at 2022-06-24 12:24:08.436369
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:24:10.793427
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        fux = FuxIE('http://www.fux.com')
        assert True
    except Exception:
        assert False

test_FuxIE()

# Generated at 2022-06-24 12:24:18.694205
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    fourtube_base_ie = FourTubeBaseIE()
    assert fourtube_base_ie._VALID_URL == FourTubeIE._VALID_URL
    assert fourtube_base_ie._URL_TEMPLATE == FourTubeIE._URL_TEMPLATE
    assert fourtube_base_ie._TKN_HOST == FourTubeIE._TKN_HOST 
    assert fourtube_base_ie._extract_formats(url, '209733', '123', ['720', '480']) == FourTubeIE._extract_formats(url, '209733', '123', ['720', '480'])

# Generated at 2022-06-24 12:24:20.540997
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, PornerBrosIE)

# Generated at 2022-06-24 12:24:21.496747
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:29.322724
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:33.247522
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert(ie._TKN_HOST == 'token.4tube.com')
    assert(ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(ie.IE_NAME == '4tube')

# Generated at 2022-06-24 12:24:40.582212
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeIE._VALID_URL, url)
    assert mobj.group('id') == '209733'
    assert mobj.group('kind') == None
    assert mobj.group('display_id') == None
    url = 'http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeIE._VALID_URL, url)
    assert mobj.group('id') == '209733'
    assert mobj.group('kind')

# Generated at 2022-06-24 12:24:47.197358
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_suite import get_testcases, get_testcases_data
    testcases = get_testcases()
    for tc in testcases:
        if tc.IE_NAME == 'PornTube':
            tu = PornTubeIE(testcases.get_test_data(tc, 1))
            tu.get_video_info(tc.url)
            break


# Generated at 2022-06-24 12:24:50.828208
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._VALID_URL is not None
    assert obj._URL_TEMPLATE is not None
    assert obj._TKN_HOST is not None
    assert obj._TESTS is not None

# Generated at 2022-06-24 12:24:55.260560
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert type(ie._TESTS) is list
    assert all(type(t) is dict for t in ie._TESTS)
    assert all(type(t['url']) is str for t in ie._TESTS)
    assert all(re.match(ie._VALID_URL, t['url']) for t in ie._TESTS)

# Generated at 2022-06-24 12:25:03.659196
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'

# Generated at 2022-06-24 12:25:04.501700
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE._TESTS

# Generated at 2022-06-24 12:25:06.568847
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        porner_bros_ie = PornerBrosIE()
    except:
        assert False, "PornerBrosIE constructor doesn't work"
    assert True

# Generated at 2022-06-24 12:25:07.794787
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == "FuxIE"

# Generated at 2022-06-24 12:25:09.733649
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()
    FuxIE()
    PornTubeIE()
    PornerBrosIE()

# Generated at 2022-06-24 12:25:10.846967
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    return FourTubeIE('FourTubeIE', '4tube', '4tube')

# Generated at 2022-06-24 12:25:12.980981
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import pytest

    with pytest.raises(TypeError):
        FourTubeIE(None, None, None)

# Generated at 2022-06-24 12:25:15.341174
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE().suitable('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')


# Generated at 2022-06-24 12:25:16.786191
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert(FuxIE.__name__ == 'FuxIE')


# Generated at 2022-06-24 12:25:20.872392
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtubeIE = FourTubeIE()
    assert isinstance(fourtubeIE, FourTubeIE)
    assert hasattr(fourtubeIE, '_VALID_URL')
    assert hasattr(fourtubeIE, '_TESTS')
    assert hasattr(fourtubeIE, 'IE_NAME')

# Generated at 2022-06-24 12:25:32.499843
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == 'PornTube'
    assert ie.SUFFIX == 'com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:25:43.789678
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie = PornerBrosIE({})
    mobj = re.match(ie._VALID_URL, url)
    assert(mobj is not None)
    assert('kind' in mobj.groupdict())
    assert('id' in mobj.groupdict())
    assert('display_id' in mobj.groupdict())
    assert('www' == mobj.group('kind'))
    assert('181369' == mobj.group('id'))
    assert('skinny-brunette-takes-big-cock-down-her-anal-hole_181369' == mobj.group('display_id'))


# Generated at 2022-06-24 12:25:47.805347
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import pytube

    video_id = '209733'
    url = 'http://www.4tube.com/videos/' + video_id + '/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

    # Check if the class can handle this url.
    assert pytube.Pafy(url).title == 'Hot Babe Holly Michaels gets her ass stuffed by black'

# Generated at 2022-06-24 12:25:49.318509
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:25:57.523836
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    testurl = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    extractor = PornTubeIE()._real_initialize()
    extractor._downloader.params.update({'noplaylist': True})
    info_dict = extractor.extract(testurl)

    assert info_dict['id'] == '7089759'
    assert info_dict['title'] == 'Teen couple doing anal'
    assert info_dict['uploader'] == 'Alexy'
    assert info_dict['upload_date'] == '20150606'
    assert str(info_dict['view_count'])
    assert int(info_dict['view_count']) > 0
    assert int(info_dict['view_count']) < 1000000

# Generated at 2022-06-24 12:26:01.123631
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest
    tests = unittest.TestSuite()
    tests.addTest(FuxIE())
    s = unittest.TextTestRunner().run(tests)
    print(s.wasSuccessful())

test_FuxIE()

# Generated at 2022-06-24 12:26:03.681960
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME in globals()
    assert ie.IE_NAME == 'Fux'

# Generated at 2022-06-24 12:26:06.070896
# Unit test for constructor of class FuxIE
def test_FuxIE():

    # test if FuxIE is a subclass of FourTubeBaseIE
    assert issubclass(FuxIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:26:06.992948
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-24 12:26:07.658332
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()

# Generated at 2022-06-24 12:26:08.578574
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:26:10.196047
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()
    assert porn_tube_ie

# Generated at 2022-06-24 12:26:13.759587
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.extract("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")



# Generated at 2022-06-24 12:26:15.364022
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)