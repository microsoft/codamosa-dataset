

# Generated at 2022-06-24 12:16:12.993381
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test for constructor of class FourTubeBaseIE
    object_FourTubeBaseIE = FourTubeBaseIE()
    assert object_FourTubeBaseIE

# Generated at 2022-06-24 12:16:13.594124
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:16:15.551738
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test to see if it can instantiate the class
    test_class = PornerBrosIE()

    assert test_class

# Generated at 2022-06-24 12:16:27.727247
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    PornTubeIE._URL_TEMPLATE = 'https://www.porntube.com/videos/video_%s'
    PornTubeIE._TKN_HOST = 'tkn.porntube.com'

# Generated at 2022-06-24 12:16:28.198715
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:16:34.848245
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-24 12:16:40.687631
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Arrange
    ie_class = FuxIE()

    assert ie_class._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie_class._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:16:42.029507
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()
    assert test

# Generated at 2022-06-24 12:16:43.223389
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i = PornerBrosIE()
    assert not i is None
    assert not i is PornerBrosIE()
    PornerBrosIE()

# Generated at 2022-06-24 12:16:45.943728
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.extract('https://www.4tube.com/videos/185012/sexy-guy-takes-off-his-clothes-and-makes-out')

# Generated at 2022-06-24 12:16:49.626220
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    if PornTubeIE is None:
        return

    with pytest.raises(ValueError) as excinfo:
        PornTubeIE()
    assert ('The "PornTubeIE" class was renamed to "FourTubeIE" and may be removed in future versions. '
            'Please migrate your code accordingly.') in str(excinfo.value)



# Generated at 2022-06-24 12:16:52.771281
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Test cases for Fux video download
    """

    # Example test case
    FuxIE()._real_extract('https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:16:54.335067
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:16:55.566052
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    yt = PornTubeIE()

# Generated at 2022-06-24 12:16:57.645828
# Unit test for constructor of class FuxIE
def test_FuxIE():
    c = FuxIE('FuxIE')
    assert c._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:17:00.351870
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie = FourTubeBaseIE()
    ie = PornTubeIE()
    ie = FourTubeBaseIE()

# Generated at 2022-06-24 12:17:04.832837
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .subtitles import SubtitlesInfoExtractor

    # Test the subclassing of parent class by
    # instantiating the subclassed object
    try:
        int_obj = FourTubeIE(SubtitlesInfoExtractor)
        int_obj.test()
    except Exception as e:
        os._exit(1)
    pass

# Generated at 2022-06-24 12:17:12.950719
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie_4tube = FourTubeIE()
    assert ie_4tube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie_4tube._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie_4tube._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-24 12:17:16.597257
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_object = FourTubeBaseIE(None, {}, None)
    assert test_object._VALID_URL == None
    assert test_object._URL_TEMPLATE == None
    assert test_object._TKN_HOST == None
    assert test_object._TESTS == []

# Generated at 2022-06-24 12:17:18.361392
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')


# Generated at 2022-06-24 12:17:22.342603
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FuxIE()

# Generated at 2022-06-24 12:17:24.622164
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:17:27.030011
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE("https://www.porntube.com/embed/7089759")
    except:
        return 1
    return 0

# Generated at 2022-06-24 12:17:36.710907
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "https://www.porntube.com/embed/7089759"
    # First, test if it outputs correctly
    ie = PornTubeIE()
    ie._download_webpage = lambda *args: None
    assert ie.suitable(url) == True
    assert ie.IE_NAME == "PornTube"
    assert ie._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)"
    assert ie._URL_TEMPLATE == "https://www.porntube.com/videos/video_%s"
    assert ie._TKN_HOST == "tkn.porntube.com"

    # Second, test

# Generated at 2022-06-24 12:17:37.778570
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()



# Generated at 2022-06-24 12:17:43.546899
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:17:44.625144
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:17:51.769410
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')
    ie = FourTubeBaseIE('fux')
    ie = FourTubeBaseIE('porntube')
    ie = FourTubeBaseIE('pornerbros')
    # This one tests that PornerBrosIE doesn't raise exception
    ie = PornerBrosIE('pornerbros', 'www.pornerbros.com')
    ie = FuxIE('fux', 'www.fux.com')

# Generated at 2022-06-24 12:17:53.655503
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj

# Generated at 2022-06-24 12:18:02.920000
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    if not hasattr(FourTubeBaseIE, 'IE_NAME'):
        class TestFourTubeBaseIE(FourTubeBaseIE):
            IE_NAME = 'test_fourtube_base_ie'
            _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?test\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
            _URL_TEMPLATE = 'https://www.test.com/videos/video_%s'
            _TKN_HOST = 'token.test.com'
    else:
        class TestFourTubeBaseIE(FourTubeBaseIE):
            pass
    ie = TestFourTubeBaseIE() # no error

# Generated at 2022-06-24 12:18:06.196066
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    s = fourtube.FourTubeIE()
    s._clone_playlist_from_url("https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

# Generated at 2022-06-24 12:18:07.636387
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:18:16.657927
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._VALID_URL = r'https://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    ie._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    ie._TKN_HOST = 'token.4tube.com'

# Generated at 2022-06-24 12:18:23.142997
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():

	v1 = FourTubeIE('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-24 12:18:25.286809
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:18:26.318550
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:18:31.992998
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Basic test for verifying that the class can be instanciated and that it has the correct
    id, name and description.
    """
    ie = FourTubeIE()
    assert ie.IE_NAME == ('4tube')
    assert ie.IE_DESC == ('4Tube and Fux')

# Generated at 2022-06-24 12:18:32.413501
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:18:40.891595
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE()
    assert info_extractor.IE_NAME == '4tube'
    assert info_extractor._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert info_extractor._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert info_extractor._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-24 12:18:42.127720
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test import get_testcases
    from .test import TEST_CASES
    testcases = get_testcases(TEST_CASES, PornTubeIE)
    return testcases

# Generated at 2022-06-24 12:18:42.809745
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie != None

# Generated at 2022-06-24 12:18:43.209871
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:18:49.564728
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        class TestPornerBrosIE(PornerBrosIE):
            _BASE_URL = 'http://www.pornerbros.com/'
            PornerBrosIE._VALID_URL = TestPornerBrosIE._VALID_URL
    except ValueError as e:
        assert "object has no attribute '_BASE_URL'" in str(e)

    try:
        class TestPornerBrosIE(PornerBrosIE):
            _TEST = {}
            PornerBrosIE._TEST = TestPornerBrosIE._TEST
    except TypeError as e:
        assert "expected string or bytes-like object" in str(e)

# Generated at 2022-06-24 12:18:52.796502
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-24 12:18:59.885768
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    TestInfoExtractor = type('TestInfoExtractor', (InfoExtractor,), {})
    class_ = PornerBrosIE
    args = {
        '_VALID_URL': PornerBrosIE._VALID_URL
    }
    ie = class_(TestInfoExtractor, PornerBrosIE.ie_key(), **args)
    assert ie.ie_key() == 'pornerbros'
    assert ie.host() == 'pornerbros.com'

if __name__ == '__main__':
    test_PornerBrosIE()

# Generated at 2022-06-24 12:19:00.814113
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:19:01.725485
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	PornerBrosIE(None, None)

# Generated at 2022-06-24 12:19:04.313574
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')
    check_porn_tube_ie=PornTubeIE('PornTube')
    assert check_porn_tube_ie.ie_key() == 'porntube'

# Generated at 2022-06-24 12:19:11.398203
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert i._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert i._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:19:12.330515
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornerBrosIE()


# Generated at 2022-06-24 12:19:14.357169
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        import test_PornTubeIE
        test_PornTubeIE.test_PornTubeIE()
    except:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-24 12:19:19.324852
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # If we don't pass any parameters, the class constructor will throw exception
    # since it can't get the JS code defining the qs_obj. The qs_obj is used to
    # form a url to get the token required to extract the formats.
    # But if we pass the qs_obj and the qs_str, we won't throw any exception.
    try:
        pornerbros_ie = PornerBrosIE('pornerbros')
    except Exception as e:
        assert str(e) == 'The qs_obj and the qs_str should not be empty!'

# Generated at 2022-06-24 12:19:21.734911
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test constructor
    assert PornerBrosIE is type(FourTubeBaseIE(PornerBrosIE.ie_key()))

# Generated at 2022-06-24 12:19:26.323322
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    a = PornerBrosIE();
    assert(a._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)');

# Generated at 2022-06-24 12:19:26.970431
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:19:28.953228
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test instantiation
    if __name__ == '__main__':
        print(PornerBrosIE())



# Generated at 2022-06-24 12:19:35.928776
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_params = [
        # test for PornerBrosIE
        {
            u'url' : u'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
            u'expected' : PornerBrosIE
        },
    ]
    for test_param in test_params:
        assert test_param['expected'](u'PornerBros')._get_recommended_IE(test_param[u'url']) == test_param['expected']

# Generated at 2022-06-24 12:19:38.335742
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:19:40.751070
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    a = FourTubeBaseIE()
    assert(a.IE_NAME == '4tube')


# Generated at 2022-06-24 12:19:44.813495
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():

    testURL = 'http://www.porntube.com/embed/7089759'

    try:
        PornTubeIE()(testURL, None)
    except Exception as e:
        print("Error: %s" % e)
        print("Could not construct a PornTubeIE object")
        assert False

    return True

# Generated at 2022-06-24 12:19:45.447147
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:19:56.719016
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    web_page = '''
    <script>
    var INITIALSTATE = '<script>window.__INITIAL_STATE__ = eval(window.atob("ZXZhbChbMjMyNTA3LDMsImh0dHBzOi8vd3d3LnBvcm5lcmJyb3MuY29tL3ZpZGVvcy8yMzI1MDdfU2lua2V5X0J1cm5ldHRlX0FuYWxfU2hvb3RzX18xMzE3MDAiXQ=="))</script>';
    </script>
    '''
    porner_bros_ie = PornerBrosIE()
    porner_bros_ie._download_webpage = lambda *args: web_page

# Generated at 2022-06-24 12:20:05.890443
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import json
    import requests
    # Get HTML of the video page with ID = 181369
    res = requests.get("https://www.pornerbros.com/embed/181369")
    if not res:
        raise Exception("Failed to get HTML")
    # Parse initialState in the script
    raw_initialstate = re.search(
        r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?P<value>(?!\1).)+)\1',
        res.text).group("value")
    # Decode the base64 string
    b64_initialstate = json.loads(raw_initialstate)
    # Get video info

# Generated at 2022-06-24 12:20:06.862763
# Unit test for constructor of class FuxIE
def test_FuxIE():
    t = FuxIE()
    assert type(t) == FuxIE

# Generated at 2022-06-24 12:20:07.359287
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:20:08.055192
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:09.740242
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    t = PornTubeIE()
    t._search_regex(r'a','a','b','c')

# Generated at 2022-06-24 12:20:19.988354
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._TKN_HOST = "localhost"
    ie._VALID_URL = "https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
    ie._URL_TEMPLATE = "https://www.4tube.com/videos/%s/video"

    webpage = "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    ie._download_webpage(webpage, "test_209733")

test_FourTubeIE()

# Generated at 2022-06-24 12:20:22.659035
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class MockFourTubeBaseIE(FourTubeBaseIE):
        pass
    obj = MockFourTubeBaseIE()
    assert obj._VALID_URL == ''
    assert obj._URL_TEMPLATE == ''
    assert obj._TKN_HOST == ''
    assert obj._TESTS is None
    assert obj.IE_NAME == ''

# Generated at 2022-06-24 12:20:30.783389
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_id = '209733'
    info = {
        'id': video_id,
        'ext': 'mp4',
        'title': 'Hot Babe Holly Michaels gets her ass stuffed by black',
        'uploader': 'WCP Club',
        'uploader_id': 'wcp-club',
        'upload_date': '20131031',
        'timestamp': 1383263892,
        'duration': 583,
        'view_count': int,
        'like_count': int,
        'categories': list,
        'age_limit': 18,
    }

# Generated at 2022-06-24 12:20:39.229297
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:44.991514
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE(url)

# Generated at 2022-06-24 12:20:45.791523
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:46.901054
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    youtube_ie = FourTubeIE()
    print(youtube_ie)

# Generated at 2022-06-24 12:20:56.730447
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie.IE_NAME == '4tube'


# Generated at 2022-06-24 12:20:58.669466
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import doctest
    doctest.testmod(FourTubeBaseIE)

# Generated at 2022-06-24 12:20:59.754760
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-24 12:21:00.849663
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x = FourTubeBaseIE()
    print(x)

# Generated at 2022-06-24 12:21:09.450811
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie._URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    ie._TKN_HOST = 'token.fux.com'
    ie._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:21:11.252519
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(4)

# Generated at 2022-06-24 12:21:15.978173
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    # Testing class initialization
    assert obj._TESTS[0]
    assert obj._VALID_URL
    assert obj._URL_TEMPLATE
    assert obj._TKN_HOST
    assert obj._TESTS



# Generated at 2022-06-24 12:21:16.988783
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, PornerBrosIE)
    


# Generated at 2022-06-24 12:21:26.516292
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(FourTubeIE._VALID_URL)._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE(FourTubeIE._VALID_URL)._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

    assert FourTubeBaseIE(FuxIE._VALID_URL)._TKN_HOST == 'token.fux.com'
    assert FourTubeBaseIE(FuxIE._VALID_URL)._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

    assert FourTubeBaseIE(PornTubeIE._VALID_URL)._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:21:28.518098
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:21:33.442054
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # The constructor takes in argument url, and returns an instance of the class
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    instance = PornerBrosIE(url)
    assert instance._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:35.664811
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_obj = FourTubeIE()
    assert test_obj is not None

# Generated at 2022-06-24 12:21:42.969943
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import youtube_dl.extractor
    # Test for the parent class (FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    # Test for the parent of parent class (InfoExtractor)
    assert issubclass(FuxIE, youtube_dl.extractor.InfoExtractor)
    # Test for the constructor of the class
    assert FuxIE == FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:21:53.669475
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:21:58.493973
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class Test(FourTubeBaseIE):
        _VALID_URL = 'test'
        _URL_TEMPLATE = 'test'
        _TKN_HOST = 'test'
    test = Test()
    assert test._TESTS == []
    assert test.ie_key() == 'FourTubeBase'
    assert test._VALID_URL == 'test'
    assert test._URL_TEMPLATE == 'test'
    assert test._TKN_HOST == 'test'

# Generated at 2022-06-24 12:21:59.843482
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-24 12:22:00.876283
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE('PornerBros')

# Generated at 2022-06-24 12:22:04.763961
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = 'https://www.porntube.com/embed/7089759'
    page = PornTubeIE()
    try:
        page._real_extract(test_url)
    except:
        assert False

# Generated at 2022-06-24 12:22:07.884404
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    semi_cls = FourTubeBaseIE.__bases__[0]
    assert isinstance(semi_cls.__dict__['_VALID_URL'], str)
    assert isinstance(semi_cls.__dict__['_URL_TEMPLATE'], str)

# Generated at 2022-06-24 12:22:10.640702
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE
    assert class_._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-24 12:22:19.089996
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornhub = PornTubeIE()
    assert pornhub._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornhub._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pornhub._TKN_HOST == 'tkn.porntube.com'
    assert pornhub._TESTS[0].get('url') == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert pornhub._TESTS[0].get('info_dict').get('id') == '7089759'
   

# Generated at 2022-06-24 12:22:24.126741
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import pornhub
    # Make sure the right implementation is being used
    # by checking some class attributes of PornHubIE
    # implementation.
    assert PornTubeIE.__name__ == 'PornTubeIE'
    assert PornTubeIE._VALID_URL.__name__ == '_VALID_URL'
    assert PornTubeIE._URL_TEMPLATE.__name__ == '_URL_TEMPLATE'

# Generated at 2022-06-24 12:22:29.828935
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie.ie_key() == 'PornerBros'

# Generated at 2022-06-24 12:22:31.631036
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:22:32.202756
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:37.943961
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """Unit test for class PornTubeIE"""
    videoID = '7089759'
    videoURL = PornTubeIE._URL_TEMPLATE % videoID
    video = PornTubeIE()._real_extract(videoURL)
    assert video['id'] == videoID
    assert video['view_count'] == int
    assert video['like_count'] == int
    assert video['age_limit'] == 18

# Generated at 2022-06-24 12:22:43.822872
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Note that this call is only needed because IE FourTubeIE
    # is no longer a simple subclass of class InfoExtractor.
    FourTubeIE._build_video_info(
        FourTubeIE, FourTubeIE._TESTS[0].get('url'), FourTubeIE._TESTS[0],
        match=None, video_id='209733'
    )

# Generated at 2022-06-24 12:22:47.920646
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:22:54.303687
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import time
    import random
    import string
    import six
    url_template = 'https://www.porntube.com/videos/%s_%d'
    test_urls = []

# Generated at 2022-06-24 12:23:02.304002
# Unit test for constructor of class FuxIE
def test_FuxIE():
  """ Constructor for class FuxIE. """
  assert FuxIE._TESTS == FourTubeIE._TESTS
  assert FuxIE._TKN_HOST == 'token.fux.com'
  assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
  assert FuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:23:10.278259
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FuxIE._TKN_HOST == 'token.fux.com'
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:23:21.869931
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:23:23.724786
# Unit test for constructor of class FuxIE
def test_FuxIE():
    B = FuxIE()
    assert B.IE_NAME == '4tube'



# Generated at 2022-06-24 12:23:29.533286
# Unit test for constructor of class FuxIE
def test_FuxIE():
    result = FuxIE._build_url_result('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert result == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-24 12:23:31.048336
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()
    print('test_PornTubeIE() finished.')

# Generated at 2022-06-24 12:23:37.435480
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    import sys
    # Ensure we test all subclasses of FourTubeBaseIE
    bases = tuple(
        cls for cls in globals().values()
        if isinstance(cls, type)
        and issubclass(cls, FourTubeBaseIE)
        and cls is not FourTubeBaseIE
        and cls is not InfoExtractor)
    saved_class = InfoExtractor
    for base in bases:
        sys.modules['__main__'].InfoExtractor = base
        try:
            FinderBaseIE()
        finally:
            sys.modules['__main__'].InfoExtractor = saved_class

# Generated at 2022-06-24 12:23:48.197860
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import requests, re
    try:
        page = requests.get('https://www.porntube.com/videos/teen-couple-doing-anal_7089759').content
    except:
        raise Exception('couldnt get test page')

    r = re.search(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1', page)
    if  r is None:
        raise Exception('couldnt find initialstate')
    data = r.group('value')
    import sys
    if sys.version_info >= (3,):
        import base64
        data = base64.b64decode(data).decode('utf-8')
    else:
        import binascii
        data = binascii.a2b_base

# Generated at 2022-06-24 12:23:49.257459
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()



# Generated at 2022-06-24 12:23:53.137101
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:24:00.115941
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:00.860055
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()

# Generated at 2022-06-24 12:24:10.285432
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()
    assert test.IE_NAME == '4tube'
    assert test._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test._TKN_HOST == 'token.4tube.com'
    assert test._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert test._TESTS[1]['only_matching']

# Generated at 2022-06-24 12:24:18.375670
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:24:30.132331
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_downloader import _test_downloader
    ie = PornTubeIE()
    ydl = _test_downloader(ie)


# Generated at 2022-06-24 12:24:33.345337
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:24:35.781818
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Constructor for PornerBrosIE
    Should return an instance of the PornerBrosIE class
    """
    assert isinstance(PornerBrosIE(), PornerBrosIE)

# Generated at 2022-06-24 12:24:36.788269
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .. import PornTubeIE
    assert PornTubeIE

# Generated at 2022-06-24 12:24:41.420176
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    my_obj = PornTubeIE('https://www.porntube.com/embed/7089759')
    assert my_obj._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'


# Generated at 2022-06-24 12:24:42.893330
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-24 12:24:50.923784
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x = FourTubeBaseIE({})
    assert x.IE_NAME == '4tube'
    assert x._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert x._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert x._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:53.320286
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE
    except NameError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 12:25:00.111043
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:25:02.734458
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert isinstance(ie, PornTubeIE)


# Generated at 2022-06-24 12:25:13.332282
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from ..compat import compat_b64decode
    from ..utils import (
        parse_duration,
        str_to_int,
        try_get,
    )
    ie = InfoExtractor()
    ie._download_webpage = lambda x, y: x
    ie._html_search_meta = lambda x, y: x
    ie._search_regex = lambda x, y, z, *a, **b: a[0]
    ie._url_basename = lambda x: x

    url_template = 'https://www.porntube.com/videos/video_%s'
    token_host = 'tkn.porntube.com'
    id = '181369'
    url = url_template % id
    webpage = url
    video = ie._download

# Generated at 2022-06-24 12:25:13.928191
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE

# Generated at 2022-06-24 12:25:19.002241
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import inspect
    class_constructors = [i[1] for i in inspect.getmembers(PornTubeIE, inspect.isclass)]
    instance_constructor = [i[1] for i in inspect.getmembers(PornTubeIE(), inspect.ismethod) if i[0] == '__init__'][0]
    assert(class_constructors[0] == instance_constructor)

# Generated at 2022-06-24 12:25:30.378769
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import re
    from .common import InfoExtractor
    from ..compat import (
        compat_b64decode,
        compat_str,
        compat_urllib_parse_unquote,
        compat_urlparse,
    )
    from ..utils import (
        int_or_none,
        parse_duration,
        parse_iso8601,
        str_or_none,
        str_to_int,
        try_get,
        unified_timestamp,
        url_or_none,
    )

    import unittest
    class FourTubeBaseIETest(unittest.TestCase):
        def test_FourTubeBaseIE(self):
            import io
            import requests

# Generated at 2022-06-24 12:25:32.967784
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # This test checks that class FuxIE is able to instantiate.
    # This test does not check the correctness of any operations.
    FuxIE()

# Generated at 2022-06-24 12:25:35.927719
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
   url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
   PornTubeIE.__init__(PornTubeIE, url)

# Generated at 2022-06-24 12:25:37.433643
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FuxIE._VALID_URL, '')

# Generated at 2022-06-24 12:25:45.688222
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxUnitTest = FuxIE()
    assert fuxUnitTest._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxUnitTest._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxUnitTest._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:25:52.783470
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        fourTubeBaseIE1 = FourTubeBaseIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
        assert fourTubeBaseIE1.url == "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    except:
        print("test_FourTubeBaseIE failure")

# Generated at 2022-06-24 12:25:54.376516
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == 'fux'

# Generated at 2022-06-24 12:25:55.295304
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-24 12:26:07.090393
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE

    # Set up some test inputs
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    video_id = '1331406'
    display_id = 'squirting-teen-ballerina-ecg'

# Generated at 2022-06-24 12:26:08.233724
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE()
    instance.IE_NAME

# Generated at 2022-06-24 12:26:12.021558
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE.suitable("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

