

# Generated at 2022-06-24 12:16:12.355262
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-24 12:16:13.183820
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:16:20.584812
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert x._TESTS[0]['md5'] == '5a5a9d7c096e998b482e1f6cd8d097b0'
    assert x._TESTS[0]['info_dict']['id'] == '7089759'
    assert x._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert x._TESTS[0]['info_dict']['title'] == 'Teen couple doing anal'
    assert x._TESTS[0]['info_dict']['uploader'] == 'Alexy'

# Generated at 2022-06-24 12:16:30.022901
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    video_id = '181369'
    media_id = '4184'
    sources = ['720', '480']
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    # Construct the class
    fth=FourTubeBaseIE()
    # Test function _extract_formats()
    formats = fth._extract_formats(url, video_id, media_id, sources)
    assert(formats[0]['resolution']=='720p')
    assert(formats[0]['quality']==720)
    assert(formats[1]['resolution']=='480p')
    assert(formats[1]['quality']==480)

# Generated at 2022-06-24 12:16:31.037970
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE(None)
    assert p is not None

# Generated at 2022-06-24 12:16:32.960600
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from sys import argv, exit
    from .common import main
    
    ie = FourTubeIE()
    ie.download(argv[1])
    exit(0)

# Generated at 2022-06-24 12:16:33.710742
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()

# Generated at 2022-06-24 12:16:34.813631
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    index = PornTubeIE()
    assert isinstance(index, FourTubeBaseIE)

# Generated at 2022-06-24 12:16:44.119780
# Unit test for constructor of class FuxIE
def test_FuxIE():
    currentDir = os.path.dirname(os.path.realpath(__file__))
    webPageContents = ''
    with open(os.path.join(currentDir,'data/video.html'), 'rb') as f:
        webPageContents = f.read().decode('utf-8')

    url = 'https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-24 12:16:47.115168
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = FuxIE()
    ie.extract(url)

# Generated at 2022-06-24 12:16:48.119543
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
    assert f is not None

# Generated at 2022-06-24 12:16:52.900253
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.ie_key() == 'PornerBros'
    assert PornerBrosIE.ie_key() == 'pornerbros'
    assert PornerBrosIE.ie_key() == PornTubeIE.ie_key()
    assert PornerBrosIE.ie_key() == FuxIE.ie_key()
    assert PornerBrosIE.ie_key() == FourTubeIE.ie_key()

# Generated at 2022-06-24 12:16:53.944480
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:16:56.130399
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE("https://www.pornerbros.com/embed/181369", "181369")

# Generated at 2022-06-24 12:17:06.217505
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_cases = (
        'https://www.porntube.com/videos/video_1525375',
        'https://www.porntube.com/videos/hawt-solo-masturbation-with-a-skinny-brunette-babe_1525375',
        'https://www.porntube.com/embed/1525375',
        'https://m.porntube.com/videos/1434668',
        'https://m.porntube.com/videos/hot-blonde-with-perfect-milf-body-pornstar-squirt_1434668',
    )
    for test_case in test_cases:
        ie = PornTubeIE()
        ie._real_extract(test_case)

# Generated at 2022-06-24 12:17:07.345180
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:17:17.994898
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    info_dict = {
        'id': '195359',
        'ext': 'mp4',
        'title': 'Awesome fucking in the kitchen ends with cum swallow',
        'uploader': 'alenci2342',
        'uploader_id': 'alenci2342',
        'upload_date': '20131230',
        'timestamp': 1388361660,
        'duration': 289,
        'view_count': int,
        'like_count': int,
        'categories': list,
        'age_limit': 18,
    }
    new_fux = FuxIE()

# Generated at 2022-06-24 12:17:27.173043
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:17:29.235764
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FuxIE._create_ie_instance())._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:17:34.842240
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url_template = 'https://www.4tube.com/videos/%s/video'
    valid_url = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    token_host = 'token.4tube.com'
    test_object = FourTubeBaseIE()
    assert test_object._TESTS == []
    assert test_object._URL_TEMPLATE == url_template
    assert test_object._VALID_URL == valid_url
    assert test_object._TKN_HOST == token_host

# Generated at 2022-06-24 12:17:43.888754
# Unit test for constructor of class FuxIE
def test_FuxIE():
    unit_test_FuxIE = FuxIE()
    assert unit_test_FuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert unit_test_FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert unit_test_FuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:17:44.986674
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TESTS

# Generated at 2022-06-24 12:17:51.828558
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_PornTube = PornTubeIE()
    print(test_PornTube.__class__.__name__)
    print(test_PornTube._VALID_URL)
    print(test_PornTube._URL_TEMPLATE)
    print(test_PornTube._TKN_HOST)
    print(test_PornTube.IE_NAME)
test_PornTubeIE()

# Generated at 2022-06-24 12:17:52.434553
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-24 12:17:57.287073
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test direct call with specific URL
    ie = FuxIE()
    ie.extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    # Test direct call with generic URL
    ie.extract('https://www.fux.com/video/195359')

# Generated at 2022-06-24 12:18:05.589975
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor_type_name = '4tube:test_FourTubeBaseIE'
    url_type = '4tube'

    class FourTubeBaseIETester(FourTubeBaseIE):
        IE_NAME = info_extractor_type_name
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?' + url_type + r'\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.' + url_type + '.com/videos/%s/video'
        _TKN_HOST = 'token.' + url_type + '.com'

    return FourTubeBaseIETester


# Unit tests for class FourTubeIE


# Generated at 2022-06-24 12:18:06.561570
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:18:07.977606
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_fux = FuxIE()
    assert test_fux != None

# Generated at 2022-06-24 12:18:16.878225
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_string = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert FourTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE()._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:18:19.774469
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    PornTubeIE(PornTubeIE.ie_key(), test_url)

# Generated at 2022-06-24 12:18:32.186415
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FourTubeBaseIE_Test(FourTubeBaseIE):
        url_tmpl = 'http://www.test.com/videos/%s/video'
        tkn_host = 'token.test.com'
        valid_url = r'https?://(?:(?P<kind>www|m)\.)?test\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    test = FourTubeBaseIE_Test()

# Generated at 2022-06-24 12:18:34.628789
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE(None)
    assert hasattr(ie, '_TESTS') and len(ie._TESTS) > 0

# Generated at 2022-06-24 12:18:44.390950
# Unit test for constructor of class FuxIE
def test_FuxIE():
	url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
	regex = FuxIE._VALID_URL
	parts = re.match(regex, url)
	assert parts is not None
	Kind = parts.group('kind')
	if parts.group('kind') is None:
		Kind = 'www'
	else:
		Kind = parts.group('kind')
	url = FuxIE._URL_TEMPLATE % parts.group('id')
	tkn_host = FuxIE._TKN_HOST
	tkn_url = 'https://%s/%s/desktop/%s' % (tkn_host, parts.group('id'), '+'.join(['720', '480', '240']))


# Generated at 2022-06-24 12:18:44.865468
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-24 12:18:46.486115
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('www', 'h')
    assert ie.ie_key() == '4tube'
    assert ie.website_name() == '4Tube'

# Generated at 2022-06-24 12:18:53.818408
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    porn_tube = PornTubeIE.PornTubeIE(url)
    assert porn_tube.get_result() == None

# Generated at 2022-06-24 12:18:57.569787
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_cases = [
        ('www', FuxIE),
        ('m', FuxIE),
        ('randomname', FourTubeIE),
    ]

    for name, ie in test_cases:
        result = FourTubeIE.suitable(name)
        assert result == ie

# Generated at 2022-06-24 12:18:59.368815
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE


if __name__ == '__main__':
    test_FourTubeBaseIE()

# Generated at 2022-06-24 12:19:01.350753
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.IE_NAME



# Generated at 2022-06-24 12:19:02.581056
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()

# Generated at 2022-06-24 12:19:04.200280
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE(None)
    assert ie.__class__.__name__ == 'FourTubeIE'

# Generated at 2022-06-24 12:19:06.915838
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_downloader import TestDownloader
    from .test_downloader import expected_warnings
    TestDownloader.expected_warnings = expected_warnings
    TestDownloader('1331406').run()

test_PornTubeIE()

# Generated at 2022-06-24 12:19:07.721450
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()

# Generated at 2022-06-24 12:19:10.673374
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # run once to get the traffic info
    PornTubeIE()._download_webpage(
        'https://www.porntube.com/embed/7089759', '7089759')

# Generated at 2022-06-24 12:19:12.521622
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.__module__ == '__main__'
    assert PornTubeIE.__name__ == 'PornTubeIE'


# Generated at 2022-06-24 12:19:13.711134
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    initialiser = FourTubeBaseIE()
    assert initialiser


# Generated at 2022-06-24 12:19:14.428335
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()
    assert True

# Generated at 2022-06-24 12:19:15.133231
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.suite()

# Generated at 2022-06-24 12:19:22.226808
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:19:26.432403
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE._download_webpage('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369', 
    '181369', 'Downloading player JS')

# Generated at 2022-06-24 12:19:31.979464
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('www')
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:19:36.728776
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Test PornerBrosIE constructor"""
    record = PornerBrosIE(None)
    assert record._TKN_HOST == 'token.pornerbros.com'
    assert record._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert record._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:19:38.289117
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert isinstance(FourTubeBaseIE(FourTubeIE), FourTubeBaseIE)

# Generated at 2022-06-24 12:19:49.779063
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:20:00.675072
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Constructor unit test of class PornerBrosIE
    """
    # use url of file test_pornerbros.html
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"

    # _VALID_URL
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    
    # group
    assert mobj.group('kind') == "www"
    assert mobj.group('id') == "181369"
    assert mobj.group('display_id') == "skinny-brunette-takes-big-cock-down-her-anal-hole"
    
    # _URL_TEMPLATE
    assert Porner

# Generated at 2022-06-24 12:20:03.218473
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    features = globals()['FourTubeBaseIE']()._get_available_formats('test_url')
    assert len(features) is 0


# Generated at 2022-06-24 12:20:04.979371
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:20:08.804926
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeIE()
    ie._download_webpage = lambda url, *args: url
    info = ie._real_extract(url)
    assert info['id'] == '209733', info
    assert info['formats'], info['formats']
    assert info['duration'] == 583, info['duration']



# Generated at 2022-06-24 12:20:16.482544
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    filename = "tests/testdata/test.html"
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    webpage = open(filename, 'rb').read()
    pb=PornerBrosIE()
    pb._extract_formats(url, "181369", "181369", ['720','1080'])
    pb._extract_data(webpage, "181369")

# Generated at 2022-06-24 12:20:21.548934
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None, None)._TKN_HOST == 'token.4tube.com'
    assert FuxIE(None, None)._TKN_HOST == 'token.fux.com'
    assert PornTubeIE(None, None)._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(None, None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:20:24.163698
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie_fourtube = FourTubeIE()
    print(ie_fourtube.IE_NAME)
    print(ie_fourtube._VALID_URL)


# Generated at 2022-06-24 12:20:31.637770
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Tests constructor of class PornTubeIE for proper initialization
    pornTube = PornTubeIE()

    # Test if field _VALID_URL of class PornTubeIE is properly initialized
    assert pornTube._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)' , "Regex pattern of field _VALID_URL of class PornTubeIE is not properly initialized"
    # Test if field _URL_TEMPLATE of class PornTubeIE is properly initialized
    assert pornTube._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s', "Field _URL_TEMPLATE of class PornTubeIE is not properly initialized"
    #

# Generated at 2022-06-24 12:20:33.299799
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:41.905470
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Constructor of class FourTubeIE should return an instance of class FourTubeIE.
    """
    # Variable to store the instantiated class.
    instantiated_class = None

    # Attempt to instantiate the class.
    try:
        instantiated_class = FourTubeIE()
    except:
        assert False, "Constructor of class FourTubeIE should return an instance of class FourTubeIE."

    # Ensure the instantiated class is an instance of FourTubeIE.
    assert isinstance(instantiated_class, FourTubeIE), "Constructor of class FourTubeIE should return an instance of class FourTubeIE."


# Generated at 2022-06-24 12:20:46.779406
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for url in [r'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', r'http://www.4tube.com/embed/209733', r'http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black']:
        ie = FourTubeIE()
        ie.extract(url)


# Generated at 2022-06-24 12:20:47.410558
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:21:00.553719
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FE = FuxIE()
    assert FE.IE_NAME == 'fux'
    assert FE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:21:05.753427
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_dict = PornTubeIE()._real_extract('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert(info_dict['id'] == '7089759')
    assert(info_dict['duration'] == 5052)
    assert(info_dict['upload_date'] == '20150606')
    assert(info_dict['title'] == 'Teen couple doing anal')

# Generated at 2022-06-24 12:21:12.043152
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest
    class MockIE(FuxIE):
        def _real_extract(self, url):
            pass
        def _extract_formats(self, url, video_id, media_id, sources):
            pass
    ie = MockIE()
    result = ie._real_extract('https://www.fux.com/embed/195359')
    unittest.TestCase().assertEquals(result['id'], '195359')

# Generated at 2022-06-24 12:21:13.496020
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from . import PornTubeIE as tester
    return tester

# Generated at 2022-06-24 12:21:17.253029
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = PornTubeIE._URL_TEMPLATE % '12345'
    obj = PornTubeIE(url)

    assert obj is not None


# Generated at 2022-06-24 12:21:17.851261
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:21:18.675636
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:21:27.560481
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    PornTubeIE('https://www.porntube.com/embed/7089759')
    PornTubeIE('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')
    PornTubeIE._VALID_URL.match('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    PornTubeIE._VALID_URL.match('https://www.porntube.com/embed/7089759')
    PornTubeIE._VALID_URL.match('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')


# Generated at 2022-06-24 12:21:28.875543
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE.__name__ == "FourTubeIE")
    

# Generated at 2022-06-24 12:21:39.541173
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:21:40.374753
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pti = PornTubeIE()

# Generated at 2022-06-24 12:21:40.968116
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:21:44.187395
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
   url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
   ie = PornerBrosIE(url)
   print(ie.IE_NAME)
   assert(ie.IE_NAME == "PornerBros")


# Generated at 2022-06-24 12:21:45.871449
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.ie_key() == 'porntube'
    assert PornTubeIE() is not None


# Generated at 2022-06-24 12:21:51.055600
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test importing PornTubeIE from PornTubeIE module
    from .PornTubeIE import PornTubeIE

    # Test instantiating a PornTubeIE object
    assert PornTubeIE is not None
    # Retrieve PornTubeIE.ie_key
    ie_key = PornTubeIE.ie_key
    # Test that ie_key exists and is equal to "PornTube"
    assert ie_key is not None
    assert ie_key == "PornTube"

# Generated at 2022-06-24 12:21:55.064358
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._VALID_URL is not None
    assert FourTubeIE._URL_TEMPLATE is not None
    assert FourTubeIE._TKN_HOST is not None
    assert FourTubeIE._TESTS is not None
    assert FourTubeIE._BASE_URL is not None
    assert FourTubeIE._LANG is not None

# Generated at 2022-06-24 12:21:55.960383
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:21:57.969561
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:09.286710
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        assert FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black') != None
        assert FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow') != None
        assert PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759') != None
        assert PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369') != None
    except AssertionError:
        print("Class FourTubeIE does not exist")


# Generated at 2022-06-24 12:22:11.662815
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class_ = globals()['FuxIE']
    assert class_ is not None
    class_()

# Generated at 2022-06-24 12:22:13.929565
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # check that FourTubeBaseIE is initialized with a dict
    assert FourTubeBaseIE._TESTS is not None and isinstance(FourTubeBaseIE._TESTS, dict)

# Generated at 2022-06-24 12:22:15.224773
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE is not FourTubeIE

# Generated at 2022-06-24 12:22:17.708910
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'

# Generated at 2022-06-24 12:22:24.327747
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Create an object of the PornTubeIE class
    tube_ie = PornTubeIE()
    # Test extraction on a video with a channel
    info = tube_ie._real_extract('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert info['uploader_id'] == '665'
    assert info['channel'] == 'Exploited College Girls'
    assert info['channel_id'] == '665'

# Generated at 2022-06-24 12:22:33.936149
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # check if it's a dictionary
    assert isinstance(FourTubeBaseIE._TESTS, dict)
    # verify every element in _TESTS
    for url in FourTubeBaseIE._TESTS:
        test = FourTubeBaseIE._TESTS[url]
        if not test.get('only_matching'):
            continue
        assert isinstance(re.match(FourTubeBaseIE._VALID_URL, url), re.Match)

# Generated at 2022-06-24 12:22:37.891908
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE().url_result(test_url)

# Generated at 2022-06-24 12:22:38.536105
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-24 12:22:40.385554
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == FourTubeIE._TKN_HOST

# Generated at 2022-06-24 12:22:47.736734
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBase = FourTubeBaseIE
    kind = 'm'
    video_id = '12345'
    display_id = 'video_id'
    url = 'https://www.4tube.com/videos/12345/video'
    mobj = re.match(fourTubeBase._VALID_URL, url)
    assert kind == mobj.group('kind')
    assert video_id == mobj.group('id')
    assert display_id == mobj.group('display_id')

# Generated at 2022-06-24 12:22:55.416120
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._TKN_HOST == "token.pornerbros.com"
    assert obj._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-24 12:23:05.364560
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black", "http://www.4tube.com/embed/209733")
    print("Actual instance type: " + str(type(ie)))
    print("Expected instance type: " + str(type(FourTubeIE)))
    print("'www' in domain: " + str("www" in ie.host))
    print("'www' in url: " + str("www" in ie.url))
    print("'m' in domain: " + str("m" in ie.host))
    print("'m' in url: " + str("m" in ie.url))

# Generated at 2022-06-24 12:23:17.389869
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # "embed" URLs
    assert FourTubeIE()._match_id('http://www.4tube.com/embed/302381')
    assert FourTubeIE()._match_id('http://m.4tube.com/embed/302381')
    assert FourTubeIE()._match_id('http://www.fux.com/embed/302381')
    assert FourTubeIE()._match_id('http://m.fux.com/embed/302381')
    assert FourTubeIE()._match_id('http://www.porntube.com/embed/302381')
    assert FourTubeIE()._match_id('http://m.porntube.com/embed/302381')
    assert FourTubeIE()._match_id('http://www.pornerbros.com/embed/302381')

# Generated at 2022-06-24 12:23:18.065244
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

# Generated at 2022-06-24 12:23:20.096820
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test FourTubeBaseIE, the constructor
    FourTubeBaseIE("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")

# Generated at 2022-06-24 12:23:31.886187
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	Video = FourTubeIE()
	display_id = "hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
	# Test the method _real_extract()
	Video._real_extract('http://www.4tube.com/embed/209733')
	# Test the method _real_extract()
	Info = Video._real_extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
	# Test if the title is correctly extracted
	assert(Info["title"] == "Hot Babe Holly Michaels gets her ass stuffed by black")
	# Test if the ID is correctly extracted
	assert(Info["id"] == "209733")
	# Test

# Generated at 2022-06-24 12:23:38.448294
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE()
    assert i._TKN_HOST == "token.4tube.com"
    assert i._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video"
    assert i.IE_NAME == "4tube"
    assert i._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?"


# Generated at 2022-06-24 12:23:44.089741
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE._TESTS[0]['info_dict']['dislike_count'] = None
    PornTubeIE._TESTS[0]['info_dict']['categories'] = None
    PornTubeIE._TESTS[1]['info_dict']['dislike_count'] = None
    PornTubeIE._TESTS[1]['info_dict']['categories'] = None

# Generated at 2022-06-24 12:23:53.695006
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import re
    assert re.match(PornTubeIE._VALID_URL, "https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    assert re.match(PornTubeIE._VALID_URL, "https://www.porntube.com/embed/7089759")
    assert not re.match(PornTubeIE._VALID_URL, "abc://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    assert re.match(PornTubeIE._VALID_URL, "https://m.porntube.com/videos/teen-couple-doing-anal_7089759")

# Generated at 2022-06-24 12:24:01.548229
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_url = 'http://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = FourTubeBaseIE(test_url)
    assert ie.ie_key() == 'FourTubeBase', 'Test failed: ie_key not matched'
    assert ie.video_id == '195359', 'Test failed: video_id not matched'
    assert ie.display_id == '195359', 'Test failed: display_id not matched'

# Generated at 2022-06-24 12:24:03.837023
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE("https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406", None)

# Generated at 2022-06-24 12:24:04.906941
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE() is not None

# Generated at 2022-06-24 12:24:11.120690
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTubeIE = FourTubeIE()
    assert fourTubeIE._TKN_HOST == 'token.4tube.com'
    assert fourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:24:14.498044
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:24:16.012626
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()
    assert inst.IE_NAME == 'pornerbros'

# Generated at 2022-06-24 12:24:18.597614
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .test import BaseTest

    class FourTubeBaseTest(FourTubeBaseIE, BaseTest):
        pass

    # Test __init__
    test_class = FourTubeBaseTest(FourTubeBaseIE._VALID_URL)
    assert test_class.ie_key() == 'FourTube'

# Generated at 2022-06-24 12:24:30.387307
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test the case when _TKN_HOST is not specified
    try:
        class FooIE(FourTubeBaseIE):
            _VALID_URL = r'http://www.example.com/'
            _TESTS = [{
                'url': 'http://www.example.com/',
            }]
        FooIE()
        assert False, "The case when _TKN_HOST is not specified should fail."
    except TypeError:
        pass

    # Test the case when _URL_TEMPLATE is not specified

# Generated at 2022-06-24 12:24:39.887261
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    m = FourTubeBaseIE('FourTubeBaseIE', 'www.4tube.com', '4tube')
    assert m._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert m._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert m._TKN_HOST == 'token.4tube.com'

    m = FourTubeBaseIE('FuxIE', 'www.fux.com', 'fux')

# Generated at 2022-06-24 12:24:42.666467
# Unit test for constructor of class FuxIE
def test_FuxIE():
    x = FuxIE()
    assert x.IE_NAME == '4tube'


# Generated at 2022-06-24 12:24:54.088991
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:24:55.985648
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print("Testing FourTubeIE")
    IE = FourTubeIE()
    assert IE != None


# Generated at 2022-06-24 12:24:58.445791
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.__class__.__name__ == 'PornerBrosIE' and ie.IE_NAME == 'pornerbros'

# Generated at 2022-06-24 12:25:00.802801
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'


# Generated at 2022-06-24 12:25:03.658839
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == 'FourTubeBaseIE'
    assert ie._VALID_URL is None
    assert ie._URL_TEMPLATE is None
    assert ie._TKN_HOST is None
    assert ie._TESTS is None

# Generated at 2022-06-24 12:25:04.195838
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:25:05.324983
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # returns an instance of class FourTubeIE
    FourTubeIE()


# Generated at 2022-06-24 12:25:09.548186
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie_Fux = FuxIE()
    assert ie_Fux.name == FuxIE.IE_NAME
    assert ie_Fux._VALID_URL == FuxIE._VALID_URL
    assert ie_Fux._TESTS == FuxIE._TESTS
    assert ie_Fux._url_template == FuxIE._URL_TEMPLATE
    assert ie_Fux._TKN_HOST == FuxIE._TKN_HOST



# Generated at 2022-06-24 12:25:10.097980
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:25:11.256700
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import doctest
    doctest.testmod(FourTubeIE)

# Generated at 2022-06-24 12:25:19.706524
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE()
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert i._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert i._TKN_HOST == 'token.4tube.com'
    assert i.IE_NAME == '4tube'

# Generated at 2022-06-24 12:25:26.810333
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    player_js = '''<script id="playerembed" src="https://static.pornerbros.com/player/v2/build/build.js" data-id="190902" data-domain="www.pornerbros.com" data-site="pornerbros.com" data-auto="true" data-width="100%" data-height="100%" data-longtail="false" data-config="none" data-user="false" data-skin="default" data-cachebuster="548919"></script>'''
    params_js = '''[190902, "https://static.pornerbros.com/player/v2/build/plugins/sites/pornerbros.com/content/default.txt", [360, 540, 720]]'''
    url = PornerBrosIE._URL_T

# Generated at 2022-06-24 12:25:28.606297
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert 'PornerBrosIE' == PornerBrosIE.IE_NAME

# Generated at 2022-06-24 12:25:37.871950
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print("Running test for class FourTubeIE")
    # Grab video details from url
    x = FourTubeIE()
    video_details = x.extract('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    # Check if video ID is correct
    if video_details['id'] == '209733':
        print("video ID test passed")
    else:
        print("video ID test failed")
    # Check if video URL is correct
    if video_details['formats'][0]['url'] == 'https://s3.amazonaws.com/fuhg/209733/209733_480p.mp4':
        print("video url test passed")

# Generated at 2022-06-24 12:25:40.076347
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    d = PornerBrosIE()
    assert d._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-24 12:25:44.409147
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-24 12:25:54.058532
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    ie._URL_TEMPLATE = 'https://www.porntube.com/videos/video_%s'
    ie._TKN_HOST = 'tkn.porntube.com'

# Generated at 2022-06-24 12:26:05.688709
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_utils_media_info import VIDEO_INFO
    import pytest
    from .test_utils_media_info import get_media_info
    with pytest.raises(TypeError) as exc_info:
        PornerBrosIE(None)
    assert exc_info.value.args == ('n is null',)
    with pytest.raises(TypeError) as exc_info:
        PornerBrosIE('abc')
    assert exc_info.value.args == ('n is not int',)
    with pytest.raises(ValueError) as exc_info:
        PornerBrosIE(-1)
    assert exc_info.value.args == ('n < 1',)
    assert PornerBrosIE(1).n == 1
    assert PornerBrosIE(0).n == 1
   

# Generated at 2022-06-24 12:26:09.216723
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie._TKN_HOST == ie._VALID_URL == ie._URL_TEMPLATE == ie.js_to_json == ie._extract_formats == ie._real_extract == None

# Generated at 2022-06-24 12:26:20.113589
# Unit test for constructor of class FuxIE
def test_FuxIE():
    I = FuxIE()
    assert I.IE_NAME == '4tube'
    assert I._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert I._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert I._TKN_HOST == 'token.fux.com'
    assert I._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'