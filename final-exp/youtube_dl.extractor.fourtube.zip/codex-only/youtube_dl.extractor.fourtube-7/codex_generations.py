

# Generated at 2022-06-24 12:16:15.377596
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    except Exception:
        assert False, 'Failed to construct class FourTubeBaseIE'
    assert True

# Generated at 2022-06-24 12:16:20.190803
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    mobj = re.match(_VALID_URL, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert mobj.group('id') == '181369'

# Generated at 2022-06-24 12:16:22.798579
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE(None)

    obj = FourTubeBaseIE(None)
    assert obj

# Functional tests for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:16:27.543605
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        from ..extractor.generic import GenericIE
    except ImportError:
        from ..utils import MissingDependencyException
        raise MissingDependencyException(
            'The additional youtube-dl test classes require the package '
            'youtube-dl.')
    # test constructor without info_dict
    FourTubeIE(GenericIE('FourTube', '4tube'))

# Generated at 2022-06-24 12:16:33.062018
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test variable declaration
    # Instantiate class object
    f = FourTubeIE()
    # Run extraction tests
    e = f.extract('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert e['id'] == '209733'
    assert e['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert e['timestamp'] == 1383263892


# Generated at 2022-06-24 12:16:34.905081
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    case = FourTubeBaseIE('4TubeBase')

# Generated at 2022-06-24 12:16:44.204382
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from unittest import TestCase

    class FourTubeTest(TestCase, FourTubeBaseIE):
        @property
        def IE_NAME(self):
            return 'Test'

        @property
        def _VALID_URL(self):
            return r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

        @property
        def _URL_TEMPLATE(self):
            return 'https://www.4tube.com/videos/%s/video'

        @property
        def _TKN_HOST(self):
            return 'token.4tube.com'


# Generated at 2022-06-24 12:16:45.437954
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    for url in PornTubeIE()._TESTS:
        url_obj = url['url']

# Generated at 2022-06-24 12:16:54.014482
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_item = {
        'info_dict': {'id': '209733', 'title': 'Hot Babe Holly Michaels gets her ass stuffed by black'},
        'params': {
            'skip_download': True
        }
    }
    ie = FourTubeIE()
    ie.suitable(test_item['info_dict']['id'])
    ie.extract(test_item['info_dict']['id'])
    ie._extract_title(test_item['info_dict']['id'])
    ie.handle_download()
    ie.result()
    ie.download()
    ie._extract_description()
    ie.add_default_info_extractors()
    ie._download_and_extract_info(test_item['info_dict']['id'], {})

# Generated at 2022-06-24 12:16:54.865684
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-24 12:16:58.798774
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    su = FourTubeBaseIE._download_json
    assert(su is FourTubeBaseIE._download_json)
    su2 = PornTubeIE._download_json
    assert(su2 is not FourTubeBaseIE._download_json)

# Generated at 2022-06-24 12:17:00.041536
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:17:01.082441
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-24 12:17:03.204320
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE("www","181369", "skinny-brunette-takes-big-cock-down-her-anal-hole")

# Generated at 2022-06-24 12:17:04.287582
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:17:12.302867
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test for _extract_formats
    # FourTubeBaseIE._extract_formats(
    #     FourTubeBaseIE(),
    #     'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
    #     '209733',
    #     'd4f7184884374b3c957d881934c05cfa',
    #     ['360', '540', '720']
    # )
    print('end test')

# Generated at 2022-06-24 12:17:21.020726
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """This test ensures that the constructor of FuxIE works as expected.
    It checks if the extracted data makes sense.
    """
    v = FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert v.IE_NAME == '4tube'
    assert v.validate("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert v.IE_NAME == '4tube'
    assert v.validate("https://www.fux.com/embed/195359")
    assert v.IE_NAME == '4tube'
    assert not v.validate("https://www.someotherpage.com/video/195359")

# Generated at 2022-06-24 12:17:31.619569
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')
    assert ie._VALID_URL == FourTubeIE._VALID_URL
    assert ie._URL_TEMPLATE == FourTubeIE._URL_TEMPLATE
    assert ie._TKN_HOST == FourTubeIE._TKN_HOST

    ie = FourTubeBaseIE('fux')
    assert ie._VALID_URL == FuxIE._VALID_URL
    assert ie._URL_TEMPLATE == FuxIE._URL_TEMPLATE
    assert ie._TKN_HOST == FuxIE._TKN_HOST

    ie = FourTubeBaseIE('porntube')
    assert ie._VALID_URL == PornTubeIE._VALID_URL
    assert ie._URL_TEMPLATE == PornTubeIE._URL_TEMPLATE

# Generated at 2022-06-24 12:17:40.412371
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(PornerBrosIE._VALID_URL, test_url)
    video_id, display_id = mobj.group('id', 'display_id')
    PornerBrosIE(PornerBrosIE._downloader, PornerBrosIE._downloader.context)._url_basename(video_id, display_id)
    PornerBrosIE(PornerBrosIE._downloader, PornerBrosIE._downloader.context)._real_initialize()

# Generated at 2022-06-24 12:17:41.489091
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:17:43.053434
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Unit test for constructor of class FuxIE
    assert FuxIE.__module__ == 'you_get.extractors.fourtube'

# Generated at 2022-06-24 12:17:45.163455
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    re.match(fux._VALID_URL, 'https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:17:51.247689
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    _FourTubeIE = type('FourTubeIE', (FourTubeIE, object), {'_TKN_HOST': 'token.4tube.com'})
    _FourTubeIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    _FourTubeIE._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:17:52.396855
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-24 12:17:53.074056
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:17:55.288783
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Instantiate the FuxIE class
    foo = FuxIE()
    assert foo is not None

# Generated at 2022-06-24 12:18:02.303601
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Test for class FourTubeBaseIE
    """
    ie = FourTubeBaseIE()
    # pylint: disable=protected-access
    # Check for token host variable
    assert ie._TKN_HOST == 'token.4tube.com'
    # Check for URL template variable
    assert len(ie._URL_TEMPLATE) != 0
    # Check for regex find values
    is_matched = ie._VALID_URL_BASE.search('https://www.4tube.com/videos/123456/video')
    assert '123456' in is_matched.group('id')

# Generated at 2022-06-24 12:18:03.739790
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE != None

# Generated at 2022-06-24 12:18:11.665939
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
        # should work as a normal IE
        ie = FourTubeBaseIE()
        test_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
        video_info = ie._real_extract(test_url)
        assert video_info['id'] == '209733'

        # should work with the base class
        ie = FourTubeBaseIE(test_url)
        video_info = ie.result()
        assert video_info['id'] == '209733'

# Generated at 2022-06-24 12:18:17.169577
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	info = FourTubeIE()._real_extract(url='http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
	assert info['id'] == '209733'


# Generated at 2022-06-24 12:18:17.817424
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-24 12:18:19.291870
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')


# Generated at 2022-06-24 12:18:20.449995
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert str(FourTubeBaseIE(None, None)) == "FourTubeBaseIE"


# Generated at 2022-06-24 12:18:21.457408
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    print("This is the constructor of PornTubeIE")

# Generated at 2022-06-24 12:18:24.728980
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie_class = PornerBrosIE.__name__
    ie = globals()[ie_class](None)
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 12:18:36.969231
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Initialization for the test function
    url_1 = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    url_2 = 'https://www.4tube.com/embed/209733'
    url_3 = 'https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    url_4 = 'https://www.4tube.com/videos/209733'

    # Checking if the class is correctly initialized
    assert FourTubeIE._VALID_URL.match(url_1).group('id') == '209733'
    assert FourTubeIE._VALID_URL.match

# Generated at 2022-06-24 12:18:38.020728
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .. import IE_NAME

# Generated at 2022-06-24 12:18:46.904089
# Unit test for constructor of class FuxIE
def test_FuxIE():
    mobj = re.match(FuxIE._VALID_URL, 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    video_id, display_id = mobj.group('id', 'display_id')
    page = FuxIE._download_webpage('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow', display_id)
    data = FuxIE._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',page,'data',group='value')

# Generated at 2022-06-24 12:18:59.372089
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test _TESTS[0] with _VALID_URL
    for _ in range(2):
        _TESTS[0] = _TESTS[0].copy()
        _TESTS[0]['info_dict'] = _TESTS[0]['info_dict'].copy()
        url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
        _TESTS[0]['info_dict']['id'] = url
        _TESTS[0]['info_dict']['url'] = url
        _TESTS[0]['info_dict']['ext'] = 'mp4'

# Generated at 2022-06-24 12:19:00.312827
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	test = FourTubeIE()

# Generated at 2022-06-24 12:19:11.576399
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from numbers import Number

    def test_parse_duration(duration_string, expected_duration):
        assert parse_duration(duration_string) == expected_duration

    ftb_inst = FourTubeBaseIE()
    assert ftb_inst

    # Unit test for parse_duration
    test_parse_duration('15.5', 15.5)
    test_parse_duration('1:05.5', 65.5)
    test_parse_duration('2:05:05.5', 7305.5)
    test_parse_duration('0:0:0.5', 0.5)
    test_parse_duration('a', None)
    test_parse_duration(None, None)
    test_parse_duration(-1, None)
    test_parse_duration(0, 0)

# Generated at 2022-06-24 12:19:17.424060
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    print("Testing constructor of class FourTubeIE")
    test_object = FourTubeIE("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert type(test_object) == FourTubeIE
    print("Passed all tests")

# Generated at 2022-06-24 12:19:18.069964
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:19:21.023675
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie1 = FourTubeBaseIE()
    assert isinstance(ie, FourTubeBaseIE)
    assert isinstance(ie1, FourTubeBaseIE)


# Generated at 2022-06-24 12:19:24.694998
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert x._VALID_URL is not None
    assert x._URL_TEMPLATE is not None
    assert x._TKN_HOST is not None
    assert x._TESTS is not None

# Generated at 2022-06-24 12:19:33.475197
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:19:42.123119
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test 1
    test1 = FourTubeIE()._TESTS[0]
    assert (test1['info_dict']['id'] == '209733')
    assert (test1['info_dict']['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black')
    # Test 2
    test2 = FourTubeIE()._TESTS[1]
    assert (test2['info_dict']['id'] == '209733')
    assert (test2['info_dict']['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black')


# Generated at 2022-06-24 12:19:52.938224
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:19:54.451413
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()

# Generated at 2022-06-24 12:19:55.789682
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE()
    instance.IE_NAME
    instance.IE_DESC

# Generated at 2022-06-24 12:20:05.162854
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import unittest
    from unittest import mock

    class _Mock_PornTubeIE(PornTubeIE):

        _TESTS = [{
            'url': 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
            'md5': 'd41d8cd98f00b204e9800998ecf8427e',
        }]

        def _download_webpage(self, url, video_id, *args, **kwargs):
            return mock.Mock(
                return_value=b'INITIALSTATE=["data"]')

        def _real_extract(self, url):
            return super(_Mock_PornTubeIE, self)._real_extract(url)


# Generated at 2022-06-24 12:20:13.769575
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    '''
    Test class FourTubeBaseIE.
    '''
    parsed_url = compat_urlparse.urlparse('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    token_url = 'https://tkn.porntube.com/7089759/desktop/480+720'
    obj = FourTubeBaseIE()
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:20:21.134199
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for ie in [FourTubeIE]:
        assert ie.suitable("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black") == True
        assert ie.suitable("https://www.4tube.com/embed/209733") == True
        assert ie.suitable("https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black") == True


# Generated at 2022-06-24 12:20:22.113401
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:31.170174
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        from Crypto.Cipher import AES
        aes = True
    except ImportError:
        aes = False
    try:
        from Crypto.PublicKey import RSA
        rsa = True
    except ImportError:
        rsa = False
    import sys
    if not aes and sys.version_info < (2, 7, 7):
        aes = True
    if not rsa and sys.version_info < (2, 7, 9):
        rsa = True
    assert PornTubeIE._download_json(None, 'test', 'http://localhost:8080',
        transform_source=lambda x, y: y).endswith('"test"')

# Generated at 2022-06-24 12:20:42.593448
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test case 1
    # Input
    title = "Awesome fucking in the kitchen ends with cum swallow"
    uploader = "alenci2342"
    uploader_id = "alenci2342"
    categories =[
        "Amateur",
        "Brunette",
        "Cumshot",
        "Femdom",
        "Fetish",
        "Handjob",
        "Kitchen",
        "Outdoor",
        "Pornstar",
        "Reality",
        "Solo Female"
    ]
    view_count = 138085
    duration = 289
    timestamp = 1388361660

    # Expected result

# Generated at 2022-06-24 12:20:43.426832
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:20:44.695804
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.is_available()


# Generated at 2022-06-24 12:20:49.036726
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().IE_NAME == '4tube'
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-24 12:20:53.716818
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    inst = PornTubeIE("https://www.porntube.com/videos/bromance-makes-room-for-a-third_1139476")
    assert inst._VALID_URL is not None

# Generated at 2022-06-24 12:21:01.768402
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    # Parameters of constructor
    # type: class FourTubeBaseIE
    # 
    # Parameters:
    #     ie_name: str
    #     ie_key: str
    #     ie_id: int

    # Following variables are used for testing purposes
    ie_name = "4tube" 
    ie_key = "YOUTUBE_IE" 
    ie_id = 0 

    # Create an object of class FourTubeBaseIE
    fourTubeBaseIE = FourTubeBaseIE(ie_name, ie_key, ie_id)

# Generated at 2022-06-24 12:21:03.145647
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, FourTubeBaseIE)


# Generated at 2022-06-24 12:21:09.438310
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:21:21.582684
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test case 1
    init_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    # Test case 2
    init_family_friendly = False
    init_age_limit = 18
    # Test case 3
    init_app_player = True
    init_token_url = 'https://token.4tube.com/209733/desktop/360+480+720'

    # Test case expected 1
    expected_video_id = '209733'
    # Test case expected 2
    expected_family_friendly = False
    expected_age_limit = 18
    # Test case expected 3
    expected_app_player = True

# Generated at 2022-06-24 12:21:29.393591
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(PornTubeIE._downloader, 'http://www.porntube.com/videos/secret-lesbian-gentlemen-2_8534741')._TKN_HOST == 'tkn.porntube.com'
    assert PornTubeIE(PornTubeIE._downloader, 'https://m.porntube.com/videos/secret-lesbian-gentlemen-2_8534741')._TKN_HOST == 'tkn-mobile.porntube.com'
    assert PornTubeIE(PornTubeIE._downloader, 'https://www.porntube.com/embed/8534741')._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:21:32.426477
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	try:
		FourTubeIE()
		assert True, 'Test Passed'
	except Exception as e:
		assert False, 'Test Failed: ' + str(e)


# Generated at 2022-06-24 12:21:41.654431
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.PornTube.com/videos/video_181369'
    result_1 = PornTubeIE()._search_regex(r'(?P<value>\d+)\)', url, 'data', group='value')
    result_2 = PornTubeIE()._parse_json(result_1, '181369')
    assert result_1 == '181369'
    assert result_2['page']['video']['id'] == 181369

# Generated at 2022-06-24 12:21:46.328699
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Note: the result data of extract function is the same with above.
    PornerBrosIE().extract(
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:21:48.174210
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    result = PornerBrosIE()
    assert(isinstance(result.__class__, type))


# Generated at 2022-06-24 12:21:57.379060
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:22:00.720938
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube', '4tube')
    # the object created by constructor is an instance of the class InfoExtractor
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-24 12:22:03.455090
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_PornerBrosIE = PornerBrosIE()
    assert (test_PornerBrosIE == PornerBrosIE)


# Generated at 2022-06-24 12:22:05.252932
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-24 12:22:14.894027
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Import modules
    import sys
    import os
    import os.path
    import json

    # Append project directory to PYTHONPATH
    sys.path.append(os.path.abspath(os.path.join("..", "..", "..", "..", "..")))

    # Import modules
    from youtube_dl import YoutubeDL

    # Set verbosity
    youtube_dl_opts = {"verbose": True}

    # List of urls to test
    urls = ["https://www.pornerbros.com/embed/181369"]

    # Test YoutubeDL instance

# Generated at 2022-06-24 12:22:17.065612
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj1 = FourTubeIE()
    assert obj1.IE_NAME == '4tube'

# Generated at 2022-06-24 12:22:18.122028
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(FuxIE._downloader)

# Generated at 2022-06-24 12:22:21.062887
# Unit test for constructor of class FuxIE
def test_FuxIE():
    t = FuxIE()
    assert t._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'

# Generated at 2022-06-24 12:22:31.309929
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import os
    import tempfile
    tempfile.gettempdir()
    os.path.realpath('.')

    s = FourTubeBaseIE()
    s._download_json([], '', [], {})
    s._extract_formats('', '', '', [])
    s._sort_formats([])
    s._download_webpage('', '', {})
    s._search_regex('', '', '', '')
    s._parse_json('', '')
    s._html_search_regex('', '', '', '')
    s._html_search_meta('', '')
    s._search_json_ld('', '', '', '')
    s._get_request_url()
    s._get_webpage_url()
    s._get_webpage_url

# Generated at 2022-06-24 12:22:42.881630
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:22:43.975293
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:53.310176
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    mobj = re.match(FuxIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    assert mobj.group('kind') is None
    assert video_id == '195359'
    assert display_id == 'awesome-fucking-kitchen-ends-cum-swallow'
    assert FuxIE._URL_TEMPLATE % video_id == ('https://www.fux.com/video/%s/video' % video_id)
    assert FuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:23:03.884797
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')
    webpage = PornerBrosIE._download_webpage(url, display_id)


# Generated at 2022-06-24 12:23:06.016621
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    if __name__ == '__main__':
        result = FourTubeIE()


# Generated at 2022-06-24 12:23:09.659337
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIEInstance = FourTubeBaseIE()
    if fourTubeBaseIEInstance is None:
        assert False, "FourTubeBaseIE constructor not working as expected."


# Generated at 2022-06-24 12:23:10.713776
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('FourTube')

# Generated at 2022-06-24 12:23:22.352898
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    pb = PornTubeIE()
    assert pb._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert pb._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pb._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:23:23.394499
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE()

# Generated at 2022-06-24 12:23:26.714764
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    expected_instance = PornTubeIE()
    assert expected_instance.__class__.__bases__[0].__name__ == "FourTubeBaseIE"

# Generated at 2022-06-24 12:23:29.929675
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert PornTubeIE()._real_extract(url)



# Generated at 2022-06-24 12:23:33.087396
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:23:41.249482
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    # Check if FuxIE inherits from FourTubeBaseIE
    assert issubclass(FuxIE, FourTubeBaseIE) is True
    # Check if FuxIE has the right name
    assert ie.IE_NAME == 'fux'
    # Check if FuxIE has the right VALID_URL
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    # Check if FuxIE has the right URL_TEMPLATE
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    # Check if Fux

# Generated at 2022-06-24 12:23:43.173880
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._extract_formats("", "", "", [])

# Generated at 2022-06-24 12:23:44.722984
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f = FourTubeBaseIE()
    assert f is not None


# Generated at 2022-06-24 12:23:55.309315
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerbros_ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerbros_ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:23:56.424938
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE is not None

# Generated at 2022-06-24 12:24:00.898226
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    four = FourTubeIE()
    assert four._TKN_HOST == 'token.4tube.com'
    assert four._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:24:03.596127
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('FuxIE','FourTube','FourTubeBase','PornTube','PornerBros')

if __name__ == '__main__':
    test_FuxIE()

# Generated at 2022-06-24 12:24:04.053837
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:06.730152
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', video_id='209733')
    inst.ie_key()
    inst.suitable()
    inst.working()
    # TODO assert inst.extract()

# Generated at 2022-06-24 12:24:07.464363
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:24:08.064285
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None, None)

# Generated at 2022-06-24 12:24:09.153787
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert(PornerBrosIE()._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-24 12:24:13.691665
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_ie = FourTubeBaseIE(None)
    assert test_ie.IE_NAME
    assert test_ie._VALID_URL
    assert test_ie._URL_TEMPLATE
    assert test_ie._TKN_HOST
    assert test_ie._TESTS

if __name__ == '__main__':
    test_FourTubeBaseIE()

# Generated at 2022-06-24 12:24:14.506931
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:24:15.094080
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:16.362275
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:24:27.475469
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..compat import compat_str
    from ..extractor import gen_extractors_map
    from ..utils import extract_attributes

    # set up the test environment
    info_dict = {
        'id': '1',
        'ext': 'mp4',
        'title': 'test',
        'uploader': 'me',
        'uploader_id': 'me',
        'upload_date': '20130130',
        'timestamp': 1359527401,
        'duration': 1224,
        'view_count': 100,
        'categories': ['cat1', 'cat2'],
        'age_limit': 18,
    }
    url = 'http://www.4tube.com/videos/1/title'

# Generated at 2022-06-24 12:24:34.876015
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj.IE_NAME == '4tube'



# Generated at 2022-06-24 12:24:43.598201
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    obj._TKN_HOST = 'token.4tube.com'
    # If a duration is null or not present, _extract_formats returns None
    # It's a website issue
    obj._extract_formats('https://www.4tube.com/embed/209733', '209733', '112766', ['720', '480', '360', '240'])
    # If the token_url is not present, _extract_formats returns None
    # It's a website issue
    obj._TKN_HOST = 'token.porntube.com'
    obj._extract_formats('https://www.porntube.com/embed/7089759', '7089759', '259440', ['720', '480', '360', '240'])

# Generated at 2022-06-24 12:24:45.792262
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert (obj._TKN_HOST == "token.4tube.com")

# Generated at 2022-06-24 12:24:53.822255
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    class TestFourTubeIE(FourTubeIE):
        def __init__(self):
            pass
    TestFourTubeIE()
    class TestFourTubeIE():
        def __init__(self):
            pass
    TestFourTubeIE = TestFourTubeIE()
    assert TestFourTubeIE.suitable('%s' % url) == True


# Generated at 2022-06-24 12:25:04.095310
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # testing constructor
    from .pornhub import PornHubIE
    from .pornhub import PornHubPlaylistIE
    from .xhamster import XHamsterIE
    from .xvideos import XvideosIE
    from .youporn import YouPornIE
    from .youjizz import YouJizzIE
    from .redtube import RedTubeIE
    from .hdpornx import HDPornXIE
    from .motherless import MotherlessIE
    import copy
    import inspect
    import os
    import re
    import sys
    import json

    def print_dict(d):
        print(json.dumps(d, indent=4))

    def run_test(class_to_test):
        # get test data from url
        ie = class_to_test()

# Generated at 2022-06-24 12:25:09.953003
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:25:17.244121
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    video_id = '209733'
    display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    kind = 'www'

    mobj = re.match(FourTubeIE._VALID_URL, url)
    assert mobj.group('kind') == kind
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') == display_id

# Generated at 2022-06-24 12:25:28.163948
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    def test_constructor():
        url = 'https://www.porntube.com/embed/7089759'
        fourTubeExtractor = PornTubeIE()
        if fourTubeExtractor._VALID_URL != r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)':
            print('Error: _VALID_URL is not correct')

        if fourTubeExtractor._URL_TEMPLATE != 'https://www.porntube.com/videos/video_%s':
            print('Error: _URL_TEMPLATE is not correct')


# Generated at 2022-06-24 12:25:29.049265
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor) == True

# Generated at 2022-06-24 12:25:33.340963
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    video = PornerBrosIE._real_extract(PornerBrosIE(), url)
    assert video['id'] == '181369'

# Generated at 2022-06-24 12:25:44.409330
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    _URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    _TKN_HOST = 'token.fux.com'
    mobj = re.match(_VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')
    webpage = _download_webpage(url, display_id)
    video

# Generated at 2022-06-24 12:25:53.130141
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert(ie.IE_NAME == '4tube')
    assert(ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(ie._TKN_HOST == 'token.4tube.com')
    assert(isinstance(ie, FourTubeBaseIE))
    #test_FourTubeIE()


# Generated at 2022-06-24 12:25:55.337423
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class UnitTestFourTubeBaseIE(FourTubeBaseIE):
        def __init__(self):
            pass
    UnitTestFourTubeBaseIE()
    return

# Generated at 2022-06-24 12:25:59.591067
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    ie = PornTubeIE()
    ie._download_webpage(url, '7089759')

# Generated at 2022-06-24 12:26:01.172863
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME

# Generated at 2022-06-24 12:26:02.399599
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Should not raise an error
    FuxIE()

# Generated at 2022-06-24 12:26:03.781833
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Arrange
    ie = FourTubeIE()

    # Act
    ie.IE_NAME

    # Assert


# Generated at 2022-06-24 12:26:04.718691
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:26:06.607828
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie is not None

# Generated at 2022-06-24 12:26:17.922817
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    mobj = re.match(FourTubeIE._VALID_URL, 'http://www.4tube.com/videos/136745/')
    assert mobj.group('kind') is None
    assert mobj.group('id') == '136745'
    assert mobj.group('display_id') is None
    mobj = re.match(FourTubeIE._VALID_URL, 'http://www.4tube.com/embed/136745')
    assert mobj.group('kind') is None
    assert mobj.group('id') == '136745'
    assert mobj.group('display_id') is None
    mobj = re.match(FourTubeIE._VALID_URL, 'http://m.4tube.com/videos/136745/')