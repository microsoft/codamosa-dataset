

# Generated at 2022-06-24 12:16:26.025860
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert fuxIE._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
    assert fuxIE._TKN_HOST == "token.fux.com"

# Generated at 2022-06-24 12:16:34.071023
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert not FourTubeBaseIE(None).suitable('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert not FourTubeBaseIE(None).suitable('https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert not FourTubeBaseIE(None).suitable('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert not FourTubeBaseIE(None).suitable('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:16:37.656850
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:16:38.301317
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:16:39.334335
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FourTubeBaseIE())

# Generated at 2022-06-24 12:16:41.403200
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.ie_key() == 'PornTube'
    assert ie.ie_name() == 'PornTube'

# Generated at 2022-06-24 12:16:50.945730
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info_extractor = FourTubeIE()
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert info_extractor._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert info_extractor._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:16:51.639237
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:17:02.549995
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_parse import _TESTS as test_templates
    from ..utils import ExtractorError
    import unittest

    class PornTubeIETest(unittest.TestCase):
        def setUp(self):
            self.__class__.ie = PornTubeIE()

        def test_extract_media_id_and_sources(self):
            for test in test_templates:
                if test['skip']:
                    continue
                if test['url'].find('/embed/') != -1:
                    continue
                webpage = test['data']

# Generated at 2022-06-24 12:17:05.075447
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._VALID_URL.match("https://www.porntube.com/videos/teen-couple-doing-anal_7089759") is not None

# Generated at 2022-06-24 12:17:07.715804
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_IE = PornerBrosIE()
    assert pornerbros_IE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:17:09.202185
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()

# Generated at 2022-06-24 12:17:13.335186
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'



# Generated at 2022-06-24 12:17:17.651406
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert re.match(FuxIE._VALID_URL, 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow') is not None
    assert re.match(FuxIE._VALID_URL, 'https://www.fux.com/embed/195359') is not None
    assert re.match(FuxIE._VALID_URL, 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow') is not None


# Generated at 2022-06-24 12:17:18.285227
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:17:26.467127
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:17:29.235848
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    loader = PornTubeIE()
    try:
        assert(loader. IE_NAME == "PornTube")
    except AssertionError:
        raise Exception("PornTube IE name is not \"PornTube\"")

# Generated at 2022-06-24 12:17:31.176241
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Test that the class constructor is not broken."""
    FourTubeIE()


# Generated at 2022-06-24 12:17:36.670146
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._TEST == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-24 12:17:40.322680
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert(instance._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')

# Generated at 2022-06-24 12:17:43.732497
# Unit test for constructor of class FuxIE
def test_FuxIE():
    info = FuxIE()._real_extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    print(info)
# unit test
#test_FuxIE()
# todo: add more tests

# Generated at 2022-06-24 12:17:55.936745
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBros = PornerBrosIE()
    assert PornerBros.IE_NAME == 'pornerbros'
    assert PornerBros._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBros._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBros._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:18:00.745485
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    unsupported_urls = [
        'https://m.4tube.com',
        'https://m.4tube.com/',
        'https://m.4tube.com/videos'
    ]
    for url in unsupported_urls:
        with pytest.raises(ExtractorError):
            FourTubeIE()._real_extract(url)



# Generated at 2022-06-24 12:18:06.277080
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-24 12:18:10.104923
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ins = PornerBrosIE('http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert ins._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:18:15.684486
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_cases = [
        {"videos": [
            {"encodings": [
                {"height": 360}
            ]}
        ]},
        {"videos": [
            {"encodings": [
                {"height": 1080}
            ]}
        ]},
        {"videos": [
            {"encodings": [
                {"height": 576}
            ]}
        ]},
        {"videos": [
            {"encodings": [
                {"height": 2160}
            ]}
        ]},
        {"videos": [
            {"encodings": [
                {"height": 1080},
                {"height": 720},
                {"height": 480},
                {"height": 360},
                {"height": 240}
            ]}
        ]}
    ]

# Generated at 2022-06-24 12:18:16.884471
# Unit test for constructor of class FuxIE
def test_FuxIE():
    s = FuxIE()
    assert s._TKN_HOST == "token.fux.com"


# Generated at 2022-06-24 12:18:22.453951
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL is not None
    assert obj._URL_TEMPLATE is not None
    assert obj._TKN_HOST is not None
    assert obj._TESTS is not None

# Generated at 2022-06-24 12:18:29.851191
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Unit test for constructor of class FuxIE
    :return: None
    """
    # Test case one
    print('Test case one')
    print('Expected result: Case one succeed')
    try:
        fux = FuxIE()
    except Exception as e:
        print('Exception of type {0} occurred'.format(type(e).__name__))
    print()


# Generated at 2022-06-24 12:18:31.992161
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
  x = FourTubeIE()
  assert x != None, "Instance of class FourTubeIE can't be created"

# Generated at 2022-06-24 12:18:39.037305
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:18:43.328502
# Unit test for constructor of class FuxIE
def test_FuxIE():
    expected = {'url': 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow',
                'only_matching': True}
    current = __import__('yt_4tube').compat_urlparse.urlparse(FuxIE()._VALID_URL)
    assert expected == current

# Generated at 2022-06-24 12:18:43.786693
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:18:45.108062
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube', 'FourTubeBase.ie')
    assert ie.SUCCESS == 0
    assert ie.FAIL == 1

# Generated at 2022-06-24 12:18:56.248232
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    assert mobj is not None
    assert 'www' == mobj.group('kind')
    assert '181369' == mobj.group('id')
    assert 'skinny-brunette-takes-big-cock-down-her-anal-hole' == mobj.group('display_id')
    assert PornerBrosIE._URL_TEMPLATE % '181369' == PornerBrosIE._real_extract(url)


# Generated at 2022-06-24 12:19:07.039068
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:19:15.839927
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test a site with a working suport
    url_m = 'http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    m_obj = FourTubeBaseIE(url_m)
    assert isinstance(m_obj, FourTubeBaseIE)
    assert m_obj.IE_NAME == '4tube'

    # Test a site with a working suport
    url_f = 'http://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'
    f_obj = FourTubeBaseIE(url_f)
    assert isinstance(f_obj, FourTubeBaseIE)
    assert f_obj.IE_NAME == 'fux'

    #

# Generated at 2022-06-24 12:19:17.179771
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
    except Exception:
        assert False


# Generated at 2022-06-24 12:19:18.517490
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_obj = PornerBrosIE()


# Generated at 2022-06-24 12:19:22.011028
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .PornTubeIE import PornTubeIE
    url = 'porntube.com/videos/teen-couple-doing-anal_7089759'
    ie = PornTubeIE(url)
    print(ie.constructor_url)

# Generated at 2022-06-24 12:19:24.048084
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    Test that PorntubeIE can be successfully instantiated.
    """
    PornTubeIE()

# Generated at 2022-06-24 12:19:33.011273
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:19:41.655915
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_downloader import _fetch_urls
    _fetch_urls('PornTube', [
        "https://www.porntube.com/videos/teen-couple-doing-anal_7089759",
        "https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406",
        "https://www.porntube.com/embed/7089759",
        "https://m.porntube.com/videos/teen-couple-doing-anal_7089759"
    ], ie_key='PornTube')

# Generated at 2022-06-24 12:19:49.778197
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == "4tube"
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._TESTS

# Generated at 2022-06-24 12:19:57.021605
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    '''
    Test constructor of class PornTubeIE
    '''
    import six.moves.urllib.parse as urlparse
    from ytdl_seven.compat import b

    url = 'https://www.porntube.com/embed/7089759'
    page = '<script>INITIALSTATE=b64(%s)</script>' % urlparse.quote(
        b('{"page":{"video":{"title":"Teen couple doing anal"}}').encode(
            'base64'))
    PornTubeIE()._real_extract(url=url, webpage=page)

# Generated at 2022-06-24 12:19:59.458409
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # No error should be thrown by constructor
    assert FourTubeIE()

# Sample usage of constructor of class FourTubeIE

# Generated at 2022-06-24 12:20:00.420221
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()._TESTS

# Generated at 2022-06-24 12:20:02.722897
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Unit test for constructor of class PornerBrosIE
    """
    pornerBrosIE = PornerBrosIE()
    print(pornerBrosIE)

# Generated at 2022-06-24 12:20:07.160807
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f1 = FourTubeBaseIE()
    f2 = FourTubeBaseIE()

    f1.to_screen = f2.to_screen
    f1._downloader = f2._downloader
    f1.report_warning = f2.report_warning
    f1.report_error = f2.report_error

    return f1, f2

# Generated at 2022-06-24 12:20:10.915089
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('FourTubeBaseIE', '4tube.com')
    FuxIE('FourTubeBaseIE', 'fux.com')
    PornTubeIE('FourTubeBaseIE', 'porntube.com')
    PornerBrosIE('FourTubeBaseIE', 'pornerbros.com')

# Generated at 2022-06-24 12:20:16.334230
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    if __name__ == '__main__':
        url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
        obj = FourTubeBaseIE()
        res = obj._real_extract(url)
        print(res)

# Generated at 2022-06-24 12:20:19.995575
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert ie._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
    assert ie._TKN_HOST == "token.fux.com"

# Generated at 2022-06-24 12:20:21.608737
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)
    assert not issubclass(FourTubeBaseIE, YoutubeIE)

# Generated at 2022-06-24 12:20:26.525023
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
  from .FourTubeIE import FourTubeIE
  from .youtube_dl.YoutubeDL import YoutubeDL
  youtube_dl = YoutubeDL()
  fourTube = FourTubeIE(youtube_dl)
  assert fourTube._VALID_URL == r'https?://(?:www\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(/[^/?#&]+)?'

# Generated at 2022-06-24 12:20:29.238687
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.download_webpage('https://www.4tube.com/videos/193797/petite-teen-with-puffy-pussy-fingering-herself')

# Generated at 2022-06-24 12:20:36.412935
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    for url in ('https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
                'https://m.porntube.com/videos/teen-couple-doing-anal_7089759'):
        pornTubeIE = PornTubeIE()
        assert url == pornTubeIE._real_extract(url)['url']

# Generated at 2022-06-24 12:20:39.277312
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()
    assert porn_tube_ie._TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-24 12:20:44.272943
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube', {})
    assert ie.ie_key() == '4tube'
    assert ie.ie_name() == '4tube'


# Generated at 2022-06-24 12:20:45.586013
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except Exception as e:
        return False
    else:
        return True

# Generated at 2022-06-24 12:20:47.003619
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube = PornTubeIE()
    assert isinstance(porn_tube, PornTubeIE)

# Generated at 2022-06-24 12:20:48.161411
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()

# Generated at 2022-06-24 12:20:50.430959
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    result = FourTubeBaseIE._TKN_HOST
    assert result == 'token.4tube.com'

# Generated at 2022-06-24 12:21:00.505872
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'
    assert PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:04.072736
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TESTS[0]['url'] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-24 12:21:07.159007
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    cls = PornerBrosIE
    assert cls == PornerBrosIE
    assert cls != FourTubeBaseIE
    assert cls != PornerBrosIE

test_PornerBrosIE()

# Generated at 2022-06-24 12:21:14.493291
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    tmpl = 'https://www.pornerbros.com/videos/video_%s'
    id = '181369'
    url = tmpl % id
    pb = PornerBrosIE()
    assert pb._URL_TEMPLATE == tmpl
    assert pb._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:21:23.368833
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import _parse_mpd_formats
    f = FourTubeIE()
    assert f is not None
    assert f._TESTS[0].get('url') == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    # Test mpd format extraction
    assert _parse_mpd_formats.__name__ == '_parse_mpd_formats'
    assert f._extract_formats.__name__ == 'FourTubeBaseIE._extract_formats'

# Generated at 2022-06-24 12:21:27.046125
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()

# Generated at 2022-06-24 12:21:29.009152
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:34.302393
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Unit test for constructor of class FourTubeIE
    """
    ie = FourTubeIE()
    assert ie._TKN_HOST.startswith('token.')
    assert ie._URL_TEMPLATE.endswith('/%s/video')
    assert ie._VALID_URL.startswith('https?://(?:(?P<kind>www|m)\.)?')

# Generated at 2022-06-24 12:21:38.144031
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    inst = PornTubeIE('https://www.porntube.com/videos/fuckme_7089759')
    assert inst.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-24 12:21:44.689080
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # A new instance of InfoExtractor should be created.
    ie = FourTubeIE()
    assert ie != None
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, FourTubeBaseIE)


# Generated at 2022-06-24 12:21:46.760687
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:21:54.363597
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = FuxIE()
    assert IE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert IE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert IE._TKN_HOST == 'token.fux.com'
    assert IE.IE_NAME == '4tube'
    assert IE.IE_DESC == '4tube.com, fux.com, porntube.com and pornerbros.com'

# Generated at 2022-06-24 12:21:57.705462
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    s = set()
    w = 0
    for i in range(2, 11):
        for j in range(i+1, 12):
            e = i * j
            if e in s:
                w += 1
            else:
                s.add(e)
    print(w)


# Generated at 2022-06-24 12:22:08.606668
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Unit test for constructor function of class FourTubeIE"""
    ie = FourTubeIE()
    # Assert that it is an instance of class InfoExtractor
    assert isinstance(ie, InfoExtractor)
    # Assert that the name of the IE is 4tube
    assert ie.IE_NAME == '4tube'
    # Assert that the name of the supported sites is 4tube.com
    assert ie.supported_sites == ['4tube.com']
    # Assert that the regex for url pattern is correct
    assert re.match(FourTubeIE._VALID_URL,
                    'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')



# Generated at 2022-06-24 12:22:10.191104
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:11.356447
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()



# Generated at 2022-06-24 12:22:14.894286
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fetch_video = FuxIE._real_extract(url)
    assert_equal(fetch_video['id'], '195359')


# Generated at 2022-06-24 12:22:17.436138
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:22:19.090056
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
	obj = FourTubeBaseIE(None)
	assert '4tube' in obj._TKN_HOST

# Generated at 2022-06-24 12:22:20.964579
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie= PornerBrosIE()
    assert pornerbros_ie


# Generated at 2022-06-24 12:22:29.965641
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTube=FourTubeIE()
    # Test of constructor
    assert FourTube.ie_key()=="4tube"
    assert FourTube.ie_url()=="4tube.com"
    assert FourTube._VALID_URL==r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTube._URL_TEMPLATE=='https://www.4tube.com/videos/%s/video'
    assert FourTube._TKN_HOST=='token.4tube.com'

# Generated at 2022-06-24 12:22:31.355603
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-24 12:22:32.331720
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pass

# Generated at 2022-06-24 12:22:33.301406
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:35.309317
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TESTS[0]['info_dict']['id'] == '181369'

# Generated at 2022-06-24 12:22:36.532994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except:
        assert False, "Impossible to create FourTubeIE instance"

# Generated at 2022-06-24 12:22:37.639775
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(_downloader=None)

# Generated at 2022-06-24 12:22:38.725043
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('http://www.porntube.com/videos/video_7089759')

# Generated at 2022-06-24 12:22:40.992734
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    infoExtractor = FourTubeBaseIE();
    assert infoExtractor.IE_NAME == "4tube"

# Generated at 2022-06-24 12:22:47.175094
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None)._TKN_HOST == 'token.4tube.com'
    assert FuxIE(None)._TKN_HOST == 'token.fux.com'
    assert PornTubeIE(None)._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:22:55.925788
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_PornTubeIE import create_instance
    from .test_PornTubeIE import init_instance
    from .test_PornTubeIE import test_params
    from .test_PornTubeIE import test_summary
    from .test_PornTubeIE import test_formats

    create_instance({})
    init_instance()
    test_params()
    test_summary()
    test_formats()

# Generated at 2022-06-24 12:22:56.957669
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(FourTubeBaseIE())

# Generated at 2022-06-24 12:23:00.849289
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()._real_extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-24 12:23:01.715764
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()

# Generated at 2022-06-24 12:23:02.513831
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE();


# Generated at 2022-06-24 12:23:10.431392
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Tests for constructor of class FourTubeBaseIE"""

    # Test for _extract_formats()
    def _extract_formats(self, url, video_id, media_id, sources):
        token_url = 'https://%s/%s/desktop/%s' % (
            self._TKN_HOST, media_id, '+'.join(sources))

        parsed_url = compat_urlparse.urlparse(url)
        tokens = self._download_json(token_url, video_id, data=b'', headers={
            'Origin': '%s://%s' % (parsed_url.scheme, parsed_url.hostname),
            'Referer': url,
        })

# Generated at 2022-06-24 12:23:12.072215
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert not obj is None


# Generated at 2022-06-24 12:23:13.129659
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:23:13.810687
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-24 12:23:26.225298
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    '''
    Simple unit test for constructor of class FourTubeIE.
    Nothing is gathered from the internet.
    '''
    from ydl.extractor.common import InfoExtractor
    from ydl.extractor.plaintext import PlaintextIE

    ie = InfoExtractor()
    ie.add_info_extractor(PlaintextIE.ie_key(), PlaintextIE)
    ie.add_info_extractor(FourTubeIE.ie_key(), FourTubeIE)

    result = ie.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

    assert(result['id'] == '209733')
    assert(result['ext'] == 'mp4')

# Generated at 2022-06-24 12:23:34.834134
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    testurl = "http://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    PornTubeIE._download_webpage = lambda self, url, video_id, data=None, headers=None: testurl
    pt = PornTubeIE()._real_initialize()
    assert pt.IE_NAME == "PornTube"
    assert pt._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pt._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-24 12:23:41.409923
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    with open('tests/test_data/porn_tube_embedded.html') as data:
        data = data.read()
        assert(PornTubeIE()._parse_json(
            PornTubeIE()._search_regex(
                r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
                data, 'data', group='value'), '181369',
            transform_source=lambda x: compat_urllib_parse_unquote(
                compat_b64decode(x).decode('utf-8')))['page']['video']['likes'] == 132)

# Generated at 2022-06-24 12:23:47.071586
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourtubebase = FourTubeBaseIE()
    # Test that get_video_info returns something.
    info = fourtubebase.get_video_info(r'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    print(info)
    assert info

# Generated at 2022-06-24 12:23:48.201547
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()



# Generated at 2022-06-24 12:23:49.357774
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    p = PornerBrosIE()
    assert p._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:23:51.269025
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE.ie_key() == 'Fux'

# Generated at 2022-06-24 12:23:53.082297
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/embed/181369')

# Generated at 2022-06-24 12:23:57.987625
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    _PornerBrosIE = PornerBrosIE()
    _FourTubeBaseIE = FourTubeBaseIE()
    assert _PornerBrosIE.__class__.__name__ == 'PornerBrosIE'
    assert _PornerBrosIE.__bases__[0].__name__ == 'FourTubeBaseIE'
    assert _FourTubeBaseIE.__class__.__name__ == 'FourTubeBaseIE'

# Generated at 2022-06-24 12:23:58.857566
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:23:59.896382
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:01.793436
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    m = PornerBrosIE()
    assert m.IE_NAME == '4tube'


# Generated at 2022-06-24 12:24:02.914586
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()



# Generated at 2022-06-24 12:24:05.760735
# Unit test for constructor of class FuxIE
def test_FuxIE():
    i = FuxIE()
    # make sure FuxIE has the correct _VALID_URL
    assert i._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:24:06.612598
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == 'PornHub'

# Generated at 2022-06-24 12:24:15.442218
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:17.697655
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-24 12:24:19.530914
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeIE()
    assert ie.__class__.__name__ == 'FourTubeIE'
    assert ie.IE_NAME == '4tube'

# First unit test, tests the normal behavior of the class

# Generated at 2022-06-24 12:24:20.640789
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    impressionlabs_ie = FourTubeIE()

# Generated at 2022-06-24 12:24:21.323684
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('test')

# Generated at 2022-06-24 12:24:26.439669
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Test that :class:`~.FourTubeBaseIE` and subclasses have a working constructor
    """
    import pytest

    with pytest.raises(TypeError):
        FourTubeBaseIE()

    with pytest.raises(TypeError):
        FourTubeBaseIE(None)

# Generated at 2022-06-24 12:24:27.094796
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:24:34.921363
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    unit_test = FourTubeBaseIE()

    assert unit_test.IE_NAME == '4tube'
    assert unit_test._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert unit_test._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert unit_test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:35.827106
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:24:39.928686
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()
    assert fourtube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:24:42.394287
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE("toto","tata","tutu")

# Generated at 2022-06-24 12:24:53.822384
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:24:55.033028
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constructor = FourTubeBaseIE()

# Generated at 2022-06-24 12:25:03.527773
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    if "PornTubeIE()" == "PornTubeIE()":
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTubeIE()
        ie = PornTube

# Generated at 2022-06-24 12:25:05.173772
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FuxIE()
    assert f.IE_NAME == '4tube'

# Generated at 2022-06-24 12:25:06.061726
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porn = PornerBrosIE()

# Generated at 2022-06-24 12:25:06.952409
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
        # Test an object
        PornerBrosIE()

# Generated at 2022-06-24 12:25:10.473833
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Arrange
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    
    # Act
    instance = PornTubeIE()
    # Assert
    assert instance._TESTS[0]['url'] == url


# Generated at 2022-06-24 12:25:12.251577
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert 'PornerBrosIE' == ie.ie_key()

# Generated at 2022-06-24 12:25:17.774360
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test class constructor."""
    ''' Test without fail. '''
    try:
        FourTubeBaseIE()
    except Exception as e:
        print(e)
    assert True
# End of test function


if __name__ == '__main__':
    from . import utils
    utils.run_tests(
        FourTubeBaseIE,
        FourTubeIE,
        FuxIE,
        PornTubeIE,
        PornerBrosIE
    )

# Generated at 2022-06-24 12:25:19.488496
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBros', 'MD5_CHECKSUM')

# Generated at 2022-06-24 12:25:20.663515
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-24 12:25:31.490846
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeBaseIE()
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('kind') == 'www'
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    assert (kind == 'www') and (video_id == '209733') and (display_id is None)
    # print("\nFourTubeBaseIE:")
    # print("\n")
    # print("\n")
    # print("\n")

# Generated at 2022-06-24 12:25:33.596612
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE("http://www.fux.com/")
    print("FuxIE Test:" + ie.getId() )

# Generated at 2022-06-24 12:25:34.285605
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE

# Generated at 2022-06-24 12:25:45.346666
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE()

    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(inst._VALID_URL, url)
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')

    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(inst._VALID_URL, url)
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')


# Generated at 2022-06-24 12:25:50.505249
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TESTS[0] == FourTubeIE._TESTS[0]
    assert FourTubeBaseIE._TESTS[0] == FuxIE._TESTS[0]
    assert FourTubeBaseIE._TESTS[0] == PornTubeIE._TESTS[0]
    assert FourTubeBaseIE._TESTS[0] == PornerBrosIE._TESTS[0]

# Generated at 2022-06-24 12:25:52.460848
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Just call constructor to test it
    PornerBrosIE()

# Generated at 2022-06-24 12:25:57.304282
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import utils_test
    info_tests = utils_test.get_testcases_from_module(utils_test, 'test_FuxIE')

    # Test standard initialization
    FuxIE()

    # Test initialization, passing url
    FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

    # Test initialization passing url from `info_tests`
    FuxIE(info_tests[0]['url'])

# Generated at 2022-06-24 12:25:58.873001
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .fux import FuxIE
    FuxIE.__module__ = 'youtube_dl.extractor.fux'
    FuxIE()

# Generated at 2022-06-24 12:25:59.649537
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:26:03.495076
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert (FourTubeBaseIE._TKN_HOST == 'token.pornerbros.com')
    assert (FourTubeBaseIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s')

# Generated at 2022-06-24 12:26:11.982729
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test constructor of class FourTubeIE
    obj = FourTubeIE()
    assert obj.ie_key() == '4tube'
    # Test method ie_key() of class FourTubeIE
    assert obj.ie_key() == '4tube'
    # Test method _real_extract() of class FourTubeIE
    assert set(obj._real_extract("")['categories']).issubset(set(['Babe', 'Brunette', 'Butt', 'Cumshot', 'Interracial', 'Milf', 'Oil', 'Pussy', 'Teen']))
    assert obj._real_extract("")['title'] == "Hot Babe Holly Michaels gets her ass stuffed by black"
    assert obj._real_extract("")['uploader'] == 'WCP Club'


# Generated at 2022-06-24 12:26:17.095739
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    IE = FuxIE()
    IE.test_test = True
    IE.test(url)
    ('test_test' in dir(IE))
    ('test_test' in dir(FuxIE))