

# Generated at 2022-06-24 12:16:26.672138
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import unittest.mock as mock
    from ytdl.extractor.fourtube import FourTubeIE

    if not mock:
        pass
    else:
        # Tests failed if 'mock' didn't defined 
        # (because of dependency on 'mock' in '2to3')
        # and 'mock' existed in Python 3.
        with mock.patch('ytdl.extractor.fourtube.compat_b64decode') as b64decode:
            # Test constructor of class FourTubeIE
            test_ie = FourTubeIE(downloader=None)

            # Check calls of method b64decode for parameters
            # that passed to constructor.

# Generated at 2022-06-24 12:16:27.240516
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:16:28.211452
# Unit test for constructor of class FuxIE
def test_FuxIE():
	fuxIE = FuxIE()

# Generated at 2022-06-24 12:16:33.027845
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == None
    assert ie._URL_TEMPLATE == None
    assert ie._TKN_HOST == None
    assert ie._TESTS == []


__all__ = [
    FourTubeIE.__name__,
    FuxIE.__name__,
    PornTubeIE.__name__,
    PornerBrosIE.__name__,
    test_FourTubeBaseIE.__name__,
]

# Generated at 2022-06-24 12:16:38.488643
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    tmp_setattr = FourTubeIE.__bases__[0].__dict__['_search_regex']

    def _mock_search_regex(webpage, pattern, name, default=NoDefault, fatal=True, flags=0, group=None):
        return 'token.4tube.com'

    # Set _search_regex to the mock value
    FourTubeIE.__bases__[0].__dict__['_search_regex'] = _mock_search_regex

    # Instantiate object
    try:
        ie = FourTubeIE()
    finally:
        # Restore _search_regex to original value
        FourTubeIE.__bases__[0].__dict__['_search_regex'] = tmp_setattr


# Generated at 2022-06-24 12:16:39.519899
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE is not None

# Generated at 2022-06-24 12:16:40.509089
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()



# Generated at 2022-06-24 12:16:41.495179
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(None)

# Generated at 2022-06-24 12:16:43.468613
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_ie = FourTubeIE()
    assert four_tube_ie.ie_name.__eq__("4tube")

# Generated at 2022-06-24 12:16:45.388509
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie = FuxIE()
    ie = PornTubeIE()
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:16:51.832945
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """ Test constructor method of class FuxIE """

    ie = FuxIE()

    # Check if class constant _VALID_URL has been initialized
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:16:55.918442
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie._TESTS is None
    assert ie.IE_NAME is None
    assert ie._VALID_URL is None
    assert ie._URL_TEMPLATE is None
    assert ie._TKN_HOST is None

# Generated at 2022-06-24 12:17:02.272532
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_videos_generic import TestVideosGeneric
    return TestVideosGeneric.test_constructor(
        lambda url: PornerBrosIE()._extract_formats(url, '181369', '181369', ['360', '720']),
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:17:03.617847
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert x is not None

# Generated at 2022-06-24 12:17:05.438581
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # this is empty on purpose
    fourTubeBaseIE = FourTubeBaseIE('a', 'b', 'c')

# Generated at 2022-06-24 12:17:16.178107
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import pornhub
    ph = pornhub.PornHub('http://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert 'video' in ph.parse()
    assert 'title' in ph.parse()['video']
    assert 'videos' in ph.parse()['video']['title']
    assert 'fetching' in ph.parse()['video']['title']['videos']
    assert 'format' in ph.parse()['video']['title']['videos']['fetching']
    assert 'MP4' in ph.parse()['video']['title']['videos']['fetching']['format']

# Generated at 2022-06-24 12:17:17.252993
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(FourTubeIE.ie_key())

# Generated at 2022-06-24 12:17:18.877115
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # pylint: disable=too-many-function-args
    FourTubeBaseIE({})

# Generated at 2022-06-24 12:17:22.464053
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj_FuxIE = FuxIE()

# Generated at 2022-06-24 12:17:23.309098
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Should not raise any exception
    FourTubeBaseIE()

# Generated at 2022-06-24 12:17:32.725479
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    # Invalid URL
    with pytest.raises(ExtractorError) as excinfo:
        FourTubeBaseIE._validate_url('http://www.4tube.com/embed/209')
    assert str(excinfo.value) == 'Invalid URL: http://www.4tube.com/embed/209'

    # Invalid URL
    with pytest.raises(ExtractorError) as excinfo:
        FourTubeBaseIE._validate_url('http://www.fux.com/video/209')
    assert str(excinfo.value) == 'Invalid URL: http://www.fux.com/video/209'

    # Invalid URL
    with pytest.raises(ExtractorError) as excinfo:
        FourTubeBaseIE._validate_url('http://www.porntube.com/video/209')
   

# Generated at 2022-06-24 12:17:34.505415
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():

	assert(PornerBrosIE._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-24 12:17:41.201314
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_cases = [
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'https://www.porntube.com/embed/7089759',
        'https://m.porntube.com/videos/teen-couple-doing-anal_7089759',
    ]
    for url in test_cases:
        assert PornTubeIE._VALID_URL == PornTubeIE._VALID_URL_TEMPLATE % 'porntube', \
            'Expected valid url regexp and found regexp does not match'

# Generated at 2022-06-24 12:17:43.320457
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    # This code will run when the doctest is run
    test_FourTubeIE()

# Generated at 2022-06-24 12:17:44.626209
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-24 12:17:55.803031
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:

        # load class
        instance = FourTubeIE()

        assert(instance is not None)

        # test this method
        media_id = instance._search_regex("""
        <button class="btn-view-quality" data-id="%s" data-quality="720p">720p</button>
    """, "123456", "media id")

        assert(media_id == "123456")

        # test this method
        params = instance._parse_json("[1234,%s]", "test-id", transform_source=lambda x: x+"1")

        assert(params == [1234, "test-id1"])

    except Exception as e:
        assert(False)

    assert(True)

# Generated at 2022-06-24 12:18:02.891035
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    def test_constructor_empty_url(url):
        if verbose: print('Testing empty URL constructor ...')
        try:
            FourTubeIE(url)
        except AssertionError:
            if verbose: print('Passed.')
        else:
            print('Failed!')

    test_constructor_empty_url(None)
    test_constructor_empty_url('')
    test_constructor_empty_url('  ')

if __name__ == '__main__':
    verbose = False
    try:
        test_FourTubeIE()
    except NameError:
        pass

# Generated at 2022-06-24 12:18:04.535917
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    InfoExtractor.test()


# Generated at 2022-06-24 12:18:05.883324
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE({})
    assert ie.IE_NAME == "4tube"

# Generated at 2022-06-24 12:18:06.900850
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:18:10.819859
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert instance._TKN_HOST == 'token.4tube.com'
    assert instance._URL_TEMPLATE % 'some_video_id' == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-24 12:18:13.603853
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	ie = FourTubeIE()

# Generated at 2022-06-24 12:18:20.128944
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Functionality
    # -------------
    # 1. Should create an instance with correct parameters.
    # 2. Should have correct properties.
    #   1. should have correct _VALID_URL
    #   2. should have correct IE_NAME
    #   3. should have correct _NETRC_MACHINE
    #   4. should have correct _TEST
    #   5. should have correct _TKN_HOST
    #   6. should have correct _URL_TEMPLATE
    # 3. Should have correct methods and attributes.
    #   2. should have method _real_extract()

    # assertion
    ie = FourTubeIE()

    # 1. Should create an instance with correct parameters.

# Generated at 2022-06-24 12:18:22.122791
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE("m.4tube.com")
        FourTubeIE("www.4tube.com")
    except Exception as e:
        print("Error: "+str(e))
        raise e


# Generated at 2022-06-24 12:18:23.853589
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    return PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:18:24.681983
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-24 12:18:36.918627
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    cls = PornerBrosIE
    valid_url = cls._VALID_URL
    video_id = "181369"
    display_id = "skinny-brunette-takes-big-cock-down-her-anal-hole"

    mobj = re.match(valid_url, cls._URL_TEMPLATE % video_id)
    if not mobj:
        print("Error getting mobj")
    kind = mobj.group('kind')
    if not kind:
        print("Error getting kind")

    if( kind == 'm' or not display_id ):
        url = cls._URL_TEMPLATE % video_id
    if not url:
        print("Error getting url")

    display_id = video_id


# Generated at 2022-06-24 12:18:39.193016
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    print ("***Testing PornTubeIE constructor***\n")
    x=PornTubeIE()
    print(x.IE_NAME)




# Generated at 2022-06-24 12:18:43.454872
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    mobj = re.match(PornTubeIE._VALID_URL, 'https://www.porntube.com/videos/122_1223')
    res = PornTubeIE._URL_TEMPLATE % mobj.group('id')
    assert(res == 'https://www.porntube.com/videos/video_1223')

# Generated at 2022-06-24 12:18:43.909656
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:18:45.278463
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # https://github.com/ytdl-org/youtube-dl/issues/5647
    pornerbros = PornerBrosIE()

# Generated at 2022-06-24 12:18:50.931125
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    assert isinstance(obj, PornTubeIE)
    assert isinstance(obj, FourTubeBaseIE)
    assert isinstance(obj, InfoExtractor)



# Generated at 2022-06-24 12:18:59.414188
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """extract video info from porntube.com"""
    # test following video:
    # https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369
    url_video = 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ydl_opts = {}
    with YoutubeDL(ydl_opts) as ydl:
        result = ydl.extract_info(url_video, download=False)

# Generated at 2022-06-24 12:19:08.276599
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()

    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:19:10.531177
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    IE = PornerBrosIE()
    assert(IE.IE_NAME == 'pornerbros')

# Generated at 2022-06-24 12:19:11.935117
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert isinstance(PornerBrosIE, type(FourTubeBaseIE))
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:19:13.119343
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-24 12:19:13.681416
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:19:16.584381
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest
    from DLStats import FuxIE

    IE = FuxIE(unittest.TestCase) # noqa: F841

# Generated at 2022-06-24 12:19:22.020212
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import os
    import json
    from ..utils import load_json
    from ..compat import compat_b64decode

    # Test _real_extract() of PornerBrosIE
    def test_real_extract(url, expected_id, expected_title, expected_uploader, expected_duration, expected_formats):

        # Download webpage corresponding to url
        webpage = self._download_webpage(url, video_id)


# Generated at 2022-06-24 12:19:23.289257
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance is not None
    assert isinstance(instance, PornerBrosIE)



# Generated at 2022-06-24 12:19:25.104935
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_downloader import TestDownloader

    host = 'www.porntube.com'
    ie = PornTubeIE(TestDownloader())
    ie = PornTubeIE(TestDownloader(), host)
    assert ie.host == host

# Generated at 2022-06-24 12:19:26.486523
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test for instantiating a class
    FourTubeIE()

# Generated at 2022-06-24 12:19:28.685056
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test import get_testcases
    from .common import merge_dicts
    return merge_dicts(*[get_testcases(PornTubeIE, test) for test in [
        PornTubeIE._TESTS[0],
        PornTubeIE._TESTS[1]]])


# Generated at 2022-06-24 12:19:37.925129
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for t in (FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE):
        assert t.__name__
        assert t.IE_NAME
        assert t.IE_DESC
        assert t._VALID_URL
        assert t._TKN_HOST
        assert hasattr(t, '_download_webpage')
        assert hasattr(t, '_search_regex')
        assert hasattr(t, '_parse_json')
        assert hasattr(t, '_html_search_meta')
        assert hasattr(t, '_extract_formats')
        assert hasattr(t, '_real_extract')
        assert hasattr(t, '_VALID_URL')
        assert hasattr(t, '_TESTS')



# Generated at 2022-06-24 12:19:40.869775
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    PornTubeIE._download_webpage(url,'test')

# Generated at 2022-06-24 12:19:41.975382
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()

# Generated at 2022-06-24 12:19:52.762231
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import unittest
    from pytube3 import YouTube

    class TestPornTubeIE(unittest.TestCase):
        def setUp(self):
            self.youtube = YouTube("http://www.porntube.com/videos/teen-couple-doing-anal_7089759")

        def test_title(self):
            self.assertEqual(self.youtube.title, 'Teen couple doing anal')

        def test_rating(self):
            self.assertEqual(self.youtube.rating, 5.0)

        def test_length(self):
            self.assertEqual(self.youtube.length, 5052)

        def test_views(self):
            self.assertEqual(self.youtube.views, 1330)


# Generated at 2022-06-24 12:19:53.814562
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE() != None


# Generated at 2022-06-24 12:20:01.038252
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Unit test for constructor of class FuxIE"""
    youtube_ie = FuxIE()
    # pylint: disable=protected-access
    assert youtube_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert youtube_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert youtube_ie._TKN_HOST == 'token.fux.com'
    # pylint: enable=protected-access

# Generated at 2022-06-24 12:20:10.638460
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie._VALID_URL == None
    assert ie._URL_TEMPLATE == None
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:13.467530
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
    except Exception as e:
        assert False, "Unit test for the constructor of class FuxIE has failed."

# Generated at 2022-06-24 12:20:17.473129
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    print("Testing PornTubeIE")
    from . import PornTubeIE
    PornTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    print("Testing OK")

# Generated at 2022-06-24 12:20:22.217493
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie != None

# Generated at 2022-06-24 12:20:25.793228
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    if PornerBrosIE.__name__ != 'PornerBrosIE':
        print('PornerBrosIE.__name__ is not "PornerBrosIE".')
        return False
    return True

# Generated at 2022-06-24 12:20:29.317616
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ..test import get_testcases

    # get_testcases() returns a dict of test function name and test cases
    for test_func_name, test_cases in get_testcases(PornTubeIE).items():
        for t in test_cases:
            t['url']

# Generated at 2022-06-24 12:20:32.092133
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:20:35.449861
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:20:37.344254
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    compatibility_check(PornerBrosIE, FourTubeIE)

# Generated at 2022-06-24 12:20:38.893475
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert instance is not None

# Generated at 2022-06-24 12:20:47.638767
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test for correct creation of an instance with all names supplied
    assert_raises(AttributeError, FourTubeBaseIE)
    ie = FourTubeBaseIE(None)
    assert isinstance(ie, InfoExtractor)

    # Test for correct creation of an instance with only required names supplied
    assert_raises(AttributeError, FourTubeBaseIE, None, None, None, None)

    ie = FourTubeBaseIE(None, None, '4tube', None)
    assert isinstance(ie, InfoExtractor)

    # Test for correct creation of an instance with no names supplied
    assert_raises(AttributeError, FourTubeBaseIE, None, None, None, None)

# Generated at 2022-06-24 12:20:49.686975
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.report_warning('test warning')
    

# Generated at 2022-06-24 12:21:01.673696
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_id = PornerBrosIE._TESTS[0]['info_dict']['id']
    stream_url = 'http://%s/%s/desktop/%s' % (PornerBrosIE._TKN_HOST, test_id, '480.mp4')
    stream_tokens = PornerBrosIE._download_json(stream_url, test_id, data=b'', headers={
            'Origin': 'https://www.pornerbros.com',
            'Referer': 'https://www.pornerbros.com/embed/%s' % test_id,
        })
    video_url = stream_tokens['480.mp4']['token']

# Generated at 2022-06-24 12:21:02.676997
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:21:05.320169
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TKN_HOST')
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-24 12:21:08.270945
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL
    assert hasattr(ie, '_url_for_video')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:21:09.275847
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-24 12:21:11.445715
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    newIE = PornTubeIE()
    assert newIE.IE_NAME == '4tube'

# Generated at 2022-06-24 12:21:16.361668
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for kind in ['4tube', 'fux', 'porntube', 'pornerbros']:
        ie = globals()[str(kind).title() + 'IE']
        assert ie._VALID_URL
        assert ie._TKN_HOST
        assert ie._TESTS

# Generated at 2022-06-24 12:21:19.237272
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_class_test_obj = PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-24 12:21:19.881441
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:21:26.681991
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    # test assert no fail
    assert ie != None
    assert ie._TESTS != None

# Generated at 2022-06-24 12:21:37.572472
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import sys
    from io import StringIO
    from ytdl.extractor.porn import PornTubeIE

    video_id, display_id = '1331406', 'xxx'
    url = 'https://www.porntube.com/videos/xxx_1331406'

    # Test that we get "initialization parameters" from "player JS"
    def _download_webpage(url, *args, **kwargs):
        assert url.endswith('/assets/js/porntube.video.js')
        return '''
            ...<$>...
            ...</$>...
            $.ajax(url, opts);   // <= This is the string we are looking for!
            ...
            ...
        '''.strip()

    # Test that we get "data" from "initialization parameters"

# Generated at 2022-06-24 12:21:40.954654
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')


# Generated at 2022-06-24 12:21:46.776557
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert FourTubeBaseIE._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert FourTubeBaseIE._TESTS[0]['info_dict']['id'] == '209733'
    assert FourTubeBaseIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert FourTubeBaseIE._TESTS[0]['info_dict']['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert FourTubeBaseIE

# Generated at 2022-06-24 12:21:48.600274
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    InfoExtractor('FourTubeIE', 'http://www.test.test')

# Generated at 2022-06-24 12:21:49.168450
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:21:53.769020
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/embed/7089759'
    ie = PornTubeIE(None)
    import pdb; pdb.set_trace()
    mobj = re.match(ie._VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')
    assert ie._download_webpage(url, display_id)

# Generated at 2022-06-24 12:21:59.513203
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornTubeClass = PornTubeIE()
    assert pornTubeClass._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornTubeClass._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pornTubeClass._TKN_HOST == 'tkn.porntube.com'
    assert pornTubeClass.IE_NAME == 'PornTube'

# Generated at 2022-06-24 12:22:10.778775
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        class testPornerBrosIE(FourTubeBaseIE):
            IE_NAME = 'pornerbros'
            _VALID_URL=r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
            _URL_TEMPLATE='https://www.pornerbros.com/videos/video_%s'
            _TKN_HOST='token.pornerbros.com'
        test = testPornerBrosIE()
        print("test_PornerBrosIE instance created")
    except:
        print("test_PornerBrosIE instance creating error")
        raise

# Generated at 2022-06-24 12:22:17.639393
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video = PornTubeIE()
    video._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    video._URL_TEMPLATE = 'https://www.porntube.com/videos/video_%s'
    video._TKN_HOST = 'tkn.porntube.com'

# Generated at 2022-06-24 12:22:18.905556
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-24 12:22:19.579212
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-24 12:22:20.147990
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()

# Generated at 2022-06-24 12:22:25.294727
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.suitable("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    ie.suitable("https://www.fux.com/embed/195359")
    ie.get_url("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")


# Generated at 2022-06-24 12:22:38.797722
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None, 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:22:41.745367
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE(downloader=None)
    assert fux_ie.IE_NAME == '4tube'


# Generated at 2022-06-24 12:22:52.164215
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test the constructor
    assert(PornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')

# Generated at 2022-06-24 12:22:59.905765
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE is not None
    # test _VALID_URL
    assert PornerBrosIE._VALID_URL is not None
    # test _URL_TEMPLATE
    assert PornerBrosIE._URL_TEMPLATE is not None
    # test _TKN_HOST
    assert PornerBrosIE._TKN_HOST is not None
    # test _TESTS
    assert PornerBrosIE._TESTS is not None

# Generated at 2022-06-24 12:23:08.325132
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    tmp_obj = PornerBrosIE()
    original_obj = FourTubeBaseIE()
    assert tmp_obj.IE_NAME == original_obj.IE_NAME
    assert tmp_obj._VALID_URL == original_obj._VALID_URL
    assert tmp_obj._URL_TEMPLATE == original_obj._URL_TEMPLATE
    assert tmp_obj._TKN_HOST == original_obj._TKN_HOST
    assert tmp_obj._TESTS == original_obj._TESTS

# Generated at 2022-06-24 12:23:20.275029
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    print("\n====== Unit tests for PornTubeIE ======")
    print("\nTest #1: Run a simple youtube data extraction."
        + "Should be successful.\n")
    url = "https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406"

# Generated at 2022-06-24 12:23:21.716010
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:23:32.838572
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')
    url = PornerBrosIE._URL_TEMPLATE % video_id
    web_page = PornerBrosIE._download_webpage(PornerBrosIE(), url, display_id)

# Generated at 2022-06-24 12:23:35.942913
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = FuxIE(url)
    assert ie.ie_key() == 'Fux'

# Generated at 2022-06-24 12:23:42.952605
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    data = 'INITIALSTATE="ZjQ3N2M0ZTQxN2Q0ZmE0MjQ1MDBjOWUyYmU0YTUyYzU=";'

# Generated at 2022-06-24 12:23:48.649712
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Initializing object without any arguments
    fourTubeBase = FourTubeBaseIE()
    # Checking arguments of the object
    if not (fourTubeBase._VALID_URL == ''
            and fourTubeBase._URL_TEMPLATE == ''
            and fourTubeBase._TKN_HOST == ''):
        raise AssertionError('Wrong arguments of object.')



# Generated at 2022-06-24 12:23:55.782324
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # no age limit => no age restrictions
    assert PornTubeIE(PornTubeIE.IE_NAME, None)
    assert PornTubeIE(PornTubeIE.IE_NAME, {}).age_limit == 0
    assert PornTubeIE(PornTubeIE.IE_NAME, {'age_limit': 0}).age_limit == 0
    assert PornTubeIE(PornTubeIE.IE_NAME, {'age_limit': 18}).age_limit == 18
    assert PornTubeIE(PornTubeIE.IE_NAME, {'age_limit': 80}).age_limit == 80

# Generated at 2022-06-24 12:24:05.741021
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Test construction of class FourTubeIE."""
    instance = FourTubeIE()
    expected_instance_name = 'FourTubeIE'
    expected_supported_qualities = ['720p', '480p']
    expected_patterns = [
        r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?']
    assert isinstance(instance, InfoExtractor)
    assert instance.ie_key() == expected_instance_name
    assert instance._VALID_URL == '|'.join(expected_patterns)
    assert instance._supported_qualities == expected_supported_qualities

# Generated at 2022-06-24 12:24:07.093885
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_class = PornerBrosIE()
    assert test_class is not None

# Generated at 2022-06-24 12:24:12.341194
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import types

    # Both PornTubeIE and PornerBrosIE are the subclasses of FourTubeBaseIE
    assert issubclass(FourTubeIE, FourTubeBaseIE) and issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE) and issubclass(PornerBrosIE, FourTubeBaseIE)

    # Test class members:
    assert hasattr(FourTubeBaseIE, '_VALID_URL') and isinstance(FourTubeBaseIE._VALID_URL, compat_str)
    assert hasattr(FourTubeBaseIE, '_URL_TEMPLATE') and isinstance(FourTubeBaseIE._URL_TEMPLATE, compat_str)

# Generated at 2022-06-24 12:24:14.922021
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    c = FourTubeIE();
    c._TESTS;

# Generated at 2022-06-24 12:24:16.875909
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # create an instance of class PornTubeIE as 'ie_instance'
    ie_instance = PornTubeIE()
    assert ie_instance is not None

# Generated at 2022-06-24 12:24:28.144793
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # pylint: disable=protected-access
    class_ = PornerBrosIE()

# Generated at 2022-06-24 12:24:28.829132
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:24:32.385892
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # we need to check wheather PornTubeIE is constructed with FourTubeBaseIE
    if not issubclass(PornTubeIE, FourTubeBaseIE):
        raise ValueError('PornTubeIE is not a subclass of FourTubeBaseIE')



# Generated at 2022-06-24 12:24:34.061248
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE()
    assert instance.IE_NAME == '4tube'

# Generated at 2022-06-24 12:24:34.961258
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE({})
    assert ie != None

# Generated at 2022-06-24 12:24:36.606183
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:24:45.035154
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    (SOME_ID, SOME_PLAYER_JS) = ('some_id', 'some_player_js')
    (SOME_URL, SOME_URL_TEMPLATE, SOME_TKN_HOST) = ('some_url', 'some_url_template', 'some_tkn_host')
    # Instantiate object without (or with default) arguments
    pb = PornerBrosIE()
    assert (pb._URL_TEMPLATE, pb._TKN_HOST) == (pb.IE_NAME + ':' + PornerBrosIE._URL_TEMPLATE, pb.IE_NAME + ':' + PornerBrosIE._TKN_HOST)

# Generated at 2022-06-24 12:24:48.090392
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.extract(ie._VALID_URL)
    ie.extract(ie._URL_TEMPLATE % '1213044')

# Generated at 2022-06-24 12:24:49.114146
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:24:50.033861
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:24:58.854686
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    # check screen_ie
    screen_ie = FuxIE(url)
    # check extract_formats
    formats = screen_ie._extract_formats(url=url, video_id=screen_ie._VALID_URL, media_id=195359, sources=['720'])
    # check sort_formats
    screen_ie._sort_formats(formats=formats)
    # check extract video
    video = screen_ie._real_extract(url=url)

# Generated at 2022-06-24 12:25:02.587751
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:25:06.558522
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'http://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    obj = PornTubeIE(info_dict={'id' : '7089759'})
    assert obj._real_extract(url) == '7089759'

# Generated at 2022-06-24 12:25:07.433261
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test = FourTubeIE()

# Generated at 2022-06-24 12:25:09.688522
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    exist = False
    for ie in gen_extractors():
        if isinstance(ie, FourTubeBaseIE):
            exist = True
    assert exist

# Generated at 2022-06-24 12:25:12.266835
# Unit test for constructor of class FuxIE
def test_FuxIE():
    global FuxIE
    info_extractor = FuxIE()
    assert info_extractor is not None


# Generated at 2022-06-24 12:25:18.247968
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test for constructor
    obj = PornerBrosIE()
    assert obj._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert obj._TKN_HOST == 'token.pornerbros.com'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'



# Generated at 2022-06-24 12:25:18.885599
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:25:26.679687
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == 'fux'
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:25:33.143692
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print("Function: construct FuxIE")
    ie = FuxIE()
    ie.IE_NAME = 'custom name'
    ie.IE_DESC = 'custom description'
    ie.constructor = 'custom_constructor'
    print("Built-in name: " + str(ie.IE_NAME))
    print("Built-in description: " + str(ie.IE_DESC))
    print("Built-in constructor: " + str(ie.constructor))

# Generated at 2022-06-24 12:25:34.983164
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(object())
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:25:44.907736
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from django.conf import settings
    settings.configure(DEBUG=True)

    import os
    import dir_pub

    print(dir(dir_pub))
    print(dir_pub.__file__)
    print(os.getcwd())

    print('Test for FourTubeIE')
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    result = FourTubeIE()._extract_formats(url, '587', '587', ['480', '720'])
    print(result)


if __name__ == "__main__":
    test_FourTubeIE()

# Generated at 2022-06-24 12:25:54.481135
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test the input and the output of constructor of class FourTubeBaseIE"""

    testobj = FourTubeBaseIE()

    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    mobj = re.match(r'https?://(?:www\.)?([^\.]+)\.com', url)
    assert mobj is not None

    URL = 'https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'
    VALID_URL = 'https?://(?:www\.)?([^\.]+)\.com/.*'

# Generated at 2022-06-24 12:26:00.559590
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black",
                     "abracadabra")
    assert(obj is not None)

if __name__ == "__main__":
    test_FourTubeIE()
    print("End unit test")

# Generated at 2022-06-24 12:26:03.970156
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-24 12:26:14.906082
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    url = fux._TESTS[0]['url']
    video = fux.url_result(url, video_id='test_video')
    video.download()
    video.download('.mp4')
    video.download(downloader=None)
    video.download(downloader=None, ext='.mp4')
    video.download(ext='.mp4')
    video.download(format_spec='test_format')
    video.download(format_spec='test_format', ext='.mp4')
    video.download(format_spec='test_format', ext='.mp4', downloader=None)
    video.download(format_spec='test_format', downloader=None)