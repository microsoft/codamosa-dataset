

# Generated at 2022-06-24 12:16:24.746106
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Programmer-defined attributes
    VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    TKN_HOST = 'token.fux.com'

    # Unit test for constructor of class FuxIE
    fourTubeBaseIE = FourTubeBaseIE("FuxIE", "fux", VALID_URL, URL_TEMPLATE, TKN_HOST)
    assert fourTubeBaseIE._TESTS

# Generated at 2022-06-24 12:16:27.589139
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()
    assert fourTubeBaseIE._VALID_URL is not None
    assert fourTubeBaseIE._TESTS is not None
    assert fourTubeBaseIE.IE_NAME is not None

# Generated at 2022-06-24 12:16:35.229513
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    # test case : test constructor of class PornTubeIE
    assert instance._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert instance._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert instance._TESTS[0]['info_dict']['id'] == '7089759'
    assert instance._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert instance._TESTS[0]['info_dict']['title'] == 'Teen couple doing anal'

# Generated at 2022-06-24 12:16:39.197005
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:16:44.701360
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._TKN_HOST == 'token.4tube.com'
    obj = FuxIE()
    assert obj._TKN_HOST == 'token.fux.com'
    obj = PornTubeIE()
    assert obj._TKN_HOST == 'tkn.porntube.com'
    obj = PornerBrosIE()
    assert obj._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:16:53.497644
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:16:55.664402
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourtubeIE = FourTubeIE()
    FourtubeIE = FourTubeIE()
    assert FourtubeIE

# Generated at 2022-06-24 12:16:58.344197
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_PornTubeIE import PornTubeIETest
    # Testing the selftest overwrites the expected output with the actual
    # output. To avoid this behavior, we create a new test object instead of
    # calling test_PornTubeIE().
    PornTubeIETest('test_constructor', PornTubeIE).runTest()

# Generated at 2022-06-24 12:16:59.615162
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube = PornTubeIE()
    return

# Generated at 2022-06-24 12:17:00.694081
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE()
    assert inst is not None

# Generated at 2022-06-24 12:17:05.126774
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL is not None
    assert ie._TKN_HOST is not None
    assert ie._URL_TEMPLATE is not None
    assert ie._TESTS is not None
    assert ie._TEST is None
    assert ie._TEST_CASES is None



# Generated at 2022-06-24 12:17:15.901361
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Unit test for constructor of class FuxIE
    """
    # Test: Standard URL
    FuxIE(FuxIE._VALID_URL)
    # Test: URL with kind = m
    FuxIE("https://m.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    # Test: URL without display_id
    FuxIE("http://www.fux.com/videos/195359")
    # Test: URL without display_id and kind = m
    FuxIE("http://m.fux.com/videos/195359")
    # Test: URL with display_id and kind = m
    FuxIE("https://m.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow")


# Generated at 2022-06-24 12:17:17.305286
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    IE = PornerBrosIE()
    assert IE is not None

# Generated at 2022-06-24 12:17:31.182726
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    a = FourTubeIE()
    assert a._TKN_HOST == 'token.4tube.com'
    assert a._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert a._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:17:34.638577
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')



# Generated at 2022-06-24 12:17:39.718568
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    catalog_url = 'http://porntube.com/catalog/26'
    fields = {'age_limit': 18, 'referer': 'http://www.porntube.com/'}
    display_id = PornTubeIE._match_id(catalog_url)
    ne = PornTubeIE()
    ne._get_video_url(display_id, catalog_url, fields)
    dir(ne)

# Generated at 2022-06-24 12:17:41.311080
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE(None)
    assert pornerBrosIE


# Generated at 2022-06-24 12:17:48.425310
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_cases = (
        (FourTubeIE, r'https://www.4tube.com/embed/209733'),
        (PornTubeIE, r'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'),
        (FuxIE, r'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'),
        (PornerBrosIE, r'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    )
    for cls, url in test_cases:
        cls._VALID_URL.format(url)

# Generated at 2022-06-24 12:17:50.268186
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:18:01.755000
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:18:11.131335
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:18:18.665718
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/embed/7089759'
    i = PornTubeIE()._real_extract(url)
    assert i['id'] == '7089759'
    assert i['title'] == 'Teen couple doing anal'
    assert i['uploader'] == 'Alexy'
    assert i['uploader_id'] == '91488'
    assert i['upload_date'] == '20150606'
    assert i['timestamp'] == 1433595647
    assert i['duration'] == 5052
    assert i['view_count'] == int
    assert i['like_count'] == int
    assert i['dislike_count'] == None
    assert i['age_limit'] == 18
    assert i['tags'] == None
    assert i['categories'] == list

# Generated at 2022-06-24 12:18:22.362045
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import unittest
    from dl_youtube__core.dl_youtube__extractor import FourTubeIE

    class FourTubeIETest(unittest.TestCase):
        def test_case1(self):
            self.assertIn(
                'fourtube',
                FourTubeIE._WORKING.get('www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', {}).keys())

    unittest.main()

# Generated at 2022-06-24 12:18:29.735308
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test invalid data cases
    with pytest.raises(RegexNotFoundError):
        assert FourTubeBaseIE._VALID_URL is not None
    with pytest.raises(RegexNotFoundError):
        assert FourTubeBaseIE._URL_TEMPLATE is not None
    with pytest.raises(RegexNotFoundError):
        assert FourTubeBaseIE._TKN_HOST is not None

# Generated at 2022-06-24 12:18:31.439310
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._TKN_HOST == None

# Generated at 2022-06-24 12:18:34.574137
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE._extract_formats('http://www.porntube.com/embed/7089759', '7089759', 'some_media_id', ['720'])

# Generated at 2022-06-24 12:18:40.891176
# Unit test for constructor of class FuxIE
def test_FuxIE():
    #pylint: disable=line-too-long
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    class_obj = FuxIE(url, None) #pylint: disable=abstract-class-instantiated
    assert class_obj._TKN_HOST == 'token.fux.com'
    #pylint: enable=line-too-long



# Generated at 2022-06-24 12:18:41.339527
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:18:43.299089
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST.endswith('token.4tube.com')
    assert FourTubeIE()._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-24 12:18:45.043031
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube = PornTubeIE()
    porn_tube.extract(
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-24 12:18:45.894877
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    d = FourTubeIE()
    assert isinstance(d, FourTubeIE)

# Generated at 2022-06-24 12:18:46.339605
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-24 12:18:57.797912
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor = FourTubeBaseIE()
    assert info_extractor.TESTS == []
    assert hasattr(info_extractor, '_VALID_URL')
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert hasattr(info_extractor, '_TESTS')
    assert info_extractor._TESTS == []
    assert hasattr(info_extractor, 'IE_NAME')
    assert info_extractor.IE_NAME == '4tube'
    assert hasattr(info_extractor, '_TKN_HOST')

# Generated at 2022-06-24 12:19:00.913302
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test = FourTubeIE()
    assert test._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video"
    assert test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:19:02.709650
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert isinstance(FourTubeBaseIE(), FourTubeBaseIE)


# Generated at 2022-06-24 12:19:05.322131
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:19:05.995675
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:19:07.631131
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:19:10.212760
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for case in [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]:
        instance = case()
        assert instance._VALID_URL
        assert instance._URL_TEMPLATE
        assert instance._TKN_HOST
        assert instance._TESTS

# Generated at 2022-06-24 12:19:10.700728
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:19:15.220039
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert PornTubeIE.__doc__ == FourTubeBaseIE.__doc__
    assert PornTubeIE._VALID_URL == FourTubeBaseIE._VALID_URL
    assert PornTubeIE._TKN_HOST == FourTubeBaseIE._TKN_HOST
    assert PornTubeIE._URL_TEMPLATE == FourTubeBaseIE._URL_TEMPLATE
    assert PornTubeIE._TESTS == FourTubeBaseIE._TESTS

# Generated at 2022-06-24 12:19:22.306435
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE.__name__ is 'FourTubeBaseIE'
    assert FourTubeBaseIE.__module__ is '_4tube_downloader'
    assert FourTubeBaseIE.__doc__ is None
    assert FourTubeBaseIE._VALID_URL is None
    assert FourTubeBaseIE._URL_TEMPLATE is None
    assert FourTubeBaseIE._TKN_HOST is None
    assert FourTubeBaseIE._TESTS is []
    assert FourTubeBaseIE._downloader is None
    assert FourTubeBaseIE._download_webpage is None
    assert FourTubeBaseIE._WORKING is True
    assert FourTubeBaseIE.IE_NAME is None
    assert FourTubeBaseIE.IE_DESC is None
    assert FourTubeBaseIE.webpage_reverse_video_reasons is None
    assert FourTubeBaseIE

# Generated at 2022-06-24 12:19:25.056432
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_constructor_test_object = PornerBrosIE()
    assert pornerbros_constructor_test_object.IE_NAME == 'PornerBros'

# Generated at 2022-06-24 12:19:27.533014
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:19:33.145128
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    if not FourTubeBaseIE._TKN_HOST:
        FourTubeBaseIE._TKN_HOST = '%s.%s' % (PornerBrosIE._TKN_HOST, PornerBrosIE._URL_TEMPLATE.split('.')[1])
    FourTubeBaseIE._VALID_URL = PornerBrosIE._VALID_URL

    instance = PornerBrosIE()
    instance._TEST = PornerBrosIE._TESTS
    instance._downloader = None

    return instance

# Generated at 2022-06-24 12:19:34.146569
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass


# Generated at 2022-06-24 12:19:41.255960
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import FakeYDL
    from .extractor.fourtube import FourTubeIE
    youtube_dl = FakeYDL({
        'extractor': 'FourTubeIE',
    })
    fourtube = FourTubeIE(youtube_dl)
    fourtube.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')



# Generated at 2022-06-24 12:19:47.585538
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    class PornerBrosIETest(unittest.TestCase):
        def test_without_displayID(self):
            PornerBrosIE()._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos|embed)/(?P<id>\d+)'
            PornerBrosIE()._URL_TEMPLATE = 'https://www.pornerbros.com/videos/%s/video'
            # This URL include display_id, but we remove it before testing
            url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
            PornerBrosIE()._real_extract

# Generated at 2022-06-24 12:19:58.499560
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeBaseIE._VALID_URL, url)
    assert mobj is not None

    video_id = mobj.group('id')
    assert video_id is not None

    kind = mobj.group('kind')
    assert kind is not None

    display_id = mobj.group('display_id')
    if not display_id:
        display_id = video_id

    url = 'https://www.4tube.com/videos/%s/video' % video_id
    assert url is not None

    tkn_host = 'token.4tube.com'
    assert tkn_

# Generated at 2022-06-24 12:19:59.537292
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-24 12:20:01.505008
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test initialization
    FourTubeIE()
    # Test initialization with name parameter
    FourTubeIE(IE_NAME='4tube')

# Generated at 2022-06-24 12:20:04.974210
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('https://www.porntube.com/embed/7089759', 'http://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-24 12:20:08.238732
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE("https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow")
    print("TEST_FuxIE")
    print("Unit test for constructor of class FuxIE")
    if ie.name == '4tube':
        print("FuxIE unit test passed")
    else:
        print("FuxIE unit test failed")


# Generated at 2022-06-24 12:20:13.112900
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    download_folder = 'download_folder'

    # Test constructor
    ie = FourTubeBaseIE(download_folder)

    # Make sure the right download directory is set
    try:
        assert ie.download_folder == download_folder
    except AssertionError:
        print('Expected ' + download_folder + ' for download directory, but got ' + ie.download_folder + ' instead.')

# Generated at 2022-06-24 12:20:22.595295
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:20:28.105208
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Go to the url: http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black
    """
    videoid = '209733'
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    #video = try_get(re, lambda x: x.group('videoid'), compat_str)

# Generated at 2022-06-24 12:20:29.556384
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    p = PornerBrosIE()



# Generated at 2022-06-24 12:20:41.943562
# Unit test for constructor of class FuxIE

# Generated at 2022-06-24 12:20:51.258365
# Unit test for constructor of class FuxIE
def test_FuxIE():
    d = FuxIE()
    assert d.IE_NAME == "4tube"
    assert d._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert d._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert d._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:21:03.182253
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_key = "209733"
    video_url = "http://www.4tube.com/videos/%s/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black" % video_key

# Generated at 2022-06-24 12:21:09.478269
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():

    url = 'https://www.4tube.com/videos/406440/romi-rain-in-the-air-tonight-part-2'
    instance = FourTubeIE()
    # Test extractor initialization with basic URL
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert instance._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert instance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:12.041615
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(PornTubeIE.ie_key())._VALID_URL == PornTubeIE._VALID_URL

# Generated at 2022-06-24 12:21:13.100036
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()

# Generated at 2022-06-24 12:21:21.713564
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    inst = FourTubeBaseIE()
    assert inst.IE_NAME == '4tube'
    assert inst._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert inst._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert inst._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:27.017215
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import PY2
    from youtube_dl.extractor.common import InfoExtractor

    try:
        if PY2:
            import urllib
            import urllib2
            http_client = urllib2
            urlparse = urllib
        else:
            import urllib3
            import urllib.request as urllib2
            import urllib.parse as urlparse
        http_client.disable_warnings()
    except ImportError:
        class http_client:
            pass
    try:
        import json
    except ImportError:
        import simplejson as json


# Generated at 2022-06-24 12:21:36.204030
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()

# Generated at 2022-06-24 12:21:38.095036
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-24 12:21:44.280704
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Base class constructor
    assert FourTubeBaseIE._TESTS is None
    assert FourTubeBaseIE._VALID_URL is None
    assert FourTubeBaseIE._URL_TEMPLATE is None
    assert FourTubeBaseIE._TKN_HOST is None
    # FourTubeBaseIE constructor
    assert FourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    assert FuxIE._VAL

# Generated at 2022-06-24 12:21:49.065514
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    r = PornerBrosIE()
    r1 = PornerBrosIE()
    assert(r.TKN_HOST == "token.pornerbros.com")
    assert(r.URL_TEMPLATE == "https://www.pornerbros.com/videos/video_%s")
    assert(r == r1)

# Generated at 2022-06-24 12:21:58.222591
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test = FuxIE()
    assert test._TKN_HOST == 'token.fux.com'
    test = FuxIE(http_scheme='https')
    assert test._TKN_HOST == 'token.fux.com'
    test = FuxIE(http_scheme='http')
    assert test._TKN_HOST == 'token.fux.com'
    test = FuxIE(domain='fux.com')
    assert test._TKN_HOST == 'token.fux.com'
    test = FuxIE(domain='www.fux.com')
    assert test._TKN_HOST == 'token.fux.com'
    test = FuxIE(domain='m.fux.com')

# Generated at 2022-06-24 12:21:59.045956
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()

# Generated at 2022-06-24 12:22:01.024028
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
        raise
    except TypeError:
        pass


# Generated at 2022-06-24 12:22:04.914067
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-24 12:22:07.288290
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    _test_instance(FourTubeIE)

test_FourTubeIE.__doc__ =  "Test FourTubeIE"


# Generated at 2022-06-24 12:22:10.408274
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(FourTubeBaseIE.IE_NAME, FourTubeBaseIE._VALID_URL)._VALID_URL == FourTubeBaseIE._VALID_URL

# Generated at 2022-06-24 12:22:12.121585
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.ie_key() == 'PornTube'

# Generated at 2022-06-24 12:22:17.359461
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._TKN_HOST == 'token.fux.com'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:22:28.619685
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    
    # define the expected values for the fields that are extracted
    expected_title = "Squirting Teen Ballerina on ECG"
    expected_id = "1331406"
    expected_ext = "mp4"
    expected_uploader = "Exploited College Girls"
    expected_uploader_id = "665"
    expected_channel = "Exploited College Girls"
    expected_channel_id = "665"
    expected_upload_date = "20130920"
    expected_timestamp = 1379685485
    expected_duration = 851
    expected_view_count = int
    expected_like_count = int
    expected_age_limit = 18

    # create an instance of the extractor
    ie = PornTubeIE()
    
    # run the actual test

# Generated at 2022-06-24 12:22:34.325577
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    ie._TKN_HOST == 'tkn.porntube.com'



# Generated at 2022-06-24 12:22:42.143047
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert obj._TKN_HOST == 'token.pornerbros.com'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:22:43.448085
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TKN_HOST == PornTubeIE.IE_NAME + '.tkn.porntube.com'


# Generated at 2022-06-24 12:22:52.425270
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Simple test for constructor of class FourTubeIE
    """
    test_cases = [
        {'url': 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'},
        {'url': 'https://www.4tube.com/embed/209733'},
        {'url': 'https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'}
    ]

    for test_case in test_cases:
        c = FourTubeIE(test_case)

# Generated at 2022-06-24 12:22:58.408816
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = FuxIE('https://www.fux.com/embed/853')
    assert IE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:23:09.280049
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    site = '4tube'
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    id = '209733'
    display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

    pattern = re.compile(r'https?://(?:(?P<kind>www|m)\.)?%s\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?' % site)
    mobj = pattern.match(url)

# Generated at 2022-06-24 12:23:16.925761
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-24 12:23:20.221880
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    class TestPornerBrosIE(unittest.TestCase):
        def test_PornerBrosIE(self):
            PornerBrosIE()
    unittest.main()

# Generated at 2022-06-24 12:23:22.506023
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()._download_webpage('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-24 12:23:33.446704
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # No site
    for url in [
            'https://www.4tube.com/videos/209733',
            'https://www.fux.com/videos/195359',
            'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
            'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369']:
        e = FourTubeBaseIE._extract_site(url)
        if e is None or e == '':
            print('Unit test for constructor of class FourTubeBaseIE failed with No site, ' + url)

# Generated at 2022-06-24 12:23:35.225789
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    tester = FourTubeBaseIE()
    result = tester.IE_NAME
    expected = "4tube"
    assert result == expected


# Generated at 2022-06-24 12:23:44.039676
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pt = PornTubeIE._build_video_info({
        'page': {
            'video': {
                'title': 'test',
                'mediaId': 34,
                'masterThumb': 'https://example.com/a.jpg',
                'user': {
                    'username': 'test_user'
                },
                'channel': {
                    'name': 'test_channel'
                },
                'likes': 1,
                'dislikes': 0,
                'playsQty': 2,
                'durationInSeconds': 3,
                'publishedAt': '2020-04-22T00:00:00+03:00'
            }
        }
    })
    assert pt['title'] == 'test'
    assert pt['thumbnail'] == 'https://example.com/a.jpg'

# Generated at 2022-06-24 12:23:54.790727
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FakeTest(FourTubeBaseIE):
        _VALID_URL = 'http://example.com'
        _URL_TEMPLATE = '%s'
        _TKN_HOST = 'token.example.com'


# Generated at 2022-06-24 12:23:56.067213
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.IE_NAME

# Generated at 2022-06-24 12:23:57.031089
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .. import FuxIE

# Generated at 2022-06-24 12:24:07.649664
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        from six.moves import urllib
    except ImportError:
        from six.moves import urllib_parse as urllib
    from ..compat import compat_b64decode
    from ..utils import try_get
    import json

    url = "https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406"
    webpage = url_or_none(url)
    
    video = try_get(
            webpage, lambda x: x['page']['video'])
    src = try_get(video, lambda x: x['mediaId'])
    json_string = compat_b64decode(compat_urllib_parse_unquote(src))
    data = json.loads(json_string)

# Generated at 2022-06-24 12:24:08.261342
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # test constructor
    PornTubeIE('PornTube')

# Generated at 2022-06-24 12:24:08.730870
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:24:10.753172
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test video
    url = 'https://fux.com/video/203054/open-door-to-creampie'
    ie = FuxIE(url)
    assert ie.ie_key() == 'Fux'

# Generated at 2022-06-24 12:24:12.480224
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE(None)
    except:
        return False
    return True

# Generated at 2022-06-24 12:24:14.920795
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _test_common_settings(_PornTubeIE, PornTubeIE)


# Generated at 2022-06-24 12:24:15.592240
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()

# Generated at 2022-06-24 12:24:24.791667
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-24 12:24:25.991710
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()

# Generated at 2022-06-24 12:24:35.993241
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TESTS[0] == {'url': 'https://www.4tube.com/videos/538849/mature-woman-in-lingerie-getting-fucked-hard', 'params': {}, 'only_matching': False, 'info_dict': {'id': '538849', 'ext': 'mp4', 'upload_date': '20150902', 'categories': ['milf'], 'age_limit': 18, 'duration': 1088, 'uploader': 'Puma Swede', 'timestamp': 1441129989, 'like_count': int, 'title': 'Mature woman in lingerie getting fucked hard', 'view_count': int, 'uploader_id': 'puma-swede'}}

# Generated at 2022-06-24 12:24:36.994866
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:24:40.351053
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'


# Generated at 2022-06-24 12:24:52.557408
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Check that fourtube module is working as expected
    class FourTubeTestIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
        _TKN_HOST = 'token.4tube.com'
    def test_FourTubeTestIE(self):
        url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
        # Successful download
        Four

# Generated at 2022-06-24 12:24:55.555072
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except NotImplementedError as e:
        print('FourTubeBaseIE() is not implemented.\n')



# Generated at 2022-06-24 12:25:04.109873
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from . import PornTubeIE, extractor
    from .extractor import IE_NAME
    from .common import InfoExtractor
    from .pornhub import PornHubIE
    assert PornTubeIE.IE_NAME == 'PornTube'
    assert PornTubeIE.__name__ == 'PornTubeIE'
    assert PornTubeIE.__module__ == extractor.__name__
    assert hasattr(extractor, 'PornTubeIE')
    assert not hasattr(extractor, 'PornHubIE')
    assert hasattr(extractor, 'PornTube')
    assert not hasattr(extractor, 'PornHub')
    assert PornTubeIE._VERSION == extractor._VERSION
    assert PornTubeIE._VALID_URL == PornHubIE._VALID_URL
    assert PornTubeIE._TESTS == PornHubIE._T

# Generated at 2022-06-24 12:25:05.050349
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None, None, None)

# Generated at 2022-06-24 12:25:15.077783
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert("FourTubeIE" in globals()), "Func:test_FourTubeIE:FourTubeIE is not defined"
    assert("FourTubeBaseIE" in globals()), "Func:test_FourTubeIE:FourTubeBaseIE is not defined"
    assert("InfoExtractor" in globals()), "Func:test_FourTubeIE:InfoExtractor is not defined"
    assert("re" in globals()), "Func:test_FourTubeIE:re is not defined"
    assert("compat_b64decode" in globals()), "Func:test_FourTubeIE:compat_b64decode is not defined"
    assert("compat_str" in globals()), "Func:test_FourTubeIE:compat_str is not defined"

# Generated at 2022-06-24 12:25:16.195474
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE() is not None;

# Generated at 2022-06-24 12:25:17.119079
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # No need to perform any test
    assert True

# Generated at 2022-06-24 12:25:23.067129
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    inst = FourTubeBaseIE('4tube')
    assert isinstance(inst, FourTubeBaseIE)
    inst = FourTubeBaseIE('Fux')
    assert isinstance(inst, FourTubeBaseIE)
    inst = FourTubeBaseIE('PornTube')
    assert isinstance(inst, FourTubeBaseIE)
    inst = FourTubeBaseIE('PornerBros')
    assert isinstance(inst, FourTubeBaseIE)


# Generated at 2022-06-24 12:25:31.825299
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    result = FourTubeIE()
    assert result.__class__.__name__ == "FourTubeIE"
    assert result._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert result._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert result._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:25:35.793460
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	# Check that constructor raises error when called with invalid domain
	import six
	assert_raises(
		ValueError,
		PornTubeIE, "porterbros.com")
	# Check that constructor works as expected
	yt_ie = PornTubeIE("porntube.com")
	assert (yt_ie.IE_NAME == u'porntube')


# Generated at 2022-06-24 12:25:43.626347
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test case 1
    info = None
    try:
        info = FourTubeBaseIE._extract_formats('url', 'id', 'media_id', ['720', '1080'])
    except:
        assert False

    # Check the result
    assert len(info) == 2
    assert info[0] == {
        'url': '08x6iX9qbq0z1',
        'format_id': '720p',
        'resolution': '720p',
        'quality': 720
    }
    assert info[1] == {
        'url': '3cLZtTIJKFnSX',
        'format_id': '1080p',
        'resolution': '1080p',
        'quality': 1080
    }

    # Test case 2
    info = {}

# Generated at 2022-06-24 12:25:49.324389
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import warnings
    warnings.filterwarnings('ignore', category=ImportWarning)

    try:
        import webvtt
        webvtt.UnknownFileFormatError
    except ImportError:
        raise ImportError(
            'FuxIE unit tests require the \'webvtt\' module which is '
            'available at \'https://github.com/enkore/pyvtt\'')
    # Works well
    FuxIE()



# Generated at 2022-06-24 12:25:50.082832
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.ie_key() == 'Fux'

# Generated at 2022-06-24 12:25:53.087058
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie._VALID_URL is not None
    assert ie._URL_TEMPLATE is not None
    assert ie._TKN_HOST is not None

# Generated at 2022-06-24 12:25:57.668935
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # I am creating instance of class FuxIE and try to test if it is derived from the FourTubeBaseIE
    obj = FuxIE()
    assert(isinstance(obj, FourTubeBaseIE) is True)


# Generated at 2022-06-24 12:25:58.671482
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    print(instance)

# Generated at 2022-06-24 12:26:04.295221
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_urls = [
        'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406',
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
        'https://www.fux.com/embed/195359',
    ]

    for url in test_urls:
        fourTubeBaseIE = FourTubeBaseIE()


# Generated at 2022-06-24 12:26:11.223331
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    class _FourTubeBaseIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
        _TKN_HOST = 'token.4tube.com'

    try:
        _FourTubeBaseIE()
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-24 12:26:12.128800
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:26:13.139871
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie != None

# Generated at 2022-06-24 12:26:16.368216
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    FourTubeIE(url)