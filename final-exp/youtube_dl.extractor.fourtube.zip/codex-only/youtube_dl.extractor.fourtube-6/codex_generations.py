

# Generated at 2022-06-24 12:16:15.669452
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'


# Generated at 2022-06-24 12:16:20.087293
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.ie_key() in ('pornerbros', 'PornerBros')

# Generated at 2022-06-24 12:16:21.565628
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """Unit test for constructor of class PornTubeIE."""
    PornTubeIE()

# Generated at 2022-06-24 12:16:26.762953
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import youtube_dl

    # Construct an object to test
    ydl = youtube_dl.YoutubeDL({})
    ie = ydl.extract_info(
        url='https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow',
        download=False
    )

    # Test some values of `ie` object
    # ...



# Generated at 2022-06-24 12:16:28.464992
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    er = PornTubeIE()
    assert er._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:16:29.199488
# Unit test for constructor of class FuxIE
def test_FuxIE():
    case = FuxIE()

# Generated at 2022-06-24 12:16:31.046825
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:16:33.906682
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import youtube_dl
    sample_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    ie = PornTubeIE()
    ie.extract(sample_url)
    assert ie == PornTubeIE()
    # TODO: loop over all subclasses

# Generated at 2022-06-24 12:16:37.849076
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE = FuxIE()
    assert FuxIE._TKN_HOST == "token.fux.com"
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:16:47.313632
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Unit test for constructor of class FourTubeBaseIE."""
    # Test argument '_VALID_URL'
    assert FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    # Test argument '_URL_TEMPLATE'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    # Test argument '_TKN_HOST'
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'
    # Test argument '_TESTS'

# Generated at 2022-06-24 12:16:48.903165
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.test()

# Generated at 2022-06-24 12:16:50.023825
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:16:57.538869
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    #From: PornTubeIE
    test_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    # To then be tested by the following classes:
    tests = [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]
    for cls in tests:
        assert cls(test_url)._TKN_HOST == cls._TKN_HOST
        assert cls(test_url)._URL_TEMPLATE == cls._URL_TEMPLATE

# Generated at 2022-06-24 12:17:06.669925
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Create instance of FuxIE class
    fux_ie = FuxIE()
    # Test the URL format
    assert re.match(r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?', fux_ie._VALID_URL)
    # Test the URL template
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    # Test the token host
    assert fux_ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:17:10.738379
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    klass = type(FourTubeBaseIE.__name__ + 'TEST', (FourTubeBaseIE,), {})

    assert issubclass(klass, FourTubeBaseIE)
    assert klass._TEST == klass._TESTS

# Generated at 2022-06-24 12:17:20.124269
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test = {
        'url': 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'info_dict': {
            'id': '7089759',
            'ext': 'mp4',
            'title': 'Teen couple doing anal',
            'uploader': 'Alexy',
            'uploader_id': '91488',
            'upload_date': '20150606',
            'timestamp': 1433595647,
            'duration': 5052,
            'view_count': int,
            'like_count': int,
            'age_limit': 18,
        },
    }

    # run test
    porn_tube = PornTubeIE()
    info_dict = porn_tube._real_extract(test['url'])

    #

# Generated at 2022-06-24 12:17:23.838144
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	import unittest
	class test_PornerBros(unittest.TestCase):
		def test_constructor(self):
			inst = PornerBrosIE()
			self.assertIsNotNone(inst)
	test_suite = unittest.TestLoader().loadTestsFromTestCase(test_PornerBros)
	unittest.TextTestRunner(verbosity=2).run(test_suite)


# Generated at 2022-06-24 12:17:33.004540
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class DummyIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?example\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.example.com/videos/video_%s'
        _TKN_HOST = 'example.com'
    assert DummyIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?example\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:17:34.961589
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-24 12:17:36.253693
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import get_testcases
    get_testcases(FourTubeIE)

# Generated at 2022-06-24 12:17:45.040167
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    For coverage purposes
    """
    ie = FourTubeBaseIE()
    r = re.compile(ie._VALID_URL)

    assert r.match('https://www.4tube.com/videos/someid/video') is not None
    assert r.match('https://www.4tube.com/embed/someid') is not None
    assert r.match('https://m.4tube.com/videos/someid/video') is not None
    assert r.match('https://m.4tube.com/embed/someid') is not None

    assert r.match('http://www.4tube.com/videos/someid/video') is not None
    assert r.match('http://www.4tube.com/embed/someid') is not None

# Generated at 2022-06-24 12:17:53.262296
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:18:01.404332
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)
    assert isinstance(ie, FourTubeBaseIE)
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:18:08.265451
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():

    testVideoUrl = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    testVideoUrl2 = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    testVideoUrl3 = 'https://www.porntube.com/videos/rita-daniels-is-fucked-by-stepson_1498302'
    testVideoUrl4 = 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-24 12:18:10.551922
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test the constructor of class FourTubeIE.
    # The goal of this test is to test if the function __init__ can be run.
    # The function __init__ only has a self parameter, so it will always run
    # successfully.
    test = FourTubeIE()



# Generated at 2022-06-24 12:18:11.573288
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-24 12:18:13.938356
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # create a new PornerBrosIE object
    obj = PornerBrosIE()
    # assert type and value of PornerBrosIE object
    assert obj is not None


# Generated at 2022-06-24 12:18:17.743877
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for clazz in [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]:
        tester = clazz()
        assert hasattr(tester, '_TKN_HOST')
        assert hasattr(tester, '_URL_TEMPLATE')
        assert tester.IE_NAME == clazz.__name__.replace(
            'FourTube', '').replace('IE', '').lower()

# Generated at 2022-06-24 12:18:31.491399
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    static_data = '''<html>
<head><meta itemprop="name" content="cool stuff!"/>
<meta itemprop="uploadDate" content="2013-12-03T00:00:00Z"></head>
<body><button data-id='1' data-quality='360'>360p</button>
<button data-id='2' data-quality='480'>480p</button>
<button data-id='3' data-quality='720'>720p</button>
<meta itemprop="thumbnailUrl" content="http://example.com/image"/></body></html>'''
    class DummyIE(FourTubeBaseIE):
        def _download_webpage(self, url, video_id, *args, **kwargs):
            return static_data

# Generated at 2022-06-24 12:18:32.896736
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()


# Generated at 2022-06-24 12:18:38.521912
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    m = re.match(FourTubeBaseIE._VALID_URL, "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    print(m.group('kind'))
    print(m.group('id'))
    print(m.group('display_id'))
    



# Generated at 2022-06-24 12:18:40.746709
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE(None)
    print(pornerbros_ie)


# Generated at 2022-06-24 12:18:43.760836
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        __import__('youtube_dl.extractor.porntube')
        __import__('youtube_dl.extractor.fourtube')
        __import__('youtube_dl.extractor.fux')
        __import__('youtube_dl.extractor.pornerbros')
        assert 4 == 4
        return 0
    except:
        return 1
test_FourTubeIE()

# Generated at 2022-06-24 12:18:47.612716
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == 'porntube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:18:49.350596
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pass

# Generated at 2022-06-24 12:18:50.412528
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-24 12:18:54.831513
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # unit test
    pornerbros = PornerBrosIE()
    pornerbros_name = pornerbros.IE_NAME
    assert pornerbros_name == 'PornerBros'


# Generated at 2022-06-24 12:18:55.496303
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-24 12:19:06.351431
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:19:13.427431
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    temp_link = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    tester = PornerBrosIE()
    assert tester._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert tester._TESTS[0]['url'] == temp_link

# Generated at 2022-06-24 12:19:16.672772
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    if not hasattr(PornerBrosIE, 'IE_NAME'):
      raise Exception('Unit test must be run with python2!')


# Generated at 2022-06-24 12:19:18.736451
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test to create an instance of fourtube base class
    fourtube = FourTubeBaseIE()
    # Check that instance is valid
    assert fourtube is not None

# Generated at 2022-06-24 12:19:20.614435
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()._real_extract('https://www.porntube.com/videos/a_7089759')

# Generated at 2022-06-24 12:19:30.596861
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_ie = FourTubeIE();
    vid = '209733'
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    data = fourtube_ie._download_webpage(url, None)
    media_id = fourtube_ie._search_regex(
        r'<button[^>]+data-id=(["\'])(?P<id>\d+)\1[^>]+data-quality=', data,
        'media id', default=None, group='id')
    sources = [
        quality
        for _, quality in re.findall(r'<button[^>]+data-quality=(["\'])(.+?)\1', data)]
   

# Generated at 2022-06-24 12:19:39.138225
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from . import FourTubeBaseIE
    fux_ie = FourTubeBaseIE()
    assert isinstance(fux_ie, FourTubeBaseIE)
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:19:43.766799
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:19:44.819230
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:19:46.546571
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-24 12:19:48.699346
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(FourTubeBaseIE)

# Generated at 2022-06-24 12:19:59.267589
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_parse_json')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_html_search_meta')
    assert hasattr(ie, '_html_search_regex')
    assert hasattr(ie, '_extract_formats')
    assert hasattr(ie, '_sort_formats')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_URL_TEMPLATE')
    assert hasattr(ie, '_TKN_HOST')

# Generated at 2022-06-24 12:20:00.248527
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:20:02.553310
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == FuxIE._VALID_URL
    assert FuxIE()._TESTS == FuxIE._TESTS


# Generated at 2022-06-24 12:20:04.512599
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")

# Generated at 2022-06-24 12:20:05.890360
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    browser = PornerBrosIE()
    assert(isinstance(browser, PornerBrosIE))

# Generated at 2022-06-24 12:20:08.067791
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE._VALID_URL, PornerBrosIE._TKN_HOST)


# Generated at 2022-06-24 12:20:11.974652
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeIE()
    assert(hasattr(instance, '_TKN_HOST'))
    assert(hasattr(instance, '_TESTS'))
    assert(isinstance(instance._TESTS, list))
    assert(isinstance(instance._TESTS[0], dict))
    assert(isinstance(instance._TESTS[0]['info_dict'], dict))
    assert(isinstance(instance._TESTS[0]['info_dict']['upload_date'], str))
    assert(isinstance(instance._TESTS[0]['info_dict']['categories'], list))

# Generated at 2022-06-24 12:20:19.989494
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    video  = {
        'categories' : list,
        'channel' : str,
        'channel_id' : str_or_none,
        'duration' : int,
        'formats' : list,
        'id' : str,
        'like_count' : int,
        'dislike_count' : int,
        'thumbnail' : str,
        'timestamp' : int,
        'title' : str,
        'upload_date' : str,
        'uploader' : str,
        'uploader_id' : str,
        'view_count' : int
    }

# Generated at 2022-06-24 12:20:22.455450
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    x = str(x)


# Generated at 2022-06-24 12:20:24.535778
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie.ie_key() == '4tube'

# Generated at 2022-06-24 12:20:32.350125
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_urls = (
        ('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
         'https://www.4tube.com/videos/209733/video'),
        ('https://www.4tube.com/embed/209733',
         'https://www.4tube.com/videos/209733/video'),
        ('https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
         'https://www.4tube.com/videos/209733/video'),
    )

    for (url, expected_result) in test_urls:
        assert FourTubeIE._

# Generated at 2022-06-24 12:20:34.329360
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    r = PornTubeIE()
    assert r.TLD == 'porntube.com'

# Generated at 2022-06-24 12:20:36.412190
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert(instance.IE_NAME == 'PornTube')

# Generated at 2022-06-24 12:20:37.718951
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    print('\n\n')
    ie = PornerBrosIE(PornerBrosIE._VALID_URL)
    print('\n\n')


# Generated at 2022-06-24 12:20:47.903999
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import sys
    if sys.version_info[0] == 2:
        return
    try:
        import httplib
        import http.client
        http.client.HTTPConnection.debuglevel = 1
        logging.basicConfig()
        logging.getLogger().setLevel(logging.DEBUG)
        requests_log = logging.getLogger("requests.packages.urllib3")
        requests_log.setLevel(logging.DEBUG)
        requests_log.propagate = True
    except ImportError:
        httplib.HTTPConnection.debuglevel = 1
        logging.basicConfig()
        logging.getLogger().setLevel(logging.DEBUG)
        requests_log = logging.getLogger("requests.packages.urllib3")
        requests_log.setLevel(logging.DEBUG)
        requests

# Generated at 2022-06-24 12:20:54.303504
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    example_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeBaseIE()
    assert ie.match_url(example_url)
    assert ie.extract(example_url)

# Generated at 2022-06-24 12:21:05.096394
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = "https://www.4tube.com/videos/video_id"
    ie = FourTubeIE(None)
    assert(ie._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?")
    assert(ie._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video")
    assert(ie._TKN_HOST == "token.4tube.com")
    assert(ie._VALID_URL.match(url).group('kind') == "www")
    assert(ie._VALID_URL.match(url).group('id') == "video_id")

# Generated at 2022-06-24 12:21:07.496905
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE._TESTS[0], PornerBrosIE._TESTS[0]['url'])

# Generated at 2022-06-24 12:21:08.051532
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:21:10.131163
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST is not None
    assert FourTubeBaseIE._TESTS



# Generated at 2022-06-24 12:21:15.765725
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.name = ie.IE_NAME
    ie.ie_key = ie.ie_key
    ie.RATINGS = ie.RATINGS
    ie.RATINGS_ORDER = ie.RATINGS_ORDER
    ie._VALID_URL = ie._VALID_URL
    ie._TESTS = ie._TESTS
    ie.BRIGHTCOVE_URL_TEMPLATE = ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_VIDEO_DATA_TEMPLATE = ie.BRIGHTCOVE_VIDEO_DATA_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE_REGEX = ie.BRIGHTCOVE_URL_TEMPLATE_REGEX
    ie.BR

# Generated at 2022-06-24 12:21:19.968504
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    print(fux.IE_NAME)
    print(fux._VALID_URL)
    print(fux._URL_TEMPLATE)
    print(fux._TKN_HOST)
    print(fux._TESTS)

# Generated at 2022-06-24 12:21:26.583918
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fx = FuxIE()
    assert fx.IE_NAME == '4tube'
    assert fx._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fx._TKN_HOST == 'token.fux.com'
    assert fx._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:21:32.176518
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video_id = '7089759'
    title = 'Teen couple doing anal'
    display_id = 'teen-couple-doing-anal_7089759'

    url = 'https://www.porntube.com/videos/' + display_id
    webpage = test_template_page(url, video_id, title)

    # Check that the class constructor is working well
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_

# Generated at 2022-06-24 12:21:44.161159
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._TKN_HOST = 'token.4tube.com'

# Generated at 2022-06-24 12:21:45.391337
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert(PornerBrosIE("") != None)

# Generated at 2022-06-24 12:21:53.444034
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE.ie_key()
    info_dict = ie.extract('https://www.fux.com/embed/195359')
    assert '195359' == info_dict['id']
    assert 'Eighteen-year-old gets her ass pounded' == info_dict['title']
    info_dict = ie.extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert '195359' == info_dict['id']
    assert 'Awesome fucking in the kitchen ends with cum swallow' == info_dict['title']

# Generated at 2022-06-24 12:22:00.237187
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()
    url = "https://www.4tube.com/videos/10267/japanese-slave"
    assert(fourtube._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?")
    assert(fourtube._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video")
    assert(fourtube._TKN_HOST == "token.4tube.com")
    assert(re.match(fourtube._VALID_URL, url) is not None)

# Generated at 2022-06-24 12:22:03.977842
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME == 'Fux'
    assert hasattr(fux, '_VALID_URL')
    assert hasattr(fux, '_TESTS')


# Generated at 2022-06-24 12:22:07.725323
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    imports = [
        'import importlib',
        'import sys',
        'importlib.reload(sys)',
    ]

    PornTubeIE.test(
        PornTubeIE._TESTS[0],
        imports=imports)

# Generated at 2022-06-24 12:22:11.840239
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')['uploader'] == 'WCP Club'

# Generated at 2022-06-24 12:22:12.751549
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE.suite()

# Generated at 2022-06-24 12:22:21.479117
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE();

# Generated at 2022-06-24 12:22:31.614890
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-24 12:22:35.961572
# Unit test for constructor of class FuxIE
def test_FuxIE():
    for ie in [FourTubeIE(), FuxIE(), PornTubeIE(), PornerBrosIE()]:
        ie.suitable('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
        ie.get_url_info('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:22:37.110711
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-24 12:22:40.538590
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()
    assert (inst._TKN_HOST == 'token.pornerbros.com')
    assert (inst._TKN_HOST != 'token.4tube.com')

# Generated at 2022-06-24 12:22:43.245461
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE.__name__ == 'FourTubeIE')
    assert("FourTubeIE()" == str(FourTubeIE()))

# Generated at 2022-06-24 12:22:44.852004
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # unit test for constructor of class FourTubeIE
    FourTubeIE()


# Generated at 2022-06-24 12:22:53.972583
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class TestPornTubeInstance(object):
        def __init__(self, test_case, name):
            self.test_case = test_case
            self.name = name
            self.test_counter = 0
            self.test_passed = 0
            self.test_failed = 0
            self.results = {
                'test_counter': 0,
                'test_passed': 0,
                'test_failed': 0,
                'test_results': [],
                'test_passed_results': [],
                'test_failed_results': [],
            }
            self.test_results = []
            self.test_passed_results = []
            self.test_failed_results = []

        def _test(self, test_func):
            self.test_counter += 1
            result = test

# Generated at 2022-06-24 12:23:03.916502
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base = FourTubeBaseIE()
    assert base._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert base._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert base._TKN_HOST == 'token.4tube.com'
    assert base._extract_formats('', '', '', '') == []

# Generated at 2022-06-24 12:23:05.231306
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube', {}, 'PornTube')

# Generated at 2022-06-24 12:23:07.178869
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from ..constructor import FourTubeIE
    assert FourTubeIE.IE_NAME == '4tube'

# Generated at 2022-06-24 12:23:17.905457
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Arrange
    mobj = re.match(FourTubeBaseIE._VALID_URL, 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    video_id = mobj.group("id")
    media_id = "209733"
    sources = ["720", "480", "240"]

    # Act
    instance = FourTubeBaseIE()
    methods = dir(instance)
    result = methods

    # Assert
    assert (result != None)
    assert (video_id == media_id)
    assert (sources == ["720", "480", "240"])

# Generated at 2022-06-24 12:23:21.611292
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

# Generated at 2022-06-24 12:23:29.778594
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Check that we can find the class by its name
    assert 'FourTubeIE' in globals()
    # Choose a url
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    # Create an instance of the class that's being tested
    instance = globals()['FourTubeIE']()._real_initialize(url)
    # Check that it is not None
    assert instance is not None

# Generated at 2022-06-24 12:23:30.639534
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_obj = PornerBrosIE()

# Generated at 2022-06-24 12:23:33.284933
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import time
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    print("Unit test for constructor of class FuxIE() is passed!")


# Generated at 2022-06-24 12:23:41.415261
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    mobj = re.match(PornTubeIE._VALID_URL, 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    video_id, display_id = mobj.group('id', 'display_id')

    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    webpage = PornTubeIE._download_webpage(url, display_id)

# Generated at 2022-06-24 12:23:42.926771
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE(None)
    assert obj != None

# Generated at 2022-06-24 12:23:45.710300
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL is None
    assert ie._URL_TEMPLATE is None
    assert ie._TKN_HOST is None

# Generated at 2022-06-24 12:23:51.319315
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._VALID_URL = 'http://www.4tube.com/videos/(?P<id>\d+)/'
    ie._extract_url('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-24 12:23:53.130433
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._VALID_URL
    assert FourTubeIE()._TKN_HOST

# Generated at 2022-06-24 12:23:56.775772
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._VALID_URL = re.compile(ie._VALID_URL)
    ie._URL_TEMPLATE = ie._URL_TEMPLATE
    ie._TKN_HOST = ie._TKN_HOST
    ie._TESTS = ie._TESTS

# Generated at 2022-06-24 12:23:58.346407
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()



# Generated at 2022-06-24 12:23:59.846531
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print(FourTubeIE(FourTubeIE.ie_key()).IE_NAME)

# Generated at 2022-06-24 12:24:09.428672
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Testing PornTube downloader
    from ..downloader.common import FileDownloader

    # Test PornTube with random id

# Generated at 2022-06-24 12:24:11.544089
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie == FuxIE()
    assert fux_ie._TESTS


# Generated at 2022-06-24 12:24:12.861007
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE(None)

# Generated at 2022-06-24 12:24:15.994734
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Set up and run constructor
    er = FourTubeIE()
    # Check if it's the correct constructor
    assert er.__class__ == FourTubeIE


# Generated at 2022-06-24 12:24:17.573873
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .test_fux import TestFuxIE
    TestFuxIE.test_fux()

# Generated at 2022-06-24 12:24:19.376426
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from PornHubIE import PornHubIE

    ie = PornHubIE()
    ie = PornTubeIE()

# Generated at 2022-06-24 12:24:21.636250
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        from you_get.extractors.porntube import PornTubeIE
    except ImportError:
        pass

# Generated at 2022-06-24 12:24:29.887540
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'



# Generated at 2022-06-24 12:24:31.711375
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_ie = FourTubeIE()
    assert test_ie.VALID_URL == FourTubeIE._VALID_URL
    assert test_ie._TKN_HOST == FourTubeIE._TKN_HOST


# Generated at 2022-06-24 12:24:32.959623
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    IE_PornTube = PornTubeIE('PornTube')
    assert IE_PornTube._VALID_URL == PornTubeIE._VALID_URL

# Generated at 2022-06-24 12:24:35.740839
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert hasattr(ie, '_TKN_HOST')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_URL_TEMPLATE')


# Generated at 2022-06-24 12:24:38.765730
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')
    ie = FourTubeBaseIE('fux')
    ie = FourTubeBaseIE('porntube')
    ie = FourTubeBaseIE('pornerbros')

# Generated at 2022-06-24 12:24:50.070260
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .PornTubeIE import PornTubeIE
    PornTubeIE()

_TUBE8_VIDEO_URL_TEMPLATE = 'http://www.tube8.com/%s/%s'
_TUBE8_EMBED_URL_TEMPLATE = 'http://www.tube8.com/embed/%s/%s'
_TUBE8_TEMPLATE = 'http://www.tube8.com/%s/%s/%s'

# Generated at 2022-06-24 12:24:52.717675
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    _FourTubeIE = FourTubeIE()
    assert _FourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:57.478013
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    # this will raise AttributeError if it doesn't work
    resolution_list = fux_ie._extract_formats('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow',195359,'101376',['360','720'])

# Generated at 2022-06-24 12:24:58.114874
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:25:03.106093
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .pornhub import PornHubIE
    from .xhamster import XHamsterIE
    from .xvideos import XHamsterIE
    #print(PornTubeIE._TESTS[0])
    #print(PornHubIE._TESTS[0])
    #print(XHamsterIE._TESTS[0])
    #print(XvideosIE._TESTS[0])
    pass

# Generated at 2022-06-24 12:25:05.794326
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except:
        assert False, 'Could not create PornerBrosIE() object'
    assert True

# Generated at 2022-06-24 12:25:07.354840
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None, None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:25:15.799235
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE('http://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-24 12:25:25.445540
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Test FuxIE __init__ method with FuxIE.IE_NAME and FuxIE._VALID_URL"""
    assert FuxIE.IE_NAME == 'Fux'
    assert FuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-24 12:25:35.453392
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:25:37.000362
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    grabber = FourTubeBaseIE()
    assert grabber is not None

# Generated at 2022-06-24 12:25:43.644391
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE('https://www.pornerbros.com/embed/181369')
    assert instance.name == 'PornerBros'
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:25:45.534440
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    a = FourTubeBaseIE();


if __name__ == '__main__':
    test_FourTubeBaseIE();

# Generated at 2022-06-24 12:25:48.131512
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()
    FourTubeBaseIE()
    PornTubeIE()
    PornerBrosIE()
    print("unit test for constructor of class FourTubeBaseIE")

# Generated at 2022-06-24 12:25:56.681349
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-24 12:26:07.687477
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:26:18.984634
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    from .compat import compat_str, compat_urllib_parse_unquote, compat_urlparse


    parsed_url = compat_urlparse.urlparse(
            'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    token_url = 'https://token.4tube.com/' + parsed_url.path.split('/')[
            2] + '/desktop/480+360+240'
    parsed_token_url = compat_urlparse.urlparse(token_url)
