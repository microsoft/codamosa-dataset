

# Generated at 2022-06-24 12:16:19.867949
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_ie = FourTubeBaseIE()

    # test _extract_formats

# Generated at 2022-06-24 12:16:22.166242
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    assert isinstance(obj, PornTubeIE)
    assert isinstance(obj, FourTubeBaseIE)



# Generated at 2022-06-24 12:16:23.190086
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.IE_NAME

# Generated at 2022-06-24 12:16:32.041901
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    expected_data = {
        'id': '7089759',
        'ext': 'mp4',
        'title': 'Teen couple doing anal',
        'uploader': 'Alexy',
        'uploader_id': '91488',
        'upload_date': '20150606',
        'timestamp': 1433595647,
        'duration': 5052,
        'view_count': 0,
        'like_count': 0,
        'age_limit': 18,
     }

# Generated at 2022-06-24 12:16:37.072307
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    # check for Parent class's constructor
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj.IE_NAME == '4tube'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-24 12:16:41.044822
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import (
        FourTubeIE,
    )
    # NOTE: This is `None` because the API is not documented.
    #       It might break at any time.
    #       Although it has been stable for more than a year.
    ie = FourTubeIE()
    assert ie is not None



# Generated at 2022-06-24 12:16:42.028553
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert isinstance(PornerBrosIE, type)

# Generated at 2022-06-24 12:16:43.643743
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert(isinstance(instance, FourTubeBaseIE)) == True

# Generated at 2022-06-24 12:16:45.989229
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Construct a PornTubeIE object with given url
    ptie = PornTubeIE()
    # Make sure that this object is not None
    assert ptie is not None


# Generated at 2022-06-24 12:16:46.849768
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-24 12:16:50.265342
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Unit test for constructor of class FuxIE"""
    from .test_downloads import FakeYDL
    ydl = FakeYDL()
    ie = FuxIE(ydl=ydl)
    assert isinstance(ie, FuxIE)

# Generated at 2022-06-24 12:16:51.962664
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._parse_json('{"test": "yes"}', 'Fake video id')

# Generated at 2022-06-24 12:17:02.925179
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_id = '209733'
    display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    url = 'http://www.4tube.com/videos/%s/%s' % (video_id, display_id)
    url_embed = 'http://www.4tube.com/embed/%s' % video_id
    url_short = 'http://www.4tube.com/%s' % video_id
    url_mobile = 'http://m.4tube.com/videos/%s/%s' % (video_id, display_id)
    instance = FourTubeIE(url)
    expected = instance.IE_NAME
    result = '4tube'
    assertEquals(expected, result)
    instance = Four

# Generated at 2022-06-24 12:17:04.417948
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    inst = FourTubeIE()
    assert inst.IE_NAME == '4tube'

# Generated at 2022-06-24 12:17:05.046657
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:17:08.885663
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_Fux = FuxIE()
    assert(test_Fux._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-24 12:17:18.917229
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fux_ie = FuxIE(FuxIE._downloader, URL=url)
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'
    assert fux_ie._downloader is not None


# Generated at 2022-06-24 12:17:22.464316
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE() is None

# Generated at 2022-06-24 12:17:27.793096
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        fourtube = FourTubeIE()
        fourtube.extract("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    except Exception as e:
        assert(False)


# Generated at 2022-06-24 12:17:29.555026
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert isinstance(p, PornTubeIE)


# Generated at 2022-06-24 12:17:35.764209
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class test1(FourTubeBaseIE):
        _VALID_URL = None
        _URL_TEMPLATE = None
        _TKN_HOST = None
    class test2(FourTubeBaseIE):
        _VALID_URL = None
        _URL_TEMPLATE = None
        _TKN_HOST = None
    if test1._TKN_HOST == test2._TKN_HOST:
        raise Exception('_TKN_HOST should be different')

# Generated at 2022-06-24 12:17:42.287445
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    IE_instance = FourTubeIE()
    assert IE_instance.IE_NAME == '4tube'
    assert IE_instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert IE_instance._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert IE_instance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:17:48.234183
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    constructor = FourTubeIE(None)
    assert constructor._TKN_HOST == 'token.4tube.com'
    assert constructor._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert constructor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert constructor._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-24 12:17:49.650335
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:17:59.637931
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test an URL which has channel name
    # See https://github.com/ytdl-org/youtube-dl/issues/18335 for more details
    PornTubeIE()._real_extract("https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406")
    # Test an URL which doesn't have channel name
    # See https://github.com/ytdl-org/youtube-dl/issues/18335 for more details
    PornTubeIE()._real_extract("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")

# Generated at 2022-06-24 12:18:02.343174
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	str1 = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
	PornTubeIE()._real_extract(str1)

# Generated at 2022-06-24 12:18:03.192325
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE() != None)

# Generated at 2022-06-24 12:18:13.644702
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE('4tube')
    assert obj._VALID_URL is None
    assert obj._URL_TEMPLATE is None
    assert obj._TKN_HOST is None
    assert obj._TESTS is None

    obj = FourTubeBaseIE.ie_key()
    assert obj == '4tube'

    obj = FourTubeBaseIE.suitable(None)
    assert obj is False

    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    obj = FourTubeBaseIE.suitable(url)
    assert obj is True

    url = 'https://www.4tube.com/embed/209733'
    obj = FourTubeBaseIE.suitable(url)

# Generated at 2022-06-24 12:18:14.561450
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():

    # Try to instantiate class
    PornTubeIE({})

# Generated at 2022-06-24 12:18:15.679016
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from ..downloader import tests
    return tests.test_fux_ie(FuxIE)

# Generated at 2022-06-24 12:18:19.685726
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    # Get a valid sample URL
    _VALID_URL = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    url = ie._VALID_URL
    # Call get_real_url
    #real_url = ie._real_url()
    # Check the real_url
    #assert real_url == _VALID_URL

# Generated at 2022-06-24 12:18:22.017249
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'

# Generated at 2022-06-24 12:18:27.178312
# Unit test for constructor of class FuxIE
def test_FuxIE():
    expected_result = {
        'url': 'https://www.fux.com/embed/195359',
        'only_matching': True
    }
    obj = FuxIE('https://www.fux.com/embed/195359')
    assert obj._TESTS[0] == expected_result

# Generated at 2022-06-24 12:18:30.130003
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # The actual tests work with the object returned by
    # main.get_extractor(url)
    FuxIE()

# Generated at 2022-06-24 12:18:33.892283
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL is None
    assert ie._TKN_HOST is None
    assert ie._URL_TEMPLATE is None
    assert ie._TESTS is None

# Generated at 2022-06-24 12:18:43.823264
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import sys
    import hashlib
    from .common import InfoExtractor
    from .extractor import (
        PornTubeIE,
        FourTubeIE,
        FuxIE,
        PornerBrosIE,
    )
    from argparse import ArgumentParser

    class MockFD(object):
        def __init__(self, fd):
            self.fd = fd
            self.seek(0, 0)

        def read(self, size):
            return self.fd.read(size)

        def seek(self, offset, whence):
            return self.fd.seek(offset, whence)

        def tell(self):
            self.fd.tell()

    parser = ArgumentParser(prog=__name__, parents=[InfoExtractor._parser])

# Generated at 2022-06-24 12:18:44.273799
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    pass

# Generated at 2022-06-24 12:18:55.868011
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestIE(FourTubeBaseIE):
        IE_NAME = 'test'
        _VALID_URL = r'https?://(?:www\.)?test\.com/video/(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.test.com/video/%s'
        _TKN_HOST = 'token.test.com'


# Generated at 2022-06-24 12:18:57.244249
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-24 12:18:59.041806
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    assert obj._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:19:09.978627
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # testing for self.IE_NAME == '4tube'
    assert FourTubeIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert FourTubeIE._

# Generated at 2022-06-24 12:19:13.427999
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._VALID_URL is None
    assert FourTubeBaseIE._TKN_HOST is None
    assert FourTubeBaseIE._URL_TEMPLATE is None
    assert FourTubeBaseIE._TESTS is None
    assert FourTubeBaseIE.IE_NAME is None

# Generated at 2022-06-24 12:19:14.393947
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert x

# Generated at 2022-06-24 12:19:14.859939
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
	FourTubeBaseIE()

# Generated at 2022-06-24 12:19:21.955135
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test constructor of PornTubeIE from FourTubeBaseIE
    # Test the constructor of class PornTubeIE from class FourTubeBaseIE
    # on checking the case where the url is of the format
    # https://www.porntube.com/embed/<video_id>
    url = 'https://www.porntube.com/embed/7089759'
    obj = PornTubeIE()
    assert (str(obj).find('PornTube') != -1), 'It should be PornTube'
    assert (str(obj).find('FourTube') != -1), 'It should be FourTube'
    assert (str(obj).find('IE_NAME') != -1), 'It should be IE_NAME'
    assert (str(obj).find('_VALID_URL') != -1), 'It should be _VALID_URL'


# Generated at 2022-06-24 12:19:24.829300
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'
    print ("OK")

# Generated at 2022-06-24 12:19:33.572705
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE;
    obj = ie("https://www.pornerbros.com/embed/181369");
    assert obj._TESTS[0]['url'] == "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369";
    assert obj._TESTS[0]['md5'] == "6516c8ac63b03de06bc8eac14362db4f";
    assert obj._TESTS[0]['info_dict']['id'] == "181369";
    assert obj._TESTS[0]['info_dict']['ext'] == "mp4";

# Generated at 2022-06-24 12:19:43.968362
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import InfoExtractor
    from ..compat import compat_urllib_parse_unquote
    from ..utils import (
        parse_duration,
        parse_iso8601,
        str_to_int,
        unified_timestamp,
        url_or_none,
    )
    from ..compat import (
        compat_b64decode,
        compat_str,
    )
    from ..compat import (
        compat_urlparse,
    )
    from ..utils import (
        int_or_none,
        try_get,
        str_or_none,
    )
    assert issubclass(FuxIE, InfoExtractor)

    # test call to url_or_none

# Generated at 2022-06-24 12:19:45.389879
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == FourTubeIE.IE_NAME


# Generated at 2022-06-24 12:19:49.094060
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie._download_webpage('https://www.porntube.com/videos/video_7089759', '7089759')

# Generated at 2022-06-24 12:19:59.622684
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    a = PornTubeIE()
    b = a.url_result(url)
    c = a._real_extract(b)
    d = a._parse_json(a._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1', a._download_webpage(url, str_or_none(c['id'])), 'data', group='value'), str_or_none(c['id']), transform_source=lambda x: compat_urllib_parse_unquote(compat_b64decode(x).decode('utf-8')))

# Generated at 2022-06-24 12:20:01.870052
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    className = PornerBrosIE.name
    print("Running unit test for class " + className)
    pornerbros = PornerBrosIE()



# Generated at 2022-06-24 12:20:03.827974
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .test_fux import test_FuxIE as test_fux
    test_fux(FuxIE())


# Generated at 2022-06-24 12:20:05.553693
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
  # Test both
  with assertRaises(TypeError):
    ie1 = FourTubeBaseIE()
  ie2 = FourTubeBaseIE(1)

# Generated at 2022-06-24 12:20:11.655094
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    inst = PornTubeIE()
    assert inst._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert inst._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert inst._TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-24 12:20:17.473754
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import sys
    sys.path.insert(0, '..')
    from ytdl.extractor import PornerBrosIE
    instance = PornerBrosIE()
    instance._real_extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:20:28.043254
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_cases = (
        ('FourTubeIE', 'https://www.4tube.com/embed/video/209733'),
        ('FuxIE', 'https://www.fux.com/embed/video/195359'),
        ('PornTubeIE', 'https://www.porntube.com/embed/7089759'),
        ('PornerBrosIE', 'https://www.pornerbros.com/embed/181369'),
    )
    for ie, url in test_cases:
        info_extractor = globals()[ie]()
        video_info = info_extractor.extract(url)
        assert video_info is not None, '%s failed' % ie
        assert video_info['id'] is not None, '%s failed' % ie

# Generated at 2022-06-24 12:20:41.098828
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_utils import create_test_ie, add_ns, get_element_by_id

# Generated at 2022-06-24 12:20:45.844629
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(ie._VALID_URL, url)
    assert(mobj.group('id') == '209733')
    assert(mobj.group('display_id') == 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert(mobj.group('kind') is None)
    token_url = 'https://token.4tube.com/209733/desktop/360+480'

# Generated at 2022-06-24 12:20:53.983423
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:20:57.644716
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE()
    except NameError as e:
        if e.args[0].startswith('global name '):
            return
    raise Exception('Expected a NameError exception')

# Generated at 2022-06-24 12:21:02.813547
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
	ie = FourTubeBaseIE();
	assert(ie is not None);
	assert(ie._TKN_HOST is None);
	assert(ie.IE_NAME is not None);
	assert(ie.IE_DESC is not None);
	print('%s: IE_NAME=%s, IE_DESC=%s, IE_VERSION=%s' % (str(ie.__class__), ie.IE_NAME, ie.IE_DESC, ie.IE_VERSION));
	print('%s: _VALID_URL=%s' % (str(ie.__class__), ie._VALID_URL));

# Generated at 2022-06-24 12:21:09.184035
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-24 12:21:20.591243
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    initializer = PornerBrosIE("http://www.pornerbros.com/videos/hot-asian-has-an-orgasm-while-she-is-being-fucked_633684")
    assert initializer.host == 'token.pornerbros.com'
    assert initializer.url_template == 'https://www.pornerbros.com/videos/video_%s'
    assert initializer.regex == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert initializer._token_host == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:28.756901
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert instance._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert instance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:21:30.151672
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.__name__ == 'porntube.com'

# Generated at 2022-06-24 12:21:30.870370
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-24 12:21:40.789668
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.__name__ == 'PornTubeIE'
    assert PornTubeIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.|)'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:21:44.287142
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ft = FourTubeIE()
    ft2 = FourTubeIE() # Make sure we don't crash on second instantiation
    print(ft)
    print(ft2)



# Generated at 2022-06-24 12:21:44.754167
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:21:55.169273
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import os
    import sys
    import unittest

    from fake_useragent import UserAgent
    from youtube_dl.downloader import http
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DownloadError, encodeArgument, format_bytes



# Generated at 2022-06-24 12:22:07.289671
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube:fux'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-24 12:22:16.224591
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert 'PornerBrosIE' in globals()
    assert 'FourTubeBaseIE' in globals()
    assert PornerBrosIE != FourTubeBaseIE
    assert PornerBrosIE.IE_NAME == 'PornerBros'
    assert re.match(PornerBrosIE._VALID_URL,
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert re.match(PornerBrosIE._VALID_URL,
        'https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-24 12:22:19.086574
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE(FourTubeBaseIE)
    except Exception:
        assert(False)
    assert(True)

# Generated at 2022-06-24 12:22:20.525868
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import doctest
    doctest.testmod(FourTubeBaseIE)

# Generated at 2022-06-24 12:22:21.550580
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
        assert PornTubeIE()

# Generated at 2022-06-24 12:22:29.218298
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    PornerBrosIE(None, 'https://www.pornerbros.com/embed/181369')
    PornerBrosIE(None, 'https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')


# Generated at 2022-06-24 12:22:30.495328
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:22:42.089746
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie_test = PornTubeIE()
    url_test = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    test_dict = {
        'id': '7089759',
        'ext': 'mp4',
        'title': 'Teen couple doing anal',
        'uploader': 'Alexy',
        'uploader_id': '91488',
        'upload_date': '20150606',
        'timestamp': 1433595647,
        'duration': 5052,
        'view_count': int,
        'like_count': int,
        'age_limit': 18,
    }
    params = {'skip_download': True}
    ie_test._real_extract(url_test)



# Generated at 2022-06-24 12:22:52.425468
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTubeBaseIE', 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:22:56.487529
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four = FourTubeBaseIE()
    assert four._TKN_HOST is None
    assert four._VALID_URL is None
    assert four._URL_TEMPLATE is None


# Generated at 2022-06-24 12:22:58.314250
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Simple test of the constructor.
    """
    test_instance = FuxIE()
    assert test_instance is not None

# Generated at 2022-06-24 12:23:00.038459
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	ptube = PornTubeIE("")
	return True

# Generated at 2022-06-24 12:23:02.422144
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('pornerbros')
    return True

# Generated at 2022-06-24 12:23:07.818301
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from . import PornerBrosIE
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'

    # Test name of instance ie is 'PornerBros'
    assert PornerBrosIE.IE_NAME == 'PornerBros'


# Generated at 2022-06-24 12:23:11.730331
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    if not sys.argv[-1].startswith('http'):
        sys.exit(1)
    ie.download(sys.argv[-1])

# Generated at 2022-06-24 12:23:14.440442
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE(PornTubeIE._downloader, None)
    assert ie.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-24 12:23:26.676658
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    info = {'id': 'test', 'title': 'test', 'timestamp': 1383263892, 'uploader_id': 'test', 'like_count': 1383263892, 'uploader': 'test', 'view_count': 1383263892, 'categories': 'test', 'duration': 1383263892}
    ie.suitable('test')
    ie.extract('test')
    ie.add_default_info([info], ie._VALID_URL, ie._TESTS[0]['url'], ie._TESTS[0])
    ie.add_thumbnail([info], 'test')
    ie.add_requested_formats([info], ['test'])
    ie.add_automatic_captions([info], ['test'])
    ie.add

# Generated at 2022-06-24 12:23:30.724018
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, InfoExtractor)
    assert issubclass(FuxIE, InfoExtractor)
    assert issubclass(PornTubeIE, InfoExtractor)
    assert issubclass(PornerBrosIE, InfoExtractor)

# Generated at 2022-06-24 12:23:39.354962
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE is not None
    PornerBrosIE._VALID_URL
    PornerBrosIE._URL_TEMPLATE
    PornerBrosIE._TKN_HOST
    PornerBrosIE._TESTS
    PornerBrosIE._VALID_URL
    PornerBrosIE._URL_TEMPLATE
    PornerBrosIE._TKN_HOST
    PornerBrosIE._TESTS
    PornerBrosIE._VALID_URL
    PornerBrosIE._URL_TEMPLATE
    PornerBrosIE._TKN_HOST
    PornerBrosIE._TESTS

    # test other function
    test = PornTubeIE._real_extract(None, "url")
    assert test is not None

    test = PornTubeIE._

# Generated at 2022-06-24 12:23:43.271990
# Unit test for constructor of class FuxIE
def test_FuxIE():

    # Arrange
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = FuxIE( url )

    # Assert
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-24 12:23:44.825461
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie is not None

# Generated at 2022-06-24 12:23:55.387296
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test that PornerBrosIE class is a subclass of FourTubeIE.
    pb_ie = PornerBrosIE
    assert issubclass(PornerBrosIE, FourTubeBaseIE)
    # Test that PornerBrosIE class has four overridden methods of FourTubeIE.
    pb_methods = [name for name, obj in pb_ie.__dict__.items()
            if hasattr(pb_ie.__dict__.get(name), '__call__')]
    assert '_real_extract' in pb_methods
    assert '_VALID_URL' in pb_methods
    assert '_URL_TEMPLATE' in pb_methods
    assert '_TKN_HOST' in pb_methods
    # Test that PornerBrosIE class has

# Generated at 2022-06-24 12:23:57.413230
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class MyFourtubeBaseIE(FourTubeBaseIE):
        def __init__(self):
            FourTubeBaseIE.__init__(self)

    MyFourtubeBaseIE()

# Generated at 2022-06-24 12:24:01.602964
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    config = PornTubeIE._build_br_config()
    assert config['preferred_quality'] == '1080'
    assert '5' in config['quality_to_bitrate']
    assert '1080' in config['quality_to_bitrate']

# Generated at 2022-06-24 12:24:02.318550
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE({})

# Generated at 2022-06-24 12:24:03.406404
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIEClass = FourTubeBaseIE()

# Generated at 2022-06-24 12:24:05.606252
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbrosIE = PornerBrosIE()
    assert pornerbrosIE.IE_NAME == 'PornerBros'

# Generated at 2022-06-24 12:24:11.309733
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    
    test_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    mobj = re.match(FourTubeBaseIE._VALID_URL, test_url)
    assert mob

# Generated at 2022-06-24 12:24:15.119939
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _downloader = PornTubeIE()
    _downloader._parse_json("yo\n{\nname: \"dave\"\n}", "v0")

# Generated at 2022-06-24 12:24:21.324117
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    AE = PornerBrosIE(PornerBrosIE._NAME, PornerBrosIE._VALID_URL, PornerBrosIE._TESTS)
    
    # Test: url is array of url in _VALID_URL
    assert AE._VALID_URL == PornerBrosIE._VALID_URL

    # Test: url is the first url in _VALID_URL
    assert url == "https://" + kind

# Generated at 2022-06-24 12:24:28.093725
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    assert obj.ie_key() == 'PornTube'
    assert obj.ie_name() == 'PornTube'
    assert obj.ie_description() == 'PornTube is a pornographic video sharing website and the largest pornography site on the Internet.'
    assert obj.ie_version() != None
    assert obj.can_extract() == True
    assert obj.working() == True



# Generated at 2022-06-24 12:24:35.330112
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Simple test for PornerBrosIE()
    """
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-24 12:24:40.441512
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert obj.IE_NAME == 'Fux'
    assert obj._TKN_HOST == 'token.fux.com'
    assert obj._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-24 12:24:43.316631
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)._real_extract('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-24 12:24:54.896150
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # the test is coded for the PornerBrosIE class before
    # changes for the parent class of PornerBrosIE,
    # FourTubeBaseIE
    from .common import InfoExtractor
    from .common import ExtractorError
    from .common import ParseError
    from .common import compat_urllib_parse_urlparse

    # mock urlopen
    import __builtin__
    __builtin__.urlopen = None
    # mock compat_urllib_parse_urlparse
    __builtin__.compat_urllib_parse_urlparse = compat_urllib_parse_urlparse
    # mock compat_urllib_parse_unquote
    __builtin__.compat_urllib_parse_unquote = compat_urllib_parse_urlparse
    # mock try_get
   

# Generated at 2022-06-24 12:25:03.427968
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .test_common import mock_httpd, HTTPRequest
    from .test_4tube import *

    video_id = "181369"
    display_id = "skinny-brunette-takes-big-cock-down-her-anal-hole"

    thumbnail = "https://cdnp06.pornhub.phncdn.com/videos/201301/30/181369/original/(m=eaAaGwObaaa)8.jpg"
    duration = "1224"
    timestamp = "1359527401"

    valid_url = 'https://www.pornerbros.com/videos/' + display_id + "_" + video_id

# Generated at 2022-06-24 12:25:10.437430
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_common import FakeHttpServer
    from .common import http_server, query_dict

    http_server = http_server(FakeHttpServer)
    http_server.content_type = 'application/json'
    http_server.server_version = '' # force host to be valid
    http_server.serve_content(b'{"id": "181369", "encodings": [{"height": 720, "fileName": "http://fake.link"}]}')

    pornerbros_ie = PornerBrosIE()
    pornerbros_ie.token_url =  http_server.get_url('/181369/desktop/720')
    pornerbros_ie.host = 'host'


# Generated at 2022-06-24 12:25:11.008818
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert True


# Generated at 2022-06-24 12:25:20.575529
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """Test PornTubeIE"""
    # Test http url
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    res = PornTubeIE(url)
    assert res.url == url
    assert res.num == "7089759"
    assert res.title == "Teen couple doing anal"
    assert res.uploader == "Alexy"
    assert res.uploader_link == "http://www.porntube.com/channels/91488"
    assert res.uploader_id == "91488"
    assert res.channel == ""
    assert res.channel_link == ""
    assert res.channel_id == ""
    assert res.upload_date == "20150606"
    assert res.timestamp == "2015-06-06"

# Generated at 2022-06-24 12:25:26.625128
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..utils import expect_warnings
    with expect_warnings():
        ie = FourTubeBaseIE()
        assert ie

    with expect_warnings():
        ie = FuxIE()
        assert ie

    with expect_warnings():
        ie = PornTubeIE()
        assert ie

    with expect_warnings():
        ie = PornerBrosIE()
        assert ie

# Generated at 2022-06-24 12:25:31.880278
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == "PornTube"
    assert ie.IE_DESC == "Porn Tube"
    assert ie.__name__ == "PornTubeIE"
    assert hasattr(ie, "_VALID_URL")
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert hasattr(ie, "_TEST")
    assert len(ie._TEST) == 1
    assert hasattr(ie, "IE_NAME")
    assert ie.IE_NAME == "PornTube"
    assert hasattr(ie, "IE_DESC")
    assert ie.IE

# Generated at 2022-06-24 12:25:32.921576
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:25:43.937905
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Here we just check constructor of PornTubeIE() class
    import requests
    import json
    # We use here known video id provided by pornhub.com (it is on their home page)
    video_id = 90910
    # Create a requests session
    session = requests.Session()
    # Create a new PornTubeIE object
    _PornTubeIE = PornTubeIE()
    # Download initial webpage it will get data which will be used in following request
    initial = session.get(
        url='https://www.porntube.com/videos/sex-with-a-teen_90910',
        headers={
            # We have to add user-agent header because PornTubeIE() uses it
            'user-agent': _PornTubeIE._USER_AGENT
        }
    ).content
    # Get for us the value of INIT

# Generated at 2022-06-24 12:25:46.576311
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
      url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
      PornTubeIE()._real_extract(url)

# Generated at 2022-06-24 12:25:55.654489
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # when
    pornerbrosIE = PornerBrosIE()

    # then
    assert pornerbrosIE._TESTS[0]["url"] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    assert pornerbrosIE._TESTS[0]["md5"] == '6516c8ac63b03de06bc8eac14362db4f'
    assert pornerbrosIE._TESTS[0]["info_dict"]["id"] == '181369'
    assert pornerbrosIE._TESTS[0]["info_dict"]["ext"] == 'mp4'

# Generated at 2022-06-24 12:26:07.528356
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE(None)

    assert obj._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:26:10.915892
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_extractor = PornTubeIE('PornTubeIE', 'http://www.porntube.com/videos/video_7089759')
    assert info_extractor is not None

# Generated at 2022-06-24 12:26:13.095056
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert(isinstance(ie, InfoExtractor))