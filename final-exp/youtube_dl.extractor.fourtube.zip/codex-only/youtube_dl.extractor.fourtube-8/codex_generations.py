

# Generated at 2022-06-24 12:16:27.770941
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import FakePyppeteer
    from .extractors import get_info_extractor
    from .common import HttpServer
    from .utils import unescapeHTML

    def http_server_cb(response, headers):
        assert(response.startswith(b'http-response:'))
        response = response[len(b'http-response:'):]
        _, url, _ = response.decode('utf-8').split('\n')
        assert(url == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')


# Generated at 2022-06-24 12:16:28.483008
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('dummy')

# Generated at 2022-06-24 12:16:29.765155
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    init = PornerBrosIE()
    assert init.IE_NAME == 'PornerBros'

# Generated at 2022-06-24 12:16:36.229884
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()

    # Test for normal method
    try:
        test._real_extract(test._URL_TEMPLATE % '181369')
    except AttributeError:
        print("ERROR: _real_extract")
    try:
        test._extract_formats(
                test._URL_TEMPLATE % '181369',
                '181369',
                '181369',
                ['720', '480', '360'])
    except AttributeError:
        print("ERROR: _extract_formats")

    # Test for _TKN_HOST (str)
    assert(type(test._TKN_HOST) == str)

    # Test for _URL_TEMPLATE (str)

# Generated at 2022-06-24 12:16:45.389411
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        import json
    except ImportError:
        import simplejson as json
    from ..jsinterp import JSInterpreter

    secret = 'XcRnsRdyIpWbLddEqAKDqAZwryZ8sUWb'
    value = 'eyJ0IjoxNTUzMjUxNzUxLCJ2IjoiVmEzWnVQQ2xyM1dkc1dJZDJtWGNwVnpmZUZFbVV5dSIsImgiOiJnbnl4aGd4dW4wcjR5bDducGJzcjd1YXRpeGJ6NXEza3ZpN25jcyJ9'


# Generated at 2022-06-24 12:16:45.947745
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE



# Generated at 2022-06-24 12:16:48.897133
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE(FuxIE._download_webpage)
    assert ie.__name__ == 'Fux'
    assert ie.IE_NAME == 'Fux'

# Generated at 2022-06-24 12:16:50.182389
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.extract(ie._VALID_URL)

# Generated at 2022-06-24 12:16:53.214302
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    PornerBrosIE()._real_extract(url)

# Generated at 2022-06-24 12:17:02.783152
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    a = PornerBrosIE('test')
    assert(a.IE_NAME == 'PornerBros')
    assert(a._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
    assert(a._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s')
    assert(a._TKN_HOST == 'token.pornerbros.com')

# Test class PornerBrosIE so that PyTest can do something useful

# Generated at 2022-06-24 12:17:04.239400
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print ("[Running] test_FuxIE")


# Generated at 2022-06-24 12:17:14.967578
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE = FourTubeIE()
    assert FourTubeIE.IE_NAME == '4tube'
    assert FourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:17:17.849604
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Make sure the constructor not fails
    try:
        FourTubeBaseIE(None, '', '', None, None)
        assert False, 'FourTubeBaseIE constructor must fail'
    except AssertionError:
        pass

# Generated at 2022-06-24 12:17:21.171403
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url_test = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    video_id = '7089759'
    display_id = 'teen-couple-doing-anal'
    PornTubeIE()._VALID_URL(url_test, video_id, display_id)

# Generated at 2022-06-24 12:17:22.188581
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie is not None

# Generated at 2022-06-24 12:17:24.008118
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    sut = FourTubeBaseIE()
    assert sut is not None

# Generated at 2022-06-24 12:17:25.571265
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()

# Generated at 2022-06-24 12:17:27.287685
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-24 12:17:36.925975
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    video_id = '209733'
    display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    mobj = re.match(_VALID_URL, url)
    assert mobj.group('kind') == 'www'
    assert mobj.group('id') == video_id
   

# Generated at 2022-06-24 12:17:42.955321
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()
    # test_formats_for_url()
    # def test_formats_for_url(self):
    #     formats = ['144']
    #     sources = ','.join(formats)
    #     token_url = 'https://token.pornerbros.com/181369/desktop/' + sources
    #     self.assertEqual('https://test.test/test_id?id=test_id&sources=' + sources,
    #                      self.ie._construct_token_url('test_id', formats))

# Generated at 2022-06-24 12:17:43.898187
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
  tester = FourTubeBaseIE()

# Generated at 2022-06-24 12:17:55.937179
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-24 12:17:58.944369
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from youtube_dl.utils import unified_strdate
    assert(FourTubeIE._TESTS[0]['info_dict']['upload_date'] == unified_strdate('20131031'))

# Generated at 2022-06-24 12:18:09.689334
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    

# Generated at 2022-06-24 12:18:14.921896
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    c = PornTubeIE()
    c._search_regex(
        r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        'INITIALSTATE = \'{"page":{"video":{"title": "test"}}}',
        'data',
        group='value')

# Generated at 2022-06-24 12:18:20.557337
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """ Test constructor of class FourTubeIE. """
    FourTubeIE()

# Generated at 2022-06-24 12:18:22.178723
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    assert obj._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-24 12:18:27.302442
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-24 12:18:36.265621
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Unit test for constructor of class FourTubeIE
    """
    base_url = 'https://www.4tube.com/'
    embed_url = 'https://www.4tube.com/embed/209733'
    video = FourTubeIE()
    video._download_webpage = lambda self, url, video_id: 'test'
    video.suitable(embed_url)
    video._download_webpage = lambda self, url, video_id: 'test'
    video.suitable(base_url)

# Generated at 2022-06-24 12:18:45.627002
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import shutil
    import tempfile
    from ..cache import Cache

    def _write_fake_file(data):
        temp_dir = tempfile.mkdtemp(prefix='youtubedl_test_')
        temp_file = temp_dir + '/fake_file'

        with open(temp_file, mode='wb') as f:
            f.write(data)

        return temp_file

    # Constructor, _parse_json and _download_webpage test
    fake_json = rb'{"test": {"a": [1, 2, 3, 4, 5]}}'
    fake_url = 'https://fake.url/'
    fake_file = _write_fake_file(fake_json)

    ie = FourTubeBaseIE()
    parsed_fake_json = ie._parse_json(fake_json)

# Generated at 2022-06-24 12:18:57.176241
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .test_suite import run_test

# Generated at 2022-06-24 12:18:58.559093
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video = PornTubeIE()
    assert isinstance(video, InfoExtractor)

# Generated at 2022-06-24 12:19:00.227742
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/porn-video_1331406')

# Generated at 2022-06-24 12:19:11.491851
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    info = FourTubeBaseIE()._extract_info(url)
    assert info['id'] == '209733'
    assert info['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert info['upload_date'] == '20131031'
    assert info['timestamp'] == 1383263892
    url2 = 'http://www.4tube.com/embed/209733'
    info2 = FourTubeBaseIE()._extract_info(url2)
    assert info2['id'] == '209733'
    assert info2['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'

# Generated at 2022-06-24 12:19:19.147331
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import unittest
    from .pornhub import PornHubIE

    class TestPornTubeIE(unittest.TestCase):
        def test_constructor(self):
            pornhub_ie = PornHubIE()

            try:
                ph_url_regex = pornhub_ie._VALID_URL
                PornTubeIE._VALID_URL = ph_url_regex

                # do not raise error
                PornTubeIE()
            finally:
                PornTubeIE._VALID_URL = PornTubeIE._VALID_URL
    unittest.main()

# Generated at 2022-06-24 12:19:21.919917
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    dl = FourTubeIE()
    assert dl.IE_NAME == '4tube'
    assert FourTubeIE.__name__ == 'FourTubeIE'
    return


# Generated at 2022-06-24 12:19:23.568837
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert isinstance(instance, PornTubeIE)

# Generated at 2022-06-24 12:19:25.995511
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Here we test that the constructor does not crash
    assert FourTubeBaseIE
    assert PornerBrosIE
    assert PornTubeIE
    assert FuxIE

# Generated at 2022-06-24 12:19:26.652974
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:19:28.654462
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.ie_key() == '4tube'
    assert obj.ie_name() == '4tube'


# Generated at 2022-06-24 12:19:29.356048
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()



# Generated at 2022-06-24 12:19:32.092095
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Arrange
    fileName = 'fourtubeie.html'
    # Act
    with open(fileName) as file:
        html = file.read()
    # Assert
    assert(len(html) > 0)


# Generated at 2022-06-24 12:19:33.590863
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x1 = FourTubeBaseIE()
    assert_equal(x1._URL_TEMPLATE,None)
    assert_equal(x1._TKN_HOST,None)


# Generated at 2022-06-24 12:19:34.168493
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-24 12:19:35.287726
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE({})
    assert instance._TKN_HOST == "tkn.pornerbros.com"

# Generated at 2022-06-24 12:19:36.792982
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE("ex.com/videos/video_123", {}, {})

# Generated at 2022-06-24 12:19:37.925630
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()



# Generated at 2022-06-24 12:19:38.944170
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux != None

# Generated at 2022-06-24 12:19:44.680876
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._VALID_URL is None
    assert obj._NETRC_MACHINE is None
    assert obj._URL_TEMPLATE is None
    assert obj._TKN_HOST is None
    assert obj._TESTS is None
    assert obj._LOGIN_URL is None
    assert obj._LOGIN_REQUIRED is True

# Generated at 2022-06-24 12:19:46.404329
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from . import PornTubeIE
    global PornTubeIE
    PornTubeIE

# Generated at 2022-06-24 12:19:47.824827
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(None)

# Generated at 2022-06-24 12:19:48.252625
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE

# Generated at 2022-06-24 12:19:50.846738
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.IE_NAME
    ie.IE_DESC
    assert ie.valid_url(ie._VALID_URL, ie.IE_NAME)

# Generated at 2022-06-24 12:20:01.170268
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # The following tests were obtained by running this command on the webpage
    # https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369:
    # if (x = document.getElementById('INITIALSTATE')) {
    #   console.log(unescape(decodeURIComponent(x.innerHTML)))
    # }
    pb = PornerBrosIE()

# Generated at 2022-06-24 12:20:01.753559
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:20:02.526129
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()

# Generated at 2022-06-24 12:20:03.396703
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x = FourTubeBaseIE()

# Generated at 2022-06-24 12:20:04.382374
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()

# Generated at 2022-06-24 12:20:13.214087
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test for constructor of class FourTubeBaseIE"""
    from .common import InfoExtractor
    from .compat import compat_b64decode, compat_str, compat_urllib_parse_unquote, compat_urlparse
    from .utils import parse_duration, parse_iso8601, str_to_int, try_get, unified_timestamp, url_or_none
    import re
    import jprops
    import json
    # Create an instance
    instance = FourTubeBaseIE()
    # Check instance
    assert isinstance(instance, InfoExtractor)
    # Check class variable
    assert instance.IE_NAME == '4tube'
    # Check instance variable
    assert isinstance(instance._VALID_URL, re._pattern_type)
    assert isinstance(instance._URL_TEMPLATE, compat_str)

# Generated at 2022-06-24 12:20:14.234476
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-24 12:20:16.284194
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj._TKN_HOST

# Generated at 2022-06-24 12:20:17.671671
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    tester = PornerBrosIE()
    assert(tester._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-24 12:20:18.313006
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-24 12:20:27.577439
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None)._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE(None)._TKN_HOST == 'token.4tube.com'
    assert FuxIE(None)._TKN_HOST == 'token.fux.com'
    assert PornTubeIE(None)._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(None)._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:20:41.055743
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .videos.PornerBrosIE import PornerBrosIE
    from .compat import (compat_urllib_parse)

    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    display_id = "skinny-brunette-takes-big-cock-down-her-anal-hole"
    video_id = "181369"


# Generated at 2022-06-24 12:20:42.718868
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()



# Generated at 2022-06-24 12:20:44.468312
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornhub_ie = PornTubeIE()
    assert pornhub_ie.ie_key() == 'PornTube'

# Generated at 2022-06-24 12:20:47.649113
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert FourTubeBaseIE._parse_json(
        FourTubeBaseIE._download_webpage(
            'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
            '7089759')[1],
        '7089759')



# Generated at 2022-06-24 12:20:51.381036
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")


# Generated at 2022-06-24 12:20:53.042582
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE().extract(url)

# Generated at 2022-06-24 12:20:55.302967
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE == FourTubeIE.construct_module_class('4tube', '4tube')


# Generated at 2022-06-24 12:21:01.041948
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:04.179075
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f = FourTubeBaseIE()
    url = 'https://www.4tube.com/embed/209733'
    f._parse_json(f._download_webpage(url, '209733'), '209733')

# Generated at 2022-06-24 12:21:05.292758
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    testPornTubeIE = PornTubeIE()
    assert testPornTubeIE is not None

# Generated at 2022-06-24 12:21:12.756961
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie.IE_NAME == 'pornerbros'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:21:21.457746
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    b = FourTubeIE()
    assert b.IE_NAME == '4tube'
    assert b._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert b._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert b._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-24 12:21:34.593993
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_inputs = [
        'https://www.porntube.com/videos/video_id',
        'https://www.porntube.com/videos/video_id/',
        'https://www.porntube.com/embed/video_id',
        'https://www.porntube.com/embed/video_id/',
        'https://m.porntube.com/videos/video_id',
        'https://m.porntube.com/videos/video_id/',
        'https://www.porntube.com/videos/video_id/video_name',
        'https://www.porntube.com/embed/video_id/video_name',
        'https://m.porntube.com/videos/video_id/video_name'
    ]

# Generated at 2022-06-24 12:21:35.178977
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE = FuxIE(None)

# Generated at 2022-06-24 12:21:38.548729
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE(pornhub.PornHubIE, 'PornTube')
    assert isinstance(ie, PornTubeIE)

# Generated at 2022-06-24 12:21:49.189950
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    def fake_download_webpage(url, video_id, note=None, errnote=None, fatal=True, encoding=None, data=None, headers=None, query=None, expected_status=None):
        return b'{"page":{"video":{"mediaId":0}}}'

    ie = PornTubeIE(downloader=None)
    # a real web page is too big to be put here
    ie._download_webpage = fake_download_webpage
    with ie:
        ie.extract(u'https://www.porntube.com/videos/blablablabla_123456')

# Generated at 2022-06-24 12:21:59.033922
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE.__name__ == 'PornerBrosIE'
    assert PornerBrosIE.ie_key() == 'pornerbros'
    assert PornerBrosIE.ie_name() == 'pornerbros'

# Generated at 2022-06-24 12:22:10.501954
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .common import InfoExtractor
    from .. import _download_json

    ie = InfoExtractor()
    ie._download_json = _download_json
    ie._TKN_HOST = 'token.pornerbros.com'
    ie._URL_TEMPLATE = 'https://www.pornerbros.com/videos/video_%s'

    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(ie._VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')
    webpage = ie._download_webpage(url, display_id)


# Generated at 2022-06-24 12:22:17.501368
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test PornerBrosIE class constructor with valid url
    assert PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    # Test constructor with invalid url

# Generated at 2022-06-24 12:22:18.184237
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-24 12:22:24.006137
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    callback = PornTubeIE._build_request(PornTubeIE)
    url = 'https://www.porntube.com/embed/7089759'
    data = callback(url)
    assert data == {
        'url': 'https://www.porntube.com/videos/video_7089759',
        'note': 'Embedded video',
        'ie_key': 'PornTube',
    }

# Generated at 2022-06-24 12:22:38.746039
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert hasattr(ie, '_TESTS')
    assert re.match(ie._VALID_URL, "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black") is not None

# Generated at 2022-06-24 12:22:40.188219
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-24 12:22:42.828003
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        IE = FourTubeIE()
    except:
        return False
    else:
        return True


# Generated at 2022-06-24 12:22:52.845999
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _VALID_URL = r'https?://(?:www\.)?porntube\.com/(?:videos/[^/]+_|embed/)(\d+)'
    mobj = re.match(_VALID_URL, 'https://www.porntube.com/embed/7089759')
    p = PornTubeIE()

    # case I(video id = 7089759): video = video

# Generated at 2022-06-24 12:22:55.436477
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    testObj = PornerBrosIE()
    assert testObj is not None

# Generated at 2022-06-24 12:22:56.595611
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE(None, None)
    except Exception:
        pass

# Generated at 2022-06-24 12:23:00.849511
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:23:03.221876
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print("Unit test for constructor of class FourTubeIE")
    obj = FourTubeIE()
    assert(obj != None)

# Generated at 2022-06-24 12:23:12.115808
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE();
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'
test_FuxIE();


# Generated at 2022-06-24 12:23:17.779135
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # constuctor with url
    PornTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    # constuctor with url and extractor
    PornTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759", extractor = 0)
    # constuctor with url, extractor and downloader
    PornTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759", extractor = 0, downloader = 0)

# Generated at 2022-06-24 12:23:29.778560
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_object = PornerBrosIE()
    # test _VALID_URL
    meta_data = re.search(PornerBrosIE._VALID_URL,
                          "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    assert meta_data.group('kind') == 'www'
    assert meta_data.group('id') == '181369'
    assert meta_data.group('display_id') == 'skinny-brunette-takes-big-cock-down-her-anal-hole'
    # test _URL_TEMPLATE

# Generated at 2022-06-24 12:23:38.411176
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    pornerbrosie = PornerBrosIE()
    pornerbrosie._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    pornerbrosie._URL_TEMPLATE = 'https://www.pornerbros.com/videos/video_%s'
    pornerbrosie._TKN_HOST = 'token.pornerbros.com'
    pornerbrosie._real_extract(url)

# Generated at 2022-06-24 12:23:48.661226
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    assert FuxIE._TKN_HOST == 'token.fux.com'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-24 12:23:58.025754
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    unit = PornerBrosIE()

# Generated at 2022-06-24 12:24:00.377028
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE, type(FourTubeIE))
    assert issubclass(FuxIE, FourTubeIE)
    assert FuxIE is not FourTubeIE
    assert FuxIE.IE_NAME == 'fux.com'


# Generated at 2022-06-24 12:24:02.257986
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from . import PornTubeIE
    assert PornTubeIE.__name__ == 'PornTubeIE'

# Generated at 2022-06-24 12:24:11.593462
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    test_fux = FuxIE()
    test_data = test_fux._download_webpage(test_url, '195359')
    test_data_init = test_fux._search_regex(r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1', test_data, 'data', group='value')
    test_data_init += test_fux._search_regex(r'"state":\s*(["\'])(?P<value>(?:(?!\1).)+)\1', test_data, 'data', group='value')
    test_data_init = test_

# Generated at 2022-06-24 12:24:14.492997
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
     PornerBrosIE()

# Generated at 2022-06-24 12:24:25.289106
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_object = FourTubeBaseIE()
    assert test_object.IE_NAME == '4tube'
    assert test_object._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test_object._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test_object._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-24 12:24:30.281401
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    a = PornerBrosIE()
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    url_data = a._URL_TEMPLATE % '181369'
    assert url_data == test_url

# Generated at 2022-06-24 12:24:33.854011
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test creation of a valid PornTubeIE instance
    api = PornTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    assert api.IE_NAME in ('4tube', 'fux', 'porntube')

# Generated at 2022-06-24 12:24:37.421485
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._constructor_types_map is not None
    assert len(PornTubeIE._constructor_types_map) == 5
    for key, value in PornTubeIE._constructor_types_map.items():
        assert key == value["type"]

# Generated at 2022-06-24 12:24:45.843751
# Unit test for constructor of class FuxIE
def test_FuxIE():
    u = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fuxIE = FuxIE()
    assert fuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'
    assert fuxIE._TESTS[0]['url'] == u

# Generated at 2022-06-24 12:24:51.590112
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test first version of constructor
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    # Test second version of constructor
    assert issubclass(FuxIE, FourTubeBaseIE)
    # Test third version of constructor
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    # Test fourth version of constructor
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-24 12:24:53.225432
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    xt = FourTubeBaseIE()

# Generated at 2022-06-24 12:24:56.804801
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print ('Test for constructor of class FourTubeBaseIE')
    m = FourTubeBaseIE()
    try:
        m.get_class_name()
    except Exception as e:
        print ('Fail to pass test for constructor of class FourTubeBaseIE')
        print ('Reason: %s' %(e))
        return
    print ('Success to pass test for constructor of class FourTubeBaseIE')
    return


# Generated at 2022-06-24 12:25:03.073000
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	print("Testing 4tube.com")
	#print(FourTubeIE()._download_json('https://token.4tube.com/839846/desktop/720+480', '839846', headers={'Origin': 'https://www.4tube.com', 'Referer': 'https://www.4tube.com/videos/839846/molly-mae-the-porn-debutante'}, data=b'')

if __name__ == '__main__':
	test_FourTubeIE()

# Generated at 2022-06-24 12:25:10.416299
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test that constructor of class FuxIE throws
    # AssertionError if no argument is passed
    try:
        FuxIE()
    except AssertionError:
        pass
    else:
        assert False, 'FuxIE failed to check at least one argument is passed'
    # Test that constructor of class FuxIE raises
    # ValueError if the argument passed is of the wrong type
    try:
        FuxIE(int())
    except ValueError:
        pass
    else:
        assert False, 'FuxIE failed to check that the passed argument is of the right type'

# Generated at 2022-06-24 12:25:12.818312
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Unit test for constructor of class FourTubeIE.
    """
    FourTubeIE = FourTubeIE()
    return FourTubeIE.IE_NAME == '4tube'

# Generated at 2022-06-24 12:25:14.704575
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
    except:
        assert False, "Can't create instance of class PornTubeIE"


# Generated at 2022-06-24 12:25:21.376171
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    name_list = [
        'Fux', 'FourTube', 'PornTube', 'PornerBros', 'FourTubeBase']
    for name_1 in name_list:
        for name_2 in name_list:
            if name_1 == name_2:
                continue
            globals()[name_1 + 'IE'](
                globals()[name_2 + 'IE']()._downloader,
                None,
                'http://example.com/')

test_FourTubeBaseIE()

# Generated at 2022-06-24 12:25:32.877412
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # first use super class method to instantiate an instance of PornerBrosIE
    pornerbros_ie = PornerBrosIE()

    # then use the self-defined method to test instance of PornerBrosIE
    assert pornerbros_ie.IE_NAME == 'PornerBros'
    assert pornerbros_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerbros_ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-24 12:25:35.831415
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    description="""
    >>> from youtube_dl.extractor.porntube import PornTubeIE
    >>> PornTubeIE(None).IE_NAME
    'PornTube'
    """
    assert_test(description)

# Generated at 2022-06-24 12:25:36.626363
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # For now, only testing that the constructor doesn't crash.
    PornTubeIE()

# Generated at 2022-06-24 12:25:40.365613
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-24 12:25:42.375220
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    inst = PornerBrosIE()
    assert inst

# Generated at 2022-06-24 12:25:47.013832
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constructor = globals()["FourTubeBaseIE"]
    fourtube_base = constructor('FourTubeBaseIE')
    assert fourtube_base._VALID_URL == ''
    assert fourtube_base._URL_TEMPLATE == ''
    assert fourtube_base._TKN_HOST == ''
    assert fourtube_base._TESTS == []

# Generated at 2022-06-24 12:25:53.299851
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Tests valid and invalid urls
    # Invalid urls don't construct objects
    urls = [
        "https://www.porntube.com/videos/",
        "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    ]
    for url in urls:
        try:
            PornTubeIE(url)
        except Exception as e:
            print('Failed to construct with url: {}'.format(url), str(e))



# Generated at 2022-06-24 12:25:57.867191
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video_url = 'https://www.porntube.com/videos/japanese-mother-and-son-in-law_146695'
    PornTubeIE()._real_extract(video_url)



# Generated at 2022-06-24 12:25:59.960899
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        # pylint:disable=no-member
        object = PornTubeIE()
        object.suite()
    except TypeError as err:
        assert False, "Unexpected exception %s" % err

# Generated at 2022-06-24 12:26:01.123439
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from . import FuxIE


# Generated at 2022-06-24 12:26:07.576999
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from . import PornTubeIE as fourTubePornTubeIE
    from . import FuxIE as fourTubeFuxIE
    from . import PornerBrosIE as fourTubePornerBrosIE

    assert isinstance(FourTubeBaseIE, type)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert fourTubePornTubeIE.IE_NAME == PornTubeIE.IE_NAME
    assert fourTubeFuxIE.IE_NAME == FuxIE.IE_NAME
    assert fourTubePornerBrosIE.IE_NAME == PornerBrosIE.IE_NAME

# Generated at 2022-06-24 12:26:16.326270
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    pornerbros_ie = PornerBrosIE()
    test_webpage = pornerbros_ie._download_webpage(test_url, None)
    assert pornerbros_ie._search_regex(r'<title>([^<]+)</title>', test_webpage, \
        'title') == 'Skinny brunette takes big cock down her anal hole'