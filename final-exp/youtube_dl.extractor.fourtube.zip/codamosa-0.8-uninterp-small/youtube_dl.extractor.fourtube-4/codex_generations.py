

# Generated at 2022-06-26 11:49:56.647981
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:49:58.636553
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert isinstance(FourTubeIE(), FourTubeIE)



# Generated at 2022-06-26 11:50:00.087901
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    four_tube_i_e = FourTubeIE()


# Generated at 2022-06-26 11:50:10.926672
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE()._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(FourTubeIE()._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(FourTubeIE()._TKN_HOST == 'token.4tube.com')

# Generated at 2022-06-26 11:50:12.204730
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:13.038897
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e = FourTubeIE()

# Generated at 2022-06-26 11:50:14.067322
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:50:15.680921
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()


# Generated at 2022-06-26 11:50:17.642670
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie_instance = PornTubeIE()
    assert ie_instance.IE_NAME == '4tube'


# Generated at 2022-06-26 11:50:19.262892
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:50:46.792030
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()

# Generated at 2022-06-26 11:50:49.543119
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert four_tube_i_e_0.IE_NAME == '4tube'


# Generated at 2022-06-26 11:50:51.048364
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:53.801291
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:55.569113
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()



# Generated at 2022-06-26 11:50:57.137916
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie_0 = FuxIE()


# Generated at 2022-06-26 11:51:02.775763
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ytdl import construct_test_args
    args = construct_test_args()
    four_tube_base_i_e = FourTubeBaseIE()
    # test function _extract_formats
    four_tube_base_i_e._extract_formats(url=None, video_id=None, token_url=None, sources=None)
    # test function _real_extract
    four_tube_base_i_e._real_extract(url=args['url'])

# unit test for FourTubeIE

# Generated at 2022-06-26 11:51:04.286469
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:51:08.224429
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

if __name__ == '__main__':
    test_case_0()
    # test_FourTubeBaseIE()

# Generated at 2022-06-26 11:51:09.624775
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()

# Generated at 2022-06-26 11:51:38.769864
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-26 11:51:43.496733
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert ('4tube.com', '4tube.com') == FourTubeBaseIE('4tube')._VALID_URL



# Generated at 2022-06-26 11:51:54.502258
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    mobj = re.match(FourTubeBaseIE._VALID_URL, 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    url = FourTubeBaseIE._URL_TEMPLATE % video_id
    assert(kind == 'www')
    assert(video_id == '209733')
    assert(display_id == 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert(url == 'https://www.4tube.com/videos/209733/video')


# Generated at 2022-06-26 11:52:05.959145
# Unit test for constructor of class FuxIE
def test_FuxIE():
  assert FuxIE._TKN_HOST == "token.fux.com"
  assert FuxIE._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
  assert FuxIE._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
  assert FuxIE._TESTS[0]['info_dict']['id'] == '195359'
  assert FuxIE._TESTS[0]['info_dict']['ext'] == 'mp4'
  assert FuxIE._TESTS[0]['info_dict']['title'] == 'Awesome fucking in the kitchen ends with cum swallow'

# Generated at 2022-06-26 11:52:15.439800
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    obj = FourTubeBaseIE()

    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-26 11:52:18.407588
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    # FuxIE(url)
    video = FuxIE().extract(url)
    print(video)



# Generated at 2022-06-26 11:52:28.457141
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE()
    #data = a._download_json('https://www.4tube.com/videos/11475178/aayesha-takia-hot-kiss-scenes-with-ashmit-patel', '11475178', data=b'')
    #data = a._download_json('https://www.4tube.com/videos/11475178/aayesha-takia-hot-kiss-scenes-with-ashmit-patel', '11475178', data=b'', headers={'origin':'https://www.4tube.com', 'referer':'https://www.4tube.com/videos/11475178/aayesha-takia-hot-kiss-scenes-with-ashmit-patel'})
    #print(data)

# Generated at 2022-06-26 11:52:31.756430
# Unit test for constructor of class FuxIE
def test_FuxIE():
    inst = FuxIE()
    assert inst._TKN_HOST == 'token.fux.com'



# Generated at 2022-06-26 11:52:38.339562
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test that the PornerBrosIE constructor is able to download webpages
    # The PornerBrosIE class inherits the FourTubeBaseIE class, whose constructor
    # makes use of _download_webpage()
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    p = PornerBrosIE()
    p._download_webpage(url, '181369') # Does not raise exception

# Generated at 2022-06-26 11:52:41.786628
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-26 11:53:52.550533
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # TODO: Would be cool to move these to the test cases for each of the
    # fourtube distribution channels
    video_id = "208275"
    media_id = "71541"
    sources = ["720", "540", "480", "360", "240"]

# Generated at 2022-06-26 11:53:53.686338
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-26 11:53:55.275255
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE as unitTestObj
    fourtubeIE = unitTestObj()
    assert isinstance(fourtubeIE, unitTestObj)


# Generated at 2022-06-26 11:53:56.624485
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    isinstance(PornerBrosIE(), FourTubeBaseIE)
    isinstance(PornerBrosIE(), FourTubeBaseIE)

# Generated at 2022-06-26 11:53:57.720135
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None, 'https://www.pornerbros.com/embed/181369')

# Generated at 2022-06-26 11:54:04.349394
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == FourTubeIE._VALID_URL
    assert FuxIE._URL_TEMPLATE == FourTubeIE._URL_TEMPLATE
    assert FuxIE._TKN_HOST == FourTubeIE._TKN_HOST
    assert FuxIE._TESTS == FourTubeIE._TESTS

# Generated at 2022-06-26 11:54:05.320440
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-26 11:54:06.304703
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-26 11:54:09.065704
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_ie = FourTubeBaseIE()

    assert four_tube_base_ie.ie_key() == '4tube'
    assert four_tube_base_ie._TESTS == []
    assert four_tube_base_ie._VALID_URL == r'(?!)'
    assert four_tube_base_ie._TKN_HOST == '(?!)'
    assert four_tube_base_ie._URL_TEMPLATE == '(?!)'

# Generated at 2022-06-26 11:54:09.656034
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()

# Generated at 2022-06-26 11:56:31.526893
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..compat import unittest
    from ..utils import FakeHttpResponse

    class FakeUrlOpener(object):
        def __init__(self, data=''):
            self.data = data

        def __call__(self, req):
            # The following is an example of the 'token server' response
            # XXX: Use the example response of some useful video, e.g.
            # https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black
            data = self.data.encode('utf-8')
            return FakeHttpResponse(
                200, data, {'Content-Type': 'application/json'},
                compat_str(req.url))


# Generated at 2022-06-26 11:56:35.203360
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTubeIE = FourTubeIE()
    assert (fourTubeIE.__class__.__name__ == 'FourTubeIE')


# Generated at 2022-06-26 11:56:36.988971
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE("https://www.pornerbros.com")

# Generated at 2022-06-26 11:56:43.150815
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert FuxIE()._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-26 11:56:44.618764
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')

# Generated at 2022-06-26 11:56:51.885892
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .. import YoutubeDL
    ydl = YoutubeDL()

    FuxIE(ydl)._real_extract(url='https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow')
    PornTubeIE(ydl)._real_extract(url='https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    PornerBrosIE(ydl)._real_extract(url='https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-26 11:56:59.578165
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert str(ie) == 'PornerBrosIE'

# Generated at 2022-06-26 11:57:05.080736
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    klass = FourTubeBaseIE
    info = klass._TESTS[0]
    url = info['url']
    print(url)
    obj = klass()
    result = obj._real_extract(url)
    print(result)
    assert result is not None

# Generated at 2022-06-26 11:57:06.086401
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:57:07.598842
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()