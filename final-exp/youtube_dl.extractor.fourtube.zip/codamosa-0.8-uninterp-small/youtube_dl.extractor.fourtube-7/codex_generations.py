

# Generated at 2022-06-26 11:49:58.760856
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:50:00.184499
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_0 = FourTubeIE()

# Generated at 2022-06-26 11:50:02.041857
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:03.854644
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:50:05.288595
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie_0 = PornTubeIE()



# Generated at 2022-06-26 11:50:06.717907
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_1 = FourTubeIE()


# Generated at 2022-06-26 11:50:08.240928
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:50:09.910579
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:11.262471
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:50:12.433935
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:27.569786
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:50:28.994485
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:30.272565
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:50:32.138852
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f_u_x_i_e = FuxIE()


# Generated at 2022-06-26 11:50:33.413356
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    four_tube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:34.201351
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_i_e_1 = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:35.481728
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:50:36.880186
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert FourTubeBaseIE()._TKN_HOST is not None

# Generated at 2022-06-26 11:50:41.137637
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()
    assert _VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'


# Generated at 2022-06-26 11:50:42.275885
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:51:20.390514
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert four_tube_i_e_0.IE_NAME == '4tube'
    assert four_tube_i_e_0._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert four_tube_i_e_0._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert four_tube_i_e_0._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:51:21.912634
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:22.820744
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-26 11:51:23.992997
# Unit test for constructor of class FuxIE
def test_FuxIE():
    four_tube_i_e_1 = FuxIE()


# Generated at 2022-06-26 11:51:26.928723
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'


# Generated at 2022-06-26 11:51:28.057190
# Unit test for constructor of class FuxIE
def test_FuxIE():
    four_tube_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:51:29.748648
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()



# Generated at 2022-06-26 11:51:39.743448
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()
    assert porner_bros_i_e._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert porner_bros_i_e._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert porner_bros_i_e._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:51:42.647536
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:51:44.721757
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()

# Generated at 2022-06-26 11:52:17.111084
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	unitTest = FourTubeIE()
	print(unitTest)

# Generated at 2022-06-26 11:52:19.531607
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    FuxIE(FuxIE.ie_key())._real_extract(url)


# Generated at 2022-06-26 11:52:28.852506
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test that the YoutubeIE constructor raises a RegexNotFoundError
    # exception when the regex does not match
    with pytest.raises(RegexNotFoundError):
        PornerBrosIE(FakeYoutubeIE, 'invalid_url')

    # Test that the YoutubeIE constructor does not raise an exception
    # when the regex matches.
    ie = PornerBrosIE(FakeYoutubeIE, 'https://www.pornerbros.com/embed/181369')
    assert isinstance(ie, PornerBrosIE)
    assert ie.suitable('https://www.pornerbros.com/embed/181369')
    assert not ie.suitable('https://www.yahoo.com/embed/181369')

# Generated at 2022-06-26 11:52:31.535486
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    m = PornerBrosIE(InfoExtractor())
    assert m.IE_NAME == 'PornerBros'

# Generated at 2022-06-26 11:52:34.245180
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    m = PornerBrosIE()
    assert m.IE_NAME == 'PornerBros'


# Generated at 2022-06-26 11:52:37.851207
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    cls = globals()['FourTubeBaseIE']
    cls('FourTube', '4tube.com')
    cls('Fux', 'fux.com')
    cls('PornTube', 'porntube.com')
    cls('PornerBros', 'pornerbros.com')

# Generated at 2022-06-26 11:52:40.209810
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'FuxIE'

# Generated at 2022-06-26 11:52:52.292849
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    headers={'Origin': 'https://www.porntube.com',
            'Referer': 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'}
    assert headers == FourTubeBaseIE()._download_json(
        'https://tkn.porntube.com/181369/desktop/400%7C600%7C900%7C1300%7C1800', '181369', data=b'',
        headers={'Origin': 'https://www.porntube.com',
                 'Referer': 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'})

# Generated at 2022-06-26 11:52:53.037003
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert instance is not None

# Generated at 2022-06-26 11:53:06.140340
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from . import commontest
    from .generic import GenericIE
    from .common import InfoExtractor

    class _MacroIE(FourTubeBaseIE):
        IE_NAME = 'macro'
        _VALID_URL = r'http://.+'

        def _real_extract(self, url):
            return {'id': 'macro'}

    instance = _MacroIE("TEST", "TEST")
    if not isinstance(instance, InfoExtractor):
        raise Exception("%s is not an instance of InfoExtractor", repr(instance))
    if not isinstance(instance, GenericIE):
        raise Exception("%s is not an instance of GenericIE", repr(instance))

    # test _real_initialize
    commontest.test_real_initialize(instance)

    # test _real_ext

# Generated at 2022-06-26 11:54:22.842814
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:54:24.933013
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None, 'test')
    assert ie is not None

# Generated at 2022-06-26 11:54:29.016568
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE(None, None)
        assert False, 'this test should fail'
    except TypeError:
        assert True

# Generated at 2022-06-26 11:54:34.185054
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-26 11:54:43.568721
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    names = globals().keys()
    for name in names:
        if name.endswith('IE'):
            globals()[name]._TESTS = []

# Generated at 2022-06-26 11:54:53.768430
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	try:
		testObj = FourTubeIE()
		testObj.IE_NAME
		testObj._VALID_URL
		testObj._URL_TEMPLATE
		testObj._TKN_HOST
		testObj._TESTS
		testObj._extract_formats
		testObj._real_extract
	except Exception as e: 
		print (e)
		raise Exception("4TubeIE Unit Testing Failure")


# Generated at 2022-06-26 11:54:59.411279
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369', {'skip_download': True})

# Generated at 2022-06-26 11:55:07.676103
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_FourTube = FourTubeIE()
    assert test_FourTube.IE_NAME == '4tube'
    assert test_FourTube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test_FourTube._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test_FourTube._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-26 11:55:13.999717
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-26 11:55:17.222411
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import re
    match = re.match(PornTubeIE._VALID_URL, 'https://www.porntube.com/embed/7089759')
    kind = match.group('kind')
    assert kind == 'www'
    video_id = match.group('id')
    assert video_id == '7089759'
    display_id = match.group('display_id')
    assert display_id == 'teen-couple-doing-anal'



# Generated at 2022-06-26 11:58:32.883554
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .common import FORMAT
    from .youtube import YoutubeIE
    porn_tube_ie = PornTubeIE()
    if "4tube.com/embed" in porn_tube_ie._TESTS[0]['url']:
        porn_tube_ie._TESTS[0]['url'] = str.replace(porn_tube_ie._TESTS[0]['url'], "4tube.com/embed", "porntube.com/embed")
    porn_tube_ie._TESTS[0]['url'] = "https://www.porntube.com/videos/today_most_viewed_all_time"
    info_dict = porn_tube_ie.extract(porn_tube_ie._TESTS[0]['url'])

# Generated at 2022-06-26 11:58:44.403507
# Unit test for constructor of class FuxIE

# Generated at 2022-06-26 11:58:47.576973
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """PornTubeIE can not be constructed directly."""
    with pytest.raises(TypeError):
        PornTubeIE()

# Generated at 2022-06-26 11:58:49.763356
# Unit test for constructor of class FuxIE
def test_FuxIE():
    _constructor_test_suite(FuxIE, FuxIE._VALID_URL)


# Generated at 2022-06-26 11:58:56.753865
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    InfoExtractor(url).name == '4tube'

# Generated at 2022-06-26 11:58:57.302272
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-26 11:59:01.622673
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Mocking InfoExtractor class
    class InfoExtractor(object):
        def __init__(self, *args, **kwargs):
            pass

    f = FourTubeBaseIE()
    assert isinstance(f, InfoExtractor)

# Generated at 2022-06-26 11:59:10.525540
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    # assert FuxIE()._TKN_HOST == 'token.fux.com'
    # assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    # assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:59:16.239350
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    #test_website_ie('PornTube')
    #test_website_ie('PornTube', 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    #test_website_ie('PornTube', 'https://www.porntube.com/embed/7089759')
    #test_website_ie('PornTube', 'https://m.porntube.com/videos/teen-couple-doing-anal_7089759')
    pass

if __name__ == '__main__':
    test_PornTubeIE()

# Generated at 2022-06-26 11:59:25.749629
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    # Make sure __init__ is called correctly
    assert obj.name == '4tube'
    assert obj.IE_NAME == '4tube'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'