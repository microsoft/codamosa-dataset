

# Generated at 2022-06-26 11:49:59.635887
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()

test_case_0()

# Generated at 2022-06-26 11:50:01.088293
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e = FourTubeIE()


# Generated at 2022-06-26 11:50:02.969859
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_obj = PornerBrosIE()

# Generated at 2022-06-26 11:50:05.234189
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Constructor with no parameter
    try:
        FourTubeBaseIE()
    except:
        assert False


# Generated at 2022-06-26 11:50:10.927830
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE in four_tube_base_i_e_0.test_case_test_PornTubeIE.__bases__

# Generated at 2022-06-26 11:50:11.765867
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-26 11:50:12.850940
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert(FourTubeBaseIE() != None)


# Generated at 2022-06-26 11:50:15.594596
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from youtube_dl.extractor.fourtube import FourTubeIE
    # Instance of FourTubeIE
    four_tube_i_e = FourTubeIE()


# Generated at 2022-06-26 11:50:17.177669
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:50:18.867942
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    Porner_Bros_IE_0 = PornerBrosIE()


# Generated at 2022-06-26 11:50:43.371011
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:50:48.301478
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    # _VALID_URL is not defined in this file
    assert ie._VALID_URL is None
    assert ie._TESTS == []
    assert ie._URL_TEMPLATE is None
    assert ie._TKN_HOST is None

# Generated at 2022-06-26 11:50:54.172588
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube', 'http://www.example.com')
    assert ie.ie_key() == 'FourTube'
    assert ie.suitable('http://www.example.com')
    assert ie.SUITABLE == 'universal'
    assert ie.working == True
    assert ie.website_url() == 'http://www.example.com'

# Generated at 2022-06-26 11:50:55.422739
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-26 11:51:03.607674
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # In Python 3.4 and later, we can use:
    # from collections.abc import Callable
    # isinstance(PornTubeIE, Callable)
    try:
        callable(PornTubeIE)
    except NameError:
        pass
    else:
        assert callable(PornTubeIE), "The class should be callable"

    # From Python 3.3.3 the class is an instance of type
    assert type(PornTubeIE)
    assert isinstance(PornTubeIE, type), "The class should be an instance of type"

    # In Python 3.4 and later, we can use:
    # from collections.abc import Callable
    # isinstance(PornTubeIE(), Callable)
    try:
        callable(PornTubeIE())
    except NameError:
        pass

# Generated at 2022-06-26 11:51:09.475330
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    expected_regex = re.compile(ie._VALID_URL)
    assertPornerBrosIE = (
        ie._VALID_URL == expected_regex.pattern
    )

    # assert
    assert assertPornerBrosIE is True

# Generated at 2022-06-26 11:51:12.812615
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE("https://www.porntube.com/videos/tiny-blonde-jenna-rides-a-cock-in-her-schoolgirl-outfit_219529")


# Generated at 2022-06-26 11:51:23.424766
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_dict = dict()
    test_dict['url'] = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    test_dict['info_dict'] = {
            'id': '7089759',
            'ext': 'mp4',
            'title': 'Teen couple doing anal',
            'uploader': 'Alexy',
            'uploader_id': '91488',
            'upload_date': '20150606',
            'timestamp': 1433595647,
            'duration': 5052,
            'view_count': int,
            'like_count': int,
            'age_limit': 18,
        }
    test_dict['params'] = {
            'skip_download': True,
        }
    PornTubeIE()._real

# Generated at 2022-06-26 11:51:26.585957
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE == PornerBrosIE._build_ie().ie_key()


# Generated at 2022-06-26 11:51:27.442646
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-26 11:52:04.667178
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_url = 'https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(FourTubeBaseIE._VALID_URL, test_url)
    assert mobj

    assert mobj.group('kind') == 'm'
    assert mobj.group('id') == '181369'
    assert mobj.group('display_id') == 'skinny-brunette-takes-big-cock-down-her-anal-hole'

# Generated at 2022-06-26 11:52:09.874811
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Constructor should not throw any exception
    FourTubeBaseIE()
    FuxIE()
    PornTubeIE()
    PornerBrosIE()
    FourTubeIE()

# Generated at 2022-06-26 11:52:11.911857
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    with pytest.raises(AssertionError):
        FourTubeBaseIE()

# Generated at 2022-06-26 11:52:20.083271
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Tests for FuxIE
    info_dict = {
        'id': '195359',
        'ext': 'mp4',
        'title': 'Awesome fucking in the kitchen ends with cum swallow',
        'uploader': 'alenci2342',
        'uploader_id': 'alenci2342',
        'upload_date': '20131230',
        'timestamp': 1388361660,
        'duration': 289,
        'view_count': int,
        'like_count': int,
        'categories': list,
        'age_limit': 18,
    }
    test_ie = FuxIE(info_dict)
    assert test_ie.title == info_dict['title']
    assert test_ie.description == ''

# Generated at 2022-06-26 11:52:22.390141
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest
    self = FuxIE()
    unittest.main()

# Generated at 2022-06-26 11:52:25.131712
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert obj.IE_NAME == 'PornerBros'
    assert obj._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-26 11:52:36.156169
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)

    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:52:49.281614
# Unit test for constructor of class FuxIE
def test_FuxIE():
    result = FuxIE()
    assert result._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert result._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert result._TKN_HOST == 'token.fux.com'
    #assert result._TESTS == [{'url': 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow', 'info_dict': {'duration': 289, 'upload_date': '20131230', 'title': 'Awesome fucking in the kitchen ends

# Generated at 2022-06-26 11:52:59.923071
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Calling the constructor with required arguments
    try:
        fourTubeBaseIE = FourTubeBaseIE(None, {})
    except Exception as exception:
        print("Failed to call constructor of class FourTubeBaseIE with required arguments: " + str(exception))

    # Calling the constructor with required arguments and an optional argument with a bad argument
    try:
        fourTubeBaseIE = FourTubeBaseIE(None, {}, badArgument='badArgument')
    except Exception as exception:
        print("Failed to call constructor of class FourTubeBaseIE with bad optional argument: " + str(exception))

    # Calling the constructor with required arguments and an optional argument

# Generated at 2022-06-26 11:53:01.947771
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert PornTubeIE is not None

# Generated at 2022-06-26 11:54:17.130610
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	PornerBrosIE(PornerBrosIE.IE_NAME, True)

# Generated at 2022-06-26 11:54:30.531001
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for ie_type in ['FourTubeIE', 'FuxIE', 'PornTubeIE', 'PornerBrosIE']:
        ie_class = globals()[ie_type]
        ie_instance = ie_class()
        ie_type_name = ie_instance.IE_NAME
        assert ie_type == ie_type_name
        ie_id = ie_instance.ie_key()
        assert ie_type_name == ie_id
        url_test_case = ie_instance._TESTS[0]
        url = url_test_case['url']
        valid_url = ie_instance._VALID_URL
        url_mobj = re.match(valid_url, url)
        assert url_mobj
        url_groups = url_mobj.groupdict()
        assert url_groups['id']

# Generated at 2022-06-26 11:54:32.564804
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()

# Generated at 2022-06-26 11:54:38.677084
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    FourTubeBaseIE.__module__ = 'youtube_dl.extractor.pornerbros'
    PornerBrosIE.__module__ = 'youtube_dl.extractor.pornerbros'
    PornerBrosIE(FourTubeBaseIE)
    print(PornerBrosIE._VALID_URL)

# Generated at 2022-06-26 11:54:42.491353
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
	global ie
	ie = FourTubeBaseIE()
	assert(ie.IE_NAME)
	assert(ie._VALID_URL)
	assert(ie._URL_TEMPLATE)
	assert(ie._TKN_HOST)
	assert(ie._TESTS)

# Generated at 2022-06-26 11:54:52.950724
# Unit test for constructor of class FuxIE
def test_FuxIE():
	test_cases = [
		("https://www.fux.com/embed/195359", "FuxIE"),
		("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow", "FuxIE")
	]
	for url, ext in test_cases:
		ie = _download_webpage(url, 195359)
		assert ie == ext

# Generated at 2022-06-26 11:54:54.476183
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    f = PornTubeIE()

# Generated at 2022-06-26 11:55:02.144472
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Should succeed
    FourTubeIE()

    # Should fail
    try:
        FourTubeIE({'bad_key': 'bad_value'})
    except TypeError:
        pass
    except:
        raise AssertionError("Did not raise TypeError")
    else:
        raise AssertionError("Did not raise TypeError")

# Generated at 2022-06-26 11:55:08.691189
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie_object = PornerBrosIE()
    assert pornerbros_ie_object._TKN_HOST == 'token.pornerbros.com'
    assert pornerbros_ie_object._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerbros_ie_object._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-26 11:55:11.250443
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .pornerbros import PornerBrosIE
    assert PornerBrosIE('')



# Generated at 2022-06-26 11:58:11.706067
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-26 11:58:21.881684
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_PornTubeIE.video_id = '7089759'
    test_PornTubeIE.url = 'https://www.porntube.com/videos/teen-couple-doing-anal_' + test_PornTubeIE.video_id
    test_PornTubeIE.player_js_url = '//cdn1.porntube.com/assets/player/v2/build/player-en_US.js?v=15'
    test_PornTubeIE.player_js_txt = test_PornTubeIE.download(test_PornTubeIE.player_js_url, 'js', 'player-en_US.js')

# Generated at 2022-06-26 11:58:27.210580
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    extractor = FourTubeIE()
    assert(extractor._VALID_URL)
    assert(extractor._URL_TEMPLATE)
    assert(extractor._TKN_HOST)
    assert(extractor._TESTS)


# Generated at 2022-06-26 11:58:34.455670
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # This URL is a channel
    url='https://fux.com/channels/16432/playboy-tv'
    fux = FuxIE()
    result = fux._real_extract(url)
    assert type(result) == dict
    assert result['title'] == 'Playboy TV'
    assert 'videos' in result
    assert type(result['videos']) == list

    # This URL is a video
    url='https://fux.com/videos/72/real-life-girlfriend-sucks-and-fucks-for-a-creampie'
    fux = FuxIE()
    result = fux._real_extract(url)
    assert type(result) == dict
    assert 'videos' not in result

# Generated at 2022-06-26 11:58:44.982941
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-26 11:58:53.611207
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Testing constructor of PornerBrosIE
    # Constructor is tested by checking if the instance has the class variables from this class
    # Instance is made using the class and validated using hasattr
    # Constructor is called using the class and instance is stored in a variable
    # Instance is validated by checking variable against hasattr
    pb_instance = PornerBrosIE()
    assert hasattr(pb_instance, '_VALID_URL') == hasattr(pb_instance, '_VALID_URL')
    assert hasattr(pb_instance, '_URL_TEMPLATE') == hasattr(pb_instance, '_URL_TEMPLATE')
    assert hasattr(pb_instance, '_TKN_HOST') == hasattr(pb_instance, '_TKN_HOST')

# Generated at 2022-06-26 11:58:57.444820
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    assert obj.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-26 11:59:00.656435
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    ie = FuxIE()
    assert ie.IE_NAME == 'fux'
    ie = PornTubeIE()
    assert ie.IE_NAME == 'porntube'
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'

# Generated at 2022-06-26 11:59:02.557154
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE('http://www.fux.com/video/209733/awesome-fucking-kitchen-ends-cum-swallow')


# Generated at 2022-06-26 11:59:14.686515
# Unit test for constructor of class FourTubeBaseIE