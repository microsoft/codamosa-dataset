

# Generated at 2022-06-26 11:49:59.925058
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBros_i_e = PornerBrosIE()
    assert pornerBros_i_e.name == 'pornerbros'


# Generated at 2022-06-26 11:50:02.969578
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    assert fux_i_e._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-26 11:50:10.269717
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE.ie_name() == 'pornerbros.com'
    assert pornerBrosIE.ie_key() == 'pornerbros'
    assert pornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'


# Generated at 2022-06-26 11:50:13.747846
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert hasattr(obj, '_VALID_URL') == True
    assert hasattr(obj, '_URL_TEMPLATE') == True
    assert hasattr(obj, '_TKN_HOST') == True
    assert hasattr(obj, '_TESTS') == True


# Generated at 2022-06-26 11:50:15.088715
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:17.593499
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    F_T_IE = FourTubeIE()
    assert F_T_IE
    assert F_T_IE.IE_NAME == '4tube'

# Generated at 2022-06-26 11:50:27.485656
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None)._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeBaseIE(None)._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE(None)._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeBaseIE(None).IE_NAME == '4tube'

# Generated at 2022-06-26 11:50:29.981645
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()
    fux_i_e_1 = FuxIE()
    fux_i_e_2 = FuxIE()

# Generated at 2022-06-26 11:50:31.701431
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fb = FourTubeBaseIE()
    assert fb is not None


# Generated at 2022-06-26 11:50:32.845672
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    a = PornerBrosIE()

# Generated at 2022-06-26 11:51:01.041207
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    p_b_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:02.987694
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().test_case_0() == FuxIE.test_case_0.__doc__

# Generated at 2022-06-26 11:51:04.434753
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_ie_inst = FourTubeIE()



# Generated at 2022-06-26 11:51:07.464836
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:51:08.893886
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:51:10.293520
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()



# Generated at 2022-06-26 11:51:11.984342
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:13.886280
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constr = FourTubeBaseIE()
    assert isinstance(constr, InfoExtractor)


# Generated at 2022-06-26 11:51:15.383068
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-26 11:51:17.493323
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    fux_i_e.expect_no_exception()


# Generated at 2022-06-26 11:52:12.423634
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	pornerbros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:52:14.493306
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        import urllib3
    except ImportError:
        return
    porntube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:52:19.718479
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()

if __name__ == '__main__':
    test_case_0()
    test_PornerBrosIE()

# Generated at 2022-06-26 11:52:22.017242
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:52:24.072242
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # This one is not as much a test as a demonstration of interface.
    PornTubeIE()

# Generated at 2022-06-26 11:52:26.032520
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_iE = PornerBrosIE()


# Generated at 2022-06-26 11:52:29.078576
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e = FourTubeBaseIE(None)

# Generated at 2022-06-26 11:52:34.765307
# Unit test for constructor of class FuxIE
def test_FuxIE():
    arg_0 = "https://www.fux.com/video/202796/busty-bible-babe-fucked-hard-in-her-perfect-ass"
    fux_i_e_0 = FuxIE(arg_0)


# Generated at 2022-06-26 11:52:35.390931
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-26 11:52:38.085199
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-26 11:54:45.827747
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourtube_base_i_e = FourTubeBaseIE()
    assert fourtube_base_i_e is not None


# Generated at 2022-06-26 11:54:47.974229
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()


# Generated at 2022-06-26 11:54:51.320791
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e = FourTubeBaseIE()


# Generated at 2022-06-26 11:54:55.435985
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

if __name__ == '__main__':
    test_FourTubeIE()

# Generated at 2022-06-26 11:54:57.354879
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-26 11:55:00.506863
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE().__class__.__name__ == 'PornerBrosIE'

# Generated at 2022-06-26 11:55:03.665106
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'FuxIE'
    assert FuxIE.__doc__ ==  'FuxIE'


# Generated at 2022-06-26 11:55:17.183616
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_1 = FuxIE()
    assert fux_i_e_1.IE_NAME=='4tube'
    assert fux_i_e_1.URL_TEMPLATE=='https://www.fux.com/video/%s/video'
    assert fux_i_e_1.TKN_HOST=='token.fux.com'
    assert fux_i_e_1.VALID_URL==re.compile(r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')

# Generated at 2022-06-26 11:55:29.186635
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    result = pornerbros_i_e._real_extract(url)

# Generated at 2022-06-26 11:55:31.233187
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:58:44.616420
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
   _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
   url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
   o = PornTubeIE()
   mobj = re.match(_VALID_URL, url)
   video_id, display_id = mobj.group('id', 'display_id')
   webpage = o._download_webpage(url, display_id)

# Generated at 2022-06-26 11:58:46.104541
# Unit test for constructor of class FuxIE
def test_FuxIE():
    global FuxIE
    FuxIE(None)

# Generated at 2022-06-26 11:58:54.202564
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import unittest
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert PornTubeIE.IE_NAME == 'PornTube'
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-26 11:58:58.662021
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import sys
    sys.path.insert(0, '..')
    from ytdl.extractor import PornTubeIE
    PornTubeIE()

# Generated at 2022-06-26 11:59:00.812838
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    model = FourTubeIE()
    pass



# Generated at 2022-06-26 11:59:01.382452
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-26 11:59:14.137682
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    ie = FuxIE()
    ie._download_webpage = lambda url : url
    info = ie._real_extract(url)

# Generated at 2022-06-26 11:59:22.485817
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
  # Unit testing is much better than this.
  try:
    dummy = FourTubeBaseIE()
  except:
    raise AssertionError("Could not construct FourTubeBaseIE")

# Main program
if __name__ == '__main__':
  print("Running unit tests...")
  test_FourTubeBaseIE()
  print("Sucess.")

# Generated at 2022-06-26 11:59:24.204398
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    constructor = PornTubeIE if PornTubeIE is not None else object
    constructor(PornTubeIE.IE_NAME, PornTubeIE._TESTS)

# Generated at 2022-06-26 11:59:29.453971
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TESTS[0].get('url', '') == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'