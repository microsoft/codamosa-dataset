

# Generated at 2022-06-26 11:49:58.999177
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:00.042393
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornTube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:50:01.875975
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:03.701279
# Unit test for constructor of class FuxIE
def test_FuxIE():
	fux_i_e_0 = FuxIE()
	return fux_i_e_0


# Generated at 2022-06-26 11:50:04.762949
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()


# Generated at 2022-06-26 11:50:06.220430
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()



# Generated at 2022-06-26 11:50:06.878002
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FuxIE()

# Generated at 2022-06-26 11:50:09.816855
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # default constructor
    fourTube_i_e = FourTubeIE()
    # pass url to constructor
    fourTube_i_e = FourTubeIE('url')


# Generated at 2022-06-26 11:50:10.953951
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:12.339437
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FOUR_TUBE_BASE_I_E_0 = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:42.361022
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert 'fux.com' in FuxIE._VALID_URL
    assert '4tube.com' in FourTubeIE._VALID_URL

# Generated at 2022-06-26 11:50:43.865696
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBros = PornerBrosIE()


# Generated at 2022-06-26 11:50:45.480925
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:46.567661
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pt = PornTubeIE()


# Generated at 2022-06-26 11:50:49.314926
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb_i_e = PornerBrosIE()
    return pb_i_e


# Generated at 2022-06-26 11:50:50.818012
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:53.184423
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:50:57.419580
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()
    porner_bros_i_e_1 = PornerBrosIE()
    assert porner_bros_i_e_0 == porner_bros_i_e_1


# Generated at 2022-06-26 11:51:03.580318
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    if ( isinstance(fux_i_e, object)
         and issubclass(type(fux_i_e), object)
         and isinstance(fux_i_e, FourTubeBaseIE)
         and issubclass(type(fux_i_e), FourTubeBaseIE)
         and isinstance(fux_i_e, InfoExtractor)
         and issubclass(type(fux_i_e), InfoExtractor)):
        print('constructor test passed.')
    else:
        print('constructor test failed.')


# Generated at 2022-06-26 11:51:07.465000
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_i_e = FourTubeIE()
    assert(str(fourtube_i_e) == '<FourTubeIE>')


# Generated at 2022-06-26 11:51:40.172328
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE(FuxIE.IE_NAME, FuxIE.ie._VALID_URL)
    except AssertionError:
        pass
    else:
        assert False, 'FuxIE constructor should raise AssertionError'

# Generated at 2022-06-26 11:51:43.570446
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    assert issubclass(FourTubeIE, InfoExtractor)

# Generated at 2022-06-26 11:51:51.497700
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert(FuxIE._VALID_URL.find('fux.com')==8)
    assert(FuxIE._URL_TEMPLATE.find('www.fux.com')==9)
    assert(FuxIE._TKN_HOST.find('token.fux.com')==0)
    assert(FuxIE._TESTS[0]['url'].find('www.fux.com')==8)

# Generated at 2022-06-26 11:51:54.027492
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # constructor shouldn't throw an exception
    FuxIE()


# Generated at 2022-06-26 11:51:59.193567
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    return PornerBrosIE()._real_extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-26 11:52:02.550264
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
    except NameError as e:
        assert False, "FuxIE() raises NameError"
    assert True


# Generated at 2022-06-26 11:52:10.004839
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE(PornTubeIE.IE_NAME, PornTubeIE._VALID_URL, PornTubeIE._TESTS)
    FourTubeBaseIE(PornerBrosIE.IE_NAME, PornerBrosIE._VALID_URL, PornerBrosIE._TESTS)

# Generated at 2022-06-26 11:52:16.766514
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    t = FourTubeIE()
    assert t._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos/|embed/)(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert t._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert t._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:52:19.362339
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Check class FourTubeIE constructor
    """
    assert FourTubeIE()



# Generated at 2022-06-26 11:52:25.564686
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .. import FuxIE
    fux = FuxIE()

    data = {'total_size': 1, 'formats': []}
    fux._extract_formats('http://www.google.com', '1', '2', data['formats'])
    assert "downloading token info" in [x.desc for x in data['formats']]

# Generated at 2022-06-26 11:53:31.141113
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = FourTubeBaseIE.return_class('Fux')
    assert i.IE_NAME == '4tube:fux'



# Generated at 2022-06-26 11:53:33.765941
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE._TESTS[0] == FourTubeIE._TESTS[0])

# Generated at 2022-06-26 11:53:34.830844
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-26 11:53:37.763244
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    assert pornerbros.IE_NAME == 'pornerbros'

# Generated at 2022-06-26 11:53:49.868782
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print('testing FourTubeIE()')
    _FourTubeIE = FourTubeIE('FourTubeIE','FourTube','four','tube','http','https','www',
        'm','videos','embed','\d+','[^/?#&]+',
        'https://www.4tube.com/videos/%s/video','token.4tube.com')
    assert _FourTubeIE.name == '4tube'
    assert _FourTubeIE.ie_key == '4tube'
    assert _FourTubeIE.host == '4tube'
    assert _FourTubeIE.domain == '4tube'
    assert _FourTubeIE.http_scheme == 'http'
    assert _FourTubeIE.https_scheme == 'https'
    assert _FourTubeIE.www_host == 'www'
    assert _FourTubeIE.mobile_host

# Generated at 2022-06-26 11:53:52.463917
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-26 11:53:53.353348
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert isinstance(PornerBrosIE, FourTubeBaseIE)



# Generated at 2022-06-26 11:53:55.358745
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_URL_TEMPLATE')
    assert hasattr(ie, '_TKN_HOST')



# Generated at 2022-06-26 11:53:56.285349
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import PornTubeIE
    PornTubeIE.PornTubeIE()


# Generated at 2022-06-26 11:54:05.380193
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://m.porntube.com/videos/teen-couple-doing-anal_7089759'
    FourTubeBaseIE._TESTS.append({
        'url': url,
        'only_matching': True,
    })
    # check for valid regural expression
    valid_regex = re.match(FourTubeBaseIE._VALID_URL, url)
    # check for valid token host
    assert valid_regex.group('kind') == 'm'
    assert FourTubeBaseIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-26 11:56:34.771825
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE is type(FourTubeIE()) and PornTubeIE is type(FuxIE()), "PornTubeIE is not a subclass of FourTubeBaseIE"
    assert PornTubeIE is type(FourTubeIE()) or PornTubeIE is type(FuxIE()), "PornTubeIE is subclass of FourTubeBaseIE and FuxIE"

# Generated at 2022-06-26 11:56:37.814216
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Check if FourTubeBaseIE class constructor works."""
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    FourTubeBaseIE(url)



# Generated at 2022-06-26 11:56:50.842861
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    info_dict = {
        'id': '209733',
        'ext': 'mp4',
        'title': 'Hot Babe Holly Michaels gets her ass stuffed by black',
        'uploader': 'WCP Club',
        'uploader_id': 'wcp-club',
        'upload_date': '20131031',
        'timestamp': 1383263892,
        'duration': 583,
        'view_count': int,
        'like_count': int,
        'categories': list,
        'age_limit': 18,
    }

    # test class constructor
    ie_obj = FourTube

# Generated at 2022-06-26 11:56:52.220738
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj

# Generated at 2022-06-26 11:56:59.913898
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import mock_urllib2_response_head

    url = 'https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'
    display_id = '195359'
    media_id = '3153'
    sources = ['360', '480', '720', '1080']

    fux = FuxIE(InfoExtractor())
    fux.urls = []

    # Mock FuxIE._download_webpage
    orig_download_webpage = fux._download_webpage

    def _download_webpage(url, display_id, note=None, errnote=None, fatal=True, redirect=True, encoding=None, post_data=None, headers={}, query={}, data=None, retries=None):
        webpage = orig_

# Generated at 2022-06-26 11:57:06.516203
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    db = FourTubeBaseIE('4tubeIE', '4tube', '4tube')
    db = FourTubeBaseIE('fuxIE', 'fux', 'fux')
    db = FourTubeBaseIE('pornhubIE', 'pornhub', 'pornhub')
    db = FourTubeBaseIE('pornerbrosIE', 'pornerbros', 'pornerbros')
    db = FourTubeBaseIE('pornhubIE', 'pornhub', 'pornhub')

# Generated at 2022-06-26 11:57:17.302204
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # pylint: disable=redefined-outer-name
    # pylint: disable=line-too-long

    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    webpage = '<html><body><meta property="og:video:url" content="http://embed.redtube.com/player/?id=7268541&style=redtube&autostart=false"></body></html>'
    fileurl = 'http://embed.redtube.com/player/?id=7268541&style=redtube&autostart=false'
    info = {'url': fileurl}

# Generated at 2022-06-26 11:57:18.575574
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)

# Generated at 2022-06-26 11:57:28.827206
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .common import SIXTY_MINUTES_IN_SECONDS
    from .utils import int_or_none
    import re

    assert re.compile(r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert re.compile(r'/videos/')
    assert int_or_none('') == None

    assert str_or_none
    assert str_or_none(1) == '1'

    assert InfoExtractor
    assert SIXTY_MINUTES_IN_SECONDS == 3600

    assert try_get

# Generated at 2022-06-26 11:57:31.041368
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert(PornerBrosIE is not None)