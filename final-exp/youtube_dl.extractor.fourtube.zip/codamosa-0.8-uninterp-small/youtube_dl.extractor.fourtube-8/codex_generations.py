

# Generated at 2022-06-26 11:49:58.448994
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_ie = PornerBrosIE()

# Generated at 2022-06-26 11:50:09.334549
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f4t4 = FourTubeIE()

    assert(f4t4.IE_NAME == "4tube")
    assert(f4t4._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(f4t4._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(f4t4._TKN_HOST == 'token.4tube.com')

# Generated at 2022-06-26 11:50:09.939043
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()
    

# Generated at 2022-06-26 11:50:11.075045
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:12.324294
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_ie_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:13.707157
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()


# Generated at 2022-06-26 11:50:15.605187
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBase_i_e = FourTubeBaseIE()
    assert FourTubeBase_i_e != 0


# Generated at 2022-06-26 11:50:17.177208
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:50:18.867297
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:50:20.177364
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:50:35.771106
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:50:36.713902
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    sut = PornTubeIE()

# Generated at 2022-06-26 11:50:40.245701
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    with pytest.raises(TypeError) as excinfo:
        FourTubeBaseIE(None)
    assert "Can't instantiate abstract class FourTubeBaseIE with abstract methods _extract_formats, _real_extract" in str(excinfo.value)


# Generated at 2022-06-26 11:50:41.188712
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-26 11:50:42.654358
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbrosie=PornerBrosIE()


# Generated at 2022-06-26 11:50:48.493486
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    porn_tube_i_e_0 = PornTubeIE()
    video_id = porn_tube_i_e_0._match_id(url)
    assert len(video_id) == 7


# Generated at 2022-06-26 11:50:54.463851
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'
    assert FourTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-26 11:50:55.718059
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()

# Generated at 2022-06-26 11:50:57.282474
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE(None)


# Generated at 2022-06-26 11:51:02.192757
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL ==  r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE()._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE()._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-26 11:51:30.387363
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-26 11:51:31.785565
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:51:34.285706
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_i_e = FourTubeIE()
    # test whether the constructor failed
    assert (fourtube_i_e != None)

# Generated at 2022-06-26 11:51:36.862172
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    assert fux_i_e._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-26 11:51:41.208557
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    infoExtractor = FourTubeIE()
    assert infoExtractor.get_fields() == ['id', 'title', 'formats', 'categories', 'thumbnail', 'uploader', 'uploader_id', 'timestamp', 'like_count', 'view_count', 'duration', 'age_limit']
    assert infoExtractor.get_name() == '4tube'


# Generated at 2022-06-26 11:51:51.656253
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
    assert f.IE_NAME == '4tube'
    assert f._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert f._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert f._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-26 11:51:54.750059
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()
	

# Generated at 2022-06-26 11:51:59.340242
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except Exception as e:
        raise AssertionError('Test of FourTubeIE failed!')
    return True


# Generated at 2022-06-26 11:52:01.654415
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()


# Generated at 2022-06-26 11:52:04.385487
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fourTubeBaseIE_0 = FuxIE()


# Generated at 2022-06-26 11:53:08.028913
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()
    assert FuxIE().IE_NAME == '4tube'
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE()._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE()._TKN_HOST == 'token.fux.com'



# Generated at 2022-06-26 11:53:19.898972
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    download_path = '.'
    url_0 = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie_0 = FourTubeBaseIE(download_path)
    video_0 = ie_0.extract(url_0)
    assert video_0['id'] == '209733'
    assert video_0['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert video_0['thumbnail'] == 'https://www.4tube.com/media/videos/tmb/209733/240.jpg'
    assert video_0['uploader'] == 'WCP Club'
    assert video_0['uploader_id'] == 'wcp-club'
    assert video

# Generated at 2022-06-26 11:53:22.364621
# Unit test for constructor of class FuxIE

# Generated at 2022-06-26 11:53:24.359989
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()

# Generated at 2022-06-26 11:53:26.356295
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:53:33.018962
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._NETRC_MACHINE == '4tube'
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-26 11:53:35.229695
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p_b_i_e_0 = PornTubeIE()

# Generated at 2022-06-26 11:53:37.052294
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f = FourTubeBaseIE()


# Generated at 2022-06-26 11:53:37.978877
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:53:39.783411
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:55:46.320739
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_i_e = PornTubeIE()

test_case_0()
test_PornTubeIE()

# Generated at 2022-06-26 11:55:47.839853
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-26 11:55:50.179939
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()



# Generated at 2022-06-26 11:55:52.763397
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_ie_0 = PornerBrosIE()


# Generated at 2022-06-26 11:55:59.451254
# Unit test for constructor of class FuxIE
def test_FuxIE():
    _valid_url = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    _url_template = 'https://www.fux.com/video/%s/video'
    _tkn_host = 'token.fux.com'

# Generated at 2022-06-26 11:56:01.092488
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_ie = PornTubeIE()


# Generated at 2022-06-26 11:56:06.257898
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTube_i_e = FourTubeIE()
    FourTube_i_e.extract_from_url('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-26 11:56:08.165250
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    c = FourTubeBaseIE()
    return c


# Generated at 2022-06-26 11:56:11.573073
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:56:12.915969
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
