

# Generated at 2022-06-26 11:50:02.675717
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    PornTubeIE()._real_extract(test_url)


# Generated at 2022-06-26 11:50:04.104320
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()


# Generated at 2022-06-26 11:50:05.544117
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:50:13.386334
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()
    # a new class of name FourTubeBaseIE is created
    assert four_tube_base_i_e_0.__name__ == 'FourTubeBaseIE'
    # a new class is created
    assert isinstance(four_tube_base_i_e_0, InfoExtractor)
    # the class is having the function
    assert hasattr(four_tube_base_i_e_0, '_real_extract')
    # the class is having the function
    assert hasattr(four_tube_base_i_e_0, '_extract_formats')

# Generated at 2022-06-26 11:50:14.718703
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:18.242892
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()
    assert four_tube_base_i_e_0._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-26 11:50:22.905399
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    rtmp_url = 'rtmp://flvserver.viewster.com/vod/mp4:viewster-smdom/mp4:porntube/porntube-smdom/1341406-squirting-teen-ballerina-ecg.mp4/playlist.m3u8'
    assert(PornTubeIE._check_rtmp_url(rtmp_url))

# Generated at 2022-06-26 11:50:24.277774
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	PornerBrosIE()
	

# Generated at 2022-06-26 11:50:28.032900
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()
    # Unit test with args
    # assert(porner_bros_i_e.name == "PornerBrosIE")


if __name__ == "__main__":
    test_PornerBrosIE()

# Generated at 2022-06-26 11:50:29.375918
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert  four_tube_base_i_e_0


# Generated at 2022-06-26 11:50:50.903770
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FourTubeDummyIE(FourTubeBaseIE):
        IE_NAME = 'fourtubedummy'
        _VALID_URL = r'http://www.dummytube.com/some_cool_video/'
        _URL_TEMPLATE = 'http://www.dummytube.com/some_cool_video/%s'
        _TKN_HOST = 'token.dummytube.com'

    FourTubeDummyIE()

# Generated at 2022-06-26 11:50:53.978772
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")

# Generated at 2022-06-26 11:50:58.842347
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	from ytdl_server.extractor.common import InfoExtractor
	from ytdl_server.extractor.pornerbros import PornerBrosIE
	IE = InfoExtractor()
	IE_PB = PornerBrosIE(IE)
	assert(type(IE_PB) == InfoExtractor)
	return True

# Generated at 2022-06-26 11:50:59.497668
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-26 11:51:00.748074
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube = PornTubeIE()
    assert porntube is not None

# Generated at 2022-06-26 11:51:13.419932
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_values = [
        'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
        'https://www.4tube.com/embed/209733',
        'https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ]

    # Constructor with valid URL
    test_url = test_values[0]
    fti = FourTubeIE()
    fti.initialize(test_url)
    assert fti.kind == 'www'
    assert fti.id == '209733'

# Generated at 2022-06-26 11:51:19.402810
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE('http://fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert ie.VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:51:21.788809
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # The website is not available in China
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:51:23.955925
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._real_extract(r'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-26 11:51:26.927913
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_PornTubeIE import PornTubeIE_test
    PornTubeIE_test(PornTubeIE)


# Generated at 2022-06-26 11:51:58.974252
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	from . import PornerBrosIE
	arg1 = PornerBrosIE()
	assert(isinstance(arg1, PornerBrosIE))

# Generated at 2022-06-26 11:52:02.745495
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance._TKN_HOST == "token.pornerbros.com"
    assert instance.ie_key() == 'PornerBros'

# Generated at 2022-06-26 11:52:04.171001
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()

# Generated at 2022-06-26 11:52:09.919993
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    print("Testing constructor of class PornerBrosIE...")
    assert PornerBrosIE == (
        pornerbros.PornerBrosIE()
        .__class__
    )

# Generated at 2022-06-26 11:52:17.007730
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Constructor without argument
    assert PornerBrosIE() is not None

    # Constructor with one argument
    assert PornerBrosIE('PornerBrosIE') is not None

    try:
        # Constructor with null argument
        assert PornerBrosIE(None) is not None
        assert False
    except TypeError:
        assert True

    try:
        # Constructor with invalid argument
        assert PornerBrosIE(0.5) is not None
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-26 11:52:23.932627
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-26 11:52:28.780914
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE(None)
    assert ie.ie_key() == 'pornerbros'
    assert ie.IE_NAME == 'pornerbros'

# Generated at 2022-06-26 11:52:30.870648
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE.constructor(PornTubeIE)


# Generated at 2022-06-26 11:52:32.950928
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert hasattr(PornerBrosIE, '_constructor')

# Generated at 2022-06-26 11:52:42.630971
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert(ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video')
    assert(ie._TKN_HOST == 'token.fux.com')
    assert(len(ie._TESTS) == 3)


# Generated at 2022-06-26 11:53:51.238104
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    result = PornerBrosIE()
    assert 18 == result.age_limit
    assert 'pornerbros.com/videos' in result.IE_NAME

# Generated at 2022-06-26 11:53:57.069033
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    from ..utils import DEFAULT_HEADERS
    from ..compat import (
        compat_str, compat_urllib_parse, compat_urllib_parse_urlencode
    )
    ie = InfoExtractor(FourTubeIE.ie_key())
    token_url = ie._TKN_HOST + '/209733/desktop/720+480+360'
    data = ''.encode('ascii')
    headers = {
        'Cookie': '__cfduid=d9f8a0e02adfa58bf12b73b742ef8d2f31481167267; fuckAdBlock=1'
    }
    headers.update(dict((k, v) for k, v in DEFAULT_HEADERS.items() if k not in headers))

   

# Generated at 2022-06-26 11:53:58.394718
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Ensure constructor of class FuxIE
    """
    f = FuxIE(object)
    assert f.name == "Fux"

# Generated at 2022-06-26 11:53:59.709605
# Unit test for constructor of class FuxIE
def test_FuxIE():
    x = FuxIE()

# Generated at 2022-06-26 11:54:03.445545
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux.IE_NAME in fux.ie_key()

# Generated at 2022-06-26 11:54:06.284653
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.ie_key() == 'PornerBros'

# Generated at 2022-06-26 11:54:07.166347
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-26 11:54:16.322647
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-26 11:54:29.746931
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "http://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406"
    ie = PornTubeIE()

    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-26 11:54:42.536787
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Test class FourTubeBaseIE.
    """

    class TestFourTubeBaseIE(FourTubeBaseIE):

        _VALID_URL = r'fake'
        IE_NAME = r'test'
        _TKN_HOST = r'test'

    # Test for _extract_formats
    # _extract_formats does not works because of NetRCPasswordManger problem
    # Test for _real_extract

# Generated at 2022-06-26 11:57:26.861999
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-26 11:57:38.775252
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """ Use the same test case as for class FourTubeIE """
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from io import BytesIO as bytesio
    from ytdl.extractor.services import FourTubeIE

    URL = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    TEST_CASE = FourTubeIE._TESTS[0]

    class TestClass(unittest.TestCase):
        def setUp(self):
            FuxIE._download_webpage = lambda *args: bytesio(self.page_contents)
            FuxIE._download_json = lambda *args, **kwargs: bytesio(self.json_contents)
            FuxIE._

# Generated at 2022-06-26 11:57:45.119969
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FuxIE()
    assert f._VALID_URL.find("fux") != -1
    assert f._TKN_HOST.find("fux") != -1
    assert f._URL_TEMPLATE.find("fux") != -1

# Generated at 2022-06-26 11:57:46.365948
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(FuxIE(), FourTubeBaseIE)

# Generated at 2022-06-26 11:57:56.244568
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == \
    r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._URL_TEMPLATE == \
    'https://www.pornerbros.com/videos/video_%s'


# Generated at 2022-06-26 11:57:58.736169
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'



# Generated at 2022-06-26 11:58:01.908667
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert isinstance(instance._TESTS, list)

# Generated at 2022-06-26 11:58:07.603545
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-26 11:58:16.516533
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(PornTubeIE.ie_key())._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE(PornerBrosIE.ie_key())._TKN_HOST == 'token.pornerbros.com'
    assert FuxIE(FuxIE.ie_key())._TKN_HOST == 'fux.com'

# Generated at 2022-06-26 11:58:18.695290
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TESTS is not None
