

# Generated at 2022-06-26 11:49:59.211500
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:50:02.274032
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # test constructor
    porner_bros_i_e = PornerBrosIE()
    assert isinstance(porner_bros_i_e, InfoExtractor)

# Generated at 2022-06-26 11:50:04.113715
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:50:06.100938
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()
    assert callable(four_tube_base_i_e_0._extract_formats)

# Generated at 2022-06-26 11:50:07.554227
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube_i_e_0 = PornTubeIE()

# Generated at 2022-06-26 11:50:09.722529
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    check(four_tube_base_i_e_0,'FourTubeBaseIE')


# Generated at 2022-06-26 11:50:11.106212
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e = FourTubeIE()


# Generated at 2022-06-26 11:50:12.852162
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert four_tube_base_i_e_0._TKN_HOST == 'token.4tube.com';


# Generated at 2022-06-26 11:50:20.087393
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test case with url from website
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    video_id = 7089759
    porn_tube_i_e = PornTubeIE()
    mobj = porn_tube_i_e._VALID_URL.match(url)
    if mobj:
        porntube_info = porn_tube_i_e._real_extract(url)
        assert porntube_info['id'] == video_id

# Generated at 2022-06-26 11:50:21.355200
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:44.658887
# Unit test for constructor of class FuxIE

# Generated at 2022-06-26 11:50:46.838500
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    _init = PornerBrosIE.__init__()
    assert _init == "PornerBrosIE"

# Generated at 2022-06-26 11:50:59.057268
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Test constructor of class PornerBrosIE"""
    # Here, expected results of id and title are not set intentionally.
    # Because url and md5 are the same as in test cases above,
    # these values should be the same to.

# Generated at 2022-06-26 11:51:00.040464
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie_instance = PornTubeIE()
    print(ie_instance)

# Generated at 2022-06-26 11:51:08.080463
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Valid URL
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    FuxIE().suitable(url)

    # Invalid URL
    url = 'https://www.fux.com/video/00/awesome-fucking-kitchen-ends-cum-swallow'
    FuxIE().suitable(url)

# Generated at 2022-06-26 11:51:09.476157
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert issubclass(PornTubeIE, FourTubeBaseIE)


# Generated at 2022-06-26 11:51:11.229927
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBros', 'PornerBrosIE')

# Generated at 2022-06-26 11:51:12.357032
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    t = PornTubeIE()
    assert t

# Generated at 2022-06-26 11:51:23.025517
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    VideoInfoExtractorInstance = FourTubeBaseIE()
    assert VideoInfoExtractorInstance.IE_NAME == '4tube'
    assert VideoInfoExtractorInstance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert VideoInfoExtractorInstance._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert VideoInfoExtractorInstance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:51:27.104768
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie._download_webpage('http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow', 195359)

# Generated at 2022-06-26 11:52:05.672969
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:52:16.760401
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Unit test for constructor of class FourTubeIE
    # The test function need us to make sure a test video is embedded on the page
    video_page = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    wepage = '<html><head><meta property="og:video" content="https://www.4tube.com/embed/209733"/></head></html>'
    extractor = FourTubeIE.parse_video(video_page, {})
    assert extractor.download()['id'] == '209733'



# Generated at 2022-06-26 11:52:17.591188
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	return PornTubeIE()


# Generated at 2022-06-26 11:52:20.229731
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert x.ie_key() == 'PornerBros'



# Generated at 2022-06-26 11:52:23.135125
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():

    # Testing basic functionality
    ie = PornerBrosIE()
    assert isinstance(ie, PornerBrosIE)

# Generated at 2022-06-26 11:52:25.274090
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE('FourTubeBaseIE')
    assert instance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:52:26.189190
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-26 11:52:38.654175
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test FourTubeBaseIE."""
    class TestFourTubeBaseIE(FourTubeBaseIE):
        IE_NAME = 'Test fubar'
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fubar\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.fubar.com/video/%s/video'
        _TKN_HOST = 'token.fubar.com'

    FourTubeBaseIE.__bases__ = (InfoExtractor,)
    x = TestFourTubeBaseIE()
    x._VALID_URL
    x._URL_TEMPLATE
    x._TKN_H

# Generated at 2022-06-26 11:52:40.208995
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-26 11:52:45.502993
# Unit test for constructor of class FuxIE
def test_FuxIE():
    info_dict = {
    'id': '123',
    'ext': 'mp4',
    'title': 'test',
    'uploader': 'test',
    'uploader_id': 'test',
    'upload_date': 'test',
    'timestamp': 'test',
    'duration': 'test',
    'view_count': 'test',
    'like_count': 'test',
    'categories': 'test',
    'age_limit': 'test',
    }
    ie = FuxIE()
    test_ie = ie._real_extract(ie._VALID_URL, info_dict)
    assert test_ie['id'] == '123'
    assert test_ie['ext'] == 'mp4'
    assert test_ie['title'] == 'test'

# Generated at 2022-06-26 11:53:50.213960
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x = FourTubeBaseIE()

# Generated at 2022-06-26 11:53:53.873049
# Unit test for constructor of class FuxIE
def test_FuxIE():
    m_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fuxIE = FuxIE()
    m_id = fuxIE._VALID_URL
    #print m_id
    m_id = re.match(m_id, m_url)
    #print m_id
    fuxIE._real_extract(m_url)


# Generated at 2022-06-26 11:53:57.454323
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # test cases for constructor
    if not hasattr(PornerBrosIE, 'IE_NAME'):
        raise Exception('PornerBrosIE does not have attribute IE_NAME')
    if not hasattr(PornerBrosIE, '_VALID_URL'):
        raise Exception('PornerBrosIE does not have attribute _VALID_URL')
if __name__ == '__main__':
    # run unit tests
    test_PornerBrosIE()

# Generated at 2022-06-26 11:54:02.425825
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # use the url as given in _TESTS[0], and construct an instance of PornTubeIE with it
    PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759', downloader=None)



# Generated at 2022-06-26 11:54:13.169792
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test for pornhub.com and pornhub.net
    ie = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert(ie._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video")
    assert(ie._TKN_HOST == "token.4tube.com")
    assert(ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie.IE_NAME == "4tube")

# Generated at 2022-06-26 11:54:14.483139
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except:
        assert False, "create class FourTubeIE failed."



# Generated at 2022-06-26 11:54:15.937486
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-26 11:54:28.559812
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    IE_cls = FourTubeIE()
    # just an example, which is not a real valid url
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    m = re.match(IE_cls._VALID_URL, url)  # regular expression
    video_id = m.group('id')
    display_id = m.group('display_id')
    url_template = IE_cls._URL_TEMPLATE
    url = url_template % video_id
    if display_id:
        url = url.replace('/video', '/%s' % display_id)  # insert the display_id into the url
    return url

# Generated at 2022-06-26 11:54:34.503189
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_case = FourTubeIE(None)
    assert test_case._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test_case._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test_case._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-26 11:54:38.863412
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    '''
    Test the constructor of class PornTubeIE
    '''
    url = r'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    porntube = PornTubeIE()
    porntube._download_webpage(url, None)

# Generated at 2022-06-26 11:57:11.333677
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FuxIE.ie_key())

# Generated at 2022-06-26 11:57:12.422973
# Unit test for constructor of class FuxIE
def test_FuxIE():
    inst = FuxIE()
    assert_equal(inst.IE_NAME, '4tube')

# Generated at 2022-06-26 11:57:13.481664
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Test the constructor of class FuxIE
    """
    pass

# Generated at 2022-06-26 11:57:21.772299
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    video_id = '209733'
    media_id = '209733'
    sources = ['480', '720', '1080']
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    fourTubeBase = FourTubeBaseIE()
    fourTubeBase._extract_formats(url, video_id, media_id, sources)

# Generated at 2022-06-26 11:57:23.976232
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE=FuxIE()
    assert fuxIE

# Generated at 2022-06-26 11:57:30.228308
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Make sure constructor is working correctly for cases with and without display_id."""
    # No display_id
    test_url = 'https://www.pornerbros.com/embed/181369'
    video_id = '181369'
    display_id = None
    porner_bros_ie = PornerBrosIE()
    mobj = re.match(porner_bros_ie._VALID_URL, test_url)
    assert video_id == mobj.group('id')
    assert display_id == mobj.group('display_id')
    # With display_id
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-26 11:57:33.000658
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	PornerBrosIE('https://www.pornerbros.com/embed/181369', '181369')

# Generated at 2022-06-26 11:57:35.504671
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        tester = PornerBrosIE()
    except:
        assert False
    assert True

# Generated at 2022-06-26 11:57:38.392246
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-26 11:57:42.866475
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.extract('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')