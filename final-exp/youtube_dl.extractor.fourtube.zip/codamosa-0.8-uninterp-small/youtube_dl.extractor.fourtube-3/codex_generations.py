

# Generated at 2022-06-26 11:49:57.522317
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert isinstance(FourTubeBaseIE(), InfoExtractor)


# Generated at 2022-06-26 11:49:58.949402
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:50:00.403291
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # no arguments
    test_case_0()


# Generated at 2022-06-26 11:50:02.223273
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:50:12.399904
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Initializes a client with none-empty arguments.
    four_tube_base_ie = FourTubeIE()

# Generated at 2022-06-26 11:50:13.747805
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:15.641175
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()

# Generated at 2022-06-26 11:50:16.661990
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube_i_e = PornTubeIE();

# Generated at 2022-06-26 11:50:18.491822
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:20.855316
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # four_tube_base_i_e_0 = FourTubeBaseIE()
    # return four_tube_base_i_e_0
    return FourTubeIE()


# Generated at 2022-06-26 11:50:49.450607
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()

# Generated at 2022-06-26 11:51:00.548694
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert four_tube_base_i_e_0.IE_NAME == '4tube'
    assert four_tube_base_i_e_0._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert four_tube_base_i_e_0._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert four_tube_base_i_e_0._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:51:02.465080
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i = PornTubeIE()


# Generated at 2022-06-26 11:51:04.106465
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:51:07.726877
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()


# Generated at 2022-06-26 11:51:08.631432
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_1 = FourTubeBaseIE()


# Generated at 2022-06-26 11:51:13.647101
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e = FourTubeBaseIE()
    assert four_tube_base_i_e.IE_NAME == '4tube'
    assert four_tube_base_i_e.test()
    assert four_tube_base_i_e._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-26 11:51:16.587731
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Call PornerBrosIE constructor
    pornerbros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:51:17.936486
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:51:20.596768
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()
    assert four_tube_base_i_e_0._VALID_URL is None


# Generated at 2022-06-26 11:51:50.917671
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = FuxIE()
    assert hasattr(IE, '_TESTS')

# Generated at 2022-06-26 11:51:58.206229
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    # create an object of the tested class
    pornerbros = PornerBrosIE()
    # check if the object is an instance of the tested class
    assert isinstance(pornerbros, PornerBrosIE), 'Object is not an instance of PornerBrosIE class'

# Generated at 2022-06-26 11:52:05.038461
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:52:17.009167
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for ie in (FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE):
        entry = ie(ie.ie_key())._build_url_result('574429', {'display_id': None})
        assert entry['url'] == 'https://www.4tube.com/videos/574429/video'
        assert entry['display_id'] == '574429'
        entry = ie(ie.ie_key())._build_url_result('574429', {'display_id': 'some-title'})
        assert entry['url'] == 'https://www.4tube.com/videos/574429/some-title'
        assert entry['display_id'] == 'some-title'

# Generated at 2022-06-26 11:52:17.569377
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-26 11:52:22.764792
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert int(PornerBrosIE._TESTS[0]['info_dict']['view_count']) > 0
    assert int(PornerBrosIE._TESTS[0]['info_dict']['duration']) > 0

# Generated at 2022-06-26 11:52:23.862964
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert instance._TKN_HOST is not None

# Generated at 2022-06-26 11:52:29.821079
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    objects = [FourTubeIE(None), PornTubeIE(None), FuxIE(None), PornerBrosIE(None)]
    for o in objects:
        assert o.extract_format == _extract_format_base


# Generated at 2022-06-26 11:52:38.775349
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtubeIE = FourTubeIE()

    assert fourtubeIE.IE_NAME == '4tube'
    assert fourtubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourtubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert fourtubeIE._TKN_HOST == 'token.4tube.com'
    assert len(fourtubeIE._TESTS) == 4



# Generated at 2022-06-26 11:52:40.934322
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_instance = FuxIE()
    assert test_instance



# Generated at 2022-06-26 11:53:53.031455
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    video_id = '209733'
    display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeIE._VALID_URL, url)
    obj = FourTubeIE(mobj.group('kind', 'id', 'display_id'))
    assert obj._VALID_URL == FourTubeIE._VALID_URL
    assert obj._TKN_HOST == FourTubeIE._TKN_HOST
    assert obj._URL_TEMPLATE == FourTubeIE._URL_TEMPLATE
    assert obj._T

# Generated at 2022-06-26 11:53:53.503347
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE

# Generated at 2022-06-26 11:53:55.978203
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-26 11:53:57.774128
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()
    # Test the constructor of class PornTubeIE.
    assert(porn_tube_ie.__class__.__name__ == "PornTubeIE")


# Generated at 2022-06-26 11:54:11.109405
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pornhub_ie = PornTubeIE()
    assert pornhub_ie.IE_NAME == 'PornTube'
    assert pornhub_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornhub_ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert pornhub_ie._TKN_HOST == 'tkn.porntube.com'
    assert len(pornhub_ie._TESTS) == 3

# Generated at 2022-06-26 11:54:12.145618
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()
    FourTubeIE()


# Generated at 2022-06-26 11:54:13.439079
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None, "https://www.porntube.com/embed/7089759")


# Generated at 2022-06-26 11:54:16.612809
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Tests constructor of subclasses.
    # We do not need to test its methods.
    FourTubeBaseIE()
    FuxIE()
    PornTubeIE()
    PornerBrosIE()

# Generated at 2022-06-26 11:54:30.055311
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE('https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    porn_tube_ie._VALID_URL = re.compile(r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
    assert porn_tube_ie == PornTubeIE('https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-26 11:54:42.567783
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-26 11:57:27.831638
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    # test whether IE can recognize itself
    assert ie.suitable('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert ie.suitable('https://www.porntube.com/embed/7089759')
    assert ie.suitable('https://m.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')


# Generated at 2022-06-26 11:57:30.674038
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert isinstance(PornTubeIE(), FourTubeBaseIE)


# Generated at 2022-06-26 11:57:35.018208
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornTubeIE()(url)

# Generated at 2022-06-26 11:57:36.365362
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    F = FourTubeBaseIE([])
    assert(F.counter == 4)

# Generated at 2022-06-26 11:57:38.692076
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    instance.ie_key()

# Generated at 2022-06-26 11:57:43.891416
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # test PornerBrosIE class is constructed properly
    pornerbros = PornerBrosIE()
    assert pornerbros.ie_key() == 'PornerBros'



# Generated at 2022-06-26 11:57:45.324783
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert(PornerBrosIE() is not None)

# Generated at 2022-06-26 11:57:51.682888
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-26 11:58:00.919486
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("181369")
    assert ie.external_urls == ["https://www.fux.com/video/181369/skinny-brunette-takes-big-cock-down-her-anal-hole", "https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"]
    assert ie.video_id == "181369"
    assert ie.title == "Skinny brunette takes big cock down her anal hole"
    assert ie.title_id == "181369"
    assert ie.external_ids == ['fux.com:181369', 'porntube.com:181369']

# Generated at 2022-06-26 11:58:11.186839
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
  ie = PornTubeIE()
  ie.url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
  ie.video_id = '7089759'
  x = ie.extract()
  assert type(x) is dict, "The return value is not a dictionary."
  assert len(x) is 17, "The dictionary does not have exactly 17 elements."
  assert 'id' in x, "The dictionary does not have a key 'id'."
  assert 'ext' in x, "The dictionary does not have a key 'ext'."
  assert 'title' in x, "The dictionary does not have a key 'title'."
  assert 'uploader' in x, "The dictionary does not have a key 'uploader'."