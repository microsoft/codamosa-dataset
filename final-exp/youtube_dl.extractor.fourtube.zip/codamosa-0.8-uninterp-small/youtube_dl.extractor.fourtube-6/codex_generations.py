

# Generated at 2022-06-26 11:49:58.266716
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-26 11:49:59.732162
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:50:02.372179
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    def test_case_0():
        four_tube_base_i_e_0 = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:04.987849
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # assert isinstance(four_tube_i_e_0, FourTubeIE)
    assert isinstance(four_tube_i_e_0, InfoExtractor)


# Generated at 2022-06-26 11:50:06.417909
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:50:07.857679
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()

# Generated at 2022-06-26 11:50:09.234755
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()

# Generated at 2022-06-26 11:50:10.645846
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_ = FuxIE()



# Generated at 2022-06-26 11:50:11.940144
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:13.125497
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    four_tube_base_i_e_0 = PornTubeIE()

# Generated at 2022-06-26 11:50:36.251219
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    fux_i_e_0 = FuxIE()
    assert fux_i_e_0._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    fux_i_e_0._real_extract(test_url)


# Generated at 2022-06-26 11:50:37.501739
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()

# Generated at 2022-06-26 11:50:39.072076
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:50:49.267636
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    porn_tube_i_e_0 = PornTubeIE()
    porn_tube_i_e_1 = PornTubeIE(url)
    porn_tube_i_e_2 = PornTubeIE(url, 0)
    porn_tube_i_e_3 = PornTubeIE(url, 0, 0)
    porn_tube_i_e_4 = PornTubeIE(url, 0, 0, 0)
    del porn_tube_i_e_0, porn_tube_i_e_1, porn_tube_i_e_2, porn_tube_i_e_3, porn_tube_i_e_4

# Generated at 2022-06-26 11:50:55.079973
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-26 11:50:57.420423
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()
    assert(porn_tube_i_e_0 is not None)

# Generated at 2022-06-26 11:50:58.713168
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:51:05.271281
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert four_tube_base_i_e_0.__class__ == FourTubeBaseIE
# Check if exception is thrown
try:
    four_tube_base_i_e_0.__init__()
except Exception as e:
    assert type(e) == NotImplementedError
# Check if exception is thrown
try:
    four_tube_base_i_e_0.__init__()
except Exception as e:
    assert type(e) == NotImplementedError
# Check if exception is thrown
try:
    four_tube_base_i_e_0.__init__()
except Exception as e:
    assert type(e) == NotImplementedError
# Check if exception is thrown

# Generated at 2022-06-26 11:51:07.726110
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()


# Generated at 2022-06-26 11:51:09.135250
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:51:35.045048
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Defining mock object for class PornerBrosIE
    class MockPornerBrosIE(PornerBrosIE):
        def _real_extract(self, url):
            return {
                'id': None,
                'title': None,
                'formats': None,
                'thumbnail': None,
                'uploader': None,
                'uploader_id': None,
                'channel': None,
                'channel_id': None,
                'timestamp': None,
                'like_count': None,
                'dislike_count': None,
                'view_count': None,
                'duration': None,
                'age_limit': None
            }

    # Defining mock object for class InfoExtractor

# Generated at 2022-06-26 11:51:36.861194
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor_ = FourTubeBaseIE()
    assert info_extractor_ is not None

# Generated at 2022-06-26 11:51:38.853932
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'

# Generated at 2022-06-26 11:51:41.606081
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    x = FourTubeIE()

# Generated at 2022-06-26 11:51:43.426237
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie is not None

# Generated at 2022-06-26 11:51:50.127928
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constructor_test(FourTubeBaseIE, ['https://www.porntube.com/videos/teen-couple-doing-anal_7089759'], {
        'skip': 'This unit test requires a mock of https://tkn.porntube.com/7089759/desktop/720+480+360',
    })

# Generated at 2022-06-26 11:51:51.654994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'



# Generated at 2022-06-26 11:52:00.269048
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ie = ydl.get_info_extractor('PornTubeIE')
    i = ie.extract('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert i['id'] == '7089759'

# Generated at 2022-06-26 11:52:01.429017
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-26 11:52:05.761504
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Unit test for constructor of class FourTubeIE
    # This class is abstract, so we had to create a constructor in it to
    # make unit tests work
    obj = FourTubeIE()

# Generated at 2022-06-26 11:52:40.935094
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube = PornTubeIE('porntube')
    if porn_tube.IE_NAME != 'PornTube':
        raise Exception('PornTubeIE constructor is invalid')


# Generated at 2022-06-26 11:52:42.478301
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:52:53.182471
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base = FourTubeBaseIE()
    body = '''
    <script id="playerembed" src="//embed.porntube.com/v2/player/porntube/embed.js?v=1"></script>
    '''
    parsed_url = compat_urlparse.urlparse(base._download_webpage(
        base._search_regex(
            r'<script[^>]id=(["\'])playerembed\1[^>]+src=(["\'])(?P<url>.+?)\2',
            body, 'player JS', group='url'),
        None,
        'Downloading player JS'))
    assert parsed_url.scheme == 'https'
    assert parsed_url.netloc == 'embed.porntube.com'

# Generated at 2022-06-26 11:53:06.328428
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_ie = FourTubeIE()
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-26 11:53:08.790068
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    with pytest.raises(TypeError):
        FourTubeBaseIE()

# Generated at 2022-06-26 11:53:11.485131
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    module = FourTubeBaseIE()
    assert module._TKN_HOST == "token.4tube.com"

# Generated at 2022-06-26 11:53:16.734560
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    porntubeIE = PornTubeIE()
    porntubeIE.extract(url)

# Generated at 2022-06-26 11:53:18.677008
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(None)


# Generated at 2022-06-26 11:53:23.499334
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE('http://www.porntube.com/embed/7089759')
    assert ie.ie_key() == 'PornTube'
    assert ie.ie_name() == 'PornTube'

# Generated at 2022-06-26 11:53:32.071162
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    from .texture import TextureIE

    class TestIE(TextureIE):
        _VALID_URL = r'http://example\.com/watch/([0-9]+)'

        _TEST = {
            'url': 'http://example.com/watch/12345',
            'file': '12345.mp4',
            'info_dict': {
                'id': '12345',
                'ext': 'mp4',
                'title': 'example video 12345',
                'categories': ['cat1', 'cat2'],
                'description': 'example desc',
                'duration': 123,
                'age_limit': 18,
            },
        }

        def _real_extract(self, url):
            video_id = self._match_id(url)
            video

# Generated at 2022-06-26 11:54:56.526959
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.get_urls() == [b'https?://www.pornerbros.com/videos/video_%s',
                             b'https?://www.porntube.com/embed/%s',
                             b'https?://www.porntube.com/videos/video_%s',
                             b'https?://www.fux.com/embed/%s',
                             b'https?://www.fux.com/video/%s/video',
                             b'https?://www.4tube.com/embed/%s',
                             b'https?://www.4tube.com/videos/%s/video']

# Generated at 2022-06-26 11:55:07.835121
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:55:10.385745
# Unit test for constructor of class FuxIE
def test_FuxIE():
    a = FuxIE()
    if a._TESTS:
        assert True
    else:
        assert False

# Generated at 2022-06-26 11:55:12.771876
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert (obj)


# Generated at 2022-06-26 11:55:15.055203
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb = PornerBrosIE()
    a = pb._TESTS[0]


# Generated at 2022-06-26 11:55:24.554626
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert pornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'


# Generated at 2022-06-26 11:55:28.362623
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/embed/195359'
    fux_instance = FuxIE(url)
    assert isinstance(fux_instance, FuxIE)

# Generated at 2022-06-26 11:55:35.879426
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from re import match
    from .common import InfoExtractor
    from .pornerbros import PornerBrosIE
    from .common import InfoExtractor
    for cls in PornerBrosIE.__bases__:
        if cls is InfoExtractor:
            assert True
    assert match(PornerBrosIE._VALID_URL, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-26 11:55:46.517364
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import sys
    if sys.version_info < (3,):
        from urlparse import urlparse
    else:
        from urllib.parse import urlparse
    url = PornerBrosIE._VALID_URL
    for test_str in (
        'http://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
        'http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
        'http://www.pornerbros.com/embed/181369',
    ):
        m_obj = re.match(url, test_str)
        assert m_obj
        video_id = m

# Generated at 2022-06-26 11:55:57.191429
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE(None, None)

# Generated at 2022-06-26 11:59:11.099819
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:59:12.577056
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from youtube_dl.extractor import FourTubeBaseIE
    assert issubclass(FourTubeBaseIE, InfoExtractor)

# Generated at 2022-06-26 11:59:23.765832
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    inst = FourTubeBaseIE(None, _VALID_URL=r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert inst._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:59:25.487898
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')

# Generated at 2022-06-26 11:59:27.046149
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print(FuxIE())

# Generated at 2022-06-26 11:59:37.836463
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    fux._VALID_URL = 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    fux._URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    fux._TKN_HOST = 'token.fux.com'