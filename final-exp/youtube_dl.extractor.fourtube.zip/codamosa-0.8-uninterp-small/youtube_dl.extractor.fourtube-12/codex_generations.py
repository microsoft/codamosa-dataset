

# Generated at 2022-06-26 11:49:58.108467
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()

# Generated at 2022-06-26 11:50:08.986729
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.IE_NAME == 'PornerBros', 'Value mismatch'
    assert PornerBrosIE.IE_DESC == 'PornerBros.com', 'Value mismatch'
    assert PornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)', 'Value mismatch'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s', 'Value mismatch'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com', 'Value mismatch'


# Generated at 2022-06-26 11:50:12.188098
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'https://www.porntube.com/embed/7089759'
    result = PornerBrosIE()._VALID_URL.match(url)
    print(result.groupdict())
    assert result.group('id')=='7089759'
    assert result.group('display_id')== None
    assert result.group('kind')=='www'

# Generated at 2022-06-26 11:50:17.177699
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()
    porner_bros_i_e_0 = PornerBrosIE()
    porner_bros_i_e_0.extract("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")

# Generated at 2022-06-26 11:50:20.311235
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except:
        raise AssertionError('Constructor of class {0} raised Exception'.format(
            PornerBrosIE.__name__))


# Generated at 2022-06-26 11:50:21.231239
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    return PornerBrosIE()

# Generated at 2022-06-26 11:50:31.302792
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    porn_tube_i_e = PornTubeIE()
    assert(porn_tube_i_e._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)')
    assert(porn_tube_i_e._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s')
    assert(porn_tube_i_e._TKN_HOST == 'tkn.porntube.com')

# Generated at 2022-06-26 11:50:32.845852
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourtube_base_i_e = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:34.121815
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:36.545820
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE.__name__ == 'FourTubeBaseIE'
    assert FourTubeBaseIE.__bases__[0].__name__ == 'InfoExtractor'


# Generated at 2022-06-26 11:50:55.374425
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Testing constructor default parameters
    FourTubeIE()

    # Testing constructor with parameters (keyword arguments)
    FourTubeIE(ie_keywords=None)

    # Testing constructor with parameters (positional arguments)
    FourTubeIE(None)

# Generated at 2022-06-26 11:51:01.677177
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE(None, None)
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-26 11:51:04.016709
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Unit test for constructor of class FuxIE.
    """
    ie = FuxIE()
    assert ie.IE_NAME == "Fux"

# Generated at 2022-06-26 11:51:16.586755
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # The following test URL should raise an exception.
    # I expect this behaviour because the regex_valid function in compat (line 121)
    # is not matching this URL.
    # http://www.4tube.com/embed/7089759
    testurl = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    expected_id = '209733'

    # Create a new instance of class FourTubeIE.
    fourtube_ie = FourTubeIE()

    # Test whether the instatiated FourTubeIE-class contains
    # the expected id.
    assert fourtube_ie.extract_id(testurl) == expected_id

# Generated at 2022-06-26 11:51:17.124731
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-26 11:51:18.108738
# Unit test for constructor of class FuxIE
def test_FuxIE():
    (FuxIE()).test

# Generated at 2022-06-26 11:51:26.617384
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-26 11:51:27.443015
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBase = FourTubeBaseIE();

# Generated at 2022-06-26 11:51:37.798021
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import os
    import unittest

    from io import StringIO

    from .common import fake_httpd
    from .test_4tube import _extract_formats

    # initialize the fake HTTP server
    server = fake_httpd.HTTPServer(
        # the localhost URL (default port is 80)
        #   to access HTTP server: http://localhost:8888/
        server_address = ('localhost', 8888),
        # the localhost URL (default port is 80)
        #   to access HTTPS server: https://localhost:8080/
        # server_address = ('localhost', 8080),

        # handle the request
        RequestHandlerClass = fake_httpd.CommonRequestHandler,
        bind_and_activate = True
    )

    # initialize the fake HTTP request
    request_data = dict()
    # the URL

# Generated at 2022-06-26 11:51:40.323250
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE.suitable('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-26 11:52:17.830188
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/embed/195359'
    expected_result = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

    URL = url
    url = urlparse(url)
    url_path_parts = url.path[1:].split('/')
    if url_path_parts[0] == 'embed':
        URL = 'https://www.fux.com/video/%s/%s' % (url_path_parts[1], url_path_parts[2])

    actual_result = URL
    assert actual_result == expected_result

# Generated at 2022-06-26 11:52:22.389834
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    classes = [FourTubeIE, FuxIE, PornTubeIE, PornerBrosIE]
    for thisClass in classes:
        instance = thisClass()
        assert isinstance(instance, thisClass)



# Generated at 2022-06-26 11:52:26.450616
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    print("Unit test for PornTubeIE")
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    PornTubeIE().suitable(url)
    PornTubeIE()._real_extract(url)
    print("Done unit test.")



# Generated at 2022-06-26 11:52:29.005421
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:52:31.147620
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:52:32.645500
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-26 11:52:35.831339
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    A basic test which just checks the constructor
    of PornTubeIE can be called
    """
    PornTubeIE("https://www.porntube.com")

# Generated at 2022-06-26 11:52:36.660998
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pass

# Generated at 2022-06-26 11:52:39.040407
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()

# Generated at 2022-06-26 11:52:51.788838
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import unittest
    import urllib
    import json
    import binascii
    from six.moves import urllib_parse, urllib_error

    from .common import InfoExtractor
    from .ptube import PornTubeIE
    from ..compat import (
        compat_b64decode,
        compat_urllib_parse_unquote,
        compat_urlparse,
    )

    class PornTubeIETest(unittest.TestCase):
        def setUp(self):
            self.ie = PornTubeIE(InfoExtractor(None))
            self.test_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'

# Generated at 2022-06-26 11:54:07.866864
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE("FuxIE", "www.fux.com" + "/videos/195359/awesome-fucking-kitchen-ends-cum-swallow", {})

# Generated at 2022-06-26 11:54:10.540653
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.ie_key() == 'porntube'
    assert ie.ie_name() == 'PornTube'


# Generated at 2022-06-26 11:54:18.682563
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():

    s = FourTubeIE

    assert s._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert s._TKN_HOST == 'token.4tube.com'

    m = re.match(r'^https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?$', 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

    assert m.group('kind') == 'www'
    assert m.group('id') == '209733'

# Generated at 2022-06-26 11:54:32.354202
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print("\nExecuting unit test for the class FuxIE")
    # Example 1
    expected_result = {
        'id': '195359',
        'ext': 'mp4',
        'title': 'Awesome fucking in the kitchen ends with cum swallow',
        'uploader': 'alenci2342',
        'uploader_id': 'alenci2342',
        'upload_date': '20131230',
        'timestamp': 1388361660,
        'duration': 289,
        'view_count': int,
        'like_count': int,
        'categories': list,
        'age_limit': 18,
    }

# Generated at 2022-06-26 11:54:33.706824
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    YouTubeIE()


# Generated at 2022-06-26 11:54:43.661359
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == '4tube:pornerbros'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._TESTS[0]['url'] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-26 11:54:45.895077
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBros = PornerBrosIE();

# Generated at 2022-06-26 11:54:56.837394
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    
    # Create a dictionary that contains the data expected to be
    # returned by the constructor
    expected_data = {'id': '7089759',
                     'ext': 'mp4',
                     'title': 'Teen couple doing anal',
                     'uploader': 'Alexy',
                     'uploader_id': '91488',
                     'upload_date': '20150606',
                     'timestamp': 1433595647,
                     'duration': 5052,
                     'view_count': int,
                     'like_count': int,
                     'age_limit': 18,
                      }
    
    # Create a PornTubeIE object using the URL given in expected_data
    x = PornTubeIE(expected_data['id'])
    # Create a dictionary that contains the data returned by the constructor

# Generated at 2022-06-26 11:54:59.186577
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Instantiation of the class
	FourTubeIE()


# Generated at 2022-06-26 11:55:03.707412
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert type(PornTubeIE) == type(FourTubeBaseIE)

# Generated at 2022-06-26 11:57:57.729887
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(FourTubeBaseIE())._download_json('', '')

# Generated at 2022-06-26 11:58:10.345698
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # normal use
    ie = PornTubeIE()
    ie.extract('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    # video id is missing
    ie.extract('https://www.porntube.com/videos/teen-couple-doing-anal')
    # display id is missing
    ie.extract('https://www.porntube.com/videos/7089759')
    # id is missing
    ie.extract('https://www.porntube.com/videos/teen-couple-doing-anal_test_test_test')
    # embed url
    ie.extract('https://www.porntube.com/embed/7089759')
    # mobile url

# Generated at 2022-06-26 11:58:21.528823
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE

    url = "https://www.porntube.com/embed/123456789"
    print(class_._VALID_URL)
    class_._VALID_URL = re.compile(
        r"^https?://(?:(?:www|m)\.)?"
        r"(?P<domain>porntube\.com)"
        r"(?:/videos/(?P<display_id>[^/]+?)_|/embed/)(?P<id>\d+)$")
    print(class_._VALID_URL)
    # This should not raise an exception
    class_(url, {})
    print(class_._VALID_URL)
    # This however should raise an exception
    import pytest

# Generated at 2022-06-26 11:58:31.779022
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Assert that subclass constructor behaves as expected."""
    ie = FourTubeIE('www.4tube.com', None, None)
    assert ie.site_name == '4tube'
    assert ie.host == 'token.4tube.com'

    ie = FourTubeIE('m.4tube.com', None, None)
    assert ie.site_name == '4tube'
    assert ie.host == 'token.4tube.com'

    ie = FourTubeIE('www.fux.com', None, None)
    assert ie.site_name == 'fux'
    assert ie.host == 'token.fux.com'

    ie = FourTubeIE('m.fux.com', None, None)
    assert ie.site_name == 'fux'

# Generated at 2022-06-26 11:58:36.892148
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        import you_get
        test.test_video_class(FourTubeBaseIE, you_get.common.any_downloader)
    except ImportError:
        pass

# Generated at 2022-06-26 11:58:38.506434
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    return PornTubeIE()._real_extract(
        # Test fake url
        'https://www.porntube.com/videos/video_7089759',
    )

# Generated at 2022-06-26 11:58:43.396689
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')



# Generated at 2022-06-26 11:58:46.532055
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        ie = PornerBrosIE()
        pass # No exception is raised
    except Exception as e:
        raise e

# Generated at 2022-06-26 11:58:51.770423
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .. import get_testcases
    from ..extractor import autopass
    from .common import InfoExtractor
    testcases = get_testcases(FourTubeIE, autopass, [])
    InfoExtractor()._download_webpage = lambda *args, **kwargs: None
    for testcase in testcases:
        getattr(FourTubeIE, testcase['method'])(FourTubeIE, **testcase['kwargs'])

# Generated at 2022-06-26 11:59:04.152919
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
  
  # Create a VideoInfo object representing a collective test video
  videoId = '6516c8ac63b03de06bc8eac14362db4f'
  videoUrl = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
  videoTitle = 'Skinny brunette takes big cock down her anal hole'
  videoUploader = 'PornerBros HD'
  videoUploaderId = 'pornerbros-hd'