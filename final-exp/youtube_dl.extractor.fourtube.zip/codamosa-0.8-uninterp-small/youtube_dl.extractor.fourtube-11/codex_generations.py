

# Generated at 2022-06-26 11:50:03.459099
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert(FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video')
    assert(FuxIE._TKN_HOST == 'token.fux.com')


# Generated at 2022-06-26 11:50:04.895765
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()

# Generated at 2022-06-26 11:50:05.931100
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-26 11:50:14.926849
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fub = FourTubeBaseIE()
    if (fub.IE_NAME != '4tube'):
        print("test_FourTubeBaseIE: IE_NAME")
        assert(False)
    if (fub._VALID_URL != r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'):
        print("test_FourTubeBaseIE: _VALID_URL")
        assert(False)
    if (fub._URL_TEMPLATE != 'https://www.4tube.com/videos/%s/video'):
        print("test_FourTubeBaseIE: _URL_TEMPLATE")
        assert(False)

# Generated at 2022-06-26 11:50:16.159955
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:50:18.481749
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    assert fux_i_e is not None


# Generated at 2022-06-26 11:50:20.577089
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    assert fux_i_e.IE_NAME == "fux"

# Generated at 2022-06-26 11:50:21.814149
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e_0 = FourTubeBaseIE()

# Generated at 2022-06-26 11:50:23.305838
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_case = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:25.020845
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBase_i_e = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:40.543898
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:50:41.473572
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-26 11:50:49.319255
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():

    # Instantiating with URL
    ie = FourTubeIE(url="http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")

    assert ie.url.endswith("209733")
    assert ie.id == "209733"
    assert ie.display_id == "hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"

# Generated at 2022-06-26 11:50:51.639328
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE();
    except:
        assert False, "Unit test for constructor of class PornerBrosIE failed"



# Generated at 2022-06-26 11:51:02.014733
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for ie in [FourTubeIE(), FuxIE(), PornTubeIE(), PornerBrosIE()]:
        _VALID_URL = ie._VALID_URL
        _URL_TEMPLATE = ie._URL_TEMPLATE
        _TKN_HOST = ie._TKN_HOST
        _TESTS = ie._TESTS
        break
    assert _VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?(?P<host>(?:4tube|fux|porntube|pornerbros)\.com)/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert _URL_TEMPLATE == 'https://www.%s/videos/%s/video'

# Generated at 2022-06-26 11:51:09.635705
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Variable '_TKN_HOST' is used in the super class.
    # It is not set in the PornerBrosIE class.
    # The constructor  of the super class is being called by the
    # function 'real_initialize()' of the InfoExtractor class,
    # which is called by the PornerBrosIE constructor.
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:51:11.842814
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:51:22.534151
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    old_PornTubeIE = PornTubeIE
    class NewPornTubeIE(old_PornTubeIE):
        _VALID_URL = r'http://(?:www\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+).*'
        _URL_TEMPLATE = 'http://www.porntube.com/videos/video_%s'
    obj = NewPornTubeIE(old_PornTubeIE._downloader)
    url = 'http://www.porntube.com/embed/7089759'

# Generated at 2022-06-26 11:51:31.878019
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/embed/195359'
    obj = FuxIE(FuxIE._VALID_URL)
    assert obj.IE_NAME == '4tube'
    assert obj._VALID_URL == FuxIE._VALID_URL
    assert obj._URL_TEMPLATE == FuxIE._URL_TEMPLATE
    assert obj._TKN_HOST == FuxIE._TKN_HOST
    assert obj._VALID_URL == FuxIE._VALID_URL
    assert obj._URL_TEMPLATE == FuxIE._URL_TEMPLATE
    assert obj._TKN_HOST == FuxIE._TKN_HOST


# Generated at 2022-06-26 11:51:41.398699
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Note: it is good that all tests are run to ensure the class is
    #       not erronously changed
    #       see "Class Does Not Support Multiple Inheritance"
    ie = FourTubeBaseIE()
    assert ie.IE_DESC == '4tube, Fux, PornTube and PornerBros'
    assert FourTubeIE._VALID_URL == ie._VALID_URL
    assert FourTubeIE._URL_TEMPLATE == ie._URL_TEMPLATE
    assert FourTubeIE._TKN_HOST == ie._TKN_HOST

    ie = FuxIE()
    assert ie.IE_DESC == 'Fux'
    assert FuxIE._VALID_URL == ie._VALID_URL
    assert FuxIE._URL_TEMPLATE == ie._URL_TEMPLATE

# Generated at 2022-06-26 11:52:10.311077
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-26 11:52:12.924522
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TKN_HOST == 'token.fux.com'



# Generated at 2022-06-26 11:52:24.603795
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow'
    class_FuxIE = FuxIE(url)
    # Test value of _TKN_HOST
    assert class_FuxIE._TKN_HOST == 'token.fux.com'
    # Test value of _URL_TEMPLATE
    assert class_FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-26 11:52:34.170182
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie._TESTS[-1]['info_dict']['upload_date'] = '20180910'
    ie._TESTS[-1]['info_dict']['categories'] = ['Amateur']
    ie._TESTS[-1]['info_dict']['age_limit'] = 18
    ie._TESTS[-1]['info_dict']['ext'] = 'webm'

# Generated at 2022-06-26 11:52:39.061126
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    ie = PornTubeIE()
    assert ie._TKN_HOST == 'tkn.porntube.com'
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-26 11:52:40.665973
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE('test')
    except:
        assert False


# Generated at 2022-06-26 11:52:41.315756
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie

# Generated at 2022-06-26 11:52:47.766975
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    print ("Name: ", ie.IE_NAME)
    print ("SUFFIX: ", ie._VALID_URL)
    print ("URL: ", ie._URL_TEMPLATE % '209733')
    print ("HOST: ", ie._TKN_HOST)

if __name__ == "__main__":
    test_FourTubeIE()

# Generated at 2022-06-26 11:52:49.622979
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie, _InfoExtractor)

# Generated at 2022-06-26 11:52:56.911733
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE()
    assert(fux_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video')
    assert(fux_ie._TKN_HOST == 'token.fux.com')


# Generated at 2022-06-26 11:54:14.647985
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    return PornTubeIE('PornTube', 'PornTube', PornTubeIE.IE_NAME, PornTubeIE._VALID_URL)

# Generated at 2022-06-26 11:54:28.633769
# Unit test for constructor of class FuxIE
def test_FuxIE():
    video_url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    obj = FuxIE()
    assert obj._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert obj._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
    assert obj._TKN_HOST == "token.fux.com"


# Generated at 2022-06-26 11:54:29.525059
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-26 11:54:32.687312
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test for instantiation of class
    PornTubeIE(None)

# Generated at 2022-06-26 11:54:35.255205
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj_Fux = FuxIE();
    assert(obj_Fux is not None)


# Generated at 2022-06-26 11:54:36.338145
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():

    PornTubeIE()

# Generated at 2022-06-26 11:54:42.088604
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    from . import PornTubeIE
    from . import FuxIE
    from . import PornerBrosIE
    assert FourTubeIE.__name__ == 'FourTubeIE'
    assert PornTubeIE.__name__ == 'PornTubeIE'
    assert FuxIE.__name__ == 'FuxIE'
    assert PornerBrosIE.__name__ == 'PornerBrosIE'

# Generated at 2022-06-26 11:54:52.712091
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # test fixture
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    test_instance = PornTubeIE(PornTubeIE.ie_key())
    # test method
    result = test_instance._real_extract(url)
    # result assertation
    print(result)

if __name__ == '__main__':
    test_PornTubeIE()

# Generated at 2022-06-26 11:54:53.287971
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-26 11:55:06.611594
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    module = 'test_PornerBrosIE'
    porner_bros_ie = PornerBrosIE()
    assert porner_bros_ie.IE_NAME == 'PornerBros'
    assert porner_bros_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert porner_bros_ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert porner_bros_ie._TKN_HOST == 'token.pornerbros.com'
    assert porner_bros_ie._TESTS

# Generated at 2022-06-26 11:58:07.603909
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    if obj.IE_NAME != '4tube':
        raise Exception('FourTubeIE constructor test failed.')

# Generated at 2022-06-26 11:58:20.646348
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE(FourTubeIE)._assert_initialization(
        FourTubeIE._VALID_URL, FourTubeIE._URL_TEMPLATE, FourTubeIE._TKN_HOST)
    FourTubeBaseIE(FuxIE)._assert_initialization(
        FuxIE._VALID_URL, FuxIE._URL_TEMPLATE, FuxIE._TKN_HOST)
    FourTubeBaseIE(PornTubeIE)._assert_initialization(
        PornTubeIE._VALID_URL, PornTubeIE._URL_TEMPLATE, PornTubeIE._TKN_HOST)

# Generated at 2022-06-26 11:58:22.418541
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    parser = PornTubeIE()

# Generated at 2022-06-26 11:58:23.795694
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)


# Generated at 2022-06-26 11:58:32.709781
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert(ie.IE_NAME=="4tube")
    assert(ie._VALID_URL==r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(ie._URL_TEMPLATE=='https://www.4tube.com/videos/%s/video')
    assert(ie._TKN_HOST=='token.4tube.com')
    assert(len(ie._TESTS)==3)

# Generated at 2022-06-26 11:58:35.090463
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE()
    assert a != None


# Generated at 2022-06-26 11:58:36.892489
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:58:38.954258
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	instance = FourTubeIE()
	instance.suite()


# Generated at 2022-06-26 11:58:50.200016
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_url = "https://fux.com/video/813997/behind-the-scenes-with-happy-tugs-stunning-asian-massage-parlor-girls"
    info = FuxIE().extract(test_url)

    print(info["id"])
    print(info["title"])
    print(info["timestamp"])
    print(info["duration"])
    print(info["age_limit"])
    print(info["categories"])
    print(info["uploader"])
    print(info["uploader_id"])

test_FuxIE()

# Generated at 2022-06-26 11:58:57.807924
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj.is_suitable("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
