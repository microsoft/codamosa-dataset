

# Generated at 2022-06-26 11:49:59.924866
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e = FourTubeIE()

# Generated at 2022-06-26 11:50:01.380808
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._name == 'PornerBros'


# Generated at 2022-06-26 11:50:05.036858
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test for instantiation and initialization of PornerBrosIE class
    pornerBros_i_e = PornerBrosIE()
    assert pornerBros_i_e != None, "Failed during instantiation"

# Generated at 2022-06-26 11:50:06.077212
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()

# Generated at 2022-06-26 11:50:15.021087
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e = FourTubeIE()
    assert four_tube_i_e._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert four_tube_i_e._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert four_tube_i_e._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:50:25.522092
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube_ie0 = PornTubeIE()
    assert porntube_ie0._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert porntube_ie0._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert porntube_ie0._TKN_HOST == 'tkn.porntube.com'
    assert porntube_ie0._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'


# Generated at 2022-06-26 11:50:26.456295
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()


# Generated at 2022-06-26 11:50:27.441789
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_case_0()

# Generated at 2022-06-26 11:50:28.903856
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:29.896706
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE() is not None


# Generated at 2022-06-26 11:50:57.649844
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-26 11:51:08.479700
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():

    porner_bros = PornerBrosIE()
    assert porner_bros._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert porner_bros._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert porner_bros._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:51:12.627909
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-26 11:51:23.225731
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pytest.importorskip('base64')
    pytest.importorskip('jsbeautifier')
    assert PornerBrosIE._VALID_URL == \
        r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._URL_TEMPLATE == \
        'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == \
        'token.pornerbros.com'

# Generated at 2022-06-26 11:51:27.070120
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE('https://www.porntube.com/videos/nothing_123')
        raise Exception()
    except ValueError:
        pass

# Generated at 2022-06-26 11:51:28.481802
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pti = PornTubeIE()
    assert(pti.IE_NAME == 'PornTube')


# Generated at 2022-06-26 11:51:38.939770
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        import selenium as sl
    except ImportError as e:
        raise Exception('Selenium not installed. Cannot run unit test for FourTubeIE')

    from selenium import webdriver

    try:
        driver = webdriver.PhantomJS()
    except sl.common.exceptions.WebDriverException as e:
        raise Exception('PhantomJS not installed. Cannot run unit test for FourTubeIE')

    url = "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    driver.get(url)
    driver.implicitly_wait(10)

    div = driver.find_element_by_class_name('js-player')
    embed = div.find_element_by_tag_name

# Generated at 2022-06-26 11:51:53.261501
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    with (open('./test/test_data/4tube_test_json.txt', 'r')) as f:
        # read source video file
        video_file = f.read()
    video = FourTubeIE._parse_json(video_file, "test")['page']['video']
    print("title: %s" % video['title'])
    print("likeCount: %s" % video['likes'])
    print("dislikeCount: %s" % video['dislikes'])
    print("masterThumb: %s" % video['masterThumb'])
    print("mediaId: %s" % video['mediaId'])
    print("publishedAt: %s" % video['publishedAt'])
    print("durationInSeconds: %s" % video['durationInSeconds'])
   

# Generated at 2022-06-26 11:52:05.531359
# Unit test for constructor of class FuxIE
def test_FuxIE():

    # Test normal usage
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    FuxIE(FuxIE.ie_key())._match_id(url)
    FuxIE(FuxIE.ie_key()).working()
    FuxIE(FuxIE.ie_key())._TESTS[0].get("url")

    # Test invalid url
    invalid_url = 'https://www.fux.com/video/195359/'
    FuxIE(FuxIE.ie_key())._match_id(invalid_url)
    FuxIE(FuxIE.ie_key()).working()

# Generated at 2022-06-26 11:52:09.308328
# Unit test for constructor of class FuxIE
def test_FuxIE():
    'Unit test for constructor of class FuxIE'
    print(FuxIE(None)._VALID_URL)

# Generated at 2022-06-26 11:52:41.478213
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie_instance = FourTubeBaseIE()
    assert ie_instance.IE_NAME == '4tube', ie_instance.IE_NAME

# Generated at 2022-06-26 11:52:43.086007
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	PornerBrosIE()


# Generated at 2022-06-26 11:52:45.384841
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie is not None

# Generated at 2022-06-26 11:52:47.918268
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:52:54.945214
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pbr = PornerBrosIE()
    assert pbr._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pbr._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:52:59.852287
# Unit test for constructor of class FuxIE
def test_FuxIE():
    x = FuxIE("http://www.fux.com/video/209733/awesome-fucking-kitchen-ends-cum-swallow")

    assert(x.IE_NAME == "4tube")


# Generated at 2022-06-26 11:53:01.876869
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    obj = PornerBrosIE()
    assert obj

# Generated at 2022-06-26 11:53:09.748225
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE._download_json = lambda self, url, video_id, data=None, headers=None: {
        '720p': {'token': '720p'},
        '480p': {'token': '480p'},
        '360p': {'token': '360p'},
    }
    FourTubeBaseIE._extract_formats('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', '209733', '70818', ['720p', '480p', '360p'])

# Generated at 2022-06-26 11:53:13.391610
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    assert pornerbros.IE_NAME == 'PornerBros'



# Generated at 2022-06-26 11:53:18.043106
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    return FourTubeIE()._extract_formats('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
                                         '209733', '209733', ['480', '720'])

# Generated at 2022-06-26 11:54:36.887338
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from unittest import TestCase
    from ..utils import TestData

    class TestPornerBrosIE(TestCase):
        def test_create_instance(self):
            obj = PornerBrosIE()

    TestData.create_instance(TestPornerBrosIE,
                             PornerBrosIE,
                             "PornerBrosIE.instance_id")

# Generated at 2022-06-26 11:54:38.266308
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE == PornerBrosIE

# Generated at 2022-06-26 11:54:43.776287
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_fourtubebase = FourTubeBaseIE()
    # The test for _VALID_URL errors when trying to access the page
    # test_fourtubebase._valid_url()
    # The test for _download_webpage errors when trying to access the page
    # test_fourtubebase._download_webpage()
    # The test for _real_initialize() errors when trying to access the page
    # test_fourtubebase._real_initialize()

# Unit tests for FourTubeIE

# Generated at 2022-06-26 11:54:47.745775
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor = FourTubeBaseIE()
    assert info_extractor._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-26 11:54:48.741173
# Unit test for constructor of class FuxIE
def test_FuxIE():
    return FuxIE

# Generated at 2022-06-26 11:54:51.469441
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    SieConstructorTest('PornTube');

# Generated at 2022-06-26 11:54:53.075574
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie=FuxIE()
    print(fux_ie)

# Generated at 2022-06-26 11:54:54.608285
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test an empty constructor
    PornTubeIE()

# Generated at 2022-06-26 11:55:04.486497
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-26 11:55:17.267006
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..compat import unittest
    from ..utils import fake_httpd

    def request_handler(handler):
        handler.protocol_version = 'HTTP/1.1'
        return True

    def token_handler(handler):
        return (
            200,
            {'Content-Type': 'application/json'},
            '{"1080p": {"token": "1080p"}, "720p": {"token": "720p"}, "480p": {"token": "480p"}, "240p": {"token": "240p"}}'
        )

    test = unittest.TestCase()

# Generated at 2022-06-26 11:58:17.530434
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie is not None

# Generated at 2022-06-26 11:58:18.623503
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()

# Generated at 2022-06-26 11:58:27.350863
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIe = PornerBrosIE('https://www.pornerbros.com/videos/video_181369')
    assert pornerBrosIe._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerBrosIe._TKN_HOST == 'token.pornerbros.com'
    return

# Generated at 2022-06-26 11:58:34.589130
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from youtube_dl.compat import unittest
    from .test_common import FakeYDL
    from .test_4tube import FourTubeBaseTestCase
    from .test_porntube import PornTubeTestCase
    from .test_4tube import _TestInfoExtractor

    import sys
    import re
    import copy

    def get_testcases(file_test, regex_test=None):
        tests = []
        name = re.match(r'^test_(.+)\.py$', file_test).group(1)
        if name == 'common':
            return tests

        ydl = FakeYDL()
        ydl_opts = copy.copy(ydl._default_options)
        ydl_opts['logger'] = ydl

        suites = []

# Generated at 2022-06-26 11:58:35.184068
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:58:42.455971
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube', 'itag', 'token_host')
    assert ie._TKN_HOST == 'token_host'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?itag\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.itag.com/videos/%s/video'

# Generated at 2022-06-26 11:58:52.963782
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        import pprint
        pp = pprint.PrettyPrinter(indent=4)
    except ImportError:
        class PrettyPrinterEmul(object):
            def pprint(temp, *args, **kwargs):
                print(temp)

        pp = PrettyPrinterEmul()

    from youtube_dl.extractor import YoutubeDL
    from youtube_dl.utils import ExtractorError
    from youtube_dl import compat_str

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    # Verify www.porntube.com

# Generated at 2022-06-26 11:59:02.522500
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_class = PornerBrosIE('PornerBrosIE', 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert test_class._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'


# Generated at 2022-06-26 11:59:05.466994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    temp = FourTubeIE()
    assert temp._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:59:10.016746
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/embed/7089759'
    test_object = PornTubeIE(url)
    assert test_object != None