

# Generated at 2022-06-26 11:50:11.248924
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Pass str_or_none as self._download_webpage does not really download webpage
    porner_bros_i_e_0 = PornerBrosIE()
    porner_bros_i_e_0._download_webpage = str_or_none
    porner_bros_i_e_0._search_regex = str_or_none
    porner_bros_i_e_0._parse_json = str_or_none

    porner_bros_i_e_0._download_webpage = str_or_none
    porner_bros_i_e_0._search_regex = str_or_none
    porner_bros_i_e_0._parse_json = str_or_none

    # Pass str_or_none as self._download_webpage does

# Generated at 2022-06-26 11:50:12.779000
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()
    

# Generated at 2022-06-26 11:50:22.984202
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
  url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
  four_tube_base_i_e_0 = FourTubeBaseIE()
  four_tube_base_i_e_0.suitable(url)
  four_tube_base_i_e_0.extract(url)
  mobj = re.match(four_tube_base_i_e_0._VALID_URL,url)
  kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
  four_tube_base_i_e_0._extract_formats(url, video_id, "12345678", [])
  four_tube_base_i

# Generated at 2022-06-26 11:50:24.765300
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:50:26.025984
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:28.533648
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    if not isinstance(obj, FourTubeBaseIE):
        raise AssertionError("Not a FourTubeBaseIE")


# Generated at 2022-06-26 11:50:29.852406
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:50:31.512427
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:33.070963
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert type(FourTubeBaseIE()) == FourTubeBaseIE


# Generated at 2022-06-26 11:50:34.321132
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:51:17.175151
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # get parameters
    # get fields
    # get formats
    # test field 'id'
    assert four_tube_i_e_0.get('id') == '209733'
    # test field 'ext'
    assert four_tube_i_e_0.get('ext') == 'mp4'
    # test field 'title'
    assert four_tube_i_e_0.get('title') == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    # test field 'uploader'
    assert four_tube_i_e_0.get('uploader') == 'WCP Club'
    # test field 'uploader_id'
    assert four_tube_i_e_0.get('uploader_id') == 'wcp-club'
    # test field 'upload_date'
    assert four_

# Generated at 2022-06-26 11:51:18.998943
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE().IE_NAME == 'PORNERBROS.COM'


# Generated at 2022-06-26 11:51:20.466174
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:51:21.996581
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:51:23.841592
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e_0 = FourTubeIE()
    assert(four_tube_i_e_0)


# Generated at 2022-06-26 11:51:34.532890
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()
    assert pornerbros_i_e._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerbros_i_e._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert pornerbros_i_e._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:51:35.900002
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:51:38.090890
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:39.346807
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_ie_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:42.567232
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_IE = PornerBrosIE()



# Generated at 2022-06-26 11:52:47.216020
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    t = FourTubeIE()
    assert t.suitable('https://www.4tube.com/embed/209733') != False
    assert t.suitable('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black') != False
    assert t.suitable('https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black') != False
    assert t.suitable('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow') == False

# Generated at 2022-06-26 11:52:57.487050
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE.IE_NAME == '4tube'
    assert FourTubeBaseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeBaseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeBaseIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:52:59.441297
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie_0 = FuxIE()


# Generated at 2022-06-26 11:53:01.457399
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:53:05.743228
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_i_e = FourTubeIE()
    assert four_tube_i_e.IE_NAME == '4tube'


# Generated at 2022-06-26 11:53:08.644994
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert isinstance(obj, FourTubeIE)


# Generated at 2022-06-26 11:53:10.918884
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner_bros_i_e = PornerBrosIE()

# Generated at 2022-06-26 11:53:13.465572
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:53:21.489040
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert four_tube_i_e_0.IE_NAME == '4tube'
    assert four_tube_i_e_0._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert four_tube_i_e_0._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert four_tube_i_e_0._TKN_HOST == 'token.4tube.com'
    assert len(four_tube_i_e_0._TESTS) == 4

# Generated at 2022-06-26 11:53:23.641645
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()


# Generated at 2022-06-26 11:54:56.140646
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:55:07.141763
# Unit test for constructor of class FuxIE
def test_FuxIE():
    data = 'awesome fucking kitchen ends cum swallow'
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    fuxIE = FuxIE()
    assert fuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'    
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == "token.fux.com"

# Generated at 2022-06-26 11:55:10.242577
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	ie = PornTubeIE()

# Generated at 2022-06-26 11:55:15.654622
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url='https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    downloader=FuxIE()
    info=downloader._real_extract(url)
    info=downloader._real_extract(url)
    assert 'id' in info

# Generated at 2022-06-26 11:55:18.117627
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(FourTubeBaseIE(), 'FourTube', '4tube.com')



# Generated at 2022-06-26 11:55:20.665311
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Validate constructor
    x = PornerBrosIE()
    assert(isinstance(x, object))

# Generated at 2022-06-26 11:55:26.275310
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._download_json('http://token.fux.com/5/542/111350/desktop/720', "7089759", data=b'', headers={
    'Origin': '%s://%s' % ('https', 'www.fux.com'),
    'Referer': 'http://www.fux.com/embed/7089759'
    })

# Generated at 2022-06-26 11:55:27.738170
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert hasattr(PornTubeIE, '_TESTS')

# Generated at 2022-06-26 11:55:30.387904
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE(None)
        assert False
    except NotImplementedError as e:
        assert_equals(e.message, 'FourTubeBaseIE is an abstract class.')

# Generated at 2022-06-26 11:55:38.782344
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    # test case 1: url is legal url
    url = "https://www.fux.com"
    print("Test Case 1: url is legal url. url = " + url)
    ie.extract(url)
    # test case 2: url is not legal url
    url = "https://www.fux.com/video/"
    print("Test Case 2: url is not legal url. url = " + url)
    try:
        ie.extract(url)
    except Exception:
        pass
    print("Test Case 2 is finished.")
    # test case 3: url is unknown website
    url = "https://www.sdfsdfs.com/video/"
    print("Test Case 3: url is unknown website. url = " + url)

# Generated at 2022-06-26 11:58:53.525547
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-26 11:59:02.799882
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-26 11:59:08.214072
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # test constructors of classes that directly inheritance from PornerBrosIE
    for ie_class in [FuxIE, PornTubeIE]:
        assert (issubclass(ie_class, PornerBrosIE))


# Generated at 2022-06-26 11:59:10.088502
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:59:17.099493
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbrosIE = PornerBrosIE()
    assert pornerbrosIE.ie_key() == 'PornerBros'
    assert pornerbrosIE.ie_name() == 'PornerBros'
    assert pornerbrosIE.mime_type() == 'text/plain'
    assert pornerbrosIE.ext() == 'txt'
    assert pornerbrosIE.api_code() == 0
    assert pornerbrosIE.get_test() == 'test'
    assert pornerbrosIE.get_test_method() == None
    assert pornerbrosIE.get_test_result() == None
    assert pornerbrosIE.is_logged() == False
    assert pornerbrosIE.logging() == False
    assert pornerbrosIE.set_logging

# Generated at 2022-06-26 11:59:18.715499
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p is not None

# Generated at 2022-06-26 11:59:23.142139
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():

    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    
    PornerBrosIE()

# Generated at 2022-06-26 11:59:36.162133
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert(ie.REAL_URL_PATTERN.findall('http://www.porntube.com/videos/teen-couple-doing-anal_7089759') == [('www', '', '7089759')])
    assert(ie.REAL_URL_PATTERN.findall('https://m.porntube.com/videos/teen-couple-doing-anal_7089759') == [('m', '', '7089759')])
    assert(ie.REAL_URL_PATTERN.findall('https://www.porntube.com/embed/7089759') == [('www', 'embed/', '7089759')])

# Generated at 2022-06-26 11:59:41.961772
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')