

# Generated at 2022-06-26 11:50:04.636325
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_i_e = FourTubeIE()
    four_i_e.ie_name
    four_i_e.ie_key
    four_i_e.host
    four_i_e_1 = FourTubeIE()
    four_i_e_2 = FourTubeIE({"output_dir": "./output/"})
    assert (four_i_e_1 == four_i_e_2)
    assert (four_i_e_1 is not four_i_e_2)


# Generated at 2022-06-26 11:50:08.544313
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert (FuxIE()._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')

# Generated at 2022-06-26 11:50:09.770680
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-26 11:50:11.198103
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ftie = FourTubeIE()
    ftie

# Generated at 2022-06-26 11:50:12.741097
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_case = FourTubeBaseIE()
    assert test_case != None


# Generated at 2022-06-26 11:50:17.085184
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)"


# Generated at 2022-06-26 11:50:18.341560
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourtube = FourTubeBaseIE()

# Generated at 2022-06-26 11:50:19.704014
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_ie_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:20.647507
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-26 11:50:30.315755
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e = FuxIE()
    assert fux_i_e._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_i_e._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_i_e._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-26 11:50:46.471229
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube_i_e_0 = FourTubeIE()


# Generated at 2022-06-26 11:50:48.839253
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb_i_e = PornerBrosIE()


# Generated at 2022-06-26 11:50:49.830042
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:50:50.905189
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-26 11:50:53.229286
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()

# Generated at 2022-06-26 11:51:02.552369
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    # Initialize object of class FourTubeBaseIE
    f_t_b_i_e_0 = FourTubeBaseIE()

    # Access to protected attribute _VALID_URL
    try:
        f_t_b_i_e_0._VALID_URL
    except AttributeError as e:
        print("FAILED: {}".format(e))
    else:
        print("SUCCESS")

    # Access to protected attribute _URL_TEMPLATE
    try:
        f_t_b_i_e_0._URL_TEMPLATE
    except AttributeError as e:
        print("FAILED: {}".format(e))
    else:
        print("SUCCESS")

    # Access to protected attribute _TKN_HOST

# Generated at 2022-06-26 11:51:04.196654
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:51:07.355414
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:51:08.420387
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()
	

# Generated at 2022-06-26 11:51:09.880028
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:39.428044
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_i_e = PornerBrosIE()

# Generated at 2022-06-26 11:51:42.568417
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE();


# Generated at 2022-06-26 11:51:46.189490
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_class_obj = FourTubeIE()
    assert test_class_obj.IE_NAME == "4tube"


# Generated at 2022-06-26 11:51:48.375395
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tub_i_e = PornTubeIE()


# Generated at 2022-06-26 11:51:49.661835
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie_0 = PornerBrosIE()


# Generated at 2022-06-26 11:51:50.902134
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()


# Generated at 2022-06-26 11:51:52.872196
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i_e = PornerBrosIE()
    print(i_e)

# Generated at 2022-06-26 11:51:56.465507
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_ie = FourTubeBaseIE()
    # Assert that FourTubeBaseIE is an instance of InfoExtractor
    assert four_tube_ie

# Generated at 2022-06-26 11:51:59.268070
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()
    assert fourtube.IE_NAME == '4tube'

# Generated at 2022-06-26 11:52:07.115148
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fb = FourTubeBaseIE()
    assert fb._VALID_URL == None
    assert fb._URL_TEMPLATE == None
    assert fb._TKN_HOST == None
    assert fb._TESTS == []
    assert fb._NETRC_MACHINE == None
    assert fb._downloader == None
    assert fb._download_webpage_handle == None
    assert fb._download_webpage_impl == None
    assert fb._downloader_options == None
    assert fb._download_retry == None
    assert fb._error_download_retry == None
    assert fb._geo_verification_headers == None
    assert fb._html_search_meta == None
    assert fb._html_search_regex == None

# Generated at 2022-06-26 11:53:06.288822
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    four_tube_base_i_e = FourTubeBaseIE()


# Generated at 2022-06-26 11:53:07.875567
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()


# Generated at 2022-06-26 11:53:10.437361
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube_i_e_0 = PornTubeIE()

# Generated at 2022-06-26 11:53:11.843785
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()

# Generated at 2022-06-26 11:53:14.471010
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()


# Generated at 2022-06-26 11:53:18.516773
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url_for_id = "https://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow"
    fux_i_e_1 = FuxIE()
    fux_i_e_1.extract(url_for_id)


# Generated at 2022-06-26 11:53:20.037065
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_case_0()


# Generated at 2022-06-26 11:53:25.858178
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-26 11:53:32.296148
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTube_i_e = FourTubeIE()

    assert(fourTube_i_e._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?")
    assert(fourTube_i_e.IE_NAME == "4tube")
    assert(fourTube_i_e._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video")
    assert(fourTube_i_e._TKN_HOST == "token.4tube.com")



# Generated at 2022-06-26 11:53:33.696274
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube = PornTubeIE()

# Generated at 2022-06-26 11:54:54.988859
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .common import InfoExtractor
    from .pornhub import PornHubIE

    ie = PornTubeIE()
    ie2 = PornHubIE()
    assert(isinstance(ie, InfoExtractor))
    assert(isinstance(ie2, InfoExtractor))
    assert(ie != ie2)

# Generated at 2022-06-26 11:55:07.353392
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    fourtube_ie = FourTubeIE()
    assert fourtube_ie.ie_key() == '4tube'


# Generated at 2022-06-26 11:55:17.934381
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    video_id = '209733'
    media_id = '4614135'
    sources = ['480', '720']
    formats = ie._extract_formats('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
                                  video_id, media_id, sources)

# Generated at 2022-06-26 11:55:26.077358
# Unit test for constructor of class FuxIE
def test_FuxIE():
    def test_assert(url):
        try:
            FuxIE(url)
        except:
            return False
        return True
    assert test_assert('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert not test_assert('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-26 11:55:37.312937
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Extract one of the 4tube videos and check the number of formats
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeIE._VALID_URL, url)
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    if kind == 'm' or not display_id:
        url = FourTubeIE._URL_TEMPLATE % video_id
    webpage = FourTubeIE._download_webpage(url, video_id)

# Generated at 2022-06-26 11:55:47.153290
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-26 11:55:52.902462
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'
    assert PornerBrosIE.__doc__ == ''
    assert PornerBrosIE.__module__ == 'youtube_dl.extractor.fourtube'

# Generated at 2022-06-26 11:55:55.178705
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-26 11:55:57.174318
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE.__name__ == 'FourTubeIE')

# Generated at 2022-06-26 11:56:00.286510
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()
    FuxIE()
    PornerBrosIE()
    FourTubeIE()

# Generated at 2022-06-26 11:59:11.480182
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test case for pattern match
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:59:23.179106
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .fux_ie import FuxIE
    fux = FuxIE()
    assert fux._TKN_HOST == 'token.fux.com'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:59:33.842625
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'
    return True

# Generated at 2022-06-26 11:59:45.713551
# Unit test for constructor of class FourTubeIE