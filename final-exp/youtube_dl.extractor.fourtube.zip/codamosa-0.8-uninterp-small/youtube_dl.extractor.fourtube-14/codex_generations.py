

# Generated at 2022-06-26 11:49:58.549338
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()


# Generated at 2022-06-26 11:49:59.591393
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    a = FourTubeIE()

# Generated at 2022-06-26 11:50:01.038036
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie_0 = PornerBrosIE()


# Generated at 2022-06-26 11:50:02.869630
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    fourTubeBaseIE = FourTubeBaseIE()


# Generated at 2022-06-26 11:50:12.920129
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_i_e_0 = FuxIE()
    assert isinstance(fux_i_e_0, FuxIE)
    assert isinstance(fux_i_e_0, FourTubeBaseIE)
    assert fux_i_e_0.IE_NAME == 'Fux'
    assert fux_i_e_0.IE_DESC == 'Fux'
    assert fux_i_e_0._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-26 11:50:14.305836
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()


# Generated at 2022-06-26 11:50:15.537832
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()


# Generated at 2022-06-26 11:50:17.077980
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p_t_i_e_0 = PornTubeIE()


# Generated at 2022-06-26 11:50:26.329035
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert (
        FuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    ), 'FuxIE.VALID_URL is incorrect'
    assert (
        FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    ), 'FuxIE._URL_TEMPLATE is incorrect'
    assert (
        FuxIE._TKN_HOST == 'token.fux.com'
    ), 'FuxIE._TKN_HOST is incorrect'


# Generated at 2022-06-26 11:50:32.593859
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_i_e = PornTubeIE()
    assert porn_tube_i_e._TESTS[0].get('url') == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert porn_tube_i_e._TESTS[1].get('url') == 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'


# Generated at 2022-06-26 11:50:54.177122
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    t = FourTubeBaseIE()
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(t._VALID_URL, url)
    assert mobj.group('id') == '209733'
    assert 'm' in mobj.group('kind')

# Generated at 2022-06-26 11:51:02.113376
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import youtube_dl
    test_url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    test_url2 = "https://m.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    ydl = youtube_dl.YoutubeDL()
    result = ydl.extract_info(test_url, download=False)
    result2 = ydl.extract_info(test_url2, download=False)
    assert (result['title'] == result2['title'] == 'Awesome fucking in the kitchen ends with cum swallow')

# Generated at 2022-06-26 11:51:11.229951
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    if __name__ == "__main__":
        # This is the string we will test on
        input_value = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
        output_value = 'https://www.4tube.com/videos/209733/video'
        obj = FourTubeIE()
        assert input_value, obj._VALID_URL
        assert output_value, obj._URL_TEMPLATE

# Generated at 2022-06-26 11:51:12.451394
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        from .test_FourTubeIE import TestFourTubeIE
        TestFourTubeIE()
    except (SystemExit, AttributeError):
        pass


# Generated at 2022-06-26 11:51:23.146848
# Unit test for constructor of class FuxIE
def test_FuxIE():
    resp = FuxIE()
    # Check if the value of _TESTS() is not empty
    assert(resp._TESTS)
    # Check if the value of _VALID_URL() is not empty
    assert(resp._VALID_URL)
    # Check if the value of _URL_TEMPLATE() is not empty
    assert(resp._URL_TEMPLATE)
    # Check if the value of _TKN_HOST() is not empty
    assert(resp._TKN_HOST)
    # Check if the value of IE_NAME() is not empty
    assert(resp.IE_NAME)
    # Check if the value of IE_DESC() is not empty
    assert(resp.IE_DESC)
    # Check if the value of _VALID_URL() is not empty

# Generated at 2022-06-26 11:51:27.845330
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._VALID_URL is not None
    assert ie._URL_TEMPLATE is not None
    assert ie._TKN_HOST is not None
    assert ie._TESTS is not None


# Generated at 2022-06-26 11:51:30.149485
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')


# Generated at 2022-06-26 11:51:31.522422
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj is not None  # no exception thrown

# Generated at 2022-06-26 11:51:33.094972
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._TESTS

# Generated at 2022-06-26 11:51:34.239698
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert(FourTubeBaseIE == FourTubeBaseIE())

# Generated at 2022-06-26 11:52:06.697329
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():

    # FourTubeBaseIE is not instantiable
    with pytest.raises(TypeError):
        FourTubeBaseIE()

# Generated at 2022-06-26 11:52:18.235315
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class test_FourTubeBaseIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.pornerbros.com/videos/video_%s'
        _TKN_HOST = 'token.pornerbros.com'
    test_url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    class_test = test_FourTubeBaseIE()

# Generated at 2022-06-26 11:52:25.003250
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    TestFourTubeIE = FourTubeIE("test_FourTubeIE")
    assert TestFourTubeIE.IE_NAME == "4tube"\
           and TestFourTubeIE._VALID_URL\
           and TestFourTubeIE._URL_TEMPLATE\
           and TestFourTubeIE._TKN_HOST\
           and TestFourTubeIE._TESTS



# Generated at 2022-06-26 11:52:28.632802
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'



# Generated at 2022-06-26 11:52:37.461582
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        with open('test_FourTubeBaseIE.txt', 'r') as f:
            tmp = f.read().split('\n')
            url = tmp[0]
            res = tmp[1]
        print('testing url: ' + url + ' ....')
        blob = FourTubeBaseIE()._download_webpage(url, 'xx')
        if blob == res:
            print('PASS')
            return True
        else:
            print('FAIL')
            return False
    except Exception as e:
        print('FAIL')
        print(e)
        return False

# Generated at 2022-06-26 11:52:49.835447
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Case 1: All extracted fields
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    porntube = PornTubeIE()
    porntube._download_webpage = lambda *a, **ka: ''
    porntube._parse_json = lambda *a, **ka: {}
    porntube._search_regex = lambda *a, **ka: ''
    porntube.extract(url)
    # Case 2: An extracted field
    url = 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    porntube = PornTubeIE()

# Generated at 2022-06-26 11:52:51.961835
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-26 11:52:54.941611
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    if not FourTubeBaseIE:
        raise ValueError('Must define FourTubeBaseIE')
    with InfoExtractor(None) as ie:
        # For some reason, this raises AttributeError in the global scope
        try:
            ie.add_ie(FourTubeBaseIE(None))
        except AttributeError as e:
            raise e

# Generated at 2022-06-26 11:52:56.301569
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()

# Generated at 2022-06-26 11:52:58.935015
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert hasattr(instance, '_VALID_URL')

# Generated at 2022-06-26 11:54:11.475177
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:54:14.115161
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    test = FourTubeIE(url)
    assert test.get_formats()


# Generated at 2022-06-26 11:54:16.175852
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE.__name__ == 'FourTubeBaseIE'

# Generated at 2022-06-26 11:54:22.989356
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.headers['User-Agent'] == 'Mozilla/5.0 (X11; Linux x86_64; rv:11.0) Gecko/20100101 Firefox/11.0 (Chrome)'
    assert ie.headers['Referer'] == 'https://www.4tube.com/', ie.headers['Referer']  #Verify Referer is www4tube.com and not www.4tube.com


# Generated at 2022-06-26 11:54:26.221978
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Constructor should return a non-None value."""
    ie = FourTubeBaseIE()
    assert ie is not None

    # Test that constructor raises an exception when called with a bogus
    # URL.
    ie = FourTubeBaseIE()
    assert ie is not None
    ie._VALID_URL = r'(?P<badURL>.*)'

    try:
        ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')
        raise Exception('constructor should have raised exception')
    except RegexNotFoundError:
        pass



# Generated at 2022-06-26 11:54:29.551482
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie, FourTubeIE)


# Generated at 2022-06-26 11:54:42.507287
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    testFile = 'test.txt'

    # Test constructor case 1
    obj = FourTubeIE(testFile)
    print(obj)

    # Test constructor case 2
    obj = FourTubeIE(testFile, 'some')
    print(obj)

    # Test constructor case 3
    obj = FourTubeIE(testFile, 'some', 'args')
    print(obj)

    # Test constructor case 4
    obj = FourTubeIE(testFile, 'some', 'args', 'more')
    print(obj)

    # Test constructor case 5
    obj = FourTubeIE(testFile, 'some', 'args', 'more', 'than')
    print(obj)

    # Test constructor case 6
    obj = FourTubeIE(testFile, 'some', 'args', 'more', 'than', 'offical')
    print(obj)

# Generated at 2022-06-26 11:54:56.265297
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor = FourTubeBaseIE()

    token_url = 'https://token.4tube.com/11111/desktop/360+480+720'
    parsed_url = compat_urlparse.urlparse('https://www.4tube.com/videos/11111')
    tokens = info_extractor._download_json(token_url, '11111', data=b'', headers={
        'Origin': '%s://%s' % (parsed_url.scheme, parsed_url.hostname),
        'Referer': 'https://www.4tube.com/videos/11111',
    })
    assert isinstance(tokens, dict)
    assert tokens[b'360']['token'] == b'360'
    assert tokens[b'480']['token'] == b'480'

# Generated at 2022-06-26 11:54:57.145555
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-26 11:54:58.838876
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    compat_str(FourTubeBaseIE)

# Generated at 2022-06-26 11:57:54.627071
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Class FourTubeIE has no unit tests.
    """
    assert False

# Generated at 2022-06-26 11:58:01.813567
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert instance.IE_NAME == '4tube'
    assert instance._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert instance._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert instance._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-26 11:58:09.109439
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Can't instantiate PornTubeIE.
    #
    # AttributeError: can't set attribute
    # 
    # TypeError: Error when calling the metaclass bases
    # module.__init__() takes at most 2 arguments (3 given)
    # 
    # TypeError: Error when calling the metaclass bases
    # module.__init__() takes at most 2 arguments (3 given)
    PornTubeIE('PornTube')

# Generated at 2022-06-26 11:58:12.321965
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    e = FourTubeBaseIE()
    assert str(e) == 'class FourTubeBaseIE'


# Generated at 2022-06-26 11:58:14.051176
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    IEConstructionContract(FourTubeBaseIE)

# Generated at 2022-06-26 11:58:18.285630
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
   # Test IE with input that has a wrong URL
   invalid_ie = FourTubeIE(1)
   assert invalid_ie._VALID_URL ==  None
   assert invalid_ie._TESTS == None

# Generated at 2022-06-26 11:58:22.742643
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_data = [
        ['http://www.porntube.com/videos/naked_truckers_2459553', 'porntube.com'],
        ['http://www.porntube.com/embed/2459553', 'porntube.com'],
        ['http://m.porntube.com/videos/naked_truckers_2459553', 'porntube.com'],
    ]
    for url, label in test_data:
        assert label == PornTubeIE._VALID_URL_RE.search(url).group('host')

# Generated at 2022-06-26 11:58:25.308381
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .common import InfoExtractor
    InfoExtractor(PornerBrosIE.ie_key())



# Generated at 2022-06-26 11:58:33.205673
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test different schemes, and keys in networklocations dictionary
    assert FourTubeIE._VALID_URL.match("http://www.4tube.com/embed/164789")
    assert FourTubeIE._VALID_URL.match("https://www.4tube.com/embed/164789")
    assert FourTubeIE._VALID_URL.match("http://m.4tube.com/embed/164789")
    assert FourTubeIE._VALID_URL.match("https://m.4tube.com/embed/164789")
    assert FourTubeIE._VALID_URL.match("http://www.4tube.com/videos/164789/anna-joy-hairy-lust")

# Generated at 2022-06-26 11:58:44.526978
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'http://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    video_id, display_id = re.match(
        PornTubeIE._VALID_URL, url).group('id', 'display_id')
    webpage = PornTubeIE._download_webpage(url, display_id)
    media_id = PornTubeIE._search_regex(
        r'<button[^>]+data-id=(["\'])(?P<id>\d+)\1[^>]+data-quality=', webpage,
        'media id', default=None, group='id')
    sources = [
        quality
        for _, quality in re.findall(r'<button[^>]+data-quality=(["\'])(.+?)\1', webpage)]
   