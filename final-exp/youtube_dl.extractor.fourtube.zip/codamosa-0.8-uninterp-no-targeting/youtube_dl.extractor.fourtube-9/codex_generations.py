

# Generated at 2022-06-22 07:27:06.668288
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    youtube_dl_utilities = PornTubeIE({})
    video_object = youtube_dl_utilities._real_extract(test_url)

    assert(video_object['id'] == '7089759')
    assert(video_object['ext'] == 'mp4')
    assert(video_object['title'] == 'Teen couple doing anal')
    assert(video_object['uploader'] == 'Alexy')
    assert(video_object['uploader_id'] == '91488')
    assert(video_object['upload_date'] == '20150606')
    assert(video_object['timestamp'] == 1433595647)

# Generated at 2022-06-22 07:27:07.381744
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass


# Generated at 2022-06-22 07:27:07.969437
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE

# Generated at 2022-06-22 07:27:18.115345
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:27:18.775433
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE({})

# Generated at 2022-06-22 07:27:22.894437
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        import uuid
        assert uuid.uuid4
        assert uuid.uuid4().hex
    except:
        assert False
    ftb = FourTubeBaseIE(uuid.uuid4().hex)
    assert ftb._VALID_URL
    assert ftb._URL_TEMPLATE
    assert ftb._TKN_HOST
    assert ftb.IE_NAME
    assert ftb._TESTS

# Generated at 2022-06-22 07:27:29.992775
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..test import get_testcases

    for test_case in get_testcases(FourTubeIE):
        yield test_case
    for test_case in get_testcases(FuxIE):
        yield test_case
    for test_case in get_testcases(PornTubeIE):
        yield test_case
    for test_case in get_testcases(PornerBrosIE):
        yield test_case

# Generated at 2022-06-22 07:27:33.585967
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Make sure an exception is raised if _TKN_HOST is not overriden
    try:
        FourTubeBaseIE()
    except Exception as e:
        assert type(e) == AttributeError

# Generated at 2022-06-22 07:27:39.738458
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE('http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert fux_ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux_ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux_ie._TKN_HOST == 'token.fux.com'



# Generated at 2022-06-22 07:27:46.960987
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('https://www.pornerbros.com/embed/181369', '', '', '')
    assert ie._TKN_HOST is 'token.pornerbros.com'
    assert ie._URL_TEMPLATE is 'https://www.pornerbros.com/videos/video_%s'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-22 07:28:05.205619
# Unit test for constructor of class FuxIE
def test_FuxIE():
    arg = 'https://www.fux.com/video/195360/naughty-office-scene-with-hot-babe'
    FuxIE(arg)

# Generated at 2022-06-22 07:28:13.707515
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-22 07:28:17.890017
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test = FourTubeBaseIE()
    assert '4tube' in test._VALID_URL
    assert test._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:28:18.540995
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:28:23.008381
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    Test to assure the constructor of class PornTubeIE
    works correctly.
    """
    class Tester(PornTubeIE):
        pass

    assert Tester()._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-22 07:28:23.657575
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-22 07:28:26.702369
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()._download_webpage('http://www.fux.com/videos/195359/awesome-fucking-kitchen-ends-cum-swallow',
                              '195359', 'Downloading video webpage')

# Generated at 2022-06-22 07:28:27.482491
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    b = FourTubeBaseIE()
    assert True

# Generated at 2022-06-22 07:28:29.537318
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert isinstance(PornTubeIE()._get_info, FileDownloader)

# Generated at 2022-06-22 07:28:31.488443
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube')

# Generated at 2022-06-22 07:29:10.629057
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    with open('test/testdata/test.txt', encoding='utf-8') as f:
        test = f.read()
    parser = PornTubeIE()
    json = parser._parse_json(test, 'testdata')['page']['video']
    assert json['title'] == 'Skinny brunette takes big cock down her anal hole'
    assert json['mediaId'] == '181369'
    assert json['user']['id'] == '1'
    assert json['channel']['id'] == '0'
    assert json['likes'] == '0'
    assert json['dislikes'] == '0'
    assert json['playsQty'] == '51887'
    assert json['durationInSeconds'] == '1224'

# Generated at 2022-06-22 07:29:11.810522
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE("url")

# Generated at 2022-06-22 07:29:14.763663
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-22 07:29:16.763014
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor = FourTubeBaseIE()
    assert isinstance(info_extractor, InfoExtractor)

# Generated at 2022-06-22 07:29:18.202608
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-22 07:29:28.614979
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .common import InfoExtractor
    ie = InfoExtractor.ie_key_map['porntube']()
    assert ie.IE_NAME == 'PornTube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:29:32.056394
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE("4tube", True)
    obj = FourTubeBaseIE("fux", True)
    obj = FourTubeBaseIE("porntube", True)
    obj = FourTubeBaseIE("pornerbros", True)
    return

# Generated at 2022-06-22 07:29:35.344171
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    from . import PornTubeIE
    from . import FuxIE
    from . import PornerBrosIE

# Generated at 2022-06-22 07:29:45.533924
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from . import utils
    from .extractor import YoutubeIE

    def test_construct(test_name, test_data):
        for url, expected_data in test_data:
            ie = utils.search_dict(expected_data, "expected_ie")
            ie_instance = ie()
            data = ie_instance.suitable(url)
            assert data[0] == expected_data["suitable"]
            assert ie_instance == expected_data["expected_ie"]
            assert ie_instance.IE_NAME == expected_data["expected_ie_name"]
            assert ie_instance.TEST == expected_data["expected_test"]


# Generated at 2022-06-22 07:29:48.733974
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert isinstance(x, PornerBrosIE)

# Generated at 2022-06-22 07:30:55.628710
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE(None)

# Generated at 2022-06-22 07:31:03.532364
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'
    assert PornerBrosIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-22 07:31:04.856484
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)

# Generated at 2022-06-22 07:31:16.996771
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Success cases
    base = FourTubeBaseIE()
    base._VALID_URL = r'https?://(?P<host>.*)/(?P<id>.*)'
    base._URL_TEMPLATE = 'https://%s/%s'
    base._TKN_HOST = 'token.4tube.com'

    item = base._real_extract('https://wwww.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert(item['id'] == '209733')

    item = base._real_extract('https://m.4tube.com/embed/209733')
    assert(item['id'] == '209733')


# Generated at 2022-06-22 07:31:17.741133
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()



# Generated at 2022-06-22 07:31:28.423389
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    if __name__ == '__main__':
        url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
        video = FourTubeIE().extract_info(url)
        print(video.keys())
        print(video.get('title'))
        print(video.get('uploader'))
        print(video.get('uploader_id'))
        print(video.get('like_count'))
        print(video.get('view_count'))
        print(video.get('id'))
        print(video.get('timestamp'))
        print(video.get('duration'))
        print(video.get('age_limit'))

# Generated at 2022-06-22 07:31:30.028788
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i = PornerBrosIE()
    assert i.ie_key() in globals()



# Generated at 2022-06-22 07:31:31.905442
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .test_fux import test_FuxIE
    test_FuxIE()

# Generated at 2022-06-22 07:31:43.631711
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fux._TKN_HOST == 'token.fux.com'
    # Test TESTS
    assert fux._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-22 07:31:47.635774
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Test constructor, normalize_url
    remoteobj = FuxIE()
    assert remoteobj.ie_key() == 'Fux'
    assert remoteobj.ie._VERSION == '20140609'
    assert remoteobj.ie_name() == 'Fux'
    # Test extractor
    remoteobj.extract(url='https://www.fux.com/embed/195359')



# Generated at 2022-06-22 07:34:30.551948
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE.__name__ == 'Fux'


# Generated at 2022-06-22 07:34:39.394651
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import BaseTest
    from .compatpatch import ClientForm as ClientFormModule
    from .extractor import gen_extractors, list_extractors, _ALL_CLASSES, _ALL_CLASSES_NAME
    from .extractor import (
        _ALL_CLASSES,
        _ALL_CLASSES_NAME,
        gen_extractors,
        list_extractors,
    )
    from .loader import ExtractorsLoader, gen_extractor_classes, load_module, update_extractors
    from .loader import (
        ExtractorsLoader,
        gen_extractor_classes,
        load_module,
        update_extractors,
    )

# Generated at 2022-06-22 07:34:50.031362
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    IE = FourTubeIE()
    assert IE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert IE._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert IE._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert IE._TESTS[0]['info_dict']['id'] == '209733'
    assert IE._

# Generated at 2022-06-22 07:34:50.839462
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-22 07:34:52.815971
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(None)._TKN_HOST == PornTubeIE._TKN_HOST


# Generated at 2022-06-22 07:35:02.089911
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert hasattr(ie, '_TKN_HOST'), 'FuxIE is not concrete class'
    assert ie._TKN_HOST == 'token.fux.com', 'FuxIE class has been changed!'
    assert hasattr(ie, '_VALID_URL'), 'FuxIE is not concrete class'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?', 'FuxIE class has been changed!'

# Generated at 2022-06-22 07:35:04.063299
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie == PornerBrosIE()

# Generated at 2022-06-22 07:35:11.346087
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test empty sources
    ie = FourTubeBaseIE()
    assert ie._extract_formats(None, None, None, []) == []
    # Test empty sources
    ie = FourTubeBaseIE()
    assert ie._extract_formats(None, None, None, ['180p', '720p', '1080p']) == [
        {'url': None, 'format_id': '180p', 'resolution': '180p', 'quality': 180},
        {'url': None, 'format_id': '720p', 'resolution': '720p', 'quality': 720},
        {'url': None, 'format_id': '1080p', 'resolution': '1080p', 'quality': 1080}]

# Generated at 2022-06-22 07:35:23.525398
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print('This is a test for constructor of class FourTubeBaseIE')
    print('Please enter the url: ')
    url=input()
    url='https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    print(url)
    #assert url_kind == 'FourTube', 'Unit test failed, url is not belong to the FourTube website'
    print('Constructor of class %s:' % 'FourTubeBaseIE')
    print('   _VALID_URL is: ' + FourTubeBaseIE._VALID_URL)
    print('   _URL_TEMPLATE is: ' + FourTubeBaseIE._URL_TEMPLATE)

# Generated at 2022-06-22 07:35:33.435422
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class_name = 'FourTubeBaseIE'
    class_obj = globals()[class_name]
    instance_obj = class_obj(class_name)

    assert(instance_obj._TKN_HOST == 'token.4tube.com')
    assert(instance_obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(instance_obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
