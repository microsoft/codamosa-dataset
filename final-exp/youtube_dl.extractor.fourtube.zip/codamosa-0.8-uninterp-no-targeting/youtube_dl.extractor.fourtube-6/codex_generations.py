

# Generated at 2022-06-22 07:27:05.628788
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE("https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-22 07:27:07.385760
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('4tube', '4tube.com')


# Generated at 2022-06-22 07:27:08.655793
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:27:12.823176
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for ie in [ FourTubeIE(),FuxIE(),PornTubeIE(),PornerBrosIE() ]:
        assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-22 07:27:13.341632
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE();

# Generated at 2022-06-22 07:27:14.774528
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE.ie_key())


# Generated at 2022-06-22 07:27:22.171832
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornTubeIE()._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE().IE_NAME == 'PornTube'
    assert PornTubeIE()._TEST_URL == 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-22 07:27:23.991898
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert isinstance(instance, PornerBrosIE)



# Generated at 2022-06-22 07:27:26.162010
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_constructor_class(FourTubeBaseIE)

# Generated at 2022-06-22 07:27:28.017179
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pti = PornTubeIE()
    print(pti)

# Generated at 2022-06-22 07:27:59.771660
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    _ = FourTubeBaseIE('FourTube', '4tube')


# Generated at 2022-06-22 07:28:13.367487
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_common import (
        BaseTest,
        BaseTestShared,
        FakeSubDownloader,
        FakeYDL,
        FakeYDLUtils,
        FakeYDLHttpServer,
        _FakeStaticServer,
    )
    from .test_PornTubeIE import (
        _FakePage,
        _FakePage2,
        _FakePage3,
        _FakePage4,
    )
    from .pornhub import PornHubIE, PornHubPlaylistBaseIE, PornHubUserVideosIE
    from .porncom import PornComIE
    from .xhamster import XHamsterIE
    from .xhamster_embed import XHamsterEmbedIE
    from .xtube import XTubeUserIE
    from .xvideos import XvideosIE
    from .xvideos_embed import XvideosEmbed

# Generated at 2022-06-22 07:28:24.837645
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(FourTubeIE, '_TESTS')
    assert hasattr(FourTubeIE, 'IE_NAME')
    assert hasattr(FourTubeIE, '_VALID_URL')
    assert hasattr(FourTubeIE, '_URL_TEMPLATE')
    assert hasattr(FourTubeIE, '_TKN_HOST')
    assert re.match(ie._VALID_URL, 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-22 07:28:25.911624
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:28:32.184748
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    u = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBros_test = PornerBrosIE()
    assert PornerBros_test._match_id(u) == '181369'

# Generated at 2022-06-22 07:28:37.038742
# Unit test for constructor of class FuxIE

# Generated at 2022-06-22 07:28:48.834212
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .. import FourTubeIE
    from .common import InfoExtractor
    test_inst = FourTubeIE()
    assert isinstance(test_inst, InfoExtractor)
    assert test_inst.IE_NAME == '4tube'
    assert test_inst._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert test_inst._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert test_inst._TKN_HOST == 'token.4tube.com'
    return "Constructor test for FourTubeIE class passed"


# Generated at 2022-06-22 07:28:49.544936
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:28:50.620534
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    constructor_test(FourTubeBaseIE)

# Generated at 2022-06-22 07:29:03.640112
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_url = "http://www.4tube.com/videos/225946/lauren-crush-breakfast-creampie"
    four_tube_ie = FourTubeIE()

    # Result
    result = four_tube_ie._real_extract(video_url)

# Generated at 2022-06-22 07:29:39.251337
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_class = FourTubeBaseIE()
    assert test_class._VALID_URL is None
    assert test_class._URL_TEMPLATE is None
    assert test_class._TKN_HOST is None
    assert test_class._TESTS is None
    assert test_class._NETRC_MACHINE == 'fourtube'

# Generated at 2022-06-22 07:29:47.835043
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    v = FourTubeBaseIE()
    assert v._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert v._URL_TEMPLATE == "https://www.4tube.com/videos/%s/video"
    assert v._TKN_HOST == "token.4tube.com"

# Generated at 2022-06-22 07:29:58.540429
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'
    assert ie.IE_SHORT_NAME == 'PornerBros'
    assert 'PornerBros' in ie.IE_DESC
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert len(ie._TESTS) > 1

# Generated at 2022-06-22 07:30:05.381549
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_PornTube import PornTubeIE
    old=PornTubeIE._VALID_URL
    old_t=PornTubeIE._TESTS
    PornTubeIE._VALID_URL=r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    test=PornTubeIE(None)._TESTS
    PornTubeIE._VALID_URL=old
    assert PornTubeIE._TESTS!=old_t
    assert test==PornTubeIE._TESTS



# Generated at 2022-06-22 07:30:07.546981
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-22 07:30:08.547578
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('Fux')

# Generated at 2022-06-22 07:30:11.219753
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Check that we can construct a FourTubeBaseIE without failure
    _ = FourTubeBaseIE({})
    _ = FuxIE({})
    _ = PornTubeIE({})
    _ = PornerBrosIE({})

# Generated at 2022-06-22 07:30:13.267420
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:30:16.915869
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('4tube', '4tube.com')
    assert ie.ie_key() == '4Tube'
    assert ie.ie_name() == '4tube'



# Generated at 2022-06-22 07:30:18.841088
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        # Test constructor
        FuxIE()
    except Exception as exc:
        # Test failed
        assert False, "Test failed: {}".format(exc)

# Generated at 2022-06-22 07:31:35.640106
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE(None)

# Generated at 2022-06-22 07:31:37.416325
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # The constructor of FourTubeBaseIE is not tested
    p = PornerBrosIE()
    assert p is not None

# Generated at 2022-06-22 07:31:48.915010
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    print('Unit test for constructor of class PornerBrosIE')
    # string to test the extract of id from url
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    # expected id from url
    expected_id = '181369'
    # expected title from json string
    expected_title = 'Skinny brunette takes big cock down her anal hole'
    # expected duration from json string
    expected_duration = 1224
    # expected uploader from json string
    expected_uploader = 'PornerBros HD'
    # expected upload date from json string
    expected_upload_date = '20130130'
    # expected view count from json string
    expected_view_count = 7
   

# Generated at 2022-06-22 07:31:52.150209
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')
    PornTubeIE('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-22 07:31:56.411510
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._TESTS[0]['url'] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'

# Generated at 2022-06-22 07:31:58.727925
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()

# Generated at 2022-06-22 07:32:00.513199
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-22 07:32:04.551860
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(PornerBrosIE.ie_key())._TKN_HOST == 'token.pornerbros.com'


# Generated at 2022-06-22 07:32:06.853359
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except:
        raise AssertionError('PornerBrosIE constructor should not raise exception')


# Generated at 2022-06-22 07:32:07.948697
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('www')

# Generated at 2022-06-22 07:35:37.104561
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_common import FakeInfoExtractor

# Generated at 2022-06-22 07:35:48.598852
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-22 07:35:49.235212
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:35:50.231319
# Unit test for constructor of class FuxIE
def test_FuxIE():
    a = FuxIE()
    return a

# Generated at 2022-06-22 07:35:51.269852
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:35:59.383755
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie_function = ie._real_extract
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    webpage = ie.urlopen(url)
    # Test regular expression
    assert re.search(ie._VALID_URL, url)
    # Test function params
    assert ie_function(url)['id'] == '7089759'

# Generated at 2022-06-22 07:36:02.907928
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:36:07.634885
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('https://www.pornerbros.com/embed/181369')
    PornerBrosIE('https://www.pornerbros.com/embed/181369')
    FourTubeIE('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-22 07:36:09.530414
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Test that FuxIE can construct its own name
    """
    FuxIE().ie_key()

# Generated at 2022-06-22 07:36:15.978055
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    print(ie.IE_NAME)
    print(ie.IE_DESC)
    print(ie._VALID_URL)
    print(ie._URL_TEMPLATE)
    print(ie._TKN_HOST)
    print(ie._TESTS)