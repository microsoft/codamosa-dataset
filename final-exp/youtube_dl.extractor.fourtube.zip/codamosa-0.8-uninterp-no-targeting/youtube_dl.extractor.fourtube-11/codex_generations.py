

# Generated at 2022-06-22 07:26:56.743128
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert(pornerBrosIE.TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-22 07:27:00.992950
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test for the constructor
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-22 07:27:01.716418
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:27:10.832823
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class_ = FuxIE
    input_string = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = class_()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:27:14.051824
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxie = FuxIE()
    fuxie.extract('http://www.fux.com/embed/195359')



# Generated at 2022-06-22 07:27:15.967206
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == 'PornTube'


# Generated at 2022-06-22 07:27:23.250641
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('www.4tube.com', 'www.4tube.com/videos/video_%s')
    FourTubeBaseIE('www.porntube.com', 'www.porntube.com/videos/video_%s')
    FourTubeBaseIE('www.pornerbros.com', 'www.pornerbros.com/videos/video_%s')
    FourTubeBaseIE('www.fux.com', 'www.fux.com/video/%s/video')
    FourTubeBaseIE._TKN_HOST = 'www.4tube.com'
    FourTubeBaseIE._TKN_HOST = 'www.fux.com'
    FourTubeBaseIE._TKN_HOST = 'www.pornerbros.com'

# Generated at 2022-06-22 07:27:34.436858
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test 'from PornTubeIE(PornerBrosIE)
    _PornTubeIE = PornTubeIE.__bases__[0]
    assert issubclass(_PornTubeIE, PornerBrosIE)
    assert issubclass(PornTubeIE, _PornTubeIE)
    # Test 'from PornTubeIE(fuxIE)
    assert issubclass(_PornTubeIE, FuxIE)
    # Test 'from fuxIE(PornerBrosIE)
    _FuxIE = FuxIE.__bases__[0]
    assert issubclass(_FuxIE, PornerBrosIE)
    assert issubclass(FuxIE, _FuxIE)

# Generated at 2022-06-22 07:27:37.200639
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)


# Generated at 2022-06-22 07:27:37.983819
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()

# Generated at 2022-06-22 07:27:57.267266
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("4TubeIE")
    assert ie.IE_NAME == "4tube"
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-22 07:27:59.084672
# Unit test for constructor of class FuxIE
def test_FuxIE():
    obj = FuxIE()
    print(obj.__class__.__name__)

if __name__ == '__main__':
    test_FuxIE()

# Generated at 2022-06-22 07:28:01.931134
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f = FourTubeBaseIE()
    f._TESTS
    f._VALID_URL
    f._download_webpage
    f._extract_formats
    f._parse_json
    f._real_extract
    f._search_regex
    f._sort_formats
    f._TKN_HOST
    f._URL_TEMPLATE

# Generated at 2022-06-22 07:28:05.372216
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()(
        'https://m.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-22 07:28:07.635413
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print('test_FuxIE')
    # test constructor
    FuxIE()._VALID_URL

# Generated at 2022-06-22 07:28:19.669839
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base_ie = FourTubeBaseIE()

# Generated at 2022-06-22 07:28:32.084364
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	import re
	mobj = re.match(PornerBrosIE._VALID_URL, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
	kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
	url = PornerBrosIE._URL_TEMPLATE % video_id
	ie = PornerBrosIE()
	ie._download_webpage = lambda *args, **kwargs: 'Page content'
	ie._search_regex = lambda *args, **kwargs: 'JSON string'

# Generated at 2022-06-22 07:28:35.971414
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Downloader, params, IE name
    info_extractor = FourTubeBaseIE()
    info_extractor.params = {}
    # Downloader, params, IE name
    assert info_extractor.ie_key() == 'FourTubeBase'

# Generated at 2022-06-22 07:28:36.650879
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:28:38.919704
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
    except Exception as e:
        assert False, 'Error thrown when instantiating PornTubeIE:\n' + str(e)

# Generated at 2022-06-22 07:29:11.468224
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(PornTubeIE.IE_NAME, PornTubeIE.IE_DESC)._VALID_URL == PornTubeIE._VALID_URL

# Generated at 2022-06-22 07:29:12.034529
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:29:13.368510
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    class_ = globals()['FourTubeIE']
    assert class_ == FourTubeIE

# Generated at 2022-06-22 07:29:15.076740
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()


# Generated at 2022-06-22 07:29:21.872832
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_url = 'https://m.porntube.com/videos/teen-couple-doing-anal_7089759'
    test_obj = PornTubeIE()
    test_obj.extract(test_url)
    test_obj._download_webpage(test_url, None)
    test_obj.IE_NAME
    test_obj._VALID_URL
    test_obj._TESTS
    test_obj.extract(test_url)

# Generated at 2022-06-22 07:29:33.054137
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn = PornTubeIE({})
    # test that instance has expected attributes
    assert porn.IE_NAME == 'PornTube'
    assert porn._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert porn._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert porn._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:29:35.068318
# Unit test for constructor of class FuxIE
def test_FuxIE():
    return FuxIE(FuxIE.ie_key())

# Generated at 2022-06-22 07:29:37.750511
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        assert FourTubeIE('video_id')
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-22 07:29:40.768637
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE({'skip_download': True})
    except:
        assert False, 'Constructor test failed'
    assert True, 'Constructor test succeeded'

# Generated at 2022-06-22 07:29:43.414272
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-22 07:30:49.471805
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, FourTubeBaseIE)


# Generated at 2022-06-22 07:30:59.052453
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Test proper initialization of video downloader
    """
    video_id = '181369'
    url = 'https://www.pornerbros.com/embed/%s' % video_id
    ie = PornerBrosIE()
    # Check all fields
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:31:06.591071
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Stub
    class StubFourTubeBaseIE(FourTubeBaseIE):
        PlayerTokenURL = 'https://example.com/'
        PlayerTokenHost = 'token.example.com'
        _VALID_URL = r'https?://(?:www|m)\.(?P<hostname>.+?)(?:\.com)?/(?:videos|embed)/(?P<id>\d+)'
    hostname = 'example'
    video_id = '1'
    url = 'https://www.%s.com/videos/%s' % (hostname, video_id)
    ie = StubFourTubeBaseIE(StubFourTubeBaseIE.ie_key(), {'hostname': hostname})

    assert ie._downloader.cache.get('https://example.com/1') is None
    assert ie._downloader.cache

# Generated at 2022-06-22 07:31:08.256015
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE
        print("Successfully instantiated PornerBrosIE object")
    except:
        print("Error instantiating PornerBrosIE object")

# Generated at 2022-06-22 07:31:09.287193
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie_obj = PornerBrosIE()

# Generated at 2022-06-22 07:31:14.869520
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # We don't strictly need to test this constructor, but it's the only way
    # to easily make sure that the class is instantiable and the superclass
    # is correctly called
    assert(FourTubeBaseIE('FourTube')._TKN_HOST == 'token.4tube.com')
    assert(PornerBrosIE('PornerBros')._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-22 07:31:26.238100
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Get 4tube Id, media id, and sources
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    webpage = PornerBrosIE()._download_webpage('https://www.pornerbros.com/embed/181369', 'test')

# Generated at 2022-06-22 07:31:37.369771
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

    # test suite for constructor of class PornTubeIE
    class TestPornTubeIE(object):
        def __init__(self, test_name, url, expected_id, expected_ext):
            self.test_name = test_name
            self.url = url
            self.expected_id = expected_id
            self.expected_ext = expected_ext


# Generated at 2022-06-22 07:31:40.107105
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_this = FuxIE('https://www.fux.com/embed/195359')
    assert test_this == "https://www.fux.com/embed/195359"

# Generated at 2022-06-22 07:31:40.761465
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:34:25.558919
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
    assert isinstance(f, FourTubeBaseIE)


# Generated at 2022-06-22 07:34:27.030069
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()

# Generated at 2022-06-22 07:34:30.451539
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	import pornerbros
	assert pornerbros.PornerBrosIE==FourTubeBaseIE

# Generated at 2022-06-22 07:34:35.129894
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    yt = FourTubeIE(object)

    assert yt._TKN_HOST == 'token.4tube.com'
    assert yt._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'


# Generated at 2022-06-22 07:34:38.830336
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-22 07:34:41.482302
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE()._TESTS
    for input in i:
        test = FourTubeIE(input)
        assert test


# Generated at 2022-06-22 07:34:43.299099
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    yt = FourTubeIE()
    assert yt._TESTS[0].get("info_dict").get("upload_date") == "20131031"

# Generated at 2022-06-22 07:34:53.813973
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_id = 209733
    url = 'https://www.4tube.com/videos/' + str(video_id) + '/video'
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:34:55.766707
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert instance.__class__.__name__ == 'FourTubeBaseIE'

# Generated at 2022-06-22 07:34:58.740815
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    construct_result = PornTubeIE().get_IE_name_and_suitable()
    assert construct_result[0] == PornTubeIE.IE_NAME