

# Generated at 2022-06-22 07:26:55.178759
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE("FourTubeBaseIE")

# Generated at 2022-06-22 07:26:58.408750
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
test_FourTubeIE.register_nose()


# Generated at 2022-06-22 07:27:05.590759
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube', 'http://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    PornTubeIE('PornTube', 'http://www.porntube.com/embed/1331406')
    PornTubeIE('PornTube', 'http://m.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')

# Generated at 2022-06-22 07:27:06.853715
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE is FourTubeIE

# Generated at 2022-06-22 07:27:08.654556
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TEST is not None


# Generated at 2022-06-22 07:27:10.724341
# Unit test for constructor of class FuxIE
def test_FuxIE(): assert FuxIE()._TESTS != FourTubeIE()._TESTS

# Generated at 2022-06-22 07:27:18.259658
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestFourTubeBaseIE(FourTubeBaseIE):
        pass

    # Test first use
    assert TestFourTubeBaseIE._TKN_HOST is None
    assert TestFourTubeBaseIE._URL_TEMPLATE is None
    assert TestFourTubeBaseIE.__name__ == 'TestFourTubeBaseIE'

    # Test second use
    obj = TestFourTubeBaseIE()
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj.__name__ == 'TestFourTubeBaseIE'

# Generated at 2022-06-22 07:27:19.378450
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE()
    print(obj.__dict__)

# Generated at 2022-06-22 07:27:20.734638
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE().IE_NAME == '4tube'


# Generated at 2022-06-22 07:27:21.497915
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE

# Generated at 2022-06-22 07:27:47.118586
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = PornerBrosIE._VALID_URL
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert PornerBrosIE._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert PornerBrosIE._TESTS[0]['url'] == 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    assert PornerBrosIE._TESTS[0]['only_matching'] == False
   

# Generated at 2022-06-22 07:27:48.906452
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE is not None

#!/usr/bin/python3
#
#
#
# Test
#
#
#

test_PornerBrosIE()

# Generated at 2022-06-22 07:27:50.881849
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE('4tube')
    FuxIE('4tube')
    PornTubeIE('4tube')
    PornerBrosIE('4tube')

test_FourTubeBaseIE()

# Generated at 2022-06-22 07:27:51.784291
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None, None)



# Generated at 2022-06-22 07:27:59.034288
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FakeIE(FourTubeBaseIE):
        _VALID_URL = 'https://www.4tube.com/videos/{0}/video'
        _TEST = {
            'url': 'https://www.4tube.com/videos/12345/video',
            'info_dict': {
                'id': '12345',
                'upload_date': '20101101',
            }
        }
    fake_ie = FakeIE()
    # check that _real_initialize is called
    assert fake_ie._downloader is not None
    assert fake_ie._match_id(fake_ie._TEST['url']) == '12345'

# Generated at 2022-06-22 07:27:59.784509
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    a = FourTubeBaseIE()

# Generated at 2022-06-22 07:28:01.987624
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:28:11.288289
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-22 07:28:12.466919
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')

# Generated at 2022-06-22 07:28:14.865679
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:28:47.790049
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Instantiate classes by its name
    FourTubeBaseIE_class = globals()['FourTubeBaseIE']
    FourTubeBaseIE_class()



# Generated at 2022-06-22 07:29:00.582308
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube')
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:29:01.317990
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.IE_NAME in globals()

# Generated at 2022-06-22 07:29:04.647852
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    # assert that no exception is raised
    FuxIE()

# Generated at 2022-06-22 07:29:13.976079
# Unit test for constructor of class FuxIE
def test_FuxIE():
    import unittest;
    assert 'FuxIE' in globals();
    assert globals()['FuxIE'] is not None;
    assert issubclass(globals()['FuxIE'], InfoExtractor);
    assert 'FourTubeBaseIE' in globals();
    assert globals()['FourTubeBaseIE'] is not None;
    assert issubclass(globals()['FourTubeBaseIE'], InfoExtractor);
    assert 'PornTubeIE' in globals();
    assert globals()['PornTubeIE'] is not None;
    assert issubclass(globals()['PornTubeIE'], FourTubeBaseIE);

if __name__ == '__main__':
    test_FuxIE();

# Generated at 2022-06-22 07:29:15.166865
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    assert i is not None

# Generated at 2022-06-22 07:29:25.918181
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-22 07:29:27.317180
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL is not None


# Generated at 2022-06-22 07:29:31.916513
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    assert(re.match(PornerBrosIE._VALID_URL, url) is not None)

# Generated at 2022-06-22 07:29:43.269045
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TESTS[0]['info_dict'] == {'id': '195359',
                                            'ext': 'mp4',
                                            'title': 'Awesome fucking in the kitchen ends with cum swallow',
                                            'uploader': 'alenci2342',
                                            'uploader_id': 'alenci2342',
                                            'upload_date': '20131230',
                                            'timestamp': 1388361660,
                                            'duration': 289,
                                            'view_count': int,
                                            'like_count': int,
                                            'categories': list,
                                            'age_limit': 18
                                            }


# Generated at 2022-06-22 07:30:51.943681
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
        infos = PornTubeIE()._real_extract("https://www.porntube.com/videos/hottest-lesbian-sex_8244740")
        assert infos == 'https://www.porntube.com/videos/video_8244740'

# Generated at 2022-06-22 07:31:01.031622
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie.name == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-22 07:31:05.163702
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    parsed_url = compat_urlparse.urlparse(FourTubeBaseIE._URL_TEMPLATE % '55346')
    headers = {
        'Origin': '%s://%s' % (parsed_url.scheme, parsed_url.hostname),
        'Referer': FourTubeBaseIE._URL_TEMPLATE % '55346',
    }
    print(headers)

# Generated at 2022-06-22 07:31:08.898815
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_FuxIE = FuxIE()
    assert test_FuxIE.fux_host == 'token.fux.com'
# End unit test

# Generated at 2022-06-22 07:31:16.098534
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['noplaylist'] = True
    ydl.add_default_info_extractors()
    info_dict = ydl.extract_info(
        'https://www.4tube.com/videos/250826/horny-vixen-sisters-share-an-eager-dong',
        download=False)
    assert info_dict['id'] == '250826'
    assert info_dict['duration'] == 470

# Generated at 2022-06-22 07:31:27.517618
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # pylint:disable=protected-access,no-value-for-parameter
    assert FourTubeBaseIE._TKN_HOST is None
    assert '4tube' == FourTubeBaseIE._VALID_URL
    assert '4tube' == FourTubeBaseIE.IE_NAME

    # Test constructor of class FourTubeBaseIE, the constructor of class InfoExtractor
    ie = FourTubeBaseIE('4tube', '4tube')
    assert '4tube' == ie._VALID_URL
    assert '4tube' == ie.IE_NAME
    assert ie._TKN_HOST is None

    # Test constructor of subclass
    ie = FourTubeIE('4tube', '4tube')
    assert '4tube' == ie._VALID_URL
    assert '4tube' == ie.IE_NAME

# Generated at 2022-06-22 07:31:31.523344
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.tags == ['porn-host']

# Generated at 2022-06-22 07:31:34.384755
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie = FuxIE("")
    assert ie



# Generated at 2022-06-22 07:31:39.793393
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_ = PornerBrosIE
    assert class_ == PornerBrosIE
    assert class_.__name__ == 'PornerBrosIE'
    assert class_.__doc__ == None
    assert class_.__module__ == '__main__'
    assert class_.IE_NAME == 'pornerbros'



# Generated at 2022-06-22 07:31:45.378115
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST.endswith('.4tube.com')
    assert PornTubeIE()._TKN_HOST.endswith('.porntube.com')
    assert PornerBrosIE()._TKN_HOST.endswith('.pornerbros.com')
    assert FuxIE()._TKN_HOST.endswith('.fux.com')

# Generated at 2022-06-22 07:34:43.051302
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # If the constructor of this class does not throw an exception, this test
    # succeeds.
    FourTubeBaseIE()

# Generated at 2022-06-22 07:34:50.134973
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class VultrIE(PornerBrosIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?vultr\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.vultr.com/videos/video_%s'
        _TKN_HOST = 'token.vultr.com'

    VultrIE()

# Generated at 2022-06-22 07:34:53.022127
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    FuxIE(url)

# Generated at 2022-06-22 07:34:56.547272
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE('FourTube', True, 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-22 07:35:04.737923
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert(fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(fux._URL_TEMPLATE == 'https://www.fux.com/video/%s/video')
    assert(fux._TKN_HOST == 'token.fux.com')
    assert(fux._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-22 07:35:06.938271
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:35:09.685657
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """Constructor for class FourTubeIE."""

    instance = FourTubeIE('4tube')
    assert(instance is not None)


# Generated at 2022-06-22 07:35:21.370811
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    FourTubeIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    FourTubeIE._URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    FourTubeIE._TKN_HOST = 'token.4tube.com'
    # contructor of class FourTubeIE
    # FourTubeIE._TESTS = [{
    #     'url': 'http://www.4

# Generated at 2022-06-22 07:35:22.176309
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()

# Generated at 2022-06-22 07:35:26.926744
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Test case for constructor of PornerBrosIE"""
    url = 'http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE(PornerBrosIE.ie_key(), url)