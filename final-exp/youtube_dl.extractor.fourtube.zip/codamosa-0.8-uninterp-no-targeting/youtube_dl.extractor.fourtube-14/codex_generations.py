

# Generated at 2022-06-22 07:27:04.605632
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    requests_mock = TestRequestsMock()
    PornTubeIE(requests_mock)._download_webpage(
        "https://www.porntube.com/videos/teen-couple-doing-anal_7089759",
        "teen-couple-doing-anal_7089759")
    requests_mock.assert_requested(
        "GET", "https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    PornTubeIE(requests_mock)._download_webpage(
        "https://www.porntube.com/embed/7089759", "7089759")
    requests_mock.assert_requested(
        "GET", "https://www.porntube.com/embed/7089759")
    Porn

# Generated at 2022-06-22 07:27:08.600729
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    with open('test/test_data/porntube_video_data.json', 'r') as data_file:
        data = data_file.read()
        PornTubeIE()._parse_json(data)

# Generated at 2022-06-22 07:27:19.738667
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class FakeFourTubeBaseIE(FourTubeBaseIE):
        IE_NAME = 'test_FourTubeBaseIE'
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
        _TKN_HOST = 'token.4tube.com'
    video = FakeFourTubeBaseIE()._real_extract('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert video['id']

# Generated at 2022-06-22 07:27:30.770671
# Unit test for constructor of class FuxIE

# Generated at 2022-06-22 07:27:33.477470
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f_class = FourTubeBaseIE.__name__
    test_class = globals()[f_class]
    instance = test_class()


# Generated at 2022-06-22 07:27:38.567779
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    init_class = PornerBrosIE(url)
    assert (init_class != None)

# Generated at 2022-06-22 07:27:48.201646
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE

# Generated at 2022-06-22 07:27:49.456338
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_FourTubeIE = FourTubeIE()
    assert test_FourTubeIE is not None


# Generated at 2022-06-22 07:27:56.988236
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:27:58.053976
# Unit test for constructor of class FuxIE
def test_FuxIE():
    x = FuxIE()
    print(x.__doc__)
    assert x.__doc__.startswith('Fux')

# Generated at 2022-06-22 07:28:26.587931
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369');

# Generated at 2022-06-22 07:28:38.919767
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    # Test for '_VALID_URL'
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)', 'This is wrong URL!'
    # Test for '_URL_TEMPLATE'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s', 'This is wrong URL!'
    # Test for '_TKN_HOST'
    assert ie._TKN_HOST == 'token.pornerbros.com', 'This is wrong URL!'
    # Test for '_TESTS'
    assert ie._

# Generated at 2022-06-22 07:28:48.176723
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    obj = PornTubeIE()._real_extract('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')
    assert obj['upload_date'] == '20130920'
    assert obj['channel'] == 'Exploited College Girls'
    assert 'channel_id' in obj
    assert obj['uploader'] == 'Exploited College Girls'
    assert obj['uploader_id'] == '665'

# Generated at 2022-06-22 07:28:51.913423
# Unit test for constructor of class FuxIE
def test_FuxIE():
    class_FuxIE = FuxIE()
    assert class_FuxIE.__class__.__name__ == 'FuxIE', \
        'Unit test for class FuxIE failed.'


# Generated at 2022-06-22 07:28:54.232103
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    d = FourTubeBaseIE("test");
    assert(d.IE_NAME == "4tube")

# Generated at 2022-06-22 07:29:06.639453
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    def _test_fragment(extractor):
        pages = [
            ('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', extractor),
            ('http://www.4tube.com/embed/209733', extractor),
            ('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', extractor),
            ('https://www.4tube.com/embed/209733', extractor)
        ]

        for page, page_extractor in pages:
            assert page_extractor._match_id(page) == '209733'
            assert page_extractor._match_id

# Generated at 2022-06-22 07:29:08.191327
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from porn_tube_ie import PornTubeIE
    PornTubeIE()

# Generated at 2022-06-22 07:29:11.214343
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .test_youtube import _extract_urls
    _extract_urls(FuxIE.ie_key())

# Generated at 2022-06-22 07:29:13.627701
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-22 07:29:14.751495
# Unit test for constructor of class FuxIE
def test_FuxIE():
	pass

# Generated at 2022-06-22 07:29:44.776021
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:29:49.802745
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Arrange
    url = 'https://www.porntube.com/embed/181369'
    # Act
    fuxIE = FuxIE(url)
    # Assert
    assert fuxIE.IE_NAME == 'fux'

# Generated at 2022-06-22 07:29:50.965959
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()

# Generated at 2022-06-22 07:30:02.347298
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    print("\nUnit test for constructor of class FourTubeIE")

# Generated at 2022-06-22 07:30:07.973644
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    bad_urls = [
        "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black-fake_id"
    ]
    for url in bad_urls:
        f = FuxIE(None)
        mobj = re.match(f._VALID_URL, url)
        assert mobj is None

# Generated at 2022-06-22 07:30:09.290818
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE(None, None, None)

# Generated at 2022-06-22 07:30:10.589299
# Unit test for constructor of class FuxIE
def test_FuxIE():
    if __name__ == "__main__":
        _ = FuxIE()

# Generated at 2022-06-22 07:30:14.543381
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie.__class__.__name__ == 'FourTubeIE'


# Generated at 2022-06-22 07:30:20.177191
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """FourTubeIE should create an instance of FourTubeIE or a subclass of FourTubeIE."""
    ie = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert (type(ie)) == FourTubeIE or issubclass(type(ie), FourTubeIE)


# Generated at 2022-06-22 07:30:25.389432
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FuxIE()._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert FuxIE()._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:31:39.611688
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.IE_NAME == '4tube'
    assert obj._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:31:42.649218
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    yt = FourTubeBaseIE('4tube', '4tube.com')
    assert yt.ie_key() == '4tube'
    assert yt.ie_key() in yt.WORKING

# Generated at 2022-06-22 07:31:43.294034
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    pass

# Generated at 2022-06-22 07:31:54.834968
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test constructor of class FourTubeIE
    # >>> d = FourTubeIE()._downloader
    d = FourTubeBaseIE()._downloader
    # >>> d == FourTubeIE()._downloader
    d == FourTubeBaseIE()._downloader
    # >>> d is FourTubeIE()._downloader
    d is FourTubeBaseIE()._downloader
    # >>> FourTubeIE()._downloader.params
    FourTubeBaseIE()._downloader.params
    # >>> FourTubeIE()._downloader = d
    FourTubeBaseIE()._downloader = d
    # >>> FourTubeIE()._downloader is d
    FourTubeBaseIE()._downloader is d
    # >>> d == FourTubeIE()._downloader
    d == FourTubeBaseIE()._downloader
    # >>> d is FourTubeIE()._downloader
   

# Generated at 2022-06-22 07:32:01.197081
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == FourTubeIE._VALID_URL
    assert ie._URL_TEMPLATE == FourTubeIE._URL_TEMPLATE
    assert ie._TKN_HOST == FourTubeIE._TKN_HOST

# Generated at 2022-06-22 07:32:12.262812
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    unit_test = FourTubeIE()
    assert unit_test.IE_NAME == '4tube'
    assert unit_test._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert unit_test._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert unit_test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:32:18.380277
# Unit test for constructor of class FuxIE
def test_FuxIE():

    mobj = re.match(FourTubeBaseIE._VALID_URL, 'https://www.fux.com/embed/195359')
    kind, video_id, display_id = mobj.group('kind', 'id', 'display_id')
    assert kind == 'www'
    assert video_id == '195359'
    assert display_id == None

# Generated at 2022-06-22 07:32:24.349916
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test for creating object of class FourTubeBaseIE"""
    a = FourTubeBaseIE()
    assert 'https://token.' in a._download_webpage(
        'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black',
        '209733', 'Downloading player JS')

# Generated at 2022-06-22 07:32:26.149956
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:32:31.070007
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE('FourTube', '4tube')
    ie = FourTubeBaseIE('Fux', 'fux')
    ie = FourTubeBaseIE('PornTube', 'porntube')
    ie = FourTubeBaseIE('PornerBros', 'pornerbros')

# Generated at 2022-06-22 07:35:38.343673
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert isinstance(fux, FuxIE)
    assert isinstance(fux, FourTubeBaseIE)


# Generated at 2022-06-22 07:35:39.890647
# Unit test for constructor of class FuxIE
def test_FuxIE():
    m = FuxIE(None, None)
    assert m

# Generated at 2022-06-22 07:35:44.870268
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    e = FourTubeBaseIE()
    assert e._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?(?P<host>4tube\.com|fux\.com|porntube\.com)/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:35:51.789608
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import os
    filepath = os.path.join(os.path.dirname(__file__), 'test_data', 'pornerbros.json')
    with open(filepath, encoding='utf-8') as f:
        html = f.read()
    import json
    video = json.loads(html)['page']['video']
    title = video['title']
    media_id = video['mediaId']
    sources = [compat_str(e['height'])
               for e in video['encodings'] if e.get('height')]

# Generated at 2022-06-22 07:35:59.727236
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    except Exception as e:
        print(e)
    try:
        PornTubeIE('https://www.porntube.com/embed/7089759')
    except Exception as e:
        print(e)
    return


# Generated at 2022-06-22 07:36:11.329352
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE.FourTubeBaseIE(FourTubeBaseIE(), 'm', 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', '209733')
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-22 07:36:11.877548
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	FourTubeIE()

# Generated at 2022-06-22 07:36:17.593334
# Unit test for constructor of class FuxIE
def test_FuxIE():
    f = FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    print("\nUnit test for constructor of class FuxIE")
    print("Type: " + str(type(f)))
    print("Value: " + str(f))
    print("URL: " + f._VALID_URL)

# Generated at 2022-06-22 07:36:22.734414
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    # construct instance of FuxIE
    FuxIE()
    # construct instance of FuxIE to cover line with except
    try:
        FuxIE()
    except RuntimeError as e:
        assert 'You must initialize 4tube extractor' in e.args[0]

# Generated at 2022-06-22 07:36:24.264225
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except:
        assert False
    else:
        assert True