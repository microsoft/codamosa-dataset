

# Generated at 2022-06-22 07:27:03.391804
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
  ie = FourTubeIE()
  assert ie.IE_NAME == '4tube'
  assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
  assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
  assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:27:15.966958
# Unit test for constructor of class FuxIE

# Generated at 2022-06-22 07:27:18.212444
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    o = PornerBrosIE()._extract_formats('url', 'video_id', 'media_id', ['480'])

# Generated at 2022-06-22 07:27:24.874637
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test constructor of PornerBrosIE
    # Case #1
    ie = PornerBrosIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

    # Case #2
    # Test __init__ method
    # If a name is passed to __init__, then it gets assigned to self._IE_NAME
    ie = PornerBrosIE('PornerBros')
    assert ie

# Generated at 2022-06-22 07:27:34.710492
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_urls = [
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406',
        'https://www.porntube.com/embed/7089759',
        'https://m.porntube.com/videos/teen-couple-doing-anal_7089759'
    ]
    for url in test_urls:
        PornTubeIE()._real_extract(url)


# Generated at 2022-06-22 07:27:38.818733
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import InfoExtractor
    from .fux import FuxIE

    ie = InfoExtractor.create_ie(FuxIE.ie_key())
    assert(isinstance(ie, FuxIE))

# Generated at 2022-06-22 07:27:41.371572
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()



# Generated at 2022-06-22 07:27:45.416235
# Unit test for constructor of class FuxIE
def test_FuxIE():
    testUrl = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    downloader = FuxIE()
    downloader.extract(testUrl)

# Generated at 2022-06-22 07:27:48.126339
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert(obj._VALID_URL == None)
    assert(obj._URL_TEMPLATE == None)
    assert(obj._TKN_HOST == None)
    assert(obj.IE_NAME == 'base_4tube_ie')

# Generated at 2022-06-22 07:27:49.706587
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE()

# Generated at 2022-06-22 07:28:05.318522
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert instance


# Generated at 2022-06-22 07:28:09.950405
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-22 07:28:11.751850
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    unit = FourTubeIE()
    assert unit.IE_NAME == '4tube'

# Generated at 2022-06-22 07:28:20.080741
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-22 07:28:29.804945
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie._VALID_URL == \
        r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/' + \
        r'(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pornerbros_ie._URL_TEMPLATE == \
        'https://www.pornerbros.com/videos/video_%s'
    assert pornerbros_ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:28:33.831158
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.IE_NAME == '4tube'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-22 07:28:34.956794
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        # Constructor of class FourTubeIE, which will raise error if something is not right
        FourTubeIE()
    except Exception:
        assert False

# Generated at 2022-06-22 07:28:37.706535
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    _PornerBrosIE = PornerBrosIE("pornerbros.com")
    assert _PornerBrosIE.IE_NAME == "pornerbros"

# Generated at 2022-06-22 07:28:43.840986
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    myIe = PornerBrosIE()
    # Check _VALID_URL from class
    assert myIe._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    # Check _TKN_HOST from class
    assert myIe._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:28:44.523358
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:29:15.803627
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    porner =  PornerBrosIE()
    assert porner
    assert porner._VALID_URL
    assert porner._URL_TEMPLATE
    assert porner._TKN_HOST
    assert porner._TESTS



# Generated at 2022-06-22 07:29:17.760870
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
      c = FourTubeIE()
      c._TKN_HOST
      c._URL_TEMPLATE

# Generated at 2022-06-22 07:29:19.138117
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = FuxIE()
    assert IE.IE_NAME == '4tube'

# Generated at 2022-06-22 07:29:21.516483
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert str(type(ie)) == "<class 'youtube_dl.extractor.fourtube.FourTubeIE'>"

# Generated at 2022-06-22 07:29:24.210185
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Create an instance for testing
    t = FourTubeBaseIE()
    # Check whether it is an instance of InfoExtractor
    assert isinstance(t, InfoExtractor)

# Generated at 2022-06-22 07:29:26.795196
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TESTS[1]['url'] == PornerBrosIE._VALID_URL

# Generated at 2022-06-22 07:29:30.133237
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-22 07:29:32.720921
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE('4tubeBaseIE')
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:29:35.124125
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-22 07:29:45.379178
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_pt = PornerBrosIE
    _VALID_URL_pt = PornerBrosIE._VALID_URL
    _URL_TEMPLATE_pt = PornerBrosIE._URL_TEMPLATE
    _TKN_HOST_pt = PornerBrosIE._TKN_HOST
    # 1. Test case that is common for all classes
    assert 'www.pornerbros.com' in class_pt._VALID_URL
    assert class_pt._URL_TEMPLATE % 'video_id' == 'https://www.pornerbros.com/videos/video_video_id'
    assert class_pt._TKN_HOST == 'token.pornerbros.com'
    # 2. Test case that is unique for this class

# Generated at 2022-06-22 07:30:23.344589
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert str(x) == 'PornerBrosIE'
    assert repr(x) == 'PornerBrosIE'

# Generated at 2022-06-22 07:30:24.488334
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_FuxIE = FuxIE()
    print(test_FuxIE)

# Generated at 2022-06-22 07:30:25.133261
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()

# Generated at 2022-06-22 07:30:25.942125
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)


# Generated at 2022-06-22 07:30:28.707067
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie
    assert ie.name == '4tube'


# Generated at 2022-06-22 07:30:31.367040
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    fuxIE._VALID_URL
    fuxIE._URL_TEMPLATE
    fuxIE._TKN_HOST
    fuxIE._TESTS

# Generated at 2022-06-22 07:30:35.871124
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	ie = FourTubeIE()
	try:
		assert False, "FourTubeIE doesn't have a test case, please add a test case for this class"
	except AssertionError as e:
		print("\n[%s] WARNING: test case doesn't exist for FourTubeIE, please add a test case for this class\n"%(inspect.stack()[0][3]))


# Generated at 2022-06-22 07:30:38.039760
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # check if PornTubeIE.__init__ initializes a new instance of PornTubeIE
    ie = PornTubeIE()
    assert(isinstance(ie, PornTubeIE))

# Generated at 2022-06-22 07:30:45.440548
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test valid url
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    assert FourTubeIE().suitable(url), 'Checking valid url'

    # Test invalid url
    url = 'http://www.4tube.com/videos/209733'
    assert not FourTubeIE().suitable(url), 'Checking invalid url'

# Generated at 2022-06-22 07:30:50.825628
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:32:04.296824
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'

# Generated at 2022-06-22 07:32:07.050857
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE(None)
    assert ie._TKN_HOST == "token.fux.com"
    assert ie.IE_NAME == "Fux"


# Generated at 2022-06-22 07:32:09.654003
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    fourTubeBaseIE = FourTubeBaseIE('PornerBrosIE')
    assert fourTubeBaseIE is not None
    assert fourTubeBaseIE


# Generated at 2022-06-22 07:32:11.468227
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.__class__.__name__ == 'FourTubeIE'

# Generated at 2022-06-22 07:32:14.093004
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert isinstance(instance, PornTubeIE)
    assert isinstance(instance, FourTubeBaseIE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 07:32:25.742885
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_cases = [
        ('https://www.fux.com/embed/195359', {
            'url': 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
        }),
        ('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow', {
            'url': 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
        }),
    ]
    for test_case in test_cases:
        assert FuxIE().suitable(test_case[0])

# Generated at 2022-06-22 07:32:29.545319
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/video_name_goes_here')


# Generated at 2022-06-22 07:32:31.441054
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.IE_NAME == "4tube"


# Generated at 2022-06-22 07:32:43.441353
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.name == 'PornerBros'
    assert ie._TESTS[0]['md5'] == '6516c8ac63b03de06bc8eac14362db4f'
    assert ie._TESTS[0]['info_dict']['id'] == '181369'
    assert ie._TESTS[0]['info_dict']['title'] == 'Skinny brunette takes big cock down her anal hole'
    assert ie._TESTS[0]['info_dict']['duration'] == 1224
    assert ie._TESTS[0]['info_dict']['age_limit'] == 18
    assert ie._TESTS[0]['info_dict']['categories'] == list

# Generated at 2022-06-22 07:32:54.679790
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:36:09.433950
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    ie._TESTS


if __name__ == '__main__':
    test_FourTubeBaseIE()

# Generated at 2022-06-22 07:36:10.112962
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass

# Generated at 2022-06-22 07:36:12.007390
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
        assert True
    except:
        assert False


# Generated at 2022-06-22 07:36:22.632449
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-22 07:36:24.188918
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()
    FuxIE()
    PornTubeIE()
    PornerBrosIE()

# Generated at 2022-06-22 07:36:27.828293
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        assert issubclass(FourTubeBaseIE, InfoExtractor)
    except AssertionError:
        print("FAILED: test_FourTubeBaseIE")


# Generated at 2022-06-22 07:36:38.853791
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    video_id = "209733"

    test_1 = [ie.age_limit, 18]
    test_2 = [ie.extractor_key, "__main__.FourTubeIE"]
    test_3 = [ie.id, video_id]