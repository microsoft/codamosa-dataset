

# Generated at 2022-06-22 07:26:56.169620
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	constructor = FourTubeIE.__init__(FourTubeIE)
	assert(constructor == None)


# Generated at 2022-06-22 07:26:57.270206
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE("FuxIE")

# Generated at 2022-06-22 07:26:58.807981
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    with pytest.raises(NotImplementedError):
        FourTubeBaseIE()

# Generated at 2022-06-22 07:27:07.965984
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.suitable('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert PornTubeIE.suitable('https://www.porntube.com/embed/7089759')
    assert PornTubeIE.suitable('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert PornTubeIE.suitable('https://www.porntube.com/videos/teen-couple-doing-anal_7089759') is False

# Generated at 2022-06-22 07:27:13.996034
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    " Verify PornerBrosIE can be instantiated"
    url = "https://www.pornerbros.com/embed/181369"
    # Instantiate PornerBrosIE
    PornerBrosIE(PornTubeIE())
    # call method _real_extract for sanity check
    PornerBrosIE(PornTubeIE())._real_extract(url)

# Generated at 2022-06-22 07:27:15.916551
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test = PornerBrosIE(None)
    assert test.IE_NAME == 'PornerBros'

# Generated at 2022-06-22 07:27:17.667156
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert isinstance(unicode(FuxIE()), unicode)
    assert isinstance(str(FuxIE()), str)

# Generated at 2022-06-22 07:27:19.955304
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-22 07:27:21.361270
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    import pytest
    with pytest.raises(TypeError):
        FourTubeIE("Hello!")

# Generated at 2022-06-22 07:27:27.329844
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:27:58.452179
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Input argument url must be a non-empty string
    url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    ie = PornerBrosIE()
    assert url == ie._VALID_URL

# Generated at 2022-06-22 07:28:02.107312
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # This test will fail if class was not defined as follows
    __import__('sys').modules['PornTubeIE'] = globals()['PornTubeIE']
    __import__('sys').modules['porntube'] = globals()['porntube']
    __import__('sys').modules['compat.porntube'] = __import__('sys').modules['compat.porntube'].__dict__['PornTubeIE'] = __import__('sys').modules['PornTubeIE']


# Generated at 2022-06-22 07:28:02.855226
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass

# Generated at 2022-06-22 07:28:16.062166
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:28:17.780024
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:28:22.779674
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    ie = FourTubeIE()
    ie.extract(url)

# Generated at 2022-06-22 07:28:23.467699
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:28:24.922850
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-22 07:28:31.511269
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    fuxIE._fuxIE._VALID_URL
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._VALID_URL != r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:28:32.137134
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(None)

# Generated at 2022-06-22 07:29:02.923256
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    ie.IE_NAME

# Generated at 2022-06-22 07:29:08.905463
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('www.porntube.com', {})
    PornTubeIE('m.porntube.com', {})
    PornTubeIE('http://www.porntube.com/videos/video_123', {})
    PornTubeIE('http://www.porntube.com/embed/123', {})
    PornTubeIE('http://m.porntube.com/videos/video_123', {})

# Generated at 2022-06-22 07:29:13.485215
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Constructor should raise RegexNotFoundError
    # when passed anything other than PornerBrosIE._VALID_URL
    badurl = 'https://www.google.com'
    with pytest.raises(ExtractorError):
        PornerBrosIE(badurl)

# Generated at 2022-06-22 07:29:14.775233
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:29:21.297658
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:29:26.219389
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-22 07:29:28.902707
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # https://www.youtube.com/watch?v=f5yn5czzjmc
    test_url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    sut = FourTubeIE()

# Generated at 2022-06-22 07:29:37.390129
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # In case of any error, first parameter of assertRaises should be its type.
    # For example, AssertionError should be AssertionError.

    # Test with invalid inputs
    with pytest.raises(AttributeError):
        test_pb_ie = PornerBrosIE()

    # Test with valid inputs
    test_pb_ie = PornerBrosIE('http://pornerbros.com/video/1234', {})
    assert test_pb_ie.video_id == 1234

# Generated at 2022-06-22 07:29:41.286942
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    for i in range(1,1000):
        test_url = "http://www.4tube.com/videos/" + str(i)
        ie = FourTubeIE()
        ie.extract(test_url)


# Generated at 2022-06-22 07:29:46.148792
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # check if class FuxIE is initialized correctly
    assert FuxIE.__name__ == "FuxIE"
    assert FuxIE.IE_NAME == "Fux"
    assert FuxIE.ie._VALID_URL == FuxIE._VALID_URL
    assert FuxIE.ie._URL_TEMPLATE == FuxIE._URL_TEMPLATE
    assert FuxIE.ie._TKN_HOST == FuxIE._TKN_HOST

# Generated at 2022-06-22 07:30:58.447228
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p.__class__ == PornTubeIE
    assert p._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert p._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert p._TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-22 07:31:03.394001
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test if the video id is properly parsed and if the extracted formats are
    # the same as in the test case
    formats = test_FourTubeIE()['info_dict']['formats']
    for format in formats:
        assert format['url'].startswith('rtmp') or 'm3u8' in format['url'] or 'mp4' in format['url']

# Generated at 2022-06-22 07:31:15.807258
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    tmp = PornerBrosIE()
    assert(tmp.IE_NAME == 'PornerBros')
    assert(tmp._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
    assert(tmp._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s')
    assert(tmp._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-22 07:31:16.957604
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:31:20.264842
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE();
    # No constructor defined, so just check it's an instance of the class
    assert isinstance(instance, FourTubeIE)

# Generated at 2022-06-22 07:31:21.334352
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()


# Generated at 2022-06-22 07:31:24.120975
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .common import InfoExtractor
    # Ensure that PornerBrosIE is a subclass of PornTubeIE
    assert issubclass(PornerBrosIE, PornTubeIE)

# Generated at 2022-06-22 07:31:34.497546
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Testing for PornTubeIE
    # "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    # "https://www.porntube.com/embed/7089759"
    # "https://m.porntube.com/videos/teen-couple-doing-anal_7089759"
    item = PornTubeIE()
    assert item._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert item._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-22 07:31:36.760704
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert type(fux) == FuxIE


# Generated at 2022-06-22 07:31:47.239252
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test_video_id = "209733"
    test_display_id = 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    test_url = 'https://www.4tube.com/videos/' + test_video_id + '/video'

    ie = FourTubeIE()
    result = ie.suitable(test_url)
    assert(result == True)

    mobj = re.match(FourTubeIE._VALID_URL, test_url)
    i = FourTubeIE()
    result = i._real_extract(mobj.group('kind'), mobj.group('id'), mobj.group('display_id'))

    assert(result['id'] == test_video_id)

# Generated at 2022-06-22 07:34:41.325720
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Check the constructor of class PornerBrosIE"""
    inst = PornerBrosIE()
    assert inst._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:34:42.769914
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.IE_NAME == "PornerBros"

# Generated at 2022-06-22 07:34:44.299582
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE('FourTube')
    assert obj is not None

# Generated at 2022-06-22 07:34:45.346921
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(_download_json)

# Generated at 2022-06-22 07:34:49.032992
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Unit Tests for class constructor.
    """

    for _, ie in globals().items():
        if ie is PornerBrosIE:
            ie_object = ie()
            assert isinstance(ie_object, PornerBrosIE)
            break



# Generated at 2022-06-22 07:34:52.032868
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE(FuxIE.ie_key())
    except Exception as e:
        return False, str(e)
    return True, None

# Generated at 2022-06-22 07:34:53.201808
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    b = FourTubeIE()
    b.to_screen()

# Generated at 2022-06-22 07:34:55.084935
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 07:34:56.917582
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

test_main()

# Generated at 2022-06-22 07:34:58.388918
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE().IE_NAME == 'pornerbros'