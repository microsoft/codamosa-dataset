

# Generated at 2022-06-22 07:26:54.871253
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE.__name__ == FourTubeIE.IE_NAME

# Generated at 2022-06-22 07:27:04.452702
# Unit test for constructor of class FuxIE
def test_FuxIE():
    #test constructor by passing url to the class
    fux_ie = FuxIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert(fux_ie.IE_NAME == '4tube')
    assert(fux_ie.ie_key() == 'Fux')
    assert(fux_ie.ie_key() != 'FourTube')
    #test constructor by passing ie_key to the class
    fourtube_ie = FourTubeIE("FourTube")
    assert(fourtube_ie.ie_key() == 'FourTube')
    assert(fourtube_ie.ie_key() != '4tube')

# Generated at 2022-06-22 07:27:07.376971
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE._add_skip_wall(PornerBrosIE._VALID_URL, PornerBrosIE._URL_TEMPLATE)

# Generated at 2022-06-22 07:27:10.670819
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-22 07:27:12.270162
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE();
    ie._VALID_URL

# Generated at 2022-06-22 07:27:15.915962
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
	video_id = '7089759'
	url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
	PornTubeIE()._download_webpage(url, video_id)

# Generated at 2022-06-22 07:27:24.040974
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    IE = FourTubeBaseIE('4tube', '4tube.com')
    assert IE._TKN_HOST == 'token.4tube.com'
    IE = FourTubeBaseIE('fux', 'fux.com')
    assert IE._TKN_HOST == 'token.fux.com'
    IE = FourTubeBaseIE('porn-tube', 'porntube.com')
    assert IE._TKN_HOST == 'tkn.porntube.com'
    IE = FourTubeBaseIE('pornerbros', 'pornerbros.com')
    assert IE._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:27:24.763060
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:27:38.092855
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    class_var = 'PornerBrosIE'
    if class_var in globals():
        del globals()[class_var]
    globals()[class_var] = type(
        class_var, (FourTubeBaseIE,), {})
    globals()[class_var]._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    globals()[class_var]._URL_TEMPLATE = 'https://www.pornerbros.com/videos/video_%s'
    globals()[class_var]._TKN_HOST = 'token.pornerbros.com'



# Generated at 2022-06-22 07:27:39.693024
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    instance = FourTubeBaseIE()
    assert isinstance(instance, FourTubeBaseIE)

# Generated at 2022-06-22 07:27:56.709667
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    value = 'fucking'
    FuxIE(None, url = test_url, value = value)

# Generated at 2022-06-22 07:27:57.251977
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()

# Generated at 2022-06-22 07:27:59.506520
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    with open('test/testdata/pornhub.txt') as f:
        ph = PornTubeIE._PornTubeIE(f.read())
    return ph.parse()



# Generated at 2022-06-22 07:28:01.696875
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    m = re.match(PornTubeIE._VALID_URL, 'https://m.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert m != None



# Generated at 2022-06-22 07:28:08.536798
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:28:11.453678
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    _expected_title = 'Teen couple doing anal'
    test_PornTubeIE.__doc__ = _expected_title
    pt = PornTubeIE()
    pt.extract(_url)
    assert pt.title == _expected_title

# Generated at 2022-06-22 07:28:14.605126
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from ..utils import ExtractorError
    from ..compat import compat_urllib_error
    with pytest.raises(ExtractorError) as exc:
        FourTubeIE()._download_webpage('http://www.example.com', '1')
    assert isinstance(exc.value.cause, compat_urllib_error.HTTPError)

# Generated at 2022-06-22 07:28:17.565934
# Unit test for constructor of class FuxIE
def test_FuxIE():
    x = FuxIE()
    assert(x._TKN_HOST == 'token.fux.com')

# Generated at 2022-06-22 07:28:28.463666
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/video/2648016/porn-life-brings-home-some-punani'
    print(PornTubeIE()._real_initialize(url))

    url = 'https://www.porntube.com/videos/porn-life-brings-home-some-punani_2648016'
    print(PornTubeIE()._real_initialize(url))

    url = 'https://www.porntube.com/videos/video_2648016'
    print(PornTubeIE()._real_initialize(url))

    url = 'https://www.porntube.com/embed/2648016'
    print(PornTubeIE()._real_initialize(url))

# Generated at 2022-06-22 07:28:31.602436
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-22 07:29:03.905342
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:29:09.003031
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    #obj = FourTubeBaseIE('FourTubeBaseIE', 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    #obj.start()
    #obj.report_warning('test', 'test')
    pass

# Generated at 2022-06-22 07:29:10.080194
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()

# Generated at 2022-06-22 07:29:11.887893
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.__class__.__name__ == 'PornTubeIE'

# Generated at 2022-06-22 07:29:15.211346
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    PornTubeIE()(url)

# Generated at 2022-06-22 07:29:25.962271
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    # Test constructor of PornTubeIE
    ie = PornTubeIE()
    # Test _VALID_URL, _URL_TEMPLATE, _TKN_HOST
    assert ie._VALID_URL == "https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)"
    assert ie._URL_TEMPLATE == "https://www.porntube.com/videos/video_%s"
    assert ie._TKN_HOST == "tkn.porntube.com"
    # Test _download_webpage() and _parse_json

# Generated at 2022-06-22 07:29:26.710472
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()

# Generated at 2022-06-22 07:29:39.392678
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Make sure the constructor doesn't crash with some values
    # It only tests the public methods
    class TestIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
        _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
        _TKN_HOST = 'token.4tube.com'
    ie = TestIE()
    webpage = '<meta itemprop="uploadDate" content="2017-01-24T17:12:40-08:00">'
    timestamp = ie._html_search_meta('uploadDate', webpage)

# Generated at 2022-06-22 07:29:49.760995
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import sys
    import pdb
    # pdb.set_trace()
    # sys.exit(0)
    # url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    # url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    # pt_ie = PornTubeIE()
    # pt_ie._download_webpage(url, video_id)
    # m = re.match(pt_ie._VALID_URL, url)
    # video_id = m.group('id')
    # mobj = re.match(pt_ie

# Generated at 2022-06-22 07:29:55.502448
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert p._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-22 07:31:15.858759
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie.extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

if __name__ == "__main__":
    test_FuxIE()

# Generated at 2022-06-22 07:31:23.722551
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    f = FourTubeIE()
    assert f._TKN_HOST == "token.4tube.com"
    assert f._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert f._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-22 07:31:29.903154
# Unit test for constructor of class FuxIE
def test_FuxIE():
    cls = FuxIE()
    assert cls._VALID_URL == "https?://(?:(?P<kind>www|m)\\.)?fux\\.com/(?:video|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?"
    assert cls._URL_TEMPLATE == "https://www.fux.com/video/%s/video"
    assert cls._TKN_HOST == "token.fux.com"

# Generated at 2022-06-22 07:31:31.603996
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()



# Generated at 2022-06-22 07:31:34.549422
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE('PornTube')
    assert isinstance(ie, PornTubeIE)


# Generated at 2022-06-22 07:31:38.247957
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    IE=FourTubeBaseIE()
    print(IE._URL_TEMPLATE)
    print(IE._TKN_HOST)
    print(IE._VALID_URL)

# Generated at 2022-06-22 07:31:39.417818
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE()
    assert i != None

# Generated at 2022-06-22 07:31:41.656500
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-22 07:31:43.847343
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    # Test the instance of PornerBrosIE to assure the call of constructor
    assert(isinstance(ie, PornerBrosIE))

# Generated at 2022-06-22 07:31:44.921034
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    cls = FourTubeIE
    print(cls)

# Generated at 2022-06-22 07:34:51.346838
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:34:52.009448
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()

# Generated at 2022-06-22 07:34:59.584907
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeIE()
    expected_fields = ['id', 'ext', 'title', 'uploader', 'uploader_id',
        'upload_date', 'timestamp', 'duration', 'view_count', 'like_count',
        'categories', 'age_limit']
    for test_dict in ie._TESTS:
        video = ie._real_extract(test_dict['url'])
        for field in expected_fields:
            assert field in video, '%s must be in video dict' % field

# Generated at 2022-06-22 07:35:01.251253
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _test_class = PornTubeIE()
    assert _test_class._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'

# Generated at 2022-06-22 07:35:04.062413
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    IE = PornTubeIE()
    # test creating object
    # assert IE, "IE should be created."


# Generated at 2022-06-22 07:35:05.219995
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.IE_NAME

# Generated at 2022-06-22 07:35:07.610460
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'

# Generated at 2022-06-22 07:35:09.684807
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import InfoExtractor
    result = FuxIE(InfoExtractor())._real_initialize()
    assert result == None

# Generated at 2022-06-22 07:35:20.324332
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    init = FourTubeIE._extract_formats('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black', '209733', '209733', ['720', '480', '360', '240'])
    assert init[0]['resolution'] == '720p'
    assert init[3]['resolution'] == '240p'
    assert init[0]['quality'] == 720
    assert init[3]['quality'] == 240
    assert init[2]['format_id'] == '360p'
    assert init[3]['format_id'] == '240p'

# Generated at 2022-06-22 07:35:21.062566
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    this_test_test_test = FourTubeIE()