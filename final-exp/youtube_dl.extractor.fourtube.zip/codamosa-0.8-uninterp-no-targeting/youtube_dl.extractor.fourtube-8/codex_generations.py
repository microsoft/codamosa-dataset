

# Generated at 2022-06-22 07:27:04.773266
# Unit test for constructor of class FuxIE

# Generated at 2022-06-22 07:27:13.500940
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ClassFourTubeBaseIE = FourTubeBaseIE
    ClassFourTubeBaseIE("FourTubeBaseIE", "FourTubeBaseIE", "4tube")
    ClassFourTubeBaseIE("FourTubeBaseIE", "FourTubeBaseIE", "fux")
    ClassFourTubeBaseIE("FourTubeBaseIE", "FourTubeBaseIE", "porntube")
    ClassFourTubeBaseIE("FourTubeBaseIE", "FourTubeBaseIE", "pornerbros")
    ClassFourTubeBaseIE("FourTubeBaseIE", "FourTubeBaseIE", "dogfartnetwork")

# Generated at 2022-06-22 07:27:21.020983
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .fux import FuxIE
    fux = FuxIE()
    fuxIE = FuxIE()
    fuxIE.IE_NAME = "Fux"
    fuxIE._VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    fuxIE._URL_TEMPLATE = 'https://www.fux.com/video/%s/video'
    fuxIE._TKN_HOST = 'token.fux.com'
    assert fuxIE.IE_NAME == fux.IE_NAME
    assert fuxIE._VALID_URL == fux._VALID_URL
    assert f

# Generated at 2022-06-22 07:27:28.219270
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info_extractor = FourTubeBaseIE("test", {})
    assert info_extractor._TKN_HOST == 'token.4tube.com', info_extractor._TKN_HOST
    info_extractor = FourTubeBaseIE("test", {'_TKN_HOST': 'test_video_x.com'})
    assert info_extractor._TKN_HOST == 'test_video_x.com', info_extractor._TKN_HOST

# Generated at 2022-06-22 07:27:40.771547
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE._TKN_HOST = 'token.porntube.com'
    # file
    assert PornTubeIE._parse_json(file('tests/test_data_porntube/video.txt').read(), None, transform_source=lambda x: compat_urllib_parse_unquote(compat_b64decode(x).decode('utf-8')))

    # urllib2
    if True:
        import urllib2
        opener = urllib2.build_opener()
        opener.addheaders = [('Cookie', 'lc=1')]
        urllib2.install_opener(opener)

# Generated at 2022-06-22 07:27:50.539086
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    a = PornTubeIE(FakeInfoExtractor())
    assert a.IE_NAME == 'porntube'
    assert a.IE_DESC == 'Porntube.com'
    assert a._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert a._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert a._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:27:52.532830
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.PornTube.com/videos/squirting-teen-ballerina-ecg_1331406'
    PornTubeIE()._real_extract(url)

# Generated at 2022-06-22 07:27:59.931472
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    from extractor import YoutubeIE
    from pytube import YouTube
    base = FourTubeBaseIE()._download_webpage(url, '209733')
    y = YoutubeIE()._search_regex(r'url\s*:\s*(["\'])(?P<url>https?://.+?)\1', base, 'url', group='url')
    y = YouTube(y)
    y.title = FourTubeBaseIE()._html_search_meta('name', base)
    y.thumbnail_url = FourTubeBaseIE()._html_search_meta('thumbnailUrl', base)
    y.description = FourTubeBaseIE

# Generated at 2022-06-22 07:28:10.762971
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    mobj = re.match(FourTubeIE._VALID_URL, url)
    kind = mobj.group('kind')
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    if kind == 'm':
        url = FourTubeIE._URL_TEMPLATE % video_id
    
    print(url)
# test ends here


# Generated at 2022-06-22 07:28:16.362016
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'
    try:
        PornTubeIE()._real_initialize(url)
    except AttributeError as e:
        print(e)
        assert(False)

if __name__ == '__main__':
    test_PornTubeIE()

# Generated at 2022-06-22 07:28:47.383922
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie != None


# Generated at 2022-06-22 07:28:57.590445
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL is not None
    assert ie._URL_TEMPLATE is not None
    assert ie._TKN_HOST is not None
    assert ie._TESTS is not None
    assert ie._download_webpage is not None
    assert ie._search_regex is not None
    assert ie._html_search_regex is not None
    assert ie._html_search_meta is not None
    assert ie._parse_json is not None
    assert ie._sort_formats is not None
    assert ie._extract_formats is not None
    assert ie._real_extract is not None

# Generated at 2022-06-22 07:29:00.387749
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-22 07:29:05.302918
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from .common import InfoExtractor
    InfoExtractor(youtube_ie.YoutubeIE.ie_key()).extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-22 07:29:09.003408
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from ..generate_extractors import gen_extractor_classes
    for ie in gen_extractor_classes('FourTubeBaseIE'):
        raise Exception('%s doesn\'t have unit test!' % ie.IE_NAME)

# Generated at 2022-06-22 07:29:11.512186
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:29:12.603352
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Test the constructor of class FourTubeBaseIE
    """
    assert issubclass(FourTubeBaseIE, InfoExtractor)



# Generated at 2022-06-22 07:29:17.760689
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    assert PornerBrosIE(url)._VALID_URL == PornerBrosIE._VALID_URL


# Generated at 2022-06-22 07:29:21.964840
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    fourtubebase = FourTubeBaseIE()
    fourtubebase._TESTS = []

    pornerbros = PornerBrosIE()
    assert pornerbros._VALID_URL == r'https?://(?P<kind>www|m)\.)?pornerbros\.com(?:/videos/(?P<display_id>[^/]+)_|/embed/)(?P<id>\d+)'
    assert pornerbros._TESTS == []

# Generated at 2022-06-22 07:29:33.085744
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
   pornerbros = PornerBrosIE()
   assert pornerbros.IE_NAME == '4tube'
   assert pornerbros._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?pornerbros\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
   assert pornerbros._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
   assert pornerbros._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:30:12.202378
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import hashlib
    print(hashlib.md5(b'\xC0\x13\x00\x00').hexdigest())
    import json
    import base64
    import urllib.parse
    import requests
    # 'https://www.porntube.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    url = 'https://www.porntube.com/embed/181369'
    data = requests.get(url).text
    js = PornTubeIE._search_regex(
        r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        data, 'data', group='value')

# Generated at 2022-06-22 07:30:15.107937
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Testing of FuxIE is done by FourTubeBaseIE
    assert FuxIE._TESTS



# Generated at 2022-06-22 07:30:17.486340
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._VALID_URL == PornTubeIE._VALID_URL

# Generated at 2022-06-22 07:30:19.829558
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
    except Exception as e:
        assert False, "PornerBrosIE constructor test failed"



# Generated at 2022-06-22 07:30:29.358856
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestIE(FourTubeBaseIE):
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?test\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
        _URL_TEMPLATE = 'https://www.test.com/videos/video_%s'
        _VALID_DISPLAY_ID = r'\d+'
        _TKN_HOST = 'token.test.com'
    assert TestIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?test\\.com/(?:videos/(?P<display_id>\\d+)_|embed/)(?P<id>\\d+)'
    assert TestIE._URL_T

# Generated at 2022-06-22 07:30:29.973477
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE._TESTS

# Generated at 2022-06-22 07:30:31.574286
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:30:33.551590
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        import base64
        assert base64
    except ImportError:
        raise Exception("base64 not imported. It is required to run PornTubeIE")


# Generated at 2022-06-22 07:30:35.020948
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie is not None

# Generated at 2022-06-22 07:30:35.957621
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    problem = FourTubeBaseIE(None, None)

# Generated at 2022-06-22 07:31:17.992153
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    resource = FourTubeIE(url)
    
    return resource


# Generated at 2022-06-22 07:31:27.196478
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    IE_FourTube = FourTubeIE()
    assert IE_FourTube.IE_NAME == '4tube'
    assert IE_FourTube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert IE_FourTube._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert IE_FourTube._TKN_HOST == 'token.4tube.com'
    assert len(IE_FourTube._TESTS) == 4

# Generated at 2022-06-22 07:31:35.210477
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    x = FourTubeBaseIE()
    assert x._TKN_HOST == 'token.4tube.com'
    assert x._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert x._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

test_FourTubeBaseIE()

# Generated at 2022-06-22 07:31:36.912957
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:31:47.239242
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    """
    Test constructor of class PornTubeIE with a Mock object
    """

    import unittest
    import mock
    import logging
    import json

    class TestPornTubeIE(unittest.TestCase):
        def test_extract(self):
            ie = PornTubeIE()
            ie.ie_key = 'PornTube'
            ie.webpage = ''
            ie._HTML_SUFFIX_PATTERN = r'\s*<!-- END www(_high)? -->'

# Generated at 2022-06-22 07:31:47.910825
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:31:57.737171
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from six.moves import urllib
    from . import _API_HOST
    assert _API_HOST == 'api.porntube.com'
    host = 'api.porntube.com'
    assert host == _API_HOST
    path = 'embed/181369'
    assert path == 'embed/181369'
    host_path = host + '/' + path
    assert host_path == 'api.porntube.com/embed/181369'
    unquoted_url = 'http://' + host_path
    assert unquoted_url == 'http://api.porntube.com/embed/181369'
    url = urllib.parse.quote_plus(unquoted_url)

# Generated at 2022-06-22 07:32:03.309655
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
        Unit test for constructor of class FuxIE
    """

    test_obj = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

    assert test_obj.get_url() == "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"

# Generated at 2022-06-22 07:32:06.450913
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(*('www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',))

# Generated at 2022-06-22 07:32:08.315813
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE(): 
    fourtube = FourTubeIE() 
    assert fourtube.IE_NAME == '4tube'

# Generated at 2022-06-22 07:33:36.428906
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-22 07:33:38.037654
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert type(ie) == PornTubeIE

# Generated at 2022-06-22 07:33:44.172578
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test = FourTubeIE('Fourtube', 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert test._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:33:46.585561
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(FuxIE._downloader, FuxIE._VALID_URL)

# Generated at 2022-06-22 07:33:48.080005
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    c = FourTubeBaseIE()
    assert c._TESTS == None

# Generated at 2022-06-22 07:33:52.199961
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Create an instance of class FuxIE
    fux_ie = FuxIE()
    # Check if the instance is created successfully
    assert fux_ie is not None, "Failed to create instance of FuxIE"


# Generated at 2022-06-22 07:33:54.739916
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert str(ie) == PornTubeIE.IE_NAME
    assert ie.ie_key() == PornTubeIE.IE_NAME
    assert len(ie._TESTS) == 3

# Generated at 2022-06-22 07:33:56.150017
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)
    assert isinstance(ie, FourTubeBaseIE)

# Generated at 2022-06-22 07:34:05.366179
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('http://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:34:09.558669
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        FourTubeBaseIE(None)
    except TypeError:
        pass
    else:
        raise Exception('FourTubeBaseIE constructor did not fail')