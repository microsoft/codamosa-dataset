

# Generated at 2022-06-22 07:26:56.275132
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    info_extractor = PornerBrosIE()

# Generated at 2022-06-22 07:26:59.112872
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        assert(FourTubeBaseIE is not None)
    except AssertionError:
        raise AssertionError('FourTubeBaseIE class is not defined')


# Generated at 2022-06-22 07:27:02.506457
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerBrosIE = PornerBrosIE()
    assert pornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-22 07:27:05.180623
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    PornTubeIE(url)



# Generated at 2022-06-22 07:27:06.365062
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:27:08.189715
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE("nitroflare.com") is not None

# Generated at 2022-06-22 07:27:08.891874
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    pass

# Generated at 2022-06-22 07:27:11.836669
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)
    assert ie.IE_NAME == "Fux"

# Generated at 2022-06-22 07:27:14.524805
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import fourtube
    assert FourTubeBaseIE(fourtube.SunPornoIE(fourtube.PornTubeIE(fourtube.FanClubIE(fourtube.MotherlessIE()))))

# Generated at 2022-06-22 07:27:16.420847
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:27:32.872094
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    e = PornTubeIE()
    assert not hasattr(e, '__name__')

# Generated at 2022-06-22 07:27:36.592512
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE.__init__(PornTubeIE)
    except Exception:
        assert False, 'Failed to test_PornTubeIE'


# Generated at 2022-06-22 07:27:38.308509
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(_print_debug=True)


# Generated at 2022-06-22 07:27:39.901143
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    # Do nothing



# Generated at 2022-06-22 07:27:42.871500
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.download('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-22 07:27:47.261638
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    _PornTubeIE = PornTubeIE()
    assert _PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-22 07:27:49.486767
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie, FourTubeBaseIE)
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Test, if constructor of class FourTubeBaseIE is called correctly 

# Generated at 2022-06-22 07:27:54.649570
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'^https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-22 07:27:56.120028
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    from . import FourTubeIE
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:27:56.950407
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()


# Generated at 2022-06-22 07:28:28.616618
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    print(ie.get_urls(ie._VALID_URL))


# Generated at 2022-06-22 07:28:31.763743
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE();
    assert isinstance(x,PornerBrosIE)


# Generated at 2022-06-22 07:28:33.526585
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('PornerBrosIE', 'PornerBrosIE')

# Generated at 2022-06-22 07:28:37.561617
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from .common import InfoExtractor
    TestInfoExtractor = InfoExtractor.factory(FuxIE)()
    TestInfoExtractor._downloader.params.update({'skip_download':True})
    TestInfoExtractor._real_extract(TestInfoExtractor._VALID_URL)

# Generated at 2022-06-22 07:28:43.007587
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test a valid URL
    fourTubeBaseIEInstance = FourTubeBaseIE(None, "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    # Test an invalid URL
    if not (fourTubeBaseIEInstance is None):
        raise Exception("Failed to initialize FourTubeBaseIE instance with an invalid URL")



# Generated at 2022-06-22 07:28:43.422722
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:28:48.430329
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Check that instances are created only from classes that inherit from FourTubeBaseIE
    try:
        f = FourTubeBaseIE()
        assert f == None
    except Exception as e:
        assert type(e) == TypeError
    f = FuxIE()
    assert f != None
    f = PornTubeIE()
    assert f != None
    f = PornerBrosIE()
    assert f != None

# Generated at 2022-06-22 07:29:01.297534
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    # going to PornTubeIE._download_webpage(url, display_id)
    webpage = PornTubeIE._download_webpage(url, '')
    # going to PornTubeIE._parse_json(self._search_regex(PornTubeIE._VALID_URL, webpage, 'data', group='value'))

# Generated at 2022-06-22 07:29:12.294992
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()

# Generated at 2022-06-22 07:29:15.920054
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """ Unit test for constructor of class FourTubeIE """

    try:
        import lxml.etree
        lxml.etree  # silence pyflakes
    except ImportError:
        from nose.exc import SkipTest
        raise SkipTest('Missing lxml.etree')

    from .common import InfoExtractor

    ie = InfoExtractor(None)

    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:30:24.419746
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.__class__.__name__ == 'FourTubeBaseIE'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'


# Generated at 2022-06-22 07:30:30.654182
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        import HTMLParser
        h = HTMLParser.HTMLParser()
    except ImportError:
        import html.parser
        h = html.parser.HTMLParser()

    player_js = '''
        $.ajax(url, opts);
    }
    })([0,1473657647,[1148,1080,720,544,426,360,270]])
    </script>
    </head>
    <body class="landing">
        <script>
            window.GTM = {
                page_path: "/",
                page_location: "http://www.4tube.com/",
                page_title: "4tube - Free Porn Videos"
            }
        </script>
    </body>
</html>
'''

# Generated at 2022-06-22 07:30:31.608131
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE(_downloader=None) is not None

# Generated at 2022-06-22 07:30:38.314155
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ies = PornerBrosIE(downloader=None, download_enabled=False)
    assert(ies._NAME == 'PornerBros')
    assert(ies._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
    assert(ies._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s')
    assert(ies._TKN_HOST == 'token.pornerbros.com')

# Generated at 2022-06-22 07:30:40.463229
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    # just test the constructor
    assert ie

# Generated at 2022-06-22 07:30:41.432146
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:30:42.995870
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    res = FourTubeIE()
    assert res


# Generated at 2022-06-22 07:30:44.692495
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie is not None


# Generated at 2022-06-22 07:30:55.941741
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import json
    from ..utils import (
        parse_duration,
        unified_timestamp,
    )
    from ..compat import (
        compat_b64decode,
        compat_urllib_parse_unquote,
    )

    def transform_source(x, video_id=None):
        x = compat_urllib_parse_unquote(compat_b64decode(x).decode('utf-8'))
        return json.loads(x)

    url = "https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406"
    video_id = "1331406"
    display_id = "squirting-teen-ballerina-ecg_1331406"
    pti = PornTubeIE()

    webpage = pti._

# Generated at 2022-06-22 07:30:56.506532
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pass

# Generated at 2022-06-22 07:33:37.983432
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-22 07:33:47.087172
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?';
    assert FuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video';
    assert FuxIE._TKN_HOST == 'token.fux.com';

# Generated at 2022-06-22 07:33:51.472182
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info = FourTubeBaseIE()
    assert info._VALID_URL is None
    assert info._URL_TEMPLATE is None
    assert info._TKN_HOST is None
    assert info._TESTS is None
    assert info._download_webpage is not None



# Generated at 2022-06-22 07:33:53.925571
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    Pbi = PornerBrosIE()
    assert(Pbi is not None)



# Generated at 2022-06-22 07:33:59.315538
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'pornerbros'
    assert ie.IE_DESC == 'PornerBros, PornTube and Fux'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:34:01.015389
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube', PornTubeIE._VALID_URL, PornTubeIE._VALID_URL)

# Generated at 2022-06-22 07:34:04.905582
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """Validate an instance of class PornerBrosIE"""
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE()._real_extract(url)

# Generated at 2022-06-22 07:34:05.806221
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Do not instantiate class PornTubeIE
    pass

# Generated at 2022-06-22 07:34:13.926281
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    info_extractor = PornerBrosIE()
    assert info_extractor.IE_NAME == '4tube'
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert info_extractor._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert info_extractor._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:34:15.400702
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # Try to create instance of class FuxIE
    fux_ie = FuxIE()

# Test for function _real_extract