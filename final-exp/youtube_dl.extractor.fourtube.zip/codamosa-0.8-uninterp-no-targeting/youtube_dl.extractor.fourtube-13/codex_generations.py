

# Generated at 2022-06-22 07:26:56.377072
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
  PornerBrosIE('pornerbros.com')

# Generated at 2022-06-22 07:27:00.531719
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    p = PornTubeIE(InfoExtractor())
    r = p.extract(url)
    assert r and r['age_limit'] == 18

# Generated at 2022-06-22 07:27:03.045712
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()._TESTS[0]
    assert obj['url'] == obj['info_dict']['url']

# Generated at 2022-06-22 07:27:07.785434
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    fuxIE._TKN_HOST
    fuxIE._URL_TEMPLATE
    assert (fuxIE._VALID_URL is
            FuxIE._VALID_URL)

# Generated at 2022-06-22 07:27:19.092664
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    class_ = PornTubeIE
    assert hasattr(class_, '_VALID_URL') and hasattr(class_, '_URL_TEMPLATE') and hasattr(class_, '_TKN_HOST') and hasattr(class_, '_TESTS')
    assert hasattr(class_, 'IE_NAME')
    if hasattr(class_, '_TEST') and isinstance(class_._TEST, dict):
        for key, value in class_._TEST.items():
            if key not in ['url', 'md5', 'info_dict', 'params']:
                assert False
            elif key == 'url':
                assert isinstance(value, str)
            elif key == 'md5':
                assert isinstance(value, str)

# Generated at 2022-06-22 07:27:20.404577
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTubeIE = FourTubeIE()
    print(fourTubeIE)

# Generated at 2022-06-22 07:27:27.732290
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class TestIE(FourTubeBaseIE):
        _VALID_URL = None
        _URL_TEMPLATE = None
        _TKN_HOST = None
        _TESTS = []
    assert TestIE.__name__ == 'TestIE'
    assert TestIE._VALID_URL == None
    assert TestIE._URL_TEMPLATE == None
    assert TestIE._TKN_HOST == None
    assert TestIE._TESTS == []

# Generated at 2022-06-22 07:27:30.812157
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
        print("Test passed")
    except Exception as e:
        print(e)
        print("Test failed")



# Generated at 2022-06-22 07:27:36.974257
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('http://www.porntube.com/embed/7089759') == PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759') == PornTubeIE('https://m.porntube.com/videos/teen-couple-doing-anal_7089759')

# Generated at 2022-06-22 07:27:38.189046
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE.suite()

# Generated at 2022-06-22 07:27:53.089328
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i = PornerBrosIE()

# Generated at 2022-06-22 07:27:54.638626
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)


# Generated at 2022-06-22 07:27:56.986574
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    class_ = FourTubeIE
    try:
        class_(None)
        assert 0, "Constructor of class %s should require an argument" % class_
    except TypeError:
        pass


# Generated at 2022-06-22 07:28:02.541387
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    obj = PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert obj.__name__ == "PornTube"
    assert obj._VALID_URL == r'(?i)https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>[0-9]+)'
    assert obj._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert obj._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:28:05.078095
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Constructor of class PornTubeIE
    PornTubeIE()



# Generated at 2022-06-22 07:28:10.236983
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    global FourTubeBaseIE
    # Setup
    FourTubeBaseIE.__bases__ = (InfoExtractor,)

    # Exercise
    fourTubeBaseIE = FourTubeBaseIE(None)

    # Verify
    assert fourTubeBaseIE.IE_NAME == '4tube'

# Generated at 2022-06-22 07:28:12.925486
# Unit test for constructor of class FuxIE
def test_FuxIE():
    #Unit test for FuxIE constructor
    try:
        FuxIE()
    except:
        print('Failed Unit test due to exception')

# Generated at 2022-06-22 07:28:23.201672
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(PornerBrosIE._VALID_URL, url)
    video_id, display_id = mobj.group('id', 'display_id')
    page = PornerBrosIE._download_webpage(url, video_id)

# Generated at 2022-06-22 07:28:24.384123
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert obj is not None

# Generated at 2022-06-22 07:28:25.573993
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    e = FourTubeIE()
    print(e)

# Generated at 2022-06-22 07:28:59.864466
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .test_downloader import get_testcases
    test_case = get_testcases(PornTubeIE)[0]
    result = PornTubeIE()._real_extract(test_case['url'])
    assert(result['title'] == test_case['info_dict']['title'])
    assert(result['id'] == test_case['info_dict']['id'])

# Generated at 2022-06-22 07:29:11.194658
# Unit test for constructor of class PornerBrosIE

# Generated at 2022-06-22 07:29:21.264215
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-22 07:29:27.691731
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie_object = FourTubeIE()
    assert ie_object._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-22 07:29:40.549238
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from pprint import pprint
    from .common import init_test_dump
    from .common import get_test_id

    test_sources = ','.join([
        'FullHD_1920x1080p_6000',
        'HD_1280x720p_6000',
        'SD_852x480p_4000',
        'SD_640x480p_2500',
        'LowRes_400x226p_1000',
    ])
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    token_url = 'https://token.4tube.com/2073525/desktop/FullHD_1920x1080p_6000+HD_1280x720p_6000'
    parsed

# Generated at 2022-06-22 07:29:49.914827
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # assert(FourTubeBaseIE.suitable('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'))
    # assert(FourTubeBaseIE.suitable('https://www.4tube.com/embed/209733'))
    # assert(FourTubeBaseIE.suitable('https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'))

    assert(FourTubeBaseIE.suitable('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'))

# Generated at 2022-06-22 07:29:53.125359
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # pylint: disable=protected-access
    obj1 = PornTubeIE(None)
    obj2 = PornTubeIE(None)
    assert obj1._TKN_HOST != obj2._TKN_HOST

# Generated at 2022-06-22 07:29:57.816273
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Unit test for constructor of class FourTubeBaseIE"""
    i = FourTubeBaseIE()
    assert i.IE_NAME == "4tube"

# Generated at 2022-06-22 07:30:05.325635
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fetcher = FuxIE()
    assert fetcher.IE_NAME == '4tube'
    fetcher = FuxIE('www')
    assert fetcher.IE_NAME == '4tube'
    fetcher = FuxIE('m')
    assert fetcher.IE_NAME == '4tube'
    fetcher = FuxIE('me')
    assert fetcher.IE_NAME == '4tube'
    fetcher = FuxIE('www.')
    assert fetcher.IE_NAME == '4tube'
    fetcher = FuxIE('.www')
    assert fetcher.IE_NAME == '4tube'
    fetcher = FuxIE('.www.')
    assert fetcher.IE_NAME == '4tube'

# Generated at 2022-06-22 07:30:08.149137
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Simple unit test for the constructor of class FourTubeIE
    """
    try:
        ie = FourTubeIE()
    except:
        assert False, "FourTubeIE() raised Exception unexpectedly!"

# Generated at 2022-06-22 07:30:38.346325
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ext = FourTubeBaseIE()

# Generated at 2022-06-22 07:30:39.432321
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie.IE_NAME == "porntube"

# Generated at 2022-06-22 07:30:43.165354
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    infoExtractor = PornerBrosIE()
    # assert that the constructor of PornerBrosIE class was executed properly
    assert infoExtractor.IE_NAME == 'PornerBros'

# Generated at 2022-06-22 07:30:50.400213
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info = FourTubeIE()._real_extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert info['id'] == '209733'
    assert info['formats'][0]['format_id'] == '720p'
    assert info['title'] == 'Hot Babe Holly Michaels gets her ass stuffed by black'
    assert info['upload_date'] == '20131031'
    assert info['duration'] == 583
    assert 'uploader' in info
    assert info['view_count'] is not None
    assert info['like_count'] is not None
    assert 'categories' in info
    assert info['age_limit'] == 18

# Generated at 2022-06-22 07:30:53.519296
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie.IE_NAME
    ie._VALID_URL
    ie._URL_TEMPLATE
    ie._TKN_HOST
    ie._TESTS



# Generated at 2022-06-22 07:31:02.398906
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    i = PornerBrosIE()
    assert i.IE_NAME == 'PornerBros'
    assert i._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert i._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert i._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:31:04.107515
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Get instance of class FourTubeIE
    obj = FourTubeIE()
    # Check if instance is valid
    assert(obj != None)



# Generated at 2022-06-22 07:31:07.309268
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'
    return 0

# Generated at 2022-06-22 07:31:12.254775
# Unit test for constructor of class FuxIE
def test_FuxIE():
    IE = PornTubeIE()
    # a successful call of FuxIE.extract() is actually inside the procedure of test_FuxIE
    IE.extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-22 07:31:19.108743
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE();
    fuxIE._download_json('https://token.fux.com/7088/720p+480p+240p', '7088', data=b'', headers={
            'Origin': 'https://www.fux.com',
            'Referer': 'https://www.fux.com/video/7088/let-s-play-with-my-pussy-%3F',
        })

# Generated at 2022-06-22 07:32:27.437977
# Unit test for constructor of class FuxIE
def test_FuxIE():
    instance = FuxIE()
    instance._URL_TEMPLATE
    #Test passes if _URL_TEMPLATE is a string

# Generated at 2022-06-22 07:32:28.358277
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Should not raise exception
    PornTubeIE()

# Generated at 2022-06-22 07:32:31.631756
# Unit test for constructor of class FuxIE
def test_FuxIE():

    s = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    assert s == FuxIE()._VALID_URL

# Generated at 2022-06-22 07:32:43.595031
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import requests

    class MockResponse():
        def __init__(self):
            self._status_code = 200
            self.headers = {'content-type': 'text/html; charset=utf-8'}
            self.text = None

        def raise_for_status(self):
            return

        def json(self):
            return self.text

    video_id = '7089759'
    display_id = 'teen-couple-doing-anal_7089759'
    url = 'https://www.porntube.com/videos/' + display_id

    response = MockResponse()

# Generated at 2022-06-22 07:32:49.159727
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # PornerBrosIE object constructor
    pornerbros = PornerBrosIE()
    # Value of pornerbros object
    pornerbros_value = pornerbros.IE_NAME
    # Assert value is PornHub
    assert pornerbros_value == 'PornHub', 'Not correct'



# Generated at 2022-06-22 07:32:50.792768
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert(FourTubeBaseIE.ie_key() == '4tube')


# Generated at 2022-06-22 07:32:51.841940
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()

# Generated at 2022-06-22 07:32:52.891819
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE()

# Generated at 2022-06-22 07:32:59.258941
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    e = FourTubeBaseIE('FourTube', 'https://www.4tube.com/videos/video_209733', '209733')
    assert e.ie_key() == 'FourTube'
    assert e._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert e._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert e._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:33:00.146861
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Checks if class FourTubeBaseIE can be initialized."""
    FourTubeBaseIE()

# Generated at 2022-06-22 07:35:58.550669
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    # Base class should be FourTubeBaseIE
    assert ie.__class__.__bases__[0] == FourTubeBaseIE

# Generated at 2022-06-22 07:36:02.438689
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    PornerBrosIE()

# Generated at 2022-06-22 07:36:05.405114
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test the constructor
    porner_bros_ie = PornerBrosIE()
    assert porner_bros_ie



# Generated at 2022-06-22 07:36:09.690944
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()._extract_formats(
        'http://www.porntube.com/videos/milf-loves-anal-fucking_1475602',
        '1475602', '259', ['720', '480', '360', '240'])

# Generated at 2022-06-22 07:36:13.485421
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    class_name = "FourTubeBaseIE"
    config = {}
    a = globals()[class_name]()
    globals().update(locals())
    assert a==globals()['FourTubeBaseIE']
    print("all test passed")

# Generated at 2022-06-22 07:36:14.614497
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    sub_class = FourTubeBaseIE()

# Generated at 2022-06-22 07:36:15.698647
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:36:18.881689
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == ''
    assert ie._URL_TEMPLATE == ''
    assert ie._TKN_HOST == ''

# Generated at 2022-06-22 07:36:27.233620
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fourtube = FuxIE()
    assert fourtube._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fourtube._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fourtube._TKN_HOST == 'token.fux.com'
    assert fourtube._TESTS[1]['url'] == 'https://www.fux.com/embed/195359'

# Generated at 2022-06-22 07:36:29.233450
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE()
        assert(False)
    except:
        pass