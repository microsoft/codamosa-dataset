

# Generated at 2022-06-22 07:26:59.225669
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE();
    return;

if __name__ == "__main__":
	test_FuxIE();

# Generated at 2022-06-22 07:27:12.004585
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # test invalid URL
    invalid_url = 'https://example.com/'
    assert FourTubeBaseIE._VALID_URL is None, '_VALID_URL should be None originally'
    assert FourTubeBaseIE._TKN_HOST is None, '_TKN_HOST should be None originally'
    assert FourTubeBaseIE._URL_TEMPLATE is None, '_URL_TEMPLATE should be None originally'
    try:
        FourTubeBaseIE(invalid_url)
    except AssertionError:
        pass
    else:
        assert False, 'Expect an AssertionError since invalid URL is used'

    # test valid URL

# Generated at 2022-06-22 07:27:14.561486
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        object = FourTubeIE()
    except:
        print("Expected FourTubeIE exception")
        return

    assert(False)


# Generated at 2022-06-22 07:27:17.371470
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE(None, 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
test_FourTubeIE.test = 1


# Generated at 2022-06-22 07:27:18.527884
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, FuxIE)

# Generated at 2022-06-22 07:27:22.894596
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    import unittest
    from ytdl.extractor import PornerBrosIE
    from ytdl.tests import get_testcases

    class TestPornerBrosIE(unittest.TestCase):
        def test_constructor(self):
            for tc in get_testcases(PornerBrosIE._TESTS, r'only_matching'):
                self.assertTrue(PornerBrosIE._VALID_URL(tc['url']))

# Generated at 2022-06-22 07:27:24.963625
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-22 07:27:25.620881
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:27:27.465855
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-22 07:27:33.048845
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        _ = FourTubeBaseIE('full_extract_test')
        _ = PornTubeIE('full_extract_test')
        _ = FuxIE('full_extract_test')
        _ = PornerBrosIE('full_extract_test')
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-22 07:27:47.131213
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE();

# Generated at 2022-06-22 07:27:47.864508
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE(None)

# Generated at 2022-06-22 07:27:55.102161
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie.IE_NAME == 'PornerBros'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:27:56.884153
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux_ie = FuxIE(FourTubeBaseIE)
    assert(fux_ie == FuxIE(FourTubeBaseIE))

# Generated at 2022-06-22 07:27:58.130959
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:28:08.543973
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = ('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    (video_id, display_id) = re.match(FourTubeIE._VALID_URL, url).group('id', 'display_id')
    url_template = FourTubeIE._URL_TEMPLATE % video_id
    assert display_id == ("hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert url_template == ('https://www.4tube.com/videos/209733/video')



# Generated at 2022-06-22 07:28:12.237224
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE(None, None)._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-22 07:28:13.000424
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:28:21.235806
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    objD = PornTubeIE()

    x = ['181369']
    y = objD._search_regex(
        r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        x, 'data', group='value')
    print(y)
    # objD._parse_json(y)


# Test
if __name__ == '__main__':
    test_PornTubeIE()

# Generated at 2022-06-22 07:28:28.651319
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    video_info_url = 'https://www.pornerbros.com/videos/video_181369'
    video_url = 'http://token.pornerbros.com/181369/desktop/360%2B480%2B720'
    headers = {
        'Origin': 'https://www.pornerbros.com',
        'Referer': 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
    }
    data = b''
    request = compat_urllib_request.Request(video_url, data=data, headers=headers)
    with compat_urllib_request.urlopen(request) as f:
        res = f.read()
    import json
    res

# Generated at 2022-06-22 07:28:56.269914
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/videos/video_181369')


# Generated at 2022-06-22 07:28:58.524734
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    try:
        PornerBrosIE(None)
        assert True
    except:
        assert False


# Generated at 2022-06-22 07:29:04.831541
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert isinstance(ie.IE_NAME, object)
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._URL_TEMPLATE == ie._URL_TEMPLATE
    assert ie._TKN_HOST == ie._TKN_HOST
    assert isinstance(ie._TESTS, object)

# Generated at 2022-06-22 07:29:06.032407
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:29:10.079190
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Tests the object creation and whether the name field is set correctly
    obj = FourTubeIE()

    assert obj.ie_key() == 'FourTube'
    assert obj.ie_name == '4tube'
    assert obj.ie_version == '0.0'

# Generated at 2022-06-22 07:29:11.397326
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    FuxIE().url_result(url)

# Generated at 2022-06-22 07:29:17.585027
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    i = InfoExtractor()
    # To use static method, see https://stackoverflow.com/questions/136097/what-is-the-difference-between-staticmethod-and-classmethod-in-python

# Generated at 2022-06-22 07:29:19.794928
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert fux._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:29:20.584533
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE(None)


# Generated at 2022-06-22 07:29:25.679972
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    obj = PornerBrosIE()
    assert(type(obj)==PornerBrosIE)
    assert(obj._VALID_URL==PornerBrosIE._VALID_URL)

# Generated at 2022-06-22 07:30:25.537316
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    test1 = FourTubeIE("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert test1.__class__.__name__ == 'FourTubeIE'

    test2 = FourTubeIE("https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow")
    assert test2.__class__.__name__ == 'FuxIE'
    
    test3 = FourTubeIE("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    assert test3.__class__.__name__ == 'PornTubeIE'
    

# Generated at 2022-06-22 07:30:29.998269
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    input_url = 'http://www.4tube.com/videos/180147/amazing-teen-blonde-gets-banged-hard'
    try:
        FourTubeBaseIE()
    except TypeError as e:
        assert("__init__() missing 1 required positional argument: 'url'" in str(e))
    ie = FourTubeBaseIE(input_url)
    assert ie.url == input_url
    assert ie.video_id == '180147'
    assert ie.display_id == 'amazing-teen-blonde-gets-banged-hard'

# Generated at 2022-06-22 07:30:31.482819
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    instance = FourTubeIE()
    assert(instance._TKN_HOST == "token.4tube.com")

# Generated at 2022-06-22 07:30:39.618906
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_cases = [PornerBrosIE, PornerBrosIE, PornerBrosIE, PornTubeIE]
    domains_tuple = ('pornerbros.com', 'pornerbros.com', 'pornerbros.com', 'porntube.com')
    assert [type.IE_NAME for type in test_cases] == [
        'PornerBros', 'PornerBros', 'PornerBros', 'PornTube']
    assert [type._NETRC_MACHINE for type in test_cases] == domains_tuple

# Generated at 2022-06-22 07:30:43.341741
# Unit test for constructor of class FuxIE
def test_FuxIE():
    try:
        FuxIE()
    except:
        print("FuxIE constructor exception")
        raise

if __name__ == '__main__':
    test_FuxIE()

# Generated at 2022-06-22 07:30:45.489513
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert isinstance(x, PornTubeIE)


# Generated at 2022-06-22 07:30:48.775745
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie = FuxIE()
    ie = PornTubeIE()
    ie = PornerBrosIE()

# Generated at 2022-06-22 07:30:50.664617
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    x = PornTubeIE()
    assert(x is not None);
    print("PornTubeIE() done");

# Generated at 2022-06-22 07:30:55.586222
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test with different scheme (http)
    url = 'http://www.porntube.com/embed/7089759'
    test_url = PornTubeIE._match_id(url)
    assert test_url == 'http://www.porntube.com/embed/7089759', 'Expected URL: %s. Got %s' % (url, test_url)

# Generated at 2022-06-22 07:30:59.794243
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()._download_webpage("http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black", "209733")

# Generated at 2022-06-22 07:32:02.453597
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:32:06.028202
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """
    Test for the constructor of the FuxIE class
    """
    ie = FuxIE()
    assert ie.ie_key() == 'Fux'
    assert ie.ie_name() == 'Fux'



# Generated at 2022-06-22 07:32:14.098457
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_PornTubeIE.ies = [
        FourTubeIE(),  FuxIE(), PornTubeIE(), PornerBrosIE()
    ]
    for ie in test_PornTubeIE.ies:
        if not ie.suitable('https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'):
            return False
    return True

# Generated at 2022-06-22 07:32:18.541837
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    url = 'https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-22 07:32:21.635259
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    obj = FourTubeBaseIE()
    assert isinstance(obj.IE_NAME, str)
    assert isinstance(obj._VALID_URL, str)
    assert isinstan

# Generated at 2022-06-22 07:32:22.710392
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porntube = PornTubeIE()

# Generated at 2022-06-22 07:32:26.923723
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert hasattr(ie,"_VALID_URL")
    assert hasattr(ie, "_TKN_HOST")
    assert hasattr(ie,"_URL_TEMPLATE")
    assert hasattr(ie,"_TESTS")
    return ie


# Generated at 2022-06-22 07:32:29.263126
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('PornerBrosIE', PornerBrosIE._URL_TEMPLATE)
    print(ie)

# Generated at 2022-06-22 07:32:35.131537
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Simple test for constructor of class FourTubeIE
    """
    instance = FourTubeIE('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert instance._TKN_HOST == "token.4tube.com"


# Generated at 2022-06-22 07:32:38.924805
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Test the constructor of PornerBrosIE
    # this should work
    PornerBrosIE()
    # this should fail, because it expects a URL as the first argument
    PornerBrosIE()._real_extract(None)

# Generated at 2022-06-22 07:34:12.019874
# Unit test for constructor of class FuxIE
def test_FuxIE():
    # input url of porn video on fux.com
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    ie = FuxIE().get_info(url)
    print(ie)


# Generated at 2022-06-22 07:34:19.640884
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video_id = "7089759"
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    html_url = "https://www.porntube.com/embed/7089759"
    webpage = PornTubeIE()._download_webpage(url, video_id)

# Generated at 2022-06-22 07:34:21.281871
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert isinstance(PornTubeIE(), FourTubeBaseIE)

# Generated at 2022-06-22 07:34:23.242145
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'



# Generated at 2022-06-22 07:34:32.202065
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Test for PornTubeIE
    for test in PornTubeIE._TESTS:
        ie = PornTubeIE()
        ie.download(test['url'])
    # Test for FuxIE
    for test in FuxIE._TESTS:
        ie = FuxIE()
        ie.download(test['url'])
    # Test for FourTubeIE
    for test in FourTubeIE._TESTS:
        ie = FourTubeIE()
        ie.download(test['url'])
    # Test for PornerBrosIE
    for test in PornerBrosIE._TESTS:
        ie = PornerBrosIE()
        ie.download(test['url'])

# Generated at 2022-06-22 07:34:35.067109
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    object = PornTubeIE()
    assert object.IE_NAME == 'PornTube'

# Generated at 2022-06-22 07:34:47.098206
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxie = FuxIE()
    assert fuxie.IE_NAME == 'fux'
    assert fuxie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxie._TKN_HOST == 'token.fux.com'
    assert fuxie.__doc__ == '4tube and fux (4tube.com, fux.com, porntube.com, pornerbros.com) video extractor'

# Generated at 2022-06-22 07:34:55.766300
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    four_tube_ie = FourTubeIE()
    assert four_tube_ie.IE_NAME == '4tube'
    assert four_tube_ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert four_tube_ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert four_tube_ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:35:04.641816
# Unit test for constructor of class PornTubeIE

# Generated at 2022-06-22 07:35:07.842708
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(PornerBrosIE._VALID_URL, PornerBrosIE._NAME)

# Generated at 2022-06-22 07:36:29.534506
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    obj = PornerBrosIE()
    assert obj._TKN_HOST == "token.pornerbros.com"

# Generated at 2022-06-22 07:36:31.718756
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube', 'www.porntube.com')



# Generated at 2022-06-22 07:36:34.929541
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Verify that _setup() is called
    class TestFourTubeBaseIE(FourTubeBaseIE):
        def _setup(self):
            assert self.IE_NAME == 'test'
    TestFourTubeBaseIE()