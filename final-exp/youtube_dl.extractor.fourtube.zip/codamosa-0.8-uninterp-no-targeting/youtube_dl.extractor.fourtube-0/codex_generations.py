

# Generated at 2022-06-22 07:26:59.018275
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE('https://www.pornerbros.com/embed/181369')

# Generated at 2022-06-22 07:27:00.156932
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:27:02.225850
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == 'token.fux.com'


# Generated at 2022-06-22 07:27:05.362204
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE().extract('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')

# Generated at 2022-06-22 07:27:06.616506
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbrosIE = PornerBrosIE()

# Generated at 2022-06-22 07:27:07.964595
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:27:18.110370
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    video_id = '7089759'
    display_id = 'teen-couple-doing-anal'
    url = 'https://www.porntube.com/videos/' + display_id + '_7089759'
    url_template = 'https://www.porntube.com/videos/video_%s'
    video_url = url_template % video_id
    webpage = r'''<script id='initialState' src='https://www.porntube.com/assets/application-bd20aa2d17ff7b0c2a2f76416f0dfc9d.js' defer></script>
    <script>
        window.location = '%s';
    </script>
    ''' % video_url

# Generated at 2022-06-22 07:27:18.931994
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('porntube:7089759')

# Generated at 2022-06-22 07:27:25.345756
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    info = FourTubeIE()._real_extract('https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')

# Generated at 2022-06-22 07:27:36.450581
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from collections import namedtuple
    from .fake_extractor import FakeExtractor
    from ..compat import compat_urllib_parse_unquote, compat_b64decode
    from ..utils import (
        parse_duration,
        unified_timestamp,
    )
    r = namedtuple("r", "status, headers, data")
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    r.status = 200
    r.headers = ""
    r.data = open("test/testdata/test_PornTubeIE.html", "rb").read()
    
    # Test parsing json
    pt = PornTubeIE()

# Generated at 2022-06-22 07:27:58.346261
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._VALID_URL == r'https?:\/\/(?:(?P<kind>www|m)\.)?4tube\.com\/(?:videos|embed)\/(?P<id>\d+)(?:\/(?P<display_id>[^\/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:27:59.401861
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE()._TKN_HOST=='token.fux.com'


# Generated at 2022-06-22 07:28:02.317263
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """
    Test case for the PornerBrosIE class
    """

    ie = PornerBrosIE()
    assert ie.IE_NAME == "pornerbros"

# Generated at 2022-06-22 07:28:03.655969
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE()



# Generated at 2022-06-22 07:28:11.001528
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Arrange
    url = "http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    # Act
    fourTubeBaseIE = FourTubeBaseIE()
    # Assert
    fourTubeBaseIE.suitable(url)


# Generated at 2022-06-22 07:28:21.061321
# Unit test for constructor of class FourTubeBaseIE

# Generated at 2022-06-22 07:28:24.331087
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeIE, FourTubeBaseIE)
    assert issubclass(FuxIE, FourTubeBaseIE)
    assert issubclass(PornTubeIE, FourTubeBaseIE)
    assert issubclass(PornerBrosIE, FourTubeBaseIE)

# Generated at 2022-06-22 07:28:28.188135
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    porn_tube_ie = PornTubeIE()
    title = porn_tube_ie._html_search_meta('name', '<meta name="thumbnailUrl" content="https://static.tacdn.com/img2/vacations/maps/share/map_hero_us.jpg" property="thumbnailUrl" />', 'title')
    assert title is False

# Generated at 2022-06-22 07:28:32.821584
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourTubeIE = FourTubeIE()
    assert fourTubeIE.__class__.__name__ == 'FourTubeIE'
    assert fourTubeIE._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:28:38.110039
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        infoExtractor = FourTubeIE(None)
        print(infoExtractor.extract_info('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'))
    except Exception as e:
        print('[ERR]:' + str(e))

# Generated at 2022-06-22 07:29:14.506785
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .common import InfoExtractor
    instance = InfoExtractor()
    test_cases = [
        (FourTubeIE, '4tube'),
        (FuxIE, 'fux'),
        (PornTubeIE, 'porntube'),
        (PornerBrosIE, 'pornerbros'),
        (InfoExtractor, None),
    ]
    for test_class, expected_name in test_cases:
        assert(
            test_class._VALID_URL == instance._VALID_URL and
            test_class._URL_TEMPLATE == instance._URL_TEMPLATE and
            test_class._TKN_HOST == instance._TKN_HOST and
            test_class.IE_NAME == expected_name)

# Generated at 2022-06-22 07:29:16.556704
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert (fux._TKN_HOST == 'token.fux.com')

# Generated at 2022-06-22 07:29:17.770966
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(test='test')

# Generated at 2022-06-22 07:29:22.382909
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE();
    _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    _URL_TEMPLATE = 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == _VALID_URL
    assert ie._URL_TEMPLATE == _URL_TEMPLATE

# Generated at 2022-06-22 07:29:28.605360
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    import warnings
    warnings.simplefilter('ignore')
    assert PornTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'



# Generated at 2022-06-22 07:29:30.562270
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:29:31.710008
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()



# Generated at 2022-06-22 07:29:41.090581
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com' 
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-22 07:29:49.937342
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    ie = FuxIE('http://4tube.com/video/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert(ie.IE_NAME == '4tube')
    assert(ie.VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')

    ie = FuxIE('http://fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert(ie.IE_NAME == 'fux')

# Generated at 2022-06-22 07:29:52.676292
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    p = PornTubeIE()
    p._download_webpage(url, None)
    assert True

# Generated at 2022-06-22 07:31:00.820057
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test_fux = FuxIE()
    assert test_fux._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:31:01.889061
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()


# Generated at 2022-06-22 07:31:06.478874
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE('PornerBros')
    assert ie._TKN_HOST == 'token.pornerbros.com'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-22 07:31:09.437249
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("FourTubeBaseIE");
    assert ie.IE_NAME == 'FourTubeBaseIE'


# Generated at 2022-06-22 07:31:10.483286
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE() is not None

# Generated at 2022-06-22 07:31:13.198545
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Unit test for constructor of class FourTubeBaseIE."""
    from .common import _test_constructor
    _test_constructor(FourTubeBaseIE, 'test')

# Generated at 2022-06-22 07:31:21.804583
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj.IE_NAME == '4tube'
    assert obj.VERSION == '0.2'
    #assert obj.DESCRIPTION == '4tube.com is the #1 porn site on the Internet always fresh and exciting. 4tube.com is the #1 porn site on the Internet always fresh and exciting. 4tube.com is the #

# Generated at 2022-06-22 07:31:27.738381
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.ie_key() == '4tube'
    assert ie.host() == 'token.4tube.com'
    assert ie.base_url == 'https://www.4tube.com/'
    assert ie.video_id == '209733'
    assert ie.display_id == 'hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'

# Generated at 2022-06-22 07:31:31.157366
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE(None)

# Generated at 2022-06-22 07:31:43.099189
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    from .test_utils import parse_json
    from .common import InfoExtractor

    fourTubeBaseIE = FourTubeBaseIE()

    # Failure cases
    # parse_json requires object like json
    assert fourTubeBaseIE._parse_json(None, '') == None

    # parse_json requires object like json
    assert fourTubeBaseIE._parse_json('', '') == None

    # parse_json requires object like json
    assert fourTubeBaseIE._parse_json('{"test": "1"}', '', transform_source=lambda x: x) == None

    # Check if _parse_json is a method of class InfoExtractor
    assert hasattr(InfoExtractor, '_parse_json')

    # Success cases

# Generated at 2022-06-22 07:34:30.650314
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._TKN_HOST == "tkn.porntube.com"

# Generated at 2022-06-22 07:34:32.746424
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE("www.fourtubebaseie.com", {}, {},
                           "FourTubeBaseIE")
    assert ie.name == "FourTubeBaseIE"

# Generated at 2022-06-22 07:34:35.571383
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj.IE_NAME == '4tube'

# Generated at 2022-06-22 07:34:39.155290
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert issubclass(FourTubeBaseIE, InfoExtractor)

test_FourTubeBaseIE()


# Generated at 2022-06-22 07:34:42.620912
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    yt = FourTubeIE()
    assert yt.__class__.__name__ == 'FourTubeIE'
    assert yt._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:34:43.304758
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pass

# Generated at 2022-06-22 07:34:49.782871
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()
    PornerBrosIE._TESTS
    PornerBrosIE._VALID_URL
    PornerBrosIE._URL_TEMPLATE
    PornerBrosIE._TKN_HOST
    PornerBrosIE._extract_formats(True, True, True, True)
    PornerBrosIE._real_extract(True)

# Generated at 2022-06-22 07:34:51.885753
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert 'FourTubeBaseIE' in ie.IE_NAME

# Generated at 2022-06-22 07:35:00.251523
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    test_cases = [
        'https://www.porntube.com/videos/teen-couple-doing-anal_7089759',
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406',
        'https://www.porntube.com/embed/7089759',
        'https://m.porntube.com/videos/teen-couple-doing-anal_7089759'
    ]
    for url in test_cases:
        PornTubeIE()._real_extract(url)

# Generated at 2022-06-22 07:35:10.772863
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE.__bases__[0] is InfoExtractor
    assert FourTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert FourTubeIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FourTubeIE._TKN_HOST == 'token.4tube.com'