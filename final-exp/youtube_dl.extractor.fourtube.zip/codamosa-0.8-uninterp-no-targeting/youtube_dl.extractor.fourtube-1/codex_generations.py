

# Generated at 2022-06-22 07:26:59.017817
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE.__name__ == 'PornerBrosIE'

# Generated at 2022-06-22 07:27:01.805258
# Unit test for constructor of class FuxIE
def test_FuxIE():
   assert hasattr(FuxIE, '_TESTS')
   assert hasattr(FuxIE, 'IE_NAME')
   assert hasattr(FuxIE, '_VALID_URL')
   asser

# Generated at 2022-06-22 07:27:04.635332
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    p = PornTubeIE()
    assert p._TESTS[0].get('info_dict').get('title') == 'Teen couple doing anal'

# Generated at 2022-06-22 07:27:08.005102
# Unit test for constructor of class FuxIE
def test_FuxIE():
    test = FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert str(test) == 'fux.com'
    assert test._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'


# Generated at 2022-06-22 07:27:10.832893
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        FourTubeIE()
    except:
        print("Error: FourTubeIE()")
        raise


# Generated at 2022-06-22 07:27:14.899807
# Unit test for constructor of class FuxIE
def test_FuxIE():
    video = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    video_info = FuxIE()._real_extract(video)
    print(video_info)

# Generated at 2022-06-22 07:27:18.034959
# Unit test for constructor of class FuxIE
def test_FuxIE():
    m = re.match(FuxIE._VALID_URL, 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')
    assert m, "URL did not match"
    assert m.group('kind') == 'www', "kind was not 'www'"

# Generated at 2022-06-22 07:27:23.894649
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    baseIE = FourTubeBaseIE()
    assert(baseIE.IE_NAME == '4tube')
    assert(baseIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert(baseIE._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video')
    assert(baseIE._TKN_HOST == 'token.4tube.com')
    assert(len(baseIE._TESTS) > 0)

# Generated at 2022-06-22 07:27:26.851986
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Unit test for constructor of class PornerBrosIE
    class_ = PornerBrosIE
    ie = class_()
    assert ie
    

# Generated at 2022-06-22 07:27:37.510171
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE.suitable("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black");
    FourTubeIE.suitable("https://www.4tube.com/embed/209733");
    FourTubeIE.suitable("https://m.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black");
    FourTubeIE.suitable("https://www.4tube.com/videos/209733");


# Generated at 2022-06-22 07:27:53.806069
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:27:55.933069
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()._real_extract(
        'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406')

# Generated at 2022-06-22 07:27:59.221906
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    # Constructor of class PornerBrosIE
    try:
        PornerBrosIE('http://www.pornerbros.com/embed/181369')
    except:
        assert False, 'Constructor of class PornerBrosIE failed.'


# Generated at 2022-06-22 07:28:04.311716
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()

    # Check whether or not the constructor of class FuxIE is working
    assert ie.IE_NAME == 'fux'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:28:08.845968
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_extractor import GeneratorExtractor
    import pytest
    ie = PornerBrosIE()
    ge = GeneratorExtractor
    with pytest.raises(TypeError):
        ge(ie, 'http://www.foo.com')

# Generated at 2022-06-22 07:28:11.061499
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    x = PornerBrosIE()
    assert x is not None

# Generated at 2022-06-22 07:28:12.754900
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:28:14.838662
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE();
    assert(fux.ie_key() == 'Fux')

# Generated at 2022-06-22 07:28:21.596831
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369'
    mobj = re.match(FourTubeBaseIE._VALID_URL, url)
    assert mobj
    assert mobj.group('kind') == 'www'
    assert mobj.group('display_id') == 'skinny-brunette-takes-big-cock-down-her-anal-hole'
    assert mobj.group('id') == '181369'

# Generated at 2022-06-22 07:28:23.449273
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'



# Generated at 2022-06-22 07:28:56.982077
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie._download_webpage("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black", 209733)
    ie._extract_formats("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black", 209733, 1613, ["480", "720"])


# Generated at 2022-06-22 07:28:59.107417
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    f = FourTubeBaseIE()
    assert f.IE_NAME == '4tube'

# Generated at 2022-06-22 07:29:01.051807
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    FourTubeBaseIE.__init__(PornerBrosIE)



# Generated at 2022-06-22 07:29:09.365039
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.IE_NAME == '4tube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:29:16.400678
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    """
    Test for constructor of class FourTubeIE
    """
    fourTubeIE = FourTubeIE()
    assert fourTubeIE._TKN_HOST == 'token.4tube.com'
    assert fourTubeIE._TESTS[0]['url'] == 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'


# Generated at 2022-06-22 07:29:23.594181
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None, None)
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:29:33.632198
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    INIT_PARAMS = [
        'https://www.4tube.com/videos/221176/sunny-leone-and-sophia-santana-stripping-teasing-and-toying',
        '221176',
    ]
    from ..__init__ import _extractors
    fourTubeBase = _extractors[FourTubeBaseIE.ie_key()]()
    fourTubeBase(*INIT_PARAMS)

    INIT_PARAMS = [
        'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
        '181369',
    ]
    pornerBros = _extractors[PornerBrosIE.ie_key()]()
   

# Generated at 2022-06-22 07:29:35.814530
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-22 07:29:44.907712
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert obj._TKN_HOST == 'token.4tube.com'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-22 07:29:56.981557
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    m = FourTubeIE()
    assert m.IE_NAME == '4tube'
    assert m._VALID_URL == re.compile(r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?')
    assert m._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert m._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:31:17.039718
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    test_url = "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    instance = PornerBrosIE()
    instance.url = test_url
    if PornerBrosIE.IE_NAME != instance.ie_key():
        raise ValueError('This IE is not PornerBrosIE')
    if instance.name() != PornerBrosIE._TESTS[0]['info_dict']['title']:
        raise ValueError('Title doesn\'t match')
    if PornerBrosIE._VALID_URL != instance.valid_url():
        raise ValueError('Invalid url')
    if instance.working():
        raise ValueError('This is unworking IE')

# Generated at 2022-06-22 07:31:18.191196
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
	# Check that PornerBrosIE constructor works
	assert PornerBrosIE()

# Generated at 2022-06-22 07:31:28.763370
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Exercise test_FourTubeBaseIE

    from .common import InfoExtractor

    class MyInfoExtractor(InfoExtractor):
        IE_NAME = 'MyInfoExtractor'
        _VALID_URL = r'https?://(?:(?P<kind>www|m)\.)?myinfoextractor\.com/(?:videos|embed)/(?P<id>\d+)/(?P<display_id>[^/?#&]+)'
        _URL_TEMPLATE = 'https://www.myinfoextractor.com/videos/%s'
        _TKN_HOST = 'token.myinfoextractor.com'

    ie = MyInfoExtractor()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'MyInfoExtractor'
    assert ie._VALID_URL == r

# Generated at 2022-06-22 07:31:31.942199
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    try:
        class TestIE(FourTubeBaseIE):
            pass
    except Exception:
        pass

# Generated at 2022-06-22 07:31:33.672710
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:31:37.903322
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:31:40.253651
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    assert pornerbros.IE_NAME == 'PornerBros'



# Generated at 2022-06-22 07:31:43.588314
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    extractor = FourTubeIE()
    assert extractor._TKN_HOST == 'token.4tube.com'
    assert extractor._TESTS[0]['info_dict']['id'] == '209733'

# Generated at 2022-06-22 07:31:45.120805
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    instance = PornerBrosIE()
    assert instance is not None



# Generated at 2022-06-22 07:31:56.331293
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE.__name__ == 'PornTubeIE'
    assert PornTubeIE.__doc__ == FourTubeBaseIE.__doc__
    assert PornTubeIE.IE_NAME == 'PornTube'
    assert PornTubeIE.IE_DESC == 'PornTube'
    assert PornTubeIE._VALID_URL == PornTubeIE._VALID_URL
    assert PornTubeIE._URL_TEMPLATE == PornTubeIE._URL_TEMPLATE
    assert PornTubeIE._TKN_HOST == PornTubeIE._TKN_HOST
    assert PornTubeIE._TESTS == PornTubeIE._TESTS
    assert PornTubeIE._parse_formats == PornTubeIE._parse_formats
    assert PornTubeIE._extract_formats == PornTubeIE._extract_formats
    assert PornTube

# Generated at 2022-06-22 07:34:57.574215
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # Test title is set correctly
    title = 'Hot Babe Holly Michaels gets her ass stuffed by black'
    html = '''
    <meta property="og:title" content="%s">
    ''' % title
    obj = FourTubeIE()
    assert obj._html_search_meta('title', html) == title

    # Test timestamp is set correctly
    timestamp = 1383263892
    html = '''
    <meta property="og:video:release_date" content="%d">
    ''' % timestamp
    obj = FourTubeIE()
    assert obj._html_search_meta('uploadDate', html) == timestamp

    # Test upload timestamp is extracted correctly
    timestamp = 1383263892
    html = '''
    <meta property="og:video:release_date" content="%d">
    ''' % timestamp


# Generated at 2022-06-22 07:34:59.487623
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # As of now there is no test video for PornHubIE that does not require
    # a login to watch.
    pass

# Generated at 2022-06-22 07:35:06.170571
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test data format:
    #
    # Test list: [
    #     Test tuple: (fixture_file, expected_output)
    # ]
    #
    # Test tuple: (
    #     Arguments: [
    #         File name
    #     ],
    #     Expected object: object
    # )
    test_data = [
        (
            # Test arguments
            'test_data/test_PornTubeIE_constructor.json',
            # Expected object
            PornTubeIE
        )
    ]

    # Error message format
    error_message = '{0} {1}'


# Generated at 2022-06-22 07:35:12.660600
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    # class FourTubeBaseIE(InfoExtractor):
    dummy = 'http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black'
    instance_fourTubeIE = FourTubeIE(dummy)
    #print(inspect.getmembers(instance_fourTubeIE))
    #print(instance_fourTubeIE)
    #print(instance_fourTubeIE.params)
    #print(instance_fourTubeIE.params['skip_download'])
    #print(instance_fourTubeIE.params['skip_download'])
    #print(instance_fourTubeIE.params['format'])
    #print(instance_fourTubeIE.params['noplaylist'])
    #print(instance_fourTubeIE.params['n

# Generated at 2022-06-22 07:35:19.494422
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb = PornerBrosIE("http://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369")
    assert pb == "http://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"

# Generated at 2022-06-22 07:35:20.845811
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    assert instance.IE_NAME == 'porntube'

# Generated at 2022-06-22 07:35:27.304234
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    info_extractor = PornTubeIE()
    assert info_extractor._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert info_extractor._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert info_extractor._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:35:31.205792
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    (FourTubeIE()).extract('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')


# Generated at 2022-06-22 07:35:33.932329
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    ie2 = FourTubeBaseIE()

# Generated at 2022-06-22 07:35:42.864222
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
	x = FourTubeIE(None)
	assert x.IE_NAME == '4tube' 
	assert x._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
	assert x._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
	assert x._TKN_HOST == 'token.4tube.com'
	assert isinstance(x._TESTS, list)
