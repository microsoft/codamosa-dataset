

# Generated at 2022-06-22 07:26:54.747091
# Unit test for constructor of class FuxIE
def test_FuxIE():
	fux = FuxIE()
	assert fux.IE_NAME == "Fux"

# Generated at 2022-06-22 07:27:00.200454
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    video_ie = FourTubeIE(FourTubeIE.ie_key())
    assert isinstance(video_ie, FourTubeIE)
    assert video_ie.ie_key() == '4tube'




# Generated at 2022-06-22 07:27:10.215201
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from . import PornTubeIE
    pt = PornTubeIE()
    assert pt.IE_NAME == 'PornTube'
    assert pt.PORN_SITES == ['porntube']
    assert pt._VALID_URL == 'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert pt._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'

# Generated at 2022-06-22 07:27:16.722049
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    encounter = PornTubeIE()
    video = encounter._real_extract('https://www.porntube.com/videos/twerk-twerk-twerk-_1298915')

    assert video['id'] == '1298915'
    assert video['title'] == 'Twerk Twerk Twerk '
    assert video['uploader'] == 'SexyLips'
    assert video['uploader_id'] == '86771'
    assert video['view_count'] == int



# Generated at 2022-06-22 07:27:24.091276
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url='https://www.porntube.com/videos/double-anal-hot-latina-kimmy-granger-has-her-pussy-destroyed_1455511'
    video_id='1455511'
    display_id='double-anal-hot-latina-kimmy-granger-has-her-pussy-destroyed'
    mobj = re.match(PornTubeIE._VALID_URL, url)
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') == display_id

# Generated at 2022-06-22 07:27:34.870996
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE('https://www.porntube.com/videos/teen-couple-doing-anal_7089759')
    assert ie.IE_NAME == 'porntube'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert ie._TKN_HOST == 'tkn.porntube.com'

# Generated at 2022-06-22 07:27:36.760340
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    fourtube = FourTubeIE()

# Generated at 2022-06-22 07:27:46.755709
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:27:48.119325
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('https://www.porntube.com/embed/7089759')

# Generated at 2022-06-22 07:27:49.856369
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """Test for constructor of class FourTubeBaseIE."""
    ftbie = FourTubeBaseIE(object)
    assert ftbie is not None
    assert ftbie._VALID_URL is not None

# Generated at 2022-06-22 07:28:06.518848
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    video_id_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    b = ie._download_webpage(video_id_url, 'test_id')

# Generated at 2022-06-22 07:28:14.891502
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE({})
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:28:18.038089
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('http://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black')
    assert ie is not None

test_FourTubeIE()


# Generated at 2022-06-22 07:28:19.109158
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:28:31.440827
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    import requests
    import ResponseStub
    from ytdl_server.request_handlers import RequestHandler
    from ytdl_server.utils import JsonResponse, JsonRequest
    from ytdl_server.exceptions import RequestException

    url = "https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black"
    stub = ResponseStub.ResponseStub()
    with mock.patch('requests.get', stub) as mock_get:
        req = JsonRequest(url, '', 'get')
        ie = FourTubeBaseIE()

        # get_video_info should return expected JsonResponse
        res = ie.get_video_info(req)

# Generated at 2022-06-22 07:28:36.182362
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    test_input_url_1 = 'https://www.4tube.com/videos/2390/video'
    test_result_1 = FourTubeBaseIE._VALID_URL_RE.match(test_input_url_1)

    assert test_result_1 is not None


# Generated at 2022-06-22 07:28:36.806802
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:28:48.528972
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    """
    Test that
    """
    test_cases = (
        ('https://www.4tube.com/videos/318030/little-caprice-wants-to-feel-it', True),
        ('https://www.4tube.com/embed/318030', True),
        ('https://m.4tube.com/videos/318030/little-caprice-wants-to-feel-it', True),
        ('https://www.4tube.com/videos/notExists', False),
    )

    for url, expected in test_cases:
        try:
            FourTubeBaseIE()._real_extract(url)
            if not expected:
                raise AssertionError('"%s" should not be success' % url)
        except Exception as e:
            if expected:
                raise Ass

# Generated at 2022-06-22 07:28:53.041746
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    from .test_pornerbros import PornerBrosIE
    pornerbros_ie = PornerBrosIE()
    assert pornerbros_ie._VALID_URL is not None
    assert pornerbros_ie._TESTS is not None

# Generated at 2022-06-22 07:28:53.717597
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert 'FuxIE' in globals()

# Generated at 2022-06-22 07:29:10.450298
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    i = FourTubeIE()

# Generated at 2022-06-22 07:29:11.661717
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE('PornTube')

# Generated at 2022-06-22 07:29:16.641147
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE()
    assert isinstance(ie.IE_NAME, str)
    assert isinstance(ie.IE_DESC, str)
    assert ie.IE_NAME == '4tube'
    assert ie.IE_DESC == '4tube is a porn tube site'

# Generated at 2022-06-22 07:29:18.505722
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE().ie_key() == 'Fux'

# Generated at 2022-06-22 07:29:28.516878
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fuxIE = FuxIE()
    assert fuxIE
    assert fuxIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert fuxIE._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert fuxIE._TKN_HOST == 'token.fux.com'
    assert fuxIE._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-22 07:29:32.350163
# Unit test for constructor of class FuxIE
def test_FuxIE():
    fux = FuxIE()
    assert(fux.ie_key() == 'Fux')
    assert(fux.ie_name() == 'fux.com')


# Generated at 2022-06-22 07:29:37.575683
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE()._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'

# Generated at 2022-06-22 07:29:43.382288
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    p = PornerBrosIE()
    assert type(p) == PornerBrosIE
    # error if url cannot be matched
    url = 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole/'
    o = p._real_initialize()
    m = p._match_id(url)
    assert m is None

# Generated at 2022-06-22 07:29:45.862548
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert hasattr(ie, '_TESTS')


# Generated at 2022-06-22 07:29:48.327608
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE().IE_NAME == 'pornerbros'

# Generated at 2022-06-22 07:30:29.229049
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    m = FourTubeIE(None)
    assert m._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert m._TKN_HOST == 'token.4tube.com'
    assert m._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'


# Generated at 2022-06-22 07:30:30.851716
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    #with pytest.raises(RegexNotFoundError):
    from .. import FourTubeIE
    assert FourTubeIE

# Generated at 2022-06-22 07:30:39.083919
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE(): 
    obj = FourTubeBaseIE() 
    assert obj.IE_NAME == "4tube"
    assert obj._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert obj._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert obj._TKN_HOST == 'token.4tube.com'

# Generated at 2022-06-22 07:30:39.738009
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-22 07:30:45.248354
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert FourTubeIE()._TKN_HOST == 'token.4tube.com'
    assert FuxIE()._TKN_HOST == 'token.fux.com'
    assert PornTubeIE()._TKN_HOST == 'tkn.porntube.com'
    assert PornerBrosIE()._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:30:47.136329
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie.IE_NAME == "Fux"

# Generated at 2022-06-22 07:30:57.553698
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE(None)
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._TKN_HOST == 'token.4tube.com'
    title = 'Hot Babe Holly Michaels gets her ass stuffed by black'

# Generated at 2022-06-22 07:31:01.025176
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')


# Generated at 2022-06-22 07:31:03.603414
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()._real_extract('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')

# Generated at 2022-06-22 07:31:15.856836
# Unit test for constructor of class FuxIE

# Generated at 2022-06-22 07:31:58.843215
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:32:02.739370
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    instance = PornTubeIE()
    print(instance)
    print(instance._VALID_URL)
    print(instance._URL_TEMPLATE)
    print(instance._TKN_HOST)
    print(instance._TESTS)
    print(instance._real_extract)

# Generated at 2022-06-22 07:32:03.872088
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    print(FourTubeBaseIE())

# Generated at 2022-06-22 07:32:04.955808
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test for constructor
    PornTubeIE()

# Generated at 2022-06-22 07:32:06.461104
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    FourTubeIE().IE_NAME
# Test for constructor of class FuxIE

# Generated at 2022-06-22 07:32:08.650625
# Unit test for constructor of class FuxIE
def test_FuxIE():
    """Constructs FuxIE class object to test it.
    """
    FuxIE()

# Generated at 2022-06-22 07:32:10.035851
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE("https://www.fux.com/embed/195359")
    assert ie is not None

# Generated at 2022-06-22 07:32:15.848456
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    assert(FourTubeIE()._VALID_URL == FourTubeBaseIE._VALID_URL)
    assert(FourTubeIE()._URL_TEMPLATE == FourTubeBaseIE._URL_TEMPLATE)
    assert(FourTubeIE()._TKN_HOST == FourTubeBaseIE._TKN_HOST)
    assert(FourTubeIE()._TESTS == FourTubeBaseIE._TESTS)



# Generated at 2022-06-22 07:32:25.404039
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert re.match(PornerBrosIE._VALID_URL, 'https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert re.match(PornerBrosIE._VALID_URL, 'https://m.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369')
    assert re.match(PornerBrosIE._VALID_URL, 'https://www.pornerbros.com/embed/181369')

# Generated at 2022-06-22 07:32:25.984476
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:33:56.689079
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    ie = FourTubeIE('4tube')

# Generated at 2022-06-22 07:33:57.415769
# Unit test for constructor of class FuxIE
def test_FuxIE():
    pass

# Generated at 2022-06-22 07:34:04.778432
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert(PornerBrosIE.__name__ == 'PornerBrosIE')
    assert(PornerBrosIE._VALID_URL ==
           r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)')
    assert(PornerBrosIE._TKN_HOST == 'token.pornerbros.com')
    assert(PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s')

# Generated at 2022-06-22 07:34:13.231829
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?4tube\.com/(?:videos|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie.IE_NAME == '4tube'

# Generated at 2022-06-22 07:34:20.377164
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    url = 'https://www.porntube.com/videos/squirting-teen-ballerina-ecg_1331406'

    webpage = ie._download_webpage(url, 'test')
    video = ie._parse_json(ie._search_regex(
        r'INITIALSTATE\s*=\s*(["\'])(?P<value>(?:(?!\1).)+)\1',
        webpage, 'data', group='value'), '1331406',
        transform_source=lambda x: compat_urllib_parse_unquote(
            compat_b64decode(x).decode('utf-8')))['page']['video']
    
    title = video['title']
    assert title == 'Squirting Teen Ballerina on ECG'

#

# Generated at 2022-06-22 07:34:21.793747
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE()

# Generated at 2022-06-22 07:34:31.118666
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    from .. import PornTubeIE

    assert PornTubeIE.IE_NAME == 'porntube'
    assert PornTubeIE.IE_DESC == 'Porntube'
    assert PornTubeIE._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?porntube\\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\\d+)'
    assert PornTubeIE._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'

# Generated at 2022-06-22 07:34:31.900166
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ex = PornTubeIE()
    print(ex)

# Generated at 2022-06-22 07:34:40.264700
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE({})
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?pornerbros\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert ie._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'
    assert ie._TKN_HOST == 'token.pornerbros.com'

# Generated at 2022-06-22 07:34:49.471091
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE(None, None)._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'
    assert FuxIE(None, None)._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'
    assert PornTubeIE(None, None)._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornerBrosIE(None, None)._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'