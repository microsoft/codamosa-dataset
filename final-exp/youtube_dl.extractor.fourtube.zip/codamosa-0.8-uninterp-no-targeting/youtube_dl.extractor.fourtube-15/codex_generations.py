

# Generated at 2022-06-22 07:27:05.034022
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornTubeIE._TKN_HOST == 'tkn.porntube.com'
    assert PornTubeIE._URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert PornTubeIE._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornerBrosIE._TKN_HOST == 'token.pornerbros.com'
    assert PornerBrosIE._URL_TEMPLATE == 'https://www.pornerbros.com/videos/video_%s'

# Generated at 2022-06-22 07:27:08.245973
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    base = FourTubeBaseIE()
    assert base._VALID_URL == r''
    assert base._URL_TEMPLATE == ''
    assert base._TKN_HOST == ''

# Generated at 2022-06-22 07:27:10.150574
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        PornTubeIE()
    except:
        assert False

# Generated at 2022-06-22 07:27:12.322025
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    inst = FourTubeBaseIE.__new__(FourTubeBaseIE)
    print(inst)

# Generated at 2022-06-22 07:27:15.552306
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TESTS[0]['url'] == 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

# Generated at 2022-06-22 07:27:16.648189
# Unit test for constructor of class FuxIE
def test_FuxIE():
    from . import YoutubeIE
    ie = YoutubeIE()
    ie = FuxIE()

# Generated at 2022-06-22 07:27:17.318151
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-22 07:27:17.973159
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE

# Generated at 2022-06-22 07:27:21.170273
# Unit test for constructor of class FuxIE
def test_FuxIE():
   # Test with a URL from www.fux.com
    url = "https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow"
    FuxIE(FuxIE.extract_urls(url))


# Generated at 2022-06-22 07:27:32.503236
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Test constructor with a valid pornhub video link
    video_url = 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    i = PornTubeIE(video_url)
    assert i.url == video_url

    # Test constructor with a PornTube embed url
    embed_url = 'https://www.porntube.com/embed/7089759'
    i = PornTubeIE(embed_url)
    assert i.url == embed_url

    # Test constructor with a url of a different domain
    url = 'https://www.youtube.com/watch?v=BmAF1R_Mf_U'
    invalid_url_ok = False
    try:
        i = PornTubeIE(url)
    except ValueError as e:
        assert e.args

# Generated at 2022-06-22 07:27:50.545549
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    assert ie._VALID_URL == PornTubeIE._VALID_URL
    assert ie._URL_TEMPLATE == PornTubeIE._URL_TEMPLATE
    assert ie._TKN_HOST == PornTubeIE._TKN_HOST

# Generated at 2022-06-22 07:27:51.783116
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert hasattr(ie, '_extract_formats')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-22 07:27:57.787292
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    P1 = PornTubeIE()
    assert P1.IE_NAME == 'PornTube'
    assert P1.VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert P1.URL_TEMPLATE == 'https://www.porntube.com/videos/video_%s'
    assert P1.TKN_HOST == 'tkn.porntube.com'


# Generated at 2022-06-22 07:28:03.040953
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    assert PornTubeIE._VALID_URL.pattern == r'https?://(?:(?P<kind>www|m)\.)?porntube\.com/(?:videos/(?P<display_id>[^/]+)_|embed/)(?P<id>\d+)'
    assert PornTubeIE._TESTS[0]['url'] == 'https://www.porntube.com/videos/teen-couple-doing-anal_7089759'
    assert PornTubeIE._TESTS[0]['info_dict']['id'] == '7089759'
    assert PornTubeIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert PornTubeIE._TESTS[0]['info_dict']['duration'] == 5052
    assert PornTubeIE._TES

# Generated at 2022-06-22 07:28:04.932383
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    PornerBrosIE(None)

# Generated at 2022-06-22 07:28:17.022070
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    try:
        from ydl_x.extractor import FourTubeIE
    except ImportError:
        print("Downgrade to legacy FourTubeIE")
        from ydl_test.test_legacy.extractor import FourTubeIE

    ydl = FourTubeIE()
    info = ydl.extract("https://www.4tube.com/videos/209733/hot-babe-holly-michaels-gets-her-ass-stuffed-by-black")
    assert info["id"] == "209733"
    assert info["title"] == "Hot Babe Holly Michaels gets her ass stuffed by black"
    assert info["upload_date"] == '20131031'
    assert info["timestamp"] == 1383263892
    assert info["uploader"] == "WCP Club"

# Generated at 2022-06-22 07:28:28.771133
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    url = "https://www.porntube.com/videos/teen-couple-doing-anal_7089759"
    obj = PornTubeIE()
    # Verify that the object is an instance of class PornTubeIE
    assert isinstance(obj, PornTubeIE)
    # Assert that it's the right class
    assert isinstance(obj, PornTubeIE)
    # Assert that it's a subclass of the right class
    assert issubclass(obj.__class__, PornTubeIE)
    # Verify that the object has the right video ID
    assert obj.video_id == '7089759'
    # Verify that the object has the right display ID
    assert obj.display_id == '7089759'
    # Verify that the object has the right video title
    assert obj.video_title == 'Teen couple doing anal'



# Generated at 2022-06-22 07:28:31.488057
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ins = FuxIE()
    assert ins is not None


# Generated at 2022-06-22 07:28:38.256805
# Unit test for constructor of class FuxIE
def test_FuxIE():
    '''
    This function is a test function for the class FuxIE.

    :return: nothing
    '''
    fuxIE = FuxIE()
    print("test_FuxIE(): The url is " + fuxIE._VALID_URL)
    print("test_FuxIE(): The template is " + fuxIE._URL_TEMPLATE)
    print("test_FuxIE(): The token host is " + fuxIE._TKN_HOST)

# Generated at 2022-06-22 07:28:38.933183
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE()

# Generated at 2022-06-22 07:29:15.414616
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    info = FourTubeBaseIE()._extract_formats('https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369',
                                             '181369', '181369', ['720'])
    print(info)

# Generated at 2022-06-22 07:29:20.109875
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    for test_obj in (
        FourTubeIE(),
        FuxIE(),
        PornerBrosIE(),
        PornTubeIE(),
    ):
        assert test_obj._VALID_URL
        assert test_obj._URL_TEMPLATE
        assert test_obj._TKN_HOST

# Generated at 2022-06-22 07:29:22.024100
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # test original constructor
    PornTubeIE()
    # test partial application
    FourTubeBaseIE()

# Generated at 2022-06-22 07:29:26.219260
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    ie = PornTubeIE()
    ie.extract(url='https://www.porntube.com/embed/7089759')

# Generated at 2022-06-22 07:29:27.946771
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie.__class__.__name__ == 'FourTubeBaseIE'

# Generated at 2022-06-22 07:29:31.232920
# Unit test for constructor of class FuxIE
def test_FuxIE():
    FuxIE('https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow')


# Generated at 2022-06-22 07:29:36.948535
# Unit test for constructor of class FuxIE
def test_FuxIE():
    unit_test = FuxIE()
    assert unit_test._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:29:44.751421
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    try:
        from .common import testcase
    except ImportError:
        import unittest as testcase
    obj = PornTubeIE()
    for test in obj._TESTS:
        obj._downloader.params.update(test.get('params', {}))
        try:
            obj.extract(test['url'])
        except testcase.TestCase.failureException as e:
            if test.get('skip'):
                raise testcase.TestCase.skipTest(e.__str__())
            else:
                raise testcase.TestCase.failureException(e.__str__())

# Generated at 2022-06-22 07:29:45.511268
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    FourTubeBaseIE()

# Generated at 2022-06-22 07:29:49.159066
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pornerbros = PornerBrosIE()
    assert pornerbros.IE_NAME == 'pornerbros'



# Generated at 2022-06-22 07:31:06.507668
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    pb = PornerBrosIE()

# Generated at 2022-06-22 07:31:09.328648
# Unit test for constructor of class FuxIE
def test_FuxIE():
    url = 'https://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'
    class_fuxIE = FuxIE(url)


# Generated at 2022-06-22 07:31:20.714729
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    # Invalid data
    with pytest.raises(ValueError):
        PornTubeIE()._parse_json('', '')
    with pytest.raises(ExtractorError):
        PornTubeIE()._parse_json('["abc"]', '')

    # Invalid json data
    with pytest.raises(ExtractorError):
        PornTubeIE()._parse_json('{', '')
    # Missing required keys
    with pytest.raises(ExtractorError):
        PornTubeIE()._parse_json('{"key":"value"}', '')
    # Invalid type
    with pytest.raises(ExtractorError):
        PornTubeIE()._parse_json('{"page":{}}', '')
    # Invalid type

# Generated at 2022-06-22 07:31:21.774309
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    assert PornerBrosIE() is not None

# Generated at 2022-06-22 07:31:23.770479
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE(FuxIE._downloader)._TKN_HOST == 'token.fux.com'

# Generated at 2022-06-22 07:31:26.782225
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    i = PornTubeIE._create_instance("https://www.porntube.com/videos/teen-couple-doing-anal_7089759")
    assert type(i) is PornTubeIE

# Generated at 2022-06-22 07:31:32.499218
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    assert FourTubeBaseIE()._VALID_URL == 'https?://(?:(?P<kind>www|m)\\.)?4tube\\.com/(?:videos|embed)/(?P<id>\\d+)(?:/(?P<display_id>[^/?#&]+))?'

# Generated at 2022-06-22 07:31:40.404650
# Unit test for constructor of class FuxIE
def test_FuxIE():
    ie = FuxIE()
    assert ie._TKN_HOST == 'token.fux.com'
    assert ie._VALID_URL == r'https?://(?:(?P<kind>www|m)\.)?fux\.com/(?:video|embed)/(?P<id>\d+)(?:/(?P<display_id>[^/?#&]+))?'
    assert ie._URL_TEMPLATE == 'https://www.fux.com/video/%s/video'

# Generated at 2022-06-22 07:31:48.758029
# Unit test for constructor of class FourTubeIE

# Generated at 2022-06-22 07:31:56.737073
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    """PornerBrosIE construction test"""
    # test URL constructor
    ie = PornerBrosIE()
    assert_true(isinstance(ie, InfoExtractor))
    assert_equal(ie.ie_key(), 'PornerBros')
    assert_equal(ie.suitable(PornerBrosIE._URL_TEMPLATE % 1), True)
    # test video creation
    video = ie.extract(PornerBrosIE._URL_TEMPLATE % 1)
    assert_true(isinstance(video, dict))
    assert_equal(video['id'], '1')


# Generated at 2022-06-22 07:35:06.137053
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE()

# Generated at 2022-06-22 07:35:12.615455
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE()
    assert ie._TESTS[0]["url"] == "https://www.pornerbros.com/videos/skinny-brunette-takes-big-cock-down-her-anal-hole_181369"
    assert ie._TESTS[0]["md5"] == "6516c8ac63b03de06bc8eac14362db4f"
    assert ie._TESTS[0]["info_dict"]["id"] == "181369"
    assert ie._TESTS[0]["info_dict"]["ext"] == "mp4"
    assert ie._TESTS[0]["info_dict"]["title"] == "Skinny brunette takes big cock down her anal hole"

# Generated at 2022-06-22 07:35:18.340310
# Unit test for constructor of class FuxIE
def test_FuxIE():
    print('Testing FuxIE')

    url = 'http://www.fux.com/video/195359/awesome-fucking-kitchen-ends-cum-swallow'

    ie = FuxIE(url)

    assert ie.isValid() == True


# Generated at 2022-06-22 07:35:19.727856
# Unit test for constructor of class PornerBrosIE
def test_PornerBrosIE():
    ie = PornerBrosIE();
    assert(ie.IE_NAME == 'PornerBros')

# Generated at 2022-06-22 07:35:20.750403
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    obj = FourTubeIE()
    assert obj is not None

# Generated at 2022-06-22 07:35:21.566351
# Unit test for constructor of class FuxIE
def test_FuxIE():
    assert FuxIE is not None


# Generated at 2022-06-22 07:35:23.576965
# Unit test for constructor of class PornTubeIE
def test_PornTubeIE():
    PornTubeIE({})._download_webpage('https://www.porntube.com/', 'test_id')

# Generated at 2022-06-22 07:35:26.875463
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    ie = FourTubeBaseIE()
    assert ie._TKN_HOST == 'token.4tube.com'
    assert ie._URL_TEMPLATE == 'https://www.4tube.com/videos/%s/video'

# Generated at 2022-06-22 07:35:27.689712
# Unit test for constructor of class FourTubeIE
def test_FourTubeIE():
    format = FourTubeIE()
    print(format)

# Generated at 2022-06-22 07:35:33.069915
# Unit test for constructor of class FourTubeBaseIE
def test_FourTubeBaseIE():
    # Constructor without arguments
    try:
        ie = FourTubeBaseIE()
    except Exception:
        assert False
    # __init__ calls _TESTS and _TESTS doesn't exist
    try:
        ie = FourTubeBaseIE(None)
    except Exception:
        assert False


if __name__ == '__main__':
    test_FourTubeBaseIE()