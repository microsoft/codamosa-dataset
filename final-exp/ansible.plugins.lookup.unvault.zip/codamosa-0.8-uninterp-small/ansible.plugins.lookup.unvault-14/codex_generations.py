

# Generated at 2022-06-25 11:27:17.960360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:27:24.874711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupBase()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    kwargs_0['unsafe'] = True
    kwargs_0['wantlist'] = False
    kwargs_0['no_log'] = True
    lookup_module_run_0.set_options(var_options=variables_0, direct=kwargs_0)
    lookup_module_run_1 = LookupBase()
    terms_1 = []
    variables_1 = {}
    kwargs_1 = {}
    kwargs_1['unsafe'] = True
    kwargs_1['wantlist'] = False
    kwargs_1['no_log'] = True

# Generated at 2022-06-25 11:27:30.782985
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test with
    # find_file_in_search_path
    # get_real_file

    # Test with fake
    # find_file_in_search_path
    # get_real_file

    # Test with
    # get_real_file

# Generated at 2022-06-25 11:27:34.731857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert lookup_module_run.run(terms=["""f'oo\'o.txt"""]) == [u'f"oo\\\'o']

# Generated at 2022-06-25 11:27:36.203085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    obj.run([])
    obj.run()


# Generated at 2022-06-25 11:27:39.624719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = dict()
    ret = lookup_module_0.run(terms_0, variables_0)
    assert not isinstance(ret, Exception)

# Generated at 2022-06-25 11:27:46.369563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # success case
    lookup_module._loader.get_real_file = lambda x, y: '/file/path'
    lookup_module.find_file_in_search_path = lambda x, y, z: '/file/path'
    terms = ['/file/path']
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)

    # error case
    lookup_module._loader.get_real_file = lambda x, y: None
    lookup_module.find_file_in_search_path = lambda x, y, z: None
    terms = ['/file/path']
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)   


# Generated at 2022-06-25 11:27:49.917501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variable_0 = {}
    result_0 = lookup_module_0.run(terms_0, variable_0)
    assert result_0 is not None

# Test for method set_options of class LookupModule

# Generated at 2022-06-25 11:27:53.634551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    assert True

# Generated at 2022-06-25 11:28:02.044831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=['lab_config_no_vault.yaml'], __at_path='/home/automate-spirent/PycharmProjects/lookup_plugins') == [u'name: bar\nansible_facts:\n  log_level: info\n  log_path: \'/tmp/run.log\'\n\n']



# Generated at 2022-06-25 11:28:08.504150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term_0 = "term0"
    term_0 = "term1"
    terms_0 = [term_0, term_0]
    dict_0 = {}
    var_0 = lookup_run(*terms_0, **dict_0)

    term_1 = "term1"
    term_1 = "term2"
    terms_1 = [term_1, term_1]
    dict_1 = {}
    var_1 = lookup_run(*terms_1, **dict_1)

# Generated at 2022-06-25 11:28:16.124577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["/etc/ansible/facts.d/", "/etc/ansible/facts.d/facts.fact"], None)
    assert (var_0 == ["#!/bin/bash\nset +e\ncommand_0", "command_1\ncommand_2\ncommand_3\n\ncommand_4\ncommand_5\ncommand_6\n\n", "\nset -e\n\ncommand_7\ncommand_8\n", "\n\ncommand_9\n\ncommand_10\ncommand_11\ncommand_12\ncommand_13\n\ncommand_14\n"], "var_0")

# Generated at 2022-06-25 11:28:22.164851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'lookupfile'
    bytes_0 = lookup_module_0.find_file_in_search_path(str_0)
    str_1 = '/etc/foo.txt'
    dict_0 = {'a': str_1}
    var_0 = lookup_run(bytes_0, **dict_0)


# Generated at 2022-06-25 11:28:23.342356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:28:26.670748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_expected = ['foo']
    kwargs_expected = {}
    actual_result = LookupModule().run(args_expected, **kwargs_expected)


# Generated at 2022-06-25 11:28:33.105564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  file_2 = None
  terms_0 = [file_2]
  dict_0 = {}
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(terms_0, **dict_0)
  assert len(var_0) == 0


# Generated at 2022-06-25 11:28:41.398012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run(terms=['/etc/ansible/hosts'])
    assert to_text(ret[0]).startswith('[unvaulted_hosts]\nlocalhost')

    ret = lookup.run(terms=['/etc/ansible/hosts', '/etc/ansible/hosts'])
    assert to_text(ret[0]).startswith('[unvaulted_hosts]\nlocalhost')
    assert to_text(ret[1]).startswith('[unvaulted_hosts]\nlocalhost')

# Generated at 2022-06-25 11:28:46.452780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = str()
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, **dict_0)
    print(str(var_0))

# Generated at 2022-06-25 11:28:48.007333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_module = LookupModule()
    assert isinstance(l_module.run(terms=[], variables=None, **{}), list)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:49.932060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bytes_0, **dict_0)

# Generated at 2022-06-25 11:28:57.655670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'foo'
    variables = {}

    lookup_module = LookupModule()
    results = lookup_module.run(terms, variables)



# Generated at 2022-06-25 11:29:00.072624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(bytes_0, **dict_0)

# Generated at 2022-06-25 11:29:10.426175
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:29:12.432782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'Default value'
    variables = 'Default value'
    lookup_module0 = LookupModule()
    ret = lookup_module0.run(terms, variables)
    assert ret == []

# Generated at 2022-06-25 11:29:20.481552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options(var_options=None, direct=None)
    lookup_module_3 = LookupModule()
    lookup_module_3.set_options(var_options=None, direct=None)


# Generated at 2022-06-25 11:29:25.202615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = None
    bytes_1 = None
    lookup_module_0.run(bytes_0, bytes_1)



# Generated at 2022-06-25 11:29:27.280746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run(None, **None)


# run tests if import as module
if __name__ == '__main__':
    import sys
    test_LookupModule_run()
    sys.exit(0)

# Generated at 2022-06-25 11:29:28.833084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 0
    #
    # 
    # 
    # 
    # 
    # 
    # 
    test_case_0()


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:36.640857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    _ansible_module_post_templar_0 = AnsibleModule(argument_spec={})
    list_0 = []
    param_0 = 'lookup'
    actual_value_0 = _ansible_module_post_templar_0._lookup_plugin_loader(param_0)
    actual_value_1 = _ansible_module_post_templar_0._create_content_tempfile(list_0)
    assert callable(actual_value_0)
    assert callable(actual_value_1)
    lookup_module_1 = LookupModule()
    _ansible_module_post_templar_1 = AnsibleModule(argument_spec={})
    actual_value_2 = _ansible_module_post_templar

# Generated at 2022-06-25 11:29:42.807891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('/home/vagrant/ansible/lib/ansible/plugins/lookup/unvault.py', '/home/vagrant/ansible/lib/ansible/plugins/lookup/unvault.py')
    assert isinstance(var_0, list)
    assert len(var_0) == 1
    assert isinstance(var_0[0], to_text)

# Unitary Test of test_LookupModule_run

# Generated at 2022-06-25 11:29:56.870092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    lookup_result_0 = lookup_module_0.run(terms_0)
    print(lookup_result_0)


#Unit test stub

# Generated at 2022-06-25 11:30:00.576907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    bytes_0 = None
    dict_0 = {}
    lookup_module_0.run(bytes_0, **dict_0)



# Generated at 2022-06-25 11:30:11.201882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, **dict_0)

if __name__ == "__main__":
    assert test_LookupModule_run() == None



# some examples from ansible-doc

# Generated at 2022-06-25 11:30:16.366924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = None
    dict_0 = {}
    var_0 = lookup_module_0.run(bytes_0, **dict_0)

# Generated at 2022-06-25 11:30:20.704722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = None
    dict_0 = {}
    lookup_module_0.run(bytes_0, **dict_0)



# Generated at 2022-06-25 11:30:28.887674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = []
    kwargs = {"variables": {"list_0": ["UNIT_TESTING/foo", "foo", "bar"]}, "terms": "UNIT_TESTING/foo"}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(*args, **kwargs)
    assert var_0 == ['baz']
    kwargs = {"variables": {"list_0": ["foo", "foo", "bar"]}, "terms": "foo"}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(*args, **kwargs)
    assert var_0 == ['baz']
    kwargs = {"variables": {"list_0": ["foo", "foo", "bar"]}, "terms": "bar"}
   

# Generated at 2022-06-25 11:30:33.437435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  bytes_0 = None
  var_0 = lookup_module_0.run(bytes_0)


# Generated at 2022-06-25 11:30:41.074708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "/etc/foo.txt"
    variables = {}

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()

    assert lookup_module_0.run(terms, variables) == lookup_module_1.run(terms, variables) == lookup_module_2.run(terms, variables) == lookup_module_3.run(terms, variables) == lookup_module_4.run(terms, variables) == lookup_module_5.run(terms, variables)

# Generated at 2022-06-25 11:30:45.885639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    0 # lookups/unvault.py:101,18 in run
    lookup_loader_0 = lookup_module_0._loader
    lookup_loader_0.add_directory('./foo/bar')
    dict_0 = {'path': 'foo/bar.txt'}
    lookup_loader_0.set_basedir(**dict_0)
    lookup_loader_0.set_basedir('./foo/bar')

    1 # lookups/unvault.py:104,18 in run
    actual_file = lookup_loader_0.get_real_file('./foo/bar/baz.txt', decrypt=True)
    with open(actual_file, 'rb') as f:
        b_contents = f.read()


# Generated at 2022-06-25 11:30:50.171475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    unvault_test_0 = 'test/unvault_test.yaml'
    terms_0 = [unvault_test_0]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:31:10.717371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0 = None
    var_0 = lookup_module_0.run(var_0, **var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:31:13.011051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    dict_0 = {}
    result = lookup_module_0.run(terms_0, **dict_0)


# Generated at 2022-06-25 11:31:19.960368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare needed objects
    lookup_module_0 = LookupModule()
    lookup_module_0._set_options = _set_options
    lookup_module_0.run = run
    lookup_module_0.find_file_in_search_path = find_file_in_search_path
    lookup_module_0._loader = _loader
    lookup_module_0._display = _display
    _display.debug = debug
    _display.vvvv = vvvv



# Generated at 2022-06-25 11:31:25.857816
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_file = 'test_content.txt'
    test_content = 'bar'
    with open(test_file, 'w') as f:
        f.write(test_content)

    lookup_terms = [test_file]
    lookup_module = LookupModule()
    lookup_result = lookup_module.run(lookup_terms)

    assert len(lookup_result) == 1

    assert test_content in lookup_result[0]

    os.remove(test_file)

# Generated at 2022-06-25 11:31:34.176423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = None
    dict_0 = {}

# Generated at 2022-06-25 11:31:35.943895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = None
    dict_0 = {}
    assert lookup_module_0.run(bytes_0, **dict_0) == []

# Generated at 2022-06-25 11:31:37.660614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "/etc/hosts"
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms)
    print(var_1)

# Generated at 2022-06-25 11:31:40.192634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0
    lookup_module_0 = var_0
    with pytest.raises(AnsibleParserError):
        var_0.run(bytes_0, **dict_0)

# Generated at 2022-06-25 11:31:49.149070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(dict_0)
    lookup_module_0.set_templar(dict_0)
    lookup_module_0.set_basedir(str_0)
    lookup_module_0.set_collection_list(list_0)
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0._collections = None
    lookup_module_0.file_found_in_search_path(str_0)

# Generated at 2022-06-25 11:31:51.115580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_1 = None
    dict_1 = {}
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(bytes_1, **dict_1)


# Generated at 2022-06-25 11:32:26.968157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        var_0 = lookup_run(bytes_0, **dict_0)


# Generated at 2022-06-25 11:32:30.201860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = None
    kwargs_0 = {}
    list_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert list_0 == []


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:32:32.959597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  term_0 = 'foo.txt'
  if lookup_module_0.run(term_0):
    pass

# Generated at 2022-06-25 11:32:36.256336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with 'bytes' term type
    kwargs_0 = {'variables': None}
    var_0 = lookup_module_0.run(bytes(), **kwargs_0)
    assert var_0 == []

    # Test with 'terms' term type
    kwargs_1 = {'variables': None}
    var_1 = lookup_module_0.run(list(), **kwargs_1)
    assert var_1 == []


# Generated at 2022-06-25 11:32:48.181198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = None
    dict_0 = {}
    var_0 = lookup_module_0.run(bytes_0, **dict_0)
    assert type(var_0) == list
    assert var_0 == []
    bytes_0 = bytes(47)
    var_0 = lookup_module_0.run(bytes_0, **dict_0)
    assert var_0 is None
    bytes_0 = bytes(52)
    var_0 = lookup_module_0.run(bytes_0, **dict_0)
    assert var_0 is None
    bytes_0 = None
    var_0 = lookup_module_0.run(bytes_0, **dict_0)
    assert var_0 is None # Unreachable
    bytes_0 = None


# Generated at 2022-06-25 11:32:54.693109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, **dict_0)

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 11:32:55.872938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert None


# Generated at 2022-06-25 11:33:00.449501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = None
    var_0 = dict()
    terms_1 = var_0
    var_1 = var_0
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(terms_1, **var_1)
    var_3 = lookup_run(var_2, **var_1)

# Generated at 2022-06-25 11:33:09.895376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    find_file_in_search_path_0 = Mock(return_value='/etc/hosts')
    ansible_loader = AnsibleLoader()
    lookup_module_0 = LookupModule()

    get_real_file_0 = MagicMock(return_value='/etc/hosts')
    ansible_loader.get_real_file = get_real_file_0
    read_0 = MagicMock(return_value="")
    open_0 = MagicMock(return_value=Mock(read=read_0))
    lookup_module_0._loader = ansible_loader
    lookup_module_0.find_file_in_search_path = find_file_in_search_path_0
    lookup_module_0.open = open_0

# Generated at 2022-06-25 11:33:14.196451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({u'cartridge_version': u'3.11', u'_ansible_baseline_ignore': True, u'_ansible_no_log': False, u'_ansible_verbosity': 4, u'_checksum_rebuild': True})
    lookup_module_0.run([u'foo.txt'])
# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 11:34:41.622425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data0 = 'String'
    data1 = {'key1': 'value1'}
    data2 = False
    data3 = (1, 2, 3)

    # data0 and data2 should fail because they're not of type list
    with pytest.raises(TypeError):
        LookupModule().run(data0, data1, data2)
    with pytest.raises(TypeError):
        LookupModule().run(data2, data1, data0)
    with pytest.raises(TypeError):
        LookupModule().run(data2, data0, data2)

    # data3 should fail because it's not of type list of str
    with pytest.raises(TypeError):
        LookupModule().run(data3, data1, data0)


    # data1 should fail because it

# Generated at 2022-06-25 11:34:45.524593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = dict()
    var_1 = dict()
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = 'list'
    var_3 = lookup_module_0.run(var_2)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:34:47.589243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_0 = lookup_run()

    # Concatenate the output to the return value
    var_0 = lookup_instance_0.run(terms, variables)
    var_0 = var_0 + lookup_instance_0
    return var_0



# Generated at 2022-06-25 11:34:50.899749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Place your unit test here



# Generated at 2022-06-25 11:34:52.427050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 11:34:58.061732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    variables_0 = None
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert (var_0 == [])


# Generated at 2022-06-25 11:35:00.406958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_1 = None
    kwargs_2 = {}
    var_0 = lookup_run(terms_0, variables_1, **kwargs_2)
    assert var_0 == None

# Generated at 2022-06-25 11:35:01.711393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if (not isinstance(lookup_module_0, LookupModule)):
        assert isinstance(lookup_module_0, LookupModule)

# Generated at 2022-06-25 11:35:03.839992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(terms, variables)
    return var_0

# Generated at 2022-06-25 11:35:09.877229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, **dict_0)