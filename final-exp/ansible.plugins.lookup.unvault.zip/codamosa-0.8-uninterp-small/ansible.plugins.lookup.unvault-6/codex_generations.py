

# Generated at 2022-06-25 11:27:21.177258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # File not found
    lookup_module = LookupModule()
    terms = ['bar.txt']
    variables = {}
    display.debug("LookupModule test case 1")
    try:
        lookup_module.run(terms, variables)
    except AnsibleParserError as e:
        assert str(e) == 'Unable to find file matching "bar.txt" '
    else:
        assert False

    # File found
    lookup_module = LookupModule()
    terms = ['test_file.txt']
    variables = {}
    display.debug("LookupModule test case 2")
    assert lookup_module.run(terms, variables) == ['foo\n']

# Generated at 2022-06-25 11:27:23.676048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
#    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:27:29.655312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['/etc/foo.txt'], {}, {}) == [u"Hi there\n"]
    assert lookup_module_0.run(['/nonexistent'], {}, {}) == []
    assert lookup_module_0.run(['/etc/nonexistent.conf'], {}, {}) == []

# Generated at 2022-06-25 11:27:35.555126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/etc/foo.txt']
    variables_1 = None
    expected_1 = "foo"
    actual_1 = lookup_module_1.run(terms_1, variables_1)
    assert expected_1 == actual_1

# Generated at 2022-06-25 11:27:43.860035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = 'test.txt'
    variables_1 = dict()
    ret = lookup_module_1.run(terms_1, variables_1)
    assert ret == ['test_test.txt']
    terms_2 = 'test.txt'
    variables_2 = dict()
    ret = lookup_module_1.run(terms_2, variables_2)
    assert ret == ['test_test.txt']
    terms_3 = 'test.txt'
    variables_3 = dict()
    ret = lookup_module_1.run(terms_3, variables_3)
    assert ret == ['test_test.txt']
    terms_4 = 'test.txt'
    variables_4 = dict()

# Generated at 2022-06-25 11:27:47.165815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run(self=None, terms=None, variables=None, **kwargs)
    assert ret == None

# Generated at 2022-06-25 11:27:49.029166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   #Invoke method with arguments
   lookup_module_1 = LookupModule()
   lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 11:27:55.006804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [u'/etc/foo.txt']
    variables = {}
    kwargs = {}
    __ret = lookup_module_1.run(terms, variables, **kwargs)
    # Check the return value
    assert __ret is not None



# Generated at 2022-06-25 11:28:01.849335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Invalid inputs
    with pytest.raises(AnsibleParserError):
        lookup_module_0.run("")
    with pytest.raises(AnsibleParserError):
        lookup_module_0.run("/asd", [])
    with pytest.raises(AnsibleParserError):
        lookup_module_0.run("", [])

# Generated at 2022-06-25 11:28:09.757158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # args for test case
    terms_0 = []

    # expected return from the lookup_module_0.run()
    expected_ret_0 = []

    # mock settings for lookup_module_0.run()
    lookup_module_0.set_options = mock.Mock()
    lookup_module_0.find_file_in_search_path = mock.Mock()
    lookup_module_0._loader.get_real_file = mock.Mock()
    open = mock.mock_open(read_data='read_data')

# Generated at 2022-06-25 11:28:14.169720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    terms = ('/etc/foo.txt',)
    lookup_module_0.run(terms, decrypt=True)

# Generated at 2022-06-25 11:28:22.272801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.errors
    import ansible.utils.display
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    terms_0 = ['/etc/foo.txt']
    variables_0 = None
    kwargs_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except ansible.errors.AnsibleParserError as e_0:
        assert 'Unable to find file matching "/etc/foo.txt"' == str(e_0)

# Generated at 2022-06-25 11:28:28.734276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["/etc/hosts"]
    variables = None
    kwargs = None
    result = len(lookup_module.run(terms, variables, **kwargs))
    assert result > 0

# Generated at 2022-06-25 11:28:30.588242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()

# Generated at 2022-06-25 11:28:39.780181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:28:45.582496
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert 'return_value' == lookup_module.run(["/tmp/ansible/test/plugin/test_plugin_loader.py"])

# Generated at 2022-06-25 11:28:52.715710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()

    terms = 'tests/files/vault/vault_unvault.yml'


# Generated at 2022-06-25 11:29:01.390606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    lookup_module_0 = LookupModule()
    lookup_module_0._display = Display()
    lookup_module_0._loader = None

    # Test 1: term = /etc/foo.txt
    terms = ["/etc/foo.txt"]

    # Test 1.1: file exists
    file_exists = True
    lookup_module_0._loader = Mock_module_loader(file_exists)

    lookup_module_0._display.debug("Unvault lookup term: %s" % terms)

    # Find the file in the expected search path
    lookupfile = lookup_module_0.find_file_in_search_path(None, 'files', terms[0])
    lookup_module_0._display.vvvv(u"Unvault lookup found %s" % lookupfile)

# Generated at 2022-06-25 11:29:05.648471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    out = lookup_module.run(['/etc/hosts'])
    assert out[0].startswith('127.0.0.1')


# Generated at 2022-06-25 11:29:08.025480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = [
        "/etc/foo.txt",
    ]
    assert lookup_module_1.run(terms_1) == ["foo\n"]

# Generated at 2022-06-25 11:29:22.441247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:29:26.804395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run = lambda terms, variables=None, **kwargs: None
    lookup_module_run = lookup_module.run
    lookup_module_run


# Generated at 2022-06-25 11:29:35.086290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    from ansible.vars import Variables
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    vault = VaultLib([vault_password])
    vault_text = "{{ lookup('unvault', 'foo.yml') | to_json }}"
    vault_bytes = to_bytes(vault_text)
    vault.encrypt(vault_bytes)
    templar = Templar(loader=None, variables={})

    variables = Variables()
    variables.update(dict())
    import io
    import os
    import sys
    import tempfile
    _, temp_path = tempfile.mkstemp()

# Generated at 2022-06-25 11:29:38.630382
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setting up the test (initializing the plugin)
    lookup_module = LookupModule()

    # Testing with default parameters
    assert lookup_module.run(["tests/util/test.yaml"]) == [u'foo: bar\n']



# Generated at 2022-06-25 11:29:43.202791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_params = {
        'terms': [
            '/examples/pj.txt'
        ],
        'variables': {
            'FILE_PATH': '/examples',
        },
    }
    expected_result = ['I am pj.txt\n']
    lookup_module_run = LookupModule().run(**test_params)
    assert lookup_module_run == expected_result

# Generated at 2022-06-25 11:29:47.747788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests for case where actual_file is variable
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct={})
    lookup_module_1.run(['/home/ansible/foo.txt'], variables=None, **{'var_options': None, 'direct': {}})


# Generated at 2022-06-25 11:29:49.482687
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()


# Generated at 2022-06-25 11:29:52.913618
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # FIXME: change the test to use a local variable instead of importing a module variable
    terms = ['/etc/foo.txt']
    variables = None
    kwargs = {}
    l = LookupModule()
    l.run(terms,variables,**kwargs)



# Generated at 2022-06-25 11:30:00.737848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(None)
    lookup_module_0.set_templar(None)
    lookup_module_0.set_basedir(None)
    lookup_module_0._display = Display()
    res = lookup_module_0.run([u'ansible.cfg'], {}, use_vault=False, use_cache=False, cache_type=u'json')

# Generated at 2022-06-25 11:30:04.567987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    unvault = lookup_module.run(['/etc/hosts'])
    assert unvault == ["# this is a bad example for an unvaulted file\n"]

# Generated at 2022-06-25 11:30:15.215970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)
    return True


# Generated at 2022-06-25 11:30:23.741396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["/etc/foo.txt"]
    terms_1 = ["/etc/bar.txt"]
    terms_2 = ["/etc/foobar.txt"]
    terms_3 = ["/etc/foobar.txt"]
    terms_4 = ["/etc/foobar.txt"]
    terms_5 = ["/etc/foobar.txt"]
    terms_6 = ["/etc/foobar.txt"]
    ret_0 = lookup_module_0.run(terms_0)
    ret_1 = lookup_module_0.run(terms_1)
    ret_2 = lookup_module_0.run(terms_2)
    ret_3 = lookup_module_0.run(terms_3)
    ret_4 = lookup_module_0.run

# Generated at 2022-06-25 11:30:26.687215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup_terms = 'test'
    variables = {'vault_password': 'test'}

    actual_result = lookup.run(lookup_terms, variables)
    expected_result = []
    assert actual_result == expected_result



# Generated at 2022-06-25 11:30:31.842185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixture_string = 'ABCDEF'
    lookup_module_0 = LookupModule()
    fd, fn = mkstemp()
    try:
        with open(fn, 'wb') as f:
            f.write(fixture_string)
        fixture_terms = [fn]
        result = lookup_module_0.run(fixture_terms)
        assert result[0] == fixture_string
    finally:
        os.close(fd)
        os.unlink(fn)

# Generated at 2022-06-25 11:30:40.393995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={})
    lookup_module_0.set_options(var_options=None)
    lookup_module_0.get_options(noop=True)
    lookup_module_0.get_options(noop=True, variables=None)
    term = ['/var/ansible/unittest/example.txt']
    try:
        ret = lookup_module_0.run(term, variables=None, **dict())
        assert ret[0] == "Example File\n"
    except:
        term = ['/var/ansible/unittest/example.txt']
        lookup_module_0.run(term, variables=None, **dict())

# Generated at 2022-06-25 11:30:42.773860
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set arguments
    lookup_module = LookupModule()
    lookup_module_0 = LookupModule()
    # run function
    result_0 = lookup_module.run(lookup_module_0)

# Generated at 2022-06-25 11:30:48.565557
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    lookup_module_0.find_file_in_search_path = lambda x, y, z: y + '/' + z
    lookup_module_0._loader = lambda x: x

    assert lookup_module_0.run(['foo']) == ['files/foo']

# Generated at 2022-06-25 11:30:49.573844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0



# Generated at 2022-06-25 11:31:00.108817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 11:31:08.700556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0_terms_0 = ["/home/ansible/vault_secret.yml"]
    test_case_0_variables_0 = None
    test_case_0_kwargs_0 = None
    test_case_0_expectedoutput_0 = [u'foo: bar\n']

    test_case_0_kwargs_1 = None
    test_case_0_expectedoutput_1 = [u'foo: bar\n']

    test_case_0_kwargs_2 = None
    test_case_0_expectedoutput_2 = [u'foo: bar\n']

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:31:26.524396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True


# Generated at 2022-06-25 11:31:29.455938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    values_3 = ['lookup_test.txt']
    ret_4 = lookup_module_0.run(values_3)
    assert ret_4 == ['test_value']

# Generated at 2022-06-25 11:31:31.205600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['/etc/foo.txt'], {}) == []

# Generated at 2022-06-25 11:31:31.840921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:31:39.581853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Unit tests for term ''
    term_0 = ''
    variables_0 = {}
    assert lookup_module_0.run(terms=term_0, variables=variables_0) == None

    # Unit tests for term ''
    term_1 = ''
    variables_1 = {}
    assert lookup_module_0.run(terms=term_1, variables=variables_1) == None


if __name__ == '__main__':
    # Test run
    if test_case_0():
        print('Test Success')
    else:
        print('Test Failure')

# Generated at 2022-06-25 11:31:50.925463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/path/to/file1', '/path/to/file2']
    variables = None
    kwargs = {
        'var': 'some_variable',
        'blah': 'blah'
    }

    expected_return = 'test_contents'

    lookup_module = LookupModule()

    def test_find_file_in_search_path(variables, dirs, basedir, check_vars=True):
        return terms[0]

    def test_get_real_file(filename, decrypt=True):
        return '/path/to/file'

    lookup_module_0 = LookupModule()
    lookup_module_0.find_file_in_search_path = test_find_file_in_search_path

# Generated at 2022-06-25 11:31:52.712413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(terms=['/etc/passwd']), list)

# Generated at 2022-06-25 11:32:00.087974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    terms_0 = ''
    variables_0 = [("unvault_lookup_plugin", dict(path="lookup_plugins", name="unvault.py"))]
    kwargs_0 = dict(actual_file='/home/ubuntu/ansible/ansible/test/data/inventory/test_inventory', _loader=dict(path_cache={}))
    lookup_module_run_0.run(terms_0, variables_0, **kwargs_0)
    
    

# Generated at 2022-06-25 11:32:06.973473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0_val = lookup_module_0.run([], {})
    assert isinstance(term_0_val, list)
    term_1_val = lookup_module_0.run([], {})
    assert isinstance(term_1_val, list)
    term_2_val = lookup_module_0.run([], {})
    assert isinstance(term_2_val, list)
    term_3_val = lookup_module_0.run([], {})
    assert isinstance(term_3_val, list)
    term_4_val = lookup_module_0.run([], {})
    assert isinstance(term_4_val, list)
    term_5_val = lookup_module_0.run([], {})

# Generated at 2022-06-25 11:32:12.886650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # read a hash
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    
    # get result
    test_case_0(lookup_module_0)
    test_case_1(lookup_module_1)
    test_case_2(lookup_module_2)
    test_case_3(lookup_module_3)
    test_case_4(lookup_module_4)
    test_

# Generated at 2022-06-25 11:32:36.932297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_module_0.run(float_0)
    assert var_0 == 0.0

# Generated at 2022-06-25 11:32:41.712744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    class AnsiColors(object):
        def color_lookup(self, string_0):
            return string_0
    ansi_colors_0 = AnsiColors()
    ansi_colors_0.color_lookup = Mock(side_effect=ansi_colors_0.color_lookup)
    ansi_colors_1 = AnsiColors()
    ansi_colors_1.color_lookup = Mock(return_value="")
    ansi_colors_2 = AnsiColors()
    ansi_colors_2.color_lookup = Mock(return_value="")
    ansi_colors_3 = AnsiColors()

# Generated at 2022-06-25 11:32:44.879845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 38.7
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:32:47.527337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:32:49.706353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 2823.82
    lookup_module_1 = LookupModule()
    lookup_run(var_0)

# Generated at 2022-06-25 11:32:57.108634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    int_0 = 72
    str_0 = '^#n\x17\x00\x00'
    dict_0 = {}
    dict_0['s_0'] = '$'
    dict_0['s_1'] = '87'
    dict_0['s_2'] = 'dW'
    dict_0['s_3'] = '`x'
    dict_0['s_4'] = '\\<'
    dict_0['s_5'] = '\x1f'
    dict_0['s_6'] = '\x04'
    dict_0['s_7'] = '\x02'
    dict_0['s_8'] = '\x11'

# Generated at 2022-06-25 11:33:05.302366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mock variables
    self = mock.MagicMock()
    self.run = mock.MagicMock(return_value=True)
    self.run = mock.MagicMock()
    # Instantiate mock objects
    term_mock_0 = mock.MagicMock()
    term_mock_0.run.return_value = "fake_return_value"
    # Call method
    LookupModule_0 = LookupModule()
    result = LookupModule_0.run(term_mock_0)
    # Assert return values
    assert result == "fake_return_value"

# Generated at 2022-06-25 11:33:09.953079
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert var_0 == 2823.82

# Generated at 2022-06-25 11:33:12.986810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_module_0.run(float_0)

# Generated at 2022-06-25 11:33:14.711010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run(['/etc/passwd'])
    assert len(str_0) == 1


# Generated at 2022-06-25 11:33:52.147285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    unvault_0 = lookup_module_0.run(float_0)
    assert unvault_0 == expected_result_0


# Generated at 2022-06-25 11:33:53.573872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert "Error" in lookup_module_0.run(float_0)


# Generated at 2022-06-25 11:33:57.057236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fetch_0 = test_case_0()

# Generated at 2022-06-25 11:34:00.677908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    scope_0 = "scope_0"
    str_0 = "str_0"
    str_1 = "str_1"
    lookup_module_0.run(float_0, scope_0, {'scope_0': str_1}, var_s=str_0)


# Generated at 2022-06-25 11:34:05.042614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_module_0.run(float_0)
    assert var_0 == bool(0)


# Generated at 2022-06-25 11:34:08.049991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Call method run of object lookup_module_0 with arguments float_0=2823.82, str_0='', variables=lookup_module_0.set_options().get('var_options')
    assert lookup_module_0.run(float_0,str_0='',variables=lookup_module_0.set_options().get('var_options')) == float_0

# Generated at 2022-06-25 11:34:13.574431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:34:15.131260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_run(float_0)
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:34:17.147666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_run(float_0)

test_case_0()

# Generated at 2022-06-25 11:34:19.263422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_run(float_0)
    return var_0
	


# Generated at 2022-06-25 11:35:56.922792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 2823.82
    var_0 = lookup_run(float_0)
    assert var_0 == 'test', 'lookup_test != case'

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:35:59.115003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_module_0.run(float_0)
    float_0 = float_0
    lookup_run(float_0)


# Generated at 2022-06-25 11:36:05.387160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = lookup_module_0.run(lookup_module_0)
    assert len(lookup_module_0) == 0
    assert lookup_module_0.run(lookup_module_0) == 0


# Generated at 2022-06-25 11:36:11.626741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    float_1 = 1654.12
    lookup_module_1.get_val_from_arg = MagicMock(return_value = None)
    lookup_module_1.run = MagicMock(return_value = None)
    lookup_module_1.run(float_1)
    assert lookup_module_1.run(float_1) == None


# Generated at 2022-06-25 11:36:13.359178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_module_0.run(float_0)


# Generated at 2022-06-25 11:36:17.425653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = run(float_0)


# Generated at 2022-06-25 11:36:22.524999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = "/etc/foo.txt"
    variables = None
    lookup_module.run(terms,variables)


# Generated at 2022-06-25 11:36:24.416581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float0 = 364.44
    float0_0 = 552.18
    lookup_module_0 = LookupModule()
    lookup_module_0.run(float0_0, float0)


# Generated at 2022-06-25 11:36:28.408190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2823.82
    var_0 = lookup_run(float_0)
    assert var_0 == 1471.41

# Generated at 2022-06-25 11:36:29.778958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float = 2823.82
    var = lookup_module.run(float)
    assert var == var

