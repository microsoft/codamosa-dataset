

# Generated at 2022-06-25 11:27:19.739137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    import ansible_collections.ansible.builtin
    lookup_module_1.set_loader(ansible_collections.ansible.builtin.AnsibleLoader("/usr/lib/python3.7/site-packages/ansible_collections/ansible/builtin/plugins/lookup", ""))
    # There is no test for this method because of its high complexity
    pass

# Generated at 2022-06-25 11:27:22.960506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule.set_options({'_ansible_debug': True})
    result_ansible_debug = lookupModule.run(['/etc/hosts'])
    assert isinstance(result_ansible_debug, list)
    assert isinstance(result_ansible_debug[0], str)


# Generated at 2022-06-25 11:27:30.517581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_terms_1 = ['/etc/hosts']
    test_variables_1 = {}
    assert lookup_module_1.run(terms=test_terms_1, variables=test_variables_1) == [b'# Ansible managed\n\n127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4\n::1         localhost localhost.localdomain localhost6 localhost6.localdomain6\n']



# Generated at 2022-06-25 11:27:36.023151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct=dict())
    lookup_module_0.set_options(var_options=dict())
    actual = lookup_module_0.run(['/etc/foo.txt'])
    desired = ['']
    assert actual == desired

# Generated at 2022-06-25 11:27:44.240577
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()

    lookup_module_0.set_loader(None)
    lookup_module_0.set_basedir(None)
    lookup_module_0._display = None
    lookup_module_0.set_options(var_options=None, direct=None)

    lookup_module_0.run(terms='/etc/foo.txt', variables={'ansible_vault_password_file': '~/vault_password'})

    lookup_module_1.set_loader(None)
    lookup_module_1.set_basedir(None)
    lookup_module_1._display = None
    lookup_module_1.set

# Generated at 2022-06-25 11:27:52.817405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'unvault_test_case_0.yml']
    variables = None
    kwargs = dict()
    kwargs['direct'] = None
    lookup_module_0.set_options(var_options=variables, direct=kwargs['direct'])
    try:
        result = lookup_module_0.run(terms=terms, variables=variables, **kwargs)
        assert result[0] == u'This file is not vaulted\n'
    except Exception as e:
        exception_msg_0 = str(e)
        display.debug(exception_msg_0)
        assert False



# Generated at 2022-06-25 11:27:54.823913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run( terms=['/Users/baspet/.ansible/plugins/lookup_plugins/unvault.py'], variables='a')

# Generated at 2022-06-25 11:28:04.761883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0_var_options = dict()
    test_case_0_var_options['convert_data'] = True
    test_case_0_terms = ['../tests/data/vault-data']
    test_case_0_kwargs = dict()
    test_case_0_kwargs['password'] = 'foobar'
    test_case_0_kwargs['vault_password_file'] = 'ansible-test-vault'
    test_case_0_kwargs['encrypt_vault_id'] = None
    test_case_0_kwargs['key'] = None
    test_case_0_kwargs['cacert_file'] = None
    test_case_0_kwargs['force'] = True
    test_case_0_kwargs['unsafe_writes']

# Generated at 2022-06-25 11:28:06.250413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=['/etc/foo.txt'], variables={}, **{})
    assert isinstance(result, list)


# Generated at 2022-06-25 11:28:10.246058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = 'test/files/test.txt'
    local_variable_0 = 'local variables'
    local_variable_1 = 'local variables 1'
    lookup_module_0.run(term_0, local_variable_0, **local_variable_1)


# Generated at 2022-06-25 11:28:24.185326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()
    lookup_module_16 = LookupModule()

# Generated at 2022-06-25 11:28:26.031867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the case that there is input hash and valid lookup name
    lookup_module_0 = LookupModule()
    assert True == lookup_module_0.run([])


# Generated at 2022-06-25 11:28:27.971398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["/etc/foo.txt"])
    lookup_module.run(["/etc/foo.txt", "/etc/bar.txt"])

# Generated at 2022-06-25 11:28:34.450601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._loader = None
    lookup_module_1.set_options = None
    lookup_module_1.find_file_in_search_path = None
    lookup_module_1.run(['{{ var1 | from_yaml }}'], variables={'var1': 'var2'}, var_options={'var1': 'var2'})


# Generated at 2022-06-25 11:28:37.902335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt','fizz.txt']
    lookup_module.run(terms)
    assert 1

# Generated at 2022-06-25 11:28:40.309262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args_0 = [["/etc/ansible/hosts"]]
    args_1 = {}
    expected__raw = ["localhost ansible_connection=local\n"]
    expected_result = (expected__raw,)
    actual_result = lookup_module_1.run(*args_0,**args_1)
    assert actual_result == expected_result


# Generated at 2022-06-25 11:28:45.674732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    variables = None
    ret = lookup_module_0.run(terms, variables)
    assert ret == []

# Generated at 2022-06-25 11:28:48.157754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '/etc/foo.txt'
    variables_0 = None
    kwargs_0 = {'default': 'test'}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print(result_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:50.913537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/test/test_file']
    variables = None
    kwargs = dict()
    content = lookup_module.run(terms, variables, **kwargs)
    assert content == ['LookupModule test run']

# Generated at 2022-06-25 11:28:58.244277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={u'this': u'works'}, direct={u'lookup_opts': {}})
    assert lookup_module_0.run([u'hosts']) == [u'127.0.0.1\n127.0.0.1\n']

# Generated at 2022-06-25 11:29:07.805249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'_input_data' : "{'var': 'value'}" })
    result = lookup_module.run([], {})
    #assert result == "foo"



# Generated at 2022-06-25 11:29:09.328332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt']
    lookup_module.run(terms)

# Generated at 2022-06-25 11:29:14.592968
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # 1. Create an instance of the Ansible class LookupModule
    lookup_module_1 = LookupModule()

    # 2. Create a test term, e.g. the path of a file
    test_term = '/etc/foo.txt'

    # 3. Create an empty dictionary of Ansible variables
    variables = {}

    # 4. Execute the lookup_module.run() method
    lookup_module_1.run(terms = test_term, variables = variables)

# Generated at 2022-06-25 11:29:19.292639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/ansible/ansible.cfg']
    variables = {"ansible_config_file": "/etc/ansible/ansible.cfg"}
    assert lookup_module.run(terms=terms, variables=variables) != []

# Generated at 2022-06-25 11:29:22.451957
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1: Make sure the method 'run' works as expected when 'decrypt' is set to True
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['/Users/jking/test/test_vault_secret.yml'], [], decrypt=True) == ['thisismypassword']
    return True



# Generated at 2022-06-25 11:29:29.713980
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    lookup_module_0.set_loader(None)

    lookup_module_0.run(terms=['foo.txt'], variables={'ansible_env': {}, 'ansible_env_redact': ['ANSIBLE_VAULT'], 'ansible_check_mode': False, 'ansible_config_dir': '/Users/jdanek/Envs/ansible3/etc/ansible'}, args={})


# Generated at 2022-06-25 11:29:31.505636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  assert lookup_module_1.run("") == [], "'1' failed"


# Generated at 2022-06-25 11:29:34.197105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([], variables=None, **{})

# Generated at 2022-06-25 11:29:38.668344
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    lookup_module_terms = ["/etc/foo.txt"]

    lookup_module_variables = dict()

    lookup_module_kwargs = dict()

    result = lookup_module.run(lookup_module_terms, lookup_module_variables, **lookup_module_kwargs)

    assert result == ['foo']

# Generated at 2022-06-25 11:29:40.992587
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    test_case_run_00 = lookup_module_0.run(None, None)

    assert test_case_run_00 == []

# Generated at 2022-06-25 11:30:02.463387
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    my_file = './test_cases/test_case_0.yml'
    with open(my_file, 'r') as f:
        vars = f.read()

    terms = ['/etc/foo.txt']
    lookup_module_0.run(terms=terms, variables=vars)

# Generated at 2022-06-25 11:30:13.028575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if required options are passed
    def test_missing_required_options(args):
        try:
            lookup_module_run(args)
        except SystemExit as exception:
            assert exception.code == 256

    args = dict(terms=[])
    test_missing_required_options(args)

    # Set up context to test the behavior

# Generated at 2022-06-25 11:30:15.299420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['/etc/foo.txt'], '')


# Generated at 2022-06-25 11:30:18.025851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 11:30:23.857235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    # value returned from lookup_module_0.run(terms_0, variables_0, kwargs_0)
    return_value_0 = None

    return None


# Generated at 2022-06-25 11:30:28.436677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()


# Generated at 2022-06-25 11:30:32.647141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # This will raise an exception
    lookup_module_0.run(None, None)

# Generated at 2022-06-25 11:30:37.289832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Execute test
    test_path = 'tests/unit/plugins/lookup/unvault/fixtures/test_0.txt'
    lookup_module_0 = LookupModule()
    terms = [test_path]
    lookup_module_0.run(terms)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:30:39.061159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_1(lookup_module_0)

# Test Use Case 1

# Generated at 2022-06-25 11:30:43.658898
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_env': {'HOME':'/home/myhome'}}, direct={'_original_file':'/home/myhome/ansible/lookup_plugins/unvault.py'})


# Generated at 2022-06-25 11:31:25.146391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:31:26.847156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(["/etc/foo.txt"])
    assert type(ret) is list

# Generated at 2022-06-25 11:31:29.145551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.set_options()
    lookup_module_run.set_env()


# Generated at 2022-06-25 11:31:35.149694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader({'set_basedir': lambda self, basedir: None})
    terms = ['/etc/hosts']
    variables = {}
    local_module_args = {}
    ret_val_0 = lookup_module_0.run(terms, variables=variables, **local_module_args)
    assert ret_val_0[0].startswith('127.0.0.1') == True


if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:31:38.531512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        'foo.txt',
        'bar.txt',
    ]
    variables = {
    }
    lookup_module_0.set_options(var_options=variables, direct={})
    lookup_module_0._loader = MockLoader()
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:31:40.388013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(["unvault"])


# Generated at 2022-06-25 11:31:42.994670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    assert lookup_module_run_0.run([]) == []

# Generated at 2022-06-25 11:31:46.260684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleParserError):
        lookup_module = LookupModule()
        lookup_module.run('/foo/bar')


# Generated at 2022-06-25 11:31:54.911124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()

    # Helper function to display the data
    def display_data(data):
        print("\n------------")
        for item in data:
            print(item)
            print("\n")


    data_list = []
    def test_run_0():
        terms = "/home/bhagwat/pyproject1/unit_testing/unit_testing_module.txt"
        data_list.append(lookup_module_0.run(terms))

    def test_run_1():
        terms = "unit_testing/unit_testing_module.txt"
        data_

# Generated at 2022-06-25 11:31:59.503062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms='/etc/foo.txt') == ['content of file /etc/foo.txt']

# Generated at 2022-06-25 11:32:38.394595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    parameters = {}
    parameters['terms'] = ['/etc/foo.txt']
    parameters['variables'] = {}
    parameters['kwargs'] = {}
    lookup_module_0.run(**parameters)


# Generated at 2022-06-25 11:32:49.214030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_11_at = lookup_module_11.run(['/etc/ansible/foo.txt'])

# Stress test for method run of class LookupModule

# Generated at 2022-06-25 11:32:56.520229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_examples = [
        {
            "terms": [
                "/etc/foo.txt"
            ],
            "kwargs": {
                "variables": {
                    "files": [
                        "./lookup_plugins/files"
                    ]
                }
            },
            "expect": [
                "bar\n"
            ]
        },
    ]
    lookup_module_0 = LookupModule()
    for test_case in lookup_examples:
        assert lookup_module_0.run(**test_case) == test_case['expect']

# Generated at 2022-06-25 11:32:58.811845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['some_path'], {})



# Generated at 2022-06-25 11:33:05.504135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['tests/unit/data/lookup_plugins/vault_lookup/vault_data.txt']
    lookup_module_1.run(terms=terms_1)
    terms_2 = ['tests/unit/data/lookup_plugins/vault_lookup/unvault_data.txt']
    lookup_module_1.run(terms=terms_2)

# Generated at 2022-06-25 11:33:08.964369
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare variables
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=None)
    terms = '/etc/foo.txt'
    variables = None
    kwargs = {}
    lookup_module_1.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:33:12.928546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['/etc/foo.txt', '/etc/foo.txt']

    variables = {'ansible_play_hosts_all': ['10.0.0.1', '10.0.0.2']}

    lookup_module.run(terms, variables)

# Generated at 2022-06-25 11:33:14.370320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run('/etc/shadow')
    assert isinstance(x, list)

# Generated at 2022-06-25 11:33:18.823883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test case #0
    test_terms = [
        'path/to/file.yml',
        'path/to/file.yml',
    ]

# Generated at 2022-06-25 11:33:22.695962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:34:44.855137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/etc/foo.txt']
    variables_1 = None
    kwargs_1 = {}
    assert lookup_module_1.run(terms=terms_1, variables=variables_1, **kwargs_1) == ["line 1\n", "line 2\n", "line 3"], "Method run of class LookupModule not working properly"


# Generated at 2022-06-25 11:34:45.525238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:34:47.906681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Retrieve file contents from unvaulted file
    lookup_module_0_terms = ["/etc/foo.txt"]
    lookup_module_0_options = {}
    assert lookup_module_0.run(lookup_module_0_terms, lookup_module_0_options) == ["bar\n"]


# Generated at 2022-06-25 11:34:53.206121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/foo.txt']
    result_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:34:58.389489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'file'
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(term_0, variables=None, **{}), list)
    assert lookup_module_0.run(term_0, variables=None, **{}) == []

# Generated at 2022-06-25 11:35:03.081932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/etc/foo.txt']
    variables = None
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:35:07.008673
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Test execution path where the file exists
    results_1 = lookup_module_1.run(['unvault.py'])
    assert lookup_module_1._loader.get_real_file('unvault.py')
    assert next(results_1) == open(lookup_module_1._loader.get_real_file('unvault.py')).read()


# Generated at 2022-06-25 11:35:09.584796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run("My test") == []

# Generated at 2022-06-25 11:35:10.128846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:35:16.025458
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    terms_1 = [
        '/etc/foo.txt',
    ]
    variables_1 = {}
    results_1 = lookup_module_1.run(terms_1, variables_1)
    assert results_1 == ['bar\n']



# Generated at 2022-06-25 11:36:48.441890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\t7,PWK~\t;(||P/w&qu'
    lookup_module_0.run(str_0)
    lookup_module_0.run(str_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)



# Generated at 2022-06-25 11:36:51.423475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = 'I`G,'
    variables_0 = 'P#['
    kwargs_0 = {'terms': terms_0, 'variables': variables_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(**kwargs_0)

# Generated at 2022-06-25 11:36:58.457581
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:36:59.269752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 0 with vanilla options
    test_case_0()


# Generated at 2022-06-25 11:37:04.592114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    Module = LookupModule()
    terms = []
    variables = {}
    kwargs = {'exclude':'exclude'}
    assert Module.run(terms, variables, **kwargs) == [], 'Expected empty list'
#
# test_case_1
#
    str_0 = 'C[(\n|w8F\x0c~mz6&q9fT\x0c|<a4PH\'\x0b\\'
    Module = LookupModule()
    terms = []
    variables = {str_0: 'exclude'}
    kwargs = {'exclude': 'exclude'}
    assert Module.run(terms, variables, **kwargs) == [], 'Expected empty list'
#
# test_case_2
#

# Generated at 2022-06-25 11:37:13.271440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    # test using gmtime
    from time import gmtime

    lookup_module_0 = LookupModule()

    time_0 = lookup_module_0._flatten(gmtime())

    assert (time_0 is not False), "gmtime returned False"

    # test using localtime
    from time import localtime

    lookup_module_1 = LookupModule()

    time_1 = lookup_module_1._flatten(localtime())

    assert (time_1 is not False), "localtime returned False"

    # test using strftime
    from time import strftime

    lookup_module_2 = LookupModule()

    time_2 = lookup_module_2._flatten(strftime('%l:%M%p'))
