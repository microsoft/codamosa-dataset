

# Generated at 2022-06-25 11:27:26.485445
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    lookup_module.set_options(var_options=None, direct=None)

    lookup_module._loader.mapping = {
            'test_data/vault.yml': 'test_data/vault.yml.vaulted',
            'test_data/test_data.yml': 'test_data/test_data.yml'
            }

    lookup_module._converter.get_real_file = lambda x,y: x

    result = lookup_module.run(['test_data/vault.yml'], variables=None)
    assert result == [u'abc\n']

    result = lookup_module.run(['test_data/test_data.yml'], variables=None)

# Generated at 2022-06-25 11:27:30.195487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms = ['/etc/foo.txt']
    variables = None
    kwargs = []
    result = lookup_module_run.run(terms, variables, **kwargs)
    assert result == ['/usr/bin/useradd']


# Generated at 2022-06-25 11:27:34.940438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ''
    variables_1 = ''
    kwargs_1 = dict()
    lookup_module_1.run(terms_1, variables_1, **kwargs_1)


# Generated at 2022-06-25 11:27:43.426054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:27:46.019187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 11:27:49.556884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = DummyLoader()
    lookup_module._loader.set_variable('lookup_file_content', b'vaulted')
    assert lookup_module.run(terms=['lookup_file'], variables={}) == ['vaulted']



# Generated at 2022-06-25 11:27:52.507706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:27:54.515038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/hostname', '/etc/hosts']
    lookup_module_0.run(terms_0)



# Generated at 2022-06-25 11:27:58.338067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    check_result = lookup_module_0.run(['foo'])
    assert check_result == []



# Generated at 2022-06-25 11:28:05.825658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing method run of class LookupModule ...")

    lookup_module_0 = LookupModule()

    # Test 1
    terms = [""]
    variables = None
    kwargs = {"variables": variables}
    ret = lookup_module_0.run(terms, **kwargs)

    assert ret == []
    
    # Test 2
    terms = [""]
    variables = {"_ansible_verbosity": 0}
    kwargs = {"variables": variables}
    ret = lookup_module_0.run(terms, **kwargs)

    assert ret == []

    # Test 3
    terms = [""]
    variables = {"_ansible_verbosity": 4}
    kwargs = {"variables": variables}
    ret = lookup_module_0.run(terms, **kwargs)

    assert ret

# Generated at 2022-06-25 11:28:09.666092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:28:12.212542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(tuple_0) == []
    var_0 = lookup_module_0.run(tuple_0)
    if var_0:
        assert var_0[0] is None
    else:
        raise AssertionError('1st element of var_0 must be None.')

# Generated at 2022-06-25 11:28:14.167983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = ((),)
    # Call test_LookupModule_run_0
    res_0 = test_LookupModule_run_0()


# Generated at 2022-06-25 11:28:19.307958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('foo.bar')

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:21.951719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # No test case
  lookup_module_0 = LookupModule()
  tuple_0 = (1, 2, 3)
  display_0 = Display()
  display_0.debug('')
  var_0 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:28:24.516847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ()
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:28:28.272998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.errors import AnsibleParserError
        from ansible.plugins.lookup import LookupModule
        from ansible.module_utils._text import to_text
        from ansible.utils.display import Display
        tuple_0 = ()
        lookup_module_0 = LookupModule()
        lookup_run(tuple_0)
    except Exception as exception_0:
        assert False


# Generated at 2022-06-25 11:28:31.239980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ("")
    var_0 = lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:28:33.769898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:28:35.400171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)

# Generated at 2022-06-25 11:28:42.160343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_1 = ()
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(tuple_1)
    assert var_1 == list(), 'expected list(), got %s' % var_1


# Generated at 2022-06-25 11:28:45.538439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:28:47.961794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:28:55.144936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize of class LookupModule
    lookup_module_0 = LookupModule()
    # Var declarition
    # Initialize with test data
    terms = ["unvault", "file_1", "file_2", "file_3"]
    variables = None
    # Expected result
    expected_result = ['file_1', 'file_2', 'file_3']
    # Actual result
    actual_result = lookup_module_0.run(terms, variables)
    # Test assertion
    assert (actual_result == expected_result)

# Generated at 2022-06-25 11:28:58.914388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the LookupModule class
    lookup_module_0 = LookupModule()

    # Define input variables
    tuple_0 = ()
    var_0 = None

    # Define the method calling sequence
    lookup_module_0.run(tuple_0, var_0)

# Generated at 2022-06-25 11:29:06.611401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # LookupModule_run() will find /etc/foo.txt
    lookup_module_0.run(['/etc/foo.txt'])
    # LookupModule_run() will fail to find /foo.txt
    lookup_module_0.run(['/foo.txt'])

# Generated at 2022-06-25 11:29:07.077852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:29:07.834557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:29:14.255113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    element = 'bar'
    term = ''
    tuple_0 = (term)
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
    if var_0 == element:
        print("PASSED")
    else:
        print("the value of var_0 is %s" % var_0)
        print("the expected value is %s" % element)
        print("FAILED")


# Generated at 2022-06-25 11:29:20.131324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run()
    except Exception as exception:
        print(str(exception))


if __name__ == "__main__":
    import sys
    import pytest

    if len(sys.argv) > 1:
        pytest.main(sys.argv[1])
    else:
        pytest.main()

# Generated at 2022-06-25 11:29:28.955010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)
    return var_0

# Generated at 2022-06-25 11:29:31.506066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_1 = (1, 2)
    var_0 = lookup_module_0.run(tuple_1)
    # test fail
    assert var_0

# Generated at 2022-06-25 11:29:35.126069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(())
    var_1 = lookup_run(('/home/u0/l0', '/home/u1/l0'))

# Generated at 2022-06-25 11:29:37.096182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == []

# Generated at 2022-06-25 11:29:39.235375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t0 = (1, )
    l0 = LookupModule()
    assert l0.run(t0) == None


# Generated at 2022-06-25 11:29:47.219025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ('', '', '', '')
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)
    var_1 = lookup_run(tuple_0)
    var_2 = lookup_run(tuple_0)
    var_3 = lookup_run(tuple_0)
    var_4 = lookup_run(tuple_0)
    var_5 = lookup_run(tuple_0)
    var_6 = lookup_run(tuple_0)
    var_7 = lookup_run(tuple_0)
    var_8 = lookup_run(tuple_0)
    var_9 = lookup_run(tuple_0)
    var_10 = lookup_run(tuple_0)
    var_11 = lookup_run

# Generated at 2022-06-25 11:29:53.253279
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run('test')
    assert var_1 == 'test', 'Expected value : test'

    tuple_1 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_1)
    assert var_0 == tuple_1, 'Expected value : None'



# Generated at 2022-06-25 11:29:56.492545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
    test_case_0()

# Generated at 2022-06-25 11:30:00.085862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_module_0.run(tuple_0)
    tuple_1 = ()
    var_1 = lookup_module_0.run(tuple_1)


# Generated at 2022-06-25 11:30:10.626151
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Constants
    str_0 = '*'
    str_1 = '~'
    str_2 = '^'
    str_3 = '- '
    str_4 = '.'
    str_5 = ' '
    str_6 = '+'
    str_7 = '^'
    str_8 = ':'
    str_9 = '+'
    str_10 = '`'
    str_11 = '#'
    str_12 = '('
    str_13 = ')'
    str_14 = ':'
    str_15 = '/'
    str_16 = ','
    str_17 = 'y=3'
    str_18 = '+'
    str_19 = '+'
    str_20 = '#'
    str_21 = '/'
    str_

# Generated at 2022-06-25 11:30:29.031892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module__terms_0 = test_case_0()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module__terms_0)

# Generated at 2022-06-25 11:30:33.260444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)

# Generated at 2022-06-25 11:30:36.934725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    variables_0 = {}
    kwargs_0 = {}
    var_0 = lookup_module_0.run(tuple_0,variables_0,**kwargs_0)
    assert var_0 == None

# Generated at 2022-06-25 11:30:37.449797
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False


# Generated at 2022-06-25 11:30:39.218512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except Exception as e:
        print(e)

test_LookupModule_run()

# Generated at 2022-06-25 11:30:46.065797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)
    var_1 = lookup_module_0.run(tuple_0)
    var_3 = lookup_module_0.run(tuple_0)
    var_4 = lookup_module_0.run(tuple_0)
    print("%s\n" % var_4)
    var_6 = lookup_module_0.run(tuple_0)
    print("%s\n" % var_6)
    print("%s\n" % var_6)
    print("%s\n" % var_6)
    print("%s\n" % var_6)
    var_9 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:30:53.520373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ()
    variables = None
    kwargs = {}
    lookupbase = LookupBase()
    lookupbase.set_options(var_options=variables, direct=kwargs)
    lookupbase._loader = None
    lookupbase._templar = None
    lookupbase._plugin_loader = None
    lookupbase.get_options = MagicMock()
    lookupbase.get_options.return_value = kwargs
    lookupbase.find_file_in_search_path = MagicMock()
    lookupbase.find_file_in_search_path.return_value = None
    lookupbase._loader.get_real_file = MagicMock()
    lookupbase._loader.get_real_file.return_value = None
    expected_0 = []

# Generated at 2022-06-25 11:30:57.733278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vault_password = b'$6$YUZ7XU6Wab/SQCf6$FBhV7hW8SywGyg0qBi3qdZaqBxBB8hxHxDahy79ghRzUMs1W8p4Fh4Oe.uZ.fgU6WXUO7GOJzDJcU6LM87A5b0'
    plaintext = b'abc123'
    vault_encrypt(plaintext, vault_password, 'test.yml', 'test_vault_1.yml')
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 11:31:02.461033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_0 = LookupModule()
    str_0 = "terms"
    tuple_1 = ()
    str_1 = lookup_module_0.run(str_0, tuple_1)
    print(str_1)

# Generated at 2022-06-25 11:31:05.890204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.run(None, None, None, None)


# Generated at 2022-06-25 11:31:39.739616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(tuple_0)

# Generated at 2022-06-25 11:31:44.473788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)
    assert len(var_0) == 0


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:31:50.264576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_term_0
    var_1 = lookup_terms_0
    var_2 = lookup_variables_0
    var_3 = lookup_kwargs_0
    var_4 = lookup_run(var_0, var_1, var_2, var_3)
    assert var_4 == lookup_ret_0
    return


# Generated at 2022-06-25 11:31:52.753017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ('foo')
    vars_0 = dict()
    var_0 = lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:31:55.754570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    request.apply_request_middleware(r) # apply the middleware

    # Test the method

    unvault_class_0 = LookupModule()
    request.addfinalizer(unvault_class_0.run)
    unvault_class_0.run()


# Generated at 2022-06-25 11:31:59.540426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:32:04.242412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_6 = ()
    lookup_module_6 = LookupModule()
    assert lookup_run(tuple_6) == 'passed'


# Generated at 2022-06-25 11:32:08.132787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    variables_0 = dict()
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(tuple_0, variables_0)

# Generated at 2022-06-25 11:32:14.517188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)
    assert (var_0 == [])
    tuple_1 = ("/etc/foo.txt")
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(tuple_1)
    assert (var_1 == ["This is the content of foo.txt"])
    tuple_2 = ("/etc/foo.txt",)
    lookup_module_0 = LookupModule()
    var_2 = lookup_run(tuple_2)
    assert (var_2 == ["This is the content of foo.txt"])

# Generated at 2022-06-25 11:32:19.814733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    dict_0 = {}
    var_0 = lookup_module_0.run(tuple_0, vars={})
    var_1 = lookup_module_0.run(tuple_0, variables=dict_0)


# Generated at 2022-06-25 11:33:32.061718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    tuple_1 = ("", )
    def verify_lookup_base_run(tuple_1):
        var_0 = lookup_module_0.run(tuple_1)
        assert len(var_0) == 1
        assert var_0[0] == "test.txt"
    verify_lookup_base_run(tuple_1)

# Generated at 2022-06-25 11:33:36.319332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    lookup_module_0.run(tuple_0, None)



# Generated at 2022-06-25 11:33:39.328549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    tuple_1 = lookup_module_0.run(tuple_0)
    if (tuple_1 == ()):
        test_case_0()
    else:
        print('Failed!')


# Generated at 2022-06-25 11:33:48.758574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    tuple_0 = ()
    dict_0 = {}
    lookup_module_0.find_file_in_search_path(dict_0, 'files', 'term')
    var_0 = lookup_module_0.run(tuple_0, dict_0)
    tuple_1 = ()
    dict_1 = {}

# Generated at 2022-06-25 11:33:52.642415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = None
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleParserError):
        lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 11:33:57.494498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case for correct path
    tuple_0 = ('/etc/foo.txt',)
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)
    assert isinstance(var_0, list) and var_0 == ["foo"]

    # Test case for invalid path
    tuple_1 = ('/etc/bar.txt',)
    lookup_module_1 = LookupModule()
    try:
        var_1 = lookup_run(tuple_1)
    except AnsibleParserError:
        var_1 = None
    assert var_1 is None

# Generated at 2022-06-25 11:34:02.277019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from os.path import exists, abspath
    from ansible.plugins.lookup.file import LookupModule as FileLookup
    file_lookup_0 = FileLookup()
    search_paths = ('.',)
    var_0 = file_lookup_0.run(('file_test.txt',), search_paths)
    assert var_0[0] == abspath('file_test.txt')
    assert not var_0[1]
    assert exists(var_0[0])


# Generated at 2022-06-25 11:34:02.635802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	pass

# Generated at 2022-06-25 11:34:07.623094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = "/etc/foo.txt"
    tuple_0 = (term_0)

    lookup_module_0 = LookupModule()
    lookup_module_0._loader = mock_loader(lookup_module_0._loader)
    lookup_module_0.find_file_in_search_path = mock_find_file_in_search_path(lookup_module_0.find_file_in_search_path)
    lookup_module_0._loader.get_real_file = mock_get_real_file(lookup_module_0._loader.get_real_file)
    lookup_module_0.open_file = mock_open_file(lookup_module_0.open_file)

    var_0 = lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:34:09.310157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (1, 0)
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)

    assert var_0 == list()



# Generated at 2022-06-25 11:37:07.473366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: Write test
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:37:10.919038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_1 = ()
    var_1 = lookup_module_1.run(tuple_1)
    assert var_1


# Generated at 2022-06-25 11:37:11.736358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == var_0, "test_case_0()"

# Generated at 2022-06-25 11:37:21.176970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule()
    ansible_fact_mod_0 = ansible.module_utils.facts.AnsibleModule()
    ansible_fact_mod_0.params = {}
    ansible_fact_mod_0.ansible_facts = {}
    ansible.module_utils.facts.AnsibleModule.get_bin_path = MagicMock()
    ansible_fact_mod_0.get_bin_path = MagicMock(return_value = ("/bin",))
    ansible_fact_mod_0.ansible_facts["command_nonzero_warnings"] = 0
    ansible_fact_mod_0.ansible_facts["command_warnings"] = 0
    ansible_fact_mod_0.ansible_facts["command_success"]