

# Generated at 2022-06-25 11:27:18.411960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:27:24.309275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = "string"
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(term_0, variables_0, **kwargs_0)
    except:
        pass
    finally:
        assert True

# Generated at 2022-06-25 11:27:32.058675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_1 = b'\xe0\xb4\x92\x03\\'
    dict_1 = {}
    lookup_module_1 = LookupModule(bytes_1, **dict_1)
    #
    lookup_module_1.run('/etc/foo.txt', {})
    #
    bytes_2 = b'\xe0\xb4\x92\x03\\'
    dict_2 = {}
    lookup_module_2 = LookupModule(bytes_2, **dict_2)
    #
    lookup_module_2.run('/etc/foo.txt', {})

# Generated at 2022-06-25 11:27:35.151940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xad\x0f\xb9\x17W\xb8\x1c\x91\x96\x1f\xbe\xa6Rx'
    terms = ['~/']
    variables = {}
    kwargs = {}
    lookup_module_0 = LookupModule(bytes_0, **dict_0)
    ret = lookup_module_0.run(terms, variables, **kwargs)
    assert ret == ['\n']

# Generated at 2022-06-25 11:27:40.272481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xe0\xb4\x92\x03\\'
    dict_0 = {}
    lookup_module_0 = LookupModule(bytes_0, **dict_0)
    str_0 = 'foo.bar'
    dict_1 = {}
    str_1 = lookup_module_0.run(str_0, **dict_1)


# Generated at 2022-06-25 11:27:46.702969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    byte_string_0 = b'Z\x12\x86\x1e\x10\x01\x04'
    byte_string_1 = b'\x1b2\xdbj6\x8c'
    byte_string_2 = b'\xd8\x03'
    byte_string_3 = b'\x05\x96\x08\xba\xa7'
    byte_string_4 = b'\xb5\t\xec\xa8\xab'
    dict_0 = {"decrypt": True}
    dict_1 = {"decrypt": True}
    dict_2 = {"decrypt": True}
    dict_3 = {"decrypt": True}
    dict_4 = {"decrypt": True}
    tuple_0 = (byte_string_0,)
    tuple

# Generated at 2022-06-25 11:27:49.917697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xe0\xb4\x92\x03\\'
    dict_0 = {}
    term_0 = lookup_module_0.run(bytes_0, **dict_0)

# Generated at 2022-06-25 11:27:53.438265
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    test_case_0()

# Generated at 2022-06-25 11:28:04.663130
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:28:14.439419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule([b'\xc0\x8d\x93\xe3\xfa\xf8R\xb9\x93\xd0\xcd\x80\xd8\xaf\x1c2d\xe6\xc8\xd9'])
    var_lookup_file_0 = b'\x88\xa2\xeaV\x9a\x9f\xc3C\xe3\x80\xd2\xbb\xf3\x1a\x02\x12\x9f\xd6\xa0\xda'
    lookup_module_0.find_file_in_search_path(var_lookup_file_0, 'files')
    lookup_module_0.set_options(direct=dict_0)
    var_search_

# Generated at 2022-06-25 11:28:24.383000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:28:29.151501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    # if necessary, update dict_0 with more keywords and values
    var_0 = lookup_module_0.run(str_0, **dict_0)
    print(var_0)

# Generated at 2022-06-25 11:28:30.845125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(**dict_0)
    assert not var_0
    lookup_module_0.run(str_0, **dict_0)

# Generated at 2022-06-25 11:28:39.955485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {'_10': 'G\rM2', '_9': 'd.\rM2', '_8': 'r_7\n~AOe:N\x0cVm^}', '_7': '$_7\n~AOe:N\x0cVm^}', '_6': '\rTfunvX', '_5': 'reconnection_retries', '_4': 'reconnection_retries', '_3': '$_7\n~AOe:N\x0cVm^}', '_2': '\rM2', '_1': '\rM2', '_0': '\rTfunvX'}
    term_0 = '^\rTfunvX'


# Generated at 2022-06-25 11:28:43.260512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:28:49.761109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    str_1 = '$_7\n~AOe:N\x0cVm^}'
    str_2 = 'reconnection_retries'
    list_0 = []
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, **dict_0)


# Generated at 2022-06-25 11:28:58.282562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)



if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:29:04.277642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleParserError):
        term_0 = '\x1f^1\x1d\x0cFN\x1c\x0b\x15'
        dict_0 = {
            'display': display,
            'var_options': {'a': 0x0},
            'direct': {'nodes': '\r\r\r\r'},
        }
        lookup_module_0 = LookupModule()
        lookup_module_0.run(term=term_0, **dict_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:08.105359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)

# Generated at 2022-06-25 11:29:11.023873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_run()



# Generated at 2022-06-25 11:29:16.594278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(dict_0)


# Generated at 2022-06-25 11:29:22.365589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    q_0 = 'p\x0c\x09I\x0b+\x0b\x06~\x0f'
    lookup_options_0 = {'variable_start_string': q_0, '_original_basename': q_0}
    str_0 = 'c\x0c\x0f\x09\x00\x0f\x0f\x0e'
    var_3 = lookup_module_0.run(str_0, lookup_options_0)
    assert var_3 == [], "Assertion failed: {} != {}".format(var_3, "")


# Generated at 2022-06-25 11:29:26.917469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_0 = 'i2YG|<q3x}l>fA'
    str_1 = 'p:yRt\x1e{{s\t]P\x0b'
    str_2 = 'xTtN\tHw$^>>'
    str_3 = 'i\x1c%oJ#]m\x1ap'
    str_4 = 'n\n\'^\r}mG|a2{'
    str_5 = 'J%c5\x1a=\x1d:WzS'
    str_6 = '\x1eOPgZ<\\*e\x0c'

# Generated at 2022-06-25 11:29:29.422329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [str(random.randint(0, 100)) for i in range(1000)]
    variables = None
    obj = LookupModule()
    parameters = {}
    obj.run(terms, variables, **parameters)

# Generated at 2022-06-25 11:29:31.549047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        LookupModule.run('')
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:29:39.983464
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test 1

    ut_id = 1

    # Setup test 1

    var_0 = '\rTfunvX'
    var_1 = 'reconnection_retries'
    var_2 = '$_7\n~AOe:N\x0cVm^}'
    var_3 = {var_1: var_0, var_2: var_0, var_2: var_0, var_0: var_0}
    lookup_module_0 = LookupModule()

    # Execution test 1

    var_4 = lookup_module_0.run(var_0, **var_3)

    # Verification test 1

    assert var_4 == ['']


# Generated at 2022-06-25 11:29:51.039362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  str_0 = '\rTfunvX'
  str_1 = 'check_all_types_for_underscore_underscorehash__underscoreunderscore'
  str_2 = 'builtin_function_or_method'
  str_3 = 'reconnection_retries'
  str_4 = '$_7\n~AOe:N\x0cVm^}'
  str_5 = 'file'
  str_6 = '_'
  str_7 = 'set_options'
  str_8 = 'display'
  str_9 = 'debug'
  dict_0 = {str_3: str_0, str_4: str_0, str_4: str_0, str_0: str_0}

# Generated at 2022-06-25 11:29:53.533625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['y'])
    lookup_module_0.set_options()
    lookup_module_0.run(['z'])


# Generated at 2022-06-25 11:29:58.265338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, **dict_0)
# Find the file in the expected search path
# Find the file in the expected search path
# Find the file in the expected search path
# Find the file in the expected search path
# Find the file in the expected search path

# Generated at 2022-06-25 11:30:09.283159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ',`fD'
    str_1 = ':'
    str_2 = 'u\x0b>]'
    str_3 = '^z'
    dict_0 = {str_3: str_0, str_3: str_0, str_3: str_0, str_0: str_1, str_2: str_0}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(**dict_0)
    dict_1 = {str_2: str_0, str_1: str_1, str_0: str_0, str_3: str_0, str_3: str_1}
    var_0 = lookup_module_0.run(str_1, **dict_1)
    assert var_0 is list

# Generated at 2022-06-25 11:30:25.755387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'EQI>G'
    var_0 = lookup_run(str_0)
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    var_1 = lookup_run(str_0, **dict_0)



# Generated at 2022-06-25 11:30:36.973470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'relation_name'
    str_1 = '\x0cTfunvX'
    str_2 = '\rTfunvX'
    str_3 = '_s\n~AOe:N\x0cVm^}'
    str_4 = '\x0bTfunvX'
    str_5 = '_o\n~AOe:N\x0cVm^}'
    str_6 = '\x0eTfunvX'
    str_7 = '\x0fTfunvX'
    str_8 = '\nTfunvX'
    str_9 = 'relation_id'

# Generated at 2022-06-25 11:30:42.700462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)
# End of Unvault Tests

# Generated at 2022-06-25 11:30:52.554287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    # TypeError: run() missing 1 required positional argument: 'terms'
    lookup_module_0.run()
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)


# Generated at 2022-06-25 11:30:58.627033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';w&\x14'
    str_1 = 'var'
    str_2 = 'var'
    str_3 = 'var'
    list_0 = [str_3]
    var_0 = str_0
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(terms=list_0, var_options={str_1: var_0, str_2: var_0})
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:31:05.779461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(str_0, **dict_0)


# Generated at 2022-06-25 11:31:07.769021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    dict_1 = {}
    lookup_result = lookup_module_1.run(['example.yml'], **dict_1)
    assert lookup_result == ['value']

# Generated at 2022-06-25 11:31:15.415940
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test setting the display_skipped_hosts option to a real boolean value

    # Test the output when the lookup_module_0.run() method fails due to an exception
    display_0 = Display()
    display_0.verbosity = 2
    lookup_module_0.display = display_0
    lookup_module_0.runner = None

    # Test calling the run() method with a invalid file path
    lookup_module_0.run()

    # Test calling the run() method with a valid file path
    lookup_module_0.run()


# Generated at 2022-06-25 11:31:21.199993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run('term_0', **{})

if __name__ == '__main__':
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:31:26.740336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)

# Generated at 2022-06-25 11:31:46.470153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'is_producaon'
    str_1 = '23\x15\x07\x0b'
    str_2 = '|\x1c\n\n'
    list_0 = [str_1, str_0, str_2]
    dict_0 = {str_0: str_1, str_1: str_1, str_2: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([list_0, str_2], **dict_0)



# Generated at 2022-06-25 11:31:49.824298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'YzDp^_'
    dict_1 = {str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_1)


# Generated at 2022-06-25 11:31:57.172231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''

# Generated at 2022-06-25 11:32:06.174746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(str_0, **dict_0)

# Generated at 2022-06-25 11:32:11.709850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)

# Generated at 2022-06-25 11:32:18.667825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, **dict_0)

# Generated at 2022-06-25 11:32:23.452991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ')'
    str_1 = '|#E\'C(c`x]\n'
    str_2 = 'P:l!\r'
    str_3 = 'ER\r'
    dict_0 = {str_1: str_0, str_2: str_0, str_3: str_0, str_2: str_0}
    var_0 = lookup_run(str_0, **dict_0)


# Generated at 2022-06-25 11:32:24.364541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple test.
    test_case_0()



# Generated at 2022-06-25 11:32:29.014888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    lookup_module_0 = LookupModule()
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(str_0, **dict_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:32:35.741476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\rTfunvX'
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    list_0 = [str_0]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0, **dict_0)
    var_1 = lookup_run(str_0, **dict_0)

# Generated at 2022-06-25 11:33:10.715187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:33:15.061785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.find_file_in_search_path({}, 'files', 'unvault_test_case_0')
    lookup_module_0._loader.get_real_file('unvault_test_case_0', decrypt=True)
    lookup_module_0.run('unvault_test_case_0')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:33:19.364344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:33:20.011549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0()


# Generated at 2022-06-25 11:33:27.896466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_1 = dict()
    list_0 = list()
    str_0 = '6j;/D_0G\x0bY'
    str_1 = "p5n'`@f}y\x1c^^\x1d~"
    dict_0['_text'] = str_0
    dict_1['_raw'] = list_0
    dict_1['_text'] = str_0
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=dict_1, direct=dict_0)
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:33:30.212745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(**{})

# Generated at 2022-06-25 11:33:39.680197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '7\x00\x00\x00\x00\x00\x00\x08'
    str_0 = '\x1c\x1f\n\x0e'
    lookup_module_0 = LookupModule()
    x_0 = lookup_module_0.run(var_0)
    var_0 = 'k'
    str_1 = '\x1c\x1f\n\x0e'
    lookup_module_0 = LookupModule()
    x_0 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:33:42.995853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0 == lookup_run_result


# Generated at 2022-06-25 11:33:49.026014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\rTfunvX'
    dict_0 = {'reconnection_retries': str_0, '$_7\n~AOe:N\x0cVm^}': str_0, '\n#\x18\tG\x1a\x15\x1b\x1f\x1f\x15\x1d\x1c\x14\x0f\x18': str_0, '\rTfunvX': str_0}
    str_1 = '\rTfunvX'
    var_0 = lookup_module_0.run(**dict_0)

# Generated at 2022-06-25 11:33:57.308966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'd_data'

# Generated at 2022-06-25 11:35:36.691272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\x0b\x07ai/\x0f\t'
    index_0 = 0
    str_1 = 'v\x0b\x07ai/\x0f\t'
    str_2 = '\t\x19'
    str_3 = str_1 + str_2
    str_4 = str_0 + str_2
    str_5 = '\x0b\x07ai/\x0f\t\t\x19'
    str_6 = '\x0b\x07ai/\x0f\t'
    str_7 = '\x0b\x07ai/\x0f\t'
    str_8 = '\x0b\x07ai/\x0f\t'

# Generated at 2022-06-25 11:35:44.114910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'N?\n#\x0c-_O\x1f'
    str_1 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_1: str_0, str_1: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = []
    lookup_module_0.run(list_0, **dict_0)
    var_0 = lookup_module_0.run(list_1, **dict_0)


# Generated at 2022-06-25 11:35:48.985839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\rTfunvX'
    list_0 = []
    str_1 = 'reconnection_retries'
    str_2 = '$_7\n~AOe:N\x0cVm^}'
    dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(list_0, **dict_0)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:35:58.245788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {'$_7\n~AOe:N\x0cVm^}': '\rTfunvX', 'reconnection_retries': '\rTfunvX', '\rTfunvX': '\rTfunvX'}
    result_0 = lookup_module_0.run(['\rTfunvX'], **dict_0)
    assert result_0 == ['BQQAID\nAd:AOe:N\x0cVm^}']

# Generated at 2022-06-25 11:36:02.662494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_0 = LookupModule()
    str_0 = '/z{O#Xaaa'
    str_1 = 'reconnection_retries'
    str_2 = 'y\x1e'
    dict_0 = {str_1: str_2, str_2: str_2, str_2: str_0, str_0: str_0}
    LookupModule_0.run(str_0, **dict_0)



# Generated at 2022-06-25 11:36:09.262620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'j&'
    str_1 = 'function'
    str_2 = '\x0b'
    str_3 = '\x0c'
    str_4 = '\x0b\x0b\x0c'
    dict_0 = {str_1: str_2, str_2: str_3, str_3: str_4, str_4: str_0}
    lookup_module_0 = LookupModule()
    dict_0.items()
    dict_0.get(str_2)
    lookup_module_0.get_option(str_1)
    lookup_module_0.set_options(var_options=dict_0, direct=dict_0)

# Generated at 2022-06-25 11:36:12.161259
# Unit test for method run of class LookupModule
def test_LookupModule_run(): # testcase_id=None
    in_0 = 0
    out_0 = (1/in_0)
    #Test execution
    test_case_0()


# Generated at 2022-06-25 11:36:21.699500
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    list_0 = ['Sg>t#*', 'N{$[na@', '+\x17\x0bzH\r>~\r', '@O<G', '\rTfunvX', '^\x1f\x1bV\x06\x0f\x0c', 'T\x1e~$\x1e\rZ', '\x0cVm^}', 'reconnection_retries']

# Generated at 2022-06-25 11:36:27.163520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if (not ('actual_file' in vars())):
        lookup_module_0 = LookupModule()
        lookup_module_0._loader.get_real_file = lambda *args, **kwargs: None
        lookup_module_0.set_options = lambda *args, **kwargs: None
        lookup_module_0.find_file_in_search_path = lambda *args, **kwargs: None
        str_0 = '\rTfunvX'
        str_1 = 'reconnection_retries'
        str_2 = '$_7\n~AOe:N\x0cVm^}'
        dict_0 = {str_1: str_0, str_2: str_0, str_2: str_0, str_0: str_0}
        lookup_module_0

# Generated at 2022-06-25 11:36:33.852367
# Unit test for method run of class LookupModule