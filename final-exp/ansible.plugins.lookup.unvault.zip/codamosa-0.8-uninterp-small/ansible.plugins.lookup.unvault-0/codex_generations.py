

# Generated at 2022-06-25 11:27:21.003528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Obtain instance of an object
    lookup_module_0 = LookupModule()
    # Call the run of method under test
    # Pass in method parameters
    # assert output of method run equals expected output
    assert lookup_module_0.run('/etc/foo.txt') == ['bar']

# Generated at 2022-06-25 11:27:26.269754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(terms=['a', 'b'], variables={'a': 'b', 'c': 'd'}, **{'a': 1, 'b': 2}), list)


# Generated at 2022-06-25 11:27:28.237983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_0.run(['', '', '', ''])

# Generated at 2022-06-25 11:27:38.189269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test when there are no terms
    lookup_module_0 = LookupModule()
    # Verify condition where search_paths is empty
    assert [""] == lookup_module_0.run([], {'search_paths': []})
    # Verify the condition where search_paths has "string" as value
    assert [""] == lookup_module_0.run([], {'search_paths': "string"})
    # Verify the condition where search_paths has ["list", "of", "strings"] as value
    assert [""] == lookup_module_0.run([], {'search_paths': ["list", "of", "strings"]})

    # Test when there are terms
    # Verify the condition where no search path is specified
    lookup_module_0 = LookupModule()
    assert [""] == lookup_module_0.run

# Generated at 2022-06-25 11:27:41.732942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ansible_vars_0 = dict()
    terms_0 = ['foo.txt']
    result = lookup_module_0.run(terms_0, ansible_vars_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:27:47.760187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    file_path_1 = "/etc/foo.txt"
    lookup_module_1.run_1 = lambda terms, variables=None, **kwargs: lookup_module_1.run(terms, variables, **kwargs)
    lookup_module_1.run(file_path_1)


# Generated at 2022-06-25 11:27:55.403138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with a valid path
    terms = [
            '/etc/ansible/ansible.cfg',
            ]
    result = lookup_module.run(terms, None)
    assert len(result) > 0

# Run tests
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:04.781665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/foo.txt']
    var_options_0 = None
    lookup_module_0.set_options(var_options=var_options_0)
    run_0 = lookup_module_0.run(terms=terms_0)
    assert run_0 == ['foo is here\n']
    terms_1 = ['/etc/foo.txt']
    var_options_1 = None
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=var_options_1)
    run_1 = lookup_module_1.run(terms=terms_1)
    assert run_1 == ['foo is here\n']
    terms_2 = ['/etc/foo.txt']
    var_

# Generated at 2022-06-25 11:28:06.733323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    lookup_module_0._loader.get_real_file(lookupfile, decrypt=True)
    assert lookup_module_0.run(terms, variables=None, **kwargs) == ret

# Generated at 2022-06-25 11:28:08.222014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    assert lookup_module_1.run() == [], 'Empty List expected'

# Generated at 2022-06-25 11:28:14.501827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    params = [
        '',
    ]
    lookup_module_0.run(params)


# Generated at 2022-06-25 11:28:18.372717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    assert isinstance(lookup_module_run_0, LookupModule)
    lookup_module_run_1 = LookupModule()
    assert isinstance(lookup_module_run_1, LookupModule)



# Generated at 2022-06-25 11:28:25.418069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1_instance = lookup_module_1.run([u'example'])
    lookup_module_2 = LookupModule()
    lookup_module_2_instance = lookup_module_2.run([u'example'])
    lookup_module_3 = LookupModule()
    lookup_module_3_instance = lookup_module_3.run([u'example'])
    lookup_module_4 = LookupModule()
    lookup_module_4_instance = lookup_module_4.run([u'example'])
    lookup_module_5 = LookupModule()
    lookup_module_5_instance = lookup_module_5.run([u'example'])
    lookup_module_6 = LookupModule()


# Generated at 2022-06-25 11:28:30.976191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookupfile_lookup_module_run_1 = open('test/files/lookupfile_lookup_module_run', 'r')
    lookupfile_lookup_module_run_1_contents = lookupfile_lookup_module_run_1.read()
    lookupfile_lookup_module_run_1.close()

    lookup_module_1._loader.set_basedir('test/files')
    lookup_module_1._loader.makedirs('test/files/files')
    lookupfile_lookup_module_run_2 = open('test/files/files/lookupfile_lookup_module_run', 'w')
    lookupfile_lookup_module_run_2.write(lookupfile_lookup_module_run_1_contents)

# Generated at 2022-06-25 11:28:37.237363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(direct=dict())
    lookup_module_1._loader.mock_add_directory('./test/unittest_data/test_lookup_plugins/lookup_test_files')
    out = lookup_module_1.run(['lookup_test.txt'])
    assert out == ['lookup_test.txt\n']

# ansible-test units --python 2.7 --python 3 -v --allow-destructive --coverage tests/units/test_lookup_unvault.py

# Generated at 2022-06-25 11:28:40.842100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test variable_manager
    variable_manager = ["", "", ""]

    # test terms
    terms = ["", ""]

    # test variables
    variables = ""

    # run function
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 11:28:46.987238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_terms = ["1.txt", "2.txt"]
    test_file = [{"1.txt": "Message1"}, {"2.txt": "Message2"}]
    result = lookup_module.run(test_terms)
    assert result == test_file



# Generated at 2022-06-25 11:28:49.583079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for key error
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleParserError) as e:
        lookup_module_0.run([['test_data_0.txt']])



# Generated at 2022-06-25 11:28:50.404693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run("", {}) == []


# Generated at 2022-06-25 11:28:55.251706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(['/etc/passwd'])
    assert len(ret) > 0

# Generated at 2022-06-25 11:29:07.192061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-25 11:29:11.402968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize LookupModule
    lookup_module = LookupModule()
    # Get a terms for unit test
    terms = ('/etc/foo.txt',)
    # Invoke the run method
    ret = lookup_module.run(terms=terms)
    assert len(ret) > 0
    assert isinstance(ret, list)


if __name__ == '__main__':
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:15.326419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = (
        set(['/etc/foo.txt', 'Another thing']),
    )

    # test with a good file
    assert lookup_module_0.run(terms_0) == ['awesome\n']

    # test with a file that doesn't exist
    assert lookup_module_0.run(['/nonexistent_file']) == []

test_case_0()

# Generated at 2022-06-25 11:29:21.874109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with invalid type
    if isinstance(lookup_module_0.run([]), list):
        assert True
    else:
        assert False
    # Test with invalid type
    if isinstance(lookup_module_0.run(''), list):
        assert True
    else:
        assert False
    # Test with invalid type
    if isinstance(lookup_module_0.run(0), list):
        assert True
    else:
        assert False
    # Test with invalid type
    if isinstance(lookup_module_0.run({}), list):
        assert True
    else:
        assert False
    # Test with invalid type
    if isinstance(lookup_module_0.run(None), list):
        assert True

# Generated at 2022-06-25 11:29:32.281445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'_ansible_vault_password_file': 'my_password_file'})
    lookup_module.set_options(var_options=None)
    lookup_module.find_file_in_search_path = lambda x, y, z: 'test/files/test_1.yaml'
    lookup_module._loader.get_real_file = lambda x, decrypt: x
    with open('test/files/file_1', 'r') as f:
        expected_value = f.read()
    #Calling run
    ret = lookup_module.run(['/etc/foo.txt'])
    #Validating Assertion
    assert ret[0] == expected_value


# Generated at 2022-06-25 11:29:35.424307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:43.019525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()
    lookup_module_1._loader = None
    lookup_module_1._templar = None
    lookup_module_1._options = {'_ansible_lookup_plugins': {'convert': {'template': '{{prefix | default("\'")}}{0}{{suffix | default("\'")}}'}, 'lookup_type': 'template'}}

# Generated at 2022-06-25 11:29:45.929249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms = [''], extract_terms = 'test')

# Generated at 2022-06-25 11:29:51.126348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    assert lookup_module_0.run(['/etc/foo.txt']) == []


# Generated at 2022-06-25 11:29:53.595376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    for term in [ "file1", "file2" ]:
        display.debug("Testing term: %s" % term)
        lookup_module_run.run(term, variables = None)

# Generated at 2022-06-25 11:30:15.187516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing LookupModule object
    lookup_module = LookupModule()

    assert lookup_module.run(["vault.yml"], []) == [u'$ANSIBLE_VAULT;1.1;AES256\n"some unvaulted text"\n']

# Generated at 2022-06-25 11:30:16.149130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


# Generated at 2022-06-25 11:30:27.055818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'_ansible_verbosity': 0})
    test_path = "tests/fixtures/lookup_plugins/source/unvault_file.yml"

    actual_path = lookup_module.run([test_path])[0]
    expected_path = "bar\n"
    assert actual_path == expected_path

    lookup_module.set_options({'_ansible_verbosity': 0})
    test_path = "tests/fixtures/lookup_plugins/source/unvault_file.txt"

    actual_path = lookup_module.run([test_path])[0]
    expected_path = "bar\n"
    assert actual_path == expected_path

# Generated at 2022-06-25 11:30:33.635577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._loader = FakeVaultLoader()
    lookup_module_1._loader.set_data("file.txt", b"File data")

    result = lookup_module_1.run(["file.txt"])
    assert len(result) == 1
    assert result[0] == "File data"



# Generated at 2022-06-25 11:30:38.516676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = (
        [
            "/tmp/foo.txt",
            "/tmp/bar.txt"
        ],
        dict()
    )
    kwargs = dict()
    ret = LookupModule().run(terms=args[0], variables=args[1], **kwargs)
    assert len(ret) == 2
    assert ret[0] == "foo\n"
    assert ret[1] == "bar\n"


# Generated at 2022-06-25 11:30:41.581111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Sample data, not really used in the execution of this module
    terms = ['foo']
    variables = {}
    kwargs = {}
    display.vvvv = True

    # Invoke LookupModule.run with our sample data
    result = lookup_module_0.run(terms, variables, **kwargs)

    # Confirm we got back the expected result
    # assert result == expected_result

# Generated at 2022-06-25 11:30:42.273913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule().run()

# Generated at 2022-06-25 11:30:50.354119
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = [["/some/path/foo.txt"]]
    kwargs = {"extensions": [''], "basedirs": ['/some/path']}
    mock_terms = Mock(spec=args)

    lookup_module_runtest = LookupModule()

    lookup_module_runtest.run(mock_terms, kwargs)
    assert mock_terms.called



# Generated at 2022-06-25 11:30:55.927692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u'']
    variables = {u'ansible_cwd': ''}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=terms, variables=variables) == []

# Generated at 2022-06-25 11:31:03.904292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the params
    lookup_module = LookupModule()
    terms = ["ansible.cfg"]
    variables = None
    kwargs = {"csv_delimiter": ",", "delimiter": ","}

    # read the file ansible.cfg and return the content in terms list
    try:
        lookup_module.run(terms, variables, **kwargs)
    except AnsibleParserError:
        assert False, "Unable to find file"

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:31:42.318637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['hostname']
    expected_0 = 'controller'
    actual = lookup_module_0.run(terms=terms_0)
    assert actual == expected_0, "Test failed. Expected: {}, Actual: {}".format(expected_0, actual)


# Generated at 2022-06-25 11:31:52.483519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_vars_0 = {}

    my_vars_0["lookupfile"] = "/etc/foo"
    my_vars_0["lookupfile_path"] = ["/etc"]

    my_vars_0["lookupfile_1"] = "/etc/bar"
    my_vars_0["lookupfile_path_1"] = ["/etc"]

    my_vars_0["lookupfile_2"] = "foo.txt"
    my_vars_0["lookupfile_path_2"] = ["."]

    my_vars_0["lookupfile_3"] = "/etc/myvault.yml"
    my_vars_0["lookupfile_path_3"] = ["/etc"]

    lookup_module_

# Generated at 2022-06-25 11:31:58.765009
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up test vars
    terms_0 = ['/etc/hosts']
    terms_1 = []
    terms_2 = ['/etc/hosts', '/etc/passwd']
    terms_3 = ['/etc/hosts']
    terms_4 = []
    terms_5 = []
    terms_6 = ['notexistingfile']
    terms_7 = ['/etc/hosts']
    variables_0 = None
    variables_1 = {u'inventory_dir': u'/etc/ansible/hosts'}
    variables_2 = {u'inventory_dir': u'/etc/ansible/hosts'}
    variables_3 = {u'inventory_dir': u'/etc/ansible/hosts'}

# Generated at 2022-06-25 11:32:03.862073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_name = 'None'
    param0 = ['fake_file.txt']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(param0) == ['fake_file_contents']

test_LookupModule_run()

# Generated at 2022-06-25 11:32:12.101838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()

# Generated at 2022-06-25 11:32:18.891190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['test']
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms)
    assert result == []


# Generated at 2022-06-25 11:32:19.404073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 11:32:20.190674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 11:32:23.734215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with a valid argument
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=[u'file1.txt'])

    # Test with an invalid arguemnt
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=[u'file2.txt'])

# Generated at 2022-06-25 11:32:24.141723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:33:06.042928
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup test data
    terms = ['terms']
    variables = [None]
    kwargs = {'kwargs': 'kwargs'}

    # create the class
    LookupModule_class_instance = LookupModule()
    result = LookupModule_class_instance.run(terms, variables, **kwargs)

    assert result == None


# Generated at 2022-06-25 11:33:13.793270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with str argument
    str_0 = '6\x1c;\x1c\x3cD\x10\x1c\x1c\x1c\x1c\x1c\x1c\x1c\x1c\x1c\x1c\x1c\x1c\x1c'
    lookup_module_0 = LookupModule(str_0)
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    lookup_module_0.run(dict_0)

    # Test with dict argument
    dict_1 = {str_0: lookup_module_0, str_0: dict_0}
    lookup_module_0.run(dict_1)



# Generated at 2022-06-25 11:33:18.368831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run is not None


# Generated at 2022-06-25 11:33:22.800794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('x'*1073741824)
    with pytest.raises(AnsibleParserError):
        lookup_module_0.run(set(), dict())


# Generated at 2022-06-25 11:33:25.844442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0()
    test_LookupModule_run_1()
    test_LookupModule_run_2()


# Generated at 2022-06-25 11:33:34.102683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = FakeModule

    file_0 = open('C:\\pm-collection\\collection\\ansible_collections\\ncr\\nc_secure\\plugins\\lookup\\unvault.py', 'w')
    file_0.write(str_0)
    type_0 = type('FakeModule', tuple_0, dict_0)
    ansible.module_utils.basic.AnsibleModule = type_0
    str_1 = ';l\x0cK@61\\2f\x0c5\n"'
    lookup_module_0 = LookupModule(str_1)
    set_0 = {str_1, str_1}

# Generated at 2022-06-25 11:33:39.408332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    set_0 = {str_0, str_0}
    dict_0 = {str_0: set_0, str_0: lookup_module_0}
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(dict_0)

# Generated at 2022-06-25 11:33:48.757851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    searchpath = 'tests/fixtures/vault'
    try:
        lookup_module_0 = LookupModule()
    except AttributeError:
        print('AttributeError raised')
        True
    else:
        print('AssertionError not raised')
        print('test #1 failed')
        assert(False)
    try:
        lookup_module_1 = LookupModule(searchpath)
    except AttributeError:
        print('AttributeError raised')
        True
    else:
        print('AssertionError not raised')
        print('test #2 failed')
        assert(False)
    try:
        lookup_module_2 = LookupModule(searchpath)
    except AttributeError:
        print('AttributeError raised')
        True
    else:
        print('AssertionError not raised')
        print

# Generated at 2022-06-25 11:33:49.584239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:33:57.917270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    input_0 = """<ansible.plugins.lookup.unvault.LookupModule object at 0x7f0e24e7ed10>"""

# Generated at 2022-06-25 11:35:39.721217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # If called with unsupported params, failed assertion is expected
    lookup_module_0 = LookupModule()
    str_0 = 'lkfj%c\x00\x141\x00\n'
    try:
        lookup_module_0.run(str_0)
        return
    except AssertionError:
        assert True
    except:
        assert False
    else:
        assert True
    try:
        lookup_module_0.run(str_0, str_0)
        return
    except AssertionError:
        assert True
    except:
        assert False
    else:
        assert True
    try:
        lookup_module_0.run(str_0, str_0, str_0)
        return
    except AssertionError:
        assert True

# Generated at 2022-06-25 11:35:43.545696
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    str_0 = '\x19\t\rz\x03H\\\x18\x1f\x0b:'
    set_0 = {str_0}
    dict_0 = {str_0: set_0}
    var_0 = lookup_run(dict_0)
    lookup_module_0.run(var_0)



# Generated at 2022-06-25 11:35:49.601557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'J0\x13'
    lookup_module_0.run(str_0)
    str_1 = ':$\x01K?[8\x0b\x1c'
    lookup_module_0.run(str_1)
    str_2 = 'n\x03\x16'
    lookup_module_0.run(str_2)
    str_3 = 'u\x0c\x11'
    lookup_module_0.run(str_3)
    str_4 = 'V*\x1e'
    lookup_module_0.run(str_4)
    str_5 = '\x0cW9\x15'
    lookup_module_0.run(str_5)
    str_

# Generated at 2022-06-25 11:35:58.347390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('7')
    dict_0 = {'v\x0c': lookup_module_0, '\x0c\n': lookup_module_0}
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule('9Q')
    dict_0 = {'\x0c\n': lookup_module_1, '\x0c\n': lookup_module_1}
    var_0 = lookup_run(dict_0)
    lookup_module_2 = LookupModule()
    dict_0 = {'\x0c\n': lookup_module_2, '\x0c\n': lookup_module_2}
    var_0 = lookup_run(dict_0)


# Generated at 2022-06-25 11:36:07.491605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()
    # Stub to return True
    def stub_find_file_in_search_path(variables, str_0, term):
        return True
    lookup_module.find_file_in_search_path = stub_find_file_in_search_path
    lookup_module.run()
    # Stub to return None
    def stub_Unvault_get_real_file(lookupfile, decrypt):
        return None
    lookup_module._loader.get_real_file = stub_Unvault_get_real_file
    lookup_module.run()
    # Stub to return False
    def stub_find_file_in_search_path(variables, str_0, term):
        return False
    lookup_module.find_file_in_

# Generated at 2022-06-25 11:36:15.014299
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_0 = ']\x18\x0b'
    lookup_module_0 = LookupModule()
    list_0 = []
    str_1 = '\n\x07'
    str_2 = 'F\x0e\x01'
    dict_0 = {str_0: list_0, str_1: str_2, str_2: lookup_module_0}
    var_0 = lookup_run(dict_0)


# Generated at 2022-06-25 11:36:20.604866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';l\x0cK@61\\2f\x0c5\n"'
    lookup_module_0 = LookupModule(str_0)
    set_0 = {str_0, str_0}
    dict_0 = {str_0: set_0, str_0: lookup_module_0}
    lookup_module_1 = LookupModule()
    lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:36:28.877299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t_0 = [None, None]
    t_1 = {}
    t_2 = LookupModule()
    t_3 = t_2.run(t_0, t_1)

test_LookupModule_run()

test_case_0()

# Generated at 2022-06-25 11:36:37.574046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';l\x0cK@61\\2f\x0c5\n"'
    lookup_module_0 = LookupModule(str_0)
    set_0 = {str_0, str_0}
    dict_0 = {str_0: set_0, str_0: lookup_module_0}
    var_0 = lookup_run(dict_0)
    assert var_0 == [u'foo\n']
    lookup_module_1 = LookupModule()
    str_1 = '\x0c'
    assert str_1 != '\x0c'
    assert str_1 == '\x0c'
    str_2 = 'y\n'
    assert str_2 != 'y\n'
    assert str_2 == '\x0c'
    str

# Generated at 2022-06-25 11:36:46.336056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'k\x1b\x11\x0c\x0f'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_module_0.run()
    str_1 = '\x1b\x11\x0c\x0f'
    var_1 = lookup_module_0.run(str_1)
    str_2 = '\x11\x0c\x0f'
    var_2 = lookup_module_0.run(str_2)
    str_3 = '\x0c\x0f'
    var_3 = lookup_module_0.run(str_3)
    str_4 = '\x0f'
    var_4 = lookup_module_0.run(str_4)
    var_