

# Generated at 2022-06-25 11:27:23.909221
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    actual = lookup_module.run(['unvault_test_file.yml'])

    expected = [u"{'a': ['foo', 'bar']}"]

    assert(expected == actual)


# Unit test to ensure good diagnostic is thrown when file is missing or encrypted

# Generated at 2022-06-25 11:27:30.172230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt']
    variables = [{}]
    assert lookup_module.run(terms) == "foo"


# Generated at 2022-06-25 11:27:37.613347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    x = lookup_module_0.run(terms_0)
    print(x)
    terms_0 = []
    x = lookup_module_0.run(terms_0)
    print(x)
    terms_0 = [None]
    x = lookup_module_0.run(terms_0)
    print(x)


# Generated at 2022-06-25 11:27:40.959107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        test_case_0()
        res = lookup_module_0.run(terms, variables=variables, **kwargs)
    except Exception as e:
        res = e.args[0]
    assert isinstance(res, list)

# Generated at 2022-06-25 11:27:41.446159
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True



# Generated at 2022-06-25 11:27:49.158045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(None)
    lookup_module_0._loader = None
    lookup_term_list_0 = []
    lookup_variable_dict_0 = {}
    lookup_direct_dict_0 = {}
    lookup_result_list_0 = lookup_module_0.run(lookup_term_list_0, lookup_variable_dict_0, **lookup_direct_dict_0)
    assert lookup_result_list_0 == []


# Generated at 2022-06-25 11:27:51.771849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
     lookup_module_0 = LookupModule()
     terms = ['testcase']
     variables = None
     kwargs = {}
     assert lookup_module_0.run(terms, variables, **kwargs) == []

# Generated at 2022-06-25 11:27:54.038620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=['/etc/motd'])

# Generated at 2022-06-25 11:28:03.841688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/etc/foo.txt']
    variables_1 = None
    lookup_module_1.run(terms_1, variables_1)

    lookup_module_2 = LookupModule()
    terms_2 = ['/etc/foo.txt']
    variables_2 = None
    lookup_module_2.run(terms_2, variables_2)

    lookup_module_3 = LookupModule()
    terms_3 = ['/etc/foo.txt']
    variables_3 = None
    lookup_module_3.run(terms_3, variables_3)

test_LookupModule_run()

# Generated at 2022-06-25 11:28:12.326500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    search_path = "."
    lookup_file = lookup_module_1.find_file_in_search_path(search_path, 'files', "./readme.md")
    if lookup_file:
        print(lookup_file)
        actual_file = lookup_module_1._loader.get_real_file(lookup_file, decrypt=True)
        with open(actual_file, 'rb') as f:
            b_contents = f.read()
        print(to_text(b_contents))

# Generated at 2022-06-25 11:28:21.827764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == []

# Generated at 2022-06-25 11:28:23.097645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = c(lookup_module_0.run)



# Generated at 2022-06-25 11:28:29.388326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # int_0 = -2538
    # bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    # var_0 = lookup_run(int_0, bytes_0)
    pass

# import unittest
# class Test_LookupModule(unittest.TestCase):
#     def test_LookupModule_run(self):
#         lookup_module_0 = LookupModule()
#         int_0 = -2538
#         bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t

# Generated at 2022-06-25 11:28:35.504469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2499
    bytes_0 = b'\x1d\x11b\xf8\x16\x0b\x86\x90\x02x\x07\xc0\x06\x97y\x0c\x17O\x94\xe9\x1f\x1c\x92\xac\x0e\x10\x1b'
    var_0 = lookup_run(int_0, bytes_0)


# Generated at 2022-06-25 11:28:40.384278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    assert lookup_module_0.run(int_0, bytes_0) == []

# Generated at 2022-06-25 11:28:51.281132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1192
    bytes_0 = b'\xe9\x1b\x8a\xba\xa7w\xa6\x06\x93#\x1a\x1b\x9a\xab\xca\xfa\x82\x80\xde\xe8\x89\x9c\x9f\x1f'
    if (lookup_module_0._local.module_loader.module_cache.get(int_0) is None):
        lookup_module_0.fail_json(int_0)
    lookup_module_0.fail_json(lookup_module_0.want_bytes())

# Generated at 2022-06-25 11:28:55.823040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(test_case_0())
    print('Passed!')

# Generated at 2022-06-25 11:29:02.128922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    def test_function():
        # No exception.
        lookup_module_0.run(int_0, bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:29:06.571858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_1 = -5717
    bytes_1 = b'\xc8\xe4\xea\xfd\x91\xb0\x9b\xe1\x80\x89\x8d,\xd8\x0e\xba\xd3\xf6\xe9\x1c\xa3\x96k\x00'
    var_1 = lookup_run(int_1, bytes_1)


# Generated at 2022-06-25 11:29:12.061420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = mock.MagicMock(spec=None, side_effect=None)
    var_0 = mock.MagicMock(spec=None, side_effect=None)
    var_0 = test_LookupModule_run_exp(lookup_module_0, var_0)



# Generated at 2022-06-25 11:29:22.624810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    assert var_0 is None
    int_0 = 613
    bytes_0 = b'\x12.\x9f\x9a\x0f\xe7\xbc\xb6\xdf\xca\x8b\x05\t\x9b\xcd\x8b\x10\x16f\xfb\xe8\x10'

# Generated at 2022-06-25 11:29:29.549297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    assert var_0 == None


# Generated at 2022-06-25 11:29:35.162612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:29:42.909113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('foo')
    var_2 = lookup_module_0.run([])
    if (not (var_0 == var_2)):
        assert 0
    var_4 = lookup_module_0.run(['bar'])
    if (not (var_0 == var_4)):
        assert 0
    var_5 = lookup_module_0.run('foo')
    if (not (var_0 == var_5)):
        assert 0
    var_6 = lookup_module_0.run(['foo'])
    if (not (var_0 == var_6)):
        assert 0
    var_7 = lookup_module_0.run([['foo'], ['bar']])
    assert var_7

# Generated at 2022-06-25 11:29:44.949462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.run(['lookupfile'])


# Generated at 2022-06-25 11:29:55.653755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)


# Generated at 2022-06-25 11:29:57.127894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'ABCD' == lookup_module_0.run(int_0, bytes_0)

# Generated at 2022-06-25 11:30:01.560744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_s = LookupModule()
    int_s = -2538
    bytes_s = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_s = lookup_module_s.run(int_s, bytes_s)
    assert len(var_s) == 1, "return value number mismatch: actual:%d expected:%d" % (len(var_s), 1)

# Generated at 2022-06-25 11:30:04.785061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:30:09.210419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}

# Generated at 2022-06-25 11:30:23.857176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:30:30.547915
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_case_0(self):

        def test_case_0(self):

            def test_case_0(self):

                def test_case_0(self):

                    def test_case_0(self):

                        def test_case_0(self):

                            def test_case_0(self):
                                lookup_run(var_0, var_0)

                            def test_case_1(self):
                                lookup_run(var_0, int_0)

                            def test_case_2(self):
                                lookup_run(var_0, float_0)

                            if len(var_0) >= 7:
                                test_case_0(self)
                            if len(var_0) >= 7:
                                test_case_1(self)

# Generated at 2022-06-25 11:30:39.960250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = 'X\x1b\x95\x0b\xbd\xfa\xbe\xbe\x17C&\x13'
    str_1 = '\x1a\xce\xfb\xe0\x85\xfe\xd8\x9f\x87\xe4\x1e\x96'
    bytes_0 = b'\x8f\x93g\xc1\x83\xd2\xb7|\x93\x92\x87\x07d\x16\xc9\x92\xb7\x84z\x8b\xfe\x1a'

# Generated at 2022-06-25 11:30:45.292209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_1 = -267
    bytes_1 = b'\xbb\xd7\xbe\xa1\x10\x04\x1d\x97\x00\xa3\x9b\x9c\xdb\xf4\xc0\xdd\xf5\x1d\xba\x9e9\x1f\x81'
    var_1 = lookup_run(int_1, bytes_1)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:30:48.385976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms = ['/etc/foo.txt']
    test_variables = {}
    assert test_terms == lookup_module_0.run(test_terms, test_variables)

# Generated at 2022-06-25 11:30:51.641610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        int_0 = -2538
        bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
        var_0 = lookup_run(int_0, bytes_0)
    except Exception:
        print('Exception: ' + str(Exception))
        assert False


# Generated at 2022-06-25 11:30:56.411509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -43840
    bytes_0 = b"LookupModule.run"
    var_0 = lookup_run(int_0, bytes_0)
    return var_0


# Generated at 2022-06-25 11:30:59.524549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:31:07.718460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -1557
    list_0 = [b'\xbb0\x9c\x8aF\xaa\x1f\x1a\x80\xc7\xda\x14\xd9\x83\xbc\xdc\x98\xa4\xb5\xdf', b'\x87\xa2\x9f\x8e\xbd\x98@\xe4\xc8\x0e\x042\xde\x9c\x8e\xda\x1f\xc1\x80\xf6\xec']
    var_0 = lookup_run(int_0, list_0)


# Generated at 2022-06-25 11:31:12.794288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)


# Generated at 2022-06-25 11:31:36.518248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:31:42.948068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # call run:
    # test_case_0
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)


# Generated at 2022-06-25 11:31:53.012361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2493

# Generated at 2022-06-25 11:31:59.012649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -4095

# Generated at 2022-06-25 11:32:09.538060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '`'
    int_0 = 19182
    b_0 = b'\x03\xee\xce\x10\x8e\xa1\x14\x1d\x95\x8c\x99\xca\x06\x86'
    var_0 = lookup_run(str_0, int_0, b_0)
    bytes_0 = b'\xe2\xdd\xc2\x0f\x08\x93\xd0\xfa\x1b\xed\xbe\xc5\x15\xaa'
    var_1 = lookup_run(bytes_0, str_0)
    str_1 = '@\xcb\x06\x7fqX\xe4'

# Generated at 2022-06-25 11:32:19.744749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj_0 = test_LookupModule()
    scope_0 = {}

# Generated at 2022-06-25 11:32:21.256845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'z'
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:32:26.780648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\x1a\x1f\x06j\xb0$\x1c\x81x?\x06\xcb\xe0'
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 11:32:36.586868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_1 = -2538
    bytes_1 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_1 = lookup_run(int_1, bytes_1)
    assert type(var_1) == type(True)
    assert var_1 == -2538
    lookup_module_2 = LookupModule()
    int_2 = -2538
    bytes_2 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_

# Generated at 2022-06-25 11:32:39.778562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:33:17.360824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    lookup_module_0 = LookupModule()
    var_0 = test_LookupModule_run(int_0, bytes_0)


# Generated at 2022-06-25 11:33:19.244553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run")
    lookup_module_run = LookupModule()
    lookup_module_run.run(terms)


# Generated at 2022-06-25 11:33:25.227610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = 'B'
    str_1 = 'l'
    str_2 = '\''
    str_3 = 'T'
    str_4 = 'q'
    str_5 = 'u'
    str_6 = '='
    str_7 = 'f'
    str_8 = 'g'
    str_9 = 'o'
    str_10 = '4'
    str_11 = '`'
    str_12 = 'S'
    str_13 = 'd'
    str_14 = 'U'
    str_15 = 'X'
    str_16 = 'C'
    str_17 = 'W'
    str_18 = 'K'
    str_19 = '#'
    str_20 = 'm'

# Generated at 2022-06-25 11:33:27.949324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms, **kwargs) == var_0


# Generated at 2022-06-25 11:33:30.377415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = create_lookup_module_()
    lookup_module_0.run()


# Generated at 2022-06-25 11:33:39.274451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    lookup_module_0.run(list_0)
    list_1 = []
    lookup_module_0.run(list_1)
    list_2 = []
    lookup_module_0.run(list_2)
    list_3 = []
    lookup_module_0.run(list_3)
    list_4 = []
    lookup_module_0.run(list_4)


# Generated at 2022-06-25 11:33:43.570633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path_0 =  lookup_module_0.run(int_0, bytes_0)
    assert path_0 == var_0

# Generated at 2022-06-25 11:33:50.391340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_module_0.run(int_0, bytes_0)
    assert var_0 == ['ansible']

# Generated at 2022-06-25 11:33:54.574216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    constants_0 = constants()
    int_0 = -2538
    str_0 = str(204)
    assert len(str_0) < int_0
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    # Replace with mock
    # constants_0.message(var_0)


# Generated at 2022-06-25 11:33:57.210052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_0 = LookupModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        lookup_instance_0.run(int_0)
    assert 'Unable to find file matching "-2538" ' in str(excinfo.value)


# Generated at 2022-06-25 11:35:35.891638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_module_0.run(int_0, bytes_0)
    var_1 = lookup_module_0.run(int_0, bytes_0)


if __name__ == '__main__':
    test_case_0()
else:
    pass

# Generated at 2022-06-25 11:35:42.183833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:35:47.349904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    assert var_0 == False

# Generated at 2022-06-25 11:35:55.407580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:36:01.223064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    int = -2538
    bytes = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    lookup_run(int, bytes)

# Generated at 2022-06-25 11:36:13.186327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_0 = lookup_run(int_0, bytes_0)
    lookup_module_0.run(var_0, '\x88\xd0\x84', '\xa5\x13\xe5:W\xae', '\x80\xe2\xbe')
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:36:22.132561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -2538
    int_1 = -2538
    bytes_0 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    int_2 = -2538
    int_3 = -2538
    bytes_1 = b'\xc0\xf6\xe0\x1c\xae\x1e!\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    int_4 = -2538
    int_5 = -2538

# Generated at 2022-06-25 11:36:30.540142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = -2538
    string_0 = "f\x86m\xc9\x9c\x9f\x9bbs\xbc\xf7\xbc\x80\xbcw\xbc\xc0\xbc\xe0\xbc"
    class_0 = LookupModule()
    var_2 = lookup_run(var_0, string_0)
    assert var_2 == class_0.run(var_0, string_0)


# Generated at 2022-06-25 11:36:33.625997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_1 = -2539
    bytes_1 = b'\xc0\xf6\xe0\x1c\xae\x1e"\xf5pF\xb4t\xc3b\x9c\xc9\x86W-D'
    var_1 = lookup_run(int_1, bytes_1)


# Generated at 2022-06-25 11:36:36.560346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # there are no assertions for this method
    return
