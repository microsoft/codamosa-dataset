

# Generated at 2022-06-25 11:27:24.555522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print(result)


# Generated at 2022-06-25 11:27:29.819485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = {}
    lookup_module_run_0['lookup_type'] = 'unvault'
    lookup_module_run_0['wantlist'] = False
    lookup_module_run_0['terms'] = 'sample text'

    ret = lookup_module_run_0['self'].run(lookup_module_run_0['terms'], wantlist=False)

# Generated at 2022-06-25 11:27:41.037196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = {'verbosity': 0, 'inventory': 'localhost,'}
    loader = DataLoader()
    passwords = {}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 11:27:43.140543
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:27:49.070686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Params
    lookup_terms = 'ElDorado'
    lookup_variables = 'hero_of_the_day'
    lookup_kwargs = 'Yes, this is a test'
    lookup_module_1 = LookupModule()
    lookup_module_1.run(lookup_terms, lookup_variables, **lookup_kwargs)

# Generated at 2022-06-25 11:27:56.907826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = '/etc/foo.txt'
    dict_0_0 = {}
    dict_0_0['direct'] = dict_0_0
    dict_0_0['var_options'] = dict_0_0
    term = [str_0]
    try:
        assert lookup_module_0.run(term, variables=dict_0_0) == ['test\n']
    except:
        display.debug("test_LookupModule_run failed")


# Generated at 2022-06-25 11:27:59.445191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    r_0 = lookup_module_0.run([""], {})
    assert r_0 == []

# Generated at 2022-06-25 11:28:00.334191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    assert lookup_module_0.run(['foo']) == []



# Generated at 2022-06-25 11:28:04.816196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    # AssertionError: list index out of range
    with pytest.raises(AssertionError):
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:28:06.011529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:28:14.917545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[u'test_terms_0'], variables={u'test_variables_0': u'test_variables_0'}, test_kwargs_0=u'test_test_kwargs_0')

# Generated at 2022-06-25 11:28:21.856062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['foo', 'bar']
    variables_1 = {}
    kwargs_1 = {'_ansible_check_mode': False, '_ansible_debug': True, '_ansible_diff': False}
    lookup_module_1.run(terms_1, variables_1, **kwargs_1)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:23.353503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.run([['/etc/foo.txt']])


# Generated at 2022-06-25 11:28:27.972941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    run_args = {'terms': ['/etc/foobar'], }
    run_kwargs = {'variables': {u'foo': {'bar': {u'faz': u'baz'}, 'qux': u'quux'}, u'from': u'geuze'}, }
    result = lookup_module_0.run(**run_args, **run_kwargs)
    assert isinstance(result, object)
    assert result == [u'foo']

# Generated at 2022-06-25 11:28:32.265308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    try:
        result = lookup_module_0.run(terms_0)
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 11:28:39.742725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/etc/foo.txt']
    variables_1 = None
    data_1 = {'encrypt_string': False}
    actual_result_1 = lookup_module_1.run(terms_1, variables_1, **data_1)
    expected_result_1 = ['This is my secret file']
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-25 11:28:43.184217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if 0:  # noqa # Using `assert_raises` or `pytest.raises` will remove the stacktrace
        assert_raises(AnsibleParserError, lookup_module_0.run)
    with pytest.raises(AnsibleParserError, match="Unable to find file matching"):
        lookup_module_0.run()

# Generated at 2022-06-25 11:28:46.987703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    assert True
  except AssertionError:
    display.error('AssertionError > skipped %s' % traceback.format_exc())
    pytest.skip(traceback.format_exc())


# Generated at 2022-06-25 11:28:49.549025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["../tests/files/foo.txt"]) == ['value of foo']
    assert lookup_module.run(["../tests/files/bar.txt"]) == ['bar']
    assert lookup_module.run(["./foo.txt"]) == ['']
    assert lookup_module.run(["./bar.txt"]) == ['value of foo']


# Generated at 2022-06-25 11:28:56.377670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.get_basedir = lambda: 'Ansible/ansible/plugins/lookup/unvault.py'
    lookup_module_1.find_file_in_search_path = lambda a, b, c: '/etc/foo.txt'
    lookup_module_1._loader = 'AnsibleLoader'
    lookup_module_1._loader.get_real_file = lambda a, b: '/etc/foo.txt'
    assert lookup_module_1.run(terms=['/etc/foo.txt'], variables={'files': []}) == [b"test2\n"]

# Generated at 2022-06-25 11:29:04.678803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None, None)
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.find_file_in_search_path(var_options=None, direct=None, term='/etc/foo.txt')
    lookup_module_0._loader.get_real_file('/etc/foo.txt', decrypt=True)
    bool_0 = False
    lookup_module_0.run(['/etc/foo.txt'], variables=bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:29:09.459612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_module_0.run(bool_0)


# Generated at 2022-06-25 11:29:15.761638
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:29:18.991353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    str_0 = "Q0VSRQo=\n"
    test_var = lookup_module_0.run(str_0)
    assert test_var == "COBRA\n"

# Generated at 2022-06-25 11:29:23.627636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 11:29:29.510024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup for test_case_0
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_run(bool_0)

    # Assertions on method run of class LookupModule
    assert var_0 == 'bar'

# Generated at 2022-06-25 11:29:32.244402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    bool_0 = None
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_0, float_0)
    lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:29:38.399492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    int_0 = 0
    int_1 = 0
    str_0 = "|"
    str_1 = "|"
    str_2 = "|"
    str_3 = "|"
    str_4 = "|"
    lookup_module_0.run(int_0, int_1, str_0, str_1, str_2, str_3, str_4)

# Generated at 2022-06-25 11:29:41.677932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [None]
    variables = [None]
    lookup_module_0 = LookupModule()
    actual_return_value_0 = lookup_module_0.run(terms, variables)
    assert actual_return_value_0 == [], "Return value did not match expected value"

# Generated at 2022-06-25 11:29:49.217449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 810.1366
    lookup_module_0 = LookupModule(bool_0, float_0)
    var_0 = ['unvault']
    var_1 = None
    var_2 = {'arg1': var_0, 'arg2': var_1, }
    try:
        result_0 = lookup_module_0.run(var_2, var_1)
    except Exception:
        raise
    else:
        assert True


# Generated at 2022-06-25 11:29:57.126586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = True
    float_0 = 5.8
    lookup_module_0 = LookupModule(bool_1, float_0)
    test_case_0()


# Generated at 2022-06-25 11:30:01.360523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    int_0 = lookup_module_0.run(bool_0)


# Generated at 2022-06-25 11:30:07.415271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_module_0.run(bool_0)

if __name__ == "__main__":
    print("Unsupported")

# Generated at 2022-06-25 11:30:15.441926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    terms_0 = []
    bool_0 = False
    test_case_0(bool_0)
    lookup_module_0.run(terms_0)
    lookup_module_0.run(terms_0)
    lookup_module_0.run(terms_0)
    lookup_module_0.run(terms_0)
    lookup_module_0.run(terms_0, False)
    lookup_module_0.run(terms_0, False)
    lookup_module_0.run(terms_0, False)
    lookup_module_0.run(terms_0, False)
    lookup_module_0.run(terms_0)
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:30:27.057029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = False
    float_0 = 1228.34
    lookup_module_0 = LookupModule(bool_0, float_0)
    var_0 = [16.69, 321.54, 759.85, 571.6, 645.27, 982.33, 452.82, 665.38, 585.22, 594.88]
    var_1 = [487.9, 293.04, 34.18, 441.73, 699.52, 515.93, 63.76, 583.56, 244.44, 981.56]

# Generated at 2022-06-25 11:30:28.313602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert true # TODO: implement your test here


# Generated at 2022-06-25 11:30:34.072938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Call method run of lookup_module_0 with the arguments:
    #    terms =
    #    variables =
    #    kwargs =

# Generated at 2022-06-25 11:30:38.899783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    str_0 = '0g`y9M'
    var_0 = lookup_module_0.run(str_0)
    assert var_0 is None

# Generated at 2022-06-25 11:30:39.725550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:30:43.075685
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    bool_0 = True
    float_0 = -1335.49
    lookup_module_0 = LookupModule(bool_0, float_0)
    var_0 = None
    var_1 = lookup_module_0.run(var_0)
    assert var_1 is None


# Generated at 2022-06-25 11:30:53.634607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()




# Generated at 2022-06-25 11:30:55.675528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    assert isinstance(lookup_module_0.run(bool_0), list)


# Generated at 2022-06-25 11:31:01.027433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "X"
    bool_0 = False
    dict_0 = dict()
    dict_0['__model__'] = str_0
    dict_0['__obj__'] = str_0
    dict_0['__secret__'] = bool_0
    dict_0['__stack__'] = list()
    dict_0['__stack__'].append(str_0)
    dict_0['__stack__'].append(int_0)
    dict_0['__stack__'].append("Y")
    dict_0['__stack__'].append("h")
    dict_0['__stack__'].append("g")
    dict_0['__stack__'].append("m")
    dict_0['__stack__'].append("e")

# Generated at 2022-06-25 11:31:07.075083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(any_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 11:31:16.084940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = 'unvault'
    file_0 = 'dir/file1.txt'
    file_1 = 'dir/file2.txt'
    lookup_module_0 = LookupModule(module_0, file_0, file_1)
    lookup_module_1 = LookupModule('bar', 'foo')
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_2 = LookupModule(bool_1, float_0)
    var_0 = lookup_run(bool_0)
    lookup_module_3 = LookupModule('unvault')
    var_1 = lookup_run('baz', 'foo')


# Run the test cases

# Generated at 2022-06-25 11:31:18.809439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_run(bool_0)



# Generated at 2022-06-25 11:31:21.051116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instantiate the class
    lookup_module_0 = LookupModule()

    # Test method run
    lookup_module_0.run()


# Generated at 2022-06-25 11:31:24.812625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = True
    float_0 = 6277.77
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_module_0.run(bool_0)
    None # For the time being, no assertions


# Generated at 2022-06-25 11:31:25.335766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None

# Generated at 2022-06-25 11:31:29.417828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    str_0 = None
    bool_2 = True
    var_0 = lookup_module_0.run(str_0, bool_2)
    assert not (var_0)


# Generated at 2022-06-25 11:31:50.725780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('terms')
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run('terms', 'variables')
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run('terms', 'variables', kwargs='kwargs')
    lookup_module_3 = LookupModule()
    var_0 = lookup_module_3.run(terms='terms')
    lookup_module_4 = LookupModule()

# Generated at 2022-06-25 11:31:53.128252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [0]
    var_2 = lookup_module_0.run(var_1)
    assert_equal(var_2, None)

# Generated at 2022-06-25 11:31:57.681838
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=var_0, direct=var_1)
    bool_0 = bool_0
    float_0 = float_0
    lookup_module_0._loader = None
    lookup_module_0.find_file_in_search_path(var_0, var_2, var_3)
    lookup_module_0._loader.get_real_file(var_4, decrypt=bool_0)
    test_case_0()


# Generated at 2022-06-25 11:32:00.456829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:32:04.969193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    list_0 = []
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 11:32:09.279740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # AssertionError: expected ['success'] from unvault lookup with term failure, got ['failure']
    path_0 = 'failure'
    lookup_module_0 = LookupModule(path_0)
    str_0 = lookup_module_0.run()
    assert type(str_0) == list
    

# Generated at 2022-06-25 11:32:11.497680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = None
    var_1 = None
    var_2 = None
    var_0 = lookup_module_0.run(var_1, var_2)

# Generated at 2022-06-25 11:32:20.398820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    str_0 = '\\'
    str_1 = '\\'
    str_2 = '\\'
    str_3 = '\\'
    str_4 = '\\'
    str_5 = '\\'
    str_6 = '\\'
    str_7 = '\\'
    str_8 = '\\'
    str_9 = '\\'
    str_10 = '\\'
    str_11 = '\\'
    str_12 = '\\'
    str_13 = '\\'
    str_14 = '\\'
    str_15 = '\\'
    str_16 = '\\'
    str

# Generated at 2022-06-25 11:32:22.273993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:32:29.631570
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test a simple term, with the file being found on the search path
    test_terms = [
        '/bar/foo.txt',
    ]
    mock_loader = MockLoader()
    mock_loader.search_paths = [
        '/foo',
        '/bar',
    ]
    mock_loader.file_exists_map = {
        '/bar/foo.txt': True,
        '/bar/ansible.cfg': True,
    }
    mock_loader.get_real_file = lambda path, decrypt=False: path
    mock_loader.list_directory = lambda path: ['foo.txt']

    mock_loader.read_vault_file = lambda: 'This is some encrypted content'

    lookup_module = LookupModule(loader=mock_loader, bool_0=False)
    results = lookup_module

# Generated at 2022-06-25 11:33:12.177571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    bool_0 = True
    float_0 = 1655.49
    float_1 = float_0
    lookup_module_0 = LookupModule(bool_0, float_1)
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:33:12.654350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:33:13.100821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 11:33:15.621791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_0 = LookupModule(float_0, bool_0, bool_0)
    str_0 = '/etc/foo.txt'
    terms_0 = [str_0]
    lookup_module_0 = lookup_plugin_0.run(terms_0)
    lookup_module_1 = lookup_run(bool_0)

# Generated at 2022-06-25 11:33:22.663284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    bool_0 = None
    bool_1 = False
    float_0 = 1267.11
    lookup_module_0 = LookupModule(bool_1, float_0)
    dict_0 = dict()
    list_0 = list()
    var_0 = lookup_module_0.run(dict_0, list_0)


# Generated at 2022-06-25 11:33:26.408756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    key_words_0 = {}
    terms_0 = None
    variables_0 = {}
    lookup_module_0 =  LookupModule(key_words_0, variables_0)
    var_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:33:31.356104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_run(bool_0)
    test = TestCase(1, 3)
    test.test_LookupModule_run()


# Generated at 2022-06-25 11:33:37.504584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    term_0 = None
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_module_0.run(term_0)

# Generated at 2022-06-25 11:33:39.577702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:33:44.613891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    lookup_module_0.run(bool_0)


# Generated at 2022-06-25 11:35:21.331012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    bool_2 = False
    bool_3 = True
    str_0 = '__'
    bool_4 = False
    bool_5 = True
    dict_0 = dict()
    dict_0[str_0] = bool_4

    test_LookupModule_run_0(bool_2, bool_3, lookup_module_0, dict_0)


# Generated at 2022-06-25 11:35:23.696411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['/etc/foo.txt']
    variables = {}
    lookup_module_0 = LookupModule(terms, variables)
    lookup_module_0.set_options(var_options=variables, direct={})
    # Test
    lookup_module_0.run(terms, variables)
    # Teardown
    assert False


# Generated at 2022-06-25 11:35:31.989592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test If we can pass a bool as a requried param
    assert "bool" == type(bool_0)
    # Test If we can pass a float as a requried param
    assert "float" == type(float_0)
    # Test If we can pass a bool as a requried param
    assert "bool" == type(bool_1)
    # Test If we can pass a float as a requried param
    assert "float" == type(float_1)
    # Test If we can pass a bool as a requried param
    assert "bool" == type(bool_2)
    # Test If we can pass a float as a requried param
    assert "float" == type(float_2)
    # Test If we can pass a bool as a requried param

# Generated at 2022-06-25 11:35:36.509316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(bool_1, float_0)
    lookup_module_1 = LookupModule(bool_0, float_0)
    lookup_module_2 = LookupModule(bool_0, float_0)
    if (lookup_module_0.run(list_0) is not lookup_module_1.run(list_0)):
        raise Exception('AssertionError')
    if (list_0 is not list_0):
        raise Exception('AssertionError')
    if (lookup_module_2.run(list_0) is not None):
        raise Exception('AssertionError')
    if (list_0 is not list_0):
        raise Exception('AssertionError')


# Generated at 2022-06-25 11:35:41.514640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case '0'
    test_case_0()
    # Test case '1'


# Create lookup_plugin instance
lookup_plugin = LookupModule()
# Create lookup_run instance
lookup_run = lookup_plugin.run(None, None, None)

# Generated at 2022-06-25 11:35:46.057947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Set up the values needed for the tests
    list_0 = ['foo']
    dict_0 = {}
    lookup_module_0 = LookupModule(None, None)
    lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 11:35:51.188046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = lookup_run()

    lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:36:00.033754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule(None)
    lookup_module_0 = var_0
    str_0 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    str_1 = 'hockey'
    str_2 = 'name'
    str_3 = 'sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit.'
    str_4 = 'hockey'
    int_0 = 73
    str_5 = 'rhythm'

# Generated at 2022-06-25 11:36:11.069223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for run
    """
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    lookup_module_0.set_options()
    var_0 = lookup_module_0.find_file_in_search_path()
    var_1 = lookup_module_0._loader.get_real_file()
    var_0 = lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 11:36:14.939606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bool_1 = False
    float_0 = 1655.49
    lookup_module_0 = LookupModule(bool_1, float_0)
    var_0 = lookup_run(bool_1)
    #assert(var_0 == ????)
    assert(var_0 == bool_0)
