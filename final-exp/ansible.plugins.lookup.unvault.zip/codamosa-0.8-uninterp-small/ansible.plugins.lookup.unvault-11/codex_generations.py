

# Generated at 2022-06-25 11:27:18.136647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = ['', '', '', '', '']
    variables_0 = {}
    ret = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:27:23.880150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = 'j_o'
    list_0 = []
    dict_1 = {}
    list_1 = lookup_module_0.run(list_0, **dict_1)



# Generated at 2022-06-25 11:27:31.067560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    term_0 = []
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(term_0, variables_0, **kwargs_0)
    assert isinstance(result_0, list)
    assert result_0 == []


# Generated at 2022-06-25 11:27:39.472581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    runner_facts = {}
    runner_executor = 'test_runner_executor'
    runner_connection = 'test_runner_connection'
    runner_play_context = 'test_runner_play_context'
    runner_plugin = 'test_runner_plugin'
    list_0 = []
    lookup_module_0 = LookupModule(runner_facts)
    lookup_module_0.set_runner(runner_executor, runner_connection, runner_play_context, runner_plugin)
    list_1 = lookup_module_0.run(list_0)
    assert list_1 == []


# Generated at 2022-06-25 11:27:41.183782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = ["ansible-kubevirt-modules"]
    lookup_module_0.run(params)


# Generated at 2022-06-25 11:27:50.793161
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_case_0
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

# Generated at 2022-06-25 11:27:53.632521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

    # Call method run of class LookupModule
    test_case_0()

# Test method run of class LookupModule with type_check=False,
# with mixed arguments

# Generated at 2022-06-25 11:28:04.687928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
  # Unit test on class LookupModule's __init__() method
  case_0 = test_case_0()
  print("Unit test on class LookupModule's __init__() method was successful")
  
  dict_1 = {}
  lookup_module_1 = LookupModule(dict_1)
  lookup_module_1._loader = "loader2"
  lookup_module_1._templar = "templar2"
  lookup_module_1._basedir = "basedir2"
  lookup_module_1._unfrackpath = "unfrackpath2"
  terms_2 = "terms2"
  variables_2 = "variables2"
  kwargs_2 = {"kwarg2": "kwarg2"}
  # Unit test on class LookupModule's run() method
  result_

# Generated at 2022-06-25 11:28:07.956391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'paths': [],
        'paths_types': 'files',
        'vars': {},
    }
    term_0 = 0
    lookup_module_0 = LookupModule(term_0, dict_0)
    str_0 = lookup_module_0.run(term_0)
    assert str_0 is None


# Generated at 2022-06-25 11:28:13.632157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = 'foo.txt'
    str_1 = 'foo.txt'
    str_2 = 'files/'
    list_0 = [str_0, str_1, str_2]
    str_3 = 'files/'
    str_4 = 'foo.txt'
    assert lookup_module_0.run(list_0) == [to_text(str_3) + to_text(str_4)]


# Generated at 2022-06-25 11:28:19.790398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible.cfg']
    vars = {}
    value = lookup_module.run(['ansible.cfg'], {})
    assert len(value) == 1


# Generated at 2022-06-25 11:28:26.704312
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:28:33.106328
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()
    lookup_plugin.terms = ['./test/files/hello.yml']
    lookup_plugin.run('./test/files/hello.yml')
    lookup_plugin.run(['./test/files/hello.yml'])


# Generated at 2022-06-25 11:28:37.017275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = ['/usr/local/ansible/inventory/hosts', '/usr/local/ansible/inventory/hosts']

    variables = {}

    kwargs = {'fail_on_undefined_lookup': False, 'template': False}

    ret = lookup_module_0.run(terms, variables, **kwargs)

    print(ret)

# Generated at 2022-06-25 11:28:40.710166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/etc/foo.txt']
    try:
        result = lookup_module_0.run(terms)
    except Exception as e:
        print(e)
        result = None
    print(result)

# Generated at 2022-06-25 11:28:51.314653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [None]
    variables = {"files_0": {"files_0_path": "/usr/share/ansible/galaxy/roles/openstack_ansible__lxc/defaults/main.yml", "files_0_real": "/home/siddharth/ansible/galaxy/roles/openstack_ansible__lxc/defaults/main.yml", "files_0_unsafe": True}, "role_path": "/home/siddharth/ansible/galaxy/roles:/usr/share/ansible/galaxy/roles", "type": "file", "ansible_playbook_python": "/usr/bin/python"}

# Generated at 2022-06-25 11:29:01.313200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [u'/etc/foo.txt']
    variables_0 = {u'inventory_hostname': u'localhost', u'ansible_hostname': u'localhost', u'ansible_ssh_host': u'localhost', u'inventory_dir': u'/root/.ansible/tmp/ansible-local-77427xvxnwp/inventory', u'inventory_file': u'', u'ansible_connection': u'local', u'ansible_user': u'root', u'inventory_file_links': [], u'ansible_playbook_python': u'/usr/libexec/platform-python'}
    kwargs_0 = {}
    # Run run function 
    # LookupModule.run(term, variables, **kwargs)
    lookup_

# Generated at 2022-06-25 11:29:09.005440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fileter = None
    lookup_module_0 = LookupModule()
    from ansible.module_utils.six import PY3
    if not PY3:
        data = files = terms = [u'foo.txt', u'bar.txt']
    else:
        data = files = terms = ['foo.txt', 'bar.txt']
    variables = {u'files': u'/etc', u'_original_file': u'/etc/bar.txt'}
    assert lookup_module_0.run(terms, variables=variables) == [u'foo\n', u'bar\n']


# Generated at 2022-06-25 11:29:16.203217
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    real_file_redis_pass = u'/home/vagrant/.ansible/tmp/ansible-tmp-1566368302.18-138377148532374/redis_pass.py'
    lookup_module = LookupModule()
    lookup_module.set_loader("/home/vagrant")
    lookup_module.set_basedir("/home/vagrant/.ansible/tmp/ansible-tmp-1566368302.18-138377148532374/")

    terms = [u'../../tests/unit/ansible_collections/community/general/tests/fixtures/ansible.cfg']
    display.debug("Unvault lookup term: %s" % terms)
    lookup_module.run(terms)

# Generated at 2022-06-25 11:29:17.901201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['test/files/vault.yml']
    assert 'foo' in lookup_module.run(terms)

# Generated at 2022-06-25 11:29:27.369309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # TODO: Write unit tests for LookupModule.run() method
    raise NotImplementedError


if __name__ == '__main__':

    test_case_0()

    test_LookupModule_run()

# Generated at 2022-06-25 11:29:32.128566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0._loader.get_real_file(lookupfile=None, decrypt=True)

# Generated at 2022-06-25 11:29:36.591936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={})
    lookup_module_0._loader = None
    terms_0 = []
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == []


# Generated at 2022-06-25 11:29:40.788058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleParserError) as execinfo:
        lookup_module_1.run(terms='/etc/foo.txt')
    assert 'Unable to find file matching "/etc/foo.txt" ' in str(execinfo.value)


# Generated at 2022-06-25 11:29:41.636958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:29:48.767277
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    lookup_module_1._loader.set_basedir('/tmp')
    terms_1 = ['playbook.yml']
    variables_1 = {}
    kwargs_1 = {}

    lookup_module_2 = LookupModule()
    lookup_module_2._loader.set_basedir('/tmp')
    terms_2 = ['playbook.yml']
    variables_2 = { u'_original_file': u'/home/hong/git/github/ansible-playbook/playbook.yml', u'playbook_dir': u'/home/hong/git/github/ansible-playbook' }
    kwargs_2 = {}

    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == lookup

# Generated at 2022-06-25 11:29:53.165709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()
    lookup_module_1.run(['a', 'b'], variables={'y': 'z'})
    lookup_module_1.run(['c'], variables={'y': 'z'})

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:55.833489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {}
    lookup = LookupModule()
    lookup.run(["/tmp/foo.txt"], params)

# Generated at 2022-06-25 11:30:00.779827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([u'playbook.yml'])
    lookup_module_0.run([u'playbook.yml', u'playbook.yml'])
    lookup_module_0.run([u'playbook.yml', u'playbook.yml', u'playbook.yml'])


# Generated at 2022-06-25 11:30:08.956942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(('vars', 'unvault'))
    assert lookup_module_0.run(['test_file'], {}, var_options={'vars': {}, 'unvault': {}}) == [b'\n', b'\n']
    assert lookup_module_0.run(['uptime'], {}, var_options={'vars': {}, 'unvault': {}}) == [b'\n', b'\n']

# Generated at 2022-06-25 11:30:23.275028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    path_0 = '/etc/passwd'
    with open(path_0, 'r') as fd_0:
        actual = lookup_module_0.run(path_0)
        assert actual == [fd_0.read()]
        assert isinstance(actual, list)

# Generated at 2022-06-25 11:30:27.358209
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Method run call without arguments
  # No exception should be thrown
  lookup_module_run = LookupModule().run(["/etc/foo.txt"])
  assert lookup_module_run == ['This is a secret']

# Generated at 2022-06-25 11:30:38.315561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_var = {'ansible_env': {'HOME': '~', 'PATH': '/usr/bin'}}
    lookup_module = LookupModule()
    assert lookup_module.run([], ansible_var) == []
    ansible_var = {'ansible_env': {'HOME': '~', 'PATH': '/usr/bin'}}
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:30:39.141410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:30:42.663913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test case 0
    # args: ('terms', 'variables=None', '**kwargs')
    # returns: []
    assert lookup_module_0.run('terms', 'variables=None', '**kwargs') == []


# Generated at 2022-06-25 11:30:50.884873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    items_terms_1 = ['/etc/passwd']
    dict_variables_2 = {}
    dict_kwargs_3 = {}
    with pytest.raises(AnsibleParserError) as pytest_wrapped_e:
        lookup_module_1.run(items_terms_1, dict_variables_2, **dict_kwargs_3)
    assert pytest_wrapped_e.type == AnsibleParserError

# Generated at 2022-06-25 11:30:57.619359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.find_file_in_search_path = Mock(return_value='/etc/foo.txt')
    lookup_module_0.open_remote_file = Mock(return_value='file')
    lookup_module_0._loader.get_real_file = Mock(return_value='open_file_object')
    lookup_module_0.run(['foo.txt'], {})

# Generated at 2022-06-25 11:31:07.770799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = [u"/etc/passwd"]
    data_as_bytes = [i.encode('utf-8') for i in data]  # convert list to bytes
    lookup_module = LookupModule()
    result = lookup_module.run(terms=data_as_bytes, inject={u"lookup_file_search_path": [u"~/.ansible/tmp/ansible-local/tmpdextCL/"]}, variables=None, **{u"_terms": [u"/etc/passwd"]})

# Generated at 2022-06-25 11:31:11.278728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt']
    variables = None
    result = lookup_module.run(terms, variables=variables)
    assert result == ['/etc/foo.txt']

# Generated at 2022-06-25 11:31:12.391428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Testing with an actual file

# Generated at 2022-06-25 11:31:34.946212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run unvault lookup.
    # Raises AnsibleParserError if it fails to find the file.
    lookup_module_0 = LookupModule()
    terms = ['unvault_test.txt']
    variables = {}
    lookup_module_0.run(terms, variables)

    # Run unvault lookup.
    # Raises AnsibleParserError if it fails to find the file.
    lookup_module_1 = LookupModule()
    terms = ['../common/unvault_test.txt']
    variables = {}
    lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 11:31:38.784718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo']
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == ['foo']


# Generated at 2022-06-25 11:31:39.975311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:31:43.647505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['foo.txt']
    variables = None
    kwargs = None
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:31:47.621795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["hello.txt"]
    variables_1 = {}
    kwargs_1 = {}
    lookup_module_1.run(terms_1, variables_1, **kwargs_1)

# Generated at 2022-06-25 11:31:48.600159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:31:51.318095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_result = lookup_module.run(['/etc/foo.txt'])
    assert lookup_module_result[0] == 'bar'

# Generated at 2022-06-25 11:31:54.256748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt']
    result = lookup_module.run(terms, variables={})
    assert len(result) == 1
    assert isinstance(result, list)
    assert isinstance(result[0], str)

# Generated at 2022-06-25 11:32:02.601422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:32:05.747356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/foo.txt']
    variables = {}
    kwargs = {}

    expected_return = [u'bar\n']


    lookup_module_0 = LookupModule()
    actual_return = lookup_module_0.run(terms, variables, **kwargs)

    assert expected_return == actual_return, actual_return

# Generated at 2022-06-25 11:32:27.998044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    str_0 = 'g4}DiAs[qzFt$i'
    dict_0 = {str_0: str_0}
    lookup_module_2 = LookupModule(**dict_0)
    var_0 = lookup_module_2.run(lookup_module_1)
    test_case_0()

# Generated at 2022-06-25 11:32:32.548255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None

# Generated from test/run_lookup_module_tests.py on 2020-04-01 01:26:43 by Ansible at revision 1cc4d97e9b

# Generated at 2022-06-25 11:32:35.003512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(**{'_options': {}, '_display': display, '_templar': display, '_loader': display})
    str_0 = '5u-q1H'
    list_0 = [str_0]
    lookup_module_1 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:32:45.181045
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:32:50.252612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = True
    lookup_module_2 = LookupModule(bool_1)
    str_1 = 'u{7F~Oy+'
    dict_1 = {str_1: str_1}
    lookup_module_3 = LookupModule(**dict_1)
    var_1 = lookup_module_3.run(lookup_module_2)


# Generated at 2022-06-25 11:32:53.594372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["test/test.txt"]
    variables = {}
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, variables)
    assert ret == ['hello']

# Generated at 2022-06-25 11:32:56.751413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run('"MhvVY', False)
    except (AnsibleParserError):
        pass
    else:
        raise Exception('AnsibleParserError not raised.')
    '_raw'
    var_0 = lookup_module_0.run('[#+xDv')
    return var_0


# Generated at 2022-06-25 11:33:02.390659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'l9%!d3[iKm6h2{a'
    dict_0 = {str_0: str_0}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 11:33:03.803855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:33:08.644297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'g4}DiAs[qzFt$i'
    dict_0 = {str_0: str_0}
    list_0 = [str_0, str_0]
    var_0 = lookup_module_0.run(list_0, ** dict_0)

# Generated at 2022-06-25 11:33:45.016777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(['unvault', '/home/test/test.txt'])
    assert lookup_module.run(['unvault', '/home/test/test.txt']) == 'Password is: 111111'

# Generated at 2022-06-25 11:33:48.358805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'g4}DiAs[qzFt$i'
    dict_0 = {str_0: str_0}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 11:33:55.399102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'B)CZJcvn{c:H:I8'
    dict_0 = {str_0: str_0}
    lookup_module_1 = LookupModule(**dict_0)
    str_1 = 'xElJEcwV>l2[il'
    list_0 = [str_1]
    var_0 = lookup_module_1.run(list_0)
    str_0 = '$h_H{V}&%+Y0sV'
    dict_1 = {str_0: str_0}
    lookup_module_2 = LookupModule(**dict_1)
    str_1 = 'ls'
    str_2 = '-la'
   

# Generated at 2022-06-25 11:33:59.905832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)
    str_1 = 'g4}DiAs[qzFt$i'
    dict_1 = {str_1: str_1}
    lookup_module_1 = LookupModule(**dict_1)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 11:34:05.940478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = True
    lookup_module_2 = LookupModule(bool_1)
    str_1 = 'e6UxW6U8z^h3:a'
    list_1 = [str_1]
    lookup_module_3 = LookupModule.run(lookup_module_2, list_1)
    return lookup_module_3


# Generated at 2022-06-25 11:34:07.065565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	terms = [terms]
	variables = [variables]
	kwargs = [kwargs]
	test_case_0()

# Generated at 2022-06-25 11:34:07.637285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 11:34:12.354321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'g4}DiAs[qzFt$i'
    dict_0 = {str_0: str_0}
    lookup_module_1 = LookupModule(**dict_0)
    bool_1 = bool_0
    dict_1 = {bool_1: bool_1}
    lookup_module_2 = LookupModule(**dict_1)
    str_1 = 'q3w}S{-p1g%c1Z'
    str_2 = 'Y' + 'y2BlsxN'
    list_0 = [str_0, str_1]
    list_1 = [str_0, str_1, str_2]
    var_1 = lookup_module_

# Generated at 2022-06-25 11:34:19.779102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_f = 'q3Y)Pw]^.rO.Fx9'
    lookup_module_2 = LookupModule(str_f)
    lookup_module_3 = LookupModule(**{'_options': str_f})
    lookup_module_4 = LookupModule(**{'_templar': str_f})
    bool_f = False
    str_f = '~TQ]u2(V&1"{u1c'
    lookup_module_5 = LookupModule(str_f)
    lookup_module_6 = LookupModule(str_f)
    lookup_module_7 = LookupModule(str_f)
    lookup_module_8 = LookupModule(str_f)
    lookup_module_9 = LookupModule(str_f)
    lookup_module

# Generated at 2022-06-25 11:34:29.640240
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:36:06.166393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_1 = {}
    var_0 = lookup_module_0.run(list_0, dict_1)

# Generated at 2022-06-25 11:36:15.745829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'U6x5k6JhU6x5k6JhU6x5k6Jh'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)
    str_1 = 'f\x19\x01\x04\x1f'
    dict_1 = {str_1: str_1}
    lookup_module_1 = LookupModule(**dict_1)
    dict_2 = {str_1: lookup_module_1}
    lookup_module_2 = LookupModule(**dict_2)
    list_0 = ['\x0b', '\x15', '\x19', '\x1b', '\x1f']

# Generated at 2022-06-25 11:36:26.377420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'q3zgYU6!+H'
    dict_0 = {str_0: str_0}
    lookup_module_1 = LookupModule(**dict_0)
    str_1 = 'Sd<'
    dict_1 = {str_1: str_1}
    lookup_module_2 = LookupModule(**dict_1)
    list_0 = [lookup_module_1, lookup_module_2]
    str_2 = 'dSZlK(Fr\x7f-1'
    dict_2 = {str_2: str_2}
    lookup_module_3 = LookupModule(**dict_2)
    lookup_module_4 = lookup_module

# Generated at 2022-06-25 11:36:35.480009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:36:41.394809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'X[Dd@.s@'
    dict_0 = {str_0: str_0}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 11:36:50.443474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    # dict_0 = dict()
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = lookup_module_0.run()
    dict_1 = {'_description': 'path(s) of files to read'}
    lookup_module_1 = LookupModule(**dict_1)
    terms_1 = lookup_module_1.run()
    dict_2 = {'_description': 'path(s) of files to read'}
    lookup_module_2 = LookupModule(**dict_2)
    terms_2 = lookup_module_2.run()
    dict_3 = {'_options': dict_2}
    lookup_module_3 = LookupModule(**dict_3)
    terms_3 = lookup_module

# Generated at 2022-06-25 11:36:51.034403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:36:59.202416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = list()
    list_0.append('[|>t}8aV;d:~rjY]lCIG')
    list_0.append('u[@VfQWbX3E;]j')
    list_0.append('(W]xhs<o[)')
    list_0.append('t;d:~rjY]lCIG')
    list_0.append('u[@VfQWbX3E;]j')
    lookup_module_1 = LookupModule(list_0)
    list_1 = list()
    list_0.append('`')
    list_0.append('>t}8aV;d:~rjY]lCIG')
    list_0.append

# Generated at 2022-06-25 11:37:03.932686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'Q%R'
    tuple_0 = (str_0,)
    str_1 = 't'
    str_2 = '8%c)'
    str_3 = 'n'
    list_0 = [str_1, str_2, str_3]
    str_4 = '   '
    list_0.append(str_4)
    str_5 = 'sDd'
    bool_1 = True
    str_6 = '4O|'
    str_7 = 'a'
    dict_0 = {str_6: bool_1, str_7: lookup_module_0}
    str_8 = '0'
    list_0.insert(1, str_8)

# Generated at 2022-06-25 11:37:06.809983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for run of class LookupModule
    test_case_0()