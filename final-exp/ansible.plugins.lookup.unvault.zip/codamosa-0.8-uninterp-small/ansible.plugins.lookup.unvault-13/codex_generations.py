

# Generated at 2022-06-25 11:27:18.904939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:27:26.034759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call method run of class LookupModule
    # Check if exception is raised
    # assertRaises(exception, method_to_be_tested, method_args)
    # assertRaises(AnsibleParserError, lookup_module_0.run, None, None, None)
    # assertRaises(AnsibleParserError, lookup_module_0.run, None, None)
    # assertRaises(AnsibleParserError, lookup_module_0.run, None)
    # assertRaises(AnsibleParserError, lookup_module_0.run)

# Generated at 2022-06-25 11:27:28.481227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Mocked argument variables
    variables = {}
    lookup_module.run(terms=["/etc/passwd"], variables=variables, **dict())

# Generated at 2022-06-25 11:27:31.836049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms_run = ["/etc/ansible/hosts"]
    variables_run = None
    kwargs_run = {'searchpath': ""}
    lookup_module_run.run(terms_run, variables_run, **kwargs_run)

# Generated at 2022-06-25 11:27:40.161852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Sample Ansible context
    context = {
        'playbook': {
            'basedir': './tests/test_lookup_plugins/'
        }
    }
    
    # Create a new lookup module with this context
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=context)
    result = lookup_module.run(terms=["foo.txt"], variables=context)
    assert result[0].strip() == "Hello, World!"
    result = lookup_module.run(terms=["bar.txt"], variables=context)
    assert result[0].strip() == "goodbye cruel world"



# Generated at 2022-06-25 11:27:43.662289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule();

    # Unit: fail on non-existent file
    #  lookup_module_0.find_file_in_search_path = lambda x, y, z: "/tmp/non-existent-file"
    #  res = lookup_module_0.run(["non-existent-file"], {})
    #  assert res == null

# Generated at 2022-06-25 11:27:53.569504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    mock_terms = ['tests/vault/test_vault.yaml', 'tests/vault/test_vault_decrypt_fail.yaml', 'tests/vault/test_vault_decrypt_fail2.yaml']
    mock_variables = {'ansible_module_generated': True, 'lookup_file_append_newline': False, 'lookup_file_find_file': True, 'lookup_file_size': False}
    mock_kwargs = {'direct': False}
    # Call method
    result = lookup_module.run(mock_terms, mock_variables, **mock_kwargs)
    # Verify

# Generated at 2022-06-25 11:28:01.722133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    def do_print(msg):
        print(str(msg))

    lookup_module_1.set_options(direct={'display': do_print})
    terms_1 = ['/tmp/testfile']

    try:
        lookup_module_1.run(terms_1)

    except (Exception) as exception:
        print(exception)

# Generated at 2022-06-25 11:28:07.008322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Usage example from documentation
    #
    lookup_module_0 = LookupModule()
    terms = [ '/etc/foo.txt' ]
    variables = {
        'ansible_pkg_mgr': 'yum'
    }
    kwargs = { 'var': 'var1' }
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:28:11.590961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # No good way of testing this completely, as there is no self.runner and therefore no self.plugin_name
    # This class looks up files in a path, but the test class here is not guaranteed to have the correct path
    #   for the kind of file we would want to test here
    lookup_module._loader = "TEST"
    lookup_module.run("examples/hosts_single")

# Generated at 2022-06-25 11:28:20.307684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['file_name']
    variables = {'some_var': 'value'}
    kwargs = {'some_kwarg': 'value'}
    lookup_module_run = LookupModule()
    assert lookup_module_run.run(terms, variables, **kwargs) is not None

# Generated at 2022-06-25 11:28:21.333743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_name = "test.yml"
    assert True

# Generated at 2022-06-25 11:28:29.642687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the lookup module
    lookup_module = LookupModule()
    # Create dummy args
    terms = ['test']
    variables = {}
    kwargs = {}
    # Invoke method run of class LookupModule
    try:
        lookup_module.run(terms, variables, **kwargs)
    except Exception:
        assert False, 'Invocation of method run of class LookupModule failed'



# Generated at 2022-06-25 11:28:36.539339
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Case 0:
    #
    # Invoke run with the following parameters:
    # terms: ['/etc/ansible/ansible.cfg']
    # variables: None
    #
    # Expected result:
    #
    # Path ./roles/test_unvault_lookup/files/ansible.cfg does not exist
    # Path ./playbooks/files/ansible.cfg does not exist

    result = lookup_module.run(terms=['ansible.cfg'])

    assert result == ['[defaults]\n\nhost_key_checking = False\n\n']

# Generated at 2022-06-25 11:28:41.356183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module._loader.file_exists.return_value = True
  lookup_module._loader.get_real_file.return_value = 'actual_file'
  lookup_module._loader._get_file_contents.return_value = b'test_file_content'
  assert lookup_module.run(['/etc/foo.txt']) == [b'test_file_content']


# Generated at 2022-06-25 11:28:46.450908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = []
    variables_0 = {}
    ret_0 = lookup_module_0.run(term_0, variables_0)
    assert ret_0 == []

# Generated at 2022-06-25 11:28:50.211040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
    except NameError:
        lookup_module_0 = None
    try:
        term_0 = [
            'foo.txt',
            'bar.txt',
        ]
        lookup_module_0.run(term_0)
    except (NotImplementedError, NameError):
        pass

# Generated at 2022-06-25 11:29:00.758700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # test_terms_1 = ""
    # kwargs_1 = {}
    # assert lookup_module_1.run(test_terms_1, **kwargs_1) == {}, "return value: " + str(lookup_module_1.run(test_terms_1, **kwargs_1))
    # 
    # test_terms_2 = ""
    # kwargs_2 = {}
    # assert lookup_module_1.run(test_terms_2, **kwargs_2) == {}, "return value: " + str(lookup_module_1.run(test_terms_2, **kwargs_2))
    # 
    # test_terms_3 = ""
    # kwargs_3 = {}
    # assert lookup_module_

# Generated at 2022-06-25 11:29:04.661495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms="test_file")

# Generated at 2022-06-25 11:29:09.714645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert '{{lookup("unvault"|default("unvault"), "/etc/foo.txt")|to_string }}' == '{{lookup("unvault"|default("unvault"), "/etc/foo.txt")|to_string }}'

# Generated at 2022-06-25 11:29:16.650019
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0 = [str]
    variables_0 = {str: str}
    kwargs_0 = {str: str}

    return_value = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert return_value == []


# Generated at 2022-06-25 11:29:23.033505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.remote_addr = '172.16.42.43'
    play_context.connection = 'ssh'
    play_context.remote_user = 'root'
    play_context.password = 'toor'
    play_context.become = False
    play_context.become_method = False
    play_context.become

# Generated at 2022-06-25 11:29:32.050440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input Parameters
    terms = [
        "index.yml"
    ]
    variables = None
    kwargs = {
        "extensions": "yml"
    }

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options = variables, direct = kwargs)
    result = lookup_module_0.run(terms, variables, **kwargs)

    assert result == [
        "{all: [{databases: [mariadb, redis], distros: [centos-7, ubuntu-18.04], images: [dev-python, dev-java]}], vault: {password: {}}}"
    ]

# Generated at 2022-06-25 11:29:35.702184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/foo.txt']
    variables = None
    kwargs = {}
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms,variables, **kwargs)

# Generated at 2022-06-25 11:29:43.703333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_1 = []
    lookup_module_2.run(terms=terms_1)
    terms_1 = ['dummy']
    lookup_module_2.run(terms=terms_1)
    terms_1 = ['dummy']
    variables_1 = {}
    lookup_module_2.run(terms=terms_1, variables=variables_1)
    terms_1 = ['dummy']
    variables_1 = {'dummy': 'dummy'}
    lookup_module_2.run(terms=terms_1, variables=variables_1)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:46.363143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.set_options({   })

    test_case_0()


# Unit test boilerplate


# Generated at 2022-06-25 11:29:55.755126
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = [
        u'/test/test_vars_file.yaml',
    ]
    variables = {
        u'hostvars': {
            u'host1': {
                u'inventory_hostname': u'host1',
            },
        },
    }
    kwargs = {
        u'plugin_args': {
            u'hostvars': {
                u'host1': {
                    u'inventory_hostname': u'host1',
                },
            },
        },
        u'_terms': {
            u'/test/test_vars_file.yaml': u'',
        },
    }

    result = lookup_module.run(terms=terms, variables=variables, **kwargs)

# Generated at 2022-06-25 11:29:58.433828
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Variables used in test
    terms = 'foo.txt'
    variables = None

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables)

    # Assert for exception in run()
    assert type(result) == list

# Generated at 2022-06-25 11:30:00.515456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run("test_value") == []

# Generated at 2022-06-25 11:30:02.985136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['foo/bar']) == [b'foo/bar']


# Generated at 2022-06-25 11:30:10.930610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_values = [
        ('_terms', 'lookupfile', 'LookupModule.run', 'test-file.txt', None),
    ]
    lookup_module_1 = LookupModule()
    res = lookup_module_1.run(test_values[0][1])
    assert res == ['file content\n']

# Generated at 2022-06-25 11:30:11.937043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:30:17.900781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    terms_0_0 = [u'/etc/foo.txt']
    variables_0_1 = dict()
    kwargs_0_2 = dict()
    ret_0_3 = lookup_module_run_0.run(terms_0_0, variables_0_1, **kwargs_0_2)
    assert ret_0_3 is None


# Generated at 2022-06-25 11:30:22.849186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/foo.txt', '/etc/not_there.txt']
    lookup_module_0.run(terms=terms_0, variables=None, direct=None)

# Generated at 2022-06-25 11:30:28.357949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["/root/ansible_controller/ansible/my_ansible_project/files/test_file.txt"]
    assert lookup_module_0.run(terms) == [b'Testing Vault-encrypted file\n']



# Generated at 2022-06-25 11:30:33.557234
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    display = Display()

    lookup_module = LookupModule()

    # Base method test
    lookup_module.run([])

    # Test argument types
    # Test return type
    # Test exception raised
    # Test exception message


# Generated at 2022-06-25 11:30:38.645983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([u'/etc/foo.txt'], variables=dict(files=[u'foo.txt']))
    lookup_module.run([u'/etc/foo.txt'], variables=dict(files=[u'foo.txt']), password='bar')

# Generated at 2022-06-25 11:30:44.087941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters
    lookup_module = LookupModule()
    terms = ['/tmp/foo.txt']
    variables = {}
    kwargs = {}

    # Expected returns
    expected_return = 'foo'

    # Call method run of class LookupModule
    # Method run should return the content of the file
    assert expected_return == lookup_module.run(terms=terms, variables=variables, **kwargs)[0], "Result is {}".format(lookup_module.run(terms=terms, variables=variables, **kwargs)[0])

# Generated at 2022-06-25 11:30:47.502802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:30:51.133103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'foo.txt', u'/etc/bar.txt']
    variables = None
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:30:58.480366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:31:02.288574
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(False, None, False)
    assert var_0 == [], 'Unable to get empty file'

# Generated at 2022-06-25 11:31:08.514281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # parameters
    terms = 'M)Ja%`@Gz\'\\&x/!Pqo\x7fL\x12;B\x0b'
    variables = 'Uz58CeP^'
    # kwargs
    kwargs = {'variables': 'yt^s'}
    lookup_module_0.run(terms, variables, **kwargs)



# Generated at 2022-06-25 11:31:11.315936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:31:16.383757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    test_case_0()
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(test_case_0(), lookup_module_0)
    lookup_module_1.run(test_case_0())
    assert test_case_0() is not None
    assert lookup_module_1 is not None
    assert lookup_module_0 is not None



# Generated at 2022-06-25 11:31:22.527668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = 'v6\tv\x08\x15\x02\x0f\x04\x15\x07\x00\n\x14\x06'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

test_LookupModule_run()

# Generated at 2022-06-25 11:31:25.479357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleParserError):
        lookup_module_0.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:31:26.847913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	try:
		test_case_0()
	except:
		assert False


# Generated at 2022-06-25 11:31:30.398995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule('\x80', lookup_module_0)
    terms_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_1.run(terms_0)

# Generated at 2022-06-25 11:31:36.967396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:31:48.323966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # creating object
    lookup_module = LookupModule()

    # invoking run() with args
    lookup_module.run(terms = ['LookupModule'])

# Generated at 2022-06-25 11:31:51.064140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = None
    kwargs = {}
    lookup_module_1 = LookupModule()
    int_0 = lookup_module_1.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:31:54.569174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = '\t\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:32:00.892162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)



# Generated at 2022-06-25 11:32:05.417547
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:32:12.039170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    int_0 = 0
    int_1 = 0
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)
    if var_0 is not None:
        doctest.testmod(verbose=False)


# Generated at 2022-06-25 11:32:22.296263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule(str_0, lookup_module_1)

    # The method run is called from the unit test.
    # It is not call from the playbook.
    def run(bool_0, dict_1, **kwargs):
        lookup_module_2.run(bool_0, dict_1, **kwargs)
    run(bool_0, dict_0, **kwargs)

# Generated at 2022-06-25 11:32:26.419984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['\x0b@Y\tk/nHK4|A-`n\\', '\x0b@Y\tk/nHK4|A-`n\\', '\x0b@Y\tk/nHK4|A-`n\\']
    variables = None
    kwargs = {"direct": True}
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(terms, variables, **kwargs)
    var_0 = lookup_module_1.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:32:32.682131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    lookup_module = LookupModule()

    # When
    lookup_module.run(['/etc/foo.txt'])
    # Then
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:32:40.404427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new class object
    thisInstance = LookupModule()

    # Get the value of the object's attribute '_plugins'
    value = thisInstance._plugins

    # Create a new class object
    thisInstance2 = LookupModule('f3\\~\t@X[\x0b', thisInstance)

    # Get the value of the object's attribute '_options'
    value2 = thisInstance2._options

    # Create a new class object
    thisInstance3 = LookupModule('', thisInstance2)

    # Get the value of the object's attribute '_loader'
    value3 = thisInstance3._loader

    # Create a new class object
    thisInstance4 = LookupModule('', thisInstance3)

    # Get the value of the object's attribute '_play_context'
    value4 = thisInstance4._play_context

# Generated at 2022-06-25 11:33:03.882714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = None
    kwargs = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, kwargs)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:33:05.737107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run unit test for method run
    test_case_0()

# Generated at 2022-06-25 11:33:13.253023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = 'Y\td3+\x0b$'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    assert lookup_module_1.run(bool_0) is None

# Test for method find_file_in_search_path of class LookupModule

# Generated at 2022-06-25 11:33:20.791073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:33:29.673176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    from ansible.errors import AnsibleParserError

    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleParserError) as error_info:
        lookup_module_0.run()

    assert error_info.value.args[0] == 'One or more required fields (terms) were not set'

# Generated at 2022-06-25 11:33:31.422275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:33:34.568629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:33:39.712977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)
    assert var_0 is None, "Return value of method 'run' is not None"

# Generated at 2022-06-25 11:33:42.665537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:33:44.941097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:34:35.748797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:34:37.730974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 11:34:38.289011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False


# Generated at 2022-06-25 11:34:41.956030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:34:46.100430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)


# Generated at 2022-06-25 11:34:52.927056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = ''
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:34:58.698090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)


# Generated at 2022-06-25 11:35:01.520394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:35:02.439006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:35:06.751125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '/7\x1a'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)

if __name__ == "__main__":
    test_lookup_plugin_basic()
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:36:46.744547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x0b@Y\tk/nHK4|A-`n\\'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(str_0, lookup_module_0)
    var_1 = lookup_module_1.run(bool_0)
# test_LookupModule_run()

# Generated at 2022-06-25 11:36:49.431033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_0.run(str_0)
    lookup_module_0.run(str_0)
    lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:36:49.907827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:36:51.216088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:36:57.583311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [True]
    variables = {'foo': 'bar'}
    kwargs = {'baz': 'quz'}
    lookup_module_0 = LookupModule(display)
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    lookup_module_0.run(terms, variables=variables, baz='quz')

# Generated at 2022-06-25 11:37:00.943073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
   if mocker:
      test_case_0()
  except NameError:
   pass

# Generated at 2022-06-25 11:37:05.558807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    int_0 = 1127233700

# Generated at 2022-06-25 11:37:11.457483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    array_0 = ['\x0b@Y\tk/nHK4|A-`n\\']
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(array_0, lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)
    assert var_0 == []


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:37:18.238821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule('@Y\tk/nHK4|A-`n\\', lookup_module_0)
    var_0 = lookup_module_1.run(bool_0)