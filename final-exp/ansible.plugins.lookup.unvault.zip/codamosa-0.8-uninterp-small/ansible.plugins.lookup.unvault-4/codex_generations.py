

# Generated at 2022-06-25 11:27:24.954614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["/usr/local/etc/ansible/tasks/vault.yml"]
    variables=None
    kwargs = {}
    returned = lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:27:32.946000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '4'
    lookup_module_0 = LookupModule(str_0)
    lookup_module_1 = LookupModule(str_0)
    lookup_module_1.display.color = False
    lookup_module_1.set_options('3')
    lookup_module_1.get_options('4')
    lookup_module_1.run('4')
    str_1 = '2'
    str_2 = '5'
    lookup_module_1.run(['4', '5'], str_2, str_1='3')

if __name__ == "__main__":
    print("Begin unit tests for lookup_plugins.unvault")
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:27:37.657707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '/etc/ansible/hosts'
    var_options_0 = None
    direct_0 = {}
    terms_0 = [term_0]
    return_0 = lookup_module_0.run(terms_0, var_options_0, direct=direct_0)

# Generated at 2022-06-25 11:27:40.690022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['4']

    # Invokes the constructor of class LookupModule
    lookup_module_0 = LookupModule(terms)
    x = lookup_module_0.run(terms)
    print(x)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:27:41.814470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run"))

# Generated at 2022-06-25 11:27:46.070865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 11:27:47.330911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 11:27:54.818982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('score')
    lookup_module_1 = LookupModule('monitor')
    lookup_module_2 = LookupModule('excel')
    lookup_module_3 = LookupModule('outer')
    lookup_module_4 = LookupModule('steal')
    lookup_module_5 = LookupModule('indicator')
    lookup_module_6 = LookupModule('snow')
    lookup_module_7 = LookupModule('trial')
    lookup_module_8 = LookupModule('scare')
    lookup_module_9 = LookupModule('crack')
    lookup_module_1.run(lookup_module_7.run(lookup_module_1.run(lookup_module_3.run())))


# Generated at 2022-06-25 11:28:04.762506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '4'
    lookup_module_0 = LookupModule(str_0)

    # example is correct
    terms = [
        'test_terms_0'
    ]
    variables = [
        'test_variables_0'
    ]
    # fail
    # assert lookup_module_0.run(terms, variables) == 'test_return_0'

    # Generated test cases for 'test_variables_0'
    # example is incorrect
    # assert lookup_module_0.run(terms, variables) == 'test_return_1'

    # Generated test cases for 'test_variables_0'
    # example is incorrect
    # assert lookup_module_0.run(terms, variables) == 'test_return_2'

    # Generated test cases for 'test_variables_

# Generated at 2022-06-25 11:28:06.427742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '4'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '4'
    lookup_module_0.run(str_1)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:28:10.746159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_data = LookupModule().run(['/etc/ansible/ansible.cfg'], variables={})
    assert type(file_data) == list


# Generated at 2022-06-25 11:28:13.858350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(['/etc/foo.txt'], 'variables', kwargs=None)
    assert result_0 == None

# Generated at 2022-06-25 11:28:18.508625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # missing term
    assert_equal(lookup_module_0.run([]), [])

# Generated at 2022-06-25 11:28:21.646436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run(y)
    print(x)

# Generated at 2022-06-25 11:28:31.695038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.C.set_configuration({'DEFAULT_VAULT_IDENTITY_LIST': ['test_vault_identity_list'], 'DEFAULT_VAULT_IDENTITY_MULTI': ['test_vault_identity_multi']})
    lookup_module_0._loader.set_vault_secrets(['test_vault_secrets'])
    lookup_module_0._loader.set_vault_password('test_vault_password')
    lookup_module_0.C.ANSIBLE_LOAD_CALLBACK_PLUGINS = False
    lookup_module_0.C.ANSIBLE_TASK_CALLBACK_PLUGINS = False
    lookup_module_0.C.ANSIBLE_STDOUT_CALLBACK = False


# Generated at 2022-06-25 11:28:37.659740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_basedir = lambda x: ''
    lookup_module.run(['file_1', 'file_2'])

# Generated at 2022-06-25 11:28:38.537602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()

    lookup_module_run_0.run([''], dict())

# Generated at 2022-06-25 11:28:41.680559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    v = {'var': '/etc/foo.txt'}
    r = lookup_module.run(terms=['/etc/foo.txt'], variables=v)
    assert r == [b'# (c) 2020 Ansible Project\n# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)\n\n', b'\n']
    assert lookup_module.run(terms=["{{ '%s' | format(var) }}"], variables=v) == r

# Generated at 2022-06-25 11:28:43.733524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    terms = ['dummy_terms']
    variables = None
    kwargs = None
    lookup_module_0.run(terms=terms,variables=variables, **kwargs)

# Generated at 2022-06-25 11:28:52.232290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(test_case_0, "run"))

# Generated at 2022-06-25 11:29:01.669135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # should raise
    try:
        lookup_module_0.run(['any', 'list'], None)
    except SystemExit as e:
        if e.code == 0:
            raise AssertionError("Bad exit code returned: 0")
        if e.code == 1:
            raise AssertionError("Bad exit code returned: 1")
        if e.code == 2:
            raise AssertionError("Bad exit code returned: 2")
        if e.code == 3:
            raise AssertionError("Bad exit code returned: 3")
        if e.code == 4:
            return
        else:
            raise AssertionError("Should not have reached this line")
    else:
        raise AssertionError("Should not have reached this line")

# Generated at 2022-06-25 11:29:10.915491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_terms_1 = ['/etc/foo.txt']
    test_run_1 = lookup_module_1.run(test_terms_1)
    assert test_run_1[0] == u'foo\n'
    test_terms_2 = ['/etc/foo.txt', '/etc/bar.txt']
    test_run_2 = lookup_module_1.run(test_terms_2)
    assert test_run_2[0] == u'foo\n'
    assert test_run_2[1] == u'bar\n'
    # TODO: Add more tests for class LookupModule; we skipped the following:
    # * test_examples
    # * test_run_with_vault

# Generated at 2022-06-25 11:29:16.573531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    test_terms_0 = [
        u'some_image.jpg',
        u'../some_video.mp4',
        u'../../../some_image.jpg'
    ]
    test_variables_0 = {}
    test_kwargs_0 = {}
    # call the run method of class LookupModule with required arguments
    # return the content of file(s) as bytes
    test_LookupModule_run_0_ret = lookup_module_0.run(terms=test_terms_0, variables=test_variables_0, **test_kwargs_0)

# Generated at 2022-06-25 11:29:21.149306
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [ '/etc/hosts' ]
    variables = {}
    display = Display()

    lookup_module_0 = None
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(terms, variables, display=display)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    #print("Testing class")
    #test_case_0()
    #print("Testing method")
    test_LookupModule_run()
    #print("Tests completed")

# Generated at 2022-06-25 11:29:23.838231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  result = LookupModule.run(terms = [''])
  assert result == ['']


# Generated at 2022-06-25 11:29:27.231799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ 'login.yml' ]
    lookup_module.run(terms)

# Generated at 2022-06-25 11:29:29.319039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:34.195704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    term = 'file_name'
    variables = {}
    try:
        lookup_module_0.run(terms=term, variables=variables)
    except AnsibleParserError as e:
        return e.args

# Generated at 2022-06-25 11:29:35.311244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:29:42.950243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=["test.txt"]) # test.txt must exist
    lookup_module_1.run(terms=["test.txt"], variables={'__files': ['/usr/lib/python3.5/site-packages/ansible/test/data/test.txt']}) # test.txt must exist
    lookup_module_1.run(terms=["/etc/passwd"]) # /etc/passwd must exist
    lookup_module_1.run(terms=["/etc/passwd"], variables={'__files': ['/etc/passwd']}) # /etc/passwd must exist
    lookup_module_1.run(terms=["/etc/passwd"], variables={'__files': ['/etc/passwd']}) # /etc/passwd

# Generated at 2022-06-25 11:29:56.908686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test template case 0.
    try:
        lookup_module.run(['/etc/foo.txt'])
    except Exception as e:
        # TODO: This will fail due to missing file
        assert False

# Generated at 2022-06-25 11:30:00.796070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(terms=["test_LookupModule_run"], variables=None, **kwargs)
    assert lookup_module_run == [u'foo\n']

# Generated at 2022-06-25 11:30:05.657712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/tmp/test']
    parsed_0 = False
    try:
        lookup_module_0.run(terms_0)
        parsed_0 = True
    except AnsibleParserError:
        assert False
    assert parsed_0


# Generated at 2022-06-25 11:30:07.891348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:30:11.166330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [""]
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(**{'terms': terms_0, 'variables': variables_0})
    print(result_0)

# Generated at 2022-06-25 11:30:23.149040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.parsing.vault import VaultLib
    # Create a vault password file for testing
    def_vault_password_file = DEFAULT_VAULT_PASSWORD_FILE

# Generated at 2022-06-25 11:30:24.779228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:30:31.242047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['/etc/hosts']) == [1]
    assert lookup_module_1.run(['/etc/hosts']) == [2]
    assert lookup_module_1.run(['/etc/hosts']) == [3]
    assert lookup_module_1.run(['/etc/hosts']) == [4]
    assert lookup_module_1.run(['/etc/hosts']) == [5]
    assert lookup_module_1.run(['/etc/hosts']) == [6]
    assert lookup_module_1.run(['/etc/hosts']) == [7]
    assert lookup_module_1.run(['/etc/hosts']) == [8]
    assert lookup

# Generated at 2022-06-25 11:30:33.138768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:30:36.986060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 1
    # test case 1.1


    
    
    
    
    
    pass

# Generated at 2022-06-25 11:30:53.380662
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    int_0 = 5
    str_0 = ''
    lookup_module_1 = LookupModule(int_0, str_0)
    lookup_module_1.run(lookup_module_0)
    lookup_module_2 = LookupModule()
    lookup_module_2.run(lookup_module_0)
    lookup_module_3 = LookupModule()
    lookup_module_3.run(lookup_module_0)
    lookup_module_4 = LookupModule()
    lookup_module_4.run(lookup_module_0)
    lookup_module_5 = LookupModule()
    lookup_module_5.run(lookup_module_0)
    lookup_module_6 = LookupModule()
    lookup_module_6.run

# Generated at 2022-06-25 11:30:53.806613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-25 11:30:55.692812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ''
    bool_0 = False
    lookup_module_1 = LookupModule(term_0, bool_0)
    lookup_module_0.run(lookup_module_1)


# Generated at 2022-06-25 11:30:57.577415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(int_0, str_0)
    var_0 = lookup_module_1.run(bool_0, lookup_module_0)

# Generated at 2022-06-25 11:30:58.405115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()

# Generated at 2022-06-25 11:31:00.809067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_0.run(lookup_module_1, lookup_module_2, lookup_module_3)
    

# Generated at 2022-06-25 11:31:10.343276
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:31:13.269830
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: The test below is not valid with current version of ansible-base

    lookup_module_0 = LookupModule()

    try:
        lookup_module_0.run("", "")
    except Exception as e:
        assert False, 'An exception happened'

# Generated at 2022-06-25 11:31:14.844477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:31:24.481384
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:31:42.633870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None




# Generated at 2022-06-25 11:31:47.573072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    int_0 = -22
    str_0 = ''
    lookup_module_1 = LookupModule(int_0, str_0)
    var_0 = lookup_module_1.run(bool_0, lookup_module_0)

# Generated at 2022-06-25 11:31:49.288925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Asserting 'bool' == type(obj_0)
    assert isinstance(test_case_0(), bool)

# Generated at 2022-06-25 11:31:55.378755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '/etc/foo.txt',
        '/etc/bar.txt',
    ]
    variables = {
        'IP_SUBNET': '11.12.13.0',
        'ANSIBLE_DIR': '.',
        'ANSIBLE_CONFIG': '~/ansible.cfg',
    }

    expected_result = [
        'some content in foo.txt',
        'some content in bar.txt',
    ]

    lookup_module = LookupModule()
    actual_result = lookup_module.run(terms, variables)

    assert expected_result == actual_result

# Generated at 2022-06-25 11:31:59.245895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'foo.txt'
    variables_0 = dict()
    var_0 = LookupModule().run(term_0, variables_0)

# Generated at 2022-06-25 11:32:11.272796
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_2 = LookupModule()
    bool_1 = False
    str_3 = "0x0a"
    str_4 = "h3ll0"
    lookup_module_3 = LookupModule(bool_1, str_3)
    var_1 = lookup_module_3.run(str_4, lookup_module_2)
    int_1 = (var_1[0] & 0xFF)
    print(int_1)
    print("hello")
    bool_2 = True
    lookup_module_4 = LookupModule(int_1, bool_2)
    print("goodbye")
    list_0 = ["hello", "goodbye"]
    var_2 = lookup_module_4.run(list_0, lookup_module_2)


# Generated at 2022-06-25 11:32:17.156470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    int_0 = -22
    str_0 = ''
    lookup_module_1 = LookupModule(int_0, str_0)
    var_0 = lookup_module_1.run(bool_0, lookup_module_0)

# Generated at 2022-06-25 11:32:20.937766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_0 = LookupModule(bool_0)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:32:24.732805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:32:27.617768
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_0 = 'foo'
    int_0 = -23
    LookupModule_0 = LookupModule(str_0, int_0)
    str_1 = 'bar'
    int_1 = -24
    var_0 = LookupModule_0.run(str_1, int_1)



# Generated at 2022-06-25 11:33:08.330071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a LookupModule object
    lookup_module_obj_0 = LookupModule()

    # Get the value of a parameter
    lookup_module_obj_0.get_option('var_options')

    # Set a parameter
    lookup_module_obj_0.set_options({'var_options':None})

    # Invoke method run
    test_case_0()

# Generated at 2022-06-25 11:33:12.650047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    int_0 = -22
    str_0 = ''
    lookup_module_1 = LookupModule(int_0, str_0)
    var_0 = lookup_module_1.run(bool_0, lookup_module_0)

# Generated at 2022-06-25 11:33:14.131719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_object = LookupModule()
    assert callable(getattr(lookup_object, 'run'))


# Generated at 2022-06-25 11:33:18.108522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:33:19.317090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()

# Generated at 2022-06-25 11:33:25.365186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = None
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == None
    assert lookup_module_0.run(var_0) == None


# Generated at 2022-06-25 11:33:25.946363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:33:31.579868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ux'
    lookup_module_1 = LookupModule(str_0)
    # AssertionError: Failed to find file matching "ux"
    try:
        lookup_module_1.run(lookup_module_0)
    except AssertionError as result:
        display.display(result)

# Generated at 2022-06-25 11:33:38.039579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    int_0 = 5
    var_0 = lookup_module_0.run(str_0, dict_0, depth=int_0)
    assert var_0 == None

# Generated at 2022-06-25 11:33:40.317419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    terms = list()
    variables = dict()
    kwargs = dict()

    result = lookup_module_0.run(terms, variables, **kwargs)

    # Teardown
    pass

# Generated at 2022-06-25 11:35:14.797781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = True
    variables = None
    l = LookupModule()
    l.run(terms, variables)


# Generated at 2022-06-25 11:35:17.051768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    string_0 = 'q'
    assert_equal(lookup_module_0.run(string_0), lookup_module_0._loader.run(string_0, boolean_0))


# Generated at 2022-06-25 11:35:19.393190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '/etc/foo.txt'
    var_0 = lookup_module_0.run(str_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:35:27.720220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    int_0 = -743
    str_0 = 'F%YW8;%c<F3&BZ2b'
    lookup_module_0 = LookupModule(int_0, str_0, -76, True, None, '}', 'NOT%!Nn!E1?L3lxT', False, 'Y;g^QA}]DZ=')
    if LookupModule.run(lookup_module_0, '', 'h,*0YsWR') == False:
      raise Exception('AssertionError')
  except AssertionError as err:
    assert False


# Generated at 2022-06-25 11:35:30.063473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    int_0 = 0
    str_0 = ''
    lookup_module_1 = LookupModule(int_0, str_0)
    var_0 = lookup_module_1.run(bool_0, lookup_module_0)


# Generated at 2022-06-25 11:35:34.168380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:35:36.190547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    lookup = LookupBase()

    var_0 = test_case_0()
    var_0 = lookup.run(var_0)

    assert var_0 != None

# Generated at 2022-06-25 11:35:39.599178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Fixture Initialization
    test_case_0()
    assert True #FIXME
    # Test Logic

# Generated at 2022-06-25 11:35:43.279232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bool_0 = False
    lookup_module_0 = LookupModule()
    int_0 = -22
    str_0 = ''
    lookup_module_1 = LookupModule(int_0, str_0)
    var_0 = lookup_module_1.run(bool_0, lookup_module_0)

# Generated at 2022-06-25 11:35:45.918363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str = ''
    lookup_module_1 = LookupModule(str)
    var_0 = lookup_module_1.run(lookup_module_0)