

# Generated at 2022-06-25 11:27:18.317271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt']
    variables = None
    kwargs = {}

    # Act
    ret = lookup_module.run(terms, variables, **kwargs)

    # Assert
    assert ret == []

# Generated at 2022-06-25 11:27:19.719227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['ansible'])

# Generated at 2022-06-25 11:27:21.888036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Check if the method raises the expected exception.
    with pytest.raises(AnsibleParserError):
        lookup_module.run(None, None)

# Generated at 2022-06-25 11:27:31.868131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # File '/etc/ansible/vault.yml' exists, decrypt = True
    lookup_module_0 = LookupModule()
    terms = ['/etc/ansible/vault.yml']
    variables = dict()
    kwargs = dict()
    assert lookup_module_0.run(terms, variables=variables, **kwargs) == ['\n']

    # File '/etc/ansible/vault.yml' exists, decrypt = False
    lookup_module_1 = LookupModule()
    terms = ['/etc/ansible/vault.yml']
    variables = dict()
    kwargs = dict()
    assert lookup_module_1.run(terms, variables=variables, **kwargs) == ['\n']

    # File '/etc/ansible/vault.yml' exists,

# Generated at 2022-06-25 11:27:37.962635
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = ['unvault_terms_0']
    variables_0 = {}
    lookup_module_0.set_options(var_options=variables_0, direct={})
    result = lookup_module_0.run(terms_0, variables=variables_0, **{})
    print("Test Case: 0, result: " + str(result))


# Generated at 2022-06-25 11:27:45.296768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader.set_basedir('/etc')
    actual_return = lookup_module_0.run(['passwd'], variables=None, **{})

# Generated at 2022-06-25 11:27:52.040531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=["path"],variables={"ansible_facts":{"env":{"HOME":"/home/user","HOSTNAME":"dog","PATH":"/home/user/bin:/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/home/user/bin"},"default_ipv4":{"address":"192.168.122.1"}},"ansible_ssh_host":"localhost","ansible_ssh_port":2222,"ansible_ssh_user":"vagrant"},ansible_connection="ssh",ansible_user="vagrant")

# Generated at 2022-06-25 11:27:56.413512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    lookup_module_0.find_file_in_search_path({}, "lookup_module", "lookup_module")
    terms_0 = ["lookup_module"]
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == ['notempty']

# Write out unit test for our class
import unittest

# Generated at 2022-06-25 11:28:02.286173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/foo.txt']
    variables_0 = None
    kwargs_0 = {}
    with pytest.raises(AnsibleParserError) as excinfo:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert excinfo.value.message == 'Unable to find file matching "/etc/foo.txt" '

# Generated at 2022-06-25 11:28:07.075277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        '/var/tmp/id_rsa',
    ]
    args_1 = {
    }
    kwargs_1 = {
    }
    lookup_module_1.run(terms_1, variables=args_1, **kwargs_1)

# Generated at 2022-06-25 11:28:14.184393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_terms_0 = ['/etc/passwd']
    result = LookupModule.run(lookup_terms_0)
    print(result)

# Generated at 2022-06-25 11:28:20.410709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0._loader.get_real_file = lambda filename, decrypt: filename

    assert lookup_module_0.run(['/etc/foo.txt']) == ['/etc/foo.txt']

# Generated at 2022-06-25 11:28:23.733089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1._loader.get_real_file('/etc/foo.txt', decrypt=True)
    print(result_1)
    lookup_module_1._loader.get_real_file('/etc/foo.txt', decrypt=True)
    print(result_1)






# Generated at 2022-06-25 11:28:26.362143
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This is a very basic test for the 'unvault' lookup plugin.
    # It is intended to be expanded upon in the future.

    # setup
    lookup_module = LookupModule()
    returned_result = lookup_module.run(terms=[], variables={}, **{})

# Generated at 2022-06-25 11:28:32.171241
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:28:37.695753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['path'], variables=None, **{'vault_password': 'password'})


# Generated at 2022-06-25 11:28:39.084841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '/root/ansible/tests/units/lookup_plugins/unvault/fixtures/test_file_1.txt'
    lookup_module.run(terms)

# Generated at 2022-06-25 11:28:41.235045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(lookup_module_0, 'lookup_plugin_test_file.txt')

# Generated at 2022-06-25 11:28:43.105787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:28:51.751197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    src_0 = 'ansible-myhost.example.com'
    terms_0 = [src_0]
    ret_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:29:03.224257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (bytes_0,)
    str_1 = 'lI$g!P3H09DQ5,>k%'
    var_0 = lookup_module_0.run(str_0, tuple_0, str_1)
    assert check_get_escaped_char('P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ') == var_0


# Generated at 2022-06-25 11:29:10.750608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'm3uVJ'
    lookup_module_1 = LookupModule(str_0)
    tuple_0 = ('b\x1f\x1dKl*8\xd7]\x81\x85\xdc\x8b\xa9\x1d\xab\x18',)
    var_0 = lookup_module_0.run(tuple_0, dict(foo='bar'))
    var_1 = lookup_module_1.run(tuple_0)


# Generated at 2022-06-25 11:29:16.261022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_2 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_2,)
    var_0 = lookup_module_1.run(str_0, tuple_0)
    assert var_0 == [b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ']

# Generated at 2022-06-25 11:29:22.706050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with path '/etc/password' as a term
    lookup_module_0 = LookupModule()
    str_0 = '/etc/passwd'
    tuple_0 = (str_0,)
    var_0 = lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:29:29.306017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ('pY.B\x1fc',)
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 is not None
    assert var_0 == b'\rF\x7f:\x90\xcf(3\x04\x8a\xcc\x1a'


# Generated at 2022-06-25 11:29:31.426191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['/etc/foo.txt'])


# Generated at 2022-06-25 11:29:32.845460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run(None, None, None)

# Generated at 2022-06-25 11:29:38.084860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [str_0]
    variables = tuple_0
    kwargs = {'ini': b'\x053\x19K\x80\xf4\x1e\xdc\x02\x97\x0c\x8d\x08\xf2\x1b\x00\xc8\x04\x9d\xcc\x1d\x00\x01\x11\x80\xaf'}
    raise NotImplementedError


# Generated at 2022-06-25 11:29:42.647452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for i in range(10):
        lookup_module_0 = LookupModule()
        str_0 = '%s'
        str_1 = 'lI$g!P3H09DQ5,>k%'
        str_2 = str_0 % str_1
        tuple_0 = ()
        var_0 = lookup_run(str_2, tuple_0)


# Generated at 2022-06-25 11:29:47.493063
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    var_0 = lookup_module_0.run(str_0, tuple_0)

# Generated at 2022-06-25 11:30:01.338840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = '0'
    str_1 = '1'
    bytes_0 = b'2'
    str_2 = '3'
    list_0 = []
    lookup_module.set_options(var_options=list_0, direct=None)
    lookup_module.run(terms=list_0)
    lookup_module.run(terms=list_0, variables=list_0)
    lookup_module.run(terms=list_0, variables=list_0, **{str_0: list_0})
    str_3 = '4'
    lookup_module.run(terms=list_0, variables=list_0, **{str_1: list_0, str_3: list_0})

# Generated at 2022-06-25 11:30:10.828524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    str_1 = '\x94\xda\xb0\x9c\xaft\xc8\x18\x94\x14\xa2'
    lookup_module_4 = LookupModule(str_1)
    str_2 = '\x18\xa3\x8cj\x0c\xeb\x9c\x8f\x16\xb0\xde'
    lookup_module_5 = LookupModule(str_2)
    int_0 = lookup_module_2.run(lookup_module_5, lookup_module_4)


# Generated at 2022-06-25 11:30:15.750027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    var_0 = lookup_run(str_0, tuple_0)


# Generated at 2022-06-25 11:30:22.462552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupBase()
    str_0 = '*dX\xcf\xe1`\xdd+'
    tuple_0 = (lookup_module_0,)
    var_0 = lookup_run(str_0, tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 11:30:31.945845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    var_0 = lookup_run(str_0, tuple_0)
    print(var_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:30:36.794238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'aK'
    tuple_0 = (lookup_module_0,)
    var_0 = lookup_run(str_0, tuple_0)

# Generated at 2022-06-25 11:30:41.894509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (None, lookup_module_0, lookup_module_1)
    var_1 = tuple_0[0]
    var_2 = tuple_0[1]
    var_3 = tuple_0[2]
    var_2.run(str_0, variables=var_1, **var_3)


# Generated at 2022-06-25 11:30:44.124617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    tuple_0 = (lookup_module_0,)
    var_0 = lookup_run(str_0, tuple_0)


# Generated at 2022-06-25 11:30:46.878603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert None == lookup_module.run()


# Generated at 2022-06-25 11:31:00.773545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '1d5Sm5j_:W-t/'
    tuple_0 = (b'9gWV7v@dC+3V\xc3\x84J\xb6\x82n'[:4], None)
    str_1 = 'aM}zI^c:l:rC'
    tuple_1 = (lookup_module_0, str_1)
    var_0 = lookup_run(str_0, tuple_1)
    assert var_0 == ('D\x02\x9e\x1f\xf5\xa2\xc5\xbbK\xe3\x9f\xa5',)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:31:24.301401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = '\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = '{"test": {"a": "foo"}}'
    str_2 = '{"test": {"a": "bar"}}'

# Generated at 2022-06-25 11:31:32.286506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    var_0 = lookup_run(str_0, tuple_0)

# Generated at 2022-06-25 11:31:34.768984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '<>'
    tuple_0 = (lookup_module_0,)
    var_0 = lookup_run(str_0, tuple_0)

# Generated at 2022-06-25 11:31:37.476907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    case_0_terms = ('/usr/bin/sshd',)
    case_0_variables = {}
    display.debug('case_0: {}'.format(case_0_terms))
    case_0_result = [b'some stuff']
    result = LookupModule().run(case_0_terms, case_0_variables)
    assert(result == case_0_result)

# Generated at 2022-06-25 11:31:44.596362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    var_0 = lookup_module_0.run(str_0, tuple_0)

# Generated at 2022-06-25 11:31:54.151631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'.\r>\x04\xae\xd9\xcdO\xfc\xa8\x8f\xc7\x13\xb1\x1b\x9b\xea\xeb\xce\xb8\x82\xbe\x95\x19\x843\x1d\xe2\xbe\xd7\xa4\x7f\x81\x91\x00\x1b\xc7\x13\xca\x94\x00\xaa.\x1e\xdc'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = '1a9RtuEPbtdPY44'
    tuple_0 = (lookup_module_1,)

# Generated at 2022-06-25 11:31:55.978132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Invoke method
    #assert str_0 == str_1    
    assert True

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:32:03.859826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(random_mock())
    lookup_module_1 = LookupModule(random_mock(), random_mock())
    str_0 = '>!BvD<W#9,\x0f/L'
    lookup_module_2 = LookupModule(random_mock(), random_mock())
    tuple_0 = (lookup_module_1, lookup_module_2, random_mock())
    var_0 = lookup_module_0.run(str_0, tuple_0)
    assert var_0 == list()
    assert lookup_module_0.run(str_0, tuple_0) == list()
    assert lookup_module_0.run(str_0, tuple_0) == list()

# Generated at 2022-06-25 11:32:04.647573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:32:12.765647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'x`0'
    tuple_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:32:47.663577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:32:56.117565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.connection = None
    lookup_module_0.play_context = None
    lookup_module_0.defer_warnings = False
    lookup_module_0.set_options()
    lookup_module_0.set_available_variables()
    str_0 = 'lI$g!P3H09DQ5,>k%'
    lookup_module_1 = LookupModule(str_0)
    lookup_module_0.set_options(var_options=lookup_module_1)
    lookup_module_0.set_available_variables(lookup_module_1)
    str_1 = 'lI$g!P3H09DQ5,>k%'

# Generated at 2022-06-25 11:33:03.843409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bytes_0 = b'\x0fk\xc3\x8b'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = '*\x15)F\x89\xfbj\x1d\xee'
    tuple_0 = (lookup_module_0,)
    var_0 = lookup_run(str_0, tuple_0)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:33:05.650414
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for method format with default value for vars
    test_case_0()

# Generated at 2022-06-25 11:33:16.090234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_8 = '7\x9a\xf5\xa0\xfe\x84\x04\xed\x97m'
    lookup_module_1 = LookupModule(str_8)
    str_9 = 'B\xbc\xd1\xf8\xfe\x9b\x04\xed\x97m'
    lookup_module_0 = LookupModule(str_9)
    str_10 = 'B\xbc\xd1\xf8\xfe\x9b\x04\xed\x97m'
    lookup_module_0 = LookupModule(str_10)
    str_11 = 'B\xbc\xd1\xf8\xfe\x9b\x04\xed\x97m'

# Generated at 2022-06-25 11:33:27.018481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(None, None, None)
    lookup_module_2 = LookupModule()
    bytes_0 = b'\x97\xbc\xc1\xab%\x92\x00\xb7\t\xaa\xea\xaf\x1c\xe3\x9b\x83q\x8fj\x03\x04\x0e\x8f\xed\xf2\xab\x7f\x14\xa4\x1f'
    lookup_module_2.set_loader(None, None, bytes_0)
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:33:32.849974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'W.zv'
    variables_0 = var_0
    test_case_0()
    str_0 = 'EQz{'
    tuple_0 = (variables_0,)
    str_1 = '32NA:B@)A'
    tuple_1 = (str_0,)
    bytes_0 = b'\x97\xde\xa9\x9c\xf6\xeb\xc2\x03\x07\x18\xea\xaa\x9c\x9a\xad\xc4F\x99\x93\x0bq\x05\xf5\xb9\x93\x11\xf3\xc3v\x1a\t\x90\x0b\xef\x89'

# Generated at 2022-06-25 11:33:39.851690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_2 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_2,)
    test_case_0(str_0, tuple_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:33:48.845786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Z#[1F2Df=wL'
    list_0 = list()
    str_1 = 'X9DX'
    bytes_0 = b'}b\x92\xd6\x91\x19\x00\xdb\x08\x0c\xe3-\x8c%\x1f\xbb\xba\xd3\x88\x9d\x00\x80f\x8f\xc1\xb1'
    list_0.append(str_0)
    list_0.append(bytes_0)
    list_0.append(str_1)
    tuple_0 = tuple(list_0)

# Generated at 2022-06-25 11:33:53.884451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleParserError, match='Unable to find file matching "a" '):
        print('a')
        test_case_0()
    with pytest.raises(AnsibleParserError, match='Unable to find file matching "a" '):
        print('b')
        test_case_0()

# Generated at 2022-06-25 11:35:23.018250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'P\xca\x96;\x85\\\t)\xa1%+=\x0eMZ'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    var_0 = lookup_run(str_0, tuple_0)

# Generated at 2022-06-25 11:35:28.150782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'z\x1b\xd4\xef?\xf8r\xb1\xdf>\x0b'
    test_case_0()



# Generated at 2022-06-25 11:35:31.435032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(9, 'c0)#Kv', (b'',))
    lookup_module_2 = LookupModule(b'', ('/etc'))
    lookup_module_3 = LookupModule('/etc')
    assert_equal(lookup_module_0.run(lookup_module_3), lookup_module_2, lookup_module_1)


# Generated at 2022-06-25 11:35:34.060496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('LookupModule_run')


# Generated at 2022-06-25 11:35:39.207565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    bytes_0 = b'\xe8\x8d\x0c\xaf\x80\xbcI\x9e\x9b\x1d\x99\xfe\xc7\x81\xa5\x8f\xed\x0e\x17\x08\xdb\xb1\x16'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = 'JL\\jY\x7f\x184\x0c\x97\x9a\x901\xabjN\x11\t'
    tuple_0 = (lookup_module_0,)
    var_1 = run(str_0, tuple_0)


# Generated at 2022-06-25 11:35:42.583027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'lI$g!P3H09DQ5,>k%'
    lookup_module_1 = LookupModule(bytes_0)
    str_0 = 'lI$g!P3H09DQ5,>k%'
    tuple_0 = (lookup_module_1,)
    lookup_module_2 = LookupModule()
    tuple_1 = (lookup_module_2, 'foo.txt')
    var_0 = lookup_run(str_0, tuple_1)

# Generated at 2022-06-25 11:35:49.548798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:35:58.532499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with valid terms as an argument
    expected = [
        "foo",
        "bar"
    ]
    bytes_0 = b'\xcd\xca\xce\xca\xde\xca\xd3\xca\xd4\xca\xca\xca\xd4\xca\xd3\xca\xde\xca\xce\xca\xc9\xca'
    lookup_module_0 = LookupModule(bytes_0)
    list_0 = [
        lookup_module_0,
        lookup_module_0
    ]
    str_0 = 'unvault'
    tuple_0 = (list_0,)
    actual = lookup_module.run(str_0, tuple_0)
    assert expected == actual

# Generated at 2022-06-25 11:36:04.480694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with 'str' type variable
    str_value = 'some string'
    byte_value = to_bytes(str_value)

    # Test without loader
    result = lookup_module_0.run([str_value], None)
    assert isinstance(result, list), 'result should be of type "list"'
    assert len(result) == 1, 'result should have length 1'
    assert result[0] == byte_value, 'result should contain byte array from from string'

    # Test with loader
    result = lookup_module_0.run([str_value], None, _loader=lookup_module_0._loader)
    assert isinstance(result, list), 'result should be of type "list"'
    assert len(result) == 1, 'result should have length 1'

# Generated at 2022-06-25 11:36:12.985184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = '/'
    tuple_0 = (term_0,)
    lookup_module_0 = LookupModule()