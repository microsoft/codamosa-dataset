

# Generated at 2022-06-25 11:27:17.466261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # args: terms, variables=None, **kwargs
    lookup_module.run(['term/one', 'term/two'], None)

# Integration test for class LookupModule

# Generated at 2022-06-25 11:27:21.752773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['foo']
    variables_1 = None
    kwargs_1 = {'_raw_params': 'foo', '_terms': ['foo'], '_convert': ['foo']}
    ret_1 = lookup_module_1.run(terms=terms_1, variables=variables_1, **kwargs_1)
    assert ret_1 == []

# Generated at 2022-06-25 11:27:23.844179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([])


# Generated at 2022-06-25 11:27:27.499487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    results = lookup_module_0.run(terms_0, variables_0)
    assert results == []

# Generated at 2022-06-25 11:27:34.526726
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookupfile_1 = "/tmp/ansible_ansible-doc_0/roles/test_/tasks/main.yml"
    lookup_module_0.set_loader(loader=None)
    lookup_module_0._loader = None
    lookup_module_0.find_file_in_search_path = test_find_file_in_search_path


# Generated at 2022-06-25 11:27:36.081407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["C:\\Users\\Ajay", "C:\\Users\\Ajay"], variables=None, **{"direct":None}) == []

# Generated at 2022-06-25 11:27:44.267248
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Read unvaulted file(s)

    # term: one
    term_one = ['test_one.vault']
    # variables: None
    variables_one = None

    instance_one = LookupModule()
    res_one = instance_one.run(term_one, variables_one)
    assert res_one == ['Hello test_one!!\n'], 'Expected: Hello test_one!!\n, Actual: %s' % res_one

    # term: two
    term_one = ['test_one.vault', 'test_two.vault']
    # variables: None
    variables_one = None

    instance_one = LookupModule()
    res_one = instance_one.run(term_one, variables_one)

# Generated at 2022-06-25 11:27:47.209062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert(lookup_module_0.run(['']) == [])


# Generated at 2022-06-25 11:27:54.044440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The file exists on the system, set the environment variable ANSIBLE_LOOKUP_PLUGINS
    # to point to the path $PWD/test/functional/test_lookup_plugins/lookup_plugins
    # before running this test
    lookup_module = LookupModule()
    files = ['/etc/ansible/testfile1.yml']
    with open(files[0], 'rb') as f:
        b_contents = f.read()
    txt_contents = to_text(b_contents)
    results = lookup_module.run(files, use_encoding=False)
    assert results[0] == txt_contents

# Generated at 2022-06-25 11:27:59.406432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = u'foo/bar.txt'
    variables = dict()
    lookup_module_0 = LookupModule()
    elements = [u'foo/bar.txt']
    assert lookup_module_0.run(terms=terms, variables=variables) == elements


# Generated at 2022-06-25 11:28:14.340660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module_0 = LookupModule()
    # Test args before passing them to run
    kwargs_0 = {}
    kwargs_0['variables'] = 'zu8%Sx'
    # Test if error is raised when expected
    try:
        assert not lookup_module_0.run('HU;r6uq', kwargs=kwargs_0)
    except Exception:
        pass
    else:
        raise AssertionError('AnsibleParserError not raised')
    # Test if error is raised when expected
    try:
        assert not lookup_module_0.run('nEp.G', kwargs=kwargs_0)
    except Exception:
        pass
    else:
        raise AssertionError('AnsibleParserError not raised')

# Generated at 2022-06-25 11:28:21.822038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(None)
    terms_1 = ["/etc/ansible/vault.txt"]
    variables_1 = {}
    try:
        lookup_module_1.run(terms_1, variables_1)
    except Exception as ex:
        print("Exception message: " + str(ex))
        assert False
    else:
        assert True

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:28:25.754576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'_original_file': 'file'})
    lookup_module_0._loader.set_basedir("/etc/ansible")

    lookup_module_0._loader.set_vault_password("vault")
    assert lookup_module_0.run(["/etc/foo.txt"]) == [u'This is an\nencrypted file.\n']

# Generated at 2022-06-25 11:28:32.109705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Trying to return from a function that returns.
    try:
        lookup_module_1.run(terms=['/etc/ansible/hosts'], variables={u'_ansible_lookup_result_from_previous_refresh': [u'127.0.0.1\tlocalhost']}, direct={})
    except SystemExit:
        pass

    # Trying to return from a function that returns.

# Generated at 2022-06-25 11:28:41.963907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    print("Unvault lookup term: /etc/foo.txt")
    lookup_file = lookup_module_0.find_file_in_search_path()
    print("Unvault lookup found %s" % lookup_file)
    assert lookup_file != None
    actual_file = lookup_module_0._loader.get_real_file()
    b_contents = actual_file.read()
    print(to_text(b_contents))
    ret = to_text(b_contents)
    assert ret == "bar"


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:28:46.792830
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    result = lookup_module_0.run(terms=['./test/data/lookup_plugin/unvault/vaulted_file.yml'], variables={})
    assert result == ['Hello World']


# Generated at 2022-06-25 11:28:48.833644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "/home/test/test-file.yml, /var/test-file.yml"
    lookup_module = LookupModule()
    lookup_module.run(terms)

# Generated at 2022-06-25 11:28:51.985635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    kwargs_0 = ''

    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == None


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:28:58.622493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # CASE-1
    lookup_module_0 = LookupModule()
    terms = ['']
    variables = ['']
    lookup_module_0.run(terms, variables, '')

    # CASE-2
    lookup_module_0 = LookupModule()
    terms = ['']
    variables = ['']
    lookup_module_0.run(terms, variables, '')

# Generated at 2022-06-25 11:29:02.982002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load fixture data.
    fixture_file_path = os.path.join(os.path.dirname(__file__), "fixtures", "test_LookupModule_run_fixture.json")
    with open(fixture_file_path, "rb") as fp:
        fixture = json.loads(fp.read())

    # Unit test the code
    assert lookup_module_0.run(**fixture) == fixture['expected_output']

# Generated at 2022-06-25 11:29:12.463129
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Tests when argument 1 is an empty list
    assert lookup_module_0.run([],{}) == []

# Generated at 2022-06-25 11:29:19.400494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])  # expected return: []
    lookup_module_0.run(['ansible'], variables={'foo': 'bar'})  # expected return: []
    lookup_module_0.run(['ansible'])  # expected return: []

# Generated at 2022-06-25 11:29:26.541201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(variable_manager={}, direct={}, variables={})
    lookup_module._loader = DictDataLoader({u'foo.txt': u'bar\nbaz\n'})
    lookup_module._templar = Templar(loader=DictDataLoader({}), variables={})
    assert lookup_module.run([u'foo.txt']) == [u'bar\nbaz\n']


# Generated at 2022-06-25 11:29:29.936136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    result = lookupModule.run(["/etc/foo.txt"], {"files": [{"/etc/test.txt": "content"}]})
    print(result)
    assert result == ["content"]

# Generated at 2022-06-25 11:29:36.809697
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing _terms=['/etc/foo.txt']
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(['/etc/foo.txt'], variables={})
    assert(ret is not None)

    # Testing _terms=['/etc/foo.txt', '/etc/bar.txt']
    lookup_module_1 = LookupModule()
    ret = lookup_module_1.run(['/etc/foo.txt', '/etc/bar.txt'], variables={})
    assert(ret is not None)

# Generated at 2022-06-25 11:29:39.925951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run( terms=[ "echota" ], variables=None, **dict() )


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:29:51.040785
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup test fixture
    lookup_module = LookupModule()
    lookup_module.set_options = lambda var_options=None, direct=None: None

    # Test 1, _terms = [NONE]
    assert lookup_module.run(terms=[None]) == []

    # Test 2, _terms = ['path1', 'path2', 'path3'], file exists
    lookup_module.find_file_in_search_path = lambda variables, subdir, name: 'file'
    lookup_module._loader = MockLoader(
        get_real_file=lambda lookupfile, decrypt=None: 'actual_file'
    )
    lookup_module._loader.get_real_file.side_effect = [
        'actual_file1',
        'actual_file2',
        'actual_file3'
    ]
   

# Generated at 2022-06-25 11:29:52.336150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "/etc/foo.txt"
    variables = None
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:29:56.687059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["/usr/lib/python2.7/site-packages/ansible/playbooks/files/test.yaml"])

# Generated at 2022-06-25 11:29:58.985142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()


# Generated at 2022-06-25 11:30:23.575021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    content = "my_secret\n"
    with tempfile.NamedTemporaryFile('w+b') as f:
        f.write(content)
        f.flush()
        lookup_module_0 = LookupModule()
        lookup_module_0.find_file_in_search_path = MagicMock(return_value=f.name)
        lookup_module_0._loader = DictObject()
        lookup_module_0._loader.get_real_file = MagicMock(return_value=f.name)
        result = lookup_module_0.run([f.name])
        assert result == [to_text(content)]
        assert lookup_module_0.find_file_in_search_path.call_count == 1
        assert lookup_module_0._loader.get_real_file.call_count

# Generated at 2022-06-25 11:30:26.825419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['/etc/foo.txt']) == []
    assert lookup_module_0.run(terms=['/etc/foo.txt'], variables={'any_old_var': 'bar'}) == []

# Generated at 2022-06-25 11:30:30.805401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    value_2 = lookup_module_1.run(['test-value-1'], variables=None, **{'test-kwarg-1': True})
    assert value_2 == ['test-value-1']

# Generated at 2022-06-25 11:30:37.205571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'tests/lookup_plugins/test_files/unvault_test.txt',
    ]
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == [
        'my_secret_key=my_secret_value\n'
    ]

# Generated at 2022-06-25 11:30:44.827686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Path to the lookup file
    lookupfile = "test_path"
    # variable to hold the return value of method run
    ret = None
    # variable to hold the value of term
    term = "test_term"
    # variable to hold the value of terms
    terms = [term]
    # variable to hold the value of variables
    variables = {"test_variables": "test_variables"}
    lookup_module_0.set_options(var_options=variables, direct={"variable": "variable"})
    # Create test object of class AnsibleParserError
    ansible_parser_error_1 = AnsibleParserError("Test AnsibleParserError")
    # Create test object of class Display
    display_0 = Display()
    display_0.debug("Test Debug")


# Generated at 2022-06-25 11:30:50.823382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_data = b'foo'
    mock_open = mock.mock_open(read_data=file_data)
    lookup_module = LookupModule()
    with mock.patch('ansible.plugins.lookup.lookup_module.open', mock_open, create=True):
        assert lookup_module.run(['test1', 'test2'], {'_original_file': 'file1'}) == [file_data, file_data]

# Generated at 2022-06-25 11:30:57.871430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(dict())
    lookup_module_0.set_basedir(str())
    lookup_module_0.set_context(dict())
    lookup_module_0.set_vars(dict())
    terms = [str()]
    variables = dict()
    result = lookup_module_0.run(terms, variables=variables)
    assert type(result) == list

# Generated at 2022-06-25 11:31:01.313623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['myfile.txt']
    result = lookup_module.run(terms)

# Generated at 2022-06-25 11:31:08.049375
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    f = open("/etc/foo.txt", "w+")
    f.write("Run Tests..")
    f.close()

    lookup_module_1 = LookupModule()

    # Return value of method run of class LookupModule
    terms = ["/etc/foo.txt"]
    variables = {}

    expected_result_1 = ['Run Tests..']
    actual_result_1 = lookup_modul

# Generated at 2022-06-25 11:31:10.557572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # AssertionError: False is not true : unittest.case.FunctionTestCase fail
    assert test_LookupModule_run

# Generated at 2022-06-25 11:31:30.776664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'string'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)
    assert var_0 == 'string'


# Generated at 2022-06-25 11:31:40.061807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  unknown_0 = u'H\x1en'
  unknown_1 = u'4"6~J'
  unknown_2 = u"@V['S"
  unknown_3 = {unknown_1: unknown_0, unknown_0: unknown_2}
  unknown_4 = u'j\x18\\Q'
  unknown_5 = [unknown_2, unknown_0, unknown_3]
  unknown_6 = u'\x1b\x1d\x1a\x07pM\x13'
  unknown_7 = u'\x12\x03\x1f\x1a\x1c\x1f\x11\x17\x02\x1a\x1f\x0f\x1d\x1e'

# Generated at 2022-06-25 11:31:42.410913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True


# Generated at 2022-06-25 11:31:51.938178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    X_0 = LookupModule()
    str_0 = '\xabr\x8b&\xa9A\x84#\x9a\x822c\xa2\x7f\xab\x8f\x9a\x0bM\xfc\x8b\x0f'
    X_1 = '\x16\x9e|\x83G?\x07\x85\x92\xdbt\x93\x97\xee\x9a\x1e\xea\x0bG\xf1'
    list_0 = [X_0, X_1, X_1]
    var_0 = lookup_run(str_0, list_0)


# Generated at 2022-06-25 11:31:58.477018
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    str_0 = 'N\r^\\r'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)

    var_0 = lookup_module_0.run(list_0)
    assert -9==var_0
    str_0 = '\\\x1f1'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)

    var_0 = lookup_module_0.run(list_0)
    assert -2==var_0
    # Tests that can be written independent of _run_lookup_plugin
    str_0

# Generated at 2022-06-25 11:32:09.499837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_0['file'] = '1'
    check_0 = LookupModule()
    check_0.set_options(var_options=var_0, direct={})
    f1 = check_0.find_file_in_search_path(var_0, 'files', '1')
    f2 = check_0.find_file_in_search_path(var_0, 'files', '2')
    path_1 = os.path.realpath('files/1')
    path_2 = os.path.realpath('files/2')
    assert f1 == path_1
    assert f2 == path_2
    actual_file_1 = check_0._loader.get_real_file(f1, decrypt=True)
    actual_file_2 = check_0._loader

# Generated at 2022-06-25 11:32:10.781905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(str_0, list_0)

# Generated at 2022-06-25 11:32:17.639499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Input params as list of path(s) of files to read
    term = "file_name.txt"
    variables = [1, 2, 3]

    # Expected output
    ret = [1, 2, 3]

    # Actual output
    assert lookup_module.run(terms=term, variables=variables) == ret

# Generated at 2022-06-25 11:32:21.609115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [1, 1, 1]
    list_1 = [1, 1, 1]
    list_2 = [1, 1, 1]
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, list_1, list_2)


# Generated at 2022-06-25 11:32:25.101332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('foo')

# Generated at 2022-06-25 11:33:05.541395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '0 e}'
    str_1 = 'Gz}aF\nxs7zW'
    list_0 = lookup_module_0.run(str_0, str_1)
    assert list_0[0] == 'Rgm\nZ?gH\x7f'


# Generated at 2022-06-25 11:33:12.684453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Z\\X,U\rs\n*ge'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_module_0.run(str_0, list_0)


# Generated at 2022-06-25 11:33:16.220995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\x05Sgs\x0b\x0E!\x1a4'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)


if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:33:27.020002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'h_b,U{'
    str_1 = 'Z\\X,U\rs\n*ge'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['foo'] = 'bar'
    dict_0['bar'] = 'baz'
    dict_1['bam'] = 'baz'
    dict_1['baz'] = 'bam'
    dict_0['baz'] = dict_1
    dict_1['foo'] = dict_0
    dict_1['bam'] = 'foo'
    dict_1['bar'] = 'bam'
    dict_0['bam'] = dict_1
    dict_0['foo'] = 'bam'

# Generated at 2022-06-25 11:33:28.172090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert(True)

# Generated at 2022-06-25 11:33:30.993565
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Unit test body
    var_0 = lookup_module_0.run('')


# Generated at 2022-06-25 11:33:37.980973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '<'
    str_1 = '?'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)

    assert True


# Generated at 2022-06-25 11:33:40.404311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '|>$nQ=y'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)


# Generated at 2022-06-25 11:33:42.598878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Z\\X,U\rs\n*ge'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)


# Generated at 2022-06-25 11:33:46.259292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run('/tmp/foo/bar.yml', list_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:35:14.834423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Z\\X,U\rs\n*ge'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)
    assert var_0 == None


# Generated at 2022-06-25 11:35:17.729897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'Z\\X,U\rs\n*ge'
    list_1 = [lookup_module_1, str_1, lookup_module_1]
    var_1 = lookup_module_1.run(str_1, list_1)


# Generated at 2022-06-25 11:35:19.240108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '{{ lookup(unvault, "foo.txt" }}'
    lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:35:26.582560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = "Item = 10"
  var_1 = 0
  var_2 = var_0
  var_3 = None
  var_4 = True
  var_5 = 1
  str_0 = lookup_var(var_0, var_1, var_2, var_3, var_4, var_5)
  var_6 = test_LookupModule_run_0(str_0, var_0)
  return var_6


# Generated at 2022-06-25 11:35:29.496517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_0 = 'q]p\nLZb\x1d`#\x1a'
    list_0 = [lookup_module_0, str_0, lookup_module_1]
    
    var_0 = lookup_run(str_0, list_0)
    assert(var_0 == lookup_run())
    # assert(a.data == data)

# Generated at 2022-06-25 11:35:35.517831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert check_run(LookupModule(), '/etc/ansible/hosts', ['/etc/ansible/hosts'], '#ansible')

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:35:40.914983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  term_0 = 'Z\\X,U\rs\n*ge'
  var_0 = lookup_run(term_0)
  return var_0


# Unit test helper functions

# Generated at 2022-06-25 11:35:46.261768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '/etc/foo.txt'
    list_0 = [lookup_module_0, str_0, lookup_module_0]
    var_1 = lookup_run(str_0, list_0)

# Generated at 2022-06-25 11:35:51.856575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['we', 'we']
    var_0 = LookupModule.run(test_LookupModule_run, list_0)
    if var_0 != None:
        raise Exception("Failed")


# Generated at 2022-06-25 11:35:57.687680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    dict_0 = {'foo': lookup_module_0}
    str_0 = 'vault.yml'
    list_0 = [lookup_module_1, str_0, dict_0]
    assert lookup_run(str_0, list_0) == None
