

# Generated at 2022-06-25 11:27:18.050478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module_0.run(['/etc/hosts'], {'hostvars': {'testhost': {}}}, ansible_vars={})
    assert result[0] == ansible_vars['hostvars']['testhost']

# Generated at 2022-06-25 11:27:18.618159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:27:24.839847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # This test case is not working.
    test_terms_0 = [u'', u'']
    # It is not possible to test this test case because the find_file_in_search_path method is not implemented
    #lookup_module_0.run(test_terms_0, test_variables_0, test_direct_0)
    pass


# Generated at 2022-06-25 11:27:27.087944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'test'
    lookup_module_0 = LookupModule()
    lookup_module_0.run(term, variables=None)

# Generated at 2022-06-25 11:27:29.814163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.find_file_in_search_path.return_value = None
    lookup_module_1.run(terms='/etc/foo.txt')

# Generated at 2022-06-25 11:27:39.510427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()

    lookupfile = lookup_module_1.find_file_in_search_path({}, 'files', '/etc/hosts')
    lookup_module_1._loader.get_real_file(lookupfile, decrypt=True)
    actual_file = lookup_module_1._loader.get_real_file(lookupfile, decrypt=True)
    with open(actual_file, 'rb') as f:
        b_contents = f.read()
    to_text(b_contents)

    test_case_0()

# Generated at 2022-06-25 11:27:42.007095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for lookup_module_0
    lookup_module_0 = LookupModule()
    # TODO

if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-25 11:27:46.984761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'dummy']
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == []

test_LookupModule_run()

# Generated at 2022-06-25 11:27:50.681818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["../../../tmp/ansible_file1.txt"]
    testcase_0 = lookup_module_0.run(terms_0)
    assert ['b"/tmp/ansible_file1.txt\\n"'] == testcase_0

# Generated at 2022-06-25 11:27:52.118757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# Generated at 2022-06-25 11:28:01.766685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_terms_0 = ["putanja_ka_fajlu"]
    var_variables_0 = [None]
    var_kwargs_0 = [None]
    result_0 = lookup_module_0.run(var_terms_0, var_variables_0, **var_kwargs_0)
    assert len(result_0) == 1

# Generated at 2022-06-25 11:28:04.636796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)

# Generated at 2022-06-25 11:28:08.822367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/foo.txt', '/etc/bar.txt']
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)


# Generated at 2022-06-25 11:28:13.863298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._display = mock.MagicMock()
    lookup_module_0._display.debug = mock.MagicMock()

    # Input parameters list for method run
    # of lookup_module_0
    term_0 = []
    lookup_module_0.run(term_0)
    lookup_module_0._display.debug.assert_called_with('Unvault lookup term: %s')

# Generated at 2022-06-25 11:28:22.653573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arguments of run
    terms = str
    variables = dict
    kwargs = dict
    # record
    lookup_module = LookupModule()
    lookup_module.set_options = MagicMock()
    lookup_module.find_file_in_search_path = MagicMock()
    lookup_module._loader.get_real_file=MagicMock()
    with open(actual_file, 'rb') as f:
        b_contents = f.read()
    ret_lookup_module = lookup_module.run(terms, variables, **kwargs)
    assert ret_lookup_module == to_text(b_contents)

# Generated at 2022-06-25 11:28:24.985517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['foo.txt', 'bar.txt'], variables=None)
    assert isinstance(var_0, list)



# Generated at 2022-06-25 11:28:26.559499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == None



# Generated at 2022-06-25 11:28:31.043753
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=None, variables=None)



# Generated at 2022-06-25 11:28:34.484207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    term_0 = '/etc/foo.txt'
    assert lookup_module_0.run([term_0]) == var_0


# Generated at 2022-06-25 11:28:36.607128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = LookupModule()
    assert(var) # constructed

    # test 1
    term = '/etc/foo.txt'
    var_0 = lookup_run(var, terms=[term])


# Generated at 2022-06-25 11:28:49.398747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.unvault import LookupModule
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible.cfg']
    variables_0 = None
    term_0 = lookup_module_0.run(terms_0, variables_0)
    assert term_0 == [b'[defaults]\nhost_key_checking = False\nretry_files_enabled = False\n\n[persistent_connection]\ncommand_timeout = 60\nconnect_timeout = 60\n']


# Generated at 2022-06-25 11:28:58.688030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._display = Display()
    lookup_module_0._display.verbosity = 3
    lookup_module_0.set_options(direct={'_ansible_no_log': True})
    lookup_module_0._loader = DictDataLoader({'vars/main.yml': 'foo: bar'})
    var_0 = lookup_module_0.run(terms=['vars/main.yml'], variables={'role_path': '/tmp/ansible-role-foo/'})
    assert len(var_0) == 1
    assert var_0[0] == 'foo: bar'


# Generated at 2022-06-25 11:29:01.722442
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # case 0
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[], variables=None, **kwargs)
    assert isinstance(var_0, list)
                                                                                                    




# Generated at 2022-06-25 11:29:11.237949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options()
    lookup.get_basedir = MagicMock(return_value='/foo/bar')
    lookup._loader.get_real_file = MagicMock(return_value='/baz/qux')
    lookup.find_file_in_search_path = MagicMock()
    lookup.get_basedir = MagicMock(return_value='/foo/bar')
    lookup._loader.get_real_file = MagicMock(return_value='/baz/qux')
    lookup.find_file_in_search_path = MagicMock()
    lookup._loader.get_real_file = MagicMock(return_value='/baz/qux')

# Generated at 2022-06-25 11:29:17.115399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_terms_1 = ['var_terms_1']
    var_kwargs_1 = dict(
        ansible_vars=dict(
            ansible_check_mode=True,
            ansible_debug=True,
            ansible_diff=True,
            ansible_diff_peek=dict(
                hash_behaviour='replace',
            ),
            ansible_local=dict(
                files='files',
            ),
            ansible_search_path=['var_search_path_1'],
        ),
        other='var_other_1',
    )
    var_return_1 = lookup_module_1.run(var_terms_1, **var_kwargs_1)
    assert var_return_1 == ['var_return_1']

# Generated at 2022-06-25 11:29:18.603897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 11:29:25.470628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  b_value_1 = False
  try:
    lookup_module_1.run(u"/", None)
  except TypeError:
    b_value_1 = True
  assert( b_value_1 == True)


# Generated at 2022-06-25 11:29:29.083929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    var_1 = lookup_run(lookup_module_1)
    assert lookup_module_1.run(None) == lookup_module_2.run(None)


# Generated at 2022-06-25 11:29:31.731843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleParserError) as error:
        lookup_module_0.run([''], None)
    assert 'AnsibleParserError: Unable to find file matching "" ' in str(error.value)

    with pytest.raises(AnsibleParserError) as error:
        lookup_module_0.run([''], None)
    assert 'AnsibleParserError: Unable to find file matching "" ' in str(error.value)

# Generated at 2022-06-25 11:29:36.261652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    variables_0 = None
    kwargs_0 = {'direct': None}
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert var_0 is None

# Generated at 2022-06-25 11:29:46.151154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:29:49.967340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:29:51.919753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:29:57.232554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert type(var_1) is list
    assert len(var_1) == 1
    assert type(var_1[0]) is str

# Generated at 2022-06-25 11:29:59.903212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # a very basic test
    test_case_0()

# Generated at 2022-06-25 11:30:01.246439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0.run(terms='/etc', variables=None, direct=None)) == list

# Generated at 2022-06-25 11:30:07.327439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    # From /usr/local/lib/python2.7/dist-packages/ansible/plugins/lookup/unvault.py
    lookup_module = LookupModule()
    
    # Testing with valid arguments
    
    # Return value of method run of class LookupModule
    lookup_run = lookup_module.run()



# Generated at 2022-06-25 11:30:10.417399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('/etc/foo.txt', 'default', _raw_params=None,
                                 _templar=None, _loader=None, ansible_version=None)


# Generated at 2022-06-25 11:30:16.249215
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_vars = {}

    test_terms = {}

    lookup_module = LookupModule()

# AWX FAILED TEST CASE
    var = lookup_run(lookup_module, test_terms, test_vars)
    assert var == None

    test_vars = {}

    test_terms = {}

    var = lookup_run(lookup_module, test_terms, test_vars)
    assert var == None

# Generated at 2022-06-25 11:30:23.429365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)
    lookup_module_0.run(terms, variables=None)
    lookup_module_0.run(terms, **kwargs)
    lookup_module_0.run(terms)
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:30:43.305552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with open('/etc/foobar') as file:
        foobar = file.read()
        lookup_module_1 = LookupModule()
        lookup_module_1.run(['/etc/foobar'], False)

        lookup_module_2 = LookupModule()
        lookup_module_2.run(['/etc/foobar'], False)

# Generated at 2022-06-25 11:30:52.994873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options = mock.Mock()
    lookup_module_0.find_file_in_search_path = mock.Mock()
    lookup_module_0._loader = mock.Mock()
    var_0 = mock.Mock()
    var_1 = mock.Mock()
    var_1.decrypt = mock.Mock()
    lookup_module_0._loader.get_real_file = mock.Mock(return_value=var_1)
    var_2 = mock.Mock()
    var_2.read = mock.Mock(return_value=bytearray(b''))
    var_2.__enter__ = mock.Mock(return_value=var_2)
    var_2.__exit__

# Generated at 2022-06-25 11:30:58.029343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0
    # Create objects
    lookup_module_0 = LookupModule()
    # Run method
    var_0 = lookup_module_0.run(['test_data/test_unvault.yml'], lookup_module_0.set_options())
    # Assert result
    assert var_0 == [b'test_data/test_unvault.yml\n']

# Generated at 2022-06-25 11:31:01.351847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:31:05.065621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        '/etc/foo.txt',
    ]
    variables = {}
    ret = lookup_run(lookup_module, terms=terms)
    assert ret == ['contents of foo.txt\n']


# Generated at 2022-06-25 11:31:06.797136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == test_case_0()

# Generated at 2022-06-25 11:31:09.904839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert len(var_0) == 3



# Generated at 2022-06-25 11:31:11.946104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == "abcd"

# Generated at 2022-06-25 11:31:22.087827
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    var_0 = lookup_module_0.run(['test_key', 'test_key_1'])
    var_1 = lookup_module_1.run(['test_key', 'test_key_1'], variables={'files_ignore_pattern': '*'})
    assert isinstance(var_0, list)
    assert isinstance(var_1, list)
    assert var_0 == var_1
    var_0 = lookup_module_0.run(['test_key', 'test_key_1'], variables={'files_ignore_pattern': 'test_key'})

# Generated at 2022-06-25 11:31:24.736290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == '{% raw %}{{foo}}{% endraw %}'


# Generated at 2022-06-25 11:32:03.151085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([u'does_not_exist.txt'], {})
    assert var_1 == []


# Generated at 2022-06-25 11:32:05.156935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, vars_0, **var_0)
    assert var_0 == str_0


# Generated at 2022-06-25 11:32:06.836823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_30 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:32:09.940632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:32:16.177176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([])
    assert var_1 == []
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run([''])
    assert var_2 == []
    lookup_module_3 = LookupModule()
    var_3 = lookup_module_3.run([])
    assert var_3 == []
    lookup_module_4 = LookupModule()
    var_4 = lookup_module_4.run([''])
    assert var_4 == []
    lookup_module_5 = LookupModule()
    var_5 = lookup_module_5.run([])
    assert var_5 == []
    lookup_module_6 = LookupModule()
    var_6 = lookup_module_6

# Generated at 2022-06-25 11:32:19.573763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = None
    variables_1 = {}
    kwargs_1 = {}
    var_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    if var_1 is not None:
        raise AssertionError('Expected a none return, got {0}'.format(var_1))


# Generated at 2022-06-25 11:32:21.179293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if (len(lookup_module_0.run(['/etc/foo.txt']))):
        raise AssertionError


# Generated at 2022-06-25 11:32:26.792335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('/etc/hosts') == lookup_run(lookup_module)
    assert lookup_module.run('/etc/hosts') != lookup_run(lookup_module, term='/etc/slapd.conf')

# Generated at 2022-06-25 11:32:27.245738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 11:32:32.825424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Testing with term = ''
    term_0 = ''
    var_0 = lookup_module_0.run(term_0)
    assert type(var_0) is list


# Generated at 2022-06-25 11:33:45.469145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'meh': 'meh'}
    var_1 = []
    var_2 = {}
    lookup_module_0 = LookupModule()
    var_return_0 = lookup_module_0.run(var_1, var_0, **var_2)
    assert var_return_0 == []

# Generated at 2022-06-25 11:33:47.160581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    x_1 = lookup_run(lookup_module_1)
    assert x_1 == None



# Generated at 2022-06-25 11:33:50.773561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    search_path_0 = __file__
    term_0 = 'foo'
    lookup_module_0.run(terms=[term_0], variables={'ansible_lookup_direct': {'searchpath': search_path_0}})


# Generated at 2022-06-25 11:33:57.897383
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set the lookup parms
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)

    # All enabled tests
    # term_0 = '/etc/foo.txt'
    # term_val_0 = 'Test Value'
    # run_terms_0 = [term_0, term_val_0]
    # lookup_module_0.run(run_terms_0, variables, **kwargs)



# Generated at 2022-06-25 11:34:02.514247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(None, None)
    assert var_1 is None

# Generated at 2022-06-25 11:34:04.578687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# def lookup_run(lookup_module_0):
    lookup_module_0.run(terms=list([]), variables=None, **None)



# Generated at 2022-06-25 11:34:09.489141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert isinstance(var_1, str) == True

# Generated at 2022-06-25 11:34:14.202383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test of the method run where '_terms' is required
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0, '_terms')

# Generated at 2022-06-25 11:34:16.210498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:34:17.703328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # test case 1
    var_1 = lookup_run(lookup_module_1)

