

# Generated at 2022-06-11 16:20:27.648527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:20:36.870677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from io import StringIO
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.unittest import mock_open
    from ansible_collections.ansible.community.tests.unit.plugins.lookup import TestLookupBase

    tester = TestLookupBase('unvault')
    tester.backup_loader_module()

    # Test creating object of LookupModule
    lookup = LookupModule()

    # Test terms is empty
    terms = list()
    assert lookup.run(terms) == []

    # Test not found lookupfile
    lookup._loader = mock.MagicMock()

# Generated at 2022-06-11 16:20:40.446963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print(lookup_module.run(['/etc/passwd']))

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 16:20:41.096949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:20:44.166512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_test = LookupModule()
    lookup_test.set_loader(MockLoader())
    result = lookup_test.run(["/foo.txt"])
    assert len(result) == 1
    assert result[0] == "Hello World"

# Generated at 2022-06-11 16:20:47.893251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run(["test"], variables={"files": {'test': 'test.txt'}})
    assert ret == ['{"foo": "bar"}\n']

# Generated at 2022-06-11 16:20:59.141607
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLoader(object):

        def get_real_file(self, file_name, decrypt=False):
            return file_name

    class MockDisplay(object):

        def debug(self, msg):
            pass

        def vvvv(self, msg):
            pass

    # Scenario: the file is found
    mock_loader = MockLoader()
    lookup_module = LookupModule()
    lookup_module._loader = mock_loader
    display = MockDisplay()
    lookup_module.display = display
    result = lookup_module.run(terms=['/etc/foo.txt'], variables={'files': ['/etc/foo.txt', '/etc/bar.txt']})

    assert result == ['/etc/foo.txt']

    # Scenario: the file is not found
    mock_loader = MockLoader()
   

# Generated at 2022-06-11 16:21:00.061961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO
    return

# Generated at 2022-06-11 16:21:01.884496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['tests/lookup_plugins/test_unvault_file']) == [b'Test!\n']

# Generated at 2022-06-11 16:21:03.858707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    assert lookup_obj.run(["/etc/hosts"])

# Generated at 2022-06-11 16:21:18.041802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
      from ansible.parsing.dataloader import DataLoader
      from ansible.vars.manager import VariableManager
      from ansible.inventory.manager import InventoryManager
      from ansible.playbook.play import Play

      loader = DataLoader()
      inventory = InventoryManager(loader=loader, sources=['localhost,127.0.0.1,'])
      variable_manager = VariableManager(loader=loader, inventory=inventory)

      lookup_plugin = LookupModule()

      play_source = dict(
          name="Ansible Unvault Unit test",
          hosts='localhost',
          gather_facts='no',
          tasks=[
              dict(action=dict(module='debug', args=dict(msg='{{lookup("unvault", "/etc/hosts")|to_string }}')))
          ]
      )

      play

# Generated at 2022-06-11 16:21:20.891838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        terms=["unvault_test.txt"],
        variables=None
    )
    assert isinstance(ret, list)
    assert ret[0] == 'TEST\n'

# Generated at 2022-06-11 16:21:23.070440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['/etc/foo.txt']) == ['hello world\n']

# Generated at 2022-06-11 16:21:26.946203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'_ansible_vault_password_file': u'vault_password_file.txt'})
    result = lookup_instance.run(['Vaulted.txt'], variables={'vault_password': 'mooo'})
    assert result == ['test\n'], 'Values should match'

# Generated at 2022-06-11 16:21:35.327123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    lookup = LookupModule()

    # Create temporary file
    f, f_path = tempfile.mkstemp(text=True)
    with open(f_path, 'w') as fw:
        fw.write('hello world')

    # Call run method
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = '/etc/ansible/vault_password'
    terms = [f_path]
    assert lookup.run(terms) == [u'hello world']

# Generated at 2022-06-11 16:21:38.654623
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/tmp/foo.txt']
    lu = LookupModule()
    res = lu.run(terms, variables={}, **{})
    assert res == ['contents foo']

# Generated at 2022-06-11 16:21:44.495838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Inputs
    terms = ['/etc/foo.txt', '/bar.txt']

    # Expected output
    expected_return = [to_text('Some content, here\n')]

    # Setup the instance
    lm = LookupModule()

    # Run the method
    returned_return = lm.run(terms)

    # Check results
    assert returned_return == expected_return

# Generated at 2022-06-11 16:21:48.519185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["file.txt", "file2.txt"]
    variables = {"random_var":"random_val"}
    kwargs = {"_terms":terms}
    assert LookupModule().run(terms, variables, **kwargs)

# Generated at 2022-06-11 16:21:50.517526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['test']) == [b'Test']

# Generated at 2022-06-11 16:21:59.057316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from .. import LookupModule

    my_file = tempfile.NamedTemporaryFile(mode="w", delete=False)
    my_file.write("test file in tmp dir")
    my_file.close()

    lookup = LookupModule()
    lookup.set_options({})
    lookup.set_loader({'_basedir': os.path.dirname(my_file.name)})

    assert lookup.run([os.path.basename(my_file.name)]) == [u"test file in tmp dir"]

    os.remove(my_file.name)

# Generated at 2022-06-11 16:22:03.765329
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    pass

# Generated at 2022-06-11 16:22:11.532817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    lookup = LookupModule()
    assert os.path.isfile('/etc/resolv.conf')
    lookup.run(terms=['/etc/resolv.conf'])
    test_content = 'TEST_CONTENT'
    test_filename = 'test_file_1'
    with tempfile.NamedTemporaryFile(prefix=test_filename, delete=False) as test_file:
        test_file.write(bytes(test_content, 'utf-8'))
    assert os.path.isfile(test_file.name)
    lookup.run(terms=[test_filename])
    os.remove(test_file.name)
    assert os.path.isfile(test_file.name) == False

# Generated at 2022-06-11 16:22:21.417488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_loader = MockLoader()
    lookup = LookupModule(loader=mock_loader)
    real_file = '/etc/my_file_name'
    contents = 'my contents'

    # Mock _loader.get_real_file
    def get_real_file_side_effect(*args, **kwargs):
        assert kwargs['decrypt']
        return real_file

    mock_loader.get_real_file.side_effect = get_real_file_side_effect

    # Mock the actual file
    def open_side_effect(file, mode):
        assert file == real_file
        assert mode == 'rb'
        return BytesIO(b'_' + contents)

    with patch('builtins.open', Mock(side_effect=open_side_effect)):
        # Run test
        result

# Generated at 2022-06-11 16:22:25.317319
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule
    # Arrange
    lookup = LookupModule()

    # Act
    result = lookup.run(['test.txt'])

    # Assert
    assert result[0] == 'Hello World!'

# Generated at 2022-06-11 16:22:33.575191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_tmpl_file: Terminating file
    test_tmpl_file = "test_tmpl_file"
    # test_phrase: Phrase to be encrypted
    test_phrase = "testing"
    # test_content: Expected contents that is retrieved from the encrypted file
    test_content = "testing\n"

    # Reset returned_data by LookupModule
    returned_data = []

    # test_assertion: List of assertion that should be returned
    test_assertion = []

    # Create test file
    with open(test_tmpl_file, "w") as filehandle:
        filehandle.write(test_phrase)

    # Encrypt test file
    os.system("ansible-vault encrypt %s" % test_tmpl_file)

    # Set up ansible.plugins.lookup.Look

# Generated at 2022-06-11 16:22:45.374326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=E0402
    # pylint: disable=C0412
    import ansible.plugins.lookup
    import os
    import shutil
    import tempfile
    from ansible.parsing.dataloader import DataLoader

    ansible_vars = {'ANSIBLE_REMOTE_TEMP': tempfile.gettempdir()}
    plugin = 'ansible.plugins.lookup'

    actual_file = tempfile.mkstemp()[1]
    os.remove(actual_file)
    open(actual_file, 'w').close()

    expected_file = os.path.join(ansible_vars["ANSIBLE_REMOTE_TEMP"],
                                 os.path.basename(actual_file))

# Generated at 2022-06-11 16:22:53.395317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create dummy file and encrypt with Vault
    import os
    import tempfile
    import yaml
    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    yaml_data = yaml.dump({'key': 'value'})

    # Write yaml_data to temp file and encrypt it
    yaml_fd, yaml_path = tempfile.mkstemp()
    os.close(yaml_fd)
    with open(yaml_path, 'w') as f:
        f.write(yaml_data)

    # Encrypt
    vault = VaultLib(password=vault_password)
    vault.encrypt_file(yaml_path)

    # Run method
    lookup_obj = LookupModule()
    encrypted_yaml_data = lookup_obj.run

# Generated at 2022-06-11 16:23:01.222714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os, sys
    import pytest

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..')) # add parent dir to sys.path

    from plugins.lookup.shared import LookupModule, AnsibleParserError

    lookup_module = LookupModule()

    # 1. test case :
    #     successful run on /etc/passwd
    terms = [ '/etc/passwd' ]
    variables = {}


# Generated at 2022-06-11 16:23:01.856222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:23:12.355282
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Init
    result = []
    terms = ['/etc/passwd']

    # Configure mock
    mock_display = mock.MagicMock()
    display.verbosity = 2
    display.debug = mock_display

    mock_display.debug.return_value = None
    mock_display.vvvv.return_value = None

    # Configure mock
    with mock.patch('ansible.plugins.lookup.unvault.open') as mock_open:

        # Define methods
        class MockOpen:
            def __init__(self):
                self.fake_contents = "fake_contents"
            def __enter__(self):
                return self
            def __exit__(self, type, value, traceback):
                pass

# Generated at 2022-06-11 16:23:22.259541
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    assert lookup_module.run(['_terms'], {}) is None

# Generated at 2022-06-11 16:23:30.667624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock invocation of LookupModule using the class method
    lookup_obj = LookupModule()

    # Create a mock searchpath to find files in
    searchpath = [['/tmp']]

    # Create a mock environment to pass to the lookup object
    environment = {'ANSIBLE_LOOKUP_PLUGINS': '/tmp'}

    # Create a mock file name to read
    read_file = 'readme.txt'

    # Mock up the invocation of lookup_obj.run
    result = lookup_obj.run([read_file], environment, searchpath=searchpath)

    # Assert that the read file text matches the file that was read
    assert(result == 'This is a test.\n')

# Generated at 2022-06-11 16:23:37.650752
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class for module_utils._text
    class MockToText(object):
        @staticmethod
        def to_text(str):
            return "to_text(str=" + str + ")"

    # Mock class for module_utils.display
    class MockDisplay(Display):
        def __init__(self):
            self.mesg = []
        def debug(self, str):
            self.mesg.append("debug: " + str)
        def vvvv(self, str):
            self.mesg.append("vvvv: " + str)

    # Mock class for class LookupBase
    class MockLookupBase(LookupBase):

        def __init__(self, loader):
            self.loader = loader
            self.var_options = None
            self.direct = None
            self.no_lookup

# Generated at 2022-06-11 16:23:49.253240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing environment
    lookup_module = LookupModule()
    lookup_module._loader = MockLoader()
    lookup_module._templar = MockTemplar()
    lookup_module._display = MockDisplay()

    # Initializing test data
    terms = ['/path/to/file']
    t_options = {'var': 'value'}
    d_options = {'verbosity': 7}

    # Setting up customized values
    lookup_module.set_options(var_options=t_options, direct=d_options)

    # Testing with no matching file
    lookup_module.run(terms)
    assert lookup_module.display.debug.call_count == 2
    assert lookup_module.display.vvvv.call_count == 1

# Generated at 2022-06-11 16:23:50.707125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fl = LookupModule()
    assert fl.run(["/path/to/file"]) == [b"foo"]

# Generated at 2022-06-11 16:23:52.345931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([])
    assert result == []

# Generated at 2022-06-11 16:23:59.892637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test cases for the run method of the LookupModule class.
    '''
    # Create a test lookup_module object
    lookup_module = LookupModule()
    # Create dummy file on file system to read
    filename = "/tmp/xyz.txt"
    with open(filename, "w") as f:
        f.write("xyz\n")
    # Run the lookup_module on the file
    result = lookup_module.run([filename])
    assert result[0] == u'xyz\n'

# Generated at 2022-06-11 16:24:08.422445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = type('', (), {
        "find_file_in_search_path": lambda self, variables, file_type, file: file,
        "_loader": type('', (), {
            "get_real_file": lambda self, file, decrypt=True: file
        })
    })

    with open('/tmp/foo.yml', 'w+') as f:
        f.write('bar')

    res = LookupModule.run(mock_self, terms=['/tmp/foo.yml'])
    assert res == ['bar\n']

# Generated at 2022-06-11 16:24:12.440413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader({'_find_file': lambda _, x: '/tmp/foo'})
    terms = ['not-encrypted', 'already-encrypted']
    assert lookup.run(terms) == [b'foo', b'foo']

# Generated at 2022-06-11 16:24:20.411735
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing with a single term
    instance = LookupModule()
    results = instance.run(['./test_lookup_plugins/unvault/lookup_test_file.yml'], {}, variables={}, **{})
    assert results[0].split()[0] == 'test_unvaulted_lookup_plugin:'

    # Testing with a list of terms
    instance = LookupModule()
    results = instance.run(['./test_lookup_plugins/unvault/lookup_test_file.yml', './test_lookup_plugins/unvault/lookup_test_file.yml'],
                           {}, variables={}, **{})
    assert results[0].split()[0] == 'test_unvaulted_lookup_plugin:'
    assert results[1].split()

# Generated at 2022-06-11 16:24:45.037049
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugins
    import ansible.plugins.lookup.unvault
    import os

    terms = [os.path.join(os.getcwd(), 'x')]
    lookup = plugins.lookup_loader.get('unvault', class_only=True)

    # Only two real tests can happen here.
    # First test is checking that if file is not found, AnsibleParserError error is raised
    # Second test is checking that if file has content then that content is returned as text
    try:
        lookup.run(terms)
    except AnsibleParserError as e:
        assert 'Unable to find file matching' in to_text(e)

# Generated at 2022-06-11 16:24:48.444823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = None
    kwargs = {}
    LookupModule.run(terms, variables, **kwargs)


# Generated at 2022-06-11 16:24:56.658002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # call LookupModule.run without arguments
    try:
        LookupModule().run()
    except TypeError as e:
        assert e.args[0] == "run() takes at least 2 arguments (0 given)"

    # call LookupModule.run with only one argument
    try:
        LookupModule().run(terms=[])
    except TypeError as e:
        assert e.args[0] == "run() takes at least 2 arguments (1 given)"

    # call LookupModule.run with valid arguments
    instance = LookupModule()
    instance.run(terms=['/etc'])

# Generated at 2022-06-11 16:24:57.176094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 16:24:59.965573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    assert lookup_instance.run(["unvault.txt"], {"ANSIBLE_DEBUG": False}) == [b'test\n']

# Generated at 2022-06-11 16:25:11.500313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    from ansible.plugins import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inv_manager = InventoryManager(loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    variable_manager._extra_vars = combine_vars(loader=loader, variables=MutableMapping(), vault_password='test_password')
    variable_manager._vault = {
        'password': 'test_password',
    }

    unvault

# Generated at 2022-06-11 16:25:18.611326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'_original_file': './test/files/test_unvaulted.yml'})
    lookup.set_loader(loader={'_basedir': './test'})
    data = lookup.run(['test_unvaulted.yml'])
    assert len(data) == 1
    assert data[0] == u'\n- password: This is another vaulted value\n'

# Generated at 2022-06-11 16:25:26.767695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Unit test for method run of class LookupModule
    lookup_module = LookupModule()
    mock_terms = ['/etc/unvault_test.yml', '/etc/garbage.yml']
    mock_variable = {'role_path': ['../../roles1', '../../roles2'],
                     'hostvars': {'127.0.0.1': {'nested_var':
                                                {'key1': 'value1', 'key2': 'value2'}}}}
    mock_kwargs = {'firstvar': 'firstvalue', 'var2': 'value2'}
    result = lookup_module.run(terms=mock_terms, variables=mock_variable, **mock_kwargs)

# Generated at 2022-06-11 16:25:38.008113
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Due to the way the run method is implemented, I need to replace the
    # find_file_in_search_path method.
    def fake_find_file_in_search_path(variables, dirname, basedir, check=None):
        return './plugins/lookup/test_file.txt'

    # Due to the way the run method is implemented, I need to replace the
    # get_real_file method.
    def fake_get_real_file(lookupfile, decrypt=False):
        with open(lookupfile, 'rb') as f:
            return f

    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display
    import ansible.utils.display
    ansible.utils.display.Display = object

    lookup = LookupModule
    lookup.find

# Generated at 2022-06-11 16:25:43.809468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLoader(object):
        def __init__(self, contents):
            self.contents = contents
        def get_real_file(self, lookupfile, decrypt=True):
            return self.contents
    lookup = LookupModule(loader=MockLoader("Test"))
    assert lookup.run(["a_file_name"]) == [to_text("Test")]

# Generated at 2022-06-11 16:26:28.946376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a dummy class for the plugin
    class Options(object):
        def __init__(self, var_options=None, direct=None):
            self.vault_password = None
            self.vault_identity = None
            self.variables = var_options
            self.direct = direct
    options = Options()

    plugin = LookupModule()
    plugin.set_options(var_options=None, direct=None)

    ##########
    # Case 1 #
    ##########
    # Case 1a: Path in terms exists
    terms = ['/etc/group']

# Generated at 2022-06-11 16:26:39.556238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.context import CLIARGS, context

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'hostvars': {'localhost': {}}}

    context.CLIARGS = {'module_path': '../../library/', 'forks': 10, 'become': False, 'become_method': None, 'become_user': None, 'check': False, 'diff': False}

# Generated at 2022-06-11 16:26:45.860429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys
    import os
    import tempfile
    basedir = tempfile.mkdtemp()
    sys.path.append(basedir)
    terms = ["/etc/foo.txt"]
    content = AnsibleVaultEncryptedUnicode.from_plaintext("foo bar baz", "pass")
    os.makedirs(os.path.join(basedir, "mytest"))
    with open(os.path.join(basedir, "mytest/foo.txt"), "wb") as f:
        f.write(content.encode())
    data = {'lookup_file_path': {'files': basedir}}
    lookup_module = LookupModule()

# Generated at 2022-06-11 16:26:55.444549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module_obj = LookupModule()

    # Create a variable
    variable = dict()
    variable['hostvars'] = dict()

    # Create a variable object
    variable_object = dict()
    variable['hostvars']['all'] = variable_object
    variable_object['ansible_search_path'] = ["/home/username/.ansible/plugins/lookup"]

    # Create a terms
    terms = ["test"]

    # Expected raw output
    b_contents = b'\n#This file is used for testing lookup module.\n#This file is used for testing lookup module.\n#This file is used for testing lookup module.\n#This file is used for testing lookup module.\n#This file is used for testing lookup module.\n'
    expected_raw

# Generated at 2022-06-11 16:27:05.104357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is quick and dirty test with the least of requirements.
    # No unit test for LookupModule.find_file_in_search_path
    test = LookupModule()

    # Assert the content of file "/etc/hosts" is returned by lookup 'unvault'
    assert "127.0.0.1 localhost localhost.localdomain" in test.run(['/etc/hosts'])
    # Assert method run crashes when file not found
    try:
        test.run(['/etc/idontexist'])
    except (AnsibleParserError) as e:
        assert e.message == 'Unable to find file matching "/etc/idontexist" '
    # Test file not found: no crash but lookup return an empty list.
    assert test.run(['/etc/idontexist'])

# Generated at 2022-06-11 16:27:12.180619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Borrowed from action_plugin/__init__.py
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{lookup("unvault", "/root/test")}}')))
             ]
        )


# Generated at 2022-06-11 16:27:15.769194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ['/etc/foo.txt']
    variables = None
    kwargs = None
    ret = lookup_plugin.run(terms, variables, **kwargs)
    assert ret is None

# Generated at 2022-06-11 16:27:17.827143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    assert look.run(['#included_vars.yml'], variables={'playbook_dir':''})

# Generated at 2022-06-11 16:27:28.976462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test: File does not exist
    mock_exists = [False]
    mock_find_file_in_search_path = ['/etc/foo.txt']
    mock_get_real_file = ['/etc/foo.txt']
    mock_open = {'/etc/foo.txt': 'secret_data'}

    l = LookupModule()
    l.get_real_file = lambda x: mock_get_real_file.pop(0)
    l.open = lambda x: mock_open[x]
    l.exists = lambda x: mock_exists.pop(0)
    l.find_file_in_search_path = lambda x, y, z: mock_find_file_in_search_path.pop(0)

    result = l.run(['/etc/foo.txt'])

# Generated at 2022-06-11 16:27:34.592001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    v = VaultLib("ansible")
    test_str = 'test'
    ciphertext = to_bytes(v.encrypt(test_str))
    l = LookupModule()
    result = l.run([ciphertext])
    assert result[0] == test_str

# Generated at 2022-06-11 16:29:09.322081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_variables = {
        'ansible_ssh_private_key_file': "my_key.pem",
        'ansible_ssh_user': "ubuntu",
        'ansible_ssh_host': "1.1.1.1",
        'ansible_connection': "ssh",
        'playbook_dir': "/usr/local/etc"
    }
    mock_terms = ["credentials.vault"]
    mock_class = LookupModule()
    ret = mock_class.run(terms=mock_terms, variables=mock_variables)
    assert ret[0] == to_text("test")

# Generated at 2022-06-11 16:29:17.163630
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultAES256
    from ansible.inventory.manager import InventoryManager

    import pprint


    # generate vault encrypted file encrypted.yml
    vault_password = 'sekret'
    vault_password_file = '/tmp/vault.password'
    with open(vault_password_file, 'w') as f:
        f.write(vault_password)
    vault_secrets = {'decryptme': 'foobar'}
    # create unencrypted file called unencrypted.yml:
    #   plaintext: this data is not encrypted
    # encrypt file to encrypted.yml
    vault = VaultAES256(vault_password)

# Generated at 2022-06-11 16:29:26.573996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Success
    yaml_data = """
- debug: msg="{{lookup('unvault', 'test.yml')|to_string}}"
- debug: msg="{{lookup('unvault', 'test1.yml', 'test2.yml')|to_string}}"
    """
    lookup_mock = LookupModule()
    lookup_mock.set_loader(loader_mock(yaml_data, ["test.yml", "test1.yml", "test2.yml"]))
    assert lookup_mock.run("test.yml") == ["yaml"]
    assert lookup_mock.run("test.yml", "test1.yml") == ["yaml"]

# Generated at 2022-06-11 16:29:34.250436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest

    # create temporary file for testing
    test_file_dir = os.path.dirname(__file__)
    test_file_name = os.path.join(test_file_dir, 'test_file.txt')
    with open(test_file_name, 'w') as f:
        f.write('test_file_contents')

    assert LookupModule().run(terms=[test_file_name]) == ['test_file_contents']

    # remove temporary file
    os.remove(test_file_name)

# Generated at 2022-06-11 16:29:41.655063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # create a yaml file for lookup
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    test_base_dir = os.path.join(cur_dir, 'test_run')
    loader.set_basedir(test_base_dir)

    # set up plugin
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(loader)
    lookup_plugin.set_basedir(test_base_dir)

    # create first vault file
    with open(os.path.join(test_base_dir, 'first_vault_file.yaml'), 'w') as f:
        password = 'password1'
        os.ch

# Generated at 2022-06-11 16:29:46.712965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.unvault import LookupModule
    lookup_module = LookupModule()
    lookup_module.set_options(None, {'_ansible_lookup_plugin': 'lookup_unvault_test_class'})
    assert lookup_module.run(["toto"]) == ["titi"]


# Generated at 2022-06-11 16:29:56.051116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import pytest
    from pytest import raises
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    lookup_plugin = LookupModule()
    loader = DataLoader()
    play_context = PlayContext()

    # Set variables for PlayContext
    play_context.secrets = dict()
    play_context.prompt = None
    play_context.untrusted_user = False
    play_context.connection = None

    # Set variables for VariableManager
    variable_manager = VariableManager()
    variable_manager.loader = loader
    variable_manager.extra_vars = dict()
    variable_manager._options_vars = dict()

    # Call lookup_plugin.run()

# Generated at 2022-06-11 16:30:01.258824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    contains_keywords = "my_secret_keyword"
    with open("/tmp/test_lookup", "w") as f:
        f.write(contains_keywords)
    for term in my_lookup.run(["/tmp/test_lookup"], variables={}, **{}):
        assert term == contains_keywords

# Generated at 2022-06-11 16:30:02.003026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return None

# Generated at 2022-06-11 16:30:08.939048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVars(dict):
        def __init__(self, lookups):
            self.lookups = lookups

        def get(self, name, deflt=None):
            return self.lookups.get(name)

    # setup mock objects
    from ansible.plugins.loader import lookup_loader
