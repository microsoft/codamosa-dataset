

# Generated at 2022-06-23 12:20:36.474199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    assert l.__class__.__name__ == 'LookupModule'

# Generated at 2022-06-23 12:20:47.415590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.version_info[0] < 3:
        from io import open
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.sentinel import Sentinel
    inventory = InventoryManager(loader=DataLoader(), sources=['/dev/null'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._extra_vars = ImmutableDict({"ansible_python_interpreter": "python3"})
    loader = DataLoader()
    display = Display()
    display.verbosity = 99
    context._init

# Generated at 2022-06-23 12:20:48.615885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # First test the constructor of class LookupModule
    module = LookupModule()
    assert module


# Generated at 2022-06-23 12:20:54.049998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    searchpath = ['/path/to/file']
    results = lm.run(terms=['/path/to/file'], variables={'ansible_playbook_python': 'python', 'ansible_playbook_dir': '.', 'ansible_local': {'ansible_lookup_plugins': {'files': searchpath}}, 'ansible_env': {'ANSIBLE_ROLES_PATH': ':'}}, inject=dict(ansible_local={'ansible_lookup_plugins': {'files': searchpath}}))
    assert type(results) == list
    assert results[0] == 'test\n'

# Generated at 2022-06-23 12:20:55.942245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert os.path.isfile(lookup.find_file_in_search_path(os.environ, 'files', 'myfile.yml'))

# Generated at 2022-06-23 12:21:07.064956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Create a temporary file, vault it and then read it back out."""
    # pylint: disable=import-error,no-name-in-module
    import tempfile
    import os
    import ansible.plugins.lookup.unvault

    tmpdir = tempfile.mkdtemp()
    tmppath = os.path.join(tmpdir, 'foo.txt')

    # Write unvaulted file
    with open(tmppath, 'wb') as f:
        f.write(b'test')

    # Read the contents back out
    found = False
    for file_contents in ansible.plugins.lookup.unvault.LookupModule().run([tmppath]):
        found = True
        assert file_contents == 'test'
    assert found

    # Write vaulted file


# Generated at 2022-06-23 12:21:17.605444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import io
    import json
    import unittest

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self._mock_find_file_in_search_path = mock_find_file_in_search_path
            self._mock_get_real_file = mock_get_real_file
            self._mock_get_resource_path = mock_get_resource_path

        def tearDown(self):
            pass


# Generated at 2022-06-23 12:21:18.592609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()

# Generated at 2022-06-23 12:21:25.099064
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import pytest

    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.lookup.unvault import LookupModule

    from ansible_collections.ansible.community.tests.unit.compat import mock

    class Options(object):
        def __init__(self, verbosity=None):
            self.verbosity = verbosity

    # create a temporary test file
    tmp_filename = 'unvault_test_file'
    test_content = 'test content'
    f = open(tmp_filename, 'w')
    f.write(test_content)
    f.close()


# Generated at 2022-06-23 12:21:26.093488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:21:35.003341
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    # Testing the parameter _terms
    with pytest.raises(AnsibleParserError) as excinfo:
      module.run(None)
    assert 'Missing required arguments:' in str(excinfo.value)

    # Testing parameter file not found
    with pytest.raises(AnsibleParserError) as excinfo:
      module.run("file_not_found")
    assert 'Unable to find' in str(excinfo.value)

    # Testing valid file
    result = module.run("lookup_unvault_test.txt")
    assert result == [u'hello\nworld']

    # Testing multiple files
    result = module.run(["lookup_unvault_test.txt", "lookup_unvault_test2.txt"])

# Generated at 2022-06-23 12:21:36.293883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule({}, {}))

# Generated at 2022-06-23 12:21:37.299497
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()

# Generated at 2022-06-23 12:21:38.405962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:21:39.399003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 12:21:42.036603
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.version == 1
    assert LookupModule.priority == LookupBase.priority
    assert LookupModule.__doc__ == LookupBase.__doc__
    assert LookupModule.run

# Generated at 2022-06-23 12:21:43.510921
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert type(lookup_module) == LookupModule


# Generated at 2022-06-23 12:21:48.401033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    try:
        lookup_module.run(terms=None, variables=None)
    except Exception as e:
        assert str(e) == 'Unable to find file matching "<None>" '

    try:
        lookup_module.run(terms=['file1.txt', 'file2.txt'], variables=None)
    except Exception as e:
        assert str(e) == 'Unable to find file matching "file1.txt" '

# Generated at 2022-06-23 12:21:49.253744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:21:59.806349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test orig method behavior
    file_content = b'file_content'
    # pylint: disable=unused-variable,undefined-variable
    @patch.object(LookupModule, 'find_file_in_search_path', return_value=b'/etc/foo.txt')
    @patch.object(LookupBase, '_loader')
    def run_test(loader, find_file_in_path_mock):
        with patch.object(loader, 'get_real_file', return_value='/etc/foo.txt'):
            with patch('__builtin__.open', mock_open(read_data=file_content)):
                # pylint: disable=protected-access
                ret = LookupModule().run([b'/etc/foo.txt'])
                assert ret == [file_content]

# Generated at 2022-06-23 12:22:00.708820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:22:02.670912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Let's start with a simple file to verify unvault process
    pass

# Generated at 2022-06-23 12:22:04.918372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 12:22:13.839885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    # test whether unvault lookup works
    lookup_module = LookupModule()
    test_content = "Hello, ansible"
    file_descriptor, test_name = tempfile.mkstemp()
    test_file = os.fdopen(file_descriptor, 'w')
    test_file.write(test_content)
    test_file.close()
    os.system("ansible-vault encrypt %s " % test_name)

    terms = [test_name]
    ret = list(lookup_module.run(terms))

    assert (ret[0] == test_content)
    os.remove(test_name)

# Generated at 2022-06-23 12:22:16.914046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:22:17.499417
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:22:19.110275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    terms = "file1.txt"
    assert l.run(terms)

# Generated at 2022-06-23 12:22:21.555229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup = LookupModule()

    # Test unvault lookup
    assert lookup.run(['./test/data/vault_file.yml'])

# Generated at 2022-06-23 12:22:22.954338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._options == {}

# Generated at 2022-06-23 12:22:25.085575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run(['bar.txt'], dict(files='/etc'), loader=None)
    assert ret

# Generated at 2022-06-23 12:22:27.894269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of the class
    lm = LookupModule()
    # run the method
    paths = lm.run(['ansible/plugins/lookup/unvault'])
    # check that the returned output is not None
    assert paths

# Generated at 2022-06-23 12:22:30.251980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing constructor")
    a = LookupModule('unvault', 'shared', [], [])
    assert a

# Generated at 2022-06-23 12:22:31.274440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule()) is LookupModule

# Generated at 2022-06-23 12:22:32.215262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-23 12:22:33.248525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:22:33.769578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupBase()
    assert ret is not None

# Generated at 2022-06-23 12:22:34.727798
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:22:36.032125
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm.run is not None

# Generated at 2022-06-23 12:22:39.454998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(terms=['/bin/cat'])
    print(result)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:22:47.660645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    existent_file = '/etc/passwd'
    non_existent_file = '/tmp/doesnotexist'
    non_existent_file_list = ['/tmp/notexist', '/tmp/also-not-exist']

    # constructor should throw error when argument is not a string, but
    # list of non-existent file(s)
    try:
        LookupModule(non_existent_file_list)
        assert False, 'constructor did not throw error when given list'
    except AssertionError:
        raise
    except:
        # correct behavior is for constructor to throw error when given list,
        # so this is a good outcome
        pass

    # constructor should not throw error when given string, even if
    # string is non-existent file

# Generated at 2022-06-23 12:22:53.695183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    mock_loader = DataLoader()
    mock_inventory = VariableManager()
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(mock_loader)
    lookup_plugin.set_inventory(mock_inventory)

    assert lookup_plugin.run([]) == []
    
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:22:55.339628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    print(lm)
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:22:56.573485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:22:57.050729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return

# Generated at 2022-06-23 12:23:07.781359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    assert None == lookupModule.run(None)
    assert None == lookupModule.run(None, variables=None)
    assert None == lookupModule.run(None, variables=None, **None)
    assert None == lookupModule.run(None, None, **None)
    assert None == lookupModule.run(None, None, **{})
    assert None == lookupModule.run(None, None, **{'lookup_name': 'lookup_value'})
    assert None == lookupModule.run(None, None, lookup_name='lookup_value')
    assert None == lookupModule.run([None, None], None, **{})
    assert None == lookupModule.run([None, None], None, lookup_name='lookup_value')

# Generated at 2022-06-23 12:23:13.480925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["/etc/passwd-ansible", "/tmp/doesnotexist"]
    variables = {}
    kwargs = {}

    testobj = LookupModule()
    result = testobj.run(terms, variables, **kwargs)
    assert len(result) == 1
    assert result[0].startswith("root:x:0:0:")
    assert "doesnotexist" not in result[0]
    assert not result[0].endswith("doesnotexist")

# Generated at 2022-06-23 12:23:15.547548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor of class LookupModule."""

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:23:19.065284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['/etc/hosts']
    variables = {}
    assert isinstance(module.run(terms, variables), list)
    assert isinstance(module.run(terms, variables)[0], str)
    assert isinstance(module.run(terms, variables)[0], str)

# Generated at 2022-06-23 12:23:20.069361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:23:21.921070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms='/etc/hosts', unset_vars=None, variables=None, **kwargs)

# Generated at 2022-06-23 12:23:23.856621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return type('LookupModule', (object,), {})()

# Generated at 2022-06-23 12:23:34.709552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping

    tmp_file = os.path.join(tempfile.gettempdir(), tempfile.gettempprefix())
    with open(tmp_file, 'wb') as f:
        f.write(b'foo')

    class MockVarsModule(Mapping):
        def __getitem__(self, key):
            return MockVarsModule

    class MockLoader(object):
        get_real_file = lambda self, lookupfile, decrypt=True: tmp_file
        _get_vars = lambda self: MockVarsModule()
        _get_basedir = lambda self: tempfile.gettempdir()

# Generated at 2022-06-23 12:23:40.829309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Create instance of LookupModule, as if it were instantiated by Ansible
    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=[])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    mock_options = {'connection': 'local'}
    mock_play_context = Play().set_loader(mock_loader)
    mock_play_context.network_os = 'ios'
    mock_play_context.remote_addr = '127.0.0.1'
    mock_play

# Generated at 2022-06-23 12:23:52.039801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Monkey patching the file finder to return a specific path
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import StringIO
    from ansible.utils.path import unfrackpath
    test_pass = '$ANSIBLE_VAULT;1.1;AES256;test_file\nResult\n'
    test_file = StringIO(test_pass)
    vault = VaultLib([('default', VaultSecret('123'))])
    vault.secrets[0][1]._decrypt_file = lambda dummy: test_file
    LookupModule._get_vault = lambda self: vault

# Generated at 2022-06-23 12:24:01.408876
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    mock_loader = DataLoader()
    mock_loader.set_basedir('/tmp')
    mock_loader._search_paths = '/foo'

    mock_variable_manager = VariableManager()
    mock_inventory = InventoryManager()

# Generated at 2022-06-23 12:24:11.521460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check initialization of object, error case
    import os
    import pytest
    from ansible.utils.display import Display
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleParserError
    display = Display()
    lookup_module = LookupModule()
    # Check initialization, success case
    lookup_module = LookupModule(display)
    lookup_module = LookupModule(display, loader=None)
    lookup_module = LookupModule(display, loader=None, templar=None)
    # Check _join_path, success case
    lookup_module._join_path(None, None)
    lookup_module._join_path("", None)
    lookup_module._join_path(None, "")
    # Check run, success case

# Generated at 2022-06-23 12:24:15.070914
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._display = Display()
    lookup_module._display.verbosity = 4

    assert 'unvault' == lookup_module.name
    assert lookup_module._display.verbosity == 4

# Generated at 2022-06-23 12:24:16.314024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:24:16.874387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:24:22.418062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert repr(lookup_module) == '<ansible.plugins.lookup.unvault.LookupModule object at 0x7fa86cdb5b38>'
    global RETURN
    assert lookup_module._get_docspec() == RETURN
    assert lookup_module._lookup_plugin == 'unvault'
    assert lookup_module._templar == 'AnsibleUndefined'
    assert lookup_module._loader == 'AnsibleUndefined'
    #assert lookup_module._templating == 'AnsibleUndefined'
    assert lookup_module._loader_name == 'AnsibleUndefined'

# Generated at 2022-06-23 12:24:34.392297
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:24:35.585644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:24:37.292966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check object created is instance of LookupModule class provided by Ansible
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 12:24:38.170413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, 'removed'

# Generated at 2022-06-23 12:24:38.709129
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:24:48.067513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader({})
    # Actual contents of unvaulted file
    lookup._loader.set_vault_password("vaultpass")
    result = lookup.run(terms=["unvault_file_exists"],
                        variables={"ansible_vault_password": "vaultpass"})
    assert result == [b"Lookup - Unvault\n"]

    lookup._loader.set_vault_password("wrong")
    try:
        lookup.run(terms=["unvault_file_exists"],
                   variables={"ansible_vault_password": "wrong"})
    except AnsibleParserError:
        pass


# Generated at 2022-06-23 12:24:50.743562
# Unit test for constructor of class LookupModule
def test_LookupModule():
	lm = LookupModule()
	assert lm
	assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 12:24:51.741479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-23 12:24:54.037175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(['unit.txt']) == ['test']

# Generated at 2022-06-23 12:25:04.245576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    plugins_path = '/Users/yplee/GitHub/ansible/lib/ansible/plugins/lookup/unvault'
    from ansible_collections.ansible.community.plugins.modules import community as community_module
    community_module.CollectionLoader.update_collection_paths(
        {'community': [plugins_path]},
        ['ansible_collections.ansible.community.plugins.modules', 'ansible.plugins.modules'],
        False
    )
    lookup_obj._loader = community_module.CollectionLoader()
    terms = ['/etc/foo.txt']
    variables = {'ansible_playbook_python': '/Users/yplee/anaconda/bin/python'}

# Generated at 2022-06-23 12:25:06.031774
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:25:08.002435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Used for unit test to generate a new class object
    # return the constructor of class LookupModule
    return LookupModule

# Generated at 2022-06-23 12:25:09.715573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert False, 'Not implemented'

# Generated at 2022-06-23 12:25:12.044872
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 12:25:22.554244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.display = Display()
    assert lookup_plugin.run([], variables={}, **{}) == []
    assert lookup_plugin.run([], variables={}, **{'_ansible_pid': '1234'}) == []
    assert lookup_plugin.run([], variables={}, **{'_ansible_pid': '1234', '_ansible_vault_password_file': '/tmp/password_file'}) == []
    assert lookup_plugin.run([], variables={}, **{'_ansible_pid': '1234', '_ansible_vault_password_file': '/tmp/password_file', '_ansible_verbosity': '4'}) == []

# Generated at 2022-06-23 12:25:30.373818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test uses optparse to avoid problem with docopt parsing arguments
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.cli import CLI
    import io
    import os
    import sys
    import StringIO

    # Reset the command line arguments to an empty list
    sys.argv = [sys.argv[0]]
    p = CLI.base_parser(
        usage='unit testing',
        usage_raw=True,
        desc='do stuff',
        epilog='none',
        sep='^',
        add_help=False)
    p.set_usage('%prog [options]')
    # Must be set to True or

# Generated at 2022-06-23 12:25:32.354988
# Unit test for constructor of class LookupModule
def test_LookupModule():
  try:
    lookup_module = LookupModule()
  except Exception as e:
    print(e)
  else:
    assert(lookup_module)

# Generated at 2022-06-23 12:25:34.051183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run([], None) == []

# Generated at 2022-06-23 12:25:41.692545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("\n--------[ Test LookupModule ]--------")
    test_lookup_data = {"lookup_item1": "lookup_value1", "lookup_item2": "lookup_value2"}
    test_terms = ["lookup_item1", "lookup_item2"]
    my_lookup_module = LookupModule()
    print("\n--------[ Expected result ]--------")
    print("The following result should be printed below this line.", "\n")
    print("lookup_value1", "\n", "lookup_value2")
    print("\n--------[ Actual result ]--------")
    print("The following result should be printed below this line.", "\n")
    print(my_lookup_module.run(test_terms, test_lookup_data))

# Generated at 2022-06-23 12:25:46.512456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    lookup = LookupModule()
    temp_dir = tempfile.gettempdir()
    temp_file = os.path.join(temp_dir, 'temp_file')

    try:
        with open(temp_file, 'w') as f:
            f.write("This is a test file")

        ret = lookup.run(terms=[temp_file])
        assert ret == [u"This is a test file"]

    finally:
        os.remove(temp_file)

# Generated at 2022-06-23 12:25:48.241891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:25:49.657869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-23 12:25:51.897296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['/example/path/file1']
    assert lm.run(terms) == [b'/example/path/file1']

# Generated at 2022-06-23 12:26:00.574276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib

    vaultfile = '../../docs/vault.txt'
    vaultpassword = 'my_secret'
    vaultContents = "Vaulted string"

    # Create vaulted file
    vault = VaultLib([])
    vault.password = vaultpassword
    vault_bytes = to_bytes(vault.encrypt(vaultContents), encoding='utf-8')
    with open(vaultfile, "w") as f:
        f.write(vault_bytes)

    # Test unvaulted file

    unvault = LookupModule()

# Generated at 2022-06-23 12:26:09.795618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # These files do not exist in the system
    assert lookup.run(['randomfile']) == []
    assert lookup.run(['randomfile','randomfile2','randomfile3']) == []

    # No match for terms
    assert lookup.run(['./randomfile']) == []
    assert lookup.run(['../randomfile']) == []

    # The system cannot find the path specified
    assert lookup.run(['randomfile.txt']) == []
    assert lookup.run(['/../randomfile.txt']) == []

    # These file(s) exist in the system

# Generated at 2022-06-23 12:26:11.155697
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup.__class__ == LookupModule

# Generated at 2022-06-23 12:26:15.240476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    terms = ['/etc/foo.txt', '/etc/bar.txt']
    ret = lookup.run(terms)
    assert(ret)

    terms = ['foobar.txt']
    ret = lookup.run(terms)
    assert(not ret)

# Generated at 2022-06-23 12:26:18.961515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    test_terms = list(range(1,10))
    ansible_vars = dict()
    module.run(test_terms, ansible_vars)

# Generated at 2022-06-23 12:26:27.771451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mocked objects
    class MockLoader:
        def get_real_file(self, file, decrypt=False):
            if file == 'test_file.vault':
                return 'files/test_file.vault'
            return None

    loader = MockLoader()
    lookup = LookupModule()

    # Mocked data
    foo_content = b"bar"
    with open("files/test_file.vault", "wb") as f:
        f.write(foo_content)

    # Call to the tested method
    actual = lookup.run(['test_file.vault'], loader, None)

    # Asserts
    assert actual == [foo_content]
    assert actual[0] == foo_content

# Generated at 2022-06-23 12:26:30.244608
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookupModule = LookupModule()

    # Raise exception because terms is empty
    try:
        lookupModule.run(terms=[], variables=None, **{})
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

# Generated at 2022-06-23 12:26:32.280757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:26:33.749202
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:26:36.706602
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        module = LookupModule()
    except Exception as e:
        print("Exception caught when creating instance of LookupModule. %s" % e)
        return False

    return True


# Generated at 2022-06-23 12:26:38.656986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:26:48.679333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil

    lookupfile = 'file.txt'
    b_data = b'This is some test data.'
    b_data_vault = b'$ANSIBLE_VAULT;1.1;AES256;ansible\n6232126466653730663565336133356231323365656633383038616264613930380a66653734373462626233633437303732303639353430653766386335346639640a373730313766653962636361373362313232383534336564343062646162386639\n'

# Generated at 2022-06-23 12:26:56.013968
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockTerm(object):
        def __init__(self):
            self.name = None

    terms = [MockTerm(), MockTerm()]
    terms[0].name = '/path/to/vaulted.myfile'
    terms[1].name = '/path/to/unvaulted.myfile'

    import ansible.plugins.loader as loader
    loader.add_directory(os.path.dirname(__file__))
    lm = LookupModule()

    ret = lm.run(terms=terms)
    assert ret[0] == 'vaulted content'
    assert ret[1] == 'unvaulted content'

    loader.cleanup_all_tmp_files()

# Generated at 2022-06-23 12:26:59.298132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(terms='foo.txt', inject={'files': '../files'})
    assert results == ["foo\n"]

# Generated at 2022-06-23 12:27:02.031822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Allocate instance of class LookupModule
    lookup = LookupModule()
    # Test a value to see if it returns expected result
    assert lookup.run(['test.txt']) == '1'

# Generated at 2022-06-23 12:27:03.159763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Hacked: to be implemented in future")

# Generated at 2022-06-23 12:27:14.811945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # find_file_in_search_path()
    def mock_find_file_in_search_path(variables, directory, filename):
        return "/foo/bar/baz.txt"

    # get_real_file()
    def mock_get_real_file(filename, decrypt=False):
        return "/foo/bar/baz.txt"

    # open()
    def mock_open(filename, mode):
        return ["123456"]

    lookup_plugin.find_file_in_search_path = mock_find_file_in_search_path
    lookup_plugin.loader._loader.get_real_file = mock_get_real_file
    lookup_plugin.open = mock_open

    # Test

# Generated at 2022-06-23 12:27:16.228970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) == type


# Generated at 2022-06-23 12:27:27.666030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case where the file has already been decrypted
    def run_method_plain_file(file_contents):
        # Create a class that pretends to be the Ansible loader
        class FakeLoader:
            def get_real_file(self, lookupfile, decrypt=False):
                return lookupfile

        # Create a class that pretends to be the Ansible file finder
        class FakeFileFinder:
            def find_file_in_search_path(self, variables, file_type, file_name):
                return find_file_in_search_path_file_name

        # Create a class that pretends to be the Ansible display
        class FakeDisplay:
            def debug(self, msg):
                return

            def vvvv(self, msg):
                return


# Generated at 2022-06-23 12:27:36.097535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'example'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{lookup("unvault", "/etc/ansible/roles/example/files/foo.txt")}}')))
         ]
    )

# Generated at 2022-06-23 12:27:39.901427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup the class object
    lookup_module = LookupModule()

    # Function run() is tested without any arguments passed
    # Expected result is empty list
    assert lookup_module.run() == []

    # Function run() is called with no arguments
    # Expected result is empty list
    assert lookup_module.run([]) == []

    # Function run() is called with valid path of the file
    # Expected result is list of a string
    assert lookup_module.run(['/etc/ansible/hosts']) == ['# This is the default ansible hosts file.\n[test-group]\nlocalhost\n']

# Generated at 2022-06-23 12:27:49.458107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test find_file_in_search_path
    # Mock find_file_in_search_path to return a file name
    # Mock _loader.get_real_file to return the file name itself
    # Mock open to read the contents of the file
    # Assert that the contents read from file should be same as what is returned by the LookupModule.run method
    # Call LookupModule.run method

    terms = ['/tmp/foo.txt', '/tmp/bar.txt']

    # mock find_file_in_search_path
    def find_file_in_search_path_mock(variables, collection_name, file_path):
        return file_path

    # mock _loader.get_real_file
    def get_real_file_mock(file_path, decrypt):
        return file_path

   

# Generated at 2022-06-23 12:27:50.720630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)
    LookupModule()

# Generated at 2022-06-23 12:27:51.972866
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_plugin = LookupModule()
    assert test_lookup_plugin

# Generated at 2022-06-23 12:28:02.990584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   display_obj = Display()
   #unit test for when the file 'term' is found
   expected_find_file_in_search_path_result = "ansible/test/vault/files/foo.txt"
   actual_find_file_in_search_path_result = "ansible/test/vault/files/foo.txt"
   #unit test for when the file 'term' is not found
   expected_find_file_in_search_path_result_if_not_found = None
   actual_find_file_in_search_path_result_if_not_found = None
   #unit test for when the file 'term' is found and has a vault secret

# Generated at 2022-06-23 12:28:03.617752
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-23 12:28:05.701346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['/etc/foo.txt'])

# Generated at 2022-06-23 12:28:07.666943
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([u'fixtures/vault.yml']) == [u'foo: bar\n']

# Generated at 2022-06-23 12:28:09.559449
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Generated at 2022-06-23 12:28:14.705050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/foo.txt']
    variables = {}
    kwargs = {}
    lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    results = lookup.run(terms, variables, **kwargs)
    assert(results == [b'expected contents'])

# Generated at 2022-06-23 12:28:19.774877
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    contents = lookup.run([], {})
    assert contents == [], 'Empty list returned'

    contents = lookup.run(['non-existent_file'], {})
    assert contents == [], 'Empty list returned'

    contents = lookup.run(['sample_file'], {'_files_': ['/tmp/'], '_fit_is_file_': ['.txt']})
    assert contents == ['Standard Input\nStandard Error\n'], 'Contents returned'

# Generated at 2022-06-23 12:28:31.510420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.parsing.vault import VaultLib

    src_file = 'test/legacy/vault/fixtures/globbed_file.yml.vault'
    dest_passwd = './test/legacy/vault/fixtures/tmp_passwd'
    dest_file = './test/legacy/vault/fixtures/tmp_file.yml.vault'

    # First ensure password file is in expected location
    v = VaultLib(password_files=['test/legacy/vault/fixtures/password'])
    with open(dest_passwd, 'wb') as f:
        f.write(v.decrypt(open(src_file).read()))

    # Then open the file using vault lookup
    lookup_mock = LookupModule()
    lookup

# Generated at 2022-06-23 12:28:32.638660
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert getattr(l, 'run')

# Generated at 2022-06-23 12:28:40.421229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import shutil
    import tempfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a vaulted file
    vault_file = os.path.join(tmpdir, 'foo.txt')
    vault_password = 'secretpassword'
    vault_contents = 'secret contents'
    with open(vault_file, 'w') as f:
        f.write(vault_contents)
    vault_args = ["--vault-password-file=%s" % os.path.join(tmpdir, 'pass.txt')]
    with open(vault_args[0][22:], 'w') as f:
        f.write(vault_password + '\n')
    from ansible.parsing.vault import VaultEditor
    vault = Vault

# Generated at 2022-06-23 12:28:50.943684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    lookup_instance = LookupModule()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # This test assumes you will run it from the Ansible test directory so that
    # the test playbook is located at ../../test/test.yml
    test_terms = [
        '../../test/test_lookup_plugins/unvault_test_file.txt'
    ]
    
    expected_result = [
        'This is the unvault test file.\n'
    ]


# Generated at 2022-06-23 12:28:58.575476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    terms = ['/etc/group']
    variables = {'role_path': './tests/fixtures/roles',
                 'playbook_dir': './tests/fixtures'}
    assert lookupModule.run(terms, variables) == [u'root:x:0:root\nbin:x:1:root,bin,daemon\ndaemon:x:2:root,bin,daemon\nuucp:x:4:root,uucp,daemon\nadm:x:3:adm\n'] # noqa

# Generated at 2022-06-23 12:28:59.957349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:29:10.606817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Create an instance of LookupModule so that it can be tested
    """

    class DummyLoader():

        class DummyVarsModule():
            def __init__(self, *args, **kwargs):
                pass

            def __call__(self, *args, **kwargs):
                return self

        class DummyVarsPlugin():
            def __init__(self, *args, **kwargs):
                pass

            def run(self, *args, **kwargs):
                return self

        def __init__(self, *args, **kwargs):
            self.vars = self.DummyVarsModule()
            self.vars_plugins = [self.DummyVarsPlugin()]

        def add_directory(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 12:29:12.369408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # @pytest.mark.skip(reason="why skip it")
    assert True

# Generated at 2022-06-23 12:29:20.616635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    env = {'ANSIBLE_LOOKUP_PLUGINS': '.../lookup_plugins'}
    lookup_plugin = lookup_loader.get('unvault', loader=loader, templar=None, environment=env)
    lookup_plugin.run(['./test/fixtures/unvault_simple.txt'])
    lookup_plugin.run(['./test/fixtures/unvault_complex.txt'])
    lookup_plugin.run(['./test/fixtures/unvault_complex.yml'])
    print("SUCCESS - LookupModule run test")

# Unit test class LookupModule

# Generated at 2022-06-23 12:29:22.764087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:29:29.621466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'_ansible_syspath': ['ansible/test/lib/ansible/plugins/lookup/test_lookups/']})
    test_data = {
        'if': [b'#!/usr/bin/python'],
        'if-not-vaulted': [b'#!/usr/bin/python'],
        'not-existent-file': [b'#!/usr/bin/python']
    }
    for term, expected_result in test_data.items():
        result = lookup.run([term])
        assert result == expected_result

# Generated at 2022-06-23 12:29:33.677394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup_result = lookup.run(["../../../../../../../../../../../../../../../../etc/passwd"],
                               variables={'files': ['/home', './']})
    assert lookup_result == []

# Generated at 2022-06-23 12:29:35.643035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:29:45.071954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_bytes

    test_class = LookupModule()

    test_terms = ['/tmp/foo.txt', '/tmp/bar.txt']

    # pylint: disable=unused-argument
    def mocked_find_file_in_search_path(vars, basedir, file):
        return "foo"

    def mocked_get_real_file(file, decrypt):
        return file

    mocked_open = ['/tmp/foo.txt', '/tmp/bar.txt']

    # The order in which the following two lines are executed is important as otherwise the 
    # mocked object is not used
    test_class._loader.get_real_file = mocked_get_real_file
    test_class.find_file_in_search_path = mocked_find

# Generated at 2022-06-23 12:29:47.019275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-23 12:29:48.678448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:29:49.018843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:29:50.399088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader

# Generated at 2022-06-23 12:29:50.987862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:29:52.294726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:29:54.150685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
     l = LookupModule()
     l.run(['lookup_fixtures/unvault.yml'])

# Generated at 2022-06-23 12:30:03.784564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options:
        connection = LocalConnection()
        remote_user = 'remote_user'
        ack_pass = None
        password = None
        forked = 0
        sudo = False
        sudo_user = None
        become = False
        become_method = None
        become_user = None
        check = False
        diff = False
        verbosity = None
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        module_paths = None
        forks = None


# Generated at 2022-06-23 12:30:14.377625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test_LookupModule_run: test run method of LookupModule """

    # pylint: disable=unused-argument
    def mock_find_file_in_search_path(variables, subdir, filename):
        return 'test_LookupModule_run_temp.txt'

    # pylint: disable=unused-argument
    def mock_get_real_file(filename, decrypt):
        return filename

    class MockLoader(object):
        def get_real_file(self, filename, decrypt):
            return mock_get_real_file(filename, decrypt)

    class MockDisplay(object):
        def __init__(self):
            self.verbosity = 4
        def debug(self, msg):
            print('DEBUG: {}'.format(msg))

# Generated at 2022-06-23 12:30:21.426781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  r = l.run(["/usr/lib64/python2.7/site.py"], variables={})

# Generated at 2022-06-23 12:30:26.524983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    g = ['file1', 'file2']
    x = mod.run(g)
    assert x == [to_text('The quick brown fox jumps over the lazy dog'), to_text('The quick brown hare jumps over the lazy dog')]


# Generated at 2022-06-23 12:30:30.306403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader({})
    assert lookup.run(["executable.txt"]) == [b"list"]
    assert lookup.run(["executable.txt", "executable.txt"]) == [b"list", b"list"]

# Generated at 2022-06-23 12:30:32.801326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the class
    test_class_instance = LookupModule()
    # There is no test method 'run'
    pass

# Generated at 2022-06-23 12:30:34.460161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None
