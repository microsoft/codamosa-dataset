

# Generated at 2022-06-23 12:20:33.073378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:20:41.432601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = 'unvault'
    lookup = LookupModule()
    lookup.get_basedir = lambda **kwargs: '/tmp'
    lookup.set_loader = lambda **kwargs: get_loader()
    lookup.set_options = lambda **kwargs: None

    my_file = u'testfile'
    my_content = u'testcontent'
    lookup.run([my_file])
    assert my_content == to_text(open(u'/tmp/testfile', 'rb').read())
    assert my_content == lookup.run([my_file])[0]


# Generated at 2022-06-23 12:20:47.635133
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None, 'Test of ansible.plugins.lookup.unvault.LookupModule failed: constructor returned None'

    # Test of constructor with invalid argument (not a dict)
    try:
        lookup = LookupModule('invalid')
        assert False, 'Test of ansible.plugins.lookup.unvault.LookupModule failed: constructor did not raise AnsibleError'
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 12:20:56.586934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate the LookupModule class
    lookup_module = LookupModule()

    # Generate mock Utils Module class
    class MockUtilsModule(object):
        pass
    mock_utils_module = MockUtilsModule()

    # Generate mock Display class
    class MockDisplay(object):
        def __init__(self):
            pass

        def debug(self, msg):
            pass

        def vvvv(self, msg):
            pass

    mock_display = MockDisplay()

    # Generate mock AnsibleVaultEncryptedUnicode Class
    class MockAnsibleVaultEncryptedUnicode(object):
        def __init__(self, raw):
            self.raw = raw

        def __str__(self):
            return str(self.raw)

    # Generate mock AnsibleVaultEncrypted

# Generated at 2022-06-23 12:21:03.729891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lmu = LookupModule()
    file = "test_LookupModule_run.yml"
    with open(file, "w") as f:
        f.write("test: test")
    assert lmu.run(["test_LookupModule_run.yml"], variables={"file": "test_LookupModule_run.yml"}) == ["test: test"]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:21:04.386858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:21:13.107414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(argument_spec=dict(
        _raw=dict(type='list', elements="raw")
    ))
    # Set up the parameters for the search path
    variables = dict(
        ansible_lookup_paths=[u'src/test/unit/lib/ansible/plugins/lookup']
    )

    lookup = LookupModule()
    result = lookup.run([u'../lookup_plugins/to-be-secured.txt'], variables=variables)
    result_str = result[0].decode('utf-8')
    assert u'unvaulted contents of to-be-secured.txt' in result_str

# Generated at 2022-06-23 12:21:14.517727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:21:15.640875
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()

    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:21:20.687839
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var_maps = {}
    look = LookupModule()
    look._loader = None

    look.set_options(var_options=var_maps)

    terms = 'test.txt'
    variables = {}
    kwargs = {}
    res = look.run(terms, variables, **kwargs)
    assert res[0] == 'this is a test\n'

# Generated at 2022-06-23 12:21:21.683530
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)


# Generated at 2022-06-23 12:21:23.946473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:21:25.662806
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert not lookup._templar

# Generated at 2022-06-23 12:21:34.486924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins import lookup_loader
    from os import path
    from tempfile import mkstemp
    from shutil import rmtree

    (tmp_fd, tmp_fname) = mkstemp(prefix="unvaulttest_")
    tmp_dir = path.dirname(tmp_fname)
    ansible_search_path = tmp_dir
    lookup = lookup_loader.get("unvault")

    # Write content to file
    with open(tmp_fname, 'w') as f:
        f.write("ansible")
    # Try to read content of file with lookup
    result = lookup.run([tmp_fname], ansible_search_path=[tmp_dir])
    assert result[0] == "ansible"
    rmtree(tmp_dir)

# Generated at 2022-06-23 12:21:36.514490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(terms=["foo.txt"]) == []

# Generated at 2022-06-23 12:21:37.542526
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:21:45.541047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    import os
    import tempfile
    for file in ['/etc/foo.txt', '/etc/bar.txt']:
        with open(file, 'w') as f:
            f.write('Hello World\n')

    # Code to be tested
    lookup_instance = LookupModule()
    ret = lookup_instance.run(['/etc/foo.txt', '/etc/bar.txt'])

    # Tests
    assert len(ret) == 2
    assert ret[0] == 'Hello World\n'
    assert ret[1] == 'Hello World\n'

    # Cleanup
    for file in ['/etc/foo.txt', '/etc/bar.txt']:
        os.remove(file)

# Generated at 2022-06-23 12:21:48.079725
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.find_file_in_search_path(None, 'files', 'foo') is None

# Generated at 2022-06-23 12:21:48.967518
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj

# Generated at 2022-06-23 12:21:50.976360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['foo/bar'], variables={'_filesdir': '/path/to/filesdir'}) == []

# Generated at 2022-06-23 12:21:54.153213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_file_module = LookupModule()
    result = lookup_file_module.run(["test.txt"])
    assert result == [u'hello world\n']

# Generated at 2022-06-23 12:21:58.352416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod._loader = FileLoader(None)
    lookup_mod.set_options({'variable': 'value'}, direct={'variable': 'test'})
    assert lookup_mod.run(['myfile']) == ['myfile']

# Generated at 2022-06-23 12:21:59.256410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:22:01.511137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/foo.txt']
    variables = {}
    kwargs = {}
    lookup = LookupModule()
    assert lookup.run(terms, variables, kwargs)

# Generated at 2022-06-23 12:22:03.831890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Simple test to ensure class LookupModule to be instantiated
    lm = LookupModule()

# Generated at 2022-06-23 12:22:13.994288
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_dict = {}
    my_dict['foo'] = 'bar'

    lookup_module = LookupModule()
    lookup_module._display = Display()
    lookup_module._loader = LookupBase._loader
    lookup_module.set_options(var_options=my_dict, direct=None)

    lookup_module_result = lookup_module.run(['.localhost.yml'],
                                             my_dict,
                                             _original_file='.localhost.yml',
                                             _file_search_path='/etc/ansible/roles/role_under_test/vars')
    assert isinstance(lookup_module_result, list) and lookup_module_result[0] == 'foo: bar'

# Generated at 2022-06-23 12:22:19.414778
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the constructor of the LookupModule class"""

    # should be fine
    LookupModule()

    # should fail
    try:
        assert LookupModule(1)
    except TypeError as e:
        assert "object of type 'int' has no len()" in str(e)
    else:
        assert False

# Generated at 2022-06-23 12:22:20.680992
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:22:22.036205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    LookupModule()



# Generated at 2022-06-23 12:22:25.350382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.unsafe_proxy import UnsafeProxy

    lookup_plugin = LookupModule()

    assert lookup_plugin
    assert isinstance(lookup_plugin.get_option('vars'), UnsafeProxy)



# Generated at 2022-06-23 12:22:31.321855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_basedir(None)

    # Test if the method run returns a list
    terms = ['/etc/hosts', '/etc/resolv.conf']
    result = lookup.run(terms)
    assert isinstance(result, list)

    # Test is the result is not empty
    result = lookup.run(terms)
    assert len(result) != 0

    # Test if the method run raises an exception if a file is not found
    terms = ['/etc/abc123']
    try:
        lookup.run(terms)
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 12:22:33.116701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None
    assert module._templar is not None


# Generated at 2022-06-23 12:22:34.200967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 12:22:35.535405
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-23 12:22:36.461450
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-23 12:22:41.397452
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms = ['/foo/bar.txt']

    variables = {'lookup_file_foo_bar_txt':'/tmp/foo/bar.txt'}

    lookupmodule_return = lookup_module.run(terms, variables=variables)
    assert lookupmodule_return == [u'foo: bar']

# Generated at 2022-06-23 12:22:50.976453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options()
    l.options = {'_original_basename': '/etc/foo.txt', '_original_file': 'foo.txt', '_original_module': 'unvault'}
    l._loader = lambda: None
    l._loader.get_real_file = lambda x, y: x
    l.get_basedir = lambda z: z
    l.find_file_in_search_path = lambda x, y, z: z
    l.run = l.run_orig
    assert l.run(['/etc/foo.txt'], {'playbook_dir': '/playbooks'}) == [u'bar']

# Generated at 2022-06-23 12:22:58.489171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_templar(None)
    assert lookup.run(terms=['/etc/passwd']) == [AnsibleUnsafeText('root:x:0:0:root:')]
    with pytest.raises(AnsibleParserError, match=r'^Unable to find file matching "\S+"'):
        lookup.run(terms=['/romulan/romulan.txt'])
    with pytest.raises(AnsibleParserError, match=r'^Unable to find file matching "\S+"'):
        lookup.run(terms=['/vagrant/vagrant.txt'])

# Generated at 2022-06-23 12:23:00.069060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:23:09.274955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We first create a lookup_plugin to test the method run of class LookupModule
    lookup_plugin = LookupModule()
    # We call the method run of class LookupModule
    assert lookup_plugin.run(['shantanu']) == ['"shantanu\\n"']
    assert lookup_plugin.run(['test']) == ['"test\\n"']
    assert lookup_plugin.run(['shantanu','test']) == ['"shantanu\\n"', '"test\\n"']
    assert lookup_plugin.run(['shantanu','test','test1']) == ['"shantanu\\n"', '"test\\n"', '"test1\\n"']

# Generated at 2022-06-23 12:23:18.456643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup = LookupModule()

    # Create a list of file names
    file_names = ['file1', 'file2']

    # Create a dictionary of terms
    terms = {'_terms': file_names}

    # Create a dictionary of variables
    vars = dict(
        ansible_playbook_python=None,
        ansible_playbook_python_interpreter=None,
        ansible_python_interpreter=None,
        ansible_python_version='',
        ansible_version='v2.10.4.0',
        playbook_dir='/Users/ansible/Documents/git/ansible-test/testdata/v2/lookup_plugins/',
    )

    # Call method run on LookupModule object

# Generated at 2022-06-23 12:23:19.692305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, "run")
    assert LookupModule.__doc__

# Generated at 2022-06-23 12:23:22.649764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test unit
    test_lookup = LookupModule()
    test_unvault_file = test_lookup.run(["/etc/ansible/group_vars/all/vault"])
    print(test_unvault_file)

# Generated at 2022-06-23 12:23:33.638555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange
    term = '/opt/vault/test.yml'
    terms = [term]
    variables = {}
    variables['files'] = 'files'

    lookup = LookupModule()
    
    # mock
    lookup._loader.get_real_file = lambda x, y: s
    lookup.find_file_in_search_path = lambda x, y, z: s
    display.display = lambda x, y, z: s
    display.display.vvvv = lambda x, y, z: s
    with open(s, 'rb') as f:
        f.read = lambda x: s

    # act
    actual = lookup.run(terms, variables)


    # assert
    assert actual == s

# Generated at 2022-06-23 12:23:36.468622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run( ('/etc/hosts', '/dev/null') )
    assert results[0].startswith('#')
    assert results[1] == ''

# Generated at 2022-06-23 12:23:39.468624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_run_mock = LookupModule()
    lookup_run_mock.run(terms=['/tmp/file1'])

# Generated at 2022-06-23 12:23:50.677258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeVars(object):
        def __init__(self):
            self.data = {'ansible_config_file': 'test_ansible.cfg'}

    class FakeOptions(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = './tests/lookup_plugins/'
            self.forks = 10
            self.become = True
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.diff = False
            self.private_key_file = None

        def _flatten(self):
            return self.__dict__

    class FakeLoader(object):
        def __init__(self, basedir):
            self.basedir = basedir


# Generated at 2022-06-23 12:23:52.188050
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert len(str(l)) > 1

# Generated at 2022-06-23 12:24:01.503396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=no-self-use
    # pylint: disable=unused-argument
    from ansible.vars.hostvars import HostVars
    lookup = LookupModule()
    lookup.set_options(Direct({}))
    lookup.set_loader('/path/to/basedir')
    lookup.set_basedir('/path/to/basedir')
    lookup._loader.set_collection_info("collection_name", "collection_version")
    hostvars = HostVars(loader=lookup._loader, variables={'ansible_local': {'myvars': {'foo': 'bar'}}})
    lookup._templar.set_available_variables(hostvars)

    # test unvault_file
    assert lookup.run(['unvault_file'])

# Generated at 2022-06-23 12:24:11.597597
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager

    # Mock the LookupBase class
    class FakeLookupBase:

        def __init__(self):
            self.loader = None

        def set_options(self, variables, direct):
            self.variables = variables
            self.direct = direct

        def find_file_in_search_path(self, variables, path, file):
            return file


    lu = FakeLookupBase()

    # Mock the AnsibleFileLoader class
    class FakeLoader:
        def __init__(self):
            self.path_hash = {}

        def get_real_file(self, file, decrypt):
            return file

    lu.loader = FakeLoader()

    # Mock the AnsibleTemplateFile class

# Generated at 2022-06-23 12:24:20.703687
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a class object to test LookupModule.run method
    lookup_instance = LookupModule()

    # Create a fake set of options for LookupModule.run
    options = {'basedir': '~/ansible', '_ansible_vault_password': '123',
               '_ansible_vault_password_file': '', '_ansible_vault_copy_from': '',
               '_ansible_vault_unknown_vault_method': '', '_original_file': 'vars/main.yaml',
               '__line__': 27, '__file__': '~/ansible/vars/main.yaml'}

    # Create a fake set of terms for LookupModule.run
    terms = ['examples/test.yaml']

    # Create a fake set of variables for Look

# Generated at 2022-06-23 12:24:22.057193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 12:24:34.031889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    `LookupModule.run` returns the contents from vaulted (or not) file(s) on the Ansible controller's file system
    """
    import os
    import tempfile
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    lookup_module = LookupModule()
    lookup_module.set_loader(None)

    dir_ = os.path.realpath(tempfile.gettempdir())
    abs_path = os.path.join(dir_, 'unvault-test_LookupModule_run')

    with open(abs_path, 'wb') as f:
        f.write(b'this is a text file\n')

    result = lookup_module.run((abs_path,), {}, {}, None)

# Generated at 2022-06-23 12:24:37.157592
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    result = module.run(['/usr/share/my-lookup-test-file-not-present'], dict())

    assert result == []


# Generated at 2022-06-23 12:24:38.047444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 12:24:39.564529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """This test checks if LookupModule can be instantiated"""
    lookup_module = LookupModule()



# Generated at 2022-06-23 12:24:40.347445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:24:48.733991
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("Testing the LookupModule class")
    print("  Running _lookup_module().run")

    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('unvault')

    # If we're not running in unit test mode, define this function
    if not callable(getattr(lookup, 'set_options', None)):
        lookup.set_options = lambda self, var_options=None, direct=None: None

    # This is the content of the file we are going to pretend we have in the filesystem
    content = "Hello world!"

    # These are the arguments we're going to pass to the run method
    terms = ['/tmp/test_unvault_file.txt']
    variables = {}
    kwargs = {}

    # Mock up the filesystem. We are using the mock library to

# Generated at 2022-06-23 12:24:49.664064
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 12:25:01.143391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.constants import DEFAULT_VAULT_SECRET_FILE

    mock_loader = DataLoader()
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=InventoryManager(loader=mock_loader))
    mock_variable_manager.extra_vars = {'vault_password_file': DEFAULT_VAULT_SECRET_FILE}
    mock_variable_manager.options_vars = {'lookup_plugin_version': 2.0}
    mock_options = {'_terms': [], '_raw_params': None, 'wantlist': True}
    mock_lookup_module = LookupModule()
   

# Generated at 2022-06-23 12:25:10.976182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing look up module
    lookup = LookupModule()

    # Empty terms, should raise AnsibleParserError
    terms = list()
    try:
        result = lookup.run(terms, variables=None, **dict())
        assert False, "AnsibleParserError with empty terms was excepted"
    except AnsibleParserError as e:
        assert True, "AnsibleParserError with empty terms was excepted: " + str(e)

    # Check for one file
    terms = ["test_file.yml"]
    result = lookup.run(terms, variables=None, **dict())
    assert isinstance(result, list), "Result should be list"
    result = result[0]
    assert isinstance(result, str), "Result should be str"

    # Check for two files

# Generated at 2022-06-23 12:25:21.402465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ansible_variable = AnsibleVariable()
    ansible_variable.set_variable('files', ['/ansible/files'])
    ansible_variable.set_variable('vars', ['/ansible/vars'])
    ansible_variable.set_variable('_original_file', '/ansible/playbooks/playbooks.yml')
    lookup_plugin_options = {
        '_terms': ['file_variable.yaml', 'file_variable_vaulted.yaml'],
        'var': ansible_variable
    }

# Generated at 2022-06-23 12:25:29.668494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    class LookupModule_unvault(LookupModule):
        def __init__(self, filename, options=None, basedir=None, **kwargs):
            super(LookupModule_unvault, self).__init__(loader=None, templar=None, **kwargs)
            self.filename = filename
            self.options = options
            self.basedir = basedir
            self.plugin_args = 'filename'
            self.plugin_options = {'options': 'options'}

        def run(self, terms, **kwargs):
            return [self.filename]

    temp = tempfile.NamedTemporaryFile()
    base_dir = os.path.dirname(temp.name)
    os.environ['__unvault_test__'] = base_dir


# Generated at 2022-06-23 12:25:31.333095
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-23 12:25:40.860854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, var_options, direct):
            self.var_options = var_options
            self.direct = direct
    
    class Variables(object):
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return { 'ansible_testing_vault_password': 'secret' }

    class Loader(object):
        def get_real_file(self, lookupfile, decrypt=True):
            return lookupfile
    
    terms = ['/path/to/file/foo.txt']
    variables = Variables()
    loader = Loader()
    options = Options(variables, None)
    lookup_module = LookupModule()

    # test existing file
    expected_result = 'bar'
   

# Generated at 2022-06-23 12:25:42.617778
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin



# Generated at 2022-06-23 12:25:44.060699
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()
    assert isinstance(LookupModule, type)

# Generated at 2022-06-23 12:25:49.701459
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class M(object):

        class V(object):

            def get_real_file(self, p, **kwargs):
                return p

    lookup_plugin = LookupModule()
    lookup_plugin._loader = M()
    lookup_plugin._loader.get_real_file = M.V().get_real_file

    assert lookup_plugin.run(['./notfound']) == ['1']

# Generated at 2022-06-23 12:25:53.361536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_module = LookupModule()
    # no such file
    assert lookup_module.run(['/tmp/does-not-exist']) == []
    # an actual file
    assert lookup_module.run(['/proc/cpuinfo'])

# Generated at 2022-06-23 12:26:01.285354
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import tempfile

    class Loader:

        def get_real_file(self, lookupfile, decrypt):
            assert decrypt        # only decrypts

            if lookupfile == '/etc/foo.txt':
                return '/etc/foo.txt'
            else:
                return None


    # because of the way this method is invoked, we need to create a temp file
    # wrapped in a contextmanager so it gets cleaned up when the test is done
    with tempfile.NamedTemporaryFile('w') as tmpfile:
        tmpfile.write('bar\n')
        tmpfile.flush()

        lookup = LookupModule()
        lookup.set_loader(Loader())
        assert lookup.run([tmpfile.name])[0] == 'bar\n'

# Generated at 2022-06-23 12:26:02.084820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global lookup
    lookup = LookupModule()


# Generated at 2022-06-23 12:26:04.264701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([])
    assert result == []

# Generated at 2022-06-23 12:26:05.230845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:26:06.180889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None) is not None

# Generated at 2022-06-23 12:26:13.093848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os, sys

    try:
        import __builtin__ as builtins # Python 2
    except ImportError:
        import builtins # Python 3

    import __main__ as main
    import tempfile

    class Mock(object):
        pass

    # Create a temporary directory and files
    tmpdir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmpdir, "foo.txt")
    tmp_vault_path = os.path.join(tmpdir, "vault.txt")
    tmp_nested_path = os.path.join(tmpdir, "nested", "bar.txt")

    # Create a file in the temporary directory
    with open(tmp_path, "w") as f:
        f.write("foo\n")


# Generated at 2022-06-23 12:26:15.784295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Arrange
    # Act
    look_up_module = LookupModule()
    # Assert
    assert look_up_module is not None

# Generated at 2022-06-23 12:26:16.710222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:26:20.041567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_inst = LookupModule()
    assert lookup_inst.run(['my_file']) == []



# Generated at 2022-06-23 12:26:20.645483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True

# Generated at 2022-06-23 12:26:22.113501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:26:25.532349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod._loader = DummyLoader()
    try:
        mod.run( terms = ["does-not-exist"], inject = dict( display = DummyDisplay() ) )
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-23 12:26:30.660359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'vars': {}}, direct={})
    term = '/does/not/exist' # We want this to fail
    terms = [term]

    try:
        res = lookup.run(terms)
        assert False, 'Expected to see exception but did not'
    except AnsibleParserError:
        assert True
    except Exception as e:
        assert False, 'Expected to see AnsibleParserError exception but got %s' % str(e)

# Generated at 2022-06-23 12:26:32.434571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    looker = LookupModule()
    assert type(looker) == LookupModule

# Generated at 2022-06-23 12:26:34.968640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['/etc/foo.txt']
    data = module.run(terms, variables={})
    assert data == ['hello world']

# Generated at 2022-06-23 12:26:36.757507
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert hasattr(lookup, 'run')


# Generated at 2022-06-23 12:26:40.753487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # setup
    unvault = LookupModule()

    # run test
    result = unvault.run(terms=["foo.txt"])

    # assert result

# Generated at 2022-06-23 12:26:41.757420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-23 12:26:44.767526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # This test case is not applicable till we figure out how to use a template loader to load vaulted file
    # assert lookup_module.run(terms=[]) ==

# Generated at 2022-06-23 12:26:53.690800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    # NOTE: no module_utils.basic to avoid needless imports
    class AnsibleModuleFake:
        def __init__(self):
            self.fail_json = lambda **kwargs: self
            self.msg = None

        def fail_json(self, **kwargs):
            self.msg = kwargs
            raise Exception(self.msg)

    class DisplayFake:
        def __init__(self):
            self.messages = []


# Generated at 2022-06-23 12:26:56.476871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    data = module.run(terms=['TestVault.yml'], variables={'vault_password': 'VaultPassword'})
    assert data == ['1']

# Generated at 2022-06-23 12:26:58.019630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' in globals()

# Generated at 2022-06-23 12:27:00.077562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.unvault import LookupModule
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:27:02.414938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test trying to read a non-existent file.
    lookup = LookupModule()
    assert lookup.run(["/tmp/does_not_exist"]) == []

# Generated at 2022-06-23 12:27:04.824205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(['r'], variables={'r': 'a.txt'})

# Generated at 2022-06-23 12:27:16.355846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.plugins.loader import lookup_loader

    class FakeLoader():
        class FakeLoaderObj():
            paths = [unfrackpath("/foo/bar/plugins/lookup/test_unvault")]

    fake_loader = FakeLoader()

    obj = lookup_loader.get('unvault', fake_loader.FakeLoaderObj(), None)

    terms = ["lookup.txt"]
    result = obj.run(terms)
    expected = [u"this is a test file\n"]
    assert result == expected

    # make sure we can lookup in both places
    fake_loader.FakeLoaderObj().paths.append("/foo/bar/plugins/lookup")
    result = obj.run(terms)

# Generated at 2022-06-23 12:27:24.275392
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a non-existent file
    l = LookupModule()
    assert l.run(["non_existent_file"], dict()) == []

    # Test with a file that has no contents
    l = LookupModule()
    assert l.run(["test.txt"], dict()) == [""]

    # Test with a file that has contents
    l = LookupModule()
    assert l.run(["contents.txt"], dict()) == ["line0\nline1\nline2\nline3\nline4\n"]

# Generated at 2022-06-23 12:27:34.020450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert [b'abc'] == lookup_module.run(terms=['/usr/bin/python'], variables={'ansible_env': {'PYTHONPATH': u'/usr/bin'}})
    assert [b'abc'] == lookup_module.run(terms=['python'], variables={'ansible_env': {'PYTHONPATH': u'/usr/bin'}})
    assert [b'abc'] == lookup_module.run(terms=[u'/usr/bin/python'], variables={'ansible_env': {'PYTHONPATH': u'/usr/bin'}})

# Generated at 2022-06-23 12:27:40.488482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class_inst = LookupModule()
    try:
        dict1 = dict(path='/path/to/file', format='file', type='file')
        assert class_inst.set_options(var_options=dict1) == None
        assert class_inst.set_options(direct=dict1) == None
    except AssertionError:
        print('test_LookupModule failed!')
        raise
    return

# Generated at 2022-06-23 12:27:42.729422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None
    assert lookup_plugin._loader is not None


# Generated at 2022-06-23 12:27:44.541859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test to check the constructor of class LookupModule
    assert True

# Generated at 2022-06-23 12:27:54.407060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # example #1
    terms = ['/tmp/test1.txt']
    variables = {'foo': 'bar'}
    ret = lookup.run(terms, variables)
    assert len(ret) == 1
    assert ret[0] == 'Hello World\n'

    # example #2
    terms = ['/tmp/test1.txt', '/tmp/test2.txt']
    variables = {'foo': 'bar'}
    ret = lookup.run(terms, variables)
    assert len(ret) == 2
    assert ret[0] == 'Hello World\n'
    assert ret[1] == 'Goodbye World\n'

    # example #3
    # - test with non existent file

# Generated at 2022-06-23 12:27:54.971479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:27:57.373859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
        return True
    except Exception as err:
        print("Error: " + str(err))
        return False

# Generated at 2022-06-23 12:27:59.277785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:28:02.710826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert test_lookup.get_options() == {'_raw_params': '', '_terms': [], '_uses_shell': False, '_filesystem_read': True}


# Generated at 2022-06-23 12:28:04.011178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 12:28:11.418673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.vvvv = lambda x: x
    test_lookup = LookupModule()

    # Find a file in the expected search path
    term = "/etc/passwd"
    lookupfile = test_lookup.find_file_in_search_path(None, 'files', term)
    assert lookupfile == term
    assert test_lookup.run([term]) == ['root:x:0:0:root:/root:/bin/bash\n']

    # Find a file that does not exist in the expected search path
    term = "/a/b/c/d/e"
    lookupfile = test_lookup.find_file_in_search_path(None, 'files', term)
    assert lookupfile == term

# Generated at 2022-06-23 12:28:19.141337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a normal file
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=['/etc/passwd'],
                               variables={'files': ['/etc/ansible']})
    assert result[0].startswith('root:x'), 'Test with normal file failed'

    # Test with a vaulted file
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=['/etc/vaulted'],
                               variables={'files': ['/etc/ansible']})
    assert result[0].startswith('vaulted'), 'Test with vaulted file failed'

# Generated at 2022-06-23 12:28:30.924586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing run method - no errors
    assert LookupModule({}).run(terms=['UNVUALT_TEST.txt'], variables={'ansible_playbook_python': '/usr/bin/python'}) == \
                            ['this is a unvault test']

    # Testing run method - file not found
    assert LookupModule({}).run(terms=['UNVUALT_TEST2.txt'], variables={'ansible_playbook_python': '/usr/bin/python'}) == \
                            []

    # Testing run method - AnsibleParserError
    try:
        LookupModule({}).run(terms=['UNVUALT_TEST3.txt'], variables={'ansible_playbook_python': '/usr/bin/python'})
    except AnsibleParserError:
        assert True

# Generated at 2022-06-23 12:28:31.511406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:28:33.108717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # initialize class
    lookup = LookupModule()
    # assert that class was created without any problems
    assert lookup is not None

# Generated at 2022-06-23 12:28:38.677461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib

    vault_password = 'test'
    vault = VaultLib(vault_password)

    test_content = vault.encrypt('content')

    terms = ['test/lookup.txt']
    with open('test/lookup.txt', 'w') as f:
        f.write(test_content)

    lookup_module = LookupModule()

    result = lookup_module.run(terms)

    assert result[0] == 'content'

# Generated at 2022-06-23 12:28:49.246327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TempModule(LookupModule):
        def _loader_class_init(self, module_name):
            pass

        def set_options(self, var_options=None, direct=None):
            pass

    # Create class instance
    temp_lookup_class = TempModule()

    # Create file with known content
    file_content = "Hey there!"
    with tempfile.NamedTemporaryFile(mode='w+b', delete=False, suffix=".vault") as temp_file:
        temp_file.write(file_content)

    # Mocking temp_lookup_class.find_file_in_search_path
    # This is necessary because only the `run` method is tested in this unit test and
    # not the whole file lookup module. The find_file_in_search_path method is called
    # in

# Generated at 2022-06-23 12:28:49.835670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:28:50.841255
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'AnsibleParserError' in globals()

# Generated at 2022-06-23 12:28:56.523851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    results = obj.run(terms=["/etc/hosts"], variables=None, **{"_terms": ["/etc/hosts"]})
    assert results[0] == "# Ansible managed:\n127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4\n::1         localhost localhost.localdomain localhost6 localhost6.localdomain6\n"

# Generated at 2022-06-23 12:29:02.228482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Tests b_contents value read from the file /etc/passwd
    b_passwd = 'root:x:0:0:root:/root:/bin/bash\n'
    terms = ['/etc/passwd']
    ret = lookup_module.run(terms)
    assert to_text(b_passwd) in ret

# Generated at 2022-06-23 12:29:03.675022
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-23 12:29:04.150222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:29:05.910857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None, 'Failed to create an object of LookupModule'

# Generated at 2022-06-23 12:29:07.022996
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mylm = LookupModule()

# Generated at 2022-06-23 12:29:09.376077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader._basedir  # pylint: disable=protected-access

# Generated at 2022-06-23 12:29:16.918756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Assert default behavior of lookup plugin working with vaulted file
    terms = ['/etc/ansible/vault_test_file.txt', ]
    ret = lookup.run(terms)
    assert ret == [b'This file is vaulted\n']

    # Assert default behavior of lookup plugin working with non-vaulted file
    terms = ['/etc/ansible/non_vault_test_file.txt', ]
    ret = lookup.run(terms)
    assert ret == ['This file is NOT vaulted\n']

# Generated at 2022-06-23 12:29:17.949602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Placeholder
    assert True

# Generated at 2022-06-23 12:29:19.666153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """The following test is designed to check LookupModule constructor
    Unit testing is performed.
    """
    LookupClass = LookupModule
    assert LookupClass

# Generated at 2022-06-23 12:29:20.636515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:29:23.953893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    results = module.run(["/etc/group"])
    assert len(results) > 0
    assert isinstance(results[0], str)

# Generated at 2022-06-23 12:29:25.989716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    assert lookup.run([]) == []

# Generated at 2022-06-23 12:29:30.002966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    assert LookupModule.run({}, terms=['foo.txt'], variables=AnsibleMapping({"_terms": ['foor.txt']})).strip() == "foo"

# Generated at 2022-06-23 12:29:37.755094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{lookup("unvault", "/etc/foo.txt")|to_string}}'))),
        ]
    )

# Generated at 2022-06-23 12:29:47.532073
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLookupBase(LookupBase):
        def find_file_in_search_path(self, variables, dirs, term):
            if term == 'foo.txt':
                return '/playbook/path/files/foo.txt'
            if term == 'bar.txt':
                return '/playbook/path/files/bar.txt'
            if term == 'baz.txt':
                return '/playbook/path/files/baz.txt'
            return None

    mock_loader = MockLookupBase()
    mock_loader.get_real_file = lambda x: x
    mock_loader._options = {}


# Generated at 2022-06-23 12:29:53.614523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    data_loader = DataLoader()
    variable_mgr = VariableManager()
    LookupModule(loader=data_loader, variable_manager=variable_mgr, loader_class=AnsibleLoader)


# Generated at 2022-06-23 12:30:01.907200
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import pytest
    from unittest.mock import patch
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.plugins.loader as plugin_loader

    lookup_plugin = plugin_loader.lookup_loader.get('unvault', class_only=True)

    display = Display()
    display.verbosity = 4

    path = os.path.realpath(os.path.dirname(__file__))


# Generated at 2022-06-23 12:30:09.304469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _mock_ansible_module = Mock(spec=AnsibleModule)
    _mock_ansible_module.params = dict(
        terms=["term1", "term2"]
    )

    _mock_loader = Mock(spec=DataLoader)
    def _mock_get_real_file(path, **kwargs):
        if path == "term1":
            return "mock_real_file_1"
        elif path == "term2":
            return "mock_real_file_2"
        raise KeyError(path)

    _mock_loader.get_real_file = _mock_get_real_file

    _mock_play_context = Mock(spec=PlayContext)


# Generated at 2022-06-23 12:30:14.364236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_loader = MockLoader()
    mock_loader._module = None
    mock_loader._get_path_options = None
    mock_loader.get_real_file = MagicMock(return_value='file.txt')

    lookup = LookupModule()
    lookup.set_loader(mock_loader)

    os.path.isfile = MagicMock(return_value=True)

    lookup.run(terms=['file.txt'])
    mock_loader.get_real_file.assert_called_once_with('file.txt', decrypt=True)

# Generated at 2022-06-23 12:30:21.403034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultLib
    from tempfile import mkdtemp
    from ansible.plugins.loader import get_all_plugin_loaders, get_loader_by_path
    import shutil

    vault_secret = 'mysecret'
    vault_password_file = mkdtemp()
    with open(vault_password_file, 'w') as f:
        f.write('%s\n' % vault_secret)

    test_string = 'this is a test'

    plain_file = mkdtemp()

# Generated at 2022-06-23 12:30:23.461981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:30:34.674901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod_args = {
        '_loader': {
            'get_real_file': lambda x, decrypt=True: x
        }
    }

    # test with one file
    lookup_plugin = LookupModule(**mod_args)
    assert lookup_plugin.run(['/tmp/foo.txt']) == ['/tmp/foo.txt']

    # test with multiple files
    lookup_plugin = LookupModule(**mod_args)
    assert lookup_plugin.run(['/tmp/foo.txt', '/tmp/bar.txt']) == ['/tmp/foo.txt', '/tmp/bar.txt']

    # test with a file which does not exist
    lookup_plugin = LookupModule(**mod_args)
