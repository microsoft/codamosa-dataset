

# Generated at 2022-06-21 06:48:01.713133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    assert lookup.run(terms=['/etc/foo.txt']) == [b'bar']

# Generated at 2022-06-21 06:48:03.850551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:48:07.957145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ('../../../../../../../../etc/passwd',)
    assert lookup_plugin.run(terms) == [b"root:x:0:0:root:/root:/bin/bash\n"]

# Generated at 2022-06-21 06:48:08.984740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule != None

# Generated at 2022-06-21 06:48:10.868375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)
    assert lookup_plugin.run('/tmp/foo') is None


# Generated at 2022-06-21 06:48:16.188304
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Initialize object of 'LookupModule' class
    lookupmodule_obj = LookupModule()

    # Execute run method of class
    result = lookupmodule_obj.run(["lookup_plugin.py"], {"_ansible_lookup_plugins": "./lookup_plugins" })

    # Print value returned by run method
    print(result)

if __name__ == '__main__':
    # Call function defined above
    test_LookupModule()

# Generated at 2022-06-21 06:48:17.569355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:48:18.598627
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:48:26.677452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the LookupModule for testing
    unvault_lm = LookupModule()
    unvault_lm.set_options()

    f = open('testfile.txt', 'wb')
    f.write(b':)')
    f.close()

    lookup = unvault_lm.run(['./testfile.txt'], [])
    assert lookup[0] == u':)'

# Generated at 2022-06-21 06:48:28.312889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options()
    assert lookup.has_plugin_options() == False

# Generated at 2022-06-21 06:48:41.185175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()

    #assert isinstance(lookup_obj, LookupModule)
    assert hasattr(lookup_obj, '_options')
    assert hasattr(lookup_obj, '_display')
    assert hasattr(lookup_obj, '_templar')
    assert hasattr(lookup_obj, 'set_options')
    assert hasattr(lookup_obj, 'run')
    assert hasattr(lookup_obj, 'get_basedir')
    assert hasattr(lookup_obj, '_compile_search_paths')
    assert hasattr(lookup_obj, 'get_search_path')
    assert hasattr(lookup_obj, '_find_file_in_search_path')

# Generated at 2022-06-21 06:48:42.621836
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:48:43.550868
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    assert l is not None

# Generated at 2022-06-21 06:48:46.570061
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_unvault = LookupModule()
    assert lookup_unvault

# Generated at 2022-06-21 06:48:54.709477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs_test = {
        '_terms': ['/etc/passwd'],
        'update_cache': 'no',
        '_orig_basename': '/etc/passwd',
        '_real_basename': '/etc/passwd',
        'encoding': 'utf-8',
        '_original_file': '/etc/passwd',
        'no_log': 'no'
    }
    lk = LookupModule()
    assert lk.run(terms=kwargs_test['_terms'], **kwargs_test) == ['# /etc/passwd\n']

# Generated at 2022-06-21 06:49:01.775424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test Case: test_LookupModule_run"""
    # Confirm contents of the file when lookup is called
    lookup_instance = LookupModule()
    assert lookup_instance.run(["/etc/ansible/hosts"]) == [u'[defaults]\n\n[local]\nlocalhost\n\n']

# Generated at 2022-06-21 06:49:03.248108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) == type

# Generated at 2022-06-21 06:49:04.095735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:49:11.883157
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert hasattr(lookup_mod, '_display')
    assert lookup_mod._display.verbosity == 0

    lookup_mod = LookupModule(display=display)
    assert hasattr(lookup_mod, '_display')
    assert lookup_mod._display.verbosity > 0

# Generated at 2022-06-21 06:49:23.094515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ..data import data
    from .test_lookup_plugins import TestLookupPlugins
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins import lookup_loader

    stdout_mock = StringIO()
    stderr_mock = StringIO()
    display.display = stdout_mock.write
    display.error = stderr_mock.write

    lookup = lookup_loader.get('unvault', class_only=True)

    expected_content = b'my_secret: S3cR3tPa$$\n'
    file_name = '/tmp/unvault_test.yml'
    with open(file_name, 'wb') as f:
        f.write(expected_content)


# Generated at 2022-06-21 06:49:36.317384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={})

    # Use some fake data for these tests
    # pylint: disable=protected-access
    lookup_module._loader = FakeLoader()

    # Test with a normal lookup
    foobar = lookup_module.run(terms=['foobar'], variables=None)
    assert foobar == [u'FOOBAR']



# Generated at 2022-06-21 06:49:46.839030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lm = LookupModule()
    terms = ["foo.txt"]
    variables= {"_filesystem_paths": {
        "_filesystem_path": "/Users/User/Documents/Ansible/lookup_plugins/test/"
    }}

    # Act 1
    ret = lm.run(terms, variables)

    # Assert 1
    assert ret == [u"bar\n"]

    # Act 2
    # Configuration to cause AnisbleParserError

# Generated at 2022-06-21 06:49:51.142137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        objLM = LookupModule()
    except Exception as e:
        print("Exception raised in class LookupModule initialization:", e)
        assert False
    assert True


# Generated at 2022-06-21 06:50:00.057596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    #setup
    lookup_instance = LookupModule()
    lookup_instance._display = display
    lookup_instance._loader = DummyLoader()
    lookup_vars = {'ansible_facts': {'ansible_system': 'linux'},
                   'ansible_architecture': 'x86_64',
                   'ansible_distribution': 'debian',
                   'ansible_distribution_version': 'stretch/sid',
                   'ansible_distribution_major_version': '9',
                   'ansible_distribution_release': 'stretch',
                   'ansible_os_family': 'Debian'}
    #execute
    actual_result =lookup_instance.run([],variables=lookup_vars)
    #assert
    assert isinstance(actual_result, list)

# Generated at 2022-06-21 06:50:02.080057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    unvault = LookupModule()
    assert unvault

# Generated at 2022-06-21 06:50:09.936709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # For testing method run(self, terms, variables=None, **kwargs):
    # Checking case when file exists.
    lookup_module = LookupModule()

    lookup_module.display = Display()
    lookup_module.set_options(var_options={}, direct={})

    lookup_module.find_file_in_search_path = \
        lambda variables, file_type, term: '/home/test_LookupModule_run'

    lookup_module._loader = open('/home/test_LookupModule_run', 'w')
    lookup_module._loader.get_real_file = \
        lambda lookupfile, decrypt: '/home/test_LookupModule_run'

    with open('/home/test_LookupModule_run', 'w') as f:
        f.write('test string')

# Generated at 2022-06-21 06:50:20.606835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import builtins
    import os
    import tempfile

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    from units.mock.loader import DictDataLoader

    from units.mock.plugins.lookup import TestLookupBase

    # Create temporary file for testing
    f, path = tempfile.mkstemp(dir=tempfile.gettempdir())
    os.close(f)

    # Create content of file and write to disk
    content = to_bytes("an-content")
    with open(path, 'wb') as f:
        f.write(content)


# Generated at 2022-06-21 06:50:23.604448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:50:24.914039
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:50:30.173220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tlist = ['test']
    lst = LookupModule()
    assert lst.run(terms=tlist, variables=None) == [b'bWVzc2FnZQ==\n']

# Generated at 2022-06-21 06:50:47.097703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # Invalid path
    try:
        lookup_instance.run(terms=['/test.txt'])
    except AnsibleParserError:
        pass
    else:
        assert False, 'AnsibleParserError not raised'

    # Valid path for file with plaintext content
    terms = ['/etc/ansible/roles/test/lookup_plugins/fixtures/lookup_file_plaintext.txt']
    result = lookup_instance.run(terms=terms)
    assert result == ['Hello World']

    # Valid path for file with vault content
    terms = ['/etc/ansible/roles/test/lookup_plugins/fixtures/lookup_file_vault.yml']
    result = lookup_instance.run(terms=terms)

# Generated at 2022-06-21 06:50:58.258589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def raise_exc():
        raise AnsibleParserError('Unable to find file matching')

    mod = LookupModule()
    mod.set_options = mock.MagicMock()
    mod.find_file_in_search_path = mock.MagicMock(return_value=__file__)
    loader = mock.MagicMock(
        get_real_file=mock.MagicMock(
            return_value='/tmp/unvault_test_file'
        )
    )
    with open('/tmp/unvault_test_file', 'w') as f:
        f.write('This is a test')
    mod._loader = loader

    # Test exception
    mod.find_file_in_search_path.side_effect = raise_exc

# Generated at 2022-06-21 06:51:07.664552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def find_file_in_search_path(self, variables, subdirs, file):
        # Ansible store the file in the following dir
        return '/home/user/.ansible/files/ansible.txt'
    module = LookupModule()
    module.set_loader(None)
    module.set_env(None)
    module.set_filt_n(None)
    module.set_aliases(None)
    module.find_file_in_search_path = find_file_in_search_path
    assert module.run(['./ansible.txt']) == [u'Hello, Ansible!']
    

# Generated at 2022-06-21 06:51:08.435275
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Create an instance of LookupModule
  lookup_module = LookupModule()


# Generated at 2022-06-21 06:51:10.127476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    lookup = LookupModule()
    assert lookup.find_file_in_search_path({}, 'files', '/etc') == '/etc'
    assert lookup.find_file_in_search_path({}, 'files', './etc') == './etc'

# Generated at 2022-06-21 06:51:14.457946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L=LookupModule()
    L.set_options()
    s=['.']
    with pytest.raises(AnsibleParserError) as e:
        L.run(s)
    assert str(e.value) == 'Unable to find file matching "." '

# Generated at 2022-06-21 06:51:16.511421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result.display == None

# Generated at 2022-06-21 06:51:22.802273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Perform test to ensure that method run of class LookupModule returns correct value
    # Create AnsibleVault instance
    lookup_module_test = LookupModule()
    # Create Ansible file module
    file_module = lookup_module_test.run("test.txt", variables="test.txt")
    # Check for equality
    assert file_module == ("test")

# Generated at 2022-06-21 06:51:35.596395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:51:38.276470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of LookupModule class
    """
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt']
    result = lookup_module.run(terms=terms, variables=None, all_vars=dict())
    assert result == ['this text is in foo.txt\n']

# Generated at 2022-06-21 06:51:58.442494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = 'unvault'
    lm = LookupModule()
    assert lm._plugin_name == test
    assert lm._plugins_wrap == test

# Generated at 2022-06-21 06:51:59.916870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lo = LookupModule()

    assert(type(lo) == LookupModule)



# Generated at 2022-06-21 06:52:01.391735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:52:14.068209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    result = test_LookupModule.run(["/etc/passwd"], None)

# Generated at 2022-06-21 06:52:21.980000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup_class = LookupModule(
        loader=None, # TODO
        templar=None, # TODO
        shared_loader_obj=None, # TODO
    )
    test_lookup_module = my_lookup_class.run(
        terms=['/etc/ansible/ansible.cfg'],
        variables=None,
    )
    assert lookup_module == ['[defaults]\n', 'callback_whitelist = profile_tasks\n', '... (truncated)']

# Generated at 2022-06-21 06:52:23.599758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:52:27.132568
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ['/path/to/file']
    variables = {}
    actual_file = lookup_module.run(terms, variables)
    assert actual_file == ['/path/to/file']

# Generated at 2022-06-21 06:52:31.883211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run:
    # test_LookupModule_run: test files in local path
    # test_LookupModule_run: test files in search path
    # test_LookupModule_run: test files in unknown path
    # test_LookupModule_run: test files in search path with different name
    # test_LookupModule_run encrypt / decrypt
    # test_LookupModule_run error with unvault
    pass

# Generated at 2022-06-21 06:52:41.438049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ A test for LookupModule class constructor with children plugin
        Lookup to read file contents.
    """
    lookup_name = 'unvault'
    lookup_cls = LookupModule.__name__
    lookup_class_path = str(LookupModule.__module__) + '.' + lookup_cls
    entry_point = lookup_class_path + '.' + lookup_name

    display.vvvv("Entry point: " + entry_point)

    # Making an instance of LookupPlugin
    lookup_plugin = __import__(LookupModule.__module__, fromlist=lookup_cls)
    lookup_instance = lookup_plugin.LookupModule()

    assert lookup_instance.__class__.__name__ == lookup_cls

# Generated at 2022-06-21 06:52:43.568337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-21 06:53:21.083632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup = LookupModule()    # instantiation
    except Exception:
        print('Exception either because importation of class LookupModule failed or instantiation failed')
        

# Generated at 2022-06-21 06:53:22.222736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj is not None

# Generated at 2022-06-21 06:53:24.049899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.debug("Testing LookupModule.run")
    assert 0 == 0
    return

# Generated at 2022-06-21 06:53:34.746327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, vars={}):
            self.become = False
            self.become_method = None
            self.become_user = None
            self.vars = vars

    class Runner(object):
        def __init__(self):
            self.options = Options()

    class PlayContext(object):
        def __init__(self):
            self.runner = Runner()

    class Loader(object):
        def __init__(self):
            self._basedir = "tests/test_lookup_plugins/unvault/data"

        def get_real_file(self, basedir, path):
            return "tests/test_lookup_plugins/unvault/data/test.yml"


# Generated at 2022-06-21 06:53:42.009624
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms  = [
        '/path/to/file1',
        '/path/to/file2']

    result = module.run(terms)

    assert len(result) == 2
    assert result[0].startswith('Content of file1')
    assert result[1].startswith('Content of file2')

# Generated at 2022-06-21 06:53:43.181332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:53:53.818617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    class AnsibleModuleStub:
        def __init__(self):
            self.params = {}

    ansible_module = AnsibleModuleStub()
    lookup_module = LookupModule()
    lookup_module._available_variables = ansible_module

    # Test with a path that does not exists.
    assert lookup_module.run(['test/I/do/not/exists']) == []

    # Test with a valid path
    results = lookup_module.run(['../../utils/display.py'])
    assert len(results) == 1

    code = open('../../utils/display.py', 'r').read()

    if PY3:
        assert results[0].encode() == code.encode()

# Generated at 2022-06-21 06:54:01.713838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = dict()

    # First test with a non vaulted file
    _content = """
    ---
    foo: bar
    baz: qux
    """

    # Create the unvault file
    try:
        with open('file_unvault', 'w') as f:
            f.write(_content)
    except:
        assert False

    # New LookupModule
    um = LookupModule()

    # This will throw an exception if the file isn't found
    um.run(['./file_unvault'], variables=options)

    # This SHOULD throw an exception because the lookup_plugin_paths
    # are not setup properly, that is why we pass in options

# Generated at 2022-06-21 06:54:05.356245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:54:11.770273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lm = LookupModule(None)
  terms = ['/etc/foo.txt']
  variables = {'ansible_vault_password': 'ansible'}
  retval = lm.run(terms, variables)
  assert retval == [b'foo'] # not real meaning of test yet

test_LookupModule_run()

# Generated at 2022-06-21 06:55:34.362706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    _terms = ['examples/agent_inventory', 'example_group']
    ret = obj.run(_terms=_terms)
    print(ret)

# Generated at 2022-06-21 06:55:40.087082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    mock_terms = ["/some/file.txt"]
    mock_variables = {"my_var": "var_value"}
    lookup_plugin.run(mock_terms, mock_variables)

# Generated at 2022-06-21 06:55:47.621451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-21 06:55:57.701351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-argument
    def mock_find_file_in_search_path(self, variables=None, dirs=None, file_name=None):
        if 'ansible_encrypt' in variables:
            return 'test_file_decryption'
        else:
            return 'test_file_encryption'

    LookupBase.find_file_in_search_path = mock_find_file_in_search_path
    lookup_module = LookupModule()
    file_content = lookup_module.run(['test'], variables={'ansible_encrypt': True})
    assert file_content == ['test_file_decryption']
    file_content = lookup_module.run(['test'], variables={'ansible_encrypt': False})

# Generated at 2022-06-21 06:56:01.181648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup_result = lookup.run("/etc/hosts", {})
    assert lookup_result[0].startswith("127.0.0.1")

# Generated at 2022-06-21 06:56:04.034818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule
    """
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)

# Generated at 2022-06-21 06:56:07.043578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run

# Generated at 2022-06-21 06:56:07.863078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:56:11.483142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    o = LookupModule()
    txt = o.run(['/etc/foo.txt'])
    assert txt
    assert txt[0].startswith('example')

# Generated at 2022-06-21 06:56:14.376262
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader is not None, '_loader attribute is missing'
    assert lookup_plugin._templar is not None, '_templar attribute is missing'
