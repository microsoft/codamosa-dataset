

# Generated at 2022-06-21 06:47:59.486188
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:48:01.391015
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert type(lu).__name__ == 'LookupModule'

# Generated at 2022-06-21 06:48:03.015444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 06:48:07.156060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = '/tmp/file.txt'
    variables = {'file': '/tmp/file.txt'}
    lookupmodule = LookupModule()
    assert lookupmodule.run(terms=terms, variables=variables) == ['content of file']

# Generated at 2022-06-21 06:48:08.677150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:48:10.320313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-21 06:48:14.353962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run_results = LookupModule().run(terms=['README.md'], variables={'lookup_file': 'artifact/README.md'})
    assert run_results[0] == 'README for Ansible Collection: nissan_network\n'
    # TODO: Add test for unicode characters

# Generated at 2022-06-21 06:48:18.497946
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    result = lookup_module.run('/etc/hosts')

    # Here we are testing only the contents of the first line of the hosts file
    # in order to reduce the chance of test failures due to unexpected changes in the hosts file
    first_line_of_hosts_file = to_text(open("/etc/hosts").readlines()[0])
    assert result[0].startswith(first_line_of_hosts_file)

# Generated at 2022-06-21 06:48:21.058214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm != None

# Generated at 2022-06-21 06:48:22.487407
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod

# Generated at 2022-06-21 06:48:31.649280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = type('MockSelf', (object,), {'_templar': 'mock_templar', '_loader': 'mock_loader'})
    mock_self._templar = type('MockTemplar', (object,), {'template': lambda x: x})
    mock_self._loader = type('MockLoader', (object,), {'get_real_file': lambda x, y: x})
    terms = ['config.yml', 'credentials.yml']
    variables = {}
    kwargs = {}
    assert LookupModule.run(mock_self, terms, variables, **kwargs) == terms

# Generated at 2022-06-21 06:48:34.227084
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    display.vvvv(u"Unvault lookup object: %s" % l)

# Generated at 2022-06-21 06:48:36.155109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Note: the constructor does nothing, so we shouldn't have to test this
    pass

# Generated at 2022-06-21 06:48:38.137355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:48:38.804937
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False

# Generated at 2022-06-21 06:48:43.592070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test Case:
    #   - missing argument
    # Expected Results:
    #   - AnsibleParserError should be raised
    with pytest.raises(AnsibleParserError) as e_info:
        test_obj = LookupModule("", "", "")
    assert str(e_info.value) == 'AnsibleParserError: Unable to find file matching "" '

# Generated at 2022-06-21 06:48:45.383878
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:48:46.870028
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    assert foo is not None

# Generated at 2022-06-21 06:48:55.585189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_plugin = LookupModule()

    # The instance is created and it contains all of the methods in the class
    assert hasattr(lookup_plugin, 'run')

    # The method run is called with arguments
    expected = [ b'# (c) 2020 Ansible Project\n', b'# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)\n' ]
    actual = lookup_plugin.run(['test/test_lookup_plugins/unvault/data/doc_fragment.yml'])
    assert actual == expected



# Generated at 2022-06-21 06:48:57.041078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-21 06:49:04.584904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = [b'foo\n']
    lm = LookupModule()
    assert lm.run(['/etc/foo.txt'], variables={'files': ['/etc/foo.txt']}) == ret

# Generated at 2022-06-21 06:49:07.776812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:49:09.216891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:49:13.500621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    lookup_module = LookupModule()
    lookup_module._loader.load_from_file.assert_called()

# Generated at 2022-06-21 06:49:14.544312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([], {}) == []

# Generated at 2022-06-21 06:49:16.318695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run
    assert lookup_module.run_terms
    assert lookup_module.run_exe

# Generated at 2022-06-21 06:49:23.236487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    with open('/etc/hosts','rb') as f:
        contents = f.read()
    contents = contents.decode('utf-8')
    b_contents = contents.encode('utf-8')
    lookup = LookupModule()
    assert lookup.run(['/etc/hosts'],dict())[0] == b_contents

# Generated at 2022-06-21 06:49:25.030995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # TODO: add unit test to check that this lookup works as expected
    assert False

# Generated at 2022-06-21 06:49:27.227834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:49:39.251294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    from ansible.utils.vault import VaultLib
    import os
    import pytest
    import tempfile
    import subprocess

    class TestCallbackModule(CallbackBase):
        pass
    loader = DataLoader()
    vault_password = 'Secret220'
    vault_password_file = '/tmp/vault_password'

# Generated at 2022-06-21 06:49:48.822458
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:49:59.144401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    import os
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()
    test_file_name = "test.txt"
    test_file_path = os.path.join(test_dir, test_file_name)

    test_file_content = "Hello World"
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = os.path.expanduser('~')+"/.ansible.vaultpw"
    with open(test_file_path, "a") as test_file:
        test_file.write(test_file_content)
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-21 06:50:09.159594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 4
    mock_self = LookupModule()
    mock_self.set_options({'_filesdir': 'files', '_basedir': './'})
    content = mock_self.run(['unvault-test.yml'], {'_filesdir': 'files', '_basedir': './'})

# Generated at 2022-06-21 06:50:17.542011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the test lookups and the test arguments
    test_lookups = LookupModule()
    test_terms = ["content.txt"]

    # Set the current path to 'test'
    test_lookups.set_resources_path('test')

    # Get the content of the file
    test_content = test_lookups.run(terms=test_terms)[0]

    # Check if the content is the expected one
    assert test_content == 'simpletext\n', 'Unvault lookup does not work as expected'

# Generated at 2022-06-21 06:50:28.155521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=missing-docstring
    # pylint: disable=too-many-arguments
    # pylint: disable=unused-argument

    # This is a test case for unit test of LookupModule.run.
    # Because Python 3.9.0 removed the implicit relative import,
    # you must use the explicit relative import with __package__.
    from ..lookup_plugins.unvault import LookupModule

    def test_find_file_in_search_path(variable, lookup_path, name_to_find):
        # Just for test purpose, this is a simple method to replace find_file_in_search_path
        # for testing.
        return name_to_find

    # Mock _loader.get_real_file()
    # So we can test the execution of the code which uses that method

# Generated at 2022-06-21 06:50:31.895123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ["/tmp/file1", "/tmp/file2"]
    l = LookupModule()
    l.set_options()
    l.run(test_terms)

# Generated at 2022-06-21 06:50:35.227492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create class object
    module_obj = LookupModule()
    # Create list variable
    module_obj.run(terms = ['./test', './test2'], variables = None)

# Generated at 2022-06-21 06:50:46.693071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    unvault_obj = LookupModule()

    # test with good encrypted files
    with open("test_unvault_test_good_file1.yml", "r") as f:
        good_file1 = f.read()
    with open("test_unvault_test_good_file2.yml", "r") as f:
        good_file2 = f.read()

    terms = [
        "/etc/ansible/test_unvault_test_good_file1.yml",
        "./test_files/test_unvault_test_good_file2.yml"
    ]
    results = unvault_obj.run(terms)
    assert results[0] == good_file1
    assert results[1] == good_file2

    # test with bad unencrypted files


# Generated at 2022-06-21 06:50:47.509913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:50:58.395136
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup test environment, including a fake lookup file
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import configparser

    class TestVars(Mapping):
        def __init__(self, values):
            self._values = values

        def __len__(self):
            return len(self._values)

        def __iter__(self):
            return iter(self._values)

        def __getitem__(self, key):
            return self._values[key]

    class TestLoader(object):
        class TestFile(object):
            def __init__(self, contents, full_path):
                self._contents = contents
                self._full_path = full_path



# Generated at 2022-06-21 06:51:25.255068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixture_file_name = 'alias.yml'
    fixture_file_path = 'fixtures/unvault/' + fixture_file_name
    fixture_file_content = 'foo: bar'
    argspec = dict(
        terms=[fixture_file_path],
        variables=dict(filesystempath=['.'])
    )
    lm = LookupModule()
    lm.set_runner({'options': dict(filesystempath='.')})
    with open(fixture_file_path, 'w') as f:
        f.write(fixture_file_content)
    results = lm.run(**argspec)
    assert results[0] == fixture_file_content
    import os
    os.remove(fixture_file_path)

# Generated at 2022-06-21 06:51:29.799008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._options == None
    assert lookup_module._loader == None
    assert lookup_module._templar == None



# Generated at 2022-06-21 06:51:38.354111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pickle
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    data = pickle.load(open("/home/jjelen/ansible/ansible-tests/lookup_plugins/unvault/klic", 'rb'))
    #print("data: %s" % data)
    vault_password_file = "/home/jjelen/ansible/ansible-tests/lookup_plugins/unvault/klic"
    vault_password = data["password"]

    vault = VaultLib(vault_password_file=vault_password_file, vault_password=vault_password)
    encrypted = vault.encrypt("Ansible Vault test")
    print("encrypted: %s" % encrypted)

# Generated at 2022-06-21 06:51:47.770435
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    import os
    import tempfile
    from ansible.errors import AnsibleParserError

    tempdir = tempfile.gettempdir()
    file_test = os.path.join(tempdir, 'file_test')
    file_test_1 = os.path.join(tempdir, 'file_test_1')
    file_test_2 = os.path.join(tempdir, 'file_test_2')


# Generated at 2022-06-21 06:51:49.833571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:51:50.950462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

test_LookupModule()

# Generated at 2022-06-21 06:51:56.338451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # TODO: add proper unit test
    if not lookup_module.run(terms=['/path/to/nowhere'], variables=None) :
        raise AssertionError('LookupModule.run should raise an exception')

# Generated at 2022-06-21 06:52:00.927322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    file_path = '/etc/group'
    content = lookup_mod.run([file_path], None)
    with open(file_path, 'rb') as f:
        b_content = f.read()
    assert [to_text(b_content)] == content

# Generated at 2022-06-21 06:52:13.988109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock the class
    class MockVars(object):
        def __init__(self):
            self.host_name = 'myserver'
            self.host_vars = {
                'myserver': {
                    'ansible_connection': 'local'
                }
            }
            self.all_hosts = ['myserver']
            self.group_names = ['mygroup']
            self.groups = {
                'mygroup': {
                    'hosts': ['myserver'],
                    'vars': {
                        'ansible_connection': 'local'
                    }
                }
            }
            self.group_vars = {
                'mygroup': {
                    'ansible_connection': 'local'
                }
            }


# Generated at 2022-06-21 06:52:14.740677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:52:49.229144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, {})

# Generated at 2022-06-21 06:52:54.227827
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test initialize
    t1 = LookupModule()
    assert t1

    # test run
    t2 = LookupModule()
    value = t2.run(['../tests/fixtures/lookup_fixture.txt'])
    assert value == [b'3\n']

# Generated at 2022-06-21 06:52:56.420777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:53:01.765184
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''A string is passed to the LookupModule constructor to test if the init function runs without any issues.'''
    test_lookup_module = 'test_lookup_module'
    l = LookupModule(loader=test_lookup_module, templar=test_lookup_module)
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:53:13.152035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader.set_basedir("/usr/share/ansible_plugins")
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.run(['./test/test_lookup_unvault_file'], variables={}, **{}) == [b'This file has been encrypted using ansible-vault.\n']
    assert isinstance(lookup_module.run(['./test/test_lookup_unvault_file'], variables={}, **{})[0], bytes)
    assert lookup_module.run(['/etc/foo.txt'], variables={}, **{}) == []

# Generated at 2022-06-21 06:53:17.703530
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_options({'vars': {}}) == ({'var_options': {}}, {'direct': {}})

# Generated at 2022-06-21 06:53:19.406628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-21 06:53:21.295559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    assert mylookup is not None

# Generated at 2022-06-21 06:53:22.516448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()

# Generated at 2022-06-21 06:53:34.095055
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    # Instantiating object of class LookupModule
    lookup_module = LookupModule()
    # Instantiating object of class display
    display = Display()
    # Creating a mock display object
    display.display = 'mock_display'

    # Mock the method find_file_in_search_path
    def mock_find_file_in_search_path():
        return 'mock_find_file_in_search_path'

    lookup_module.find_file_in_search_path = mock_find_file_in_search_path

    # Mock the method _loader.get_real_file
    def mock_get_real_file():
        return 'mock_get_real_file'

    lookup_module._loader.get_real_file = mock_get_real_file

    # Mock

# Generated at 2022-06-21 06:55:00.269371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.write(b'abc')
    tmpfile.close()

    look = LookupModule()

    res = look.run([tmpfile.name], variables=dict())

    assert res == [b'abc']

    os.unlink(tmpfile.name)



# Generated at 2022-06-21 06:55:08.258829
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()

    assert lookup_instance.run(terms=['README.md'],
                               variables={'ANSIBLE_LOOKUP_PLUGINS': '/path/to/lookup_plugin_dir'}) == []
    assert lookup_instance.run(terms=['/path/to/README.md'],
                               variables={'ANSIBLE_LOOKUP_PLUGINS': '/path/to/lookup_plugin_dir'}) == []

    assert lookup_instance.run(terms=['non_existing_file'],
                               variables={'ANSIBLE_LOOKUP_PLUGINS': '/path/to/lookup_plugin_dir'}) == []

    lookup_instance._loader.set_collection_playbook_paths(['/path/to/playbook_dir'])

    assert lookup

# Generated at 2022-06-21 06:55:17.984336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import shutil
    import tempfile
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import lookup_loader
    
    test_data = os.path.join(os.path.dirname(__file__), 'UnvaultLookupData')
    assert os.path.exists(test_data)
    tmp_path = tempfile.mkdtemp()
    test_file = os.path.join(tmp_path, 'test.yml')
    with open(test_file, 'wb') as f:
        f.write(to_bytes(u'test_secret: secret'))


# Generated at 2022-06-21 06:55:25.817067
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible_collections.ansible.community.plugins.module_utils._text import to_text
    from ansible_collections.ansible.community.tests.unit.plugins.lookup.test_lookup_plugins import TestLookupBase

    # ansible.utils.display.Display()
    display = TestLookupBase.display

    # ansible_collections.ansible.community.plugins.lookup.unvault.LookupModule()
    lookup_module = LookupModule()

    # ansible_collections.ansible.community.plugins.lookup.unvault.LookupModule.run()
    ret = lookup_module.run([
        '/etc/foo.txt',
        'foo.txt',
    ])
    assert ret == [
        'foo',
        'bar',
    ]

# Generated at 2022-06-21 06:55:28.102068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['test.txt']) == []

# Generated at 2022-06-21 06:55:31.063778
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    terms = ['/etc/foo.txt', './bar.txt']
    lookup.run(terms)


# Generated at 2022-06-21 06:55:38.694719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests setup
    # Mock the lookup_base plugin module
    base=dict(
        find_file_in_search_path=lambda variables, dirname, filename: "",
        _loader=dict(
            get_real_file=lambda lookupfile, decrypt: lookupfile,
        )
    )
    # Mock the module_utils display module
    display=dict(
        debug=lambda msg: None,
        vvvv=lambda msg: None,
    )
    # Mock the module_utils to_text function
    def to_text(bytes):
        return "to_text"
    # Mock built-in open
    def open(filename, mode):
        assert mode == 'rb'
        return "file"
    # Mock file handle read() method
    def read():
        return "content"
    # END Tests setup

   

# Generated at 2022-06-21 06:55:46.550562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    display = Display() 
    module = AnsibleModule(argument_spec=dict())
    # Check module.fail_json() behavior
    assert module.fail_json.__name__ == 'fail_json'
    # Check module.exit_json() behavior
    assert module.exit_json.__name__ == 'exit_json'
    # Check module.params object
    assert type(module.params) is dict
    assert module.params == {}
    # Check type of module.params
    assert type(module.params) is dict
    # Create LookupModule() object
    l = LookupModule()
    # Check type of l object
    assert type(l) is LookupModule


# Generated at 2022-06-21 06:55:57.090659
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup._loader = DummyLoader()

    with pytest.raises(AnsibleParserError):
        lookup.run(['/does/not/exist'])

    assert lookup.run(['/does/exist']) == ['some content']
    assert lookup.run(['/some/vault', '/does/exist']) == ['some content', 'some content']
    assert lookup.run(['/some/vault', '/does/exist', '/some/other/vault']) == ['some content', 'some content', 'some content']
    assert lookup.run(['/some/other/vault', '/does/exist', '/some/vault']) == ['some content', 'some content', 'some content']


# Generated at 2022-06-21 06:56:08.076201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f1 = '/etc/foo.txt'
    f2 = '/etc/bar.txt'

    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    mock_loader = Mock(get_real_file=lambda f, decrypt=True: f)
    mock_lookup = Mock(
        find_file_in_search_path=lambda variables, name, term: term,
        _loader=mock_loader)

    with open(f1, 'w+') as f:
        f.write('foo')
    with open(f2, 'w+') as f:
        f.write('bar')

    assert(['foo'] == LookupModule.run(mock_lookup, [f1]))