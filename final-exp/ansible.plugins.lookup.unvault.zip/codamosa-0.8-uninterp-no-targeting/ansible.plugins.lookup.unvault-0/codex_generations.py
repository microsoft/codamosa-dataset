

# Generated at 2022-06-21 06:48:03.694427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:48:14.601339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    # Test with path of unexisting file
    try:
        ret = instance.run(['./path/of/unexisting/file'])
        assert False, 'unexisting file path should raise AnsibleParserError not "%s"' % ret
    except AnsibleParserError as e:
        # Test with path of existing file
        ret = instance.run(['../../lookup_plugins/action_plugins/../../module_utils/basic.py'])
        assert isinstance(ret, list), '"ret" should be a list, not "%s"' % type(ret)
        assert len(ret) == 1, '"len(ret)" should be one, not "%s"' % len(ret)
        assert isinstance(ret[0], str), '"ret[0]" should be a str, not "%s"' % type

# Generated at 2022-06-21 06:48:18.346602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_templar(None)
    assert lookup_module.run([None, 'test_data'], variables={}, connection=None) == ['test_data']

# Generated at 2022-06-21 06:48:30.345543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os.path
    import ansible.plugins.lookup.file
    from ansible.plugins.lookup.file import LookupModule as FLookupModule
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.utils.path import unfrackpath

    class AnsibleOptions(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = None
            self.become_method

# Generated at 2022-06-21 06:48:38.754182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile

    file_content = 'file content'
    path_file = os.path.join(tempfile.gettempdir(), 'tmp_unvault_run_file')
    with open(path_file, 'w') as f:
        f.write(file_content)

    unvault_lookup = LookupModule()
    terms = [path_file]
    result = unvault_lookup.run(terms, variables=None)
    assert file_content == result[0]
    shutil.rmtree(path_file)

# Generated at 2022-06-21 06:48:42.318196
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/tmp/foo']
    variables = {}
    kwargs = {}

    lookup = LookupModule()
    lookup.set_options(var_options=variables, direct=kwargs)
    lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-21 06:48:43.386364
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 06:48:44.466394
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:48:48.849251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run(terms=['/etc/foo.txt'], variables={'faked_a': '/etc/foo.txt'})

# Generated at 2022-06-21 06:48:50.630147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run([], [])

# Generated at 2022-06-21 06:48:53.469334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:48:57.998754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 06:49:08.098287
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common.file import FileLock
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAes256
    from ansible.parsing.vault import VaultAad
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import b
    import os
    import pytest
    import shutil
    import tempfile

    vault_password = "vault_password"
    secret_data = "secret"
    tmp_directory = tempfile.mkdtemp()
    os.chmod(tmp_directory, 0o700)


# Generated at 2022-06-21 06:49:08.972673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:49:10.375033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:49:15.362069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    results = lookup.run(['file1', 'file2'], variables={'lookup_file_search_path': '.'})
    assert len(results) == 2
    assert results[0] == b'file1 contents'
    assert results[1] == b'file2 contents'

# Generated at 2022-06-21 06:49:18.718850
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([], []) == []
    assert lookup.run(['/etc/ansible/hosts'], []) == [u'default\nlocalhost\n']

# Generated at 2022-06-21 06:49:29.256753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify unvault lookup class is initialized
    lookup = LookupModule()
    assert lookup is not None
    # Verify unvault lookup returns data when file exists
    terms = ['/home/user/test.yml']
    lookup.set_loader()
    lookup.set_templar()
    lookup.set_basedir('/home/user')
    ret = lookup.run(terms)
    assert ret == [u'key1: val1\nkey2: val2']

    # Verify unvault lookup throws AnsibleParserError when file does not exist
    terms = ['/home/user/nosuchfile.yml']
    lookup.set_loader()
    lookup.set_templar()
    lookup.set_basedir('/home/user')

# Generated at 2022-06-21 06:49:30.216308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return None

# Generated at 2022-06-21 06:49:31.889964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [ 'foo.txt' ]

    result = lookup_module.run(terms, variables=None)

    assert result == [ "foo\n" ]

# Generated at 2022-06-21 06:49:38.993142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._loader is not None

# Generated at 2022-06-21 06:49:40.544566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None

# Generated at 2022-06-21 06:49:44.300368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    try:
        lookup_module
    except NameError:
        raise AnsibleError('unvault plugin: nameerror')

# Generated at 2022-06-21 06:49:47.507287
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ['/etc/foo.txt']
    variables = None
    ret = []

    lookup_mod = LookupModule()
    assert lookup_mod is not None
    lookup_mod.run(terms, variables, **{'debug':True})

# Generated at 2022-06-21 06:49:50.133449
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup._options is not None
    assert lookup._loader is not None

# Generated at 2022-06-21 06:49:55.729924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Generate lookup module instance
    lm = LookupModule()
    # Generate lookup argument
    lm.set_options({})
    # Execute run method
    result = lm.run(['/etc/'], variables={})
    # Check the result
    assert result == []


# Generated at 2022-06-21 06:49:57.683964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert lookupModule is not None

# Generated at 2022-06-21 06:49:58.528453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:50:08.950240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('unvault')

    # Tests for the case when the file exists, but does not exist when the search
    # path is applied
    test_file_name = 'test_file'
    _, test_file_path = tempfile.mkstemp(prefix=test_file_name)
    test_file = os.path.basename(test_file_path)
    test_file_contents = 'test-contents'

    with open(test_file, 'wb') as f:
        f.write(to_bytes(test_file_contents))

    assert lookup.run([test_file]) == [test_file_contents]

# Generated at 2022-06-21 06:50:15.964978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert isinstance(c, LookupBase)
    try:
        c.run(terms=["test"])
    except AnsibleParserError as e:
        error = str(e)
    except Exception as err:
        error = err
    assert error.startswith("Unable to find file matching")

# Generated at 2022-06-21 06:50:26.929770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.set_options({'_ansible_lookup_unvault': True})

    assert lookup_instance.run(['/etc/foo.txt']) == ["bar content\n"]

# Generated at 2022-06-21 06:50:38.484013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins import lookup_loader
    import random
    import tempfile
    import os
    loader = lookup_loader.get("unvault")

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, "file-"+str(int(random.random()*100000)))
    contents = b'abcd'
    with open(temp_file, 'wb') as f:
       f.write(contents)

    temp_file2 = os.path.join(temp_dir, "file-"+str(int(random.random()*100000)))
    contents = b'abcd'
    with open(temp_file2, 'wb') as f:
       f.write(contents)

   

# Generated at 2022-06-21 06:50:45.554462
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def find_file_in_search_path(variables, subdirs, search_path):
        return 'foo.txt'

    instance = LookupModule()
    instance._loader = object()
    instance._loader.get_real_file = lambda x, decrypt=True: 'bar.txt'
    instance.find_file_in_search_path = find_file_in_search_path
    assert instance.run(['foo.txt'], {}) == ['foobar']

# Generated at 2022-06-21 06:50:48.248224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj is not None

# Generated at 2022-06-21 06:50:58.663281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import stat
    from ansible.plugins.lookup.unvault import LookupModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleParserError

    # Example arguments
    terms = "/this/is/a/test/file"
    variables=ImmutableDict({"paths":["/this/is/a/test"]})
    kwargs = {}

    # Create test directory
    os.makedirs("/this/is/a/test/")

    # Create test file
    with open("/this/is/a/test/file", 'w') as f:
        f.writelines(["File contents"])

    # Create test lookup object
    lookup = LookupModule

# Generated at 2022-06-21 06:51:02.044896
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_var = {'files': ['/etc']}
    lookup_plug = LookupModule()
    lookup_plug.set_options(var_options=test_var, direct={})
    lookup_plug.run("/test_file")


# Generated at 2022-06-21 06:51:03.228216
# Unit test for constructor of class LookupModule
def test_LookupModule():

    test_module = LookupModule()
    assert test_module is not None

# Generated at 2022-06-21 06:51:03.821108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:51:13.416962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Without a directory argument and with a nonexistent file argument
    lookup_module_obj = LookupModule(
        loader=None,
        basedir='/home/test',
        run_add_hooks=True,
        vault_id=None  # vault_id is required by __init__()
    )
    assert lookup_module_obj._options['_original_basedir'] == '/home/test'
    assert lookup_module_obj.compile_options() == {}
    assert lookup_module_obj.run(terms='does/not/matter', variables={}) == []

# Generated at 2022-06-21 06:51:17.053223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['/etc/foo.txt']
    variables = None
    lm = LookupModule()
    lm.run(terms, variables)

# Generated at 2022-06-21 06:51:35.776510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:51:37.578241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 4
    module = LookupModule()
    terms = ["/etc/hosts"]
    module.run(terms)

# Generated at 2022-06-21 06:51:39.123470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:51:48.084925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/etc/answer']
    vault_pass = 'test'
    with open(terms[0], 'w') as f:
        f.write('42')
    cmd = 'ansible-vault encrypt {} --vault-password-file=.vault_pass.txt'.format(terms[0])
    os.system(cmd)
    with open('.vault_pass.txt', 'w') as f:
        f.write(vault_pass)
    with open('.vault_pass.txt', 'r') as f:
        vault_pass = f.read()
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = '.vault_pass.txt'
    os.environ['ANSIBLE_VAULT_PASSWORD'] = vault_pass

# Generated at 2022-06-21 06:51:50.775256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([0], variables={'playbook_dir': '~/'}) == []

# Generated at 2022-06-21 06:51:52.370789
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 06:52:02.266680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setting up class instance
    lookup_obj = LookupModule()

    path = "/etc/foo.txt"

    path_list = [path]

    # setting up vars_manager instance
    from ansible.template import Templar
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)
    variable_manager._templar = templar

    # variable_manager.extra_vars = {'ansible_verbose_always': True}

    # set options
    lookup_obj.set_options(var_options={'ansible_verbose_always': True}, direct={})

    # setting up mock
    def mock_get_real_file(self, path, decrypt=False):
        return path

    lookup_obj._loader

# Generated at 2022-06-21 06:52:13.901444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_loader, sources=[])
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)

    test_terms = [u'/etc/foo.txt']
    test_file = 'test/files/TEST_LOOKUP'
    test_lookup_module = LookupModule()
    test_lookup_module.set_options(direct={'paths': 'test/files'})
    test_lookup_module.run(test_terms, test_variable_manager)

# Generated at 2022-06-21 06:52:14.907821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance

# Generated at 2022-06-21 06:52:18.639990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["item0", "item1", "item2"]) == ['item0', 'item1', 'item2']

# Generated at 2022-06-21 06:52:52.589152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) > 0

# Generated at 2022-06-21 06:53:02.719510
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    contents = b'hello world'
    term = './unvault_test.file'
    terms = [term]
    variables = dict()
    kwargs = dict()

    # Instance of class LookupModule
    lookup_module = LookupModule()

    # Parameters with mocked methods and return values
    lookup_module.set_options = MagicMock(return_value=None)

    # Create a new file and add its contents
    open(term, 'wb').write(contents)
    with open(term, 'rb') as f:
        b_contents = f.read()
    assert contents == b_contents, "File content doesn't match with previous one"

    # Run method run of class LookupModule
    assert lookup_module.run(terms, variables, **kwargs) == [contents]

# Generated at 2022-06-21 06:53:04.762017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:53:13.018820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod._display = display

    assert mod.run(terms=u'/etc/hosts', variables=dict(ansible_vault_password_file=u'b.txt')) == to_text(b'127.0.0.1\tlocalhost\n\n# The following lines are desirable for IPv6 capable hosts\n::1     ip6-localhost ip6-loopback\nfe00::0 ip6-localnet\nff00::0 ip6-mcastprefix\nff02::1 ip6-allnodes\nff02::2 ip6-allrouters\nff02::3 ip6-allhosts\n')

# Generated at 2022-06-21 06:53:14.202495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:53:17.841519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    test_lookup.set_loader({'File': {'_prefix': 'files'}})

# Generated at 2022-06-21 06:53:19.480220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({}, {})

# Generated at 2022-06-21 06:53:21.335590
# Unit test for constructor of class LookupModule
def test_LookupModule():

    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Generated at 2022-06-21 06:53:33.471897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    # Python3
    import unittest
    import ansible.plugins.lookup.unvault

    try:
        # Python 2.7
        from StringIO import StringIO
        import mock
    except ImportError:
        # Python 3.8
        from io import StringIO
        from unittest import mock

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.module = mock.Mock()
            self.module.run.return_value = ["Test"]

        def test_run(self):
            # Inserting user input in the test as a parameter
            result = ansible.plugins.lookup.unvault.LookupModule.run(self.module, terms=["test.txt"])
            self.assertEqual(result, ["Test"])


# Generated at 2022-06-21 06:53:34.872666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run('/not/existing/file')

# Generated at 2022-06-21 06:54:54.023745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:55:03.866260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Copied from lib/ansible/plugins/lookup/__init__.py
    # set-up metaclass variables
    setattr(LookupBase, '_lookup_plugins', dict())
    LookupBase.class_vars = dict()

    # run constructor
    lookup_module = LookupModule()

    # test that all variables were set as expected
    assert lookup_module._options == {}
    assert lookup_module._display.verbosity == 0
    assert lookup_module._display.deprecated_warning == False
    assert lookup_module._display.colorize == 'auto'
    assert lookup_module._display.columns == 80


# Generated at 2022-06-21 06:55:11.781197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of self
    lookupModule = LookupModule()

    # Create a terms list
    terms = ['/etc/foo.txt']

    # Call run to get results
    results = lookupModule.run(terms)

    # Check results
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] == 'This is foo.txt\n'

# Generated at 2022-06-21 06:55:14.178072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("in test_LookupModule_run")
    lm = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    lm.run(terms, variables, **kwargs)

# Generated at 2022-06-21 06:55:25.209084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["example"]
    variables = dict()

    result1 = lookup.run(terms, variables)

# Generated at 2022-06-21 06:55:26.831773
# Unit test for constructor of class LookupModule
def test_LookupModule():
	assert hasattr(LookupModule(),'run')

# Generated at 2022-06-21 06:55:37.181599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    lookup_module = LookupModule()


# Generated at 2022-06-21 06:55:39.796168
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert lookup_module.file_encoding == 'utf-8'

# Generated at 2022-06-21 06:55:41.138978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:55:47.886425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
