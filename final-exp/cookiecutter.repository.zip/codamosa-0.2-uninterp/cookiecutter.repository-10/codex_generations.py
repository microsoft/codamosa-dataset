

# Generated at 2022-06-17 17:32:57.281000
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-17 17:33:02.588657
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    import tempfile
    import shutil
    import json
    import os
    import sys
    from cookiecutter.main import cookiecutter

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter template
    cookiecutter_template = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(cookiecutter_template)
    with open(os.path.join(cookiecutter_template, 'cookiecutter.json'), 'w') as f:
        json.dump({'full_name': 'Fake Name'}, f)

    # Create a temporary cookiecutter template

# Generated at 2022-06-17 17:33:12.487166
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-17 17:33:20.968232
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:33:32.416582
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json function."""
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo/fake-repo') == True

# Generated at 2022-06-17 17:33:37.388628
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_

# Generated at 2022-06-17 17:33:46.186152
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == (
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        False,
    )


# Generated at 2022-06-17 17:33:57.380909
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gitlab': 'https://gitlab.com/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-17 17:34:08.448481
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:34:13.848618
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:34:28.069476
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test for function repository_has_cookiecutter_json
    """
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo-tmpl/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo-tmpl/fake-repo-pre') == True

# Generated at 2022-06-17 17:34:36.708667
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:34:45.112334
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:34:55.298599
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for function repository_has_cookiecutter_json."""
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-no-json') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-no-json/') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-no-json/fake-repo-tmpl') == True

# Generated at 2022-06-17 17:35:07.344267
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )


# Generated at 2022-06-17 17:35:17.085136
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter import main
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    clone_to_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    clone_to_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    clone_to_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    clone_to_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    clone_to_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    clone_to_dir = tempfile.mkdtemp

# Generated at 2022-06-17 17:35:21.934979
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir.endswith('cookiecutter-pypackage')
    assert cleanup is False

# Generated at 2022-06-17 17:35:30.566613
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the repository_has_cookiecutter_json function."""
    # Test a valid directory
    assert repository_has_cookiecutter_json(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            '..',
            'tests',
            'fake-repo-pre',
        )
    )

    # Test an invalid directory
    assert not repository_has_cookiecutter_json(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            '..',
            'tests',
            'fake-repo-pre',
            'invalid',
        )
    )

# Generated at 2022-06-17 17:35:36.702458
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = '.'
    abbreviations = {'.': '.'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '.'
    assert cleanup == False

    # Test with a local directory
    template = './tests/fake-repo-tmpl'
    abbreviations = {'.': '.'}
    clone_to_dir = '.'
    checkout = None

# Generated at 2022-06-17 17:35:46.363463
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:35:54.970582
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/cookiecutter-test',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ('/tmp/cookiecutter-test/cookiecutter-pypackage', False)

# Generated at 2022-06-17 17:36:02.251839
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
        "ghu": "git+https://{}@github.com/{}.git",
        "ghp": "git+ssh://git@github.com/{}.git",
        "bbp": "git+ssh://git@bitbucket.org/{}.git",
        "bbh": "git+https://{}@bitbucket.org/{}.git",
    }

# Generated at 2022-06-17 17:36:13.163349
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
   

# Generated at 2022-06-17 17:36:21.899561
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test that repository_has_cookiecutter_json returns True if the
    repo_directory is valid and False otherwise.
    """
    repo_directory = 'tests/fake-repo-tmpl'
    assert repository_has_cookiecutter_json(repo_directory) == True
    repo_directory = 'tests/fake-repo-tmpl/'
    assert repository_has_cookiecutter_json(repo_directory) == True
    repo_directory = 'tests/fake-repo-tmpl-no-cookiecutter-json'
    assert repository_has_cookiecutter_json(repo_directory) == False
    repo_directory = 'tests/fake-repo-tmpl-no-cookiecutter-json/'
    assert repository_has_cookiecutter_json(repo_directory) == False

# Generated at 2022-06-17 17:36:32.304376
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test the function repository_has_cookiecutter_json.
    """
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter.json file
    temp_json_file = tempfile.NamedTemporaryFile(
        dir=temp_dir,
        suffix='.json',
        delete=False,
    )
    temp_json_file.close()

    # Test that the function returns True
    assert repository_has_cookiecutter_json(temp_dir)

    # Remove the temporary cookiecutter.json file
    os.remove(temp_json_file.name)

    # Test that the function returns False
    assert not repository_has_cookiecutter_json(temp_dir)

    # Remove the temporary directory

# Generated at 2022-06-17 17:36:36.988299
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a directory argument
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone

# Generated at 2022-06-17 17:36:46.048615
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that repository_has_cookiecutter_json returns True for a valid
    repository directory and False for an invalid one."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary repository directory
    repo_dir = os.path.join(temp_dir, 'repo_dir')
    os.mkdir(repo_dir)

    # Create a temporary cookiecutter.json file
    cookiecutter_json = os.path.join(repo_dir, 'cookiecutter.json')
    with open(cookiecutter_json, 'w') as f:
        f.write('{"foo": "bar"}')

    # Test that repository_has_cookiecutter_json returns True for the
    # temporary repository directory


# Generated at 2022-06-17 17:36:54.949233
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:00.550233
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '~/'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '~/cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:12.232539
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.utils import rmtree
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone_to_dir = 'tests/test-output/repo-tmp'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    abbreviations = DEFAULT_CONFIG['abbreviations']

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )


# Generated at 2022-06-17 17:37:27.262655
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repo
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = None
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repo with directory

# Generated at 2022-06-17 17:37:39.169772
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test with a local directory
    local_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    repo_dir, cleanup = determine_repo_dir(
        template=local_dir,
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir == local_dir
    assert cleanup is False

    # Test with a local directory that is not a repo
    local_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl-no-json')
   

# Generated at 2022-06-17 17:37:53.170148
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone

# Generated at 2022-06-17 17:38:03.492369
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a repository in the temporary directory
    repo_dir = os.path.join(tmpdir, 'foo')
    os.mkdir(repo_dir)
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{"foo": "bar"}')

    # Test with a local directory

# Generated at 2022-06-17 17:38:14.714545
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == (
        '/tmp/cookiecutter-pypackage',
        False,
    )

# Generated at 2022-06-17 17:38:22.533967
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    import tempfile
    import shutil
    import json
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter.json file
    cookiecutter_json = os.path.join(temp_dir, 'cookiecutter.json')
    with open(cookiecutter_json, 'w') as f:
        json.dump({'foo': 'bar'}, f)

    # Test with a local directory

# Generated at 2022-06-17 17:38:30.560674
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:38:38.794646
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == './cookiecutter-pypackage'


# Generated at 2022-06-17 17:38:52.702596
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase

    class DetermineRepoDirTests(TestCase):

        def setUp(self):
            self.temp_dir = mkdtemp()
            self.addCleanup(rmtree, self.temp_dir)

        def test_determine_repo_dir_with_abbreviation(self):
            """
            Test that determine_repo_dir returns the correct directory
            when given a template with an abbreviation.
            """
            template = 'gh:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-17 17:39:03.041161
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:14.352932
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup

# Generated at 2022-06-17 17:39:25.023483
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the function determine_repo_dir
    """
    # Test for a local directory
    template = '.'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '.'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = '.'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = 'tests'


# Generated at 2022-06-17 17:39:33.846129
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:42.416877
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:52.736782
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository with a directory

# Generated at 2022-06-17 17:40:03.488426
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.utils import rmtree

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = 'tests/test-repo'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )


# Generated at 2022-06-17 17:40:14.157606
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-17 17:40:24.457296
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory that doesn't exist
    template = 'tests/fake-repo-tmpl-doesnt-exist'
    abbreviations = {}
    clone_

# Generated at 2022-06-17 17:40:33.238172
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:40:42.826888
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test for a valid repo
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repo with a directory
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-17 17:41:00.885141
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone

# Generated at 2022-06-17 17:41:05.444130
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    # Test for a valid repository
    repo_dir, cleanup = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository with a directory

# Generated at 2022-06-17 17:41:17.836525
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '~/cookiecutters'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '~/cookiecutters/cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid

# Generated at 2022-06-17 17:41:28.550998
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:41:39.372752
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:41:53.674341
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:42:02.801928
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test with an invalid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-17 17:42:14.035213
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout='master',
        no_input=False,
        password=None,
        directory=None,
    ) == (
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        False,
    )


# Generated at 2022-06-17 17:42:19.930289
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:42:29.782213
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:42:52.926761
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
