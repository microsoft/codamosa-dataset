

# Generated at 2022-06-17 17:33:05.393755
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for function repository_has_cookiecutter_json."""
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-no-json') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-no-json/') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-no-json/fake-repo-tmpl') == True

# Generated at 2022-06-17 17:33:13.843918
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-17 17:33:19.350296
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage',
        abbreviations={},
        clone_to_dir='/tmp/cookiecutters',
        checkout='master',
        no_input=True,
        password=None,
        directory=None,
    ) == ('/tmp/cookiecutters/cookiecutter-pypackage', False)

# Generated at 2022-06-17 17:33:32.186365
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/cookiecutter-test',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    ) == ('/tmp/cookiecutter-test/cookiecutter-pypackage', False)

# Generated at 2022-06-17 17:33:42.291440
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-pre'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_

# Generated at 2022-06-17 17:33:54.946654
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == (
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        False,
    )


# Generated at 2022-06-17 17:34:05.143299
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test for function determine_repo_dir"""
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/cookiecutter-test',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ('/tmp/cookiecutter-test/cookiecutter-pypackage', False)


# Generated at 2022-06-17 17:34:11.637402
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == expected

    template = 'bb:audreyr/cookiecutter-pypackage'
    expected = 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == expected

    template = 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-17 17:34:23.719610
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    from cookiecutter import main

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test with directory
    directory = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:34:35.914919
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    from cookiecutter import main
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter.json file
    temp_json = tempfile.NamedTemporaryFile(
        dir=temp_dir,
        suffix='.json',
        delete=False
    )
    temp_json.write(b'{"cookiecutter": "json"}')
    temp_json.close()

    # Test the function with a local directory

# Generated at 2022-06-17 17:34:51.104346
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    import tempfile
    import shutil
    import json
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter.json file
    cookiecutter_json = os.path.join(temp_dir, 'cookiecutter.json')
    with open(cookiecutter_json, 'w') as f:
        json.dump({'name': 'test'}, f)

    # Test with a directory
    assert determine_repo_dir(temp_dir, {}, temp_dir, None, False) == (temp_dir, False)

    # Test with a zip file
    zip_file = os.path.join(temp_dir, 'test.zip')
    shutil.make_archive

# Generated at 2022-06-17 17:34:58.664793
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ('cookiecutter-pypackage', False)

# Generated at 2022-06-17 17:35:11.171179
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository with directory

# Generated at 2022-06-17 17:35:22.261160
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert cleanup == False

# Generated at 2022-06-17 17:35:31.965760
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'


# Generated at 2022-06-17 17:35:41.006266
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    # pylint: disable=unused-argument
    def mock_repo_has_cookiecutter_json(repo_directory):
        """Mock the repository_has_cookiecutter_json function."""
        return repo_directory == 'repo_dir'

    def mock_is_repo_url(value):
        """Mock the is_repo_url function."""
        return value == 'repo_url'

    def mock_is_zip_file(value):
        """Mock the is_zip_file function."""
        return value == 'zip_file'

    def mock_expand_abbreviations(template, abbreviations):
        """Mock the expand_abbreviations function."""
        return template


# Generated at 2022-06-17 17:35:49.561189
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test function determine_repo_dir
    """
    # Test for is_repo_url
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+ssh://git@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-17 17:35:59.323651
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.main import cookiecutter

    # Test a local repo
    repo_dir, cleanup = determine_repo_dir(
        template='tests/fake-repo-tmpl',
        abbreviations={},
        clone_to_dir='tests/fake-repo-preview',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup is False

    # Test a local repo with directory

# Generated at 2022-06-17 17:36:11.261109
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a valid repo
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

    # Test with a valid repo and directory

# Generated at 2022-06-17 17:36:19.413063
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:36:29.126688
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir
    """
    # Test for a valid repo_dir
    repo_dir = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/cookiecutter-test',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )
    assert repo_dir[0] == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert repo_dir[1] == False

    # Test for a valid repo_dir

# Generated at 2022-06-17 17:36:40.207093
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository with abbreviations

# Generated at 2022-06-17 17:36:49.377893
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout

# Generated at 2022-06-17 17:36:59.870259
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:09.997627
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:19.739581
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:31.530500
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir() function.
    """
    from cookiecutter import config
    from cookiecutter import utils

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = config.DEFAULT_ABBREVIATIONS
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a

# Generated at 2022-06-17 17:37:42.157632
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == os.path.join(clone_to_dir, 'cookiecutter-pypackage')
    assert cleanup is False


# Generated at 2022-06-17 17:37:53.645540
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:58.931853
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    from cookiecutter.main import cookiecutter

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    repo_dir, cleanup = determine_repo_dir(
        template,
        cookiecutter.DEFAULT_ABBREVIATIONS,
        cookiecutter.DEFAULT_CLONE_DIRECTORY,
        cookiecutter.DEFAULT_CHECKOUT,
        cookiecutter.DEFAULT_NO_INPUT,
    )
    assert repo_dir == template
    assert cleanup is False

    # Test with a local directory and a directory argument
    template = 'tests/fake-repo-tmpl'

# Generated at 2022-06-17 17:38:08.125430
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-pre'
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_

# Generated at 2022-06-17 17:38:16.122491
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '.'
    assert cleanup == False


# Generated at 2022-06-17 17:38:22.111520
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:38:31.006335
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test for a valid repo
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repo with directory

# Generated at 2022-06-17 17:38:38.937071
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/test-output'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a URL
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}


# Generated at 2022-06-17 17:38:52.510158
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup is False

# Generated at 2022-06-17 17:39:03.041294
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:11.164421
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:22.878879
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:28.848209
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository

# Generated at 2022-06-17 17:39:44.537669
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    import tempfile
    import shutil
    import os
    import json
    import pytest

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter.json file
    cookiecutter_json_file = os.path.join(temp_dir, 'cookiecutter.json')
    with open(cookiecutter_json_file, 'w') as f:
        json.dump({'name': 'test'}, f)

    # Test if the directory is valid
    assert repository_has_cookiecutter_json(temp_dir)

    # Test if the directory is invalid
    assert not repository_has_cookiecutter_json(tempfile.mkdtemp())

    # Test if the directory is valid

# Generated at 2022-06-17 17:39:52.709292
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test for function determine_repo_dir
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False


# Generated at 2022-06-17 17:40:03.403318
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    from cookiecutter.config import DEFAULT_ABBREVIATIONS
    from cookiecutter.utils import rmtree
    from cookiecutter import __version__

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    repo_dir, cleanup = determine_repo_dir(
        template,
        DEFAULT_ABBREVIATIONS,
        'tests/fake-repo-prefixed',
        'master',
        False,
    )
    assert repo_dir == template
    assert cleanup is False

    # Test with a local directory and a directory argument
    template = 'tests/fake-repo-tmpl'

# Generated at 2022-06-17 17:40:11.627031
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.main import cookiecutter

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = determine_repo_dir(
        template=template,
        abbreviations={},
        clone_to_dir=cookiecutter.DEFAULT_CLONE_DIR,
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir[0].endswith('cookiecutter-pypackage')
    assert repo_dir[1] is False

# Generated at 2022-06-17 17:40:22.673444
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a zip file
    template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    abbreviations = {}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage-master'
    assert cleanup == True

    # Test with a repo URL

# Generated at 2022-06-17 17:40:29.770037
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/cookiecutter-test',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ('/tmp/cookiecutter-test/cookiecutter-pypackage', False)


# Generated at 2022-06-17 17:40:38.635880
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:40:51.898251
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '/home/user/cookiecutters'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-17 17:40:59.418995
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:41:11.355575
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory within the temporary directory
    temp_dir_2 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory within the temporary directory
    temp_dir_3 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory within the temporary directory
    temp_dir_4 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory within the temporary directory
    temp_dir_5 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory within the temporary directory
    temp_dir_6 = tempfile

# Generated at 2022-06-17 17:41:29.103799
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = './tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == './tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and directory
    template = './tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'


# Generated at 2022-06-17 17:41:40.238971
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir
    """
    import tempfile
    import shutil
    import json
    import os
    import sys
    import unittest

    class TestRepo(unittest.TestCase):
        """
        TestRepo class
        """

        def setUp(self):
            """
            setUp function
            """
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_dir_clone = tempfile.mkdtemp()
            self.tmp_dir_clone_2 = tempfile.mkdtemp()
            self.tmp_dir_clone_3 = tempfile.mkdtemp()
            self.tmp_dir_clone_4 = tempfile.mkdtemp()
            self.tmp_dir_clone_5 = tempfile.mkdtemp()


# Generated at 2022-06-17 17:41:53.783687
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a valid repo
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

    # Test with a valid repo and directory

# Generated at 2022-06-17 17:42:04.880417
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    import shutil
    import tempfile

    from cookiecutter.main import cookiecutter

    # Create a temporary directory to store the repo
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned repo
    clone_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the unzipped repo
    unzip_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the repo with a subdirectory
    subdir_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the repo with a subdirectory
    subdir_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the repo with a subdirectory
    subdir_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:42:16.031470
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    from cookiecutter import main
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.utils import rmtree

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'test-repo-tmpl')
    checkout = 'master'
    no_input = False
    password = None
    directory = None


# Generated at 2022-06-17 17:42:27.939196
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == template
    assert cleanup == False

    # Test with a local directory and a directory argument
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False

# Generated at 2022-06-17 17:42:37.473705
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    # Test for a valid repo
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir.endswith('cookiecutter-pypackage')
    assert cleanup is False

    # Test for a valid repo with a directory

# Generated at 2022-06-17 17:42:40.854256
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # TODO: Add unit tests for determine_repo_dir
    pass

# Generated at 2022-06-17 17:42:51.969444
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:43:02.397889
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ('/tmp/cookiecutter-pypackage', False)
