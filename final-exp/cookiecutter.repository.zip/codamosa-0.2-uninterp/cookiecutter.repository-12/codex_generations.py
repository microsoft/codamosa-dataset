

# Generated at 2022-06-17 17:32:59.569952
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test repository_has_cookiecutter_json function.
    """
    assert repository_has_cookiecutter_json(
        'tests/test-repo-tmpl/{{cookiecutter.repo_name}}'
    )
    assert not repository_has_cookiecutter_json(
        'tests/test-repo-tmpl/{{cookiecutter.repo_name}}/fake'
    )
    assert not repository_has_cookiecutter_json(
        'tests/test-repo-tmpl/{{cookiecutter.repo_name}}/fake/fake'
    )
    assert not repository_has_cookiecutter_json(
        'tests/test-repo-tmpl/{{cookiecutter.repo_name}}/fake/fake/fake'
    )

# Generated at 2022-06-17 17:33:06.191290
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-17 17:33:14.380582
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    import shutil
    import tempfile

    # Create a temporary directory to store the test repo
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the test repo
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the test repo
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the test repo
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the test repo
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the test repo
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary

# Generated at 2022-06-17 17:33:22.843989
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-17 17:33:34.054107
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    repo_dir, cleanup = determine_repo_dir(
        template,
        DEFAULT_CONFIG['abbreviations'],
        'tests/fake-repo-prefixed',
        None,
        False,
    )
    assert repo_dir == template
    assert cleanup is False

    # Test with a local directory and a directory within the repo
    template = 'tests/fake-repo-tmpl'

# Generated at 2022-06-17 17:33:43.885963
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
    ) == (
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        False,
    )


# Generated at 2022-06-17 17:33:53.585618
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == './cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:34:03.874362
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir
    """
    # template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    # abbreviations = {}
    # clone_to_dir = '.'
    # checkout = None
    # no_input = False
    # password = None
    # directory = None
    # repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    # print(repo_dir)
    # print(cleanup)
    # assert repo_dir == '.'
    # assert cleanup == False

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir

# Generated at 2022-06-17 17:34:10.941781
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json function."""
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo/fake-repo') == True

# Generated at 2022-06-17 17:34:22.131403
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:34:36.066911
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
   

# Generated at 2022-06-17 17:34:45.357954
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-pre'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
   

# Generated at 2022-06-17 17:34:55.169318
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup is False

    # Test with a local directory and a directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}

# Generated at 2022-06-17 17:35:03.892727
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:35:15.976489
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup is False

    # Test with a local directory and a directory within the repo
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'

# Generated at 2022-06-17 17:35:26.132427
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # TODO: Add more tests
    # TODO: Add tests for exceptions
    # TODO: Add tests for abbreviations
    # TODO: Add tests for zip files
    # TODO: Add tests for local directories
    # TODO: Add tests for remote repositories
    # TODO: Add tests for local repositories
    # TODO: Add tests for directories within repositories
    # TODO: Add tests for non-existent directories
    # TODO: Add tests for non-existent repositories
    # TODO: Add tests for non-existent zip files
    # TODO: Add tests for non-existent abbreviations
    # TODO: Add tests for non-existent branches
    # TODO: Add tests for non-existent tags
    # TODO: Add tests for non-existent commits
    # TODO: Add tests

# Generated at 2022-06-17 17:35:34.705917
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    import tempfile
    import shutil
    import os
    from cookiecutter.main import cookiecutter

    # Create a temporary directory to store the repo
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the template
    template_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned repo
    clone_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the unzipped repo
    unzip_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned repo
    clone_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned repo
    clone_dir = tempfile.mkdtemp()

    #

# Generated at 2022-06-17 17:35:43.284791
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:35:55.454436
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter import main

    # Test 1: Test that determine_repo_dir returns the correct directory
    # for a local template
    template = 'tests/test-template'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/test-template'
    assert cleanup == False

    # Test 2: Test that determine_repo_dir returns the correct directory
    # for a local template with a directory

# Generated at 2022-06-17 17:36:06.386702
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
   

# Generated at 2022-06-17 17:36:16.975333
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:36:24.417314
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test that determine_repo_dir returns the correct directory.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:36:33.270281
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone

# Generated at 2022-06-17 17:36:42.256871
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository with a directory

# Generated at 2022-06-17 17:36:50.521799
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    # Test for a zip file
    template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage-master'
    assert cleanup == True

    # Test for a repo url

# Generated at 2022-06-17 17:37:01.025143
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir() function."""
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None

# Generated at 2022-06-17 17:37:12.764915
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-preview'
    checkout = None
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_

# Generated at 2022-06-17 17:37:22.006148
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '.'
    checkout = None
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:37:34.110743
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test for a valid repository with directory

# Generated at 2022-06-17 17:37:43.601544
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a valid repository
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

    # Test with a valid repository with a directory

# Generated at 2022-06-17 17:37:56.209961
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = '.'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '.'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = '.'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = ''
    no_input = False
    password = ''
    directory = 'tests'
    repo_dir

# Generated at 2022-06-17 17:38:05.699735
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # Test for a valid repository
    repo_dir, cleanup = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup is False

    # Test for a valid repository with a directory

# Generated at 2022-06-17 17:38:15.846548
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = '.'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '.'
    assert cleanup == False

    # Test with a local directory and a directory
    template = '.'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None

# Generated at 2022-06-17 17:38:28.318463
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:38:37.557477
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    from cookiecutter import config
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
        repo_dir, cleanup = determine_repo_dir(
            template,
            config.DEFAULT_ABBREVIATIONS,
            tmp_dir,
            None,
            False,
        )
        assert repo_dir.endswith('cookiecutter-pypackage')
        assert cleanup is False

        template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'

# Generated at 2022-06-17 17:38:48.111893
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a repository in a subdirectory of the temporary directory
    repo_dir = os.path.join(tmpdir, 'foo')
    os.mkdir(repo_dir)
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{"foo": "bar"}')

    # Test: Local repository

# Generated at 2022-06-17 17:38:53.438370
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test for a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test for a local directory with a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
   

# Generated at 2022-06-17 17:39:04.813628
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup is False

    # Test with a local directory and a directory argument
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
   

# Generated at 2022-06-17 17:39:11.055849
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = "C:\\Users\\user\\AppData\\Local\\Temp\\cookiecutter-test"
    checkout = "master"
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == "C:\\Users\\user\\AppData\\Local\\Temp\\cookiecutter-test\\cookiecutter-pypackage"
    assert cleanup == False

# Generated at 2022-06-17 17:39:16.194775
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:33.983069
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:39:43.822734
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'

# Generated at 2022-06-17 17:39:52.785435
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    from cookiecutter.main import cookiecutter

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    repo_dir, cleanup = determine_repo_dir(
        template,
        cookiecutter.DEFAULT_ABBREVIATIONS,
        cookiecutter.DEFAULT_CLONE_DIRECTORY,
        None,
        False,
    )
    assert repo_dir == template
    assert cleanup is False

    # Test with a local directory and a directory within it
    template = 'tests/fake-repo-tmpl'

# Generated at 2022-06-17 17:40:03.240379
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter import main

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = main.DEFAULT_ABBREVIATIONS
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:40:13.871407
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/tmp/test_determine_repo_dir'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == '/tmp/test_determine_repo_dir/cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:40:23.263351
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == './cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:40:32.062140
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:40:41.109852
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == (
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        False,
    )


# Generated at 2022-06-17 17:40:52.475306
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = DEFAULT_CONFIG['abbreviations']
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert cleanup == False

# Generated at 2022-06-17 17:40:59.867088
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:41:22.390965
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'test_dir'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == os.path.join(clone_to_dir, 'cookiecutter-pypackage')
    assert cleanup == False

# Generated at 2022-06-17 17:41:32.108261
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:41:41.137451
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir
    """
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter.json file
    cookiecutter_json = os.path.join(temp_dir, 'cookiecutter.json')
    with open(cookiecutter_json, 'w') as f:
        json.dump({'foo': 'bar'}, f)

    # Test that the function returns the correct directory

# Generated at 2022-06-17 17:41:54.205036
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir
    """
    from cookiecutter import main
    import os
    import shutil
    import tempfile

    # Create a temporary working directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory for the cookiecutter template
    temp_template_dir = tempfile.mkdtemp()

    # Create a temporary directory for the cookiecutter template
    # with a cookiecutter.json file
    temp_template_dir_with_cookiecutter_json = tempfile.mkdtemp()
    with open(os.path.join(temp_template_dir_with_cookiecutter_json, 'cookiecutter.json'), 'w') as f:
        f.write('{}')

    # Create a temporary directory for the cookiecutter template
    # with

# Generated at 2022-06-17 17:42:02.056740
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:42:11.545658
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:42:19.602338
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a valid template
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp'
    checkout = None
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

    # Test with an invalid template

# Generated at 2022-06-17 17:42:30.646421
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'tests/fake-repo-tmpl'
    assert cleanup == False

    # Test with a local directory and a subdirectory
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = '.'
   

# Generated at 2022-06-17 17:42:38.328142
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'cookiecutter-pypackage'
    assert cleanup == False

# Generated at 2022-06-17 17:42:52.030274
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir function.
    """
    from cookiecutter.config import DEFAULT_ABBREVIATIONS
    from cookiecutter.utils import rmtree
    from cookiecutter.vcs import is_vcs
    import tempfile

    # Test with a local directory
    template = 'tests/fake-repo-tmpl'
    clone_to_dir = tempfile.mkdtemp()
    repo_dir, cleanup = determine_repo_dir(
        template,
        DEFAULT_ABBREVIATIONS,
        clone_to_dir,
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir == template
    assert cleanup is False

    # Test with a local directory and a subdirectory