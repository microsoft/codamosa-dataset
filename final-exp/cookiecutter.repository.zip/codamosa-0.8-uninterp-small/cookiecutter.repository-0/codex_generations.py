

# Generated at 2022-06-25 15:33:12.058633
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    input_0 = '{{_cookiecutter.project_slug}}'
    input_1 = {'cookiecutter-pypackage': 'https://github.com/audreyr/cookiecutter-pypackage'}
    input_2 = '/tmp/pytest-of-repo/pytest-0/test_determine_repo_dir0'
    input_3 = None
    input_4 = False
    input_5 = None
    input_6 = None
    output_var_0, output_var_1 = determine_repo_dir(
        input_0, input_1, input_2, input_3, input_4, input_5, input_6
    )

# Generated at 2022-06-25 15:33:14.765845
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # 1
    assert (expand_abbreviations("github:kragniz/cookiecutter-pypackage", {
            'github': 'https://github.com/{}.git',
            'bitbucket': 'https://bitbucket.org/{}'})) == "https://github.com/kragniz/cookiecutter-pypackage.git"



# Generated at 2022-06-25 15:33:18.806645
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    print("test values: true false")
    test_case_0()


test_repository_has_cookiecutter_json()

# Generated at 2022-06-25 15:33:23.564429
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    try:
        assert test_case_0() == False
    except AssertionError as e:
        print(e)
    else:
        print('test for function repository_has_cookiecutter_json pass')

test_repository_has_cookiecutter_json()

# Generated at 2022-06-25 15:33:24.147466
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert True == False


# Generated at 2022-06-25 15:33:29.447414
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Set up test data
    var_0 = False
    var_1 = {}
    var_2 = os.getcwd()
    var_3 = None
    var_4 = False
    var_5 = None
    var_6 = None

    # Call function
    result = determine_repo_dir(var_0, var_1, var_2, var_3, var_4, var_5, var_6)

    # Verify results
    assert result == None


# Generated at 2022-06-25 15:33:33.866048
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    s = 'a'
    d = {}
    b = True
    c = 'b'
    i = 1
    assert determine_repo_dir(s, d, b, c, i) == ''



# Generated at 2022-06-25 15:33:38.704188
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "a"
    abbreviations = {}
    clone_to_dir = "a"
    checkout = "a"
    no_input = True
    password = None
    directory = None
    var_0 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert var_0 == (False, True)

# Generated at 2022-06-25 15:33:44.513441
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    clone_to_dir = './example'
    checkout = None
    no_input = True
    password = None
    directory = None
    template = './test-repo-tmpl'

    # invoke function, then check expected results
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

    assert repo_dir == './example/test-repo-tmpl/template'

# Generated at 2022-06-25 15:33:51.843205
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'C:\\Python35\\Scripts'
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    directory_1, cleanup_1 = determine_repo_dir(template, abbreviations,
                                                clone_to_dir, checkout,
                                                no_input, password,
                                                directory)
    assert directory_1 == 'C:\\Python35\\Scripts\\cookiecutter-pypackage' \
        and cleanup_1 is False

# Generated at 2022-06-25 15:33:57.694823
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    try:
        test_case_0()
    except Exception:
        pass



# Generated at 2022-06-25 15:34:03.835728
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    source_template_path = os.path.abspath('./')
    template='template_case_0'
    abbreviations = dict()
    abbreviations['template_case_0'] = 'https://github.com/cookiecutter/cookiecutter.git'
    clone_to_dir = os.path.join(source_template_path, 'repos')
    checkout='master'
    no_input=True
    password=None
    directory=None


# Main function to run unit tests

# Generated at 2022-06-25 15:34:06.240697
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # <Input 0>
    repo_directory = ''
    # <Output 0>
    assert (False) == (repository_has_cookiecutter_json(repo_directory))



# Generated at 2022-06-25 15:34:11.991269
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print('Test determine_repo_dir')
    abbreviations = {'gh': 'https://github.com'}
    clone_to_dir = '~/cookiecutters'
    checkout = 'master'
    no_input = True
    password = 'password'
    directory = 'Cookiecutter-Pypackage'
    template = '~/Cookiecutter-Pypackage'
    template_name, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert template_name == os.path.expanduser('~/Cookiecutter-Pypackage/Cookiecutter-Pypackage')
    assert cleanup == False


# Generated at 2022-06-25 15:34:21.313741
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    bool_0 = False
    bool_1 = True
    int_0 = 0
    int_1 = 1
    int_2 = 2
    str_0 = ""
    str_1 = "a"
    str_2 = "b"
    str_3 = "c"

    # Test cases
    # Create a cookiecutter.json file in temp dir.
    # Create a template dir in the temp dir.
    # Put the cookiecutter.json in the template dir.
    # Check the template dir exists and the cookiecutter.json file is present.
    # Put the cookiecutter.json in the temp dir.
    # Check the temp dir exists and the cookiecutter.json file is present.
    # Put the cookiecutter.json in the parent dir of the temp dir.
    # Check the parent dir exists and the cookiecut

# Generated at 2022-06-25 15:34:26.691303
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # This tests the default case
    assert True == repository_has_cookiecutter_json("")
    # This tests the exception case
    # assert True == repository_has_cookiecutter_json(repo_directory)
    # python3 -m unittest -q tests.cookiecutter.test_main.test_repository_has_cookiecutter_json



# Generated at 2022-06-25 15:34:28.124598
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(repo_directory=True)


# Generated at 2022-06-25 15:34:38.690182
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = 'test'
    var_1 = {}
    var_2 = 'test'
    var_3 = ''
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = ''
    var_15 = None
    var_16 = ''
    var_17 = None
    var_18 = ''
    var_19 = None
    var_20 = ''
    var_21 = None
    var_22 = ''
    var_23 = None
    var_24 = ''
    var_25 = None
    var_26 = ''
    var_27 = None

# Generated at 2022-06-25 15:34:40.252601
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test for command-line options.
    # One argument, --version.
    assert True



# Generated at 2022-06-25 15:34:49.565023
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_dir_1 = "/Users/william/tests/test_dir_1"
    allowed_test_dir_1 = True
    file_1 = "/Users/william/tests/test_file_1"
    allowed_file_1 = False

    test_repo_1_cookiecutter_json_file = "/Users/william/tests/test_repo_1/cookiecutter.json"

    test_repo_1_cookiecutter_json_file_exists = os.path.isfile(test_repo_1_cookiecutter_json_file)
    test_repo_1_exists = os.path.isdir("/Users/william/tests/test_repo_1")

# Generated at 2022-06-25 15:34:52.961782
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(True) == False
    assert repository_has_cookiecutter_json(False) == False



# Generated at 2022-06-25 15:34:58.892528
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    s = determine_repo_dir(
        template='dfgjhfdjhdf',
        abbreviations='dgfdjhgfdhjgfd',
        clone_to_dir='dfgjhfdjhdf',
        checkout='dfgjhfdjhdf',
        no_input='dfgjhfdjhdf',
        password='dfgjhfdjhdf',
        directory='dfgjhfdjhdf'
    )
    return s

# Generated at 2022-06-25 15:35:06.106888
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Local variable test
    assert repository_has_cookiecutter_json('cookiecutter') == False


# Generated at 2022-06-25 15:35:13.329790
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir("test", {}, "C:\\test\\test.zip", False, False, None, None) == ("C:\\test\\test", True)
    assert determine_repo_dir("test", {}, "/test/test.zip", False, False, None, None) == ("/test/test", True)
    assert determine_repo_dir("test", {}, "test.zip", False, False, None, None) == ("test", True)
    assert determine_repo_dir("test", {}, "", False, False, None, None) == ("test", False)

# Generated at 2022-06-25 15:35:23.054442
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Setup
    os.chdir('./cookiecutter')

    # Assert
    assert os.path.isdir('./tests/fake-repo-pre/')
    assert os.path.isfile('./tests/fake-repo-pre/cookiecutter.json')
    assert repository_has_cookiecutter_json('./tests/fake-repo-pre/')

    assert not os.path.isdir('./tests/fake-repo-post/')
    # Cleanup
    os.chdir('../')

# Generated at 2022-06-25 15:35:30.310874
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # global determine_repo_dir

    # Default test path for determine_repo_dir
    # path = os.getcwd() + '/tests/test-url/'
    # if not os.path.exists(path):
    #    os.makedirs(path)
    # template = path + 'cookiecutter-example'

    template = 'https://github.com/jacebrowning/cookiecutter-example'
    abbreviations = {}
    clone_to_dir = 'https://github.com/cookie/'
    checkout = 'master'
    no_input = True
    password = '123'
    directory = None

# Generated at 2022-06-25 15:35:31.386121
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == is_repo_url(False)


# Generated at 2022-06-25 15:35:38.005212
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    try:
        # Test case 0
        template = "~/Code/cookiecutter-pypackage"
        clone_to_dir = "~/Code"
        template_dir, cleanup = determine_repo_dir(
            template,
            {},
            clone_to_dir,
            False,
            False
        )

    except AssertionError as e:
        print("\n" + str(e))
        return 0
    else:
        return 1


# Generated at 2022-06-25 15:35:40.573294
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert True == repository_has_cookiecutter_json("")
    assert False == repository_has_cookiecutter_json("")
    assert False == repository_has_cookiecutter_json("")


# Generated at 2022-06-25 15:35:51.283598
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ''
    abbreviations = {'default': 'gh:audreyr/cookiecutter-pypackage'}
    clone_to_dir = 'fake/path/cookiecutter-django'
    checkout = ''
    no_input = True
    #determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input)
    #determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, '', 'fake/path/cookiecutter-django')
    #determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, '', 'fake/path/cookiecutter-django')
    #determine_repo_dir(template, abbreviations, clone_to_dir

# Generated at 2022-06-25 15:35:59.945555
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template, clone_to_dir, checkout, no_input, password, directory = 'https://github.com/audreyr/cookiecutter-pypackage.git', './', '', False, '', ''
    repo, cleanup = determine_repo_dir(template, {}, clone_to_dir, checkout, no_input, password, directory)
    return repo, cleanup

# Generated at 2022-06-25 15:36:05.923218
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ''
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = ''
    password = ''
    directory = ''
    _, _ = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    pass


# Generated at 2022-06-25 15:36:16.681470
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'repos'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    result = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    # assert result == expected_result
    assert '-master' in result
    assert result[1] is False

# Generated at 2022-06-25 15:36:21.639397
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/Users/kevin/.cookiecutters'
    checkout = ''
    no_input = True
    password = 'c'
    directory = ''
    try:
        var_0 = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory,
        )
    except IOError:
        var_0 = ''



# Generated at 2022-06-25 15:36:22.590579
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True



# Generated at 2022-06-25 15:36:33.121125
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {'gh': 'https://github.com/audreyr/{}.git'}
    clone_to_dir = 'C:\\Users\\jacky\\AppData\\Local\\Temp\\cookiecutter-test_case_1'
    checkout = None
    no_input = True
    password = None
    directory = None
    var_1, var_2 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert var_1 == 'C:\\Users\\jacky\\AppData\\Local\\Temp\\cookiecutter-test_case_1\\cookiecutter-pypackage'


# Generated at 2022-06-25 15:36:34.376420
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-25 15:36:43.436123
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # set up a fake abbreviations
    abbreviations = {'default': 'gh:pytest-dev/cookiecutter-pytest-plugin'}

    # set up some fake parameters
    template = 'default'  # clone_to_dir = None

    # set up a fake os.path
    os.path.isdir = lambda path: True
    repo_dir = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir=None,
        checkout='master',
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir[0] == 'gh:pytest-dev/cookiecutter-pytest-plugin'

# Generated at 2022-06-25 15:36:54.420256
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git',{},'',True,False)
    assert determine_repo_dir('C:\\Users\\praveen.muthu\\AppData\\Roaming\\Python\\Python37\\site-packages\\cookiecutter\\',{},'',True,False)
    assert determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git',{},'',False,True)
    assert determine_repo_dir('C:\\Users\\praveen.muthu\\AppData\\Roaming\\Python\\Python37\\site-packages\\cookiecutter\\',{},'',False,True)

# Generated at 2022-06-25 15:36:59.832463
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert callable(determine_repo_dir)
    abbreviations = {}
    clone_to_dir = 'test_clone_to_dir'
    checkout = 'test_checkout'
    no_input = False
    password = 'test_password'
    directory = 'test_directory'

# Generated at 2022-06-25 15:37:05.844052
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert not is_repo_url(False)



# Generated at 2022-06-25 15:37:16.674705
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'template'
    abbreviations = 'abbreviations'
    clone_to_dir = 'clone_to_dir'
    checkout = 'checkout'
    no_input = 'no_input'
    password = 'password'
    directory = 'directory'

    # Call function
    ret = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    # Check the returned value
    assert ret == (directory, False)

# Generated at 2022-06-25 15:37:25.394424
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'foo'
    abbreviations = {'bar': 'baz'}
    clone_to_dir = '^&*'
    checkout = 'bug_1234'
    no_input = False
    password = 'blah'
    directory = None 
    repodir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repodir == 'foo:baz'
    assert cleanup == False


# Generated at 2022-06-25 15:37:27.360895
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == True

test_case_0()

test_determine_repo_dir()

# Generated at 2022-06-25 15:37:39.020632
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test 1
    template = 'test_test'
    abbreviations = {}
    clone_to_dir = 'test_test'
    checkout = 'test_test'
    no_input = False
    password = 'test_test'
    directory = 'test_test'
    repo_dir = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    
    # Test 2
    template = 'test_test'
    abbreviations = {}
    clone_to_dir = 'test_test'
    checkout = 'test_test'
    no_input = False
    password = 'test_test'
    directory = 'test_test'

# Generated at 2022-06-25 15:37:50.741535
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # when using git clone
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage-audreyr'
    assert determine_repo_dir(str_0) == str_1

    # when using abbreviations
    str_0 = 'cookiecutter-pypackage'
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir(str_0) == str_1

    # if the repo is a zip file
    str_0 = 'cookiecutter-pypackage.zip'

# Generated at 2022-06-25 15:37:54.779411
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ''
    abbreviations = {var_0: var_0}
    clone_to_dir = ''
    checkout = ''
    no_input = test_case_0()
    password = None
    directory = None
    res = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)



# Generated at 2022-06-25 15:38:03.845061
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/home/user/cookiecutter-template'
    checkout = 'develop'
    no_input = False
    password = 'password'
    directory = '{{cookiecutter.repo_name}}'
    output = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert output


# Generated at 2022-06-25 15:38:11.832285
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "~/cookiecutter-django/{{cookiecutter.repo_name}}"
    abbreviations = {'audit-cookiecutter':'https://github.com/cookiecutter/'
                     'audit-cookiecutter.git'}
    clone_to_dir = ''
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout,
                       no_input, password, directory)
    return determine_repo_dir

if __name__ == '__main__':
    # Call function
    test_determine_repo_dir()
    test_case_0()

# Generated at 2022-06-25 15:38:17.774565
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Simple tests
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/cookiecutter-djangopackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://bitbucket.org/pokoli/cookiecutter-djangopackage')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
   

# Generated at 2022-06-25 15:38:31.965281
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations = {'gh:': 'https://github.com/{}.git'}
    clone_to_dir = 'c:/Users/yuxi/Desktop/cookiecutter-pypackage'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    output = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    print('output:')
    print(output)


# Generated at 2022-06-25 15:38:34.628120
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert (determine_repo_dir("template", {}, "clone_to_dir", "checkout", True, "password", "directory")) == ("template", False)


# Generated at 2022-06-25 15:38:39.864253
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git',
                     'bb': 'https://bitbucket.org/{}.git',
                     }
    clone_to_dir = '/tmp/cookiecutter-test'
    checkout = 'master'
    no_input = False
    password = 'bar'
    directory = None

    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir,
                                            checkout, no_input, password, directory)

    assert repo_dir and cleanup == False


# Generated at 2022-06-25 15:38:47.413059
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Must pass in a string
    with pytest.raises(TypeError) as excinfo:
        _, _ = determine_repo_dir(True)
    assert 'must be a string' in str(excinfo.value)

    # Must be a valid repo
    with pytest.raises(RepositoryNotFound) as excinfo:
        _, _ = determine_repo_dir('%')
    assert 'A valid repository for "%" could not be found' in str(excinfo.value)



# Generated at 2022-06-25 15:38:52.719351
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = (
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    abbreviations = {}
    clone_to_dir = 'foo'
    checkout = ''
    no_input = False
    password = None
    directory = None
    var_1 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-25 15:38:55.835318
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template_0 = "/"
    var_0 = determine_repo_dir(template_0)

    assert var_0 == False

if __name__ == "__main__":
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:39:00.351045
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(test_case_0(),
                              None,
                              None,
                              None,
                              None,
                              None,
                              None) == test_case_0()

# Generated at 2022-06-25 15:39:06.925192
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = None
    abbreviations = None
    clone_to_dir = None
    checkout = None
    no_input = False
    password = None
    directory = None
    # var_0: `repo_dir`
    # var_1: `should_cleanup`
    var_0, var_1 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )
    # Print
    print(var_0, var_1)

# Generated at 2022-06-25 15:39:14.246710
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'test_template'
    abbreviations = {}
    clone_to_dir = 'test_clone_to_dir'
    checkout = 'test_checkout'
    no_input = True
    password = None
    directory = 'test_directory'
    repository, _ = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert not(repository == None)


# Generated at 2022-06-25 15:39:21.397921
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    abbreviations = {'gh': 'https://github.com/{}.git'}

    clone_to_dir = 'C:\\python36\\Lib\\site-packages\\cookiecutter\\_abc.py'

    checkout = 'master'

    no_input = True

    password = None

    directory = 'cookiecutter-pypackage'

    directory, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    assert directory is not None

    if directory:
        print('Test success')



# Generated at 2022-06-25 15:39:41.009373
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = None
    abbreviations = None
    clone_to_dir = None
    checkout = None
    no_input = True
    password = None
    directory = None
    try:
        repo_dir, cleanup = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory,
        )
        print(repo_dir)
        print(cleanup)
    except Exception as e:
        print(str(e))



# Generated at 2022-06-25 15:39:50.879499
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {
        'pypi': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'gh': 'https://github.com/{}.git',
        'bitbucket': 'https://bitbucket.org/{}',
    }
    clone_to_dir = '/home/audreyr/cookiecutters'
    checkout = 'master'
    no_input = False
    password = '12345'
    directory = 'tests'

# Generated at 2022-06-25 15:39:58.697174
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'test/test_gen_proj'
    checkout = 'master'
    no_input = False
    password = 'test'
    directory = None

    cookiecutter_template_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    print(cookiecutter_template_dir)
    print(cleanup)

# Generated at 2022-06-25 15:40:03.125491
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'test'
    abbreviations = dict()
    clone_to_dir = 'test'
    checkout = 'test'
    no_input = False
    password = None
    directory = None
    ret = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)


# Generated at 2022-06-25 15:40:09.042305
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        determine_repo_dir('https://github.com/pydanny/cookiecutter-django.git', {}, '/tmp', 'master', True)
    except RepositoryNotFound:
        pass


# Generated at 2022-06-25 15:40:14.561800
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    expected_0 = "/tmp/tests/fakerepo/foo"
    expected_1 = False
    actual_0, actual_1 = determine_repo_dir(
        template="/tmp/tests/fakerepo/foo",
        abbreviations={},
        clone_to_dir="/tmp/tests/fake-repo-tmpl",
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert actual_0 == expected_0
    assert actual_1 == expected_1
    

# Generated at 2022-06-25 15:40:22.698419
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = ''
    no_input = True
    password = None
    directory = None
    var_0, var_1 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print(var_0)
    print(var_1)


# Generated at 2022-06-25 15:40:30.147853
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = dict()
    abbreviations['git+git@github.com:jhermann/cookiecutter-pyramid.git'] = 'git@github.com:jhermann/cookiecutter-pyramid.git'
    assert abbreviations['git+git@github.com:jhermann/cookiecutter-pyramid.git'] == 'git@github.com:jhermann/cookiecutter-pyramid.git'

    abbreviations['git'] = 'git@'
    assert abbreviations['git'] == 'git@'

    abbreviations['file'] = 'file://localhost/'
    assert abbreviations['file'] == 'file://localhost/'

    abbreviations['hg'] = 'hg+https://'
    assert abbreviations['hg'] == 'hg+https://'


# Generated at 2022-06-25 15:40:38.920702
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    log_file_name = 'cookiecutter.log'
    if os.path.exists(log_file_name):
        log_file = open(log_file_name, 'a')
    else:
        log_file = open(log_file_name, 'w')

    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    abbreviations = ''
    clone_to_dir = ''
    checkout = ''
    no_input = ''
    password = ''
    directory = ''
    cookie_template, cleanup = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )

    log_file.write('cookie_template: ' + str(cookie_template) + '\n')
    log

# Generated at 2022-06-25 15:40:49.160970
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ""
    abbreviations = ""
    clone_to_dir = ""
    checkout = ""
    no_input = ""
    password = ""
    directory = ""

# Generated at 2022-06-25 15:41:27.349665
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'http://example.com/repo/foo.zip'

# Generated at 2022-06-25 15:41:36.333970
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'git@github.com:myrepo/mytemplate.git' 
    abbreviations = {'mytempl': 'git@github.com:myrepo/mytemplate.git'}
    clone_to_dir = '~/mytemplates'
    checkout = 'develop' 
    no_input = False
    password = 'password'
    directory = 'mytemplatedir'
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print(repo_dir, cleanup)
#if __name__ == '__main__':
#    test_determine_repo_dir()

# Generated at 2022-06-25 15:41:42.090769
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_2 = 'http://example.com/'
    template = is_repo_url(var_2)
    var_3 = dict()
    abbreviations = expand_abbreviations(template, var_3)
    var_4 = './'
    clone_to_dir = clone(abbreviations, var_4)
    var_5 = 'master'
    checkout = clone(abbreviations, var_5)
    var_6 = True
    no_input = no_input(abbreviations, var_6)
    var_7 = \
''
    password = password(abbreviations, var_7)
    var_8 = \
''
    directory = directory(abbreviations, var_8)

# Generated at 2022-06-25 15:41:49.909617
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/path/to/cookiecutters'
    checkout = ''
    no_input = False
    password = None
    directory = None
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    test_case_0()

if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-25 15:41:59.055081
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    directory = './tests/fake-repo-tmpl/'
    template = directory
    abbreviations = {
        'gh': 'https://github.com/{}.git',
    }
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None

    dir_0, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
    )

    assert dir_0 == directory
    assert cleanup

    template = 'gh:audreyr-cookiecutter-pypackage'

# Generated at 2022-06-25 15:42:07.174153
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/Users/Audrey/projects/cookiecutter-django/tests/true-repo-tmpl'
    checkout = 'master'
    no_input = True
    directory = None
    result = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, directory)

# Generated at 2022-06-25 15:42:18.609286
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print('Inside the test_determine_repo_dir Function\n')
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'test_value'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    out_var_0 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    print('out_var_0:')
    print(out_var_0)

if __name__ == '__main__':
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:42:26.189243
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    repo_dir, clone_to_dir, abbreviations = None, None, None
    checkout, no_input, password, directory = None, None, None, None

    try:
        repo_dir, cleanup = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory,
        )
    except RepositoryNotFound as e:
        raise e

    return repo_dir

# Generated at 2022-06-25 15:42:33.630271
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # /home/user/Downloads/temp/a/cookiecutter.json
    # /home/user/Downloads/temp/b/cookiecutter.json
    git_url = 'file:/home/user/Downloads/temp/b'
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = ''
    password = 'testing123'
    directory = ''
    var_0 = determine_repo_dir(
        git_url,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

if __name__ == '__main__':
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:42:35.539369
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("Test for determine_repo_dir")
    # Test case # 0
    test_case_0()

test_determine_repo_dir()