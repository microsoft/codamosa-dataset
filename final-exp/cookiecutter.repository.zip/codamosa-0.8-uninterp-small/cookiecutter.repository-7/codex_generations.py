

# Generated at 2022-06-25 15:33:12.261380
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Initialize the dictionary of abbreviations.
    abbreviations = {}
    abbreviations['gh'] = 'https://github.com/{}.git'
    abbreviations['bb'] = 'https://bitbucket.org/{}.git'
    abbreviations['dd'] = 'https://bitbucket.org/{}.git'
    abbreviations['gl'] = 'https://gitlab.com/{}.git'
    abbreviations['tb'] = 'https://gitlab.com/{}.git'

    # Create a temporary directory for cloning into.
    import tempfile
    clone_to_dir = tempfile.mkdtemp()
    assert isinstance(clone_to_dir, str)

    # Clone the URL into the temporary directory.

# Generated at 2022-06-25 15:33:18.198294
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'D:/project/app/app/templates'
    abbreviations = None
    clone_to_dir = '/abbreviation'
    checkout = 'master'
    no_input = False
    password = None
    directory = 'project'
    res = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print(res)


if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-25 15:33:26.717607
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'C:\\Users\\admin\\AppData\\Local\\Temp\\sc_nj_dl_'
    checkout = None
    no_input = False
    password = ''
    directory = ''
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir,
                                           checkout, no_input, password, directory)
    assert repo_dir is not None
    assert cleanup is False
    assert repo_dir[-5:] == '.git'

# Generated at 2022-06-25 15:33:32.379876
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}'}
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://github.com/audreyr/cookiecutter-pypackage'



# Generated at 2022-06-25 15:33:35.203710
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {"full": "foo/bar"}
    assert expand_abbreviations("full:baz", abbreviations) == "foo/bar:baz"



# Generated at 2022-06-25 15:33:43.589578
# Unit test for function expand_abbreviations

# Generated at 2022-06-25 15:33:53.315671
# Unit test for function determine_repo_dir

# Generated at 2022-06-25 15:34:04.055199
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = 'nmUu\x0c\n'
    str_1 = 'nmUu\x0c\n'
    str_2 = 'nmUu\x0c\n'
    str_3 = 'nmUu\x0c\n'
    str_4 = 'nmUu\x0c\n'
    str_5 = 'nmUu\x0c\n'
    str_6 = 'nmUu\x0c\n'
    str_7 = 'nmUu\x0c\n'
    str_8 = 'nmUu\x0c\n'
    str_9 = 'nmUu\x0c\n'
    str_10 = 'nmUu\x0c\n'

# Generated at 2022-06-25 15:34:18.949776
# Unit test for function expand_abbreviations

# Generated at 2022-06-25 15:34:25.455873
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "eggs"
    abbreviations = '{}'
    clone_to_dir = None
    checkout = "spam"
    no_input = False
    password = "foobar"
    directory = None
    res = determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input,password,directory)

'''
if __name__ == "__main__":

    test_determine_repo_dir()
    test_case_0()
'''

assert(repository_has_cookiecutter_json("nmUu\x0c\n") == False)
assert(determine_repo_dir("eggs", '{}', None, "spam", False, "foobar", None) == False)

# Generated at 2022-06-25 15:34:37.206805
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/Users/cj/dropbox/projects/python/costa'
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-25 15:34:45.358359
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_case_0()
    test_20_input=''
    test_20_input=test_20_input.replace("\n", "")
    test_21_input=''
    test_21_input=test_21_input.replace("\n", "")
    test_22_input=''
    test_22_input=test_22_input.replace("\n", "")
    test_23_input=''
    test_23_input=test_23_input.replace("\n", "")
    test_24_input=''
    test_24_input=test_24_input.replace("\n", "")
    test_25_input=''
    test_25_input=test_25_input.replace("\n", "")
    test_26_input=''
    test

# Generated at 2022-06-25 15:34:47.686055
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Assertions
    print("Test:determine_repo_dir")
    assert 1==1, "Assertions broken"


# Generated at 2022-06-25 15:34:48.875301
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == True
    return 0


test_determine_repo_dir()

# Generated at 2022-06-25 15:34:49.940353
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = {}

    assert determine_repo_dir(var_0) == ""

# Generated at 2022-06-25 15:34:52.899004
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir("https://github.com/audreyr/cookiecutter-pypackage.git",{"cookiecutter-pypackage":"https://github.com/audreyr/cookiecutter-pypackage.git"},var_0,"","","") == (template, False)

# Generated at 2022-06-25 15:35:01.168540
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print('Testing for determine_repo_dir function.')

    template = ""
    abbreviations = {}
    clone_to_dir = ""
    checkout = ""
    no_input = ""
    password = ""
    directory = ""

    try:
        determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory,
        )
    except RepositoryNotFound as e:
        print(e)

    try:
        assert determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory,
        )
    except AssertionError as e:
        print(e)

    determine_repo_dir

# Generated at 2022-06-25 15:35:11.231466
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert is_zip_file("C:\\Users\\a\\Desktop\\1.zip") is True
    assert is_zip_file("C:\\Users\\a\\Desktop\\1") is False
    assert is_repo_url("C:\\Users\\a\\Desktop\\1") is False
    assert is_repo_url("C:\\Users\\a\\Desktop\\1.git") is False
    assert is_repo_url("C:/Users/a/Desktop/1.git") is True


# Generated at 2022-06-25 15:35:16.272395
# Unit test for function determine_repo_dir

# Generated at 2022-06-25 15:35:24.240102
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    '''Asserts that the correct value is returned for determine_repo_dir()'''
    template = 'cookiecutter-pypackage'
    abbreviations = {}
    clone_to_dir = '~'
    checkout = '~'
    no_input = '~'
    password = '~'
    directory = '~'
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout,
                              no_input, password, directory) == (
                                  'cookiecutter-pypackage', False)

# Generated at 2022-06-25 15:35:32.414934
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = "/tmp"
    checkout = "master"
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert repo_dir == "/tmp/cookiecutter-pypackage"


# Generated at 2022-06-25 15:35:40.299548
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}',
    }
    print(determine_repo_dir(
        'gh:audreyr/cookiecutter-pypackage',
        abbreviations,
        clone_to_dir='.',
        checkout='master',
        no_input=False,
        password='',
        directory=None
    ))
    # assert 'gh:audreyr/cookiecutter-pypackage' == 'gh:audreyr/cookiecutter-pypackage'


# Generated at 2022-06-25 15:35:47.622941
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ""
    abbreviations = {}
    clone_to_dir = ""
    checkout = ""
    no_input = True
    password = ""
    directory = ""
    repository_dir, cleanup = determine_repo_dir(template, abbreviations,
                                                 clone_to_dir, checkout,
                                                 no_input, password,
                                                 directory)
    assert type(repository_dir) == str
    assert type(cleanup) == bool

# Generated at 2022-06-25 15:35:52.853529
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test the function returns the right output in the right cases
    # See https://help.semmle.com/wiki/display/PYTHON/Finding+bugs+in+Python+code+with+QL+libraries
    from Cookiecutter._repository_info import REPO_REGEX
    abbrev = {'abbrev': 'abbrev_value'}
    template = 'abbrev'
    repo_url = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    clone_to_dir = 'test_clone_to_dir'
    checkout = 'master'
    no_input = True
    password = None
    directory = 'test_directory'
    assert template == 'abbrev'
    # assert abbrev_value == 'abbrev_value'


# Generated at 2022-06-25 15:35:53.344517
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-25 15:35:57.807789
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test_case_0()
    print("Test #0 (no input) - Passed!")



if __name__ == "__main__":
    test_determine_repo_dir()

# Generated at 2022-06-25 15:35:58.763202
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_case_0()


# Generated at 2022-06-25 15:36:05.702568
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert 1 == 1
    # assert determine_repo_dir() == "project_name/{{cookiecutter.repo_name}}"
    # assert determine_repo_dir() == ""
    # assert determine_repo_dir() == "https://github.com/pydanny/cookiecutter-django-crud.git"
    # assert determine_repo_dir() == "{{cookiecutter.repo_name}}"


# Generated at 2022-06-25 15:36:17.965814
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'C:\\Users\\jiey6\\Desktop\\cookie_temp\\cookiecutter-pytest\\tests\\test_generate.py'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print(repo_dir)
    print(cleanup)

if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-25 15:36:22.357400
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    determine_repo_dir(test_case_0(),test_case_0,test_case_0)

test_determine_repo_dir()

# Generated at 2022-06-25 15:36:33.214836
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "../../home/nonexistent/.local/share/cookiecutters/cookiecutter-example"
    abbreviations = {
        "gh": "https://github.com/",
        "bb": "https://bitbucket.org/",
    }
    clone_to_dir = "../../.cookiecutters/"
    checkout = None
    no_input = True
    password = "None"
    directory = "folder"

    determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

# Generated at 2022-06-25 15:36:43.839562
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}/{}.git',
        'ghu': 'git@github.com:{}.git',
    }
    clone_to_dir = '.nest/cookiecutters'
    checkout = 'master'
    no_input = True
    password = ''
    template = 'gh:audreyr/cookiecutter-pypackage'
    directory = ''

    repo_dir, cleanup = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )
    expected_repo_dir = os.path.join(clone_to_dir, "audreyr", "cookiecutter-pypackage")
    assert repo_dir == expected_repo_dir

# Generated at 2022-06-25 15:36:54.871708
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Input parameters
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/tmp/cookiecutter-ePjKk7'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    
    repository_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    print(repository_dir)
    print(cleanup)
    assert repository_dir == '/tmp/cookiecutter-ePjKk7/cookiecutter-pypackage'
    assert cleanup == False


# Generated at 2022-06-25 15:37:02.264908
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    clone_to_dir = 'D:\\codebase\\github\\cookiecutter-django'
    template = 'D:\\codebase\\github\\cookiecutter-django'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }

    checkout = None
    no_input = False
    password = None
    directory = None

    print('determine_repo_dir()')
    determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory
    )

# Generated at 2022-06-25 15:37:10.439735
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter import repository
    template = 'torvalds/linux'
    abbreviations = {}
    clone_to_dir = ''
    checkout = 'master'
    no_input = False
    expectedOutput = ('', True)
    actualOutput = repository.determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input)
    assert actualOutput == expectedOutput
    template = '/tmp'
    abbreviations = {}
    clone_to_dir = ''
    checkout = 'master'
    no_input = False
    expectedOutput = ('', True)
    actualOutput = repository.determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input)
    assert actualOutput == expectedOutput


# Generated at 2022-06-25 15:37:15.940519
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ''
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    var_0 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-25 15:37:24.339586
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'git@github.com:Me/my-repo'
    abbreviations = dict()
    clone_to_dir = 'C:\\Windows\\Temp'
    checkout = 'master'
    no_input = True
    password = 'strongpass'
    directory = '.github'

    # Call function
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    print('repo_dir', repo_dir)
    print('cleanup', cleanup)

# Generated at 2022-06-25 15:37:32.407043
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_1 = False
    var_2 = 'Pydev console: starting (pid: 59906).'
    var_3 = {}
    var_4 = 'Pydev console: starting (pid: 59906).'
    var_5 = 'Pydev console: starting (pid: 59906).'
    var_6 = False
    var_7 = 'Pydev console: starting (pid: 59906).'
    var_8 = 'Pydev console: starting (pid: 59906).'
    var_9 = 'Pydev console: starting (pid: 59906).'
    var_10 = 'Pydev console: starting (pid: 59906).'
    var_11 = '\\Github\\cookiecutmst\\exa'

# Generated at 2022-06-25 15:37:41.501325
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = '/Users/ciaran/Projects/cookiecutter/tests/test-repos/'
    abbreviations = {}
    clone_to_dir = '/Users/ciaran/Projects/cookiecutter/tests/test-repos/'
    checkout = None
    no_input = False
    password = None
    directory = None
    (var_0, result) = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

# Generated at 2022-06-25 15:37:51.993071
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = "/home/pip-req-build/sample_dir"
    var_1 = [ var_0 ]
    var_2 = "git+git://git.myproject.org/MyProject.git@"
    var_3 = [
        var_2
    ]
    var_4 = [
        var_0,
        var_2
    ]
    var_5 = "https://github.com/audreyr/cookiecutter-pypackage.git"
    var_6 = [
        var_5
    ]
    var_7 = [
        var_0,
        var_5
    ]
    var_8 = "git@github.com:audreyr/cookiecutter-pypackage.git"
    var_9 = [
        var_8
    ]
   

# Generated at 2022-06-25 15:37:57.712105
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test if repository_has_cookiecutter_json returned True.
    return True

# Generated at 2022-06-25 15:38:07.343906
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Set up test values
    template = "val_0"
    abbreviations = "val_1"
    clone_to_dir = "val_2"
    checkout = "val_3"
    no_input = "val_4"
    password = "val_5"
    directory = "val_6"
    arg_0 = template
    arg_1 = abbreviations
    arg_2 = clone_to_dir
    arg_3 = checkout
    arg_4 = no_input
    arg_5 = password
    arg_6 = directory

    # Call the function
    results = determine_repo_dir(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6)

    # Check for correct result
    assert (results == (False, False))

# Generated at 2022-06-25 15:38:14.183432
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ''
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = False
    password = None
    directory = None
    output_0, output_1 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert output_0 is None and output_1 is None


# Generated at 2022-06-25 15:38:24.642794
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # print("Test case #0")
    result_0 = determine_repo_dir(template=None, abbreviations=None, clone_to_dir=None, checkout=None, no_input=None, password=None, directory=None)
    # if result_0 != None:
    #     print("Test case #0 failed!")
    # else:
    #     print("Test case #0 passed!")

    print("Test case #1")
    result_1 = determine_repo_dir(template=bool, abbreviations=dict, clone_to_dir=str, checkout=None, no_input=False, password=None, directory=None)
    if result_1 != True:
        print("Test case #1 failed!")
    else:
        print("Test case #1 passed!")

test_case_0()


# Generated at 2022-06-25 15:38:32.877952
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Uncomment these lines as you're writing code to test functions
    # from cookiecutter.main import determine_repo_dir
    # from cookiecutter.main import determine_repo_dir

    # Note that these tests only produce output for failed tests.
    # That's intentional to make it easy to get disgnostic info
    # when tests fail.
    # TODO: consider making assertTrue and assertFalse with diagnostics

    # Test 1
    print("Test 1")
    template = 'tests/test-repo-tmpl'
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    abbreviations = {
        'gh': 'https://github.com/{0}.git',
        'bb': 'https://bitbucket.org/{0}',
    }
    directory = None

# Generated at 2022-06-25 15:38:39.690938
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert isinstance(determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage', {'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage'}, 'cookiecutter_determine_repo_dir_8604a052', None, False, None), tuple)

# Generated at 2022-06-25 15:38:48.330959
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/',
        'bb': 'https://bitbucket.org/',
        'ow': 'git@owncloud.org:',
    }
    clone_to_dir = './.mock'
    checkout = 'master'
    no_input = False
    password = None

    assert(determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password))


# Generated at 2022-06-25 15:38:55.144675
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations = {}
    clone_to_dir = None
    checkout = 'replace'
    no_input = None
    password = None
    directory = None
    ret_3, ret_4 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )
    assert ret_3 is None
    assert ret_4 is None



# Generated at 2022-06-25 15:39:02.611043
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "/home/daniel/Code/get_cookiecutter/"
    abbreviations = {}
    clone_to_dir = "/home/daniel/Code/get_cookiecutter/"
    checkout = "master"
    # no_input = "dd"

    repo_dir = determine_repo_dir(template, abbreviations, clone_to_dir, checkout)
    print(repo_dir)
    assert repo_dir == True



# Generated at 2022-06-25 15:39:08.783872
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test for Python <3.4
    if not hasattr(determine_repo_dir, "__annotations__"):
        return

    from cookiecutter.main import determine_repo_dir
    import pytest

    pytest.main(['-qq', '--capture=no'])
    determine_repo_dir(bool_0)


if __name__ == '__main__':
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:39:16.274787
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert callable(determine_repo_dir)



# Generated at 2022-06-25 15:39:21.452648
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Variable declaration
    template = ''
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = True
    password = None
    directory = ''

    # Call function
    repo_dir, cleanup = determine_repo_dir(template, abbreviations,
                                           clone_to_dir, checkout, no_input,
                                           password, directory)

    try:
        assert repo_dir
        assert cleanup
    except AssertionError:
        raise AssertionError("Function 'determine_repo_dir' failed.")



# Generated at 2022-06-25 15:39:31.790957
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Call function with args, kwargs
    args = ()

# Generated at 2022-06-25 15:39:36.916693
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'cookiecutter-pypackage'
    abbreviations = {}
    clone_to_dir = ''
    checkout = 'master'
    no_input = ''
    password = None
    directory = None
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)



# Generated at 2022-06-25 15:39:38.381774
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True

# Generated at 2022-06-25 15:39:43.681873
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/bob/project.git'
    abbreviations = {}
    clone_to_dir = 'test/test_dir'
    checkout = None
    no_input = False
    password = None
    directory = None
    #pytest.set_trace()
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=None,
        directory=None,
    )

    assert cleanup == False
    assert repo_dir == 'test/test_dir/project'

# Generated at 2022-06-25 15:39:46.568002
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert 'something like git:// ssh:// file:// etc.' in REPO_REGEX.pattern
    assert 'something like user@...' in REPO_REGEX.pattern

# Generated at 2022-06-25 15:39:47.507784
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True



# Generated at 2022-06-25 15:39:56.076243
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    abbreviations = ''
    clone_to_dir = ''
    checkout = ''
    no_input = ''
    password = ''
    directory = ''
    var_0 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

if __name__ == "__main__":
    test_determine_repo_dir()

# Generated at 2022-06-25 15:40:05.413026
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    if __name__ == '__main__':
        # Run the example code
        repo_dir, should_be_cleaned_up = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password=password,
            directory=directory,
        )
        print(repo_dir)
        print(should_be_cleaned_up)

    # Test that the directory should not be cleaned up
    assert not should_be_cleaned_up
    # Test that the repo

# Generated at 2022-06-25 15:40:24.866552
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = False
    abbreviations = {}
    clone_to_dir = False
    checkout = False
    no_input = False
    password = None
    directory = 'test_determine_repo_dir'
    result_0 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )


# Generated at 2022-06-25 15:40:25.742027
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass


# Generated at 2022-06-25 15:40:31.337192
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'test/test_output/test-cookiecutter-test-test/'
    clone_to_dir = 'test/test_output/'
    abbreviations = {}
    checkout = None
    cleanup = False
    no_input = False
    password = None
    directory = None

    value = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    pass


# Generated at 2022-06-25 15:40:38.109809
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("  Testing function determine_repo_dir...")
    clone_to_dir = "~/.cookiecutters/"
    checkout = "master"
    no_input = False
    directory = "~/example-false"
    template = ""
    abbreviations = ""
    test_determine_repo_dir_0(clone_to_dir, checkout, no_input, directory, template, abbreviations)
    test_determine_repo_dir_1(clone_to_dir, checkout, no_input, directory, template, abbreviations)



# Generated at 2022-06-25 15:40:41.796159
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 10
    abbreviations = 10
    clone_to_dir = 10
    checkout = 10
    no_input = 10
    password = 10
    directory = 10
    obj = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)


# Generated at 2022-06-25 15:40:51.528297
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    clone_to_dir_0 = 'u /*7G~|XoYi8R'
    directory_0 = '=Mq5r0@5i'
    checkout_0 = 'd(KQ]m?nX'
    abbreviations_0 = 'C5p{EIi`'
    no_input_0 = 'K'
    template_0 = 'cookiecutter/cookiecutter-pypackage'

    check_0 = determine_repo_dir(
        template_0,
        abbreviations_0,
        clone_to_dir_0,
        checkout_0,
        no_input_0,
        password=None,
        directory=directory_0,
    )

    if check_0 is None:
        print('Passed test case 0!')
    else:
        print

# Generated at 2022-06-25 15:40:57.742155
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    tpl = 'https://github.com/xuy/cookiecutter-flask.git'
    repo_dir = determine_repo_dir(tpl, {}, '.', 'master', False)[0]
    assert os.path.exists(repo_dir)


if __name__ == '__main__':
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:41:03.668866
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    url = 'git@git.code.sf.net:p/scummvm/scummvm.git'
    assert determine_repo_dir(url) == (url, '', '')

    url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir(url) == (url, '', '')

    url = 'git@git.myproject.org:MyProject/MyProjectRepo.git'
    assert determine_repo_dir(url) == (url, '', '')

    url = 'hg@bitbucket.org/pypa/sampleproject'
    assert determine_repo_dir(url) == (url, '', '')


# Generated at 2022-06-25 15:41:07.783099
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    template = ''
    repo_candidate, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )


# Generated at 2022-06-25 15:41:12.765590
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ""
    clone_to_dir = ""
    checkout = ""
    no_input = ""
    password = ""
    directory = ""
    abbreviations = {}
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    # assert repo_dir is ""
    # assert cleanup is True

# Generated at 2022-06-25 15:41:53.189142
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}.git', 'bb': 'https://bitbucket.org/{}.git', 'gitee': 'https://gitee.com/{}.git'}
    clone_to_dir = '/Users/dirkbaumann/code/cookiecutter/tests/fixtures/fake-repo-tmpl'
    checkout = None
    no_input = False
    password = None
    directory = None
    template, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    return template, cleanup

# Generated at 2022-06-25 15:42:00.506888
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = "abbreviations"
    clone_to_dir = "."
    checkout = "master"
    no_input = False
    password = "password"
    directory = "tests"
    output = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )
    assert output == ("./tests/audreyr/cookiecutter-pypackage", True)

# unit tests for expand_abbreviations

# Generated at 2022-06-25 15:42:05.078804
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    param_0 = ''
    param_1 = {}
    param_2 = ''
    param_3 = ''
    param_4 = False
    param_5 = ''
    param_6 = ''
    determine_repo_dir(param_0, param_1, param_2, param_3, param_4, param_5,
                       param_6)


# Generated at 2022-06-25 15:42:14.392748
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Get the path to the cookiecutter template directory
    # (it will be a temporary directory)
    git_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    _, cleanup = determine_repo_dir(git_url, {}, '.', 'master', False)

    # Ensure the path returned is a real directory (it should be a
    # temporary directory) and ensure it contains a cookiecutter.json file
    assert os.path.isdir(cleanup)



# Generated at 2022-06-25 15:42:22.045269
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'repo-abc'

    abbreviations = {'abc': 'https://github.com/audreyr/cookiecutter-pypackage.git'}

    clone_to_dir = None

    checkout = 'master'

    no_input = False

    password = None

    directory = None

    # Testing all branches
    try:
        determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    except RepositoryNotFound as e:
        pass


if __name__ == '__main__':
    template = 'repo-abc'

    abbreviations = {'abc': 'https://github.com/audreyr/cookiecutter-pypackage.git'}


# Generated at 2022-06-25 15:42:28.637499
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/zeekayug/cookiecutter.git'
    abbreviations = {
        'myorgs': 'https://github.com/myorg/{}.git',
        'mynames': 'https://github.com/myorg/{}.git',
    }
    clone_to_dir = os.path.dirname(os.path.abspath(__file__))
    checkout = os.path.join(clone_to_dir, 'cookiecutter.json')
    no_input = True
    password = '*'
    directory = ''
    var_1 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-25 15:42:33.490342
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    class_var_0 = RepositoryNotFound
    var_0 = determine_repo_dir(
        'http://github.com/audreyr/cookiecutter-pypackage',
        {'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage.git'},
        'c:\\users\\user\\appdata\\local\\temp',
        None,
        True,
        'xkcd.com',
        'password',
    )


# Generated at 2022-06-25 15:42:34.559270
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test 0
    test_case_0()



# Generated at 2022-06-25 15:42:41.494753
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
# Test cases from: https://www.owasp.org/index.php/XSS_Filter_Evasion_Cheat_Sheet
# Must sign up to searchsploit to get the content of test case 1
#  if it is installed, but can probably do without it.
# Test case 1
    input_0 = """<IMG SRC="javascript:alert('XSS');">"""
    output_0 = determine_repo_dir(input_0)
# Test case 2
    input_1 = """<IMG SRC=javascript:alert('XSS')>"""
    output_1 = determine_repo_dir(input_1)
# Test case 3
    input_2 = """<IMG SRC=JaVaScRiPt:alert('XSS')>"""

# Generated at 2022-06-25 15:42:48.315504
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = 'git:git@github.com:audreyr/cookiecutter-pypackage.git'
    var_1 = {'gh:': 'git@github.com:', 'bb:': 'git@bitbucket.org:'}
    var_2 = 'wc:git:git@github.com:audreyr/cookiecutter-pypackage.git'
    var_3 = 'wc:git:git@github.com:audreyr/cookiecutter-pypackage.git'
    var_4 = 'wc:git:git@github.com:audreyr/cookiecutter-pypackage.git'
    var_5 = False
    var_6 = None
    var_7 = 'cookiecutter.json'
    var_8 = False
    var_