

# Generated at 2022-06-25 15:33:02.866707
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert is_zip_file(
        "https://github.com/jacebrowning/template-python/archive/0.1.0.zip"
    )
    assert is_zip_file(
        "https://github.com/jacebrowning/template-python/archive/0.1.0.zip"
    )
    assert not is_zip_file(
        "https://github.com/jacebrowning/template-python/archive/0.1.0.tar.gz"
    )

    assert not is_repo_url(
        "https://github.com/jacebrowning/template-python/archive/0.1.0.zip"
    )

# Generated at 2022-06-25 15:33:12.621813
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test template and repo_dir combination to make sure
    # each worked properly.
    from tempfile import mkdtemp
    from contextlib import contextmanager

    @contextmanager
    def _test_config_vars(**kwargs):
        """
        Helper function for changing configuration variables,
        restoring them back to their original values after the
        context manager has finished.
        """
        old_values = {}
        for key, val in kwargs.items():
            old_values[key] = getattr(config, key)
            setattr(config, key, val)
        yield
        for key, val in old_values.items():
            setattr(config, key, val)

# Generated at 2022-06-25 15:33:16.961528
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test expand abbreviations."""
    assert expand_abbreviations('{{cookiecutter.repo_name}}',
                                {'cookiecutter-pypackage': 'foo'}) == 'foo'
    assert expand_abbreviations('user/repo',
                                {'user/repo': 'foo'}) == 'foo'

# Generated at 2022-06-25 15:33:18.336853
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    directory = '/home/cookie'
    assert repository_has_cookiecutter_json(directory) == False

# Generated at 2022-06-25 15:33:19.385655
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert not is_zip_file('.zip')

# Generated at 2022-06-25 15:33:20.814318
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == False


# Generated at 2022-06-25 15:33:29.096056
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        str_0 = '\x0bd i6`\t'
        dict_0 = {}
        str_1 = '49:o'
        str_2 = 'REPO_URL'
        str_2 = expand_abbreviations(str_1, dict_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 15:33:39.192075
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    with pytest.raises(RepositoryNotFound) as excinfo:
        determine_repo_dir(
            template = '\x0bd i6`\t .zip',
            abbreviations = {
                'master': 'https://github.com/audreyr/cookiecutter-pypackage.git',
            },
            clone_to_dir = 'tests/fake-repo-tmpl',
            checkout = None,
            no_input = False,
            password = None,
            directory = None
        )
    assert 'A valid repository for "\x0bd i6`\t .zip" could not be found in the following locations:' in str(excinfo.value)
    assert 'tests/fake-repo-tmpl\\\x0bd i6`\t .zip' in str(excinfo.value)

# Generated at 2022-06-25 15:33:46.509441
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        str_0 = '\x0bd i6`\t .zip'
        var_0 = is_zip_file(str_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 15:33:58.184643
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    clone_to_dir = '/git/cookiecutter-pypackage'
    template_path = '/git/cookiecutter-pypackage/fL8WZp'
    abbreviation_dict = {
        'foo': 'juXq3',
        'bar': 'nY5bw',
    }
    clone_to_dir = '/git/cookiecutter-pypackage'
    checkout = 'master'
    no_input = False
    password = 'Ii7b1'
    directory = '/U4p6O'

# Generated at 2022-06-25 15:34:05.314695
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert 'my_abbreviation_0' == expand_abbreviations('my_abbreviation_0', {'my_abbreviation_0':'expanded_abbreviation_0'})
    assert 'expanded_abbreviation_0' == expand_abbreviations('my_abbreviation_0', {'my_abbreviation_0':'expanded_abbreviation_0'})


# Generated at 2022-06-25 15:34:11.751227
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Create a object representing the local file system in which we will
    # search for the cookiecutter.json file.
    from fs.osfs import OSFS
    from fs.opener import open_fs
    from fs.path import normpath

    from tempfile import mkdtemp
    from shutil import rmtree
    from textwrap import dedent

    from git import Repo
    from os import chdir, getcwd, path
    from zipfile import ZipFile

    from subprocess import run

    # Initialize list of possible abbreviations
    abbreviations = {
        'ct': 'https://github.com/{}/cookiecutter-template',
        'gh': 'https://github.com/{}',
    }

    # Set some defaults
    directory = 'root'
    clone_to_dir = '.'
    template

# Generated at 2022-06-25 15:34:12.531735
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert callable(determine_repo_dir)

# Generated at 2022-06-25 15:34:21.087695
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('git://github.com/audreyr/cookiecutter-pypackage.git', None, '', '', False, None) == \
           ('', True)
    assert determine_repo_dir_2('/home/dafydd/workspace/cookiecutter', None, '', '', False) == \
           ('/home/dafydd/workspace/cookiecutter', False)
    assert determine_repo_dir_3('/home/dafydd/workspace/cookiecutter', None, '', '', True, '', 'cookiecutter.json') == \
           ('/home/dafydd/workspace/cookiecutter/cookiecutter.json', False)



# Generated at 2022-06-25 15:34:31.438513
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations_0 = {
        'full': 'https://github.com/{}',
        'user': 'https://github.com/audreyr/{}',
        'gh': 'https://github.com/{}',
        'ghuser': 'https://github.com/audreyr/{}',
        'bit': 'https://bitbucket.org/{}',
        'bb': 'https://bitbucket.org/{}',
        'bbuser': 'https://bitbucket.org/audreyr/{}',
    }
    int_0 = None

# Generated at 2022-06-25 15:34:38.477347
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        source_dir = 'tests/test-repo/'
        abbreviations = {'gh': 'https://github.com/{}.git'}
        template = 'tests/test-repo'
        expected_dir = 'tests/test-repo/'
        clone_to_dir = 'tests/'
        repo_dir, cleanup = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            None,
            False,
            None,
            None,
        )
        if expected_dir != repo_dir:
            raise Exception(
                'determine_repo_dir returned incorrect result: {}. Expected: {}.'.format(
                    repo_dir, expected_dir
                )
            )
    except Exception as e:
        print(e)


# Generated at 2022-06-25 15:34:46.032540
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}

    result = expand_abbreviations('example', abbreviations)
    assert result == 'example'

    result = expand_abbreviations('p-k/example', abbreviations)
    assert result == 'p-k/example'

    result = expand_abbreviations('gh:example', abbreviations)
    assert result == 'https://github.com/example.git'

    result = expand_abbreviations('gh:example/foo/bar', abbreviations)
    assert result == 'https://github.com/example/foo/bar.git'

    result = expand_abbreviations('gh:example:foo/bar', abbreviations)
    assert result == 'https://github.com/example:foo/bar.git'

    result = expand

# Generated at 2022-06-25 15:34:46.632001
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 15:34:53.454523
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(template='https://github.com/audreyr/cookiecutter-pypackage.git', abbreviations={'gh:': 'https://github.com/{}.git'}) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations={'gh:': 'https://github.com/{}.git'}) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-25 15:35:01.367765
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("\nBegin test_determine_repo_dir")
    # test with good repository
    #template = 'https://github.com/matthewwithanm/cookiecutter-pypackage'
    template = os.path.join('tests', 'fake-repo-tmpl')
    abbreviations = None
    clone_to_dir = None
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, is_cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    print("repo_dir: ", repo_dir)
    assert(repo_dir == template)

# Generated at 2022-06-25 15:35:11.692925
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 's0fT'
    abbreviations = {'w': '1', 'n': 's', 'e': 'a', 'v': 's'}
    clone_to_dir = 'p'
    checkout = 'd'
    no_input = False
    password = 'r'
    directory = 'E'
    catalog = [template, abbreviations, clone_to_dir, checkout, no_input, password,
               directory]
    for item in catalog:
        determine_repo_dir(item, *catalog)


# Generated at 2022-06-25 15:35:19.797567
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    repo_dir = "C:\\Users\\ragha\\Desktop\\Plant\\cookiecutter-batch-processing"
    cur_dir = os.getcwd()
    template = os.path.join(cur_dir, 'Plant')
    assert (determine_repo_dir(template, None, repo_dir, None, False, None, None) ==
            (repo_dir, False))


# Generated at 2022-06-25 15:35:29.459953
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("\nTest 1: URL")
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = "/home/audreyr/clone_to_dir"
    checkout = None
    no_input = False
    password = None
    directory = None
    expected_result_1 = \
        "/home/audreyr/clone_to_dir/cookiecutter-pypackage", False
    determined_result_1 = determine_repo_dir(template, abbreviations,
                                             clone_to_dir, checkout,
                                             no_input, password, directory)
    print("Expected: {}".format(expected_result_1))

# Generated at 2022-06-25 15:35:35.189702
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Create a dummy cookiecutter.json file
    with open('cookiecutter.json', 'w') as f:
        f.write('')

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    repo_dir, _ = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )


# Generated at 2022-06-25 15:35:37.966275
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/home/travis/build/audreyr/cookiecutter") == int(0)
    print("Test successfully completed")

# Generated at 2022-06-25 15:35:43.495948
# Unit test for function determine_repo_dir

# Generated at 2022-06-25 15:35:53.275773
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Reading input from file in.txt
    with open('in.txt', 'r') as f_input:
        for line in f_input:
            input_array = line.split()
            first_var = input_array[0]
        # Calling determine_repo_dir function and storing its output in variable chk
            chk = determine_repo_dir(first_var)
    # Outputting the value of chk
    print(chk)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:35:58.841809
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # noinspection PyProtectedMember
    assert determine_repo_dir(
        template=None,
        abbreviations=None,
        clone_to_dir=None,
        checkout=None,
        no_input=None,
        password=None,
        directory=None,
    )


# Generated at 2022-06-25 15:35:59.364225
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-25 15:36:04.235738
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    repository_candidates = ['/home/Projects/cookiecutter-pypackage']
    repo_candidate = repository_candidates[0]
    res = repository_has_cookiecutter_json(repo_candidate)

# Generated at 2022-06-25 15:36:09.395309
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir(test_repo, {}, '.', 'master', 'True') == \
        ('cookiecutter-pypackage', False)

# Generated at 2022-06-25 15:36:14.377300
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    int_0 = 'cookiecutter-pypackage2'
    assert repository_has_cookiecutter_json(int_0) == True

    int_1 = 'cookiecutter-pypackage'
    assert repository_has_cookiecutter_json(int_1) == False


# Generated at 2022-06-25 15:36:17.033472
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('/home/') == False
    assert repository_has_cookiecutter_json('/home/alex/code/python/cookiecutter-demo') == True


# Generated at 2022-06-25 15:36:19.007721
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(u"A:\\Dev\\cookiecutter-pylibrary\\tests\\fake-repo-pre/") == True

# Generated at 2022-06-25 15:36:21.208521
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory_1 = "/home/homeassistant/.homeassistant"
    # Check if repo_directory is a valid repository
    assert repository_has_cookiecutter_json(repo_directory_1) == False



# Generated at 2022-06-25 15:36:29.379801
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    cache_dir = '~/test/cookiecutter_test/test_determine_repo_dir'
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    _, cleanup = determine_repo_dir(template, {}, cache_dir, 'master', False)

    # cleanup the directory if any
    if cleanup:
        import shutil

        shutil.rmtree(cache_dir)


test_case_0()
test_determine_repo_dir()

# Generated at 2022-06-25 15:36:31.412520
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter.main import cookiecutter
    repo_directory = cookiecutter('.', '.')
    assert(repository_has_cookiecutter_json(repo_directory))
    assert(not repository_has_cookiecutter_json('.'))


# Generated at 2022-06-25 15:36:38.731727
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/Users/test/test'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    out = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert out[0] == '/Users/test/test/cookiecutter-pypackage/'
    assert out[1] == False

# Generated at 2022-06-25 15:36:42.199168
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = None
    var_0 = determine_repo_dir(int_0, int_0, int_0, int_0, int_0, int_0, int_0)
    return var_0


# Generated at 2022-06-25 15:36:44.154827
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    determine_repo_dir()
if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-25 15:36:51.879530
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "abc.zip"
    abbreviations = {'abc': 1}
    clone_to_dir = "/home/juser/projects"
    checkout = None
    no_input = True
    password = None
    directory = None
    assert determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    ) == (template, True)

# Generated at 2022-06-25 15:36:56.172481
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    for i in range(0, 2):
        try:
            test_case_0()
        except TypeError as e:
            print(e)
        except RepositoryNotFound as e:
            print(e)
        except Exception as e:
            print(e)

# Generated at 2022-06-25 15:37:08.186411
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test case 0
    try:
        int_0 = None
        template = int_0
        abbreviations = {}
        clone_to_dir = os.getcwd()
        checkout = 'master'
        no_input = False
        password = None
        directory = None
        output_0, cleanup = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory,
        )
        output_0 = str(output_0)

        assert False
    except RepositoryNotFound:
        pass


# Generated at 2022-06-25 15:37:18.714914
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """ Function to test determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=None,
        directory=None,
        )

    A function to test the determine_repo_dir function from the
    repository module.

    Parameters
    ----------
    param1 : string
        The project_template directory.
    param2 : string
        The abbreviation of the repos directory.
    param3 : string
        The clone_to_dir directory.
    param4 : string
        The checkout directory.
    param5 : string
        The no_input value.
    param6 : str
        The password value.
    param7 : str
        The directory value.
    Returns
    -------
    str
        The cookiecutter template directory

    """

# Generated at 2022-06-25 15:37:22.123898
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = None
    var_0 = determine_repo_dir(int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 15:37:31.275246
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {
        "audrey": "https://github.com/audreyr",
        "cookiecutter-pypackage": "audrey/cookiecutter-pypackage",
    }
    clone_to_dir = "/home/badassbob/code/cookiecutter-somedjangopackage"
    checkout = "0.9.0"
    no_input = False
    password = None
    directory = "{{cookiecutter.repo_name}}/{{cookiecutter.year}}/"

# Generated at 2022-06-25 15:37:36.244395
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert (is_repo_url(determine_repo_dir(abbreviations=None, template=None, checkout="master", clone_to_dir="dummy", no_input=False, password=None, directory=None)[0]))
    return


# Generated at 2022-06-25 15:37:40.085170
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = None
    abbreviations = None
    clone_to_dir = None
    checkout = None
    no_input = None
    password = None
    directory = None
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory) == (None, None)


# Generated at 2022-06-25 15:37:51.136908
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Initialize the class variables
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-tmpl'
    checkout = 'master'
    no_input = False

    # Patch the functions
    (determine_repo_dir.__globals__[
        'is_repo_url']
     ) = test_case_0

    # Run the test function
    template = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    directory = None

    test = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        directory=directory
    )

    # Ensure the results are correct

# Generated at 2022-06-25 15:37:57.937167
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    directory = None
    no_input = False
    clone_to_dir = "./"
    checkout = 'master'

    template = "./"

    # 1. Assert expected return behavior
    assert determine_repo_dir(template,\
                               abbreviations,\
                               clone_to_dir,\
                               checkout,\
                               no_input,\
                               directory) == ('./', False)

    # 2. Assert expected return behavior
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"


# Generated at 2022-06-25 15:38:05.272935
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git', {}, '', '', '') == ('https://github.com/audreyr/cookiecutter-pypackage.git', False)
    assert determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git', {}, '', '', '', '', 'cookiecutter.json') == ('https://github.com/audreyr/cookiecutter-pypackage.git', False)


# Generated at 2022-06-25 15:38:08.358507
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Error:
    try:
        determine_repo_dir()
    except TypeError:
        print('Expected and caught TypeError')

test_case_0()
test_determine_repo_dir()

# Generated at 2022-06-25 15:38:15.971008
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    input_0 = 'https://github.com/audreyr/cookiecutter-pypackage'
    input_1 = {'audreyr': 'https://github.com/audreyr/{}'}
    input_2 = None
    input_3 = None
    input_4 = False
    input_5 = None
    input_6 = 'LICENSE'
    output = determine_repo_dir(input_0, input_1, input_2, input_3, input_4, input_5, input_6)
    assert output == ('/tmp/LICENSE', False)


# Generated at 2022-06-25 15:38:26.432267
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Setup test variables
    int_0 = None
    str_0 = '2b085e3db1c5ce534d05f3a3db8a8e38c28497f5'
    str_1 = 'https://bitbucket.org/dhellmann/cookiecutter-pypackage.git'
    str_2 = 'D:/Users/user/AppData/Local/Temp/cc_tmp7txxhoy/cookiecutter-pypackage'
    str_3 = 'https://api.github.com/repos/audreyr/cookiecutter-pypackage/zipball/master'

    # Invoke function
    result_0 = determine_repo_dir(int_0, None, str_0, str_1, str_2, None, str_3)

    #

# Generated at 2022-06-25 15:38:29.873832
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert callable(determine_repo_dir)


# Generated at 2022-06-25 15:38:37.213158
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    ret = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )

    assert ret == "cookiecutter-pypackage"

# Generated at 2022-06-25 15:38:48.299425
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    :return: a string representation of the template directory
    :rtype: str
    """
    int_0 = None
    int_1 = 'test'
    int_2 = '/home/vagrant/sync/cookiecutter-pypackage'
    int_3 = 'https://github.com/audreyr/cookiecutter.git'
    int_4 = '/home/vagrant/sync/cookiecutter-pypackage'
    int_4 = '/home/vagrant/sync/cookiecutter-pypackage'
    var_0 = is_repo_url(int_0)
    var_1 = is_repo_url(int_1)
    var_2 = is_repo_url(int_2)

# Generated at 2022-06-25 15:38:52.632849
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(template="a",
                              abbreviations={},
                              clone_to_dir="b",
                              checkout="c",
                              no_input="d",
                              password="e",
                              directory="f") == ("g", True)



# Generated at 2022-06-25 15:38:54.128602
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir("test.zip", {}, ".", None, False, None) == (False, True)


# Generated at 2022-06-25 15:39:01.428661
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = None
    abbreviations = {}
    clone_to_dir = None
    checkout = None
    no_input = False
    password = None
    directory = None
    fun_out = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)


if __name__ == '__main__':
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:39:05.640569
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir() == expected



# Generated at 2022-06-25 15:39:10.399415
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    template = "cookiecutter-pypackage" # Repo name
    abbreviations = {'cookiecutter': 'AudreyRoy', } # Repo abbreviation
    clone_to_dir = 'C:/Users/hoang.n/OneDrive - Red River College/Red_River/DevOps/cookiecutter-pypackage' # Clone directory
    checkout = 'master' # Checkout branch
    no_input = True
    password = None
    directory = None

    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)


# Generated at 2022-06-25 15:39:15.624065
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ""
    abbreviations = ""
    clone_to_dir = ""
    checkout = "master"
    no_input = ""
    password = ""
    directory = ""
    (repo_dir, cleanup) = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print("repo_dir: " + repo_dir)
    print("cleanup: " + str(cleanup))

    template = "https://github.com/audreyr/cookiecutter-pypackage"
    abbreviations = ""
    clone_to_dir = ""
    checkout = "master"
    no_input = ""
    password = ""
    directory = ""

# Generated at 2022-06-25 15:39:22.282390
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert(determine_repo_dir('https://github.com/user/repo', 'abbreviations', 'clone_to_dir', 'checkout', 'no_input', 'password', 'directory') == ('directory', 'cleanup'))
    assert(determine_repo_dir('http://github.com/user/repo', 'abbreviations', 'clone_to_dir', 'checkout', 'no_input', 'password', 'directory') == ('directory', 'cleanup'))
    assert(determine_repo_dir('ftp://github.com/user/repo', 'abbreviations', 'clone_to_dir', 'checkout', 'no_input', 'password', 'directory') == ('directory', 'cleanup'))

# Generated at 2022-06-25 15:39:32.970660
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # var_0 = repo_directory=None
    # var_1 = abbreviations=None
    # var_2 = clone_to_dir=None
    # var_3 = checkout=None
    # var_4 = no_input=None
    # var_5 = password=None
    # var_6 = directory=None

    # var_0 = template="git@github.com:audreyr/cookiecutter-pypackage.git"
    template = "git@github.com:audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = ""
    checkout = ""
    no_input = "None"

# Generated at 2022-06-25 15:39:41.416658
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("determine repo dir test")
    # Example 1
    template = "test"
    abbreviations = { }
    clone_to_dir = "test"
    checkout = "test"
    no_input = None
    password = "test"
    directory = None
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    # Example 2
    template = "test"
    abbreviations = { }
    clone_to_dir = "test"
    checkout = "test"
    no_input = None
    password = "test"
    directory = None
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)



# Generated at 2022-06-25 15:39:50.937708
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template='',
        abbreviations=None,
        clone_to_dir=None,
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    ) == (
        '',
        True,
    )
    assert determine_repo_dir(
        template='',
        abbreviations={
            'python': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        },
        clone_to_dir='/var/folders/xy/p4tp4l8d6p19jwxbq0srb74h0000gp/T/tmpf0v_FP',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )

# Generated at 2022-06-25 15:40:00.170232
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Loop through all possible cases and verify
    # if the case passes or fails
    # Ensure that each exception is thrown
    int_0, int_1, int_2, int_3, int_4, int_5, int_6, int_7, int_8, int_9 = None, None, None, None, None, None, None, None, None, None
    try:
        determine_repo_dir(int_0, int_1, int_2, int_3, int_4, int_5, int_6)
    except:
        pass
    try:
        determine_repo_dir(int_0, int_1, int_2, int_3, int_4, int_5, int_6)
    except:
        pass

# Generated at 2022-06-25 15:40:06.870672
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Remove the directory if exist
    if os.path.isdir('/home/rmth/repos/cookiecutter-sphinxdoc'):
        import shutil
        shutil.rmtree('/home/rmth/repos/cookiecutter-sphinxdoc')
    # Test case 0
    var_0 = 'cookiecutter-sphinxdoc'
    var_1 = {}
    var_2 = '/home/rmth/repos'
    var_3 = None
    var_4 = False
    var_5 = None
    var_6 = None
    var_7 = determine_repo_dir(var_0, var_1, var_2, var_3, var_4, var_5, var_6)
    assert type(var_7) == tuple

# Generated at 2022-06-25 15:40:11.385747
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    with pytest.raises(RepositoryNotFound) as exception_info:
        determine_repo_dir(
            template=None,
            abbreviations=None,
            clone_to_dir=None,
            checkout=None,
            no_input=False,
            password=None,
            directory=None,
        )


# Generated at 2022-06-25 15:40:26.111199
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(int_0)
    int_1 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    int_2 = 'cookiecutter-pypackage'
    int_3 = None
    var_0 = determine_repo_dir(int_0, int_1, int_2, int_3, )
    assert var_0 == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    int_4 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(int_4)

# Generated at 2022-06-25 15:40:35.326223
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test function arguments.
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'github': 'https://github.com/{0}', 'bitbucket': 'https://bitbucket.org/{0}'}
    clone_to_dir = '/tmp/cookie/'
    checkout = None
    no_input = False
    password = None
    directory = None
    # Result variable.
    out_0 = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )
    # True if this test should pass.


# Generated at 2022-06-25 15:40:37.565165
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert os.path.isabs(determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git', {}, '.', None, None)[0])

# Generated at 2022-06-25 15:40:39.566375
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('aa:bb:cc',{},None,None,None) == 'aa:bb:cc'

# Generated at 2022-06-25 15:40:46.977222
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Testing for ValueError if the type of input parameter is not right
    with pytest.raises(TypeError):
        determine_repo_dir(123, None, None, None, None)
        determine_repo_dir(None, 123, None, None, None)
        determine_repo_dir(None, None, 123, None, None)
        determine_repo_dir(None, None, None, 123, None)
        determine_repo_dir(None, None, None, None, 123)
    return



# Generated at 2022-06-25 15:40:52.833977
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    results = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage',
        abbreviations=None,
        clone_to_dir='/home/vagrant/cookiecutter-test-repos',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )
    assert results[0].split('cookiecutter-test-repos')[1] == '/cookiecutter-pypackage'
    assert results[1] is False



# Generated at 2022-06-25 15:40:59.811698
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    int_1 = {
        'gh': 'https://github.com/{}/',
        'bb': 'https://bitbucket.org/{}/',
    }
    int_2 = None
    int_3 = None
    int_4 = None
    int_5 = None
    int_6 = None
    int_7 = None
    var_0 = determine_repo_dir(int_0, int_1, int_2, int_3, int_4, int_5, int_6, int_7)
    print(var_0)
    print(type(var_0))



# Generated at 2022-06-25 15:41:08.464334
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    [global_var_0, global_var_1]
    """
    var_0 = 1
    #var_1 = None

    if var_0 == 1:
        var_0 = 1
        var_1 = 1
        var_2 = 1

        int_0 = "https://github.com/audreyr/cookiecutter-pypackage.git"
        var_3 = determine_repo_dir(
            template=int_0,
            abbreviations={},
            clone_to_dir="/home/miyuraj/.cookiecutters",
            checkout=None,
            no_input=True,
            password=None,
            directory=None
        )

        var_4 = var_3[0]
        var_5 = var_3[1]

    # Unit test for function expand

# Generated at 2022-06-25 15:41:14.041192
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    directory = None
    template = '/home/jstrick/.cookiecutters/context-dict'
    abbreviations = {}
    clone_to_dir = '/home/jstrick/dev/'
    checkout = None
    no_input = False
    password = None
    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )
    print('repo_dir =', repo_dir)
    print('cleanup =', cleanup)


# Generated at 2022-06-25 15:41:23.361667
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = "A valid repository for \"{}\" could not be found in the following locations:\n{}"
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {
        "python": "https://github.com/wdm0006/cookiecutter-pipproject.git",
    }
    clone_to_dir = "/home/ted/.cookiecutters"
    checkout = "master"
    no_input = False
    password = None
    directory = "example-repo"

# Generated at 2022-06-25 15:41:42.865440
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/Audhoot/cookiecutter-pypackage-minimal.git'
    abbreviations = {'gh' : 'https://github.com/{}'}
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    int_0 = 'https://github.com/Audhoot/cookiecutter-pypackage-minimal.git'
    var_0 = is_repo_url(int_0)
    var_1 = False
    var_2 = False
    if not var_0:
        if (directory):
            int_1 = os.path.isfile(os.path.join(directory, 'cookiecutter.json'))
            var_2 = os.path.isdir(directory)

# Generated at 2022-06-25 15:41:51.035522
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        assert(is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git"))
        print("passed")
    except Exception as e:
        print(e)

    # test_case_0
    try:
        test_case_0()
        print("passed")
    except Exception as e:
        print(e)

    try:
        assert(is_repo_url(None) == False)
        print("passed")
    except Exception as e:
        print(e)



# Generated at 2022-06-25 15:41:52.367939
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True, determine_repo_dir()


# Generated at 2022-06-25 15:41:54.309770
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir("None", "None", "None", "None") == "None"


# Generated at 2022-06-25 15:42:06.671425
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil

    # Setup
    temp_dir = os.path.join('tests', 'input')
    template_dir = os.path.join(temp_dir, 'fake-repo-tmpl')
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    checkout = 'master'
    no_input = False

    # Test
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = temp_dir
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input
    )

    assert repo_dir
    assert not cleanup

# Generated at 2022-06-25 15:42:18.272373
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    arguments = {
        'template': '',
        'abbreviations': {},
        'clone_to_dir': '',
        'checkout': '',
        'no_input': False,
        'directory': '',
    }
    repo_dir, cleanup = determine_repo_dir(**arguments)
    assert repo_dir == '', '\nExpected: %s\nGot     : %s' % (
        '',
        repo_dir,
    )
    assert cleanup == None, '\nExpected: %s\nGot     : %s' % (
        None,
        cleanup,
    )


# Generated at 2022-06-25 15:42:27.909315
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        template = "../my-cookiecutter-project"
        abbreviations = {
            "gh": "https://github.com/{0}.git",
            "bb": "https://bitbucket.org/{0}",
            "gl": "https://gitlab.com/{0}.git",
        }
        clone_to_dir = "dummy_path"
        checkout = None
        no_input = False
        directory = None
        determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            directory,
        )
    except (RepositoryNotFound, TypeError) as identifier:
        print(identifier)

# Generated at 2022-06-25 15:42:34.570749
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # input variables
    # tuple_0 = (int_0, bool_0)
    template = "https://github.com/audreyr/cookiecutter-pypackage"
    abbreviations = dict
    clone_to_dir = "C:\\Users\\arnol\\AppData\\Local\\Temp\\cookiecutter-zs7i_jwi\\"
    checkout = None
    no_input = False
    password = None
    directory = None

    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
# unit test for is_repo_url

# Generated at 2022-06-25 15:42:35.214413
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print ('No variable for this function')


# Generated at 2022-06-25 15:42:40.954561
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = None
    int_1 = None
    int_2 = None
    int_3 = None
    int_4 = None
    int_5 = None
    int_6 = None
    int_7 = None
    int_8 = None
    int_9 = None
    int_10 = None
    int_11 = None
    int_12 = None
    int_13 = None
    int_14 = None
    int_15 = None
    int_16 = None
    int_17 = None
    int_18 = None
    int_19 = is_repo_url(int_0)
    int_20 = is_repo_url(int_1)
    int_21 = is_repo_url(int_2)
    list_0 = []
    int_22 = is_re