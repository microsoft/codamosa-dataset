

# Generated at 2022-06-25 15:33:05.445818
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir == 'foo/bar'


# Generated at 2022-06-25 15:33:17.979319
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = '[s0R|1b'
    abbreviations = {
    '[s0R|1b': 'dao_fast.git'
    }
    clone_to_dir = '/G$JH'
    checkout = '|7JYOMUCy'
    no_input = True
    password = 'lIwu]x@'
    directory = '1`R'
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    if repo_dir is not None:
        print(f'The repo_dir is {repo_dir}')
    else:
        print(f'The repo_dir is none')
    if cleanup is True:
        print(f'The cleanup is {cleanup}')

# Generated at 2022-06-25 15:33:24.256071
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gae': 'git+git@github.com:lakshmanteja/cookiecutter-gae.git'}
    assert expand_abbreviations('gae:xxx', abbreviations) == 'git+git@github.com:lakshmanteja/cookiecutter-gae.git:xxx'
    assert expand_abbreviations('xxxyyy', abbreviations) == 'xxxyyy'


# Generated at 2022-06-25 15:33:34.114221
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    print("Start Unit test for function expand_abbreviations")
    temp_json = {
        #'gh': u'https://github.com/{}/cookiecutter-{}.git',
        #'bb': u'https://bitbucket.org/{}/cookiecutter-{}',
        'gist': u'https://gist.github.com/{}.git',
        'zip': u'{}'
    }
    print("Test case: Test GitHub")
    template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', temp_json)
    print('The value of template is: {}'.format(template))
    print("Test case: Test Bitbucket")

# Generated at 2022-06-25 15:33:43.137169
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Input parameters
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'default': 'https://github.com/audreyr/cookiecutter-pypackage.git'}
    clone_to_dir = '/tmp/cookiecutter-jD0I4o/audreyr-cookiecutter-pypackage'
    checkout = None
    no_input = False
    password = None
    directory = ''

    # Expected output
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory) == \
    ('/tmp/cookiecutter-jD0I4o/audreyr-cookiecutter-pypackage', False) 



# Generated at 2022-06-25 15:33:52.984903
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = dict()
    abbreviations['https://github.com/audreyr/cookiecutter-pypackage'] = \
        'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations['https://github.com/audreyr/cookiecutter-pypackage.git'] = \
        'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations['git@github.com:audreyr/cookiecutter-pypackage.git'] = \
        'git@github.com:audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-25 15:34:03.754814
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    str_1 = '/home/vagrant/cookiecutter-pypackage'
    str_2 = '/home/vagrant/cookiecutter-pypackage/'
    dictionary_0 = {}

    # with
    #   checkout = 'release/0.4.0'
    #   clone_to_dir = '/home/vagrant/python-package-cookiecutter/'
    #   no_input = False
    #   password = None
    #   template = str_0


# Generated at 2022-06-25 15:34:05.859537
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('github', {'github': 'https://github.com/{}'}) == 'https://github.com/'


# Generated at 2022-06-25 15:34:07.810220
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = determine_repo_dir(template='', 
                               abbreviations={}, 
                               clone_to_dir='', 
                               checkout=None, 
                               no_input=None, 
                               password='', 
                               directory='')
    assert var_0 == (None, False)

# Generated at 2022-06-25 15:34:15.746785
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Setup
    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}'}
    excepted_value = 'https://github.com/audreyr/cookiecutter-pypackage'

    # Execute
    result = expand_abbreviations(template, abbreviations)

    # Check
    assert(result == excepted_value)
    
    

# Generated at 2022-06-25 15:34:24.558638
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    template_name = 'cookiecutter-pypackage'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    # Function call
    repo_dir = determine_repo_dir(
        template_name,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    if repo_dir[0] == repo_url:
        print('Success!')
    else:
        print('Failure')

if __name__ == "__main__":
    test_case_0()
    test_determine_

# Generated at 2022-06-25 15:34:30.505993
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'abbreviations': 'something'}
    clone_to_dir = '/path/to/something'
    template = 'abbreviations'
    checkout = 'master'
    no_input = False

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
    )


# Generated at 2022-06-25 15:34:40.496589
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # Isolated rerun of /home/ben/workspace/cookiecutter/tests/test_main.py::test_determine_repo_dir
    #test_determine_repo_dir()
    
    str_0 = 'vZYhN'
    dict_0 = {
        'vZYhN': 'M',
        'Wuxd': 'vZYhN',
    }
    str_1 = 'vZYhN'
    str_2 = 'vZYhN'
    str_3 = '/home/ben/workspace/cookiecutter/tests/test-data/fake-repo-tmpl'
    tuple_0 = determine_repo_dir(str_0, dict_0, str_1, str_2, True)

# Generated at 2022-06-25 15:34:46.623042
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test case for function determine_repo_dir"""
    template = 'foo'
    abbreviations = 0
    clone_to_dir = 0
    checkout = 0
    password = 'foo'
    var_0 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        True,
        password,
    )
    test_case_0()

test_determine_repo_dir()

# Generated at 2022-06-25 15:34:52.283796
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage'
    str_1 = 'cookiecutter-pypackage'
    dict_0 = {}
    str_2 = 'test'
    str_3 = ''
    bool_0 = True

    tuple_0 = determine_repo_dir(str_0, dict_0, str_2, str_3, bool_0)

    # Test 0
    assert tuple_0[0] == str_1
    assert tuple_0[1] == False


# Generated at 2022-06-25 15:34:58.893501
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Initialize test variables
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/home/user/cookiecutter-tutorial'
    checkout = None
    no_input = False
    password = None
    directory = None

    # Test function
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    


# Generated at 2022-06-25 15:35:13.812284
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_1 = '|\r/%jxM%W'
    str_2 = '|\r/%jxM%W'
    dict_1 = {'|\r/%jxM%W': '|\r/%jxM%W', '|\r/%jxM%W': 'z7V'}
    str_3 = '|\r/%jxM%W'
    str_4 = 'I\nE'
    int_1 = 136
    bool_1 = False
    bool_2 = False
    str_5 = '|\r/%jxM%W'
    str_6 = '|\r/%jxM%W'

# Generated at 2022-06-25 15:35:14.762729
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == False



# Generated at 2022-06-25 15:35:17.045317
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == determine_repo_dir('|\r/%jxM%W', {}, '', '', False)

# Generated at 2022-06-25 15:35:27.727732
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.cli import determine_repo_dir

    url_0 = "http://example.com"
    abbreviations_0 = {}
    clone_to_dir_0 = "/tmp/test"
    checkout_0 = "master"
    no_input_0 = True
    password_0 = None
    directory_0 = None

    try:
        determine_repo_dir(
            url_0,
            abbreviations_0,
            clone_to_dir_0,
            checkout_0,
            no_input_0,
            password_0,
            directory_0,
        )
        assert False, "AssertionError: repo should not exist"
    except RepositoryNotFound:
        pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:35:37.965730
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = '|\r/%jxM%W'
    abbreviations = {'cookiecutter-pypackage': 'gh:audreyr/cookiecutter-pypackage'}
    clone_to_dir = 'yjKL_wkplb'
    checkout = 'qKfQ'
    no_input = True
    password = 12345
    directory = 'cookiecutter-pypackage'
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-25 15:35:49.059510
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from json import load as jsonload

    from .compat import Path
    from .main import SAMPLE_REPO

    str_1 = 'github.com/audreyr/cookiecutter-pypackage'
    str_2 = 'cookiecutter-pypackage'

    str_3 = 'cookiecutter/boilerplate'
    str_4 = 'cookiecutter/boilerplate/cookiecutter.json'

    template_path = str(Path(SAMPLE_REPO).parent / '{{cookiecutter.repo_name}}')

    repo_json_path = Path(SAMPLE_REPO) / 'cookiecutter.json'
    assert repo_json_path.exists()

    with repo_json_path.open() as f:
        repo_dict = jsonload(f)

    repo_dict

# Generated at 2022-06-25 15:36:01.108217
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print('Test determine_repo_dir')
    template = 'some_repo_url'
    abbreviations = {'g': 'git@github.com:{}.git'}
    clone_to_dir = '/some/root/dir'
    checkout = 'some_branch'
    no_input = True
    password = 'some_pwd'
    directory = 'some/sub/dir'
    res = determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input,password,directory)
    print(res)

if __name__ == '__main__':
    test_case_0()
    # test_determine_repo_dir()

# Generated at 2022-06-25 15:36:10.808063
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    list_0 = ['B', '#Ib', '_0,!Z', 'C', '.G', '0r,]', '{yc%', 'g', '+', 'U$}']
    list_1 = ['', '~+9', 'J', '_,7', '$', 'T', 'G', 'r+<', '|', 'J03', '>']
    str_0 = list_0[2]
    list_2 = ['Y7M', 'k', '^6U', '+', 'zA', '1', 'G', '}', 'Wg', 'f*<', 'w']
    tuple_0 = ()
    str_1 = list_1[9]
    str_2 = list_2[4]
    str_3 = list_0[10]
    str

# Generated at 2022-06-25 15:36:18.319521
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'bb': 'https://bitbucket.org/pokoli/cookiecutter-djangopackage',
        'default': 'https://github.com/audreyr/cookiecutter-pypackage.git'
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    repo_dir = determine_repo_dir(template, abbreviations)
    print(repo_dir)



# Generated at 2022-06-25 15:36:26.047924
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'abcd'
    abbreviations = {'abcd': 'abcd'}
    clone_to_dir = '/home/kunal/.cookiecutters'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-25 15:36:36.037878
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    clone_to_dir = ''
    checkout = ''
    no_input = ''
    password = ''

    abbreviations = {'gh:b': 'git+https://github.com/repo/b.git'}
    template = 'gh:b'
    directory = ''
    repo_dir, cleanup = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )
    assert repo_dir == 'git+https://github.com/repo/b.git'

    abbreviations = {'gh:b': 'git+https://github.com/repo/b.git'}
    template = 'gh:b'
    directory = 'name'

# Generated at 2022-06-25 15:36:43.259742
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = dict()
    clone_to_dir = 'test_dir'
    checkout = 'master'
    no_input = 'in'
    directory = 'test_dir'
    template = 'test'
    repo_candidate, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, 
                                                 no_input, directory=directory)
    assert repo_candidate == template
    assert cleanup == True
    
test_case_0()
test_determine_repo_dir()

# Generated at 2022-06-25 15:36:54.220267
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = '|\r/%jxM%W'
    str_0_0 = ''
    str_1 = 'cookiecutter.zip'

    str_2 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    str_3 = '~/repos/cookiecutter-pypackage'
    str_4 = '~/repos/cookiecutter-pypackage/.git'

    str_5 = '~/repos/my-path/cookiecutter-pypackage'

    var_0 = {
        'gh': 'https://github.com/{}.git',
        'lb': 'https://bitbucket.org/{}',
        'bb': 'https://bitbucket.org/{}.git'
    }
   

# Generated at 2022-06-25 15:37:00.151095
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template_0 = '~/Projects/cookiecutter-pypackage'
    abbreviations_0 = {'gh': 'https://github.com/{}.git'}
    clone_to_dir_0 = '~/Projects/cookiecutter-pypackage'
    checkout_0 = ''
    no_input_0 = True
    password_0 = None
    directory_0 = None
    str_0 = determine_repo_dir(template_0, abbreviations_0, clone_to_dir_0, checkout_0, no_input_0, password_0, directory_0)
    # assert str_0 == '~/Projects/cookiecutter-pypackage'
    print('str_0: ' + str_0)

# Generated at 2022-06-25 15:37:18.423307
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Given
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'cookiecutter': 'audreyr', 'cc': 'audreyr'}
    clone_to_dir = '/tmp/'
    checkout = 'master'
    no_input = True
    password = 'nopassword'
    directory = None

    # when
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )

    # then
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

    # cleanup
    import shutil

# Generated at 2022-06-25 15:37:26.652170
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Set the default values for parameter 'directory'
    directory = None

    # Call the function
    output_dir = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    # Setting the type of the return value of the function 'determine_repo_dir'
    assert isinstance(output_dir, tuple), f"\nExpected: <class 'tuple'>\nActual: {type(output_dir)}"


# Generated at 2022-06-25 15:37:31.694026
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'test_determine_repo_dir'
    abbreviations = {'test_determine_repo_dir' : 'test_value'}
    clone_to_dir = 'test_determine_repo_dir'
    checkout = 'master'
    no_input = True
    password = 'test_determine_repo_dir'
    directory = 'test_determine_repo_dir'
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-25 15:37:41.291111
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Check that we correctly detect URLs
    assert is_repo_url('http://example.com')
    assert is_repo_url('https://example.com')
    assert is_repo_url('git@example.com')
    assert is_repo_url('git@example.com:user/repo.git')
    assert is_repo_url('git+https://example.com')
    assert is_repo_url('git+ssh://example.com/repo.git')
    assert not is_repo_url('ssh://example.com/repo.git')

    assert is_zip_file('repo.zip')
    assert is_zip_file('https://example.com/repo.zip')
    assert not is_zip_file('repo')

# Generated at 2022-06-25 15:37:51.840589
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'C:/Users/Rachan/PycharmProjects/cookiecutter-cli/tests/test-output/test-templates/{{cookiecutter.repo_name}}'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    abbreviations['bb'] = 'https://bitbucket.org/{}'
    clone_to_dir = 'C:/Users/Rachan/PycharmProjects/cookiecutter-cli/tests/test-output/test-templates'
    checkout = None
    no_input = False
    password = None
    directory = None
    print(determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input,password,directory))



# Generated at 2022-06-25 15:37:58.308180
# Unit test for function determine_repo_dir

# Generated at 2022-06-25 15:38:07.942700
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {"gh":"https://github.com/{}" }
    clone_to_dir = None
    checkout = "master"
    no_input = None
    password = "123"
    directory = None

    determine_repo_dir(template, abbreviations, clone_to_dir, checkout,
            no_input, password, directory)
    print("Function determine_repo_dir")
    print("template:", template)
    print("abbreviations:", abbreviations)
    print("clone_to_dir:", clone_to_dir)
    print("checkout:", checkout)
    print("no_input:", no_input)
    print("password:", password)

# Generated at 2022-06-25 15:38:15.057475
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 3
    abbreviations = None
    clone_to_dir = 'ubgB%YkK#'
    checkout = '\x7f#Qsjg'
    no_input = True
    password = '$YjSyc%S'
    directory = 'L9jF37[|'

    (var_0, var_1) = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-25 15:38:24.325470
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.gi'

    abbreviations = {'github': 'https://github.com/{}.git'}

    clone_to_dir = '/home/user/cookiecutter-repo'

    checkout = 'da10d51'

    no_input = True

    directory = '/home/user/cookiecutter-repo'

    expected_str = '/home/user/cookiecutter-repo/cookiecutter-pypackage'

    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, directory)

    assert repo_dir == expected_str

# Generated at 2022-06-25 15:38:36.644063
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage"
    abbreviations = None
    clone_to_dir = "/cookiecutter"
    checkout = None
    no_input = False
    password = 'password'
    directory = ""
    result = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )

    full_repo_dir = os.path.join(clone_to_dir, template.split('/')[-1])
    assert result == (full_repo_dir, False)
    assert os.path.exists(full_repo_dir)



# Generated at 2022-06-25 15:38:52.719128
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_2 = './cookiecutter-pypackage'
    str_4 = 'cookiecutter-pypackage'
    str_2 = './cookiecutter-pypackage'
    dict_1 = {
        str_4: str_2,
    }
    str_3 = 'github.com/audreyr/cookiecutter-pypackage'
    repo_dir_0, cleanup_0 = determine_repo_dir(template = str_3, abbreviations = dict_1, clone_to_dir = '.', checkout = 'master', no_input = True)

# Generated at 2022-06-25 15:38:56.160381
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    dict_0 = {
        '|\r/%jxM%W': '|\r/%jxM%W',
    }
    # TODO: Determine if it is possible to provide more comprehensive test data.
    test_determine_repo_dir_exception(dict_0)


# Generated at 2022-06-25 15:39:04.484627
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    global var_0
    var_0 = determine_repo_dir(
        template = '|\r/%jxM%W',
        abbreviations = None,
        clone_to_dir = '/tmp/some_dir',
        checkout = 'master',
        no_input = False,
        password = None,
        directory = None,
    )
    assert var_0 == ('/tmp/some_dir/|\r/%jxM%W', False), "determine_repo_dir did not return values as expected."


# Generated at 2022-06-25 15:39:10.688506
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = '{{https://github.com/%7B%7Bcookiecutter.github_username%7D%7D/' \
            '{%7Bcookiecutter.project_name%7D%7D.git}}'
    str_1 = "{%7B%7Bcookiecutter.github_username%7D%7D}"
    str_2 = '{%7Bcookiecutter.project_name%7D%7D'
    str_3 = '{{https://github.com/{{cookiecutter.github_username}}/' \
            '{{cookiecutter.project_name}}.git}}'
    str_4 = '%7B%7Bcookiecutter.github_username%7D%7D'

# Generated at 2022-06-25 15:39:18.791214
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = './data/{{cookiecutter.repo_name}}'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '{{cookiecutter.project_slug}}'
    checkout = 'master'
    no_input = False
    password = 'none'
    directory = 'src'
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert repo_dir == './data/cookiecutter-foobar/src', 'Failed to get repo dir'
    assert cleanup == False, 'Failed to set cleanup'


# Test Functions

# Generated at 2022-06-25 15:39:31.231844
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_1 = '*a_XX=Ba'
    var_2 = '\n2wbvRG<x'
    var_3 = '|\r/%jxM%W'
    var_4 = 'eHk-j'
    var_5 = '1V}`j*v4'
    var_6 = 'P9?F*j'
    var_7 = 'B[C#'
    var_8 = 'U6PrGp\r'
    var_9 = 'q3?%'
    var_10 = '%c]B!_}'
    var_11 = '\rpA?bxC-g'
    var_12 = 'GY'
    var_13 = '1KXyB'
    var_14 = 'n'
    var_15

# Generated at 2022-06-25 15:39:40.396190
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    str_1 = 'cookiecutter-pypackage'
    var_0 = is_zip_file(str_1)
    var_1 = is_repo_url(str_0)
    var_2 = determine_repo_dir(template=str_0, abbreviations={}, clone_to_dir=None, checkout=None, no_input=True, password=None, directory=None)
    var_3 = True
    var_4 = None
    var_5 = True
    var_6 = '/Users/username/.cookiecutters'
    var_7 = 'audreyr'
    var_8 = 'cookiecutter-pypackage'

# Generated at 2022-06-25 15:39:50.570335
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert is_repo_url(0) == False
    assert is_repo_url('') == False
    assert is_repo_url('...') == False
    assert is_repo_url('/') == False
    assert is_repo_url(':') == False
    assert is_repo_url('/dev/urandom') == False
    assert is_repo_url('/usr/local/bin/python3.4') == False
    assert is_repo_url('http://') == True
    assert is_repo_url('http:///') == True
    assert is_repo_url('http://.') == True
    assert is_repo_url('http://|') == True
    assert is_repo_url('http:///') == True
    assert is_repo_url

# Generated at 2022-06-25 15:40:00.088344
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = '|\r/%jxM%W'

# Generated at 2022-06-25 15:40:06.825572
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = None
    clone_to_dir = 'clone_to_dir'
    checkout = 'checkout'
    no_input = False
    password = 'password'
    directory = None

    template = 'template'
    determined_repo_dir = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )

    assert len(determined_repo_dir) == 2

    template = 'git+https://github.com/cookiecutter-django/cookiecutter-django.git'

# Generated at 2022-06-25 15:40:32.203541
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    with pytest.raises(SystemExit):
        abbreviations = {}
        template = 'C:\\Program Files\\HP\\HP BTO Software\\bin\\python.exe'
        clone_to_dir = 'C:\\Users\\cjpalmer\\AppData\\Local\\Temp\\tmpq3j_afq4'
        checkout = 'master'
        no_input = True
        determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input)



# Generated at 2022-06-25 15:40:35.456982
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert isinstance(determine_repo_dir('|\r/%jxM%W',
                                         None,
                                         'A5H5zYX%c',
                                         '1f<GF%C=ygr',
                                         True,
                                         '1f<GF%C=ygr',
                                         'w?<*Ao=Pt'), tuple)



# Generated at 2022-06-25 15:40:41.445167
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    temp_dir_0 = 'f.y[w(.^\#'
    template_0 = 'f.y[w(.^\#'
    ret_0 = determine_repo_dir(
        template_0,
        abbreviations,
        temp_dir_0,
        'O[NayD\';o',
        False,
        'LSW%Xvj}l',
        'F,fLR\'W[y',
    )
    ret_0[0] = True
    ret_0[1] = True
    template_1 = 'f.y[w(.^\#'

# Generated at 2022-06-25 15:40:49.832271
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("\n=== Testing Cookiecutter ===")
    print("\n=== Determining Repository Directory ===")
    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = True
    password = ''
    directory = ''
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print(repo_dir)
    print(cleanup)
    return repo_dir, cleanup

# Generated at 2022-06-25 15:40:59.564864
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # === Set up test variables ===
    # You can edit these to manipulate certain test cases
    str_0 = 'git+git://github.com/wdm0006/cookiecutter-pypackage.git#egg=cookiecutter-pypackage'
    str_1 = 'https://github.com/wdm0006/cookiecutter-pypackage.git'
    str_2 = 'wdm0006/cookiecutter-pypackage'
    str_3 = 'https://github.com/wdm0006/cookiecutter-pypackage/archive/2.1.1.zip'
    str_4 = '/home/user1/cookiecutter-pypackage'
    str_5 = 'wdm0006/cookiecutter-pypackage/cookiecutter.json'
   

# Generated at 2022-06-25 15:41:07.008848
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'file:///Users/user/Documents/projects/cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/{0}.git',
        'bb': 'https://bitbucket.org/{0}',
        'git': 'https://gitorious.org/{0}.git',
    }
    clone_to_dir = '/Users/user/Documents/projects/cookiecutters'
    checkout = 'master'
    no_input = False


if __name__ == '__main__':
    test_case_0()
    test_determine_repo_dir()

# Generated at 2022-06-25 15:41:15.127970
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_data_0 = {
        'template': 'c:/Program Files',
        'abbreviations': None,
        'clone_to_dir': 'c:/windows/system32/cmd.exe',
        'checkout': None,
        'no_input': False,
        'password': None,
        'directory': 'ms',
        'expect': ('c:/Program Files/ms', False)
    }

# Generated at 2022-06-25 15:41:24.257344
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    templates = ['.', './some/path/to/j2/project/']
    abbreviations = {
        'j2': 'https://github.com/{0}',
        'cookiecutter-pypackage': 'https://github.com/audreyr/{}',
    }
    clone_to_dir = 'tests/test-output'
    checkout = None
    no_input = False
    password = None
    directory = None

    for template in templates:
        repo, cleanup = determine_repo_dir(
            template, abbreviations, clone_to_dir, checkout, no_input, password, directory
        )
        assert repo[0] == 't'
        assert not cleanup
        assert not is_repo_url(repo)


# Generated at 2022-06-25 15:41:31.703939
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/pydanny/cookiecutter-django-crud.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghe': 'git@github.com:{}.git',
    }
    clone_to_dir = 'C:\\Users\\WUZHE\\Documents\\GitHub\\Python\\cookiecutter-pypackage'
    checkout = None
    no_input = True
    password = '9Eg>q%3G<n'
    directory = 'hook'
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-25 15:41:37.412015
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    directory = 'tests/{}/'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

# Generated at 2022-06-25 15:42:31.844907
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_9 = str_0 = '|\r/%jxM%W'
    var_6 = var_6 = False
    var_7 = None
    var_8 = False
    var_10 = None
    var_1 = (var_9, var_6, var_7, var_8, var_10)
    var_2 = None
    var_3 = ''
    var_4 = False
    var_5 = None
    var_0 = determine_repo_dir(var_1, var_2, var_3, var_4, var_5)

# Generated at 2022-06-25 15:42:38.547952
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    local_0 = 'Hy!b}t+:uFR7\x5c5\t;,[w('
    local_1 = "9@*fm)cJAz"
    abbreviations = {
        local_0: "{}"
    }
    template = "FgLzIjXE"
    local_3 = determine_repo_dir(
        template,
        abbreviations,
        "/_B",
        "\"F@cj2Q/\x7f",
        True,
        "}-a3qhC'${NX"
    )
    local_4 = abbreviations[local_0]
    local_5 = template.partition(':')
    local_7 = local_5[0]
    local_10 = local_7 in abbreviations
    local_13 = local_5

# Generated at 2022-06-25 15:42:46.596920
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'NotARepo'
    abbreviations = {'abbrev': 'https://github.com/bennetc/cookiecutter-abbrev'}
    clone_to_dir = '/fake/dir'
    checkout = 'master'
    no_input = False
    password = None
    directory = 'test_a'
    repo, cleanup = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input,
        password=password, directory=directory
    )

# Generated at 2022-06-25 15:42:47.785011
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("""TEST CASE 0""")
    test_case_0()


# Generated at 2022-06-25 15:42:54.778428
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for determine_repo_dir"""
    abbreviations = None
    clone_to_dir = 'cd1'
    template = 'tc1'
    checkout = 'c1'
    no_input = True
    password = 'p1'
    directory = 'd1'
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    # True if the `repo_directory` is valid, else False
    assert repo_dir is not None

# Generated at 2022-06-25 15:42:59.485661
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import cookiecutter

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir, cleanup = determine_repo_dir(
        template,
        {},
        cookiecutter.DEFAULT_CLONE_DIR,
        None,
        no_input=True,
        password=None,
        directory=None,
    )
    assert repo_dir
    assert not cleanup

    # Clean up (delete) the cloned repo, so it doesn't pollute the system.
    cookiecutter.rmtree(repo_dir)

