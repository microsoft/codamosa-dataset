

# Generated at 2022-06-25 15:32:59.230826
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '/home/sakulkar/PycharmProjects/TestingCookieCutter'
    checkout = None
    no_input = False
    password = None
    directory = None
    out = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    assert out == ('/home/sakulkar/PycharmProjects/TestingCookieCutter/cookiecutter-pypackage', False)


# Generated at 2022-06-25 15:33:01.137537
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'a'
    abbreviations = {
        'a': 'b'
    }
    var_0 = expand_abbreviations(template, abbreviations)
    assert var_0 == 'b'


# Generated at 2022-06-25 15:33:07.787056
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    int_0 = './dir_0'
    var_0 = repository_has_cookiecutter_json(int_0)
    assert var_0

    int_0 = './dir_0/cookiecutter.json'
    var_0 = repository_has_cookiecutter_json(int_0)
    assert not var_0
    # Output: 


# Generated at 2022-06-25 15:33:10.030093
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    int_0 = True
    var_0 = repository_has_cookiecutter_json(int_0)
    assert var_0 == False
    test_case_0()


# Generated at 2022-06-25 15:33:12.347846
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = determine_repo_dir()


# Generated at 2022-06-25 15:33:20.339572
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from pyfakefs.fake_filesystem_unittest import Patcher
    from tests.test_repos import _mock_cookiecutter_json
    with Patcher() as patcher:
        patcher.fs.create_file('cookiecutter.json', contents=_mock_cookiecutter_json)
        patcher.fs.create_dir('a/b/c')
        patcher.fs.create_file('a/b/c/cookiecutter.json', contents=_mock_cookiecutter_json)
        patcher.fs.create_file('a/b/c/d/cookiecutter.json', contents=_mock_cookiecutter_json)

# Generated at 2022-06-25 15:33:22.843161
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    call_0 = test_case_0()


if __name__ == "__main__":
    test_expand_abbreviations()

# Generated at 2022-06-25 15:33:25.080846
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(None) == False
    #assert repository_has_cookiecutter_json() == False


# Generated at 2022-06-25 15:33:31.098972
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = None
    int_1 = None
    str_0 = determine_repo_dir(int_0, int_0, int_1, int_0, int_0)

# Automatic unit tests
try:
    test_determine_repo_dir()
except AssertionError:
    print(test_determine_repo_dir.__name__ + " failed.")
else:
    print(test_determine_repo_dir.__name__ + " passed.")

# Manual unit test for function determine_repo_dir

# Generated at 2022-06-25 15:33:36.767200
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = None
    int_1 = determine_repo_dir(int_0, int_0, int_0, int_0, int_0)
    assert len(int_1) == 2

# Test that the cookiecutter.json file exists in the repo

# Generated at 2022-06-25 15:33:42.312062
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = {}
    var_0['0_0'] = 'c:\Projects\Hawk'
    var_0['0_1'] = 'https://github.com/Hawk'
    var_0['cookiecutter_json'] = 'cookiecutter.json'

    determine_repo_dir(var_0)    
    

# Generated at 2022-06-25 15:33:43.380563
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    if not determine_repo_dir():
        raise AssertionError('Test passed.')

# Generated at 2022-06-25 15:33:47.811072
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # create the template name
    template = 'abc'
    # create abbreviations
    abbreviations = { 'abc': 'abc' }
    # create clone to directory
    clone_to_dir = '#'
    # create the checkout name
    checkout = 'develop'
    # create the password
    password = '1234'
    # create directory where cookiecutter.json is located
    directory = 'location'
    # create the tuple and store return value
    var_1 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, password, directory)

# Generated at 2022-06-25 15:33:49.567314
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("repo_directory") == False


# Generated at 2022-06-25 15:34:01.166323
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test 1
    # <Path>
    # Expected: True
    arg = "/Users/dongkwan/Desktop/CookieCutter/cookiecutter-pypackage-sample"
    assert repository_has_cookiecutter_json(arg) is True

    # Test 2
    # <Path> 'cookiecutter.json' not in directory
    # Expected: False
    arg = "/Users/dongkwan/Desktop/CookieCutter/cookiecutter-pypackage-sample/foo"
    assert repository_has_cookiecutter_json(arg) is False

    # Test 3
    # <Path> 'cookiecutter.json' in directory
    # Expected: True

# Generated at 2022-06-25 15:34:09.056601
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Test case 0
    template_0 = '.'
    abbreviations_0 = {'.': '.'}
    var_0 = expand_abbreviations(template_0, abbreviations_0)
    assert var_0 == template_0
    # Test case 1
    template_1 = './pypackage'
    abbreviations_1 = {'.': '.'}
    var_1 = expand_abbreviations(template_1, abbreviations_1)
    assert var_1 == template_1
    # Test case 2
    template_2 = './pypackage/'
    abbreviations_2 = {'.': '.'}
    var_2 = expand_abbreviations(template_2, abbreviations_2)
    assert var_2 == template_2
    # Test case 3
    template

# Generated at 2022-06-25 15:34:19.602769
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from os import remove
    from os.path import join, exists, getcwd
    from time import time
    from random import randint
    from shutil import rmtree
    from cookiecutter.vcs import checkout

    pwd = getcwd()

    # Prepare test directory
    test_dir = 'test_dir_%d' % randint(0, int(time()))

    while exists(join(pwd, test_dir)):
        test_dir = 'test_dir_%d' % randint(0, int(time()))


# Generated at 2022-06-25 15:34:23.013494
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # Remove the following lines and replace with your code here
    raise NotImplementedError()


# Generated at 2022-06-25 15:34:24.044637
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json()

# Generated at 2022-06-25 15:34:27.074461
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("Tests/fake-repo-tmpl") == True
    assert repository_has_cookiecutter_json("Tests/bogus") == False

# Generated at 2022-06-25 15:34:35.525819
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert (
        determine_repo_dir(
            'gh:audreyr/cookiecutter-pypackage',
            abbreviations=abbreviations,
            clone_to_dir='.',
            checkout=None,
            no_input=True,
            password=None,
            directory=None,
        )
        == (
            'https://github.com/audreyr/cookiecutter-pypackage',
            False,
        )
    )

# Generated at 2022-06-25 15:34:39.871144
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Validate object with object argument
    object_var_0 = RepositoryNotFound()
    # Call function
    var_0 = repository_has_cookiecutter_json(object_var_0)
    assert True == var_0

# Generated at 2022-06-25 15:34:41.572790
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert callable(determine_repo_dir)


# Generated at 2022-06-25 15:34:50.236109
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    zip_uri = "https://github.com/davidbailey00/Cookiecutter-Multi-Project/archive/master.zip"
    is_url = True

# Generated at 2022-06-25 15:34:50.623182
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True



# Generated at 2022-06-25 15:34:54.580320
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("C:/Users/Yash/Documents/GitHub/cookiecutter-datascience/cookiecutter.json") == True
    assert repository_has_cookiecutter_json("C:/Users/Yash/Documents/GitHub/cookiecutter-datascience/") == True
    assert repository_has_cookiecutter_json("C:/Users/Yash/Documents/GitHub/cookiecutter-datascience/data") == False
    print("All cookiecutter tests passed!")

# Generated at 2022-06-25 15:34:56.013628
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json()


# Generated at 2022-06-25 15:34:57.816211
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert callable(determine_repo_dir)

# Generated at 2022-06-25 15:35:08.379734
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    path = "C:\\Users\\user\\Documents\\GitHub\\dimer\\dimer\\tests\\test_input\\cookiecutter-pypackage\\cookiecutter.json"

# Generated at 2022-06-25 15:35:11.707263
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("./tests/test-repo-tmpl/") == True
    assert repository_has_cookiecutter_json("./tests/test-repo-tmpl/test-dir") == True


# Generated at 2022-06-25 15:35:26.171437
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    directory = "."
    clone_to_dir = "/Users/aalvarez/Projects/cookiecutter_playground/repos/cookiecutter-pypackage_149998537857/audreyr"
    checkout = "master"
    no_input = False
    test_determine_repo_dir_result_0 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        directory=directory,
    )

# Generated at 2022-06-25 15:35:39.629993
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "adfasdf"
    abbreviations = {'f': '1', 'a': 't'}
    clone_to_dir = "dafasdf"
    checkout = "1"
    no_input = True
    password = None
    directory = None

    int_0 = 362
    var_0 = is_repo_url(int_0)

    # Get the first element
    int_1 = abbreviations.get('f')

    # Get the first element
    int_2 = abbreviations.get('a')

    # dict comprehension
    int_3 = {x: abbreviations.get(x) for x in abbreviations}

    # dict comprehension with if statement

# Generated at 2022-06-25 15:35:50.228866
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'determine_repo_dir'
    checkout = '0.9.0'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    # Check
    assert repo_dir == 'determine_repo_dir/cookiecutter-pypackage'


if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-25 15:35:59.226551
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'a.zip'
    abbreviations = {'a': 'a.com', 'b': 'b.com'}
    clone_to_dir = '/a/b/c'
    checkout = None
    no_input = False
    password = None
    directory = None


# Generated at 2022-06-25 15:36:08.634726
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_repo_dir = determine_repo_dir(
        template = os.path.join(os.path.dirname(__file__), 'repo/tests/test-repo-3/{{cookiecutter.repo_name}}'),
        abbreviations = {},
        clone_to_dir = '/tmp/cookiecutter-test-repo-2',
        checkout = None,
        no_input = False,
        password = None,
        directory = None)
    assert test_repo_dir == ('/tmp/cookiecutter-test-repo-2/repo/tests/test-repo-3/repo_name_3', False)


# Generated at 2022-06-25 15:36:16.933082
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = "https://github.com/audreyr/cookiecutter-pypackage.git"
    var_1 = {}
    var_2 = "C:/b87e51c9/sample_repo"
    var_3 = "1f2d1b75ac0d73c61151e81e9c17db8bcfc16b04"
    var_4 = False
    var_5 = ""
    var_6 = ""

    var_7, var_8 = determine_repo_dir(var_0, var_1, var_2, var_3, var_4, var_5, var_6)

    assert var_7 == "C:/b87e51c9/sample_repo"
    assert var_8 == False



# Generated at 2022-06-25 15:36:17.946042
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir() == (None, None, None)

# Generated at 2022-06-25 15:36:21.980035
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    int_0 = 213
    int_1 = 295
    var_0 = determine_repo_dir(int_0, int_1)

# Generated at 2022-06-25 15:36:22.594193
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True

# Generated at 2022-06-25 15:36:30.054587
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    clone_to_dir = ""
    checkout = "master"
    no_input = False
    password = None
    directory = None
    template = "https://github.com/audreyr/cookiecutter-pypackage"
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

if __name__ == "__main__":
    test_determine_repo_dir()

# Generated at 2022-06-25 15:36:37.637937
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = None
    var_1 = 'repository'
    var_2 = 'template'
    var_3 = 'directory'

    assert determine_repo_dir(var_0, var_1, var_2, var_3) == 'repository/template/directory'

# Generated at 2022-06-25 15:36:45.312912
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = '/Users/audreyr/foo'
    abbreviations = {'gh': 'https://github.com/{}'}
    clone_to_dir = '/Users/audreyr/projects/cookiecutters'
    checkout = None
    no_input = True
    password = None
    directory = None
    determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-25 15:36:52.082325
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "Cookiecutter-"
    abbreviations = {'gh': 'https://github.com/{0}.git'}
    clone_to_dir = "/Users/kaichengyan/Desktop/cookiecutter-data-science"
    checkout = "2019.11"
    no_input = True
    password = None
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password)

if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-25 15:36:57.600708
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # This test case will fail at run time.
    determine_repo_dir(
        template = int_0,
        abbreviations = int_0,
        clone_to_dir  = int_0,
        checkout = int_0,
        no_input = int_0,
        password = int_0,
        directory = int_0,
    )

# Generated at 2022-06-25 15:37:01.208954
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_determine_repo_dir_0()


# Generated at 2022-06-25 15:37:08.120965
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = 'cookiecutter-pypackage'
    checkout = None
    no_input = True
    password = None
    directory = None
    obj_0 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    test_case_0()

# Generated at 2022-06-25 15:37:11.183144
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    determine_repo_dir("git@gitlab.com:cookicutter/tester.git", None, None, None, None)

# Generated at 2022-06-25 15:37:19.468252
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = True
    password = None
    directory = None
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input,
        password, directory)
    # A boolean value indicating whether the cookiecutter template directory
    #  should be removed after instantiation.
    #
    #  :return: A boolean value.


if __name__ == '__main__':
    test_determine_repo_dir()
    test_case_0()

# Generated at 2022-06-25 15:37:26.453548
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir("https://github.com/audreyr/cookiecutter-pypackage.git", "", "", "", "", "")

if __name__ == "__main__":
    # Unit test for function is_repo_url
    test_case_0()
    # Unit test for function determine_repo_dir
    test_determine_repo_dir()

# Generated at 2022-06-25 15:37:31.403472
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Remove the following lines and replace them with your test case
    template = ''
    abbreviations = ''
    clone_to_dir = ''
    checkout = ''
    no_input = ''
    password = ''
    directory = ''

    try:
        template = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory
        )
        print(template)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 15:37:43.928054
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Pass variables to function
    template = "git@github.com:audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = "/home/user/cookiecutter-tmp"
    checkout = None
    no_input = False
    password = None
    directory = "{{cookiecutter.repo_name}}"
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)



# Generated at 2022-06-25 15:37:52.166376
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'user/repo.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = ""
    test_case_0()
    repository_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )
    assert repository_dir == 'https://github.com/user/repo.git'


# Generated at 2022-06-25 15:37:59.791437
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = './cookiecutter-pypackage'
    abbreviations = dict()
    clone_to_dir = './cookiecutter-tests'
    checkout = 'master'
    no_input = 'no_input'
    directory = './'
    out, cleanup = determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input,directory)
    assert out == './cookiecutter-tests/cookiecutter-pypackage'
    assert not cleanup


# Generated at 2022-06-25 15:38:03.482375
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 358
    abbreviations = 358
    clone_to_dir = 358
    cleanup = 358
    checkout = 358
    no_input = 358
    password = 358
    directory = 358
    var_0 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)


# Generated at 2022-06-25 15:38:12.318539
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    class Class_0:
        def __init__(self):
            self.int_0 = 362
            self.bool_0 = True
            self.bool_1 = True

# Generated at 2022-06-25 15:38:21.836188
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'ghe': 'git@github.com:{}.git',
        'bbe': 'git@bitbucket.org:{}',
    }
    clone_to_dir = '/Users/audreyr/code/cookiecutter-templates'
    checkout = '0.9.2'
    no_input = True
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )


# Generated at 2022-06-25 15:38:31.134873
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.repository import determine_repo_dir

    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/{}',
    }
    clone_to_dir = 'fake-repo'
    checkout = None
    no_input = False

    # Abbreviation
    result = determine_repo_dir(
        template='gh:audreyr/cookiecutter-pypackage',
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
    )
    assert 'fake-repo/audreyr-cookiecutter-pypackage' in result[0]

   

# Generated at 2022-06-25 15:38:39.128996
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import pytest
    import mock
    abbreviations = {
      'gh': 'https://github.com/{}.git',
      'bb': 'https://bitbucket.org/{}'
    }
    template = ""
    clone_to_dir = "/Users/matthewhartman/repos/github/cookiecutter/tests/test-data"
    checkout = ""
    no_input=False
    password = None
    directory = ""
    #Test that a directory will be returned if given a repo name
    repo_candidate = "/Users/matthewhartman/repos/github/cookiecutter/tests/test-data/fake-repo-tmpl"

# Generated at 2022-06-25 15:38:40.897297
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_case_0()


# Generated at 2022-06-25 15:38:48.418491
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

	# Create the test variable
	dict_0 = {"test2":"lastName","test1":"firstName","test0":"userName"}
	var_1 = False
	var_2 = "test0"
	dict_1 = {"test0":"test"}
	var_3 = ".\\test"


	# Exercise the function
	var_0 = determine_repo_dir(dict_0, var_1, dict_0, var_2, dict_0, var_2, dict_1, var_3)
	assert var_0 == (".\\test\\cookiecutter.json", False)

# Generated at 2022-06-25 15:39:10.706606
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print('\nINPUT 1')
    print(REPO_REGEX)
    print('OUTPUT')
    print(1)
    print('')
    print('')

    print('\nINPUT 2')
    print('https://bitbucket.org/pokoli/cookiecutter-tryton.git')
    print('OUTPUT')
    print(1)
    print('')
    print('')

    print('\nINPUT 3')
    print('https://bitbucket.org/pokoli/cookiecutter-tryton')
    print('OUTPUT')
    print(0)
    print('')
    print('')

    print('\nINPUT 4')

# Generated at 2022-06-25 15:39:19.697863
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert (determine_repo_dir({'feature/123', 'https://github.com/audreyr/cookiecutter-pypackage.git'}, 1, 1, 1)[0] == 'https://github.com/audreyr/cookiecutter-pypackage.git')
    assert (determine_repo_dir({'feature/123', 'https://github.com/audreyr/cookiecutter-pypackage.git'}, 1, 1, 1)[1] == 1)
    assert (determine_repo_dir({'feature/123', 'https://github.com/audreyr/cookiecutter-pypackage.git'}, 1, 1, 1)[2] == 1)

# Generated at 2022-06-25 15:39:21.180286
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = determine_repo_dir
    int_0 = 362
    var_0(int_0)

# Generated at 2022-06-25 15:39:26.570125
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = ''
    abbreviations = {}
    clone_to_dir = ''
    checkout = ''
    no_input = False
    password = ''
    directory = ''
    # code coverage is 87%
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-25 15:39:36.997311
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template_0 = '../dot_cookiecutters/{{cookiecutter.repo_name}}'
    abbreviations_0 = {}
    clone_to_dir_0 = '$HOME/.cookiecutters'
    checkout_0 = 'master'
    no_input_0 = True
    directory_0 = None
    result_0 = determine_repo_dir(template_0, abbreviations_0, clone_to_dir_0,
                                  checkout_0, no_input_0, directory_0)
    print('type of result_0 = ' + str(type(result_0)))
    print('result_0 = ' + str(result_0))
    assert len(result_0) == 2
    print('type of result_0[0] = ' + str(type(result_0[0])))

# Generated at 2022-06-25 15:39:43.123638
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    arg_0 = "zippy"
    arg_1 = "happy fun times"
    arg_2 = "sad times"
    arg_3 = "check_check"
    arg_4 = True
    arg_5 = "password password"
    arg_6 = "directory"

    ret_0, ret_1 = determine_repo_dir(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6)
    assert type(ret_0) is str
    assert type(ret_1) is bool


# Generated at 2022-06-25 15:39:53.547451
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gitlab': 'https://gitlab.com/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    clone_to_dir = 'test_dir'
    checkout = 'master'
    no_input = True
    password = '123456'
    directory = 'template'
    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )

# Generated at 2022-06-25 15:40:00.835208
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "something"
    abbreviations = "something"
    clone_to_dir = "something"
    checkout = "something"
    no_input = "something"
    password = "something"
    directory = "something"
    determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )


# Generated at 2022-06-25 15:40:02.907892
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = determine_repo_dir("hoi")
    var_1 = determine_repo_dir("hoi")
    assert var_0 == var_1



# Generated at 2022-06-25 15:40:13.214963
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Input parameters
    template = os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl')
    abbreviations = {}
    clone_to_dir = os.getcwd()
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    # Expected output
    expected = (template, False)
    # Actual output
    actual = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    # Assertions
    assert actual == expected


# Generated at 2022-06-25 15:40:50.891535
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}.git', 'bb': 'https://bitbucket.org/{}.git', 'gitlab': 'https://gitlab.com/{}', 'arch': 'file:///var/cache/pacman/pkg'}
    template = 'fruits'
    clone_to_dir = 'c:\\users\\administrator\\appdata\\local\\temp'
    checkout = 'v0.1.2'
    no_input = False
    password = 'p@ssw0rd'
    directory = 'my-project'
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

test_case_0()
test_determine_repo_dir()

# Generated at 2022-06-25 15:41:02.929266
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template_0 = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations_0 = {'hi': 'hi'}
    clone_to_dir_0 = 'meh'
    checkout_0 = 'abcd/ef'
    no_input_0 = True
    password_0 = 'hii'
    directory_0 = 'hii'
    for int_1 in range(1, 100):
        if int_1 < 0:
            var_0 = determine_repo_dir(template_0, abbreviations_0, clone_to_dir_0, checkout_0, no_input_0, password_0, directory_0)
    template_0 = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-25 15:41:04.715984
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test_case_0
    int_0 = 362
    var_0 = determine_repo_dir(int_0)


# Generated at 2022-06-25 15:41:08.395452
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    with pytest.raises(RepositoryNotFound):
        determine_repo_dir(
            template='http://cookiecutter.readthedocs.io/en/latest/registry.html',
            abbreviations='',
            clone_to_dir='/tmp',
            checkout='',
            no_input=False,
            password=None,
            directory=None,
        )

# Generated at 2022-06-25 15:41:18.238601
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert repository_has_cookiecutter_json(r'C:\\Users\\cookiecutters')
    assert not repository_has_cookiecutter_json('C:\\Users\\cookiecutters')
    assert not repository_has_cookiecutter_json('C:\\Users\\cookiecutters\\')
    assert not repository_has_cookiecutter_json(r'\\Users\\cookiecutters')
    assert not repository_has_cookiecutter_json(r'C:\\Users\\cookiecutters\\')
    assert not repository_has_cookiecutter_json('C:\\cookiecutters')
    assert not repository_has_cookiecutter_json('C:\\cookiecutters\\')
    assert not repository_has_cookiecutter_json(r'\\cookiecutters')

# Generated at 2022-06-25 15:41:25.421118
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Tests determine_repo_dir()."""
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone_to_dir = 'C:\\Users\\Nico\\Desktop\\myproject'
    checkout = '0.1.2'
    no_input = False
    password = None
    directory = None
    str_0, bool_0 = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert str_0 == 'C:\\Users\\Nico\\Desktop\\myproject\\cookiecutter-pypackage'
    assert bool

# Generated at 2022-06-25 15:41:28.792526
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone_to_dir = '/Users/audreyr/cookiecutters'
    checkout = 'develop'
    password = None
    directory = None

    assert determine_repo_dir(
        template, clone_to_dir, checkout, password, directory
    ) is not None


if __name__ == "__main__":
    test_determine_repo_dir()

# Generated at 2022-06-25 15:41:34.332034
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Initialization
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'testcases/remove_me'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    
    # Call function
    const_0 = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    
    if isinstance(const_0, tuple) and const_0[0] == 'testcases/remove_me/cookiecutter-pypackage' and const_0[1] == False:
        print('Test passed!')
    else:
        print('Test failed!')


# Generated at 2022-06-25 15:41:40.945974
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    var_0 = is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")
    var_1 = is_repo_url("git+git://github.com/audreyr/cookiecutter-pypackage.git#egg=Cookiecutter-pypackage")
    var_2 = is_repo_url("file:///home/audreyr/projects/cookiecutter-pypackage")
    var_3 = is_repo_url("audreyr/cookiecutter-pypackage")
    var_4 = is_repo_url("git@github.com/audreyr/cookiecutter-pypackage.git")       

# Generated at 2022-06-25 15:41:46.253820
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "../../examples/example-repo-pre/{{cookiecutter.repo_name}}"
    abbreviations = {}
    clone_to_dir = "../../examples/example-repo-pre"
    checkout = None
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout) == "../../examples/example-repo-pre/"
