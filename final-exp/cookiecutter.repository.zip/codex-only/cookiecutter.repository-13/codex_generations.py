

# Generated at 2022-06-23 16:23:25.842880
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'example': 'https://example.com/{}.git',
        'examplehg': 'mercurial+https://example.com/{}.hg',
    }

# Generated at 2022-06-23 16:23:29.818795
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('test.ZiP') == True
    assert is_zip_file('test.ziP') == True

    assert is_zip_file('test.py') == False
    assert is_zip_file('test.py.zip') == True
    assert is_zip_file('testzip') == False
    assert is_zip_file('') == False
    assert is_zip_file(' ') == False


# Generated at 2022-06-23 16:23:35.530232
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('file.ZIP')
    assert is_zip_file('/tmp/some_file.zip')
    assert is_zip_file('C:\\tmp\\some_file.zip')
    assert not is_zip_file('.zip')
    assert not is_zip_file('file.zip.')
    assert not is_zip_file('file.zipped')

# Generated at 2022-06-23 16:23:44.611594
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'gl': 'git@gitlab.com:{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    # repo name
    repo = 'my_repo'
    assert expand_abbreviations(repo, abbreviations) == repo

    # full URL
    repo = 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(repo, abbreviations) == repo

    # github repo
    repo = 'gh:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:23:49.988676
# Unit test for function is_repo_url
def test_is_repo_url():

    # If a repo is valid return True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')

    # If a repo is invalid return False
    assert not is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:23:56.073473
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo-pre-gen-project',
    )
    assert repository_has_cookiecutter_json(test_repo)

    test_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo-pre-gen-project.py',
    )
    assert not repository_has_cookiecutter_json(test_repo)

# Generated at 2022-06-23 16:23:56.673832
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True



# Generated at 2022-06-23 16:24:02.278785
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    result = expand_abbreviations(template, abbreviations)
    assert result == expected

# Generated at 2022-06-23 16:24:10.982054
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    repo_dir = determine_repo_dir(
        template='gh:audreyr/cookiecutter-pypackage',
        abbreviations={'gh': 'https://github.com/{}.git'},
        clone_to_dir='.',
        checkout=None,
        no_input=True,
        password=None,
        directory=None
    )
    assert repo_dir == ('https://github.com/audreyr/cookiecutter-pypackage.git', False)

# Generated at 2022-06-23 16:24:14.702242
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('archive.zip')
    assert is_zip_file('archive.ZIP')
    assert is_zip_file('archive.Zip')
    assert not is_zip_file('archive.zip2')
    assert not is_zip_file('archive')

# Generated at 2022-06-23 16:24:19.959937
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import utils
    template = utils.get_template('full')
    assert repository_has_cookiecutter_json(
        template
    ), 'False returned for a valid repo'

    assert not repository_has_cookiecutter_json(
        'invalid_dir'
    ), 'True returned for an invalid repo'



# Generated at 2022-06-23 16:24:26.009479
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    import shutil
    import os.path

    cookiecutter_json = 'cookiecutter.json'
    temp_dir = tempfile.mkdtemp()
    temp_dir_with_config = tempfile.mkdtemp()
    shutil.copy(cookiecutter_json, temp_dir_with_config)

    assert not repository_has_cookiecutter_json(temp_dir)
    assert repository_has_cookiecutter_json(temp_dir_with_config)

    shutil.rmtree(temp_dir)
    shutil.rmtree(temp_dir_with_config)

# Generated at 2022-06-23 16:24:29.286031
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('cookiecutter-pypackage',
                              {},
                              ".",
                              None,
                              True,
                              password=None,
                              directory=None
                              ) == ('./cookiecutter-pypackage', False)



# Generated at 2022-06-23 16:24:33.936062
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert 'https://github.com/nvie/cookiecutter.git' == expand_abbreviations(
        'gh:nvie/cookiecutter', abbreviations
    )

# Generated at 2022-06-23 16:24:37.274009
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations("foo", {"foo": "bar"}) == "bar"


# Generated at 2022-06-23 16:24:45.193799
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/some/local/folder')
    assert not is_repo_url('file:///some/local/folder')
    assert not is_repo_url('/')
    assert not is_repo_url('file://something')
    assert not is_repo_url('/file://something')
    assert not is_repo_url('/file://something/else')
    assert not is_re

# Generated at 2022-06-23 16:24:52.352990
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:25:01.764522
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the is_repo_url function."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git#egg=cookiecutter-pypackage')

# Generated at 2022-06-23 16:25:07.695743
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    files_dir = os.path.dirname(__file__)
    repo_directory = os.path.join(files_dir, 'fake-repo-tmpl')
    repo_json_exists = repository_has_cookiecutter_json(repo_directory)

    assert repo_json_exists is True

# Generated at 2022-06-23 16:25:14.385531
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file_names = ['test.zip', 'test.ZIP', 'test.ZiP', 'test.zIp']
    non_zip_file_names = ['test', 'test.', 'test.zi', 'test.zip_', 'test.zip.gz']

    for name in zip_file_names:
        assert is_zip_file(name)

    for name in non_zip_file_names:
        assert not is_zip_file(name)

# Generated at 2022-06-23 16:25:17.304459
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('my_app.zip')
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git') == False

# Generated at 2022-06-23 16:25:29.373899
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'git@github.com:audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url(
        'git@github.com:audreyr/cookiecutter-pypackage.git#egg=cookiecutter'
    )
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:25:39.363972
# Unit test for function is_repo_url
def test_is_repo_url():
    # Tests all the possible values of is_repo_url
    repo_urls = [
        "file:///home/user/file",
        "file:///c:/users/user/file",
        "https://github.com/Zabanaa/cookiecutter-Django",
        "https://github.com/Zabanaa/cookiecutter-Django.git",
        "git+https://github.com/audreyr/cookiecutter.git",
        "git://github.com/audreyr/cookiecutter.git",
        "git@github.com:audreyr/cookiecutter.git",
        "git://github.com:audreyr/cookiecutter.git",
        "git://github.com/Zabanaa/cookiecutter-Django.git",
    ]

# Generated at 2022-06-23 16:25:50.338679
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test the function expand_abbreviations

    1. Test if it expands the abbreviations
    2. Test if it expands the abbreviations with a template given
       using the format method
    3. Test if it returns the template name if it's not in the
       abbreviations dictionary
    """

    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'bb:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:26:00.464999
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import utils
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()

    # Test with empty directory
    assert not repository_has_cookiecutter_json(test_dir)

    # Test with non-empty directory
    utils.make_sure_path_exists(os.path.join(test_dir, 'testdir'))
    assert not repository_has_cookiecutter_json(test_dir)

    # Test with directory that contains a file
    utils.make_sure_path_exists(os.path.join(test_dir, 'subdir'))
    with open(os.path.join(test_dir, 'subdir', 'textfile.txt'), 'w'):
        pass

# Generated at 2022-06-23 16:26:03.035789
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json"""
    test_repo = '.tests/tests/fixtures/test-repo-tmpl'
    assert repository_has_cookiecutter_json(test_repo)



# Generated at 2022-06-23 16:26:03.786200
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir is not None

# Generated at 2022-06-23 16:26:12.407749
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {"github": "https://github.com/{}.git"}
    cases = [
        ("github:audreyr/cookiecutter-pypackage", "https://github.com/audreyr/cookiecutter-pypackage.git"),
        ("github:", "https://github.com/.git"),
        ("not_there:foo/bar", "not_there:foo/bar")
    ]
    for template, expected in cases:
        assert expected == expand_abbreviations(template, abbreviations)

# Generated at 2022-06-23 16:26:15.954792
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_repo_directory = os.path.join(os.path.dirname(__file__), 'test')
    test_repo_directory_exists = os.path.isdir(test_repo_directory)

    test_repo_config_exists = os.path.isfile(
        os.path.join(test_repo_directory, 'cookiecutter.json')
    )
    assert test_repo_config_exists
    assert repository_has_cookiecutter_json(test_repo_directory)

# Generated at 2022-06-23 16:26:22.178408
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Check that if a given directory having a cookiecutter.json
    """
    cookiecutter_json_file = os.path.join(os.path.abspath(os.path.curdir), 'cookiecutter.json')
    assert repository_has_cookiecutter_json(os.path.abspath(os.path.curdir)) == True
    assert repository_has_cookiecutter_json(os.path.abspath(os.path.pardir)) == False

# Generated at 2022-06-23 16:26:31.837239
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = { 'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'gl': 'git@gitlab.com:{}.git',
    }
    assert expand_abbreviations('foo', abbreviations) == 'foo'
    assert expand_abbreviations('gh:foo', abbreviations) == 'https://github.com/foo.git'
    assert expand_abbreviations('bb:foo/bar', abbreviations) == 'https://bitbucket.org/foo/bar'
    assert expand_abbreviations('gl:foo/bar', abbreviations) == 'git@gitlab.com:foo/bar.git'

# Generated at 2022-06-23 16:26:41.770592
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('template/') == True
    assert repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage') == False
    assert repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage.git/master') == False
    assert repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage.git/master/') == True

# Generated at 2022-06-23 16:26:51.306521
# Unit test for function is_zip_file
def test_is_zip_file():
    """
    Test that the is_zip_file function works for different urls
    """
    assert is_zip_file('file.zip') == True
    assert is_zip_file('/Users/file.zip') == True
    assert is_zip_file('file.tar') == False
    assert is_zip_file('http://github.com/example/file.zip') == True
    assert is_zip_file('git@github.com:example/file.zip') == True
    assert is_zip_file('https://github.com/example/file.zip') == True
    assert is_zip_file('HTTPS://github.com/example/file.zip') == True
    assert is_zip_file('https://github.com/examp2le/file.zip.txt') == True



# Generated at 2022-06-23 16:27:01.630404
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'lh': 'https://{}.repositoryhosting.com/{}.git',
    }

    assert expand_abbreviations('pydanny/cookiecutter-django', abbreviations) == \
        'pydanny/cookiecutter-django'

    assert expand_abbreviations('gh:pydanny/cookiecutter-django', abbreviations) == \
        'https://github.com/pydanny/cookiecutter-django.git'


# Generated at 2022-06-23 16:27:08.762974
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/user/repo.git')
    assert is_repo_url('git@github.com:user/repo.git')
    assert is_repo_url('https://github.com/user/repo/')
    assert is_repo_url('https://username@bitbucket.org/user/repo.git')
    assert not is_repo_url('user/repo.git')
    assert not is_repo_url('/user/repo.git')
    assert not is_repo_url('/Users/audreyr/cookiecutters/pypackage')
    assert not is_repo_url('pypackage')

# Generated at 2022-06-23 16:27:15.620599
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {
        "ab": "abc",
        "abc": "def"
    }
    assert expand_abbreviations("ab", abbrevs) == "abc"
    assert expand_abbreviations("abc", abbrevs) == "def"
    assert expand_abbreviations("ab:{}".format("d"), abbrevs) == "abc:d"
    assert expand_abbreviations("ab:{}".format("de"), abbrevs) == "abc:de"

# Generated at 2022-06-23 16:27:21.280397
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations_dict = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations_dict) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:27:29.971712
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/tmp/random.zip')
    assert is_zip_file('file:///tmp/random.zip')
    assert not is_zip_file('git://github.com/foo/bar.git')
    assert not is_zip_file('https://github.com/foo/bar.git')
    assert not is_zip_file('git+ssh://github.com/foo/bar.git')
    assert not is_zip_file('foo/bar.git')
    assert not is_zip_file('foo@github.com/bar.git')
    assert not is_zip_file('https://github.com/foo/bar')
    assert not is_zip_file('https://github.com/foo/bar.gz')

# Generated at 2022-06-23 16:27:41.024236
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    # Short GitHub URL
    assert is_repo_url('audreyr/cookiecutter-pypackage')
    # With .git suffix
    assert is_repo_url('audreyr/cookiecutter-pypackage.git')
    # With .git suffix and no username
    assert is_repo_url('cookiecutter-pypackage.git')
    # With .git suffix, no username, and no git://
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage.git')
    # With .git suffix and git://

# Generated at 2022-06-23 16:27:49.352427
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True == is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert True == is_repo_url('https://github.com/audreyr')
    assert False == is_repo_url('https://github.com')
    assert False == is_repo_url('file://github.com')
    assert False == is_repo_url('git://github.com')
    assert False == is_repo_url('/Users')
    assert False == is_repo_url('/')
    assert False == is_repo_url('/Users/file')
    assert False == is_repo_url('Users/file')
    assert False == is_repo_url('Users')
    assert False == is_repo_url('Users/')

# Generated at 2022-06-23 16:27:55.130381
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'github': 'https://github.com/{}'}
    test_template = 'github:cookiecutter-django/cookiecutter-django'
    assert expand_abbreviations(test_template, abbreviations) == (
        'https://github.com/cookiecutter-django/cookiecutter-django'
    )

# Generated at 2022-06-23 16:28:06.684377
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert (
        expand_abbreviations("gh:audreyr/cookiecutter-pypackage", {"gh": "https://github.com/{0}.git"})
        == "https://github.com/audreyr/cookiecutter-pypackage.git"
    )

    assert expand_abbreviations("audreyr/cookiecutter-pypackage", {}) == "audreyr/cookiecutter-pypackage"

    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", {}) == "gh:audreyr/cookiecutter-pypackage"


# Generated at 2022-06-23 16:28:18.810936
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the is_repo_url function."""

    test_repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(test_repo_url)

    test_repo_url_2 = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(test_repo_url_2)

    test_repo_url_3 = 'https://github.com/audreyr/cookiecutter-pypackage'
    assert is_repo_url(test_repo_url_3)

    test_repo_url_4 = 'git://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:28:21.016822
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if the repository has a cookiecutter.json file."""
    assert repository_has_cookiecutter_json('.')


# Generated at 2022-06-23 16:28:28.075056
# Unit test for function is_zip_file
def test_is_zip_file():
    test_template = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    test_template_with_suffix = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master/xyz.zip'
    test_folder = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master/xyz'
    assert is_zip_file(test_template)
    assert is_zip_file(test_template_with_suffix)
    assert not is_zip_file(test_folder)

# Generated at 2022-06-23 16:28:34.716889
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test if determine_repo_dir function works as expected"""
    # Initialize variables
    template = "/tmp/template"
    abbreviations = {"template": template}
    clone_to_dir = "/tmp/clone_to_dir"
    checkout = "master"
    no_input = False
    password = None
    directory = None

    # Expected result: we expect the directory to be '/tmp/template', and
    # the cleanup variable to be False
    exp_directory, exp_cleanup = template, False

    # Get the directory and cleanup variable
    act_directory, act_cleanup = determine_repo_dir(template,
                                                    abbreviations,
                                                    clone_to_dir,
                                                    checkout,
                                                    no_input,
                                                    password,
                                                    directory)

    # Ass

# Generated at 2022-06-23 16:28:45.084258
# Unit test for function is_repo_url
def test_is_repo_url():
    value = 'git+https://github.com/pytest-dev/cookiecutter-pytest-plugin.git'
    assert is_repo_url(value) == True
    value = 'https://github.com/pytest-dev/cookiecutter-pytest-plugin.git'
    assert is_repo_url(value) == True
    value = 'git://github.com/pytest-dev/cookiecutter-pytest-plugin.git'
    assert is_repo_url(value) == True
    value = 'git@github.com:pytest-dev/cookiecutter-pytest-plugin.git'
    assert is_repo_url(value) == True
    value = 'git@github.com/pytest-dev/cookiecutter-pytest-plugin.git'
    assert is_repo

# Generated at 2022-06-23 16:28:51.047070
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'cc_full': 'gh:audreyr/cookiecutter-pypackage'
    }
    assert expand_abbreviations('cc_full', abbreviations) == \
        'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('cc_full:my_new_project', abbreviations) == \
        'gh:audreyr/cookiecutter-pypackage:my_new_project'
    assert expand_abbreviations('cc_full:my_new_project/foobar',
                                abbreviations) == \
        'gh:audreyr/cookiecutter-pypackage:my_new_project/foobar'

# Generated at 2022-06-23 16:28:52.128552
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    raise NotImplementedError


# Generated at 2022-06-23 16:28:58.873778
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import main

    if main.__name__ == '__main__':
        __package__ = "cookiecutter"
    else:
        __package__ = main.__name__

    print(__package__)

if __name__ == "__main__":
    test_repository_has_cookiecutter_json()

# Generated at 2022-06-23 16:28:59.987099
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test determine_repo_dir()
    pass

# Generated at 2022-06-23 16:29:03.962553
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') is True
    assert is_zip_file('test.zip.zip') is True
    assert is_zip_file('test.zip.json') is False
    assert is_zip_file('test.json') is False

# Generated at 2022-06-23 16:29:14.874326
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from cookiecutter import utils

    template = 'gh:audreyr/cookiecutter-pypackage'
    clone_to_dir = mkdtemp()
    expected_repo_path = os.path.join(clone_to_dir, 'cookiecutter-pypackage')

    # Test the happy path
    repo_path, cleanup = determine_repo_dir(
        template,
        abbreviations={},
        clone_to_dir=clone_to_dir,
        checkout=None,
        no_input=False,
    )

    # Test that the right repo is found
    assert repo_path == expected_repo_path
    # Test that the repo is cleaned up

# Generated at 2022-06-23 16:29:20.930324
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # determine_repo_dir(
    #     template,
    #     abbreviations,
    #     clone_to_dir,
    #     checkout,
    #     no_input,
    #     password=None,
    #     directory=None,
    # )
    # assert True
    # return True
    # os.path.join(repo_directory, 'cookiecutter.json')
    assert True

# Generated at 2022-06-23 16:29:21.689612
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-23 16:29:26.026808
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json,"""
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') is True
    assert repository_has_cookiecutter_json('./fake-repo-tmpl') is False
    assert repository_has_cookiecutter_json('/fake-repo-tmpl') is False

# Generated at 2022-06-23 16:29:29.566096
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template="~/my-repos/cookiecutter-pypackage",
        abbreviations={},
        clone_to_dir="~/my-repos/cc-repos",
        checkout=None,
        no_input=None,
        password=None,
    ) == ("~/my-repos/cookiecutter-pypackage", False)



# Generated at 2022-06-23 16:29:34.083442
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('file:///Users/x/y/cookiecutter-pypackage.git')

    assert not is_repo_url('/Users/x/y/cookiecutter-pypackage.git')
    assert not is_repo_url('cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:29:37.872440
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = os.getcwd()
    assert repository_has_cookiecutter_json(repo_directory) == True
    # Deceiving function in order to test the outcome
    repo_directorys = os.path.dirname(os.getcwd())
    assert repository_has_cookiecutter_json(repo_directorys) == False

# Generated at 2022-06-23 16:29:47.903020
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test repo URL matcher."""
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:29:52.314809
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Verify func behaves as expected."""
    assert not repository_has_cookiecutter_json('/tmp/testdir')
    assert not repository_has_cookiecutter_json('/tmp/testdir/cookiecutter.json')
    assert repository_has_cookiecutter_json('/tmp/testdir/cookiecutter.json')



# Generated at 2022-06-23 16:29:59.633789
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    clone_to_dir = '/tmp/cookiecutters'
    os.system('rm -rf {}'.format(clone_to_dir))
    repo_url = 'https://github.com/Anirudh-Das/cookiecutter-lambda'
    test_repository_candidates = [
        'tests/test-repo-tmpl',
        '{}/test-repo-tmpl'.format(clone_to_dir),
    ]
    repo_dir, cleanup = determine_repo_dir(
        repo_url,
        abbreviations={},
        clone_to_dir=clone_to_dir,
        checkout='master',
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir in test_repository_candidates
    assert cleanup

# Generated at 2022-06-23 16:30:06.108486
# Unit test for function is_zip_file
def test_is_zip_file():
    templates_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        'tests',
        'test-data',
        'templates',
    )
    zip_file = os.path.join(templates_dir, 'jquery.zip')
    assert(is_zip_file(zip_file) is True)

# Generated at 2022-06-23 16:30:15.960432
# Unit test for function is_repo_url
def test_is_repo_url():  # noqa: D103
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///home/username/cookiecutter-pypackage/')
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo

# Generated at 2022-06-23 16:30:17.920351
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert not is_zip_file('test.gif')

# Generated at 2022-06-23 16:30:21.461853
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/my_repo.git') is False
    assert is_zip_file('my_repo.git') is False
    assert is_zip_file('my_repo.zip') is True

# Generated at 2022-06-23 16:30:31.175789
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'lp': 'lp:{}',
        'ghu': 'https://{}@github.com/audreyr/cookiecutter-pypackage.git',
        'ghe': 'git@github.com:{}.git',
        'myfork': 'https://github.com/myname/{}.git',  # trailing slash
    }

    # With no abbreviation
    assert expand_abbreviations(
        'nope', abbreviations
    ) == 'nope'

    # With abbreviation

# Generated at 2022-06-23 16:30:41.675828
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print(determine_repo_dir(
        template='rabbit',
        abbreviations={},
        clone_to_dir='/',
        checkout=None,
        no_input=False
    ))
    print(determine_repo_dir(
        template='rabbit',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False
    ))
    print(determine_repo_dir(
        template='https://github.com/flamme/cookiecutter-rabbit.git',
        abbreviations={},
        clone_to_dir='.',
        checkout=None,
        no_input=False
    ))



# Generated at 2022-06-23 16:30:44.994222
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('a.zip') == True
    assert is_zip_file('a.zip.bak') == True
    assert is_zip_file('a.bak.zip') == True
    assert is_zip_file('a.zip.bak.zip') == True
    assert is_zip_file('a.tar.gz') == False
    assert is_zip_file('a.bak') == False


# Generated at 2022-06-23 16:30:52.497291
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('/home/foo/Projects/example-repo') == False
    assert is_repo_url('example-repo') == False
    assert is_repo_url('../example-repo') == False
    assert is_repo_url('example-repo/') == False
    assert is_repo_url('example_repo') == False

# Generated at 2022-06-23 16:31:02.519121
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(None) == False
    assert repository_has_cookiecutter_json('12345') == False
    assert repository_has_cookiecutter_json(
        os.path.expanduser('~/.cookiecutters')
    ) == True
    assert repository_has_cookiecutter_json(
        os.path.join(os.path.expanduser('~/.cookiecutters'), 'configs')
    ) == True
    assert os.path.exists(os.path.expanduser('~/.cookiecutters/configs')) == 1
    assert repository_has_cookiecutter_json(
        os.path.join(os.path.expanduser('~/.cookiecutters'), 'configs_new')
    ) == False

# Generated at 2022-06-23 16:31:04.415802
# Unit test for function is_zip_file
def test_is_zip_file():
    """ test for function is_zip_file """
    assert is_zip_file('template.zip') == True
    return

# Generated at 2022-06-23 16:31:15.878081
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for the determine_repo_dir() function."""
    class MockRepository(object):
        def __init__(self):
            self.repo_dir = 'foo'

        def __enter__(self):
            return self.repo_dir

        def __exit__(sef, exc_type, exc_val, exc_tb):
            pass


    class MockVCS(object):
        def __init__(self, repo_url, clone_to_dir):
            self.repo_url = repo_url
            self.clone_to_dir = clone_to_dir
            self.checkout = None

        def __enter__(self):
            return MockRepository()

        def __exit__(self, exc_type, exc_value, tb):
            pass



# Generated at 2022-06-23 16:31:17.567215
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('/cookiecutter-demo') == False

# Generated at 2022-06-23 16:31:22.926219
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-pytest.zip')
    assert is_zip_file('tests/files/cookiecutter-pytest.zip')
    assert not is_zip_file('cookiecutter-pytest.tar.gz')
    assert not is_zip_file('cookiecutter-pytest')
    assert not is_zip_file('cookiecutter-pytest.git')

# Generated at 2022-06-23 16:31:28.593116
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("test/test-repo-tmpl") == True
    assert repository_has_cookiecutter_json("test/test-repo-tmpl-no-cookiecutter-json") == False
    assert repository_has_cookiecutter_json("test/test-repo-tmpl/hooks") == True
    assert repository_has_cookiecutter_json("test/test-repo-tmpl-no-hooks") == False


# Generated at 2022-06-23 16:31:36.003223
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test for is_repo_url."""
    # Test all valid URLs
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url(
        'hg+https://bitbucket.org/pokoli/cookiecutter-skeleton'
    )
    assert is_repo_url('file:///home/user/cookiecutter-example')

# Generated at 2022-06-23 16:31:47.361678
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:31:52.450413
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from tests.test_repositories import template_folder

    repo_directory = template_folder()
    repo_directory_exists = os.path.isdir(repo_directory)
    repo_config_exists = os.path.isfile(
        os.path.join(repo_directory, 'cookiecutter.json')
    )

    assert repo_directory_exists and repo_config_exists

# Generated at 2022-06-23 16:31:56.484447
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Return True if the candidate directory contains a `cookiecutter.json` file.
    """
    # Valid
    assert repository_has_cookiecutter_json('tests/fake-repo-template')
    # Directory path doesn't exist
    assert not repository_has_cookiecutter_json('fake-repo-template')
    # Directory does exist but it doesn't have a cookiecutter.json
    assert not repository_has_cookiecutter_json('tests')

# Generated at 2022-06-23 16:32:02.263341
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-django.zip')
    assert is_zip_file('~/cookicutter-django.zip')
    assert is_zip_file('~/path/to/cookiecutter-django.zip')
    assert is_zip_file('https://github.com/wdm0006/cookiecutter-django/archive/master.zip')

    assert not is_zip_file('https://github.com/wdm0006/cookiecutter-django/master')



# Generated at 2022-06-23 16:32:08.405373
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function is_zip_file()."""
    # Standard case
    assert(is_zip_file('myzip.zip') == True)
    # Case-insensitive
    assert(is_zip_file('myzip.ZIP') == True)
    # Wrong extension
    assert(is_zip_file('myzip.tar') == False)
    # Name without extension
    assert(is_zip_file('myfile') == False)

# Generated at 2022-06-23 16:32:09.831369
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert(True == repository_has_cookiecutter_json('tests/fake-repo-pre/'))
    assert(False == repository_has_cookiecutter_json('tests/fake-repo-pre'))

# Generated at 2022-06-23 16:32:12.452051
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = '../cookiecutter-django'
    assert repository_has_cookiecutter_json(repo_directory) == True



# Generated at 2022-06-23 16:32:15.293876
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/example-cookiecutter-repo')

# Generated at 2022-06-23 16:32:18.481850
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json"""
    return repository_has_cookiecutter_json("../tests/fake-repo-tmpl") == True

# Generated at 2022-06-23 16:32:27.637337
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json"""

    passing_test_cases = [
        ('https://github.com/audreyr/cookiecutter-pypackage.git',),
        ('/Users/audreyr/Documents/git/cookiecutter-pypackage',),
    ]

    failure_test_cases = [
        ('/Users/audreyr/Documents/git/cookiecutter-pypackage-missing-cookiecutter.json',),
    ]

    for case in passing_test_cases:
        assert repository_has_cookiecutter_json(case[0]) is True

    for case in failure_test_cases:
        assert repository_has_cookiecutter_json(case[0]) is False


# Generated at 2022-06-23 16:32:36.855609
# Unit test for function expand_abbreviations
def test_expand_abbreviations():

    assert(expand_abbreviations('gh:audreyr',{'gh': 'https://github.com/{}'}) ==
            'https://github.com/audreyr')
    assert(expand_abbreviations('bitbucket.org/pokoli/cookiecutter-tryton',{}) ==
            'bitbucket.org/pokoli/cookiecutter-tryton')
    assert(expand_abbreviations('gh',{'gh': 'https://github.com/{}'}) ==
            'https://github.com/{}')

# Generated at 2022-06-23 16:32:41.737435
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Assert if a repository has a cookiecutter.json file.
    """
    Repo_Dir = '/tmp/cookiecutter/tests/fixtures/fake-repo/'
    assert repository_has_cookiecutter_json(Repo_Dir) == True

# Generated at 2022-06-23 16:32:50.023205
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    
    # Test abbreviations
    abbreviations = {"starters":"https://github.com/rmorgan10/template/starters:{}"}
    name, cleanup = determine_repo_dir(
        template="starters:cookiecutter-master",
        abbreviations=abbreviations,
        clone_to_dir=".",
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert(name == "https://github.com/rmorgan10/template/starters:cookiecutter-master")
    assert(cleanup == False)

    # Test zip file

# Generated at 2022-06-23 16:32:54.312950
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('nasty_project.zip')
    assert not is_zip_file('nasty_project.dev')
    assert not is_zip_file('nasty_proj.ect.zip')
    assert not is_zip_file('nasty_proj.ect.zip.zip')

# Generated at 2022-06-23 16:32:57.965568
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip')
    assert is_zip_file('foo.ZiP')
    assert not is_zip_file('foo.bar')

# Generated at 2022-06-23 16:33:07.638590
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil
    from cookiecutter import config, utils
    from cookiecutter.exceptions import InvalidModeException
    from cookiecutter.repository import (
        REPO_REGEX,
        expand_abbreviations,
        is_repo_url,
        is_zip_file,
        repository_has_cookiecutter_json,
    )

    def test_repo_url(url):
        assert REPO_REGEX.match(url) is not None

    def test_not_repo_url(url):
        assert REPO_REGEX.match(url) is None

    HERE = os.path.abspath(os.path.dirname(__file__))
    EXAMPLE_REPO = os.path.join(HERE, 'test-repo-tmpl')
    US

# Generated at 2022-06-23 16:33:19.186984
# Unit test for function is_repo_url
def test_is_repo_url():
    # hack to figure out the dir we are running in
    # or not, if we are running python setup.py test
    local_dir = os.path.dirname(os.path.realpath(__file__))
