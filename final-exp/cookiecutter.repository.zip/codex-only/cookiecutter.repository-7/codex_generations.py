

# Generated at 2022-06-23 16:23:26.032537
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'did': 'dir:///absolute/path/to/{}',
        'drel': 'dir://relative/path/to/{}'
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:jhermann/cookiecutter-flask', abbreviations) == 'https://bitbucket.org/jhermann/cookiecutter-flask.git'
    assert expand_abbreviations('did:some_template_dir', abbreviations)

# Generated at 2022-06-23 16:23:32.566166
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'


# Generated at 2022-06-23 16:23:34.701213
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert not is_zip_file('test.not.zip')

# Generated at 2022-06-23 16:23:40.211534
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') is True
    assert is_zip_file('foo.ZIP') is True
    assert is_zip_file('foo.bar.zip') is True
    assert is_zip_file('foo.bar.ZIP') is True
    assert is_zip_file('foo.bar') is False
    assert is_zip_file('foo') is False

# Generated at 2022-06-23 16:23:46.922185
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='tests/fake-repo-tmpl',
        checkout=None,
        no_input=True,
        password=None,
        directory=None
    ) == ('tests/fake-repo-tmpl/cookiecutter-pypackage', False)

# Generated at 2022-06-23 16:23:52.953997
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test if repository URL (regex) is recognized as a URL."""
    assert is_repo_url('git://repo.git')
    assert is_repo_url('git+ssh://repo.git')
    assert is_repo_url('git+https://repo.git')
    assert is_repo_url('user@server:path')

# Generated at 2022-06-23 16:23:56.966564
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify that is_repo_url can identify a repo url."""
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage'
    assert is_repo_url(repo_url) == True



# Generated at 2022-06-23 16:24:02.106017
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('hello.zip') is True
    assert is_zip_file('hello.ZIP') is True
    assert is_zip_file('hello.ZiP') is True
    assert is_zip_file('hello.ZIP.tar') is False
    assert is_zip_file('/path/2/hello.zip') is True

# Generated at 2022-06-23 16:24:07.767256
# Unit test for function is_zip_file
def test_is_zip_file():
    """ Test is_zip_file function. """

    fake_files = [
        "example.json",
        "example.xlsx",
        "example.txt",
        "example.zip"
    ]

    assert is_zip_file(fake_files[3])
    assert not is_zip_file(fake_files[1])
    assert not is_zip_file(fake_files[0])


# Generated at 2022-06-23 16:24:19.525109
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git',
    }

# Generated at 2022-06-23 16:24:29.049677
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://gitlab.com/pycqa/flake8.git')
    assert is_repo_url('https://github.com/hackebrot/pytest-tldr.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@gitlab.com:pycqa/flake8.git')
    assert is_repo_url('git@github.com:hackebrot/pytest-tldr.git')
    assert is_repo_url('file:///home/me/cookiecutters')

# Generated at 2022-06-23 16:24:41.438214
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bitbucket': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('pydanny/cookiecutter-django', abbreviations) == 'pydanny/cookiecutter-django'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:pydanny/cookiecutter-django', abbreviations) == 'https://github.com/pydanny/cookiecutter-django.git'

# Generated at 2022-06-23 16:24:44.672468
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') == True
    assert is_zip_file('foo.tar.gz') == False

# Generated at 2022-06-23 16:24:45.292509
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    pass

# Generated at 2022-06-23 16:24:51.176469
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('foo', {}, 'clone_to_dir', 'checkout', True) == ('foo', False)
    assert determine_repo_dir('foo:bar', {'foo': 'baz'}, 'clone_to_dir', 'checkout', True) == ('baz:bar', False)
    assert determine_repo_dir('foo.zip', {}, 'clone_to_dir', 'checkout', True, password='password') == ('unzipped foo', True)
    assert determine_repo_dir('https://example.com/foo.git', {}, 'clone_to_dir', 'checkout', True) == ('clone_to_dir/foo', False)

# Generated at 2022-06-23 16:24:54.663204
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Should return true if cookiecutter.json exists in a directory."""
    repository_candidate = 'fake_cookiecutter_repo/'
    assert repository_has_cookiecutter_json(repository_candidate)

# Generated at 2022-06-23 16:25:03.451290
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test is_repo_url function.
    """
    # test if it works on correct inputs
    assert(is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git"))
    assert(is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git"))
    assert(is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git"))
    assert(is_repo_url("https://github.com/audreyr/cookiecutter-pypackage"))
    assert(is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git#egg=cookiecutter"))

# Generated at 2022-06-23 16:25:08.782580
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    with open('cookiecutter.json', 'w') as f:
        f.write('{}')
    try:
        assert repository_has_cookiecutter_json(os.getcwd())
        assert not repository_has_cookiecutter_json('/tmp/')
    finally:
        os.remove('cookiecutter.json')

# Generated at 2022-06-23 16:25:18.304705
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/talwrii/cookiecutter-demo-template"
    shortcuts = {
        "demo": "https://github.com/talwrii/cookiecutter-demo-template"
    }
    clone_dir = "d:/"
    result = determine_repo_dir(template, shortcuts, clone_dir, "master", False)
    assert "d:/cookiecutter-demo-templat" in result[0] and not result[1]

    template = "d:/cookiecutter-demo-templat"
    result = determine_repo_dir(template, shortcuts, clone_dir, "master", False)
    assert "d:/cookiecutter-demo-templat" in result[0] and not result[1]

    template = "demo"

# Generated at 2022-06-23 16:25:23.729761
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test for the is_zip_file function."""
    assert is_zip_file('test.zip')
    assert is_zip_file('test.zIp')
    assert not is_zip_file('testzip')
    assert not is_zip_file('test.z i p')

# Generated at 2022-06-23 16:25:33.541360
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/0.1.2.zip')
    assert is_zip_file('foo.zip')
    assert is_zip_file('./foo.zip')
    assert is_zip_file('.\\foo.zip')
    assert is_zip_file('cookiecutter-foo.zip')
    assert not is_zip_file('foo.ZIP')
    assert not is_zip_file('foo.ZiP')
    assert not is_zip_file('foo.ZIP.rar')
    assert not is_zip_file('foo.rar')
    assert not is_zip_file('foo.ZIP.bz2')
    assert not is_zip_file('foo.bz2')

# Generated at 2022-06-23 16:25:34.743042
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test_test.zip") == True




# Generated at 2022-06-23 16:25:38.980880
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter.zip')
    assert is_zip_file('https://github.com/d0ugal/cookiecutter-pypackage/archive/0.1.3.zip')
    assert not is_zip_file('https://github.com/d0ugal/cookiecutter-pypackage/archive/0.1.3.zip/extra-path')
    assert not is_zip_file('cookiecutter.json')

# Generated at 2022-06-23 16:25:46.438216
# Unit test for function is_repo_url
def test_is_repo_url():
    url_candidates = {
        "https://github.com/audreyr/cookiecutter-pypackage": True,
        "git@github.com/audreyr/cookiecutter-pypackage.git": True,
        "/Users/audreyr/projects/cookiecutter-pypackage/": False,
    }

    for url, expected_result in url_candidates.items():
        result = is_repo_url(url)
        assert result == expected_result

# Generated at 2022-06-23 16:25:48.792344
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/Users/audrey/foo/bar.zip')
    assert is_zip_file('http://github.com/foo/bar.zip')

# Generated at 2022-06-23 16:25:58.156890
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function"""
    # test is_repo_url
    assert is_repo_url('file:///home/foo/code/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')

    # test expand_abbreviations
    abbreviations = {'gh': 'https://github.com/{}.git'}

# Generated at 2022-06-23 16:25:59.937496
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """ Test to ensure repository_has_cookiecutter_json works. """
    from cookiecutter import utils

    repo_dir = utils.repository_has_cookiecutter_json('../tests/fake-repo-pre/')
    assert repo_dir is True

# Generated at 2022-06-23 16:26:03.072265
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('/foo/bar') == False
    assert repository_has_cookiecutter_json('/foo/bar/cookiecutter.json') == False
    assert repository_has_cookiecutter_json('./cookiecutter/data') == True

# Generated at 2022-06-23 16:26:03.569290
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-23 16:26:09.357533
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file = "./cookiecutter-pypackage.zip"
    fake_zip_file = "./.DS_Store"
    assert is_zip_file(zip_file) is True
    assert is_zip_file(fake_zip_file) is False


# Generated at 2022-06-23 16:26:19.725667
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test a regex for matching repo URLs."""

# Generated at 2022-06-23 16:26:25.106534
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/zipball/master')
    assert not is_zip_file('jacebrowning/template-pack')
    assert not is_zip_file('jacebrowning/template-pack.git')
    assert not is_zip_file('jacebrowning/template-pack.zip/master')

# Generated at 2022-06-23 16:26:36.440333
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("https://github.com/wizardsoftheweb/cookiecutter-vagrant-puppet/raw/master/dist/cookiecutter-vagrant-puppet-1.0.0.zip") == True
    assert is_zip_file("https://github.com/wizardsoftheweb/cookiecutter-vagrant-puppet/raw/master/dist/cookiecutter-vagrant-puppet-1.0.0") == False
    assert is_zip_file("/var/lib/jenkins/workspace/cookiecutter-vagrant-puppet/dist/cookiecutter-vagrant-puppet-1.0.0.zip") == True

# Generated at 2022-06-23 16:26:48.138888
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    class TestAbbreviations(object):

        def __init__(self):
            self.abbreviations = {"gh": "https://github.com/{}.git"}

        def test_unknown_abbreviation(self):
            template = "rawr"
            result = expand_abbreviations(template, self.abbreviations)
            assert template == result, "should return original"

        def test_expansion_with_abbreviation(self):
            template = "gh:audreyr/cookiecutter-pypackage"
            result = expand_abbreviations(template, self.abbreviations)
            expected = "https://github.com/audreyr/cookiecutter-pypackage.git"
            assert result == expected, "should expand abbreviation"

# Generated at 2022-06-23 16:26:57.476064
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {}) == 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh', abbreviations) == 'https://github.com/gh.git'
    assert expand_abbreviations('gh', {}) == 'gh'

# Generated at 2022-06-23 16:27:06.892999
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test to see if the various type of repo URL are detected."""
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:27:13.420592
# Unit test for function is_zip_file
def test_is_zip_file():
    """
    Verify that function is_zip_file
    correctly detects zip files.
    """
    tests = [
        "foo.zip",
        "bar.zip.bar",
        "foo/bar.zip",
        "foo/bar.zip/foo",
        "bar.zip/foo",
    ]
    for test in tests:
        assert is_zip_file(test)


# Generated at 2022-06-23 16:27:20.311936
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:27:26.112179
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('pypackage', {'pypackage': 'caktus/pypackage-cookiecutter'}) == 'caktus/pypackage-cookiecutter'
    assert expand_abbreviations('pypackage:1.9', {'pypackage': 'caktus/pypackage-cookiecutter'}) == 'caktus/pypackage-cookiecutter:1.9'

# Generated at 2022-06-23 16:27:32.769042
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function"""
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp('test_determine_repo_dir')

    # Create fake repo
    fake_repo = os.path.join(temp_dir, 'fake_repo')
    shutil.copytree(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'test_repo_templates',
            'fake_repo'
        ),
        os.path.join(temp_dir, 'fake_repo')
    )

    # Create fake zip

# Generated at 2022-06-23 16:27:45.354218
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Correct expansions of abbreviations
    template_abbrev1_correct = 'test-project'
    abbreviations = {'tp': 'test-project'}
    template = 'tp'
    template_new = expand_abbreviations(template, abbreviations)
    assert template_new == template_abbrev1_correct

    template_abbrev2_correct = 'cookiecutter-pypackage'
    abbreviations = {'pp': 'cookiecutter-pypackage'}
    template = 'pp'
    template_new = expand_abbreviations(template, abbreviations)
    assert template_new == template_abbrev2_correct

    template_abbrev3_correct = 'cookiecutter-djangopackage:custom'

# Generated at 2022-06-23 16:27:47.057424
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('.')

# Generated at 2022-06-23 16:27:58.225842
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{0}.git'}
    assert expand_abbreviations(template, abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {}
    assert expand_abbreviations(template, abbreviations) == 'gh:audreyr/cookiecutter-pypackage'

    template = 'audreyr/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{0}.git'}

# Generated at 2022-06-23 16:28:07.000722
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine repo dir function."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'clonedir'
    checkout = ''
    no_input = True
    password = ''
    directory = ''
    clean_repo, clean_up = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert clean_repo.startswith(clone_to_dir)

# Generated at 2022-06-23 16:28:18.852294
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """This test only covers the simplest cases. More test cases are needed."""
    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
    }
    clone_to_dir = 'dummy-directory-name'
    checkout = 'develop'
    no_input = False
    password = None
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    assert repo_dir, 'dummy-directory-name/audreyr/cookiecutter-pypackage'
    assert not cleanup

# Generated at 2022-06-23 16:28:22.648000
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' in determine_repo_dir('pypackage', {'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage.git'}, '.', None, False)

# Generated at 2022-06-23 16:28:25.805224
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test if the function returned the right result
    """
    assert repository_has_cookiecutter_json("C:\\Users\\Gedson\\.cookiecutters")


# Generated at 2022-06-23 16:28:36.042309
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test the function expand_abbreviations."""
    test_abbreviations = {'cc': 'https://github.com/audreyr/cookiecutter-pypackage'}
    assert expand_abbreviations('cc', test_abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'
    test_abbreviations = {'gh:owner': 'https://github.com/{}/cookiecutter-project'}
    assert expand_abbreviations('gh:owner', test_abbreviations) == 'https://github.com/{}/cookiecutter-project'
    assert expand_abbreviations('cc', test_abbreviations) == 'cc'

# Generated at 2022-06-23 16:28:46.088942
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test is_repo_url()."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:28:50.626274
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test for function expand_abbreviations."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'default': 'https://github.com/{}',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    exp_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == exp_template



# Generated at 2022-06-23 16:29:03.387797
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')

    assert not is_repo_url('something/that/looks/like/a/path/to/a/project')
    assert not is_repo_url('/an/absolute/path/to/a/project')
    assert not is_repo_url('../relative/path/to/a/project')
    assert not is_repo_url('C:\\Windows\\path\\to\\a\\project')

# Generated at 2022-06-23 16:29:14.672634
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json function."""
    import tempfile
    import shutil
    import filecmp

    # create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # copy the template repository to the temporary directory
    cookiecutter_json_directory = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl',
    )
    shutil.copytree(cookiecutter_json_directory, temp_dir)
    cookiecutter_json_path = os.path.join(temp_dir, 'cookiecutter.json')
    assert os.path.exists(cookiecutter_json_path) is True
    assert repository_has_cookiecutter

# Generated at 2022-06-23 16:29:25.266659
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghu': 'https://{}@github.com/{}.git',
        'bbu': 'git@bitbucket.org:{}.git',
        'lp': 'https://git.launchpad.net/{}.git',
    }

    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbrevi

# Generated at 2022-06-23 16:29:32.751290
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}/archive/master.zip'
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    correct_template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    assert expanded_template == correct_template

# Generated at 2022-06-23 16:29:41.842133
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    # Expect false if directory doesn't exist
    directory = r'C:\not-exist\test'
    result = repository_has_cookiecutter_json(directory)
    assert not result

    # Expect false if directory exists but it doesn't contain cookiecutter.json
    directory = r'C:\not-exist'
    if not os.path.isdir(directory):
        os.mkdir(directory)
    result = repository_has_cookiecutter_json(directory)
    assert not result

    # Expect true if directory exists and it does contain cookiecutter.json
    directory = r'C:\not-exist'
    if not os.path.isdir(directory):
        os.mkdir(directory)
    f = open(directory + "\\cookiecutter.json", "w+")
    f.close()
    result = repository

# Generated at 2022-06-23 16:29:49.713451
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Test abbreviation
    template = 'py'
    abbreviations = {
        'py': 'https://github.com/audreyr/cookiecutter-pypackage.git',
    }
    template_expanded = expand_abbreviations(template, abbreviations)
    assert template_expanded == 'https://github.com/audreyr/cookiecutter-pypackage.git', "expand_abbreviation failed when expanding an abbreviation"

    # Test advanced abbreviation
    template = 'gh+py'
    abbreviations = {
        'py': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'gh+': 'https://github.com/',
    }
    template_expanded = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-23 16:29:52.083394
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/tmp/template.zip')
    assert not is_zip_file('/tmp/template.txt')

# Generated at 2022-06-23 16:29:59.609681
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:30:09.114840
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }
    assert expand_abbreviations('foo', abbrevs) == 'foo'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbrevs) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:cowboy/dotfiles', abbrevs) == 'https://bitbucket.org/cowboy/dotfiles.git'

# Generated at 2022-06-23 16:30:11.264993
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('example.zip') == True


# Generated at 2022-06-23 16:30:18.297407
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations_test = {"git": "git+https://github.com/{}.git",
                          "gh": "git+https://github.com/{}.git"}
    assert(expand_abbreviations("git:owner/repo", abbreviations_test)
           == "git+https://github.com/owner/repo.git")
    assert(expand_abbreviations("gh:owner/repo", abbreviations_test)
           == "git+https://github.com/owner/repo.git")
    assert(expand_abbreviations("owner/repo", abbreviations_test)
           == "owner/repo")


## Backwards compatibility for pre-1.5.0
# TODO: Remove in version 2.0

# Generated at 2022-06-23 16:30:21.107345
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = "/Users/me/github/cookiecutter/cookiecutter-pypackage"
    assert repository_has_cookiecutter_json(repo_directory)

# Generated at 2022-06-23 16:30:30.841091
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage') is True
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') is True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage') is True

# Generated at 2022-06-23 16:30:34.182263
# Unit test for function is_zip_file
def test_is_zip_file():
    for example in ['cookiecutter-example.zip', 'example.zip']:
        assert is_zip_file(example) == True

    for example in ['cookiecutter-example.tar.gz', 'example.txt']:
        assert is_zip_file(example) == False



# Generated at 2022-06-23 16:30:37.981434
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Tests if repository_has_cookiecutter_json correctly determines if a repo
    contains a valid cookiecutter.json
    """
    # Invalid directories
    invalid_directories = [
        '/not/a/real/directory',
        '/not/a/real/directory/',
        '.',
    ]
    for invalid_dir in invalid_directories:
        assert repository_has_cookiecutter_json(invalid_dir) is False


# Generated at 2022-06-23 16:30:43.678207
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert 'https://github.com/audreyr.git' == expand_abbreviations('gh:audreyr', abbreviations)
    assert '.' == expand_abbreviations('.', abbreviations)
    assert 'gh:audreyr' == expand_abbreviations('gh:audreyr', {})

# Generated at 2022-06-23 16:30:50.436031
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that we can find cookiecutter.json in the right places."""
    import os
    import pytest
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as temp_dir:
        # Make some directories with cookiecutter.json
        cc_json_dirs = [
            temp_dir,
            os.path.join(temp_dir, 'first_level_dir'),
            os.path.join(temp_dir, 'first_level_dir', 'second_level_dir')
        ]

        for cc_json_dir in cc_json_dirs:
            os.makedirs(cc_json_dir)
            with open(os.path.join(cc_json_dir, 'cookiecutter.json'), 'w') as f:
                f.write('Test file\n')

# Generated at 2022-06-23 16:31:00.524134
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('a.zip') == True
    assert is_zip_file('a.tar.gz') == False
    assert is_zip_file('a.tar.bz2') == False
    assert is_zip_file('a.tgz') == False
    assert is_zip_file('a.tar') == False
    assert is_zip_file('z.zip') == True
    assert is_zip_file('A.ZIP') == True
    assert is_zip_file('a.ZIP') == True
    assert is_zip_file('a.tar.gz.zip') == True
    assert is_zip_file('/some/path/a.zip') == True
    assert is_zip_file('http://some.url/a.zip') == True

# Generated at 2022-06-23 16:31:11.205881
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test that abbreviations are properly expanded.
    """
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert 'gh:audreyr/cookiecutter-pypackage' == \
        expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == \
        expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)

# Generated at 2022-06-23 16:31:20.838288
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    exists_true = os.path.exists("./tests/fake-repo-tmpl")
    assert exists_true
    isdir_true = os.path.isdir("./tests/fake-repo-tmpl")
    assert isdir_true
    isfile_true = os.path.isfile("./tests/fake-repo-tmpl/cookiecutter.json")
    assert isfile_true
    result_true = repository_has_cookiecutter_json(
        "./tests/fake-repo-tmpl"
    )
    assert result_true
    exists_false = os.path.exists("./tests/fake-repo-tmpl-no-json")
    assert exists_false

# Generated at 2022-06-23 16:31:24.736761
# Unit test for function is_zip_file
def test_is_zip_file():
    assert not is_zip_file('../')
    assert is_zip_file('../xx.zip')
    assert is_zip_file('https://github.com/me/aaa.zip')
    assert is_zip_file('file:///home/me/aaa.zip')
    assert is_zip_file('ssh://github.com/me/aaa.zip')
    assert not is_zip_file('https://github.com/me/aaaa')


# Generated at 2022-06-23 16:31:25.295794
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    pass

# Generated at 2022-06-23 16:31:30.720031
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Initialise variables
    template = 'https://github.com/mjschmidt/cookiecutter-python'
    abbreviations = {}
    directory = ''
    clone_to_dir = 'C:/Users/Michael/Desktop/cookiecutter-project/'
    checkout = ''
    no_input = ''

    # Function under test
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, directory, clone_to_dir, checkout, no_input)

    # Check results
    print(repo_dir)
    print(cleanup)



# Generated at 2022-06-23 16:31:41.319170
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {"gh": "https://github.com/{}.git",
                     "bb": "https://bitbucket.org/{}.git"}
    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage",
                                abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"
    assert expand_abbreviations("bb:pokoli/cookiecutter-skeleton",
                                abbreviations) == "https://bitbucket.org/pokoli/cookiecutter-skeleton.git"
    assert expand_abbreviations("audreyr/cookiecutter-pypackage",
                                abbreviations) == "audreyr/cookiecutter-pypackage"

# Generated at 2022-06-23 16:31:50.731986
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    '''
    To test the function determine_repo_dir
    '''
    template = "https://github.com/github/gitignore"
    abbreviations = {}
    clone_to_dir = "/tmp"
    checkout = None
    no_input = 0
    expected_result = "/tmp/github-gitignore"
    actual_result, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
    )

# Generated at 2022-06-23 16:32:01.809295
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/fake') == False
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/fake/') == False
    assert repository_has_cookiecutter_json('fake') == False
    assert repository_has_cookiecutter_json

# Generated at 2022-06-23 16:32:07.382599
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('.')
    assert repository_has_cookiecutter_json(
        './tests/test-templates/cookiecutter-pypackage'
    )
    assert not repository_has_cookiecutter_json('./tests/not-a-valid-repo')


# Unit tests for function expand_abbreviations

# Generated at 2022-06-23 16:32:15.859418
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify that is_repo_url returns correct values."""
    assert not is_repo_url('')
    assert not is_repo_url('http://github.com/')
    assert not is_repo_url('https://github.com/')
    assert not is_repo_url('http://github.com/audreyr/cookiecutter.git')
    assert not is_repo_url('https://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter.git')
    assert is_repo_url(
        'git://github.com/audreyr/cookiecutter-pypackage.git'
    )

# Generated at 2022-06-23 16:32:18.042583
# Unit test for function is_zip_file
def test_is_zip_file():
    value = "./cookiecutter-django/tests/test-repo-pre/foobar.zip"
    output = is_zip_file(value)
    assert output == True


# Generated at 2022-06-23 16:32:19.676293
# Unit test for function repository_has_cookiecutter_json

# Generated at 2022-06-23 16:32:21.938512
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    result = repository_has_cookiecutter_json("/home/yogesh/mint/cookiecutter-pypackage-minimal/")
    assert result

# Generated at 2022-06-23 16:32:32.589320
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    clone_to_dir = '/Users/audreyr/cookiecutters'
    checkout = None
    no_input = False
    directory = "tests/fake-repo-pre/{{cookiecutter.project_slug}}"
    abbreviations = {'gh': 'https://github.com/{}'}

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        directory=directory
    )
    
    assert repo_dir == template
    assert cleanup == False
    assert os.path.exists(repo_dir)

# Generated at 2022-06-23 16:32:42.040230
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/cookiecutter-djangopackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/Users/audreyr/.cookiecutters/cookiecutter-pypackage')

# Generated at 2022-06-23 16:32:44.548502
# Unit test for function is_zip_file
def test_is_zip_file():
    test = 'cookiecutter-foobar'
    result = is_zip_file(test)
    assert result is True, "Is zip file: %s" % result

# Generated at 2022-06-23 16:32:55.969333
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
  abbreviations = {
      'gh': 'https://github.com/{}.git',
      'bb': 'https://bitbucket.org/{}.git',
  }
  assert expand_abbreviations('account/repo', abbreviations) == 'account/repo'
  assert expand_abbreviations('gh:account/repo', abbreviations) == 'https://github.com/account/repo.git'
  assert expand_abbreviations('bb:account/repo', abbreviations) == 'https://bitbucket.org/account/repo.git'
  assert expand_abbreviations('gh:account/repo:tag', abbreviations) == 'https://github.com/account/repo.git:tag'

# Generated at 2022-06-23 16:33:06.847252
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:33:10.111391
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/test-repo-tmpl')
    assert not repository_has_cookiecutter_json('tests/fake-repo-tmpl')

# Generated at 2022-06-23 16:33:12.661982
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip')
    assert is_zip_file('foo') is False
    assert is_zip_file('foo.bar') is False

# Generated at 2022-06-23 16:33:21.967289
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'github': 'https://github.com/{}',
        'gh': 'https://github.com/{}',
        'bitbucket': 'https://bitbucket.com/{}',
        'bb': 'https://bitbucket.com/{}',
    }
    assert expand_abbreviations('github:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'