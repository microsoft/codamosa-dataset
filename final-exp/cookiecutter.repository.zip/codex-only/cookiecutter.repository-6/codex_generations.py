

# Generated at 2022-06-23 16:23:21.093365
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    dir_name = 'tests/fake-repo-tmpl'
    assert repository_has_cookiecutter_json(dir_name)

    dir_name = 'tests/fake-repo-pre/'
    assert repository_has_cookiecutter_json(dir_name)

# Generated at 2022-06-23 16:23:25.552624
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test is_zip_file function."""
    assert is_zip_file('foobar.zip')
    assert not is_zip_file('foobar.tar.gz')
    assert not is_zip_file('foobar.txt')
    assert not is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git')



# Generated at 2022-06-23 16:23:36.056210
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test expand_abbreviations
    """
    abbrevs = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    template = 'account/repo'
    out = expand_abbreviations(template, abbrevs)
    assert template == out

    template = 'gh:account/repo'
    out = expand_abbreviations(template, abbrevs)
    assert 'https://github.com/account/repo.git' == out

    template = 'gh:account/repo:tags/0.1'
    out = expand_abbreviations(template, abbrevs)
    assert 'https://github.com/account/repo/tags/0.1' == out


# Generated at 2022-06-23 16:23:44.934307
# Unit test for function is_repo_url
def test_is_repo_url():
    urls = [
        "https://github.com/user/testrepo.git",
        "git@github.com/user/testrepo.git",
        "git+https://github.com/user/testrepo.git",
        "git+ssh://github.com/user/testrepo.git",
        "ssh://github.com/user/testrepo.git",
        "file:///home/user/testrepo.git",
        "git://github.com/user/testrepo.git",
    ]
    for url in urls:
        assert is_repo_url(url)


# Generated at 2022-06-23 16:23:53.907151
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/user/repo.git'
    abbreviations = {}
    clone_to_dir = '/tmp/testing/cookiecutters'
    checkout = ''
    no_input = False
    password = ''
    directory = ''

    repo_dir, should_cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory
    )

    assert repo_dir == '/tmp/testing/cookiecutters/repo/cookiecutter.json'
    assert should_cleanup is False

# Generated at 2022-06-23 16:24:05.202465
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("somfile.zip") == True
    assert is_zip_file("somepath/to/somfile.zip") == True
    assert is_zip_file("somefile.zip.zip") == True
    assert is_zip_file("somefile") == False
    assert is_zip_file("somefile.exe") == False
    assert is_zip_file("somepath/to/somefile.exe") == False
    assert is_zip_file("some-file.zip") == True
    assert is_zip_file("some-path/to/some-file.zip") == True
    assert is_zip_file("some-file.zip.zip") == True
    assert is_zip_file("some-file") == False
    assert is_zip_file("some-file.exe") == False


# Generated at 2022-06-23 16:24:09.902143
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/home/kevin/") == False
    assert repository_has_cookiecutter_json("/home/kevin/cookiecutter/") == False
    assert repository_has_cookiecutter_json("/home/kevin/cookiecutter/tests/") == True


# Generated at 2022-06-23 16:24:20.468638
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Verify for correct expansion of template abbreviations"""
    abbreviations = {
    'gh': 'https://{0}.git',
    'bb': 'https://{0}.git',
    'git': 'https://{0}.git'
    }

    assert expand_abbreviations("gh:nvie/cookiecutter", abbreviations) == "https://github.com/nvie/cookiecutter.git"
    assert expand_abbreviations("nvie/cookiecutter", abbreviations) == "https://github.com/nvie/cookiecutter.git"
    assert expand_abbreviations("git:nvie/cookiecutter", abbreviations) == "https://github.com/nvie/cookiecutter.git"

# Generated at 2022-06-23 16:24:29.550953
# Unit test for function expand_abbreviations

# Generated at 2022-06-23 16:24:41.545433
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test output of determine_repo_dir with git repos."""
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    mydir = os.path.dirname(os.path.abspath(__file__))
    clone_to_dir = os.path.join(mydir, 'foo')

    repo_dir = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )

# Generated at 2022-06-23 16:24:50.636971
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "gh-branch": "https://github.com/{}.git@{}",
        "bb": "https://bitbucket.org/{}.git",
        "bb-branch": "https://bitbucket.org/{}.git@{}",
        "gl": "git+gitlab://gitlab.com/{}.git",
    }

    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"

# Generated at 2022-06-23 16:25:00.531626
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}', 'bb': 'https://bitbucket.org/{}', 'gl': 'https://gitlab.com/{}' }
    assert expand_abbreviations('cookiecutter-pypackage', abbreviations) == 'cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:25:08.945326
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/wdobler/cookiecutter-openstack.git')
    assert is_repo_url('git@github.com:wdobler/cookiecutter-openstack.git')
    assert is_repo_url('https://github.com:wdobler/cookiecutter-openstack.git')
    assert is_repo_url('file:///home/wdobler/cookiecutter-openstack.git')



# Generated at 2022-06-23 16:25:13.350573
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'ghu': 'gh:audreyr/cookiecutter'
    }

    template = expan

# Generated at 2022-06-23 16:25:20.377853
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git')== False
    assert is_zip_file('cookiecutter-pypackage.git') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git/archive/master.zip') == True
    assert is_zip_file('file:///home/audreyr/cookiecutter-pypackage/archive/master.zip') == True



# Generated at 2022-06-23 16:25:31.685631
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    def repo_path(url):
        """Get the path to a git repository."""
        return os.path.join(os.getcwd(), 'tests', 'test-repo-{}'.format(url))

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    repo_dir = repo_path(template)
    clone_to_dir = repo_path('clones')
    checkout = 'develop'
    no_input = False
    password = None
    directory = None

    # Test when directory is None

# Generated at 2022-06-23 16:25:41.725434
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/pydanny/cookiecutter-django'
    abbreviations = {'gh': 'https://github.com/{}'}
    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory)
    print(repo_dir)
    assert repo_dir.endswith('cookiecutter-django')
    assert not cleanup

if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-23 16:25:44.737065
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function is_zip_file."""
    assert is_zip_file('something.zip')
    assert not is_zip_file('something.somethingelse')
    assert not is_zip_file('something')



# Generated at 2022-06-23 16:25:52.431089
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}",
        "gl": "https://gitlab.com/{}.git",
    }
    template = "foo"
    assert template=="foo"
    template = "gh:foo"
    assert template=="https://github.com/foo.git"
    template = "bb:foo"
    assert template=="https://bitbucket.org/foo"
    template = "gl:foo"
    assert template=="https://gitlab.com/foo.git"

# Generated at 2022-06-23 16:25:59.530916
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrs = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbrs) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbrs) == 'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-23 16:26:08.628472
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh' : 'https://github.com/{}.git',
        'bb' : 'https://bitbucket.org/{}'
    }
    assert(expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git')
    assert(expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:26:19.144209
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test to check the function repository_has_cookiecutter_json."""
    from . import temporary_directory

    # Create a temporary directory
    with temporary_directory() as tmpdir:
        # Create a cookiecutter.json file inside the temporary directory
        file_path = os.path.join(tmpdir, 'cookiecutter.json')
        with open(file_path, 'w') as file:
            file.write("some file content")

        # Check whether the temporary directory has a cookiecutter.json file
        # which should pass
        assert (
            repository_has_cookiecutter_json(tmpdir)
        )

        # Remove the cookiecutter.json file
        os.remove(file_path)

        # Check whether the temporary directory has a cookiecutter.json file
        # which should fail

# Generated at 2022-06-23 16:26:30.394986
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test is_repo_url function."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+git@github.com:pydanny/cookiecutter-django.git')
    assert is_repo_url('git+https://github.com/pydanny/cookiecutter-django.git')
    assert is_repo_url('hg+https://bitbucket.org/pydanny/cookiecutter-django')
   

# Generated at 2022-06-23 16:26:40.667715
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('ssh://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/pokoli-skeleton')
    assert is_repo_url('file:///Users/audreyr/cookiecutters/pypackage')
    assert is_repo_url('file:///abs/path/to/cookiecutter-template')
    assert not is_repo_url('pypackage')
    assert not is_

# Generated at 2022-06-23 16:26:44.195707
# Unit test for function is_zip_file
def test_is_zip_file():
    flag_zip_file=is_zip_file('test.zip')
    assert flag_zip_file==True
    flag_zip_file=is_zip_file('test.txt')
    assert flag_zip_file==False
    flag_zip_file=is_zip_file('test.ZIp')
    assert flag_zip_file==True

# Generated at 2022-06-23 16:26:52.376782
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test for function is_repo_url."""
    assert not is_repo_url('/Users/audreyr/projects/cookiecutter-pypackage')
    assert not is_repo_url('cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:27:02.352589
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:user/repo') == True
    assert is_repo_url('git@github.com/user/repo') == True
    assert is_repo_url('https://github.com/user/repo.git') == True
    assert is_repo_url('https://github.com/user/repo.git#egg=cookiecutter-pypackage') == True
    assert is_repo_url('https://github.com/user/repo.git') == True
    assert is_repo_url('git://git@github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:27:05.893763
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = "abc"
    assert not repository_has_cookiecutter_json(repo_directory)

    repo_directory = "/home/yiming/product_name/cookiecutter-pypackage/"
    assert repository_has_cookiecutter_json(repo_directory)

# Generated at 2022-06-23 16:27:09.900260
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(
        "/Users/rohan/Documents/projects/cookiecutter-pypackage/"
        "cookiecutter-pypackage") is True


# Generated at 2022-06-23 16:27:12.611703
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('example.zip')
    assert not is_zip_file('example.jpeg')

# Generated at 2022-06-23 16:27:19.977341
# Unit test for function determine_repo_dir

# Generated at 2022-06-23 16:27:29.017796
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:27:38.838616
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {"github": "https://github.com/{}.git"}
    clone_to_dir = "/tmp/"
    checkout = "master"
    no_input = "True"
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(template,abbreviations,clone_to_dir,checkout,no_input,password,directory)
    print(repo_dir)

if __name__ == "__main__":
    test_determine_repo_dir()

# Generated at 2022-06-23 16:27:41.939439
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Verify that expand_abbreviations() works as expected."""
    assert 'gh:audreyr/cookiecutter-pypackage' == expand_abbreviations(
        'pypackage', {'gh': 'gh:{0}'}
    )



# Generated at 2022-06-23 16:27:45.619053
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test the is_zip_file function."""

    # Should return true for zip file and false for non-zip file
    assert (is_zip_file('test.zip')) == True
    assert (is_zip_file('test.txt')) == False



# Generated at 2022-06-23 16:27:50.533119
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('template.zip')
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/zipball/master')
    assert not is_zip_file('/absolute-path/to/template')
    assert not is_zip_file('audreyr/cookiecutter-pypackage')
    assert not is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_zip_file('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:27:59.429635
# Unit test for function is_repo_url
def test_is_repo_url():
    pattern = re.compile(r'(git|ssh|http(s)?)\://[\w\.@]+[/]?[\w\.?=%&=\-@/$,;]*')
    assert is_repo_url('https://github.com/wdm0006/cookiecutter-pypackage-minimal') is True
    assert is_repo_url('git@github.com:wdm0006/cookiecutter-pypackage-minimal.git') is True
    assert is_repo_url('https://github.com/wdm0006/cookiecutter-pypackage-minimal/') is True
    assert is_repo_url('git@github.com:wdm0006/cookiecutter-pypackage-minimal.git/') is True

# Generated at 2022-06-23 16:28:09.173624
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test expand_abbreviations function."""
    assert expand_abbreviations('user_name', {
        'user_name': '{{cookiecutter.user_name}}',
    }) == '{{cookiecutter.user_name}}'
    assert expand_abbreviations('username', {
        'username': '{{cookiecutter.user_name}}',
    }) == '{{cookiecutter.user_name}}'
    assert expand_abbreviations('full_name', {
        'full_name': '{{cookiecutter.full_name}}',
        'full': '{{cookiecutter.full_name}}',
    }) == '{{cookiecutter.full_name}}'

# Generated at 2022-06-23 16:28:20.148844
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test if is_repo_url returns expected output.
    """
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage/') == False
    assert is_repo_url('git+git://git.example.com/audreyr/example-pypackage-name.git') == True
    assert is_repo_url('git://git.example.com/audreyr/example-pypackage-name.git') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True

# Generated at 2022-06-23 16:28:29.066743
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test local directory
    template_name = '.' # Current directory
    abbreviations = {
        # Note: We are not supporting abbreviations yet
    }
    clone_to_dir = os.getcwd() # Current directory
    checkout = '' # The branch, tag or commit ID to checkout after clone
    no_input = False # Prompt the user at command line for manual configuration
    password = '' # The password to use when extracting the repository
    directory = '' # Directory within repo where cookiecutter.json lives

    # Test for a local directory
    is_repository_return = is_repo_url(template_name)
    print('Is %s a repository URL? %s' % (template_name, is_repository_return))

    # Test for template name
    template_name = '.' # Current directory
    template_expanded

# Generated at 2022-06-23 16:28:37.538082
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test function determine_repo_dir."""
    import os
    import tempfile

    from cookiecutter import configuration

    # A directory containing a project template directory.
    template_dir = os.path.join('tests', 'fake-repo-tmpl')
    # A URL to a git repository.
    git_repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    # A zip file URL.
    zip_repo = 'https://github.com/audreyr/cookiecutter-pypackage/' + \
        'archive/master.zip'

    # Remember the current working directory and change to a temp
    # directory.
    cwd = os.getcwd()
    os.chdir(tempfile.mkdtemp())

    # Expect template directory


# Generated at 2022-06-23 16:28:46.926656
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/wdijkerman/cookiecutter-dac-api.git')
    assert is_repo_url('git+git://github.com/wdijkerman/cookiecutter-dac-api.git')
    assert is_repo_url('git+https://github.com/wdijkerman/cookiecutter-dac-api.git')
    assert is_repo_url('https://github.com/wdijkerman/cookiecutter-dac-api')
    assert is_repo_url('git+https://github.com/wdijkerman/cookiecutter-dac-api')
    assert is_repo_url('git@github.com:wdijkerman/cookiecutter-dac-api.git')

# Generated at 2022-06-23 16:28:52.078165
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-no-tmpl') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-no-dir/') == False
test_repository_has_cookiecutter_json()

# Generated at 2022-06-23 16:29:04.664187
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/username/repo.git')
    assert is_repo_url('https://bitbucket.org/username/repo')
    assert is_repo_url('git@github.com:username/repo.git')
    assert is_repo_url('git@github.com:username/repo')
    assert is_repo_url('git@bitbucket.org:username/repo')
    assert is_repo_url('git://github.com/username/repo.git')
    assert is_repo_url('git://github.com/username/repo')
    assert is_repo_url('git://bitbucket.org/username/repo')

# Generated at 2022-06-23 16:29:12.259216
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('cookiecutter_json/test_repo_true') == True
    assert repository_has_cookiecutter_json('cookiecutter_json/test_repo_false') == False
    assert repository_has_cookiecutter_json('cookiecutter/test_repo_true') == False
    assert repository_has_cookiecutter_json('cookiecutter_json/test_repo_true/') == True


# Generated at 2022-06-23 16:29:15.617102
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(".")
    assert not repository_has_cookiecutter_json("/root/")

# Generated at 2022-06-23 16:29:25.619763
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test the expand_abbreviations function."""
    abbreviations = {
        'gh': 'https://github.com/{0}.git',
        'bb': 'https://bitbucket.com/{0}.git',
        'gitlab': 'https://gitlab.com/{0}.git',
    }

# Generated at 2022-06-23 16:29:31.437376
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:foo/bar:my-awesome-repo', {'gh': 'git@github.com:{}.git'}) == 'git@github.com:foo/bar:my-awesome-repo.git'

# Generated at 2022-06-23 16:29:40.501147
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    d = {
        'jquery': 'https://github.com/jquery/jquery.git',
        'cc': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'gh': 'https://github.com/',
        'linode': 'git@git.linode.com:',
    }

    assert expand_abbreviations('gh:foo/bar', d) == 'https://github.com/foo/bar'
    assert expand_abbreviations('gh:foo/bar.git', d) == 'https://github.com/foo/bar.git'
    assert expand_abbreviations('jquery', d) == 'https://github.com/jquery/jquery.git'

# Generated at 2022-06-23 16:29:42.460296
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('my_archive.zip') == True
    assert is_zip_file('my_file') == False

# Generated at 2022-06-23 16:29:48.554059
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/path/to/project_tmpl.zip')
    assert is_zip_file('/path/to/project_tmpl.ZIP')
    assert not is_zip_file('/path/to/project_tmpl.tar.gz')
    assert not is_zip_file('/path/to/project_tmpl.tar')

# Generated at 2022-06-23 16:29:52.432616
# Unit test for function is_repo_url
def test_is_repo_url():
    # string = 'ssh://example.com/path/to/repo.git'
    string = 'git@github.com:org/repo.git'
    repo_url = REPO_REGEX.match(string)
    if repo_url is not None:
        return True
    return False


# Generated at 2022-06-23 16:29:58.991974
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Basic unit tests for function determine_repo_dir
    """
    # Relative directory
    test_dir, cleanup = determine_repo_dir(
        template = '.',
        abbreviations = {},
        clone_to_dir = os.getcwd(),
        checkout = '',
        no_input = True,
        password = None,
        directory = None
    )
    assert os.path.join(os.getcwd(), 'cookiecutter.json') == os.path.join(test_dir, 'cookiecutter.json'), 'Test directory does not contain cookiecutter.json'
    assert test_dir == '.', 'Test directory location is not the current directory'
    assert cleanup == False, 'Test directory should not be marked for cleanup'
    
    # Relative directory
    test_dir, cleanup = determine

# Generated at 2022-06-23 16:30:10.641299
# Unit test for function is_repo_url
def test_is_repo_url():
    cases = {
        'bla': False,
        'htte://bla': True,
        'http://bla.blu': True,
        'https://bla.blu': True,
        'git+https://bla.blu': True,
        'git+http://bla.blu': True,
        'git://bla.blu': True,
        'ssh://bla.blu': True,
        'file:///home/danny/bla.blu': True,
        'user@server:user/repo': True,
        'git+ssh://user@server:user/repo': True,
    }
    for case, answer in cases.items():
        assert is_repo_url(case) == answer

# Generated at 2022-06-23 16:30:18.077922
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter')
    assert is_repo_url('git+ssh://github.com/audreyr/cookiecutter')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter')
    assert is_repo_url('git@github.com:audreyr/cookiecutter')
    assert is_repo_url(
        'git@github.com:'
        'audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url('git://github.com/audreyr/cookiecutter')
    assert is_repo_url('ssh://github.com/audreyr/cookiecutter')

# Generated at 2022-06-23 16:30:21.402224
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('a.zip')
    assert is_zip_file('./a.zip')
    assert is_zip_file('foo/a.zip')
    assert not is_zip_file('./foo/a/zip')


# Generated at 2022-06-23 16:30:31.089429
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test function determine_repo_dir."""
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG
    from tests.test_utils import make_fake_repo, make_fake_repo_with_subdir
    from tests.test_utils import make_fake_zip

    fake_config = {
        'cookiecutter': {
            'repository_dir': 'test/test-repo-tmpl',
            'abbreviations': {
                'gh': 'https://github.com/{}',
                'bb': 'https://bitbucket.org/{}',
            },
        },
    }

    fake_repo_dir = make_fake_repo()
    fake_repo_subdir = make_fake_repo_with_subdir()

# Generated at 2022-06-23 16:30:34.690673
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter.zip') is True
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git') is False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.zip') is True


# Generated at 2022-06-23 16:30:40.812667
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') == True
    assert is_zip_file('foo.bar.zip') == True
    assert is_zip_file('foo.bar.zip.baz') == False
    assert is_zip_file('foo.zip.baz') == False
    assert is_zip_file('foo.baz') == False



# Generated at 2022-06-23 16:30:43.108796
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test.zip")
    assert is_zip_file("test.zip.zip")
    assert not is_zip_file("test.tar.gz")

# Generated at 2022-06-23 16:30:45.975437
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test Function: repository_has_cookiecutter_json"""
    return_value = repository_has_cookiecutter_json('')
    expected = False
    assert return_value == expected


# Generated at 2022-06-23 16:30:50.799454
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test.zip") == True
    assert is_zip_file("test.ZIP") == True
    assert is_zip_file("test.ZiP") == True
    assert is_zip_file("test.zIp") == True
    assert is_zip_file("test.ziP") == True
    assert is_zip_file("test.zip.z") == True


# Generated at 2022-06-23 16:30:53.173752
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test function."""
    repo_dir = 'tests/fake-repo-tmpl'
    assert repository_has_cookiecutter_json(repo_dir) == True

# Generated at 2022-06-23 16:30:57.321945
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:31:06.305141
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Instantiate a temporary directory,
    # which will be removed automatically upon exit.
    with tempfile.TemporaryDirectory() as tmp:
        # Create a directory and file within the temporary directory.
        os.mkdir(os.path.join(tmp, 'test'))
        with open(os.path.join(tmp, 'test', 'cookiecutter.json'), 'w') as f:
            f.write('{}')
        # Test that the function returns True for this directory
        assert repository_has_cookiecutter_json(os.path.join(tmp, 'test'))
        # Test that the function returns False for a directory that
        # doesn't exist within the temporary directory.
        assert not repository_has_cookiecutter_json(os.path.join(tmp, 'blah'))
        # Test that the function returns False

# Generated at 2022-06-23 16:31:11.684023
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = "gh:audreyr/cookiecutter-pypackage"
    result = expand_abbreviations(template, abbreviations)
    expected = "https://github.com/audreyr/cookiecutter-pypackage.git"
    assert result == expected

    # test the case where we don't have the abbr defined
    template = "bb:https://bitbucket.org/pokoli/cookiecutter-pytds.git"
    result = expand_abbreviations(template, abbreviations)
    expected = "bb:https://bitbucket.org/pokoli/cookiecutter-pytds.git"

# Generated at 2022-06-23 16:31:16.988184
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    template = './'

    abbreviations = {}

    clone_to_dir = '.'

    checkout = 'master'

    no_input = False

    password = None

    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )

    assert repo_dir == '.'
    assert cleanup == False

# Generated at 2022-06-23 16:31:18.001046
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test to determine repo directory.
    """
    return 0

# Generated at 2022-06-23 16:31:22.188198
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {"gh": "https://github.com/{}.git"}
    template = expand_abbreviations("foo", abbreviations)
    assert template == "foo"
    template = expand_abbreviations("gh:foo", abbreviations)
    assert template == "https://github.com/foo.git"

# Generated at 2022-06-23 16:31:25.524023
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Return True if the repo_directory is valid
    """
    repo_directory = '/Users/bob/workspace/project_cookiecutter_test'
    assert repository_has_cookiecutter_json(repo_directory)

# Generated at 2022-06-23 16:31:34.739496
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('fish://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git/some/folder')

# Generated at 2022-06-23 16:31:37.982108
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Make sure this function properly detects a valid Cookiecutter template.
    :return:
    """
    assert repository_has_cookiecutter_json('examples') == True

# Generated at 2022-06-23 16:31:44.990731
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/home/username/project.zip')
    assert is_zip_file('/home/username/project.ZIP')

    assert not is_zip_file('/home/username/project.zip1')
    assert not is_zip_file('/home/username/project.zip12')
    assert not is_zip_file('/home/username/projectfile')
    assert not is_zip_file('/home/username/project')


# Generated at 2022-06-23 16:31:54.400803
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('.', abbreviations) == '.'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:', abbreviations) == 'https://github.com/.git'
    assert expand_abbreviations('bb:jacebrowning/template-python', abbreviations) == 'https://bitbucket.org/jacebrowning/template-python.git'

# Generated at 2022-06-23 16:32:03.227851
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test abbreviations

    # Test is_zip_file
    assert(is_zip_file('test.zip') is True)
    assert(is_zip_file('test.tar.gz') is False)

    # Test is_repo_url
    assert(is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') is True)
    assert(is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git') is True)
    assert(is_repo_url('something_else.git') is False)

    # Test repository_has_cookiecutter_json

    # Test that determine_repo_dir returns a tuple

# Generated at 2022-06-23 16:32:13.387985
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test is_repo_url
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+http://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage')


# Generated at 2022-06-23 16:32:20.475914
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    template_dir = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert template_dir == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    template_dir = expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations)
    assert template_dir == 'https://bitbucket.org/audreyr/cookiecutter-pypackage'
    template_dir = expand_abbreviations('gh:audreyr/some-fake-repo', abbreviations)

# Generated at 2022-06-23 16:32:23.672170
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == False

# Generated at 2022-06-23 16:32:28.739832
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test to check whether repository is valid"""
    answer = repository_has_cookiecutter_json("cookiecutter")
    assert answer == True
    answer = repository_has_cookiecutter_json("cookiecutters")
    assert answer == False


# Generated at 2022-06-23 16:32:31.526117
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-pypackage.zip')
    assert not is_zip_file('cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:32:34.388814
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/test-repo/")
    assert not repository_has_cookiecutter_json("tests/test-repo-no-config/")



# Generated at 2022-06-23 16:32:38.511496
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_filename = "temp.zip"
    assert is_zip_file(zip_filename)
    tar_filename = "temp.tar.gz"
    assert not is_zip_file(tar_filename)

# Generated at 2022-06-23 16:32:48.073862
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "git@github.com:kylesluder/cookie-repo.git"
    abbreviations = {
        "gh": 'https://github.com/{}',
        "bb": 'https://bitbucket.org/{}'
    }
    clone_to_dir = "/tmp"
    checkout = "master"
    no_input = False
    directory = "cookiecutter-repo"

    # try to get repo dir
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, directory=directory)
    assert (repo_dir == '/tmp/cookie-repo/cookiecutter-repo')

    # cleanup after test
    import shutil
    shutil.rmtree('/tmp/cookie-repo')

# Generated at 2022-06-23 16:32:50.492664
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    assert repository_has_cookiecutter_json('.')
    assert not repository_has_cookiecutter_json('nonexistent')

# Generated at 2022-06-23 16:32:57.199596
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert ('abbr:abc' == expand_abbreviations('abbr:abc',
                                               {'abbr': 'val:{}'}))
    assert ('val:def' == expand_abbreviations('abbr:def',
                                               {'abbr': 'val:{}'}))
    assert ('val:abc' == expand_abbreviations('val:abc',
                                               {'abbr': 'val:{}'}))
    assert ('abbr:abc' == expand_abbreviations('abbr:abc', {'abbr': 'val'}))

# Generated at 2022-06-23 16:33:00.387703
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc/abc.zip') == True
    assert is_zip_file('abc/abc.tar.gz') == False


# Generated at 2022-06-23 16:33:08.620326
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine repo dir."""
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_name = 'cookiecutter-pypackage'
    repo_dir = '/Users/audreyr/tests/cookiecutter-tribble/tests/fake-repo-pre/'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'audreyr': 'https://github.com/audreyr',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:33:19.948756
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'myfork': 'https://github.com/myusername/{}.git'
    }
    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git", "Could not expand gh:audreyr/cookiecutter-pypackage to https://github.com/audreyr/cookiecutter-pypackage.git"