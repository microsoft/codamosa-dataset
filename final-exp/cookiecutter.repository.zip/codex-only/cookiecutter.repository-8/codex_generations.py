

# Generated at 2022-06-23 16:23:24.506256
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    # Check for expansion
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    # Check for no expansion via invalid abbreviation
    assert expand_abbreviations('badabb:audreyr/cookiecutter-pypackage', abbreviations) == 'badabb:audreyr/cookiecutter-pypackage'

    # Check for no expansion via colon syntax

# Generated at 2022-06-23 16:23:33.987369
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage.git', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:23:39.549879
# Unit test for function is_zip_file
def test_is_zip_file():
    assert True == is_zip_file('/tmp/test.zip')
    assert True == is_zip_file('/tmp/test.ZIP')
    assert False == is_zip_file('/tmp/test.zip.txt')
    assert False == is_zip_file('/tmp/test.txt')


# Generated at 2022-06-23 16:23:47.324597
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')
    assert not is_repo_url('/Users/audreyr/projects/cookiecutter-pypackage')

# Generated at 2022-06-23 16:23:56.505576
# Unit test for function is_zip_file

# Generated at 2022-06-23 16:24:07.254567
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil

    # Test zipped repo
    template = 'tests/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repos'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    zipped_template = template + '.zip'
    shutil.make_archive(zipped_template, 'zip', template)

    repo_dir, cleanup = determine_repo_dir(
        zipped_template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=password,
    )
    assert repo_dir
    assert cleanup
    os.remove(zipped_template + ".zip")

    # Test github repo

# Generated at 2022-06-23 16:24:17.832490
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'gitlab': 'https://gitlab.com/{}.git',
    }
    assert 'gh:audreyr/cookiecutter-pypackage' == expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations)

# Generated at 2022-06-23 16:24:27.916094
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = "abc"
    abbreviations = {"abc": "path/to/abc{0}",
                     "def": "path/to/def{0}"}
    # abc expands to "path/to/abc"
    assert expand_abbreviations(template, abbreviations) == "path/to/abc"

    # abc:def expands to "path/to/abcdef"
    template = "abc:def"
    assert expand_abbreviations(template, abbreviations) == "path/to/abcdef"

    # abc:def:ghi expands to "path/to/abcdefghi"
    template = "abc:def:ghi"
    assert expand_abbreviations(template, abbreviations) == "path/to/abcdefghi"

    # abc:def:ghi: expands to

# Generated at 2022-06-23 16:24:33.269035
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = "foo/bar"
    abbreviations = {"foo": "https://github.com/user/foo/tree/master/{}"}
    template = expand_abbreviations(template, abbreviations)
    assert template == 'https://github.com/user/foo/tree/master/bar'

# Generated at 2022-06-23 16:24:42.465141
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/arothman/cookiecutter-pypackage/zipball/master') == True
    assert is_zip_file('https://github.com/foo/bar/zipball/master') == True
    assert is_zip_file('https://github.com/foo/bar/zipball/') == True
    assert is_zip_file('git@github.com:foo/bar.git') == False
    assert is_zip_file('git@github.com:foo/bar/zipball/exampl') == False
    assert is_zip_file('https://github.com/foo/bar/zipball') == False

# Generated at 2022-06-23 16:24:47.977326
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('pypackage', dict(pypackage='https://github.com/audreyr/cookiecutter-pypackage')) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', dict(gh='https://github.com/{}')) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', dict(gh='https://github.com/{0}')) == 'https://github.com/audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:24:54.367583
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('something.zip')
    assert not is_zip_file('file_without_extension')
    assert is_zip_file('lowercase.zip')
    assert is_zip_file('UPPERCASE.ZIP')
    assert is_zip_file('camelCase.zip')
    assert not is_zip_file('something.ZIP.zip')

# Generated at 2022-06-23 16:25:03.214441
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///home/user/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:25:04.734054
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert not repository_has_cookiecutter_json('test/fake-repo')

# Generated at 2022-06-23 16:25:15.388008
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert ('https://github.com/audreyr/cookiecutter-pypackage.git' ==
            expand_abbreviations(template, abbreviations))
    template = 'gh:foo'
    assert ('https://github.com/foo.git' ==
            expand_abbreviations(template, abbreviations))
    template = 'bb:foo'
    assert ('https://bitbucket.org/foo.git' ==
            expand_abbreviations(template, abbreviations))
    template = 'foo'

# Generated at 2022-06-23 16:25:21.692121
# Unit test for function is_zip_file
def test_is_zip_file():
    value = 'foo.zip'
    assert is_zip_file(value) is True

    value = 'foo.ZIP'
    assert is_zip_file(value) is True

    value = 'foo.ZiP'
    assert is_zip_file(value) is True

    value = 'foo.zip.zip'
    assert is_zip_file(value) is True

    value = 'fo.zipp'
    assert is_zip_file(value) is False

    value = 'foo.zp'
    assert is_zip_file(value) is False

# Generated at 2022-06-23 16:25:23.077857
# Unit test for function is_zip_file
def test_is_zip_file():
    file_url = 'http://example.com/file.zip'
    assert is_zip_file(file_url) is True
    assert is_zip_file(file_url.upper()) is True
    assert is_zip_file(file_url + '2') is True



# Generated at 2022-06-23 16:25:33.517526
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test expand abbreviations for repository."""
    t = 'explicit'
    exp = expand_abbreviations(t, dict(git='git+git', bzr='bzr+https'))
    assert exp == t

    t = 'git:myorg/myrepo.git'
    exp = expand_abbreviations(t, dict(git='git+git', bzr='bzr+https'))
    assert exp == 'git+git:myorg/myrepo.git'

    t = 'git'
    exp = expand_abbreviations(t, dict(git='git+git', bzr='bzr+https'))
    assert exp == 'git+git'

    t = 'git:myorg/myrepo.git'

# Generated at 2022-06-23 16:25:44.254197
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test expanding abbreviations."""
    abbreviations = {'gh': 'https://github.com/{}.git'}

    class TestExpansions(object):
        def __init__(self, abbreviation, template):
            self.abbreviation = abbreviation
            self.template = template

    test_expansions = [
        TestExpansions(
            abbreviation='gh:audreyr/cookiecutter-pypackage',
            template='https://github.com/audreyr/cookiecutter-pypackage.git'
        ),
        TestExpansions(
            abbreviation='gh:username123/some-repo',
            template='https://github.com/username123/some-repo.git',
        ),
    ]

    for test_expansion in test_expansions:
        expanded

# Generated at 2022-06-23 16:25:54.388179
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function `determine_repo_dir`.

    The function `determine_repo_dir` takes a template as an argument and return
    a tuple containing the cookiecutter json location and boolean whether that 
    directory should be cleaned up after the templaate has been instantiated.
    """
    clone_to_dir = './'
    checkout = None
    no_input = False
    password = None
    directory = None
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }

    # Check if `determine_repo_dir` is working properly with template 
    # reference that contains cookiecutter.json

# Generated at 2022-06-23 16:26:02.561827
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    here = os.path.dirname(os.path.abspath(__file__))

    assert repository_has_cookiecutter_json(
        os.path.join(here, 'fake-repo-pre/{{cookiecutter.repo_name}}')
    )

    assert repository_has_cookiecutter_json(
        os.path.join(here, 'fake-repo-post/{{cookiecutter.repo_name}}')
    )

    assert repository_has_cookiecutter_json(
        os.path.join(here, 'fake-repo-pre')
    )

    assert repository_has_cookiecutter_json(
        os.path.join(here, 'fake-repo-post')
    )

# Generated at 2022-06-23 16:26:08.873623
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('~/foo.zip') is True
    assert is_zip_file('~/foo.ZIP') is True
    assert is_zip_file('~/foo.ZiP') is True
    assert is_zip_file('foobar') is False

# Generated at 2022-06-23 16:26:19.374372
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Unit test for function expand_abbreviations"""
    # 'cc' abbreviation is the cookiecutter-django repo
    abbreviations = {
        "cc": "https://github.com/pydanny/cookiecutter-django.git",
        "gh": "https://github.com/{}.git",
    }

    template = "cc"
    expected = "https://github.com/pydanny/cookiecutter-django.git"
    result = expand_abbreviations(template, abbreviations)
    assert result == expected

    template = "gh:pybites/blog_code"
    expected = "https://github.com/pybites/blog_code.git"
    result = expand_abbreviations(template, abbreviations)
    assert result == expected

    # nothing to expand in this

# Generated at 2022-06-23 16:26:26.261572
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test if a valid template can be found."""
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'tests/fake-repo-tmpl'
    checkout = None
    no_input = True
    password = None
    directory = None
    try:
        determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
            password,
            directory
        )
    except RepositoryNotFound as e:
        assert False, 'Valid template should not fail: ' + str(e)
    assert True


# Generated at 2022-06-23 16:26:30.395008
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')



# Generated at 2022-06-23 16:26:40.667570
# Unit test for function is_repo_url
def test_is_repo_url():
    # https://github.com/nvie/cookiecutter
    value1 = 'https://github.com/nvie/cookiecutter.git'
    result1 = is_repo_url(value1)
    assert(result1)

    # https://github.com/nvie/cookiecutter.git
    value2 = 'https://github.com/nvie/cookiecutter.git'
    result2 = is_repo_url(value2)
    assert(result2)

    # git@github.com/nvie/cookiecutter.git
    value3 = 'git@github.com/nvie/cookiecutter.git'
    result3 = is_repo_url(value3)
    assert(result3)

    # git+ssh://git@github.com/nvie/cookiecutter.git


# Generated at 2022-06-23 16:26:50.676425
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test the regex that interprets a template location as a repository url.
    """
    assert is_repo_url(
        'git@github.com:audreyr/cookiecutter-pypackage.git'
    ) is True
    assert is_repo_url(
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    ) is True
    assert is_repo_url(
        'https://github.com/audreyr/cookiecutter-pypackage/'
    ) is True
    assert is_repo_url(
        'https://bitbucket.org/pokoli/cookiecutter-trytonmodule.git'
    ) is True

# Generated at 2022-06-23 16:26:52.980518
# Unit test for function is_repo_url
def test_is_repo_url():
    result = is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert result is True

# Generated at 2022-06-23 16:27:02.786064
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("C:\\Users\\") == False 
    assert repository_has_cookiecutter_json("C:\\Users\\ ") == False
    assert repository_has_cookiecutter_json("C:\\Users\\Prashant") == False
    assert repository_has_cookiecutter_json("C:\\Users\\Prashant\\") == False
    assert repository_has_cookiecutter_json("C:\\Users\\Prashant\\cookiecutter") == False
    assert repository_has_cookiecutter_json("C:\\Users\\Prashant\\cookiecutter\\") == False
    assert repository_has_cookiecutter_json("C:\\Users\\Prashant\\cookiecutter\\") == False

# Generated at 2022-06-23 16:27:10.130683
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test is_repo_url function
    # test if the url is a repo url
    assert(is_repo_url("https://github.com/cookiecutter/cookiecutter-pypackage.git"))
    assert(is_repo_url("git://github.com/cookiecutter/cookiecutter-pypackage.git"))
    assert(is_repo_url("file://localhost/~cookiecutter/cookiecutter-pypackage.git"))
    assert(is_repo_url("ssh://user@server:cookiecutter-pypackage.git"))
    assert(is_repo_url("user@server:cookiecutter-pypackage.git"))

# Generated at 2022-06-23 16:27:19.276328
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        'username/repo_name', {'username': 'git@github.com:{}.git'}
    ) == 'git@github.com:username/repo_name.git'
    assert expand_abbreviations(
        'username/repo_name', {'username': 'git@github.com:{}'}
    ) == 'git@github.com:username/repo_name'
    assert expand_abbreviations('foo', {'foo': 'bar'}) == 'bar'
    assert expand_abbreviations('foo:something', {'foo': 'bar:{}'}) == 'barsomething'
    assert expand_abbreviations('foo:something', {'foo': 'bar{}'}) == 'barsomething'

# Generated at 2022-06-23 16:27:28.405238
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage') == True

# Generated at 2022-06-23 16:27:30.640815
# Unit test for function is_zip_file
def test_is_zip_file():
    result = is_zip_file('file1.zip')
    assert result == True


# Generated at 2022-06-23 16:27:40.863007
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {"gh": "https://github.com/{}"}) == "https://github.com/audreyr/cookiecutter-pypackage"
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', {"gh": "https://github.com/{}"}) == "audreyr/cookiecutter-pypackage"
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage:develop', {"gh": "https://github.com/{}"}) == "https://github.com/audreyr/cookiecutter-pypackage:develop"

# Generated at 2022-06-23 16:27:44.617484
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/home/myuser/myproject.zip')
    assert is_zip_file('/home/myuser/myproject.ZIP')
    assert not is_zip_file('/home/myuser/myproject.tar.gz')

# Generated at 2022-06-23 16:27:51.068635
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:28:03.300489
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from git import Repo
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import main
    import shutil
    import os

    main.cookiecutters_dir = os.path.join(os.getcwd(), 'tests/fake-repo-tmpl')
    repository_template = 'fake-repo'
    abbreviations = DEFAULT_CONFIG['abbreviations']

    clone_to_dir = 'tests/test-output'
    if os.path.isdir(clone_to_dir):
        shutil.rmtree(clone_to_dir)
    os.makedirs(clone_to_dir)

    checkout = None
    no_input = False
    password = None

# Generated at 2022-06-23 16:28:11.401175
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'gl': 'https://gitlab.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    actual = expand_abbreviations(template, abbreviations)
    assert actual == expected

    template = 'gh:foo/bar'
    expected = 'https://github.com/foo/bar.git'
    actual = expand_abbreviations(template, abbreviations)
    assert actual == expected

    template = 'foo/bar'
    expected = 'foo/bar'

# Generated at 2022-06-23 16:28:17.654920
# Unit test for function is_zip_file
def test_is_zip_file():
    assert(is_zip_file("foo.zip") == 1)
    assert(is_zip_file("foo.ZIP") == 1)
    assert(is_zip_file("foo.ZiP") == 1)
    assert(is_zip_file("foo.bar") == None)
    assert(is_zip_file(".zip") == None)
    assert(is_zip_file("") == None)

# Generated at 2022-06-23 16:28:27.282340
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'bb+hg': 'https://bitbucket.org/{}',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:', abbreviations) == 'https://github.com/.git'
    assert expand_abbreviations('bb:jacebrowning/template-python', abbreviations) == 'https://bitbucket.org/jacebrowning/template-python.git'

# Generated at 2022-06-23 16:28:32.264592
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip')
    assert is_zip_file('abc.ZIP')
    assert is_zip_file('abc.Zip')
    assert not is_zip_file('abc.ziph')
    assert not is_zip_file('abc.zip.tar.gz')

# Generated at 2022-06-23 16:28:36.339074
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:28:43.335813
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations("mytemplate", {'mytemplate': 'https://example.com/mytemplate'}) == 'https://example.com/mytemplate'
    assert expand_abbreviations("mytemplate", {}) == 'mytemplate'
    assert expand_abbreviations("mytemplate:foo", {'mytemplate': 'https://example.com/{}'}) == 'https://example.com/foo'
    assert expand_abbreviations("mytemplate:foo", {}) == 'mytemplate:foo'

# Generated at 2022-06-23 16:28:50.221204
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
        "gl": "https://gitlab.com/{}.git",
    }

    # Test full template name
    template = 'https://github.com/cookiecutter/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == template

    # Test just abbreviation
    template = 'gh:cookiecutter/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://github.com/cookiecutter/cookiecutter-pypackage.git'

    # Test abbreviation with no template
    template = 'gh:'

# Generated at 2022-06-23 16:29:00.962381
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file(value="file.zip") == True
    assert is_zip_file(value=".zip") == True
    assert is_zip_file(value=".zipzap") == True
    assert is_zip_file(value="file.ZIP") == True
    assert is_zip_file(value="file.nozip") == False
    assert is_zip_file(value="zip") == False
    assert is_zip_file(value="") == False
    assert is_zip_file(value="zipzap") == False
    assert is_zip_file(value="Zip") == False


# Generated at 2022-06-23 16:29:12.893721
# Unit test for function determine_repo_dir

# Generated at 2022-06-23 16:29:23.942660
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test is_repo_url.

    """
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('../')
    assert not is_repo_url('../../')
    assert not is_repo_url('../../../')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:29:34.275094
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/testing/cookiecutter-testing/archive/master.zip') == True
    assert is_zip_file('file.zip') == True
    assert is_zip_file('stdin') == False
    assert is_zip_file('https://github.com/testing/cookiecutter-testing/archive/master.tar.gz') == False
    assert is_zip_file('https://github.com/testing/cookiecutter-testing/archive/master.targz') == False
    assert is_zip_file('https://github.com/testing/cookiecutter-testing/archive/master') == False
    assert is_zip_file('hej') == False
    assert is_zip_file('') == False

# Generated at 2022-06-23 16:29:39.219745
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("faketemplate.zip")
    assert not is_zip_file("faketemplate")
    assert is_zip_file("faketemplate.ZIP")
    assert not is_zip_file("faketemplate.7z")


# Generated at 2022-06-23 16:29:47.529067
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "ghd": "https://github.com/{}/downloads/cookiecutter-{}.zip",
        "bb": "https://bitbucket.org/{}",
        "bbd": "https://bitbucket.org/{}/get/{}.zip",
        "l": "https://launchpad.net/{}",
        "ld": "https://launchpad.net/{}/+download/cookiecutter-{}.zip",
    }


# Generated at 2022-06-23 16:29:52.000518
# Unit test for function is_zip_file
def test_is_zip_file():
    """The function is_zip_file should correctly detect if a string is a zipfile path."""
    assert is_zip_file("some/path/to/a.zip")
    assert is_zip_file("some/path/to/a.ZIP")
    assert not is_zip_file("some/path/to/a.zipper")

# Generated at 2022-06-23 16:29:58.734672
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir(template, {}, ".", "master", False)
    template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    assert determine_repo_dir(template, {}, ".", "master", False)
    template = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir(template, {}, ".", "master", False)
    template = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir(template, {}, ".", "master", False)
   

# Generated at 2022-06-23 16:30:02.286756
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template="abc"
    abbreviations = {
        'abc': 'abcxyz'
    }
    assert expand_abbreviations(template, abbreviations) == 'abcxyz'


# Generated at 2022-06-23 16:30:07.367351
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'



# Generated at 2022-06-23 16:30:16.715546
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/zipball/master') == True
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/tarball/master') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.zip') == True
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.tar') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.tar.gz') == False
   

# Generated at 2022-06-23 16:30:27.339095
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from unittest import TestCase

    from cookiecutter.prompt import read_user_yes_no


# Generated at 2022-06-23 16:30:30.450534
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{0}.git'}) == "https://github.com/audreyr/cookiecutter-pypackage.git"

# Generated at 2022-06-23 16:30:34.437472
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Validate our abbreviations function."""
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:30:45.305284
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify is_repo_url correctly identifies repository URLs."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:pydanny/cookiecutter-djangopackage.git')
    assert is_repo_url('git@bitbucket.org:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pydanny/cookiecutter-djangopackage')

# Generated at 2022-06-23 16:30:50.300902
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') is True
    assert is_zip_file('/foo/bar/foo.zip') is True
    assert is_zip_file('foo.zip') is True
    assert is_zip_file('foo') is False
    assert is_zip_file(None) is False
    assert is_zip_file('foo.cookie') is False
    assert is_zip_file('https://github.com/foo/foo.zip') is True
    assert is_zip_file('https://github.com/foo/foo.cookie') is False

# Generated at 2022-06-23 16:31:00.524268
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:31:08.252507
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test if URL is a repository URL.
    """
    # testing for a valid repository urls
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+http://bitbucket.org/pokoli/cookiecutter-dummy-package-pokoli')
    assert is_repo_url('ssh://hg@bitbucket.org/pokoli/cookiecutter-dummy-package-pokoli')


# Generated at 2022-06-23 16:31:13.892579
# Unit test for function is_repo_url
def test_is_repo_url():
    value_true = 'https://github.com/hackebrot/cookiecutter-pypackage.git'
    value_false = '/user/test'
    value_none = None

    assert is_repo_url(value_true)
    assert not is_repo_url(value_false)
    assert not is_repo_url(value_none)

# Generated at 2022-06-23 16:31:19.071165
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file = "cookiecutter.zip"
    not_zip_file = "cookiecutter.py"
    assert is_zip_file(zip_file)
    assert not is_zip_file(not_zip_file)

# Generated at 2022-06-23 16:31:23.358351
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}',
        'git@github.com': 'https://github.com/{}',
    }

    assert expand_abbreviations(template, abbreviations) == template

# Generated at 2022-06-23 16:31:26.379769
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('file.ZIP')
    assert not is_zip_file('file.txt')
    assert not is_zip_file('file.zip.txt')



# Generated at 2022-06-23 16:31:28.343201
# Unit test for function is_zip_file
def test_is_zip_file():
    #Given
    template = 'master.zip'
    #When
    result = is_zip_file(template)
    #Then
    assert result == True



# Generated at 2022-06-23 16:31:35.870251
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test is_repo_url
    """
    assert is_repo_url("git+https://github.com/username/reponame.git")
    assert is_repo_url("https://github.com/username/reponame.git")
    assert not is_repo_url("../relative/path/to/repo")
    assert not is_repo_url("/absolute/path/to/repo")
    assert not is_repo_url("/path/to/zip/file.zip")
    assert not is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git")
    assert not is_repo_url("http://www.example.com")
    assert not is_repo_url("notarealrepo")



# Generated at 2022-06-23 16:31:42.729762
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if a directory exists"""
    repo_directory = '/'
    repo_directory_exists = os.path.isdir(repo_directory)
    assert repo_directory_exists == True

    """Test if a file exists in the directory"""
    cookiecutter_file = '/cookiecutter.json'
    repo_config_exists = os.path.isfile(cookiecutter_file)
    assert repo_config_exists == True


# Generated at 2022-06-23 16:31:47.854669
# Unit test for function is_zip_file
def test_is_zip_file():
    """
    Unit test for function is_zip_file
    """
    assert is_zip_file('test.zip')
    assert is_zip_file('test.ZIP')
    assert is_zip_file('test.Zip')
    assert not is_zip_file('test.zipa')
    assert not is_zip_file('test.zip.')

# Generated at 2022-06-23 16:31:54.910509
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('master.zip') == True
    assert is_zip_file('/path/to/master.zip') == True
    assert is_zip_file('/path/to/master.tar.gz') == False
    assert is_zip_file('master.tar.gz') == False
    assert is_zip_file('master.ZIP') == True
    assert is_zip_file('/path/to/master.ZIP') == True
    assert is_zip_file('/path/to/master.tar.gZ') == False
    assert is_zip_file('master.tar.gZ') == False


# Generated at 2022-06-23 16:32:00.148697
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check if repository exists."""
    assert repository_has_cookiecutter_json('../tests/fake-repo-tmpl/') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-no-json/') == False

# Generated at 2022-06-23 16:32:11.053178
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # TODO: test for http, https, ssh and file url formats
    url_type = 'git'
    url_name = 'github.com'
    url_user = 'shamhiz'
    url_repo = 'cookiecutter-rad'
    url_branch = 'master'
    url_dir = 'template'
    url = '{0}://{1}/{2}/{3}.git'.format(url_type, url_name, url_user, url_repo)
    repo_dir_suffix = 'cookiecutter-rad'
    repo_dir = os.path.join(os.getcwd(), repo_dir_suffix)


# Generated at 2022-06-23 16:32:19.035291
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir() function."""
    assert determine_repo_dir(template='gh:audreyr/cookiecutter-pypackage',
                              abbreviations={'gh': 'https://github.com/{}.git'},
                              clone_to_dir=clone_to_dir,
                              checkout='master',
                              no_input=True)
    assert determine_repo_dir(template='git@github.com:audreyr/cookiecutter-pypackage.git',
                              abbreviations={'gh': 'https://github.com/{}'},
                              clone_to_dir=clone_to_dir,
                              checkout='master',
                              no_input=True)

# Generated at 2022-06-23 16:32:20.290184
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo/')

# Generated at 2022-06-23 16:32:23.414534
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
            template='https://github.com/test',
            abbreviations={}, clone_to_dir='', checkout='', no_input=True,
            password=None, directory=None) == ('https://github.com/test', True)

# Generated at 2022-06-23 16:32:34.430580
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.utils import make_sure_path_exists

    test_repo_dir = DEFAULT_CONFIG['cookiecutters_dir']
    test_repo_name = 'example-repo'
    test_repo_path = os.path.join(test_repo_dir, test_repo_name)
    make_sure_path_exists(test_repo_path)

    test_config_path = os.path.join(test_repo_path, 'cookiecutter.json')
    with open(test_config_path, 'w') as f:
        f.write('{}')

    assert repository_has_cookiecutter_json(test_repo_path)

# Generated at 2022-06-23 16:32:38.568633
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip') is True
    assert is_zip_file('file.tar.gz') is False
    assert is_zip_file('file.tar.bz2') is False

# Generated at 2022-06-23 16:32:48.108700
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test with git+https
    repo_dir, cleanup = determine_repo_dir(
        template="git+https://github.com/audreyr/cookiecutter-pypackage.git",
        abbreviations = {},
        clone_to_dir = os.path.expanduser('~/.cookiecutters'),
        checkout = None,
        no_input = False,
    )
    expected = os.path.join(
        os.path.expanduser('~/.cookiecutters'),
        'cookiecutter-pypackage'
    )
    assert repo_dir == expected, repo_dir
    assert cleanup == False, cleanup

    # Test with git+ssh

# Generated at 2022-06-23 16:32:49.769766
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('aaa.zip') == True


# Generated at 2022-06-23 16:32:57.496835
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:33:07.383291
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:33:08.075147
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    #import pytest
    pass

# Generated at 2022-06-23 16:33:19.533891
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test with a path to an existing cookiecutter template directory
    existing_directory = os.path.dirname(__file__)
    repo_dir, cleanup = determine_repo_dir(
        template=existing_directory,
        abbreviations={},
        clone_to_dir=os.path.join(existing_directory, 'tests', 'test-dir', 'repos'),
        checkout=None,
        no_input=True,
        password=None
    )
    assert repo_dir == existing_directory
    assert cleanup == False
    # Test with a path to an existing directory that does not contain a
    # cookiecutter.json file
    non_repo_dir = os.path.join(existing_directory, 'tests')