

# Generated at 2022-06-23 16:23:21.655289
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert abbreviations['gh'].format('audreyr/cookiecutter-pypackage') == template
    assert abbreviations['gh'] == 'https://github.com/{}.git'

if __name__ == '__main__':
    test_expand_abbreviations()

# Generated at 2022-06-23 16:23:24.804386
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('http://example.com/example.zip') == True
    assert is_zip_file('example.zip') == True
    assert is_zip_file('example.tar.gz') == False


# Generated at 2022-06-23 16:23:30.821843
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('vcs+ssh://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:23:39.098894
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function"""
    repo_path = determine_repo_dir(
        template='my_repo/my_template/cookiecutter.json',
        abbreviations={},
        clone_to_dir='/dummy/path',
        checkout=None,
        no_input=True,
    )

    assert repo_path[0] == 'my_repo/my_template/cookiecutter.json'
    assert repo_path[1] is False

    repo_path = determine_repo_dir(
        template='git@github.com/my_repo',
        abbreviations={},
        clone_to_dir='/dummy/path',
        checkout=None,
        no_input=True,
    )


# Generated at 2022-06-23 16:23:46.195396
# Unit test for function is_repo_url
def test_is_repo_url():
    string1 = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    string2 = 'file://cookiecutter-pypackage'
    string3 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    string4 = '../cookiecutter-pypackage'
    string5 = 'git://github.com/audreyr/cookiecutter-pypackage.git'
    string6 = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    string7 = 'git+file://cookiecutter-pypackage'
    string8 = 'git+ssh://git@github.com:audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:23:50.601041
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test.zip")
    assert not is_zip_file("test.txt")
    assert is_zip_file("test.zipx")
    assert not is_zip_file("/test.zip")


# Generated at 2022-06-23 16:23:57.192184
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert (repository_has_cookiecutter_json('/home/bob/projects/cookiecutter-django') == True)
    assert (repository_has_cookiecutter_json('/home/bob/projects/cookiecutter-pypackage') == True)
    assert (repository_has_cookiecutter_json('/home/bob/projects/cookiecutter-openstack-module') == True)
    assert (repository_has_cookiecutter_json('/home/bob/projects/cookiecutter-openstack-module/') == False)
    assert (repository_has_cookiecutter_json('projects/cookiecutter-openstack-module') == False)


# Generated at 2022-06-23 16:24:05.060916
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test with a valid repository URLs
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')

    # Test with non repository URLs
    assert not is_repo_url('audreyr/cookiecutter-pypackage')
    assert not is_repo_url('file://audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:24:06.980201
# Unit test for function is_zip_file
def test_is_zip_file():
    assert (is_zip_file("test/test/test.zip"))
    assert (not is_zip_file("test/test/test.zips"))

# Generated at 2022-06-23 16:24:17.750649
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    cc_json_exists = os.path.isfile(
        os.path.join(os.getcwd(), 'tests', 'fake-repo-tmpl', 'cookiecutter.json')
    )
    assert repository_has_cookiecutter_json(
        os.path.join(os.getcwd(), 'tests', 'fake-repo-tmpl')
    ) == cc_json_exists
    assert repository_has_cookiecutter_json(
        os.path.join(os.getcwd(), 'tests', 'fake-repo-pre-v0.1.1')
    ) == cc_json_exists

# Generated at 2022-06-23 16:24:24.887849
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {
        "bio": "https://github.com/chapmanb/bcbb/tree/master/standards/{}",
        "snake": "https://bitbucket.org/johanneskoester/snakemake/get/{}.zip",
        "sci": "https://bitbucket.org/nschiff2/science-project/get/{}.zip",
    }

    assert expand_abbreviations("sci:master", abbrevs) == "https://bitbucket.org/nschiff2/science-project/get/master.zip"

# Generated at 2022-06-23 16:24:30.429368
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        "abbrev_key": "https://github.com/audreyr/cookiecutter-pypackage.git"
    }
    print(determine_repo_dir(
        template="abbrev_key",
        abbreviations=abbreviations,
        clone_to_dir="/tmp",
        checkout="master",
        no_input=True,
        password=None,
        directory=None
    ))
    # ('/tmp/cookiecutter-pypackage', False)



# Generated at 2022-06-23 16:24:41.966770
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for the function `repository_has_cookiecutter_json`.

    Create a temporary directory, a sub-directory, and an empty file
    in that sub-directory. Then assert that the `repository_has_cookiecutter_json`
    function returns True for the sub-directory, but returns False for the
    parent directory.

    Finally, create a `cookiecutter.json` file in the sub-directory, and
    assert that the function returns True for the sub-directory.
    """
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_sub_dir = os.path.join(temp_dir, 'temp_sub_dir')

# Generated at 2022-06-23 16:24:45.656090
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') is True
    assert repository_has_cookiecutter_json('tests/fake-repo-post/') is False

# Generated at 2022-06-23 16:24:57.487131
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {"gh":"https://github.com/{}.git"}
    assert "https://github.com/audreyr/cookiecutter-pypackage.git" == expand_abbreviations(
        "gh:audreyr/cookiecutter-pypackage", abbrevs)
    assert "https://github.com/audreyr/cookiecutter-pypackage.git" == expand_abbreviations(
        "gh:audreyr/cookiecutter-pypackage.git", abbrevs)
    # No change expected
    assert "gh:audreyr/cookiecutter-pypackage.git" == expand_abbreviations(
        "gh:audreyr/cookiecutter-pypackage.git", {})

# Generated at 2022-06-23 16:25:07.213169
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test with a local directory
    assert determine_repo_dir('.', {}, '.', 'master', True, '/home/user/dev/etlutils') == ('/home/user/dev/etlutils', False)
    # Test with a URL
    assert determine_repo_dir('https://github.com/user/repo', {}, '.', 'master', True) == ('.', False)
    # Test with a zip file
    assert determine_repo_dir('https://github.com/user/repo/archive/master.zip', {}, '.', 'master', True) == ('.', True)
    # Test with an abbreviation

# Generated at 2022-06-23 16:25:16.817423
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('.') == True
    assert repository_has_cookiecutter_json('/Users/crad/Projects') == False
    assert repository_has_cookiecutter_json('/Users/crad/Projects/cookiecutter') == True
    assert repository_has_cookiecutter_json('/Users/crad/Projects/cookiecutter-navi') == True
    assert repository_has_cookiecutter_json('/Users/crad/Projects/cookiecutter-navi/navi-cookiecutter') == False
    assert repository_has_cookiecutter_json('/Users/crad/Projects/cookiecutter-navi/navi-cookiecutter-i') == False

# Generated at 2022-06-23 16:25:24.129602
# Unit test for function is_repo_url
def test_is_repo_url():
    git_http_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(git_http_url) is True, 'git http case failed'

    https_github_ls_url = 'https://github.com/audreyr/cookiecutter-pypackage/tree/master/%7B%7Bcookiecutter.repo_name%7D%7D'
    assert is_repo_url(https_github_ls_url) is False, 'https github ls case failed'

    local_path = '/Users/audreyr/Documents/projects/cookiecutter-pypackage'
    assert is_repo_url(local_path) is False, 'local path case failed'

# Generated at 2022-06-23 16:25:33.865823
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = determine_repo_dir("gh:audreyr/cookiecutter-pypackage", {}, "repos", 
                                                                          "main", False)
    assert template[0] == 'repos/audreyr-cookiecutter-pypackage'
    assert template[1] == False

    template = determine_repo_dir("audreyr/cookiecutter-pypackage", {}, "repos", 
                                                                          "main", False)
    assert template[0] == 'audreyr/cookiecutter-pypackage'
    assert template[1] == False

    template = determine_repo_dir("audreyr/cookiecutter-pypackage", {}, "repos", 
                                                                          "main", False, 'test')
    assert template

# Generated at 2022-06-23 16:25:44.606275
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Check determine_repo_dir function"""
    assert determine_repo_dir('foo', {'foo': 'bar'}, None, None, None) == ('bar', False)
    assert determine_repo_dir('foo', {'foo': 'bar'}, 'baz', 'spam', 'eggs') == \
           ('bar', False)
    assert determine_repo_dir('foo', {'foo': 'bar:{}'}, None, None, None,
                              'eggs', 'spam') == ('bar:spam', False)
    assert determine_repo_dir('https://github.com/foo/bar', {'foo': ':bar'},
                              'baz', 'spam', 'eggs', 'spam') == \
           ('https://github.com/foo/bar', False)
   

# Generated at 2022-06-23 16:25:53.618271
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Make sure that abbreviations expand correctly."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'email': 'user@example.com/{}',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(':audreyr/cookiecutter-pypackage',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:26:00.336065
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('cookiecutter-pypackage')
    assert not is_repo_url('./cookiecutter-pypackage')
    assert not is_repo_url('/Users/audreyr/projects/cookiecutter-pypackage')



# Generated at 2022-06-23 16:26:05.696617
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://example.com/repository.zip') == True
    assert is_zip_file('https://example.com/repository.zip?foo=bar') == True
    assert is_zip_file('https://example.com/repository.otherzip') == False
    assert is_zip_file('file:///path/to/file.zip') == True
    assert is_zip_file('file:///path/to/file.otherzip') == False
    assert is_zip_file('file:///path/to/file.zip?foo=bar') == True



# Generated at 2022-06-23 16:26:16.585266
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
            'gh': 'https://github.com/{}.git',
            'bb': 'https://bitbucket.org/{}.git',
            }
    template1 = "REPO_NAME"
    template2 = "gh:USER_NAME/REPO_NAME"
    template3 = "bb:USER_NAME/REPO_NAME"
    template4 = "NOT_AN_ABBREVIATION:USER_NAME/REPO_NAME"

    if expand_abbreviations(template1, abbreviations) != template1:
        raise Exception("test_expand_abbreviations failed")
    if expand_abbreviations(template2, abbreviations) != "https://github.com/USER_NAME/REPO_NAME.git":
        raise Exception("test_expand_abbreviations failed")


# Generated at 2022-06-23 16:26:21.630238
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    # repo_abbreviations = {}
    # template = ''
    # clone_to_dir = ''
    # checkout = ''
    # no_input = False
    #
    # determine_repo_dir(
    #     template, repo_abbreviations, clone_to_dir, checkout, no_input
    # )
    pass

# Generated at 2022-06-23 16:26:25.969471
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # A repository dir with no cookiecutter.json should be False
    assert repository_has_cookiecutter_json('./tests/fake-repo-pre') is False
    # A repository dir with cookiecutter.json should be True
    assert repository_has_cookiecutter_json('./tests/fake-repo-pre-master') is True

# Generated at 2022-06-23 16:26:36.805023
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test directory contains a valid repository with a `cookiecutter.json` file in the root.
    template = os.path.join('tests', 'test-template')
    clone_to_dir = os.path.join('tests', 'test-template-copy')
    abbreviations = {
        'test-template': template,
        'test-template-copy': clone_to_dir,
    }

    # A valid repo directory returns itself.
    assert determine_repo_dir(
        template, abbreviations, clone_to_dir, False, False
    ) == (template, False)

    # An invalid repo directory raises RepositoryNotFound.
    repo_dir = os.path.join('tests', 'not-a-repo')
    abbreviations['not-a-repo'] = repo_dir

# Generated at 2022-06-23 16:26:44.569448
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/foo/bar/baz')
    assert not is_repo_url('foo/bar/baz')
    assert not is_repo_url('./baz')

# Generated at 2022-06-23 16:26:50.110528
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from tests.test_repo import cookiecutters_dir, template_dir, template_url

    abbreviations = {'home': template_dir}
    extracted_dir, cleanup = determine_repo_dir(
        template='home',
        abbreviations=abbreviations,
        clone_to_dir=cookiecutters_dir,
        checkout=None,
        no_input=True,
        password=None,
        directory=None
    )

    assert cleanup is False



# Generated at 2022-06-23 16:27:00.292858
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:27:08.564934
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the function determine_repo_dir
    The test set is small and only tests a subset of the possible states
    in the first if elif statement
    """
    template = "https://github.com/audreyr/cookiecutter"
    abbreviations = {"cookie": "https://github.com/audreyr/cookiecutter"}
    clone_to_dir = "/tmp/cookiecutter-test"
    checkout = "8.0"
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

# Generated at 2022-06-23 16:27:18.120052
# Unit test for function is_zip_file
def test_is_zip_file():
    input_value = "https://github.com/hongtaoh/cookiecutter-flask/archive/master.zip"
    assert is_zip_file(input_value) == True
    input_value = "http://github.com/hongtaoh/cookiecutter-flask/archive/master.zip"
    assert is_zip_file(input_value) == True
    input_value = "https://github.com/hongtaoh/cookiecutter-flask/archive/master.tar.gz"
    assert is_zip_file(input_value) == False
    input_value = "https://github.com/hongtaoh/cookiecutter-flask/archive/master.zip"
    assert is_zip_file(input_value) == True

# Generated at 2022-06-23 16:27:22.917885
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    For now, it tests only the case when a valid repository is found,
    since the case when it is not found is nearly impossible to test.
    """
    assert determine_repo_dir(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        {},
        '/tmp',
        'master',
        False
    )

# Generated at 2022-06-23 16:27:30.698866
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test that abbreviations can be expanded"""
    assert expand_abbreviations('cc-j2', {'cc-j2': 'https://github.com/audreyr/cookiecutter-pypackage'}) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', {'cc-j2': 'https://github.com/audreyr/cookiecutter-pypackage'}) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:27:36.540248
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Verify that repository_has_cookiecutter_json works properly.
    """
    repo_directory = os.path.dirname(os.path.abspath(__file__))
    assert repository_has_cookiecutter_json(repo_directory) == False
    assert repository_has_cookiecutter_json("/") == False

# Generated at 2022-06-23 16:27:47.089520
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Return True if directory contains a cookiecutter.json file"""

    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/{{cookiecutter.repo_name}}/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/{{cookiecutter.dir_name}}/') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/{{cookiecutter.dir_name}}') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/cookiecutter.json') == False

# Generated at 2022-06-23 16:27:58.258281
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:28:08.797668
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = dict(gh='https://github.com/{}')
    clone_to_dir = 'my_directory'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    template_1 = '/my/directory'
    template_2 = 'gh:audreyr/cookiecutter-pypackage'
    template_3 = 'gh:audreyr/cookiecutter-pypackage.zip'
    template_4 = '/my/directory:subdir'

    repo_dir_1, cleanup_1 = determine_repo_dir(
        template_1,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    repo_dir_2, cleanup_2 = determine_re

# Generated at 2022-06-23 16:28:16.389531
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter', abbrevs) == 'https://github.com/audreyr/cookiecutter.git'
    assert expand_abbreviations('https://github.com/audreyr/cookiecutter.git', abbrevs) == 'https://github.com/audreyr/cookiecutter.git'


# Generated at 2022-06-23 16:28:21.632688
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('asdf.zip')
    assert is_zip_file('asdf.ZIP')
    assert is_zip_file('../asdf.zip')
    assert is_zip_file('/asdf/asdf/asdf.zip')
    assert is_zip_file('../asdf.zip')
    assert is_zip_file('asdf.ZIP')

# Generated at 2022-06-23 16:28:29.489357
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/mhcao916/cookiecutterPython"
    abbreviations = {}
    clone_to_dir = os.getcwd()
    checkout = ""
    no_input = True
    directory = ""
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir,
                                           checkout, no_input, directory=directory)

    print("determine_repo_dir: repo_dir={}".format(repo_dir))
    print("determine_repo_dir: cleanup={}".format(cleanup))


if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-23 16:28:37.927244
# Unit test for function determine_repo_dir

# Generated at 2022-06-23 16:28:40.677198
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    os.remove("tests/test-repo-tmpl/.git")
    assert repository_has_cookiecutter_json("tests/test-repo-tmpl/")

# Generated at 2022-06-23 16:28:41.652790
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # TODO: add unittest for this
    pass

# Generated at 2022-06-23 16:28:49.201812
# Unit test for function is_repo_url
def test_is_repo_url():
    urls = [
        'git@github.com:audreyr/cookiecutter-pypackage.git',
        'git://github.com/audreyr/cookiecutter-pypackage.git',
        'git@bitbucket.org:pokoli/cookiecutter-tryton.git',
        'hg+https://bitbucket.org/pokoli/cookiecutter-tryton',
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'https://bitbucket.org/pokoli/cookiecutter-tryton',
    ]

    for url in urls:
        assert is_repo_url(url) is True

   

# Generated at 2022-06-23 16:29:02.100284
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir('django') == 'django'
    assert determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git') == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert determine_repo_dir('audreyr/cookiecutter-pypackage') == 'audreyr/cookiecutter-pypackage'
    assert determine_repo_dir('git@github.com:audreyr/cookiecutter-pypackage.git') == 'git@github.com:audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:29:08.468146
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert(repository_has_cookiecutter_json('../test_entry_points'))
    assert(repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage'))

if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-23 16:29:13.177096
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    assert repository_has_cookiecutter_json('/') == False
    assert repository_has_cookiecutter_json('/fake_dir') == False
    assert repository_has_cookiecutter_json('/fake_dir/') == False
    assert repository_has_cookiecutter_json('/fake_dir/fake_dir/fake_dir') == False

# Generated at 2022-06-23 16:29:23.985691
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import sys
    import shutil

    if sys.version_info[0] == 3 and sys.version_info[1] >= 3:
        from tempfile import TemporaryDirectory
    else:
        from backports.tempfile import TemporaryDirectory

    d1 = TemporaryDirectory()

    os.mkdir(os.path.join(d1.name, "test_dir"))
    file = os.path.join(d1.name, "test_dir", "cookiecutter.json")
    f = open(file, 'w')
    f.write('')

    result = repository_has_cookiecutter_json(
        os.path.join(d1.name, "test_dir"))

    assert result is True, 'repository_has_cookiecutter_json failed'

    shutil.rmtree(file)
   

# Generated at 2022-06-23 16:29:26.009496
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('fake_dir') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True

# Generated at 2022-06-23 16:29:28.106737
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    determine_repo_dir('/Users/chris/projects/cookiecutter-example', {'CCE': 'cookiecutter-example'}, '/Users/chris/projects', 'master', False, None)

# Generated at 2022-06-23 16:29:37.171108
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Setup
    template = "cc-master"
    abbreviations = {"cc-master": "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"}
    directory = "tests/test-temp"
    clone_to_dir = "tests/test-temp"

    # Run test case
    repo_candidate, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, '', False, None, directory)
    assert repo_candidate == "tests/test-temp/cookiecutter-pypackage-master/tests/test-temp/cookiecutter.json"
    assert cleanup is False

# Generated at 2022-06-23 16:29:39.220418
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert not is_zip_file('test.ZIP')
    assert not is_zip_file('test.txt')

# Generated at 2022-06-23 16:29:47.528715
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Assert that a valid directory returns True."""

# Generated at 2022-06-23 16:29:52.315085
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    a_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl')
    assert repository_has_cookiecutter_json(
        a_dir
    ), 'This should return true'
    assert not repository_has_cookiecutter_json(
        'fake_dir'
    ), 'This should return false'


# Generated at 2022-06-23 16:29:58.924311
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert(expand_abbreviations("gh", {"gh": "https://github.com/{}"}) == "https://github.com/gh")
    
    assert(expand_abbreviations("gh:janedoe/demo-repo", {"gh": "https://github.com/{}"}) == "https://github.com/janedoe/demo-repo")
    
    assert(expand_abbreviations("gh:janedoe/demo-repo", {"gh": "https://github.com/{0}"}) == "https://github.com/janedoe/demo-repo")
    

# Generated at 2022-06-23 16:30:02.947046
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    cwd = os.getcwd()
    repo_directory = os.path.join(cwd, 'tests/fake-repo-tmpl')
    assert not repository_has_cookiecutter_json(repo_directory)



# Generated at 2022-06-23 16:30:14.041448
# Unit test for function is_repo_url
def test_is_repo_url():
    # Empty string
    assert not is_repo_url('')

    # Local file path
    assert not is_repo_url('./boo-yah')

    # HTTP URL
    assert is_repo_url('http://example.com/slug')

    # HTTPS URL
    assert is_repo_url('https://example.com/slug')

    # SSH URL
    assert is_repo_url('git@example.com:slug')

    # Git URL
    assert is_repo_url('git://example.com/slug')

    # Mercurial URL
    assert is_repo_url('hg+http://example.com/slug')

    # Username + password
    assert is_repo_url('http://username:password@example.com/slug')

    # Username

# Generated at 2022-06-23 16:30:25.341561
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test the expand_abbreviations function"""
    # Setup
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }

# Generated at 2022-06-23 16:30:28.120636
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        '..',
        'tests',
        'fake-repo'))


# Generated at 2022-06-23 16:30:36.842024
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'test': 'tests/test-repo.git'
    }
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory=None
    

# Generated at 2022-06-23 16:30:44.731508
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test is_repo_url function.

    # Input
    value = 'git+git://github.com/audreyr/cookiecutter-pypackage.git'
    # Output
    True
    """
    inputs = [
        'git+git://github.com/audreyr/cookiecutter-pypackage.git',
    ]
    outputs = [
        True
    ]

    for i in inputs:
        assert is_repo_url(i)

    for o in outputs:
        assert o


# Generated at 2022-06-23 16:30:50.065480
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations={"pypackage" : "https://github.com/audreyr/cookiecutter-pypackage.git"}
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    expected = "https://github.com/audreyr/cookiecutter-pypackage.git"
    assert template == expected
    template = 'pypackage'
    assert template == expected

# Generated at 2022-06-23 16:30:53.718650
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("abc.zip")
    assert is_zip_file("abc.ZIP")
    assert not is_zip_file("abc.zipx")
    assert not is_zip_file("abc.txt")

test_is_zip_file()

# Generated at 2022-06-23 16:31:03.535575
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import __file__ as cookiecutter_file
    from os.path import dirname, join

    cookiecutter_path = dirname(cookiecutter_file)
    fixture_path = join(cookiecutter_path, 'tests', 'test-cookiecutters')
    fixtures = [
        join(fixture_path, 'example-repo-tmpl'),
        join(fixture_path, 'example-repo-tmpl-master', 'foobar'),
        join(fixture_path, 'example-repo-tmpl-master'),
        join(fixture_path, 'example-repo-tmpl-master', 'fake')
    ]

    for fixture in fixtures:
        assert repository_has_cookiecutter_json(fixture)

# Unit tests for function determine_repo_dir

# Generated at 2022-06-23 16:31:07.814208
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""
    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    actual = is_repo_url(template)
    expected = True
    assert actual == expected

# Generated at 2022-06-23 16:31:17.704638
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('https://github.com/pizzapanther/cookiecutter-example-pypackage-minimal/') == True
    assert repository_has_cookiecutter_json('https://github.com/pizzapanther/cookiecutter-example-pypackage-minimal') == True
    assert repository_has_cookiecutter_json('https://github.com/pizzapanther/cookiecutter-example-pypackage-minimal/cookiecutter.json') == False
    assert repository_has_cookiecutter_json('/home/pizzapanther/Desktop/cookiecutter-example-pypackage-minimal') == True

# Generated at 2022-06-23 16:31:24.174146
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_template = "project_name"
    test_abbreviations = {"foo": "https://github.com/bar/baz", "project_name": "project_name:master"}
    test_clone_to_dir = "/path/to/clone/directory"
    test_checkout = "master"
    test_no_input = False
    test_password = "bad_password"
    test_directory = "test_directory"



# Generated at 2022-06-23 16:31:26.975225
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip')
    assert not is_zip_file('foo.tar')
    assert is_zip_file('foo.ZIP')

# Unit tests for function is_repo_url

# Generated at 2022-06-23 16:31:33.293526
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage',
        abbreviations={
            'gh': 'https://github.com/{}.git',
            'bb': 'https://bitbucket.org/{}',
        }
    ) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations(
        'audreyr/cookiecutter-pypackage',
        abbreviations={
            'gh': 'https://github.com/{}.git',
            'bb': 'https://bitbucket.org/{}',
        }
    ) == 'audreyr/cookiecutter-pypackage'


# Generated at 2022-06-23 16:31:34.724332
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    determine_repo_dir("https://github.com/cookiecutter-django/cookiecutter-django.git")

# Generated at 2022-06-23 16:31:46.444182
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'notapath': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'notapath-with-sc': 'https://github.com/audreyr/{}.git',
        'cloned_repo': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'localpath': 'tests/fake-repo-tmpl',
    }

    repo_dir, cleanup = determine_repo_dir(
        template='localpath',
        abbreviations=abbreviations,
        clone_to_dir='./tests/test-tmp',
        checkout=None,
        no_input=False,
        password=None,
        directory=None
    )

# Generated at 2022-06-23 16:31:50.475878
# Unit test for function is_zip_file
def test_is_zip_file():
    """ Test the is_zip_file method """
    test_string = 'http://helloworld.com/zip.zip'
    expected_result = True
    actual_result = is_zip_file(test_string)

    assert actual_result == expected_result


# Generated at 2022-06-23 16:32:01.635187
# Unit test for function is_repo_url
def test_is_repo_url():
    """ Check if is_repo_url returns true for valid repo urls"""
    repo_urls = [
        'git://github.com/audreyr/cookiecutter-pypackage.git',
        'git@git.somewhere.com:audreyr/cookiecutter-pypackage.git',
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'https://github.com/audreyr/cookiecutter-pypackage',
        'https://github.com/audreyr/cookiecutter-pypackage/',
        'git@git.somewhere.com:audreyr/cookiecutter-pypackage',
        'git://github.com/audreyr/cookiecutter-pypackage',
    ]



# Generated at 2022-06-23 16:32:12.367064
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.com/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:pokonski/cookiecutter-django-rest', abbreviations) == 'https://bitbucket.com/pokonski/cookiecutter-django-rest.git'

# Generated at 2022-06-23 16:32:23.310426
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'cookiecutter-django'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl')
    checkout = 'master'
    no_input = False
    password = None
    directory = 'mydir'

    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

if __name__ == '__main__':
    template = 'cookiecutter-django'
    abbreviations = {'gh': 'https://github.com/{}.git'}

# Generated at 2022-06-23 16:32:30.792652
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("capstone_project.zip")
    # assert is not a zip file
    assert is_zip_file("some_package.tar.gz") == False
    assert is_zip_file("my_repo") == False
    assert is_zip_file("git+git@github.com:dylanjorgensen/cookiecutter-pytest-plugin.git") == False
    print("test for is_zip_file() passed")


# Generated at 2022-06-23 16:32:39.068244
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import pytest
    assert os.path.exists('cookiecutter-pypackage')
    assert os.path.exists('cookiecutter-pypackage-master')
    assert os.path.exists(os.path.join('cookiecutter-pypackage-master', 'cookiecutter.json'))
    assert os.path.exists(os.path.join('cookiecutter-pypackage', 'cookiecutter.json'))
    assert os.path.exists(os.path.join('cookiecutter-pypackage', 'README.rst'))
    assert os.path.exists(os.path.join('cookiecutter-pypackage', 'setup.py'))

# Generated at 2022-06-23 16:32:48.401414
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_repo = 'tests/fake-repo-tmpl'
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = '.'
    checkout = None
    no_input = False
    password = None
    directory = None

    # Test when template is a url
    test_repo, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert os.path.exists(test_repo)
    assert(cleanup == False)

    # Test when template is a local path
    template = test_repo
    test_repo, cleanup = determine_repo

# Generated at 2022-06-23 16:32:55.731023
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
        }
    template = "gh:audreyr/cookiecutter-pypackage"
    actual = expand_abbreviations(template, abbrevs)
    expected = "https://github.com/audreyr/cookiecutter-pypackage.git"
    assert actual == expected, (
        "Expected '{}', but got '{}'".format(expected, actual)
        )



# Generated at 2022-06-23 16:33:01.245422
# Unit test for function is_zip_file
def test_is_zip_file():
    assert(is_zip_file('template.zip') == True)
    assert(is_zip_file('template.tar.gz') == False)
    assert(is_zip_file('template.ZIP') == True)
    assert(is_zip_file('template.Zip') == True)

# Generated at 2022-06-23 16:33:07.284869
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import main
    from cookiecutter.config import get_user_config
    from cookiecutter import utils
    from cookiecutter.vcs import clone
    from cookiecutter.zipfile import unzip

    user_config = get_user_config()
    repo = 'gh:audreyr/cookiecutter-pypackage-minimal' # repo with cookiecutter.json
    template_folder, cleanup = determine_repo_dir(
        repo,
        user_config.get('cookiecutters_dir'),
        None,
        None,
        False,
        password=None,
    )

    assert template_folder == 'cookiecutter-pypackage-minimal'
    assert cleanup == True


# Generated at 2022-06-23 16:33:18.849135
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test if expand abbreviations works"""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    assert expand_abbreviations('username/repo', abbreviations) == \
        'username/repo'
    assert expand_abbreviations('gh:audreyr/cookiecutter', abbreviations) == \
        'https://github.com/audreyr/cookiecutter.git'
    assert expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('pypackage', abbreviations)