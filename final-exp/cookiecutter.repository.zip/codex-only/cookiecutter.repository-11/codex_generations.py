

# Generated at 2022-06-23 16:23:22.462933
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Run tests on function is_repo_url to check for various types of input
    and return expected True/False statements
    """
    assert is_repo_url('https://github.com/foo/bar.git') == True
    assert is_repo_url('git@github.com:foo/bar.git') == True
    assert is_repo_url('/path/to/my/dir') == False
    assert is_repo_url('foo/bar') == False

# Generated at 2022-06-23 16:23:24.609774
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("abc.zip")
    assert is_zip_file("abc.ZIP")
    assert not is_zip_file("abc.ZIB")



# Generated at 2022-06-23 16:23:35.489624
# Unit test for function is_repo_url
def test_is_repo_url():
    # test URLs
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:atlassianlabs/common-build-scripts.git')
    assert is_repo_url('https://bitbucket.org/pokoli/cookiecutter-tryton.git')
    assert is_repo_url('git://github.com/ionelmc/cookiecutter-pylibrary.git')

    # test non-URLs
    assert not is_repo_url('not_a_url')

# Generated at 2022-06-23 16:23:44.570825
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test some common cases to ensure that is_repo_url is working."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')
    assert not is_repo_url('')
    assert is_repo_url('git+https://github.com/audreyr/'
                       'cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+ssh://git@github.com:audreyr/'
                       'cookiecutter-pypackage.git')
    assert is_

# Generated at 2022-06-23 16:23:48.885488
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') is True
    assert is_zip_file('test.ZIP') is True
    assert is_zip_file('testzip') is False
    assert is_zip_file('test.zip.gz') is False
    assert is_zip_file('test.gsz') is False

# Generated at 2022-06-23 16:23:51.184103
# Unit test for function is_zip_file
def test_is_zip_file():
  assert is_zip_file("somefile.zip")
 

# Generated at 2022-06-23 16:23:55.694224
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip') and is_zip_file('abc.ZIP') and is_zip_file('abc.Zip')
    assert not is_zip_file('abc') and not is_zip_file('.zip') and not is_zip_file('zip')


# Generated at 2022-06-23 16:24:05.824088
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/foo/bar') == True
    assert is_repo_url('foo') == False
    assert is_repo_url('git://foo.com') == True
    assert is_repo_url('https://foo.net/bar/baz.git') == True
    assert is_repo_url('/var/tmp/bar') == False
    assert is_repo_url('file:///tmp/bar') == True
    assert is_repo_url('foo+http://example.com/bar') == True
    assert is_repo_url('foo@example.com:bar/baz') == True
    assert is_repo_url('') == False


# Generated at 2022-06-23 16:24:09.223180
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("cookiecutter.zip") == True
    assert is_zip_file("cookiecutter.tar.gz") == False
    assert is_zip_file("cookiecutter") == False


# Generated at 2022-06-23 16:24:12.598927
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Given
    repo_directory = 'tests/fake-repo-tmpl'

    # When
    result = repository_has_cookiecutter_json(repo_directory)

    # Then
    assert result == True


# Generated at 2022-06-23 16:24:16.265092
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test that repository_has_cookiecutter_json returns True if
    the passed in directory contained a cookiecutter.json.
    """
    assert repository_has_cookiecutter_json('/') == False


# Generated at 2022-06-23 16:24:27.497760
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    if os.path.exists('/tmp/cookiecutter-tests/'):
        shutil.rmtree('/tmp/cookiecutter-tests/')
    os.mkdir('/tmp/cookiecutter-tests/')

    # create simple template, add cookiecutter.json, add .nojekyll, commit and push
    os.mkdir('/tmp/cookiecutter-tests/simple_template/')
    os.mkdir('/tmp/cookiecutter-tests/simple_template/{{cookiecutter.repo_name}}/')
    with open('/tmp/cookiecutter-tests/simple_template/cookiecutter.json', 'w') as f:
        f.write('{"repo_name": "simpletest"}')

# Generated at 2022-06-23 16:24:40.594908
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import tempfile

    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.exceptions import RepositoryNotFound


# Generated at 2022-06-23 16:24:48.711361
# Unit test for function is_zip_file
def test_is_zip_file():
    print("Check if is_zip_file() works as intended...")
    test_cases = [
        ("https://github.com/rbaron/cookiecutter-pypackage/archive/master.zip",
         True),
        ("/Users/rbaron/Code/cookiecutter-pypackage", False)
    ]
    for test_case in test_cases:
        print("\t{} --> {}".format(test_case[0],
                                   is_zip_file(test_case[0])))
        assert is_zip_file(test_case[0]) == test_case[1]

# Generated at 2022-06-23 16:24:59.184035
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    #Case 1: Template directory exists with cookiecutter.json
    assert repository_has_cookiecutter_json(
        "/home/kartikey/Desktop/cookiecutter-dynamic-boilerplate") == True
    #Case 2: Template directory does not exists
    assert repository_has_cookiecutter_json(
        "/home/kartikey/Desktop/cookiecutter-dynamic-boilerplate-2") == False
    #Case 3: Template directory exists without cookiecutter.json
    assert repository_has_cookiecutter_json(
        "/home/kartikey/Desktop/cookiecutter-dynamic-boilerplate-3") == False

if __name__ == '__main__':
    test_repository_has_cookiecutter_json()

# Generated at 2022-06-23 16:25:01.053238
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("./tests/fake-repo-pre/") is True


# Generated at 2022-06-23 16:25:03.283284
# Unit test for function is_repo_url
def test_is_repo_url():
    repo_url = 'https://github.com/jhermann/cookiecutter-flask-skeleton'
    assert is_repo_url(repo_url) == True


# Generated at 2022-06-23 16:25:06.041388
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert  repository_has_cookiecutter_json('/Users/bwilson/repos/cookiecutter-pypackage-minimal') == True

# Generated at 2022-06-23 16:25:08.343717
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(os.path.join(os.path.dirname(__file__), '..'))
    assert not repository_has_cookiecutter_json(os.path.join(os.path.dirname(__file__), 'unit_tests'))

# Generated at 2022-06-23 16:25:17.942131
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Verify that repository_has_cookiecutter_json returns True if the specified
    directory contains a cookiecutter.json file, else False
    """
    cwd = os.getcwd()

    os.chdir('tests/fake-repo-tmpl')

    #repository_has_cookiecutter_json checks the argument is a directory that
    #exists, before testing it is a valid cookiecutter template repository
    assert not repository_has_cookiecutter_json('/tmp/does-not-exist')
    assert not repository_has_cookiecutter_json('tests/fake-repo-tmpl')

    os.chdir('tests/fake-repo-pre/')
    assert not repository_has_cookiecutter_json('./tests/fake-repo-pre')

    assert repository_has_cookie

# Generated at 2022-06-23 16:25:29.775448
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir("/test", {}, "", "", ""
            ) == ("/test", False)
    assert determine_repo_dir("/test/", {}, "", "", ""
            ) == ("/test/", False)
    assert determine_repo_dir("C:/test", {}, "", "", ""
            ) == ("C:/test", False)
    assert determine_repo_dir("C:/test/", {}, "", "", ""
            ) == ("C:/test/", False)
    assert determine_repo_dir("C:\\test", {}, "", "", ""
            ) == ("C:\\test", False)
    assert determine_repo_dir("C:\\test\\", {}, "", "", ""
            ) == ("C:\\test\\", False)
   

# Generated at 2022-06-23 16:25:39.379813
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test that abbreviations in the template name are expanded correctly.
    """

    abbreviations = {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}'
    }

    # Test a template name containing no abbreviations.
    template_no_abbrev = 'example'
    assert expand_abbreviations(template_no_abbrev, abbreviations) == 'example'

    # Test a template name containing an abbreviation at the beginning.
    template_abbrev_begin = 'bb:accountname/repo'
    assert expand_abbreviations(template_abbrev_begin, abbreviations) == \
           'https://bitbucket.org/accountname/repo'

    # Test a template name containing an abbreviation in the middle.

# Generated at 2022-06-23 16:25:50.376466
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git#egg=package-name')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git#egg=package-name&subdirectory=cookiecutter.json')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:25:54.246611
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter.zip') == True
    assert is_zip_file('cookiecutter.json') == False
    assert is_zip_file('cookiecutter.ZIP') == True

# Generated at 2022-06-23 16:26:00.296209
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = "~/cookiecutters/cookiecutter-pypackage"
    repo_directory_exists = os.path.isdir(repo_directory)
    assert(repo_directory_exists)

    repo_config_exists = os.path.isfile(
        os.path.join(repo_directory, 'cookiecutter.json')
    )
    assert(repo_config_exists)

    assert(repository_has_cookiecutter_json(repo_directory))

# Generated at 2022-06-23 16:26:05.256107
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Make sure directory and abbreviations are properly expanded."""
    abbreviations = {'gh': 'https://github.com/{}.git'}

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'  # noqa

    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'  # noqa

# Generated at 2022-06-23 16:26:10.187839
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:26:13.433077
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from pytest_cookies.plugin import fixture_path
    template = os.path.join(fixture_path('demo-repo-template'), '{{ cookiecutter.demo_name }}')
    abbreviations = {}
    checkout = ''
    clone_to_dir = ''
    no_input = False

    assert os.path.exists(template)
    determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input)
    assert True

# Generated at 2022-06-23 16:26:19.944746
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}'
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://bitbucket.org/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == \
        'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:26:24.322085
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json"""
    assert repository_has_cookiecutter_json('.') == False
    here = os.path.abspath(os.path.dirname(__file__))
    repo = os.path.join(here,'../tests/fake-repo/')
    assert repository_has_cookiecutter_json(repo) == True

# Generated at 2022-06-23 16:26:32.308968
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_string = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='C:\\Users\\Bob\\Documents\\GitHub\\',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )
    assert test_string == (
        'C:\\Users\\Bob\\Documents\\GitHub\\cookiecutter-pypackage',
        False,
    )

# Generated at 2022-06-23 16:26:41.576638
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the repository_has_cookiecutter_json function."""
    # Repo has a cookiecutter.json
    assert (
        repository_has_cookiecutter_json(
            os.path.join(
                os.path.dirname(__file__),
                '../../tests/fixtures/fake-repo-pre/',
            )
        )
        is True
    )

    # Repo has no cookiecutter.json
    assert (
        repository_has_cookiecutter_json(
            os.path.join(
                os.path.dirname(__file__),
                '../../tests/fixtures/fake-repo-pre/fake-pre-repo',
            )
        )
        is False
    )

# Generated at 2022-06-23 16:26:50.465745
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import pytest
    with pytest.raises(RepositoryNotFound):
        assert not repository_has_cookiecutter_json('')
    assert not repository_has_cookiecutter_json('/not/a/valid/file/path')
    assert not repository_has_cookiecutter_json('./tests')
    assert not repository_has_cookiecutter_json('./tests/fake-repo-tmpl')
    assert repository_has_cookiecutter_json('./tests/fake-repo-tmpl-notags')
    assert repository_has_cookiecutter_json('./tests/fake-repo-tmpl-notags/no/extra/path/')


# Generated at 2022-06-23 16:26:51.573399
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/tmp/django_app.zip') is True

# Generated at 2022-06-23 16:27:01.953524
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    from cookiecutter.utils import (
        rmtree,
        make_sure_path_exists,
        is_repo_url,
        is_zip_file,
    )

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

    # Create a temp directory to clone into
    clone_to_dir = tempfile.mkdtemp()

    # Create a temp zip file
    zip_file = tempfile.NamedTemporaryFile(suffix='.zip')

    # Create a temp directory to clone into
    make_sure_path_exists(clone_to_dir)

    # Create a valid repo
    repo_dir = os.path.join(temp_dir, 'foobar')
    make_sure_path_exists(repo_dir)
    make_

# Generated at 2022-06-23 16:27:08.198495
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'cookiecutter-pypackage'
    clone_to_dir = '/home/tests/.cookiecutters'
    checkout = None
    no_input = False
    password = 'password'
    directory = None
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = expand_abbreviations(template, abbreviations)
    assert template == 'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-23 16:27:15.244236
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function is_zip_file."""
    assert is_zip_file('cookiecutter.zip') is True
    assert is_zip_file('cookiecutter.ZIP') is True
    assert is_zip_file('~/cookiecutter/test.zip') is True
    assert is_zip_file('git+https://github.com/audreyr/cookiecutter-pypackage.git') is False
    assert is_zip_file('pypackage') is False

# Generated at 2022-06-23 16:27:24.149172
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    This function was added to the project template repository;
    the directory argument is set to this function.

    This test function tests the function
    repository_has_cookiecutter_json()

    This function is in the for loop for
    repository_candidates = [template, os.path.join(clone_to_dir, template)]
    in the function determine_repo_dir()

    This function is called from cookiecutter.main()

    check the template with:
       assert repository_has_cookiecutter_json(repo_candidate) == True
    """
    check = repository_has_cookiecutter_json(dir)
    assert check == True



# Generated at 2022-06-23 16:27:31.558245
# Unit test for function is_repo_url
def test_is_repo_url():
    def assert_is_repo_url(value, expected):
        assert is_repo_url(value) == expected

    # Git protocol
    assert_is_repo_url('git://github.com/audreyr/cookiecutter.git', True)
    assert_is_repo_url('git+git://github.com/audreyr/cookiecutter.git', True)
    assert_is_repo_url('git+ssh://github.com/audreyr/cookiecutter.git', True)
    assert_is_repo_url('git+https://github.com/audreyr/cookiecutter.git', True)
    assert_is_repo_url('git+file://github.com/audreyr/cookiecutter.git', True)

    # Git protocol with user
    assert_is

# Generated at 2022-06-23 16:27:37.331895
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if a repo has cookiecutter.json file."""
    assert repository_has_cookiecutter_json('/tmp') == False
    assert repository_has_cookiecutter_json('/tmp/cookiecutter-master') == False
    assert repository_has_cookiecutter_json('/tmp/cookiecutter-master/cookiecutter.json') == True

# Generated at 2022-06-23 16:27:47.712992
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        # GitHub repos
        'gh': 'https://github.com/{}.git',
        'bk': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git',
    }
    # Abbreviations with one positional argument
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bk:alex/cookiecutter-django', abbreviations) == \
        'https://bitbucket.org/alex/cookiecutter-django.git'

# Generated at 2022-06-23 16:27:52.992382
# Unit test for function is_zip_file
def test_is_zip_file():
    assert not is_zip_file('git://...')
    assert not is_zip_file('foo')
    assert not is_zip_file('foo.json')
    assert is_zip_file('foo.zip')
    assert is_zip_file('foo.ZIP')

# Generated at 2022-06-23 16:28:04.803943
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for function repository_has_cookiecutter_json."""
    from .vcs import remove
    from .zipfile import remove_repo_from_checked_out_zip
    from .api import get_user_config

    # Create temporary user config
    config_dict = {'cookiecutters_dir': '~/.cookiecutters/'}
    config_file = get_user_config(config_file=None, default_config=config_dict)
    config_file.close()

    # Create temporary cookiecutter.json file
    cookiecutter_file = open('./tests/fake-repo-tmpl/cookiecutter.json', 'w')
    cookiecutter_file.write('{"key": "value"}')
    cookiecutter_file.close()

    # Create temporary cookiecutters directory

# Generated at 2022-06-23 16:28:08.439952
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip') == True
    assert is_zip_file('file.tar.gz') == False
    assert is_zip_file('file.txt') == False
    assert is_zip_file('file.zip.txt') == False


# Generated at 2022-06-23 16:28:19.899337
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json"""
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create a random directory with cookiecutter.json
    tmp_repo_dir = tempfile.mkdtemp(dir=tmp_dir)
    cookiecutter_json_file = open(tmp_repo_dir + '/cookiecutter.json', 'w')
    cookiecutter_json_file.close()

    # create a random directory with no cookiecutter.json
    tmp_no_json_repo_dir = tempfile.mkdtemp(dir=tmp_dir)

    assert repository_has_cookiecutter_json(tmp_repo_dir)

# Generated at 2022-06-23 16:28:22.375802
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        "tmp/ccdemo",
        {},
        "/tmp",
        None,
        True,
        None) == ("/tmp/tmp/ccdemo", False)

# Generated at 2022-06-23 16:28:28.747460
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template1 = 'gh:audreyr/cookiecutter-pypackage'
    template2 = 'audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template1, abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template2, abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:28:30.559280
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test is_zip_file."""
    assert is_zip_file("test.zip")
    assert not is_zip_file("test.tar.gz")



# Generated at 2022-06-23 16:28:38.956456
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test that is_repo_url works as expected."""
    import cookiecutter.repository as r
    assert r.is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not r.is_repo_url('/home/audreyr/cookiecutter-pypackage')
    assert r.is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not r.is_repo_url('cookiecutter-pypackage')
    assert r.is_repo_url('zestedesavoir/zds-site')

# Generated at 2022-06-23 16:28:41.033856
# Unit test for function is_zip_file
def test_is_zip_file():  
    assert is_zip_file('x.zip') == True
    assert is_zip_file('x.ZIP') == True
    assert is_zip_file('x.xzip') == False

# Generated at 2022-06-23 16:28:47.201016
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""
    url = (
        'git+git@github.com:audreyr/cookiecutter-pypackage.git'
        '#egg=cookiecutter-pypackage'
    )
    assert is_repo_url(url)
    assert not is_repo_url('foo')

# Generated at 2022-06-23 16:28:53.458702
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Determine if a directory contains a `cookiecutter.json` config file.

    :param repo_directory: The candidate repository directory.
    :return: True if the `repo_directory` is valid, else False.
    """
    repo_directory = "example"
    assert repository_has_cookiecutter_json(repo_directory) == True
# test_repository_has_cookiecutter_json()

# Generated at 2022-06-23 16:28:59.264113
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('test.ZiP') == True
    assert is_zip_file('test.ZIP3') == False
    assert is_zip_file('test') == False

# Generated at 2022-06-23 16:29:09.012377
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'foobar-cookiecutter': 'https://github.com/foobar/cookiecutter-{}'
    }


# Generated at 2022-06-23 16:29:16.669429
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test case for function determine_repo_dir"""
    # Given the data
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = dict()
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    # when determine_repo_dir is called
    cookiecutter_template_directory, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    # the function should behave as expected

# Generated at 2022-06-23 16:29:26.197917
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Setup abbreviations dictionary
    abbreviation_defs = {}
    abbreviation_defs["gh"] = "https://github.com/{}.git"
    abbreviation_defs["bb"] = "https://bitbucket.org/{}.git"
    abbreviation_defs["ghu"] = "https://{}@github.com/{}.git"
    abbreviation_defs["gho"] = "https://github.com/{}/{}.git"

    # Test expansion of abbreviations
    assert(expand_abbreviations("gh:bob/proj", abbreviation_defs) == "https://github.com/bob/proj.git")

# Generated at 2022-06-23 16:29:37.680309
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url("github.com:jacebrowning/template-repo") is False
    assert is_repo_url("github.com/jacebrowning/template-repo") is False
    assert is_repo_url("git@github.com:jacebrowning/template-repo.git") is False
    assert is_repo_url("git@github.com/jacebrowning/template-repo.git") is False
    assert is_repo_url("github.com:jacebrowning/template-repo") is False
    assert is_repo_url("git@github.com:jacebrowning/template-repo.git") is False
    assert is_repo_url("local-directory") is False

# Generated at 2022-06-23 16:29:46.113268
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://example.com/org/project.git')
    assert is_repo_url('git+ssh://example.com/org/project.git')
    assert is_repo_url('git+https://example.com/org/project.git')
    assert is_repo_url('git+file://example.com/org/project.git')
    assert is_repo_url('git+file:///example.com/org/project.git')
    assert is_repo_url('http://example.com/org/project.git')
    assert is_repo_url('https://example.com/org/project.git')
    assert is_repo_url('ssh://example.com/org/project.git')

# Generated at 2022-06-23 16:29:55.416488
# Unit test for function is_repo_url
def test_is_repo_url():
    # test with valid url
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git/') == True

    # test with invalid url
    assert is_repo_url('/my/path/to/cookiecutter-pypackage.git') == False
    assert is_repo_url('/my/path/to/cookiecutter-pypackage') == False

# Generated at 2022-06-23 16:30:03.213085
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "b": "https://bitbucket.org/{}",
        "g": "https://github.com/{}",
    }

    template = "b:cookiecutter-django/cookiecutter-django"
    result = expand_abbreviations(template, abbreviations)
    assert result == "https://bitbucket.org/cookiecutter-django/cookiecutter-django"

# Generated at 2022-06-23 16:30:14.261414
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Verify that `repository_has_cookiecutter_json` works correctly.

    :return: `None` if the test passes, raises AssertionError if test fails.
    """
    test_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test_dir')
    )
    assert repository_has_cookiecutter_json(test_dir) is True
    assert repository_has_cookiecutter_json(os.path.join(test_dir, '.')) is True
    assert repository_has_cookiecutter_json(
        os.path.join(test_dir, '..', '..')
    ) is False

# Generated at 2022-06-23 16:30:18.065624
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    template_path = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-template'
    )
    assert repository_has_cookiecutter_json(template_path)



# Generated at 2022-06-23 16:30:23.573981
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    checks for a cookiecutter.json file in directory
    """
    repo_directory = 'cookiecutter-pypackage/'
    assert repository_has_cookiecutter_json(repo_directory)
    repo_directory = 'tests/fake-repo-tmpl/'
    assert repository_has_cookiecutter_json(repo_directory)



# Generated at 2022-06-23 16:30:32.564753
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test the is_repo_url function.
    """
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage/')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('~/path/to/cookiecutter-pypackage')
    assert not is_repo_url('path/to/cookiecutter-pypackage')
    assert not is_repo_url('/path/to/cookiecutter-pypackage')

# Generated at 2022-06-23 16:30:43.687348
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}',
        'ghu': 'https://{}.github.io',
        'bb': 'https://bitbucket.org/{}',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage'

    template = 'ghu:audreyr'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://audreyr.github.io'

    template = 'bb:atugushev/cookiecutter-django/'
    expanded_template = expand_abbre

# Generated at 2022-06-23 16:30:48.378953
# Unit test for function is_repo_url
def test_is_repo_url():
    assert(is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('hg+https://bitbucket.org/pokoli/somemodule'))
    assert(is_repo_url('user@hostname:user/repo.git'))
    assert(not is_repo_url('git://github.com/audreyr/'))
    assert(not is_repo_url('@non-existant'))

# Generated at 2022-06-23 16:30:53.837347
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') is True

# Generated at 2022-06-23 16:30:58.689801
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    cloned_repo = clone(
        repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git',
        checkout = None,
        clone_to_dir = '/tmp',
        no_input = False,
    )
    assert repository_has_cookiecutter_json(cloned_repo)

# Generated at 2022-06-23 16:31:00.475456
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print("testing")
    assert determine_repo_dir("", "", "", "", "")

# Generated at 2022-06-23 16:31:04.670611
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:31:15.916228
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # test 1: git repo
    repo_dir, cleanup = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir=tmpdir,
        checkout='',
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir == os.path.join(tmpdir, 'cookiecutter-pypackage'), 'Wrong repo dir'
    assert cleanup == False, 'Should not clean up repo dir'

    shutil.rmtree(os.path.join(tmpdir, 'cookiecutter-pypackage'))

   

# Generated at 2022-06-23 16:31:26.154079
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # import unittest
    import click
    from click.testing import CliRunner
    from .version import __version__

    from .main import cookiecutter

    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    non_git_url = 'https://example.com/project.zip'
    runner = CliRunner()
    result = runner.invoke(
        cookiecutter,
        ['--no-input', '--overwrite-if-exists', repo_url, '--output-dir={}'.format(os.path.join("tests", "fake-repo"))],
    )
    assert result.exit_code == 0


# Generated at 2022-06-23 16:31:34.829728
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('nope', abbreviations) == \
        'nope'

# Generated at 2022-06-23 16:31:39.275706
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    directory = 'C://Users//kamal marawat'
    result1 = True
    result2 = False
    assert repository_has_cookiecutter_json(directory) == result1
    assert repository_has_cookiecutter_json(directory) != result2


# Generated at 2022-06-23 16:31:41.460537
# Unit test for function is_zip_file
def test_is_zip_file():
    file_name = "./file.zip"
    assert is_zip_file(file_name) == True


# Generated at 2022-06-23 16:31:49.824579
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('user@domain.com:something_else')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('file:///home/audreyr')

# Generated at 2022-06-23 16:31:56.877635
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the is_repo_url function."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/cookiecutter-djangopackage')
    assert is_repo_url('ssh://hg@bitbucket.org/pokoli/cookiecutter-djangopackage')
    assert is_repo_url('https://github.com/pokoli/cookiecutter-djangopackage.git')

# Generated at 2022-06-23 16:32:08.896607
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
       "gh": "https://github.com/{}",
       "bb": "https://bitbucket.org/{}",
       "test": "file://{}/test_template"}

    template = expand_abbreviations('gh:cookiecutter-django', abbreviations)
    expected = 'https://github.com/cookiecutter-django'
    assert template == expected, template

    template = expand_abbreviations('test:test_template', abbreviations)
    expected = 'file://test_template/test_template'
    assert template == expected, template

    template = expand_abbreviations(
        'test:test_template:test_path', abbreviations)
    expected = 'file://test_template/test_template:test_path'
    assert template == expected, template

# Generated at 2022-06-23 16:32:17.664538
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine repo dir
    """
    # Test a git repository
    repo_name = 'gh:audreyr/cookiecutter-pypackage'
    repository = determine_repo_dir(
        template=repo_name,
        abbreviations={},
        clone_to_dir='',
        checkout='',
        no_input=True,
        password="",
        directory="",
    )
    assert os.path.basename(repository[0]) == 'cookiecutter-pypackage'
    assert repository[1] is False

    # Test a zip file
    repo_name = 'https://github.com/audreyr/cookiecutter-pypackage/'
    'archive/master.zip'

# Generated at 2022-06-23 16:32:19.722152
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/wbolster/cookiecutter-django-crud') == True



# Generated at 2022-06-23 16:32:28.666190
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Assert that the has_cookiecutter_json function works as expected."""
    invalid_repository = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-tmpl',
    )
    valid_repository = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
    )

    assert not repository_has_cookiecutter_json(invalid_repository)
    assert not repository_has_cookiecutter_json(valid_repository)


# Generated at 2022-06-23 16:32:33.716310
# Unit test for function is_zip_file
def test_is_zip_file():
    zip = "sample.zip"
    tgz = "sample.tgz"
    tar = "sample.tar"
    jar = "sample.jar"
    assert is_zip_file(zip)
    assert is_zip_file(tgz)
    assert is_zip_file(tar)
    assert not is_zip_file(jar)


# Generated at 2022-06-23 16:32:38.927968
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that it returns true/false based on repo validity."""
    assert repository_has_cookiecutter_json('example-master')
    assert not repository_has_cookiecutter_json('not-valid-repo')
    assert repository_has_cookiecutter_json('example-master/')
    assert not repository_has_cookiecutter_json('not-valid-repo/')
    assert not repository_has_cookiecutter_json('/tmp')
    assert not repository_has_cookiecutter_json('/tmp/')



# Generated at 2022-06-23 16:32:44.504906
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    # Case 1 - valid
    repo_candidate = os.path.expanduser('~')
    assert(repository_has_cookiecutter_json(repo_candidate) == False)

    # Case 2 - valid
    repo_candidate = os.path.expanduser('~/cookiecutters')
    assert(repository_has_cookiecutter_json(repo_candidate) == False)

# Generated at 2022-06-23 16:32:51.546730
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Create directory.
    os.mkdir("testdir")
    # Create invalid git repo directory
    assert repository_has_cookiecutter_json("testdir") == False
    # Delete directory.
    os.rmdir("testdir")
    # Create directory.
    os.mkdir("testdir2")
    # Create json.
    f = open("testdir2/cookiecutter.json", "w")
    f.close()
    # Create invalid git repo directory
    assert repository_has_cookiecutter_json("testdir2") == True
    # Delete directory.
    os.rmdir("testdir2")
    # Create directory.
    os.mkdir("testdir3")
    # Create json.
    f = open("testdir3/cookiecutter.json", "w")
    f.close()

# Generated at 2022-06-23 16:32:56.941172
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """ Unit test for function determine_repo_dir"""

    template="https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations={}
    clone_to_dir="./cookiecutter"
    checkout=None
    no_input=False

    repo_candidates, cleanup=determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password=None, directory=None)

    assert repo_candidates.endswith(clone_to_dir)
    assert cleanup is False
    assert repository_has_cookiecutter_json(repo_candidates)

    template="https://cookiecutter-django.readthedocs.io/en/latest/zipfile/djangopackage.zip"
    repo_candidates,

# Generated at 2022-06-23 16:32:59.715448
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert not repository_has_cookiecutter_json('.')
    assert repository_has_cookiecutter_json('./tests/')

# Generated at 2022-06-23 16:33:08.292610
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the output of determine_repo_dir()"""
    tmp_dir = '/Users/aalali/tmp'
    template = 'https://github.com/hfdp-template.git'
    abbreviations = {}
    abbreviations['A'] = '{}/A'
    abbreviations['B'] = '{}/B'
    clone_to_dir = tmp_dir
    checkout = ''
    no_input = True
    password = 'password'
    directory = 'hello'
    (repo_candidate, cleanup) = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)
    print('repo_candidate = {}'.format(repo_candidate))

# Generated at 2022-06-23 16:33:19.686958
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Old and new abbreviations
    abbreviations_old = {
        "gh": "https://github.com/{0}.git",
        "bb": "https://bitbucket.org/{0}",
    }
    abbreviations_new = {
        "gh": 'gh:{{ cookiecutter.github_username }}/{{ cookiecutter.repo_name }}',
        "bb": 'bb:{{ cookiecutter.bitbucket_username }}/{{ cookiecutter.repo_name }}',
    }
    test_url = 'https://github.com/hackebrot/cookiecutter-pymodule.git'
    assert expand_abbreviations('gh:hackebrot/cookiecutter-pymodule', abbreviations_old) == test_url