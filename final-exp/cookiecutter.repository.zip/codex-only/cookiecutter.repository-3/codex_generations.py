

# Generated at 2022-06-23 16:23:20.971078
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/AudreyRoy/cookiecutter-pypackage-minimal.git'
    abbreviations = {}
    clone_to_dir = '/Users/hoge/cookiecutter/repo-dir/'
    checkout = None
    no_input = False
    directory = None
    password = None

    repo_dir, cleanup = determine_repo_dir(
                        template,
                        abbreviations,
                        clone_to_dir,
                        checkout,
                        no_input,
                        directory,
                        password
                    )

    print(repo_dir)

# Generated at 2022-06-23 16:23:27.337925
# Unit test for function is_zip_file
def test_is_zip_file():
    assert not is_zip_file('https://github.com/audreyr/cookiecutter')
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip')  # noqa
    assert is_zip_file('https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master')  # noqa
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/tarball/master')  # noqa
    assert is_zip_file('master')
    assert is_zip_file('./master.zip')

# Generated at 2022-06-23 16:23:37.135498
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    class TestRepositoryHasCookiecutterJson:

        def test_with_cookiecutter_json(self, tmpdir):
            os.mkdir(str(tmpdir.ensure('foo', dir=True)))
            with open(str(tmpdir.ensure('foo/cookiecutter.json')), 'w') as f:
                f.write("{}")

            assert repository_has_cookiecutter_json(str(tmpdir.ensure('foo')))

        def test_without_cookiecutter_json(self, tmpdir):
            os.mkdir(str(tmpdir.ensure('foo', dir=True)))
            with open(str(tmpdir.ensure('foo/cookiecutter.txt')), 'w') as f:
                f.write("{}")

            assert not repository_has_cookiecut

# Generated at 2022-06-23 16:23:43.366128
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test function that determines whether abbreviations are expanded correctly.
    """
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    correct_expansion = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert (
        expand_abbreviations(template, abbreviations)
        == correct_expansion
    )


# Generated at 2022-06-23 16:23:54.437588
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    :return: Bool
    """
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations
    )
    assert 'https://bitbucket.org/pydanny/cookiecutter-django' == expand_abbreviations(
        'bb:pydanny/cookiecutter-django', abbreviations
    )

# Generated at 2022-06-23 16:24:04.272399
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    clone_to_dir = '/home/vagrant/repos/cookiecutter-test'
    checkout = ''
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

    assert(repo_dir == '/home/vagrant/repos/cookiecutter-test/audreyr/cookiecutter-pypackage')
    assert(cleanup == False)

# Generated at 2022-06-23 16:24:13.029809
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert determine_repo_dir('gh:audreyr/cookiecutter-pypackage', abbreviations, 'tmp/repos', None, None) == (
    'tmp/repos/cookiecutter-pypackage', False)
    assert determine_repo_dir(
        'https://github.com/audreyr/cookiecutter-pypackage', abbreviations, 'tmp/repos', None, None) == (
    'tmp/repos/cookiecutter-pypackage', False)

# Generated at 2022-06-23 16:24:23.098748
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+ssh://git@github.com/audreyr/'
                       'cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/'
                       'python-project-template')

# Generated at 2022-06-23 16:24:28.240681
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    #Test for common abbreviations
    assert "gh:" in expand_abbreviations("gh:audreyr/cookiecutter-pypackage",
                                       {'gh': 'https://github.com/{}'})

    #Test for custom abbreviations
    assert "https://my-repo.com/my-template" in expand_abbreviations(
        "myrepo-server:my-template",
        {'myrepo-server': 'https://my-repo.com/{}'}
    )

# Generated at 2022-06-23 16:24:41.042518
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test is_repo_url function."""

# Generated at 2022-06-23 16:24:44.574401
# Unit test for function is_repo_url
def test_is_repo_url():
    assert not is_repo_url('foo.bar')
    assert is_repo_url('file://foo.bar')
    assert not is_repo_url('/something/local')

# Generated at 2022-06-23 16:24:47.539471
# Unit test for function is_zip_file
def test_is_zip_file():
    import os
    assert is_zip_file("tmp.zip") == True
    assert is_zip_file("t.zip") == True
    assert is_zip_file("t") == False
    assert is_zip_file("t.ZIP") == True

# Generated at 2022-06-23 16:24:58.912014
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git://git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:25:03.449855
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    root_dir = os.path.abspath(os.path.dirname(__file__))
    template = os.path.join(root_dir, 'tests/test-template')
    repo_path, cleanup = determine_repo_dir(template, None, None, None, False,
                                            None, None)
    assert os.path.normpath(template) == os.path.normpath(repo_path)
    assert cleanup is False

# Generated at 2022-06-23 16:25:09.671987
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(
        r'/home/user/workspace/test_cc_repo') == True
    assert repository_has_cookiecutter_json(
        r'/home/user/workspace/test_cc_repo') == True
    assert repository_has_cookiecutter_json(
        r'/home/user/workspace/test_cc_repo') == True

# Generated at 2022-06-23 16:25:19.009242
# Unit test for function is_repo_url
def test_is_repo_url():
    def test_str(test):
        return is_repo_url(test)
        # if is_repo_url(test) ^ is_repo_url_truth:
        #     raise AssertionError(
        #         "Expected is_repo_url({0}) to return {1}, got {2}".format(
        #             test, is_repo_url_truth, not is_repo_url_truth
        #         )
        #     )


    is_repo_url_truth = True
    yield test_str, "https://github.com"
    yield test_str, "git://github.com"
    yield test_str, "git@github.com"
    yield test_str, "git+git://github.com"

# Generated at 2022-06-23 16:25:22.965632
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert not is_zip_file('file.tx')
    assert not is_zip_file('file')

# Generated at 2022-06-23 16:25:28.454436
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import os

    directory='tests/test-repo-tmpl'
    repo_config_exists = os.path.isfile(
        os.path.join(directory, 'cookiecutter.json')
    )
    assert repository_has_cookiecutter_json(directory) == True
    assert os.path.isdir(directory) == True
    assert repo_config_exists == True

# Generated at 2022-06-23 16:25:37.054266
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter.main import cookiecutter

    # Get current working directory
    cwd = os.getcwd()

    # Create temporary working directory
    tmp_working_dir = cwd + "/tmp_working_dir"
    os.mkdir(tmp_working_dir)

    # Save current working directory
    old_cwd = cwd

    # Change current working directory to tmp_working_dir
    os.chdir(tmp_working_dir)

    # Create subdirectory in tmp_working_dir
    tmp_subdir = tmp_working_dir + "/tmp_subdir"
    os.mkdir(tmp_subdir)

    # Create cookiecutter.json in tmp_working_dir
    cookiecutter_json = tmp_working_dir + "/cookiecutter.json"

# Generated at 2022-06-23 16:25:44.528704
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Verify that the function repository_has_cookiecutter_json works."""
    import shutil
    import tempfile

    test_dir = os.path.join(tempfile.mkdtemp(), 'test_repo')
    os.mkdir(test_dir)
    with open(os.path.join(test_dir, 'cookiecutter.json'), 'w'):
        pass

    assert repository_has_cookiecutter_json(test_dir)
    shutil.rmtree(os.path.dirname(test_dir))

# Generated at 2022-06-23 16:25:53.578274
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert 'https://github.com/audreyr/cookiecutter-pypackage' == expand_abbreviations('pypackage', {'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage'})
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == expand_abbreviations('pypackage:git', {'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage.{}'})

# Generated at 2022-06-23 16:25:59.002158
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('cc', {'cc': 'https://github.com/audreyr/cookiecutter-pypackage'}) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('username/repo', {'username/repo': 'https://github.com/username/repo'}) == 'https://github.com/username/repo'



# Generated at 2022-06-23 16:26:03.789779
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "/home/user/projects/cookiecutter-pypackage"
    abbreviations = {
        "gh": "https://github.com/{0}.git",
        "bb": "https://bitbucket.org/{0}.git",
    }

    path = determine_repo_dir(template,abbreviations,clone_to_dir="/home/user/projects/directory",checkout='master', no_input=False)
    print(path)


# Generated at 2022-06-23 16:26:13.097996
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('') == False
    assert repository_has_cookiecutter_json('/Users/adam/code/my_project_template') == False
    assert repository_has_cookiecutter_json('/Users/adam/code/my_project_template/cookiecutter.json') == False
    assert repository_has_cookiecutter_json('/Users/adam/code/my_project_template2') == False
    assert repository_has_cookiecutter_json('/Users/adam/code/my_project_template2/cookiecutter.json') == True

# Generated at 2022-06-23 16:26:18.938922
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import cookiecutter

    cwd = os.getcwd()
    try:
        os.chdir('tests/test-repos/repo-tmpl/')
        context = cookiecutter('.')
        assert 'project_name' in context
        assert context['project_name'] == 'new_project'
    finally:
        os.chdir(cwd)

# Generated at 2022-06-23 16:26:22.216795
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function is_zip_file."""
    assert is_zip_file("cookiecutter---/cookiecutter.zip")



# Generated at 2022-06-23 16:26:33.003907
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """tests determine_repo_dir method"""
    import tempfile

    # Create a Test Repo
    tmp_dir = tempfile.mkdtemp()

    # Create the subfolder within the Test repo
    # Determine Repo Dir will look for cookiecutter.json in the subfolder
    subfolder = tmp_dir + "/subfolder"
    os.mkdir(subfolder)

    template_dir, cleanup = determine_repo_dir(
        subfolder,
        abbreviations={},
        clone_to_dir=tmp_dir,
        checkout="master",
        no_input=False,
        password=None,
        directory="subfolder",
    )
    assert (template_dir == subfolder)


# Generated at 2022-06-23 16:26:35.724857
# Unit test for function is_zip_file
def test_is_zip_file():
    value = "abc.zip"
    result = is_zip_file(value)
    assert result is True

# Generated at 2022-06-23 16:26:47.552775
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://user@example.com/abcdef')
    assert is_repo_url('https://example.com/abcdef')
    assert is_repo_url('http://example.com/abcdef')
    assert is_repo_url('ssh://example.com/abcdef')
    assert is_repo_url('git+file://example.com/abcdef')
    assert is_repo_url('git+ftp://example.com/abcdef')
    assert is_repo_url('git+ssh://example.com/abcdef')
    assert is_repo_url('git+https://example.com/abcdef')

    assert not is_repo_url('git:example.com/abcdef')

# Generated at 2022-06-23 16:26:51.652805
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test for method is_zip_file"""
    assert is_zip_file("abc.zip") is True
    assert is_zip_file("abc.ZIP") is True
    assert is_zip_file("abc.zip12") is False


# Generated at 2022-06-23 16:26:55.279272
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip')
    assert is_zip_file('foo.ZIP')
    assert not is_zip_file('foo.zipx')
    assert not is_zip_file('fooxzip')

# Generated at 2022-06-23 16:27:04.285792
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test for a directory that does not exist
    tempory_directory = "/This/is/not/a/valid/directory"
    print(repository_has_cookiecutter_json(tempory_directory))
    # Test for a directory that does exist, but does not contain
    # a cookiecutter.json script
    tempory_directory = "C:/Users/Kyo"
    print(repository_has_cookiecutter_json(tempory_directory))
    # Test for a directory that does exist, and does contain
    # a cookiecutter.json script
    tempory_directory = "C:/Users/Kyo/FeedMolecules"
    print(repository_has_cookiecutter_json(tempory_directory))



# Generated at 2022-06-23 16:27:16.184473
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Function `repository_has_cookiecutter_json` returns expected results."""
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    assert(repository_has_cookiecutter_json(template_dir))

    # Case: No cookiecutter.json file
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    assert(not repository_has_cookiecutter_json(template_dir))

    # Case: No template directory
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl', 'fake-repo')

# Generated at 2022-06-23 16:27:20.089329
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify that URL is detected as a repository URL."""
    repo_url = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(repo_url) == True



# Generated at 2022-06-23 16:27:29.125075
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    from cookiecutter.main import cookiecutter

    # Recording
    # TEST_COOKIECUTTER_REPO: https://github.com/hackebrot/cookiecutter-pypackage.git
    # TEST_REPO_CHECKOUT: v0.3.1
    # TEST_ZIPPED_COOKIECUTTER_REPO: https://github.com/hackebrot/cookiecutter-pypackage/archive/v0.3.1.zip

    # Ensure that abbreviations are expanded and then used

# Generated at 2022-06-23 16:27:36.467489
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_repo_directory = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-tmpl'))
    assert repository_has_cookiecutter_json(test_repo_directory) == True

    test_repo_directory += '-fail'
    assert repository_has_cookiecutter_json(test_repo_directory) == False

# Generated at 2022-06-23 16:27:46.013982
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that validating a repository works."""
    os.makedirs('valid_repo')
    with open(os.path.join('valid_repo', 'cookiecutter.json'), 'w') as f:
        f.write('{}')

    os.makedirs('invalid_repo')
    with open(os.path.join('invalid_repo', 'cookiecutter.json'), 'w') as f:
        f.write('{')  # invalid JSON

    assert repository_has_cookiecutter_json('valid_repo') is True  # noqa
    assert repository_has_cookiecutter_json('invalid_repo') is False  # noqa

# Generated at 2022-06-23 16:27:55.700749
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    tmpdir = tempfile.mkdtemp()
    shutil.copytree(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'test-corrupt-repo',
        ),
        os.path.join(tmpdir, 'test-corrupt-repo'),
    )

    repo_directory = os.path.join(tmpdir, 'test-corrupt-repo')
    assert not repository_has_cookiecutter_json(repo_directory)

    shutil.rmtree(tmpdir)

# Generated at 2022-06-23 16:28:07.238017
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('ssh://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://bitbucket.org/pokoli/cookiecutter-pokoli-module')

# Generated at 2022-06-23 16:28:08.978020
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-23 16:28:15.409521
# Unit test for function is_zip_file
def test_is_zip_file():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert not is_zip_file(template)

    template = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'

    assert is_zip_file(template)

    assert not is_zip_file('foo.bar')

# Generated at 2022-06-23 16:28:25.806210
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        # 'py': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'ghe': 'https://{}@github.com/{}.git'
    }
    ## Test case 1
    template = 'py:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    actual = expand_abbreviations(template, abbreviations)
    assert expected == actual
    ## Test case 2
    template = 'bb:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:28:31.360350
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://codeload.github.com/audreyr/cookiecutter-pypackage\
/zip/1.0')==True
    assert is_zip_file('https://codeload.github.com/audreyr/cookiecutter-pypackage')==False



# Generated at 2022-06-23 16:28:39.404285
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import cookiecutter

    base_dir = os.path.dirname(os.path.abspath(cookiecutter.__file__))

    elixir_path = os.path.join(
        base_dir, os.pardir, os.pardir, 'tests', 'test-elixir-app'
    )

    (
        repo_dir,
        cleanup,
    ) = determine_repo_dir(
        template=elixir_path,
        abbreviations={},
        clone_to_dir='/',
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )

    assert elixir_path == repo_dir
    assert cleanup is False

    (
        repo_dir,
        cleanup,
    ) = determine_repo

# Generated at 2022-06-23 16:28:47.855835
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'myfork': 'https://bitbucket.org/myuser/{}.git',
    }

    template = 'gh:audreyr/cookiecutter-pypackage'
    template_expanded = expand_abbreviations(template, abbreviations)
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert template_expanded == repo_url

    template = 'bb:pokoli/cookiecutter-dockerfile'
    template_expanded = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-23 16:28:52.743619
# Unit test for function is_zip_file
def test_is_zip_file():
    assert not is_zip_file('foo.tar.gz')
    assert not is_zip_file('foo.tar')
    assert is_zip_file('foo.zip')
    assert is_zip_file('foo.ZIP')
    assert is_zip_file('foo.taz')


# Generated at 2022-06-23 16:28:55.423286
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    if not repository_has_cookiecutter_json('tests'):
        raise AssertionError('Could not find tests directory')

# Generated at 2022-06-23 16:29:06.661565
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import os
    import shutil
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import utils

    config_dict = DEFAULT_CONFIG
    config_dict['cookiecutters_dir'] = '~/cookiecutters'

    if os.path.exists(config_dict['cookiecutters_dir']):
        shutil.rmtree(config_dict['cookiecutters_dir'])
    os.makedirs(config_dict['cookiecutters_dir'])

    # Dirs

# Generated at 2022-06-23 16:29:11.396339
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    stubbed out test just to make sure it gets called
    :return:
    """
    # TODO: make this test do something useful
    assert True, 'determine_repo_dir() is stubbed out for now'

# Generated at 2022-06-23 16:29:18.320492
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('example.zip')
    assert is_zip_file('example.ZIP')
    assert is_zip_file('example.zip')
    assert is_zip_file('example.ZIP')
    assert not is_zip_file('example.git')
    assert not is_zip_file('example.tar.gz')
    assert not is_zip_file('example.tar.bz2')

# Generated at 2022-06-23 16:29:27.208624
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:29:34.702958
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('foo')



# Generated at 2022-06-23 16:29:36.906193
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('.')



# Generated at 2022-06-23 16:29:39.136353
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    assert is_zip_file(zip_template)

# Generated at 2022-06-23 16:29:49.578039
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}'
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == template
    template = 'audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == template
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == template
    template = 'bb:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == template

# Generated at 2022-06-23 16:29:58.414754
# Unit test for function is_repo_url
def test_is_repo_url():
    passed = [
        'git://github.com/audreyr/cookiecutter-pypackage.git',
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'file://localhost/Users/audreyr/cookiecutter-pypackage/.git',
        'git@github.com:audreyr/cookiecutter-pypackage.git',
        'ssh://git@github.com/audreyr/cookiecutter-pypackage.git',
        'git+ssh://git@github.com/audreyr/cookiecutter-pypackage.git',
        'git+https://github.com/audreyr/cookiecutter-pypackage.git',
    ]

# Generated at 2022-06-23 16:30:05.320158
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test a directory that has a cookiecutter.json file
    assert repository_has_cookiecutter_json('tests/test-repo-pre/')
    # Test a directory that does not have a cookiecutter.json file
    assert not repository_has_cookiecutter_json('tests/fake-repo-pre/')
    # Test a directory that does not exist
    assert not repository_has_cookiecutter_json('tests/nonexistent-dir')

# Generated at 2022-06-23 16:30:11.605984
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('http://foo.bar/test.zip')
    assert is_zip_file('foo/test.zip')
    assert is_zip_file('test.zip')
    assert not is_zip_file('http://foo.bar/test.zipper')
    assert not is_zip_file('foo/test')
    assert not is_zip_file('foo.zip/bar')


# Generated at 2022-06-23 16:30:21.461712
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Example repo:

    /tmp/cookiecutter-tpl
    ├── {{cookiecutter.repo_name}}
    │   ├── README.md
    │   └── {{cookiecutter.repo_name}}
    │       ├── __init__.py
    │       └── {{cookiecutter.repo_name}}.py
    └── cookiecutter.json

    """

    cookiecutters_dir = 'tests/test-generate-files'
    repo_dir = 'tests/test-repo-tmpl'
    repo_json = 'cookiecutter.json'
    repo_tmpl = '{{cookiecutter.repo_name}}'
    clone_to_dir = '/tmp/'

    #clean git repo

# Generated at 2022-06-23 16:30:23.262024
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('examples')

# Generated at 2022-06-23 16:30:32.323586
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test HTTP URL
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(template)
    # Test SSH URL
    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(template)
    # Test local path with cookiecutter.json
    template = 'tests/fake-repo-pre/'
    assert not is_repo_url(template)
    # Test local barebones directory without cookiecutter.json
    template = 'tests/fake-repo-tmpl/'
    assert not is_repo_url(template)
    # Test file URL
    template = 'file://localhost/some/path/to/repo.git'

# Generated at 2022-06-23 16:30:39.265145
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if the given directory is a repository directory."""

    test_dir = os.path.abspath('tests/fake-repo-pre/')
    assert repository_has_cookiecutter_json(test_dir) is True

    test_dir = os.path.abspath('tests/fake-repo-pre/fake-repo-post/')
    assert repository_has_cookiecutter_json(test_dir) is False

# Generated at 2022-06-23 16:30:44.935219
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test_file.zip')
    assert is_zip_file('C:\\Test_folder\\test_file.zip')
    assert is_zip_file('Test folder\\test_file.zip')
    assert not is_zip_file('test_file.tar.gz')
    assert not is_zip_file('test')
    assert not is_zip_file('test.txt')
    assert not is_zip_file('test.txt.zip.txt')

# Generated at 2022-06-23 16:30:48.169036
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert not repository_has_cookiecutter_json("/bla/bla")
    assert repository_has_cookiecutter_json("/bla/bla") == False
    repo = "tests/test-repo-tmpl/"
    assert repository_has_cookiecutter_json(repo)
    assert repository_has_cookiecutter_json(repo) == True

# Generated at 2022-06-23 16:30:48.694023
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-23 16:30:49.547820
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print('please test me')

# Generated at 2022-06-23 16:30:55.511947
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template="https://github.com/audreyr/cookiecutter-pypackage.git",
        abbreviations={},
        clone_to_dir="/tmp",
        checkout="",
        no_input=True,
    ) == (
        "/tmp/cookiecutter-pypackage",
        False,
    )
    assert determine_repo_dir(
        template="mypackagename",
        abbreviations={"default": "https://github.com/audreyr/cookiecutter-pypackage.git"},
        clone_to_dir="/tmp",
        checkout="",
        no_input=True,
    ) == (
        "/tmp/cookiecutter-pypackage",
        False,
    )

# Generated at 2022-06-23 16:30:59.078615
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """In the case of the list of files empty,
    repository_has_cookiecutter_json should return False"""
    list_files = []
    assert repository_has_cookiecutter_json(list_files) == False


# Generated at 2022-06-23 16:31:07.310151
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Check if function expand_abbreviations is working as expected."""
    abbreviations = {"gh": "https://github.com/{}.git", "bb": "https://bitbucket.org/{}.git"}
    template = "gh:audreyr/cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"
    template = "bb:atlassian/common-directory-npm"
    assert expand_abbreviations(template, abbreviations) == "https://bitbucket.org/atlassian/common-directory-npm.git"
    template = "http://something.com"
    assert expand_abbreviations(template, abbreviations) == "http://something.com"

# Generated at 2022-06-23 16:31:13.000168
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """todo"""
    assert expand_abbreviations('py', {'py': 'python'}) == 'python'
    assert expand_abbreviations('a:b', {'a': 'expanded'}) == 'expanded:b'
    assert expand_abbreviations('a:b', {'x': 'expanded'}) == 'a:b'

# Generated at 2022-06-23 16:31:22.032693
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir.
    """
    repo_dir = "/my/repo/dir/repo"
    template = "my_template"
    abbreviations = {
        template: repo_dir,
    }
    clone_to_dir = "."
    checkout = "master"
    no_input = False

    repo_candidate, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
    )

    assert repo_candidate == repo_dir
    assert cleanup == False

    repo_dir = "/my/repo/dir/repo"
    template = "my_template"

# Generated at 2022-06-23 16:31:24.257333
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git") == True
    # test a path which is not a repo url
    assert is_repo_url("/home/Shared/cookiecutter-pypackage") == False


# Generated at 2022-06-23 16:31:28.234347
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check that function returns True if artifact exists in repo."""
    clone_to_dir = '/home/frozenmoose/coding/repos'
    cookiecutter_json_path = '/home/frozenmoose/coding/repos/cookiecutter-pypackage'
    os.path.isdir(cookiecutter_json_path)


# Generated at 2022-06-23 16:31:33.372585
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    # This one is tricky
    assert not is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')



# Generated at 2022-06-23 16:31:39.005755
# Unit test for function is_zip_file
def test_is_zip_file():
    template = 'test.zip'
    assert is_zip_file(template)
    template = 'test.ZiP'
    assert is_zip_file(template)
    template = 'test.ZiP/test'
    assert not is_zip_file(template)
    template = 'http://example.com/test.ZiP/test'
    assert not is_zip_file(template)

# Generated at 2022-06-23 16:31:50.390319
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # folder with cookiecutter.json
    template = os.path.join('tests', 'fake-repo-tmpl')
    repo_dir, cleanup = determine_repo_dir(template,{},'','')
    assert(repo_dir == template)
    assert(cleanup == False)

    # folder without cookiecutter.json
    template = os.path.join('tests', 'fake-repo-tmpl-nested')
    try:
        repo_dir, cleanup = determine_repo_dir(template, {}, '', '')
    except:
        assert(True)
    else:
        assert(False)

    # file
    template = os.path.join('tests', 'fake-repo-tmpl', 'cookiecutter.json')

# Generated at 2022-06-23 16:31:55.788971
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = 'D:\\repository_has_cookiecutter_json'
    if not os.path.exists(repo_directory):
        os.makedirs(repo_directory)
    assert(repository_has_cookiecutter_json(repo_directory) == False)
    with open(os.path.join(repo_directory, 'cookiecutter.json'), 'w+') as file:
        file.write('test')
    assert(repository_has_cookiecutter_json(repo_directory) == True)

# Generated at 2022-06-23 16:32:03.687835
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template1 = 'https://github.com/me/my-repo.git'
    template2 = 'https://github.com/me/my-repo.git:my-branch'
    template3 = 'test/test-cookiecutter-repo/{{cookiecutter.unix_user_id}}'
    template4 = 'test/test-cookiecutter-repo/myself/{{cookiecutter.unix_user_id}}'
    clone_to_dir = '/tmp'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    checkout = 'master'
    no_input = True


# Generated at 2022-06-23 16:32:13.797952
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:pydanny/cookiecutter-django.git')
    assert is_repo_url('git+ssh://git@github.com/audreyr/'
                       'cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/'
                       'cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:32:20.727223
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test for git url
    url_git = "git@github.com:audreyr/cookiecutter-pypackage.git"
    assert is_repo_url(url_git) == True

    # Test for http url
    url_http = "http://github.com/audreyr/cookiecutter-pypackage"
    assert is_repo_url(url_http) == True

    # Test for local path
    url_local = "/home/audreyr/git/cookiecutter-pypackage.git"
    assert is_repo_url(url_local) == False

    # Test for zip file
    url_zip = "/home/audreyr/cookiecutter-pypackage.zip"
    assert is_repo_url(url_zip) == False

# Generated at 2022-06-23 16:32:32.501378
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/user/repo/archive/master.zip')
    assert is_zip_file('https://github.com/user/repo/archive/master.ZIP')
    assert is_zip_file('https://github.com/user/repo/archive/master.zIp')
    assert is_zip_file('https://github.com/user/repo/archive/master.zip/master/')
    assert is_zip_file('repo.zip')
    assert is_zip_file('/home/user/repo.ZIP')
    assert is_zip_file('C:foo/bar/repo.zip')
    assert is_zip_file('C:/foo/bar/repo.zip')

# Generated at 2022-06-23 16:32:41.891387
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir is working correctly when template is a git url.
    """
    template = "https://github.com/username/cookiecutter-pypackage.git"
    abbreviations = {"cookiecutter-pypackage":"https://github.com/username/cookiecutter-pypackage.git"}
    clone_to_dir = "test_dir"
    checkout = "master"
    no_input = True
    password = None
    directory = None

    _,_ = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

    return

# Generated at 2022-06-23 16:32:50.117121
# Unit test for function is_repo_url
def test_is_repo_url():
    import pytest
    assert is_repo_url('git+https://github.com/nhoag/cookiecutter-pypackage-minimal.git')
    assert is_repo_url('git+git://github.com/nhoag/cookiecutter-pypackage-minimal.git')
    assert is_repo_url('https://github.com/nhoag/cookiecutter-pypackage-minimal.git')
    assert is_repo_url('git://github.com/nhoag/cookiecutter-pypackage-minimal.git')
    assert is_repo_url('git://github.com/nhoag/cookiecutter-pypackage-minimal.git#egg=cookiecutter')

# Generated at 2022-06-23 16:32:50.932439
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    pass

# Generated at 2022-06-23 16:32:55.798368
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test whether repository_has_cookiecutter_json works correctly."""

    # Test case 1
    # true because there is, indeed, a 'cookiecutter.json' file at the given
    # location
    repo_directory = 'tests/fake-repo-pre/'
    expected_result = True

    result = repository_has_cookiecutter_json(repo_directory)
    assert result == expected_result

    # Test case 2
    # false because there is no 'cookiecutter.json' file
    repo_directory = 'tests/fake-repo-post/'
    expected_result = False

    result = repository_has_cookiecutter_json(repo_directory)
    assert result == expected_result

# Generated at 2022-06-23 16:33:06.812029
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test is_repo_url()
    assert is_repo_url('git@github.com:audreyr/cookiecutter.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('https://github.com/robvanderleek/cookiecutter-pylibrary.git')

    # test is_zip_file()
    assert is_zip_file('test.zip')
    assert is_zip_file('/test.zip')
    assert is_zip_file('/test/test.zip')
    assert not is_zip_file('test.ZIP')
    assert not is_zip_file('test.zip.zip')
    assert not is_zip_file('/test.zip/test.zip')

   

# Generated at 2022-06-23 16:33:11.653558
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    '''
    Tests that repository_has_cookiecutter_json() returns True for existing directory with cookiecutter.json file
    '''
    repo_directory = os.path.dirname(os.path.realpath(__file__))
    assert repository_has_cookiecutter_json(repo_directory)

# Generated at 2022-06-23 16:33:20.236003
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test with a directory containing a cookiecutter.json
    base_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'fake-repo-pre'
    )
    assert repository_has_cookiecutter_json(base_dir) == True

    # Test with a directory not containing a cookiecutter.json
    base_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'fake-repo-post'
    )
    assert repository_has_cookiecutter_json(base_dir) == False