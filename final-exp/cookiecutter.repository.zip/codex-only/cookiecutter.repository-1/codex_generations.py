

# Generated at 2022-06-23 16:23:23.293274
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:sloria/cookiecutter-flask.git')
    assert is_repo_url('git+https://github.com/sloria/cookiecutter-flask.git')
    assert is_repo_url('hg+http://hg.myproject.org/myproject#egg=MyProject')
    assert is_repo_url('git://github.com/sloria/cookiecutter-flask.git')
    assert is_repo_url('ssh://hg@bitbucket.org/sloria/cookiecutter-flask')

# Generated at 2022-06-23 16:23:29.322058
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {
        'gh': 'https://github.com/{}.git',
        'gl': 'https://gitlab.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'ghe': 'https://ghe.mycompany.com/{}.git',
    }

    def test(abbrevs, template, expected):
        assert expand_abbreviations(template, abbrevs) == expected

    test(abbrevs, 'cookiecutter-pypackage', 'cookiecutter-pypackage')
    test(abbrevs, 'gh:audreyr/cookiecutter-pypackage',
         'https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:23:38.326563
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter.main import cookiecutter


# Generated at 2022-06-23 16:23:42.849212
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:23:45.665455
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("hello.zip")
    assert not is_zip_file("hello.ZIP")
    assert not is_zip_file("hello.zi")



# Generated at 2022-06-23 16:23:50.382592
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('some-repo.zip')
    assert is_zip_file('some-repo.ZIP')
    assert is_zip_file('some-repo.Zip')
    assert is_zip_file('some-repo.ZiP')



# Generated at 2022-06-23 16:23:57.385719
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git+git://github.com/foo/baz')
    assert is_repo_url('git://github.com/foo/baz')
    assert is_repo_url('git+https://github.com/foo/baz')
    assert is_repo_url('https://github.com/foo/baz')
    assert is_repo_url('git+ssh://github.com/foo/baz')
    assert is_repo_url('ssh://github.com/foo/baz')
    assert is_repo_url('git+file://github.com/foo/baz')
    assert is_repo_url('file://github.com/foo/baz')
    assert is_repo_url('me@myhost:mydir/myrepo')
   

# Generated at 2022-06-23 16:24:07.970686
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://foo.com/bar.git')
    assert is_repo_url('git+git://foo.com/bar.git')
    assert is_repo_url('git+ssh://foo.com/bar.git')
    assert is_repo_url('git+file://foo.com/bar.git')
    assert is_repo_url('git+https://foo.com/bar.git')
    assert is_repo_url('git+somethingelse://foo.com/bar.git')
    assert is_repo_url('ssh://foo.com/bar.git')
    assert is_repo_url('file://foo.com/bar.git')
    assert is_repo_url('https://foo.com/bar.git')
    assert is_repo_url

# Generated at 2022-06-23 16:24:19.524936
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:24:27.527055
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # result of locate template
    # repo_directory = '/Users/derekgreene/Code/open_source/cookiecutter/cookiecutter-pypackage'
    # repo_directory = '/Users/derekgreene/Code/open_source/cookiecutter/'
    repo_directory = '/Users/derekgreene/Code/open_source/cookiecutter/tests/test-data/fake-repo-pre/'

    # Test that the directory exists
    assert os.path.isdir(repo_directory)

    # Test that the config exists
    assert repository_has_cookiecutter_json(repo_directory) is True

# Generated at 2022-06-23 16:24:32.662544
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = "user/repo"
    abbreviations = {'user': 'https://github.com/{0}'}
    expanded = expand_abbreviations(template, abbreviations)

    assert expanded == 'https://github.com/user/repo', expanded

# Generated at 2022-06-23 16:24:42.602153
# Unit test for function is_zip_file
def test_is_zip_file():
    assert (is_zip_file('cookiecutter-pypackage.zip') == True)
    assert (is_zip_file('cookiecutter-pypackage.ZIP') == True)
    assert (is_zip_file('cookiecutter-pypackage.zIp') == True)
    assert (is_zip_file('cookiecutter-pypackage.ZiP') == True)
    assert (is_zip_file('cookiecutter-pypackage.ZIP3') == False)
    assert (is_zip_file('cookiecutter-pypackage.tar.gz') == False)
    assert (is_zip_file('cookiecutter-pypackage.txz') == False)


# Generated at 2022-06-23 16:24:50.721189
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function `is_repo_url`."""
    urls = [
        'https://github.com/user/repo.git',
        'https://github.com/user/repo/archive/master.zip',
        'git://github.com/user/repo.git',
        'git@github.com:user/repo.git',
        'git+ssh://github.com/user/repo.git',
        'git+https://github.com/user/repo.git',
        'https://github.com/user/repo',
        'ssh://hg@bitbucket.org/user/repo',
    ]
    not_urls = [
        'bitbucket.org/user/repo',
        '/home/user/repo',
    ]
   

# Generated at 2022-06-23 16:24:57.090101
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(
        os.path.abspath(os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'test-cookiecutter-repo'))
    )
    assert not repository_has_cookiecutter_json(
        os.path.abspath(os.path.join(
            os.path.dirname(__file__))
        )
    )

# Generated at 2022-06-23 16:25:04.832775
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test cases for function determine_repo_dir
    """
    determine_repo_dir(
        template='cookiecutter-pypackage',
        abbreviations={
            'gh': 'https://github.com/{}.git',
            'bb': 'https://bitbucket.org/{}',
        },
        clone_to_dir='.',
        checkout='master',
        no_input=False,
        password=None,
        directory='.',
    )


# Generated at 2022-06-23 16:25:15.388299
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {"gh": "https://github.com/{}.git",
                     "bb": "https://bitbucket.org/{}.git"}
    template = "myusername/myrepo"
    expected = "myusername/myrepo"
    actual = expand_abbreviations(template, abbreviations)
    assert actual == expected
    # Test with a ':'
    template = "gh:myusername/myrepo"
    expected = "https://github.com/myusername/myrepo.git"
    actual = expand_abbreviations(template, abbreviations)
    assert actual == expected
    # Test with a '_'
    template = "gh_myusername/myrepo"
    expected = "https://github.com/myusername/myrepo.git"
    actual = expand_abbreviations

# Generated at 2022-06-23 16:25:22.771675
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('tests/fake-repo-tmpl/foobar.zip') is True
    assert is_zip_file('tests/fake-repo-tmpl/foobar.ZIP') is True
    assert is_zip_file('tests/fake-repo-tmpl/foobar.tar.gz') is False
    assert is_zip_file('tests/fake-repo-tmpl/foobar') is False
    assert is_zip_file('/dir1/dir2/tests/fake-repo-tmpl/foobar.zip') is True
    assert is_zip_file('c:\\dir1\\dir2\\tests\\fake-repo-tmpl\\foobar.zip') is True

# Generated at 2022-06-23 16:25:31.359872
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test whether we detect a valid repository URL."""
    assert is_repo_url('https://github.com/foo/bar.git')
    assert is_repo_url('git://github.com/foo/bar.git')
    assert is_repo_url('git+ssh://github.com/foo/bar.git')
    assert is_repo_url('git+ssh://github.com/foo/bar.git')
    assert is_repo_url('git+file://github.com/foo/bar.git')
    assert is_repo_url('https://foo.bar.baz:80000/abc/def.git')



# Generated at 2022-06-23 16:25:35.232093
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert not repository_has_cookiecutter_json('/tmp/')
    assert not repository_has_cookiecutter_json('/tmp/test_123/')
    assert not repository_has_cookiecutter_json('/test_123/')
    assert not repository_has_cookiecutter_json('./test_123/')


# Generated at 2022-06-23 16:25:42.352103
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file_name.zip') == True
    assert is_zip_file('file_name.ZIP') == True
    assert is_zip_file('file_name.zip.ZIP') == False
    assert is_zip_file('file_name.ZIP.zip') == False
    assert is_zip_file('file_name.tar.gz') == False
    assert is_zip_file('other_name.zip') == True


# Generated at 2022-06-23 16:25:48.966422
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/sloria/cookiecutter-flask/archive/master.zip')
    assert is_zip_file('/Users/sloria/Dev/flask.zip')
    assert not is_zip_file('https://github.com/sloria/cookiecutter-flask/archive/master.tar.gz')
    assert not is_zip_file('/Users/sloria/Dev/flask.tar.gz')



# Generated at 2022-06-23 16:25:55.656944
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git', 'bb': 'https://bitbucket.org/{}.git'}
    template = expand_abbreviations('gh:foo/bar', abbreviations)
    assert template == 'https://github.com/foo/bar.git'
    template = expand_abbreviations('bb:foo/bar', abbreviations)
    assert template == 'https://bitbucket.org/foo/bar.git'
    template = expand_abbreviations('local:foo', abbreviations)
    assert template == 'local:foo'

# Generated at 2022-06-23 16:26:04.060094
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert os.path.basename(determine_repo_dir('.')[0]) == '.cookiecutters'
    assert os.path.basename(determine_repo_dir('cookiecutter-pypackage')[0]) == 'cookiecutter-pypackage'
    assert not os.path.exists(determine_repo_dir('cookiecutter-pypackage',
                                                 clone_to_dir='test')[0])
    assert not os.path.exists(determine_repo_dir('git@github.com:pytest-dev/cookiecutter-pytest-plugin.git',
                                                 clone_to_dir='test')[0])

# Generated at 2022-06-23 16:26:15.532810
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import shutil
    import tempfile

    cookiecutter_json_content = """
{
    "full_name": "Test"
}"""

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    tmp_repo_dir = os.path.join(tmp_dir, "test_repo")
    os.mkdir(tmp_repo_dir)

    # Create a temporary cookiecutter.json file
    tmp_cookiecutter_json = os.path.join(tmp_repo_dir, "cookiecutter.json")
    with open(tmp_cookiecutter_json, 'w') as f:
        f.write(cookiecutter_json_content)

    # Assert that the repo has the json file 

# Generated at 2022-06-23 16:26:24.817432
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    repo_with_json_dir = os.path.join(
        temp_dir.name, 'repo'
    )
    os.mkdir(repo_with_json_dir)
    json_file_path = os.path.join(
        repo_with_json_dir, 'cookiecutter.json'
    )
    open(json_file_path, 'w+').close()

    assert repository_has_cookiecutter_json(repo_with_json_dir)

    repo_without_json_dir = os.path.join(
        temp_dir.name, 'repo2'
    )
    os.mkdir(repo_without_json_dir)

# Generated at 2022-06-23 16:26:27.165652
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(os.path.join('tests', 'fake-repo-tmpl'))



# Generated at 2022-06-23 16:26:38.262990
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    test_determine_repo_dir
    """
    original_cwd = os.getcwd()
    os.chdir('tests/test-extract-repoe')

    repo_dir, cleanup = determine_repo_dir(
        template='cookiecutter-django/',
        abbreviations={},
        clone_to_dir='foo/bar',
        checkout=None,
        no_input=False,
        directory=None
    )
    assert repo_dir == 'cookiecutter-django/', repo_dir
    assert not cleanup, cleanup


# Generated at 2022-06-23 16:26:49.519576
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test function expand_abbreviations."""
    abb = {
        "my_repo": "https://github.com/MyOrg/{}",
        "my_user": "https://github.com/{}/MyRepo",
    }
    # Test
    assert "foo/bar" == expand_abbreviations("foo/bar", abb)

    # Test
    assert "https://github.com/MyOrg/master" == expand_abbreviations(
        "my_repo:master",
        abb,
    )

    # Test
    assert "https://github.com/my_user/MyRepo" == expand_abbreviations(
        "my_user",
        abb,
    )

    # Test

# Generated at 2022-06-23 16:26:59.695134
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from .main import get_user_config

    # Testing None as template value
    try:
        determine_repo_dir(
            template=None,
            abbreviations=None,
            clone_to_dir=None,
            checkout=None,
            no_input=True,
            password=None,
            directory=None
        )
        raise AssertionError('Should raise error for template=None')
    except:
        pass

    # Testing abbreviations
    abbreviations = {
        'default': 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    }

# Generated at 2022-06-23 16:27:08.131133
# Unit test for function is_repo_url
def test_is_repo_url():
    # not a repo url
    assert is_repo_url('.') == False
    assert is_repo_url('/home/user') == False
    # is a repo url
    assert is_repo_url('git+https://github.com/user/repo.git') == True
    assert is_repo_url('https://github.com/user/repo.git') == True
    assert is_repo_url('git://github.com/user/repo.git') == True
    assert is_repo_url('ssh://github.com/user/repo.git') == True
    assert is_repo_url('hg+https://github.com/user/repo.git') == True
    assert is_repo_url('git@github.com:user/repo.git') == True

# Generated at 2022-06-23 16:27:12.966638
# Unit test for function is_zip_file
def test_is_zip_file():
    assert(is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/zipball/master'))
    assert not(is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/tarball/master'))

# Generated at 2022-06-23 16:27:13.570395
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-23 16:27:16.517998
# Unit test for function is_zip_file
def test_is_zip_file():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    condition = is_zip_file(template)
    assert condition == False

"""
Test for function expand_abbreviations
"""

# Generated at 2022-06-23 16:27:26.672530
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations
    )
    assert 'https://github.com/cookiecutter/cookiecutter-pypackage.git' == expand_abbreviations(
        'gh:cookiecutter/cookiecutter-pypackage', abbreviations
    )

# Generated at 2022-06-23 16:27:39.709439
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test if the function is_repo_url is working as expected
    """

# Generated at 2022-06-23 16:27:47.676206
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("somefile.zip") == True
    assert is_zip_file("somefile.zip.txt") == False
    assert is_zip_file("sample.zip") == True
    assert is_zip_file("sample.html") == False
    assert is_zip_file("file.zip") == True
    assert is_zip_file("file.txt") == False
    assert is_zip_file("file.zi") == False
    assert is_zip_file("file.ZIP") == True
    assert is_zip_file("file.ZiP") == True
    assert is_zip_file("file.ZIP.txt") == False


# Generated at 2022-06-23 16:27:58.577216
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        {},
        'C:\\Users\\hbokh\\AppData\\Local\\Temp\\Cookiecutter',
        'C:\\Users\\hbokh\\AppData\\Local\\Temp\\Cookiecutter\\cookiecutter-pypackage',
        'master',
        False) == ('C:\\Users\\hbokh\\AppData\\Local\\Temp\\Cookiecutter\\cookiecutter-pypackage', False)

# Generated at 2022-06-23 16:28:00.687722
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert True == repository_has_cookiecutter_json("/tmp")


# Generated at 2022-06-23 16:28:10.001297
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert 'user/project' == expand_abbreviations(
        'user/project', {}
    )
    assert 'user/project' == expand_abbreviations(
        'user:project', {'user': 'user'}
    )
    assert 'user/project' == expand_abbreviations(
        ':project', {'user': 'user/{}'}
    )
    assert 'user/project' == expand_abbreviations(
        'user/project', {'proj': 'user/{}'}
    )
    assert 'other/project' == expand_abbreviations(
        'user/project', {'user': 'other'}
    )

# Generated at 2022-06-23 16:28:20.814440
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    here = os.path.abspath(os.path.dirname(__file__))
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage'
    repo_name = 'test_repo_name'
    directory_name = 'test_directory_name'
    clone_to_dir = os.path.join(here, repo_name)

    repo_dir, cleanup = determine_repo_dir(
        template=repo_url,
        abbreviations={},
        clone_to_dir=clone_to_dir,
        checkout=None,
        no_input=True,
        password=None,
        directory=directory_name
    )
    assert repo_dir == os.path.join(clone_to_dir, directory_name)
    assert cleanup is False



# Generated at 2022-06-23 16:28:26.900042
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Verify that function repository_has_cookiecutter_json() works
    in the following scenarios:
    - repo_directory exists, cookiecutter.json exists
    - repo_directory does not exist, cookiecutter.json does not exist
    - repo_directory does not exist, cookiecutter.json exists
    - repo_directory exists, cookiecutter.json does not exist
    """
    # repo_directory exists, cookiecutter.json exists
    assert repository_has_cookiecutter_json(
        repo_directory=os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.project_name}}')
    )
    # repo_directory does not exist, cookiecutter.json does not exist

# Generated at 2022-06-23 16:28:34.090868
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test expand_abbreviations function."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'username': 'johndoe',
    }

    assert expand_abbreviations('username', abbreviations) == 'johndoe'
    assert expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations
    ) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(
        'gh:my-org/my-repo', abbreviations
    ) == 'https://github.com/my-org/my-repo.git'
    assert expand_abbrevi

# Generated at 2022-06-23 16:28:37.054083
# Unit test for function is_zip_file
def test_is_zip_file():
    """Assert that file name in zip format is identified as zip file."""
    test_value = 'test_is_zip_file.zip'
    assert is_zip_file(test_value) == True


# Generated at 2022-06-23 16:28:46.718650
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git+ssh://git@example.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/pydanny/cookiecutter-djangopackage') == True
    assert is_repo_url('https://github.com/pydanny/cookiecutter-djangopackage/') == True

# Generated at 2022-06-23 16:28:53.458903
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Runs all tests for function expand_abbreviations
    """
    abbreviations = {
        'gh': "https://github.com/{0}.git"
    }
    template = "gh:audreyr/cookiecutter-pypackage"
    test_template = expand_abbreviations(template, abbreviations)
    assert test_template == "https://github.com/audreyr/cookiecutter-pypackage.git"

# Generated at 2022-06-23 16:29:03.529211
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file/path/to/template.zip') == True
    assert is_zip_file('file/path/to/template.ZIP') == True
    assert is_zip_file('file/path/to/template.ZiP') == True
    assert is_zip_file('file/path/to/template.ziP') == True
    assert is_zip_file('file/path/to/template.zIP') == True
    assert is_zip_file('file/path/to/template.ZIP.git') == True
    assert is_zip_file('file/path/to/template') == False



# Generated at 2022-06-23 16:29:11.942909
# Unit test for function is_repo_url
def test_is_repo_url():
    def _run_is_repo_url_test(value, expected_result):
        actual_result = is_repo_url(value)
        assert actual_result == expected_result


# Generated at 2022-06-23 16:29:23.818619
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/foo/bar.git')
    assert is_repo_url('git://github.com/foo/bar')
    assert is_repo_url('git@github.com:foo/bar.git')
    assert is_repo_url('git+https://github.com/foo/bar')
    assert is_repo_url('hg+https://foo.com/bar')
    assert is_repo_url('git+ssh://git@github.com/foo/bar')
    assert is_repo_url('git+git://git@github.com/foo/bar')
    assert is_repo_url('git+http://github.com/foo/bar')
    assert is_repo_url('git+https://github.com/foo/bar')


# Generated at 2022-06-23 16:29:29.449083
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.config import DEFAULT_ABBREVIATIONS
    from cookiecutter.repository import find_template
    TEST_DIR = 'tests/fake-repo-tmpl'
    template_name = 'fake-repo-tmpl'
    repo_dir = determine_repo_dir(
        template=template_name,
        abbreviations=DEFAULT_ABBREVIATIONS,
        clone_to_dir='.',
        checkout='master',
        no_input=True,
        password=None,
        directory=None,
    )
    assert repo_dir[0] == TEST_DIR
    assert repo_dir[1] is False



# Generated at 2022-06-23 16:29:33.213411
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json."""
    test_repo_directory = 'tests/fixtures/fake-repo-tmpl'

    assert(repository_has_cookiecutter_json(test_repo_directory) is True)

# Generated at 2022-06-23 16:29:35.210380
# Unit test for function is_zip_file
def test_is_zip_file():
    if is_zip_file("cookiecutter-master.zip"):
        return True
    else:
        return False


# Generated at 2022-06-23 16:29:40.388401
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test is_zip_file method."""
    assert is_zip_file('cookiecutter.zip') == True
    assert is_zip_file('cookiecutter.ZIP') == True
    assert is_zip_file('cookiecutter.ZiP') == True
    assert is_zip_file('cookiecutter.ZIP.another',) == False
    assert is_zip_file('cookiecutter',) == False


# Generated at 2022-06-23 16:29:43.092233
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_test_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    assert is_zip_file(zip_test_url) == True


# Generated at 2022-06-23 16:29:53.195277
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import get_user_config
    from cookiecutter import utils

    # Start with a fresh temporary directory
    temp_dir = tempfile.mkdtemp()
    current_dir = os.getcwd()
    os.chdir(temp_dir)

    # Run a version of cookiecutter that prompts the user to confirm overwriting the existing directory
    test_cookiecutter = functools.partial(cookiecutter, confirm_overwrite=True, no_input=False)
    # Mock out read_user_yes_no so it always auto-responds with 'n'

# Generated at 2022-06-23 16:29:59.414137
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:atlassianlabs/cookiecutter-bitbucket-pipelines.git')
    assert is_repo_url('ssh://hg@bitbucket.org/barseghyanartur/cookiecutter-djangopackage')

# Generated at 2022-06-23 16:30:11.605596
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:atlassian_tutorial/helloworld.git')
    assert is_repo_url('git+https://github.com/audreyr/'
                       'cookiecutter-pypackage.git')
    assert is_repo_url('git+ssh://git@github.com/audreyr/'
                       'cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:30:18.077522
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile, shutil
    try:
        template_dir = tempfile.mkdtemp()
        # should be a dir with cookiecutter.json
        assert repository_has_cookiecutter_json(template_dir) == False

        # create cookiecutter.json
        cookiecutter_json = os.path.join(template_dir, 'cookiecutter.json')
        fp = open(cookiecutter_json, 'w')
        fp.write('{}')
        fp.close()

        # should be a dir with cookiecutter.json now
        assert repository_has_cookiecutter_json(template_dir) == True

    finally:
        # clean up
        shutil.rmtree(template_dir)

# Generated at 2022-06-23 16:30:22.732301
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'g': 'https://github.com/my/{}'}
    template = 'g:foo/bar'
    expected = 'https://github.com/my/foo/bar'
    actual = expand_abbreviations(template, abbreviations)
    assert expected == actual

# Generated at 2022-06-23 16:30:30.922077
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    tmpl = '{{cookiecutter.author_name.lower().replace(" ", "_")}}/{{cookiecutter.repo_name}}'
    tmpl2 = 'github.com/{{cookiecutter.author_name.lower().replace(" ", "-")}}/{{cookiecutter.repo_name}}'
    abbrv = {'test': tmpl, 'test2': tmpl2}
    assert expand_abbreviations('test', abbrv) == tmpl
    assert expand_abbreviations('test:repo_name', abbrv) == tmpl
    assert expand_abbreviations('test2:repo_name', abbrv) == tmpl2

# Generated at 2022-06-23 16:30:37.909884
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # By default, cloning file:///abcd should succeed; checking for existence
    # of repo should fail, but not error
    assert determine_repo_dir(template="file:///abcd",
                              abbreviations={},
                              clone_to_dir='/tmp',
                              checkout="master",
                              no_input=True) == ("/tmp/abcd", False)

    # Should not be able to clone http://, only https://
    try:
        determine_repo_dir(template="http://github.com/audreyr/cookiecutter-pypackage.git",
                           abbreviations={},
                           clone_to_dir='/tmp',
                           checkout="master",
                           no_input=True)
        assert False
    except Exception:
        assert True

    # Successful cloning of https://

# Generated at 2022-06-23 16:30:44.571033
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test function repository_has_cookiecutter_json."""
    if os.name == 'nt':
        # os.path.join() does not work on Windows with single backslash.
        # WORKAROUND the testing path manually with double backslash
        path = 'C:\\my_path\\my_repo_directory'
    else:
        path = '/my_path/my_repo_directory'

    assert repository_has_cookiecutter_json(path) is False



# Generated at 2022-06-23 16:30:50.532999
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("./template.zip") is True
    assert is_zip_file("./template.ZIP") is True
    assert is_zip_file("./template.Zip") is True
    assert is_zip_file("./template.ZiP") is True
    assert is_zip_file("./template.zIp") is True
    assert is_zip_file("./template.zip/invalid") is False
    assert is_zip_file("./template.tar") is False

# Generated at 2022-06-23 16:31:00.565334
# Unit test for function is_repo_url
def test_is_repo_url():

    # for the test we need to disable SSL socket verification
    import ssl

    try:
        _create_unverified_https_context = ssl._create_unverified_context
    except AttributeError:
        # Legacy Python that doesn't verify HTTPS certificates by default
        pass
    else:
        # Handle target environment that doesn't support HTTPS verification
        ssl._create_default_https_context = _create_unverified_https_context


# Generated at 2022-06-23 16:31:08.280902
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template="https://github.com/audreyr/cookiecutter-pypackage",
        abbreviations=None,
        clone_to_dir=os.path.join(os.path.expanduser('~'), 'cookiecutters'),
        checkout=None,
        no_input=True,
        password=None,
    ) == (
        os.path.join(os.path.expanduser('~'), 'cookiecutters', 'cookiecutter-pypackage'),
        False,
    )

# Generated at 2022-06-23 16:31:09.992030
# Unit test for function is_zip_file
def test_is_zip_file():
    f = '../python.zip'
    assert is_zip_file(f) == True

# Generated at 2022-06-23 16:31:13.074794
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)

# Generated at 2022-06-23 16:31:17.798104
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert is_zip_file('test.ZIP')
    assert is_zip_file('some.other.zip')
    assert not is_zip_file('some.other.ZIPz')
    assert not is_zip_file('some.other.txt')
    assert not is_zip_file('some/other/zip')
    assert not is_zip_file('zip')

# Generated at 2022-06-23 16:31:25.250071
# Unit test for function is_repo_url
def test_is_repo_url():
    repo_urls = ['git://github.com/audreyr/cookiecutter-pypackage.git', 'git@github.com:audreyr/cookiecutter-pypackage.git', 
                 'https://github.com/audreyr/cookiecutter-pypackage.git', 'ssh://hg@bitbucket.org/pokoli/cookiecutter-djangopackage', 
                 'git+git://github.com/audreyr/cookiecutter-pypackage.git', 'user@example.com:audreyr/cookiecutter-pypackage.git',
                 '/home/user/audreyr/cookiecutter-pypackage.git']

# Generated at 2022-06-23 16:31:32.270570
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert not is_repo_url("test")
    assert is_repo_url("test.com")
    assert is_repo_url("git@test.com:test/test")
    assert is_repo_url("http://test.com/test")
    assert is_repo_url("https://test.com/test")
    assert is_repo_url("git+https://test.com/test")
    assert is_repo_url("ssh://test.com/test")
    assert is_repo_url("git://test.com/test")
    assert is_repo_url("git+git://test.com/test")
    assert is_repo_url("git+ssh://test.com/test")
    assert is_repo_url("file://test.com/test")

# Generated at 2022-06-23 16:31:34.849689
# Unit test for function is_zip_file
def test_is_zip_file():
    zipfile = "base.zip"
    not_zipfile = "base"
    assert is_zip_file(zipfile) is True
    assert is_zip_file(not_zipfile) is False

# Generated at 2022-06-23 16:31:41.225512
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import pytest
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        with open(os.path.join(tmp_dir, 'cookiecutter.json'), 'w'):
            assert repository_has_cookiecutter_json(tmp_dir)

        with pytest.raises(RepositoryNotFound):
            assert not repository_has_cookiecutter_json(tmp_dir + '123')


# Generated at 2022-06-23 16:31:46.012904
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(
        "/home/greg/cookiecutter-pypackage/"
    ) is True
    assert repository_has_cookiecutter_json(
        "somewhere/that/does/not/exist"
    ) is False

# Generated at 2022-06-23 16:31:50.476270
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('test') == False
    assert is_zip_file('test.') == False
    assert is_zip_file('.zip') == False

# Generated at 2022-06-23 16:31:58.464497
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    assert not repository_has_cookiecutter_json('/blub')
    assert repository_has_cookiecutter_json('/home/')
    assert repository_has_cookiecutter_json('/home/python-boilerplate/')
    assert not repository_has_cookiecutter_json('/home/python-boilerplate')
    assert repository_has_cookiecutter_json('/home/python-boilerplate/project_name/')


# Generated at 2022-06-23 16:32:07.803703
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = dict()
    assert expand_abbreviations("user/repo", abbreviations) == "user/repo"
    assert expand_abbreviations("gh:user/repo", abbreviations) == "gh:user/repo"
    assert expand_abbreviations("user", abbreviations) == "user"
    abbreviations["gh"] = "github.com/{}"
    assert expand_abbreviations("gh:user/repo", abbreviations) == "github.com/user/repo"
    assert expand_abbreviations("user/repo", abbreviations) == "user/repo"



# Generated at 2022-06-23 16:32:16.813690
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }

    result = expand_abbreviations("gh:audreyr/cookiecutter-pypackage", abbreviations)
    assert result == "https://github.com/audreyr/cookiecutter-pypackage.git"
    result = expand_abbreviations("gh:", abbreviations)
    assert result == "https://github.com/{}.git"
    result = expand_abbreviations("bitbucket.org/pydanny/cookiecutter-djangopackage", abbreviations)
    assert result == "https://bitbucket.org/pydanny/cookiecutter-djangopackage"

# Generated at 2022-06-23 16:32:23.781377
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test if some text is a repository url."""
    assert(is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(not is_repo_url('https://github.com/audreyr/cookiecutter-pypackage'))

# Generated at 2022-06-23 16:32:33.672539
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    import shutil
    from cookiecutter.repository import repository_has_cookiecutter_json
    path_to_test = tempfile.mkdtemp()

    # test a irrelevant path
    assert repository_has_cookiecutter_json(path_to_test) is False

    # create the necessary file and check again
    with open(os.path.join(path_to_test, 'cookiecutter.json'), 'w') as f:
        f.write('')
    assert repository_has_cookiecutter_json(path_to_test) is True

    # clean up
    shutil.rmtree(path_to_test)

# Generated at 2022-06-23 16:32:40.576313
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test is_repo_url for all possible combination in cookiecutter.json file."""
    assert is_repo_url("git@github.com:nkatsarakis/cookiecutter-flask-api.git") == True
    assert is_repo_url("git+https://github.com/nkatsarakis/cookiecutter-flask-api.git") == True
    assert is_repo_url("git+git://github.com/nkatsarakis/cookiecutter-flask-api.git") == True
    assert is_repo_url("git+ssh://github.com/nkatsarakis/cookiecutter-flask-api.git") == True

# Generated at 2022-06-23 16:32:44.850774
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('somefile.zip')
    assert not is_zip_file('somefile.tar.gz')
    assert not is_zip_file('somefilezip')
    assert not is_zip_file('zip')
    assert not is_zip_file('https://somefile.zip')


# Generated at 2022-06-23 16:32:48.493296
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }
    template = expand_abbreviations("tw:cookiecutter-django", abbreviations)
    assert template == 'https://github.com/cookiecutter-django.git'

# Generated at 2022-06-23 16:32:57.757760
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:33:02.121036
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {"short": "user/repo"}
    template = 'short'

    test_abbreviation = expand_abbreviations(template, abbreviations)
    assert test_abbreviation == 'user/repo'

# Generated at 2022-06-23 16:33:08.345882
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/fake-repo-tmpl") == True, \
    "Passed"
    assert repository_has_cookiecutter_json("tests/fake-repo-pre") == True, \
    "Passed"
    #this uses a directory that doesn't exist
    assert repository_has_cookiecutter_json("tests/fake-repo-pre1") == False, \
    "Passed"
    #this uses a file that doesn't exist
    assert repository_has_cookiecutter_json("tests/fake-repo-pre/cookiecutter.json") == False, \
    "Passed"

# Generated at 2022-06-23 16:33:12.679379
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert not is_zip_file('test.gz')
    assert not is_zip_file('test.rar')
    assert not is_zip_file('tar.gz')
