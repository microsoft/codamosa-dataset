

# Generated at 2022-06-23 16:23:16.387425
# Unit test for function determine_repo_dir

# Generated at 2022-06-23 16:23:25.155100
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{0}.git'}) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{0}.git'}) == 'audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:Nekroze/cookiecutter-haskell', {'gh': 'https://github.com/{0}.git'}) == 'https://github.com/Nekroze/cookiecutter-haskell.git'

# Generated at 2022-06-23 16:23:27.716575
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_filename = 'asdf.zip'
    assert is_zip_file(zip_filename) == True



# Generated at 2022-06-23 16:23:37.373872
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }

    assert expand_abbreviations('foo', abbreviations) == 'foo'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:maraujop/cookiecutter-django', abbreviations) == \
        'https://bitbucket.org/maraujop/cookiecutter-django.git'

# Generated at 2022-06-23 16:23:42.682542
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    sample_abbreviations = {"test_user": "https://github.com/{}/cookiecutter-test.git"}
    assert expand_abbreviations("test_user:hello", sample_abbreviations) == "https://github.com/hello/cookiecutter-test.git"

if __name__ == '__main__':
    test_expand_abbreviations()

# Generated at 2022-06-23 16:23:53.830756
# Unit test for function is_repo_url
def test_is_repo_url():
    assert not is_repo_url('test')
    assert is_repo_url('git://github.com/pytest-dev/pytest.git')
    assert is_repo_url('git@github.com:pytest-dev/pytest.git')
    assert is_repo_url('https://github.com/pytest-dev/pytest.git')
    assert not is_repo_url('ssh://github.com/pytest-dev/pytest.git')
    assert is_repo_url('git@github.com:pytest-dev/pytest.git')
    assert is_repo_url('git@github.com:pytest-dev/pytest-cov.git')
    assert is_repo_url('git@github.com:pytest-dev/pytest.git')


# Generated at 2022-06-23 16:24:05.200818
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('foo/bar') == False
    assert is_repo_url('foo/bar/baz.zip') == False
    assert is_repo_url('/foo/bar') == False
    assert is_repo_url('~/bar') == False
    assert is_repo_url('./bar') == False
    assert is_repo_url('/foo/bar/baz/') == False
    assert is_repo_url('git@github.com:foo/bar.git') == True
    assert is_repo_url('git@github.com:foo/bar.git') == True
    assert is_repo_url('git+git@github.com:foo/bar.git') == True

# Generated at 2022-06-23 16:24:13.606892
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:24:18.359157
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('myproject.zip') == True
    assert is_zip_file('myproject.ZIP') == True
    assert is_zip_file('myproject.tar.zip') == True
    assert is_zip_file('myproject.zi') == False

# Generated at 2022-06-23 16:24:22.457218
# Unit test for function is_repo_url
def test_is_repo_url():
    url = 'https://example.com/path/to/repo.git'
    assert is_repo_url(url)

    url = 'https://example.com/path/to/repo'
    assert not is_repo_url(url)



# Generated at 2022-06-23 16:24:28.139473
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test against a URL that should be accepted
    assert is_repo_url("git+https://github.com/audreyr/cookiecutter-pypackage.git")
    # Test against a URL that should be rejected
    assert not is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")
    assert not is_repo_url("/this/is/not/a/url")


# Generated at 2022-06-23 16:24:33.435974
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Verify that determine_repo_dir returns a valid directory.
    
    Cookiecutter searches for a valid repository when the user specifies a template
    such as 'https://github.com/user/repo.git', 'https://github.com/user/repo/archive/master.zip', 'user/repo/archive/master.zip', or 'user/repo'.

    Depending on whether the template is a url or directory, Cookiecutter will clone or unzip the repository, respectively. 
    
    test_determine_repo_dir() verifies that determine_repo_dir() returns a valid directory based on the template.
    """

# Generated at 2022-06-23 16:24:43.768241
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'tr': 'https://bitbucket.org/tutorials/'
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    new_abbreviations = expand_abbreviations(template, abbreviations)
    assert new_abbreviations == 'https://github.com/audreyr/cookiecutter-pypackage'

    template = 'bb:audreyr/cookiecutter-pypackage'
    new_abbreviations = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-23 16:24:49.208287
# Unit test for function is_zip_file
def test_is_zip_file():
    """
    Check for is_zip_file
    """

    assert(is_zip_file("junk.zip") == True)
    assert(is_zip_file("junk.ZIP") == True)
    assert(is_zip_file("junk.zIP") == True)
    assert(is_zip_file("junk.zp") == False)
    assert(is_zip_file("junk.z") == False)
    assert(is_zip_file("junk.zipp") == False)

# Generated at 2022-06-23 16:24:56.228182
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("demo.zip")
    assert is_zip_file("demo.ZIP")
    assert is_zip_file("repo-with-capitals.Zip")
    assert not is_zip_file("repo-without-capitals.zip")
    assert not is_zip_file("repo-without-extension")
    assert not is_zip_file("git+https://path/to/repo.git")



# Generated at 2022-06-23 16:25:03.449383
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+ssh://hg@bitbucket.org/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:25:14.511579
# Unit test for function is_zip_file
def test_is_zip_file():
  assert(is_zip_file('test.zip') == True)
  assert(is_zip_file('.zip') == True)
  assert(is_zip_file('/home/test/test.zip') == True)
  assert(is_zip_file('./test.zip') == True)
  assert(is_zip_file('./test.zip1') == False)
  assert(is_zip_file('./test.tar') == False)
  assert(is_zip_file('./test') == False)
  assert(is_zip_file('./test.txt') == False)
  assert(is_zip_file('test.zip.tar') == False)
  assert(is_zip_file('test') == False)
  assert(is_zip_file('test.txt') == False)

# Generated at 2022-06-23 16:25:23.240429
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Create a function to test the template list
    def test_template_list(templates_list, expect_repo_dir, expect_cleanup):
        result_repo_dir = None
        result_cleanup = None
        
        for template_dir, cleanup_after_templating in templates_list:
            if result_repo_dir == None:
                result_repo_dir = template_dir
                result_cleanup = cleanup_after_templating
            elif result_repo_dir != template_dir:
                result_repo_dir = None
                result_cleanup = None
                break
        assert result_repo_dir == expect_repo_dir
        assert result_cleanup == expect_cleanup
    
    # Create a temporary folder to clone

# Generated at 2022-06-23 16:25:25.430963
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("examples/") is True
    assert repository_has_cookiecutter_json("/examples") is False

# Generated at 2022-06-23 16:25:26.981493
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip') == True


# Generated at 2022-06-23 16:25:35.925579
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:pokoli/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/pokoli/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:25:41.559394
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'git': '/home/{}.git'
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:25:46.958086
# Unit test for function is_repo_url
def test_is_repo_url():
    assert True is is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert True is is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert False is is_repo_url('foo')
    assert False is is_repo_url('foo:bar')

# Generated at 2022-06-23 16:25:56.137177
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test the expand_abbreviations function."""
    abbreviations = {"gh": "https://github.com/{}.git", "bb": "https://bitbucket.org/{}.git"}
    template = "gh:audreyr/cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"

    template = "bb:audreyr/cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == "https://bitbucket.org/audreyr/cookiecutter-pypackage.git"

    template = "gh:audreyr/cookiecutter-pypackage"

# Generated at 2022-06-23 16:25:56.701689
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True

# Generated at 2022-06-23 16:26:04.252279
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:26:12.141262
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/home/user/git/cookiecutter-example") == True
    assert repository_has_cookiecutter_json("/home/user/git/cookiecutter-example/") == True
    assert repository_has_cookiecutter_json("/home/user/git/cookiecutter-example/cookiecutter.json") == True
    assert repository_has_cookiecutter_json("/home/user/git/cookiecutter-example/cookiecutter.py") == False

# Generated at 2022-06-23 16:26:16.938164
# Unit test for function is_repo_url
def test_is_repo_url():
    assert not is_repo_url('/Users/audreyr/a_folder')
    assert not is_repo_url('http://example.com/a_folder')
    assert not is_repo_url('http://example.com/a_folder.zip')
    assert is_repo_url('http://example.com/a_folder.git')
    assert is_repo_url('http://example.com/a_folder.git/')
    assert is_repo_url('git://example.com/a_folder.git')
    assert is_repo_url('https://example.com/a_folder.git')
    assert is_repo_url('git+https://example.com/a_folder.git')

# Generated at 2022-06-23 16:26:23.821810
# Unit test for function is_zip_file
def test_is_zip_file():
    tests = [
        ('somefile.zip', True),
        ('somefile.Zip', True),
        ('somefile.ZIP', True),
        ('/some/path/somefile.zip', True),
        ('/some/path/somefile.ZIP', True),
        ('/some/path/somefile.ZiP', True),
        ('somefile.zippitydoppity', False),
        ('/some/path/somefile.zippitydoppity', False),
    ]

    for test_input, expected in tests:
        assert is_zip_file(test_input) == expected

# Generated at 2022-06-23 16:26:35.038490
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert(determine_repo_dir("cookiecutter-pypackage", {}, "", "", False)[0].endswith("cookiecutter-pypackage"))
    assert(determine_repo_dir("git@github.com:audreyr/cookiecutter-pypackage.git", {}, "", "", False)[0].endswith("cookiecutter-pypackage"))
    assert(determine_repo_dir("https://github.com/audreyr/cookiecutter-pypackage", {}, "", "", False)[0].endswith("cookiecutter-pypackage"))
    assert(determine_repo_dir(".", {}, "", "", False)[0].endswith("."))

# Generated at 2022-06-23 16:26:40.555352
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-pypackage.zip')
    assert is_zip_file('cookiecutter-pypackage.ZIP')
    assert not is_zip_file('cookiecutter-pypackage.tar.gz')

'''
Unit test for function determine_repo_dir.
'''

# Generated at 2022-06-23 16:26:48.138741
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Verify that abbreviations are expanded as expected
    """
    abbreviations = {
            'cc': 'https://github.com/{}.git',
            'gh': 'https://github.com/{}.git',
            'pb': 'https://bitbucket.org/{}'
    }
    assert expand_abbreviations('cc:foo/bar', abbreviations) == 'https://github.com/foo/bar.git'
    assert expand_abbreviations('cc:foo/bar', {}) == 'cc:foo/bar'

# Generated at 2022-06-23 16:26:54.393887
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """If something like "pypackage:white" is given, split it."""
    abbreviations = {
        'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'white': 'https://github.com/arakhmatullin/cookiecutter-pypackage-white.git',
    }
    assert (
        expand_abbreviations('pypackage:white', abbreviations)
        == 'https://github.com/arakhmatullin/cookiecutter-pypackage-white.git'
    )

# Generated at 2022-06-23 16:26:58.825384
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template="seanh/cookiecutter-example",
        abbreviations={"seanh": "https://github.com/seanh"},
        clone_to_dir=".",
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ("cookiecutter-example", False)

    assert determine_repo_dir(
        template="/home/seanh/cookiecutter-example",
        abbreviations={},
        clone_to_dir=".",
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ("/home/seanh/cookiecutter-example", False)


# Generated at 2022-06-23 16:27:07.040043
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test for the determine_repo_dir function
    """
    template = 'https://github.com/user/repo'
    abbreviations = {'gh': 'https://github.com/{}'}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = True
    password = 'password'
    directory = None

    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    assert repo_dir == './repo'
    assert cleanup == False


if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-23 16:27:11.516955
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test for the determine_repo_dir() function.
    """
    # Default
    assert determine_repo_dir(template='') == ()

    # Template
    assert determine_repo_dir(template='/_template') == ()



# Generated at 2022-06-23 16:27:11.931983
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-23 16:27:19.693017
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert 'https://github.com/audreyr/cookiecutter.git' == expand_abbreviations('gh:audreyr/cookiecutter', abbreviations)
    assert 'https://github.com/audreyr/cookiecutter-pypackage.git' == expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert 'https://bitbucket.org/pydanny/cookiecutter-django.git' == expand_abbreviations('bb:pydanny/cookiecutter-django', abbreviations)

# Generated at 2022-06-23 16:27:28.767462
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git#egg=cookiecutter-pypackage')
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:27:35.734594
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo/bar/my_repo.zip')
    assert is_zip_file('my_repo.zip')
    assert not is_zip_file('git@github.com:jacebrowning/my_repo.git')
    assert not is_zip_file('my_repo')
    assert not is_zip_file('.zip')


# Generated at 2022-06-23 16:27:42.614857
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function is_zip_file."""
    test_data = [
        ('path/to/template', False),
        ('path/to/template.zip', True),
        ('https://github.com/audreyr/cookiecutter-pypackage.git', False),
    ]
    for item in test_data:
        assert is_zip_file(item[0]) == item[1]



# Generated at 2022-06-23 16:27:49.515091
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # test with valid template
    template_valid = 'https://github.com/siddharthp/git-template-valid.git'
    repo_dir_valid, cleanup = determine_repo_dir(template_valid, None, None, '', None)
    assert repository_has_cookiecutter_json(repo_dir_valid)

    # test with invalid template
    template_invalid = 'https://github.com/siddharthp/git-template-invalid.git'
    repo_dir_invalid, cleanup = determine_repo_dir(template_invalid, None, None, '', None)
    assert not repository_has_cookiecutter_json(repo_dir_invalid)

# Generated at 2022-06-23 16:27:59.261153
# Unit test for function is_repo_url
def test_is_repo_url():
    a = is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert a == True, "git@github.com:audreyr/cookiecutter-pypackage.git is a valid address"
    b = is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert b == True, "https://github.com/audreyr/cookiecutter-pypackage.git is a valid address"
    c = is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert c == True, "git://github.com/audreyr/cookiecutter-pypackage.git is a valid address"

# Generated at 2022-06-23 16:28:08.001288
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for repository_has_cookiecutter_json"""
    assert repository_has_cookiecutter_json('fixtures/fake-repo-tmpl') is True
    assert repository_has_cookiecutter_json('fixtures/fake-repo-pre/{{cookiecutter.repo_name}}') is True
    assert repository_has_cookiecutter_json('cookiecutter.json') is False
    assert repository_has_cookiecutter_json('fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}') is False
    assert repository_has_cookiecutter_json('fixtures/fake-repo-nonexistent') is False

# Generated at 2022-06-23 16:28:14.742405
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('py',{'py':'Python'}) == 'Python'
    assert expand_abbreviations('py:123',{'py':'Python:{}'}) == 'Python:123'
    assert expand_abbreviations('py:123',{'Python':'Python:{}'}) == 'Python:123'

# Generated at 2022-06-23 16:28:19.113561
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    import os

    directory = tempfile.mkdtemp()
    open(os.path.join(directory, 'cookiecutter.json'), 'a').close()
    assert repository_has_cookiecutter_json(directory)
    os.rmdir(directory)

# Generated at 2022-06-23 16:28:28.447346
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_candidate = '/Users/cookiecutter-1.0.0'
    #when dir does not exist
    assert repository_has_cookiecutter_json(repo_candidate) == False
    #when dir exists and has cookiecutter.json
    os.mkdir(repo_candidate)
    open(os.path.join(repo_candidate, 'cookiecutter.json'), 'a').close()
    assert repository_has_cookiecutter_json(repo_candidate) == True
    #when dir exists and does not have cookiecutter.json
    os.unlink(os.path.join(repo_candidate, 'cookiecutter.json'))
    assert repository_has_cookiecutter_json(repo_candidate) == False
    #clean up

# Generated at 2022-06-23 16:28:31.378177
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("something.zip") == True
    assert is_zip_file("something.ZIP") == True
    assert is_zip_file("something.zIp") == True
    assert is_zip_file("something.ziP") == True

    assert is_zip_file("something.tar.gz") == False


# Generated at 2022-06-23 16:28:42.113247
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    cookiecutter_json_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )
    clone_to_dir = '.tests'
    non_existent_dir = 'non_existent_dir'
    assert not repository_has_cookiecutter_json(non_existent_dir)
    assert repository_has_cookiecutter_json(cookiecutter_json_dir)

    # Test with a template that exists
    template = 'fake-repo-pre'
    abbreviations = {}
    checkout = 'master'
    no_input = True

# Generated at 2022-06-23 16:28:48.679529
# Unit test for function is_zip_file
def test_is_zip_file():
    cases = [
        ("archive.zip", True),
        ("archive.tar.gz", False),
        ("archive.ZIP", True),
        ("archive.TAR.GZ", False),
        ("archive.zip.gz", False),
        ("zip", False),
    ]
    for case in cases:
        assert(is_zip_file(case[0]) == case[1])


# Generated at 2022-06-23 16:29:01.494758
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///home/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+ssh://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:29:07.416658
# Unit test for function is_zip_file
def test_is_zip_file():
    """Assert that is_zip_file() is working properly."""
    test_path = 'cookiecutter/tests/context/fake-repo-tmpl'
    assert is_zip_file(test_path) is False
    test_path = 'cookiecutter/tests/context/fake-repo-tmpl.zip'
    assert is_zip_file(test_path) is True

# Generated at 2022-06-23 16:29:16.321171
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    input1 = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    input2 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    input3 = '~/my-projects/cookiecutter-pypackage'
    input4 = 'cookicutter-pypackage'
    input5 = 'audreyr/cookiecutter-pypackage'
    input6 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    input7 = 'audreyr/cookiecutter-pypackage/archive/master.zip'

    clone_to_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:29:22.570094
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""

# Generated at 2022-06-23 16:29:26.027185
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:29:31.770973
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # create a directory and put a cookiecutter.json file in there
    # then test determine_repo_dir with it
    import os
    import shutil
    import tempfile
    template_name = 'test_determine_repo_dir'
    my_template_dir = os.path.join(tempfile.gettempdir(), template_name) + os.sep
    shutil.copytree(
        os.path.join('tests', 'test-data', 'fake-repo-tmpl'),
        my_template_dir,
    )
    my_clone_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 16:29:33.578174
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True

# Generated at 2022-06-23 16:29:35.210323
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test.zip")
    assert not is_zip_file("test.json")

# Generated at 2022-06-23 16:29:39.221945
# Unit test for function is_repo_url
def test_is_repo_url():
    """ Unit test for function is_repo_url """
    assert True == is_repo_url('https://github.com/hodgestar/cookiecutter-pypackage')
    assert True == is_repo_url('git+https://github.com/hodgestar/cookiecutter-pypackage')
    assert True == is_repo_url('user@example.com')
    assert False == is_repo_url('example.com')
    assert False == is_repo_url('file:///C:\directory/cookiecutter-pypackage')
    assert False == is_repo_url('ssh://user@exmaple.com/cookiecutter-pypackage')
    assert False == is_repo_url('C:\directory\cookiecutter-pypackage')

# Generated at 2022-06-23 16:29:45.417834
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """ Unit test for function determine_repo_dir """
    test_repo_dir = determine_repo_dir(
        template="/Users/me/my_repositories/my_cookiecutter_repo",
        abbreviations={},
        clone_to_dir="/tmp",
        checkout="master",
        no_input=True,
        password=None,
        directory=None
    )
    assert test_repo_dir == ("/Users/me/my_repositories/my_cookiecutter_repo", False)

# Generated at 2022-06-23 16:29:55.063916
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'ghu': '{}',
    }

    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    expanded = expand_abbreviations(template, abbreviations)
    assert expanded == expected

    template = 'bb:audreyr/cookiecutter-pypackage'
    expected = 'https://bitbucket.org/audreyr/cookiecutter-pypackage'
    expanded = expand_abbreviations(template, abbreviations)
    assert expanded == expected


# Generated at 2022-06-23 16:30:06.010645
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import shutil
    import tempfile
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the subdirectory /myproject
    myproject = os.path.join(tmpdir, 'myproject')
    os.makedirs(myproject)
    # Create the file cookiecutter.json in that subdirectory
    with open(os.path.join(myproject, 'cookiecutter.json'), 'w') as f:
        f.write('{}')
    # Should return true
    assert repository_has_cookiecutter_json(myproject) == True
    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-23 16:30:10.227947
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('unicorn.zip')
    assert is_zip_file('unicorn.ZIP')
    assert is_zip_file('unicorn.Zip')
    assert not is_zip_file('unicorn.zipx')

# Generated at 2022-06-23 16:30:15.257127
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-post/') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo/') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-post/fake-repo/') == True

# Generated at 2022-06-23 16:30:25.103048
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # Test with a clone_to_dir
    test_clone_to_dir = os.path.join(os.path.expanduser('~'), 'test_clone_to_dir')
    test_template = 'https://github.com/audreyr/cookiecutter-pypackage'

    template_dir, cleanup = determine_repo_dir(
        template=test_template,
        abbreviations={},
        clone_to_dir=test_clone_to_dir,
        checkout='',
        no_input=False,
        password=None,
    )

    assert template_dir.startswith(test_clone_to_dir) is True
    assert cleanup is False


# Generated at 2022-06-23 16:30:33.598720
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    from unittest import mock
    from tempfile import NamedTemporaryFile

    # Py2k does not have mock_open
    if not hasattr(mock, 'mock_open'):
        mock.mock_open = mock.Mock

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone_to_dir = '/home/audreyr'
    abbreviations = {}
    checkout = None
    no_input = False
    password = None

    repo_dir, cleanup = determine_repo_dir(template,
                                           abbreviations,
                                           clone_to_dir,
                                           checkout,
                                           no_input,
                                           password)

# Generated at 2022-06-23 16:30:43.678825
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'git@gitlab.com:{}.git',
        'local': '/Users/foo/projects/{}',
    }

    fullname = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert fullname == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    fullname = expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations)
    assert fullname == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:30:49.328814
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test if a value ends with .zip should return True."""
    assert is_zip_file('/path/to/project_template.zip') is True
    assert is_zip_file('/path/to/project_template.ZIP') is True
    assert is_zip_file('/path/to/project_template.ZiP') is True
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git') is False

# Generated at 2022-06-23 16:30:52.208511
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Repository will be recognized as a template if it contains cookiecutter.json file.
    """
    repo_dir = os.path.dirname(os.path.realpath(__file__))
    assert repository_has_cookiecutter_json(repo_dir)

# Generated at 2022-06-23 16:31:02.213298
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # TODO: test http:// and git://
    test_repo_dir = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='./',
        checkout='master',
        no_input=True,
        password=None,
        directory=None,
    )
    assert test_repo_dir[0] == './cookiecutter-pypackage'


# Generated at 2022-06-23 16:31:04.664867
# Unit test for function is_zip_file
def test_is_zip_file():
    assert (is_zip_file('test_file.zip') == True)
    assert (is_zip_file('test_file.xml') == False)
    assert (is_zip_file('test_file') == False)

# Generated at 2022-06-23 16:31:08.140591
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert (repository_has_cookiecutter_json(
        "/home/user/repo/test")) == True
    assert (repository_has_cookiecutter_json(
        "/home/user/repo/test/cookiecutter.json")) == False
    assert (repository_has_cookiecutter_json(
        "/home/user/repo/")) == False

# Generated at 2022-06-23 16:31:17.938287
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import pytest

    def test_local_and_github_repo():
        template = 'foo/bar'
        abbreviations = {
            'myrepo': 'https://github.com/myorg/myrepo.git',
        }
        clone_to_dir = '.'
        checkout = None
        no_input = False

        repo_dir, cleanup = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
        )
        assert repo_dir == 'foo/bar'
        assert not cleanup

        template = 'myrepo'
        repo_dir, cleanup = determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input,
        )
       

# Generated at 2022-06-23 16:31:23.948370
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    print("Testing function repository_has_cookiecutter_json...")
    from shutil import rmtree
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        # Create new directory that should be a repository
        os.makedirs(os.path.join(tmpdir, 'repo_dir', 'cookiecutter.json'))
        assert repository_has_cookiecutter_json(os.path.join(tmpdir, 'repo_dir'))

    # Remove the temporary directory
    # rmtree(tmpdir)

# Generated at 2022-06-23 16:31:29.641378
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh', {'gh': 'https://github.com/{}'}) == 'https://github.com/'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{}'}) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {}) == 'gh:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:31:40.958384
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that detects when a valid repository is found."""
    # Real, but not valid repo
    real_but_not_valid = os.path.join(os.path.dirname(__file__), '..')
    assert not repository_has_cookiecutter_json(real_but_not_valid)

    # Real and valid repo.
    real_and_valid = os.path.join(os.path.dirname(__file__), '..', '..')
    assert repository_has_cookiecutter_json(real_and_valid)

    # Fake, but not valid repo
    not_real_nor_valid = os.path.join(os.path.dirname(__file__), 'fake', 'fake')
    assert not repository_has_cookiecutter_json(not_real_nor_valid)

# Generated at 2022-06-23 16:31:45.282729
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('repo.zip')
    assert is_zip_file('repo.ZIP')
    assert not is_zip_file('repo.json')
    assert not is_zip_file('repozip')

# Generated at 2022-06-23 16:31:54.576098
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'default': 'https://github.com/audreyr/cookiecutter-pypackage.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:some/repo', abbreviations) == 'https://github.com/some/repo.git'
    assert expand_abbreviations('bb:some/repo', abbreviations) == 'https://bitbucket.org/some/repo.git'
    assert expand_abbre

# Generated at 2022-06-23 16:32:00.819211
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test if determine_repo_dir returns the right repository directory."""
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations=None,
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    ) == ('./cookiecutter-pypackage', False)

# Generated at 2022-06-23 16:32:11.700706
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    curr_dir = os.getcwd()
    temp_dir = os.path.join(curr_dir, 'test_template')

# Generated at 2022-06-23 16:32:19.448393
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    # Test expand_abbreviations with abbreviations
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == expected_template

    # Test expand_abbreviations without abbreviations
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    expected_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:32:22.060681
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-post/') == False


# Generated at 2022-06-23 16:32:27.378976
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('url_to_zip_file.zip')
    assert is_zip_file('https://example.com/archive.zip')
    assert not is_zip_file('something.notzip')
    assert not is_zip_file('zip')



# Generated at 2022-06-23 16:32:33.074082
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('aabb.zip') == True
    assert is_zip_file('aabb.zip.txt') == False
    assert is_zip_file('.zip') == False
    assert is_zip_file('aabb.ZIP') == True
    assert is_zip_file('aabb.ZIP.txt') == False
    assert is_zip_file('.ZIP') == False


# Generated at 2022-06-23 16:32:36.179564
# Unit test for function is_zip_file
def test_is_zip_file():
    is_zip_file('/my/dir/myfile.zip')
    is_zip_file('myfile.zip')
    is_zip_file('myfile.ZIP')



# Generated at 2022-06-23 16:32:46.929844
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from functools import partial
    from cookiecutter.generate import check_dir

    abbreviations = {
        'full': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    expand_abbreviations = partial(
        determine_repo_dir,
        abbreviations=abbreviations,
        clone_to_dir='',
        checkout='',
        no_input=False,
        password='',
        directory='',
    )

    assert expand_abbreviations('full') == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations

# Generated at 2022-06-23 16:32:56.988820
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        template="gh:audreyr/cookiecutter-pypackage",
        abbreviations={"gh": "https://github.com/{}"},
    ) == "https://github.com/audreyr/cookiecutter-pypackage"

    assert expand_abbreviations(
        template="audreyr/cookiecutter-pypackage",
        abbreviations={"gh": "https://github.com/{}"},
    ) == "audreyr/cookiecutter-pypackage"


# Generated at 2022-06-23 16:33:07.080904
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that repository_has_cookiecutter_json returns the correct response for a good directory"""
    # Make a good repository
    import tempfile
    from cookiecutter.config import get_config_file
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    temp_dir = tempfile.mkdtemp()
    template = 'https://github.com/audreyr/cookiecutter-pypackage'
    cookiecutter(template, extra_context={'full_name': 'Test Developer'}, output_dir=temp_dir)
    repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    # Now test it
    assert repository_has_cookiecutter_json(repo_dir) is True

# Generated at 2022-06-23 16:33:09.466411
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("foo.zip") == True
    assert is_zip_file("foo.bar.zip") == True
    assert is_zip_file("foo.bar.ZIP") == True
    assert is_zip_file("foo.bar.zippp") == False

# Generated at 2022-06-23 16:33:12.419060
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('somerepo.zip')
    assert not is_zip_file('somerepo.gif')

# Unit tests for function expand_abbreviations

# Generated at 2022-06-23 16:33:17.787370
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('example.zip') == True
    assert is_zip_file('url') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git') == False


if __name__ == '__main__':
    test_is_zip_file()