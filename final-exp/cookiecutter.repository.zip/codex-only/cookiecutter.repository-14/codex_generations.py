

# Generated at 2022-06-23 16:23:24.427268
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file(r"C:\Users\foo\bar\baz\proj_name.zip")
    assert is_zip_file(r"/home/foo/bar/baz/proj_name.zip")
    assert is_zip_file(r"https://github.com/audreyr/cookiecutter-pypackage/archive/1.0.zip")
    assert not is_zip_file(r"https://github.com/audreyr/cookiecutter-pypackage/archive/1.0.tar.gz")
    assert not is_zip_file(r"https://github.com/audreyr/cookiecutter-pypackage/archive/1.0")

# Generated at 2022-06-23 16:23:35.449238
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify result of is_repo_url()."""
    assert is_repo_url('example.com/may')
    assert is_repo_url('example.com/may.git')
    assert is_repo_url('example.com/may/')
    assert is_repo_url('example.com/may.git/')
    assert is_repo_url('git+http://example.com/may')
    assert is_repo_url('git+http://example.com')
    assert is_repo_url('git+http://example.com/may.git')
    assert is_repo_url('git+http://example.com/may.git/')
    assert is_repo_url('git+https://example.com/may')

# Generated at 2022-06-23 16:23:42.322997
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('http://file.zip')
    assert is_zip_file('git@git.zip')
    assert is_zip_file('file:///file.zip')
    assert is_zip_file('git+https://git.zip')
    assert is_zip_file('git+ssh://git.zip')
    assert not is_zip_file('file.zp')
    assert not is_zip_file('file.zip.p')


# Generated at 2022-06-23 16:23:45.862263
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("abc.zip") is True
    assert is_zip_file("abc.tar") is False
    assert is_zip_file("abc.tar.gz") is False
    assert is_zip_file("abc.7z") is False

# Generated at 2022-06-23 16:23:55.822479
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}'}

    # Test abbreviation expansion without any abbreviation
    expected_result = 'https://github.com/audreyr/cookiecutter-pypackage'
    template = 'https://github.com/audreyr/cookiecutter-pypackage'

    assert expand_abbreviations(template, abbreviations) == expected_result

    # Test abbreviation expansion with abbreviation
    expected_result = 'https://github.com/audreyr/cookiecutter-pypackage'
    template = 'gh:audreyr/cookiecutter-pypackage'

    assert expand_abbreviations(template, abbreviations) == expected_result

    # Test abbreviation expansion with abbreviation and path separators

# Generated at 2022-06-23 16:24:01.302076
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test determine_repo_dir() function.

    API changes have deep consequences on the whole project, so let's
    make sure we have basic test coverage.
    """
    from .main import cli

    result = cli.invoke(
        cli.commands['init'], ['tests/fake-repo-tmpl']
    )
    assert result.exit_code == 0

# Generated at 2022-06-23 16:24:07.486582
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import os
    repo_directory = os.path.expanduser("~/.cookiecutters")
    template = 'pypackage'
    repo_directory = os.path.join(repo_directory, template)
    repository_has_cookiecutter_json(repo_directory)
    # assert repository_has_cookiecutter_json(repo_directory) == False
    assert repository_has_cookiecutter_json(repo_directory) == True


# Generated at 2022-06-23 16:24:18.752160
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test regex for repository URL."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('http://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('ssh://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('git@bitbucket.org:atlassianlabs/common-git-hooks')
    assert not is_repo_url('/foo/bar.git')

# Generated at 2022-06-23 16:24:23.478947
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded = expand_abbreviations(template, abbreviations)
    assert expanded == 'https://github.com/audreyr/cookiecutter-pypackage.git'



# Generated at 2022-06-23 16:24:31.215291
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Tests cookiescutter determine_repo_dir.

    Defines abbreviations to use in case of shortened templates.
    Defines a template path to test a local repo.
    Checks all possible matches as defined in determine_repo_dir and returns
    a boolean.
    """
    abbreviations = {'gh': 'https://github.com/{}'}
    directory = None
    checkout = 'master'
    no_input = True
    template = 'gh:audreyr/cookiecutter-pypackage'
    clone_to_dir = 'cookiecutters'
    cookiecutter_dir, cleanup = determine_repo_dir(template, abbreviations,
                                               clone_to_dir, checkout,
                                               no_input, directory=directory)

# Generated at 2022-06-23 16:24:42.278239
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(template='Cookiecutter-pypackage', abbreviations={
        'Cookiecutter-pypackage': 'https://github.com/audreyr/cookiecutter-pypackage'
    }) == (
        'https://github.com/audreyr/cookiecutter-pypackage',
        False
    )

    assert determine_repo_dir(template='cookiecutter-pypackage', abbreviations={
        'cookiecutter-pypackage': 'https://github.com/audreyr/cookiecutter-pypackage'
    }) == (
        'https://github.com/audreyr/cookiecutter-pypackage',
        False
    )


# Generated at 2022-06-23 16:24:46.070441
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that repo_directory that has cookiecutter.json is identified."""
    assert repository_has_cookiecutter_json(
        'tests/test-suite/fake-repo-pre/'
    ) == True



# Generated at 2022-06-23 16:24:53.542288
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # test_determine_repo_dir_invalid_template
    with pytest.raises(RepositoryNotFound):
        determine_repo_dir(
            template='https://github.com/not-a-github-user/not-a-repo.git',
            abbreviations=None,
            clone_to_dir='.',
            checkout=None,
            no_input=False,
        )



# Generated at 2022-06-23 16:24:55.739130
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True



# Generated at 2022-06-23 16:25:04.086541
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'lp': 'lp:{}',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded = expand_abbreviations(template, abbreviations)
    assert expanded == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded = expand_abbreviations(template, {})
    assert expanded == 'gh:audreyr/cookiecutter-pypackage'

    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded = expand_abbrevi

# Generated at 2022-06-23 16:25:11.039158
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}

    # Test matching of abbreviation
    assert expand_abbreviations('gh:myuser/myrepo', abbreviations) == 'https://github.com/myuser/myrepo.git'

    # Test non matching of abbreviation
    assert expand_abbreviations('myuser/myrepo', abbreviations) == 'myuser/myrepo'

# Generated at 2022-06-23 16:25:19.772669
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from .main import DEFAULT_CONFIG
    from .config import DEFAULT_ABBREVIATIONS

    DEFAULT_ABBREVIATIONS.update({'my_awesome_repo': 'git@github.com:my_awesome_repo'})

    template= 'my_awesome_repo'
    abbreviations = DEFAULT_ABBREVIATIONS
    repo_dir = determine_repo_dir(template, abbreviations,
                                      DEFAULT_CONFIG['clone_to_dir'],
                                      DEFAULT_CONFIG['checkout'],
                                      DEFAULT_CONFIG['no_input'],
                                      DEFAULT_CONFIG['password'],
                                      )[0]
    print(repo_dir)
    assert 'my_awesome_repo' in repo_dir

# Generated at 2022-06-23 16:25:28.499077
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre', 'fake-repo'
    )
    assert repository_has_cookiecutter_json(repo_directory) == True

    repo_directory = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'
    )
    assert repository_has_cookiecutter_json(repo_directory) == False

# Generated at 2022-06-23 16:25:37.078281
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.config import read_user_config, DEFAULT_ABBREVIATIONS
    from cookiecutter import DEFAULT_CONFIG

    # init
    config = read_user_config(DEFAULT_CONFIG["user_config_path"])
    abbreviations = dict(DEFAULT_ABBREVIATIONS, **config["abbreviations"])

    # invalid url
    repo_url = "https://fake.com/foo/bar.git"
    directory = "foobardir"

# Generated at 2022-06-23 16:25:39.338819
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('sample.zip') == True
    assert is_zip_file('sample.tar.gz') == False


# Generated at 2022-06-23 16:25:42.399836
# Unit test for function is_zip_file
def test_is_zip_file():
    """Tests is_zip_file."""
    assert is_zip_file('file.zip') == True


# Generated at 2022-06-23 16:25:48.020729
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter.zip') == True
    assert is_zip_file('/home/foo/cookiecutter.zip') == True
    assert is_zip_file('https://github.com/audreyr/cookiecutter.git') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter/archive/master.zip') == True


# Generated at 2022-06-23 16:25:50.413261
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test/test.zip')
    assert not is_zip_file('test/test')
    assert not is_zip_file('test/test.tar.gz')

# Generated at 2022-06-23 16:26:00.465501
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+ssh://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'git://github.com/audreyr/cookiecutter-pypackage/'
        'tree/1.0.2#egg=cookiecutter-pypackage-1.0.2'
    )

# Generated at 2022-06-23 16:26:06.180670
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Return the directory that contains a template.

    Discard the cleanup parameter, which is a boolean for whether to
    clean up the directory after running the tests.
    """
    cookiecutter_dir, _ = determine_repo_dir(
        template='cookiecutter-pypackage/',
        abbreviations={},
        clone_to_dir=os.path.abspath('./'),
        checkout='master',
        no_input=False,
        password=None,
        directory='tests/fake-repo-pre/',
    )
    assert cookiecutter_dir.endswith(
        'tests/fake-repo-pre'
    )

# Generated at 2022-06-23 16:26:14.710498
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_repo = "/dev/null"
    assert not repository_has_cookiecutter_json(test_repo)
    test_repo = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        "../tests/test-template"
    )
    assert repository_has_cookiecutter_json(test_repo)
    test_repo = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        "../tests/test-template/non-existing"
    )
    assert not repository_has_cookiecutter_json(test_repo)

# Generated at 2022-06-23 16:26:24.322877
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""
    urls = [
        'github.com/audreyr/cookiecutter-pypackage',
        'https://github.com/audreyr/cookiecutter-pypackage',
        'git+https://github.com/audreyr/cookiecutter-pypackage',
        'git://github.com/audreyr/cookiecutter-pypackage',
        'ssh://git@github.com/audreyr/cookiecutter-pypackage',
        'git@github.com:audreyr/cookiecutter-pypackage',
        'file://localhost/home/username/path/to/repo',
    ]
    for url in urls:
        assert is_repo_url(url) is True

# Unit

# Generated at 2022-06-23 16:26:35.649143
# Unit test for function is_repo_url
def test_is_repo_url():

    assert is_repo_url('file:///home/nuxeo/nuxeo-core/') == True
    assert is_repo_url('git+git://git.example.com/MyProject#egg=MyProject') == True
    assert is_repo_url('git+https://github.com/abhilashlal/cookiecutter-flask-pkg') == True
    assert is_repo_url('https://github.com/nuxeo/nuxeo.git') == True
    assert is_repo_url('git://github.com/nuxeo/nuxeo.git') == True
    assert is_repo_url('ssh://github.com/nuxeo/nuxeo.git') == True

# Generated at 2022-06-23 16:26:47.467752
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir() function."""
    from cookiecutter.main import cookiecutter

    template = 'https://github.com/pytest-dev/cookiecutter-pytest-plugin'
    output_dir = 'tests/test-output/'
    result = cookiecutter(
        template=template,
        output_dir=output_dir,
        checkout=None,
        no_input=True,
        extra_context={
            'full_name': 'Vitor Oliveira',
            'email': 'vjoaop@gmail.com',
            'github_username': 'vitorjoao',
            'project_name': 'hello-world',
        },
    )
    assert result['cookiecutter'] == output_dir


# Generated at 2022-06-23 16:26:52.794402
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    here = os.path.abspath(os.path.dirname(__file__))
    fixtures_dir = os.path.join(here, 'fixtures')
    template_dir = os.path.join(fixtures_dir, 'fake-repo-tmpl')
    assert repository_has_cookiecutter_json(template_dir)

# Generated at 2022-06-23 16:27:00.977124
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    )
    assert not repository_has_cookiecutter_json(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    )
    assert not repository_has_cookiecutter_json(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'no-repo-here')
    )

# Generated at 2022-06-23 16:27:09.036447
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@bitbucket.org:pydanny/cookiecutter-django.git') == True
    assert is_repo_url('git+https://github.com/pydanny/cookiecutter-django.git') == True
    assert is_repo_url('hg+https://bitbucket.org/pydanny/cookiecutter-django#develop') == True

# Generated at 2022-06-23 16:27:11.360919
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert not is_zip_file('test.tar')

# Generated at 2022-06-23 16:27:16.796882
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    "test to confirm that expand_abbreviations works as advertised"
    from cookiecutter.prompt import read_user_choice

    abbreviations = {'gh': 'https://github.com/{}/cookiecutter-{}.git'}
    template = "gh:pydanny/cookiecutter-django"
    exptemplate = "https://github.com/pydanny/cookiecutter-django.git"

    assert(exptemplate == expand_abbreviations(template, abbreviations))


# Generated at 2022-06-23 16:27:27.108498
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = dict(
        gh='https://github.com/{}.git',
        bb='https://bitbucket.org/{}.git',
    )
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_url = 'https://github.com/pydanny/cookiecutter-django.git'
    #repo_url = 'https://github.com/scummos/cookiecutter-jinja2-module.git'
    #repo_url = 'gh:pydanny/cookiecutter-django'
    #repo_url = 'bb:scummos/cookiecutter-jinja2-module'
    #repo_url = '/Users/scummos/Development/scummos/cookiecutter-jinja

# Generated at 2022-06-23 16:27:40.049065
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip') == True, "Url to a zip file must be True"
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage') == False, "A url must return False"
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.tar.gz') == False, "A file that is not zip must return False"
    assert is_zip_file('/home/test/test.zip') == True, "A path to a zip file must return True"
    assert is_zip_file('~/test/test.zip') == True, "A path to a zip file must return True"
   

# Generated at 2022-06-23 16:27:48.861987
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "fake_template_dir"
    abbreviations = {"fake_template_dir" : "fake_abbreviation_dir"}
    clone_to_dir = "fake_clone_to_dir"
    checkout = "fake_checkout"
    no_input = "fake_no_input"
    password = "fake_password"
    directory = "fake_directory"
    try:
        assert determine_repo_dir(template, abbreviations, clone_to_dir,
        checkout, no_input, password, directory)
    except RepositoryNotFound:
        cleanup = "nothing to see here"
    expected = "fake_abbreviation_dir/fake_directory"
    assert expected == determine_repo_dir(template, abbreviations, clone_to_dir,
        checkout, no_input, password, directory)[0]

# Generated at 2022-06-23 16:27:59.003112
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # - test
    #   - input
    #   - expected result
    #   - expected cleanup
    test_name = 'determine_repo_dir'

# Generated at 2022-06-23 16:28:01.705144
# Unit test for function is_zip_file
def test_is_zip_file():
    """Verify is_zip_file() returns a boolean."""
    assert isinstance(is_zip_file("test.zip"), bool)

# Generated at 2022-06-23 16:28:10.540342
# Unit test for function determine_repo_dir

# Generated at 2022-06-23 16:28:21.200468
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # a directory with a cookiecutter.json file should be valid
    repo_directory = os.path.join('tests', 'fixtures', 'fake-repo-pre')
    repo_directory_exists = os.path.isdir(repo_directory)
    repo_config_exists = os.path.isfile(
        os.path.join(repo_directory, 'cookiecutter.json')
    )
    assert repository_has_cookiecutter_json(repo_directory) == (
        repo_directory_exists and repo_config_exists
    )

    # a directory without a cookiecutter.json file should be invalid
    repo_directory = os.path.join('tests', 'fixtures', 'fake-repo-post')

# Generated at 2022-06-23 16:28:32.132468
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import determine_repo_dir
    import shutil

    # Create a temporary working directory
    import tempfile

    temp_dir = tempfile.mkdtemp()

    # Define the directory to clone a repository into
    clone_to_dir = temp_dir + "/repos"

    # Define test directory, should not be a repo
    test_dir = clone_to_dir + "/test-repo"

    # Define the test repository
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"

    # Define abbreviations
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
    }

    # Test that determine_repo_dir

# Generated at 2022-06-23 16:28:39.035829
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Tests for function expand_abbreviations."""
    abbr = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_url = expand_abbreviations(template, abbr)
    assert repo_url == expected
    assert is_repo_url(repo_url)
    template = 'same'
    default_repo_url = expand_abbreviations(template, abbr)
    assert default_repo_url == template



# Generated at 2022-06-23 16:28:48.694260
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == False
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git#master') == True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('ssh://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('file:///Users/fake/cookiecutter-pypackage.git') == True
    assert is_

# Generated at 2022-06-23 16:28:55.928478
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    input = '<repo>:<rest>'
    abbreviations = {'<repo>': 'git@github.com:<rest>'}
    expected = expand_abbreviations(input, abbreviations)
    assert expected == 'git@github.com:<rest>', 'Input: {input} Expected: {expected}'.format(
        input=input,
        expected=expected,
    )


# Generated at 2022-06-23 16:29:02.894642
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test type checking in the is_repo_url function.

    :return: None
    """
    test_urls = {
        (True, "git@github.com:audreyr/cookiecutter.git"): None,
        (False, "not a repo"): None,
    }
    for test_url in test_urls:
        assert is_repo_url(test_url) == test_urls[test_url]

# Generated at 2022-06-23 16:29:13.698747
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for function `repository_has_cookiecutter_json`"""

    import tempfile
    import shutil

    repo_dir = None
    try:
        # Without cookiecutter.json
        repo_dir = tempfile.mkdtemp()
        assert repository_has_cookiecutter_json(repo_dir) == False

        # With cookiecutter.json
        cookiecutter_json_fp = os.path.join(repo_dir, 'cookiecutter.json')
        open(cookiecutter_json_fp, 'a').close()
        assert repository_has_cookiecutter_json(repo_dir) == True
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:29:20.974464
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    if not repository_has_cookiecutter_json(curr_dir):
        raise ValueError("repository_has_cookiecutter_json returned False on"
                         "good repo")
    if repository_has_cookiecutter_json(curr_dir + '/foobar'):
        raise ValueError("repository_has_cookiecutter_json returned True on"
                         "bad repo")

# Generated at 2022-06-23 16:29:29.018571
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test that abbreviations can be expanded."""
    assert expand_abbreviations('cookiecutter-pypackage:', {}) == 'cookiecutter-pypackage:'
    assert expand_abbreviations('cookiecutter-pypackage:mypackage', {}) == 'cookiecutter-pypackage:mypackage'
    assert expand_abbreviations('local:', {'local': '.'}) == '.'
    assert expand_abbreviations('local:mypackage', {'local': '.'}) == 'mypackage'
    assert expand_abbreviations('local:mypackage', {'local': '/home/user'}) == '/home/user/mypackage'

# Generated at 2022-06-23 16:29:39.051182
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git',
    }

    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:', abbreviations) == 'https://github.com/{}.git'

# Generated at 2022-06-23 16:29:49.479766
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        "git@github.com/audreyr/cookiecutter-pypackage.git",
        {
            "cc-pypackage": "git@github.com/audreyr/cookiecutter-pypackage.git"
        },
    ) == "git@github.com/audreyr/cookiecutter-pypackage.git"
    assert expand_abbreviations(
        "audreyr/cookiecutter-pypackage",
        {
            "gh": "https://github.com/{}",
            "gh-repo": "https://github.com/{}",
        },
    ) == "https://github.com/audreyr/cookiecutter-pypackage"

# Generated at 2022-06-23 16:29:57.236926
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify that is_repo_url returns True for each part of the URL regex."""
    REPO_TESTS = [
        'git://',
        'git+git://',
        'git+ssh://',
        'git+file://',
        'git+https://',
        'git+git://',
        'git@',
        'git://github.com/audreyr/cookiecutter-pypackage.git',
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'ssh://git@github.com/audreyr/cookiecutter-pypackage.git',
        'file://localhost/home/foo/p/cookiecutter-pypackage.git',
    ]


# Generated at 2022-06-23 16:30:09.255601
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:30:17.551451
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test cases for function is_repo_url."""
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:30:23.473696
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Determine if `repo_directory` contains a `cookiecutter.json` file.
    :param repo_directory: The candidate repository directory.
    :return: True if the `repo_directory` is valid, else False.
    """
    assert (
        repository_has_cookiecutter_json("/Users/PulgaVieira/repository")
        == True
    )



# Generated at 2022-06-23 16:30:25.824358
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import utils
    assert repository_has_cookiecutter_json(utils.find_template('.')) == True


# Generated at 2022-06-23 16:30:34.184545
# Unit test for function is_zip_file
def test_is_zip_file():
    """
    Test the function is_zip_file
    """
    assert is_zip_file('template.zip') is True
    assert is_zip_file('template.ZIP') is True
    assert is_zip_file('template.ziP') is True
    assert is_zip_file('template.ZiP') is True
    assert is_zip_file('template.zIP') is True
    assert is_zip_file('template.ZIP') is True
    assert is_zip_file('template.ZIP') is True
    assert is_zip_file('template.ZIP') is True
    assert is_zip_file('template.ZIP') is True
    assert is_zip_file('template.ZIP') is True
    assert is_zip_file('template.tar.gz') is False
    assert is_zip_

# Generated at 2022-06-23 16:30:39.791425
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///Users/foo/bar')
    assert is_repo_url('foo@bar:baz/qux')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+ssh://hg@bitbucket.org/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:30:49.208773
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """ Test that abbreviations are expanded properly
    """
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'test': 'https://github.com/{}/testrepo.git',
    }

    assert 'https://github.com/user/repo.git' == expand_abbreviations(
        'gh:user/repo', abbreviations
    )
    assert 'https://github.com/user/repo.git' == expand_abbreviations(
        'https://github.com/user/repo.git', abbreviations
    )

# Generated at 2022-06-23 16:30:51.836395
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('ms_test')
    assert not is_repo_url('../local_test/')

# Generated at 2022-06-23 16:30:58.488429
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip')
    assert not is_zip_file('abc.ZIP')
    assert not is_zip_file('/home/user/abc.zip')
    assert not is_zip_file('/home/user/abc')
    assert not is_zip_file('//home/user/abc')
    assert not is_zip_file('abc.json')
    assert not is_zip_file('abc.json.zip')
    assert not is_zip_file('abc')

# Generated at 2022-06-23 16:31:06.928866
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify expected output for a variety of input values."""

# Generated at 2022-06-23 16:31:09.269330
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("../tests/fake-repo-pre/{{cookiecutter.repo_name}}") == True
    assert repository_has_cookiecutter_json("../tests/fake-repo-pre") == True
    assert repository_has_cookiecutter_json("../tests/fake-repo-pre/something") == False

# Generated at 2022-06-23 16:31:11.646349
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('dummy.zip')
    assert not is_zip_file('dummy.zip1')
    assert not is_zip_file('dummy')

# Generated at 2022-06-23 16:31:21.470775
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter.git')
    assert is_repo_url('hg@bitbucket.org/audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('ssh://hg@bitbucket.org/audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://bitbucket.org/pokoli/cookiecutter-tryton')
    assert is_repo_url('file://localhost/home/audreyr/cookiecutter/some-repo-name')

    # Invalid URIs

# Generated at 2022-06-23 16:31:30.046029
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'gitlab': 'https://gitlab.com/{}',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                 abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bb:pokoli/cookiecutter-skeleton',
                                 abbreviations) == 'https://bitbucket.org/pokoli/cookiecutter-skeleton'

# Generated at 2022-06-23 16:31:36.767197
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = "gh:audreyr/cookiecutter-pypackage"
    expected = "https://github.com/audreyr/cookiecutter-pypackage.git"
    result = expand_abbreviations(template, abbreviations)
    assert result == expected
    template = "bb:audreyr/cookiecutter-pypackage"
    expected = "https://bitbucket.org/audreyr/cookiecutter-pypackage.git"
    result = expand_abbreviations(template, abbreviations)
    assert result == expected
    template = "audreyr/cookiecutter-pypackage"


# Generated at 2022-06-23 16:31:44.622994
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    test_abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git'
    }

    assert expand_abbreviations('cc', test_abbreviations) == 'cc'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                test_abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:31:48.539873
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_dir = "../tests/files/fake-repo-tmpl"
    result = repository_has_cookiecutter_json(test_dir)
    assert result == True, "Function should return True for a valid repo directory"

# Generated at 2022-06-23 16:31:52.788646
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('something.zip') == True
    assert is_zip_file('something.tar.gz') == False
    assert is_zip_file('something.tar.bz2') == False
    assert is_zip_file('something.tar') == False
    assert is_zip_file('something.exe') == False
    assert is_zip_file('.') == False

# Generated at 2022-06-23 16:32:02.657342
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'm': 'https://github.com/mohitsharma44/{}.git',
        'k': 'https://github.com/kennethreitz/{}.git'
    }

    assert expand_abbreviations('m:cookiecutter-pypackage',
                                abbreviations) == 'https://github.com/mohitsharma44/cookiecutter-pypackage.git'
    assert expand_abbreviations('k:cookiecutter-pypackage',
                                abbreviations) == 'https://github.com/kennethreitz/cookiecutter-pypackage.git'
    assert expand_abbreviations('didnotwork',
                                abbreviations) == 'didnotwork'

# Generated at 2022-06-23 16:32:06.554508
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('.')



# Generated at 2022-06-23 16:32:15.822611
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gd': 'https://gitlab.com/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gd:pycqa/flake8', abbreviations) == 'https://gitlab.com/pycqa/flake8.git'
    assert expand_abbreviations('bb:pycqa/flake8', abbreviations) == 'https://bitbucket.org/pycqa/flake8.git'
    assert expand_abbrevi

# Generated at 2022-06-23 16:32:21.703203
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    assert expand_abbreviations(
        template="gh:audreyr/cookiecutter-pypackage",
        abbreviations=abbreviations
    ) == "https://github.com/audreyr/cookiecutter-pypackage.git"

    assert expand_abbreviations(
        template="gh:audreyr/cookiecutter-pypackage:develop",
        abbreviations=abbreviations
    ) == "https://github.com/audreyr/cookiecutter-pypackage:develop.git"


# Generated at 2022-06-23 16:32:33.520294
# Unit test for function is_repo_url
def test_is_repo_url():
    """What I've done here is to test that is_repo_url matches the

    REPO_REGEX
    """

    # Test for git://, git+git://, git+ssh:// and git+https://
    m = REPO_REGEX.match('git://github.com/nvie/cookiecutter')
    assert m is not None
    m = REPO_REGEX.match('git+git://github.com/nvie/cookiecutter')
    assert m is not None
    m = REPO_REGEX.match('git+ssh://github.com/nvie/cookiecutter')
    assert m is not None
    m = REPO_REGEX.match('git+https://github.com/nvie/cookiecutter')
    assert m is not None

    # Test for http://, https:// and ssh://


# Generated at 2022-06-23 16:32:40.069065
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.config import DEFAULT_CONFIG

    template = 'git@github.com:audreyr/cookiecutter-pypackage-minimal.git'
    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=DEFAULT_CONFIG['abbreviations'],
        clone_to_dir='/tmp/',
        checkout='master',
        no_input=False,
        password=None,
    )
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage-minimal.git'
    assert repo_dir.endswith(repo_url[repo_url.rfind('/') + 1 :])

# Generated at 2022-06-23 16:32:47.389215
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test functions to determine if the directory has a cookiecutter.json file

    :return: True if the function succeeds, else False
    """
    assert not repository_has_cookiecutter_json('/tmp')
    assert not repository_has_cookiecutter_json('/tmp/whatever')
    assert not repository_has_cookiecutter_json('/tmp/whatever/thing')
    assert not repository_has_cookiecutter_json('/tmp/whatever/thing/cookiecutter.json/')

    assert repository_has_cookiecutter_json('/tmp/whatever/thing/cookiecutter.json')

# Generated at 2022-06-23 16:32:55.035188
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbs = {'boo': 'http://path/to/boo/{0}', 'hoo': 'http://path/to/hoo'}
    assert 'http://path/to/boo/bar' == expand_abbreviations('boo:bar', abbs)
    assert 'http://path/to/boo/bar' == expand_abbreviations('http://path/to/boo/bar', abbs)
    assert 'http://path/to/boo/bar' == expand_abbreviations('hoo/bar', abbs)

# Generated at 2022-06-23 16:33:03.396078
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('cookiecutter-pypackage') == False
    assert is_repo_url('/Users/audreyr/projects/cookiecutter-pypackage') == False


# Generated at 2022-06-23 16:33:12.000333
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test if a value is a zip file or not"""
    testfiles = ['test.zip', 'test.ZIP', 'test.Zip', 'test.zIP']
    testfiles2 = ['test.tar', 'test.aar', 'test.rar', 'test.ar', 'test.xz']
    for obj in testfiles:
        assert(is_zip_file(obj)==True)
    for obj in testfiles2:
        assert(is_zip_file(obj)==False)


# Generated at 2022-06-23 16:33:21.763541
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Expand abbreviations in a template name."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'bb:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
