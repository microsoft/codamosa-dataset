

# Generated at 2022-06-23 16:23:24.582040
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gh-tar': 'https://github.com/{}/archive/master.tar.gz',
        'gh-zip': 'https://github.com/{}/archive/master.zip',
        'gl': 'git@gitlab.com:{}.git',
        'local': '/home/username/repos/{}'
    }
    assert expand_abbreviations('ja', abbreviations) == 'ja'
    assert expand_abbreviations('gh:ja', abbreviations) == 'https://github.com/ja.git'
    assert expand_abbreviations('local:ja', abbreviations) == '/home/username/repos/ja'


# Generated at 2022-06-23 16:23:35.448964
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(template="my-repo", abbreviations={},
                              clone_to_dir='/tmp', checkout=None, no_input=True, password=None,
                              directory=None) == ('/tmp/my-repo', False)
    assert determine_repo_dir(template="my-repo", abbreviations={},
                              clone_to_dir='/tmp', checkout=None, no_input=True, password=None,
                              directory="subdir") == ('/tmp/my-repo/subdir', False)

# Generated at 2022-06-23 16:23:41.444472
# Unit test for function expand_abbreviations

# Generated at 2022-06-23 16:23:44.726830
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') == True
    assert is_zip_file('.zip') == False
    assert is_zip_file('.zip') == False



# Generated at 2022-06-23 16:23:49.018183
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Expand abbreviations"""
    abbreviations = {'org_name': 'python-cookiecutter-{}'}
    template = 'example'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'python-cookiecutter-example'


# Generated at 2022-06-23 16:23:57.200122
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the is_repo_url function"""
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')


# Generated at 2022-06-23 16:24:05.058483
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    # Location of this file
    this_file = os.path.abspath(__file__)
    # Location of the tests directory
    test_dir = os.path.dirname(this_file)
    # Location of the test directory parent
    test_parent_dir = os.path.dirname(test_dir)

    # Both of these locations contain valid cookiecutter.json
    assert repository_has_cookiecutter_json(test_dir)
    assert repository_has_cookiecutter_json(test_parent_dir)

# Generated at 2022-06-23 16:24:13.604355
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:24:21.474674
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    expected = {
        'owner/repo': 'owner/repo',
        'gh:owner/repo': 'https://github.com/owner/repo.git',
        'bb:owner/repo': 'https://bitbucket.org/owner/repo.git',
    }

    for key in expected:
        actual = expand_abbreviations(key, abbreviations)
        assert actual == expected[key]

# Generated at 2022-06-23 16:24:22.554251
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('.')

# Generated at 2022-06-23 16:24:25.770538
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('{{cookiecutter.repo_name}}/tests') == True
    assert repository_has_cookiecutter_json('{{cookiecutter.repo_name}}/tests/test_repo_has_cookiecutter_json') == False


# Generated at 2022-06-23 16:24:28.215837
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    print(determine_repo_dir(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        {},
        '',
        '',
        True
    ))

# Generated at 2022-06-23 16:24:37.579200
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'gh'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations(template, abbreviations) == 'https://github.com/gh.git'

    abbreviations = {'gh': 'https://github.com/{}'}
    template = 'gh:owner/repo'
    assert expand_abbreviations(template, abbreviations) == 'https://github.com/owner/repo'


# Generated at 2022-06-23 16:24:45.335089
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test for function is_repo_url
    """
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/cookiecutter-tryton')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/home/docs/cookiecutters/pypackage')

# Generated at 2022-06-23 16:24:57.781085
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from tempfile import TemporaryDirectory
    from cookiecutter.config import DEFAULT_CONFIG

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = os.path.join(tmp_dir, 'repo')
        os.makedirs(tmp_dir)
        os.makedirs(os.path.join(tmp_dir, DEFAULT_CONFIG['replay_dir']))
        os.makedirs(os.path.join(tmp_dir, DEFAULT_CONFIG['hooks_dir']))
        os.makedirs(os.path.join(tmp_dir, DEFAULT_CONFIG['context_file']))

        assert not repository_has_cookiecutter_json(tmp_dir)


# Generated at 2022-06-23 16:25:05.167009
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter import config
    from cookiecutter import utils
    from cookiecutter.exceptions import RepositoryNotFound

    curr_dir = os.getcwd()

    # Test template as local path
    test_dir1 = os.path.abspath(os.path.dirname(__file__))
    repo_dir1, cleanup1 = determine_repo_dir(
        template=test_dir1,
        abbreviations={},
        clone_to_dir=curr_dir,
        checkout=None,
        no_input=False,
    )
    assert repo_dir1 == test_dir1
    assert cleanup1 is False
    assert repository_has_cookiecutter_json(repo_dir1)

    # Test template as local path joined with clone_to_dir

# Generated at 2022-06-23 16:25:15.413675
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghe': 'https://{}@github.com/audreyr/cookiecutter-pypackage.git',
    }

    template = 'gh:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'bb:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-23 16:25:20.412518
# Unit test for function is_zip_file
def test_is_zip_file():
    """ Test is_zip_file function. """
    assert is_zip_file('abc.zip') == True
    assert is_zip_file('abc.tar.gz') == False
    assert is_zip_file('abc.ZIP') == True
    assert is_zip_file('abc') == False
    assert is_zip_file('abc.ZiP.tar') == False


# Generated at 2022-06-23 16:25:31.685798
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True

# Generated at 2022-06-23 16:25:39.364298
# Unit test for function is_zip_file
def test_is_zip_file():
    value1 = 'C:\\Users\\Desktop\\templates\\cookiecutter-pypackage\\'
    value2 = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    value3 = 'https://github.com/audreyr/cookiecutter-pypackage'
    value4 = 'C:\\Users\\Desktop\\templates\\cookiecutter-pypackage.zip'
    value5 = 'C:\\Users\\Desktop\\templates\\cookiecutter-pypackage.exe'
    assert(is_zip_file(value1) == False)
    assert(is_zip_file(value2) == False)
    assert(is_zip_file(value3) == False)
    assert(is_zip_file(value4) == True)
   

# Generated at 2022-06-23 16:25:50.392277
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Verify the function works for the expected inputs
    """
    assert is_repo_url("git+https://github.com/tothebeat/cookiecutter-pypackage.git") == True
    assert is_repo_url("git@github.com:tothebeat/cookiecutter-pypackage.git") == True
    assert is_repo_url("https://github.com/tothebeat/cookiecutter-pypackage.git") == True
    assert is_repo_url("git://github.com/tothebeat/cookiecutter-pypackage.git") == True
    assert is_repo_url("https://github.com/tothebeat/cookiecutter-pypackage/archive/master.zip") == True

# Generated at 2022-06-23 16:25:59.625733
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test if the abbreviations dictionary is expanded properly."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}'
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                abbreviations) == \
           'https://github.com/audreyr/cookiecutter-pypackage'

    assert expand_abbreviations('gh:cookiecutter-pypackage',
                                abbreviations) == \
           'https://github.com/cookiecutter-pypackage'


# Generated at 2022-06-23 16:26:06.779779
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the `repository_has_cookiecutter_json` function."""
    # Create a temporary directory to use
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # A non-existent directory should not contain a cookiecutter.json file
    assert (
        repository_has_cookiecutter_json(os.path.join(temp_dir, 'no_such_dir'))
        is False
    )

    # An empty directory should not contain a cookiecutter.json file
    os.mkdir(os.path.join(temp_dir, 'empty_dir'))
    assert (
        repository_has_cookiecutter_json(os.path.join(temp_dir, 'empty_dir'))
        is False
    )

    # A directory containing a cookiecutter.json file should be

# Generated at 2022-06-23 16:26:17.458633
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Tests for function expand_abbreviations"""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'plain': 'path/to/{}',
    }

    # Test for github repo
    template = 'gh:audreyr/cookiecutter-pypackage'
    actual_template = \
        expand_abbreviations(template, abbreviations)
    expected_template = \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert actual_template == expected_template

    # Test for github repo with user in path
    template = 'gh:brosner/cookiecutter-django'
    actual_template = \
        expand_ab

# Generated at 2022-06-23 16:26:22.008900
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-pypackage.zip')
    assert is_zip_file('cookiecutter-pypackage-master.zip')
    assert not is_zip_file('cookiecutter-pypackage.zip.zip')
    assert is_zip_file('kkeeter-cookiecutter-pypackage.zip')

# Generated at 2022-06-23 16:26:28.439061
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import cookiecutter

    # Test: cloned repository
    repo_dir, cleanup = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir=cookiecutter.DEFAULT_CLONE_DIR,
        checkout=None,
        no_input=False,
    )
    assert '/cookiecutter-pypackage' in repo_dir
    assert cleanup == False

    # Test: local repository

# Generated at 2022-06-23 16:26:39.518563
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'foobar': 'https://github.com/audreyr/cookiecutter-pypackage.git',
    }
    clone_to_dir = '.'
    checkout = None
    no_input = None
    password = None
    directory = None

    template = 'foobar'
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir
    assert cleanup == False

    template = os.path.join('tests', 'test-repo-tmpl')

# Generated at 2022-06-23 16:26:40.763587
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') == True

# Generated at 2022-06-23 16:26:45.195938
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template_name = 'foobar'
    abbreviations = {'foo': 'bar'}
    assert expand_abbreviations(template_name, abbreviations) == template_name
    abbreviations = {'foo': 'bar', 'foobar': '{}'}
    assert expand_abbreviations(template_name, abbreviations) == ''
    template_name = 'foo:bar'
    assert expand_abbreviations(template_name, abbreviations) == 'bar'

# Generated at 2022-06-23 16:26:48.472036
# Unit test for function is_zip_file
def test_is_zip_file():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    iszip = is_zip_file(template)
    assert (iszip == False)


# Generated at 2022-06-23 16:26:56.784551
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.repository.abbreviations import REPO_ABBREVIATIONS

    for repo, abb in REPO_ABBREVIATIONS.items():
        #print "Template =", abb
        repo_dir, cleanup = determine_repo_dir(template=abb,
                                               abbreviations=REPO_ABBREVIATIONS,
                                               clone_to_dir=".",
                                               checkout=None,
                                               no_input=True)
        assert repo_dir.endswith(repo + "/")
        #print "Repo dir =", repo_dir
        #print "Cleanup =", cleanup
        assert cleanup is False

# Generated at 2022-06-23 16:27:06.318523
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    ''' This tests for our determine_repo_dir. There's a similar test for
    our cookiecutter.cli.main.main function.
    '''
    # First, we make sure we can give it something that exists
    repo_dir, should_cleanup = determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/tmp/',
        checkout='master',
        no_input=True,
    )
    assert repo_dir.startswith('/tmp/cookiecutter-pypackage')
    # Do we need to clean up this dir?
    assert should_cleanup is False
    # Now, how about something that isn't what we need?
    # TODO: this might be

# Generated at 2022-06-23 16:27:15.745922
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('/path/to/file.zip')
    assert is_zip_file('C:\\path\\to\\file.zip')
    assert not is_zip_file('file.txt')
    assert not is_zip_file('file.zip.ext')
    assert not is_zip_file('/path/to/file.txt')
    assert not is_zip_file('C:\\path\\to\\file.txt')
    assert not is_zip_file('C:\\path\\to\\file')
    assert not is_zip_file('\\path\\to\\file')

# Generated at 2022-06-23 16:27:25.929832
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbr = {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}',
    }

    assert is_repo_url(
        'gh:audreyr/cookiecutter-pypackage'
    ) == True

    assert is_repo_url(
        'git@github.com:cookiecutter/cookiecutter-pypackage.git'
    ) == True

    assert is_repo_url(
        'https://github.com/cookiecutter/cookiecutter-pypackage.git'
    ) == True

    assert is_repo_url(
        'cookiecutter-pypackage'
    ) == False


# Generated at 2022-06-23 16:27:27.562040
# Unit test for function is_zip_file
def test_is_zip_file():
    file_name = 'abc.zip'
    assert is_zip_file(file_name) == True


# Generated at 2022-06-23 16:27:40.087913
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify that the function is successfully matching legitimate repo URLs."""
    print("testing is_repo_url")
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git+https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git+ssh://git@github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")

# Generated at 2022-06-23 16:27:46.597343
# Unit test for function is_repo_url
def test_is_repo_url():
    """Ensure is_repo_url function works properly."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pydanny/cookiecutter-djangopackage')
    assert is_repo_url('https://github.com/pydanny/cookiecutter-djangopackage.git')
    assert is_repo_url('ssh://hg@bitbucket.org/pydanny/cookiecutter-djangopackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-23 16:27:49.583526
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test.zip")
    assert not is_zip_file("test")



# Generated at 2022-06-23 16:27:59.059666
# Unit test for function is_zip_file
def test_is_zip_file():
    test_cases = [
        ('http://some-url/some-directory/some-zip-file.zip', True),
        ('http://some-url/some-directory/some-zip-file.tar.gz', False),
        ('https://some-url/some-directory/some-zip-file.zip', True),
        ('git@some-url/some-directory/some-zip-file.zip', True),
        ('file://some-url/some-directory/some-zip-file.zip', True),
        ('some-directory/some-zip-file.zip', True),
        ('some-directory/some-tar-file.tar.gz', False),
    ]
    for test in test_cases:
        assert is_zip_file(test[0]) == test[1]

# Generated at 2022-06-23 16:28:09.106829
# Unit test for function is_repo_url

# Generated at 2022-06-23 16:28:12.111062
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert isinstance(determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory), tuple)

# Generated at 2022-06-23 16:28:16.684838
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'

# Generated at 2022-06-23 16:28:20.219979
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("my_file.zip")
    assert not is_zip_file("my_file.zip.zip")
    assert not is_zip_file("not_a_zip")

# Generated at 2022-06-23 16:28:29.100026
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from pathlib import Path
    from .extra_context import ROOT_DIR
    from .extra_context import REPOSITORY_PATH
    from .extra_context import REPOSITORY_URL
    from .extra_context import REPOSITORY_CLONE_TO_DIR
    test_path = Path(ROOT_DIR, 'random_dir')
    assert repository_has_cookiecutter_json(REPOSITORY_PATH) == True
    assert repository_has_cookiecutter_json(REPOSITORY_URL) == False
    assert repository_has_cookiecutter_json(REPOSITORY_CLONE_TO_DIR) == False
    assert repository_has_cookiecutter_json(str(test_path)) == False
    test_path.mkdir()

# Generated at 2022-06-23 16:28:34.747358
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = "owner/repo"
    abbreviations = {
        'bitbucket': 'https://bitbucket.org/{}.git',
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }
    correct_output = "https://github.com/owner/repo.git"
    output = expand_abbreviations(template, abbreviations)
    assert output == correct_output

# Generated at 2022-06-23 16:28:44.764432
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/wdzajicek/cookiecutter-openstack-ml2') is True
    assert is_repo_url('http://github.com/wdzajicek/cookiecutter-openstack-ml2') is True
    assert is_repo_url('file:///opt/cust_templates/openstack-ml2') is True
    assert is_repo_url('git+https://github.com/wdzajicek/cookiecutter-openstack-ml2') is True
    assert is_repo_url('git@github.com:wdzajicek/cookiecutter-openstack-ml2') is True
    assert is_repo_url('openstack-ml2') is False


# Generated at 2022-06-23 16:28:50.994718
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test cases for determine_repo_dir()"""
    template = 'https://github.com/Test/Test_Repo.git'
    abbreviations = {'test': 'https://github.com/Test/Test_Repo.git'}
    clone_to_dir = '/tmp/Test_Repo'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '/tmp/Test_Repo/Test_Repo'
    assert cleanup == False

    template = 'test'

# Generated at 2022-06-23 16:28:58.133055
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    actual = expand_abbreviations(template, abbreviations)
    assert actual == expected

# Generated at 2022-06-23 16:29:02.176999
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Bare template name
    template = "version1"
    abbreviations = {'v': 'version'}
    assert expand_abbreviations(template, abbreviations) == template

    # Template name preceded by abbreviation
    template = "v:version1"
    abbreviations = {'v': 'version'}
    assert expand_abbreviations(template, abbreviations) == 'version:version1'

    # Template name with orphaned abbreviation
    template = "v:version1"
    abbreviations = {'vv': 'version'}
    assert expand_abbreviations(template, abbreviations) == template

    # Longer template name with orphaned abbreviation
    template = "vv:version1"
    abbreviations = {'v': 'version'}
    assert expand_abbreviations(template, abbreviations) == template

# Generated at 2022-06-23 16:29:14.055524
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
    }
    template = "audreyr/cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == \
        "https://github.com/{}.git".format(template)
    template = "cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == \
        "https://github.com/{}.git".format(template)
    template = "gh:cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == \
        "https://github.com/{}.git".format("cookiecutter-pypackage")

# Generated at 2022-06-23 16:29:24.107257
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file_1 = 'https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master'
    zip_file_2 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_file_3 = '~/my_templates/cookiecutter-pypackage-master.zip'
    zip_file_4 = 'cookiecutter-pypackage-master.zip'

    assert is_zip_file(zip_file_1)
    assert is_zip_file(zip_file_2)
    assert is_zip_file(zip_file_3)
    assert is_zip_file(zip_file_4)

# Generated at 2022-06-23 16:29:30.556438
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Tests determine_repo_dir from the repo_dir.py module.
    """
    from cookiecutter.main import cookiecutter
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    checkout = None
    no_input = True
    clone_to_dir = None
    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=True,
    )
    cookiecutter(
        repo_dir=repo_dir,
        cleanup_repo=cleanup,
        overwrite_if_exists=True,
    )

# Generated at 2022-06-23 16:29:35.912180
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json."""
    # Test for valid directory with cookiecutter.json
    repo = repository_has_cookiecutter_json(
        'tests/foobar-test-repo/fake-repo-tmpl')
    assert repo is True

    # Test for directory without cookiecutter.json
    repo = repository_has_cookiecutter_json('tests/')
    assert repo is False

# Generated at 2022-06-23 16:29:45.256519
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function test_is_zip_file."""
    assert (
        is_zip_file("https://github.com/audreyr/cookiecutter-pypackage.git")
        is False
    )
    assert (
        is_zip_file(
            "https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master"
        )
        is True
    )
    assert (
        is_zip_file(
            "https://codeload.github.com/audreyr/cookiecutter-pypackage/tar.gz/master"
        )
        is True
    )

# Generated at 2022-06-23 16:29:54.919120
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir"""
    import shutil

    temp_dir = '~/temp-repo'
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    template = 'cookiecutter-pypackage'
    repo_dir, should_cleanup = determine_repo_dir(
        template=template,
        abbreviations={},
        clone_to_dir=temp_dir,
        checkout=None,
        no_input=False,
    )
    assert repo_dir.endswith(template)
    assert not should_cleanup

    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)


# Generated at 2022-06-23 16:30:07.367014
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://{}',
        'bb': 'https://bitbucket.org/{}',
        'gl': 'https://gitlab.com/{}',
    }


# Generated at 2022-06-23 16:30:10.731876
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/fake-repo-pre/")
    assert not repository_has_cookiecutter_json("tests/fake-repo-post/")

# Generated at 2022-06-23 16:30:18.126644
# Unit test for function determine_repo_dir

# Generated at 2022-06-23 16:30:27.566744
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile

    # Create an example valid repository
    temp_dir = tempfile.mkdtemp()
    config_file = open(os.path.join(temp_dir, 'cookiecutter.json'), 'w')
    config_file.close()

    # Create an example invalid repository (no config file)
    invalid_repo_dir = tempfile.mkdtemp()

    assert repository_has_cookiecutter_json(temp_dir)
    assert not repository_has_cookiecutter_json(invalid_repo_dir)

    # Cleanup
    os.remove(config_file.name)
    os.rmdir(temp_dir)
    os.rmdir(invalid_repo_dir)

# Generated at 2022-06-23 16:30:30.193514
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = "gh"
    abbreviations = {
        'gh': 'https://github.com/{}.git'
    }
    assert expand_abbreviations(template, abbreviations) == 'https://github.com/{}.git'

# Generated at 2022-06-23 16:30:34.255746
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') is True
    assert is_zip_file('foo.ZIP') is True
    assert is_zip_file('bar/foo.zip') is True
    assert is_zip_file('.zip') is True

    assert is_zip_file('foo') is False
    assert is_zip_file('bar/foo.py') is False

# Generated at 2022-06-23 16:30:45.083109
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test function expand_abbreviations."""
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {}) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bitbucket:audreyr/cookiecutter-pypackage', {}) == 'https://bitbucket.com/audreyr/cookiecutter-pypackage.git'

    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-23 16:30:49.126782
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "gh": "https://github.com/{}.git",
    }
    assert expand_abbreviations("gh:audreyr/cookiecutter", abbreviations) == "https://github.com/audreyr/cookiecutter.git"
    assert expand_abbreviations("https://github.com/audreyr/cookiecutter.git", abbreviations) == "https://github.com/audreyr/cookiecutter.git"

# Generated at 2022-06-23 16:30:52.808952
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/kennethreitz/sampleproject.git') == True
    assert is_repo_url('git+https://github.com/kennethreitz/sampleproject.git') == True

# Generated at 2022-06-23 16:30:56.123492
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from tests.test_utils import TESTS_DIR

    # test valid repo
    assert repository_has_cookiecutter_json(TESTS_DIR)

    # test invalid repo
    assert not repository_has_cookiecutter_json('/tmp')

# Generated at 2022-06-23 16:30:58.541524
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = './tests/test-repo/'
    assert repository_has_cookiecutter_json(repo_directory) == True

# Generated at 2022-06-23 16:31:06.951806
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }

    assert expand_abbreviations('.', abbreviations) == '.'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage.git',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:31:08.600819
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert not is_zip_file('test.tar.gz')
    assert not is_zip_file('test')
    assert not is_zip_file('test/test')


# Generated at 2022-06-23 16:31:18.171072
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test function is_repo_url
    """
    assert is_repo_url("git+https://github.com/yyyy/xxxx.git")
    assert not is_repo_url("git+https:/github.com/yyyy/xxxx.git")
    assert not is_repo_url("git+/github.com/yyyy/xxxx.git")
    assert is_repo_url("git@github.com:yyyy/xxxx.git")
    assert not is_repo_url("git@github.com:yyyy/xxxx.git/")
    assert is_repo_url("git@github.com:yyyy/xxxx.git/test")
    assert is_repo_url("https://github.com/yyyy/xxxx.git")

# Generated at 2022-06-23 16:31:20.983109
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    #assert repository_has_cookiecutter_json(some_repo_dir)
    assert repository_has_cookiecutter_json('/tmp/cookiecutter-repo-template')

# Generated at 2022-06-23 16:31:29.642678
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test of determine_repo_dir()"""

    # Unit tests for determine_repo_dir()
    template = 'foo'
    abbreviations = {}

    clone_to_dir = ''
    checkout = ''
    no_input = False
    password = ''

    assert determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, password, no_input)

# Generated at 2022-06-23 16:31:34.436618
# Unit test for function expand_abbreviations
def test_expand_abbreviations():

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                {"gh": "https://github.com/{}"}) == \
        "https://github.com/audreyr/cookiecutter-pypackage"
    assert expand_abbreviations('cookiecutter-pypackage',
                                {"gh": "https://github.com/{}"}) == \
        "cookiecutter-pypackage"

# Generated at 2022-06-23 16:31:46.100592
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the execution of the function determine_repo_dir.
    """
    git_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}',
    }
    checkout = None
    clone_to_dir = '/Users/audreyr/cookiecutters/'
    no_input = True
    password = None

    template = 'gh:audreyr/cookiecutter-pypackage'
    directory = 'tests/fake-repo-pre/'

# Generated at 2022-06-23 16:31:55.070580
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Verify that determine_repo_dir returns the right template directory."""
    import tempfile
    import shutil


# Generated at 2022-06-23 16:32:03.485887
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the function is_repo_url."""
    assert(is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('hg+https://bitbucket.org/pokoli/python-project-template'))
    assert(is_repo_url('git://github.com/wdm0006/cookiecutter-django-crud.git'))

# Generated at 2022-06-23 16:32:13.635550
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the repository_has_cookiecutter_json function."""
    fake_repo_directory = '/fake/repo/directory'
    fake_repo_cookiecutter_json_file = '/fake/repo/directory/cookiecutter.json'

    # Should be False as the directory does not exist and therefore there is no
    # cookiecutter.json file.
    assert not repository_has_cookiecutter_json(fake_repo_directory)

    # Create fake file
    with open(fake_repo_cookiecutter_json_file, 'w') as fake_repo_json_file:
        fake_repo_json_file.write('{ }')

    # Should be True now that a cookiecutter.json file is present

# Generated at 2022-06-23 16:32:20.627791
# Unit test for function expand_abbreviations
def test_expand_abbreviations():

    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git', "`gh` should be expanded."
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git', "`bb` should be expanded."
    assert expand_abbreviations('bb', abbreviations) == 'bb', "a non matching abbreviation shouldn't be expanded."
    assert expand_abbre

# Generated at 2022-06-23 16:32:26.518810
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/zipball/master') == True
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/blob/master/README.rst') == False

# Generated at 2022-06-23 16:32:29.934200
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('hello/somthing/my.zip')
    assert not is_zip_file('hello/somthing/my.tar.gz')
    assert not is_zip_file('hello/somthing/my.zipgz')

# Generated at 2022-06-23 16:32:38.525489
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from pytest import raises
    from cookiecutter import config
    from cookiecutter import repo
    from .text import is_url_regex

    cfg = config.get_config()

    # Test: Full https URL
    repo_dir = repo.determine_repo_dir(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations=cfg['abbreviations'],
        clone_to_dir=os.path.expanduser('~/.cookiecutters'),
        checkout=None,
        no_input=True,
        directory=None,
    )
    assert 'cookiecutter-pypackage' in repo_dir

    # Test: git://

# Generated at 2022-06-23 16:32:43.032358
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'my-org': 'https://github.com/my-org/cookiecutter-my-repo',
    }
    template = 'my-org:my-repo:v0.0.1'
    clone_to_dir = 'cookiecutter-test'
    checkout = 'v0.0.1'
    no_input = True
    password = None
    directory = None
    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory) == ('cookiecutter-test/my-repo:v0.0.1', True)


# Generated at 2022-06-23 16:32:50.765685
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test for a valid repo url
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage.git') == False
    # Test for an invalid repo url
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage') == False
    assert is_repo_url('/home/user/cookiecutter-pypackage') == False
    assert is_repo_url('/tmp/cc_tmpx6p_bd') == False
    assert is_repo_url('cookiecutter-pypackage') == False

# Generated at 2022-06-23 16:32:59.133169
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test that we can instantiate the repo dir for a template reference."""
    import tempfile
    from cookiecutter.prompt import read_user_yes_no

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone_to_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:33:07.175301
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test if repo-dir exists but cookiecutter.json not present
    repo_dir = 'tests/fixtures/fake-repo'
    assert repository_has_cookiecutter_json(repo_dir) is False

    # Test if repo-dir does not exist
    repo_dir = 'tests/fixtures/non-existing-dir'
    assert repository_has_cookiecutter_json(repo_dir) is False

    # Test if repo-dir exists and cookiecutter.json is present
    repo_dir = 'tests/fixtures/fake-repo-tmpl'
    assert repository_has_cookiecutter_json(repo_dir) is True

# Generated at 2022-06-23 16:33:07.772269
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    os.stat()

# Generated at 2022-06-23 16:33:19.303995
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('GIT+SSH://github.com/audreyr/cookiecutter-pypackage.git')