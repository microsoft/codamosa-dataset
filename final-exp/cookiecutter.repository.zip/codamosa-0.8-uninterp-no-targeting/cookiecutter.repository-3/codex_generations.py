

# Generated at 2022-06-21 10:53:02.341096
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:atlassianlabs/cookiecutter-bitbucket-pipelines.git')
    assert is_repo_url('bitbucket.org:atlassianlabs/cookiecutter-bitbucket-pipelines.git')
   

# Generated at 2022-06-21 10:53:14.238237
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:53:23.135476
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import logging
    import shutil
    import tempfile

    from cookiecutter.utils import rmtree

    logger = logging.getLogger(__name__)

    logger.debug('Making temporary directory')
    temp_dir = tempfile.mkdtemp()
    cleanup_dirs = [temp_dir]

    logger.debug('Making a temporary `cookiecutter.json`')
    cookiecutter_json = os.path.join(temp_dir, 'cookiecutter.json')
    open(cookiecutter_json, 'a').close()

    assert repository_has_cookiecutter_json(temp_dir)

    logger.debug('Making a temporary `fake.json`')
    fake_json = os.path.join(temp_dir, 'fake.json')
    open(fake_json, 'a').close()

   

# Generated at 2022-06-21 10:53:32.913779
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
    }
    clone_to_dir = 'C:\\Users\\name\\path'
    checkout = 'master'
    no_input = True
    password = 'password'
    directory = 'directory'

    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("audreyr/cookiecutter-pypackage") == False
    assert is_zip_file("test.zip") == True

# Generated at 2022-06-21 10:53:39.230755
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-foobar.zip') == True
    assert is_zip_file('../cookiecutter-foobar.zip') == True
    assert is_zip_file('cookiecutter-foobar.ZIP') == True
    assert is_zip_file('cookiecutter-foobar.tar.gz') == False
    assert is_zip_file('http://localhost/cookiecutter-foobar.zip') == True

# Generated at 2022-06-21 10:53:47.206015
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test if abbreviation works"""
    test_abbreviations = {'abbrev': 'https://github.com/{}.git'}
    assert expand_abbreviations('abbrev:foo', test_abbreviations) == 'https://github.com/foo.git'
    assert expand_abbreviations('foo', test_abbreviations) == 'foo'
    assert expand_abbreviations('abbrev:', test_abbreviations) == 'https://github.com/.git' # pylint: disable=line-too-long

# Generated at 2022-06-21 10:53:53.641210
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}

    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 10:53:57.979693
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    assert repository_has_cookiecutter_json(temp_dir) == False

    import touch
    touch.touch(os.path.join(temp_dir, 'cookiecutter.json'))
    assert repository_has_cookiecutter_json(temp_dir) == True

# Generated at 2022-06-21 10:54:05.827373
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') is True

# Generated at 2022-06-21 10:54:16.217901
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'db': 'django-project-template:postgresql',
                     'cb': 'https://github.com/nvie/cookiecutter-flask'}

    assert expand_abbreviations('db', abbreviations) == 'django-project-template:postgresql'
    assert expand_abbreviations('cb', abbreviations) == 'https://github.com/nvie/cookiecutter-flask'
    assert expand_abbreviations('db:my_project', abbreviations) == 'django-project-template:postgresql:my_project'
    assert expand_abbreviations('db:', abbreviations) == 'django-project-template:postgresql:'
    assert expand_abbreviations('db:', abbreviations) == 'django-project-template:postgresql:'


# Generated at 2022-06-21 10:54:21.593952
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('home/cc/myzip.zip')==True
    assert is_zip_file('home/cc/myzip.tar')==False

# Generated at 2022-06-21 10:54:34.767231
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test regular git URLs
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')

    # Test git+ssh URLs
    assert is_repo_url('git+ssh://git@github.com/audreyr/cookiecutter-pypackage.git')

    # Test zip files
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git/archive/master.zip')

    # Test local paths

# Generated at 2022-06-21 10:54:43.844680
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function
    """
    from behave import given, when, then, step
    from behave import use_fixture, use_step_matcher, given, when, then

    from assertpy import assert_that
    from cookiecutter.config import DEFAULT_ABBREVIATIONS, DEFAULT_CONFIG

    from config_helpers import get_validated_config_from_string

    use_step_matcher("re")


    @given('a template name')
    def template_name(context):
        """
        A template name
        """
        context.template = 'foo'


# Generated at 2022-06-21 10:54:52.446201
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if path contains cookiecutter.json"""
    assert repository_has_cookiecutter_json("/dev/null") == False
    # Here we test that Cookiecutter finds cookiecutter.json in its own directory
    # when run from the top level of the repo
    example_path = os.path.join(os.path.dirname(__file__),
                                "..",
                                "tests",
                                "test-repo-pre",
                                "cookiecutter.json")
    assert repository_has_cookiecutter_json(example_path) == True

# Generated at 2022-06-21 10:55:02.962807
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {
        'gh': 'https://github.com/{0}.git'
    }) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations('git@github.com:audreyr/cookiecutter-pypackage',
                                {'git@github.com': 'https://github.com/{0}'}) \
        == 'https://github.com/audreyr/cookiecutter-pypackage'


# Generated at 2022-06-21 10:55:14.591828
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///Users/audreyr/tests/fake-repo-pre/')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git#egg=cookiecutter')
    assert is_repo_url('git@bitbucket.org:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:55:21.647239
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Testing determine_repo_dir() using a fake repo

    :raises: `RepositoryNotFound` if the fake repo is wrongly loaded
    """
    template = 'fake_repo'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    checkout = 'master'
    no_input = True
    clone_to_dir = 'tests/fake_repo'
    directory = 'tests/fake_repo/fake_repo_subfolder'
    repo, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout,
                                       no_input, directory=directory)
    assert repo == directory

# Generated at 2022-06-21 10:55:32.274170
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                    abbreviations)
    assert template == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    template = expand_abbreviations('bb:audreyr/cookiecutter-pypackage',
                                    abbreviations)
    assert template == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    template = expand_abbreviations('audreyr/cookiecutter-pypackage',
                                    abbreviations)

# Generated at 2022-06-21 10:55:35.732587
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected_expanded_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    expanded_template = expand_abbreviations(template, abbreviations)
    assert expected_expanded_template == expanded_template

# Generated at 2022-06-21 10:55:41.489933
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test for function repository_has_cookiecutter_json.

    test repository_has_cookiecutter_json with wrong directory name
    (should be False)
    """
    repos = 'wrongdirectory'
    expected = False
    actual = repository_has_cookiecutter_json(repos)
    assert actual == expected


# Generated at 2022-06-21 10:55:53.974218
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/terryyin/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}'}
    clone_to_dir = 'random_dir'
    checkout = ''
    no_input = True
    password = ''

    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
    )
    print("repo_dir", repo_dir)
    print("cleanup", cleanup)

# Generated at 2022-06-21 10:56:03.667631
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('file:///home/robin/pickled-cucumber')
    assert is_repo_url('/home/robin/pickled-cucumber')
    assert is_repo_url('C:\\home\robin\pickled-cucumber')
    assert is_repo_url('sftp://myserver.com/pickled-cucumber')

# Generated at 2022-06-21 10:56:12.793536
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""

    # Case 1: invalid template
    template = 'xyz'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = '~'
    no_input = False
    checkout = None

    try:
        determine_repo_dir(
            template,
            abbreviations,
            clone_to_dir,
            checkout,
            no_input)
    except RepositoryNotFound:
        pass

    # Case 2: valid template
    template = 'gh:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 10:56:21.779737
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'
    }

    assert expand_abbreviations('/path/to/my/repo', abbreviations) == '/path/to/my/repo'
    assert expand_abbreviations('gh:test/test', abbreviations) == 'https://github.com/test/test.git'
    assert expand_abbreviations('bb:test/test', abbreviations) == 'https://bitbucket.org/test/test.git'

# Generated at 2022-06-21 10:56:31.680547
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test various cases of determining repository directory.
    """
    # test with valid repository
    # mock repository url
    url_template = 'https://github.com/wdm0006/cookiecutter-pypackage.git'
    # mock clone_to directory
    clone_to_dir = '.'
    # checkout branch
    checkout = None
    # no_input
    no_input = False
    # password
    password = None
    # directory
    directory = None
    repodir, clean = determine_repo_dir(
        url_template, {}, clone_to_dir, checkout, no_input, password, directory)
    assert 'cookiecutter-pypackage' in repodir
    assert clean == False

# Generated at 2022-06-21 10:56:40.633977
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_cookiecutter_json = "tests/test-repo-tmpl/cookiecutter.json"
    test_fake_json_directory = "/home/fake_user/fake_repo"
    cookiecutter_json_directory = "tests/test-repo-tmpl"
    assert repository_has_cookiecutter_json(test_cookiecutter_json) is False
    assert repository_has_cookiecutter_json(test_fake_json_directory) is False
    assert repository_has_cookiecutter_json(cookiecutter_json_directory)


# Generated at 2022-06-21 10:56:45.569250
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = './test_dir'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    # Test function and test exception
    try:
        determine_repo_dir(template, abbreviations, clone_to_dir,
                           checkout, no_input, password, directory)
    except RepositoryNotFound as e:
        print(e)

    # Test function and print result
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir,
                                           checkout, no_input, password, directory)
    print(repo_dir)
    print(cleanup)

# Generated at 2022-06-21 10:56:54.068059
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@bitbucket.org:pokoli/cookiecutter-tryton.git')
    assert is_repo_url('git@bitbucket.org:pokoli/cookiecutter-tryton')
    assert is_repo_url('https://github.com/pokoli/cookiecutter-tryton')

# Generated at 2022-06-21 10:56:59.008598
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
	abbreviations = {'pypackage': 'https://github.com/audreyr/cookiecutter-pypackage'}
	assert expand_abbreviations("pypackage", abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage"


# Generated at 2022-06-21 10:57:11.241935
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Assert True for test_determine_repo_dir."""

# Generated at 2022-06-21 10:57:23.443492
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter import config
    template = "https://github.com/wsu-cuny/cookiecutter-odsc-tutorial.git"
    abbreviations = config.get_user_config()['abbreviations']
    clone_to_dir = "."
    checkout = None
    no_input = True
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=None,
        directory=directory,
    )
    assert(repo_dir == "cookiecutter-odsc-tutorial")
    assert(cleanup == False)

# Generated at 2022-06-21 10:57:27.879505
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('cookiecutter-pypackage')


# Generated at 2022-06-21 10:57:38.267279
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # if directory is a non-existing repo
    fake_repo = '/this/is/a/fake/repository'
    assert not repository_has_cookiecutter_json(fake_repo)

    # zipfile
    '''
    import zipfile
    zipped_dir_1 = 'tests/test-data/fake-repo-1.zip'
    zipfile.ZipFile(zipped_dir_1, 'w')
    fake_repo = 'tests/test-data/fake-repo-1.zip'
    assert not repository_has_cookiecutter_json(fake_repo)
    '''

    # if directory is a repo without cookiecutter.json
    fake_repo = 'tests/test-data/fake-repo-1/'
    assert not repository_has_cookiecutter

# Generated at 2022-06-21 10:57:49.535011
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil
    from cookiecutter import main, utils
    from cookiecutter import vcs
    from cookiecutter import zipfile

    # Setup
    project_dir = 'fake-project'
    fake_repo_dir = os.path.join(project_dir, 'fake-repo')
    fake_repo_config = os.path.join(project_dir, 'cookiecutter.json')
    fake_repo_url = 'https://github.com/audreyr/cookiecutter-pypackage-minimal.git'
    fake_zip_file = os.path.join(
        project_dir,
        'cookiecutter-pypackage-minimal-master-cookiedozer.zip'
    )

# Generated at 2022-06-21 10:57:57.317362
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # ZIP
    unzipped_dir = unzip(
        zip_uri="users/audreyr/cookiecutters/cookiecutter-pypackage",
        is_url=False,
        clone_to_dir="/home/user/code/cookiecutters",
        no_input=True,
        password="1234",
    )
    assert unzipped_dir == "/home/user/code/cookiecutters/cookiecutter-pypackage"

    # Repository URL
    cloned_repo = clone(
        repo_url="https://github.com/audreyr/cookiecutter-pypackage.git",
        checkout="develop",
        clone_to_dir="/home/user/code/cookiecutters",
        no_input=True,
    )

# Generated at 2022-06-21 10:58:07.256140
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test is_repo_url to ensure it correctly identifies repo urls."""

# Generated at 2022-06-21 10:58:12.954648
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that the function repository_has_cookiecutter_json properly returns
       True / False."""

    assert repository_has_cookiecutter_json('tests/test-repo-tmpl2')
    assert not repository_has_cookiecutter_json('tests/test-repo-tmpl-bad1')
    assert not repository_has_cookiecutter_json('tests/test-repo-tmpl')

# Generated at 2022-06-21 10:58:18.065470
# Unit test for function is_zip_file
def test_is_zip_file():
    """Unit test of function is_zip_file"""
    #pylint: disable=C0103
    assert is_zip_file("file.zip")
    assert is_zip_file("file.ZIP")
    assert not is_zip_file("file.txt")
    assert not is_zip_file("/path/to/file.zip")


# Generated at 2022-06-21 10:58:27.077702
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    '''
    Ensure that the repository_has_cookiecutter_json function
    works as expected
    '''
    from cookiecutter import main, utils
    from unittest import mock
    from cookiecutter.config import get_user_config

    mock_context_file = os.path.join(utils.get_project_root(), 'tests', 'fake-repo-pre/cookiecutter.json')

    config_dict = get_user_config()
    config_dict['replay_dir'] = os.path.join(utils.get_project_root(), 'tests', 'fake-repo-pre/')

    # Test that the existing directory is valid
    template = 'tests/fake-repo-pre/'

# Generated at 2022-06-21 10:58:33.870012
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbr = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh', abbr) == 'https://github.com/{}.git'
    assert expand_abbreviations('gh:', abbr) == 'https://github.com/{}.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter', abbr) == 'https://github.com/audreyr/cookiecutter.git'

# Generated at 2022-06-21 10:58:45.523829
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # TODO: This unit test only covers a few cases. Write more tests and
    # specifically test the exceptions raised when the template is not
    # found.
    clone_to_dir = os.path.join(
        os.path.expanduser('~'),
        'testing-cookiecutter-abbreviations',
    )
    os.makedirs(clone_to_dir, exist_ok=True)

    expected_path = os.path.join(
        clone_to_dir,
        'python_boilerplate',
    )

    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }


# Generated at 2022-06-21 10:58:57.926361
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('GIT@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url

# Generated at 2022-06-21 10:59:02.019412
# Unit test for function is_repo_url
def test_is_repo_url():
    test_url = 'git://github.com/foo/bar.git'
    test_not_url = 'foo/bar.git'
    assert is_repo_url(test_url) == True
    assert is_repo_url(test_not_url) == False

# Generated at 2022-06-21 10:59:10.547523
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """test repository_has_cookiecutter_json function."""
    test_directory = 'test'

    assert not repository_has_cookiecutter_json(test_directory)

    # Create directory
    os.mkdir(test_directory)
    assert not repository_has_cookiecutter_json(test_directory)

    # Create empty file
    with open(os.path.join(test_directory, 'cookiecutter.json'), 'a'):
        os.utime(os.path.join(test_directory, 'cookiecutter.json'), None)
        assert repository_has_cookiecutter_json(test_directory)

    # Delete 'cookiecutter.json' file and directory
    os.remove(os.path.join(test_directory, 'cookiecutter.json'))

# Generated at 2022-06-21 10:59:22.764930
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-django.zip') == True
    assert is_zip_file('/home/bob/cookiecutter-django.zip') == True
    assert is_zip_file('some/random/path/to/cookiecutter-django.zip') == True
    assert is_zip_file('some/random/path/to/cookiecutter-django.zip/') == False
    assert is_zip_file('./cookiecutter-django.zip') == True
    assert is_zip_file('./cookiecutter-django.zip/') == False
    assert is_zip_file('http://example.com/cookiecutter-django.zip') == True

# Generated at 2022-06-21 10:59:30.962359
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Ensure that the function determine_repo_dir works as expected."""
    from .prompt import normalize_repo_var

    template = 'username/repo'
    abbreviations = {'gh': 'https://github.com/{}'}
    clone_to_dir = '/tmp'

    actual_repo, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        'master',
        False,
        None,
        None,
    )
    expected_repo = normalize_repo_var(
        'https://github.com/username/repo'
    )
    assert actual_repo == expected_repo



# Generated at 2022-06-21 10:59:38.254353
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert(determine_repo_dir("https://github.com/aclements/pypackage.git", None, "/tmp/cc-test", "master", True, None, None) == ("/tmp/cc-test/pypackage", False))
    assert(determine_repo_dir("https://github.com/aclements/pypackage.git", None, "/tmp/cc-test", "master", True, None, "abc") == ("/tmp/cc-test/pypackage/abc", False))
    assert(determine_repo_dir("https://github.com/aclements/pypackage.git#master", None, "/tmp/cc-test", "master", True, None, None) == ("/tmp/cc-test/pypackage", False))

    # Ensure that local

# Generated at 2022-06-21 10:59:43.432964
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_project_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'test-project.tmpl'
    )
    assert repository_has_cookiecutter_json(test_project_dir) == True
    assert repository_has_cookiecutter_json('fake_path') == False
    assert repository_has_cookiecutter_json('') == False

# Generated at 2022-06-21 10:59:51.906894
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test that determine_repo_dir() works as expected
    """
    # No repo_dir given
    repo_dir, cleanup = determine_repo_dir(
        template=None,
        abbreviations={},
        clone_to_dir=os.getcwd(),
        checkout='master',
        no_input=False,
        password=None
    )

    assert repo_dir is None
    assert cleanup is None

    # No repo_dir given
    repo_dir, cleanup = determine_repo_dir(
        template=None,
        abbreviations={},
        clone_to_dir=os.getcwd(),
        checkout='master',
        no_input=False,
        password=None
    )

    assert repo_dir is None
    assert cleanup is None

    # A repo_dir is given


# Generated at 2022-06-21 10:59:54.049017
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Ensure that a cookiecutter.json file is present."""
    directory = os.path.dirname(os.path.abspath(__file__))
    assert repository_has_cookiecutter_json(directory)

# Generated at 2022-06-21 11:00:05.178628
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "cc": "https://github.com/{}.git",
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
    }
    assert expand_abbreviations("cc:foobar/foobar", abbreviations) == "https://github.com/foobar/foobar.git"
    assert expand_abbreviations("cc:foobar/foobar/", abbreviations) == "https://github.com/foobar/foobar/{}"
    assert expand_abbreviations("bb:foobar/foobar", abbreviations) == "https://bitbucket.org/foobar/foobar.git"
    assert expand_abbreviations("foobar/foobar", abbreviations) == "foobar/foobar"

# Generated at 2022-06-21 11:00:15.231085
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil
    from cookiecutter.utils import rmtree
    from cookiecutter import config
    from cookiecutter import vcs

    repo_url = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = config.DEFAULT_ABBREVIATIONS

    cookiecutters_dir = 'cookiecutters'
    clone_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', cookiecutters_dir))
    try:
        shutil.rmtree(clone_dir)
    except OSError as e:
        print(e)
    try:
        os.makedirs(clone_dir)
    except OSError as e:
        print(e)



# Generated at 2022-06-21 11:00:16.821045
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == template

# Generated at 2022-06-21 11:00:23.632333
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test whether URIs are found to be repository URIs."""

# Generated at 2022-06-21 11:00:30.739235
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Unittest for function is_repo_url
    """
    assert is_repo_url("http://github.com/myproject")
    assert is_repo_url("https://github.com/myproject")
    assert is_repo_url("git@github.com:myproject")
    assert is_repo_url("file:///home/user/projects/myproject")

    assert not is_repo_url("/home/user/projects/myproject")
    assert not is_repo_url("myproject")
    assert not is_repo_url("")


# Generated at 2022-06-21 11:00:35.080620
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json"""
    tdir = os.path.join(os.getcwd(), 'test')
    expected_true = web_project(tdir)
    assert repository_has_cookiecutter_json(expected_true) is True
    expected_false = os.path.join(expected_true, 'invalid')
    assert repository_has_cookiecutter_json(expected_false) is False



# Generated at 2022-06-21 11:00:40.679358
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/Users/Ana/Exports/cookiecutter-pytest-plugin") == True
    assert repository_has_cookiecutter_json("/Users/Ana/Exports/cookiecutter-pytest-plugin/") == True
    assert repository_has_cookiecutter_json("/Users/Ana/Exports/cookiecutter-pytest-plugin//") == False
    assert repository_has_cookiecutter_json("/Users//Ana/Exports/cookiecutter-pytest-plugin") == False

# Generated at 2022-06-21 11:00:47.526460
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    test_abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'foo': 'https://github.com/cookiecutter/{}.git'
    }

    # Test expansion of abbreviations
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                test_abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage',
                                test_abbreviations) == \
        'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'



# Generated at 2022-06-21 11:00:56.848016
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json.

    Check that:
        * A valid directory with a valid config file, will return true
        * An invalid directory with a valid config file, will return false
        * An invalid directory with an invalid config file, will return false
        * A valid directory with an invalid config file, will return false
    """
    # Define valid and invalid directory paths
    valid_dir = os.path.abspath("cookiecutter")
    invalid_dir = os.path.abspath("this_dir_does_not_exist")
    # Assert that a valid directory with a valid config file returns true
    assert repository_has_cookiecutter_json(valid_dir)
    # Assert that an invalid directory with a valid config file returns false

# Generated at 2022-06-21 11:01:00.012999
# Unit test for function is_zip_file
def test_is_zip_file():
    template_name = 'repository.zip'
    assert is_zip_file(template_name) == True

# Generated at 2022-06-21 11:01:10.146943
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('git@github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('~/dev/github.com/audreyr/cookiecutter-pypackage.git') == False
    assert is_repo_

# Generated at 2022-06-21 11:01:16.733269
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    true_dir = os.path.join('tests', 'fake-repo-pre', 'fake-repo')
    assert repository_has_cookiecutter_json(true_dir) == True
    false_dir = os.path.join('tests', 'fake-repo-pre', 'fake-repo', 'missing-files')
    assert repository_has_cookiecutter_json(false_dir) == False

# Generated at 2022-06-21 11:01:26.626402
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:', abbreviations) == 'https://github.com/{}.git'
    assert expand_abbreviations('gh', abbreviations) == 'https://github.com/{}.git'
    assert expand_abbreviations(':audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 11:01:34.637894
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check that repository_has_cookiecutter_json returns True for valid repository."""
    test_dir = os.path.dirname(os.path.abspath(__file__))
    assert repository_has_cookiecutter_json(test_dir) == True

    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(os.path.split(os.path.split(test_dir)[0])[0],"tests","test-repo-tmpl")
    assert repository_has_cookiecutter_json(test_dir) == True

    test_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-21 11:01:46.190730
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghu': 'https://{}@github.com/{}.git',
    }
    expanded_template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    expanded_template = expand_abbreviations('ghu:pydanny/cookiecutter-django', abbreviations)
    assert expanded_template == 'https://pydanny@github.com/cookiecutter-django.git'

# Generated at 2022-06-21 11:01:54.636739
# Unit test for function is_repo_url

# Generated at 2022-06-21 11:02:07.452607
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git', 'bb': 'https://bitbucket.org/{}.git'}
    assert expand_abbreviations('user/repo', abbreviations) == 'user/repo'
    assert expand_abbreviations('gh:user/repo', abbreviations) == 'https://github.com/user/repo.git'
    assert expand_abbreviations('bb:user/repo', abbreviations) == 'https://bitbucket.org/user/repo.git'
    assert expand_abbreviations('gh:', abbreviations) == 'https://github.com/.git'
    assert expand_abbreviations('bb:', abbreviations) == 'https://bitbucket.org/.git'

# Generated at 2022-06-21 11:02:12.270520
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(template="https://github.com/audreyr/cookiecutter-pypackage.git",
        abbreviations={},
        clone_to_dir=".",
        checkout="",
        no_input=False,
        password=None,
        directory=None) == (
            'cookiecutter-pypackage', False)

    assert determine_repo_dir(template="my-first-cookiecutter",
        abbreviations={"my-first-cookiecutter": "https://github.com/audreyr/cookiecutter-pypackage.git"},
        clone_to_dir=".",
        checkout="",
        no_input=False,
        password=None,
        directory=None) == (
            'cookiecutter-pypackage', False)

    assert determine_

# Generated at 2022-06-21 11:02:18.468376
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_dir1 = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
    assert repository_has_cookiecutter_json(repo_dir1)==False # directory exists, but json file not present
    repo_dir2 = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
    assert repository_has_cookiecutter_json(repo_dir2)==False # both json file and the directory do not exist

# Generated at 2022-06-21 11:02:22.351788
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for repository_has_cookiecutter_json"""
    assert repository_has_cookiecutter_json('./tests/fake-repo-tmpl') == True

# Generated at 2022-06-21 11:02:32.735895
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {"gh":"https://github.com/{0}"}
    template = 'gh:audreyr/cookiecutter-pypackage'
    clone_to_dir = r'c:\temp'
    checkout = 'master'
    no_input = True
    password = 'password'
    is_arbitrary_local_execution = '\cookiecutter' in os.getcwd()
    if is_arbitrary_local_execution:
        directory = 'tests\test-extend'
    else:
        directory = 'tests/test-extend'
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-21 11:02:41.901921
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('ponys/pinkie-pie.zip') == True
    assert is_zip_file('mane/twilight-sparkle.zip') == True
    assert is_zip_file('twilight-sparkle.zip') == True
    assert is_zip_file('fluttershy.zip') == True

    assert is_zip_file('ponys/pinkie-pie.tar.gz') == False
    assert is_zip_file('mane/twilight-sparkle.tar.xz') == False
    assert is_zip_file('twilight-sparkle.tar.bz2') == False
    assert is_zip_file('fluttershy.tar.bz2') == False

# Generated at 2022-06-21 11:02:45.114737
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/home/user/test-repo/") == False
    assert repository_has_cookiecutter_json("/home/user/test-repo/vscode-extension") == True

# Generated at 2022-06-21 11:02:47.641440
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_repo = 'tests/test-repo'
    assert repository_has_cookiecutter_json(test_repo) is True

# Generated at 2022-06-21 11:02:57.715991
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Ensure that repository_has_cookiecutter_json behaves as expected."""
    test_dir = os.path.abspath(os.path.dirname(__file__))
    cookiecutter_json = os.path.join(
        os.path.normcase(test_dir),
        '..',
        'tests',
        'fake-repo-pre',
        'cookiecutter.json',
    )

    if not os.path.exists(cookiecutter_json):
        try:
            import pytest
        except ImportError:
            raise ValueError(
                (
                    'pytest must be installed to run unit tests. '
                    '`pip install pytest`'
                )
            )
        pytest.fail('No cookiecutter.json in fake-repo-pre')
