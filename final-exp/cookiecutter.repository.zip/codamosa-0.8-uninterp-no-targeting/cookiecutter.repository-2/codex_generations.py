

# Generated at 2022-06-21 10:53:00.066296
# Unit test for function is_zip_file
def test_is_zip_file():
    uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    if is_zip_file(uri):
        print('Zip file test passed')
    else:
        print('Zip file test failed')


# Generated at 2022-06-21 10:53:11.751524
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test a valid repository URL
    template = 'git@github.com:jacebrowning/cookiecutter-flask-pypackage.git'
    assert is_repo_url(template)
    repo_dir = determine_repo_dir(
        template=template,
        clone_to_dir='/tmp/cookiecutters/',
        abbreviations={},
        checkout='master',
        no_input=True,
    )
    assert repo_dir is not None
    assert not repo_dir[1]

    # Test a directory containing the template
    template = '.../cookiecutter-flask-pypackage'
    assert not is_repo_url(template)

# Generated at 2022-06-21 10:53:21.870022
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if repository_has_cookiecutter_json works correctly."""
    assert not repository_has_cookiecutter_json('/Users/me/work/')
    assert not repository_has_cookiecutter_json('/Users/me/work/cookiecutter-foobar')
    assert repository_has_cookiecutter_json('/Users/me/work/cookiecutter-foobar/')
    assert repository_has_cookiecutter_json('/Users/me/work/cookiecutter-foobar/foo')
    assert repository_has_cookiecutter_json('/Users/me/work/cookiecutter-foobar/foo/')
    assert not repository_has_cookiecutter_json('/Users/me/work/cookiecutter-foobar/foo/bar')
    assert not repository_has_cooki

# Generated at 2022-06-21 10:53:25.251330
# Unit test for function is_zip_file
def test_is_zip_file():
    """Return True if value is a zip file."""
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.tar.gz') == False

# Generated at 2022-06-21 10:53:32.800209
# Unit test for function is_zip_file
def test_is_zip_file():
    import pytest
    assert is_zip_file("test.zip")
    assert is_zip_file("test.ZIP")
    assert is_zip_file("./test/test.zip")
    assert not is_zip_file("./README.md")
    assert not is_zip_file("some-url")
    assert not is_zip_file("some-url/epics")
    assert not is_zip_file("os.path.join(scandir)")
    assert not is_zip_file(None)
    assert not is_zip_file("")
    assert not is_zip_file(1)

# Generated at 2022-06-21 10:53:44.417830
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template='test_template',
        abbreviations={'test_template': 'https://github.com/test/test_template'},
        clone_to_dir='test_dir',
        checkout='test_checkout',
        no_input=True,
        password='test_password',
        directory='test_directory',
    ) == ('test_dir/test_template', False)
    assert determine_repo_dir(
        template='test_template',
        abbreviations={'test_template': 'https://github.com/test/test_template'},
        clone_to_dir='',
        checkout='test_checkout',
        no_input=True,
        password='test_password',
        directory='test_directory',
    ) == ('test_template', False)

# Generated at 2022-06-21 10:53:49.342941
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('file.ZIP')
    assert is_zip_file('file.Zip')
    assert is_zip_file('file.zIp')
    assert not is_zip_file('file.zip2')
    assert not is_zip_file('file.zipp')

# Generated at 2022-06-21 10:53:56.287033
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Check if determine_repo_dir returns expected output."""
    repository_dir = determine_repo_dir(
        template="https://test.test/test.git",
        abbreviations={},
        clone_to_dir=".",
        checkout="master",
        no_input=True,
        password=None,
        directory=".",
    )
    assert repository_dir[0] == os.path.join(os.getcwd(), "test")

# Generated at 2022-06-21 10:53:59.382079
# Unit test for function is_zip_file
def test_is_zip_file():
    assert (is_zip_file('./tests/test-data/simple/simple.zip') == True)
    assert (is_zip_file('./tests/test-data/simple/simple') == False)
    assert (is_zip_file('./tests/test-data/simple/simple.jpeg') == False)

# Generated at 2022-06-21 10:54:05.867210
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # repo_directory exists and contains a cookiecutter.json
    repo_directory = os.path.join('tests','files','fake-repo-pre')
    assert repository_has_cookiecutter_json(repo_directory)

    # repo_directory exists and does not contain a cookiecutter.json
    repo_directory = os.path.join('tests','files','fake-repo-post')
    assert not repository_has_cookiecutter_json(repo_directory)

    # repo_directory does not exist
    repo_directory = os.path.join('tests','files','fake-repo-fake')
    assert not repository_has_cookiecutter_json(repo_directory)

# Generated at 2022-06-21 10:54:18.008545
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Verify that the is_repo_url function works as expected.
    """
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('foo')
    assert not is_repo_url('')

# Generated at 2022-06-21 10:54:31.240544
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:54:41.855905
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """raise repository not found with correct error message"""
    from cookiecutter.config import DEFAULT_ABBREVIATIONS
    from cookiecutter.repository import determine_repo_dir
    from cookiecutter.exceptions import RepositoryNotFound

    try:
        determine_repo_dir(
            template='',
            abbreviations=DEFAULT_ABBREVIATIONS,
            clone_to_dir='',
            checkout=None,
            no_input=False,
            password=None,
            directory=None
        )
    except RepositoryNotFound as e:
        assert e.args[0] == "A valid repository for "" could not be found in the following locations:\n"
    else:
        assert False, "Expected to raise RepositoryNotFound exception"

# Generated at 2022-06-21 10:54:45.456370
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test if a directory has a cookiecutter.json file.
    """
    repo_directory = 't/test-template-repo'

    assert repository_has_cookiecutter_json(repo_directory) == True

# Generated at 2022-06-21 10:54:55.368584
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('myfile.zip')
    assert is_zip_file('myfile.ZIP')
    assert is_zip_file('myfile.zIp')
    assert not is_zip_file('myfile.tar.gz')
    assert not is_zip_file('myfile.tar.bz2')
    assert not is_zip_file('myfile.tar')
    assert not is_zip_file('myfile.zip.txt')
    assert not is_zip_file('myfile.targz')
    assert not is_zip_file('myfile.txt')
    assert not is_zip_file('myfile.ZIP2')

# Generated at 2022-06-21 10:55:00.673898
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import pytest

    with pytest.raises(RepositoryNotFound) as e:
        determine_repo_dir(
            template='tests/fake-repo-tmpl',
            abbreviations={},
            clone_to_dir='/tmp',
            checkout=None,
            no_input=False,
        )
    assert e.type == RepositoryNotFound

# Generated at 2022-06-21 10:55:05.023913
# Unit test for function is_zip_file
def test_is_zip_file():
    test_values = [
        ('foo.zip', True),
        ('foo.ZIP', True),
        ('foo.bar.zip', True),
        ('foo.zip/bar', False),
        ('foo.bar/baz.zip', False),
        ('bar.json', False),
    ]

    for value, expected in test_values:
        yield check_is_zip_file, value, expected



# Generated at 2022-06-21 10:55:16.021142
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # Parameters
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {
        "audreyr": "https://github.com/audreyr/cookiecutter-pypackage",
        "gh": "https://github.com/{}",
        "bb": "https://bitbucket.org/{}",
    }
    clone_to_dir = "/tmp/machine_learning_project/"
    checkout = "master"
    no_input = True
    password = None
    directory = None

    # Call function
    repo_dir = determine_repo_dir(template,
                                  abbreviations,
                                  clone_to_dir,
                                  checkout,
                                  no_input,
                                  password,
                                  directory)

    # Check

# Generated at 2022-06-21 10:55:25.943737
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    For a given template of different formats, check the cloned directory
    and the cleanup flag.
    """
    abbreviations = {
        'gh': 'https://github.com/{}.git'
    }
    clone_to_dir = '/tmp/templates'
    checkout = 'release'
    no_input = True
    password = 'password'
    directory = 'dir'
    # vcs_dir
    template = 'gh:pydanny/cookiecutter-django'
    cloned_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )
   

# Generated at 2022-06-21 10:55:34.849916
# Unit test for function is_repo_url
def test_is_repo_url():
    r"""Test regex that is used to determine if a value is a repository URL."""

# Generated at 2022-06-21 10:55:40.264856
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/', 'tests/')

# Generated at 2022-06-21 10:55:47.496147
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghe': 'https://ghe.mycorp.com/{}.git',
    }
    assert expand_abbreviations('foo:bar', abbreviations) == 'foo:bar'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbrevi

# Generated at 2022-06-21 10:55:57.792075
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Asserts successful local repo path
    repo_dir_1, cleanup = determine_repo_dir(
        template='/User/name/projects/repo-dir',
        abbreviations=None,
        clone_to_dir=None,
        checkout=None,
        no_input=None,
        password=None,
        directory='.',
    )
    assert cleanup is False
    assert repo_dir_1 == '/User/name/projects/repo-dir'

    # Asserts successful zip file path

# Generated at 2022-06-21 10:56:09.451599
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'path': '/home/jace/repos/{}',
    }
    template = 'gh:myrepo'
    clone_to_dir = '/tmp/'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    # Note that for unittests we're using our own repo as a template
    # and not using the abbreviations from our regular cookiecutter.json
    # file.

    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory) == ('/tmp/myrepo', False)

    template = 'bb:myrepo'



# Generated at 2022-06-21 10:56:19.488888
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine repo dir function."""
    # Tests
    # Valid Git URL, no cookies
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir, cleanup = determine_repo_dir(
        template,
        {},
        '.',
        None,
        False,
        'secret',
    )
    assert repo_dir == './cookiecutter-pypackage'
    assert cleanup is False

    # Valid Git URL, no cookies, directory specified
    repo_dir, cleanup = determine_repo_dir(
        template,
        {},
        '.',
        None,
        False,
        'secret',
        'fake',
    )
    assert repo_dir == './cookiecutter-pypackage/fake'
   

# Generated at 2022-06-21 10:56:30.738091
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """ Unit test for function expand_abbreviations() """
    assert expand_abbreviations(".", {}) == "."
    assert expand_abbreviations(".", {".": "/tmp/foo"}) == "/tmp/foo"
    assert expand_abbreviations("foo", {".": "/tmp/foo"}) == "foo"
    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", {}) == "gh:audreyr/cookiecutter-pypackage"
    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", {"gh:": "https://github.com/{}"}) == "https://github.com/audreyr/cookiecutter-pypackage"

# Generated at 2022-06-21 10:56:42.685592
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    if __name__ == '__main__':
        print('\nUnit tests for functions in repo.py')
        print(determine_repo_dir('~/python/cookiecutter-pypackage', '', '', '', True)[0])
        print(determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage', '', '', '', True)[0])
        print(determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', '', '', '', True)[0])

# Generated at 2022-06-21 10:56:46.384324
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('./tests/test-repo-tmpl/') == True
    assert repository_has_cookiecutter_json('./tests/test-repo-tmpl/tests') == True
    assert repository_has_cookiecutter_json('./') == False

# Generated at 2022-06-21 10:56:48.204549
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for repository_has_cookiecutter_json function."""
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True

# Generated at 2022-06-21 10:56:58.957144
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Determine the repository directory and cleanup value.
    """
    template = expand_abbreviations('foo', {'foo': 'bar'})
    assert template == 'bar'

    template = expand_abbreviations('foo:bar', {'foo': 'baz{}'})
    assert template == 'baz:bar'

    assert is_repo_url('http://github.com/repo')

    assert not is_repo_url('/path/to/repo')

    assert is_zip_file('/path/to/repo.zip')

    assert not is_zip_file('/path/to/repo.tar')

    assert not is_zip_file('http://github.com/repo.tar')


# Generated at 2022-06-21 10:57:11.648075
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/Users/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('cookiecutter-pypackage')
    assert not is_repo_url('pypackage')

# Generated at 2022-06-21 10:57:18.730673
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the function ``repository_has_cookiecutter_json``."""
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    test_data_dir = os.path.join(temp_dir, 'test_data')
    os.mkdir(test_data_dir)
    os.mkdir(os.path.join(test_data_dir, 'empty_dir'))
    os.mkdir(os.path.join(test_data_dir, 'dir_with_config'))
    open(
        os.path.join(test_data_dir, 'dir_with_config', 'cookiecutter.json'),
        'a'
    ).close()

    assert repository_has_cookiecutter_json(test_data_dir) is True


# Generated at 2022-06-21 10:57:21.575001
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that repository_has_cookiecutter_json works."""
    assert repository_has_cookiecutter_json(repo_directory=None) is False


# Generated at 2022-06-21 10:57:31.006677
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = 'C:\tmp'
    checkout = 'master'
    no_input = 'True'
    password = ''
    directory = 'name/dir'

    # Test with abbreviations
    assert determine_repo_dir(
        template='gh:Org/repo',
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory
    ) == ('https://github.com/Org/repo.git', False)

    # Test with url

# Generated at 2022-06-21 10:57:41.051028
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test is_repo_url."""
    assert is_repo_url('file:///home/audreyr/cookiecutters/pypackage') is True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage.git') is True

    assert is_repo_url('http://') is False
    assert is_repo_url('https://') is False
    assert is_repo_url('not a url') is False

# Generated at 2022-06-21 10:57:52.108440
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit tests for function `is_repo_url`."""
    assert(is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('https://bitbucket.org/pokoli/cookiecutter-tryton'))
    assert(is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git'))

    assert(not is_repo_url('my_user/my_repo'))
    assert(not is_repo_url('../other_repo'))

# Generated at 2022-06-21 10:57:56.376676
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh:audreyr/cookiecutter-pypackage':
                     'https://github.com/audreyr/cookiecutter-pypackage.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == \
           'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-21 10:58:06.064838
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Arrange
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = "audreyr"
    checkout = "master"
    no_input = True
    password = None
    directory = None
    
    # Act
    repo_dir = determine_repo_dir(template,
                                  abbreviations,
                                  clone_to_dir,
                                  checkout,
                                  no_input,
                                  password,
                                  directory)

    # Assert
    assert repo_dir[0] == os.path.join(clone_to_dir, "cookiecutter-pypackage")
    assert repo_dir[1] == False

# Generated at 2022-06-21 10:58:14.966005
# Unit test for function is_zip_file
def test_is_zip_file():
    # test cases
    valid_zip_file = "test.zip"
    invalid_zip_file = "file.txt"
    valid_zip_file_uppercase = "TEST.ZIP"
    invalid_zip_file_uppercase = "FILE.TXT"

    assert is_zip_file(valid_zip_file) == True
    assert is_zip_file(invalid_zip_file) == False
    assert is_zip_file(valid_zip_file_uppercase) == True
    assert is_zip_file(invalid_zip_file_uppercase) == False

test_is_zip_file()

# Generated at 2022-06-21 10:58:24.710957
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter import config
    from shutil import rmtree
    from tempfile import mkdtemp
    from time import time
    from os import path
    from subprocess import check_call
    from cookiecutter.utils.paths import INVALID_PATH_CHARS

    my_config = config.get_user_config()

    temp_dir = mkdtemp()
    repo_dir = path.join(temp_dir, 'repo')
    cc_dir = path.join(repo_dir, 'cookiecutter.json')
    os.mkdir(repo_dir)

    with open(cc_dir, 'w') as f:
        f.write('{"foo":"bar"}')

    my_config['repository_dir'] = temp_dir


# Generated at 2022-06-21 10:58:41.494102
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import cookiecutter
    dict_abbreviations = {}
    dict_abbreviations['twbs/bootstrap'] = 'https://github.com/twbs/bootstrap.git'
    template = 'twbs/bootstrap'
    clone_to_dir = '.cookiecutters'
    checkout = '4.0.0-alpha.2'
    result = determine_repo_dir(
        template,
        dict_abbreviations,
        clone_to_dir,
        checkout,
        no_input=True)
    print(result)


# Generated at 2022-06-21 10:58:43.916417
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file = 'cookiecutter-pypackage.zip'
    assert is_zip_file(zip_file)
    assert not is_zip_file(zip_file.upper())
    assert not is_zip_file('cookiecutter-pypackage')
    assert not is_zip_file('cookiecutter-pypackage.rar')

# Generated at 2022-06-21 10:58:45.532255
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
       assert repository_has_cookiecutter_json('/home/matthew/cookiecutter-pypackage')

# Generated at 2022-06-21 10:58:57.926379
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Template_dir with cookiecutter.json will be repo_candidate1
    template_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-template-repo',
        'cookiecutter-test-template'
    )
    repo_candidate1 = os.path.join(template_dir, '{{cookiecutter.repo_name}}')

    # {{cookiecutter.repo_name}} template cloned to repo_candidate2
    repo_candidate2 = os.path.join(template_dir, '{{cookiecutter.repo_name}}')

    # Repo_dir to determine if it contains a cookiecutter.json file

# Generated at 2022-06-21 10:59:07.920642
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('a-relative-path')
    assert not is_repo_url('~/my-path/')
    assert is_repo_url(
        'file:///Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    )
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-21 10:59:14.776794
# Unit test for function is_zip_file
def test_is_zip_file():
    """Verify that is_zip_file returns True if value is a zip file."""
    assert is_zip_file('/foo/baz.zip') == True
    assert is_zip_file('/foo/baz.tar.gz') == False
    assert is_zip_file('https://github.com/foo/bar/baz.zip') == True
    assert is_zip_file('https://github.com/foo/bar/baz.tar.gz') == False

# Generated at 2022-06-21 10:59:26.627257
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the repository_has_cookiecutter_json function."""
    from .context_file import make_context_file

    # Verify that missing directory results in return of false
    dir_name = 'test_repo_does_not_exist'
    result = repository_has_cookiecutter_json(dir_name)
    assert result is False, "directory '{}' doesn't exist - is expected".format(dir_name)

    # Create a test repo directory
    dir_name = 'test_repo_exists'
    os.mkdir(dir_name)
    context_file = os.path.join(dir_name, 'cookiecutter.json') 

    # Verify that repo_directory is missing the context_file.
    result = repository_has_cookiecutter_json(dir_name)

# Generated at 2022-06-21 10:59:34.064406
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test the determine_repo_dir function.
    """
    template = "git@github.com:audreyr/cookiecutter-pypackage.git"
    clone_to_dir = "/tmp"
    checkout = "master"
    no_input = True
    password = "password"
    directory = "test"
    abbreviations = {
        "gh": "https://github.com/{}.git",
    }

    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

    assert repo_dir == "/tmp/cookiecutter-pypackage/test"
    assert cleanup == False

# Generated at 2022-06-21 10:59:39.379431
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the repository_has_cookiecutter_json function."""
    assert repository_has_cookiecutter_json(
        '/Users/audreyr/projects/cookiecutter-pypackage'
    )
    assert not repository_has_cookiecutter_json(
        '/Users/audreyr/projects/cookiecutter-pypackage/missing_file.txt'
    )



# Generated at 2022-06-21 10:59:46.863419
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = "/Users/Travis/travis-ci/build/audreyr/cookiecutter-pypackage"
    checkout = "master"
    no_input = True
    password = None
    directory = None

    test_repo = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, password, directory)

    assert isinstance(test_repo, tuple)
    assert os.path.isdir(test_repo[0])
    assert test_repo[1] == False

# Generated at 2022-06-21 11:00:13.810393
# Unit test for function is_repo_url
def test_is_repo_url():
    urls = [
        "git://github.com/audreyr/cookiecutter-pypackage.git",
        "https://github.com/audreyr/cookiecutter-pypackage.git",
        "https://github.com/audreyr/cookiecutter-pypackage",
        "git@github.com:audreyr/cookiecutter-pypackage.git",
        "audreyr/cookiecutter-pypackage",
        "../../other/repo/on/my/computer",
    ]

    for url in urls:
        assert is_repo_url(url) == True

# Generated at 2022-06-21 11:00:22.313612
# Unit test for function is_repo_url
def test_is_repo_url():
    pattern = REPO_REGEX
    
    # Test valid URLs
    assert(True == pattern.match('git@github.com:hlapp/cookiecutter-foo.git'))
    assert(True == pattern.match('https://github.com/hlapp/cookiecutter-boo.git'))
    assert(True == pattern.match('githttps://github.com/hlapp/cookiecutter-boo.git'))
    assert(True == pattern.match('git://github.com/hlapp/cookiecutter-boo.git'))
    assert(True == pattern.match('ssh://git@github.com/hlapp/cookiecutter-boo.git'))
    assert(True == pattern.match('file:///c:/myrepo/cookiecutter-boo.git'))

# Generated at 2022-06-21 11:00:31.350091
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    full_template_dir = os.path.join( os.path.dirname(os.path.realpath(__file__)), 'fake-repo-pre/')
    assert repository_has_cookiecutter_json( full_template_dir )

    full_template_dir = os.path.join( os.path.dirname(os.path.realpath(__file__)), 'fake-repo-pre')
    assert repository_has_cookiecutter_json( full_template_dir )

    fake_dir = os.path.join( os.path.dirname(os.path.realpath(__file__)), 'fake-repo-pre-fail/')
    assert not repository_has_cookiecutter_json( fake_dir )


# Generated at 2022-06-21 11:00:38.439169
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("hg+ssh://hg@bitbucket.org/barseghyanartur/cookiecutter-djangobaseproject") == True
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git#egg=cookiecutter-pypackage") == True

# Generated at 2022-06-21 11:00:44.456224
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():  # pragma: no cover
    
    # No cookiecutter.json file and no directory, should return false
    assert not repository_has_cookiecutter_json(
            './test/test_norepo')
    
    # No cookiecutter.json file and directory exists, should return false
    assert not repository_has_cookiecutter_json(
            './test/test_invalidrepo')
    
    # cookiecutter.json file exists and directory exists, should return true
    assert repository_has_cookiecutter_json(
            './test/test_validrepo')

# Generated at 2022-06-21 11:00:49.778363
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test function repository_has_cookiecutter_json"""
    import os
    import tempfile
    from cookiecutter.utils import rmtree
    # Create a temp dir
    temp_dir = tempfile.mkdtemp()

    # Create a temp repo with a cookiecutter.json file
    cookiecutter_contents = """
{\n"name": "Some Project Name"\n}
    """
    cookiecutter_path = os.path.join(temp_dir, 'cookiecutter.json')
    with open(cookiecutter_path, 'w') as f:
        f.write(cookiecutter_contents)

    # Verify that repository_has_cookiecutter_json
    # returns true when run on the dir with the cookiecutter.json file

# Generated at 2022-06-21 11:00:59.375055
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    test_abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gist': 'https://gist.github.com/{}.git',
    }

    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", test_abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"
    assert expand_abbreviations("audreyr/cookiecutter-pypackage", test_abbreviations) == "audreyr/cookiecutter-pypackage"

# Generated at 2022-06-21 11:01:08.289664
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test the repository_has_cookiecutter_json function.

    The function should return True if the `repo_directory` is valid.
    """
    # A directory containing a 'cookiecutter.json' file.
    repo_directory = 'tests/test-repo-tmpl'
    assert True == repository_has_cookiecutter_json(repo_directory) is True

    # An empty directory.
    repo_directory = 'tests/test-empty-repo'
    assert True == repository_has_cookiecutter_json(repo_directory) is False

    # A directory containing a 'non-cookiecutter.json' file.
    repo_directory = 'tests/test-non-cookiecutter-json'
    assert True == repository_has_cookiecutter_json(repo_directory) is False

# Generated at 2022-06-21 11:01:19.824133
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    template_dir = os.path.join(os.path.dirname(__file__), '../tests/fake-repo-tmpl')

    # First test that true is returned when the directory exists and
    # has a cookiecutter.json
    assert repository_has_cookiecutter_json(template_dir)

    # Next test that false is returned when directory exists and
    # does not have a cookiecutter.json
    no_cookiecutter_json_dir = os.path.join(os.path.dirname(__file__), '../tests/no-cookiecutter-json')
    assert not repository_has_cookiecutter_json(no_cookiecutter_json_dir)

    # Finally test that false is returned when directory does not exist

# Generated at 2022-06-21 11:01:30.230135
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter

    assert DEFAULT_CONFIG['cookiecutter']['abbreviations'] == {
        'gh': 'https://github.com/{}',
        'bb': 'https://bitbucket.org/{}',
        'gl': 'https://gitlab.com/{}',
    }

    # Repo that was abbreviated with a trailing slash
    # Should still work
    cookiecutter(
        'tests/test-repo-tmpl/',
        no_input=True,
        output_dir='test-test_determine_repo_dir',
    )

    # Add the following abbreviations to DEFAULT_CONFIG

# Generated at 2022-06-21 11:01:59.984335
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""

    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')



# Generated at 2022-06-21 11:02:04.582768
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert(determine_repo_dir("git@git@git@git@git@github.com:jacebrowning/template-python-pkg.git",{},"/","master",False,"password","directory")==(False))

# Generated at 2022-06-21 11:02:13.971111
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    # clone test git repositories
    from git import Repo
    from cookiecutter.main import cookiecutter

    repo_urls = [
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'https://github.com/audreyr/cookiecutter-pypackage-minimal.git',
        'https://github.com/audreyr/cookiecutter-pypackage-maximal.git',
    ]
    repo_test_dirs = []
    for repo_url in repo_urls:
        Repo.clone_from(repo_url, '.')
        repo_test_dirs.append("cookiecutter-" + repo_url.split("/")[-1][:-4])

    # create abbreviations for test git repositories

# Generated at 2022-06-21 11:02:25.088060
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test regex for determining a repository url."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url(
        'hg+https://bitbucket.org/pokoli/cookiecutter-trytonmodule'
    )
    assert is_repo_url(
        'file://home/dhellmann/Code/cookiecutter-pypackage'
    )

# Generated at 2022-06-21 11:02:27.800193
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip')
    assert is_zip_file('ZIP') is False
    assert is_zip_file('https://github.com/foo/bar') is False

# Generated at 2022-06-21 11:02:35.738117
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test for function `is_zip_file`."""
    assert not is_zip_file('a_file.txt')
    assert not is_zip_file('a_file')
    assert not is_zip_file('a_file.txt.zip')
    assert is_zip_file('a_file.zip')
    assert is_zip_file('/some/directory/a_file.zip')
    assert is_zip_file('a_file.ziP')
    assert is_zip_file('/some/directory/a_file.ziP')

# Generated at 2022-06-21 11:02:44.056279
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/user/repo') is True
    assert is_repo_url('hg+https://github.com/user/repo') is True
    assert is_repo_url('file:///some/repo') is True
    assert is_repo_url('git@github.com/user/repo.git') is True

    assert is_repo_url('https://github.com/user/repo') is False
    assert is_repo_url('https://github.com/user/repo.zip') is False
    assert is_repo_url('https://github.com/user/repo.zip#master') is False
    assert is_repo_url('~/local/repo') is False



# Generated at 2022-06-21 11:02:50.058629
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test that abbreviations are expanded correctly."""
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template_name = 'gh:audreyr/cookiecutter-pypackage'

    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    result = expand_abbreviations(template_name, abbreviations)

    assert result == expected

# Generated at 2022-06-21 11:02:57.567531
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """ Test function determine_repo_dir()"""

    template = 'git@github.com:wau/test.git'
    abbreviations = {}
    clone_to_dir = '~/temp'
    checkout = ''
    no_input = ''
    directory = ''
    repo_dir, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input, directory)
    
    print(repo_dir)
    print(cleanup)

if __name__ == '__main__':
    test_determine_repo_dir()