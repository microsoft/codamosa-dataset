

# Generated at 2022-06-21 10:53:02.123536
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    test_abbreviations = {'gh:audreyr/cookiecutter-pypackage': 'https://github.com/audreyr/cookiecutter-pypackage.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', test_abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage/', test_abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage/'

# Generated at 2022-06-21 10:53:14.014322
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test variations of GitHub url with .git suffix
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    # Test with non-standard ssh port
    assert is_repo_url('git@example.com:audreyr/cookiecutter-pypackage.git')
    # Test with https and without .git suffix
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    # Test with http and without .git suffix
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')
    # Test with git:// scheme

# Generated at 2022-06-21 10:53:18.537976
# Unit test for function is_repo_url
def test_is_repo_url():
    # fmt: off
    # Should be true.
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git+https://github.com/audreyr/cookiecutter-pypackage.git")
    # Should be false.
    assert not is_repo_url("github.com/audreyr/cookiecutter-pypackage.git")
    # fmt: on
# EOF

# Generated at 2022-06-21 10:53:22.755474
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Unit tests for the repository_has_cookiecutter_json
    function.
    """
    template = os.path.join(os.path.dirname(__file__), "fake-repo-tmpl")
    result = repository_has_cookiecutter_json(template)
    assert result == True

# Generated at 2022-06-21 10:53:26.721974
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("my_archive.zip")
    assert is_zip_file("my_archive.ZIP")
    assert is_zip_file("my_archive.Zip")
    assert not is_zip_file("my_archive.Zi")
    assert not is_zip_file("my_archive.zi")
    assert not is_zip_file("my_archive.zi")
    assert not is_zip_file("my_archive.tar")
    assert not is_zip_file("my_/archive/tar")
    assert not is_zip_file("my_archive.zip/")
    assert not is_zip_file("/my_archive.zip")
    assert not is_zip_file("my_archive.zip/file.tar")

# Generated at 2022-06-21 10:53:33.398165
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/NOTHERE') == False
    assert repository_has_cookiecutter_json('tests/') == False
    assert repository_has_cookiecutter_json('./') == False
    assert repository_has_cookiecutter_json('') == False

# Generated at 2022-06-21 10:53:37.825637
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    template1 = 'test_templates/test_template1'
    assert repository_has_cookiecutter_json(template1)

    template2 = 'test_templates/test_template2'
    assert not repository_has_cookiecutter_json(template2)



# Generated at 2022-06-21 10:53:42.734740
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(
        template='https://github.com/audreyr/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/root/cloned_repos',
        checkout=None,
        no_input=False,
        password=None,
        directory=None
    ) == ('/root/cloned_repos/cookiecutter-pypackage', False)



# Generated at 2022-06-21 10:53:50.107199
# Unit test for function is_zip_file
def test_is_zip_file():
    """Verify that is_zip_file returns True for zip files."""
    assert is_zip_file('filename.zip')
    assert is_zip_file('/path/to/filename.zip')
    assert is_zip_file('.zip')
    assert is_zip_file('filename.ziP')
    assert is_zip_file('filename.ZIP')
    assert is_zip_file('filename.Zip')
    assert is_zip_file(u'filename.ziP')
    assert is_zip_file(u'filename.ZIP')
    assert is_zip_file(u'filename.Zip')



# Generated at 2022-06-21 10:53:51.923295
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass
    # assert False, "TODO: unit test me!"



# Generated at 2022-06-21 10:53:59.289232
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_invalid_repo = "invalid"
    test_valid_repo = "tests/fake-repo-tmpl"
    assert repository_has_cookiecutter_json(test_invalid_repo) is False
    assert repository_has_cookiecutter_json(test_valid_repo) is True

# Generated at 2022-06-21 10:54:06.001956
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json(
        'https://github.com/audreyr/cookiecutter-pypackage'
    )
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/')
    assert repository_has_cookiecutter_json('../tests/fake-repo-post/')
    assert not repository_has_cookiecutter_json(
        'https://github.com/audreyr/cookiecutter-pypackage-1'
    )
    assert not repository_has_cookiecutter_json('../tests/fake-repo-pre')
    assert not repository_has_cookiecutter_json('../tests/fake-repo-post')

# Generated at 2022-06-21 10:54:07.637608
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('fake-repo-dir') == False

# Generated at 2022-06-21 10:54:17.096769
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json."""
    # Create temporary directory on the fly:
    import tempfile
    with tempfile.TemporaryDirectory() as temp_d:
        project_tmp_dir = os.path.join(temp_d, 'project')
        os.makedirs(project_tmp_dir)
        config_file_path = os.path.join(project_tmp_dir, 'cookiecutter.json')
        with open(config_file_path, 'w') as config_file:
            config_file.write('{{ "folder": "value" }}\n')
        assert repository_has_cookiecutter_json(temp_d)
        assert repository_has_cookiecutter_json(project_tmp_dir)


# Generated at 2022-06-21 10:54:30.867090
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test if a given string is a repo url or not."""
    # Valid Repository URLs
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file://localhost/Users/ronny/projects/cookiecutter-pypackage')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git://git.example.com/MyProject')
    assert is_repo_url('git+ssh://git@github.com/MyOrganisation/MyProject.git')
    assert is_repo_url('git+ssh://git@github.com/MyOrganisation/MyProject')

# Generated at 2022-06-21 10:54:41.892796
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    # full name
    assert expand_abbreviations('mattuz/cookiecutter-template', abbreviations) == 'mattuz/cookiecutter-template', 'Full name without abbreviations.'
    # abbreviate
    assert expand_abbreviations('gh:mattuz/cookiecutter-template', abbreviations) == 'https://github.com/mattuz/cookiecutter-template.git', 'Abbreviate.'
    # expand

# Generated at 2022-06-21 10:54:44.009744
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')



# Generated at 2022-06-21 10:54:55.413661
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test is_zip_file function."""
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test') == False
    assert is_zip_file('test.zip.zip') == False
    assert is_zip_file('test.zip2') == False
    assert is_zip_file('test.zip/') == False
    assert is_zip_file('/test.zip/') == False
    assert is_zip_file('C:\\test.zip') == True
    assert is_zip_file('/home/user/test.zip') == True
    assert is_zip_file('/home/user/test.zip/') == False
    assert is_zip_file('C:\\test.zip\\') == False

# Generated at 2022-06-21 10:55:04.880070
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        'pypackage', {'pypi': 'https://github.com/audreyr/cookiecutter-pypackage.git'}
    ) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations(
        'pypackage', {'pypi': 'https://github.com/audreyr/{}.git'}
    ) == 'https://github.com/audreyr/pypackage.git'


# Generated at 2022-06-21 10:55:15.984338
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'git@gitlab.com:{}.git',
        'user_gh': 'https://github.com/user/{}.git',
        'user_bb': 'https://bitbucket.org/user/{}.git',
        'user_gl': 'git@gitlab.com:user/{}.git',
    }


# Generated at 2022-06-21 10:55:23.016405
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = "gh:audreyr/cookiecutter-pypackage"
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 10:55:23.721733
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    pass

# Generated at 2022-06-21 10:55:30.025298
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = './tests/files/fake-repo-tmpl'
    assert repository_has_cookiecutter_json(repo_directory) == True
    repo_directory = './tests/files/fake-repo-tmpl-without-cookiecutter-json'
    assert repository_has_cookiecutter_json(repo_directory) == False

# Generated at 2022-06-21 10:55:36.647212
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:55:43.192484
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Verify abbreviations are expanded correctly."""
    abbreviations = {'gh': 'https://github.com/{}.git'}
    # Test user/repo shortcut
    project = 'gh:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(
        project, abbreviations
    )
    assert result == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 10:55:52.102067
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    assert(expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git")
    assert(expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == "https://bitbucket.org/audreyr/cookiecutter-pypackage")

# Generated at 2022-06-21 10:56:00.136479
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # test case: template string is a local path.
    repo_dir = determine_repo_dir(template='/local/path',
                                  abbreviations=None,
                                  clone_to_dir='/tmp',
                                  checkout=None,
                                  no_input=False,
                                  password=None)
    # test case: template string contains abbreviations.
    repo_dir = determine_repo_dir(template='myproject',
                                  abbreviations={'myproject': 'https://github.com/test/test'},
                                  clone_to_dir='/tmp',
                                  checkout=None,
                                  no_input=False,
                                  password=None)
    # test case: template string is a remote git repository.

# Generated at 2022-06-21 10:56:03.051944
# Unit test for function is_zip_file
def test_is_zip_file():
    assert(is_zip_file("abc.zip")==True)
    assert(is_zip_file("abc.json")==False)



# Generated at 2022-06-21 10:56:04.411084
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # TODO
    pass

# Generated at 2022-06-21 10:56:11.066482
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'tests/test_repo'
    checkout = 'develop'
    no_input = False
    password = None
    directory = None

    repo_dir = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == 'repo_dir'

# Generated at 2022-06-21 10:56:18.784288
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl')

# Generated at 2022-06-21 10:56:21.672214
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/fake-repo-tmpl") == False
    assert repository_has_cookiecutter_json("tests") == True

# Generated at 2022-06-21 10:56:23.022673
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    determine_repo_dir()

# Generated at 2022-06-21 10:56:32.873453
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:56:41.167547
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = "hg:user:repo"
    abbreviations = {
        "hg": "https://bitbucket.org/{0}",
        "git": "https://github.com/{0}",
        "org": "https://bitbucket.org/{0}",
        "gh": "https://github.com/{0}",
    }

    result = expand_abbreviations(template, abbreviations)
    assert result == "https://bitbucket.org/user:repo"
    
    

# Generated at 2022-06-21 10:56:46.474177
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://my-git-repo.com/my-repo.git') == True
    assert is_repo_url('git+http://my-git-repo.com/my-repo.git') == True
    assert is_repo_url('https://my-git-repo.com/my-repo.git') == True
    assert is_repo_url('https+ssh://my-git-repo.com/my-repo.git') == True
    assert is_repo_url('git+git@my-git-repo.com/my-repo.git') == True
    assert is_repo_url('file://home/username/my-repo') == True

# Generated at 2022-06-21 10:56:49.676302
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter.main import cookiecutter

    tmpdir, cleanup = cookiecutter('tests/test-repo/', checkout='master')

    assert repository_has_cookiecutter_json(
        os.path.join(tmpdir, 'tests', 'test-repo')
    )
    cleanup()

# Generated at 2022-06-21 10:56:52.215543
# Unit test for function is_repo_url
def test_is_repo_url():
    template = 'git@github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(template)


# Generated at 2022-06-21 10:57:04.357477
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'myfork': 'https://github.com/myusername/{}.git',
    }
    assert expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage', abbreviations
    ) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations(
        'gh:audreyr/cookiecutter-pypackage.git', abbreviations
    ) == 'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-21 10:57:07.360236
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    true_repo_dir = os.path.join(os.path.dirname(
                                 os.path.dirname(__file__)),
                                 'tests',
                                 'fake-repo-tmpl')
    assert repository_has_cookiecutter_json(true_repo_dir)

    false_repo_dir = os.path.join(os.path.dirname(
                                   os.path.dirname(__file__)),
                                   'tests',
                                   'fake-repo-pre')
    assert not repository_has_cookiecutter_json(false_repo_dir)

# Generated at 2022-06-21 10:57:30.573411
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@bitbucket.org:atlassianlabs/cookiecutter-bob.git")
    assert is_repo_url("git+https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git+ssh://git@github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo

# Generated at 2022-06-21 10:57:34.125459
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('hello.zip')
    assert is_zip_file('hello.ZIP')
    assert not is_zip_file('hello.txt')
    assert not is_zip_file('hello.tar.gz')

# Generated at 2022-06-21 10:57:45.104407
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations_dict = {
        "gh": "https://github.com/{}/cookiecutter-{}",
        "bb": "https://bitbucket.org/{}/cookiecutter-{}",
    }
    template_name = 'gh:example/cookiecutter-example'
    template_name_expanded = expand_abbreviations(
        template=template_name, abbreviations=abbreviations_dict
    )
    assert template_name_expanded == \
        'https://github.com/example/cookiecutter-example'

    template_name_expanded = expand_abbreviations(
        template='example', abbreviations=abbreviations_dict
    )
    assert template_name_expanded == 'example'


# Generated at 2022-06-21 10:57:54.923063
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    clone_to_dir = None
    checkout = None
    no_input = True
    password = None
    directory = None

    assert determine_repo_dir(template, abbreviations, clone_to_dir, checkout,
                              no_input, password, directory) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'gh:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 10:57:59.141927
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        template='gh:audreyr',
        abbreviations={'gh': 'https://github.com/{}.git'}
    ) == 'https://github.com/audreyr.git'

# Generated at 2022-06-21 10:58:08.073594
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test that is_repo_url works as expected."""
    assert is_repo_url('https://bitbucket.org/pokoli/cookiecutter-pylibrary')
    assert is_repo_url('ssh://hg@bitbucket.org/pokoli/cookiecutter-pylibrary')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'hg+ssh://hg@bitbucket.org/pokoli/cookiecutter-pylibrary'
    ) is True
    assert is_repo_url('file://localhost/home/shravan/code/cookiecutter-pylibrary')

# Generated at 2022-06-21 10:58:18.413154
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    os.mkdir('./test_data/test_repo_has_json')
    os.mkdir('./test_data/test_repo_has_no_json')
    os.mkdir('./test_data/test_repo_no_exist')
    open('./test_data/test_repo_has_json/cookiecutter.json', 'a').close()
    assert repository_has_cookiecutter_json('./test_data/test_repo_has_json')
    assert not repository_has_cookiecutter_json('./test_data/test_repo_has_no_json')
    assert not repository_has_cookiecutter_json('./test_data/test_repo_no_exist')

# Generated at 2022-06-21 10:58:27.325121
# Unit test for function is_repo_url
def test_is_repo_url():
    # Test valid git urls
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') is True
    assert is_repo_url('ssh://git@github.com/audreyr/cookiecutter-pypackage.git') is True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') is True

# Generated at 2022-06-21 10:58:30.257941
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    reponame = "tests/test-repo"
    assert repository_has_cookiecutter_json(reponame) == True

# Generated at 2022-06-21 10:58:33.575957
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test the is_zip_file function returns True if the string ends in '.zip'"""
    assert is_zip_file('name.zip') == True
    assert is_zip_file('name.zip.txt') == False


# Generated at 2022-06-21 10:59:08.604118
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghe': 'https://{}.github.com/{}.git'
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expected = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == expected
    template = 'foo:bar'
    expected = 'foo:bar'
    assert expand_abbreviations(template, abbreviations) == expected

# Generated at 2022-06-21 10:59:19.953982
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    tmplt = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbrvs = {
        'pypkg': 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.3.0.zip'
    }
    clonedir = "/home/user/clone/"
    checkout = "master"
    noinput = False
    passwd = None
    dir = None
    (res1, cleanup1) = determine_repo_dir(tmplt, abbrvs, clonedir, checkout, noinput, passwd, dir)
    assert res1 == "/home/user/clone/cookiecutter-pypackage"
    assert cleanup1 == False

    tmplt = "pypkg"

# Generated at 2022-06-21 10:59:30.241701
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        "abbrev_with_no_param": "repo_with_no_param",
        "abbrev_with_params_1": "repo_with_params_{0}",
        "abbrev_with_params_2": "repo_with_params_{0}_{1}",
    }
    # Test with no parameters
    template = "abbrev_with_no_param"
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == "repo_with_no_param", (
        'Expanding abbreviations on {0} should be {1}, but is {2}'
        .format(template, "repo_with_no_param", expanded_template))

    # Test with one parameter

# Generated at 2022-06-21 10:59:33.700664
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Testing is_repo_url
    """
    assert is_repo_url('https://github.com/audreyr/cookiecutter') is True
    assert is_repo_url('file://cookiecutter') is True
    assert is_repo_url('/cookiecutter') is False



# Generated at 2022-06-21 10:59:43.141964
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Test with no abbreviations given
    result = expand_abbreviations('test', {})
    assert result == 'test'

    # Test with an abbreviation present
    abbreviations = {'test': 'testing'}
    result = expand_abbreviations('test', abbreviations)
    assert result == 'testing'

    # Test with a colon-terminated abbreviation, with no
    # text to the right of the colon
    abbreviations = {'test': 'testing:'}
    result = expand_abbreviations('test', abbreviations)
    assert result == 'testing:'

    # Test with a colon-terminated abbreviation, with
    # text to the right of the colon
    abbreviations = {'test': 'testing:{}'}
    result = expand_abbreviations('test', abbreviations)

# Generated at 2022-06-21 10:59:48.258170
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert is_zip_file('https://foo.bar/test.zip')
    assert is_zip_file('file:///home/user/test.zip')
    assert is_zip_file('file:///home/user/subdir/test.zip')

    assert is_zip_file('my-repo.zip')
    assert not is_zip_file('my-repo')


# Generated at 2022-06-21 10:59:55.631013
# Unit test for function is_zip_file

# Generated at 2022-06-21 11:00:00.180158
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    temp_directory = tempfile.mkdtemp()
    with open(os.path.join(temp_directory, "cookiecutter.json"), 'w') as f:
        f.write('{}')

    assert(repository_has_cookiecutter_json(temp_directory) == True)
    shutil.rmtree(temp_directory)


# Generated at 2022-06-21 11:00:08.564954
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Verify that the existence of `cookiecutter.json` is correctly detected."""
    # Given that a directory containing a `cookiecutter.json` file exists
    test_path = os.path.join(os.path.dirname(__file__), 'fake-repo-pre')
    test_file = os.path.join(test_path, 'cookiecutter.json')
    # When the existence of a `cookiecutter.json` file is checked
    candidate_exists = repository_has_cookiecutter_json(test_path)
    # Then the value returned is true
    assert candidate_exists is True
    # Given that a directory containing a `cookiecutter.json` file exists
    test_path = os.path.join(os.path.dirname(__file__), 'fake-repo-post')


# Generated at 2022-06-21 11:00:15.470329
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    test_dir = "~/dev/testing"
    test_dir_expected = os.path.expanduser(test_dir)

    # Directory
    assert determine_repo_dir(
        template=test_dir,
        abbreviations={},
        clone_to_dir="~/dev/tmp",
        checkout=None,
        no_input=True,
    ) == (test_dir_expected, False)

    # Directory with cookiecutter.json

# Generated at 2022-06-21 11:01:24.363907
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check repository_has_cookiecutter_json works as expected."""
    if not os.path.exists('repo_has_cookiecutter_json_unittest'):
        os.makedirs('repo_has_cookiecutter_json_unittest')
    with open('repo_has_cookiecutter_json_unittest/cookiecutter.json', 'w') as f:
        f.write('aaa')
    assert(repository_has_cookiecutter_json('repo_has_cookiecutter_json_unittest') == True)
    os.remove('repo_has_cookiecutter_json_unittest/cookiecutter.json')
    os.rmdir('repo_has_cookiecutter_json_unittest')

# Generated at 2022-06-21 11:01:28.749666
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}'}
    expanded = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert expanded == 'https://github.com/audreyr/cookiecutter-pypackage'


# Generated at 2022-06-21 11:01:32.072749
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test1.zip') == True
    assert is_zip_file('test.ZIP') == True

    assert is_zip_file('test.tar') == False
    assert is_zip_file('test.tar.gz') == False


# Generated at 2022-06-21 11:01:36.900718
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('file.ZIP')
    assert not is_zip_file('file')
    assert not is_zip_file('file.zip.')

# Generated at 2022-06-21 11:01:47.391433
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "https://cookiecutter.example.com/author/repo"
    abbreviations = {}
    clone_to_dir = '/tmp'
    checkout = ''
    no_input = False
    password = None
    directory = None

    print(determine_repo_dir(
        template = template,
        abbreviations = abbreviations,
        clone_to_dir = clone_to_dir,
        checkout = checkout,
        no_input = no_input,
        password = password,
        directory = directory
    ))

    template = "https://cookiecutter.example.com/author/repo"
    abbreviations = {}
    clone_to_dir = '/tmp'
    checkout = ''
    no_input = False
    password = None
    directory = 'subdir'


# Generated at 2022-06-21 11:01:53.649222
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the is_repo_url function."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://hg@bitbucket.org/pokoli/cookiecutter-tryton.git')



# Generated at 2022-06-21 11:01:57.462658
# Unit test for function is_repo_url
def test_is_repo_url():
    # TODO: Expand test coverage
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')


# Generated at 2022-06-21 11:02:08.634975
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter import DEFAULT_CONTEXT
    from cookiecutter.utils import clean_up_dir
    from cookiecutter.utils import work_in

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone_to_dir = 'test-dir'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        DEFAULT_CONTEXT['cookiecutter']['repository_abbreviations'],
        clone_to_dir,
        checkout,
        no_input,
        password=password,
        directory=directory,
    )

# Generated at 2022-06-21 11:02:10.932460
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip') is True
    assert is_zip_file('foo.ZIP') is True



# Generated at 2022-06-21 11:02:13.388337
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip')
