

# Generated at 2022-06-21 10:53:11.751145
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test different ways to get a repo dir from the template name

    Copied from cookiecutter/tests/test_output.py and modified
    """

    # Make sure that we can use abbreviations
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir='.',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )

# Generated at 2022-06-21 10:53:12.689012
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("cookiecutter.zip") is True
    assert is_zip_file("cookiecutter.json") is False


# Generated at 2022-06-21 10:53:22.437959
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import shutil
    import tempfile
    from cookiecutter.utils import rmtree
    
    # Create a temporary working directory
    temp_directory = tempfile.mkdtemp()
    
    # Create a temporary git repository
    temp_repo = tempfile.mkdtemp(dir=temp_directory)
    os.chdir(temp_repo)
    with open('cookiecutter.json', 'w') as f:
        f.write('{"foo": "bar"}')
    os.system('git init')
    os.system('git add .')
    os.system('git commit -m "initial commit"')

    # This is the case where is_zip_file returns false, 
    # is_repo_url returns false, and a valid directory is given
    # This is the case where no cleanup should be done


# Generated at 2022-06-21 10:53:32.686379
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    test_path = "/home/user/cookiecutter-test" 
    test_abbreviations = {'gh': 'https://github.com/{}.git'}
    test_clone_to_dir = "/home/user/cookiecutter-dir"
    test_checkout = None
    test_no_input = True
    test_password = None
    test_directory = None

    test_template = expand_abbreviations(test_path, test_abbreviations)

# Generated at 2022-06-21 10:53:37.212817
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/tmp/file.zip')
    assert is_zip_file('/tmp/file.ZIP')
    assert is_zip_file('/tmp/file.zIp')
    assert not is_zip_file('/tmp/file.tar')

# Generated at 2022-06-21 10:53:39.004871
# Unit test for function is_zip_file
def test_is_zip_file():
    value = 'cookiecutter-pypackage'
    assert is_zip_file(value)

# Generated at 2022-06-21 10:53:45.006582
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('~/cookiecutter-demo/cookiecutter-djangopackage')
    assert not repository_has_cookiecutter_json('~/cookiecutter-demo/cookiecutter-djangopackage/cookiecutter.txt')
    assert not repository_has_cookiecutter_json('')



# Generated at 2022-06-21 10:53:49.733373
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter.repository import repository_has_cookiecutter_json

    path = os.getcwd()
    assert repository_has_cookiecutter_json(path) == True

    path = os.path.expanduser('~')
    assert repository_has_cookiecutter_json(path) == False

# Generated at 2022-06-21 10:53:56.911278
# Unit test for function is_repo_url
def test_is_repo_url():
    assert(is_repo_url('http://github.com/audreyr/cookiecutter.git'))
    assert(is_repo_url('git@github.com:audreyr/cookiecutter.git'))
    assert(not is_repo_url('https://github.com/audreyr/cookiecutter'))
    assert(not is_repo_url('https://github.com/audreyr/cookiecutter.git'))

# Generated at 2022-06-21 10:54:04.557173
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gh-bb': 'https://{}.git',
    }
    clone_to_dir = '.tmp-cookiecutters'
    template = 'gh:msakthip/cookiecutter-datascience'
    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir='/tmp/cookiecutters',
        checkout=None,
        no_input=False,
        password=None,
        directory=None,
    )
    assert repo_dir is not None
    assert cleanup is False

# Generated at 2022-06-21 10:54:16.821000
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'gl': 'https://gitlab.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }

# Generated at 2022-06-21 10:54:30.824285
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Return True if the function determine_repo_dir work as expected."""
    from cookiecutter.config import prepare_abbreviations
    from functools import partial
    from cookiecutter.main import cookiecutter

    def run_cookiecutter(template, no_input=False, checkout=None, password=None, directory='.'):
        """Return True if the function cookiecutter work as expected."""
        abbreviations = prepare_abbreviations(
            abbreviations_file='tests/test-abbreviations.yaml'
        )
        return (
            determine_repo_dir(
                template,
                abbreviations,
                'tests/test-repos',
                checkout,
                no_input,
                password=password,
                directory=directory
            )
        )


# Generated at 2022-06-21 10:54:41.857248
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('ssh://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-21 10:54:53.171419
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """ test function determine_repo_dir"""
    curr_dir = os.path.dirname(__file__)
    project_template = "project_name"
    clone_to_dir = os.path.join(curr_dir, "..", "..", "tests", "test-repo")
    no_input = True
    abbreviations = {"github": "https://github.com/{}.git"}
    # asserts the correct template directory is returned and the
    # correct cleanup flag is set
    assert determine_repo_dir(
        project_template,
        abbreviations,
        clone_to_dir,
        "master",
        no_input,
        password=None,
        directory=None,
    ) == (os.path.join(clone_to_dir, 'test-repo'), False)
   

# Generated at 2022-06-21 10:55:03.553643
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+http://hg.myproject.org/myproject#egg=myproject')
    assert is_repo_url('git+ssh://git@github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_

# Generated at 2022-06-21 10:55:10.070647
# Unit test for function is_zip_file
def test_is_zip_file():
    assert False == is_zip_file("")
    assert False == is_zip_file("foo")
    assert False == is_zip_file("zip")
    assert False == is_zip_file("zip.zip")
    assert True == is_zip_file("zip.ZIP")
    assert True == is_zip_file("zip.zip.zip")


# Generated at 2022-06-21 10:55:18.866827
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:pokoli/extradmin.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('hg+https://bitbucket.org/pokoli/extradmin')
    assert is_repo_url('ssh://hg@bitbucket.org/pokoli/extradmin')

# Generated at 2022-06-21 10:55:25.024110
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    location = this_dir = os.path.dirname(os.path.realpath(__file__))
    location = os.path.join(this_dir, '..', '..', 'tests', 'files')
    assert not repository_has_cookiecutter_json(location)

    location = os.path.join(this_dir, '..', '..', 'tests', 'files', 'fake-repo-pre')
    assert repository_has_cookiecutter_json(location)

# Generated at 2022-06-21 10:55:32.020940
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrevs = {"gh": "https://github.com/{}.git"}
    assert expand_abbreviations("gh:user/repo", abbrevs) == "https://github.com/user/repo.git"
    assert expand_abbreviations("user/repo", abbrevs) == "user/repo"
    assert expand_abbreviations("https://github.com/user/repo.git", abbrevs) == "https://github.com/user/repo.git"

# Generated at 2022-06-21 10:55:36.551326
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = 'p\w+'
    abbreviations = {'p': 'p/p/p'}
    clone_to_dir = '.'
    checkout = '*'
    no_input = True
    password = '*'
    directory = '.'
    determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password=None,
        directory=None,
    )

if __name__ == '__main__':
    test_determine_repo_dir()

# Generated at 2022-06-21 10:55:47.029011
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git'}
    template = 'cc'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'cc'

    template = 'test'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'test'

    template = 'gh:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'gh:bts/bts'
    result = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-21 10:55:57.517283
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/Repo/repo') == True
    assert is_repo_url('git://github.com/Repo/repo') == True
    assert is_repo_url('git@github.com/Repo/repo') == True
    assert is_repo_url('file:///home/repo') == True
    assert is_repo_url('ssh://github.com/Repo/repo') == True
    assert is_repo_url('ssh://github.com/Repo/repo') == True
    assert is_repo_url('git@github.com:user/project.git') == True
    assert is_repo_url('git@github.com/user/project.git') == True

# Generated at 2022-06-21 10:56:09.215576
# Unit test for function is_repo_url
def test_is_repo_url():
    """Return True if value is a repository URL."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///Users/audreyr/projects/cookiecutter-pypackage')
    assert is_repo_url('ssh://mygithost.com/cookiecutter-pypackage.git')
    assert is_repo_url('hg+ssh://mygithost.com/cookiecutter-pypackage')

    # Test that a URL-like string without a protocol is not a repo URL

# Generated at 2022-06-21 10:56:11.689127
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Ensure that is_repo_url returns True when matching a URL.
    """
    assert is_repo_url('http://github.com/acdha/cookiecutter-pypackage.git')



# Generated at 2022-06-21 10:56:23.292612
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:56:29.053340
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Validate repository discovery."""
    assert repository_has_cookiecutter_json('/tmp/test')
    assert repository_has_cookiecutter_json('/tmp/test/')
    assert not repository_has_cookiecutter_json('/tmp/test/abc')
    assert not repository_has_cookiecutter_json('/tmp/test/abc/')

# Generated at 2022-06-21 10:56:33.222823
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/home/asif")
    assert repository_has_cookiecutter_json("/home/asif/cookiecutter")
    assert not repository_has_cookiecutter_json("/home/asif/cookicutter")



# Generated at 2022-06-21 10:56:44.438437
# Unit test for function expand_abbreviations
def test_expand_abbreviations():

    abbreviations = {
            "gh": "https://github.com/{}",
            "bb": "https://bitbucket.org/{}",
            }

    assert expand_abbreviations("foo", abbreviations) == "foo"
    assert expand_abbreviations("foo/bar", abbreviations) == "foo/bar"
    assert expand_abbreviations("gh:foo/bar", abbreviations) == "https://github.com/foo/bar"
    assert expand_abbreviations("bb:foo/bar", abbreviations) == "https://bitbucket.org/foo/bar"
    assert expand_abbreviations("gh:bar/foo/bar", abbreviations) == "https://github.com/bar/foo/bar"

# Generated at 2022-06-21 10:56:48.235807
# Unit test for function is_zip_file
def test_is_zip_file():
    template = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    assert(is_zip_file(template) == False)

    template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    assert(is_zip_file(template) == True)

# Generated at 2022-06-21 10:56:57.191261
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # For coverage test
    # pylint: disable=unused-argument
    assert is_zip_file('/path/to/zip_file.zip')
    assert not is_zip_file('/path/to/template/')
    assert not is_zip_file('/path/to/template')

    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/path/to/template/')
    assert not is_repo_url('/path/to/template')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:57:13.204195
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:sigmavirus24/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:sigmavirus24/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git#egg=cookiecutter')

# Generated at 2022-06-21 10:57:21.395121
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("foo.zip")
    assert is_zip_file("foo.ZIP")
    assert is_zip_file("foo.Zip")
    assert is_zip_file("foo.ZiP")
    assert is_zip_file("foo.zIp")
    assert is_zip_file("foo.ZIp")
    assert is_zip_file("foo.ZIp.zip")
    assert is_zip_file("foo.zip.zip")
    assert not is_zip_file("foo.bar")
    assert not is_zip_file("foo.bar.zip")
    assert not is_zip_file("foo.bar.ZIP")

# Generated at 2022-06-21 10:57:30.863615
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('{{cookiecutter.full_name}}/{{cookiecutter.repo_name}}', {'user': '{{cookiecutter.full_name}}'}) == '{{cookiecutter.full_name}}/{{cookiecutter.repo_name}}'
    assert expand_abbreviations('user/{{cookiecutter.repo_name}}', {'user': '{{cookiecutter.full_name}}'}) == '{{cookiecutter.full_name}}/{{cookiecutter.repo_name}}'
    assert expand_abbreviations('user:{{cookiecutter.repo_name}}', {'user': '{{cookiecutter.full_name}}'}) == '{{cookiecutter.full_name}}:{{cookiecutter.repo_name}}'
    assert expand_ab

# Generated at 2022-06-21 10:57:35.343307
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('url_to_zip.zip')
    assert is_zip_file('url_to_zip.ZIP')
    assert not is_zip_file('url_to_branch#master')
    assert not is_zip_file('url_to_branch#master/path/to/directory/')

# Generated at 2022-06-21 10:57:42.397182
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip')
    assert is_zip_file('abc.ZIP')
    assert is_zip_file('.zip')
    assert not is_zip_file('abc.gz')
    assert not is_zip_file('.gz.ZIP')
    assert not is_zip_file('.zip.gz')
    assert not is_zip_file('abcde')
    assert not is_zip_file('abc.de')
    assert not is_zip_file('')

# Generated at 2022-06-21 10:57:47.097275
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-template/')
    assert not repository_has_cookiecutter_json('tests/fake-repo-pre/')
    assert not repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo-template')

# Generated at 2022-06-21 10:57:54.014006
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test REPO_REGEX by ensuring it matches the following strings:
    - git://
    - ssh://
    - file://
    - something like user@...
    """
    test_strings = [
        'git://',
        'ssh://',
        'file://',
        'git@github.com:user/repo',
        'user@githost:path/to/repo',
    ]

    for test_string in test_strings:
        assert is_repo_url(test_string)

# Generated at 2022-06-21 10:58:05.277246
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    raw_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = 'tests/fake-repo-tmpl'
    checkout = None
    no_input = False
    password = None
    directory = None


    exp_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    exp_cleanup = False
    exp_dir = 'tests/fake-repo-tmpl'
    repo, cleanup = determine_repo_dir(
        raw_template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )

    assert repo

# Generated at 2022-06-21 10:58:08.954759
# Unit test for function is_zip_file
def test_is_zip_file():
    filename = 'cookiecutter-pypackage.zip'
    assert is_zip_file(filename) == True



# Generated at 2022-06-21 10:58:18.676754
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test for function repository_has_cookiecutter_json."""
    tmp_dir = os.path.join('tmp', 'test_repository_has_cookiecutter_json')
    cookiecutter_json = os.path.join(tmp_dir, 'cookiecutter.json')
    assert not os.path.exists(tmp_dir)

    try:
        # setup
        os.makedirs(tmp_dir)
        with open(cookiecutter_json, 'w') as f:
            f.write('{"cookiecutter": "test"}')

        assert repository_has_cookiecutter_json(tmp_dir)

    finally:
        # teardown
        if os.path.exists(tmp_dir):
            os.removedirs(tmp_dir)

# Generated at 2022-06-21 10:58:33.624653
# Unit test for function is_zip_file
def test_is_zip_file():
    """Function is_zip_file unit test."""
    assert is_zip_file('my_repo.zip') == True
    assert is_zip_file('my_repo.ZIP') == True
    assert is_zip_file('my_repo.txt') == False
    assert is_zip_file('my_repo.zip/cookiecutter.json') == False
    assert is_zip_file('my_repo') == False
    assert is_zip_file('') == False

# Generated at 2022-06-21 10:58:42.659861
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:58:49.183097
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    template = "https://github.com/cookiecutter-django/cookiecutter-django"
    clone_to_dir = "local_repos"
    checkout = ""
    no_input = ""
    password = ""
    directory = ""

    repo_dir = determine_repo_dir(
        template, abbreviations, clone_to_dir, checkout, no_input, password, directory
    )

    assert "cookiecutter-django" in repo_dir[0]

# Generated at 2022-06-21 10:58:52.126887
# Unit test for function is_zip_file
def test_is_zip_file():
    expected = True
    assert is_zip_file('foo.zip') == expected

    expected = False
    assert is_zip_file('foo.tar.gz') == expected



# Generated at 2022-06-21 10:58:53.169426
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == 1

# Generated at 2022-06-21 10:59:03.117702
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    cookiecutter_repos = determine_repo_dir(
        template='/fake/repos/fake-repo-master',
        abbreviations={},
        clone_to_dir='/fake',
        checkout='master',
        no_input=False,
        password=None,
        directory=None,
    )
    print(cookiecutter_repos[0])
    print(cookiecutter_repos[1])
    assert cookiecutter_repos[0] == '/fake/repos/fake-repo-master'
    assert cookiecutter_repos[1] == False



# Generated at 2022-06-21 10:59:11.067571
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'user': 'https://github.com/alphabetagamma/{}.git',
        'github': 'https://github.com/{}.git',
        'bitbucket': 'https://bitbucket.org/{}.git',
        'local': '/home/{}',
        'user_local': '/home/alphabetagamma/{}'
    }

    # Test a few use cases
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbre

# Generated at 2022-06-21 10:59:23.418071
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Test with no abbreviations
    template = expand_abbreviations('cookiecutter-pypackage', {})
    assert template == 'cookiecutter-pypackage'

    # Test with full name with abbreviation
    abbreviations = {'gh': 'https://github.com/{}'}
    template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert template == 'https://github.com/audreyr/cookiecutter-pypackage'

    # Test with abbreviation and no colon
    abbreviations['pypackage'] = 'audreyr/cookiecutter-pypackage'
    template = expand_abbreviations('pypackage', abbreviations)

# Generated at 2022-06-21 10:59:32.106073
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # This has been commented out because it fails on travis because of a
    # time out. It takes too long to download the repository.
    #
    # assert determine_repo_dir(
    #     template='https://github.com/ionelmc/cookiecutter-pylibrary',
    #     abbreviations=dict(),
    #     clone_to_dir='tests/fake-repo-tmpl',
    #     checkout=None,
    #     no_input=True,
    # )
    assert determine_repo_dir(
        template='tests/fake-repo-tmpl',
        abbreviations=dict(),
        clone_to_dir='tests/fake-repo-tmpl',
        checkout=None,
        no_input=True,
    )

# Generated at 2022-06-21 10:59:37.818463
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    current_directory = os.getcwd()
    os.chdir("tests/test-repo")
    assert repository_has_cookiecutter_json(".") == True
    assert repository_has_cookiecutter_json("tests/test-repo") == True
    assert repository_has_cookiecutter_json("fake-directory") == False
    assert repository_has_cookiecutter_json("tests/test-repo/does-not-exist") == False
    os.chdir(current_directory)

if __name__ == "__main__":
    test_repository_has_cookiecutter_json()

# Generated at 2022-06-21 10:59:48.982495
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir"""

# Generated at 2022-06-21 10:59:50.718171
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('example.zip')
    assert is_zip_file('example.ZIP')
    assert not is_zip_file('example')

# Generated at 2022-06-21 10:59:54.082932
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/user/repo')
    assert is_repo_url('git://github.com/user/repo.git')
    assert is_repo_url('user@server:user/foo.git') is False
    assert is_repo_url('foo/bar/baz.zip') is False

# Generated at 2022-06-21 11:00:03.388061
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations(
        'gh:user/repo',
        abbreviations={'gh': 'https://github.com/{}'}
    ) == 'https://github.com/user/repo'
    assert expand_abbreviations(
        'user/repo',
        abbreviations={'gh': 'https://github.com/{}'}
    ) == 'user/repo'
    assert expand_abbreviations(
        'gh:user/repo',
        abbreviations={'gh': 'https://github.com/{}', 'bb': 'https://bitbucket.org/{}'}
    ) == 'https://github.com/user/repo'

# Generated at 2022-06-21 11:00:06.435984
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = expand_abbreviations(template, abbreviations)
    assert expanded_template == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 11:00:12.235825
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('test.ZiP') == True
    assert is_zip_file('test.ZIP.ZIP') == True
    assert is_zip_file('test.zip.zip') == True
    assert is_zip_file('/path/to/test.zip') == True

    assert is_zip_file('test.zi') == False

# Generated at 2022-06-21 11:00:21.601212
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'cc': 'https://github.com/{}.git',
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }

    assert expand_abbreviations('cc:audreyr/cookiecutter-pypackage',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 11:00:30.971208
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    import shutil
    import os

    template_dir = tempfile.mkdtemp()


# Generated at 2022-06-21 11:00:37.414760
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url.

    :return: None.
    """
    print('testing is_repo_url')
    assert is_repo_url('git@gitlab.com:user/example-repo.git')
    assert is_repo_url('https://gitlab.com:user/example-repo.git')
    assert is_repo_url('https://gitlab.com/user/example-repo.git')
    assert is_repo_url('./example-repo.git')
    assert not is_repo_url('example-repo.git')


if __name__ == '__main__':
    test_is_repo_url()

# Generated at 2022-06-21 11:00:45.279836
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.config import get_user_config
    from cookiecutter.config import parse_cookiecutter_config

    # user config
    user_config_path = DEFAULT_CONFIG['config_file']
    user_config_contents = get_user_config(user_config_path)
    user_config = parse_cookiecutter_config(user_config_contents)

    # Load the abbreviations
    abbreviations = user_config['abbreviations']

    # apply abbreviations
    clone_to_dir = '/tmp/cookiecutters'
    checkout = 'master'
    no_input = True
    password = None
    directory = None

    # repo_dir, cleanup = determine_repo_dir(
    #     'gh:audre

# Generated at 2022-06-21 11:01:00.980580
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function `determine_repo_dir`."""
    assert determine_repo_dir(
        template='.',
        abbreviations={},
        clone_to_dir=None,
        checkout='master',
        no_input=False,
        password=None,
    ) == (os.path.abspath(os.path.join('.', '..')), False)

# Generated at 2022-06-21 11:01:09.597320
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test for function determine_repo_dir."""
    from cookiecutter.main import cookiecutter

    # Test for valid template with no abbreviations
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    abbreviations = {}
    clone_to_dir = 'tests/test-repo/{{cookiecutter.repo_name}}'
    checkout = None
    no_input = False
    password = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
    )
    assert repo_dir.endswith(
        'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 11:01:18.218492
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}'}
    assert determine_repo_dir('gh:foo/bar', abbreviations, '', '', False)[0] == 'https://github.com/foo/bar'
    assert determine_repo_dir('gh:foo/bar:master', abbreviations, '', '', False)[0] == 'https://github.com/foo/bar:master'
    assert determine_repo_dir('gh:foo/bar', abbreviations, '', '', False)[1] == False

# Generated at 2022-06-21 11:01:28.349179
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Function-level testing"""
    # Sample abbreviations
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    # Sample templates
    templates = [
        'gh:pyca/cryptography',
        'https://github.com/pyca/cryptography.git',
        ('gh:pyca/cryptography', 'indices'),
        ('https://github.com/pyca/cryptography.git', 'indices'),
    ]
    # Add template with abbreviation as base and a local dir
    clone_to_dir = create_sample_repo()
    templates.append('cryptography-cookiecutter')
    templates.append(('cryptography-cookiecutter', 'indices'))
    # Add templates that

# Generated at 2022-06-21 11:01:35.275289
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'gl': 'https://gitlab.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'gist': 'https://gist.github.com/{}.git',
        'azdevops': 'https://dev.azure.com/{}',
    }
    assert expand_abbreviations("gh:audreyr/cookiecutter-pypackage", abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"

# Generated at 2022-06-21 11:01:36.674059
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip')

# Generated at 2022-06-21 11:01:41.651363
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 11:01:42.751941
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # todo: find out what is going wrong here
    pass

# Generated at 2022-06-21 11:01:52.189651
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/does-not-exist') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo/') == True

    assert repository_has_cookiecutter_json('tests/fake-repo-post/') == False
    assert repository_has_cookiecutter_json('tests/fake-repo-post') == False

# Generated at 2022-06-21 11:01:53.821469
# Unit test for function is_repo_url
def test_is_repo_url():
    result = is_repo_url("https://github.com/cookiecutter/cookiecutter.git")
    assert result == True



# Generated at 2022-06-21 11:02:07.858647
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    try:
        determine_repo_dir(
            template='https://github.com/audreyr/cookiecutter-pypackage.git',
            abbreviations={},
            clone_to_dir=os.path.expanduser('~/fake-repos'),
            checkout=None,
            no_input=False,
            password=None,
        )
    except RepositoryNotFound:
        assert False
    finally:
        assert True

# Generated at 2022-06-21 11:02:15.832069
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter.zip') is True
    assert is_zip_file('http://example.com/cookiecutter.zip') is True
    assert is_zip_file('/example.com/cookiecutter.zip') is True
    assert is_zip_file('C:\\example.com\\cookiecutter.zip') is True
    assert is_zip_file('/full/path/to/cookiecutter.zip') is True
    assert is_zip_file('C:\\full\\path\\to\\cookiecutter.zip') is True
    # Handle relative paths
    assert is_zip_file('path/to/cookiecutter.zip') is True
    assert is_zip_file('to/cookiecutter.zip') is True
    assert is_zip_file('cookiecutter.zip') is True


# Generated at 2022-06-21 11:02:20.772534
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Function repository_has_cookiecutter_json() test.
    """
    if repository_has_cookiecutter_json("/home/mrodel/Dropbox/mrodel/") is False:
        print(1)
    else:
        print(2)

# Generated at 2022-06-21 11:02:29.862510
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Unit test determine_repo_dir function."""
    template = 'cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'lp': 'https://launchpad.net/{}.git',
    }
    clone_to_dir = 'tests/fake-repo-tmpl'
    checkout = 'master'
    no_input = True
    password = '123'
    directory = 'dir'

    template = expand_abbreviations(template, abbreviations)

    assert template == 'https://github.com/cookiecutter-pypackage.git'


# Generated at 2022-06-21 11:02:35.100123
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file = './cookiecutter-pypackage.zip'
    non_zip_file = './cookiecutter-pypackage'
    assert is_zip_file(zip_file)
    assert not is_zip_file(non_zip_file)

# Generated at 2022-06-21 11:02:38.959740
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    shortened_reference = 'pypi:requests'
    abbreviations = { 'pypi': 'https://pypi.org/simple/{0}' }

    assert expand_abbreviations(
        shortened_reference, abbreviations) == 'https://pypi.org/simple/requests'



# Generated at 2022-06-21 11:02:40.054257
# Unit test for function is_zip_file
def test_is_zip_file():
    result = is_zip_file("test.zip")
    assert result == True


# Generated at 2022-06-21 11:02:44.955545
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("test.zip") == True
    assert is_zip_file("test.zip.zip") == False
    assert is_zip_file("/home/test.zip") == True
    assert is_zip_file("test") == False
    assert is_zip_file("test.zip/") == False
    assert is_zip_file("test.zip/home") == False

# Generated at 2022-06-21 11:02:55.890572
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test abbreviations expansion."""
    abbreviations = {
        'my_database': 'https://github.com/my-org/{}.git',
        'default': 'https://github.com/my-org/my-default-project.git',
    }