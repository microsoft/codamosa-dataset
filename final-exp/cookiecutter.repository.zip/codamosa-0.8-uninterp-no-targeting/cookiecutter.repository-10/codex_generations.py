

# Generated at 2022-06-21 10:53:02.455170
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json."""
    clone_to_dir = os.path.join('tests', 'fake-repo-tmpl')

    # Test is directory exists and contains a cookiecutter.json
    repo_directory = os.path.join(clone_to_dir, 'fake-repo-tmpl')
    assert repository_has_cookiecutter_json(repo_directory) is True

    # Test when directory does not contain a cookiecutter.json
    repo_directory = os.path.join(clone_to_dir, 'fake-repo-tmpl-no-json')
    assert repository_has_cookiecutter_json(repo_directory) is False

    # Test when directory does not exist

# Generated at 2022-06-21 10:53:14.321600
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test abbreviations expansion."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    # simple expansion
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

    # same, but with a colon on the end
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage:',
                                abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'

    # expansion with colon

# Generated at 2022-06-21 10:53:23.188050
# Unit test for function is_zip_file

# Generated at 2022-06-21 10:53:25.820279
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file = '/static/logo-navy.zip'
    assert is_zip_file(zip_file) is True

# Generated at 2022-06-21 10:53:34.040928
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:53:37.213500
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test for function test_is_zip_file."""
    assert is_zip_file('/data/projects/cookiecutter-data-science/master.zip')



# Generated at 2022-06-21 10:53:41.948890
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('fake-repo-1') == False
    assert repository_has_cookiecutter_json('/home/vagrant/cookiecutter-pypackage/') == False
    assert repository_has_cookiecutter_json('/home/vagrant/cookiecutter-pypackage') == True

# Generated at 2022-06-21 10:53:42.882247
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # TODO
    pass

# Generated at 2022-06-21 10:53:51.610023
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:53:55.071034
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/fake-repo-pre/")==True
    assert repository_has_cookiecutter_json("tests/fake-repo-pre/cookiecutter.json")==False
    assert repository_has_cookiecutter_json("tests/fake-repo-pre/biscuits/")==False

# Generated at 2022-06-21 10:54:01.238183
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test function repository_has_cookiecutter_json"""
    assert repository_has_cookiecutter_json('.') == True
    assert repository_has_cookiecutter_json('..') == False
    assert repository_has_cookiecutter_json('/') == False
    assert repository_has_cookiecutter_json(__file__) == False

# Generated at 2022-06-21 10:54:12.989835
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir()."""
    git_repo_url = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    hg_repo_url = 'https://bitbucket.org/pokoli/cookiecutter-pokoli-skeleton'
    repo_url = 'https://github.com/devyhia/django-template.git'
    git_repo_url_with_subdir = (
        'git@github.com:audreyr/cookiecutter-pypackage.git#subdir={{cookiecutter.repo_name}}'
    )
    zip_repo_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'

# Generated at 2022-06-21 10:54:20.775330
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

# Generated at 2022-06-21 10:54:23.735157
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file_name = 'test_document.zip'
    assert is_zip_file(zip_file_name)



# Generated at 2022-06-21 10:54:36.501628
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    import tempfile
    import shutil
    from cookiecutter.config import DEFAULT_CONFIG

    def create_testing_repo(d, name):
        """Create a testing repo at `n`."""
        n = os.path.join(d, name)
        os.mkdir(n)
        os.mkdir(os.path.join(n, 'hello'))
        with open(os.path.join(n, 'hello', 'cookiecutter.json'), 'w') as f:
            f.write('{}')

    def make_testing_directories(d):
        """Create a testing repo at `n`."""
        create_testing_repo(d, 'repo')

# Generated at 2022-06-21 10:54:39.689018
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = os.path.join(os.getcwd(), 'tests', 'fake-repo-pre-render')

    assert repository_has_cookiecutter_json(repo_directory) == True

# Generated at 2022-06-21 10:54:40.607873
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert True

# Generated at 2022-06-21 10:54:52.043402
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abcd.zip') == True # test for .zip extension
    assert is_zip_file('/home/abcd.zip') == True # test with path
    assert is_zip_file('abcd.zip?') == True # test with query
    assert is_zip_file('abcd.ZIP?1234') == True # test with query + fragment
    assert is_zip_file('abcd.ZIP#1234') == True # test with fragment
    assert is_zip_file('abcd.ZIP') == True # test with upper case extension
    assert is_zip_file('http://host.com/file.zip') == True # test for url
    assert is_zip_file('test') == False # test for false
    assert is_zip_file('/home/test') == False # test for

# Generated at 2022-06-21 10:54:57.260582
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    template_dir = 'cookiecutter-pypackage'
    curr_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(curr_dir, template_dir)
    assert repository_has_cookiecutter_json(template_dir)

# Generated at 2022-06-21 10:55:06.023388
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test when repo does not exist
    repo_directory = '/tmp/does_not_exist'

    assert(repository_has_cookiecutter_json(repo_directory) == False)

    # Test when repo exists but cookiecutter.json doesn't
    repo_directory = os.path.join(os.path.dirname(__file__), 'testsubdir')

    assert(repository_has_cookiecutter_json(repo_directory) == False)

    # Test when repo exists and cookiecutter.json exists at root
    repo_directory = os.path.join(os.path.dirname(__file__), 'testsubdir', '.cookiecuttersubdir')

    assert(repository_has_cookiecutter_json(repo_directory) == True)


# Generated at 2022-06-21 10:55:21.576675
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    dir = os.getcwd() + "/tests"
    print("\n** TEST DIR: " + dir)
    print("Repository has cookiecutter.json: " + str(repository_has_cookiecutter_json(dir)))
    dir = os.getcwd() + "/tests/fake_repo_no_config"
    print("** BAD TEST DIR: " + dir)
    print("Repository has cookiecutter.json: " + str(repository_has_cookiecutter_json(dir)))
    dir = os.getcwd() + "/tests/fake_repo_no_dir"
    print("** BAD TEST DIR: " + dir)
    print("Repository has cookiecutter.json: " + str(repository_has_cookiecutter_json(dir)))


# Generated at 2022-06-21 10:55:28.682204
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test for True
    exists = repository_has_cookiecutter_json('./tests/fake-repo-tmpl')
    assert exists

    # Test for False
    notexists = repository_has_cookiecutter_json('./tests/fake-repo-no-tmpl')
    assert notexists

    # Test with None
    nonetype = repository_has_cookiecutter_json(None)
    assert nonetype

# Generated at 2022-06-21 10:55:38.652529
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test the function expand_abbreviations
    """
    # Define custom abbreviations
    abbreviations = {'gh': 'https://github.com/{}.git'}

    # Test the abbreviation with no arguments
    template = 'gh'
    resolved_template = expand_abbreviations(template=template,
                                             abbreviations=abbreviations)
    assert ('https://github.com/{}.git' == resolved_template)

    # Test the abbreviation with argument
    template = 'gh:audreyr/cookiecutter-pypackage'
    resolved_template = expand_abbreviations(template=template,
                                             abbreviations=abbreviations)

# Generated at 2022-06-21 10:55:41.915678
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test function is_repo_url."""
    assert is_repo_url('https://github.com/cookiecutter/cookiecutter.git')



# Generated at 2022-06-21 10:55:52.979185
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('archive.zip') == True
    assert is_zip_file('/home/user/data/archive.zip') == True

    assert is_zip_file('archive.ZIP') == True
    assert is_zip_file('archive.Zip') == True

    assert is_zip_file('data/archive.zip') == True
    assert is_zip_file('data\\archive.zip') == True

    assert is_zip_file('archive.zip.gz') == False
    assert is_zip_file('archive.ZIP.GZ') == False
    assert is_zip_file('archive.tar.zip') == False
    assert is_zip_file('archive.tar.bz2') == False
    assert is_zip_file('archive.tar.tar') == False

# Generated at 2022-06-21 10:56:00.580884
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert is_repo_url('git@example.com:foo/bar.git')
    assert is_repo_url('git://example.com/bar/baz.git')
    assert is_repo_url('https://github.com/foo/bar.git')
    assert not is_repo_url('./foo/bar.git')
    assert not is_repo_url('foo/bar.git')
    assert not is_repo_url('./foo/bar')
    assert not is_repo_url('../foo/bar')
    value_tuple = determine_repo_dir(
        template='./',
        abbreviations={},
        clone_to_dir='/',
        checkout='master',
        no_input=False,
        password=None
    )
    assert value_

# Generated at 2022-06-21 10:56:09.920227
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    repo_directory = os.path.join(tmp_dir, 'repo_dir')
    os.mkdir(repo_directory)
    os.mknod(os.path.join(repo_directory, 'cookiecutter.json'))

    assert repository_has_cookiecutter_json(repo_directory) is True

    os.remove(os.path.join(repo_directory, 'cookiecutter.json'))
    assert repository_has_cookiecutter_json(repo_directory) is False

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-21 10:56:13.616613
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Integration test for repository_has_cookiecutter_json function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        "repos", "fake-repo-tmpl"
    )
    assert repository_has_cookiecutter_json(repo_dir)

# Generated at 2022-06-21 10:56:17.467314
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('this.zip')
    assert is_zip_file('that.ZIP')
    assert not is_zip_file('other')
    assert not is_zip_file('some.file')

# Generated at 2022-06-21 10:56:29.263357
# Unit test for function determine_repo_dir
def test_determine_repo_dir():

    git_repo = 'https://github.com/me/my-repo.git'

    def _repo_has_cookiecutter_json(*args, **kwargs):
        return True

    def _clone_mock(*args, **kwargs):
        return git_repo

    def _is_repo_url_mock(value):
        return True

    abbreviations = {'mit': 'https://github.com/audreyr/cookiecutter-pypackage'}

    # Setup mocked values for clone, is_repo_url and repository_has_cookiecutter_json
    original_repo_has_cookiecutter_json = repository_has_cookiecutter_json
    original_clone = clone
    original_is_repo_url = is_repo_url


# Generated at 2022-06-21 10:56:46.845214
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    clone_to_dir = os.path.abspath(os.path.join('tests', 'test-repos', 'empty'))
    checkout = None
    no_input = False
    password = None
    directory = None

    # Local, existing repository
    template = os.path.abspath('tests/test-repos/localtestrepo')
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == template
    assert cleanup is False
    assert os.path.exists(repo_dir)

    # Local, non-existent repository

# Generated at 2022-06-21 10:56:55.428603
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('/home/duca/cookiecutter-django') == True
    assert repository_has_cookiecutter_json('/home/duca/cookiecutter-django/') == True
    assert repository_has_cookiecutter_json('/home/duca/cookiecutter-django/cookiecutter.json') == False
    assert repository_has_cookiecutter_json('/home/duca/cookiecutter-django/cookiecutter.txt') == False
    assert repository_has_cookiecutter_json('/home/duca/cookiecutter-django/XXX') == False
    assert repository_has_cookiecutter_json('/tmp/abc') == False

# Generated at 2022-06-21 10:57:04.307447
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Test that repository_has_cookiecutter_json returns False when there is no
    cookiecutter.json
    """
    dir_name = os.getcwd()
    assert bool(repository_has_cookiecutter_json(dir_name))
    os.rename('cookiecutter.json', 'cookiecutter.json.bak')
    assert not bool(repository_has_cookiecutter_json(dir_name))
    os.rename('cookiecutter.json.bak', 'cookiecutter.json')



# Generated at 2022-06-21 10:57:15.317280
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test function determine_repo_dir."""
    repo_dir, cleanup = determine_repo_dir(
        template='.',
        abbreviations={},
        clone_to_dir=os.getcwd(),
        checkout='',
        no_input=False,
    )
    assert cleanup == False
    repo_dir, cleanup = determine_repo_dir(
        template='tests/fake-repo-tmpl',
        abbreviations={},
        clone_to_dir=os.getcwd(),
        checkout='',
        no_input=False,
    )
    assert cleanup == False

# Generated at 2022-06-21 10:57:20.778569
# Unit test for function is_zip_file
def test_is_zip_file():
    test_cases = {
        "test.zip": True,
        "test.ZIP": True,
        "test.ZIP.ext": False,
        "zip.exe": False,
        "zip": False,
    }

    for test_case, result in test_cases.items():
        assert(is_zip_file(test_case) == result)


# Generated at 2022-06-21 10:57:24.420664
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test the expand_abbreviations function"""
    abbrevs = {'abbrev': 'prefix/{0}'}
    assert expand_abbreviations('abbrev:test', abbrevs) == 'prefix/test'



# Generated at 2022-06-21 10:57:32.680353
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:57:40.722847
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('my_template.zip')
    assert is_zip_file('http://example.com/my_template.zip')
    assert is_zip_file('git@github.com:my_user/my_template.zip')
    assert is_zip_file('file:///home/johndoe/my_template.zip')
    assert not is_zip_file('my_template')
    assert not is_zip_file('git+git://github.com/my_user/my_template')
    assert not is_zip_file('my_template.tar.gz')


# Generated at 2022-06-21 10:57:45.912419
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert(repository_has_cookiecutter_json("tests/test-repo-pre/") == True)
    assert(repository_has_cookiecutter_json("tests/broken-repo-pre") == False)
    assert(repository_has_cookiecutter_json("tests/broken-repo-post/") == False)

# Generated at 2022-06-21 10:57:49.581201
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('te.st.zip') == True
    assert is_zip_file('test.git') == False

# Generated at 2022-06-21 10:58:15.409921
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("/a/b/c.zip") == True
    assert is_zip_file("c.zip") == True
    assert is_zip_file("/a/b/c.ZIP") == True
    assert is_zip_file("/a/b/c.ZiP") == True
    assert is_zip_file("/a/b/c.ZIP/") == False
    assert is_zip_file("c.ZiP/") == False
    assert is_zip_file("/a/b/c.zipp") == False
    assert is_zip_file("/a/b/c.z") == False
    assert is_zip_file("/a/b/c.zip.txt") == False

# Generated at 2022-06-21 10:58:22.025353
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter.zip')
    assert is_zip_file('cookiecutter.ZIP')
    assert is_zip_file('cookiecutter.ZiP')
    assert is_zip_file('cookiecutter.ZIP123')
    assert not is_zip_file('cookiecutter.zip/cookiecutter.json')
    assert not is_zip_file('cookiecutter.json')
    assert not is_zip_file('/cookiecutter.zip')

# Generated at 2022-06-21 10:58:29.497580
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from tests.test_setuptools import TEST_REPO
    from tests.test_repo_scaffolding import TEST_CHECKOUT
    abbreviations = {}
    clone_to_dir = './'
    checkout = TEST_CHECKOUT
    no_input = False
    password = None
    directory = None
    template = 'git+https://github.com/audreyr/cookiecutter-pypackage.git'

    # This is what I actually need to test.
    # repo_dir, cleanup = determine_repo_dir(
    #     template, abbreviations, clone_to_dir, checkout, no_input, password)
    # print(repo_dir)
    # print(cleanup)
    assert False

    # The rest of this is for debugging purposes.
    # abbreviations = {}
    # clone_

# Generated at 2022-06-21 10:58:31.962064
# Unit test for function is_zip_file
def test_is_zip_file():
    """Unit test that is_zip_file returns correct values."""
    assert is_zip_file("/path/to/some/cookiecutter.zip")
    assert is_zip_file("/path/to/some/cookiecutter.zip")
    assert not is_zip_file("/path/to/some/cookiecutter.tar.gz")
    assert not is_zip_file("/path/to/some/cookiecutter.txt")

# Generated at 2022-06-21 10:58:35.119239
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Given
    template = 'tests/fake-repo-tmpl'

    # When
    res = repository_has_cookiecutter_json(template)

    # Then
    assert res == True



# Generated at 2022-06-21 10:58:38.005500
# Unit test for function is_zip_file
def test_is_zip_file():
    """ Tests for is_zip_file function """
    test_param = 'test.zip'
    zip_file = is_zip_file(test_param)
    if not zip_file:
        raise AssertionError('test.zip was not a recognised zip file')

    test_param = '/path/to/directory/test.zip'
    zip_file = is_zip_file(test_param)
    if not zip_file:
        raise AssertionError('/path/to/directory/test.zip was not a recognised zip file')

# Generated at 2022-06-21 10:58:40.103201
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test function `is_repo_url`."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-21 10:58:41.199909
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('hello_world.zip') == True


# Generated at 2022-06-21 10:58:43.663862
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = os.environ['HOME']
    if os.name == 'nt':
        repo_directory = os.environ['USERPROFILE']
    assert repository_has_cookiecutter_json(repo_directory) == False
    assert repository_has_cookiecutter_json(os.getcwd()) == True


# Generated at 2022-06-21 10:58:49.786936
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh', {'gh': 'https://github.com/{}'}) == \
        'https://github.com/{}'

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                {'gh': 'https://github.com/{}'}) == \
        'https://github.com/audreyr/cookiecutter-pypackage'


# Generated at 2022-06-21 10:59:28.104024
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test for function determine_repo_dir"""
    assert determine_repo_dir("cookiecutter-pypackage", "abbreviations", "clone_to_dir", "checkout", "no_input", "password")

# Generated at 2022-06-21 10:59:36.018491
# Unit test for function is_repo_url
def test_is_repo_url():
    assert True == is_repo_url("git+git://github.com/audreyr/cookiecutter-pypackage.git")
    assert True == is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git")
    assert True == is_repo_url("https://github.com/ndmock/cookiecutter-pypackage-web.git")
    assert True == is_repo_url("git@github.com:ndmock/cookiecutter-pypackage-web.git")

    assert False == is_repo_url("audreyr/cookiecutter-pypackage")
    assert False == is_repo_url("~/audreyr/cookiecutter-pypackage")
    assert False == is_repo_

# Generated at 2022-06-21 10:59:40.813583
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("https://github.com/cookiecutter-django/cookiecutter-django/archive/master.zip")
    assert not is_zip_file("https://github.com/cookiecutter-django/cookiecutter-django/archive/master.tar.gz")


# Generated at 2022-06-21 10:59:49.614061
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('test.ZIP') == True
    assert is_zip_file('test.Zip') == True
    assert is_zip_file('test.zIp') == True
    assert is_zip_file('./test.zip') == True
    assert is_zip_file('test/test.zip') == True
    assert is_zip_file('test\test.zip') == True
    assert is_zip_file('test_test.zip') == True
    assert is_zip_file('http://127.0.0.1:8000/static/file.zip') == True

# Generated at 2022-06-21 10:59:55.959865
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """determine_repo_dir returns the repo dir when it exists"""
    template = 'tests/fixtures/fake-repo-tmpl'
    abbreviations = {}
    clone_to_dir = 'tests/determine_repo_dir-test'
    checkout = None
    no_input = False
    password = None
    directory = None
    repo_dir = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    assert repo_dir[0] == 'tests/fixtures/fake-repo-tmpl'
    assert repo_dir[1] == False

# Generated at 2022-06-21 11:00:05.220498
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(template = "https://github.com/audreyr/cookiecutter-pypackage.git",
                              abbreviations = {},
                              clone_to_dir = '', 
                              checkout = 'master', 
                              no_input = False, 
                              password = None, 
                              directory = None) == ('https://github.com/audreyr/cookiecutter-pypackage.git', False)

# Generated at 2022-06-21 11:00:14.924248
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('https://github.com/audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 11:00:19.177194
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check that we get the appropriate bool returned for the
    repository_has_cookiecutter_json function.
    """
    fake_repo = os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl')
    assert repository_has_cookiecutter_json(fake_repo)



# Generated at 2022-06-21 11:00:25.456766
# Unit test for function is_zip_file
def test_is_zip_file():
    """Check if zip file is detected"""
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip')
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/v0.1.5.zip')
    assert not is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-21 11:00:33.876573
# Unit test for function is_repo_url

# Generated at 2022-06-21 11:01:35.283877
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("tests/foo/bar/baz.zip") == True

# Generated at 2022-06-21 11:01:46.357066
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git+https://example.com')
    assert not is_repo_url('https://.com')
    assert not is_repo_url('file://myserver.com/file')
    assert is_repo_url('git://myserver.com/file')
    assert is_repo_url('ssh://myserver.com/file')
    assert is_repo_url('git@myserver.com:file')
    assert is_repo_url('git@myserver.com')
    assert not is_repo_url('git@myserver.com:')
    assert is_repo_url('git@myserver.com/')
    assert is_repo_url('git@myserver.com/:')

# Generated at 2022-06-21 11:01:54.817731
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git'
    }
    # Test abbreviation with no argument
    input_str = 'gh'
    expected_str = 'https://github.com/.git'
    output_str = expand_abbreviations(input_str, abbreviations)
    assert output_str == expected_str
    # Test abbreviation with argument
    input_str = 'gh:audreyr/cookiecutter-pypackage'
    expected_str = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    output_str = expand_abbreviations(input_str, abbreviations)
    assert output_str == expected_str
    # Test non-abbreviation

# Generated at 2022-06-21 11:02:07.328992
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    result = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == result

    template = 'gh:audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template, abbreviations) == result

    template = 'bb:pydanny/cookiecutter-django'
    result = 'https://bitbucket.org/pydanny/cookiecutter-django.git'

# Generated at 2022-06-21 11:02:15.572469
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'myfork': 'https://github.com/myfork/{}.git',
    }
    # Test not in abbreviation dictionary
    assert expand_abbreviations(template='https://github.com/audreyr/cookiecutter-pypackage.git',
                                abbreviations=abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    # Test in abbreviation dictionary

# Generated at 2022-06-21 11:02:25.661171
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""
    is_repo_url('https://github.com/cookiecutter/cookiecutter') == True
    is_repo_url('git@github.com/audreyr/cookiecutter.git') == True
    is_repo_url(
        '/Users/audreyr/projects/cookiecutter-pypackage/'
    ) == False
    is_repo_url('cookiecutter-pypackage') == False
    is_repo_url('cookiecutter_pypackage') == False
    is_repo_url('audreyr/cookiecutter-pypackage') == False
    is_repo_url('foo.zip') == False

# Generated at 2022-06-21 11:02:32.075025
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('foo.zip')
    assert is_zip_file('.zip')
    assert is_zip_file('')
    assert is_zip_file('bar/foo.zip')
    assert not is_zip_file('bar.zip/foo')
    assert not is_zip_file('foo.zp')
    assert not is_zip_file('zip')
    assert not is_zip_file('bar/foo.zp')
    assert not is_zip_file('bar.zp/foo')
    assert not is_zip_file('foo')


# Generated at 2022-06-21 11:02:37.546422
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = "~/home"
    cookiecutter_json = os.path.join(repo_directory, 'cookiecutter.json')
    os.path.isfile(cookiecutter_json)
    assert repository_has_cookiecutter_json(cookiecutter_json) == True

# Generated at 2022-06-21 11:02:45.092844
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.tests.test_utils.fake_repo_test_dir import (
        zip_url_response,
        zip_url_response_pass,
        fake_mock,
    )

    # test checking a cloned template with a directory
    # location specified
    test_run = determine_repo_dir('tests/fake-repo-tmpl', {}, '.',
                                  None, False, directory='fake-repo-tmpl')
    result_should_be = (os.path.join(os.getcwd(),
                                     'tests', 'fake-repo-tmpl'),
                        False)
    assert test_run == result_should_be

    # test checking an unzipped template
    fake_mock.get(zip_url_response, content=zip_url_response_pass)

# Generated at 2022-06-21 11:02:48.016357
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test for function is_repo_url."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
