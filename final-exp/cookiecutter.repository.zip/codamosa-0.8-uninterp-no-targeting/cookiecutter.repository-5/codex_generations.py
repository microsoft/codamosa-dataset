

# Generated at 2022-06-21 10:53:02.671107
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbrs = dict(
        gh = 'https://github.com/{}.git',
        bb = 'https://bitbucket.org/{}.git',
    )
    assert expand_abbreviations('foo', abbrs) == 'foo'
    assert expand_abbreviations('gh:bar', abbrs) == 'https://github.com/bar.git'
    assert expand_abbreviations('gh:bar/baz', abbrs) == 'https://github.com/bar/baz.git'
    assert expand_abbreviations('bb:bar/baz', abbrs) == 'https://bitbucket.org/bar/baz.git'

# Generated at 2022-06-21 10:53:07.002269
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test to see if function repository_has_cookiecutter_json works"""
    repo_directory = '/home/projects/cookiecutter/'
    assert repository_has_cookiecutter_json(repo_directory) == True


# Generated at 2022-06-21 10:53:18.407372
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:wdm0006/cookiecutter-pypackage-min.git')
    assert is_repo_url('git://github.com/pallets/cookiecutter-flask.git')
    assert is_repo_url('git+https://github.com/pydanny/cookiecutter-djangopackage.git')
    assert is_repo_url('hg+http://bitbucket.org/pokoli/cookiecutter-tryton')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:53:26.385131
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip') == True
    assert is_zip_file('http://127.0.0.1:8080/api/templates/sftp/sftp-user.zip') == True
    assert is_zip_file('../../cookiecutter-templates/sftp-client') == False
    assert is_zip_file('sftp-client') == False
    assert is_zip_file('./sftp-client') == False
    assert is_zip_file('sftp-client.zip') == True


# Generated at 2022-06-21 10:53:29.269212
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    assert repository_has_cookiecutter_json(repo_dir) is False

# Generated at 2022-06-21 10:53:34.023056
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function is_zip_file using valid ZIP file."""
    # Test with a valid ZIP file
    assert is_zip_file("file.zip") == True



# Generated at 2022-06-21 10:53:45.622835
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh', {'gh': 'https://github.com/{}'}) == 'https://github.com/'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{}'}) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'git@github.com:{}.git'}) == 'git@github.com:audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh', {'gh': 'git@github.com:{}.git'}) == 'git@github.com:.git'

# Generated at 2022-06-21 10:53:53.313378
# Unit test for function is_zip_file
def test_is_zip_file():
    """is_zip_file function test."""
    assert not is_zip_file('some string')
    assert not is_zip_file('some.txt')
    assert not is_zip_file('some.tar.gz')
    assert is_zip_file('file.zip')
    assert is_zip_file('folder/file.zip')
    assert is_zip_file('file.ZIP')
    assert is_zip_file('folder/file.ZIP')

# Generated at 2022-06-21 10:53:55.924810
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('foo')

# Generated at 2022-06-21 10:54:04.132439
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/wdm0006/cookiecutter-pypackage.git')
    assert is_repo_url('hg+http://hg.myproject.org/MyProject#egg=MyProject')
    assert is_repo_url('ssh://hg@bitbucket.org/ericsnowcurrently/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:wdm0006/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/wdm0006/cookiecutter-pypackage.git')
    assert is_repo_url('file://localhost/home/user/p/r/o/j/ec/t')
    assert is_repo_

# Generated at 2022-06-21 10:54:16.980576
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from click.testing import CliRunner
    cli_runner = CliRunner()

    template_with_cookiecutter_json = "https://github.com/iory/cookiecutter-jinja2.git"
    with cli_runner.isolated_filesystem():
        output = cli_runner.invoke(
            cli, ['--no-input', template_with_cookiecutter_json], input='\n'.join(
                [
                    'description',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                ]
            )
        )

# Generated at 2022-06-21 10:54:26.227810
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations("foo", {"foo":"bar"}) == "bar"
    assert expand_abbreviations("foo:", {"foo":"bar"}) == "bar:"
    assert expand_abbreviations("foo:bar", {"foo":"baz"}) == "baz:bar"

    assert expand_abbreviations("foo", {}) == "foo"
    assert expand_abbreviations("foo:", {}) == "foo:"
    assert expand_abbreviations("foo:bar", {}) == "foo:bar"

# Generated at 2022-06-21 10:54:29.509941
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/test-repo") == True


# Generated at 2022-06-21 10:54:40.709683
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test function `determine_repo_dir`"""
    # git parse test
    template = "https://github.com/cookiecutter/cookiecutter-pypackage@v0.3.0#egg=cookiecutter-pypackage"
    repo_dir, _ = determine_repo_dir(template)
    assert repo_dir == "cookiecutter-pypackage"
    
    # git parse test
    template = "https://github.com/cookiecutter/cookiecutter-pypackage@v0.3.0"
    repo_dir, _ = determine_repo_dir(template)
    assert repo_dir == "cookiecutter-pypackage@v0.3.0"
    
    # zip parse test

# Generated at 2022-06-21 10:54:43.765334
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('cookiecutter-pypackage')

# Generated at 2022-06-21 10:54:50.890560
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "abbrev"
    abbreviations = {'abbrev':"abbrev"}
    clone_to_dir = "master"
    checkout = "master"
    no_input = False
    password = None
    directory = None
    repo_candidate, cleanup = determine_repo_dir(template, abbreviations, clone_to_dir, checkout, no_input)
    assert repo_candidate == "abbrev"
    assert cleanup == False

# Generated at 2022-06-21 10:54:59.052971
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Validate that `repository_has_cookiecutter_json()` works properly."""
    assert repository_has_cookiecutter_json(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'templates',
            'pymodule',
        )
    )
    assert not repository_has_cookiecutter_json(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'templates',
        )
    )

# Generated at 2022-06-21 10:55:04.780703
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "git@gitlab.com:kirk-dahlgren/vapor-app-seed.git"
    abbreviations = {}
    clone_to_dir = '~/'
    checkout = 'vapor-2.0'
    no_input = False
    directory = None

    directory, cleanup = determine_repo_dir(
    template,
    abbreviations,
    clone_to_dir,
    checkout,
    no_input,
    directory=directory
    )
    print(directory, cleanup)

# Generated at 2022-06-21 10:55:09.088907
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test determine_repo_dir function."""
    # TODO: This function is currently untested.
    # TODO: Add tests for unzipping files.
    # TODO: Add tests for cloning repositories.
    pass

# Generated at 2022-06-21 10:55:15.032151
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('C:\\Users\\Bertolt\\Downloads\\cookiecutter-django-master.zip') == True
    assert is_zip_file('C:\\Users\\Bertolt\\Downloads\\cookiecutter-django-master.rar') == False
    assert is_zip_file('C:\\Users\\Bertolt\\Downloads\\cookiecutter-django-master.tar.gz') == False
    assert is_zip_file('C:\\Users\\Bertolt\\Downloads\\cookiecutter-django-master.tar') == False


# Generated at 2022-06-21 10:55:22.984717
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json using a mock template"""
    test_dir = 'tests/fixtures/'
    test_template = os.path.join(test_dir, 'foobar')
    # Test that repository_has_cookiecutter_json returns true when the template contains
    # a cookiecutter.json file
    assert repository_has_cookiecutter_json(test_template)
    # Test that repository_has_cookiecutter_json returns false when the template does not
    # contain a cookiecutter.json file
    assert not repository_has_cookiecutter_json(test_dir)


# Generated at 2022-06-21 10:55:33.382583
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test the is_repo_url function."""
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@bitbucket.org:brettcannon/cookiecutter-pypackage.git")
    assert is_repo_url("git@bitbucket.org:brettcannon/cookiecutter-pypackage")

# Generated at 2022-06-21 10:55:42.020359
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json method."""
    assert(repository_has_cookiecutter_json("tests/fake-repo-pre/") == True)
    assert(repository_has_cookiecutter_json("tests/fake-repo-post/") == True)
    assert(repository_has_cookiecutter_json("tests/fake-repo-pre-master") == False)
    assert(repository_has_cookiecutter_json("tests/fake-repo-post-master") == False)

# Generated at 2022-06-21 10:55:45.525687
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('hello.zip') == True
    assert is_zip_file('hello.ZIP') == True
    assert is_zip_file('hello.ZiP') == True
    assert is_zip_file('hello.ZiP1') == False


# Generated at 2022-06-21 10:55:52.147896
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    assert repository_has_cookiecutter_json('./tests') is True
    assert repository_has_cookiecutter_json('./cookiecutter') is False
    assert repository_has_cookiecutter_json('./tests/fake-repo-tmpl') is False
    assert repository_has_cookiecutter_json('./tests/fake-repo-tmpl-missing') is False

# Generated at 2022-06-21 10:56:00.160151
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Unit test for function determine_repo_dir.
    """
    current_dir = os.getcwd()
    repo_dir = os.path.join(current_dir, 'tests/fake-repo-pre/')
    abbreviations = dict()
    clone_to_dir = current_dir
    checkout = 'master'
    no_input = False
    directory = None
    repo_dir, is_cleanup = determine_repo_dir(
        template=repo_dir,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        directory=directory,
    )
    assert repo_dir == os.path.join(current_dir, 'tests/fake-repo-pre/')

# Generated at 2022-06-21 10:56:08.012539
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviation_test = {'test_org': 'https://github.com/test_org/{}'}

    assert expand_abbreviations('test_org:foo', abbreviation_test) == 'https://github.com/test_org/foo'
    assert expand_abbreviations('foo', abbreviation_test) == 'foo'
    assert expand_abbreviations('test_org', abbreviation_test) == 'https://github.com/test_org/'


# Generated at 2022-06-21 10:56:12.988440
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    _abbreviations = {
        'gh': 'https://github.com/{}.git',
    }

    assert expand_abbreviations('foo', _abbreviations) == 'foo', \
        'foo not expanded'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                _abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git', \
        'gh: not expanded'

# Generated at 2022-06-21 10:56:14.425358
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("tests/files/example_dir/example.zip") == True

# Generated at 2022-06-21 10:56:18.292994
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # template variable should be a string representing
    # a candidate directory
    template = '/home/username/Documents/Repo/'
    assert repository_has_cookiecutter_json(template)


# Generated at 2022-06-21 10:56:30.308578
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('mytempl:myrepo:mybranch', {}) == 'mytempl:myrepo:mybranch'
    assert expand_abbreviations('mytempl', {'mytempl': 'myrepo:mybranch'}) == 'myrepo:mybranch'
    assert expand_abbreviations('mytempl:myrepo:mybranch', {'mytempl': 'myrepo:mybranch'}) == 'myrepo:mybranch'
    assert expand_abbreviations('mytempl:myrepo:mybranch', {'mytempl': 'myrepo:{}'}) == 'myrepo:mybranch'

# Generated at 2022-06-21 10:56:38.619414
# Unit test for function is_repo_url
def test_is_repo_url():
	assert(is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git'))
	assert(not is_repo_url('./my_format.zip'))
	assert(is_repo_url('my_user_name@github.com/audreyr/cookiecutter-pypackage.git'))
	assert(not is_repo_url('/home/my_user_name/cookiecutter-pypackage'))


# Generated at 2022-06-21 10:56:42.127774
# Unit test for function is_zip_file
def test_is_zip_file():
    """Verify the is_zip_file function."""
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage.git') is False
    assert is_zip_file('some/path.zip') is True

# Generated at 2022-06-21 10:56:48.907017
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check that repository_has_cookiecutter_json() works as expected."""
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') is False
    assert repository_has_cookiecutter_json('tests/fake-repo-pre') is False

    assert repository_has_cookiecutter_json('tests/fake-repo-pre/{{cookiecutter.repo_name}}') is False
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo') is True

    assert repository_has_cookiecutter_json('tests/fake-repo-post') is True

# Generated at 2022-06-21 10:56:54.714822
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    import shutil

    # Test directory that exists, but doesn't contain a cookiecutter.json
    os.mkdir('/tmp/testdir')
    assert (False == repository_has_cookiecutter_json('/tmp/testdir'))

    # Test directory that exists, that does contain a cookiecutter.json
    with open('/tmp/cookiecutter.json', 'w') as fh:
        fh.write('{}')
    assert (True == repository_has_cookiecutter_json('/tmp'))

    # Test non-existent directory
    shutil.rmtree('/tmp/testdir')
    assert (False == repository_has_cookiecutter_json('/tmp/testdir'))

    # Cleanup
    shutil.rmtree('/tmp')

# Generated at 2022-06-21 10:56:57.645259
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    if repository_has_cookiecutter_json('~/cookiecutter/cookiecutter-demo/'):
        return True
    else:
        return False

# Generated at 2022-06-21 10:57:09.819465
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('https://github.com/audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 10:57:18.042991
# Unit test for function repository_has_cookiecutter_json

# Generated at 2022-06-21 10:57:21.489209
# Unit test for function is_zip_file
def test_is_zip_file():
    input = 'tests/files_for_tests/django-slum/cookiecutter.zip'
    actual = is_zip_file(input)
    expected = True
    assert actual == expected

# Generated at 2022-06-21 10:57:25.664722
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Let's make sure the repository is found.
    """
    assert(determine_repo_dir("test_template_test", {}, ".", "",
                              False, directory="test_template_test") ==
           ("test_template_test", False))

# Generated at 2022-06-21 10:57:36.697915
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('file:///home/audreyr/src/cookiecutter-pypackage') == True
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('/home/audreyr/src/cookiecutter-pypackage') == False


# Generated at 2022-06-21 10:57:43.341348
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('foo')

# Generated at 2022-06-21 10:57:53.714518
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test expanding abbreviations and parsing relative paths."""
    abbreviations_mock = {
        'gh': 'https://github.com/{}.git',
        'ghc': 'https://github.com/{0}/{0}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'bbc': 'https://bitbucket.org/{0}/{0}.git',
    }
    assert is_repo_url('gh:audreyr/cookiecutter-pypackage')
    assert is_repo_url('ghc:audreyr/cookiecutter-pypackage')
    assert is_repo_url('bb:audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:58:05.032583
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == True
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('./some/folder') == False
    assert is_repo_url('~/some/folder') == False
    assert is_repo_url('file:///some/folder') == False
    assert is_repo_url('file://C:/some/folder') == False
    assert is_repo_url('file:/some/folder') == False

# Generated at 2022-06-21 10:58:08.147816
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests')
    assert not repository_has_cookiecutter_json('does/not/exist')

# Generated at 2022-06-21 10:58:16.322676
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """ Verify that determine_repo_dir returns the correct repo dir """
    assert determine_repo_dir("https://github.com/audreyr/cookiecutter-pypackage.git", {}, ".", "master", False)[0] != ''
    assert determine_repo_dir("https://github.com/audreyr/cookiecutter-pypackage.git", {}, ".", "master", False)[1] != ''
    assert determine_repo_dir("https://github.com/audreyr/cookiecutter-pypackage.git", {}, ".", "master", False) != None



# Generated at 2022-06-21 10:58:25.795628
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'lp': 'https://launchpad.net/{}.git',
    }
    assert expand_abbreviations("gh:user/project", abbreviations) == \
        "https://github.com/user/project.git"
    assert expand_abbreviations("lp:project/trunk", abbreviations) == \
        "https://launchpad.net/project/trunk.git"
    assert expand_abbreviations("bb:user/repo.git", abbreviations) == \
        "https://bitbucket.org/user/repo.git"
    assert expand_abbreviations("whatever", abbreviations) == "whatever"

# Generated at 2022-06-21 10:58:28.914150
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/tmp") == False
    assert repository_has_cookiecutter_json("/tmp/cookiecutter-pypackage") == True
    

# Generated at 2022-06-21 10:58:34.585785
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('random.zip') == True
    assert is_zip_file('random.zip.zip') == True
    assert is_zip_file('random.txt') == False
    assert is_zip_file('random.tar.gz') == False
    assert is_zip_file('random.ZiP') == True
    assert is_zip_file('.zip') == False

# Generated at 2022-06-21 10:58:39.179882
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    repo = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    abbreviations = {'gh': 'git@github.com:{0}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == repo
# test_expand_abbreviations()

# Generated at 2022-06-21 10:58:54.845593
# Unit test for function is_repo_url
def test_is_repo_url():
    # Assert that is_repo_url returns true when the
    # value passed is a valid repo url
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("hg+https://github.com/audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("hg+https://github.com/audreyr/cookiecutter-pypackage") == True
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git") == True
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git") == True
    assert is_

# Generated at 2022-06-21 10:59:05.901600
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from shutil import rmtree
    from tempfile import mkdtemp
    
    cc_json_content = """
    {
        "full_name": "Your full name",
        "email": "Your email address",
        "repo_name": "Your new project's short name",
        "project_name": "Your new project's short name",
        "project_short_description": "Your new project's short description",
        "release_date": "TODAY"
    }
    """

    with open("cookiecutter.json", "w") as f:
        f.write(cc_json_content)
        
    fake_dir = mkdtemp()
    test_dir = os.path.abspath(".")
    assert repository_has_cookiecutter_json(test_dir) == True
    rmtree

# Generated at 2022-06-21 10:59:16.519856
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Tests the determine_repo_dir function.

    :return: If the determine_repo_dir function works, this function will
        silently return None. Otherwise, an Exception will be raised.
    :raises: An Exception if the determine_repo_dir function does not work.
    """
    import json
    import shutil
    import tempfile
    from cookiecutter.utils import make_sure_path_exists

    # Create a temporary directory to use as the repository.
    repo_dir_path = tempfile.mkdtemp()
    os.chdir(repo_dir_path)

    # Create the cookiecutter.json file in the repository
    json_data = {
        'project_name': 'Test',
        'repo_name': 'Test',
        'owner_name': 'Test',
    }

# Generated at 2022-06-21 10:59:23.361521
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('archive.zip'), 'Zip is detected when it should'

    assert not is_zip_file('.zip'), 'zip is not detected when it should not'
    assert not is_zip_file(''), 'zip is not detected when it should not'
    assert not is_zip_file('no_zip.in_here'), 'zip is not detected when it should not'


# Generated at 2022-06-21 10:59:29.733866
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Test function is_repo_url.
    """
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file://localhost/home/user/cookiecutter-pypackage')
    assert is_repo_url('/home/user/cookiecutter-pypackage') == False


# Generated at 2022-06-21 10:59:36.696857
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations("abbrev", { "abbrev": "expanded/abbrev" }) == "expanded/abbrev"
    assert expand_abbreviations("no-abbrev", { "abbrev": "expanded/abbrev" }) == "no-abbrev"
    assert expand_abbreviations("abbrev:postfix", { "abbrev": "expanded/abbrev/{{cookiecutter.postfix}}" }) == "expanded/abbrev/postfix"
    assert expand_abbreviations("no-abbrev", { "abbrev": "expanded/abbrev/{{cookiecutter.postfix}}" }) == "no-abbrev"

# Generated at 2022-06-21 10:59:46.360646
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('toto.zip') is True, "toto.zip is a zip file"
    assert is_zip_file('toto.ZIP') is True, "toto.ZIP is a zip file"
    assert is_zip_file('toto.ziP') is True, "toto.ziP is a zip file"
    assert is_zip_file('toto.zIp') is True, "toto.zIp is a zip file"
    assert is_zip_file('toto.Zip') is True, "toto.Zip is a zip file"
    assert is_zip_file('toto.ZIP.zip') is True, "toto.ZIP.zip is a zip file"


# Generated at 2022-06-21 10:59:51.113554
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """
    Unit test for repository_has_cookiecutter_json.

    Verifies that it returns the correct value.
    """
    # Test when there is a cookiecutter.json file (True)
    assert repository_has_cookiecutter_json("/home/david/test/test") == True

    # Test when there isn't a cookiecutter.json file (False)
    assert repository_has_cookiecutter_json("/home/david/test") == False

# Generated at 2022-06-21 10:59:59.053348
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function to determine whether a string points to a zip file."""
    test_strings = [
        'templates/test-repo-tmpl',
        './templates/test-repo-tmpl',
        '/home/someuser/templates/test-repo-tmpl',
        'templates/test-repo-tmpl.zip',
        'templates/test-repo-tmpl.ZIP',
    ]

    expected_results = [False, False, False, True, True]

    for test_string, expected_result in zip(test_strings, expected_results):
        assert is_zip_file(test_string) is expected_result



# Generated at 2022-06-21 11:00:07.718032
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Verify determine_repo_dir method."""
    template = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(template) is True

    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = False
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template=template,
        abbreviations={},
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        no_input=no_input,
        password=password,
        directory=directory,
    )
    assert isinstance(repo_dir, str)
    assert isinstance(cleanup, bool)
    assert cleanup == False

# Generated at 2022-06-21 11:00:18.785528
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # A simple test would be to create a temporary directory,
    # create a cookiecutter.json file, pass the path to that directory, and assert that it returns true
    tempdir = os.path.dirname(__file__)
    assert repository_has_cookiecutter_json(tempdir)

# Generated at 2022-06-21 11:00:24.064747
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('some-archive.zip')
    assert is_zip_file('https://some.example.com/ex-archive.zip')
    assert not is_zip_file('file.tar.gz')
    assert not is_zip_file('/some_directory/')
    assert not is_zip_file('git@github.com:example_user/example_repo.git')

# Generated at 2022-06-21 11:00:32.892445
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'foo': 'http://foo.com/{}',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    expanded_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(template,abbreviations) == expanded_template

    template = 'bb:audreyr/cookiecutter-pypackage'
    expanded_template = 'https://bitbucket.org/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template,abbreviations) == expanded_template


# Generated at 2022-06-21 11:00:41.469896
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'dict': '.'
    }
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    template = 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations(template, abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    template = 'bb:audreyr/cookiecutter-pypackage'
    assert expand_abbrevi

# Generated at 2022-06-21 11:00:46.042065
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert not determine_repo_dir("test_repo_dir", 
        {}, "", "", True, directory="")[1]
    assert determine_repo_dir("test_repo_dir", 
        {}, "", "", True, directory="")[1]
    assert not determine_repo_dir("git+https://github.com/obriencj/cookiecutter-pypackage-minimal.git", 
        {}, "", "", True, directory="")[1]

# Generated at 2022-06-21 11:00:55.081926
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    invalid_dir = '/blah/blah/blah/blah/blah'
    assert repository_has_cookiecutter_json(invalid_dir) == False

    invalid_dir = 'tests/test-data/fake-repo/fake-project-1'
    assert repository_has_cookiecutter_json(invalid_dir) == False

    invalid_dir = 'tests/test-data/fake-repo/fake-project-2'
    assert repository_has_cookiecutter_json(invalid_dir) == False

    valid_dir = 'tests/test-data/fake-repo/fake-project-1/fake-project-1'
    assert repository_has_cookiecutter_json(valid_dir) == True


# Generated at 2022-06-21 11:01:02.409524
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test whether the is_zip_file function behaves like expected."""
    assert is_zip_file('hello.zip') == True
    assert is_zip_file('hello.ZIP') == True
    assert is_zip_file('hello.ziP') == True
    assert is_zip_file('hello.zip/') == True
    assert is_zip_file('hello.zip/sub') == True
    assert is_zip_file('hello.zipsub') == False

# Generated at 2022-06-21 11:01:04.128341
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('cookiecutter') == True
    assert repository_has_cookiecutter_json('cookiecutter/blah') == False

# Generated at 2022-06-21 11:01:09.052383
# Unit test for function is_repo_url
def test_is_repo_url():
    """ is_repo_url function unit test.
        For the regex to work correctly, the input should start with an
        http(s)://, so strip that part away before testing.
    """

    assert is_repo_url('https://github.com/pytest-dev/cookiecutter-pytest-plugin')
    assert not is_repo_url('/home/user/archive.zip')
    assert not is_repo_url('./path-to-repo')
    assert not is_repo_url('../path-to-repo')

# Generated at 2022-06-21 11:01:17.364834
# Unit test for function is_zip_file
def test_is_zip_file():
    import sys
    import os
    sys.path.append(os.path.abspath('.'))
    from cookiecutter.repository import is_zip_file
    assert is_zip_file('myfile.zip')==True
    assert is_zip_file('myfile.ZIP')==True
    assert is_zip_file('myfile.zIp')==True
    assert is_zip_file('myfile.zIP')==True
    assert is_zip_file('myfile')==False

# Generated at 2022-06-21 11:01:41.466706
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test if the repository_has_cookiecutter_json function works as intended."""

    # Test with a directory that is not a repository
    path = '/home/user/example/fake_repo'
    assert repository_has_cookiecutter_json(path) == False

    # Test with a directory that is a repository
    path = '/home/user/example/fake_repo'
    assert repository_has_cookiecutter_json(path) == False

# Generated at 2022-06-21 11:01:47.945554
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abr = {'gh':'https://github.com/{}.git'}

    # Test that an abbreviation is expanded, while
    # a string is not affected
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abr) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abr) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 11:01:54.658027
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('Test.zip') == True
    assert is_zip_file('Test.ZIP') == True
    assert is_zip_file('Test.zIp') == True
    assert is_zip_file('Test.ZiP') == True
    assert is_zip_file('Test.ZiP') == True
    assert is_zip_file('.zip') == True
    assert is_zip_file('zip') == False
    assert is_zip_file('zi') == False
    assert is_zip_file('zi.') == False
    assert is_zip_file('.zi') == False


# Generated at 2022-06-21 11:01:59.132475
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test function repository_has_cookiecutter_json."""
    repository_has_cookiecutter_json_value = repository_has_cookiecutter_json('.')
    assert repository_has_cookiecutter_json_value == True

# Generated at 2022-06-21 11:02:03.053546
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Should return True if the directory contains a cookiecutter.json."""
    assert repository_has_cookiecutter_json('boilerplate/cookiecutter-pypackage')


# Generated at 2022-06-21 11:02:12.894175
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert 'https://github.com/{0}/{1}.git'.format('audreyr', 'cookiecutter-pypackage') == expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {
        'gh': 'https://github.com/{0}/{1}.git',
        'bb': 'https://bitbucket.org/{0}/{1}',
    })

# Generated at 2022-06-21 11:02:23.441961
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {}) == 'gh:audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:', {'gh': 'git@github.com:'}) == 'git@github.com:'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', {'gh': 'git@github.com:'}) == 'audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'git@github.com:{}'}) == 'git@github.com:audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 11:02:32.012032
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert (
        expand_abbreviations(template, abbreviations)
        == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    )

    template = 'audreyr/cookiecutter-pypackage'
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    assert expand_abbreviations(template, abbreviations) == template

    template = 'gh:audreyr/another'

# Generated at 2022-06-21 11:02:42.457195
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test for function determine_repo_dir.
    """
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl/') is True
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl-no-json/') is False
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl-no-dir') is False

    no_input = False
    clone_to_dir = 'tests/'
    checkout = None
    abbreviations = {'my_repo': 'https://github.com/hackebrot/cookiecutter-pypackage.git'}

    # Check if repo_dir is local directory
    template = 'tests/fake-repo-tmpl'

# Generated at 2022-06-21 11:02:53.143455
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Make sure we can determine the correct repository directory."""
    from cookiecutter.config import get_user_config

    current_path = os.path.abspath(os.getcwd())
    repo_with_json_dir = os.path.join(current_path, 'tests', 'fake-repo-tmpl')

    # Abbreviations not in use
    template = 'fake-repo-tmpl'
    repo_dir = determine_repo_dir(
        template,
        abbreviations={},
        clone_to_dir=current_path,
        checkout=None,
        no_input=True,
        password=None,
    )
    assert repo_dir == (repo_with_json_dir, False)

    # Abbreviations in use
    template = 'fake'
    repo_