

# Generated at 2022-06-21 10:52:55.833197
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check that repository_has_cookiecutter_json returns True for valid path."""
    assert repository_has_cookiecutter_json('../test-test-test-test')==True


# Generated at 2022-06-21 10:53:02.794281
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:53:06.657220
# Unit test for function is_zip_file
def test_is_zip_file():
    path_to_file = "/Users/joe/Documents/cookies.zip"
    result = is_zip_file(path_to_file)
    assert result == True


# Generated at 2022-06-21 10:53:14.238470
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test function repository_has_cookiecutter_json."""
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/')
    assert (
        not repository_has_cookiecutter_json('tests/fake-repo-pre/fake-repo-pre/')
    )
    assert not repository_has_cookiecutter_json('tests/fake-repo-pre')
    assert not repository_has_cookiecutter_json('')
    assert not repository_has_cookiecutter_json('foobarbaz')

# Generated at 2022-06-21 10:53:18.245303
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('file.ZIP')
    assert not is_zip_file('file.txt')
    assert not is_zip_file('file')


# Generated at 2022-06-21 10:53:24.820425
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    os.mkdir('my_directory')
    assert repository_has_cookiecutter_json('my_directory_2') == False
    assert repository_has_cookiecutter_json('my_directory') == False
    assert repository_has_cookiecutter_json('test') == False

    file = open('test/test.txt', 'w')
    assert repository_has_cookiecutter_json('test') == False
    file.close()

    file2 = open('my_directory/cookiecutter.json', 'w')
    assert repository_has_cookiecutter_json('my_directory') == True
    file2.close()

    assert repository_has_cookiecutter_json('my_directory_2') == False

    assert repository_has_cookiecutter_json('test/') == False


# Generated at 2022-06-21 10:53:29.870426
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    expanded_abbreviations = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert expanded_abbreviations == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 10:53:34.901705
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('something.zip')
    assert is_zip_file('something.cbz')
    assert is_zip_file('something.ZIP')
    assert not is_zip_file('something')


# Generated at 2022-06-21 10:53:40.545962
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage',abbreviations)
    print(template)
    assert template == 'https://github.com/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-21 10:53:44.756619
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('/Users/audreyr/cookiecutter-pypackage')



# Generated at 2022-06-21 10:53:57.895915
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that the function repository_has_cookiecutter_json returns
    True when the directory contains a cookiecutter.json file, and False if not.
    """
    # create a test directory that does not contain a cookiecutter.json file
    import tempfile
    import shutil
    import os
    test_tdir = tempfile.mkdtemp()
    assert not repository_has_cookiecutter_json(test_tdir)
    test_ccfile = os.path.join(test_tdir, 'cookiecutter.json')
    # create a file to test
    open(test_ccfile, 'a').close()
    assert repository_has_cookiecutter_json(test_tdir)
    # remove the test file
    os.remove(test_ccfile)
    # remove the tempdir

# Generated at 2022-06-21 10:54:01.798524
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('foo', {}) == 'foo'
    assert expand_abbreviations('foo', {'foo': 'bar'}) == 'bar'
    assert (
        expand_abbreviations('foo:bar', {'foo': '{0}-repo'}) == 'bar-repo'
    )

# Generated at 2022-06-21 10:54:08.930382
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}

    template = expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations)
    assert(template == 'https://github.com/audreyr/cookiecutter-pypackage.git')

if __name__ == '__main__':
    test_expand_abbreviations()

# Generated at 2022-06-21 10:54:11.918303
# Unit test for function is_zip_file
def test_is_zip_file():
    zip_file = 'abc.zip'
    assert is_zip_file(zip_file)

    not_zip = 'abc.xzp'
    assert not is_zip_file(not_zip)

# Generated at 2022-06-21 10:54:20.182736
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    import os
    if not os.path.exists(os.path.join(os.getcwd(), 'tests', 'fake-repo-tmpl')):
        os.makedirs(os.path.join(os.getcwd(), 'tests', 'fake-repo-tmpl'))
    open(os.path.join(os.getcwd(), 'tests', 'fake-repo-tmpl', 'cookiecutter.json'), 'a').close()

# Generated at 2022-06-21 10:54:28.319678
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Unit test for function repository_has_cookiecutter_json."""
    # A directory containing a .cookiecutter.yaml
    temp_dir = '/tmp/tempdir'
    assert repository_has_cookiecutter_json(temp_dir) == False

    # A directory not containing a .cookiecutter.yaml
    temp_dir = '/tmp/tempdir'
    assert repository_has_cookiecutter_json(temp_dir) == False

# Generated at 2022-06-21 10:54:36.125604
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/foo/bar/baz/cookiecutter-foobar.zip') is True
    assert is_zip_file('https://github.com/some/repo/cookiecutter-foobar.ZIP') is True
    assert is_zip_file('https://github.com/some/repo/cookiecutter-foobar.tar.gz') is False
    assert is_zip_file('https://github.com/some/repo/cookiecutter-foobar.h5') is False


# Generated at 2022-06-21 10:54:40.243678
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:pytest-dev/cookiecutter-pytest-plugin.git')
    assert is_repo_url('https://github.com/pytest-dev/cookiecutter-pytest-plugin.git')

# Generated at 2022-06-21 10:54:50.137827
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    # Test language: regex
    # Test language: Python
    pass

# Generated at 2022-06-21 10:55:01.316370
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'cookiecutter-pypackage'

    template = 'gh:audreyr/cookiecutter-pypackage'
    result = expand_abbreviations(template, abbreviations)
    assert result == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    template = 'bb:jacebrowning/template-python'
    result = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-21 10:55:11.089374
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git") is True
    assert is_repo_url("git+https://github.com/audreyr/cookiecutter-pypackage.git") is True
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git") is True
    assert is_repo_url("cookiecutter-pypackage") is False

# Generated at 2022-06-21 10:55:14.312933
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    test_determine_repo_dir
    """
    # TODO: determine_repo_dir needs to be tested
    # (https://github.com/audreyr/cookiecutter/issues/1188)
    # You are welcome to add tests here!
    pass

# Generated at 2022-06-21 10:55:16.203188
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('test.zip') == True
    assert is_zip_file('test.z') == False

# Generated at 2022-06-21 10:55:18.982149
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/tmp/cookiecutter-simple-python") is True
    assert repository_has_cookiecutter_json("/tmp/cookiecutter-simple-python/cookiecutter.json") is False

# Generated at 2022-06-21 10:55:21.866034
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("my_data.zip")
    assert is_zip_file("my_data.ZIP")
    assert not is_zip_file("my_data.xml")
    assert not is_zip_file("my_data.txt")

# Generated at 2022-06-21 10:55:23.094985
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file("text_file.zip") == True


# Generated at 2022-06-21 10:55:28.076911
# Unit test for function is_zip_file
def test_is_zip_file():
    """
    Test Zip file and not Zip file

    """
    assert is_zip_file('test.zip')
    assert not is_zip_file('test')
    assert not is_zip_file('test.txt')



# Generated at 2022-06-21 10:55:35.553384
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:55:45.678903
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('audreyr@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:55:52.242600
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('a.zip') == True, "Is a .zip file"
    assert is_zip_file('a.ZIP') == True, "Is a .ZIP file"
    assert is_zip_file('a.not zip') == False, "Is not a .zip file"
    assert is_zip_file('a not zip') == False, "Is not a .zip file"

# Generated at 2022-06-21 10:56:01.310202
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip') == True
    assert is_zip_file('http://some.url.com/file.zip') == True
    assert is_zip_file('http://some.url.com/file.txt') == False
    assert is_zip_file('/path/to/file.zip') == True
    assert is_zip_file('/path/to/file.txt') == False
    assert is_zip_file('/path/to/file') == False
    assert is_zip_file('file.zip') == True
    assert is_zip_file('file.txt') == False
    assert is_zip_file('file') == False

# Generated at 2022-06-21 10:56:06.404506
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempdir
    testdir = tempdir.TemporaryDirectory()
    assert not repository_has_cookiecutter_json(testdir.name)

    testdir.create_file('cookiecutter.json', contents='')
    assert repository_has_cookiecutter_json(testdir.name)

# Generated at 2022-06-21 10:56:11.889364
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('cc', {"cc": "cookiecutter-pypackage"}) == "cookiecutter-pypackage"
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {"gh": "https://github.com/{}"}) == "https://github.com/audreyr/cookiecutter-pypackage"
    assert expand_abbreviations('https://github.com/audreyr/cookiecutter-pypackage', {"gh": "https://github.com/{}"}) == "https://github.com/audreyr/cookiecutter-pypackage"

# Generated at 2022-06-21 10:56:16.641007
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {"gh": "https://github.com/{}.git"}
    template = "gh:audreyr/cookiecutter-pypackage"
    assert expand_abbreviations(template, abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git"

# Generated at 2022-06-21 10:56:23.399579
# Unit test for function expand_abbreviations
def test_expand_abbreviations():

    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'gh:audreyr/cookiecutter-pypackage'

    assert expand_abbreviations(template, abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'



# Generated at 2022-06-21 10:56:33.110496
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('file://cookiecutter-django')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+git@github.com:pytest-dev/pytest.git')
    assert is_repo_url('hg+https://bitbucket.org/ubernostrum/django-registration')
    assert is_repo_url('ssh://bitbucket.org/ubernostrum/django-registration')
    assert is_repo_url('git@github.com:pytest-dev/pytest.git')
   

# Generated at 2022-06-21 10:56:44.355624
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # Given
    template = 'test1'
    abbreviations = {'test1': 'test2', 'test2': 'test3:{}'}
    # When
    result = expand_abbreviations(template, abbreviations)
    # Then
    assert result == 'test3:{}'
    # When
    template = 'test2'
    # Then
    result = expand_abbreviations(template, abbreviations)
    assert result == 'test3:{}'
    # When
    template = 'test1:test2'
    # Then
    result = expand_abbreviations(template, abbreviations)
    assert result == 'test3:test2'
    # When
    template = 'test3:test3'
    # Then
    result = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-21 10:56:51.745178
# Unit test for function is_repo_url
def test_is_repo_url():
    test_repo_urls = [
        'file:///my/cool/project',
        'https://www.github.com/user/repo',
        'git+https://www.github.com/user/repo',
        'git@github.com:user/repo',
    ]
    test_not_repo_urls = [
        'file:///my/cool/project/some_file.txt',
        'www.github.com/user/repo',
        'github.com/user/repo',
        '/local/path',
        'file://local/path',
        'local/path',
    ]

    for repo_url in test_repo_urls:
        assert is_repo_url(repo_url) is True

# Generated at 2022-06-21 10:56:54.785511
# Unit test for function is_repo_url
def test_is_repo_url():
    value = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(value) # should be True



# Generated at 2022-06-21 10:57:00.790481
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    repo_direc = os.getcwd()
    repo_direc_exists = os.path.isdir(repo_direc)
    repo_config_exists = os.path.isfile(
        os.path.join(repo_direc, 'cookiecutter.json')
    )

    assert repo_direc_exists and repo_config_exists

# Generated at 2022-06-21 10:57:09.668132
# Unit test for function is_zip_file
def test_is_zip_file():
    assert True == is_zip_file("test.zip")


# Generated at 2022-06-21 10:57:17.994970
# Unit test for function is_repo_url
def test_is_repo_url():
    # Some example git URLs that we want to match
    git_ssh_url = 'git@github.com:audreyr/cookiecutter.git'
    git_ssh_url_with_port = 'git@github.com:audreyr/cookiecutter.git:2200'
    git_http_url = 'https://github.com/audreyr/cookiecutter.git'
    git_https_url = 'git://github.com/audreyr/cookiecutter.git'

    # Make sure that git URL regex matches the above
    assert REPO_REGEX.match(git_ssh_url)
    assert REPO_REGEX.match(git_ssh_url_with_port)
    assert REPO_REGEX.match(git_http_url)

# Generated at 2022-06-21 10:57:28.640010
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'github': 'https://github.com/{}.git',
                     'bitbucket': 'https://bitbucket.com/{}.git'}

    assert expand_abbreviations('github:UserA/repo1', abbreviations) == 'https://github.com/UserA/repo1.git'
    assert expand_abbreviations('https://github.com/UserA/repo1', abbreviations) == 'https://github.com/UserA/repo1'
    assert expand_abbreviations('github.com/UserA/repo1', abbreviations) == 'github.com/UserA/repo1'

# Generated at 2022-06-21 10:57:35.360578
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
    }
    assert expand_abbreviations('cookiecutter-pypackage', abbreviations) == 'cookiecutter-pypackage'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 10:57:46.505758
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    class MockOsPath:
        def __init__(self, isdir_value):
            self.isdir_value = isdir_value
            self.isfile_value = True

        def isdir(self, _):
            return self.isdir_value

        def isfile(self, _):
            return self.isfile_value

        def join(self, *parts):
            return '+'.join(parts)

    class MockOs:
        def __init__(self):
            self.path = MockOsPath(True)

    class MockRepositoryNotFound(Exception):
        pass

    class MockRepo:
        def __init__(self, repo_directory):
            self.repo_directory = repo_directory

    class MockAbbreviations:
        def __init__(self, values):
            self.values

# Generated at 2022-06-21 10:57:55.772212
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:58:06.256486
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == False
    assert is_repo_url('audreyr/cookiecutter-pypackage') == False
    assert is_repo_url('/Users/audreyr/projects/cookiecutter-pypackage') == False
    assert is_repo_url('cookiecutter-pypackage') == False

if __name__ == '__main__':
    test_is_repo_url()

# Generated at 2022-06-21 10:58:14.328792
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    test_expand_abbreviations.result = False
    assert expand_abbreviations("foo/bar", {"foo": "baz"}) == "baz/bar"
    assert expand_abbreviations("foo:bar", {"foo": "baz"}) == "baz:bar"
    assert expand_abbreviations("foo:bar", {"foo": "baz:{}"}) == "baz:bar"
    assert expand_abbreviations("fooz:bar", {"foo": "baz:{}"}) == "fooz:bar"

# Generated at 2022-06-21 10:58:20.115411
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('a.zip') is True
    assert is_zip_file('abc.zip') is True
    assert is_zip_file('abcdef.zip') is True
    assert is_zip_file('.zip') is True
    assert is_zip_file('zip') is False
    assert is_zip_file('zip.tar') is False
    assert is_zip_file('zip.a') is False


# Generated at 2022-06-21 10:58:28.456564
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # Github templates
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    abbreviations = {}
    clone_to_dir = ""
    checkout = ""
    no_input = False
    password = ""
    directory = ""
    repo_candidates = [""]
    cleanup = False

    repo_candidates = ["https://github.com/audreyr/cookiecutter-pypackage.git"]
    cleanup = True
    assert determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    ) == (repo_candidates, cleanup)

    template = "https://github.com/audreyr/cookiecutter-pypackage"
    abbrevi

# Generated at 2022-06-21 10:58:43.526437
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    def check_abbreviation(abbreviations, template, expected_template):
        actual_template = expand_abbreviations(template, abbreviations)
        assert actual_template == expected_template

    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}',
        'do': 'https://git.door43.org/{}.git',
    }
    check_abbreviation(abbreviations, 'https://github.com/audreyr/cookiecutter-pypackage.git', 'https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-21 10:58:54.959017
# Unit test for function is_repo_url
def test_is_repo_url():
    assert not is_repo_url('abc/xyz.html')
    assert not is_repo_url('file:/abc/xyz.html')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url(
        'git+https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url(
        'hg+https://bitbucket.org/pokoli/'
        'cookiecutter-pokoli-sphinx-theme'
    )
    assert is_re

# Generated at 2022-06-21 10:59:06.039717
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('audreyr/cookiecutter-pypackage')
    assert is_repo_url('~/projects/cookiecutter-pypackage')
    assert not is_repo_url('~/projects/cookiecutter-pypackage/')
    assert not is_repo_

# Generated at 2022-06-21 10:59:16.768277
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test that if repo_directory doesn't exist, then repo_directory is False
    repo_directory = "/Users/bex/cookiecutters/cookiecutter"
    if os.path.exists(repo_directory):
        os.remove(repo_directory)
    repo_config_exists = os.path.isfile(
        os.path.join(repo_directory, 'cookiecutter.json')
    )
    assert not repo_config_exists

    # Test that if repo_directory does exist, but doesn't contain a
    # cookiecutter.json file, then repo_directory is False
    os.makedirs("/Users/bex/cookiecutters/cookiecutter")
    repo_directory = "/Users/bex/cookiecutters/cookiecutter"

# Generated at 2022-06-21 10:59:26.626950
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage')
    assert not is_repo_url('yoyo/yoyo-yoyo')

# Generated at 2022-06-21 10:59:28.886289
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test if repo_url is found."""
    value = 'https://github.com/audreyr/cookiecutter-pypackage'
    expected = True
    actual = is_repo_url(value)
    assert actual is True


# Generated at 2022-06-21 10:59:36.570971
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Repository has cookiecutter json."""
    # read file to store_content
    content = ""
    with open(os.path.join('tests', 'test_repo', 'cookiecutter.json')) as f:
        content = f.read()

    # read file to store_fake_content
    fake_content = ""
    with open(os.path.join('tests', 'test_repo', 'fake_cookiecutter.json')) as f:
        fake_content = f.read()

    # create .txt file in tests/test_repo
    txtfile = open(os.path.join('tests', 'test_repo', 'test.txt'), "w+")
    txtfile.write("test")
    txtfile.close()

    # create .git folder in tests/test_re

# Generated at 2022-06-21 10:59:43.559513
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    relative_path = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-cookiecutters',
        'tests',
        'fail_on_no_template'
    )
    absolute_path = os.path.abspath(relative_path)

    assert repository_has_cookiecutter_json(absolute_path) == True
    assert repository_has_cookiecutter_json(absolute_path + "bleh") == False

# Generated at 2022-06-21 10:59:51.050467
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter')
    assert is_repo_url('git+git://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter.git')
    assert is_repo_url('git+ssh://github.com/audreyr/cookiecutter')
    assert is_repo_url('git+git@github.com:audreyr/cookiecutter.git')
    assert is_repo_url('hg+https://github.com/audreyr/cookiecutter')
    assert is_repo_url('ssh://hg@bitbucket.org/audreyr/cookiecutter')

# Generated at 2022-06-21 10:59:57.591804
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url("https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git+https://github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("ssh://git@github.com/audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@github.com:audreyr/cookiecutter-pypackage.git")
    assert is_repo_url("git@bitbucket.org:atlassianlabs/cookiecutter-bitbucket-pipelines.git")

# Generated at 2022-06-21 11:00:18.785400
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('cookiecutter-master.zip') == True
    assert is_zip_file('cookiecutter-master') == False
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip') == True
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master') == False


# Generated at 2022-06-21 11:00:25.408568
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('audreyr/cookiecutter-pypackage')


# Generated at 2022-06-21 11:00:33.807349
# Unit test for function is_repo_url
def test_is_repo_url():
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(repo_url) == True
    assert is_repo_url('file:///Users/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('/Users/audreyr/cookiecutter-pypackage.git') == False
    assert is_repo_url('cookiecutter-pypackage') == False
    assert is_repo_url('file://../cookiecutter-pypackage.git') == True
    assert is_repo_url('~/cookiecutter-pypackage.git') == False

# Generated at 2022-06-21 11:00:38.187056
# Unit test for function is_zip_file
def test_is_zip_file():
    # File with .zip extension
    assert is_zip_file('postcard.zip')
    # File with .ZIP extension
    assert is_zip_file('postcard.ZIP')
    # File with .ziP extension
    assert is_zip_file('postcard.ziP')
    # File with no zip extension
    assert not is_zip_file('postcard.txt')


# Generated at 2022-06-21 11:00:42.548668
# Unit test for function is_zip_file
def test_is_zip_file():
    """Assert that is_zip_file returns true for all .zip files."""
    test_zip_files = [
        'http://some-domain.com/test.zip',
        'zip_file.zip',
        'test/test_zip.zip',
    ]
    for test_zip_file in test_zip_files:
        assert is_zip_file(test_zip_file)



# Generated at 2022-06-21 11:00:44.483114
# Unit test for function is_zip_file
def test_is_zip_file():
    assert(is_zip_file('test.zip') == True)
    assert(is_zip_file('test.tar') == False)

# Generated at 2022-06-21 11:00:46.870427
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    from cookiecutter import utils
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert utils.expand_abbreviations('gh:foo/bar', abbreviations) == 'https://github.com/foo/bar.git'

# Generated at 2022-06-21 11:00:53.642878
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/') == True
    assert repository_has_cookiecutter_json('tests/fake-repo-pre//') == True

    try:
        assert repository_has_cookiecutter_json('fake-repo-tmpl') == False
        assert False
    except:
        assert True

    try:
        assert repository_has_cookiecutter_json('tests/fake-repo-pre') == False
        assert False
    except:
        assert True

# Generated at 2022-06-21 11:01:00.628860
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    # Test positive response:
    if repository_has_cookiecutter_json('/Users/dan/.cookiecutters/cookiecutter-pypackage'):
        print("Test positivo correcto")
    # Test negative response:
    if not repository_has_cookiecutter_json('/Users/dan/.cookiecutters/cookiecutter-pypackage-test'):
        print("Test negativo correcto")

# Generated at 2022-06-21 11:01:01.897495
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("/") == True

# Generated at 2022-06-21 11:01:40.083583
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test that repository_has_cookiecutter_json returns correct value."""
    assert repository_has_cookiecutter_json("tests/fake-repo-tmpl/") == True
    assert repository_has_cookiecutter_json("tests/fake-repo-tmpl/somedir") == False
    assert repository_has_cookiecutter_json("tests/fake-repo-tmpl/somedir*") == False

# Generated at 2022-06-21 11:01:49.889273
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip') == True
    assert is_zip_file('/tmp/abc/abc.zip') == True
    assert is_zip_file('/tmp/abc/abc.ZIP') == True
    assert is_zip_file('/tmp/abc/abc.z.i.p') == True
    assert is_zip_file('/tmp/abc/abc.z.i.p.123') == True
    assert is_zip_file('abc.ZIP') == True
    assert is_zip_file('abc.ZIP.123') == True
    assert is_zip_file('abc.z.i.p') == True
    assert is_zip_file('abc') == False
    assert is_zip_file('123') == False
    assert is_zip_file('abc.z') == False

# Generated at 2022-06-21 11:01:51.786074
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('abc.zip')
    assert not is_zip_file('abc.zip2')


# Generated at 2022-06-21 11:01:59.073452
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/foo/bar.zip')
    assert is_zip_file('https://foo.com/bar/baz.zip')
    assert is_zip_file('\\foo\\bar.zip')
    assert is_zip_file('C:\\foo\\bar.zip')
    assert not is_zip_file('/foo/bar.tar.gz')
    assert not is_zip_file('\\foo\\bar.tar.gz')
    assert not is_zip_file('C:\\foo\\bar.tar.gz')
    assert not is_zip_file('git@github.com/foo/bar.git')
    assert not is_zip_file('git@github.com/foo/bar.git:baz')

# Generated at 2022-06-21 11:02:10.669391
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    # abbreviations for unit testing
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
        "gl": "https://gitlab.com/{}.git"
    }

    # Full template name, no abbreviation
    template = "https://github.com/cookiecutter-django/cookiecutter-django.git"
    expanded_value = expand_abbreviations(template, abbreviations)
    assert(expanded_value == template)

    # Abbreviation found, no format parameter
    template = "gh:cookiecutter-django/cookiecutter-django"
    expanded_value = expand_abbreviations(template, abbreviations)

# Generated at 2022-06-21 11:02:17.188353
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    from cookiecutter.main import cookiecutter
    # test_cookiecutter.spec_projects/'
    template_url = 'https://github.com/cookiecutter/cookiecutter-pypackage.git'
    template_dir = cookiecutter(
        template_url, no_input=True, overwrite_if_exists=True
    )
    test_dir = os.path.dirname(template_dir)
    repo_dir, cleanup = determine_repo_dir(
        template=template_dir,
        abbreviations={'cookiecutter-': 'git+https://github.com/cookiecutter/{}.git'},
        clone_to_dir=test_dir,
        checkout=None,
        no_input=True,
        password=None,
        directory=None,
    )

# Generated at 2022-06-21 11:02:27.964509
# Unit test for function is_repo_url
def test_is_repo_url():
    """Unit test for function is_repo_url."""
    assert is_repo_url('http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('file:///home/user/cookiecutter-pypackage.git')

    assert not is_repo_url('cookiecutter-pypackage')
    assert not is_repo_url('/home/user/cookiecutter-pypackage')

# Generated at 2022-06-21 11:02:38.662217
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {}
    clone_to_dir = '.'
    checkout = 'master'
    no_input = False
    password = None
    directory = None

    # Test zip file
    template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    assert repo_dir == '.cookiecutters/cookiecutter-pypackage-master'
    assert cleanup == True

    # Test zip file with directory
    template = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'

# Generated at 2022-06-21 11:02:45.114407
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Test expand abbreviations"""
    abbreviations = {
        "gh": "https://github.com/{}.git",
        "bb": "https://bitbucket.org/{}.git",
    }

    assert expand_abbreviations("foo", abbreviations) == "foo"
    assert expand_abbreviations("gh:a/b", abbreviations) == "https://github.com/a/b.git"
    assert expand_abbreviations("bb:a/b", abbreviations) == "https://bitbucket.org/a/b.git"
    assert expand_abbreviations("gh:a/b/c", abbreviations) == "https://github.com/a/b/c.git"

# Generated at 2022-06-21 11:02:51.439533
# Unit test for function is_zip_file
def test_is_zip_file():
    templates = [
        '',
        '.zip',
        'file.txt',
        'file.zip',
        'file.ZIP',
        'file.a.b.c.d.zip',
    ]
    results = [False, True, False, True, True, True]
    for template, result in zip(templates, results):
        assert is_zip_file(template) == result
