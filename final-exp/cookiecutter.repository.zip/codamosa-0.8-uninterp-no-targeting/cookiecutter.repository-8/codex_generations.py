

# Generated at 2022-06-21 10:53:03.165496
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage') == False
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git') == True
    assert is_repo_url('https://bitbucket.org/pokoli/cookiecutter-tryton.git') == True

# Generated at 2022-06-21 10:53:14.674326
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 10:53:24.074699
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://{}',
        'bb': 'git@{}:',
        'file': 'file:///{}',
        'user': '{}/{{cookiecutter.repo_name}}',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage', abbreviations) == 'git@audreyr/cookiecutter-pypackage:'
    assert expand_abbreviations('file:foo/bar/baz', abbreviations) == 'file:///foo/bar/baz'

# Generated at 2022-06-21 10:53:33.373468
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # clone zip file that has cookiecutter.json in top level directory
    template = 'gh:audreyr/cookiecutter-pypackage'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = '/tmp'
    checkout = 'master'
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory
    )
    assert repo_dir == '/tmp/cookiecutter-pypackage'
    assert cleanup == False

    # clone zip file that has cookiecutter.json in subdirectory

# Generated at 2022-06-21 10:53:41.044902
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('file.zip')
    assert is_zip_file('file.ZIP')
    assert not is_zip_file('file.zip.xz')
    assert not is_zip_file('file.zipxz')
    assert not is_zip_file('file')
    assert not is_zip_file('file.txt')
    assert not is_zip_file('file.txt.zip')
    assert not is_zip_file('file.txt.ZIP')
    assert not is_zip_file('dir/file.zip')

# Generated at 2022-06-21 10:53:44.289662
# Unit test for function is_zip_file
def test_is_zip_file():
    test_filename = './cookiecutter/tests/test-data/fake-repo-tmpl.zip'
    assert is_zip_file(test_filename)


# Generated at 2022-06-21 10:53:47.088647
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('/path/to/repo/template/template.zip')
    assert not is_zip_file('/path/to/repo/template')



# Generated at 2022-06-21 10:53:58.349867
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Returns True if `repo_directory` contains a `cookiecutter.json` file."""
    template = 'foo'
    abbreviations = {}
    clone_to_dir = 'foo'
    checkout = 'develop'
    no_input = False
    password = None
    directory = None

    repository_candidates = [template, os.path.join(clone_to_dir, template)]
    print(repository_candidates)
    for repo_candidate in repository_candidates:
        if repository_has_cookiecutter_json(repo_candidate):
            return repo_candidate, False


# Generated at 2022-06-21 10:54:06.047276
# Unit test for function is_repo_url
def test_is_repo_url():
    '''Test for is_repo_url()'''
    assert is_repo_url(
        "https://github.com/audreyr/cookiecutter-pypackage.git"
    ) is True
    assert is_repo_url(
        "file://C:\\Users\\audreyr\\Documents\\GitHub\\cookiecutter-pypackage"
    ) is True
    assert is_repo_url(
        "git@github.com:audreyr/cookiecutter-pypackage.git"
    ) is True
    assert is_repo_url(
        "git+git://github.com/audreyr/cookiecutter-pypackage.git"
    ) is True

# Generated at 2022-06-21 10:54:16.299546
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        assert not repository_has_cookiecutter_json(tmpdirname)
        os.mkdir(os.path.join(tmpdirname, "empty"))
        assert not repository_has_cookiecutter_json(
            os.path.join(tmpdirname, "empty")
        )
        assert not os.path.isfile(
            os.path.join(tmpdirname, "empty", "cookiecutter.json")
        )
        open(
            os.path.join(tmpdirname, "empty", "cookiecutter.json"), "w"
        ).close()
        assert not repository_has_cookiecutter_json(
            os.path.join(tmpdirname, "empty")
        )
        assert os.path.isf

# Generated at 2022-06-21 10:54:24.128253
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir(template='https://github.com/foo/bar.git',
                              abbreviations={},
                              clone_to_dir='/tmp',
                              checkout=None,
                              no_input=False,
                              directory=None) == ('/tmp/bar', False)

# Generated at 2022-06-21 10:54:28.263328
# Unit test for function is_zip_file
def test_is_zip_file():
    assert(is_zip_file("myrepo.zip") == True)
    assert(is_zip_file("myrepo.txt") == False)



# Generated at 2022-06-21 10:54:31.290182
# Unit test for function is_zip_file
def test_is_zip_file():
    value = 'cookiecutter-pypackage/tests/test-drive/{{cookiecutter.repo_name}}-master.zip'
    assert is_zip_file(value) == True

# Generated at 2022-06-21 10:54:36.856628
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from tests.test_utils import here
    os.chdir(here('..'))
    # current dir should have a cookiecutter.json
    assert repository_has_cookiecutter_json(here('..'))
    # Parent dir does not have cookiecutter.json
    assert not repository_has_cookiecutter_json(here())

# Generated at 2022-06-21 10:54:42.770595
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    # TODO: This test may not need to be so complete.
    assert determine_repo_dir(
        template='git@github.com:xiongjungithub/cookiecutter-pypackage.git',
        abbreviations={},
        clone_to_dir='/c/tmp',
        checkout=None,
        no_input=False,
        password=None,
        directory=None
    ) == ('/c/tmp/cookiecutter-pypackage', False)



# Generated at 2022-06-21 10:54:54.258241
# Unit test for function is_repo_url
def test_is_repo_url():
    """Verify that is_repo_url() works as expected."""
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@bitbucket.org:pokoli/cookiecutter.git')
    assert is_repo_url('git+http://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')

# Generated at 2022-06-21 10:54:58.959952
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """Test the determine_repo_dir function."""
    assert determine_repo_dir(
        'test', {'test':'test'}, 'test', None, None, 'test', 'test'
    ) == ('test/test', False)

test_determine_repo_dir()

# Generated at 2022-06-21 10:55:01.598658
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = os.getcwd()
    assert(repository_has_cookiecutter_json(repo_directory) == True)



# Generated at 2022-06-21 10:55:03.438064
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert determine_repo_dir == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 10:55:07.598186
# Unit test for function is_zip_file
def test_is_zip_file():
    
    # Given
    file = 'cookiecutter.zip'

    # When
    result = is_zip_file(file)

    # Then
    assert result == True


# Generated at 2022-06-21 10:55:17.796517
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Unit test for function expand_abbreviations."""
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    assert 'bb:owner/repo' == expand_abbreviations('bb:owner/repo', abbreviations)
    assert 'gh:owner/repo' == expand_abbreviations('gh:owner/repo', abbreviations)
    assert 'https://github.com/owner/repo' == expand_abbreviations('gh:owner/repo', abbreviations)
    assert 'https://bitbucket.org/owner/repo' == expand_abbreviations('bb:owner/repo', abbreviations)

# Generated at 2022-06-21 10:55:21.906501
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    repo_dir, cleanup = determine_repo_dir(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        {}, 
        '.', '', False
    )
    assert repo_dir == 'cookiecutter-pypackage'
    #assert cleanup == False



# Generated at 2022-06-21 10:55:30.026612
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """A unit test for funtion determine_repo_dir

    :return: True if the test is successful else False
    """
    try:
        determine_repo_dir(
            template='file:///path/to/local/repo/dir',
            abbreviations={},
            clone_to_dir='/tmp',
            checkout='master',
            no_input=False,
            password=None,
            directory=None,
        )
    except:
        return False
    else:
        return True


# Generated at 2022-06-21 10:55:41.441945
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-21 10:55:52.752994
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'gl': 'https://gitlab.com/{}.git',
    }

    assert expand_abbreviations('foo', abbreviations) == 'foo'

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage',
                                abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

    assert expand_abbreviations('bb:audreyr/cookiecutter-pypackage',
                                abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'


# Generated at 2022-06-21 10:55:54.906209
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('filename.zip')
    assert not is_zip_file('foo')



# Generated at 2022-06-21 10:56:01.260858
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """Unit test for function expand_abbreviations"""
    abbreviations_dict = {'cc': 'https://github.com/foo/{0}.git'}
    testcase1 = expand_abbreviations('cc:bar', abbreviations_dict)
    assert testcase1 == 'https://github.com/foo/bar.git'
    testcase2 = expand_abbreviations('cc:baz', abbreviations_dict)
    assert testcase2 == 'https://github.com/foo/baz.git'

# Generated at 2022-06-21 10:56:08.233958
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{}'}) == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert expand_abbreviations('audreyr/cookiecutter-pypackage', {'gh': 'https://github.com/{}'}) == 'audreyr/cookiecutter-pypackage'

# Generated at 2022-06-21 10:56:11.725003
# Unit test for function is_zip_file
def test_is_zip_file():
    assert True == is_zip_file("abc.zip")
    assert True == is_zip_file("abc.ZIP")
    assert False == is_zip_file("abc.zap")
    assert False == is_zip_file("/var/www/foo/bar/abc.zip")
    assert False == is_zip_file("zip.zip/zip")


# Generated at 2022-06-21 10:56:23.398461
# Unit test for function is_repo_url
def test_is_repo_url():
    """
    Unit test for function is_repo_url
    """
    #repo_urls = ['git+https://github.com/audreyr/cookiecutter-pypackage.git',
    #             'https://github.com/audreyr/cookiecutter-pypackage.git',
    #             'github.com/audreyr/cookiecutter-pypackage.git',
    #             'git@github.com:audreyr/cookiecutter-pypackage.git',

# Generated at 2022-06-21 10:56:31.160935
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    test_path = os.path.dirname(os.path.realpath(__file__))
    test_repo_directory = os.path.join(test_path, "..")
    assert repository_has_cookiecutter_json(test_repo_directory)

# Generated at 2022-06-21 10:56:34.285859
# Unit test for function is_repo_url
def test_is_repo_url():
    url = 'git+git://github.com/audreyr/cookiecutter-pypackage.git'
    assert is_repo_url(url) == True

# Generated at 2022-06-21 10:56:37.513721
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test repository_has_cookiecutter_json."""
    assert repository_has_cookiecutter_json(os.path.dirname(__file__))

# Generated at 2022-06-21 10:56:47.209182
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'gl': 'https://gitlab.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }
    template = 'gh:njainnjain/cookiecutter-github-repo-description.git'
    clone_to_dir = 'cookiecutter'
    checkout = '0.1.0'
    directory = 'test'
    repo_dir, cleanup_dir = determine_repo_dir(
        template=template,
        abbreviations=abbreviations,
        clone_to_dir=clone_to_dir,
        checkout=checkout,
        directory=directory,
    )
    print(f'repo_dir is {repo_dir}')




# Generated at 2022-06-21 10:56:51.269221
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/') == True
    assert is_repo_url('git@github.com') == False
    assert is_repo_url('git@github.com') == False
    assert is_repo_url('file') == False
    assert is_repo_url('file.txt') == False

# Generated at 2022-06-21 10:57:00.088506
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Determine success of function determine_repo_dir
    """
    d1 = determine_repo_dir(template='https://github.com/audreyr/cookiecutter-pypackage',
                            abbreviations={},
                            clone_to_dir='C:\\Users\\akarthi\\AppData\\Local\\Temp',
                            checkout='master',
                            no_input=False,
                            password='1234',
                            directory=None)

    assert d1 == ('C:\\Users\\akarthi\\AppData\\Local\\Temp\\cookiecutter-pypackage', False)

# Generated at 2022-06-21 10:57:12.248636
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
    }

    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations(expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations), abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('gh:', abbreviations) == 'https://github.com/.git'

# Generated at 2022-06-21 10:57:16.739465
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    from cookiecutter import utils

    repo_config_exists = os.path.isfile(
        os.path.join('tests', 'test-repo-tmpl', 'cookiecutter.json')
    )

    repo_dir = utils.get_user_config().get('default_repo')

    assert repository_has_cookiecutter_json(repo_dir) == repo_config_exists

# Generated at 2022-06-21 10:57:22.115770
# Unit test for function is_zip_file
def test_is_zip_file():
    for test_case in ["Python.zip", "my_project.zip",
                      "http://example.com/my_project.zip"]:
        assert is_zip_file(test_case) == True
    assert is_zip_file(".zippo") == False
    assert is_zip_file("Python.ZiP") == True

# Generated at 2022-06-21 10:57:23.284429
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    pass


# Generated at 2022-06-21 10:57:35.040749
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Test for determine_repo_dir.
    """
    import shutil

    # Create a dummy repository for testing.
    dummy_template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fake-repo-preview'
    )

    shutil.copytree(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'fake-repo'
        ),
        dummy_template_dir,
    )

    # Add a cookiecutter.json file to the root of the dummy repo
    fh = open(
        os.path.join(dummy_template_dir, 'cookiecutter.json'), 'w'
    )

# Generated at 2022-06-21 10:57:43.549970
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
  abbreviations = {
    "gh": "https://github.com/{}.git",
    "bb": "https://bitbucket.org/{}.git"
  }
  assert(expand_abbreviations("gh:audreyr/cookiecutter-pypackage", abbreviations) == "https://github.com/audreyr/cookiecutter-pypackage.git")
  assert(expand_abbreviations("bb:audreyr/cookiecutter-pypackage", abbreviations) == "https://bitbucket.org/audreyr/cookiecutter-pypackage.git")

# Generated at 2022-06-21 10:57:45.441000
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('tests/fake-repo-tmpl') == True

# Generated at 2022-06-21 10:57:55.161524
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:58:00.302212
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    template = 'gh:my_user/my_proj'
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations(template, abbreviations) == \
           'https://github.com/my_user/my_proj.git'

# Generated at 2022-06-21 10:58:04.330721
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    if os.path.exists('/tmp/test_repository_has_cookiecutter_json'):
        os.system('rmdir /tmp/test_repository_has_cookiecutter_json')

    directory = '/tmp/test_repository_has_cookiecutter_json'
    os.system('mkdir ' + directory)

    # Verify that the function returns False when the repository directory
    # does not exist.
    assert not repository_has_cookiecutter_json('/tmp/bad_directory')

    # Verify that the function returns False when the repository does not
    # contain a cookiecutter.json file.
    assert not repository_has_cookiecutter_json(directory)

    # Verify that the function returns True when the repository contains
    # a cookiecutter.json file.

# Generated at 2022-06-21 10:58:08.674882
# Unit test for function is_repo_url
def test_is_repo_url():
    url_true = 'https://github.com/audreyr/cookiecutter.git'
    url_false = '/home/audreyr'

    assert is_repo_url(url_true) is True
    assert is_repo_url(url_false) is False
 


# Generated at 2022-06-21 10:58:17.669717
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    os.path.isdir = lambda x: True
    os.path.isfile = lambda x: True
    assert repository_has_cookiecutter_json('/') == True

    os.path.isdir = lambda x: True
    os.path.isfile = lambda x: False
    assert repository_has_cookiecutter_json('/') == False

    os.path.isdir = lambda x: False
    os.path.isfile = lambda x: True
    assert repository_has_cookiecutter_json('/') == False

    os.path.isdir = lambda x: False
    os.path.isfile = lambda x: False
    assert repository_has_cookiecutter_json('/') == False

# Generated at 2022-06-21 10:58:22.708014
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('/tmp/test', abbreviations) == '/tmp/test'

# Generated at 2022-06-21 10:58:30.251384
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    #template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    template = 'https://github.com/tonywu2014/test_cookiecutter/archive/master.zip'
    clone_to_dir = '/Users/tony/Desktop'
    abbreviations = {'tonywu2014': 'github.com/tonywu2014'}
    checkout = ''
    no_input = True
    password = None
    directory = None
    repo_dir, cleanup = determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )
    print("Repo dir: {}".format(repo_dir))
    print("cleanup: {}".format(cleanup))

# Generated at 2022-06-21 10:58:45.389365
# Unit test for function is_repo_url

# Generated at 2022-06-21 10:58:57.732175
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {
        'cc': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'cc-docs': 'https://github.com/audreyr/cookiecutter-pypackage-docs.git'
    }

    assert expand_abbreviations('foo', abbreviations) == 'foo'
    assert expand_abbreviations('cc', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('cc:foo', abbreviations) == \
        'https://github.com/audreyr/cookiecutter-pypackage/foo'

# Generated at 2022-06-21 10:59:00.939136
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = '/Users/danielhauck/GitHub/cookiecutter-pypackage'
    assert repository_has_cookiecutter_json(repo_directory) is True



# Generated at 2022-06-21 10:59:09.943291
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_with_config = '/tmp/cookiecutter-test'
    repo_without_config = '/tmp/cookiecutter-test2'
    if os.path.isfile(repo_with_config):
        os.remove(repo_with_config)
    if os.path.isfile(repo_without_config):
        os.remove(repo_without_config)
    if os.path.exists(repo_with_config):
        os.rmdir(repo_with_config)
    if os.path.exists(repo_without_config):
        os.rmdir(repo_without_config)
    assert(not repository_has_cookiecutter_json(repo_with_config))

# Generated at 2022-06-21 10:59:22.089652
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    '''
    Example
    -------
    >>> test_determine_repo_dir()
    '''
    import shutil

# Generated at 2022-06-21 10:59:26.406898
# Unit test for function is_zip_file
def test_is_zip_file():
    # expected value is True
    assert is_zip_file("../test_files/test-repo.zip")

    # expected value is False
    assert not is_zip_file("../test_files/test-repo")


# Unit test function repository_has_cookiecutter_json

# Generated at 2022-06-21 10:59:30.650222
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json("tests/test-data/fake-repo-tmpl") == True
    assert repository_has_cookiecutter_json("tests/test-data/fake-repo-tmpl-no-json") == False
    assert repository_has_cookiecutter_json("tests/test-data/fake-repo-tmpl-no-dir") == False

# Generated at 2022-06-21 10:59:37.960732
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    template = "/home/user/cookiecutter-pypackage/"
    abbreviations = {"pypackage": "/home/user/cookiecutter-pypackage/"}
    clone_to_dir = "/home/user/"
    checkout = "master"
    no_input = True
    password = None
    directory = None
    exists = os.path.exists(template)
    assert exists == True
    exists = os.path.exists(abbreviations["pypackage"])
    assert exists == True
    exists = os.path.exists(clone_to_dir)
    assert exists == True


# Generated at 2022-06-21 10:59:44.411774
# Unit test for function is_repo_url
def test_is_repo_url():

    # known urls
    assert is_repo_url('git@github.com:foo/bar.git')
    assert is_repo_url('git://github.com/bar/baz.git')
    assert is_repo_url('https://github.com/bar/baz.git')
    assert is_repo_url('https://example.com/foo/bar.git')
    assert is_repo_url('git@bitbucket.org:bar/baz.git')
    assert is_repo_url('https://bitbucket.org/bar/baz.git')
    assert is_repo_url('git@gitorious.org:foo/bar.git')
    assert is_repo_url('https://gitorious.org/foo/bar.git')
    assert is_re

# Generated at 2022-06-21 10:59:53.815890
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url(
        'git+ssh://github.com/audreyr/cookiecutter-pypackage.git'
    )
    assert is_repo_url('hg+ssh://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git@github.com:audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('/some/path/on/my/computer') is False
    assert is_repo_url('my-short-name') is False

# Generated at 2022-06-21 11:00:22.392496
# Unit test for function is_zip_file
def test_is_zip_file():
    assert is_zip_file('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip') == True
    assert is_zip_file('http://example.com/cookiecutter-pypackage-master.zip') == True
    assert is_zip_file('/User/me/Desktop/cookiecutter-pypackage-master.zip') == True
    assert is_zip_file('~/cookiecutter-pypackage-master.zip') == True
    assert is_zip_file('/User/me/Desktop/cookiecutter-pypackage-master.zip') == True
    assert is_zip_file('cookiecutter-pypackage-master.zip') == True

# Generated at 2022-06-21 11:00:31.423746
# Unit test for function is_repo_url
def test_is_repo_url():
    assert(is_repo_url('git+git://git@github.com:audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('git://github.com/audreyr/cookiecutter-pypackage'))
    assert(is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('ssh://github.com/audreyr/cookiecutter-pypackage.git'))
    assert(is_repo_url('file://~/projects/cookiecutter-pypackage'))

# Generated at 2022-06-21 11:00:38.527175
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = 'test'
    checkout = 'master'
    no_input = False
    password = ''
    
    directory = ''
    repo_candidate, cleanup = determine_repo_dir(
        'gh:user/repo', abbreviations, clone_to_dir, checkout, no_input, password, directory)
    assert repo_candidate == os.path.join(clone_to_dir, 'user-repo')
    
    directory = 'path/to'
    repo_candidate, cleanup = determine_repo_dir(
        'gh:user/repo', abbreviations, clone_to_dir, checkout, no_input, password, directory)

# Generated at 2022-06-21 11:00:41.352109
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():

    directory = "/dir/dir2"
    repo_dir = {"dir": directory}
    has_file = repository_has_cookiecutter_json(repo_dir)
    assert has_file, "repository directory is not correct"



# Generated at 2022-06-21 11:00:47.926091
# Unit test for function is_repo_url
def test_is_repo_url():
    """Test regex matching for repository URLs."""

# Generated at 2022-06-21 11:00:55.081872
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Determine the repository directory from a template reference.
    """
    abbreviations = {'gh': 'https://github.com/{}.git'}
    clone_to_dir = 'fake_clone_to_dir'
    checkout = 'fake_checkout'
    no_input = 'fake_no_input'
    password = 'fake_password'
    directory = 'fake_directory'
    template = 'fake_template'
    assert determine_repo_dir(
        template,
        abbreviations,
        clone_to_dir,
        checkout,
        no_input,
        password,
        directory,
    )

# Generated at 2022-06-21 11:00:59.240813
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    cookiecutter_repo = '/Users/audreyr/Documents/projects/cookiecutter'
    assert repository_has_cookiecutter_json(cookiecutter_repo) is True

# Generated at 2022-06-21 11:01:01.939261
# Unit test for function is_zip_file
def test_is_zip_file():
    value = 'C:/Users/kwame/Desktop/cookiecutter.zip'
    if is_zip_file(value):
        print("True")
    else:
        print("False")



# Generated at 2022-06-21 11:01:07.434324
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Test the function repository_has_cookiecutter_json."""
    assert repository_has_cookiecutter_json('tests/fake-repo-pre/')
    assert repository_has_cookiecutter_json('tests/fake-repo-pre')
    assert repository_has_cookiecutter_json('tests/fake-repo-pre-no-slash')
    assert not repository_has_cookiecutter_json('tests/fake-repo-pre-broken')

# Generated at 2022-06-21 11:01:11.280967
# Unit test for function is_zip_file
def test_is_zip_file():
    """Test function."""
    tests = [('test.zip', True), ('test.ZIP', True), ('test.ZiP', True),
             ('test.txt', False), ('testTXT', False), ('test/test.zip', False),
             ('test.zip/test', False), ('test.zip/test/test2', False)]
    for s, ex in tests:
        assert(is_zip_file(s) == ex)


# Generated at 2022-06-21 11:01:56.366593
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    assert repository_has_cookiecutter_json('../tests/fake-repo-tmpl/') == True
    assert repository_has_cookiecutter_json('../tests/fake-repo-pre/') == False
    assert repository_has_cookiecutter_json('../tests/fake-repo-no-cookiecutter-json/') == False
    assert repository_has_cookiecutter_json('../tests/fake-repo-no-config/') == False

# Generated at 2022-06-21 11:02:04.341162
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('git+https://github.com/audreyr/cookiecutter-pypackage.git')
    assert not is_repo_url('/foo/bar/baz.zip')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip')

# Generated at 2022-06-21 11:02:12.063955
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    abbreviations = {'gh': 'https://github.com/{}.git'}
    abbreviations['bitbucket'] = 'https://bitbucket.org/{}.git'
    assert expand_abbreviations('gh:audreyr/cookiecutter-pypackage', abbreviations) == 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert expand_abbreviations('bitbucket:audreyr/cookiecutter-pypackage', abbreviations) == 'https://bitbucket.org/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-21 11:02:15.215772
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    assert (
        determine_repo_dir(
            'https://github.com/drgarcia1986/cookiecutter-pypackage-min',
            {},
            '.',
            '.',
            True
        )[1] is False
    )

# Generated at 2022-06-21 11:02:21.250776
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    repo_directory = os.getcwd() #TODO: This should be mocked

    with open('cookiecutter.json', 'w') as f:
        f.write('{}')

    # assert True!
    assert (repository_has_cookiecutter_json(repo_directory) is True)
    os.remove('cookiecutter.json')

# Generated at 2022-06-21 11:02:30.247259
# Unit test for function expand_abbreviations
def test_expand_abbreviations():
    """
    Test abbreviations expansion.
    """
    abbreviations = {
        'gh': 'https://github.com/{}.git',
        'bb': 'https://bitbucket.org/{}.git',
        'ghe': 'git@github.com:{}.git',
        'bbe': 'ssh://hg@bitbucket.org/{}',
    }

# Generated at 2022-06-21 11:02:40.868291
# Unit test for function determine_repo_dir
def test_determine_repo_dir():
    """
    Determine repo dir
    """
    # Tests
    # Repo URL
    assert repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage')

    # Local repo
    assert repository_has_cookiecutter_json('/home/audreyr/projects/cookiecutter-pypackage')

    # Zip file
    assert repository_has_cookiecutter_json('https://github.com/audreyr/cookiecutter-pypackage/archive/0.1.2.zip')
    assert repository_has_cookiecutter_json('github.com/audreyr/cookiecutter-pypackage/archive/0.1.2.zip')

    # Non-existing

# Generated at 2022-06-21 11:02:48.291999
# Unit test for function is_repo_url
def test_is_repo_url():
    assert is_repo_url('git://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert is_repo_url('User@machinename:path/to/repo.git')
    assert is_repo_url('/Users/audreyr/repos/cookiecutter-pypackage')
    assert not is_repo_url('cookiecutter-pypackage')

# Generated at 2022-06-21 11:02:56.648668
# Unit test for function repository_has_cookiecutter_json
def test_repository_has_cookiecutter_json():
    """Check if repository_has_cookiecutter_json works for all cases."""
    # First check positive cases, where cookiecutter.json file exists
    assert repository_has_cookiecutter_json('tests/test-tmpl') == True
    assert repository_has_cookiecutter_json('tests/test-tmpl-2') == True

    # Now check negative cases, where cookiecutter.json file does not exist
    assert repository_has_cookiecutter_json('tests/test-tmpl-wrong') == False
    assert repository_has_cookiecutter_json('tests/test-tmpl-wrong-2') == False