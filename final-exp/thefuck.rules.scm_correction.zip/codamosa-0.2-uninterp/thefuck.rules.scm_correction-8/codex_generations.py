

# Generated at 2022-06-18 08:44:17.185409
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:21.639456
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:25.640256
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:30.329813
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:34.697711
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:39.433126
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:43.971455
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:50.292146
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository',
                             script='git status'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository',
                             script='git status',
                             script_parts=['git', 'status']))

# Generated at 2022-06-18 08:44:54.839081
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:59.226473
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:06.939462
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:11.114036
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:15.686089
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:19.620079
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:22.613682
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:27.647732
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:32.153757
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))


# Generated at 2022-06-18 08:45:36.687229
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:41.555978
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:43.637085
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:54.580512
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:58.690856
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:03.510023
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))


# Generated at 2022-06-18 08:46:13.222491
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git\n')

# Generated at 2022-06-18 08:46:17.249778
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:22.949750
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:27.580784
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:32.026615
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:36.912790
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:41.271033
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:59.869181
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:05.197872
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-18 08:47:09.240660
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:14.449044
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:18.960983
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:22.990931
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:27.144775
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:31.996419
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:42.341627
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             stderr='abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             stderr='abort: no repository found'))

# Generated at 2022-06-18 08:47:46.454356
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:22.382827
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:26.786365
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:35.162482
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository',
                             script='git status'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository',
                             script='git status',
                             script_parts=['git', 'status']))

# Generated at 2022-06-18 08:48:38.810324
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))

# Generated at 2022-06-18 08:48:42.729335
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:47.891728
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:49.501397
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:53.602623
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:58.105295
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:49:06.107692
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n\n'))

# Generated at 2022-06-18 08:50:19.130232
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:27.579888
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n')
    assert match(command)


# Generated at 2022-06-18 08:50:32.055193
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:36.710216
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:45.168748
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             stderr='abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             stderr='abort: no repository found'))

# Generated at 2022-06-18 08:50:47.995865
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:58.447065
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             'abort: no repository found',
                             'abort: no repository found'))


# Generated at 2022-06-18 08:51:03.133946
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:51:06.121003
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:51:10.077533
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:30.745450
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:34.754866
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:38.347204
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:41.443942
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:45.674838
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:50.900595
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:55.249121
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:54:00.000288
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found!'))


# Generated at 2022-06-18 08:54:03.285707
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:54:07.020915
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))
