

# Generated at 2022-06-18 08:44:23.729756
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n\n'))

# Generated at 2022-06-18 08:44:27.971973
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:32.429153
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:42.896068
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))


# Generated at 2022-06-18 08:44:48.436642
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))


# Generated at 2022-06-18 08:44:53.051891
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:57.429023
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:02.688092
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:07.115116
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:11.303348
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:18.607061
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:21.932962
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:27.373498
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:31.481132
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:36.023614
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:42.196259
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: repository is unrelated'))


# Generated at 2022-06-18 08:45:44.537706
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:47.517260
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:50.790653
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:54.578166
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:05.744091
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:10.249368
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:14.377412
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:23.757168
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git\n')

# Generated at 2022-06-18 08:46:28.501202
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:32.907182
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:37.725074
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:42.060330
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:46.667287
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))


# Generated at 2022-06-18 08:46:50.521845
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:07.781746
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:12.503182
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:17.266891
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:21.363947
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:25.375974
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:29.669389
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:35.296436
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:40.103923
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (y/n)'))
    assert not match(Command('hg status', 'abort: no repository found (y/n)'))


# Generated at 2022-06-18 08:47:44.217046
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:49.071603
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:25.000954
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:30.048293
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))


# Generated at 2022-06-18 08:48:34.933093
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('hg status', 'abort: no repository found (or any of the parent directories): .hg'))


# Generated at 2022-06-18 08:48:39.930745
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found (or any of the parent directories): .hg'))


# Generated at 2022-06-18 08:48:44.712475
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'nothing to commit'))


# Generated at 2022-06-18 08:48:54.123817
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found (or any of the parent directories): .hg'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))


# Generated at 2022-06-18 08:48:59.545731
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found!'))


# Generated at 2022-06-18 08:49:03.284519
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:49:06.534529
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:49:15.242591
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n\n'))

# Generated at 2022-06-18 08:50:27.569230
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))


# Generated at 2022-06-18 08:50:32.054741
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:36.709092
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:41.104937
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:44.522424
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:47.904765
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:50.389453
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:55.253474
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:51:03.210830
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found!'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:51:07.460616
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:30.731732
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:34.752334
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:38.359239
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:43.593047
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:47.267145
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:52.687455
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:56.975434
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:54:00.888722
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:54:03.063613
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))


# Generated at 2022-06-18 08:54:06.239873
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))
