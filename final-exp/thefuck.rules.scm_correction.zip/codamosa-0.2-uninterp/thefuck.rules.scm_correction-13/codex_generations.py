

# Generated at 2022-06-18 08:44:18.173964
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:22.360789
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:26.334790
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:31.099269
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:35.956218
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:40.531015
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:44.648869
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:47.126558
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:51.810555
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:56.430460
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:04.090193
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:08.349182
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:12.636357
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:17.229386
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:20.880750
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'nothing to commit'))


# Generated at 2022-06-18 08:45:26.683211
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no such file or directory'))


# Generated at 2022-06-18 08:45:36.214600
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             'abort: no repository found'))

# Generated at 2022-06-18 08:45:41.113377
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:44.561958
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:47.549096
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:58.691312
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:03.040369
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:12.186814
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))


# Generated at 2022-06-18 08:46:16.319486
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:20.204999
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:25.152965
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:29.639020
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:35.164613
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:39.978534
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:44.363423
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:03.039216
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:06.193710
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:08.640332
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:13.754082
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:23.149456
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))

# Generated at 2022-06-18 08:47:27.309284
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:32.229131
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:42.530059
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n\n'))

# Generated at 2022-06-18 08:47:51.573883
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))


# Generated at 2022-06-18 08:47:55.203764
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:30.617469
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:34.573858
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:39.514878
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))


# Generated at 2022-06-18 08:48:44.282406
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-18 08:48:46.654480
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:52.247083
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found!'))


# Generated at 2022-06-18 08:48:56.222502
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:49:00.893637
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:49:04.446411
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:49:08.782334
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found',
                             stderr='abort: no repository found'))


# Generated at 2022-06-18 08:50:20.264838
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:24.676864
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:28.020689
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:32.629516
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:37.324207
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:41.744584
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:45.071082
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:50.525911
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found!'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:59.033373
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .hg'))


# Generated at 2022-06-18 08:51:04.728211
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'nothing to commit (working directory clean)'))


# Generated at 2022-06-18 08:53:33.557779
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n\n'))

# Generated at 2022-06-18 08:53:37.501559
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:41.156522
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'nothing to commit'))


# Generated at 2022-06-18 08:53:45.357150
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:50.466048
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:54.831121
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:54:02.821590
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))

# Generated at 2022-06-18 08:54:05.406845
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:54:13.769244
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git\n')