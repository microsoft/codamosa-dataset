

# Generated at 2022-06-18 08:44:16.090544
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:20.468599
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:24.591728
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:29.102455
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:33.386338
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:38.278334
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:42.932649
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:45.620255
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:44:51.209233
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n\n'))

# Generated at 2022-06-18 08:44:55.545337
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:02.776308
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:07.161171
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:16.088305
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))


# Generated at 2022-06-18 08:45:19.949237
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:22.831529
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:27.775753
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:31.988058
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:36.511940
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-18 08:45:41.388965
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:45:45.842896
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             stderr='abort: no repository found'))


# Generated at 2022-06-18 08:45:57.056949
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:01.412973
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:05.782867
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:10.295925
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:16.740818
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert match(Command('hg status', 'abort: no repository found in /home/user/project'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:21.737761
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:26.694990
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:31.386688
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:35.658336
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:40.408737
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:46:58.760648
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:02.254849
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:05.462532
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:09.548518
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:15.462918
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found!'))


# Generated at 2022-06-18 08:47:21.474252
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-18 08:47:25.492615
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:29.787021
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:35.475100
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:47:39.792572
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:13.588614
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:23.196963
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n\n\n')
    assert match(command)


# Generated at 2022-06-18 08:48:27.549347
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:31.225671
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:39.978053
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))

# Generated at 2022-06-18 08:48:44.759965
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no such file or directory'))


# Generated at 2022-06-18 08:48:49.599734
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-18 08:48:53.721081
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:48:58.359708
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-18 08:49:02.270294
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:13.426388
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:17.532090
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:21.960146
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:25.547070
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:28.684707
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:33.122826
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:37.845134
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:46.053886
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found', 'abort: no repository found', 'abort: no repository found'))

# Generated at 2022-06-18 08:50:48.698705
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:50:51.073843
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:15.869641
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found',
                             'abort: no repository found'))

# Generated at 2022-06-18 08:53:19.729698
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:22.394462
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:33.359572
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('git status', 'On branch master\nnothing to commit, working directory clean'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: repository C:\\Users\\User\\Documents\\GitHub\\thefuck not found!'))
    assert not match(Command('hg status', 'abort: repository C:\\Users\\User\\Documents\\GitHub\\thefuck not found!\n(use "hg init" to create a new one)'))

# Generated at 2022-06-18 08:53:37.005578
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', ''))
    assert not match(Command('hg status', ''))


# Generated at 2022-06-18 08:53:40.087987
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:44.160378
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:47.943076
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-18 08:53:54.567705
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('hg status', 'abort: no repository found (or any of the parent directories): .hg'))


# Generated at 2022-06-18 08:53:58.757723
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))
