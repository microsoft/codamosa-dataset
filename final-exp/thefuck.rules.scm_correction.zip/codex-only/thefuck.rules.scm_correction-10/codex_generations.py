

# Generated at 2022-06-24 07:07:36.916881
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(Command('git branch', u'fatal: Not a git repository'))
    assert match(Command('hg branch', u'abort: no repository found'))
    assert match(Command('git branch', u'master', u'fatal: Not a git repository'))
    assert match(Command('hg branch', u'master', u'abort: no repository found'))
    assert not match(Command('git branch', u'fatal: Not a git repository (or any of the parent directories): .git '))
    assert not match(Command('hg branch', u'abort: no repository found (or any of the parent directories): .hg'))


# Generated at 2022-06-24 07:07:39.914738
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg pull') == 'git pull'
    assert get_new_command('git add .') == 'hg add .'

# Generated at 2022-06-24 07:07:44.840896
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg commit -am "Foo bar"')
    assert u'git commit -am "Foo bar"' == get_new_command(command)

    command = Command('git status')
    assert u'hg status' == get_new_command(command)

# Generated at 2022-06-24 07:07:47.305216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git branch') == 'hg branch'
    assert get_new_command('git branch test') == 'hg branch test'
    assert get_new_command('hg branch') == 'git branch'
    assert get_new_command('hg branch test') == 'git branch test'

# Generated at 2022-06-24 07:07:50.067236
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('git push origin master')
    assert(get_new_command(command) == 'hg push origin master')

# Generated at 2022-06-24 07:07:54.563220
# Unit test for function match
def test_match():
    assert not match(Command('git', 'asdf'))
    assert not match(Command('hg', 'qwer'))
    assert not match(Command('git', 'fatal: Not a git repository'))
    assert not match(Command('hg', 'abort: no repository found'))



# Generated at 2022-06-24 07:07:56.313431
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit -am 'new commit'") == 'hg commit -am new commit'

# Generated at 2022-06-24 07:07:58.959162
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg status', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-24 07:08:04.042059
# Unit test for function match
def test_match():
    wrong_command = Command('git status', 'fatal: Not a git repository')
    assert match(wrong_command)

    wrong_command = Command('hg log', 'abort: no repository found')
    assert match(wrong_command)

    wrong_command = Command('svn log', 'abort: no repository found')
    assert not match(wrong_command)

    wrong_command = Command('git log', 'abort: no repository found')
    assert not match(wrong_command)



# Generated at 2022-06-24 07:08:07.278288
# Unit test for function match
def test_match():
    assert(match(Command('git status', 'fatal: Not a git repository', None, None, None)))
    assert(not match(Command('git status', 'fatal: Not a git repository', None, None, None)))

# Generated at 2022-06-24 07:08:09.982137
# Unit test for function match
def test_match():
    command = Command(script='git checkout master', stdout='fatal: Not a git repository', stderr='fatal: Not a git repository')
    assert match(command)

# Generated at 2022-06-24 07:08:12.921607
# Unit test for function match
def test_match():
    command = Command("hg", "Not a git repository")
    assert match(command)
    command = Command("git", "Not a git repository")
    assert not match(command)


# Generated at 2022-06-24 07:08:15.122195
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    new_command = get_new_command(command)
    assert 'hg push' in new_command

# Generated at 2022-06-24 07:08:18.638566
# Unit test for function match
def test_match():
    assert match(Command('git branch', '', 'fatal: Not a git repository'))
    assert match(Command('hg branch', '', 'abort: no repository found'))
    assert not match(Command('hg branch', '', 'hg branch'))

# Generated at 2022-06-24 07:08:20.724345
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.wrong_scm import get_new_command
    assert get_new_command(u'git commit') == u'hg commit'

# Generated at 2022-06-24 07:08:23.746380
# Unit test for function match
def test_match():
    output = "fatal: Not a git repository"
    assert match(Command(script="git status", output=output))
    assert not match(Command(script="hg status", output=output))


# Generated at 2022-06-24 07:08:28.725462
# Unit test for function match
def test_match():
    assert match(Command('hg fasd', 'abort: no repository found'))
    assert not match(Command('hg fasd', 'abort: no repository found!'))
    assert match(Command('git fasd', 'fatal: Not a git repository'))
    assert not match(Command('git fasd', 'fatal: Not a girt repository'))

# Generated at 2022-06-24 07:08:30.529336
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'

# Generated at 2022-06-24 07:08:32.289501
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:08:33.672062
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command('')

# Generated at 2022-06-24 07:08:38.600285
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status") == "hg status"
    assert get_new_command("git add test1 test2") == "hg add test1 test2"
    assert get_new_command("git config --global user.name") == "hg config --global user.name"
    assert get_new_command("git config --global user.email") == "hg config --global user.email"


# Generated at 2022-06-24 07:08:43.005016
# Unit test for function get_new_command
def test_get_new_command():
    old_command = u'git commit -m "Test commit"'
    assert get_new_command(old_command) == u'hg commit -m "Test commit"'

    old_command = u'git commit -m "Another test commit"'
    assert get_new_command(old_command) == u'hg commit -m "Another test commit"'

    old_command = u'git add .'
    assert get_new_command(old_command) == u'hg add'

# Generated at 2022-06-24 07:08:46.810025
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git status', '')
    assert not match(command)
    command = Command('hg status', 'abort: no repository found')
    assert match(command)
    command = Command('hg status', '')
    assert not match(command)



# Generated at 2022-06-24 07:08:48.152889
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('gitt push origin master') == 'git push origin master'

# Generated at 2022-06-24 07:08:51.246411
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status -m") == "hg status"
    assert get_new_command("git branch") == "hg branch"
    assert get_new_command("git clone bla bla bla") == "hg clone bla bla bla"

# Generated at 2022-06-24 07:08:53.035216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit") == "hg commit"
    assert get_new_command("git commit -m 'test'") == "hg commit -m 'test'"

# Generated at 2022-06-24 07:08:54.927992
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no repository found'))



# Generated at 2022-06-24 07:08:57.732437
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg add .'

# Generated at 2022-06-24 07:09:01.681345
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git pull") == "hg pull"
    assert get_new_command("git branch") == "hg branch"
    assert get_new_command("git add file.txt") == "hg add file.txt"


# Generated at 2022-06-24 07:09:07.343260
# Unit test for function match
def test_match():
    wrong_command = Command('git status')
    wrong_command.output = 'fatal: Not a git repository'
    assert match(wrong_command)
    hg_wrong_command = Command('hg status')
    hg_wrong_command.output = 'abort: no repository found'
    assert match(hg_wrong_command)
    non_wrong_command = Command('git status')
    non_wrong_command.output = 'On branch master'
    assert not match(non_wrong_command)
    non_wrong_command = Command('hg status')
    non_wrong_command.output = '1 files updated, 0 files merged, 0 files removed, 0 files unresolved'
    assert not match(non_wrong_command)


# Generated at 2022-06-24 07:09:08.923605
# Unit test for function match
def test_match():
    out = 'git: \'fetch\' is not a git command. See \'git --help\''
    assert_true(match(Command('git fetch', out)))



# Generated at 2022-06-24 07:09:11.780204
# Unit test for function match
def test_match():
    assert match(Command('git pull', 'fatal: Not a git repository'))
    assert not match(Command('git pull', 'fatal: You are not currently on a branch'))

# Generated at 2022-06-24 07:09:16.738398
# Unit test for function match
def test_match():

    command_git = Command("git", "git")
    command_hg = Command("hg", "hg")

    # Test : Match
    assert match(command_git) is True
    assert match(command_hg) is True

    # Test : No Match
    assert match(Command("ls", "ls")) is False
    assert match(Command("rm", "rm")) is False



# Generated at 2022-06-24 07:09:22.029952
# Unit test for function match

# Generated at 2022-06-24 07:09:28.078500
# Unit test for function match
def test_match():
    command = Command('git commit -am "fix typos"', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg status', 'abort: no repository found')
    assert match(command)

    command = Command('git commit -am "fix typos"', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg status', 'abort: no repository found')
    assert match(command)


# Generated at 2022-06-24 07:09:33.275241
# Unit test for function match
def test_match():
    assert match(Command('ls', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found in /usr/local (or any parent directory)'))
    assert not match(Command('git status', 'hello world'))
    assert not match(Command('hg status', ''))


# Generated at 2022-06-24 07:09:41.695359
# Unit test for function match
def test_match():
    # Correct match
    command = Command('hg status', 'abort: no repository found')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    # Correct match in case of extra text in command output
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    # Incorrect match_and_apply
    command = Command('git status', 'fatal: repository')
    assert not match(command)

    command = Command('hg status', 'abort:')
    assert not match(command)

    # Incorrect match if command.script_parts does not contain command
    command = Command('hg status -u', 'abort: no repository found')
    assert not match

# Generated at 2022-06-24 07:09:45.504464
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', '', ['git', 'status'])) == 'hg status'
    assert get_new_command(Command('git status', '', '', ['git', 'status', '-v'])) == 'hg status -v'

# Generated at 2022-06-24 07:09:46.480887
# Unit test for function match

# Generated at 2022-06-24 07:09:51.430674
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'git status'))
    assert not match(Command('hg status', 'hg status'))


# Generated at 2022-06-24 07:09:56.879927
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: not a hg repository'))


# Generated at 2022-06-24 07:10:06.393596
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git', ''))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git', '', '', '~/.config/thefuck/rules'))
    assert not match(Command('git status', 'On branch master', ''))
    assert match(Command('hg status', 'abort: no repository found', ''))
    assert match(Command('hg status', 'abort: no repository found!', ''))
    assert not match(Command('hg status', 'diff -r 0000000000000000000000000000000000000000 "--git".hgrc "--hg"..hgignore', ''))

# Generated at 2022-06-24 07:10:12.181366
# Unit test for function match
def test_match():
    commands = [
        u"fatal: Not a git repository (or any of the parent directories): .git",
        u"fatal: Not a git repository (or any of the parent directories): .gitfatal: Not a git repository (or any of the parent directories): .git",
        u"fatal: Not a git repository (or any of the parent directories): .git fatal: Not a git repository (or any of the parent directories): .git",
        u"fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git"]
    for command in commands:
        assert match(DummyCommand(command, u"git"))



# Generated at 2022-06-24 07:10:17.531795
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert(get_new_command(command) == 'hg status')
    command = Command('git add .')
    assert(get_new_command(command) == 'hg add .')
    command = Command('git commit -m "test"')
    assert(get_new_command(command) == 'hg commit -m "test"')

# Generated at 2022-06-24 07:10:20.632249
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git commit') == 'hg commit'
    assert get_new_command('git init') == 'hg init'

# Generated at 2022-06-24 07:10:24.434711
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         ''
                         'fatal: Not a git repository'))
    assert not match(Command('git status',
                             ''
                             'abort: no re'))


# Generated at 2022-06-24 07:10:25.809631
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git status', 'abort: no repository found'))
    assert new_command == 'hg status'

# Generated at 2022-06-24 07:10:28.875340
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git branch --set-upstream-to=origin/master master', 'git@host:~/git', {})) == 'git branch --set-upstream-to=origin/master master' # NOQA

# Generated at 2022-06-24 07:10:34.320186
# Unit test for function match
def test_match():
    assert not match(Command('git branch', output='  branch1\n* branch2'))
    assert match(Command('git branch', output='error: Not a git repository'))
    #assert match(Command('hg branch', output='abort: no repository found'))
    assert match(Command('hg branch', output='abort: no repository found'))
    assert match(Command('git branch', output='error: Not a git repository'))
    #assert match(Command('hg branch', output='abort: no repository found'))



# Generated at 2022-06-24 07:10:43.943321
# Unit test for function get_new_command
def test_get_new_command():
	import os
	import mock
	os.environ["PWD"] = 'tmp/'
	os.environ["HOME"] = 'tmp/'
	with open('tmp/.git', "w") as git_file:
		git_file.write('')
	
	with mock.patch('thefuck.rules.git.wrong_scm_patterns', {'git': 'fatal: Not a git repository'}):
		assert get_new_command('git add') == 'git add'
		assert get_new_command('') == 'git '
		assert get_new_command('add') == 'git add'
	
	os.remove('tmp/.git')
	with open('tmp/.hg', "w") as hg_file:
		hg_file.write('')
	

# Generated at 2022-06-24 07:10:47.682611
# Unit test for function match
def test_match():
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository'))

# Generated at 2022-06-24 07:10:50.070963
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git push') == 'hg push'

# Generated at 2022-06-24 07:10:53.697511
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg branch', '')
    assert get_new_command(command) == 'git branch'
    command = Command('git branch', '')
    assert get_new_command(command) == 'git branch'



# Generated at 2022-06-24 07:11:00.718474
# Unit test for function match
def test_match():
    # Test failed to find a scm directory
    assert match(Command('git status', '')) == False
    # Test found scm directory but it is not the one we are looking for
    assert match(Command('git status', 'fatal: Not a git repository')) == False
    # Test wrong scm and no scm directory
    assert match(Command('hg status', 'abort: no repository found')) == False
    # Test correct scm and scm directory
    assert match(Command('hg status', 'abort: no repository found')) == False


# Generated at 2022-06-24 07:11:03.639235
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'git status')) == 'git status'
    assert get_new_command(Command('hg status', 'hg status')) == 'hg status'

# Generated at 2022-06-24 07:11:06.937771
# Unit test for function match
def test_match():
    from thefuck.shells import shell
    assert match(shell.and_('git', 'cd .', 'fatal: Not a git repository'))
    assert not match(shell.and_('git', 'cd .'))


# Generated at 2022-06-24 07:11:10.057475
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('hg status', 'abort: no repository found', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-24 07:11:16.080357
# Unit test for function match
def test_match():

    import os
    import sys

    output = "fatal: Not a git repository (or any of the parent directories): .git"

    command = type('obj', (object,), {})()
    command.script = "git status"
    command.script_parts = command.script.split(" ")
    command.output = output
    # Mock command.script_parts[0]
    command.script_parts[0] = 'git'
    # Mock Path.is_dir
    prev_is_dir = os.path.isdir
    os.path.isdir = lambda path : True
    # Mock _get_actual_scm
    prev_actual_scm = sys.modules['thefuck.rules.wrong_scm']._get_actual_scm

# Generated at 2022-06-24 07:11:23.357049
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository'))
    assert match(Command('git', 'fatal: Not a git repository')) is False
    assert match(Command('git', 'fatal: Not a git repository')) is False
    assert match(Command('hg', 'abort: no repository found'))
    assert match(Command('hg', 'abort: no repository found')) is False
    assert match(Command('hg', 'abort: no repository found')) is False


# Generated at 2022-06-24 07:11:31.129516
# Unit test for function match
def test_match():
    """
    Function match has to return true if command contains name of any source
    control software and output says that there is no repository.
    It also has to return false if command is correct.
    It also has to return false if command is correct when current directory
    is a git repository.
    """
    assert match(Command('git status', '', ''))
    assert match(Command('git status', '', 'fatal: Not a git repository'))
    assert match(Command('git status', '', 'abort: no repository found'))
    assert match(Command('hg status', '', ''))
    assert match(Command('hg status', '', 'fatal: Not a git repository'))
    assert match(Command('hg status', '', 'abort: no repository found'))

# Generated at 2022-06-24 07:11:32.687618
# Unit test for function get_new_command
def test_get_new_command():
    command = (u'git branch')
    get_new_command(command)
    assert u'hg branch' == get_new_command(command)



# Generated at 2022-06-24 07:11:40.375047
# Unit test for function match
def test_match():
    # Git version
    text_git = "git --git-dir=.git/ log --name-status --date=iso -1    f6bca44\nfatal: Not a git repository (or any of the parent directories): .git\n"
    command_git = Command('git --git-dir=.git/ log --name-status --date=iso -1    f6bca44',
                          text_git,
                          '',
                          ['.hg', '.git'])
    assert match(command_git)

    # Hg version
    text_hg = "hg --debug glog\nabort: no repository found in '/home/hugo/.config/git' (.hg not found)!\n"

# Generated at 2022-06-24 07:11:43.779971
# Unit test for function match
def test_match():
    command = Command('git status')
    assert not match(command)
    command = Command('git add .', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git add .', 'fatal: Not a git repository', 'hg')
    assert not match(command)



# Generated at 2022-06-24 07:11:44.913199
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'hg push'

# Generated at 2022-06-24 07:11:50.899841
# Unit test for function match
def test_match():
    command = Command('git', '', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git', '', 'Not a git repository')
    assert not match(command)
    command = Command('git', '', 'abort: no repository found')
    assert not match(command)
    command = Command('hg', '', 'abort: no repository found')
    assert match(command)
    command = Command('hg', '', 'Not a hg repository')
    assert not match(command)
    command = Command('hg', '', 'fatal: Not a git repository')
    assert not match(command)



# Generated at 2022-06-24 07:11:51.940030
# Unit test for function match
def test_match():
    assert match(Command('git brew home', 'fatal: Not a git repository'))


# Generated at 2022-06-24 07:11:53.846288
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository (or any \
of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master\n\n'))



# Generated at 2022-06-24 07:11:56.944193
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git status', 'error')
    assert not match(command)


# Generated at 2022-06-24 07:12:00.794759
# Unit test for function match
def test_match():
    command = Command('hg status',
                      'abort: no repository found!\n')

    assert match(command)

    command = Command('git status',
                      'fatal: Not a git repository\n')

    assert match(command)


# Generated at 2022-06-24 07:12:08.900381
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', 'fatal: Not a git repository')) == True
    assert match(Command('git commit -m "test"', 'abort: no repository found')) == False
    assert match(Command('hg commit -m "test"', 'abort: no repository found')) == True
    assert match(Command('hg commit -m "test"', 'fatal: Not a git repository')) == False
    assert match(Command('hg commit -m "test"', 'error: no repository found')) == False
    assert match(Command('hg commit -m "test"', 'error: Not a git repository')) == False

# Generated at 2022-06-24 07:12:13.072464
# Unit test for function match
def test_match():
    command_output = Command('git status', stderr=u'fatal: Not a git repository')
    assert match(command_output)
    command_output = Command('git branch', stderr=u'fatal: Not a git repository')
    assert not match(command_output)


# Generated at 2022-06-24 07:12:20.375353
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command({u'script_parts': [u'git', u'commit', u'-m', u'test'], u'env': {}, u'_output_file': u'/var/folders/tv/7t1d2tb14xv6hrd5hn569_1w0000gn/T/thefuck-MzWiFL', u'_code': 1, u'output': u'\\ufefffatal: Not a git repository (or any of the parent directories): .git\\n'}) == u'git commit -m test'

# Generated at 2022-06-24 07:12:22.833630
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='hg add .', output='error: no repository found')) == 'git add .'

# Generated at 2022-06-24 07:12:25.724835
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'fatal: Not a git repository'))
    assert not match(Command('git push origin master', 'Everything up-to-date'))



# Generated at 2022-06-24 07:12:29.835558
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository',
                         ''))
    assert match(Command('hg status',
                         'abort: no repository found',
                         ''))
    assert not match(Command('svn status',
                             'svn: E155007: This client is too old to work',
                             ''))


# Generated at 2022-06-24 07:12:32.530287
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git', '/dev/null', 'fatal: Not a git repository')) == 'hg'

# Generated at 2022-06-24 07:12:35.361973
# Unit test for function match
def test_match():
    new_command = 'git status'
    actual_scm = 'git'
    test_command = Command(new_command, 'fatal: Not a git repository')
    matched = match(test_command)
    assert matched == True


# Generated at 2022-06-24 07:12:39.075354
# Unit test for function match
def test_match():
    command = Command('hg commit', '\n')
    assert match(command)[0] == \
            'hg commit'


# Generated at 2022-06-24 07:12:43.294069
# Unit test for function match
def test_match():
    test_cases = [
        ('sadwqadwq', None), # Test case for no match
        ('git error: foo', True),
        ('git error: foo', False),
        ('fatal: foo', True),
        ('fatal: bar', False),
        ('hg error: foo', True),
        ('hg error: foo', False),
        ('abort: foo', True),
        ('abort: bar', False),
    ]

    for (inp, out) in test_cases:
        assert match(Command(inp, '')) == out

# Generated at 2022-06-24 07:12:44.768685
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git status') == u'hg status'


# Generated at 2022-06-24 07:12:46.980439
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: Not a git repository"))
    assert not match(Command("git status", "nothing_wrong"))



# Generated at 2022-06-24 07:12:49.651032
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git bad command', 'fatal: Not a git repository')) == 'hg bad command'

# Generated at 2022-06-24 07:12:52.076346
# Unit test for function match
def test_match():
    old_get_actual_scm = _get_actual_scm
    _get_actual_scm = lambda: 'git'
    assert not match(Command('git branch', 'fatal: not a git repository', ''))
    assert match(Command('git branch', 'fatal: Not a git repository', ''))
    _get_actual_scm = old_get_actual_scm



# Generated at 2022-06-24 07:12:55.348844
# Unit test for function match
def test_match():
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))

    assert match(Command('git status', 'fatal: Not a git repository'))


# Generated at 2022-06-24 07:12:57.883029
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command("git status", "")
    ) == 'git status'

    assert get_new_command(
        Command("git status", u'fatal: Not a git repository')
    ) == 'hg status'

# Generated at 2022-06-24 07:13:05.440865
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', '')) == True
    assert match(Command('git', 'fatal: Not a git repository', '')) == True
    assert match(Command('hg status', 'fatal: Not a git repository', '')) == False
    assert match(Command('hg', 'abort: no repository found', '')) == True
    assert match(Command('git status', 'fatal: Not a git repository', ''), '') == True
    assert match(Command('git', 'fatal: Not a git repository', '')) == True
    assert match(Command('hg status', 'fatal: Not a git repository', '')) == False
    assert match(Command('hg', 'abort: no repository found', '')) == True


# Generated at 2022-06-24 07:13:13.009449
# Unit test for function match
def test_match():
	# Test case 1: no wrong scm
	wrong_scm_command = Command('git status')
	wrong_scm_command.stdout = 'Hi'

	assert not match(wrong_scm_command)

	# Test case 2: wrong scm
	wrong_scm_command.stdout = 'fatal: Not a git repository'
	wrong_scm_command.script_parts = ['git', 'status']

	assert match(wrong_scm_command)


# Generated at 2022-06-24 07:13:14.826185
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert get_new_command(command) =='hg status'

# Generated at 2022-06-24 07:13:19.644680
# Unit test for function match
def test_match():
    # When actual scm is not executable
    assert not match(Command('git', '', 'fatal: Not a git repository'))
    assert not match(Command('hg', '', 'abort: no repository found'))

    # When actual scm is executable
    assert match(Command('git', '', 'fatal: Not a git repository (fatal)'))
    assert match(Command('hg', '', 'abort: no repository found (abort)'))


# Generated at 2022-06-24 07:13:22.243741
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'bundle install') == u'git bundle install'
    assert get_new_command(u'git stash')

# Generated at 2022-06-24 07:13:25.463091
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))


# Generated at 2022-06-24 07:13:27.120957
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg commit')) == 'git commit'

# Generated at 2022-06-24 07:13:28.469072
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == u'hg status'

# Generated at 2022-06-24 07:13:30.931559
# Unit test for function match
def test_match():
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('git status', 'fatal: Not a git repository'))


# Generated at 2022-06-24 07:13:32.886052
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found in subdirectory'))


# Generated at 2022-06-24 07:13:35.700278
# Unit test for function match
def test_match():
    command = Command('git status', 'git status\nfatal: Not a git repository (or any of the parent directories): .git\n')

    assert match(command)



# Generated at 2022-06-24 07:13:38.385444
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command("git config user.name", "fatal: Not a git repository")) == \
           "hg config user.name"

# Generated at 2022-06-24 07:13:40.411057
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("scm from repo", "output")
    assert get_new_command(command) == "actual_scm from repo"

# Generated at 2022-06-24 07:13:47.590711
# Unit test for function match
def test_match():
    # Should return false if no git/hg command is invoked
    assert match(Command('ls', '')) == False

    # Should return false if command is successfull
    assert match(Command('git status', '')) == False
    assert match(Command('hg status', '')) == False

    # Should return true if command is unsuccessfull
    assert match(Command('git status', 'fatal: Not a git repository')) == True
    assert match(Command('git status', 'abort: no repository found')) == True


# Generated at 2022-06-24 07:13:51.054297
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository',
                         path='/tmp/test'))

    assert not match(Command('git status',
                 'fatal: Not a git repo',
                 path='/tmp/test'))


# Generated at 2022-06-24 07:13:53.545756
# Unit test for function match
def test_match():
    command = Command('git status')
    command.output = 'fatal: Not a git repository'
    assert match(command)
    command.output = 'abort: no repository found'
    assert not match(command)
    command.output = ''
    assert not match(command)


# Generated at 2022-06-24 07:13:55.666811
# Unit test for function match
def test_match():
    # If match return True, we would get_new_command and change command.
    # If match return False, we would not get_new_command and do nothing.
    command = 'git push origin master'
    match = match(command)
    assert match == True



# Generated at 2022-06-24 07:13:57.624853
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:14:01.540629
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git push origin dev', 'fatal: No'
         'repository found.')) == 'git push origin dev'
    assert get_new_command(Command('hg push origin dev', 'abort: No'
         'repository found.')) == 'hg push origin dev'

# Generated at 2022-06-24 07:14:04.706182
# Unit test for function match
def test_match():
    # Check if scm specified is wrong
    assert match(Command('git status', 'fatal: Not a git repository'))
    # Check if scm specified is right
    assert not match(Command('git status', 'On branch master'))



# Generated at 2022-06-24 07:14:09.432763
# Unit test for function match
def test_match():
    """
        test for function match
    """
    for scm in wrong_scm_patterns.keys():
        assert match(Command("git please", "fatal: Not a git repository"))
        assert match(Command("hg please", "abort: no repository found"))
    assert not match(Command("cvs please", "", ""))


# Generated at 2022-06-24 07:14:16.552117
# Unit test for function match
def test_match():
    assert match(Command('git checkout origin/master', 'fatal: Not a git repository'))
    assert match(Command('git push', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git checkout origin/master', ''))
    assert not match(Command('git push', ''))
    assert not match(Command('git status', ''))
    assert not match(Command('hg checkout origin/master', ''))
    assert not match(Command('hg push', ''))
    assert not match(Command('hg status', ''))
    assert match(Command('hg checkout origin/master', 'abort: no repository found'))
    assert match(Command('hg push', 'abort: no repository found'))

# Generated at 2022-06-24 07:14:20.579351
# Unit test for function match
def test_match():
    assert match(Command(script='git', output='fatal: Not a git repository'))
    assert match(Command(script='hg', output='abort: no repository found'))
    assert not match(Command(script='git', output='git status'))
    assert not match(Command(script='hg', output='hg status'))
    assert not match(Command(script='ls', output='ls'))


# Generated at 2022-06-24 07:14:26.701125
# Unit test for function match
def test_match():
    assert not match(Command(script='git', output='fatal: Not a git repository'))
    assert not match(Command(script='hg', output='fatal: Not a git repository'))
    assert not match(Command(script='git', output='abort: no repository found'))
    assert not match(Command(script='hg', output='abort: no repository found'))
    assert match(Command(script='git', output='fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command(script='hg', output='abort: no repository found (.hg not found in /whatever/)'))


# Generated at 2022-06-24 07:14:29.295341
# Unit test for function match
def test_match():
    assert match(Command('git commit -m ""', 'fatal: Not a git repository'))
    assert not match(Command('git commit -m ""', 'Correct message'))
    assert match(Command('hg tag', 'abort: no repository found'))
    assert not match(Command('hg tag', 'usage: hg tag ...'))


# Generated at 2022-06-24 07:14:32.498586
# Unit test for function get_new_command
def test_get_new_command():
    if _get_actual_scm() == 'hg':
        assert get_new_command('git push origin') == 'hg push origin'
    else:
       assert get_new_command('git push origin') == 'git push origin'

# Generated at 2022-06-24 07:14:36.532783
# Unit test for function get_new_command
def test_get_new_command():
    scm = 'git'
    assert get_new_command(u'hg commit -m "lol"') == u'git commit -m "lol"'
    assert get_new_command(u'git commit') == u'git commit'

# Generated at 2022-06-24 07:14:41.100212
# Unit test for function match
def test_match():
    command = Command('git status',
                      'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

    command = Command('hg status',
                      'abort: no repository found in \'C:\\Users\\ajay\\Documents\' (.hg not found)!\n')
    assert match(command)


# Generated at 2022-06-24 07:14:45.420671
# Unit test for function match
def test_match():
    assert match(Command('git push',
        u'fatal: Not a git repository (or any of the parent directories): .git\n')
    ) == True
    assert match(Command('hg push',
        'abort: no repository found in')
    ) == True
    assert match(Command('git push',
        'Updating e1ea04..d8f37a6\n')
    ) == False



# Generated at 2022-06-24 07:14:50.006415
# Unit test for function get_new_command
def test_get_new_command():
    # Test if the new command is changed to the right one
    assert get_new_command(command=Command('git stash', 'fatal: Not a git repository')) == 'hg stash'
    # Test if the new command is not changed to the wrong one
    assert get_new_command(command=Command('git stash', 'fatal: Not a git repository')) != 'git stash'
    # Test if the new command is not changed to the wrong one
    assert get_new_command(command=Command('git stash', 'fatal: Not a git repository')) != 'hg pull'



# Generated at 2022-06-24 07:14:54.980553
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: Not a git repository'))
    assert match(Command('hg push', 'abort: no repository found'))
    assert not match(Command('git push', 'fatal: Not a hg repository'))
    assert not match(Command('hg push', 'abort: no git repository found'))


# Generated at 2022-06-24 07:14:59.543799
# Unit test for function match
def test_match():
    assert match(Command('git.exe')) is False
    assert match(Command('git.exe status', error='fatal: Not a git repository')) is True
    assert match(Command('git.exe status', error='fatal: Not a git repository (or any of the parent directories): .git')) is True
    assert match(Command('git.exe status', error='fatal: Not a git repository (or any of the parent directories)')) is False


# Generated at 2022-06-24 07:15:01.459744
# Unit test for function match
def test_match():
    assert match(Command('git add file'))
    assert not match(Command('git init'))



# Generated at 2022-06-24 07:15:04.893016
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\ngit: \'status\' is not a git command. See \'git --help\'.\n')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:15:08.737517
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(('git', 'commit', '-m', 'fix')) == 'hg commit -m fix'
    assert get_new_command(('hg', 'diff', '-c', '-1')) == 'git diff -c -1'

# Generated at 2022-06-24 07:15:11.911390
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    new_command = get_new_command(Command('git status', 'fatal: Not a git repository', '', '', '', ''))
    assert new_command == 'hg status'

# Generated at 2022-06-24 07:15:14.815767
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status',
                                    stdout='fatal: Not a git repository (or any of the parent directories): .git\n')) == 'hg status'

# Generated at 2022-06-24 07:15:17.954148
# Unit test for function match
def test_match():
    assert match(Command('git branch', output=u'fatal: Not a git repository'))
    assert match(Command('hg branch', output=u'abort: no repository found'))

# Generated at 2022-06-24 07:15:19.634354
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git checkout --') == 'hg checkout --'

# Generated at 2022-06-24 07:15:22.902410
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command(script='git stash pop', output='fatal: Not a git repository')
    assert get_new_command(test_command) == 'hg stash pop'



# Generated at 2022-06-24 07:15:30.771691
# Unit test for function match
def test_match():
    assert match(Command(script='git log', output=u'fatal: Not a git repository')) == True
    assert match(Command(script='git log', output=u'abort: no repository found')) == False
    assert match(Command(script='hg log', output=u'fatal: Not a git repository')) == False
    assert match(Command(script='hg log', output=u'abort: no repository found')) == True
    assert match(Command(script='python log', output=u'fatal: Not a git repository')) == False
    assert match(Command(script='python log', output=u'abort: no repository found')) == False

# Generated at 2022-06-24 07:15:32.254834
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -a') == 'hg commit -a'



# Generated at 2022-06-24 07:15:34.117534
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git status', 'fatal: Not a git repository'))
            == u'git status')

# Generated at 2022-06-24 07:15:36.617408
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg update', stderr=u'abort: no repository found')
    # If the actual scm is git it should be changed to git
    assert get_new_command(command) == u'git update'


# Generated at 2022-06-24 07:15:40.542800
# Unit test for function match
def test_match():
    assert not match(Command('git status'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))



# Generated at 2022-06-24 07:15:43.382838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff') == 'git diff'
    assert get_new_command('hg diff') == 'hg diff'

# Generated at 2022-06-24 07:15:46.832620
# Unit test for function match
def test_match():
    assert (match(Command('git init', 'fatal: Not a git repository')))
    assert (match(Command('hg status', 'abort: no repository found')))
    assert not match(Command('git init'))
    assert not match(Command('hg status'))

# Generated at 2022-06-24 07:15:48.709451
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_to_hg import get_new_command

    assert get_new_command("git status") == 'hg status'

# Generated at 2022-06-24 07:15:52.665835
# Unit test for function match
def test_match():
    assert match(Command('git branch', '', 'fatal: Not a git repository'))
    assert match(Command('hg branch', '', 'abort: no repository found'))
    assert not match(Command('git branch', '', '* master'))
    assert not match(Command('hg branch', '', 'default'))
    assert not match(Command('inspect branch', '', 'inspect branch'))


# Generated at 2022-06-24 07:15:55.641700
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2 file3', 'fatal: Not a git repository'))
    assert match(Command('hg add file1 file2 file3', 'abort: no repository found'))
    assert not match(Command('git add file1 file2 file3', 'file1 file2 file3'))
    assert not match(Command('hg add file1 file2 file3', 'file1 file2 file3'))


# Generated at 2022-06-24 07:15:57.894911
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    assert get_new_command(command).startswith('hg')

# Generated at 2022-06-24 07:15:59.994572
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git test', {'git': 'test'}) == 'test'

# Generated at 2022-06-24 07:16:05.524166
# Unit test for function match
def test_match():
    command = Command('git status', '/home/test', 'git: fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command) == True
    command = Command('git status', '/home/test', 'test: abort: no repository found in /home/test')
    assert match(command) == True
    command = Command('git status', '/home/test', 'test: abort: no repository found')
    assert match(command) == False


# Generated at 2022-06-24 07:16:07.330573
# Unit test for function match
def test_match():
    assert match(Command('git add', 'fatal: Not a git repository'))
    assert match(Command('hg add', 'abort: no repository found'))


# Generated at 2022-06-24 07:16:16.377403
# Unit test for function match
def test_match():
    assert match(Command('git commit',
                         'fatal: Not a git repository',
                         '',
                         '/home/user/dir'))
    assert not match(Command('git commit',
                             '',
                             '',
                             '/home/user/dir'))
    assert not match(Command('hg commit',
                             '',
                             '',
                             '/home/user/dir'))
    assert match(Command('hg commit',
                         'abort: no repository found',
                         '',
                         '/home/user/dir'))
    assert not match(Command('hg commit',
                             '',
                             '',
                             '/home/user/dir'))


# Generated at 2022-06-24 07:16:18.372557
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git branch')) == 'hg branch'

# Generated at 2022-06-24 07:16:20.959089
# Unit test for function match
def test_match():
    command = Command('git init', 'fatal: Not a git repository')
    assert match(command)

# Generated at 2022-06-24 07:16:23.372036
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg add', 'abort: no repository found!')
    assert get_new_command(command) == 'git add'


priority = 1000

# Generated at 2022-06-24 07:16:25.773311
# Unit test for function get_new_command
def test_get_new_command():
    scm = 'git'

    assert get_new_command('git status') == 'git status'
    assert get_new_command('git vcs') == 'git vcs'

# Generated at 2022-06-24 07:16:31.525027
# Unit test for function match
def test_match():
    assert match(Command('git commit', 'fatal: Not a git repository'))
    assert match(Command('git commit', 'nonsense')) is False
    assert match(Command('hg commit', 'abort: no repository found'))
    assert match(Command('hg commit', 'nonsense')) is False
    assert match(Command('svn commit', 'nonsense')) is False

# Unit tests for function get_new_command

# Generated at 2022-06-24 07:16:35.479790
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg clone https://github.com/nvbn/thefuck')
    assert get_new_command(command) == 'git clone https://github.com/nvbn/thefuck'


# Generated at 2022-06-24 07:16:37.249715
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git pull origin master') == 'hg pull origin master'

# Generated at 2022-06-24 07:16:41.276371
# Unit test for function match
def test_match():
    assert match(Command('git foo', 'fatal: Not a git repository'))
    assert not match(Command('git foo', 'git foo'))
    assert match(Command('hg foo', 'abort: no repository found'))
    assert not match(Command('hg foo', 'hg foo'))


# Generated at 2022-06-24 07:16:43.683604
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository', '')) == 'hg status'

# Generated at 2022-06-24 07:16:46.234818
# Unit test for function match
def test_match():
    command = 'git status'.split()
    output = 'fatal: Not a git repository'
    wrong_command = Command(command, output)
    assert match(wrong_command) is None

# Generated at 2022-06-24 07:16:56.865511
# Unit test for function match
def test_match():
    assert(match(Command('git status', 'fatal: Not a git repository')) == True)
    assert(match(Command('git status', 'fatal: Not a git reposisrory')) == False)
    assert(match(Command('hg status', 'abort: no repository found')) == True)
    assert(match(Command('hg status', 'abort: blob repository found')) == False)
    assert(match(Command('hg status', 'abort: no repository found')) == True)
    assert(match(Command('hg status', 'abort: blob repository found')) == False)
    assert(match(Command('hg status', 'abort: no repository found')) == True)
    assert(match(Command('hg status', 'abort: blob repository found')) == False)

# Generated at 2022-06-24 07:17:01.616403
# Unit test for function match
def test_match():
    assert match(Command('git remote add origin git@github.com:nvie/gitflow.git', 'fatal: Not a git repository', None))
    assert not match(Command('git remote add origin git@github.com:nvie/gitflow.git', 'fatal: Not a git repository', None))
    assert not match(Command('hg push', 'abort: no repository found', '/tmp'))

# Generated at 2022-06-24 07:17:02.687243
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command('hg status')

# Generated at 2022-06-24 07:17:06.023230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git add') == 'hg add'
    assert get_new_command('git add file.py') == 'hg add file.py'
    assert get_new_command('git add file.py, file2.py') == 'hg add file.py, file2.py'

# Generated at 2022-06-24 07:17:07.863574
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git branch')
    assert get_new_command(command) == 'hg branch'

# Generated at 2022-06-24 07:17:12.476890
# Unit test for function get_new_command
def test_get_new_command():
    class CommandMock(object):
        def __init__(self, script_parts):
            self.script_parts = script_parts
        def output(self):
            return ''
    mock = CommandMock([u'git', u'init', u'.'])
    assert get_new_command(mock) == u'hg init .'

# Generated at 2022-06-24 07:17:19.300383
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', 'fatal: Not a git repository'))
    assert match(Command('git commit', '', 'fatal: Not a git repository (or any'
                                            't of the parent directories): .git'))
    assert match(Command('git commit', '', 'fatal: Not a git repository (or any'
                                            't of the parent directories): .git'))
    assert not match(Command('git commit', '', 'fatal: Not a git'))

# Generated at 2022-06-24 07:17:25.490997
# Unit test for function match
def test_match():
    command_git_output = """fatal: Not a git repository
fatal: Not a git repository (or any of the parent directories): .git"""
    assert match(Command('git status', command_git_output))
    assert not match(Command('git status'))
    command_hg_output = """abort: no repository found
(.hg not found in /home/user)
abort: no repository found in /tmp"""
    assert match(Command('hg status', command_hg_output))
    assert not match(Command('hg status'))


# Generated at 2022-06-24 07:17:26.256480
# Unit test for function match
def test_match():
    assert match(Command('git status'))

