

# Generated at 2022-06-24 07:07:25.723159
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:07:30.147048
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status'))
    assert not match(Command('hg status'))

# Generated at 2022-06-24 07:07:33.204961
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git foo') == 'hg foo'
    assert get_new_command('svn foo') == 'svn foo'

# Generated at 2022-06-24 07:07:35.859730
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u"git foo") == u"hg foo"
    assert get_new_command(u"hg add foo") == u"git add foo"

# Generated at 2022-06-24 07:07:40.020206
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git checkout master', '')) == 'hg checkout master'
    assert get_new_command(Command('hg checkout master', '')) == 'git checkout master'

# Generated at 2022-06-24 07:07:43.422465
# Unit test for function match
def test_match():
    assert match(Script('git push --force origin master'))
    assert not match(Script('git push --force origin master', error='abort: no changes found'))



# Generated at 2022-06-24 07:07:49.848730
# Unit test for function get_new_command

# Generated at 2022-06-24 07:07:53.996592
# Unit test for function match
def test_match():
	# Pattern in terminal output
	command = Command('git', 'fatal: Not a git repository')
	assert match(command)
	# Pattern not in terminal output	
	command = Command('git', '')
	assert not match(command)
	# Pattern in terminal output, but another scm is used
	command = Command('hg', 'fatal: Not a git repository')
	assert not match(command)



# Generated at 2022-06-24 07:07:59.858283
# Unit test for function match
def test_match():
    assert match(Command('git status', wrong_scm_patterns['git']))
    assert match(Command('git status', 'something else'))

    assert match(Command('hg status', wrong_scm_patterns['hg']))
    assert match(Command('hg status', 'something else'))

    assert not match(Command('git status', 'bad command line'))
    assert not match(Command('hg status', 'bad command line'))


# Generated at 2022-06-24 07:08:01.014970
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'

# Generated at 2022-06-24 07:08:08.782461
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git branch')) == 'hg branch'
    assert get_new_command(Command('git commit -m "test"')) == 'hg commit -m "test"'
    assert get_new_command(Command('git add --all')) == 'hg add --all'
    assert get_new_command(Command('git push origin master')) == 'hg push origin master'
    assert get_new_command(Command('git pull')) == 'hg pull'
    assert get_new_command(Command('git stash')) == 'hg stash'

# Generated at 2022-06-24 07:08:10.729413
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git checkout .', '')

    assert get_new_command(command) == 'hg checkout .'

# Generated at 2022-06-24 07:08:17.202173
# Unit test for function match
def test_match():
    stderr = 'fatal: Not a git repository (or any of the parent directories): .git'
    command = Command('git status', stderr=stderr)
    assert (match(command) == True)
    stderr = 'abort: no repository found in /Users/nick/repos/testing/stuff/.hg (glob)'
    command = Command('hg status', stderr=stderr)
    assert (match(command)) == True


# Generated at 2022-06-24 07:08:22.917777
# Unit test for function match
def test_match():
    command = Command('git push origin master')
    command.output = 'fatal: Not a git repository'
    assert match(command)

    command = Command('hg pull')
    command.output = 'abort: no repository found'
    assert match(command)

    command = Command('git push origin master')
    command.output = 'git push origin master'
    assert not match(command)

    command = Command('hg pull')
    command.output = 'hg pull'
    assert not match(command)


# Generated at 2022-06-24 07:08:25.361933
# Unit test for function match
def test_match():
    assert match(get_command('git status'))
    assert match(get_command('hg status'))
    assert not match(get_command('ls'))


# Generated at 2022-06-24 07:08:27.874364
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git commit test',
                                 stdout='fatal: Not a git repository')
    assert get_new_command(command) == 'hg commit test'

# Generated at 2022-06-24 07:08:33.127709
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '')
    assert get_new_command(command) == 'hg push'
    command = Command('git pull', '')
    assert get_new_command(command) == 'hg pull'
    command = Command('git clone', '')
    assert get_new_command(command) == 'hg clone'

# Generated at 2022-06-24 07:08:35.222931
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repositor')) == u'status'

# Generated at 2022-06-24 07:08:36.476142
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) == 'hg status'

# Generated at 2022-06-24 07:08:38.058930
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg commit -m "initial commit"') == 'git commit -m "initial commit"'

# Generated at 2022-06-24 07:08:45.554052
# Unit test for function get_new_command
def test_get_new_command():
    import unittest
    class TestGetNewCommand(unittest.TestCase):
        @unittest.mock.patch('thefuck.rules.wrong_scm.path_to_scm', {'.git': 'git', '.hg': 'hg'})
        @unittest.mock.patch('thefuck.rules.wrong_scm.Path', unittest.mock.MagicMock())
        def setUp(self):
            self.path = unittest.mock.MagicMock()
            self.path.is_dir.return_value = True


# Generated at 2022-06-24 07:08:49.269058
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status'))
    assert match(Command('git status', 'abort: no repository found'))
    assert not match(Command('git status'))



# Generated at 2022-06-24 07:08:50.951669
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', '/tmp/test/')) == 'hg status'

# Generated at 2022-06-24 07:08:52.602805
# Unit test for function match
def test_match():
    assert not match(Command('ls', 'fatal: Not a git repository', ''))



# Generated at 2022-06-24 07:08:54.537404
# Unit test for function match
def test_match():
    command = Command('git rebase xyz')
    assert match(command)
    command = Command('hg rebase xyz')
    assert match(command)


# Generated at 2022-06-24 07:08:56.106745
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('not found')) == 'git not found'

# Generated at 2022-06-24 07:09:02.401945
# Unit test for function match
def test_match():
    assert match(Command('ls',
                         stderr='abort: no repository found')) == True
    assert match(Command('ls',
                         stderr='fatal: Not a git repository')) == True
    assert match(Command('git',
                         stderr='fatal: Not a git repository')) == False
    assert match(Command('hg',
                         stderr='abort: no repository found')) == False


# Generated at 2022-06-24 07:09:06.681491
# Unit test for function match
def test_match():
    assert match(Command('git status',
        'fatal: Not a git repository (or any of the parent directories): .git',
        ''))

    assert not match(Command('git add',
        'nothing to commit, working directory clean',
        ''))

    assert match(Command('hg status',
        'abort: no repository found in (...)',
        ''))

    assert not match(Command('hg status',
        '(...)',
        ''))


# Generated at 2022-06-24 07:09:16.861022
# Unit test for function get_new_command
def test_get_new_command():
    # If script_parts[0] is git
    command = MagicMock()
    command.output = 'fatal: Not a git repository (or any of the parent directories): .git'
    command.script_parts = ['git', 'status']

    # If script_parts[0] is git but the output is not from git
    command = MagicMock()
    command.output = 'fatal: Not a git repository (or any of the parent directories): .git'
    command.script_parts = ['ls', '-la']

    # If script_parts[0] is hg
    command = MagicMock()
    command.output = 'abort: no repository found in'
    command.script_parts = ['hg', 'status']

    # If script_parts[0] is hg but the output is not from hg
   

# Generated at 2022-06-24 07:09:18.021735
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg clone') == 'git clone'

# Generated at 2022-06-24 07:09:20.039499
# Unit test for function get_new_command
def test_get_new_command():
    command = "hg status"
    assert get_new_command(command) == "git status"


enabled_by_default = True

# Generated at 2022-06-24 07:09:22.387844
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git status', '')) == 'hg status'

# Generated at 2022-06-24 07:09:24.066165
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == u'"git" '

# Generated at 2022-06-24 07:09:26.450432
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git pull')
    assert get_new_command(command) == 'hg pull'


# Generated at 2022-06-24 07:09:29.003552
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == u'hg status'

# Generated at 2022-06-24 07:09:32.643506
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git clone git@github.com:nvbn/thefuck.git'
    assert get_new_command(command) == u'hg clone git@github.com:nvbn/thefuck.git'


# Generated at 2022-06-24 07:09:34.743864
# Unit test for function get_new_command
def test_get_new_command():
    from . import Command

    command = Command('git status', '', '')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:09:39.077328
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status") == "git status"
    assert get_new_command("git add file") == 'git add file'
    assert get_new_command("git commit -m 'I have a file'") == "git commit -m 'I have a file'"
    assert get_new_command("git push origin master") == "git push origin master"


# Generated at 2022-06-24 07:09:45.502606
# Unit test for function match
def test_match():
    assert match(Command('git status', wrong_scm_patterns['git'] + '\n'))
    assert not match(Command('git status', 'On branch master\n'))
    assert not match(Command('hg status', wrong_scm_patterns['hg'] + '\n'))
    assert match(Command('hg status', 'abort: no repository found\n'))
    assert not match(Command('hg status', 'nothing changed\n'))


# Generated at 2022-06-24 07:09:50.020937
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('hg status')) == 'git status'
    assert get_new_command(Command('git add .')) == 'hg add'

# Generated at 2022-06-24 07:09:56.401118
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): \n'))
    assert not match(Command('git status', ''))
    assert not match(Command('hg status', 'fatal: Not a git repository'))


# Generated at 2022-06-24 07:09:58.744859
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg commit') == u'git commit'
    assert get_new_command('git commit') == u'git commit'

# Generated at 2022-06-24 07:09:59.722679
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-24 07:10:01.170247
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .', _get_actual_scm=lambda: 'hg') == 'hg add .'

# Generated at 2022-06-24 07:10:02.091198
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:10:09.694182
# Unit test for function match
def test_match():
    assert match(Command('ls', 'fatal: Not a git repository'))
    assert not match(Command('ls', 'fatal: git'))
    assert not match(Command('ls', 'fatal: git repository'))
    assert not match(Command('ls', 'fatal: git Not a repository'))
    assert not match(Command('hg', 'abort: no repository found'))
    assert not match(Command('git', 'fatal: Not a git repository'))
    assert not match(Command('hg', 'abort: no found'))


# Generated at 2022-06-24 07:10:11.708751
# Unit test for function match
def test_match():
    command = "fatal: Not a git repository"
    assert match(command) == True



# Generated at 2022-06-24 07:10:14.085723
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(u"git somthing", "git: 'somthing' is not a git command. See 'git --help'.")) == "hg somthing")

# Generated at 2022-06-24 07:10:21.777831
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git push')) == 'hg push'
    assert get_new_command(Command('git add -p')) == 'hg add -p'
    assert get_new_command(Command('git stash')) == 'hg stash'
    assert get_new_command(Command('git commit')) == 'hg commit'
    assert get_new_command(Command('git branch')) == 'hg branch'
    assert get_new_command(Command('git remote')) == 'hg remote'
    assert get_new_command(Command('git checkout')) == 'hg checkout'
    assert get_new_command(Command('git reflog')) == 'hg reflog'
    assert get_

# Generated at 2022-06-24 07:10:28.836072
# Unit test for function match
def test_match():
    # Test if there are no folders and match is false
    command = Command('git status', u'fatal: Not a git repository')
    app_name = wrong_scm_patterns.keys()[0]
    assert match(command, app_name) == False
    # Test if there are folders and match is true
    command = Command('git status', u'error: no such command: sttus')
    app_name = wrong_scm_patterns.keys()[0]
    assert match(command, app_name) == True


# Generated at 2022-06-24 07:10:30.676043
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg commit'

# Generated at 2022-06-24 07:10:33.892891
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert not match(Command('hg status', ''))
    assert not match(Command('git status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository'))


# Generated at 2022-06-24 07:10:38.329919
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_hg_no_repository_found import _get_actual_scm
    _get_actual_scm = lambda: 'git'
    assert get_new_command('git status') == 'git status'
    _get_actual_scm = lambda: 'hg'
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:10:44.026090
# Unit test for function match
def test_match():
    command = Command("git commit", "fatal: Not a git repository")
    assert match(command)
    command = Command("git branch", "fatal: Not a git repository")
    assert not match(command)
    command = Command("hg commit", "abort: no repository found")
    assert match(command)
    command = Command("hg branch", "abort: no repository found")
    assert not match(command)


# Generated at 2022-06-24 07:10:55.368690
# Unit test for function match
def test_match():
    # Test that when scm is correct it returns False
    assert not match(Command('git status', '', ''))
    assert not match(Command('hg status', '', ''))
    # Test that when scm is wrong it returns the new command
    assert match(Command('hg status', '', 'abort: no repository found'))
    assert match(Command('git status', '', 'fatal: Not a git repository'))
    # Test that when scm is wrong it returns False
    assert not match(Command('hg status', '', ''))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git status', '', 'git: \'status\' is not a git command'))
    assert not match(Command('hg status', '', 'hg: unknown command \'status\''))
    

# Generated at 2022-06-24 07:10:58.341920
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git status")
    new_command = get_new_command(command)
    assert new_command == 'hg status'

# Generated at 2022-06-24 07:11:08.672977
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg st'
    assert get_new_command('git add -A') == 'hg add -A'
    assert get_new_command('git commit -m "test commit"') == 'hg commit -m "test commit"'
    assert get_new_command('git commit') == 'hg commit'
    assert get_new_command('git commit -m ') == 'hg commit -m '
    assert get_new_command('git push') == 'hg push'
    assert get_new_command('git pull') == 'hg pull'
    assert get_new_command('git fetch') == 'hg fetch'
    assert get_new_command('git log') == 'hg log'
    assert get_new_command('git checkout') == 'hg checkout'

# Generated at 2022-06-24 07:11:11.281012
# Unit test for function match
def test_match():
    command = 'git status'
    command_output = 'fatal: Not a git repository (or any of the parent directories): .git'

    assert match(Command(command, command_output))


# Generated at 2022-06-24 07:11:14.279404
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='hg add', stdout='abort: no repository found')
    assert get_new_command(command) == 'git add'
    command = Command(script='git add', stdout='fatal: Not a git repository')
    assert get_new_command(command) == 'hg add'

# Generated at 2022-06-24 07:11:16.018054
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u"git status -s", []) == "hg status"

# Generated at 2022-06-24 07:11:22.504578
# Unit test for function match
def test_match():
    actual_scm = _get_actual_scm()
    assert match(Command('git status',
                          'fatal: Not a git repository'))
    assert match(Command('hg status',
                          'abort: no repository found'))
    # Test if it ignores the correctely spelled SCM
    assert not match(Command(actual_scm + ' status',
                             'fatal: Not a git repository'))


# Generated at 2022-06-24 07:11:24.912881
# Unit test for function get_new_command
def test_get_new_command():
    command = type('', (), {})()
    command.script_parts = ['git', 'status']
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:11:27.896701
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a hg repository'))


# Generated at 2022-06-24 07:11:32.057618
# Unit test for function match
def test_match():
    assert match(Command('git')) == False
    assert match(Command('git', 'status')) == False
    assert match(Command('hg')) == False
    assert match(Command('hg', 'status')) == False

# Unit test function get_new_command

# Generated at 2022-06-24 07:11:34.703315
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    new_command = get_new_command(command)
    assert new_command == 'hg status'


# Generated at 2022-06-24 07:11:41.313817
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository (or any of the parent directories): .git\n', ''))
    assert match(Command('hg branch', 'abort: no repository found in /home/joe/!\n', ''))
    assert match(Command('git branch', '\n', ''))
    assert not match(Command('joe branch', 'fatal: Not a git repository (or any of the parent directories): .git\n', ''))


# Generated at 2022-06-24 07:11:51.999221
# Unit test for function match
def test_match():
    command = Command('git rebase',
        'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

    command = Command('git rebase',
        'fatal: Not a git repository (or any of the parent directories): .git\n',
        '')
    assert match(command)

    command = Command('git rebase',
        'fatal: Not a git repository (or any of the parent directories): .git\n',
        '',
        '')
    assert match(command)

    command = Command('git rebase',
        'fatal: Not a git repository (or any of the parent directories): .git\n',
        '',
        '',
        '')
    assert match(command)


# Generated at 2022-06-24 07:11:53.417256
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('git st')
    assert 'hg st' == get_new_command(cmd)

# Generated at 2022-06-24 07:11:56.168116
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg status', 'hg status')) == 'git status'
    assert get_new_command(Command('git status', 'git status')) == 'git status'

# Generated at 2022-06-24 07:11:59.038746
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg', 'blabla', 'abort: no repository found!')
    assert get_new_command(command) == 'git blabla'

# Generated at 2022-06-24 07:12:02.223615
# Unit test for function match
def test_match():
    command = Command('git remote -v', 'fatal: Not a git repository')
    assert match(command)
    command = Command('hg push', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-24 07:12:04.595299
# Unit test for function get_new_command
def test_get_new_command():
    script_parts = ['git', 'blah', 'blah']
    assert get_new_command(Command(script_parts, '', '', '')) == u'hg blah blah'

# Generated at 2022-06-24 07:12:08.778616
# Unit test for function match
def test_match():
    # Test case 1
    command = 'git push'
    output = 'fatal: Not a git repository'
    assert match(script(command, output))

    # Test case 2
    command = 'git push'
    output = 'fatal: Not a git repository'
    assert not match(script(command, output))

# Generated at 2022-06-24 07:12:14.553409
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git log', '', 'fatal: Not a git repository')) == 'hg log'
    assert get_new_command(Command('git revert', '', 'fatal: Not a git repository')) == 'hg revert'
    assert get_new_command(Command('hg update', '', 'abort: no repository found')) == 'git update'

# Generated at 2022-06-24 07:12:17.355904
# Unit test for function match
def test_match():
    assert match(Command('git pull', 'fatal: Not a git repository'))
    assert match(Command('hg pull', 'abort: no repository found'))
    assert not match(Command('git pull', 'fatal: Not a git repository'))

# Generated at 2022-06-24 07:12:21.536763
# Unit test for function match
def test_match():
    command = Command('git push blah blah blah', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git push blah blah blah', 'fatal: Not a git repo')
    assert not match(command)


# Generated at 2022-06-24 07:12:30.597520
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', '') == True)
    assert match(Command('hg status', 'abort: no repository found', '') == True)

    assert match(Command('git status', 'fatal: Not a git repository', '') == True)
    assert match(Command('hg status', 'abort: no repository found', '') == True)
    assert match(Command('git status', 'die: Not a git repository', '') == False)
    assert match(Command('hg status', 'die: no repository found', '') == False)
    assert match(Command('git status', 'fatal: git repository', '') == False)
    assert match(Command('hg status', 'abort: no found', '') == False)

# Generated at 2022-06-24 07:12:32.530581
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status") == "hg summary"

# Generated at 2022-06-24 07:12:34.395030
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', '', '/home/dev/test')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:12:38.569891
# Unit test for function get_new_command
def test_get_new_command():
	# create dummy command
	args = argparse.Namespace(script='git status', script_parts=['git', 'status'], stderr=None, stdout='fatal: Not a git repository')
	command = Command(args.script, args.script_parts, args.stdout, args.stderr)
	new_command = get_new_command(command)
	assert new_command == u'hg status'

# Generated at 2022-06-24 07:12:40.846722
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert not match(Command('not a real command', '', ''))
    assert not match(Command('', '', ''))
    assert not match(Command('git status', '', ''))

# Generated at 2022-06-24 07:12:43.847945
# Unit test for function match
def test_match():
    if _get_actual_scm() == 'hg':
        assert match('git status')
    elif _get_actual_scm() == 'git':
        assert match('hg status')


# Generated at 2022-06-24 07:12:45.108391
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository')).pattern == 'fatal: Not a git repository'

# Generated at 2022-06-24 07:12:49.831388
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git stash', 'Not a git repository', '/')) == 'hg stash'
    assert get_new_command(Command('git stash', 'Not a git repository', '/tmp/')) == 'git stash'
    assert get_new_command(Command('git stash', 'Out of memory', '/tmp/')) == 'git stash'

# Generated at 2022-06-24 07:12:53.908125
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff HEAD') == 'hg diff'
    assert get_new_command('git diff') == 'hg diff'
    assert get_new_command('git clone git@github.com:nvbn/thefuck') == 'hg clone git@github.com:nvbn/thefuck'

# Generated at 2022-06-24 07:12:58.750147
# Unit test for function match
def test_match():
    assert match(Command("git", "git: 'rebase' is not a git command. See 'git --help'."))
    assert not match(Command("git", "merge"))
    assert match(Command("hg", "abort: no repository found in 'E:\\coding\\python\\fuckit_test'"))
    assert not match(Command("hg", "merge"))



# Generated at 2022-06-24 07:13:06.171194
# Unit test for function match
def test_match():
    assert match(Command(script='git'))
    assert not match(Command(script='git status'))
    assert match(Command(script='git status', output='fatal: Not a git repository'))
    assert match(Command(script='git status', output='fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command(script='gut status', output='fatal: Not a git repository'))
    assert match(Command(script='gut status', output='fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command(script='git status', output='On branch master'))
    assert match(Command(script='hg'))
    assert not match(Command(script='hg status'))

# Generated at 2022-06-24 07:13:10.918892
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'hg add .'
    assert get_new_command('git commit -m "test"') == 'hg commit -m "test"'
    assert get_new_command('git push origin master') == 'hg push origin master'

# Generated at 2022-06-24 07:13:13.103449
# Unit test for function match
def test_match():
    assert(match(Command('hg status')) == True)
    assert(match(Command('git status')) == True)



# Generated at 2022-06-24 07:13:16.952234
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    from thefuck.types import Command

    assert get_new_command(Command('git status', 'git: fatal: Not a git repository (or any of the parent directories): .git', Bash())) == 'hg status'


enabled_by_default = True

# Generated at 2022-06-24 07:13:20.599762
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command_t("git status", "git")) == "git status"
    assert get_new_command(command_t("git status", "hg")) == "hg status"
    assert get_new_command(command_t("git log", "hg")) == "hg log"

# Generated at 2022-06-24 07:13:22.302470
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git checkout title')
    assert get_new_command(command) == 'hg checkout title'

# Generated at 2022-06-24 07:13:24.145293
# Unit test for function match
def test_match():
    cmd = Command('git yolo', 'fatal: Not a git repository')
    assert match(cmd)

# Generated at 2022-06-24 07:13:30.329943
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git diff', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository', False))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg diff', 'abort: no repository found'))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-24 07:13:31.822929
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository'))

    assert not match(Command('ls', ''))



# Generated at 2022-06-24 07:13:33.010874
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git branch', '')) == 'hg branch'

# Generated at 2022-06-24 07:13:34.489103
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'hg commit'
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:13:35.313192
# Unit test for function get_new_command
def test_get_new_command():
  pass

# Generated at 2022-06-24 07:13:38.945715
# Unit test for function match
def test_match():
    assert match(Command(script='git status',
                         output='fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command(script='git status',
                             output='On branch master'))

# Generated at 2022-06-24 07:13:42.629241
# Unit test for function match
def test_match():
    assert match(Command('git some thing',
        'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg some thing',
        'abort: no repository found!'))



# Generated at 2022-06-24 07:13:46.808332
# Unit test for function match
def test_match():
    assert match(Command('git status', '')) == True
    assert match(Command('git', '')) == False
    assert match(Command('hg status', '')) == True
    assert match(Command('hg', '')) == False
    assert match(Command('svn status', '')) == False


# Generated at 2022-06-24 07:13:48.779285
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:13:51.131153
# Unit test for function match
def test_match():
    arg = "git add ."
    command = Command(arg)
    command.output = "fatal: Not a git repository"
    
    assert(match(command))


# Generated at 2022-06-24 07:13:55.804480
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert not match(command)


# Generated at 2022-06-24 07:14:04.120418
# Unit test for function match
def test_match():
    f = match
    e = match_error

    assert f(Command('git status', output=u'fatal: Not a git repository'))
    assert not f(Command('git status', output=u'fatal: Not a git repository'))
    assert not f(Command('git status', output=u'fatal: Not a git repository'))
    assert not f(Command('git status', output=u'fatal: Not a git repository'))

    assert f(Command('git status', output=u'fatal: Not a git repository'))
    assert not f(Command('git status', output=u'fatal: Not a git repository'))
    assert not f(Command('git status', output=u'fatal: Not a git repository'))

# Generated at 2022-06-24 07:14:06.468936
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git status --porcelain' == get_new_command(u'hg status --porcelain')

# Generated at 2022-06-24 07:14:11.359773
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'
    command = Command('git status', 'fatal: Not a git repository')
    command.script_parts = ['git', 'status']
    assert get_new_command(command) == 'hg status'
    command = Command('foo bar', 'fatal: Not a git repository')
    assert get_new_command(command) == command.script


# Generated at 2022-06-24 07:14:14.450501
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'abort: no repository found'))
    assert not match(Command('hg status', 'fatal: Not a git repository'))



# Generated at 2022-06-24 07:14:16.589013
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git log', 'some')) == 'hg log'
    assert get_new_command(Command('git status', 'some')) == 'hg status'

# Generated at 2022-06-24 07:14:22.679123
# Unit test for function get_new_command
def test_get_new_command():
    script_parts = ["git", "branch"]
    output = "fatal: Not a git repository"
    command = Command(script_parts, output)
    
    wrong_scm = "git"
    right_scm = _get_actual_scm()
    # Command input
    print("Command input: " + str(command.script_parts) + "\n")
    # Command output
    print("Command output: " + str(command.output) + "\n")
    # Wrong SCM
    print("Wrong SCM: " + wrong_scm + "\n")
    # Right SCM
    print("Right SCM: " + right_scm + "\n")
    # New command
    command_new = get_new_command(command)
    print("New command: " + command_new + "\n")


# Generated at 2022-06-24 07:14:24.055797
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git status'
    assert get_new_command(command) == 'hg status'
    command2 = 'git log'
    assert get_new_command(command2) == 'hg log'

# Generated at 2022-06-24 07:14:26.071268
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command(u'git status', u'git status'))

# Generated at 2022-06-24 07:14:31.015168
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found {}'.format('%s')))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-24 07:14:33.040403
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git st')
    new_command = get_new_command(command)
    assert new_command == 'hg st'

# Generated at 2022-06-24 07:14:35.934171
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('git status -sb', 'fatal: Not a git repository')

    scm = get_new_command(command)

    assert scm == 'hg status -sb'

# Generated at 2022-06-24 07:14:39.850484
# Unit test for function match
def test_match():
    module = wrong_scm_patterns.keys()[0]
    message = wrong_scm_patterns[module]

    assert match(Command('git commit', message))
    assert not match(Command('git commit', ''))
    assert match(Command('git commit', message, module=module))
    assert not match(Command('git commit', '', module=module))

# Generated at 2022-06-24 07:14:47.624251
# Unit test for function match
def test_match():
    # Test for a wrong repo
    path = Path("/path/to/repo")
    path.is_dir = lambda: True
    assert match(Command('git status',
                         '/bin/git status \nfatal: Not a git repository',
                         '/path/to/repo',
                         'git'))
    # Test for wrong command
    assert not match(Command('git commit',
                         '/bin/git commit',
                         '/path/to/repo',
                         'git','commit', '-m', 'foo'))
    # Test for right repo
    path.is_dir = lambda: False
    path = Path("/path/to/repo/.git")
    path.is_dir = lambda: True

# Generated at 2022-06-24 07:14:53.280783
# Unit test for function match
def test_match():
    assert match(
        Command('git', '', 'fatal: Not a git repository')) is True
    assert match(
        Command('git', '', '')) is False
    assert match(
        Command('hg', '', 'abort: no repository found')) is True
    assert match(
        Command('hg', '', '')) is False


# Generated at 2022-06-24 07:14:54.583371
# Unit test for function match
def test_match():
    command = Command('git status')
    assert match(command)


# Generated at 2022-06-24 07:14:56.614951
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit -m 'wrong'")
    assert get_new_command(command) == "hg commit -m 'wrong'"

# Generated at 2022-06-24 07:14:59.414183
# Unit test for function get_new_command
def test_get_new_command():
    ret = get_new_command(Command('git anything', 'fatal: Not a git repository'))
    assert ret == 'hg anything'

    ret = get_new_command(Command('hg anything', 'abort: no repository found'))
    assert ret == 'git anything'

# Generated at 2022-06-24 07:15:01.420189
# Unit test for function match
def test_match():
    assert match(Command('git branch'))
    assert match(Command('hg qseries'))


# Generated at 2022-06-24 07:15:03.235387
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)



# Generated at 2022-06-24 07:15:04.740970
# Unit test for function get_new_command
def test_get_new_command():
    command = u'git branch'

    assert(get_new_command(command) == 'hg branch')

# Generated at 2022-06-24 07:15:10.984377
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository', '', 0)
    assert match(command)

    import os
    os.chdir(os.path.join(os.getcwd(), '..'))
    command = Command('git status', 'fatal: Not a git repository', '', 0)
    assert not match(command)

    command = Command('git status', '', '', 0)
    assert not match(command)


# Generated at 2022-06-24 07:15:13.794932
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert _get_actual_scm() == 'hg'
    assert get_new_command(command) == 'hg status'


# Generated at 2022-06-24 07:15:15.190560
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status')) == 'hg status'

# Generated at 2022-06-24 07:15:18.333755
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('svn : add my.txt') == 'hg : add my.txt'
    assert get_new_command('hg : add my.txt') == 'hg : add my.txt'

# Generated at 2022-06-24 07:15:21.326233
# Unit test for function get_new_command
def test_get_new_command():
    for path, scm in path_to_scm.items():
        assert get_new_command(Command(u'git status', u'')) == 'git status'


# Generated at 2022-06-24 07:15:27.307028
# Unit test for function match
def test_match():
	# Should trigger
    assert match(Command('git commit', 'fatal: Not a git repository'))
    # Should not trigger
    assert not match(Command('git commit', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git commit', 'fatal: Not a git repository (or any of the parent directories): .hg'))
    assert not match(Command('hg commit', 'abort: no repository found'))


# Generated at 2022-06-24 07:15:31.265359
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "Hello"',
                         'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg push', 'abort: no repository found'))
    assert not match(Command('git commit -m "Hello"',
                             'On branche master'))


# Generated at 2022-06-24 07:15:35.771868
# Unit test for function get_new_command
def test_get_new_command():
    match_ = match(Command('git status', '', '/'+path_to_scm['.git']))
    new_command = get_new_command(Command('git status', '', '/'+path_to_scm['.git']))
    print(new_command)
    # expected to be True
    print(match_)
    assert match_ == True
    # expected to be 'git status'
    assert new_command == 'git status'

# Generated at 2022-06-24 07:15:38.630334
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'status') == u'hg status'
    assert get_new_command(u'status -uno') == u'hg status -uno'
    assert get_new_command(u'status -b test') == u'hg status -b test'

# Generated at 2022-06-24 07:15:41.669688
# Unit test for function match
def test_match():
    assert (match(Command(script='git status', output='fatal: Not a git repository')))
    assert (not match(Command(script='git status', output='On branch master')))
    assert (match(Command(script='hg status', output='abort: no repository found')))
    assert (not match(Command(script='hg status', output='On branch master')))


# Generated at 2022-06-24 07:15:45.019874
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git reset --hard HEAD', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg reset --hard HEAD'

# Generated at 2022-06-24 07:15:46.109173
# Unit test for function match
def test_match():
	assert match(u'git add')
	assert match(u'hg add')


# Generated at 2022-06-24 07:15:49.320660
# Unit test for function match
def test_match():
    # Wrong SCM command
    command = Command('git help', 'fatal: Not a git repository')
    assert match(command)

    # Wrong SCM command
    command = Command('hg help', 'abort: no repository found')
    assert match(command)


# Generated at 2022-06-24 07:15:50.983507
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:16:00.134355
# Unit test for function match
def test_match():
    assert not match(Command('git status', '', 'fatal: Not a git repository', 1))
    assert not match(Command('hg status', '', 'abort: no repository found', 1))
    assert not match(Command('hg commit', '', 'abort: no repository found', 1))
    assert not match(Command('git clone', '', 'fatal: Not a git repository', 1))
    assert not match(Command('git push', '', 'fatal: Not a git repository', 1))
    assert not match(Command('git pull', '', 'fatal: Not a git repository', 1))
    assert not match(Command('git remote', '', 'fatal: Not a git repository', 1))
    assert not match(Command('git add .', '', 'fatal: Not a git repository', 1))

# Generated at 2022-06-24 07:16:02.049366
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status')) == 'hg status'
    assert get_new_command(Command(script='git commit')) == 'hg commit'
    assert get_new_command(Command(script='git checkout blah')) == 'hg checkout blah'

# Generated at 2022-06-24 07:16:04.786121
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'git status'
    assert get_new_command(cmd) == 'hg status'
    assert get_new_command(cmd) != 'git status'

# Generated at 2022-06-24 07:16:07.652674
# Unit test for function match
def test_match():
    assert match('fatal: Not a git repository')
    assert match('abort: no repository found')
    assert not match('fatal: Not a git repository')
    assert not match('abort: no reposito')
    assert not match('fatal: Not a git ')


# Generated at 2022-06-24 07:16:12.921854
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', path='/git/git'))
    assert match(Command('git status', 'fatal: Not a git repository', path='/hg/hg'))
    assert not match(Command('hg status', 'fatal: Not a git repository', path='/git/git'))



# Generated at 2022-06-24 07:16:16.060746
# Unit test for function get_new_command
def test_get_new_command():
    _get_actual_scm = 'git'
    assert get_new_command('git fet') == 'git fet'
    _get_actual_scm = 'hg'
    assert get_new_command('git fet') == 'hg fet'

# Generated at 2022-06-24 07:16:17.174140
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg log'

# Generated at 2022-06-24 07:16:20.405393
# Unit test for function match
def test_match():
    assert match(Command('git stash pop', 'fatal: Not a git repository'))
    assert match(Command('git push origin master', 'fatal: Not a git repository'))
    assert match(Command('hg log -l 1', 'abort: no repository found'))
    assert match(Command('hg push', 'abort: no repository found'))


# Generated at 2022-06-24 07:16:26.233929
# Unit test for function match
def test_match():
    wrong_command = Command('git branch', 'fatal: Not a git repository')
    assert match(wrong_command)

    right_command = Command('git branch', 'a test branch')
    assert not match(right_command)

    wrong_command = Command('hg branch', 'abort: no repository found')
    assert match(wrong_command)

    right_command = Command('hg branch', 'a test branch')
    assert not match(right_command)


# Generated at 2022-06-24 07:16:29.152104
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg commit -m "my commit"')
    new_command = get_new_command(command)
    assert(new_command == 'git commit -m "my commit"')

# Generated at 2022-06-24 07:16:31.818052
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg status') == 'git status'
    assert get_new_command('git status') == 'git status'



# Generated at 2022-06-24 07:16:43.031928
# Unit test for function match
def test_match():
    run = Command('git checkout dev')
    run.return_code = 128
    run.output = 'fatal: Not a git repository'
    assert match(run)

    run = Command('git checkout dev')
    run.return_code = 128
    run.output = 'abort: no repository found'
    assert not match(run)

    run = Command('hg status')
    run.return_code = 255
    run.output = 'fatal: Not a git repository'
    assert not match(run)

    run = Command('hg status')
    run.return_code = 255
    run.output = 'abort: no repository found'
    assert match(run)

    run = Command('git checkout dev')
    run.return_code = 0
    run.output = 'fatal: Not a git repository'
   

# Generated at 2022-06-24 07:16:44.789394
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:16:46.647380
# Unit test for function match
def test_match():
    assert match(Command('git diff',
                         'fatal: Not a git repository',
                         ''))



# Generated at 2022-06-24 07:16:49.559886
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git diff file') == 'hg diff file'


enabled_by_default = True

# Generated at 2022-06-24 07:16:55.985470
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git commit'
    new_command = get_new_command(command)
    assert new_command == 'hg commit'

    command = 'git commit -m "First commit"'
    new_command = get_new_command(command)
    assert new_command == 'hg commit -m "First commit"'

    command = 'git push'
    new_command = get_new_command(command)
    assert new_command == 'hg push'

# Generated at 2022-06-24 07:16:57.992502
# Unit test for function get_new_command
def test_get_new_command():
    scm = _get_actual_scm()
    assert get_new_command(Command(script="git status")) == scm + " status"

# Generated at 2022-06-24 07:16:59.281499
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit')) == 'git commit'

# Generated at 2022-06-24 07:17:01.121332
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)



# Generated at 2022-06-24 07:17:04.841083
# Unit test for function match
def test_match():
    assert match(Command('git commit')) == False
    assert match(Command('git commit', 'fatal: Not a git repository')) == True
    assert match(Command('hg commit')) == False
    assert match(Command('hg commit', 'abort: no repository found')) == True


# Generated at 2022-06-24 07:17:10.542219
# Unit test for function match
def test_match():
    assert match(Command(script='git', stderr='fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command(script='hg', stderr='abort: no repository found in X/Y'))
    assert not match(Command(script='svn', stderr='fatal: Not a git repository'))


# Generated at 2022-06-24 07:17:14.984000
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg status', '')
    assert get_new_command(command) == 'git status'

    command = Command('hg annotate emacs/README.md', '')
    assert get_new_command(command) == 'git annotate emacs/README.md'



# Generated at 2022-06-24 07:17:20.062850
# Unit test for function match
def test_match():
    actual_scm = _get_actual_scm()
    wrong_scm = 'hg' if actual_scm == 'git' else 'git'
    pattern = wrong_scm_patterns[wrong_scm]

    assert match(Command('{} status'.format(wrong_scm), pattern))
    assert not match(Command('git status'))


# Generated at 2022-06-24 07:17:21.858617
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:17:32.732633
# Unit test for function match
def test_match():
    command = Command(script='git status',
                      output='fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command(script='git status',
                      output='fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

    command = Command(script='hg blame',
                      output='abort: no repository found in ' +
                      '/home/frigus/.thefuck/.git (.git)')
    assert match(command)

    command = Command(script='hg blame',
                      output='abort: no repository found in ' +
                      '/home/frigus/.fagit/.git/.git (.git)')
    assert not match(command)
