

# Generated at 2022-06-24 07:07:24.328120
# Unit test for function get_new_command
def test_get_new_command():
    command = "git status"
    assert get_new_command(command) == "hg status"


# Generated at 2022-06-24 07:07:29.923797
# Unit test for function match
def test_match():
    input_command = 'git ls'
    input_output = "fatal: Not a git repository (or any of the parent directories): .git"
    path_to_scm = {
        '.git': 'git',
        '.hg': 'hg',
    }
    assert type(match(input_command)) == tuple
    assert match(input_command)[0] == True
    assert match(input_command)[1] == path_to_scm['.git']
    assert match(input_command)[2] == input_output

# Generated at 2022-06-24 07:07:37.577019
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git branch', 'fatal: Not a git repository'))
    assert get_new_command(Command('git branch', 'fatal: Not a git repository (or any of the parent directories)',
                                   'fatal: Not a git repository (or any of the parent directories): .git'))
    assert get_new_command(Command('hg branches', 'abort: no repository found',
                                   'abort: no repository found!'))

# Generated at 2022-06-24 07:07:42.023942
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='test script',
                      stdout='test stdout',
                      stderr='test stderr')
    assert get_new_command(command) == 'test script'

enabled_by_default = True

# Generated at 2022-06-24 07:07:49.496837
# Unit test for function get_new_command
def test_get_new_command():

    # Test with git
    command = Command('git status')
    new_command = get_new_command(command)
    assert new_command == u'hg status'

    # Test with hg
    command = Command('hg status')
    new_command = get_new_command(command)
    assert new_command == u'git status'

    # Test with hg debug
    command = Command('hg debugconfig')
    new_command = get_new_command(command)
    assert new_command == u'git debugconfig'

# Generated at 2022-06-24 07:07:51.704726
# Unit test for function match
def test_match():
    assert match(Command('git branh', 'fatal: Not a git repository'))
    assert not match(Command('hg branch', ''))


# Generated at 2022-06-24 07:07:56.167740
# Unit test for function get_new_command
def test_get_new_command():
    # Using git command
    assert get_new_command(Command('git command')) == 'hg command'
    # Using hg command
    assert get_new_command(Command('hg command')) == 'hg command'
    # Using diff command
    assert get_new_command(Command('git diff')) == 'hg diff'

# Generated at 2022-06-24 07:07:59.155982
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git status', 'fatal: Not a hg repository')
    assert not match(command)


# Generated at 2022-06-24 07:08:00.979135
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'abc')
    new = get_new_command(command)
    assert u'hg status' == new

# Generated at 2022-06-24 07:08:05.141422
# Unit test for function match
def test_match():
    stderr = b'fatal: Not a git repository'
    assert match(Command(script='git', stderr=stderr))
    stderr = b'abort: no repository found'
    assert match(Command(script='hg', stderr=stderr))
    stderr = b'abort: no repository found'
    assert not match(Command(script='git', stderr=stderr))


# Generated at 2022-06-24 07:08:07.913908
# Unit test for function get_new_command
def test_get_new_command():
    """Unit test for the function `get_new_command`"""
    command = make_command('git branch')

    assert ('git branch' == get_new_command(command))

# Generated at 2022-06-24 07:08:10.320985
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.no_such_cmd import get_new_command
    command = 'git init'
    assert get_new_command(command) == 'hg init'


# Generated at 2022-06-24 07:08:12.417128
# Unit test for function match
def test_match():
	assert(match('git status') == False)
	assert(match('hg status') == False)

# Generated at 2022-06-24 07:08:14.628666
# Unit test for function get_new_command
def test_get_new_command():
    run_command = MagicMock(output='fatal: Not a git repository')
    assert get_new_command(run_command) == 'hg status'

# Generated at 2022-06-24 07:08:18.296813
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository',
                         '/home/user/'))
    assert match(Command('hg status',
                         'abort: no repository found',
                         '/home/user/'))


# Generated at 2022-06-24 07:08:20.724582
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg status', '/home/user/dev/fuck')

    assert get_new_command(command) == 'git status'

enabled_by_default = False

# Generated at 2022-06-24 07:08:22.970963
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-24 07:08:28.045520
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command('git branch', ''))
    assert not match(Command('hg branch', ''))
    assert not match(Command('hg branch', 'abort: no repository found',
                    '/path/to/my/repo'))


# Generated at 2022-06-24 07:08:35.933124
# Unit test for function match
def test_match():
    assert not match(Command('git 3', '', '', Path('.')))
    assert match(Command('git 3', 'fatal: Not a git repository', '', Path('.', '.hg', '3')))
    assert match(Command('hg 3', 'abort: no repository found', '', Path('.', '.git', '3')))
    assert not match(Command('git 3', '', '', Path('.', '.hg')))
    assert not match(Command('hg 3', '', '', Path('.', '.git')))


# Generated at 2022-06-24 07:08:39.756602
# Unit test for function match
def test_match():
    command = Command('git pull origin master', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg pull', 'abort: no repository found')
    assert match(command)

    command = Command('git status', 'On branch master')
    assert not match(command)


# Generated at 2022-06-24 07:08:42.761735
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git status'
    actual_scm = 'hg'
    assert 'hg git status' == get_new_command(command, actual_scm)

# Generated at 2022-06-24 07:08:46.038987
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git status') == 'git status'
	assert get_new_command('git add .') == 'git add .'
	assert get_new_command('git clone testinggit') == 'git clone testinggit'

# Generated at 2022-06-24 07:08:50.076380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'hg push'
    assert get_new_command(Command('git clone', '')) == 'hg clone'
    assert get_new_command(
        Command('git push origin master', '')) == 'hg push origin master'

# Generated at 2022-06-24 07:09:00.539196
# Unit test for function match
def test_match():
    def _mock_get_actual_scm(return_value):
        _get_actual_scm.cache_clear()
        _get_actual_scm = mock.MagicMock()
        _get_actual_scm.return_value = return_value

    command = Command(script = 'git commit -m "Fix typos"',
                      output = 'fatal: Not a git repository')
    _mock_get_actual_scm('hg')
    assert match(command) is True

    _mock_get_actual_scm('git')
    assert match(command) is False

    command = Command(script = 'git commit -m "Fix typos"',
                      output = 'abort: no repository found')
    _mock_get_actual_scm('git')

# Generated at 2022-06-24 07:09:02.081414
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git add .' == get_new_command(
        Command('hg add .', ''))



# Generated at 2022-06-24 07:09:05.817174
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    git_command = Command('git diff', 'fatal: Not a git repository',
                          'git diff')
    hg_command = Command('hg diff', 'abort: no repository found',
                         'hg diff')
    assert get_new_command(git_command) == 'git diff'
    assert get_new_command(hg_command) == 'hg diff'


# Generated at 2022-06-24 07:09:08.155874
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'hg push origin master'

# Generated at 2022-06-24 07:09:09.231446
# Unit test for function match
def test_match():
    assert match(Command('git status'))


# Generated at 2022-06-24 07:09:16.224114
# Unit test for function match
def test_match():
    output = u"fatal: Not a git repository (or any of the parent directories): .git"
    command = Command(script = "git status", stdout = output)
    assert match(command)
    output = u"abort: no repository found in '.'"
    command = Command(script = "hg status", stdout = output)
    assert match(command)
    output = u"fatal: not a git repository"
    command = Command(script = "git status", stdout = output)
    assert not match(command)
    


# Generated at 2022-06-24 07:09:17.468876
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)


# Generated at 2022-06-24 07:09:18.854721
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git diff --staged") == "hg diff --staged"

# Generated at 2022-06-24 07:09:20.493562
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git status", "")) == "hg status"


# Generated at 2022-06-24 07:09:23.542290
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    match = Command('git add .', '', '')

    assert get_new_command(match) == 'hg add .'

# Generated at 2022-06-24 07:09:25.297456
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(['git','status']) == 'git status'



# Generated at 2022-06-24 07:09:27.365014
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: Not a git repository"))


assert _get_actual_scm() == 'git'


# Generated at 2022-06-24 07:09:31.907717
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg remove', 'abort: no repository found'))
    assert not match(Command('git status', ''))
    assert not match(Command('hg remove', ''))


# Generated at 2022-06-24 07:09:33.280700
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git')
    assert get_new_command(command) == 'hg'

# Generated at 2022-06-24 07:09:35.357652
# Unit test for function match
def test_match():
    command = ('git pull', 'fatal: Not a git repository')
    assert match(command)

    command = ('hg pull', 'abort: no repository found')
    assert match(command)


# Generated at 2022-06-24 07:09:37.418055
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status', output='fatal: Not a git repository')) == 'hg status'



# Generated at 2022-06-24 07:09:42.101877
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git status')) == 'hg status')
    assert(get_new_command(Command('git commit -mmsg')) == 'hg commit -mmsg')
    assert(get_new_command(Command('git log')) == 'hg log')



# Generated at 2022-06-24 07:09:43.492175
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add -A') == 'hg add'

# Generated at 2022-06-24 07:09:46.477230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git add') == 'hg add'
    assert get_new_command('git remote') == 'hg remote'

# Generated at 2022-06-24 07:09:51.064076
# Unit test for function get_new_command
def test_get_new_command():
    # This test is checking that get_new_command changes 'git' to the current
    # path's scm command
    assert get_new_command(Command('git status', 'abort: no repository found',
                                   '/home/alex/work/proj')) == 'hg status'

# Generated at 2022-06-24 07:09:54.450174
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git s') == 'hg s'
    assert get_new_command('git add') == 'hg add'
    assert get_new_command('git pull') == 'hg pull'
    assert get_new_command('git push') == 'hg push'

# Generated at 2022-06-24 07:09:59.191083
# Unit test for function match
def test_match():
    assert not match(Command('git diff',
                             output=
                             'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match((Command('git diff',
                          output='fatal: Not a git repository (or any of the parent directories): .git\n')))



# Generated at 2022-06-24 07:10:03.915387
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_hg import get_new_command
    assert get_new_command(Command('git status', 'fatal: Not a git repository', '')) == 'hg status'
    assert get_new_command(Command('git status', 'fatal: Not a git repository', '')) == 'hg status'

# Generated at 2022-06-24 07:10:07.036103
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command = Mock(script_parts=['git', 'branch'], output="fatal: Not a git repository")
    assert get_new_command(command) == 'hg branch'

# Generated at 2022-06-24 07:10:08.409235
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'ls -la') == u'git ls -la'

# Generated at 2022-06-24 07:10:10.832585
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'



# Generated at 2022-06-24 07:10:14.392546
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('wrong_scm commit')) == 'git commit'
	assert get_new_command(Command('wrong_scm init')) == 'git init'
	assert get_new_command(Command('wrong_scm status')) == 'git status'

# Generated at 2022-06-24 07:10:17.350896
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    new_command = get_new_command(Command('git commit'))
    assert new_command.lower() == 'hg commit'

# Generated at 2022-06-24 07:10:19.149824
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status')

# Generated at 2022-06-24 07:10:22.930205
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git add -A',
                      stderr='abort: no repository found',
                      env={'PWD': '/home/mateos/Documents/python-thefuck'})
    assert get_new_command(command) == 'hg add -A'

# Generated at 2022-06-24 07:10:32.309718
# Unit test for function match
def test_match():
    assert match(Command('git no-such-branch', 'fatal: Not a git repository'))
    assert not match(Command('git branch', '  branch-name'))
    assert match(Command('hg branch', 'abort: no repository found'))

    # thefuck will search the directory tree to find the right SCM
    with mock.patch('os.path.isdir') as isdir,\
         mock.patch('os.walk') as walk:
        isdir.return_value = False
        assert not match(Command('git branch', 'fatal: Not a git repository'))

        isdir.return_value = True

# Generated at 2022-06-24 07:10:32.913398
# Unit test for function match
def test_match():
    match(Command('git status', None))


# Generated at 2022-06-24 07:10:37.023054
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git commit -v') == u'hg commit -v'
    assert get_new_command(u'git branch -a') == u'hg branch -a'
    assert get_new_command(u'git add --all') == u'hg add --all'


# Generated at 2022-06-24 07:10:41.274035
# Unit test for function match
def test_match():
    assert not match(Command('git', '', ''))
    assert not match(Command('hg', '', ''))

    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert match(Command('hg', '', 'abort: no repository found'))



# Generated at 2022-06-24 07:10:44.025293
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.run_scm import get_new_command
    assert get_new_command('git commit') == 'hg commit'
    assert get_new_command('git push') == 'hg push'

# Generated at 2022-06-24 07:10:46.441204
# Unit test for function match
def test_match():
    result = match(Command('git add .', 'fatal: Not a git repository'))
    assert result


# Generated at 2022-06-24 07:10:54.386683
# Unit test for function match
def test_match():
    command = Command("git status")
    command.output = "fatal: Not a git repository"
    assert match(command) == True

    command = Command("git status")
    command.output = "abort: Not a git repository"
    assert match(command) == False

    command = Command("hg status")
    command.output = "abort: Not a hg repository"
    assert match(command) == True

    command = Command("hg status")
    command.output = "fatal: Not a hg repository"
    assert match(command) == False


# Generated at 2022-06-24 07:10:59.276183
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal error'))
    assert match(Command('hg status', 'Some error message'))
    assert not match(Command('git status', 'Some error message'))
    assert not match(Command('hg status', 'fatal error'))


# Generated at 2022-06-24 07:11:03.286945
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Mock(script='git commit', script_parts=['git', 'commit'])) == 'hg commit'
    assert get_new_command(Mock(script='hg pull', script_parts=['hg', 'pull'])) == 'git pull'

# Generated at 2022-06-24 07:11:04.946845
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("hg init", "wrong_scm_pattern")) == "git init"

# Generated at 2022-06-24 07:11:07.901261
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository','')
    assert match(command)
    command = Command('hg status', 'abort: no repository found','')
    assert matc

# Generated at 2022-06-24 07:11:15.969718
# Unit test for function get_new_command
def test_get_new_command():
    command = "git add ."
    command2 = "git add ./"
    command3 = "git add ./file.txt"
    command4 = "git add C:\\temp\\"
    new_command = get_new_command(Command(command, ""))
    new_command2 = get_new_command(Command(command2, ""))
    new_command3 = get_new_command(Command(command3, ""))
    new_command4 = get_new_command(Command(command4, ""))
    assert new_command == "hg add ."
    assert new_command2 == "hg add ./"
    assert new_command3 == "hg add ./file.txt"
    assert new_command4 == "hg add C:\\temp\\"

# Generated at 2022-06-24 07:11:18.297255
# Unit test for function get_new_command
def test_get_new_command():
    command = create_command('git status')
    assert get_new_command(command) == 'hg status'


# Generated at 2022-06-24 07:11:19.637130
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git add .", "")) == "hg add ."

# Generated at 2022-06-24 07:11:24.825027
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git diff', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'status'))
    assert not match(Command('git status', 'status'))

# Generated at 2022-06-24 07:11:27.571605
# Unit test for function match
def test_match():
    command = Command('hg pull', '', 'abort: no repository found')
    assert match(command)
    command = Command('git pull', '', 'fatal: Not a git repository')
    assert match(command)


# Generated at 2022-06-24 07:11:29.271239
# Unit test for function match
def test_match():
    assert ('hg status' in 'abort: no repository found')

# Generated at 2022-06-24 07:11:30.783961
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'


# Generated at 2022-06-24 07:11:35.909154
# Unit test for function match
def test_match():
    # Test case: wrong scm
    command = Command(script='git status', stderr='fatal: Not a git repository')
    assert match(command)

    # Test case: right scm
    command = Command(script='git status', stderr='fatal: Not a git repository', env={'HOME': '/tmp/home'})
    assert not match(command)


# Generated at 2022-06-24 07:11:40.932510
# Unit test for function match
def test_match():
    # Test Git input
    assert match(Command('git stash',
        'fatal: Not a git repository',
        '', 'git'))
    # Test Mercurial input
    assert not match(Command('hg status', 
        '', '', 'hg'))
    # Test no input
    assert not match(Command('', ''))



# Generated at 2022-06-24 07:11:42.411882
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg status')
    assert get_new_command(command) == 'git status'

# Generated at 2022-06-24 07:11:43.799484
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg status') == 'git status'

# Generated at 2022-06-24 07:11:46.548661
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', wrong_scm_patterns['git'])
    assert get_new_command(command) == 'hg push origin master'

# Generated at 2022-06-24 07:11:48.674005
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git config --global core.editor vim')
    assert get_new_command(command) == 'hg config --global core.editor vim'

# Generated at 2022-06-24 07:11:50.433640
# Unit test for function match
def test_match():
    command = Command('git commit', 'fatal: Not a git repository')
    assert not match(command)


# Generated at 2022-06-24 07:11:52.186672
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:11:56.850252
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', None)) == True
    assert match(Command('hg commit', 'abort: no repository found', None)) == True
    assert match(Command('hg commit', 'abort: no repository found', None)) == True
    assert match(Command('git status', '', None)) == False



# Generated at 2022-06-24 07:12:01.825099
# Unit test for function match
def test_match():
    """the match function from class Git should return True if wrong scm is used
    """
    from thefuck.types import Command
    wrong_command = Command('git commit',
                            'hg: repository . not found\nfatal: Not a git repository',
                            '', 0)
    matched_command = match(wrong_command)
    assert matched_command == True



# Generated at 2022-06-24 07:12:08.860450
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'git status', u'fatal: Not a git repository')
    cmd = get_new_command(command)
    assert cmd == u'hg status'
    command = Command(u'git push origin master', u'fatal: Not a git repository')
    cmd = get_new_command(command)
    assert cmd == u'hg push origin master'
    command = Command(u'hg status', u'abort: no repository found ')
    cmd = get_new_command(command)
    assert cmd == u'git status'
#------------------------------

# Generated at 2022-06-24 07:12:18.044531
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git some_command', 'fatal: Not a git repository (or any of the parent directories): .git\n', None)) == 'hg some_command'
    assert get_new_command(Command('git another_command', 'fatal: Not a git repository (or any of the parent directories): .git\n', None)) == 'hg another_command'
    assert get_new_command(Command('git unknown_command', 'fatal: Not a git repository (or any of the parent directories): .git\n', None)) == 'hg unknown_command'
    assert get_new_command(Command('hg some_command', 'fatal: Not a git repository (or any of the parent directories): .git\n', None)) == 'hg some_command'

# Generated at 2022-06-24 07:12:20.051126
# Unit test for function match
def test_match():
    assert match(Command('git push'))
    assert not match(Command('git push', 'fatal: Not a git repository'))
    assert not match(Command('git push', 'fatal: Not a hg repository'))


# Generated at 2022-06-24 07:12:23.223968
# Unit test for function match
def test_match():
    assert match(Command(script='hg status'))
    assert match(Command(script='git status'))
    assert not match(Command(script='svn status'))


# Generated at 2022-06-24 07:12:25.324638
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository', '')) == 'hg status'


# match test

# Generated at 2022-06-24 07:12:27.256266
# Unit test for function match
def test_match():
    command = Command('git add .', 'fatal: Not a git repository')
    #pdb.set_trace()
    assert match(command)


# Generated at 2022-06-24 07:12:29.872411
# Unit test for function get_new_command
def test_get_new_command():
    class TempCommand:
        script_parts = ['git', 'status']
        output = 'fatal: Not a git repository'
    res = get_new_command(TempCommand())
    assert res == 'hg status'

# Generated at 2022-06-24 07:12:37.405281
# Unit test for function match
def test_match():
    # Test for non-existant directory, scm's both git and hg
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command) == True
    command2 = Command('hg status', 'abort: no repository found')
    assert match(command2) == True

    # Test for existant directory, scm's both git and hg
    command3 = Command('git status', 'fatal: Not a git repository')
    assert match(command3) == True
    command4 = Command('hg status', 'abort: no repository found')
    assert match(command4) == True


# Generated at 2022-06-24 07:12:39.292323
# Unit test for function match
def test_match():
    assert (match('git status') == 'git')
    assert (match('hg status') == 'hg')
    assert (match('svn status') == None)


# Generated at 2022-06-24 07:12:42.417298
# Unit test for function match
def test_match():
    command = "git status"
    command2 = "ls -l"
    command3 = "hg status"
    command4 = "ls -l"
    assert(match(command) == False)
    assert(match(command2) == False)
    assert(match(command3) == False)
    assert(match(command4) == False)


# Generated at 2022-06-24 07:12:44.597513
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git commit -a') == 'hg commit -a'

# Generated at 2022-06-24 07:12:46.784511
# Unit test for function match
def test_match():
    assert match(Command('./fuck', 'fatal: Not a git repository'))
    assert not match(Command('./fuck', 'fatal: Not a hg repository'))

# Generated at 2022-06-24 07:12:48.596964
# Unit test for function match
def test_match():
    command = Command('git status', '\nfatal: Not a git repository')
    assert match(command)

# Generated at 2022-06-24 07:12:50.851357
# Unit test for function match
def test_match():
    assert match(Command('git status', '')) == True
    assert match(Command('hg status', '')) == True



# Generated at 2022-06-24 07:12:54.371066
# Unit test for function match
def test_match():
    command = Command('git stash', '')
    assert match(command) is None

    command = Command('git stash', 'fatal: Not a git repository')
    assert match(command) is True

    command = Command('hg pull', 'abort: no repository found')
    assert match(command) is True


# Generated at 2022-06-24 07:12:56.341404
# Unit test for function match
def test_match():
    assert match(Command('git test.py', 'abort: no repository found', ''))
    assert match(Command('git test.py', '', '')) == False

# Generated at 2022-06-24 07:13:00.231256
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_hg import get_new_command, match

    command = type('Command', (object,), {
        'script': 'git checkout master',
        'script_parts': ['git', 'checkout', 'master'],
        'output': 'error: pathspec \'master\' did not match any file(s) known to git.'})
    assert match(command)
    assert get_new_command(command) == 'hg checkout master'


# Generated at 2022-06-24 07:13:00.800751
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('test') == 'test'

# Generated at 2022-06-24 07:13:03.099047
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.wrong_scm import get_new_command
    assert get_new_command(u'git add') == u'git-difftool add'

# Generated at 2022-06-24 07:13:04.269990
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git commit'



# Generated at 2022-06-24 07:13:08.204402
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'hg add .'
    assert get_new_command('git commit -m "fix typo"') == 'hg commit -m "fix typo"'

# Generated at 2022-06-24 07:13:16.192998
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command(script='git status', stdout='fatal: Not a git repository')) == 'git status'
    assert get_new_command(Command(script='git status', stdout='abort: no repository found')) == 'hg status'
    assert get_new_command(Command(script='git status', stdout='abort: no repository found (try opening a supervisor)')) == 'hg status'
    assert get_new_command(Command(script='git status', stdout='abort: no repository found (try opening a supervisor) (foo)')) == 'hg status'


# Generated at 2022-06-24 07:13:24.379632
# Unit test for function match
def test_match():
    wrong_scm_wrong_command = Command('git branch',
                                      'fatal: Not a git repository (or any parent up to mount point /home)',
                                      '/home/josh/')
    wrong_scm_correct_command = Command('git branch',
                                        'fatal: Not a git repository (or any parent up to mount point /home)',
                                        '/home/josh/')

    assert match(wrong_scm_wrong_command)
    assert match(wrong_scm_correct_command)
    assert not match(Command('git branch', '', '/home/josh/'))
    assert not match(Command('hg branch', '', '/home/josh/'))



# Generated at 2022-06-24 07:13:29.512041
# Unit test for function match
def test_match():
    result = match(Command('git foo', 'fatal: Not a git repository'))
    assert result.bool is True

    result = match(Command('hg foo', 'abort: no repository found'))
    assert result.bool is True

    result = match(Command('git foo', 'foo bar'))
    assert result.bool is False

    result = match(Command('hg foo', 'joe bar'))
    assert result.bool is False


# Generated at 2022-06-24 07:13:33.022274
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git log')) == 'git log'
    assert get_new_command(Command('git log -p')) == 'git log -p'
    assert get_new_command(Command('hg status')) == 'hg status'
    assert get_new_command(Command('hg ci')) == 'hg ci'


# Generated at 2022-06-24 07:13:37.549335
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command('git branch', ''))
    assert not match(Command('hg branch', ''))


# Generated at 2022-06-24 07:13:39.045893
# Unit test for function match
def test_match():
    script = Script('git status')
    assert match(script) == False

# Generated at 2022-06-24 07:13:41.338319
# Unit test for function get_new_command
def test_get_new_command():
    command = types.Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:13:44.553452
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git' == _get_actual_scm()
    assert 'git log' == get_new_command('hg log')
    assert 'git add' == get_new_command('hg add')
    

# Generated at 2022-06-24 07:13:52.543004
# Unit test for function match
def test_match():

    from thefuck.rules.wrong_scm import match

    # Make sure we always have an actual git repo for testing
    path = os.getcwd()

    if os.path.isdir(".git"):
        pass
    else:
        os.system("git init > /dev/null")

    # Test when we have a git repo but user runs hg
    command = MagicMock(script='hg status',
                        script_parts=['hg', 'status'],
                        output="abort: no repository found!",
                        stderr="abort: no repository found!")
    assert match(command)


# Generated at 2022-06-24 07:13:53.982760
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'git: \'status\' is not a git command')
    assert 'hg status' == get_new_command(command)

# Generated at 2022-06-24 07:13:55.851888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) == 'git status'

# Generated at 2022-06-24 07:13:58.208845
# Unit test for function match
def test_match():
    command = Command("git branches", "fatal: Not a git repository")
    assert match(command)

    command = Command("hg branches", "abort: no repository found")
    assert match(command)


# Generated at 2022-06-24 07:13:59.630096
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git command") == "hg command"
    assert get_new_command("git command --help") == "hg command --help"

# Generated at 2022-06-24 07:14:02.471412
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git checkout master')) == 'hg checkout master'

available = ['hg', 'git']

# Generated at 2022-06-24 07:14:04.820451
# Unit test for function match
def test_match():
    assert match(command=Command('git pull origin master',
        output='fatal: Not a git repository (or any of the parent directories): .git'))


# Generated at 2022-06-24 07:14:07.465419
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git status", """
fatal: Not a git repository (or any of the parent directories): .git
""")
    
    assert get_new_command(command) == "hg status"


# Generated at 2022-06-24 07:14:10.819042
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "hello"') == 'hg commit -m "hello"'
    assert get_new_command('hg push') == 'git push'

# Generated at 2022-06-24 07:14:13.827199
# Unit test for function match
def test_match():
    assert match(Command('git status', wrong_scm_patterns['git']))
    assert match(Command('hg status', wrong_scm_patterns['hg']))
    assert match(Command('git status', wrong_scm_patterns['hg'])) is False


# Generated at 2022-06-24 07:14:15.099854
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'hg push origin master'



# Generated at 2022-06-24 07:14:16.434123
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command(MagicMock(script_parts=["git", "status"])) == "hg status"

# Generated at 2022-06-24 07:14:20.904672
# Unit test for function match
def test_match():
    # Returns False if command is from wrong SCM but the output is not showing wrong repo
    assert not match(Command('git status', ''))
    # Returns False if command is from wrong SCM but the output is showing wrong repo does NOT exist
    assert not match(Command('git status', 'fatal: Not a git repository'))
    # Returns True if command is from wrong SCM and the output is showing wrong repo
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-24 07:14:25.009975
# Unit test for function match
def test_match():
    assert match(Command('git commit', 'fatal: Not a git repository'))
    assert match(Command('hg pull', 'abort: no repository found'))
    assert not match(Command('git commit', 'fatal: Not a hg repository'))
    assert not match(Command('hg commit', 'abort: Not a git repository'))
    assert not match(Command('hg pull', 'abort: hg repository found'))


# Generated at 2022-06-24 07:14:26.386583
# Unit test for function match
def test_match():
    command = Command('git status', '', '/home/will/git_repo/')
    assert match(command)
    assert 'hg' == _get_actual_scm()



# Generated at 2022-06-24 07:14:27.459166
# Unit test for function match
def test_match():
	assert match(Command(script='git push origin master',output=wrong_scm_patterns['git']))


# Generated at 2022-06-24 07:14:30.194322
# Unit test for function get_new_command

# Generated at 2022-06-24 07:14:32.260317
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) == 'hg status'

# Generated at 2022-06-24 07:14:33.590936
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:14:34.904583
# Unit test for function get_new_command
def test_get_new_command():
    assert('git add .') == get_new_command("hg add .")

# Generated at 2022-06-24 07:14:38.053258
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git foo', '', 'fatal: Not a git repository')) == 'hg foo'

# Generated at 2022-06-24 07:14:40.157099
# Unit test for function get_new_command
def test_get_new_command():
    _get_actual_scm = lambda: "hg"
    assert get_new_command(Command(script='git status')) == u'hg status'

# Generated at 2022-06-24 07:14:45.172978
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', ''))
    assert match(Command('git status', 'fatal: Not a git repositor'))
    assert not match(Command('git status', 'fatal: Not a git repository',
                             ''))
    assert not match(Command('hg status', 'abort: no repository found'))

#Unit test for function get_new_command

# Generated at 2022-06-24 07:14:46.480719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:14:51.724183
# Unit test for function match
def test_match():
    from thefuck import shells
    from thefuck.shells import git
    assert match(git.and_(wrong_scm_patterns['git'], get_new_command=lambda c: c))
    assert not match(git.and_(wrong_scm_patterns['hg'], get_new_command=lambda c: c))

# Generated at 2022-06-24 07:14:56.090381
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository', None)
    assert match(command)
    command = Command('git status', 'is up to date', None)
    assert not match(command)
    command = Command('hg status', 'abort: no repository found', None)
    assert match(command)


# Generated at 2022-06-24 07:15:01.460588
# Unit test for function match
def test_match():
    output = "fatal: Not a git repository (or any of the parent directories): .git"
    wrong_command = "git checkout my_feature_branch"
    assert match(Command(wrong_command, output))

    output = "abort: no repository found in "
    wrong_command = "hg push"
    assert match(Command(wrong_command, output))


# Generated at 2022-06-24 07:15:03.968059
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git push origin master')) == 'hg push origin master'

# Generated at 2022-06-24 07:15:08.639048
# Unit test for function match
def test_match():
    assert match(Command('hg', '', 'abort: no repository found!'))
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert not match(Command('git', '', 'some error'))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-24 07:15:09.756641
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit") == "hg commit"

# Generated at 2022-06-24 07:15:12.855705
# Unit test for function match
def test_match():
    {'git status': 'fatal: Not a git repository',
     'git branch': 'fatal: Not a git repository',
     'git commit': 'fatal: Not a git repository',
     'hg commit': 'abort: no repository found'}


# Generated at 2022-06-24 07:15:23.778559
# Unit test for function match
def test_match():
    # git in path
    # git not in path
    # hg in path
    # hg not in path
    assert not match(Command('hg status',
                             ''))
    assert match(Command('git status',
                         ''))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', '',
                             '/usr/local/bin:/usr/bin:/bin',
                             '/usr/local/bin:/usr/bin:/bin:/bin'))
    assert match(Command('hg status', '',
                        '',
                        '/usr/bin:/bin'))

# Generated at 2022-06-24 07:15:27.267392
# Unit test for function get_new_command
def test_get_new_command():
    # scenario 1
    command = Command('git status')
    assert get_new_command(command) == 'hg status'

    # scenario 2
    command = Command('git push origin master')
    assert get_new_command(command) == 'hg push origin master'



# Generated at 2022-06-24 07:15:28.568541
# Unit test for function match
def test_match():
    command = Command('git status', 'output')
    assert match(command)

# Generated at 2022-06-24 07:15:29.744808
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg diff') == 'git diff'

# Generated at 2022-06-24 07:15:31.490245
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', '')
    new_command = get_new_command(command)
    assert new_command == 'hg status'

# Generated at 2022-06-24 07:15:33.615332
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git log')) == 'hg log'

# Generated at 2022-06-24 07:15:40.456324
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status', output='fatal: Not a git repository')) == u'hg status'
    assert get_new_command(Command(script='hg status', output='abort: no repository found')) == u'git status'
    assert get_new_command(Command(script='hg status', output='abort: no repository found')) == u'git status'
    assert get_new_command(Command(script='git status', output='abort: no repository found')) == u'hg status'
    assert get_new_command(Command(script='hg status', output='fatal: Not a git repository')) == u'git status'

# Generated at 2022-06-24 07:15:41.643573
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', 'fatal: Not a git repository')) == u'hg status'

# Generated at 2022-06-24 07:15:51.335671
# Unit test for function get_new_command
def test_get_new_command():
    # test git
    before = 'git add --all'
    after = 'git add --all'
    assert(get_new_command(before) == after)
    before = 'git checkout master'
    after = 'hg checkout master'
    assert(get_new_command(before) == after)
    before = 'git commit'
    after = 'git commit'
    assert(get_new_command(before) == after)
    # test hg
    before = 'hg diff'
    after = 'hg diff'
    assert(get_new_command(before) == after)
    before = 'hg commit'
    after = 'hg commit'
    assert(get_new_command(before) == after)
    before = 'hg update'
    after = 'hg update'

# Generated at 2022-06-24 07:15:54.466259
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git remote -v', 'fatal: Not a git repository', None)) == 'hg remote -v'
    assert get_new_command(Command('git remote -v', 'abort: no repository found', None)) == 'git remote -v'

# Generated at 2022-06-24 07:15:57.255499
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status',
                                   output='fatal: Not a git repository')) == 'git status'
    assert get_new_command(Command(script='hg status',
                                   output='abort: no repository found')) == 'hg status'


# Generated at 2022-06-24 07:15:59.387448
# Unit test for function get_new_command
def test_get_new_command():

    class command:
        script_parts = ['git', 'status']
        output = "fatal: Not a git repository"

    assert u'hg status' == get_new_command(command)

# Generated at 2022-06-24 07:16:08.187457
# Unit test for function match
def test_match():
    assert match(Command('git merge helloworld', 'fatal: Not a git repository (or any parent up to mount point /vagrant)\nStopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).\n')) == True
    assert match(Command('git merge helloworld', 'fatal: Not a git repository (or any parent up to mount point /vagrant)\nStopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).\n')) == True
    assert match(Command('hg push helloworld', 'abort: no repository found!\n(create a repository with \'hg init\' or specify a path with \'hg --repository REPO\')\n')) == True

# Generated at 2022-06-24 07:16:10.100779
# Unit test for function match
def test_match():
    command = Command(script='git commit')
    command.output = 'fatal: Not a git repository'
    assert match(command)


# Check if function get_new_command returns the correct command

# Generated at 2022-06-24 07:16:12.321062
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status") == "hg status", "git status is translated to hg status"


# Generated at 2022-06-24 07:16:20.176768
# Unit test for function match
def test_match():
    command = Command('not a real command')
    command.script_parts = ['not','in','a','scm']
    assert match(command) is False
    command.script_parts = ['in','a','scm']

    # Wrong scm
    command.output = 'fatal: Not a git repository (or any of the parent directories): .git'
    assert match(command) is False
    command.output = 'abort: no repository found in .'
    assert match(command) is False

    # Wrong scm and correct path
    command.output = 'fatal: Not a git repository (or any of the parent directories): .hg'
    assert match(command) is True
    command.output = 'abort: no repository found in .git'
    assert match(command) is True


# Generated at 2022-06-24 07:16:25.821869
# Unit test for function match
def test_match():
    assert match(Command('git status',
            'fatal: Not a git repository',
            path='/home/ck/'))
    assert match(Command('git status',
            'fatal: Not a git repository',
            path='/home/ck/.hg'))
    assert not match(Command('git status',
            'fatal: Not a git repository',
            path='/home/ck/.git'))


# Generated at 2022-06-24 07:16:27.445616
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit', '')
    assert get_new_command(command) == u'hg commit'

# Generated at 2022-06-24 07:16:35.680703
# Unit test for function match
def test_match():
    output1 = 'git: \'c\' is not a git command. See \'git --help\'.\n\
The most similar command is checkout'
    output2 = 'fatal: Not a git repository (or any of the parent directories): .git'
    output3 = 'abort: no repository found in /etc/init.d/'
    output4 = 'fatal: Not a git repository (or any of the parent directories): .git'

    command1 = Command(output1, 'git c')
    command2 = Command(output2, 'git status')
    command3 = Command(output3, 'hg status')
    command4 = Command(output4, 'git status')
    assert not match(command1)
    assert not match(command2)
    assert not match(command3)
    assert match(command4)

# Unit

# Generated at 2022-06-24 07:16:43.873330
# Unit test for function get_new_command
def test_get_new_command():
    # Test replacing "git" with "hg"
    command = Command('git diff')
    new_command = get_new_command(command)

    assert new_command == 'hg diff'

    # Test replacing "hg" with "git"
    command = Command('hg status')
    new_command = get_new_command(command)

    assert new_command == 'git status'

    # Test replacing "hg" with "git" with other options
    command = Command('hg status -v')
    new_command = get_new_command(command)

    assert new_command == 'git status -v'

# Generated at 2022-06-24 07:16:46.389364
# Unit test for function match
def test_match():
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert not match(Command('git', '', 'command not found'))


# Generated at 2022-06-24 07:16:49.294818
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    command.script_parts = ['git', 'status']
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:16:52.518122
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.not_a_git_repo import get_new_command
    assert get_new_command(command=
                           'git commit -m "test"') == 'hg commit -m "test"'

# Generated at 2022-06-24 07:16:58.564803
# Unit test for function get_new_command
def test_get_new_command():
    def assert_get_new_command(script, scm_in, scm_out):
        command = type('command', (object,), {'output':'', 'script_parts': script.split(' ')})
        assert get_new_command(command) == ' '.join([scm_out] + script.split(' ')[1:])

    assert_get_new_command('git init', 'git', 'git')
    assert_get_new_command('hg init', 'hg', 'hg')
    assert_get_new_command('git init', 'hg', 'git')
    assert_get_new_command('hg init', 'git', 'hg')

# Generated at 2022-06-24 07:17:02.197190
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == u'hg status'
    assert get_new_command(Command('hg status')) == u'git status'
    assert get_new_command(Command('git status rhg')) == u'hg status rhg'
    assert get_new_command(Command('hg status rgit')) == u'git status rgit'

# Generated at 2022-06-24 07:17:03.120488
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command("git add . ")

# Generated at 2022-06-24 07:17:06.034612
# Unit test for function match
def test_match():
    assert match(Command('git status', wrong_scm_patterns['git']))
    assert match(Command('hg diff', wrong_scm_patterns['hg']))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg diff', 'diff --git a/b/c b'))


# Generated at 2022-06-24 07:17:07.457092
# Unit test for function match
def test_match():
    assert no_scm.match(Command('git help', 'fatal: Not a git repository'))
    assert no_scm.match(Command('hg help', 'abort: no repository found'))


# Generated at 2022-06-24 07:17:16.086332
# Unit test for function match
def test_match():
    # match 1
    git_commands = ['git init', 'git clone https://github.com/nvbn/thefuck', 'git commit -m "example"']
    git_result = 'fatal: Not a git repository (or any of the parent directories): .git'
    git = Command(git_commands[0], git_result)
    assert match(git)
    # match 2
    hg_commands = ['hg init', 'hg clone https://github.com/nvbn/thefuck', 'hg commit -m "example"']
    hg_result = 'abort: no repository found in /path/to/current/dir/ (or any parent directory)'
    hg = Command(hg_commands[0], hg_result)
    assert match(hg)
    # not match 1
    git

# Generated at 2022-06-24 07:17:21.001763
# Unit test for function match
def test_match():
    from thefuck.rules.git_mixed_up_with_mercurial import match
    assert match(
        'git commit -m "fixes"',
        'fatal: Not a git repository')
    assert not match(
        'hg commit -m "fixes"',
        'fatal: Not a git repository')
    assert not match(
        'git commit -m "fixes"',
        '')
    assert not match(
        'this is a funny command',
        'hg: command not found')


# Generated at 2022-06-24 07:17:25.340100
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', ''))
