

# Generated at 2022-06-24 07:07:28.498414
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add file') == 'hg add file'

# Generated at 2022-06-24 07:07:34.930602
# Unit test for function match
def test_match():
    assert match(Command('git status',
        '/home/sushil/Documents/git/learn_python/bf\nfatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', '/home/sushil/Documents/\nfatal: Not a git repository (or any of the parent directories): .git'))

# Generated at 2022-06-24 07:07:37.881340
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command('git status', 'fatal: Not a git repository', '', 0, 'git status'))
    assert str(new_cmd) == 'hg status'

# Generated at 2022-06-24 07:07:42.423174
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('hg status', 'abort: no repository found', ''))
    assert not match(Command('bzr status', '', ''))


# Generated at 2022-06-24 07:07:45.442486
# Unit test for function match
def test_match():
    assert(match('git status'))
    assert(not match('ccialab build'))


# Unit tests for function get_new_command

# Generated at 2022-06-24 07:07:50.696751
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command

    assert get_new_command(Command('git remote -v', '', '')) == 'hg remote -v'
    assert get_new_command(Command('git push -u origin master', '', '')) == 'hg push -u origin master'
    assert get_new_command(Command('git commit -a -m "commiting code"', '', '')) == 'hg commit -a -m "commiting code"'

# Generated at 2022-06-24 07:07:53.093097
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg status', 'abort: no repository found')) == 'git status'


# Generated at 2022-06-24 07:07:57.195190
# Unit test for function match
def test_match():
    command = Command('git status')
    assert not match(command)

    command = Command('git status', 'abort: no repository found')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository')
    assert not match(command)


# Generated at 2022-06-24 07:08:00.550454
# Unit test for function match
def test_match():
    script = u'git branch'
    command_output = u'fatal: Not a git repository'
    assert match(Command(script, command_output))


# Generated at 2022-06-24 07:08:02.576718
# Unit test for function match
def test_match():
  assert match(Command('git status', 'fatal: Not a git repository'))
  assert not match(Command('hg status', 'fatal: Not a git repository'))


# Generated at 2022-06-24 07:08:12.582906
# Unit test for function match
def test_match():
    assert(match(Command('git commit', 'fatal: Not a git repository')))
    assert(match(Command('git commit', 'fatal: Not a git repository (or any of the parent directories): .git')))
    assert(not match(Command('git commit', '')))
    assert(not match(Command('git commit', 'fatal: Not a git repository (or any of the parent directories): .git')))
    assert(not match(Command('git commit', 'fatal: Not a git repository')))
    assert(match(Command('hg commit', 'abort: no repository found')))
    assert(not match(Command('hg commit', '')))
    assert(not match(Command('hg commit', 'abort: no repository found')))


# Generated at 2022-06-24 07:08:16.533309
# Unit test for function get_new_command
def test_get_new_command():
    scm = _get_actual_scm()
    script = ['git', 'commit']
    command = Command(script, 'fatal: Not a git repository')
    assert get_new_command(command) == u' '.join([scm] + script[1:])

# Generated at 2022-06-24 07:08:18.638193
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'hg push'
    assert get_new_command(Command('hg push')) == 'git push'


# Generated at 2022-06-24 07:08:22.521272
# Unit test for function match
def test_match():
    output = u"""fatal: Not a git repository (or any of the parent directories): .git"""
    assert match(Command('git status', output))

    output = u"""abort: no repository found in '/home/hellotamila/' (.hg not found)"""
    assert match(Command('hg status', output))



# Generated at 2022-06-24 07:08:25.269200
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script="git status",
                                          stdout="fatal: Not a git repository"))
    assert new_command.script == "hg status", "new_command is wrong"

# Generated at 2022-06-24 07:08:26.968393
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command('git a')
    assert new_command == 'hg a'

# Generated at 2022-06-24 07:08:28.631163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg commit', '')) == 'git commit'

# Generated at 2022-06-24 07:08:33.176590
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add x.txt', u'git: \'add x.txt\' is not a git command.\ngit: See \'git --help\'.\n', 'git_add.git')
    assert get_new_command(command) == 'hg add x.txt'


# Generated at 2022-06-24 07:08:36.986012
# Unit test for function match
def test_match():
    command = Command(script='git fetch origin a_branch_name', output='fatal: Not a git repository')
    assert match(command)
    command = Command(script='hg push origin a_branch_name', output='abort: no repository found')
    assert match(command)


# Generated at 2022-06-24 07:08:38.473237
# Unit test for function match
def test_match():
    assert match(Command('git status'))
    assert match(Command('hg status'))


# Generated at 2022-06-24 07:08:41.115777
# Unit test for function match
def test_match():
    wrong_command = Command('git status', wrong_scm_patterns['git'])
    assert match(wrong_command)
    assert not match(Command('hg status', wrong_scm_patterns['hg']))



# Generated at 2022-06-24 07:08:50.531687
# Unit test for function match
def test_match():
    assert match(Command('git')).is_false()
    assert match(Command('git status')).is_false()
    assert match(Command('git commit aaaa')).is_false()
    assert match(Command('git commit')).is_false()
    assert match(Command('git commit -m aa')).is_false()
    assert match(Command('git commit -m aa', 'fatal: Not a git repository')).is_true()
    assert match(Command('git commit -m aa', '', 'fatal: Not a git repository')).is_true()
    assert match(Command('git status', 'abort: no repository found')).is_false()
    assert match(Command('hg status', 'abort: no repository found')).is_true()


# Generated at 2022-06-24 07:08:52.603371
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string('git status'))
    assert get_new_command(Command.from_string('hg status'))

# Generated at 2022-06-24 07:08:53.820344
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'

# Generated at 2022-06-24 07:08:57.243446
# Unit test for function match
def test_match():
    command = Command('git commit',
        'fuck: this is not a git repository\n',
        '',
        0,
        'git')

    assert match(command)

    command = Command('fuck commit',
        'fuck: this is not a git repository\n',
        '',
        0,
        'fuck')

    assert match(command) == False



# Generated at 2022-06-24 07:09:04.646948
# Unit test for function match
def test_match():
    wrong_git_output = 'fatal: Not a git repository (or any of the parent directories): .git'
    wrong_hg_output = 'abort: no repository found in /home/huyng/Repos/docksal (search path = [])!'

    assert match(Command('git status', wrong_git_output))
    assert match(Command('hg status', wrong_hg_output))
    assert not match(Command('git status', ''))
    assert not match(Command('hg status', ''))


#  Unit test for function get_new_command

# Generated at 2022-06-24 07:09:11.343276
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository.\n'))
    assert match(Command('git status', 'fatal: Not \n git repository.\n'))
    assert not match(Command('git status', 'git repository.\n'))
    assert not match(Command('hg status', 'abort: no repository found\n'))
    assert not match(Command('hg status', 'abort: no repository\n'))


# Generated at 2022-06-24 07:09:11.933199
# Unit test for function match
def test_match():
    assert match(Command('git status', '/tmp'))

# Generated at 2022-06-24 07:09:14.924477
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository')) == True
    assert match(Command('hg status', 'abort: no repository found')) == True


# Generated at 2022-06-24 07:09:21.798485
# Unit test for function match
def test_match():
    #test cases
    assert match(Command('git status', 'fatal: Not a git repository')) == True
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')) == True
    assert match(Command('hg status', 'abort: no repository found')) == True
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')) == True
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')) == True

    #test for false negatives
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n')) != False

# Generated at 2022-06-24 07:09:26.697807
# Unit test for function match
def test_match():
    assert match(Command('git status',
        'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg status',
        'abort: no repository found in /home/user/.hgrc\n'))
    assert not match(Command('git status'))
    assert not match(Command('hg status'))

# Generated at 2022-06-24 07:09:28.856734
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git status', 'fatal: Not a git repository')) == 'hg status'



# Generated at 2022-06-24 07:09:31.343152
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:09:33.516774
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository'))
    assert not match(Command('git', 'test'))



# Generated at 2022-06-24 07:09:37.143818
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', '')) == 'hg status'
    assert get_new_command(Command('git checkout master', '', '')) == 'hg checkout master'
    assert get_new_command(Command('git branch', '', '')) == 'hg branch'
    assert get_new_command(Command('git push origin master', '', '')) == 'hg push origin master'



# Generated at 2022-06-24 07:09:48.033655
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository (or any of the parent directories): .git\n')) == True
    assert match(Command('git branch', 'fatal: Not a git repository')) == False
    assert match(Command('git branch', 'fatal: Not a hg repository (or any of the parent directories): .hg\n')) == False
    assert match(Command('git branch', 'fatal: Not a hg repository (or any of the parent directories): \n')) == False
    assert match(Command('hg branch', 'abort: no repository found (or any of the parent directories): .hg\n')) == True
    assert match(Command('hg branch', 'abort: no repository found\n')) == False

# Generated at 2022-06-24 07:09:55.047293
# Unit test for function match
def test_match():
    command = Command('git', 'git status', '')
    assert not match(command)

    command = Command('git', 'git status',
                      'fatal: Not a git repository')
    assert not match(command)

    command = Command('git', 'git status',
                      'fatal: Not a git repository (or any of the parent directories): .git')
    assert not match(command)

    command = Command('git', 'git status',
                      'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)

# Generated at 2022-06-24 07:10:00.840185
# Unit test for function match
def test_match():
    assert match(Command('git foo', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg foo', 'abort: no repository found!\n'))
    assert not match(Command('git foo', 'fatal: Not a git repository (or any of the parent directories): .git\nfoo'))

# Generated at 2022-06-24 07:10:06.524554
# Unit test for function get_new_command
def test_get_new_command():
    scm = 'hg'

    mocked_command = FakeCommand('git status', '', '', '')
    assert get_new_command(mocked_command) == 'hg status'

    mocked_command = FakeCommand('git push', '', '', '')
    assert get_new_command(mocked_command) == 'hg push'

    mocked_command = FakeCommand('git branch', '', '', '')
    assert get_new_command(mocked_command) == 'hg branch'


# Generated at 2022-06-24 07:10:07.824571
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status sorry', '', '', '', '')) == 'hg status sorry'

# Generated at 2022-06-24 07:10:09.080495
# Unit test for function match
def test_match():
    assert match(Command(script='hg push', output="abort: no repository found!"))


# Generated at 2022-06-24 07:10:12.076640
# Unit test for function match
def test_match():
    command = Command('git log')
    assert match(command)

    command = Command('hg status')
    assert match(command)

    command = Command('foo log')
    assert not match(command)


# Generated at 2022-06-24 07:10:16.250661
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command('git branch', ''))
    assert not match(Command('git branch', 'fatal: Not a git repository', 'fatal: Not a git repository'))



# Generated at 2022-06-24 07:10:20.959813
# Unit test for function match
def test_match():
    # wrong repo
    output = 'fatal: Not a git repository'
    assert match(Command(script='git', output=output))

    # right repo
    output = 'fatal: Not a git repository (or any of the parent directories): .git'
    assert not match(Command(script='git', output=output))


# Generated at 2022-06-24 07:10:22.734939
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg status')
    assert get_new_command(command) == 'git status'


# Generated at 2022-06-24 07:10:26.903670
# Unit test for function match
def test_match():
    assert match(Command("git status",
                         output=u"fatal: Not a git repository (or any of the parent directories): .git",
                         ))
    assert match(Command("hg status",
                         output=u"abort: no repository found",
                         ))


# Generated at 2022-06-24 07:10:29.674029
# Unit test for function match
def test_match():
    assert match(Command('git foo', 'fatal: Not a git repository', ''))
    assert not match(Command('git foo', '', ''))

# Generated at 2022-06-24 07:10:34.775154
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'hg push') == u'git push'
    assert get_new_command(u'hg push --force') == u'git push --force'
    assert get_new_command(u'git add') == u'git add'
    assert get_new_command(u'git commit --hello') == u'git commit --hello'

# Generated at 2022-06-24 07:10:36.493732
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert u'git pull' == get_new_command(Command(u'hg pull', u''))

# Generated at 2022-06-24 07:10:41.592250
# Unit test for function match
def test_match():
    assert not match(Command(script='git foo', output='fatal: Not a git repository', stderr='fatal: Not a git repository'))
    assert not match(Command(script='hg foo', output='abort: no repository found', stderr='abort: no repository found'))
    assert not match(Command(script='git foo', output=''))


# Generated at 2022-06-24 07:10:44.308786
# Unit test for function match
def test_match():
    assert match(Command("git status")) == False
    assert match(Command("git status", "abort: no repository found")) == False
    assert match(Command("git status", "fatal: Not a git repository")) == True

# Generated at 2022-06-24 07:10:48.615919
# Unit test for function match
def test_match():
    command = Command('hg commit', 'abort: no repository found!\n')
    assert not match(command)

    command = Command('git commit', 'fatal: Not a git repository\n')
    assert match(command)


# Generated at 2022-06-24 07:10:58.776160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(type('obj', (object,), {
            'script_parts': ['git', 'add', 'xxx']})) == 'hg add xxx'
    assert get_new_command(type('obj', (object,), {
            'script_parts': ['hg', 'add', 'xxx']})) == 'git add xxx'
    assert get_new_command(type('obj', (object,), {
            'script_parts': ['git', 'add', '.', '-m', 'xxx']})) == 'hg add . -m xxx'
    assert get_new_command(type('obj', (object,), {
            'script_parts': ['hg', 'add', '.', '-m', 'xxx']})) == 'git add . -m xxx'
    assert get

# Generated at 2022-06-24 07:11:03.999362
# Unit test for function match
def test_match():
    assert match(Command('git init', 'fatal: Not a git repository'))
    assert match(Command('hg init', 'abort: no repository found'))
    assert not match(Command('git init', ''))
    assert not match(Command('hg init', ''))
    assert not match(Command('hg init', 'abort: no repository found'))



# Generated at 2022-06-24 07:11:05.652988
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'

# Generated at 2022-06-24 07:11:10.016446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command([u'git', u'foo']) == u'hg foo'
    assert get_new_command([u'git', u'foo', u'bar']) == u'hg foo bar'
    assert get_new_command([u'git', u'add']) == u'hg add'



# Generated at 2022-06-24 07:11:13.855559
# Unit test for function match
def test_match():
    assert match(Command(script='git add', output='fatal: Not a git repository'))
    assert match(Command(script='git add', output='abort: no repository found'))
    assert not match(Command(script='git add', output='fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))

# Generated at 2022-06-24 07:11:15.554388
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert get_new_command(command) == 'hg status'



# Generated at 2022-06-24 07:11:21.051602
# Unit test for function match
def test_match():
   ### Test for git
   err = "git: 'brnch' is not a git command."
   err = Command(err, 'git brnch')
   assert match(err)
   ### Test for hg
   err = "hg: unknown command 'branch'"
   err = Command(err, 'hg brnch')
   assert match(err)


# Generated at 2022-06-24 07:11:23.722874
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status',
                                   stderr='fatal: Not a git repository')) \
           == 'hg status'

# Generated at 2022-06-24 07:11:26.669441
# Unit test for function match
def test_match():
    assert match('git status') is True
    assert match('git') is True
    assert match('git checkout') is True
    assert match('git push') is True
    assert match('git pull') is True
    assert match('hg add') is True

# Generated at 2022-06-24 07:11:34.040301
# Unit test for function match
def test_match():
    from thefuck.rules.wrong_scm import match
    from thefuck.types import Command

    assert match(Command(script='git add .',
                         stderr='fatal: Not a git repository',
                         script_parts=['git', 'add', '.']))
    assert not match(Command(script='git add .',
                             stderr='fatal: Not a hg repository',
                             script_parts=['git', 'add', '.']))


# Generated at 2022-06-24 07:11:39.914617
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(['git', 'branch']) == 'hg branch'
    assert get_new_command(['git', 'push', 'origin', 'master']) == 'hg push origin master'
    assert get_new_command(['hg', 'pull']) == 'git pull'
    assert get_new_command(['hg', 'push', 'origin', 'master']) == 'git push origin master'

# Generated at 2022-06-24 07:11:43.289509
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script=u"git commit -m \"Test message\"",
    output=u"fatal: Not a git repository\nfatal: Not a git repository\nfatal: Not a git repository\n")) == \
    "hg commit -m \"Test message\""

# Generated at 2022-06-24 07:11:46.928686
# Unit test for function match
def test_match():
    # test no git repo command
    assert match(Command('git status', '')) == True

    # test git repo command
    assert match(Command('git status', 'On branch master\n')) == False

    # test hg repo command
    assert match(Command('hg st', 'hg: unknown command st\n')) == False

# Generated at 2022-06-24 07:11:50.234300
# Unit test for function match
def test_match():
    from thefuck.rules.git_wrong_scm import match
    assert match(Command('git',
                         'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git', '\n'))

# Generated at 2022-06-24 07:11:52.375544
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('git commit'))
    assert 'hg commit' in get_new_command(Command('git commit'))

# Generated at 2022-06-24 07:11:57.255056
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '/home/user/proj')) == 'hg status'
    assert get_new_command(Command('git add .', '/home/user/proj')) == 'hg add .'
    assert get_new_command(Command('git di', '/home/user/proj')) == 'hg di'

# Generated at 2022-06-24 07:11:59.016868
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert match(Command('hg status', ''))
    assert not match(Command('git rebase', ''))
    assert not match(Command('hg rebase', ''))


# Generated at 2022-06-24 07:12:01.105041
# Unit test for function match
def test_match():
    command = Command('git status', '', '/Users/Sharoykin/Documents/Work/Prism')
    assert match(command)


# Generated at 2022-06-24 07:12:04.547205
# Unit test for function get_new_command
def test_get_new_command():
    args = argparse.Namespace(script='', script_parts=['git', 'commit', '-am', 'Adding somemodule'])
    result = get_new_command(args)
    assert result == 'hg commit -am Adding somemodule'

# Generated at 2022-06-24 07:12:08.739286
# Unit test for function match
def test_match():
    assert match(
        Command('git commit -m "foo"',
            output=u'fatal: Not a git repository')) is True
    assert match(
        Command('git commit -m "foo"',
            output=u'[master c4c3b1e] foo')) is False

# Generated at 2022-06-24 07:12:11.235425
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git commit'
    assert get_new_command(command) == 'hg commit'

enabled_by_default = True

# Generated at 2022-06-24 07:12:12.889339
# Unit test for function match
def test_match():
    command = Command('hg hg command', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-24 07:12:15.604039
# Unit test for function match
def test_match():
    assert not match(Command('git status',
                             'fatal: Not a git repository'))
    assert match(Command('hg status',
                         'My Project\n\nnothing to commit'))


# Generated at 2022-06-24 07:12:19.189610
# Unit test for function match
def test_match():
    assert not match(Command(script='hg branch',
                             stderr='abort: no repository found!'))
    assert match(Command(script='hg branch',
                         stderr='abort: no repository found'))
    assert match(Command(script='git branch',
                         stderr='fatal: Not a git repository'))


# Generated at 2022-06-24 07:12:22.677495
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg status')) == 'git status'
    assert get_new_command(Command('git status')) == 'git status'

# Generated at 2022-06-24 07:12:24.866672
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository',
                                    '')) == 'hg status'

# Generated at 2022-06-24 07:12:27.144891
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command("git commit", "")) == "hg commit"


enabled_by_default = (test_get_new_command() == "hg commit")

# Generated at 2022-06-24 07:12:29.525429
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git status', '', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:12:32.579452
# Unit test for function match
def test_match():
    output = "fatal: Not a git repository"
    command = 'git config --global user.email "you@example.com"'

    assert match(Command(command, output))


# Generated at 2022-06-24 07:12:34.100710
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)


# Generated at 2022-06-24 07:12:35.280175
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git status")) == 'hg status'

# Generated at 2022-06-24 07:12:37.916146
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg clone repo', '')) == 'git clone repo'
    assert get_new_command(Command('hg add file1 file2', '')) == 'git add file1 file2'


# Generated at 2022-06-24 07:12:39.499784
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:12:43.220866
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'On branch master'))



# Generated at 2022-06-24 07:12:45.257760
# Unit test for function get_new_command
def test_get_new_command():
    actual_scm = _get_actual_scm()
    assert get_new_command('hg path') == '{} path'.format(actual_scm)

# Generated at 2022-06-24 07:12:47.880594
# Unit test for function match
def test_match():
    # Test when command is right
    command = 'git status'
    assert not match(command)

    # Test when command is wrong
    command = 'hg status'
    assert match(command)

# Generated at 2022-06-24 07:12:51.720364
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'hg add .'
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git commit -m "fix"') == 'hg commit -m "fix"'

# Generated at 2022-06-24 07:12:53.950861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git commit -m "message"', stdout='fatal: Not a git repository')) == 'hg commit -m "message"'

# Generated at 2022-06-24 07:12:57.098227
# Unit test for function match
def test_match():
    assert match(Command('git stash', 'fatal: Not a git repository'))
    assert match(Command('hg revert', 'abort: no repository found'))
    assert not match(Command('git stash', ''))
    assert not match(Command('hg revert', ''))


# Generated at 2022-06-24 07:12:59.636828
# Unit test for function match
def test_match():
    assert match(Command(script='git lol', output='fatal: Not a git repository'))
    assert not match(Command(script='git lol', output='fatal: Not a hg repository'))
    assert not match(Command(script='git lol', output='fatal: shit'))



# Generated at 2022-06-24 07:13:02.019141
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    input_ = Command('git reset --hard HEAD^', 'C:/')
    expected = 'hg reset --hard HEAD^'
    assert get_new_command(input_) == expected

# Generated at 2022-06-24 07:13:03.401742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(['git', 'add', 'foo']) == 'hg add foo'

# Generated at 2022-06-24 07:13:13.829573
# Unit test for function match
def test_match():
    assert match(Command(script='git status', output='fatal: Not a git repository'))
    assert match(Command(script='git status', output='fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command(script='hg status', output='abort: no repository found'))
    assert match(Command(script='hg status', output='abort: repository /Users/user/.ssh not found'))
    assert not match(Command(script='echo hello', output='hello'))
    assert not match(Command(script='git status', output='On branch master'))
    assert not match(Command(script='hg status', output='comparing with /Users/user/Projects/repo'))


# Generated at 2022-06-24 07:13:17.339502
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'fatal: Not a git repository')) == 'hg add'
    assert get_new_command(Command('hg add', 'abort: no repository found')) == 'git add'

# Generated at 2022-06-24 07:13:21.303308
# Unit test for function match
def test_match():
    command = Command('git branch', u'fatal: Not a git repository (or any of the parent directories): .git')
    assert(match(command))
    command = Command('hg branch', u'abort: no repository found in /home/travis/build/ultimate-setup/thefuck/thefuck/.hg')
    assert(match(command))

# Generated at 2022-06-24 07:13:26.080756
# Unit test for function match
def test_match():
    command1 = Command('git status', 'fatal: Not a git repository')
    assert match(command1)
    command2 = Command('hg status', 'abort: no repository found')
    assert match(command2)
    command3 = Command('git status', 'On branch master')
    assert not match(command3)


# Generated at 2022-06-24 07:13:28.901944
# Unit test for function match
def test_match():
    assert match(Command('git commit',
        'fatal: Not a git repository', '', 'current_dir', 2))
    assert match(Command('hg commit',
        'abort: no repository found', '', 'current_dir', 2))


# Generated at 2022-06-24 07:13:30.575382
# Unit test for function get_new_command
def test_get_new_command():
    """Test the work of get_new_command function"""
    assert get_new_command(Command('git add', '')) == 'hg add'

# Generated at 2022-06-24 07:13:38.385356
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git add .') == 'hg add .'
    assert get_new_command('git init') == 'hg init'
    assert get_new_command('git fetch') == 'hg fetch'
    assert get_new_command('git pull') == 'hg pull'
    assert get_new_command('git push') == 'hg push'
    assert get_new_command('git branch') == 'hg branch'
    assert get_new_command('git checkout') == 'hg checkout'

# Generated at 2022-06-24 07:13:40.412008
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('ls')
    command.output = 'output'
    assert get_new_command(command) == 'git ls'

# Generated at 2022-06-24 07:13:42.233239
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git commit' == get_new_command(Command('hg commit', '', ''))

# Generated at 2022-06-24 07:13:49.721925
# Unit test for function get_new_command
def test_get_new_command():
    # Setup
    class Command(object):
        def __init__(self, script_parts):
            self.script_parts = script_parts

        def __unicode__(self):
            return u' '.join(self.script_parts)

    # Test
    assert get_new_command(Command(['git', 'stash'])) == 'hg stash'
    assert get_new_command(Command(['hg', 'add', '.'])) == 'git add .'
    assert get_new_command(Command(['hg', 'commit'])) == 'git commit'

# Generated at 2022-06-24 07:13:54.421576
# Unit test for function match
def test_match():
    assert match(Command('git stash', 'fatal: Not a git repository'))
    assert match(Command('git stash', 'abort: working directory has revisions not on a remote'))

    not_match(Command('git stash', 'fatal: Not a git repository', 'fatal: Not a git repository'))
    not_match(Command('git stash', 'abort: working directory has revisions not on a remote', 'abort: working directory has revisions not on a remote'))


# Generated at 2022-06-24 07:13:58.422300
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('svn status', ''))



# Generated at 2022-06-24 07:14:00.661086
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status')) == 'hg status'
    assert get_new_command(Command(script='git init')) == 'hg init'

# Generated at 2022-06-24 07:14:04.744039
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: Not a git repository'))
    assert match(Command('git push', 'abort: no repository found'))
    assert not match(Command('git push', 'fatal: not a repository'))


# Generated at 2022-06-24 07:14:12.346999
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository', '', 'git'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert match(Command('hg status', 'abort: no repository found', '', 'hg'))

    assert not match(Command('git status', 'fatal: Not a git repository', '', 'hg'))
    assert not match(Command('hg status', 'abort: no repository found', '', 'git'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found'))



# Generated at 2022-06-24 07:14:17.542974
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -am "Blah"') == 'hg commit -m "Blah"'
    assert get_new_command('git push') == 'hg push'
    assert get_new_command('git checkout master') == 'hg update master'
    assert get_new_command('git log') == 'hg log'
    assert get_new_command('git merge master') == 'hg merge master'

# Generated at 2022-06-24 07:14:24.116611
# Unit test for function match
def test_match():
    # git -> hg
    command_git = Command('git status', 'fatal: Not a git repository')
    assert match(command_git) == True
    new_command_git = get_new_command(command_git)
    assert new_command_git == 'hg status'

    # hg -> git
    command_hg = Command('hg status', 'abort: no repository found')
    assert match(command_hg) == True
    new_command_hg = get_new_command(command_hg)
    assert new_command_hg == 'git status'

# Generated at 2022-06-24 07:14:26.959884
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'


enabled_by_default = __name__ != '__main__'

# Generated at 2022-06-24 07:14:29.143561
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg push') == 'git push'
    assert get_new_command('hg status') == 'git status'

# Generated at 2022-06-24 07:14:37.895598
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git status', output='fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

    command = Command(script='hg status', output='abort: no repository found')
    assert get_new_command(command) == 'git status'

    command = Command(script='hg init', output='abort: no repository found')
    assert get_new_command(command) == 'git init'

    command = Command(script='git add .', output='fatal: Not a git repository')
    assert get_new_command(command) == 'hg add .'



# Generated at 2022-06-24 07:14:40.944013
# Unit test for function match
def test_match():
    output = '''fatal: Not a git repository (or any of the parent directories): .git
'''
    input = 'git push origin master'
    command = Command(input, output)
    assert match(command)


# Generated at 2022-06-24 07:14:43.577493
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script_parts': ['git', 'status']})
    
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:14:46.612247
# Unit test for function match
def test_match():
    command = Command('git stash list', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git stash list', '')
    assert not match(command)
    command = Command('hg stash list', '')
    assert not match(command)


# Generated at 2022-06-24 07:14:47.610016
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff') == 'hg diff'

# Generated at 2022-06-24 07:14:49.453679
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) == 'hg status'

# Generated at 2022-06-24 07:14:54.538049
# Unit test for function match
def test_match():
    assert match(Command(script='hg push', output='abort: no repository found')) == True
    assert match(Command(script='git push', output='fatal: Not a git repository')) == True
    assert match(Command(script='git push', output='git: \'push\' is not a git command. See \'git --help\'.')) == False


# Generated at 2022-06-24 07:14:56.913642
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('git status', '', '', '', 'fatal: Not a git repository', '', '', '', '')) == 'hg status'

# Generated at 2022-06-24 07:14:58.761511
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("hg commit -m \"OK\"", "")
    assert get_new_command(command) == "git commit -m \"OK\""

# Generated at 2022-06-24 07:15:01.722363
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git commit') == 'hg commit'

# Generated at 2022-06-24 07:15:03.188375
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git status') == u'hg status'

# Generated at 2022-06-24 07:15:04.362447
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:15:11.711299
# Unit test for function get_new_command
def test_get_new_command():
    from mock import patch
    from thefuck.types import Command
    from thefuck.rules.wrong_scm import get_new_command as tget_new_command

    with patch('thefuck.rules.wrong_scm.path_to_scm', {'.git': 'git', '.hg': 'hg'}):
        with patch('thefuck.rules.wrong_scm._get_actual_scm', return_value='git'):
            assert tget_new_command(Command('hg command', '', '')) == 'git command'

# Generated at 2022-06-24 07:15:19.524693
# Unit test for function match
def test_match():
    # Test for error command output
    errors = ['fatal: Not a git repository', 'abort: no repository found']

    for error in errors:
        assert match(Command('git status', error))
        assert match(Command('hg status', error))

    # Test for non error command output
    assert not match(Command('git status', 'test'))
    assert not match(Command('git commit', 'test'))
    assert not match(Command('hg status', 'test'))
    assert not match(Command('hg diff', 'test'))


# Generated at 2022-06-24 07:15:28.748440
# Unit test for function match
def test_match():
    cwd = os.getcwd()
    os.chdir('/tmp')
    assert match(Command('git status', '/tmp'))
    assert match(Command('hg status', '/tmp'))
    assert not match(Command('git status', cwd))
    assert not match(Command('hg status', cwd))
    assert match(Command('git status', '/tmp', 'git'))
    assert match(Command('hg status', '/tmp', 'hg'))
    assert not match(Command('git status', cwd, 'git'))
    assert not match(Command('hg status', cwd, 'hg'))
    os.chdir(cwd)


# Generated at 2022-06-24 07:15:30.945357
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status')) == 'hg status'
    assert get_new_command(Command(script='hg add file')) == 'git add file'

# Generated at 2022-06-24 07:15:32.056482
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git log') == 'hg log'

# Generated at 2022-06-24 07:15:33.577460
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-24 07:15:35.555733
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:15:36.797126
# Unit test for function match
def test_match():
    command = ''
    assert match(command) is None

# Generated at 2022-06-24 07:15:39.662606
# Unit test for function match
def test_match():
    match_test = Command('git status', r'fatal: Not a git repository ')
    assert match(match_test)


# Generated at 2022-06-24 07:15:41.535052
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script_parts': ['git', 'init']})
    assert get_new_command(command) == 'hg init'

# Generated at 2022-06-24 07:15:43.676832
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg summary'

# Generated at 2022-06-24 07:15:46.791469
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git add') == 'hg add'
    assert get_new_command('git commit') == 'hg commit'



# Generated at 2022-06-24 07:15:48.714622
# Unit test for function match
def test_match():
    assert match(Command("git pull", "fatal: Not a git repository"))
    assert not match(Command("git pull", "Aborting"))



# Generated at 2022-06-24 07:15:53.022041
# Unit test for function match
def test_match():
    assert(match(Command('git status', '', 'fatal: Not a git repository')))
    assert(match(Command('git status', '', 'abcdefg fatal: Not a git repository')))
    assert(not match(Command('git status', '', 'abcdefg')))
    assert(match(Command('hg push', '', 'abort: no repository found')))
    assert(not match(Command('hg push', '', 'abort: no repository found abc')))


# Generated at 2022-06-24 07:15:54.507212
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'fatal: Not a git repository')) == 'hg push'

# Generated at 2022-06-24 07:15:57.425356
# Unit test for function match
def test_match():
    command = Command('git config user.name', 'fatal: Not a git repository')
    assert match(command) == True
    command = Command('hg config user.name', 'abort: no repository found')
    assert match(command) == True
    

# Generated at 2022-06-24 07:15:59.453207
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-24 07:16:00.900264
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:16:05.223322
# Unit test for function match
def test_match():
    # Test wrong scm
    command_1 = "hg pwd"
    command_2 = "hg status"
    command_3 = "git pwd"
    command_4 = "git log"

    assert match(Command(command_1, "")) == True
    assert match(Command(command_2, "")) == True
    assert match(Command(command_3, "")) == True
    assert match(Command(command_4, "")) == True

    # Test correct scm
    command_1 = "git pwd"
    command_2 = "git status"
    command_3 = "hg pwd"
    command_4 = "hg status"

    assert match(Command(command_1, "")) == False
    assert match(Command(command_2, "")) == False

# Generated at 2022-06-24 07:16:09.446941
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) != 'git status'
    assert get_new_command(Command('git status', '')) == 'hg status'
    assert get_new_command(Command('git remote --verbose', '')) == 'hg remote --verbose'

# Generated at 2022-06-24 07:16:15.660088
# Unit test for function match
def test_match():
    assert match(Command('git status', 'Not a git repository'))
    assert match(Command('git status', 'Not a git repository\n'))
    assert not match(Command('git status', 'Not a git repository\n\n'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found\n'))
    assert not match(Command('git status', 'abort: no repository found'))



# Generated at 2022-06-24 07:16:19.862603
# Unit test for function get_new_command
def test_get_new_command():
    command_git = Command('git commit', 'fatal: Not a git repository')
    command_hg = Command('hg commit', 'abort: no repository found')
    assert get_new_command(command_git) == 'git commit'
    assert get_new_command(command_hg) == 'hg commit'

# Generated at 2022-06-24 07:16:26.306465
# Unit test for function match
def test_match():
    scm = _get_actual_scm()
    assert match(Command('git grep hello *',
                         wrong_scm_patterns['git']))
    assert match(Command('hg grep hello *',
                         wrong_scm_patterns['hg']))
    assert match(Command('git grep hello *',
                         "fatal: Not a git")) is False
    assert match(Command('hg grep hello *',
                         "abort: Not a hg")) is False


# Generated at 2022-06-24 07:16:27.290994
# Unit test for function match
def test_match():
    assert match('git status')


# Generated at 2022-06-24 07:16:31.600318
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', ''))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', ''))


# Generated at 2022-06-24 07:16:34.695619
# Unit test for function get_new_command
def test_get_new_command():
    args = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(args) == 'hg status'

# Generated at 2022-06-24 07:16:38.066064
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {})
    command.output = 'fatal: Not a git repository'
    command.script_parts = ['git', 'status']
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:16:47.994361
# Unit test for function match
def test_match():
    # Wrong directory, no git, so no match
    assert not match(Command('git status', 'fatal: Not a git repository', ''))
    # Wrong directory, yes git, so match
    assert match(Command('git status', 'fatal: Not a git repository', '', path='/tmp'))
    # Right directory, is git dir, so no match
    assert not match(Command('git status', '', '', path='/home/user/.git'))
    # Wrong directory, no hg, so no match
    assert not match(Command('hg status', 'fatal: Not a git repository', ''))
    # Wrong directory, yes hg, so match
    assert match(Command('hg status', 'abort: no repository found', '', path='/tmp'))
    # Right directory, is hg dir, so no match


# Generated at 2022-06-24 07:16:51.464199
# Unit test for function get_new_command
def test_get_new_command():
    command = namedtuple('Command','script_parts')
    command.script_parts = ['git','checkout','master']
    assert get_new_command(command) == 'hg checkout master'

# Generated at 2022-06-24 07:16:54.160028
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status'))
    assert match(Command('hg status', 'abort: no repository found'))

# Generated at 2022-06-24 07:16:58.083771
# Unit test for function match
def test_match():
    command = Command('hg help commit', '', 'fatal: Not a git repository (or any parent up to mount point /Users/muhano/Documents)\nStopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).')
    assert match(command)


# Generated at 2022-06-24 07:17:00.796694
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(MagicMock(is_git=True, script_parts=['git','status']))
    assert new_command == 'git status'


# Generated at 2022-06-24 07:17:04.471129
# Unit test for function match
def test_match():
    assert match(Command(script='git status', output='fatal: Not a git repository'))
    assert not match(Command(script='git status', output='On branch master'))
    assert match(Command(script='hg status', output='abort: no repository found'))
    assert not match(Command(script='hg status', output='abort: repository is unrelated'))



# Generated at 2022-06-24 07:17:07.723547
# Unit test for function match
def test_match():
    scm = _get_actual_scm()
    if scm == 'git':
        command = 'git status'
    else:
        command = 'hg status'
    
    assert match(command)

# Generated at 2022-06-24 07:17:10.679622
# Unit test for function get_new_command
def test_get_new_command():
	assert 'git log' == get_new_command(Command('hg log', ''))
	assert 'git status' == get_new_command(Command('hg status', ''))

# Generated at 2022-06-24 07:17:12.593314
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:17:15.819375
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg pull', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-24 07:17:17.008693
# Unit test for function match
def test_match():
    assert match('git branch')
    assert not match('git -help')


# Generated at 2022-06-24 07:17:19.830055
# Unit test for function match
def test_match():
    assert not match(Command('git status'))

    wrong_output = 'fatal: Not a git repository'

    command = Command('git checkout', 'cd /tmp')
    assert match(Command('git checkout', 'cd /tmp', wrong_output))

# Generated at 2022-06-24 07:17:22.277342
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command(Command(script='hg status'))
    assert 'hg status' == get_new_command(Command(script='git status'))

# Generated at 2022-06-24 07:17:25.289528
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import types
    command = types.Command('git status', '', '')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-24 07:17:26.658591
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git -C path status')==('hg -C path status'))