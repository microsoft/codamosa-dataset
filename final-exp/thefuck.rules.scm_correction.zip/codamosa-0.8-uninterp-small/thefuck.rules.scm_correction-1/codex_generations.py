

# Generated at 2022-06-26 06:39:13.185797
# Unit test for function match
def test_match():
    assert match('d(du\\41\\)') == False
    assert match('d[du\\41\\]') == False
    assert match('d(du\\41\\]') == False
    assert match('[ddu\\41\\]') == False


# Generated at 2022-06-26 06:39:14.924997
# Unit test for function match
def test_match():
    str_0 = 'git init'
    var_0 = match(str_0)
    assert var_0==False


# Generated at 2022-06-26 06:39:23.079797
# Unit test for function match
def test_match():
    with stubs.patch("git.repo.base.Repo") as repo_mock:
        repo_mock.return_value.git.status.return_value = "fatal: Not a git repository (or any of the parent directories): .git"
        assert match("git status") == True
        assert match("git pull") == True
        repo_mock.return_value.git.status.return_value = "fatal: Not a git repository"
        assert match("git status") == True
        assert match("git push") == True
        repo_mock.return_value.git.status.return_value = "foo"
        assert match("git status") == False
        assert match("git pull") == False
        assert match("git push") == False

# Generated at 2022-06-26 06:39:26.685336
# Unit test for function match
def test_match():
    assert match('') == False
    assert match('d(du\\41\\)') == False
    assert match('d(du\\41\\)') == False
    assert match('d(du\\41\\)') == False



# Generated at 2022-06-26 06:39:30.580919
# Unit test for function match
def test_match():
    assert match(u'git commit -a')
    assert not match(u'git push')
    assert match(u'hg pull')
    assert not match(u'hg branch')


# Generated at 2022-06-26 06:39:32.404392
# Unit test for function match
def test_match():
    var_0 = get_new_command("git file --diff HEAD")
    var_1 = get_new_command("git log")


# Generated at 2022-06-26 06:39:34.318231
# Unit test for function match
def test_match():
    func_0 = match(str_0)
    assert func_0 == False


# Generated at 2022-06-26 06:39:37.158714
# Unit test for function match
def test_match():
    command_0 = 'd(du\\41\\)'
    assert bool(match(command_0))
    command_1 = 'd(du\\41\\)'
    assert not bool(match(command_1))


# Generated at 2022-06-26 06:39:39.110212
# Unit test for function match
def test_match():
    var_0 = 'git status'
    str_0 = 'fatal: Not a git repository'
    var = match(var_0)


# Generated at 2022-06-26 06:39:41.143321
# Unit test for function match
def test_match():
    str_0 = 'd(du\\41\\)'
    var_0 = match(str_0)


# Generated at 2022-06-26 06:39:45.748954
# Unit test for function match
def test_match():
	assert match('git pull origin master') == None
	assert match('git push origin master') == None
	assert match('git add .') == None

# Generated at 2022-06-26 06:39:47.770548
# Unit test for function match
def test_match():
    assert match(str_0, var_0)
    assert not match(str_0, var_0)


# Generated at 2022-06-26 06:39:50.293504
# Unit test for function match
def test_match():
    match_0 = match(str_0)
    match_1 = match(str_1)
    match_2 = match(str_2)
    match_3 = match(str_3)



# Generated at 2022-06-26 06:39:57.162037
# Unit test for function match
def test_match():
    var_0 = match('git commit -m')
    assert(var_0 == True)
    str_0 = 'git commit -m'
    var_1 = match(str_0)
    assert(var_1 == True)
    var_2 = match('git commit -m "test"')
    assert(var_2 == True)
    str_1 = 'git commit -m "test"'
    var_3 = match(str_1)
    assert(var_3 == True)
    var_4 = match('git pull')
    assert(var_4 == False)
    str_2 = 'git pull'
    var_5 = match(str_2)
    assert(var_5 == False)
    var_6 = match('git status')
    assert(var_6 == False)

# Generated at 2022-06-26 06:40:03.665780
# Unit test for function match
def test_match():
    assert(match('fatal: Not a git repository') == True)
    assert(match('abort: no repository found') == True)
    assert(match('git status') == False)
    assert(match('asdfsaf') == False)
    assert(match('git asdfdsaf') == False)
    assert(match('git status') == False)
    assert(match('hg status') == False)
    assert(match('hg asdfdsaf') == False)


# Generated at 2022-06-26 06:40:09.384898
# Unit test for function match
def test_match():
    # Mock object
    class MockObject:
        script_parts = ['.git']
        output = ['fatal: Not a git repository']

    command = MockObject()
    actual_return = match(command)

    expected_return = True
    assert actual_return == expected_return

# test_match()



# Generated at 2022-06-26 06:40:15.732398
# Unit test for function match
def test_match():
    try:
        assert match('ls') == False
        assert match('git') == False
        assert match('git status') == False
        assert match('git status 10') == False
        assert match('git status 10 10') == False
        assert match('git status -n 10') == False
        assert match('git status -n +10') == False
    except AssertionError:
        print("Error!")
        return False;
    return True;


test_case_0()

# Generated at 2022-06-26 06:40:16.500809
# Unit test for function match
def test_match():
    var = match('git status')
    return var

# Generated at 2022-06-26 06:40:27.921737
# Unit test for function match
def test_match():
    var_2 = 'fatal: Not a git repository'
    str_1 = 'git commit -m "test"\n' + var_2
    var_1 = Command(script=str_1, output=var_2)
    var_3 = 'git'
    var_4 = 'fatal: Not a git repository'
    var_5 = 'abort: no repository found'
    var_6 = _get_actual_scm
    var_7 = Path('/home/user/.git')
    var_8 = var_7.is_dir
    var_9 = var_7.__init__
    var_12 = var_9('/home/user/.git')
    var_10 = var_8
    var_11 = var_6

# Generated at 2022-06-26 06:40:37.580756
# Unit test for function match

# Generated at 2022-06-26 06:40:47.666007
# Unit test for function match
def test_match():
    assert(_get_actual_scm() == 'git')
    c = Command('git branch', '')
    assert(match(c) == False)
    c = Command('git status', 'fatal: Not a git repository')
    assert(match(c) == True)
    get_new_command(c)

    c = Command('hg branch', '')
    assert(match(c) == False)
    c = Command('hg status', 'abort: no repository found')
    assert(match(c) == True)
    get_new_command(c)

# Generated at 2022-06-26 06:40:54.201278
# Unit test for function match
def test_match():
    command0 = ['git', '!git']
    check0 = match(command0)
    command1 = ['svn', '!svn']
    check1 = match(command1)
    command2 = ['hg', '!hg']
    check2 = match(command2)
    command3 = ['bzr', '!bzr']
    check3 = match(command3)
    command4 = ['git', '!svn']
    check4 = match(command4)
    command5 = ['hg', '!git']
    check5 = match(command5)
    command6 = ['bzr', '!hg']
    check6 = match(command6)
    command7 = ['svn', '!bzr']
    check7 = match(command7)
    assert check0 == False


# Generated at 2022-06-26 06:41:03.756537
# Unit test for function match
def test_match():
    str_0 = 'git commit -m "test"'
    str_1 = 'fatal: Not a git repository (or any of the parent directories): .git'
    str_2 = '\'hg\' is not recognized as an internal or external command,'
    str_3 = 'operable program or batch file.'
    str_4 = 'abort: no repository found in'
    str_6 = 'git pull'
    var_0 = match(str_0 + ' ' + str_1)
    var_1 = match(str_3 + ' ' + str_2 + ' ' + str_2)
    var_2 = match(str_6 + ' ' + str_1)
    var_3 = match(str_0 + ' ' + str_4)

# Generated at 2022-06-26 06:41:05.131153
# Unit test for function match
def test_match():
    assert match('git status')


# Generated at 2022-06-26 06:41:09.644716
# Unit test for function match
def test_match():
    str_1 = 'd(du\\41\\)'
    var_1 = match(str_1)
    assert not var_1
    str_2 = 'fatal: Not a git repository (or any of the parent directories): ' +\
            '.git'
    var_2 = match(str_2)
    assert var_2


# Generated at 2022-06-26 06:41:11.960568
# Unit test for function match
def test_match():
    assert match('git status')
    assert not match('hg status')

# Generated at 2022-06-26 06:41:14.444147
# Unit test for function match
def test_match():
    str_0 = 'd(du\\41\\)'
    var_0 = match(str_0)
    assert var_0 == 'git'


# Generated at 2022-06-26 06:41:18.066933
# Unit test for function match
def test_match():
    str_0 = 'd(du\\41\\)'
    var_0 = match(str_0)
    assert var_0

    str_1 = 'd(du\\41\\)'
    var_1 = match(str_1)
    assert var_1



# Generated at 2022-06-26 06:41:21.995048
# Unit test for function match
def test_match():
    command = 'git commit -m "test"'
    actual_scm = 'git'
    assert(match(command) == actual_scm)


# Generated at 2022-06-26 06:41:24.688349
# Unit test for function match
def test_match():
    command = 'd(du\41\)'
    assert match(command)
    assert match(command)
    assert match(command)
    assert match(command)
    assert match(command)

# Generated at 2022-06-26 06:41:38.881381
# Unit test for function match
def test_match():
    str_0 = 'git status'
    var_0 = match(str_0)
    assert var_0 == None

    str_1 = 'hg status'
    var_1 = match(str_1)
    assert var_1 == None

    str_2 = 'git status'
    var_2 = match(str_2)
    assert var_2 == None

    str_3 = 'hg status'
    var_3 = match(str_3)
    assert var_3 == None

    str_4 = 'hg status'
    var_4 = match(str_4)
    assert var_4 == None

    str_5 = 'git status'
    var_5 = match(str_5)
    assert var_5 == None


# Generated at 2022-06-26 06:41:39.734897
# Unit test for function match
def test_match():
    assert True

# Generated at 2022-06-26 06:41:40.757839
# Unit test for function match
def test_match():
    assert match('git lg')



# Generated at 2022-06-26 06:41:41.527728
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-26 06:41:43.784041
# Unit test for function match
def test_match():
    assert get_new_command('git commit') == 'hg commit'
    assert get_new_command('git commit') == 'git commit'

# Generated at 2022-06-26 06:41:50.760944
# Unit test for function match
def test_match():
    command_0 = Command(script="git push origin master",
                        stdout=("error: failed to push some refs to 'http://github.com/nvbn/thefuck.git'\n"
                                'hint: Updates were rejected because the tip of your current branch is behind\n'
                                'hint: its remote counterpart. Merge the remote changes (e.g.\n'
                                "'git pull') before pushing again.\n"
                                'hint: See the '
                                "'Note about fast-forwards' in 'git push --help' for details.\n"),
                        stderr='')
    asser

# Generated at 2022-06-26 06:41:52.638526
# Unit test for function match
def test_match():
    assert match('git diff\n')
    assert not match('git dif\n')



# Generated at 2022-06-26 06:41:54.467234
# Unit test for function match
def test_match():
    str_0 = 'd(du\\41\\)'
    var_0 = match(str_0)
    print(var_0)
    assert var_0 == None

# Generated at 2022-06-26 06:41:58.784570
# Unit test for function match
def test_match():
	assert match(str_0) == var_0
	assert match('fatal: Not a git repository') == False
	assert match('abort: no repository found') == False
	assert match('git fatal: Not a git repository') == False

# Generated at 2022-06-26 06:42:00.679351
# Unit test for function match
def test_match():
    # AssertionError: True is not false : fail to match
    assert_equals(match, False)


# Generated at 2022-06-26 06:42:10.209453
# Unit test for function match
def test_match():
    assert match(Command('git status')) is True
    assert match(Command('git push')) is False
    assert match(Command('hg pull')) is False
    assert match(Command('hg branch')) is True
    assert match(Command('g')) is True
    assert not match(Command('python run.py'))


# Generated at 2022-06-26 06:42:12.868558
# Unit test for function match
def test_match():
    float_0 = -3904.84701
    var_0 = get_new_command(float_0)
    var_1 = match(var_0)
    assert var_1 == False


# Generated at 2022-06-26 06:42:14.576497
# Unit test for function match
def test_match():
    assert match(Command("git push", "fatal: Not a git repository (or any of the parent directories): .git\nno branch master"))


# Generated at 2022-06-26 06:42:17.025560
# Unit test for function match
def test_match():
    var_0 = match(float_0)
    assert var_0
    var_0 = match(var_0)
    assert var_0


# Generated at 2022-06-26 06:42:18.970561
# Unit test for function match
def test_match():
    assert match(float_0) == get_new_command(float_0)

# Generated at 2022-06-26 06:42:29.631320
# Unit test for function match
def test_match():
    # AssertionError
    error = AssertionError()

# Generated at 2022-06-26 06:42:32.540676
# Unit test for function match
def test_match():
    assert match('hg pull') == True
    assert match('git pull') == False



# Generated at 2022-06-26 06:42:34.923962
# Unit test for function match
def test_match():
    var_0 = -3532.1967
    match(var_0)


# Generated at 2022-06-26 06:42:35.927511
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 06:42:46.127175
# Unit test for function match
def test_match():
    assert match(Command(script = "git fsck", output = "git: 'fsck' is not a git command. See 'git --help'.\n\nThe most similar command is "\
+ "checkout\n")) == True
    assert match(Command(script = "git log", output = "git: 'log' is not a git command. See 'git --help'.\n\nThe most similar command is "\
+ "blame\n")) == True
    assert match(Command(script = "git annex whereis", output = "git: 'annex' is not a git command. See 'git --help'.\n\nThe most similar "\
+ "command is add\n")) == True

# Generated at 2022-06-26 06:42:57.859123
# Unit test for function match
def test_match():
    # test_match_script_parts_0
    float_0 = -5377.3903911
    var_0 = match(float_0)
    assert(var_0 != None)

if __name__ == '__main__':
    test_match()
    test_case_0()

# Generated at 2022-06-26 06:42:59.841678
# Unit test for function match
def test_match():
    float_3 = -7339.5729
    var_3 = get_command_output()
    assert match(var_3, float_3) == False


# Generated at 2022-06-26 06:43:09.871209
# Unit test for function match
def test_match():
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False
    assert match('git status') == False

# Generated at 2022-06-26 06:43:11.394375
# Unit test for function match
def test_match():
    assert match('git')
    assert not match('ls')


# Generated at 2022-06-26 06:43:13.764581
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository')) == False


# Generated at 2022-06-26 06:43:16.167136
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    var_0 = match(float_0)
    assert var_0 == 'git'


# Generated at 2022-06-26 06:43:18.011149
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    var_0 = match(float_0)
    assert var_0 == False

# Generated at 2022-06-26 06:43:26.751885
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    float_1 = -1.36199
    float_2 = -0.0
    float_3 = -1.2951
    float_4 = -0.0
    float_5 = -0.0
    float_6 = -1.36199
    float_7 = -2147483648
    float_8 = -1.3002
    float_9 = -0.0
    float_10 = -1.3002
    float_11 = -0.0
    float_12 = -2147483648
    float_13 = -1.3002
    float_14 = -0.0
    float_15 = -3764.27544
    test_case_0(float_15)

# Generated at 2022-06-26 06:43:29.726575
# Unit test for function match
def test_match():
    # Test_case0
    float_0 = -3764.27544
    var_0 = match(float_0)
    assert var_0 == False



# Generated at 2022-06-26 06:43:31.696003
# Unit test for function match
def test_match():
    assert match('fatal: Not a git repository (or any of the parent directories): .git')
    assert match('abort: no repository found')

# Generated at 2022-06-26 06:43:58.072395
# Unit test for function match
def test_match():
    assert match(command('hg status'))
    assert match(command('git status'))
    assert match(command('git push'))
    assert match(command('hg status'))
    assert match(command('git status'))
    assert match(command('git push'))
    assert match(command('git commit -am "New commit"'))
    assert match(command('hg status'))
    assert match(command('git status'))
    assert match(command('git diff'))
    assert match(command('hg status'))
    assert match(command('git status'))
    assert match(command('git push'))
    assert match(command('git commit -am "New commit"'))
    assert match(command('git commit -am "New commit"'))
    assert match(command('hg status'))
    assert match

# Generated at 2022-06-26 06:44:01.421287
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    float_1 = float_0
    float_2 = + float_1
    assert match(float_0) == False
    assert match(float_1) == False
    assert match(float_2) == False



# Generated at 2022-06-26 06:44:02.642428
# Unit test for function match
def test_match():
    assert match("git branch") == _get_actual_scm()


# Generated at 2022-06-26 06:44:08.734054
# Unit test for function match
def test_match():
    assert match({
        'script': '/usr/bin/git status',
        'stderr': '',
        'stdout': 'fatal: Not a git repository',
        'script_parts': ['git', 'status'],
        'env': {},
        'stdin': '',
        'output': 'fatal: Not a git repository',
        'cmd': '/usr/bin/git status'})
    assert match({
        'script': 'git status',
        'stderr': '',
        'stdout': 'fatal: Not a git repository',
        'script_parts': ['git', 'status'],
        'env': {},
        'stdin': '',
        'output': 'fatal: Not a git repository',
        'cmd': 'git status'})

# Generated at 2022-06-26 06:44:10.894403
# Unit test for function match
def test_match():
    float_0 = -55.2023
    var_0 = match(float_0)
    assert var_0 == True


# Generated at 2022-06-26 06:44:13.537043
# Unit test for function match
def test_match():
    out = "fatal: Not a git repository"
    command = Command(script="git push", output=out)
    assert match(command)


# Generated at 2022-06-26 06:44:15.401003
# Unit test for function match
def test_match():
    print("Running match test")
    assert match("git status")
    assert match("git branch")
    assert match("git checkout master")


# Generated at 2022-06-26 06:44:16.291765
# Unit test for function match
def test_match():
    assert True == match([1,2,3])

# Generated at 2022-06-26 06:44:18.043399
# Unit test for function match
def test_match():
    float_0 = -1740.85512
    var_0 = match(float_0)


# Generated at 2022-06-26 06:44:26.976355
# Unit test for function match
def test_match():
    float_0 = -143
    float_1 = 3764.27544
    float_2 = -4.4
    float_3 = 9
    float_4 = -3764.27544
    var_2 = get_new_command(float_1)
    var_3 = get_new_command(float_2)
    var_4 = get_new_command(float_3)
    var_5 = get_new_command(float_4)
    if (float_1 >= float_2):
        var_0 = int((float_0 * float_1))
    else:
        var_0 = int((float_0 * float_2))
    if (float_2 < float_0):
        var_1 = int((float_0 - float_2))

# Generated at 2022-06-26 06:45:04.600828
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    command_0 = Command(float_0)
    assert match(command_0) == False


# Generated at 2022-06-26 06:45:05.362136
# Unit test for function match
def test_match():
    assert match(float_0)


# Generated at 2022-06-26 06:45:07.147122
# Unit test for function match
def test_match():
    input_0 = "git add"
    var_0 = match(input_0)
    assert var_0 == True



# Generated at 2022-06-26 06:45:08.819214
# Unit test for function match
def test_match():
    float_0 = -165
    function_result_0 = match(float_0)
    assert function_result_0 == True


# Generated at 2022-06-26 06:45:09.963749
# Unit test for function match
def test_match():
    var_0 = match(float)
    assert var_0 == float


# Generated at 2022-06-26 06:45:20.484340
# Unit test for function match
def test_match():
    assert not match(Context(script='git', output='Not a git repository'))
    assert match(Context(script='git', output='fatal: Not a git repository\n'))
    assert not match(Context(script='hg', output='abort: no repository found'))
    assert match(Context(script='hg', output='abort: no repository found\n'))
    assert not match(Context(script='svn', output='E155007'))
    assert not match(Context(script='svn', output='E155007: '))
    assert not match(Context(script='svn', output='E155007: blah blah\n'))
    assert not match(Context(script='svn', output='blah blah\nE155007: blah blah\n'))

# Generated at 2022-06-26 06:45:22.006990
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    var_0 = match(float_0)
    assert var_0 == 0.0


# Generated at 2022-06-26 06:45:23.680044
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    var_0 = match(float_0)
    assert var_0 == 'hg'

# Generated at 2022-06-26 06:45:26.630832
# Unit test for function match
def test_match():
    assert match('foo') == False, "test 1"
    assert match('foo') == False, "test 2"
    assert match('foo') == False, "test 3"
    assert match('foo') == False, "test 4"
    assert match('foo') == False, "test 5"


# Generated at 2022-06-26 06:45:27.891544
# Unit test for function match
def test_match():
    var_0 = -3764.27544
    var_1 = match(var_0)


# Generated at 2022-06-26 06:46:57.917228
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    assert not match(float_0)
    float_0 = -15.930349
    assert not match(float_0)



# Generated at 2022-06-26 06:46:59.693479
# Unit test for function match
def test_match():
    assert (match('git status')) == False


# Generated at 2022-06-26 06:47:03.894600
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'abort: no repository found'))

    assert not match(Command('git status'))
    assert not match(Command('hg status', 'abort: no repository found'))



# Generated at 2022-06-26 06:47:08.354340
# Unit test for function match
def test_match():
    assert wrong_scm_patterns.keys() == ['git', 'hg']
    cwd = os.getcwd()
    os.chdir(os.path.join(os.getcwd(), 'tests'))
    actual_scm = _get_actual_scm()
    assert actual_scm == 'hg'
    from thefuck.types import Command
    command = Command(script='git', stdout='fatal: Not a git repository')
    os.chdir(cwd)
    assert match(command) == True


# Generated at 2022-06-26 06:47:12.278380
# Unit test for function match
def test_match():
    var_0_0 = match(u'git status')
    
    assert var_0_0 == False
    float_0 = -3764.27544
    var_0_1 = match(float_0)
    
    assert var_0_1 == False
    float_1 = -3764.27544
    var_0_2 = match(float_1)
    
    assert var_0_2 == False

# Generated at 2022-06-26 06:47:17.742653
# Unit test for function match
def test_match():
    # workdir/
    #           .git/
    #           .hg/
    #           .gitignore
    alternative_path = 'test/test_scm/'
    os.chdir(alternative_path)

    assert match(Command('echo', 'fatal: Not a git repository'))
    assert match(Command('echo', 'abort: no repository found'))
    assert not match(Command('echo', 'something wrong'))

    os.chdir('..')



# Generated at 2022-06-26 06:47:19.176136
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    var_0 = match(float_0)

# Generated at 2022-06-26 06:47:20.643839
# Unit test for function match
def test_match():
    # Intentionally failing test
    assert False



# Generated at 2022-06-26 06:47:22.258021
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    var_0 = match(float_0)


# Generated at 2022-06-26 06:47:26.191548
# Unit test for function match
def test_match():
    float_0 = -3764.27544
    assert not match(float_0)
    float_1 = 2.5
    assert not match(float_1)
    var_0 = get_new_command(float_0)
    assert not match(var_0)
    var_1 = get_new_command(float_1)
    assert not match(var_1)