

# Generated at 2022-06-26 06:39:16.470905
# Unit test for function match
def test_match():
    # Positive test cases (examples) with arguments:
    assert match(Command('git status'))

    # Negative test cases (counterexamples) with arguments:
    assert not match(Command('git test'))



# Generated at 2022-06-26 06:39:18.972834
# Unit test for function match
def test_match():
    output = 'fatal: Not a git repository'
    assert match(output)
    output1 = 'abort: no repository found'
    assert not match(output1)

# Generated at 2022-06-26 06:39:20.199289
# Unit test for function match
def test_match():
    assert True

if __name__ == '__main__':
    test_match()

# Generated at 2022-06-26 06:39:21.051467
# Unit test for function match
def test_match():
	assert match(1) == 1


# Generated at 2022-06-26 06:39:24.323150
# Unit test for function match
def test_match():
    assert match(Command('git', 'git something', 'fatal: Not a git repository'))
    assert match(Command('hg', 'hg something', 'abort: no repository found'))
    assert not match(Command('git', 'git something', 'foo'))


# Generated at 2022-06-26 06:39:30.418093
# Unit test for function match
def test_match():
    output = "fatal: Not a git repository (or any of the parent directories): .git"
    script = "git checkout master"
    command = Command(script, output)
    try:
        assert match(command) == True
        print("test_match_success")
    except AssertionError:
        print("test_match_failed")


# Generated at 2022-06-26 06:39:31.262347
# Unit test for function match
def test_match():
    assert False



# Generated at 2022-06-26 06:39:33.168428
# Unit test for function match
def test_match():
    int_0 = -211
    var_0 = match(int_0)
    assert var_0

# Generated at 2022-06-26 06:39:39.075326
# Unit test for function match
def test_match():
    print("Test 1 of match")
    # Test returns
    assert match("git status") == True
    print("Test 2 of match")
    assert match("git status") == True
    print("Test 3 of match")
    assert match("git status") == True
    print("Test 4 of match")
    assert match("git status") == True
    print("Test 5 of match")
    assert match("git status") == True
    print("Test 6 of match")
    assert match("git status") == True
    print("Test 7 of match")
    assert match("git status") == True


# Generated at 2022-06-26 06:39:41.144486
# Unit test for function match
def test_match():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-26 06:39:43.612565
# Unit test for function match
def test_match():
    assert match(command) == True

# Generated at 2022-06-26 06:39:46.002653
# Unit test for function match
def test_match():
    command = 'fatal: Not a git repository'
    assert match(command)


# Generated at 2022-06-26 06:39:54.280035
# Unit test for function match
def test_match():
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)
    assert(match('git status') == true)

# Generated at 2022-06-26 06:39:56.913867
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))

# Generated at 2022-06-26 06:40:01.141075
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "fix test"', 'fatal: Not a git repository', '')) is True
    assert match(Command('git commit -m "fix test"', 'fatal: Not a git repository', '')) is True


# Generated at 2022-06-26 06:40:04.174410
# Unit test for function match
def test_match():
    assert match(u'git rebase') == None
    assert match(u'npm dedupe && git rebase') == None
    assert match(u'npm dedupe && git push') == None
    assert match(u'git push') == None


# Generated at 2022-06-26 06:40:10.950497
# Unit test for function match
def test_match():
    assert match(Command('git lg', '', ''))
    assert match(Command('hg lg', '', ''))
    assert not match(Command('hg lg', '', 'abort: no repository found!'))
    assert not match(Command('git lg', '', 'fatal: Not a git repository'))
    # assert match(Command('ls', '', ''))   # This is used only for testing a bug

if __name__ == "__main__":
    test_case_0()
    test_match()

# Generated at 2022-06-26 06:40:19.254253
# Unit test for function match
def test_match():
  int_0 = -211
  var_1 = True
  var_2 = True
  var_3 = True
  var_4 = True
  var_5 = True
  var_6 = True
  var_7 = "abort: no respository found"
  var_8 = True
  var_9 = True
  var_10 = "abort: no respository found"
  var_11 = True
  var_12 = True
  var_13 = "abort: no respository found"
  var_14 = True
  var_15 = True
  var_16 = "abort: no respository found"
  var_17 = True
  var_18 = True
  var_19 = "abort: no respository found"
  var_20 = True
  var_21 = True
  var_22

# Generated at 2022-06-26 06:40:23.154538
# Unit test for function match
def test_match():
    int_0 = -211
    var_0 = match(int_0)
    var_1 = _get_actual_scm()


# Generated at 2022-06-26 06:40:24.520523
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:40:28.946632
# Unit test for function match
def test_match():
    msg = u"fatal: Not a git repository"
    assert match(msg)



# Generated at 2022-06-26 06:40:31.426992
# Unit test for function match
def test_match():
    assert match('fatal: Not a git repository')
    assert match('abort: no repository found')


# Generated at 2022-06-26 06:40:33.902742
# Unit test for function match
def test_match():
    assert match(command) == true
    assert match(command) == true
    assert match(command) == false
    assert match(command) == true


# Generated at 2022-06-26 06:40:41.710287
# Unit test for function match
def test_match():
    assert match(get_new_command('git status')) in (True, None)
    assert match(get_new_command('hg status')) in (True, None)
    assert match(get_new_command('git status', 'E:\\')) in (False, None)
    assert match(get_new_command('hg status', 'E:\\')) in (False, None)


# Generated at 2022-06-26 06:40:50.531007
# Unit test for function match
def test_match():
    assert not match.__self__.match(Command('git', '', 'fatal: Not a git repository'))
    assert not match.__self__.match(Command('git', '', 'other error'))
    assert match.__self__.match(Command('git', '', 'fatal: Not a git repository\nother error'))
    assert match.__self__.match(Command('git', '', 'other error\nfatal: Not a git repository'))
    assert not match.__self__.match(Command('git', '', 'fatal: Not a git repository (does not exit)'))
    assert not match.__self__.match(Command('git', '', 'fatal: Not a git repository (does not exit)'), None, 'does not exist')

# Generated at 2022-06-26 06:40:52.940943
# Unit test for function match
def test_match():
    assert match(u'git falsdkjf') == False
    assert match(u'git fatal: Not a git repository') == True


# Generated at 2022-06-26 06:41:02.572355
# Unit test for function match
def test_match():
    assert match(command=Command('git branch', 'fatal: Not a git repository', 'https://github.com/cxreg/dotfiles', '', 0, 'git branch')) == True
    assert match(command=Command('git branch', 'abort: no repository found', 'https://github.com/cxreg/dotfiles', '', 0, 'git branch')) == True
    assert match(command=Command('hg branch', 'abort: no repository found', 'https://github.com/cxreg/dotfiles', '', 0, 'hg branch')) == True
    assert match(command=Command('git branch', 'fatal: Not a git repository', 'https://github.com/cxreg/dotfiles', '', 0, 'git branch')) == True

# Generated at 2022-06-26 06:41:03.473670
# Unit test for function match
def test_match():
    assert match(0) == False


# Generated at 2022-06-26 06:41:08.902041
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository'))
    assert not match(Command('hg', 'fatal: Not a git repository'))



# Generated at 2022-06-26 06:41:14.708489
# Unit test for function match
def test_match():
    assert match(-1045) == False
    assert match(-1044) == False
    assert match(-1043) == True
    assert match(-1042) == False
    assert match(-1041) == False
    assert match(-1040) == False
    assert match(-1039) == False
    assert match(-1038) == False
    assert match(-1037) == False
    assert match(-1036) == False
    assert match(-1035) == False
    assert match(-1034) == False
    assert match(-1033) == False
    assert match(-1032) == False
    assert match(-1031) == False
    assert match(-1030) == False
    assert match(-1029) == False
    assert match(-1028) == False
    assert match(-1027) == False
    assert match(-1026) == False


# Generated at 2022-06-26 06:41:23.239684
# Unit test for function match
def test_match():
    var_1 = re.fullmatch('', '')
    var_2 = re.fullmatch('', '')
    assert not match(var_1)
    assert not match(var_2)


# Generated at 2022-06-26 06:41:30.331117
# Unit test for function match
def test_match():
    assert not match('fuck')
    assert match('fuck '+wrong_scm_patterns['git'])
    assert not match('fuck '+wrong_scm_patterns['git']+' asdas')
    assert match('fuck '+wrong_scm_patterns['hg'])
    assert not match('fuck '+wrong_scm_patterns['hg']+' asdas')


# Generated at 2022-06-26 06:41:32.508334
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', '', 666)) == False


# Generated at 2022-06-26 06:41:33.719937
# Unit test for function match
def test_match():
    assert match(3) == False
    assert match(6) == True
    assert match(8) == False


# Generated at 2022-06-26 06:41:35.355824
# Unit test for function match
def test_match():
    assert match(get_new_command) == wrong_scm_patterns


# Generated at 2022-06-26 06:41:37.239355
# Unit test for function match
def test_match():
    int_0 = -211
    var_0 = match(int_0)
    assert False


# Generated at 2022-06-26 06:41:47.658530
# Unit test for function match
def test_match():
    int_0 = -211
    string_0 = 'fatal: Not a git repository'
    byte_0 = '\x1e\xff'
    byte_1 = '\xff\x19'
    byte_2 = '\xe4\xe5'
    byte_3 = '\x7f\x1e'
    byte_4 = '\x7f\x1a'
    string_1 = '\n    git status \n  '
    string_2 = '\n    git status \n  '
    string_3 = '\n    git status \n  '
    string_4 = '\n    git status \n  '
    string_5 = '\n    git status \n  '
    string_6 = '\n    git status \n  '

# Generated at 2022-06-26 06:41:54.630988
# Unit test for function match
def test_match():
    int_0 = -101
    var_0 = match(int_0)
    var_1 = _get_actual_scm()
    if var_1 == 'git':
        var_2 = 'git'
        var_3 = command.script_parts[0]
        var_4 = var_2 == var_3
    var_5 = pattern in command.output
    var_6 = var_4 and var_5
    var_7 = not var_6
    if var_7:
        var_8 = match(int_0)
        var_9 = _get_actual_scm()
        if var_9 == 'hg':
            var_10 = 'hg'
            var_11 = command.script_parts[0]
            var_12 = var_10 == var_11
        var_13

# Generated at 2022-06-26 06:41:56.549662
# Unit test for function match
def test_match():
    assert match(False)


# Generated at 2022-06-26 06:42:04.904534
# Unit test for function match
def test_match():
    assert(match(["git", "status"]) == False)
    assert(match(["git", "xxx"]) == False)
    assert(match(["hg", "xxx"]) == False)
    assert(match(["hg", "status"]) == False)
    assert(match(["hg", "log", "--style", "changelog"]) == False)
    assert(match(["git", "log", "--grep", "SM-1"]) == False)
    assert(match(["git", "xlog", "--grep", "SM-1"]) == False)
    assert(match(["hg", "xlog", "--grep", "SM-1"]) == False)

# Generated at 2022-06-26 06:42:27.190536
# Unit test for function match
def test_match():
    cases = [('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True), ('', True)]

    for arg, expected in cases:
        if arg == '3328309':
            arg = 3328309
        if arg == '4453325':
            arg = 4453325
        if arg == '2':
            arg = 2
        if arg == '2017':
            arg = 2017
        if arg == '20171231':
            arg = 20171231
        if arg == '0.5':
            arg

# Generated at 2022-06-26 06:42:30.103254
# Unit test for function match
def test_match():
    in_0 = "Here is how you would use this function in a real project"
    test_case_0(in_0)

# Generated at 2022-06-26 06:42:33.992964
# Unit test for function match
def test_match():
    var_0 = Command('git log', '')

    var_0 = match(var_0)
    assert var_0, var_0


# Generated at 2022-06-26 06:42:37.422431
# Unit test for function match
def test_match():
    # 1. Create dummy command object
    int_0 = -211
    # 2. Call the function
    var_0 = match(int_0)
    # 3. Compare
    assert var_0 == False



# Generated at 2022-06-26 06:42:41.266965
# Unit test for function match
def test_match():
    assert match(Command('git')) is None
    assert match(Command('git branch'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', ''))



# Generated at 2022-06-26 06:42:42.504177
# Unit test for function match
def test_match():
    assert match(u'git rebase')


# Generated at 2022-06-26 06:42:47.323031
# Unit test for function match
def test_match():
    mem_0 = int(-149742372)
    sys_0 = int(-471567737)
    sys_1 = int(982859996)
    sys_2 = int(-857651130)
    func_0 = match("git status")
    assert func_0 != 0
    assert mem_0 != 0
    assert sys_0 != 0
    assert sys_1 != 0
    assert sys_2 != 0


# Generated at 2022-06-26 06:42:55.264399
# Unit test for function match
def test_match():
    cmd_0 = {'output': 'fatal error: Not a git repository'}
    script_0 = 'git'
    parts_0 = ['git']
    command_0 = Command(script_0, parts_0, cmd_0)

    assert match(command_0) == False

    cmd_1 = {'output': 'fatal error: Not a git repository'}
    script_1 = 'git'
    parts_1 = ['git']
    command_1 = Command(script_1, parts_1, cmd_1)

    assert match(command_1) == False

# Generated at 2022-06-26 06:42:56.691033
# Unit test for function match
def test_match():
    assert match("fatal: Not a git repository") == True


# Generated at 2022-06-26 06:42:57.545988
# Unit test for function match
def test_match():
    assert False == match(0)


# Generated at 2022-06-26 06:43:21.945702
# Unit test for function match
def test_match():
    pass



# Generated at 2022-06-26 06:43:24.189155
# Unit test for function match
def test_match():
    assert match(0) == False
    assert match(1) == False
    assert match(2) == False
    assert match(3) == False


# Generated at 2022-06-26 06:43:25.313470
# Unit test for function match
def test_match():
    with pytest.raises(SystemExit):
        test_case_0()

# Generated at 2022-06-26 06:43:34.714468
# Unit test for function match
def test_match():
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')
    assert match('git status')

# Generated at 2022-06-26 06:43:36.338484
# Unit test for function match
def test_match():
    assert not match(Command("git status", "fatal: Not a git repository (or any of the parent directories): .git\n"))

# Generated at 2022-06-26 06:43:39.184932
# Unit test for function match
def test_match():
    int_0 = -211
    var_0 = match(int_0)

# Generated at 2022-06-26 06:43:42.323626
# Unit test for function match
def test_match():
    assert match('git add .', '', 'fatal: Not a git repository')
    assert not match('git add .', '', 'fatal: you are in a git repository')


# Generated at 2022-06-26 06:43:43.497209
# Unit test for function match
def test_match():
    assert match(Command(script='git status')) == True


# Generated at 2022-06-26 06:43:55.023705
# Unit test for function match
def test_match():

    # Case 1
    # AssertionError: assert False
    cmd = Command('git status')
    cmd.output = '"fatal: Not a git repository"'

    assert match(cmd) == False

    # Case 2
    # AssertionError: assert True
    cmd = Command('git status')
    cmd.output = '"fatal: Not a git repository"'

    assert match(cmd) == True

    # Case 3
    # AssertionError: assert False
    cmd = Command('hg status')
    cmd.output = '"abort: no repository found"'

    assert match(cmd) == False

    # Case 4
    # AssertionError: assert True
    cmd = Command('hg status')
    cmd.output = '"abort: no repository found"'

    assert match(cmd) == True

# Unit

# Generated at 2022-06-26 06:43:59.489911
# Unit test for function match
def test_match():
    var_0 = 'git status'
    var_1 = 'git: \'stauts\' is not a git command. See \'git --help\''
    var_2 = Command(script=var_0, output=var_1)

    assert match(var_2) == True



# Generated at 2022-06-26 06:45:01.220066
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg status', 'abort: no repository found in /etc!\n')) is False
    assert match(Command('hg status')) is False
    assert match(Command('fuck status')) is False

# Generated at 2022-06-26 06:45:06.944786
# Unit test for function match
def test_match():
    assert match({'script_parts': ['git'], 'output': 'fatal: Not a git repository'}) == True
    assert match({'script_parts': ['git'], 'output': 'fatal: Not a git repository'}) == True
    assert match({'script_parts': ['git'], 'output': 'fatal: Not a git repository'}) == True
    assert match({'script_parts': ['git', 'diff'], 'output': 'fatal: Not a git repository'}) == True
    assert match({'script_parts': ['git', 'commit'], 'output': 'fatal: Not a git repository'}) == True

# Generated at 2022-06-26 06:45:08.049073
# Unit test for function match
def test_match():
    assert(match("git on non git repos") == False)


# Generated at 2022-06-26 06:45:09.798222
# Unit test for function match
def test_match():
    var_0 = WrappedCommand("git status", "fatal: Not a git repository")
    assert match(var_0)


# Generated at 2022-06-26 06:45:12.553573
# Unit test for function match
def test_match():
    var_0 = 'git branch'
    var_1 = parse_alias(var_0)
    var_2 = match(var_1)
    assert var_2 == False


# Generated at 2022-06-26 06:45:21.203596
# Unit test for function match
def test_match():
    assert not match(Command(script='git foobar', output='fatal: Not a git repository'))
    assert match(Command(script='git foobar', output='fatal: Not a git repository (or any of the parent directories): .git \nfoobar'))
    assert not match(Command(script='hg foobar', output='fatal: Not a git repository (or any of the parent directories): .git \nfoobar'))
    assert match(Command(script='hg foobar', output='fatal: Not a hg repository'))
    assert not match(Command(script='git foobar', output='fatal: Not a hg repository'))

# Generated at 2022-06-26 06:45:22.099328
# Unit test for function match
def test_match():
    assert match('git status')


# Generated at 2022-06-26 06:45:29.051100
# Unit test for function match
def test_match():
    assert match(test_case_0) == -26717
    assert match(test_case_1) == -26717
    assert match(test_case_2) == -26717
    assert match(test_case_3) == -26717
    assert match(test_case_4) == -26717
    assert match(test_case_5) == -26717
    assert match(test_case_6) == -26717
    assert match(test_case_7) == -26717
    assert match(test_case_8) == -26717
    assert match(test_case_9) == -26717
    assert match(test_case_10) == -26717
    assert match(test_case_11) == -26717
    assert match(test_case_12) == -26717

# Generated at 2022-06-26 06:45:30.244525
# Unit test for function match
def test_match():
    assert match('git status')
    assert match('git pull')
    assert not match('hg commit')


# Generated at 2022-06-26 06:45:31.971129
# Unit test for function match
def test_match():
    command = "git status"

    assert(match(command))


# Generated at 2022-06-26 06:47:48.580084
# Unit test for function match
def test_match():
    command = "git gui"
    var_match = match(command)
    print(var_match)
    return True


# Generated at 2022-06-26 06:47:50.743921
# Unit test for function match
def test_match():
    int_0 = -211
    var_0 = match(int_0)
    assert var_0
    
var_0 = _get_actual_scm()

# Generated at 2022-06-26 06:47:51.787349
# Unit test for function match
def test_match():
    assert match(command = 'output_0') == False


# Generated at 2022-06-26 06:47:52.761810
# Unit test for function match
def test_match():
	assert match('fatal: Not a git repository') == True


# Generated at 2022-06-26 06:47:54.233302
# Unit test for function match
def test_match():
    assert not match(Command("git add", "fatal: Not a git repository"))


# Generated at 2022-06-26 06:47:55.407405
# Unit test for function match
def test_match():
    assert match(int_0) == _get_actual_scm()


# Generated at 2022-06-26 06:47:57.655871
# Unit test for function match
def test_match():
    int_0 = -211
    var_0 = match(int_0)
    assert var_0



# Generated at 2022-06-26 06:47:59.692159
# Unit test for function match
def test_match():
    var_0 = 'git status'
    var_1 = match(var_0)
    assert var_1 == False


# Generated at 2022-06-26 06:48:00.685987
# Unit test for function match
def test_match():
    assert match()



# Generated at 2022-06-26 06:48:03.121670
# Unit test for function match
def test_match():
    new_command = "branch"
    command = "git branch"
    stdout = "fatal: Not a git repository"
    stderr = ""
    assert match(Command(command, new_command, stdout, stderr))