

# Generated at 2022-06-26 06:39:15.195094
# Unit test for function match
def test_match():
    str_1 = '.git/git'
    var_1 = match(str_1)
    print(':', var_1)


# Generated at 2022-06-26 06:39:24.203914
# Unit test for function match
def test_match():
    str_0 = 'as'
    assert match(str_0) == False
    str_1 = 'sad'
    assert match(str_1) == False
    str_2 = 'ads'
    assert match(str_2) == False
    str_3 = 'asd'
    assert match(str_3) == False
    str_4 = 'adsasd'
    assert match(str_4) == False
    str_5 = 'adsasd'
    assert match(str_5) == False
    str_6 = 'asdas'
    assert match(str_6) == False
    str_7 = 'asd'
    assert match(str_7) == False
    str_8 = 'dsa'
    assert match(str_8) == False
    str_9 = 'dsa'

# Generated at 2022-06-26 06:39:26.253371
# Unit test for function match
def test_match():
    result = match('LovdQ\\ae>>$E')
    assert(result == False)


# Generated at 2022-06-26 06:39:36.588056
# Unit test for function match
def test_match():

    # Preparing test data

    str_0 = '*|@F>rwl\x0b"\n%'
    str_1 = 'B+6-M#C\x0b'
    Path_2 = Path('Iy@\x17\x0c\x14s\x15(c\x1c')
    str_3 = 'Hl{r\x1a&qn'
    str_4 = '$ZN\x18oT\x0f'
    str_5 = '*LovdQ\\ae\n$E'
    str_6 = '%\x06'

# Generated at 2022-06-26 06:39:38.833146
# Unit test for function match
def test_match():
    assert match('git clone git://github.com/nvie/gitflow.git') == True
    assert match('git clone git://github.com/nvie/gitflow.git') == True


# Generated at 2022-06-26 06:39:41.722969
# Unit test for function match
def test_match():
    str_1 = '*LovdQ\\ae\n$E'
    var_1 = match(str_1)
    assert var_1 == True


# Generated at 2022-06-26 06:39:46.508055
# Unit test for function match
def test_match():
    str_0 = '*LovdQ\\ae\n$E'
    str_1 = '/mnt/data/mitesh/Desktop/github/pyscripts'
    var_0 = match(str_0, str_1)
    assert var_0 == True


# Generated at 2022-06-26 06:39:47.394997
# Unit test for function match
def test_match():
    assert match('')


# Generated at 2022-06-26 06:39:48.255958
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:39:49.809640
# Unit test for function match
def test_match():
	param_0 = get_new_command(813)
	assert param_0 == 1726

# Generated at 2022-06-26 06:39:53.307958
# Unit test for function match
def test_match():
    assert match('git status')
    assert not match('git --version')
    assert match('hg status')
    assert not match('hg --version')



# Generated at 2022-06-26 06:39:57.320716
# Unit test for function match
def test_match():
    assert _get_actual_scm() == 'git'
    assert match(Command(script = 'git status', output = 'fatal: Not a git repository'))
    assert not match(Command(script = 'git status', output = 'On branch master'))


# Generated at 2022-06-26 06:40:09.012235
# Unit test for function match
def test_match():
    var_0 = 'git status'

# Generated at 2022-06-26 06:40:11.950228
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository'
    var_0 = match(str_0)


# Generated at 2022-06-26 06:40:18.256785
# Unit test for function match
def test_match():
    str_0 = 'git status'
    scm = _get_actual_scm()
    pattern = wrong_scm_patterns[scm]
    out = u'fatal: Not a git repository'
    assert match(str_0) == (out in str_0)
    
    str_0 = 'hg status'
    scm = _get_actual_scm()
    pattern = wrong_scm_patterns[scm]
    out = u'abort: no repository found'
    assert match(str_0) == (out in str_0)


# Generated at 2022-06-26 06:40:22.530201
# Unit test for function match
def test_match():
    assert match('$ git status') == True
    assert match('$ hg status') == True


# Generated at 2022-06-26 06:40:26.411508
# Unit test for function match
def test_match():
    def test_case_0():
        str_0 = '*LovdQ\\ae\n$E'
        var_0 = match(str_0)
        assert var_0 is False
    test_case_0()

# Generated at 2022-06-26 06:40:27.835569
# Unit test for function match
def test_match():
    func_exec = match(command)
    assert func_exec


# Generated at 2022-06-26 06:40:30.244971
# Unit test for function match
def test_match():
    assert match('git status', 'fatal: Not a git repository')
    assert match('hg status', 'abort: no repository found')
    assert not match('svn status', 'fatal: Not a git repository')


# Generated at 2022-06-26 06:40:31.577905
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-26 06:40:37.901866
# Unit test for function match
def test_match():
    str_0 = 'git pull'
    var_0 = match(str_0)
    assert var_0 == 'git'


# Generated at 2022-06-26 06:40:44.197977
# Unit test for function match
def test_match():
    assert match(u'fatal: Not a git repository: .') == False
    assert match(u"*LovdQ\\ae\n$E") == False
    assert match(u'$l#0#^;$P%%') == False
    assert match(u'Fatal: Not a git repository: ./d6') == False
    assert match(u'.*ba+1/\x0c') == False
    assert match(u'!u\x0cK7\t') == False
    assert match(u'fatal: Not a git repository: ./.git\x0c') == False
    assert match(u'{a\r') == False
    assert match(u'\r\n\r\n') == False

# Generated at 2022-06-26 06:40:45.044282
# Unit test for function match
def test_match():
    assert True

# Generated at 2022-06-26 06:40:49.243710
# Unit test for function match
def test_match():
    assert match(Mock('git: No such file or directory')) == True
    assert match(Mock('git: No such file or directory')) == True
    assert match(Mock('git: No such file or directory')) == True
    assert match(Mock('git: No such file or directory')) == True
    assert match(Mock('git: No such file or directory')) == True

# Generated at 2022-06-26 06:40:53.096059
# Unit test for function match
def test_match():
    var_1 = match('git status')
    expected_1 = False
    assert expected_1 == var_1
    var_2 = match('hg status')
    expected_2 = False
    assert expected_2 == var_2


# Generated at 2022-06-26 06:40:55.175917
# Unit test for function match
def test_match():
    str_0 = 'alo'
    str_1 = 'hello wolrd'
    str_2 = 'kdkd'


# Generated at 2022-06-26 06:40:56.652457
# Unit test for function match
def test_match():
    assert match(str_0) == True
    

# Generated at 2022-06-26 06:40:59.596731
# Unit test for function match
def test_match():
    str_0 = 'git pull'
    str_1 = 'hg pull'
    var_0 = match(str_0)
    var_1 = match(str_1)
    assert var_0 == False
    assert var_1 == False


# Generated at 2022-06-26 06:41:02.572397
# Unit test for function match
def test_match():
    assert match("bogus command\nNot a git repository") == True
    assert match("bogus command\nNot a git repository") == False


# Generated at 2022-06-26 06:41:11.756912
# Unit test for function match
def test_match():
    assert match('git status_0') == False
    assert match('git status_1') == False
    assert match('git status_2') == False
    assert match('git status_3') == False
    assert match('git status_4') == False
    assert match('git status_5') == False
    assert match('git status_6') == False
    assert match('git status_7') == False
    assert match('git status_8') == False
    assert match('git status_9') == False
    assert match('git status_10') == False
    assert match('git status_11') == False
    assert match('git status_12') == False
    assert match('git status_13') == False
    assert match('git status_14') == False
    assert match('git status_15') == False

# Generated at 2022-06-26 06:41:25.354793
# Unit test for function match
def test_match():
    scm = 'git'
    pattern = 'fatal: Not a git repository'
    path = '.hg'
    Path = '.hg'
    is_dir = '.hg'
    command_output = 'fatal: Not a git repository'
    command_script_parts = 'git'
    if Path == is_dir:
        return var_0
    else:
        return command_output
    return pattern in command_output
    return str_0
    return command_script_parts
    

# Generated at 2022-06-26 06:41:26.979169
# Unit test for function match
def test_match():
    assert match(get_new_command)


# Generated at 2022-06-26 06:41:28.608380
# Unit test for function match
def test_match():
    assert match('git status')


# Generated at 2022-06-26 06:41:33.813005
# Unit test for function match
def test_match():
    assert match (Command('git branch', 'fatal: Not a git repository'))
    assert not match (Command('git branch', 'fatal: Not a git repository'))
    assert not match (Command('git branch', 'fatal: Not a git repository'))
    assert match (Command('git branch', 'fatal: Not a git repository'))

# Generated at 2022-06-26 06:41:35.776776
# Unit test for function match
def test_match():
    command = 'git status'
    output = 'fatal: Not a git repository'

    # Tested method
    var_0 = match(command, output)

# Generated at 2022-06-26 06:41:36.876680
# Unit test for function match
def test_match():
    assert match('$ git status')


# Generated at 2022-06-26 06:41:38.141077
# Unit test for function match
def test_match():
    assert match('') != get_new_command('')


# Generated at 2022-06-26 06:41:40.231874
# Unit test for function match
def test_match():
    str_0 = 'git'
    str_1 = 'hg'


# Generated at 2022-06-26 06:41:42.301624
# Unit test for function match
def test_match():
	var_0 = match(str)
	assert var_0 == true

# Generated at 2022-06-26 06:41:43.211637
# Unit test for function match
def test_match():
    assert match('git status') == True


# Generated at 2022-06-26 06:41:57.927588
# Unit test for function match
def test_match():
    # Lazy initialization
    var_0 = 'hg'

    assert var_0 == _get_actual_scm()
    assert match('git status') == True

# Generated at 2022-06-26 06:42:00.511655
# Unit test for function match
def test_match():
    script_0 = 'hg status'
    output_0 = 'abort: no repository found'
    assert match(Command(script_0, output_0)) == False


# Generated at 2022-06-26 06:42:03.958209
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository'
    var_0 = match(str_0)
    assert not var_0
    str_1 = 'fatal: Not a git repository (or any of the parent directories): .git'
    var_1 = match(str_1)
    assert not var_1


# Generated at 2022-06-26 06:42:13.597405
# Unit test for function match
def test_match():
    #
    # NOTE: The following test is not applicable, because it 
    #       depends on the actual state of the file system.
    #       Please adapt accordingly.
    #
    # assert match(get_new_command('foo')) == False
    assert match(get_new_command('foo'))
    assert match(get_new_command('fooЧДДДђ')) == False
    assert match(get_new_command('fooЧДДФДђ')) == False
    assert match(get_new_command('fooЧДДФДђ')) == False


# Generated at 2022-06-26 06:42:23.897517
# Unit test for function match
def test_match():
    str_0 = '^$'
    var_0 = match(str_0)

    str_1 = ''
    var_1 = match(str_1)

    str_2 = '<head><title>400 Bad Request</title></head>\n<body bgcolor="white">\n<center><h1>400 Bad Request</h1></center>\n<hr><center>nginx</center>\n</body>\n</html>\n'
    var_2 = match(str_2)

    str_3 = 'jQuery.get(url, undefined, callback, type).always(function(){});'
    var_3 = match(str_3)

    str_4 = 'div'
    var_4 = match(str_4)


# Generated at 2022-06-26 06:42:25.334695
# Unit test for function match
def test_match():
    assert match('git commit') == True
    assert match('hg log') == True



# Generated at 2022-06-26 06:42:29.099223
# Unit test for function match
def test_match():
    str_0 = 'git status'
    assert match(str_0) == True, 'fail'
    str_1 = 'git status'
    assert match(str_1) != False, 'fail'


# Generated at 2022-06-26 06:42:29.786470
# Unit test for function match

# Generated at 2022-06-26 06:42:33.162689
# Unit test for function match
def test_match():
    var_0 = Command('git status', 'fatal: Not a git repository')
    var_1 = match(var_0)


# Generated at 2022-06-26 06:42:44.345912
# Unit test for function match
def test_match():
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))

# Generated at 2022-06-26 06:43:12.442844
# Unit test for function match
def test_match():
    command = 'git pull origin master'
    wrong_result = 'fatal: Not a git repository'
    correct_result = 'git pull origin master'
    var_result = get_new_command(command)
    assert var_result == correct_result



# Generated at 2022-06-26 06:43:12.811277
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:43:14.995015
# Unit test for function match
def test_match():
    str_0 = '*LovdQ\\ae\n$E'
    var_0 = match(str_0)
    

# Generated at 2022-06-26 06:43:20.816855
# Unit test for function match
def test_match():
    # Ensure the following assertions hold:
    # assert 'git' in match(git_repository)

    # Ensure that the match function works properly
    # assert not match(unicode_command)

    assert match(git_repository)

    # assert 'git' in match(git_repository, git_repository_output)

    # Ensure that the match function works properly
    assert not match(unicode_command)



# Generated at 2022-06-26 06:43:22.807744
# Unit test for function match
def test_match():
    str_0 = '^TlN'
    var_0 = match(str_0)
    print(var_0)


# Generated at 2022-06-26 06:43:25.188081
# Unit test for function match
def test_match():
    str_0 = 'git commit -m "fix 9"'
    str_0 = '*LovdQ\\ae\n$E'
    var_2 = match(str_0)
    assert var_2


# Generated at 2022-06-26 06:43:26.383121
# Unit test for function match
def test_match():
    assert match('git help')


# Generated at 2022-06-26 06:43:35.524192
# Unit test for function match
def test_match():
    var_0 = 'git'
    var_1 = ['git', 'foo', 'bar']
    var_2 = 'git foo bar'
    var_3 = 'git foo bar'
    var_4 = 'git foo bar'
    var_5 = 'hi'
    var_6 = 'hi'
    var_7 = 'hi'
    var_8 = 'hi'
    var_9 = 'hi'
    var_10 = 'hi'
    var_11 = 'hi'
    var_12 = 'hi'
    var_13 = 'hi'
    var_14 = 'hi'
    var_15 = 'git'
    var_16 = 'git'
    var_17 = 'git'
    var_18 = 'git'
    var_19 = 'git'

# Generated at 2022-06-26 06:43:37.231346
# Unit test for function match
def test_match():
    assert match("git status") == False
    assert match("hg commit") == False
    assert match("git branch") == False
    assert match("hg status") == False


# Generated at 2022-06-26 06:43:45.884183
# Unit test for function match
def test_match():
    # Init
    path_to_scm = {
        '.git': 'git',
        '.hg': 'hg',
    }

    wrong_scm_patterns = {
        'git': 'fatal: Not a git repository',
        'hg': 'abort: no repository found',
    }

    _get_actual_scm = lambda: None

    for_app = lambda *args: lambda *args: None

    command = lambda: None
    command.script_parts = ['git', 's', 'add', 'file']
    command.output = 'fatal: Not a git repository'

    # Run
    match(command)

    # Assert



# Generated at 2022-06-26 06:44:43.416619
# Unit test for function match
def test_match():
    var_0 = "fatal: Not a git repository"
    var_1 = wrong_scm_patterns
    var_2 = _get_actual_scm()
    var_3 = match(var_0, var_1, var_2)



# Generated at 2022-06-26 06:44:45.509483
# Unit test for function match
def test_match():
    func_obj = match
    try:
        assert True == func_obj('git status')
    except AssertionError:
        print('test failed')


# Generated at 2022-06-26 06:44:48.085554
# Unit test for function match
def test_match():
    assert match(
      u'git README.rst',
      {
        u'stderr': u'fatal: Not a git repository',
        u'exit_code': 128
      }
    )


# Generated at 2022-06-26 06:44:50.893308
# Unit test for function match
def test_match():
    test_case_0()
    assert match(str_0)


# Generated at 2022-06-26 06:44:56.406706
# Unit test for function match
def test_match():
    str_0 = 'hg push --dry-run'
    str_1 = 'hg init'
    str_2 = 'hg status --no-status'
    str_3 = 'hg add'
    var_0 = match(str_0)
    var_1 = match(str_1)
    var_2 = match(str_2)
    var_3 = match(str_3)



# Generated at 2022-06-26 06:45:01.890655
# Unit test for function match
def test_match():
    var_0 = 'git status'
    var_1 = subprocess.check_output(var_0, shell=True, universal_newlines=True)
    var_2 = get_new_command(var_1)
    if var_1:
        assert match(var_1)
    else:
        assert not match(var_1)
        

# Generated at 2022-06-26 06:45:02.617967
# Unit test for function match
def test_match():
    assert match(1) == 2

# Generated at 2022-06-26 06:45:03.933217
# Unit test for function match
def test_match():
    assert match('*LovdQ\\ae\n$E') == True


# Generated at 2022-06-26 06:45:06.087236
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository\nabort: no repository found'
    var_0 = match(str_0)
    assert var_0 == True


# Generated at 2022-06-26 06:45:08.678228
# Unit test for function match
def test_match():
    input_1 = "git status"
    output_1 = match(input_1)
    assert output_1 == None

    input_2 = "hg status"
    output_2 = match(input_2)
    assert output_2 == None

# Generated at 2022-06-26 06:47:22.709091
# Unit test for function match
def test_match():
    str_0 = '*LovdQ\\ae\n$E'
    var_0 = match(str_0)
    var_1 = match(str_0)
    assert var_0 == var_1


# Generated at 2022-06-26 06:47:32.307232
# Unit test for function match
def test_match():

    # simple case
    str_0 = ':('
    var_0 = match(str_0)
    assert var_0 == True

    # simple case
    str_0 = ')('
    var_0 = match(str_0)
    assert var_0 == False

    # simple case
    str_0 = '*LovdQ\\ae\n$E'
    var_0 = match(str_0)
    assert var_0 == True

    # simple case
    str_0 = '('
    var_0 = match(str_0)
    assert var_0 == False

    # simple case
    str_0 = 'cd'
    var_0 = match(str_0)
    assert var_0 == False

    # simple case
    str_0 = 'cd '
    var_0 = match

# Generated at 2022-06-26 06:47:36.713643
# Unit test for function match
def test_match():
    str_0 = 'git status'
    str_1 = 'fatal: Not a git repository (or any of the parent directories): .git'
    var_0 = match(str_0)
    var_1 = match(str_1)
    var_2 = get_new_command(str_0)
    print(var_0)
    print(var_1)
    print(var_2)

# Generated at 2022-06-26 06:47:39.106844
# Unit test for function match
def test_match():
    var_0 = 'git status'
    var_0 = Command(var_0, 'fatal: Not a git repository (or any of the parent directories): .git\n')
    var_1 = match(var_0)
    assert var_1 == True


# Generated at 2022-06-26 06:47:40.013639
# Unit test for function match
def test_match():
    assert match(str_0) # 1


# Generated at 2022-06-26 06:47:40.784859
# Unit test for function match
def test_match():
    assert match('git init')

# Generated at 2022-06-26 06:47:43.662209
# Unit test for function match
def test_match():
    cmd_0 = u'git diff'
    out_0 = u'fatal: Not a git repository'
    where_0 = Path(u'.hg')
    assert match(cmd_0, out_0, where_0)


# Generated at 2022-06-26 06:47:45.118968
# Unit test for function match
def test_match():
    var_0 = '/home/user/project/.git'
    var_1 = _get_actual_scm(var_0)


# Generated at 2022-06-26 06:47:46.427316
# Unit test for function match
def test_match():
    str_0 = '*LovdQ\\ae\n$E'
    var_0 = match(str_0)
    assert not var_0

# Generated at 2022-06-26 06:47:51.589078
# Unit test for function match
def test_match():
    with patch('thefuck.rules.git.Path', return_value=True) as \
            get_git_path:
        with patch('thefuck.rules.git.which', return_value=None) as \
                which_command:
            assert match('fatal: Not a git repository')
            get_git_path.assert_any_call()
            which_command.assert_any_call('git')
