

# Generated at 2022-06-26 06:39:14.215886
# Unit test for function match
def test_match():
    match = MagicMock(return_value = True)
    assert match()


# Generated at 2022-06-26 06:39:16.719900
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository (or any of the parent directories): .git'
    var_0 = match(str_0)
    assert var_0


# Generated at 2022-06-26 06:39:24.695981
# Unit test for function match
def test_match():
    script_0   = "hg status"
    output_0   = "abort: no repository found in '/Users/matthew/Documents/Projects/Python/TheFuck (hg repo) (hg link)/thefuck/tests'!\n(.hg not found)\n"
    pattern_0  = "abort: no repository found"
    script_1   = "git br"
    output_1   = "fatal: Not a git repository (or any of the parent directories): .git\n"
    pattern_1  = "fatal: Not a git repository"
    assert(match(script_0) == pattern_0)
    assert(match(script_1) == pattern_1)


# Generated at 2022-06-26 06:39:26.685487
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository'
    var_2 = match(str_0)

# Generated at 2022-06-26 06:39:33.921498
# Unit test for function match
def test_match():
    assert wrong_scm_patterns['hg'] == 'abort: no repository found'
    assert wrong_scm_patterns['git'] == 'fatal: Not a git repository'
    assert _get_actual_scm() is not None
    assert path_to_scm['.git'] == 'git'
    assert path_to_scm['.hg'] == 'hg'
    assert match('hg pull')
    assert get_new_command('hg pull') == 'git pull'

# Generated at 2022-06-26 06:39:34.743618
# Unit test for function match
def test_match():
    # Call the function with arguments:
    match('')

# Generated at 2022-06-26 06:39:42.122560
# Unit test for function match
def test_match():
    with mock.patch('thefuck.rules.git.is_hg', lambda x: False):
        # Test 1.
        with mock.patch('thefuck.rules.git.is_git', lambda x: True):
            assert_true(match('git branch edit'))
        # Test 2.
        with mock.patch('thefuck.rules.git.is_git', lambda x: False):
            assert_true(match('git branch edit'))
        # Test 3.
        with mock.patch('thefuck.rules.git.is_hg', lambda x: True):
            assert_true(match('git branch edit'))
        # Test 4.

# Generated at 2022-06-26 06:39:43.695658
# Unit test for function match
def test_match():
    assert match('fatal: Not a git repository')
    assert not match('abort: no repository found')

# Generated at 2022-06-26 06:39:47.891595
# Unit test for function match
def test_match():
    str_1 = ' git commit -m "MRO"  }'
    str_2 = 'hg status }'
    var_1 = match(str_1)
    var_2 = match(str_2)
    assert var_1
    assert var_2


# Generated at 2022-06-26 06:39:55.581253
# Unit test for function match
def test_match():
    # Getting system information
    file_name = os.path.basename(__file__)
    file_path = os.path.abspath(__file__)
    file_directory = os.path.dirname(os.path.abspath(__file__))
    os_name = os.name
    os_type = platform.system()

    # Running test
    input_command = 'git status'
    actual_output = match(input_command)
    expected_output = False

    # Printing output
    if actual_output == expected_output:
        print(
            f'[{file_name} {os_name} {os_type}]\n[PASS]')

# Generated at 2022-06-26 06:39:58.701195
# Unit test for function match
def test_match():
    assert match('hello') == False


# Generated at 2022-06-26 06:40:01.347050
# Unit test for function match
def test_match():
    str_0 = 'git status'
    var_0 = match(str_0)
    return var_0

test_match()

# Generated at 2022-06-26 06:40:02.528068
# Unit test for function match
def test_match():
    assert match('git commit') == True
    assert match('hg tip') == True

# Generated at 2022-06-26 06:40:11.218191
# Unit test for function match
def test_match():
    path_to_scm = {}
    path_to_scm.pop('', '')
    empty_patterns = {}
    empty_patterns.pop('', '')
    path_to_scm['.git'] = 'git'
    path_to_scm['.hg'] = 'hg'
    wrong_scm_patterns = {}
    wrong_scm_patterns.pop('', '')
    wrong_scm_patterns['git'] = 'fatal: Not a git repository'
    wrong_scm_patterns['hg'] = 'abort: no repository found'

    assert match(u'git asdff') == True
    assert match(u'git asdff') == True
    assert match(u'git asdff') == True

# Generated at 2022-06-26 06:40:12.282192
# Unit test for function match
def test_match():
    assert match('git status')


# Generated at 2022-06-26 06:40:14.391685
# Unit test for function match
def test_match():
    str_0 = ' }'
    var_0 = match(str_0)

    assert var_0 == None

# Generated at 2022-06-26 06:40:18.397030
# Unit test for function match
def test_match():
    assert(match('git status') == True)
    assert(match('git remote add origin git@github.com:rfhwiggins/dotfiles.git') == True)
    assert(match('git push -u origin master') == True)
    assert(match('hg status') == True)
    assert(match('hg add') == True)
    assert(match('mercurial') == False)


# Generated at 2022-06-26 06:40:29.058465
# Unit test for function match
def test_match():
    str_0 = ' '
    var_0 = match(str_0)
    assert var_0 == None

    str_1 = ' '
    var_1 = match(str_1)
    assert var_1 == None

    str_2 = ' '
    var_2 = match(str_2)
    assert var_2 == None

    str_3 = ' '
    var_3 = match(str_3)
    assert var_3 == None

    str_4 = ' '
    var_4 = match(str_4)
    assert var_4 == None

    str_5 = ' '
    var_5 = match(str_5)
    assert var_5 == None

    str_6 = ' '
    var_6 = match(str_6)
    assert var_6 == None

    str_

# Generated at 2022-06-26 06:40:31.424526
# Unit test for function match
def test_match():
    str_0 = ' }'
    var_0 = match(str_0)
    assert var_0 == False

# Generated at 2022-06-26 06:40:36.123349
# Unit test for function match
def test_match():
    var_1 = ' }'
    var_1 = match(var_1)
    assert var_1 == False

    var_2 = 'fatal: Not a git repository'
    var_2 = match(var_2)
    assert var_2 == True

    var_3 = 'abort: no repository found'
    var_3 = match(var_3)
    assert var_3 == True

# Generated at 2022-06-26 06:40:41.348135
# Unit test for function match
def test_match():
    assert match('') == True
    assert match('fatal: Not a git repository') == True
    assert match('abort: no repository found') == True


# Generated at 2022-06-26 06:40:50.560129
# Unit test for function match
def test_match():
    assert match(u'git commit -m "{}"' + 
                                                 '\nfatal: Not a git repository (or any of the parent directories): .git')
    assert match(u'hg commit -m {}' + 
                                                 '\nabort: no repository found in' +
                                                 '\n ()')
    assert match(u'git rev-parse' + 
                                                 '\nfatal: Not a git repository (or any of the parent directories): .git')
    assert match(u'hg rev-parse' + 
                                                 '\nabort: no repository found in' +
                                                 '\n ()')
    assert not match(u'git push' + 
                                                 '\nfatal: Not a git repository (or any of the parent directories): .git')


# Generated at 2022-06-26 06:40:52.563175
# Unit test for function match
def test_match():
    assert match("fatal: Not a git repository") is True
    assert match("abort: no repository found") is True

# Generated at 2022-06-26 06:40:56.999310
# Unit test for function match
def test_match():
    str_0 = 'git status'
    str_1 = 'git status'
    str_2 = 'hg commit'
    var_0 = match(str_0)
    var_1 = match(str_1)
    var_2 = match(str_2)

# Unit tests for function get_new_command

# Generated at 2022-06-26 06:40:58.132278
# Unit test for function match
def test_match():
    assert match(str_0) == True


# Generated at 2022-06-26 06:41:01.394933
# Unit test for function match
def test_match():
    var_0 = Command.from_string('git status')
    var_0.output = 'fatal: Not a git repository'
    var_1 = _get_actual_scm()
    assert match(var_0)


# Generated at 2022-06-26 06:41:11.114789
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository (or any of the parent directories): .git  \n'
    var_0 = match(str_0)
    assert (var_0 == False)

    str_0 = 'fatal: Not a git repository (or any of the parent directories): .git  \n'
    var_0 = match(str_0)
    assert (var_0 == False)

    str_0 = 'abort: no repository found in http://github.com/nvbn/thefuck\n'
    var_0 = match(str_0)
    assert (var_0 == False)

    str_0 = 'abort: no repository found in http://github.com/nvbn/thefuck\n'
    var_0 = match(str_0)
    assert (var_0 == False)

# Generated at 2022-06-26 06:41:13.494028
# Unit test for function match
def test_match():
    assert match('git commit') == False
    assert match('hg commit') == False
    assert match('git commit') == False


# Generated at 2022-06-26 06:41:15.424365
# Unit test for function match
def test_match():
    str_0 =' }'
    var_0 = match(str_0)
    assert(var_0 == False)

# Generated at 2022-06-26 06:41:16.726249
# Unit test for function match
def test_match():
    assert get_new_command('') == ''


# Generated at 2022-06-26 06:41:23.255575
# Unit test for function match
def test_match():
    assert match(test_case_0()) == True


# Generated at 2022-06-26 06:41:27.498252
# Unit test for function match
def test_match():
    #assert match(str_0) == True
    #assert match(str_1) == False
    #assert match(str_2) == False
    #assert match(str_3) == False
    assert match(str_4) == False
    

# Generated at 2022-06-26 06:41:30.962503
# Unit test for function match
def test_match():
    cmd = Command(str_0)
    actual_result = match(cmd)
    expected_result = False
    assert expected_result == actual_result

test_case_0()

# Generated at 2022-06-26 06:41:32.886536
# Unit test for function match
def test_match():
    assert match(test_case_0) == False


# Generated at 2022-06-26 06:41:35.648419
# Unit test for function match
def test_match():
    str_0 = 'abort: no repository found'
    str_1 = 'fatal: Not a git repository'
    assert match(str_0) == None
    assert match(str_1) == None

# Generated at 2022-06-26 06:41:43.044133
# Unit test for function match
def test_match():
    # Configure the mock object
    command = mock.MagicMock(spec = 'thefuck.types.Command')
    command.script_parts = ['git', 'status']
    command.output = 'abort: no repository found'
    _get_actual_scm = mock.MagicMock(return_value = '.hg')

    # Execute the tested function
    result = match(command)

    # Check the result
    assert result == True
    assert _get_actual_scm.called


# Generated at 2022-06-26 06:41:45.781949
# Unit test for function match
def test_match():
    str_0 = 'git status'
    assert match(str_0)
    print(get_new_command(str_0))


if __name__ == '__main__':
    test_match()

# Generated at 2022-06-26 06:41:48.153625
# Unit test for function match
def test_match():
    command = Command(script_parts=['git', 'status'], stdout=b'fatal: Not a git repository')
    assert match(command) == True
    

# Generated at 2022-06-26 06:41:48.987989
# Unit test for function match
def test_match():
    assert True


# Generated at 2022-06-26 06:41:53.647942
# Unit test for function match
def test_match():
    line_0 = 'not a git repository'
    actual_0 = match(line_0)
    assert actual_0 == None
    line_1 = 'fatal: Not a git repository: .git'
    actual_1 = match(line_1)
    assert actual_1 == None
    pass


# Generated at 2022-06-26 06:41:58.099390
# Unit test for function match
def test_match():
    str_0 = '}'
    result_0 = match(str_0)
    assert result_0 == False


# Generated at 2022-06-26 06:42:00.352388
# Unit test for function match
def test_match():

    # Test if the function returns the right value
    var_0 = match('mercurial')
    var_1 = match('git')


# Generated at 2022-06-26 06:42:01.838963
# Unit test for function match
def test_match():
    str_0 = thefuck.utils.get_closest
    var_0 = match(str_0)

# Generated at 2022-06-26 06:42:02.628797
# Unit test for function match
def test_match():
    assert callable(match)


# Generated at 2022-06-26 06:42:03.377321
# Unit test for function match
def test_match():
    assert(match(' }'))



# Generated at 2022-06-26 06:42:08.202327
# Unit test for function match
def test_match():
    str_0 = ''
    str_1 = ''
    str_2 = ''

    assert match(str_0) == False
    assert match(str_1) == False
    assert match(str_2) == False



# Generated at 2022-06-26 06:42:10.391601
# Unit test for function match
def test_match():
    assert match( 'hg status' )
    assert match( 'git add' )


# Generated at 2022-06-26 06:42:19.845051
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository'
    var_0 = match(str_0)
    str_1 = 'fatal: Not a git repository'
    var_1 = match(str_1)
    str_2 = 'fatal: Not a git repository'
    var_2 = match(str_2)
    str_3 = 'abort: no repository found'
    var_3 = match(str_3)
    str_4 = 'abort: no repository found'
    var_4 = match(str_4)
    str_5 = 'abort: no repository found'
    var_5 = match(str_5)
    str_6 = ' }'
    var_6 = match(str_6)
    str_7 = 'abort: no repository found'

# Generated at 2022-06-26 06:42:21.470182
# Unit test for function match
def test_match():
    assert(match("git status"))
    assert(not match("git add"))


# Generated at 2022-06-26 06:42:24.175483
# Unit test for function match
def test_match():
    str_0 = ' }'
    var_1 = match(str_0)
    assert var_1


# Generated at 2022-06-26 06:42:30.299815
# Unit test for function match
def test_match():
    cmd = 'git reset --hard origin/master'
    assert match(cmd)


# Generated at 2022-06-26 06:42:31.758964
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-26 06:42:39.049449
# Unit test for function match
def test_match():
    str_0 = get_new_command('git rev-parse --abbrev-ref HEAD')
    str_1 = get_new_command('git status')
    str_2 = get_new_command('git commit')
    str_3 = get_new_command('git branch')
    str_4 = get_new_command('git push')
    str_5 = get_new_command('git reset --hard origin/master')
    str_6 = get_new_command('git checkout master')


# Generated at 2022-06-26 06:42:47.278386
# Unit test for function match
def test_match():
    # Expected outcomes
    assert not match(Command('git rebase origin/master', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git rebase origin/master', 'fatal: Not a git repository (or any of the parent directories): .git\n', path='/Users/lancelobanov'))
    assert not match(Command('git rebase origin/master', 'rb: fail\n', path='/Users/lancelobanov'))
    assert match(Command('hg rebase origin/master', 'abort: no repository found (.hg not found)!\n', path='/Users/lancelobanov'))


# Generated at 2022-06-26 06:42:49.674532
# Unit test for function match
def test_match():
    command = 'git'
    output = ' '
    match(command, output)


# Generated at 2022-06-26 06:42:59.154195
# Unit test for function match
def test_match():
    str_0 = ' }'
    str_1 = ' '
    str_2 = '"%s" does not appear to be a git repository'
    str_3 = '}'
    str_4 = '{'
    str_5 = 'This operation is not supported in this workbench.'
    str_6 = 'k'
    str_7 = '}'
    str_8 = 'I'
    str_9 = 'fatal: Not a git repository'
    str_10 = '%s'
    var_0 = u''
    var_1 = u'{'
    var_2 = u' }'
    var_3 = u' '
    var_4 = u''
    var_5 = u'{'
    var_6 = u''
    var_7 = u'}'
    var

# Generated at 2022-06-26 06:43:00.825436
# Unit test for function match
def test_match():
    assert match('jshint **/*.js') == True
    assert match('jshint **/*.js') == False


# Generated at 2022-06-26 06:43:04.797329
# Unit test for function match
def test_match():
    assert match('git match') == True
    assert match('git match') == True
    assert match('git match') == True
    assert match('git match') == False
    assert match('hg match') == False
    assert match('hg match') == True

# Generated at 2022-06-26 06:43:05.782090
# Unit test for function match
def test_match():
    assert match('') == None



# Generated at 2022-06-26 06:43:08.700370
# Unit test for function match
def test_match():
    str_0 = 'cd . . .'
    bool_0 = match(str_0)
    bool_1 = match(str_0)



# Generated at 2022-06-26 06:43:22.885951
# Unit test for function match
def test_match():
    assert (match('git status')).script == u'git status'
    assert (match('git status')).stdout == u""
    assert (match('git status')).stderr == u""
    assert (match('git status')).script_parts == [u'git', u'status']
    assert (match('git status')).output == u'fatal: Not a git repository'
    assert (match('git status')).matched_expr == u'fatal: Not a git repository'
    assert (match('git status')).rule == 'git_root'


# Generated at 2022-06-26 06:43:24.648063
# Unit test for function match
def test_match():
    str_0 = ' }'
    var_0 = match(str_0)
    var_1 = match(str_0)

# Generated at 2022-06-26 06:43:25.500642
# Unit test for function match
def test_match():
    assert match('') == None


# Generated at 2022-06-26 06:43:27.049283
# Unit test for function match
def test_match():
    assert match('.git status') == True
    assert match('git status') == True



# Generated at 2022-06-26 06:43:30.849941
# Unit test for function match
def test_match():
    assert match('fatal: Not a git repository') == True
    assert match('abort: no repository found') == True
    assert match('abort: no repository found (try running this command in the root of a Mercurial repository)') == True

# Generated at 2022-06-26 06:43:32.236581
# Unit test for function match
def test_match():
    assert match("fatal: Not a git repository (or any of the parent directories): .git") == True


# Generated at 2022-06-26 06:43:33.237443
# Unit test for function match
def test_match():
    assert match('') == ''


# Generated at 2022-06-26 06:43:34.640612
# Unit test for function match
def test_match():
	result = match('fatal: Not a git repository')
	assert result == True


# Generated at 2022-06-26 06:43:44.721092
# Unit test for function match
def test_match():
    str_1 = 'foo '
    str_2 = 'bar '
    str_3 = 'foo bar'
    str_4 = '!@#$%^&*'
    str_5 = '%^&*()'
    str_6 = '()_+'
    str_7 = '~`'
    str_8 = '1234567890-='
    str_9 = 'qwertyuiop[]\\'
    str_10 = 'asdfghjkl;\''
    str_11 = 'zxcvbnm,./'
    str_12 = 'zxcvbnm,./asdfghjkl;\'qwertyuiop[]\\1234567890-='
    str_13 = '!@#$%^&*()_+-='

# Generated at 2022-06-26 06:43:46.683186
# Unit test for function match
def test_match():
    # Run the test
    test_case_0()


# Generated at 2022-06-26 06:44:09.321569
# Unit test for function match
def test_match():
    str_1 = 'git status'
    str_2 = 'fatal: Not a git repository'
    str_3 = 'git'
    var_2 = match(str_1,str_2,str_3)
    assert var_2 == 'True'

# Generated at 2022-06-26 06:44:11.593637
# Unit test for function match
def test_match():
    assert match('fatal: Not a git repository') == False
    assert match('abort: no repository found') == False
    # match('') should be False

# Generated at 2022-06-26 06:44:13.926205
# Unit test for function match
def test_match():
    str_0 = ['git']
    var_0 = match(str_0)
    assert var_0 is not False


# Generated at 2022-06-26 06:44:15.989732
# Unit test for function match
def test_match():
    # Test:
    #   * Case 0
    str_0 = ' }'
    var_0 = match(str_0)
    assert var_0 == True


# Generated at 2022-06-26 06:44:17.194897
# Unit test for function match
def test_match():
    assert True == match('}')



# Generated at 2022-06-26 06:44:20.782919
# Unit test for function match
def test_match():
    var_1 = Path(']')
    var_2 = var_1.is_dir()
    var_3 = '.'
    var_4 = var_3.is_dir()
    ref_1 = var_4
    assert (ref_1 == var_2) == True


# Generated at 2022-06-26 06:44:22.590970
# Unit test for function match
def test_match():
    assert match("git a") == False
    assert match("git a") == False
    assert match("git a") == False

# Generated at 2022-06-26 06:44:23.743673
# Unit test for function match
def test_match():
    assert match('git status')
    assert match('hg commit')


# Generated at 2022-06-26 06:44:26.199251
# Unit test for function match
def test_match():
    str_0 = 'git: \'checkout\' is not a git command'
    var_0 = match(str_0)
    assert var_0 == False


# Generated at 2022-06-26 06:44:28.524919
# Unit test for function match
def test_match():
    arg_0 = "rm -rf ~/Wrong/repo\nfatal: Not a git repository (or any of the parent directories): .git"
    match(arg_0)


# Generated at 2022-06-26 06:45:05.219138
# Unit test for function match
def test_match():
    scm = 'git'
    pattern = 'fatal: Not a git repository'
    output = 'fatal: Not a git repository'

    assert match(scm, pattern, output) == true


# Generated at 2022-06-26 06:45:10.488714
# Unit test for function match

# Generated at 2022-06-26 06:45:12.344229
# Unit test for function match
def test_match():

    var_0 = get_new_command(str_0)
    assert var_0 == ' }'

# Generated at 2022-06-26 06:45:13.118166
# Unit test for function match
def test_match():
    assert _get_actual_scm() == 'git'

# Generated at 2022-06-26 06:45:21.205024
# Unit test for function match
def test_match():
    var_1 = "foo\nfatal: Not a git repository (or any of the parent directories): .git"
    var_1 = match(var_1)
    var_2 = "foo\nabort: no repository found in"
    var_2 = match(var_2)
    var_3 = "foo\n"
    var_3 = match(var_3)
    var_4 = "foo\nfatal: Not a git repositor y (or any of the parent directories): .git"
    var_4 = match(var_4)


# Generated at 2022-06-26 06:45:23.272302
# Unit test for function match
def test_match():
    var_0 = match(var_0)
    assert var_0 == ' git remote add origin git@github.com:pshah123'



# Generated at 2022-06-26 06:45:25.717382
# Unit test for function match
def test_match():
    str_0 = ''
    assertion_failed = False
    try:
        match(str_0)
        assert False
    except AssertionError:
        assertion_failed = True
    assert assertion_failed


# Generated at 2022-06-26 06:45:28.091701
# Unit test for function match
def test_match():
    output_0 = "fatal: Not a git repository"
    func_0 = match(output_0)
    test = func_0
    assert test



# Generated at 2022-06-26 06:45:28.942760
# Unit test for function match
def test_match():
    assert match('git push origin master')


# Generated at 2022-06-26 06:45:38.333302
# Unit test for function match
def test_match():
    arg0 = ''
    arg1 = ''
    arg2 = get_new_command(arg2)
    try:
        ret_0 = match(arg0, arg1, arg2)
    except:
        ret_0 = None
    try:
        ret_1 = match(arg0, arg1)
    except:
        ret_1 = None
    try:
        ret_2 = match(arg0, arg1, arg2)
    except:
        ret_2 = None
    try:
        ret_3 = match(arg0, arg1)
    except:
        ret_3 = None
    assert ret_0 == False
    assert ret_1 == False
    assert ret_2 == False
    assert ret_3 == False

# Generated at 2022-06-26 06:47:03.027429
# Unit test for function match
def test_match():
    assert match(u'echo i refs/remotes/remote-name/master') == True
    

# Generated at 2022-06-26 06:47:04.814090
# Unit test for function match
def test_match():
    test_obj_0 = ' }'
    var_0 = match(test_obj_0)
    assert var_0 == true

# Test match with arg 2

# Generated at 2022-06-26 06:47:09.968847
# Unit test for function match
def test_match():
    # path_to_scm
    str_0 = Path('.git')
    str_1 = Path('.git').is_dir()
    str_2 = Path('.hg')
    str_3 = Path('.hg').is_dir()
    str_4 = 'git'
    str_5 = 'hg'
    var_0 = match(str_0)
    var_1 = match(str_1)
    var_2 = match(str_2)
    var_3 = match(str_3)
    var_4 = match(str_4)
    var_5 = match(str_5)


# Generated at 2022-06-26 06:47:15.570155
# Unit test for function match
def test_match():
    # Unit test of function match
    str_0 = 'git status\ngit: \'statu\' is not a git command. See \'git --help\'.\n\nThe most similar command is\n\tstatus\n'
    str_1 = 'abort: no repository found in \'~/.dotfiles/.gems\' (.hg not found)!\n'
    var_0 = match(str_0)
    var_1 = match(str_1)
    assert var_0 == True
    assert var_1 == True


# Generated at 2022-06-26 06:47:17.706575
# Unit test for function match
def test_match():
    x=_get_actual_scm()
    if 'git' in command.output:
        return True
    else:
        return False

# Generated at 2022-06-26 06:47:19.995698
# Unit test for function match
def test_match():
    str_0 = 'fatal: Not a git repository (or any of the parent directories): .git'
    var_0 = match(str_0)

# Generated at 2022-06-26 06:47:23.658552
# Unit test for function match
def test_match():
    str_0 = "' }'"
    var_0 = match(str_0)
    assert var_0 == False

    str_1 = " }'\nfatal: Not a git repository: '.git'\n"
    var_1 = match(str_1)
    assert var_1 == True


# Generated at 2022-06-26 06:47:30.718046
# Unit test for function match
def test_match():
    str_0 = 'git commit -am "Nice commit message"' # Should be "hg commit -am "Nice commit message""
    var_0 = match(str_0)
    assert var_0 == True

    str_0 = 'hg commit -am "Nice commit message" # Should be "hg commit -am "Nice commit message""'
    var_0 = match(str_0)
    assert var_0 == True

    str_0 = 'blah blah blah'
    var_0 = match(str_0)
    assert var_0 == False


# Generated at 2022-06-26 06:47:34.430106
# Unit test for function match
def test_match():
    str_0 = 'git status'
    output_0 = 'fatal: Not a git repository'
    var_0 = match(str_0, output_0)

    print(var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 06:47:38.102577
# Unit test for function match
def test_match():
    # check that error message is detected
    assert match('fatal: Not a git repository')
    assert match('abort: no repository found')

    # should not be detected if error message is not present
    assert not match('git status')
    assert not match('hg status')

    # should work with any number of arguments
    assert match('hg status -s')
    assert match('git status -s')