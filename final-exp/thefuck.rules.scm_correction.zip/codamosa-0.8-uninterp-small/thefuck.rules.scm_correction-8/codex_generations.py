

# Generated at 2022-06-26 06:39:14.651918
# Unit test for function match
def test_match():

    # Call get_new_command() with a mock and check if it returns the correct
    # answer.
    var_0 = _get_actual_scm()
    assert var_0 == ''


# Generated at 2022-06-26 06:39:15.452896
# Unit test for function match
def test_match():
    assert True == match(False)


# Generated at 2022-06-26 06:39:19.425934
# Unit test for function match
def test_match():
    command = ''
    try:
        match(command)
    except TypeError as e:
        assert 'wrong type' in e.message
    command = ''
    try:
        match(command)
    except TypeError as e:
        assert 'wrong type' in e.message


# Generated at 2022-06-26 06:39:20.605218
# Unit test for function match
def test_match():
    # Arguments
    command = None

    assert match(command)


# Generated at 2022-06-26 06:39:21.452758
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 06:39:26.253950
# Unit test for function match
def test_match():
    var_0 = Mock(script='git commit', output='fatal: Not a git repository')
    var_1 = match(var_0)
    assert(var_1 == True)
    var_2 = Mock(script='git commit', output='fatal: Not a git repo')
    var_3 = match(var_2)
    assert(var_3 == False)


# Generated at 2022-06-26 06:39:36.590413
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository')) is True
    assert match(Command('git status', 'fatal: Not a git repository')) is True
    assert match(Command('git status', 'fatal: Not a git repository')) is True
    assert match(Command('git status', 'fatal: Not a git repository')) is True
    assert match(Command('git status', 'fatal: Not a git repository')) is True
    assert match(Command('git status', 'abort: no repository found')) is False
    assert match(Command('git status', 'abort: no repository found')) is False
    assert match(Command('git status', 'abort: no repository found')) is False
    assert match(Command('git status', 'abort: no repository found')) is False

# Generated at 2022-06-26 06:39:37.857443
# Unit test for function match
def test_match():
    test_command = Command('git status', '', '')
    assert match(test_command) == True


# Generated at 2022-06-26 06:39:43.898818
# Unit test for function match
def test_match():
    from thefuck.rules.vcs_func import match
    from thefuck.rules.vcs_func import wrong_scm_patterns
    from thefuck.rules.vcs_func import get_actual_scm as _get_actual_scm
    from thefuck.types import Command
    _get_actual_scm._cache.clear()
    var_0 = Command(script='', below='', above='', stderr=u'fatal: Not a git repository (or any of the parent directories): .git', stdout=u'', argv=[])
    bool_0 = wrong_scm_patterns['git'] in var_0.output
    var_1 = get_new_command(var_0)
    assert match(var_0) is None
    assert bool_0 is True
    assert var_1 == u

# Generated at 2022-06-26 06:39:52.606653
# Unit test for function match
def test_match():
    # Mock of Command
    class Command(object):
        def __init__(self, output, script_parts):
            self.output = output
            self.script_parts = script_parts
    # Asserts
    bool_0 = match(Command('fatal: Not a git repository', ['git', 'pull', 'origin']))
    bool_1 = match(Command('abort: no repository found', ['hg', 'pull', 'origin']))
    bool_2 = match(Command('Error', []))
    bool_3 = match(Command('Error', ['hg', 'pull', 'origin']))

    assert bool_0 == True
    assert bool_1 == True
    assert bool_2 == False
    assert bool_3 == False


# Generated at 2022-06-26 06:40:04.386092
# Unit test for function match
def test_match():
    var_1 = "hg comit -m 'first'"
    var_2 = Command(var_1)
    var_3 = '.git'
    var_4 = Path(var_3)
    var_5 = var_4.is_dir()
    var_6 = 'git'
    var_7 = var_2.output
    var_8 = wrong_scm_patterns[var_6]
    var_9 = var_8 in var_7
    var_10 = _get_actual_scm()
    var_11 = var_9 and var_10
    var_12 = get_new_command(var_2)
    var_13 = _get_actual_scm()
    var_14 = var_2.script_parts
    var_15 = 1
    var_16 = var_14

# Generated at 2022-06-26 06:40:10.010629
# Unit test for function match
def test_match():
    assert match(command='hg commit') == True
    assert match(command='git commit') == True

# Generated at 2022-06-26 06:40:11.843555
# Unit test for function match
def test_match():
    result = match('git')
    assert result == True


# Generated at 2022-06-26 06:40:12.794171
# Unit test for function match
def test_match():
    do_test_case_0()


# Generated at 2022-06-26 06:40:18.900637
# Unit test for function match
def test_match():
    from thefuck.shells import shell
    import os

    # Default test case, where command matches with the rule
    script = 'ls -la'
    output = 'bash: ls: command not found'
    command = Command(script, output)
    match_status = match(command)
    assert match_status == True
    new_command = get_new_command(command)
    assert new_command == 'ls -la'

    # False test case
    script = 'ls -la'
    output = ''
    command = Command(script, output)
    match_status = match(command)
    assert match_status == False

# Generated at 2022-06-26 06:40:29.056531
# Unit test for function match
def test_match():
    var_0 = None
    var_1 = Std(var_0).output_text == 'fatal: Not a git repository'
    var_2 = Std(var_0).output_text == 'abort: no repository found'
    var_3 = Path('.git').is_dir() or Path('.hg').is_dir()
    var_4 = var_1 and var_3 or var_2 and var_3
    var_5 = Command()
    var_5.script = 'git'
    var_5.script_parts = ['git', 'status']
    var_5.stdout = Std(var_5).stdout
    var_5.stderr = Std(var_5).stderr
    var_5.output = Std(var_5).output

# Generated at 2022-06-26 06:40:33.299800
# Unit test for function match
def test_match():
    new_command = get_new_command(bool_0)
    assert new_command == "git config user.name John Doe"
    new_command = get_new_command(bool_1)
    assert new_command == "git config user.email john@example.com"

# Generated at 2022-06-26 06:40:39.944598
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'fatal: Not a git repository (or any of the parent directories): .git\n', '', '', '', ''))
    assert not match(Command('git push origin master', 'fatal: Not a git repository (or any of the parent directories): .git\n', '', '', '', ''))
    assert match(Command('git push origin master', 'abort: no repository found in /home/demo/.vesta/conf!\n', '', '', '', ''))
    assert not match(Command('git push origin master', 'abort: no repository found in /home/demo/.vesta/conf!\n', '', '', '', ''))


# Generated at 2022-06-26 06:40:45.600977
# Unit test for function match
def test_match():
    var_0 = 'git status'
    var_1 = Command(script=var_0)
    var_2 = 'abort: no repository found'
    var_3 = _get_actual_scm()
    var_4 = (var_2 in var_1.output and var_3)
    assert var_4 == match(var_1)


# Generated at 2022-06-26 06:40:46.403295
# Unit test for function match
def test_match():
    assert match(bool_0) == None

# Generated at 2022-06-26 06:40:55.745057
# Unit test for function match
def test_match():

    # Test with no input

    # Test with a git output
    var_4 = Command('git foo', '', '', 'fatal: Not a git repository\n')
    bool_0 = match(var_4)
    assert bool_0 == True

    # Test with a hg output
    var_5 = Command('hg foo', '', '', 'abort: no repository found\n')
    bool_1 = match(var_5)
    assert bool_1 == True


# Generated at 2022-06-26 06:41:00.003020
# Unit test for function match
def test_match():
    true = match(command=get_new_command(Command(script='thefuck git fdsf', output="fatal: Not a git repository")))
    assert true == True
    true = match(command=get_new_command(Command(script='thefuck hg fdsf', output="abort: no repository found")))
    assert true == True


# Generated at 2022-06-26 06:41:06.608810
# Unit test for function match
def test_match():
    assert match(Command("git x", "fatal: Not a git repository"))
    assert match(Command("git x", "abort: no repository found"))
    assert match(Command("git x", "abort: no repository found\n"))
    assert not match(Command("git x", "fatal: Not a git repository\n"))
    assert not match(Command("git x", ""))
    return 0


# Generated at 2022-06-26 06:41:10.710747
# Unit test for function match
def test_match():
    var_0 = Command('hg status', 'abort: no repository found')
    var_1 = match(var_0)
    assert not var_1
    bool_0 = None
    var_2 = Command('git status', 'fatal: Not a git repository')
    var_3 = match(var_2)
    assert var_3


# Generated at 2022-06-26 06:41:12.006300
# Unit test for function match
def test_match():
    assert match(Command("git commit"))


# Generated at 2022-06-26 06:41:12.991493
# Unit test for function match
def test_match():
    assert match('') == None


# Generated at 2022-06-26 06:41:22.623694
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"', 'fatal: Not a git repository')) is True
    assert match(Command('hg commit -m "message"', 'abort: no repository found')) is True
    assert match(Command('hg commit -m "message"', 'abort: no repository found')) is True
    assert match(Command('hg commit -m "message"', 'abort: no repository found')) is True
    assert match(Command('git commit -m "message"', 'fatal: Not a git repository')) is True
    assert match(Command('hg commit -m "message"', 'abort: no repository found')) is True



# Generated at 2022-06-26 06:41:25.753082
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', '', '', ''))
    assert not match(Command('git status', 'fatal: Not a git repository', '', '', ''))


# Generated at 2022-06-26 06:41:33.233286
# Unit test for function match
def test_match():
    # command = "git"
    # pytest.raises(AttributeError, match(command))
    #
    # command = "git status"
    # pytest.raises(AttributeError, match(command))
    #
    # command = "hg not"
    # pytest.raises(AttributeError, match(command))
    #
    # command = "hg status"
    # pytest.raises(AttributeError, match(command))
    pass



# Generated at 2022-06-26 06:41:36.017680
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository')) == False
    


# Generated at 2022-06-26 06:41:46.585193
# Unit test for function match
def test_match():
    assert match(
        Command(script='git',
                stderr='fatal: Not a git repository',
                env={'LANG': 'en_US.UTF-8'})
    )
    assert not match(
        Command(script='git',
                stderr='fatal: Not a git repository',
                env={'LANG': 'zh_CN.UTF-8'})
    )
    assert match(
        Command(script='git',
                stderr='fatal: Not a git repository (or any of the parent directories): .git',
                env={'LANG': 'en_US.UTF-8'})
    )

# Generated at 2022-06-26 06:41:49.419854
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    _get_actual_scm()
    test_case_0()
    assert match(bytes_0)


# Generated at 2022-06-26 06:41:53.241767
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)
    assert(var_0 == False)


# Generated at 2022-06-26 06:41:57.120396
# Unit test for function match
def test_match():
    match_var_1 = match(Script(u'git'))
    match_var_2 = match(Script(u'hg'))


# Generated at 2022-06-26 06:42:04.487693
# Unit test for function match
def test_match():
    var = 3
    def test_case_0():
        bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
        var_0 = match(bytes_0)
        assert var_0
        return

    def test_case_1():
        bytes_0 = b'\x8f(\x92\xd4\x9c\xcf\x93\x0c\x96m\x1e\x8a\xc1\x9f\xab\xcc'
        var_0 = get_new_command(match(bytes_0))
        assert var_0 == b"git rebase"
        return



# Generated at 2022-06-26 06:42:07.443317
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)



# Generated at 2022-06-26 06:42:09.266200
# Unit test for function match
def test_match():
    assert match(False) == command

# Generated at 2022-06-26 06:42:10.676743
# Unit test for function match
def test_match():
    assert match(None)
    assert match(None)


# Generated at 2022-06-26 06:42:12.015071
# Unit test for function match
def test_match():
    assert match(bytes_0) == 0


# Generated at 2022-06-26 06:42:15.347839
# Unit test for function match
def test_match():
    assert match(b'git status')
    assert match(b'git --version')
    assert match(b'hg push')
    assert match(b'hg --version')
    assert not match(b'git status')
    assert not match(b'hg status')


# Generated at 2022-06-26 06:42:21.432712
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert match(Command('hg status', ''))
    assert not match(Command('git status', 'some status'))


# Generated at 2022-06-26 06:42:25.073163
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)
    assert var_0 == False


# Generated at 2022-06-26 06:42:33.875223
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    bytes_1 = b'\xbd\xef\x8f\xea\x0f\x18\xa8\x98\xe3u\xb1+\x99\x11\x92\xd6\xfc\x1bu\x8f\x17\x9a\x16'
    bytes_2 = b'3\x1f\x04\xb3\x91\xda\xf5\x88\xa6\x8e\xfb\n\x12\x85\x16\xdf\x81\x82\xb9\xe6\xd6'

# Generated at 2022-06-26 06:42:36.680468
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    assert match(bytes_0) is False


# Generated at 2022-06-26 06:42:37.531184
# Unit test for function match
def test_match():
    assert match('git init') == True


# Generated at 2022-06-26 06:42:39.839827
# Unit test for function match
def test_match():
    scm_str = 'git'
    result_str = match(scm_str)
    assert result_str is True


# Generated at 2022-06-26 06:42:45.517467
# Unit test for function match
def test_match():
    var_1 = False
    bites_0 = b'missing operand\nfatal: Not a git repository (or any of the parent directories): .git\n'
    bites_1 = b"=\xb8\xcf7YN\x7fmZ~f\r"
    command_0 = Command(b'git status', bites_0, bites_1)

    assert match(command_0) == var_1

# Generated at 2022-06-26 06:42:50.193919
# Unit test for function match
def test_match():
    assert isinstance(match, object)
    # assert match == None
    # assert match == 1
    # assert match == tuple([1, '2'])
    # assert match == tuple()
    assert match == dict([])
    assert match == frozenset()
    assert match == 1.



# Generated at 2022-06-26 06:42:53.420120
# Unit test for function match
def test_match():
    command = 'git commit -m "initial"\ngit status\nfatal: Not a git repository (or any of the parent directories): .git'
    assert match(command)


# Generated at 2022-06-26 06:42:57.328802
# Unit test for function match
def test_match():
    input = "git checkout dev_branch"
    output = "fatal: Not a git repository"
    interp = "hg checkout dev_branch"
    assert match(RunningCommand(input, output)) == True
    assert get_new_command(RunningCommand(input, output)) == interp


# Generated at 2022-06-26 06:43:16.166924
# Unit test for function match
def test_match():
    assert match(b'\xda\xfe\x83\xf9\x9a\xe7\xbe\x16\x8d\x81\xea\xeb\x0c\xe8\xe1\xd0\x85\x1c\x8d\x0f\xb0\xdd\xf8\x9e\xb7\x93\xfa\xb8\xac') == True

# Generated at 2022-06-26 06:43:23.445477
# Unit test for function match
def test_match():

    arg_0 = 'foo bar'
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    arg_1 = 'test output'
    arg_2 = 'test'
    Path.from_parts.return_value = 'from_parts'
    Path.from_parts.is_dir.return_value = None

    var_0 = match(arg_0, arg_1, arg_2)

    assert var_0 == None
    Path.from_parts.assert_called_with(arg_2)


# Generated at 2022-06-26 06:43:27.509396
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)
    assert var_0 == True


# Generated at 2022-06-26 06:43:36.349430
# Unit test for function match
def test_match():
    assert match('git status') == False
    assert match('git commit') == False
    assert match('hg log') == False
    assert match('hg status') == False
    assert match('git pull') == False
    assert match('git push') == False
    assert match('git commands') == False
    assert match('git command') == False
    assert match('hg pull') == False
    assert match('hg push') == False
    assert match('hg commands') == False
    assert match('hg command') == False
    assert match('git log') == False
    assert match('git checkout') == False
    assert match('git fetch') == False
    assert match('git merge') == False
    assert match('hg commit') == False
    assert match('hg checkout') == False
    assert match('hg fetch') == False


# Generated at 2022-06-26 06:43:44.114556
# Unit test for function match
def test_match():
    assert match(bytes('git status', 'utf-8')) == True
    assert match(bytes('git diff', 'utf-8')) == False
    assert match(bytes('git commit', 'utf-8')) == False
    assert match(bytes('hg diff', 'utf-8')) == True
    assert match(bytes('hg status', 'utf-8')) == False
    assert match(bytes('hg commit', 'utf-8')) == False
    assert match(bytes('hg push', 'utf-8')) == False


# Generated at 2022-06-26 06:43:47.910866
# Unit test for function match
def test_match():
    assert match('git commit') == True
    assert match('hg commit') == True
    assert match('git rebase') == True
    assert match('hg rebase') == True


# Generated at 2022-06-26 06:43:49.562944
# Unit test for function match
def test_match():
    match('abort: no repository found')


# Generated at 2022-06-26 06:43:59.673851
# Unit test for function match

# Generated at 2022-06-26 06:44:02.145969
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)
    assert not match(Command('git', ''))
    assert not match(Command('thefuck', ''))


# Generated at 2022-06-26 06:44:02.608105
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-26 06:44:29.700400
# Unit test for function match
def test_match():
    # Testing for match
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match(b'') == False
    assert match

# Generated at 2022-06-26 06:44:37.079854
# Unit test for function match
def test_match():
    var_0 = False
    command = 'git status'
    var_2 = True
    for i in range(16):
        if var_2:
            break
    var_3 = False
    command = 'git status'
    var_2 = True
    for i in range(16):
        if var_2:
            break
    var_3 = False
    command = 'git status'
    var_2 = True
    for i in range(16):
        if var_2:
            break
    if var_1:
        if var_1:
            var_0 = True
    var_0 = True
    return True

# Generated at 2022-06-26 06:44:38.444963
# Unit test for function match
def test_match():
    assert match('git status')
    assert not match('git config')
    assert not match('git push')


# Generated at 2022-06-26 06:44:40.603514
# Unit test for function match
def test_match():
    assert(match(b"fatal: Not a git repository") == False)

# Test case for git

# Generated at 2022-06-26 06:44:47.792058
# Unit test for function match

# Generated at 2022-06-26 06:44:52.708083
# Unit test for function match
def test_match():
    # False case
    command_1 = Command('git')
    result = match(command_1)
    assert result == False

    # True case
    command_2 = Command('hg')
    result = match(command_2)
    assert result == True

# Generated at 2022-06-26 06:45:02.516461
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    assert (match(bytes_0) == True)

    string_0 = "xe/\xbd\xed\x8b/"
    assert (match(string_0) == False)

    bytes_1 = b'\x84\x08\x1d"\x87Fz\xc6\x18\xd8\x9c\xf0\x86\xa8\x8f\xfb\xd4\x84\xb2\xba\xee\x16t\xfd\x0c\x0f\x87\x15'
    assert (match(bytes_1) == False)

    bytes_2 = b'\x1e'

# Generated at 2022-06-26 06:45:07.713900
# Unit test for function match
def test_match():
    assert match(b'git remote -v') == False
    assert match(b'hg status') == False
    assert match(b'git status') == False
    assert match(b'hg add') == False
    assert match(b'hg init') == False
    assert match(b'hg pull') == False
    assert match(b'git init') == False
    assert match(b'git commit -m "Initial"') == False
    assert match(b'git push') == False
    assert match(b'hg revert') == False
    assert match(b'git revert') == False


# Generated at 2022-06-26 06:45:17.519490
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)
    assert(var_0 == True)
    bytes_1 = b'\x01\x07\xa4\x91\x80\x82\x06'
    var_1 = match(bytes_1)
    assert(var_1 == False)
    bytes_2 = b'\x8a\x8c\x9b\x90\xba\xc5\x02'
    var_2 = match(bytes_2)
    assert(var_2 == False)

# Generated at 2022-06-26 06:45:19.560098
# Unit test for function match
def test_match():
    var_0 = Path('/.git').is_file()
    assert (var_0 == False)


# Generated at 2022-06-26 06:46:09.527590
# Unit test for function match
def test_match():
    # Command 'git status'
    assert match(Command(script='git status',
                         output=b'dfxx xfdd   xdfd ',
                         stderr=b'fatal: Not a git repository',
                         script_parts=['git', 'status'],
                         stderr_parts=['fatal: Not a git repository'],
                         env={}))

    # Command 'git status'
    assert not match(Command(script='git status',
                             output=b'fatal: Not a git repository ',
                             stderr=b'fatal: Not a git repository',
                             script_parts=['git', 'status'],
                             stderr_parts=['fatal: Not a git repository'],
                             env={}))

    # Command 'git status'

# Generated at 2022-06-26 06:46:10.668201
# Unit test for function match
def test_match():
    assert match([]) == False
    assert match([]) == False


# Generated at 2022-06-26 06:46:13.069268
# Unit test for function match
def test_match():
    assert match(bytes_0) == bytes_0


# Generated at 2022-06-26 06:46:20.521785
# Unit test for function match
def test_match():
    assert not match(Command('git status', 'Not a git repository', ''))
    assert not match(Command('git status', 'fatal: repository', ''))
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('git status', 'fatal: Not a git repository\nfatal: Not a git repository', ''))
    assert not match(Command('git commit', 'fatal: Not a git repository', ''))
    assert not match(Command('hg commit', 'abort: no repository found', ''))
    assert match(Command('hg commit', 'abort: no repository found\nfatal: Not a git repository', ''))

# Generated at 2022-06-26 06:46:24.244703
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    scm_0 = _get_actual_scm()
    pattern_0 = wrong_scm_patterns[scm_0]
    assert(match(bytes_0)) == pattern_0 in bytes_0.output


# Generated at 2022-06-26 06:46:26.683680
# Unit test for function match
def test_match():
    assert match('git status\nfatal: Not a git repository') == False
    assert match('git status\nfatal: Not a hg repository') == False
    assert match('git status\nfatal: Not a git repository') == False
    assert match('git status\nfatal: Not a hg repository') == False

# Generated at 2022-06-26 06:46:30.409050
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A'
    var_0 = match(bytes_0)
    assert(var_0 == 0)



# Generated at 2022-06-26 06:46:31.867338
# Unit test for function match
def test_match():
    result_0 = match(bytes_0)
    assert result_0 == False


# Generated at 2022-06-26 06:46:34.310079
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)



# Generated at 2022-06-26 06:46:37.377973
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository'))
    assert match(Command('hg', 'abort: no repository found'))
    assert not match(Command('git', 'fatal: No such file'))
    assert not match(Command('hg', 'fatal: No such file'))

# Generated at 2022-06-26 06:48:06.050347
# Unit test for function match
def test_match():
    assert match(b'not a git repository')
    assert match(b'abort: no repository found')

# Generated at 2022-06-26 06:48:07.223092
# Unit test for function match
def test_match():
    assert match(wrong_scm_patterns['git']) == _get_actual_scm()


# Generated at 2022-06-26 06:48:08.170747
# Unit test for function match
def test_match():
    result = match(match)
    assert result == True


# Generated at 2022-06-26 06:48:14.290546
# Unit test for function match
def test_match():
    assert match(commands.Command('git status', 'fatal: Not a git repository'))
    assert not match(commands.Command('git commit', 'abort: no repository found'))
    assert not match(commands.Command('git commit', 'fatal: Not a git repository'))
    assert not match(commands.Command('git status', 'abort: no repository found'))

# Generated at 2022-06-26 06:48:15.777905
# Unit test for function match
def test_match():
    assert match('git branch -r')
    assert not match('git branch -r')


# Generated at 2022-06-26 06:48:18.690893
# Unit test for function match
def test_match():
    bytes_0 = b'\xa8A=\xb8\xcf7YN\x7fmZ~f\r'
    var_0 = match(bytes_0)
    assert var_0 == False

# Generated at 2022-06-26 06:48:21.493111
# Unit test for function match
def test_match():
    assert match(b'fatal: Not a git repository')
    assert not match(b'test: Not a git repository')
    assert match(b'abort: no repository found')
    assert not match(b'test: no repository found')


# Generated at 2022-06-26 06:48:23.423625
# Unit test for function match
def test_match():
    assert match('git status')
    assert match('git add')
    assert match('git commit')
    assert match('git pull')


# Generated at 2022-06-26 06:48:24.890270
# Unit test for function match
def test_match():
    args = ( ('./bashrc', 'fatal: Not a git repository'), )
    expected = False
    actual = match(args)
    assert(expected == actual)


# Generated at 2022-06-26 06:48:25.517236
# Unit test for function match
def test_match():
    assert match('') == True
