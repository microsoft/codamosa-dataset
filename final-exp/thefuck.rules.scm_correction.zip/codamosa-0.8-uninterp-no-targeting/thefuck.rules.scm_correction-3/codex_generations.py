

# Generated at 2022-06-22 02:16:28.830636
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git', 'git status')
    assert get_new_command(command) == 'hg status'


enabled_by_default = any([Path(path).is_dir() for path in path_to_scm])

# Generated at 2022-06-22 02:16:33.303544
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository',
                                   '')) == 'hg status'
    assert get_new_command(Command('hg status', 'abort: no repository found', '')) == 'git status'

# Generated at 2022-06-22 02:16:37.496274
# Unit test for function match
def test_match():
    # Git does not match with wrong scm command
    assert not match(Command('git branch', ''))
    # Git does match with right scm command
    assert match(Command('git branch', 'fatal: Not a git repository'))
    # Hg does not match with wrong scm command
    assert not match(Command('hg branch', ''))
    # Hg does match with right scm command
    assert match(Command('hg branch', 'abort: no repository found'))


# Generated at 2022-06-22 02:16:45.212481
# Unit test for function match
def test_match():
    # Should match when a git command is launched in an hg repository
    command = Command(script='git status',
                      output='fatal: Not a git repository',
                      env={'PWD': '/home/louis/Documents/projet/projet'})
    assert match(command)
    # Should match when a hg command is launched in a git repository
    command = Command(script='hg status',
                      output='abort: no repository found',
                      env={'PWD': '/home/louis/Documents/court-circuit'})
    assert match(command)


# Generated at 2022-06-22 02:16:47.966561
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'git: error: no status')) == 'git status'



# Generated at 2022-06-22 02:16:50.839470
# Unit test for function match
def test_match():
	command = 'hg status'
	output = 'abort: no repository found'
	assert match(Command(command, output))
	
	command = 'git status'
	output = 'fatal: not a git repository'
	assert match(Command(command, output))


# Generated at 2022-06-22 02:16:58.667715
# Unit test for function match
def test_match():
    assert match(Command(script='git config --global user.name',
                         output='fatal: Not a git repository'))
    assert match(Command(script='hg commit -m "my commit"',
                         output='abort: no repository found'))
    assert match(Command(script='git branch',
                         output='abort: no repository found'))
    assert not match(Command(script='git config --global user.name',
                             output="fatal: 'git' is not a git command."))
    assert not match(Command(script='hg commit -m "my commit"',
                             output='** unknown exception encountered'))


# Generated at 2022-06-22 02:17:00.416314
# Unit test for function get_new_command
def test_get_new_command():
    command = 'hg status'
    assert get_new_command(command) == 'git status'

# Generated at 2022-06-22 02:17:02.617810
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git status',
                                   '/path/to/git/repo')) == u'git status'

# Generated at 2022-06-22 02:17:03.784634
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'



# Generated at 2022-06-22 02:17:06.749256
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command("git status")
    assert new_command == "hg status"

# Generated at 2022-06-22 02:17:08.849986
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git push origin master'
    assert get_new_command('hg commit') == 'hg commit'

# Generated at 2022-06-22 02:17:12.076168
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git commit -a', output='')
    assert get_new_command(command) == 'hg commit -a'

# Generated at 2022-06-22 02:17:17.753485
# Unit test for function match
def test_match():
    from thefuck.types import Command

    match1 = Command('git push origin master',
                     'fatal: Not a git repository (or any of the parent directories): .git\n')
    match2 = Command('hg status', 'abort: no repository found in /path/to/repo!\n')
    assert not match(match1)
    assert match(match2)



# Generated at 2022-06-22 02:17:19.538864
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'hg commit -m "test"'

# Generated at 2022-06-22 02:17:30.201879
# Unit test for function match
def test_match():
    # Test if the command is git and the actual scm is hg
    command = Command(script="git status",
                      stderr='fatal: Not a git repository')
    new_command = Command(script="hg status",
                      stderr='fatal: Not a git repository')
    assert match(command)
    assert get_new_command(command) == new_command.script
    # Test if the command is hg and the actual scm is git
    command = Command(script="hg status",
                      stderr='abort: no repository found!')
    new_command = Command(script="git status",
                      stderr='abort: no repository found!')
    assert match(command)
    assert get_new_command(command) == new_command.script

# Generated at 2022-06-22 02:17:33.770259
# Unit test for function match
def test_match():
    from thefuck.rules.wrong_scm import match
    from thefuck.types import Command
    assert match(Command('hg log',
        ''))
    assert not match(Command('git log',
        ''))

# Generated at 2022-06-22 02:17:37.663404
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', '')) == 'hg status'
    assert get_new_command(Command('git branch', '', '')) == 'hg branch'
    assert get_new_command(Command('git checkout newbranch', '', '')) == 'hg checkout newbranch'

# Generated at 2022-06-22 02:17:38.811194
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) == 'hg status'

# Generated at 2022-06-22 02:17:41.734841
# Unit test for function match
def test_match():
    message = 'fatal: Not a git repository'
    command = Command('git status', message)
    assert match(command)


# Testing presence of .git directory function match

# Generated at 2022-06-22 02:17:54.656120
# Unit test for function match
def test_match():
    output_git = 'fatal: Not a git reposity'
    output_hg = 'abort: no reposity found'
    path_git = '/.git'
    path_hg = '/.hg'

    # Unit test for git command
    with mock.patch('thefuck.rules.scm.Path') as mock_path:
        mock_path.return_value.is_dir.return_value = True
        command = mock.Mock(script_parts=[u"git"], output=output_git)
        assert match(command) is True
        command = mock.Mock(script_parts=[u"git"], output=output_hg)
        assert match(command) is False

    # Unit test for hg command

# Generated at 2022-06-22 02:17:57.527386
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_use_hg import get_new_command
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-22 02:18:01.863823
# Unit test for function match
def test_match():
    assert match(Command('git', '')) == False
    assert match(Command('hg', '')) == False
    assert match(Command('git rebase', 'fatal: Not a git repository')) == True
    assert match(Command('hg rebase', 'abort: no repository found')) == True


# Generated at 2022-06-22 02:18:08.507895
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command(['git', 'branch'], 'fatal: Not a git repository'))
    assert not match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command(['hg', 'branch'], 'abort: no repository found'))


# Generated at 2022-06-22 02:18:14.047567
# Unit test for function match
def test_match():
	assert match(Command(script='git', 
		stderr='fatal: Not a git repository',
		env={'PWD': '/home/user'},
		)) == True
	assert match(Command(script='git', 
		stderr='abort: no repository found',
		env={'PWD': '/home/user/repo'},
		)) == False


# Generated at 2022-06-22 02:18:16.020502
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git root', 'fatal: Not a git repository', '', 5)
    assert 'hg root' == get_new_command(command)

# Generated at 2022-06-22 02:18:24.563629
# Unit test for function match
def test_match():
    def test_call(output, expected_is_match, expected_scm):
        assert match(Command('git', output=output)) == expected_is_match
        if expected_is_match:
            assert _get_actual_scm() == expected_scm

    for scm, pattern in wrong_scm_patterns.items():
        test_call('Not a ' + scm + ' repository', True, scm)
    assert not match(Command('git', output='Not a git, repository'))


# Generated at 2022-06-22 02:18:25.846147
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git push origin master' == get_new_command('hg push origin master')

# Generated at 2022-06-22 02:18:30.306209
# Unit test for function match
def test_match():
	command = type('obj', (object,), {'script_parts': ['git', 'push', 'origin', 'master']})()
	command.script_parts[0] = 'git'
	command.output = 'fatal: Not a git repository'
	command.script = 'git push origin master'
	assert match(command)


# Generated at 2022-06-22 02:18:33.848328
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg pull', 'abort: no repository found'))
    assert not match(Command('hg pull', 'pulling from default'))



# Generated at 2022-06-22 02:18:40.966321
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status', env={'PWD': '/home/test/'})) == 'hg status'
    assert get_new_command(Command(script='git check', env={'PWD': '/home/test/'})) == 'hg check'



# Generated at 2022-06-22 02:18:43.995088
# Unit test for function match
def test_match():
    assert match(Command('git branch'))
    assert match(Command('hg branch'))
    assert not match(Command('git branch', 'fatal: Not a git repository'))


# Generated at 2022-06-22 02:18:47.418567
# Unit test for function get_new_command
def test_get_new_command():
    command = Namespace(script_parts = ['git', 'commit'], output = 'git: \'commit\' is not a git command.')
    assert get_new_command(command) == 'hg commit'



# Generated at 2022-06-22 02:18:52.278013
# Unit test for function match
def test_match():
    assert match(Command('git status',
                    'fatal: Not a git repository (or any of the parent directories): .git\n', 'dummy'))
    
    assert not match(Command('hg status',
                    'abort: no repository found!\n', 'dummy'))


# Generated at 2022-06-22 02:18:54.210674
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git')) == 'hg'

# Generated at 2022-06-22 02:18:55.954176
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command(Command("git add file.txt")) == "hg add file.txt"

# Generated at 2022-06-22 02:19:02.748482
# Unit test for function match
def test_match():
    assert not match(Command('git status',
                             'fatal: Not a git repository'
                                 ' (or any of the parent directories): .git'))
    assert match(Command('git status',
                         'fatal: Not a git repository'))
    assert match(Command('git status'
                         'fatal: Not a git repository (or any of the parent '
                         'directories): .git'
                         'fatal: Not a git repository (or any of the parent '
                         'directories): .git'))


# Generated at 2022-06-22 02:19:09.247658
# Unit test for function match
def test_match():
    assert not match(Command('git', '', ''))
    assert not match(Command('git', '', wrong_scm_patterns['git']))
    assert not match(Command('hg', '', wrong_scm_patterns['hg']))
    assert match(Command('git', '', wrong_scm_patterns['git']))
    assert match(Command('hg', '', wrong_scm_patterns['hg']))


# Generated at 2022-06-22 02:19:10.539890
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg status', 'abc: Not a git repository')) == 'git status'

# Generated at 2022-06-22 02:19:13.090691
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('hg common',
                                    'fatal: Not a git repository',
                                    '')) == 'git common'

# Generated at 2022-06-22 02:19:18.455840
# Unit test for function match
def test_match():
    # no repo dir
    command = Command('status', '', 'fatal: Not a git repository')
    assert match(command) == False

    # repo dir exists
    command = Command('git status', '', 'fatal: Not a git repository')
    assert match(command) == True


# Generated at 2022-06-22 02:19:20.862328
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git commit -am "Message"')) == 'hg commit -m "Message"'

# Generated at 2022-06-22 02:19:22.933324
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='hg add .', output='abort: no repository found!\n')) == 'git add .'

# Generated at 2022-06-22 02:19:25.039258
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-22 02:19:26.138840
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git status")) == "hg status"

# Generated at 2022-06-22 02:19:27.169719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '')) == 'hg status'

# Generated at 2022-06-22 02:19:29.118569
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    command.script_parts = ['git', 'status']
    new_command = get_new_command(command)
    assert new_command == 'hg status'

# Generated at 2022-06-22 02:19:31.662926
# Unit test for function match
def test_match():
    assert match(Command('git foo', 'git foo\nfatal: Not a git repository'))
    assert not match(Command('git foo', 'git foo\nfatal: Not a git hrepository'))
    assert not match(Command('git foo', 'hg foo\nfatal: Not a git repository'))


# Generated at 2022-06-22 02:19:34.100935
# Unit test for function match
def test_match():
    tests = [
        (Command('hg diff', 'abort: no repository found'), True),
        (Command('hg diff', 'something...'), False),
        (Command('git diff', 'fatal: Not a git repository'), True),
        (Command('git diff', 'something...'), False),
    ]

    for test, result in tests:
        assert match(test) == result

# Generated at 2022-06-22 02:19:35.311241
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert get_new_command(command).startswith('hg')
    assert get_new_command(command).endswith('status')

# Generated at 2022-06-22 02:19:45.542039
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    command = Command('git status', 'Not a git repository (or any of the parent directories): .git')
    assert not match(command)
    command = Command('hg status', 'abort: no repository found in . or .!')
    assert match(command)
    command = Command('hg status', 'No repository found in . or .!')
    assert not match(command)


# Generated at 2022-06-22 02:19:47.450272
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git branch')
    assert get_new_command(command) == 'hg branch'

# Generated at 2022-06-22 02:19:49.597375
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git fetch origin')
    assert get_new_command(command) == 'hg fetch origin'

    command = Command('git fetch origin', 'hg')
    assert get_new_command(command) == 'hg fetch origin'

# Generated at 2022-06-22 02:19:56.989585
# Unit test for function match
def test_match():
    assert match(Command('git', '', output="fatal: Not a git repository")) == True
    assert match(Command('git', '', output="Not a git repository")) == False
    assert match(Command('git', '', output="abort: no repository found")) == False
    assert match(Command('hg', '', output="abort: no repository found")) == True
    assert match(Command('hg', '', output="Not a git repository")) == False


# Generated at 2022-06-22 02:20:02.992873
# Unit test for function match
def test_match():
    # Default command
    assert match(Command('git status', '', '', 'fatal: Not a git repository'))
    assert match(Command('git status', '', '', 'abort: no repository found'))

    # Command with arguments
    assert match(Command('git status -v', '', '', 'fatal: Not a git repository'))
    assert match(Command('git status -v', '', '', 'abort: no repository found'))

    # Command with options
    assert match(Command('git status -v', '', '', 'fatal: Not a git repository'))
    assert match(Command('git status -v', '', '', 'abort: no repository found'))

    # Command with sudo
    assert match(Command('sudo git status', '', '', 'fatal: Not a git repository'))

# Generated at 2022-06-22 02:20:04.785948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-22 02:20:07.880115
# Unit test for function match
def test_match():
    assert match(Command(script='git status'))
    assert not match(Command(script='hg status'))


# Generated at 2022-06-22 02:20:12.624795
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.wrong_scm import get_new_command
    command = type("Command", (object,),
                   {"script_parts": ['git', 'add', 'file']})
    assert get_new_command(command) == "hg add file"


# Generated at 2022-06-22 02:20:17.256308
# Unit test for function match
def test_match():
    assert not match(Command('python2 test.py'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))

# Generated at 2022-06-22 02:20:19.506172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'hg push'
    assert get_new_command(Command('hg push')) == 'git push'

# Generated at 2022-06-22 02:20:25.273336
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git commit -a -m "unit test"')) == 'hg commit -a -m "unit test"'

# Generated at 2022-06-22 02:20:27.810540
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git push'

# Generated at 2022-06-22 02:20:30.396593
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script_parts': ['git','status']})
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-22 02:20:33.753611
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))

# Generated at 2022-06-22 02:20:38.270979
# Unit test for function match
def test_match():
    # Unit test for git error
    command = Command('git status', "fatal: Not a git repository (or any of the parent directories): .git\n")
    assert match(command)
    # Unit test for hg error
    command = Command('hg status', "abort: no repository found (.hg not found)!\n")
    assert match(command)


# Generated at 2022-06-22 02:20:41.531760
# Unit test for function match
def test_match():
    assert match(Command(script='git init', output='fatal: Not a git repository'))
    assert match(Command(script='hg init', output='abort: no repository found'))
    assert not match(Command(script='ls', output=''))


# Generated at 2022-06-22 02:20:45.538559
# Unit test for function match
def test_match():
	assert match(Script(Script.from_shell('git status'), 'fatal: Not a git repository'))
	assert not match(Script(Script.from_shell('git status'), 'git status'))
	assert match(Script(Script.from_shell('hg status'), 'abort: no repository found'))
	assert not match(Script(Script.from_shell('hg status'), 'hg status'))
	assert not match(Script(Script.from_shell('ls'), 'ls'))


# Generated at 2022-06-22 02:20:56.480385
# Unit test for function match
def test_match():
    assert not match(Command('git status', ''))
    assert not match(Command('git status', ''))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('hg status', ''))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert match(Command('hg status', 'abort: no repository found!\n'))


# Generated at 2022-06-22 02:20:58.757405
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-22 02:21:02.166009
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository',
                         '/home/user/dir/'))
    assert not match(Command('git status', 'On branch master',
                             '/home/user/dir/'))



# Generated at 2022-06-22 02:21:12.568532
# Unit test for function match
def test_match():
    assert match(Command('git commit', 'fatal: Not a git repository'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert not match(Command('git commit', 'fatal: Not a valid object name: \'HEAD\''))
    assert not match(Command('git commit', 'fatal: This operation must be run in a work tree'))
    assert not match(Command('hg commit', 'syntax: invalid argument'))

# Generated at 2022-06-22 02:21:13.580865
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'


priority = 100

# Generated at 2022-06-22 02:21:17.405578
# Unit test for function match
def test_match():
    assert not match(Command(script='git', stderr='fatal: Not a git repository'))
    assert match(Command(script='hg', stderr='abort: no repository found!'))


# Generated at 2022-06-22 02:21:20.136062
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git'
    output = 'git status'
    command = Command(script, output)
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-22 02:21:22.537858
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'fatal: Not a git repository')) == 'hg push'

# Generated at 2022-06-22 02:21:26.371320
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('git', '', '')) and get_new_command(Command('git', '', '')) == 'hg '
    assert match(Command('git', '', '')) == False and get_new_command(Command('git', '', '')) == 'git '

# Generated at 2022-06-22 02:21:28.628048
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')

    assert get_new_command(command) == u'hg status'

# Generated at 2022-06-22 02:21:32.031711
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command(script = "git add file1 file2 file3",
                           stdout = "fatal: Not a git repository", stderr = "")
    assert get_new_command(test_command) == "hg add file1 file2 file3"

# Generated at 2022-06-22 02:21:36.241324
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git status') == u'hg status'
    assert get_new_command(u'git push') == u'hg push'
    assert get_new_command(u'git push -f') == u'hg push -f'
    assert get_new_command(u'git push -f test') == u'hg push -f test'

# Generated at 2022-06-22 02:21:39.957417
# Unit test for function match
def test_match():
    from tests.utils import Command
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command('git branch', '* master'))

# Generated at 2022-06-22 02:21:50.071157
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg status', 'abort: no repository found')) == u'git status'

    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == u'hg status'


# Generated at 2022-06-22 02:21:51.730558
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git --version") == "hg --version"

# Generated at 2022-06-22 02:21:58.167234
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository')) == True
    assert match(Command('git branch', 'abort: no repository found')) == False
    assert match(Command('hg branch', 'fatal: Not a git repository')) == False
    assert match(Command('hg branch', 'abort: no repository found')) == True



# Generated at 2022-06-22 02:21:59.727887
# Unit test for function match
def test_match():
    assert match(Command('git commit -m test'))
    assert not match(Command('git status'))


# Generated at 2022-06-22 02:22:00.561319
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git branch')
    assert get_new_command(command) == 'hg branch'

# Generated at 2022-06-22 02:22:09.486622
# Unit test for function match
def test_match():
	
	# Test if the function match works, when the wrong scm is used
	assert match(Command('git help'))
	assert match(Command('git fetch'))
	assert match(Command('hg log'))
	assert match(Command('hg fetch'))
	
	# Test if the function match works when the correct scm is used
	assert not match(Command('git clone https://github.com/davidrhoden/kthv.git'))
	assert not match(Command('hg clone https://github.com/davidrhoden/kthv'))



# Generated at 2022-06-22 02:22:16.193326
# Unit test for function match
def test_match():
    assert match(Command('git stash', 'fatal: Not a git repository',
                         '/d/e/f'))
    assert not match(Command('git stash', 'fatal: Not a hg repository',
                             '/d/e/f'))
    assert not match(Command('git stash', 'fatal: Not a git repository /d',
                             '/d/e/f'))
    assert not match(Command('git stash', 'fatal: Not a git repository',
                             '/d/e/f'))



# Generated at 2022-06-22 02:22:18.183701
# Unit test for function get_new_command
def test_get_new_command():
    _get_actual_scm = lambda: 'hg'
    assert 'git commit -m foo' == get_new_command('git commit -m foo')

# Generated at 2022-06-22 02:22:20.550847
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'



# Generated at 2022-06-22 02:22:26.097570
# Unit test for function match
def test_match():
    from thefuck.types import Command

    # command.output is wrong
    assert not match(Command(script='hg', output='abort: not a hg repository'))

    # command.output is right
    assert match(Command(script='hg', output='abort: no repository found'))

    # command.script_parts[0] = 'git'
    assert match(Command(script='git', output='fatal: not a git repository'))

    # script_parts[0] = 'hg'
    assert match(Command(script='hg', output='abort: no repository found'))



# Generated at 2022-06-22 02:22:44.700640
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.wrong_scm import get_new_command
    new_command = get_new_command(u'git push origin master')
    print (new_command)
    assert new_command == u'hg push origin master'

# Generated at 2022-06-22 02:22:48.214348
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', ''))
    assert not match(Command('ls status', ''))

# Generated at 2022-06-22 02:22:52.490126
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.wrong_scm import get_new_command
    assert get_new_command('') == 'git'
    assert get_new_command('git foo') == 'git foo'
    assert get_new_command('hg foo') == 'hg foo'


# Generated at 2022-06-22 02:22:54.835215
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git add .')) == 'hg add .'

# Generated at 2022-06-22 02:22:55.359088
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-22 02:22:58.194845
# Unit test for function get_new_command
def test_get_new_command():
    """
    Unit test for function get_new_command
    """
    from thefuck.rules.wrong_scm import get_new_command
    command = 'git clone bruce'
    assert get_new_command(command) == 'hg clone bruce'

# Generated at 2022-06-22 02:22:59.773140
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git pull')) == 'hg pull'

# Generated at 2022-06-22 02:23:03.006377
# Unit test for function match
def test_match():
    assert(match(command=Command('git status', '', '', 'fatal: Not a git repository')).output == u'git status' )


# Generated at 2022-06-22 02:23:08.240717
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

    command = Command('git status -s', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status -s'

    command = Command('hg status', 'abort: no repository found')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-22 02:23:15.611129
# Unit test for function match
def test_match():
    output_git = 'fatal: Not a git repository (or any of the parent directories): .git'
    error_git = CalledProcessError(1, 'git diff', output=output_git)
    output_hg = 'abort: no repository found!'
    error_hg = CalledProcessError(1, 'hg diff', output=output_hg)

    assert match(Command('git diff', output=output_git))
    assert not match(Command('git diff', output=output_hg))
    assert match(Command('hg diff', output=output_hg))
    assert not match(Command('hg diff', output=output_git))

    assert match(Command('git diff', error=error_git))
    assert not match(Command('git diff', error=error_hg))

# Generated at 2022-06-22 02:23:44.141223
# Unit test for function get_new_command
def test_get_new_command():
    # Test in case Git is used
    # Command is git status
    command = Command('git status')
    assert get_new_command(command) == 'hg status'
    # Command is git status
    command = Command('git reset --hard')
    assert get_new_command(command) == 'hg reset --hard'
    # Command is git stash
    command = Command('git stash')
    assert get_new_command(command) == 'hg stash'
    # Command is git checkout
    command = Command('git checkout')
    assert get_new_command(command) == 'hg checkout'
    # Command is git log
    command = Command('git log')
    assert get_new_command(command) == 'hg log'
    # Test in case Hg is used
    command = Command('hg status')
   

# Generated at 2022-06-22 02:23:46.022300
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'git hello', u'fatal: Not a git repository')
    assert get_new_command(command) == u'hg hello'

# Generated at 2022-06-22 02:23:48.107181
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-22 02:23:52.537057
# Unit test for function match
def test_match():
    assert not match('git clone https://www.github.com')
    assert match('git clone https://www.github.com').script == 'https://www.github.com'
    assert match('git clone https://www.github.com') == 'hg clone https://www.github.com'



# Generated at 2022-06-22 02:23:54.564115
# Unit test for function match
def test_match():
    assert match(Command(script='git status'))
    assert match(Command(script='hg status'))
    assert not match(Command(script='svn status'))


# Generated at 2022-06-22 02:23:59.676729
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    if _get_actual_scm() == 'git':
        assert get_new_command(Command('hg status', '', '')) == 'git status'
    else:
        assert get_new_command(Command('git status', '', '')) == 'hg status'

# Generated at 2022-06-22 02:24:01.961510
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git status", "fatal: Not a git repository")
    assert get_new_command(command) == "hg status"

# Generated at 2022-06-22 02:24:05.053467
# Unit test for function match
def test_match():
    command = Command('git status')
    assert match(command) is False
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command) is True


# Generated at 2022-06-22 02:24:08.308328
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git status') == u'hg status'
    assert get_new_command(u'git pull') == u'hg pull'
    assert get_new_command(u'hg commit') == u'git commit'

# Generated at 2022-06-22 02:24:13.179493
# Unit test for function get_new_command
def test_get_new_command():
    _get_actual_scm.cache_clear()
    os.chdir('/home/codio/.thefuck/rules')
    with open('.git', 'w') as f:
        pass

    assert get_new_command(Command('git status')) == 'git status'
    os.remove('.git')

# Generated at 2022-06-22 02:24:48.008754
# Unit test for function match
def test_match():
    command = Command('hg status', 'abort: no repository found')
    assert match(command)
    assert get_new_command(command) == 'git status'

    command = Command('hg status', 'abort: no repository found')
    assert match(command)
    assert get_new_command(command) == 'git status'

# Generated at 2022-06-22 02:24:49.379707
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git lol')) == u'git lol'

# Generated at 2022-06-22 02:24:51.364457
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git add") == "git add"
    assert get_new_command("git status") == "git status"

# Generated at 2022-06-22 02:24:59.770402
# Unit test for function get_new_command
def test_get_new_command():
    # Setup
    tiny_script_parts = ['git', 'status']
    command1 = Command(' '.join(tiny_script_parts), tiny_script_parts)
    tiny_scm_parts = ['hg', 'status']
    command2 = Command(' '.join(tiny_scm_parts), tiny_scm_parts)
    # Exercise

    # Verify
    expected1 = 'git status'
    actual1 = get_new_command(command1)
    expected2 = 'hg status'
    actual2 = get_new_command(command2)
    # Cleanup
    assert actual1 == expected1
    assert actual2 == expected2

# Generated at 2022-06-22 02:25:09.799225
# Unit test for function match
def test_match():
    assert not match(Command('scm status', ''))
    assert not match(Command('scm status'
                             'fatal: Not a git repository(or any of the parent directories): .git',
                             'fatal: Not a git repository(or any of the parent directories): .git'))
    assert not match(Command('scm status'
                             'fatal: Not a git repository(or any of the parent directories): .git',
                             'fatal: Not a git repository(or any of the parent directories): .git'))
    assert match(Command('scm status', 'fatal: Not a git repository'))
    assert match(Command('scm status', 'abort: no repository found'))


# Generated at 2022-06-22 02:25:14.744256
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git asdf')) == 'hg asdf'
    assert get_new_command(Command('git asdf', 'fatal: Not a git repository\n')) == 'hg asdf'
    assert get_new_command(Command('hg asdf', 'abort: no repository found\n')) == 'git asdf'

# Generated at 2022-06-22 02:25:22.736918
# Unit test for function match
def test_match():
    assert match(Command(script='git status'))
    assert match(Command(script='git branch'))
    assert match(Command(script='git pull'))
    assert match(Command(script='git add'))
    assert match(Command(script='git log'))
    assert match(Command(script='git commit'))
    assert match(Command(script='git checkout'))
    assert match(Command(script='git status'))
    assert match(Command(script='git push'))

    assert not match(Command(script='hg status'))
    assert not match(Command(script='hg branch'))
    assert not match(Command(script='hg pull'))
    assert not match(Command(script='hg add'))
    assert not match(Command(script='hg log'))

# Generated at 2022-06-22 02:25:24.567433
# Unit test for function match
def test_match():

    # Return true, if output contains a certain pattern
    assert match(Command('git commit', '')) == True

    # Return false, if output does not contain a certain pattern
    assert match(Command('hg commit', '')) == False

# Generated at 2022-06-22 02:25:28.629794
# Unit test for function match
def test_match():
    assert match('git commit -a -m') == True

# Generated at 2022-06-22 02:25:33.150199
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'git status', path='~/')) == 'hg status'