

# Generated at 2022-06-22 02:16:30.592729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status')) == 'hg status'
    assert get_new_command(Command(script='hg status')) == 'git status'
    assert get_new_command(Command(script='hg status -v')) == 'git status -v'

# Generated at 2022-06-22 02:16:35.085268
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git diff') == 'hg diff'
    assert get_new_command('brave-git-status') == 'brave-hg-status'

# Generated at 2022-06-22 02:16:36.400318
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-22 02:16:41.465611
# Unit test for function match
def test_match():
    assert match(Command('git status', '')) == False
    assert match(Command('git status', 'fatal: Not a git repository')) == True
    assert match(Command('hg log', 'abort: no repository found')) == True
    assert match(Command('hg log', '')) == False

# Generated at 2022-06-22 02:16:43.223288
# Unit test for function match
def test_match():
    assert match(Command('git status'))
    assert match(Command('hg status'))
    assert not match(Command('npm status'))


# Generated at 2022-06-22 02:16:48.397000
# Unit test for function match
def test_match():
    

    command1 = "git add -f"
    command2 = "hg add -f"
    command3 = "hg add -f"
    command4 = "git add -f"


    assert not match(command1)
    assert match(command2)
    assert not match(command3)
    assert match(command4)

# Generated at 2022-06-22 02:16:51.896270
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg status') == 'git status'
    assert get_new_command('git clone git@github.com:nvbn/thefuck.git') == 'hg clone git@github.com:nvbn/thefuck.git'

# Generated at 2022-06-22 02:16:54.398612
# Unit test for function match
def test_match():
    script = "git"
    output = "fatal: Not a git repository"
    command = Command(script, output)

    assert match(command)



# Generated at 2022-06-22 02:16:55.866414
# Unit test for function match
def test_match():
    assert match(Command('git FUCK'))


# Generated at 2022-06-22 02:16:58.290483
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git add -A') == 'hg add -A'

# Generated at 2022-06-22 02:17:01.531421
# Unit test for function match
def test_match():

    from thefuck.types import Command

    assert match(Command('git init', ''))



# Generated at 2022-06-22 02:17:02.438637
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('fuck')) == u'git fuck'

# Generated at 2022-06-22 02:17:06.890282
# Unit test for function match
def test_match():
	assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
	assert not match(Command('git status', 'On branch master\n'))
	assert match(Command('hg stat', 'abort: no repository found!'))
	assert not match(Command('hg stat', 'abort: no repository found!'))

# Generated at 2022-06-22 02:17:08.000560
# Unit test for function match
def test_match():
    assert match(Command('git status'))


# Generated at 2022-06-22 02:17:11.361953
# Unit test for function match
def test_match():
    assert match(Command('git branch -r', '',
        'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('git branch -r', '',
        '  origin/master\n'))
    assert match(Command('hg branch', '',
        'abort: no repository found in /home/mana/code/config (.hg not found)!\n'))
    assert not match(Command('hg branch', '', 'default'))

# Generated at 2022-06-22 02:17:12.860908
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(command) == "git commit -m"


priority = 1000

# Generated at 2022-06-22 02:17:17.988934
# Unit test for function match
def test_match():
    command = Command('git branch')
    command.output = 'fatal: Not a git repository'
    assert match(command)

    command.output = 'fatal: Not a hg repository'
    assert not match(command)

    command.script_parts[0] = 'hg'
    command.output = 'abort: no repository found'
    assert match(command)


# Generated at 2022-06-22 02:17:20.743316
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status','abort: no repository found'))


# Generated at 2022-06-22 02:17:24.822207
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(
        'git add .',
        'fatal: Not a git repository'
        ' (or any of the parent directories): .git\n')

    assert get_new_command(command) == 'hg add .'

# Generated at 2022-06-22 02:17:27.811039
# Unit test for function match
def test_match():
    output = 'fatal: Not a git repository'
    actual_scm = 'hg'
    script = 'git status'
    script_parts = script.split()
    command = Command(script, script_parts, output)

    assert match(command)

# Generated at 2022-06-22 02:17:33.619591
# Unit test for function match
def test_match():
    assert match(Command('git add .', wrong_scm_patterns['git']))
    assert not match(Command('hg add .', wrong_scm_patterns['hg']))
    assert not match(Command('test add .', wrong_scm_patterns['git']))

# Generated at 2022-06-22 02:17:35.785407
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git', ''))==True


# Generated at 2022-06-22 02:17:37.792614
# Unit test for function match
def test_match():
    def check(script, expected):
        assert match(Command(script, '')) == expected

    check('git commit', False)
    check('git commit', True)

    check('hg commit', False)
    check('hg commit', True)

# Generated at 2022-06-22 02:17:39.547530
# Unit test for function match
def test_match():
    assert not match(Command('hg status', ''))
    assert match(Command('git status', 'fatal: Not a git repository'))


# Generated at 2022-06-22 02:17:49.908429
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git', '', '')) == 'hg'
    assert get_new_command(Command('git commit', '', '')) == 'hg commit'
    assert get_new_command(Command('git commit -a', '', '')) == 'hg commit -a'
    assert get_new_command(Command('git commit -a -m', '', '')) == 'hg commit -a -m'
    assert get_new_command(Command('git commit --amend', '', '')) == 'hg commit --amend'
    assert get_new_command(Command('git commit --amend --all', '', '')) == 'hg commit --amend --all'

# Generated at 2022-06-22 02:17:52.435368
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git pull') == 'hg pull'

# Generated at 2022-06-22 02:17:56.953305
# Unit test for function match
def test_match():
    from thefuck.rules.wrong_scm_used import match
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))



# Generated at 2022-06-22 02:18:00.002579
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git config --list', '')) == 'hg config --list'
    assert get_new_command(Command('hg config --list', '')) == 'git config --list'


# Generated at 2022-06-22 02:18:02.190873
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'hg dummy_command') == u'git dummy_command'

# Generated at 2022-06-22 02:18:11.264407
# Unit test for function match
def test_match():
    assert not match(Command('git', error='Not a git repository'))
    assert not match(Command('git', error='fatal: Not a git repository'))
    assert match(Command('git', error='fatal: Not a git repository (or any of the parent directories): '))
    assert not match(Command('hg', error='fatal: Not a git repository (or any of the parent directories): '))
    assert not match(Command('hg', error='no repository found'))
    assert match(Command('hg', error='abort: no repository found'))


# Generated at 2022-06-22 02:18:17.074116
# Unit test for function match
def test_match():
    scm = _get_actual_scm()

    output = '''fatal: Not a git repository (or any of the parent directories): .git
    '''

    assert match(Command(scm + ' push origin master', output))


# Generated at 2022-06-22 02:18:19.196645
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git status')) == 'hg status')


# Generated at 2022-06-22 02:18:20.564057
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'

# Generated at 2022-06-22 02:18:25.379401
# Unit test for function match
def test_match():
    command_not_in_scm = Command('git status', wrong_scm_patterns['git'])
    command_in_scm = Command('git status', 'On branch master')
    assert not match(command_not_in_scm)
    assert match(command_in_scm)



# Generated at 2022-06-22 02:18:27.842605
# Unit test for function match
def test_match():
    script = "git status"
    output = 'fatal: Not a git repository'
    assert match(Command(script, output))


# Generated at 2022-06-22 02:18:31.734906
# Unit test for function match
def test_match():
    assert not match(Command('git'))
    assert match(Command('git', 'status', error='''fatal: Not a git repository'''))
    assert not match(Command('hg'))
    assert match(Command('hg', 'status', error='''abort: no repository found'''))


# Generated at 2022-06-22 02:18:34.244724
# Unit test for function match
def test_match():
    assert match(Command('git'))
    assert not match(Command('git foo'))
    assert not match(Command('hg'))
    assert match(Command('hg foo'))
    assert not match(Command('svn'))


# Generated at 2022-06-22 02:18:37.480529
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command('git branch', ''))
    assert not match(Command('hg branch', ''))

# Generated at 2022-06-22 02:18:48.518177
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git branch', 'fatal: Not a git repository')) == 'hg branch'
    assert get_new_command(Command('git remote', 'fatal: Not a git repository')) == 'hg remote'
    assert get_new_command(Command('git status', 'fatal: Not a git repository')) == 'hg status'
    assert get_new_command(Command('hg branch', 'abort: no repository found')) == 'git branch'
    assert get_new_command(Command('hg remote', 'abort: no repository found')) == 'git remote'
    assert get_new_command(Command('hg status', 'abort: no repository found')) == 'git status'

# Generated at 2022-06-22 02:18:52.933571
# Unit test for function match
def test_match():
    assert match(Command('git status', 'git: fatal: Not a git repository(or any of the parent directories): .git'))
    assert match(Command('hg status', '.... abort: no repository found!'))
    assert not match(Command('git status', 'nothing wrong'))

# Generated at 2022-06-22 02:19:00.079405
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git status') == 'hg status'

# Generated at 2022-06-22 02:19:02.310600
# Unit test for function match
def test_match():
    command = Command('git push origin master', 'fatal: Not a git repository')
    assert match(command)



# Generated at 2022-06-22 02:19:03.696916
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git foo') == u'hg foo'

# Generated at 2022-06-22 02:19:11.764247
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match('git', command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match('git', command)

    command = Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n' +
                                    'fatal: Not a git repository (or any of the parent directories): .git\n' +
                                    'fatal: Not a git repository (or any of the parent directories): .git')
    assert match('git', command)


# Generated at 2022-06-22 02:19:20.166590
# Unit test for function match
def test_match():
    assert(match(Command(script = 'git status', output = 'fatal: Not a git repository'))) == True
    assert(match(Command(script = 'git status', output = 'abort: no repository found'))) == False
    assert(match(Command(script = 'hg status', output = 'fatal: Not a git repository'))) == False
    assert(match(Command(script = 'hg status', output = 'abort: no repository found'))) == True
    assert(match(Command(script = 'hg status', output = 'abort: no repository found'))) == True
    assert(match(Command(script = 'hg status', output = 'hg is not recognized as an internal or external command'))) == False


# Generated at 2022-06-22 02:19:21.661759
# Unit test for function match
def test_match():
    command = Command('git diff', 'fatal: Not a git repository')

    assert match(command)


# Generated at 2022-06-22 02:19:24.702379
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git pull') == 'hg pull'
    assert get_new_command('git status') == 'hg status'


# Generated at 2022-06-22 02:19:27.794146
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git'
    assert get_new_command(command) == u'hg'

    command = 'git add .'
    assert get_new_command(command) == u'hg add .'

    command = 'git commit'
    assert get_new_command(command) == u'hg commit'

# Generated at 2022-06-22 02:19:30.853091
# Unit test for function match
def test_match():
    command = Command('git branch')
    assert match(command)
    command = Command('hg branch')
    assert not match(command)


# Generated at 2022-06-22 02:19:36.652389
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script=u'git init')) == u'hg init'
    assert get_new_command(Command(script=u'git add')) == u'hg add'
    assert get_new_command(Command(script=u'hg init')) == u'git init'
    assert get_new_command(Command(script=u'hg add')) == u'git add'

# Generated at 2022-06-22 02:19:50.079503
# Unit test for function get_new_command

# Generated at 2022-06-22 02:19:52.588066
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg clone test', '', '', 'hg abort: no repository found\n')
    assert get_new_command(command) == 'git clone test'

# Generated at 2022-06-22 02:19:55.729307
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git commit', ''))
    assert new_command == 'hg commit'

# Generated at 2022-06-22 02:19:56.670684
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg log')
    assert get_new_command(command) == 'git log'

# Generated at 2022-06-22 02:19:58.841427
# Unit test for function match
def test_match():
    result_match = match('git status')
    assert result_match == True
    result_not_match = match('git status')
    assert result_not_match == True


# Generated at 2022-06-22 02:20:00.427186
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git checkout master') == 'hg checkout master'

# Generated at 2022-06-22 02:20:05.521950
# Unit test for function match
def test_match():
    command = Command("git branch",
                      "fatal: Not a git repository (or any of the parent directories): .git")
    assert match(command)
    command = Command("git branch",
                      "fatal: Not a git repository")
    assert match(command) == False

# Generated at 2022-06-22 02:20:11.782544
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git test') == u'hg test'
    assert get_new_command(u'git a  b') == u'hg a  b'
    assert get_new_command(u'git "a  b"') == u'hg "a  b"'
    assert get_new_command(u'git \'a  b\'') == u'hg \'a  b\''
    assert get_new_command(u'git "a  b') == u'hg "a  b'
    assert get_new_command(u'git \'a  b') == u'hg \'a  b'



# Generated at 2022-06-22 02:20:14.929287
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m bla') == 'hg commit -m bla'

# Generated at 2022-06-22 02:20:18.648752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git', '', '')) == u'git'
    assert get_new_command(Command('git', 'push', '')) == u'git push'
    assert get_new_command(Command('git', 'push', '', 'git push origin master')) == u'git push origin master'

# Generated at 2022-06-22 02:20:39.544444
# Unit test for function match
def test_match():
    assert not match(Command('git', '', ''))
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert match(Command('git', '', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git', '', 'fatal: Not a git repository: \'/Users/cheng/Programming/private-dotfiles/.git\''))
    assert match(Command('hg', '', ''))
    assert match(Command('hg', '', 'abort: no repository found'))
    assert match(Command('hg', '', 'abort: no repository found in /Users/cheng/Programming/private-dotfiles'))
    assert not match(Command('svn', '', ''))


# Generated at 2022-06-22 02:20:41.149776
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git commit' == get_new_command(Command('hg commit', '', '', ''))

# Generated at 2022-06-22 02:20:44.202816
# Unit test for function match
def test_match():
    command = Command("git branch", "fatal: Not a git repository")
    assert match(command)

    command = Command("git branch", "Not a git repository")
    assert not match(command)

    command = Command("hg branch", "abort: no repository found")
    assert match(command)


# Generated at 2022-06-22 02:20:54.370173
# Unit test for function match
def test_match():
    assert not match(Command('git commit -a -m my commit', ''))
    assert match(Command('git commit -a -m my commit',
                         'fatal: Not a git repository'))
    assert not match(Command('git commit -a -m my commit',
                             'fatal: Not a git repository'))
    assert not match(Command('hg commit -a -m my commit', ''))
    assert match(Command('hg commit -a -m my commit',
                         'abort: no repository found'))
    assert not match(Command('hg commit -a -m my commit',
                             'abort: no repository found'))

# Generated at 2022-06-22 02:20:56.347479
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git commit -a", "")) == "hg commit -a"

# Generated at 2022-06-22 02:20:58.981799
# Unit test for function match
def test_match():
    from thefuck.types import Command
    matched = match(Command('git adda', ''))
    assert not matched
    matched = match(Command('git adda', 'fatal: Not a git repository'))
    assert matched

# Generated at 2022-06-22 02:21:02.050796
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'git push origin master', u'fatal: Not a git repository (or any of the parent directories): .git', u'git push origin master')
    assert get_new_command(command) == 'hg push origin master'

# Generated at 2022-06-22 02:21:11.082850
# Unit test for function get_new_command
def test_get_new_command():
	from thefuck.rules.wrong_scm import get_new_command
	assert get_new_command('git commit -am "fix"') == 'git commit -am "fix"'
	assert get_new_command('git status') == 'git status'
	assert get_new_command('git add --all') == 'git add --all'
	assert get_new_command('git add --all ; git commit -am "add" ') == 'git add --all ; git commit -am "add" '
	assert get_new_command('git commit -am "fix"') == 'git commit -am "fix"'

# Generated at 2022-06-22 02:21:16.463221
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command, CommandOutput
    command = Command('hg status', 'abort: no repository found')
    assert get_new_command(command)== 'git status'
    wrong_command = Command('git status', 'unable')
    assert get_new_command(wrong_command) == 'git status'


# Generated at 2022-06-22 02:21:20.719554
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', output=''))
    assert not match(Command('hg status', output=''))
    assert not match(Command('test status', output=''))



# Generated at 2022-06-22 02:21:46.850556
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash # pylint: disable=import-error
    command = Bash('git add .')
    assert get_new_command(command) == 'hg add .'

# Generated at 2022-06-22 02:21:50.913887
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found:'))
    assert not match(Command('hg status', 'On branch master'))


# Generated at 2022-06-22 02:21:55.658138
# Unit test for function match
def test_match():
    assert match(u'git status') is False
    assert match(u'hg status') is False 
    assert match(u'git status', u'fatal: Not a git repository') is True
    assert match(u'hg status', u'abort: no repository found') is True
    

# Generated at 2022-06-22 02:22:01.679185
# Unit test for function get_new_command
def test_get_new_command():
    def test_get_new_command(command, expected):
        assert expected == get_new_command(command)

    from tests.utils import Command

    test_get_new_command(Command('git commit', '', 'fatal: Not a git repository'), 'hg commit')
    test_get_new_command(Command('git status', '', 'fatal: Not a git repository'), 'hg status')

# Generated at 2022-06-22 02:22:03.732840
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff', '')) == 'hg diff'

# Generated at 2022-06-22 02:22:04.917122
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git init')) == 'hg init'

# Generated at 2022-06-22 02:22:07.892905
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git status', 'git status'))
    assert u'hg status' == new_command

# Generated at 2022-06-22 02:22:17.707887
# Unit test for function match
def test_match():
    assert not match(Command('git', '', ''))
    assert not match(Command('git', '', '', '', ''))
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert match(Command('git', '', 'fatal: Not a git repository', '', ''))
    assert not match(Command('git', '', 'fatal: Not a git repository', '', '', '', ''))
    assert not match(Command('git', '', 'fatal: Not a git repository', '', '', '', '', '', ''))
    assert match(Command('hg', '', 'abort: no repository found'))
    assert not match(Command('hg', '', 'abort: no repositoriy foundy'))

# Generated at 2022-06-22 02:22:21.915930
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -a -m "some msg"')
    assert get_new_command(command) == u'hg commit -a -m "some msg"'

    command = Command('git status')
    assert get_new_command(command) == u'hg status'

# Generated at 2022-06-22 02:22:24.486904
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'hg push'
    assert get_new_command(Command('git commit')) == 'hg commit'

# Generated at 2022-06-22 02:22:53.748328
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git help', 'fatal: Not a git repository')) == u'hg help'
    assert get_new_command(Command('git help', 'fatal: Not a git repository', path='/foo/git/test')) == u'git help'

# Generated at 2022-06-22 02:22:55.634204
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg push', 'abort: no repository found')
    assert get_new_command(command) == 'git push'

# Generated at 2022-06-22 02:22:58.331980
# Unit test for function get_new_command
def test_get_new_command():
    command = AttrDict({
        'script': u'git commit -m',
        'script_parts': ['git', 'commit', '-m'],
        })
    assert u'hg commit -m' == get_new_command(command)


# Generated at 2022-06-22 02:23:00.218700
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', '', None)) == 'hg status'

# Generated at 2022-06-22 02:23:05.711075
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status', stderr='fatal: Not a git repository')) == 'hg status'
    assert get_new_command(Command(script='git status', stderr='fatal: Not a git repository', stdout='stuff')) == 'hg status'


# Generated at 2022-06-22 02:23:07.094731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git', 'origin')) == 'hg origin'

# Generated at 2022-06-22 02:23:14.777836
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git foo') == 'git foo'
    assert get_new_command('git remote') == 'git remote'
    assert get_new_command('git remote add') == 'git remote add'
    assert get_new_command('git remote add origin') == 'git remote add origin'
    assert get_new_command('git remote add origin github') == 'git remote add origin github'
    assert get_new_command('git remote add origin github.com:toy/vimrc.git') == 'git remote add origin github.com:toy/vimrc.git'
    assert get_new_command('gith foo') == 'hg foo'
    assert get_new_command('gith remote') == 'hg remote'
    assert get_new_command('gith remote add') == 'hg remote add'


# Generated at 2022-06-22 02:23:17.935179
# Unit test for function match
def test_match():
    assert match(Command('git st', 'fatal: Not a git repository'))
    assert not match(Command('git st', 'git-svn: command not found'))
    assert match(Command('hg st', '''abort: no repository found
(looks like a hg repository)'''))
    assert not match(Command('hg st', '''abort: no suitable response from remote hg'''))


# Generated at 2022-06-22 02:23:24.971282
# Unit test for function match
def test_match():
    command = Command('git push origin master')

    # When git is not installed and hg is, expect True
    with patch('thefuck.rules.git.has_program') as has_program:
        has_program.return_value = False
        assert match(command)

    # When git is installed and hg not, expect False
    with patch('thefuck.rules.git.has_program') as has_program:
        has_program.return_value = True
        assert not match(command)


# Generated at 2022-06-22 02:23:26.143118
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg commit')) == 'git commit'

# Generated at 2022-06-22 02:24:07.307821
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "hello world"',
                         'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg commit -m "hello world"',
                         'abort: no repository found!\n'))
    assert not match(Command('git commit -m "hello world"', '12'))
    assert not match(Command('hg commit -m "hello world"', '12'))
    assert not match(Command('git commit -m "hello world"', '12',
                             'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg commit -m "hello world"', '12',
                         'abort: no repository found!\n'))



# Generated at 2022-06-22 02:24:18.736920
# Unit test for function match
def test_match():
    # Git
    assert match(Command('git commit', '', 'fatal: Not a git repository'))
    assert match(Command('git push', '', 'fatal: Not a git repository'))
    assert match(Command('git status', '', 'fatal: Not a git repository'))
    assert not match(Command('git diff', '', 'fatal: Not a git repository'))
    assert not match(Command('git reset', '', 'fatal: Not a git repository'))

    # Hg
    assert match(Command('hg commit', '', 'abort: no repository found'))
    assert match(Command('hg push', '', 'abort: no repository found'))
    assert match(Command('hg status', '', 'abort: no repository found'))

# Generated at 2022-06-22 02:24:21.081326
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    assert _get_actual_scm() == 'hg'
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-22 02:24:27.203350
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit --amend')) == 'hg commit --amend'
    assert get_new_command(Command('git push -f origin')) == 'hg push -f origin'
    assert get_new_command(Command('hg push -f origin')) == 'hg push -f origin'

# Generated at 2022-06-22 02:24:31.281780
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command(Command('hg status'))
    assert 'git commit -m "test" "file1" "file2"' == get_new_command(Command('hg commit -m "test" "file1" "file2"'))


# Generated at 2022-06-22 02:24:35.897764
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert match(Command('git status', 'fatal: Not a hg repository'))
    assert match(Command('hg status', 'abort: no git repository'))



# Generated at 2022-06-22 02:24:39.585207
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))

# Generated at 2022-06-22 02:24:43.973409
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

    command = Command('hg status', 'fatal: Not a hg repository')
    assert get_new_command(command) == 'git status'

# Generated at 2022-06-22 02:24:46.683281
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'
    assert get_new_command(Command('git fetch')) == 'hg fetch'

# Generated at 2022-06-22 02:24:51.190917
# Unit test for function match
def test_match():
    assert match(
        Command('git status', 'fatal: Not a git repository')) is True
    assert match(
        Command('git status', '')) is False
    assert match(
        Command('hg status', 'abort: no repositor found')) is True
    assert match(
        Command('hg status', '')) is False


# Generated at 2022-06-22 02:26:08.004152
# Unit test for function match
def test_match():
    from thefuck.rules.git_hg_confusion import match

    # Test is_git = True
    command = {
        'script_parts': ['git', 'status'],
        'output': 'fatal: Not a git repository'
    }
    with patch('thefuck.rules.git_hg_confusion.Path', Path):
        assert match(command)

    # Test is_git = True, is_hg = True
    command = {
        'script_parts': ['git', 'status'],
        'output': 'abort: no repository found'
    }
    with patch('thefuck.rules.git_hg_confusion.Path', Path):
        assert match(command)

    # Test is not a wrong command

# Generated at 2022-06-22 02:26:11.642613
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: not a git repository'))
    assert not match(Command('git status', ''))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-22 02:26:19.524852
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git fake_command', '')) == 'hg fake_command'
    assert get_new_command(Command('git fake_command fake_arg', '')) == 'hg fake_command fake_arg'
    assert get_new_command(Command('git fake command', '')) == 'hg fake command'
    assert get_new_command(Command('git fake command fake_arg', '')) == 'hg fake command fake_arg'

# Generated at 2022-06-22 02:26:26.003321
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository'))
    assert match(Command('git add .',
                         'fatal: Not a git repository'))
    assert not match(Command('git add .',
                             'fatal: Not a git repository',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('hg status',
                             'abort: no repository found'))



# Generated at 2022-06-22 02:26:27.739787
# Unit test for function match
def test_match():
    from thefuck.rules.wrong_scm import match
    from thefuck.types import Command

    assert match(Command('foo', 'bar'), None)

