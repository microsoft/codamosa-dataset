

# Generated at 2022-06-22 02:16:29.769675
# Unit test for function match
def test_match():
    assert not match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('git branch', 'fatal: Not a git repository (or any of the parent directories): .git\n'))


# Generated at 2022-06-22 02:16:40.270946
# Unit test for function match
def test_match():
    assert match(Command(script='git status', output='error')) is None
    assert match(Command(script='hg pull', output='abort: no repository found'))
    assert match(Command(script='hg pull', output='error')) is None


# Generated at 2022-06-22 02:16:43.088866
# Unit test for function match
def test_match():
    assert match(Command('git pull', 'fatal: Not a git repository'))
    assert not match(Command('git status', ''))



# Generated at 2022-06-22 02:16:49.226333
# Unit test for function match
def test_match():
    assert match(Command(script='git status',
                         stderr='fatal: Not a git repository'))

    assert match(Command(script='git status',
                         stderr='abort: no repository found'))

    assert match(Command(script='git status',
                         stderr='Not a git repository'))

    assert match(Command(script='git status',
                         stderr='abort: no repository'))



# Generated at 2022-06-22 02:16:52.644922
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    input_command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(input_command) == 'hg status'

# Generated at 2022-06-22 02:16:55.296843
# Unit test for function get_new_command
def test_get_new_command():
    scm = _get_actual_scm()
    command = Command('git status', '')
    assert get_new_command(command) == scm + u' status'

# Generated at 2022-06-22 02:17:01.487399
# Unit test for function match
def test_match():
    match1 = match(Command('git status',
                           "fatal: Not a git repository",
                           "", 1))
    # Test if the actual scm is hg
    assert match1

    match2 = match(Command('git status',
                           "fatal: Not a git repository",
                           "", 1))
    # Test if the actual scm is git
    assert not match2

    match3 = match(Command('hg status',
                           "abort: no repository found",
                           "", 1))
    # Test if the actual scm is git
    assert not match3

    match4 = match(Command('hg status',
                           "abort: no repository found",
                           "", 1))
    # Test if the actual scm is hg
    assert match4



# Generated at 2022-06-22 02:17:04.202159
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command = _get_actual_scm.__wrapped__()
    assert_equal(get_new_command(Command(script='git commit', stdout=u'fatal: Not a git repository')), u'hg commit')

# Generated at 2022-06-22 02:17:10.601200
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg status', 'abort: no repository found in /home/james/Desktop/thefuck!\n'))
    assert not match(Command('git status', ''))
    assert not match(Command('hg status', ''))


# Generated at 2022-06-22 02:17:13.532041
# Unit test for function match
def test_match():
    #from thefuck.rules import match
    #command = Command("git push --set-upstream origin master")
    #print("TEST:", match(command))
    pass


# Generated at 2022-06-22 02:17:17.292510
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg commit', 'abort: no repository found!')
    assert get_new_command(command) == 'git commit'

# Generated at 2022-06-22 02:17:25.285005
# Unit test for function match
def test_match():
    output = 'error: pathspec \'status\' did not match any file(s) known to git' #pass
    assert match(Command(script='git status', output=output))
    output = 'not a repo' #pass
    assert not match(Command(script='git status', output=output))
    output = 'not a repo' #pass
    assert not match(Command(script='hg status', output=output))
    output = 'abort: no repository found' #pass
    assert match(Command(script='hg status', output=output))


# Generated at 2022-06-22 02:17:27.937408
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git abc', '/')) == 'hg abc'

# Generated at 2022-06-22 02:17:30.199986
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', 'fatal: Not a git repository')) == 'hg commit'

# Generated at 2022-06-22 02:17:35.742592
# Unit test for function match
def test_match():
    # Match true
    assert match(Command('git status', 'fatal: Not a git repository'))
    # Match false
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'On branch master'))



# Generated at 2022-06-22 02:17:37.299108
# Unit test for function match
def test_match():
    command = Command('git branch', wrong_scm_patterns['git'])
    assert match(command)

# Generated at 2022-06-22 02:17:38.473514
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command('hg status')


# Generated at 2022-06-22 02:17:40.484523
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git pull') == 'hg pull'

# Generated at 2022-06-22 02:17:49.996833
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git commit -m "initial commit"') == 'hg commit -m "initial commit"'
    assert get_new_command('git push') == 'hg push'
    assert get_new_command('git checkout master') == 'hg checkout master'
    assert get_new_command('git log') == 'hg log'
    assert get_new_command('git add -A') == 'hg add -A'
    assert get_new_command('git status') == 'hg status'
    assert get_new_command('git branch') == 'hg branch'

# Generated at 2022-06-22 02:17:52.436078
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git', 'adb')) == 'adb'

# Generated at 2022-06-22 02:17:59.076087
# Unit test for function match
def test_match():
    assert match(Command('git status',
                'fatal: Not a git repository'))
    assert match(Command('hg status',
                'abort: no repository found'))


# Generated at 2022-06-22 02:18:00.634938
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status')) == 'hg status'

# Generated at 2022-06-22 02:18:03.074367
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-22 02:18:11.688648
# Unit test for function match
def test_match():
    correct = [['git', 'branch'], ['git', 'branch', 'master'], ['hg', 'branch'], ['hg', 'branch', 'master']]
    wrong = [['git', 'add'], ['git', 'add', '*'], ['hg', 'add'], ['hg', 'add', '*']]

    for command in correct:
        assert match(Command(command, '', '')) is False

    for command in wrong:
        assert match(Command(command, '', '')) is True


# Generated at 2022-06-22 02:18:14.005415
# Unit test for function match
def test_match():
    assert match(Command('git -a', 'fatal: Not a git repository'))

    assert match(Command('hg -a', 'abort: no repository found'))


# Generated at 2022-06-22 02:18:16.638462
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git commit -m',
                          'fatal: Not a git repository',
                          '')) == 'hg commit -m'

# Generated at 2022-06-22 02:18:19.862179
# Unit test for function match
def test_match():
    command = Command('git pull', '')
    assert match(command)
    command = Command('wrong_scm pull', '')
    assert match(command) is None

# Generated at 2022-06-22 02:18:22.269306
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff -u1', '', '')) == 'hg diff -u1'

# Generated at 2022-06-22 02:18:24.907446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg commit') == 'git commit'
    assert get_new_command('git commit') == 'git commit'

# Generated at 2022-06-22 02:18:27.758726
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-22 02:18:36.370577
# Unit test for function match
def test_match():
    from thefuck.rules.correction import match
    from thefuck.types import Command

    assert match(Command('git status', '', "fatal: Not a git repository"))
    assert not match(Command('git status', '', ""))
    assert not match(Command('hg status', '', ''))



# Generated at 2022-06-22 02:18:38.914119
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(['git','add','my_file'])
    assert get_new_command(command) == 'hg add my_file'

# Generated at 2022-06-22 02:18:43.827189
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg status', 'abort: no changes found'))


# Generated at 2022-06-22 02:18:51.469424
# Unit test for function match
def test_match():
    assert match(Command('git ci -m "test"', 'error: pathspec \\"test\\" did not match any file(s) known to git.\n'))
    assert match(Command('hg init', 'abort: no repository found'))
    assert not match(Command('ls', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg init', 'fatal: Not a hg repository'))

# Generated at 2022-06-22 02:19:01.814512
# Unit test for function get_new_command

# Generated at 2022-06-22 02:19:04.823152
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('hg status', '')
    assert get_new_command(command) == 'git status'
    command = Command('git status', '')
    assert get_new_command(command) == 'git status'

# Generated at 2022-06-22 02:19:08.910301
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no reopsitory found'))
    assert not match(Command('git branch', 'foo'))


# Generated at 2022-06-22 02:19:11.922628
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("hg commit -a", "C:\\Users\\UserName\\Documents\\GitHub\\repo\\my-repo")
    assert "git commit -a" == get_new_command(command)

# Generated at 2022-06-22 02:19:13.560580
# Unit test for function match
def test_match():
    result = match(Command('git', 'fatal: Not a git repository'))
    assert result


# Generated at 2022-06-22 02:19:17.487539
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git commit', stderr='fatal: Not a git repository')) == 'hg commit'
    assert get_new_command(Command(script='hg commit', stderr='abort: no repository found')) == 'git commit'

# Generated at 2022-06-22 02:19:31.709683
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == u'hg status'

# Generated at 2022-06-22 02:19:35.215502
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', 'fatal: Not a git repository')
    assert get_new_command(command) == u'hg status'
    # TODO: Add tests for functions get_new_command and match

# Generated at 2022-06-22 02:19:37.421527
# Unit test for function match
def test_match():
    assert match(Command('git', 'git status', 'fatal: Not a git repository'))
    assert not match(Command('git', 'git status', 'On branch'))


# Generated at 2022-06-22 02:19:39.493174
# Unit test for function get_new_command
def test_get_new_command():
    test_1 = Command('git pull', 'fatal: Not a git repository')
    new_1 = get_new_command(test_1)
    assert new_1 == 'hg pull'


# Generated at 2022-06-22 02:19:47.370562
# Unit test for function get_new_command
def test_get_new_command():
    # There is already a repo initialized and we try to run git commands
    command = Command('git status')
    assert get_new_command(command) == 'hg status'

    # There is already a repo initialized and we try to run hg commands
    command = Command('hg pull')
    assert get_new_command(command) == 'git pull'

    # There is no repo initialize and we try to run git commands
    command = Command('git status')
    assert get_new_command(command) == 'git status'

# Generated at 2022-06-22 02:19:49.514569
# Unit test for function match
def test_match():
    command = Command('hg stash', 'abort: no repository found')
    assert match(command)

    command = Command('hg stash', 'hg: command not found')
    assert not match(command)


# Generated at 2022-06-22 02:19:52.076554
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git help')) == 'git help'
    assert get_new_command(Command('hg help')) == 'hg help'


# Generated at 2022-06-22 02:19:56.059097
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', '', 'Not a git repository')
    assert get_new_command(command) == u'hg status'


enabled_by_default = True

# Generated at 2022-06-22 02:19:58.919448
# Unit test for function match
def test_match():
    test_match_1 = Command('git add')
    assert not match(test_match_1)
    test_match_2 = Command('hg branch', 'abort: no repository found')
    assert match(test_match_2)


# Generated at 2022-06-22 02:20:00.022422
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .', '')) == 'hg add'

# Generated at 2022-06-22 02:20:30.133217
# Unit test for function get_new_command
def test_get_new_command():
    # First, test that the function returns the correct command
    # if current working directory is a git repo
    with open(".git", "w") as git_dir:
        git_dir.close()
    assert get_new_command("git status") == "git status"
    os.remove(".git")
    # Second, test that the function returns the correct command
    # if current working directory is a hg repo
    with open(".hg", "w") as hg_dir:
        hg_dir.close()
    assert get_new_command("git status") == "hg git status"
    os.remove(".hg")
    # Finally, test that the function still returns the correct command
    # if the current working directory is not a git or hg repository

# Generated at 2022-06-22 02:20:35.622828
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git commit -m "test"') == u'hg commit -m "test"'
    assert get_new_command(u'git commit') == u'hg commit'
    assert get_new_command(u'git remote add origin git@git.git') == u'hg remote add origin git@git.git'
    assert get_new_command(u'git push') == u'hg push'

# Generated at 2022-06-22 02:20:39.378595
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git branch', 'fatal: Not a git repository (or any of the parent directories): .git\n')) == 'hg branch'
    assert get_new_command(
        Command('git branch', 'fatal: Not a git repository')) == 'git branch'

# Generated at 2022-06-22 02:20:40.940752
# Unit test for function match
def test_match():
    assert match(Command('hg'))
    assert match(Command('git'))

      

# Generated at 2022-06-22 02:20:43.587416
# Unit test for function match
def test_match():
    command = Command('git init', 'fatal: not a git repository')
    assert not match(command)

    command = Command('hg init', 'fatal: not a git repository')
    assert not match(command)


# Generated at 2022-06-22 02:20:45.499715
# Unit test for function match
def test_match():
    assert match('git status')
    assert match('hg status')
    assert not match('svn status')



# Generated at 2022-06-22 02:20:48.559211
# Unit test for function match
def test_match():
    assert match(command='git status', output='fatal: Not a git repository')
    assert match(command='git status', output='fatal: Not a hg repository')


# Generated at 2022-06-22 02:20:54.134437
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository'))
    assert not match(Command('git', 'fatal: Not a git repository'))
    assert match(Command('hg', 'abort: no repository found'))
    assert not match(Command('hg', 'abort: no repository found'))

# Generated at 2022-06-22 02:20:56.438342
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git status', 'fatal: Not a git repository', '', 1)) == 'hg status'

# Generated at 2022-06-22 02:21:01.056842
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command(Command.from_string('git pull')))
    print(get_new_command(Command.from_string('git status')))
    print(get_new_command(Command.from_string('git add')))
    print(get_new_command(Command.from_string('git commit')))
    print(get_new_command(Command.from_string('git push')))

# Generated at 2022-06-22 02:21:59.164630
# Unit test for function match
def test_match():
    command = types.Command('git push', 'fatal: Not a git repository', '')
    assert match(command)
    # Wrong command
    command = types.Command('git status', 'fatal: Not a git repository', '')
    assert not match(command)
    # Wrong error
    command = types.Command('git push', 'fatal: Not a git repo', '')
    assert not match(command)
    # Wrong scm
    command = types.Command('hg push', 'abort: no repository found', '')
    assert match(command)


# Generated at 2022-06-22 02:22:00.954992
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git status', output='fatal: Not a git repository')) == 'hg status'

# Generated at 2022-06-22 02:22:09.560255
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push git@github.com:...') == 'git push git@github.com:...'
    assert get_new_command('hg push git@github.com:...') == 'hg push git@github.com:...'
    assert get_new_command('git push git@github.com:...', '/opt/folder') == 'hg push git@github.com:...'
    assert get_new_command('hg push git@github.com:...', '/opt/folder') == 'hg push git@github.com:...'

# Generated at 2022-06-22 02:22:10.672774
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('hg init', '')) == 'git init'

# Generated at 2022-06-22 02:22:12.512299
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git branch')
    get_new_command(command) == 'scm branch'

# Generated at 2022-06-22 02:22:15.597571
# Unit test for function match
def test_match():
    command = Command('git stash', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg status', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-22 02:22:17.390535
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')

    assert match(command)



# Generated at 2022-06-22 02:22:23.522206
# Unit test for function match
def test_match():
    # wrong scm
    assert match(u'git status')
    assert match(u'git checkout stable')
    assert match(u'hg status')
    assert match(u'hg checkout stable')
    
    # correct scm
    assert not match(u'git status')
    assert not match(u'git checkout stable')
    assert not match(u'hg status')
    assert not match(u'hg checkout stable')


# Generated at 2022-06-22 02:22:27.665734
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repositor'))
    assert not match(Command('hg status', 'abort: no repository found '))

# Generated at 2022-06-22 02:22:30.036848
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('hg diff') == 'git diff'
    assert get_new_command('git reset') == 'hg reset'

# Generated at 2022-06-22 02:24:26.060547
# Unit test for function match
def test_match():
    assert match(Command('git diff', 'fatal: Not a git repository'))
    assert not match(Command('git diff', 'fatal: Not a git repository(or any of the parent directories): .git'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert not match(Command('hg commit', 'No repository found (or any of the parent directories): .hg'))


# Generated at 2022-06-22 02:24:28.436484
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))


# Generated at 2022-06-22 02:24:38.756767
# Unit test for function get_new_command
def test_get_new_command():
    _get_new_command = get_new_command
    _get_actual_scm = _get_actual_scm
    _path_to_scm = path_to_scm
    _wrong_scm_patterns = wrong_scm_patterns


# Generated at 2022-06-22 02:24:49.259339
# Unit test for function match
def test_match():
    for scm, pattern in wrong_scm_patterns.items():
        assert match(Command('', pattern))
        assert match(Command('', pattern + ' '))
        assert match(Command('', pattern + '\n'))
        assert match(Command('', pattern + '\nabc'))
        assert match(Command('', pattern + '\nabc\n'))
        assert match(Command('', pattern + '\nabc\n'))
        assert match(Command('', pattern + ' abc\ndef\n'))
        assert match(Command('', pattern + '\nabc\ndef'))
        assert match(Command('', 'abc\n' + pattern + '\ndef'))
        assert match(Command('', pattern + '\ndef'))

# Generated at 2022-06-22 02:24:54.721093
# Unit test for function match
def test_match():
    assert match(Scrip(['git', 'status'], 'fatal: Not a git repository'))
    assert not match(Scrip(['git', 'status'], 'On branch master'))
    assert match(Scrip(['hg', 'status'], 'abort: no repository found'))
    assert not match(Scrip(['hg', 'status'], 'A .'))



# Generated at 2022-06-22 02:24:59.026813
# Unit test for function get_new_command
def test_get_new_command():
    # Test git command
    assert(get_new_command(Command('git status', 'fatal: Not a git repository')) == 'git status')

    # Test hg command
    assert(get_new_command(Command('hg status', 'abort: no repository found')) == 'hg status')

# Generated at 2022-06-22 02:25:03.772557
# Unit test for function match
def test_match():
    assert match(Command('git fetch', wrong_scm_patterns['git']))
    assert match(Command('hg pull', wrong_scm_patterns['hg']))
    assert not match(Command('git fetch', 'nothing'))
    assert not match(Command('hg pull', 'nothing'))


# Generated at 2022-06-22 02:25:06.039861
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command('hg status')
    assert 'hg status' == get_new_command('git status')

# Generated at 2022-06-22 02:25:10.715466
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git pull --rebase', '', 'fatal: Not a git repository')) == \
        'hg pull --rebase'
    assert get_new_command(Command('hg --version', '', 'abort: no repository found')) == \
        'git --version'

# Generated at 2022-06-22 02:25:13.761280
# Unit test for function match
def test_match():
    git = "git commit -m 'test_match'"
    git_out = "fatal: Not a git repository"
    assert match(Command(git, git_out))
