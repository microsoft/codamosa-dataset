

# Generated at 2022-06-12 12:11:48.374082
# Unit test for function match
def test_match():
    assert match(Command('git status', wrong_scm_patterns['git'], '', 1))
    assert not match(Command('git status', '', '', 1))

    assert match(Command('hg status', wrong_scm_patterns['hg'], '', 1))
    assert not match(Command('hg status', '', '', 1))


# Generated at 2022-06-12 12:11:56.058897
# Unit test for function match
def test_match():
    assert match(ShellCommand(script='git status',
                              output='fatal: Not a git repository'))
    assert match(ShellCommand(script='git status',
                              output='fatal: Not a git repository'))
    assert not match(ShellCommand(script='git status',
                                  output=''))

    assert match(ShellCommand(script='hg status',
                              output='abort: no repository found'))
    assert not match(ShellCommand(script='hg status',
                                  output=''))



# Generated at 2022-06-12 12:12:02.225104
# Unit test for function match
def test_match():
    # SCM's correctly detected
    assert match(Command('git', '', u'fatal: Not a git repository'))
    assert not match(Command('hg', '', u'abort: no repository found'))
    assert not match(Command('git', '', u'fatal: Not a hg repository'))

    # Other output ignored
    assert not match(Command('git', '', u'fatal: Not a git'))
    assert not match(Command('hg', '', u'abort: no'))

# Generated at 2022-06-12 12:12:04.837636
# Unit test for function match
def test_match():
    from thefuck.types import Command
    script = Command(script='git pull',
        stderr='fatal: Not a git repository',
        stdout='')
    assert match(script)

# Generated at 2022-06-12 12:12:07.147584
# Unit test for function match
def test_match():
    assert match(Command('git add .'))
    assert not match(Command('git status'))
    assert match(Command('hg diff'))
    assert not match(Command('ls'))


# Generated at 2022-06-12 12:12:08.872929
# Unit test for function match
def test_match():
    command = Command('git status', '')
    assert match(command)


# Generated at 2022-06-12 12:12:11.017888
# Unit test for function match
def test_match():
    command = Command('git add a/b.c', 'fatal: Not a git repository') 
    assert match(command)
    command = Command('git add a/b.c', 'fatal: Not a hg repository')
    assert not match(command)



# Generated at 2022-06-12 12:12:16.066196
# Unit test for function match
def test_match():
    command = Command('git commit', 'fatal: Not a git repository')
    assert match(command) == True
    command = Command('git commit', 'abort: no repository found')
    assert match(command) == False
    command = Command('hg commit', 'abort: no repository found')
    assert match(command) == True



# Generated at 2022-06-12 12:12:19.473205
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command('hg branch', wrong_scm_patterns['hg']))
    assert not match(Command('git branch', wrong_scm_patterns['git']))

# Generated at 2022-06-12 12:12:23.450609
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no changes found'))


# Generated at 2022-06-12 12:12:31.320254
# Unit test for function match
def test_match():
    scm = _get_actual_scm()
    cmd = Command(script='git BranchName', stdout='fatal: Not a git repository')
    assert match(cmd)
    cmd = Command(script='git BranchName', stdout='fatal: This is a git repository')
    assert not match(cmd)
    cmd = Command(script='hg BranchName', stdout='abort: This is not a hg repository')
    assert not match(cmd)
    cmd = Command(script='hg BranchName', stdout='abort: no repository found')
    assert match(cmd)
    cmd = Command(script='hg BranchName', stdout='fatal: not a git repository')
    assert not match(cmd)
    cmd = Command(script='git BranchName', stdout='abort: no hg repository found')

# Generated at 2022-06-12 12:12:34.447032
# Unit test for function match
def test_match():
    """ Test match() function """
    from thefuck.types import Command
    command = Command('git commit -m "first commit"',
                      'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)


# Generated at 2022-06-12 12:12:37.426278
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('git status', '', ''))
    assert not match(Command('hg status', '', ''))


# Generated at 2022-06-12 12:12:42.205703
# Unit test for function match
def test_match():
    assert match(Command(script='hg add .', stderr=wrong_scm_patterns['hg']))
    assert match(Command(script='git add .', stderr=wrong_scm_patterns['git']))
    assert match(Command(script='git status', stderr=wrong_scm_patterns['git']))


# Generated at 2022-06-12 12:12:46.081166
# Unit test for function match
def test_match():
    assert match(Command('git', 'fatal: Not a git repository'))
    assert match(Command('hg', 'abort: no repository found'))
    assert not match(Command('git', 'fatal: Not a git repository'))
    assert not match(Command('hg', 'abort: no repository found'))


# Generated at 2022-06-12 12:12:56.483618
# Unit test for function match
def test_match():
    output_git = u'fatal: Not a git repository';
    output_hg = u'abort: no repository found';
    command_git = u'git branch';
    command_hg = u'hg branch';
    assert match(Command(command_git, output_git))
    assert match(Command(command_hg, output_hg))
    assert not match(Command(command_git, u'fatal: Not a git  repository'))
    assert not match(Command(command_hg, u'abort: no  repository found'))
    assert not match(Command(u'cd' + command_git, output_git))
    assert not match(Command(u'cd' + command_hg, output_hg))
    Path('.git').touch()

# Generated at 2022-06-12 12:13:00.576926
# Unit test for function match
def test_match():
    command = Command('git add .', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git add .', "abort: no repository found ('path')!")
    assert not match(command)

    command = Command('hg add .', "abort: no repository found ('path')!")
    assert match(command)


# Generated at 2022-06-12 12:13:08.821472
# Unit test for function match
def test_match():
    assert not match(Command(u'git', u''))
    assert not match(Command(u'git', u'', u'git: \'fatal:dasd\' is not a git command. See \'git --help\''))
    assert not match(Command(u'git', u'', u'fatal: \'dasd\' is not a git command. See \'git --help\''))
    assert not match(Command(u'git', u'', u'fatal: Not a git repository'))
    assert match(Command(u'git', u'', u'fatal: Not a git repository asd'))
    assert match(Command(u'git', u'', u'fatal: Not a git repository (errno 2)'))
    assert not match(Command(u'hg', u''))

# Generated at 2022-06-12 12:13:12.177867
# Unit test for function match
def test_match():
    wrong_command = Command('hg log',
                            '''
                            abort: no repository found in '/home/user/' (.hg not found)
                            '''
                            )
    assert match(wrong_command)



# Generated at 2022-06-12 12:13:18.829931
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository(or something else)'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository.'))
    assert not match(Command('git status', 'fatal: Not a git repository (or something else)'))
    assert not match(Command('git status', 'fatal: Not a git repository (or something else) fatal: Not a git repository'))



# Generated at 2022-06-12 12:13:22.869837
# Unit test for function match
def test_match():
    command = Command(script='wrong_scm status', output='fatal: Not a git repository')
    assert match(command) 


# Generated at 2022-06-12 12:13:26.385381
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert not match(Command('git status', 'something'))

# Generated at 2022-06-12 12:13:30.518980
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repositor'))
    assert not match(Command('hg status', 'abort: no repository fo'))

# Generated at 2022-06-12 12:13:33.028759
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('svn status', ''))


# Generated at 2022-06-12 12:13:34.823550
# Unit test for function match

# Generated at 2022-06-12 12:13:36.983636
# Unit test for function match
def test_match():
    test_command = Command('git status', 'fatal: Not a git repository', '/dev/null')
    assert match(test_command) is True


# Generated at 2022-06-12 12:13:40.693688
# Unit test for function match
def test_match():
    result = match(Command(script="git status", output='fatal: Not a git repository'))
    assert result is True
    result = match(Command(script="hg status", output='abort: no repository found'))
    assert result is True
    result = match(Command(script="svn status", output='abort: no repository found'))
    assert result is False


# Generated at 2022-06-12 12:13:44.786862
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch','abort: no repository found'))
    assert not match(Command('git branch', 'test'))
    assert not match(Command('hg branch', 'test'))


# Generated at 2022-06-12 12:13:47.265979
# Unit test for function match
def test_match():
    from thefuck.rules.main import get_all_matched_rules
    from tests.utils import Command

    assert get_all_matched_rules(Command('git status'))

# Generated at 2022-06-12 12:13:53.083726
# Unit test for function match
def test_match():
    # assert that all patterns are in wrong_scm_patterns.values()
    assert all([p.lower() in wrong_scm_patterns[s] for s, p in path_to_scm.items()])

    output = u'fatal: Not a git repository (or any of the parent directories): .git'
    assert not match(Command(script=u'hg status', output=output))
    assert match(Command(script=u'git status', output=output))


# Generated at 2022-06-12 12:13:57.001571
# Unit test for function match
def test_match():

    c = Command(script='git status',
                stdout=wrong_scm_patterns['git'])
    assert match(c) == True


# Generated at 2022-06-12 12:13:58.489753
# Unit test for function match
def test_match():
    cath = Command('git commit -m "test"')
    assert match(cath)



# Generated at 2022-06-12 12:14:07.459210
# Unit test for function match
def test_match():
    """ It should return True if match function return False """
    res = match('git status')
    assert res == False
    res = match('git status', 'git: fatal: Not a git repository')
    assert res == True
    res = match('git status', 'git: fatal: Not a git repository', 'some message')
    assert res == True
    res = match('git status', 'some message', 'git: fatal: Not a git repository')
    assert res == True
    res = match('git status', 'some message', 'git: fatal: Not a git repository', 'git: fatal: Not a git repository')
    assert res == True

# Generated at 2022-06-12 12:14:11.789141
# Unit test for function match
def test_match():
    assert not match(Command(script = 'git commit'))
    assert not match(Command(script = 'git commit', output = 'Wrong repo'))
    assert match(Command(script = 'git commit',
                        output = 'fatal: Not a git repository'))
    assert match(Command(script = 'hg commit',
                        output = 'abort: no repository found'))


# Generated at 2022-06-12 12:14:15.531886
# Unit test for function match
def test_match():
    assert match(Command('git status')) == True
    assert match(Command('git status', 'fatal: Not a git repository')) == True
    assert match(Command('git status', 'bad command')) == False
    assert match(Command('hg badcommand')) == True
    assert match(Command('hg badcommand', 'abort: no repository found')) == True
    assert match(Command('hg badcommand', 'bad command')) == False


# Generated at 2022-06-12 12:14:23.685263
# Unit test for function match
def test_match():
    args = ["git","log"]
    git_command = Command(args, None, "fatal: Not a git repository")
    #case 1: should match, git is the default, but there is a hg repo
    assert match(git_command) is True
    #case 2: should not match, git is the default, there is no repo
    no_git_command = Command(args, None, "fatal: Not a git repository")
    assert match(no_git_command) is False

    #case 3: should match, hg is the default, but there is a git repo
    args = ["hg","log"]
    hg_command = Command(args, None, "abort: no repository found!")
    assert match(hg_command) is True

# Generated at 2022-06-12 12:14:26.708065
# Unit test for function match
def test_match():
    command = Command('git branch', 'fatal: Not a git repository')
    assert match(command)
    command = Command('hg branch', 'abort: no repository found')
    assert match(command)


# Generated at 2022-06-12 12:14:29.151906
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))



# Generated at 2022-06-12 12:14:35.336679
# Unit test for function match
def test_match():
    pass
    # command1 = Command('git commit -am "hello"', '', '', '')
    # command2 = Command('hg push', '', '', '')
    # command3 = Command('git commit -am "hello"', '', '', '')
    # command4 = Command('hg push', '', '', '')

    # assert match(command1) == True
    # assert match(command2) == True
    # assert match(command3) == False
    # assert match(command4) == False

# Generated at 2022-06-12 12:14:38.192436
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git status', 'fatal: not a git repository')
    assert not match(command)


# Generated at 2022-06-12 12:14:44.502836
# Unit test for function match
def test_match():
    assert (not match(Command(script='git status',
                              stderr='fatal: Not a git repository')))
    assert match(Command(script='git status',
                         stderr='fatal: Not a git repository'))
    assert (not match(Command(script='git status',
                              stderr='fatal: Not a git repository')))



# Generated at 2022-06-12 12:14:50.076515
# Unit test for function match
def test_match():
    script = 'git status'
    command = Command(script, wrong_scm_patterns['git'])
    assert(match(command))

    script = 'hg status'
    command = Command(script, wrong_scm_patterns['hg'])
    assert(match(command))

    script = 'svn status'
    command = Command(script, 'something else')
    assert(not match(command))



# Generated at 2022-06-12 12:14:55.525909
# Unit test for function match
def test_match():
    # Test 1: Check if it can pick up existing repository
    command = Command('hg commit -m test', 'abort: no repository found!')
    assert match(command) == True

    # Test 2: Check if it ignores when there is no Git/Hg repository
    command = Command('git push origin master', 'git: \'push\' is not a git command.')
    assert match(command) == False

# Generated at 2022-06-12 12:14:58.373151
# Unit test for function match
def test_match():
    command = 'hg status'
    wrong_command = 'hg status'
    correct_command = 'git status'

    assert match(Command(command))
    assert not match(Command(correct_command))


# Generated at 2022-06-12 12:15:00.724863
# Unit test for function match
def test_match():
    command1 = Command('git status', 'fatal: Not a git repository')
    assert match(command1)
    

# Generated at 2022-06-12 12:15:10.389629
# Unit test for function match
def test_match():
    assert not match(Command('git status', ''))
    assert not match(Command('hg status', ''))

    output = 'fatal: Not a git repository'
    assert match(Command('git status', output))
    output = 'abort: no repository found'
    assert match(Command('hg status', output))

    with Path('.git').temporary(True):
        output = 'fatal: Not a git repository'
        assert match(Command('git status', output))

    with Path('.hg').temporary(True):
        output = 'abort: no repository found'
        assert match(Command('hg status', output))

    with Path('.git').temporary(True), Path('.hg').temporary(True):
        output = 'abort: no repository found'

# Generated at 2022-06-12 12:15:13.484000
# Unit test for function match
def test_match():
    assert match(Command('foo', 'fatal: Not a git repository'))
    assert match(Command('foo', 'fatal: Not a hg repository'))
    assert not match(Command('git foo', ''))



# Generated at 2022-06-12 12:15:16.711566
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'foo'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'foo'))


# Generated at 2022-06-12 12:15:18.417058
# Unit test for function match
def test_match():
	test_bash = "hg add test.txt"
	test_cmd = Command(test_bash, "fatal: Not a git repository")
	assert match(test_cmd) is False

# Generated at 2022-06-12 12:15:20.373392
# Unit test for function match
def test_match():
    assert match(Command('git status'))
    assert not match(Command('git --version'))
    assert not match(Command('hg --version'))
    assert not match(Command('svn --version'))

# Generated at 2022-06-12 12:15:27.861195
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('svn status', 'svn: Not a git repository'))

# Generated at 2022-06-12 12:15:30.021645
# Unit test for function match
def test_match():
        assert match(ScriptInfo(script=u'git status', output=u'fatal: Not a git repository')) is True


# Generated at 2022-06-12 12:15:33.876614
# Unit test for function match
def test_match():
    def assert_match(output):
        assert match(Command('git', output))
        assert match(Command('hg', output))

    assert_match("fatal: Not a git repository")
    assert_match("fatal: Not a hg repository")
    assert not match(Command('git', ''))
    assert not match(Command('hg', ''))
    assert not match(Command('ls', ''))

# Generated at 2022-06-12 12:15:36.284724
# Unit test for function match
def test_match():
    assert match(command=Command(script='git',
                                 output='fatal: Not a git repository')) == True
    assert match(command=Command(script='git',
                                 output='fatal: Not a repository')) == False


# Generated at 2022-06-12 12:15:38.763521
# Unit test for function match
def test_match():
    assert match(Command('git status',
                   'fatal: Not a git repository (or any'))
    assert not match(Command('git status',
                    'fatal: Not a git repository (or any'))

# Generated at 2022-06-12 12:15:40.724809
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: Not a git repository (or any of the parent directories): .git'))



# Generated at 2022-06-12 12:15:44.267243
# Unit test for function match
def test_match():
    assert match(Command('git branch',
                         'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command('git branch',
                         'fatal: Not a git repository (or any of the parent directories): .git\nfatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('ls'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 12:15:48.195656
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command) == True

    command = Command('hg status', 'abort: no repository found')
    assert match(command) == True

    command = Command('git status', 'fatal: Not a git repository')
    assert match(command) == True



# Generated at 2022-06-12 12:15:53.458341
# Unit test for function match
def test_match():
    assert match(Command(script='git env', output='git: \'env\' is not a git command. See \'git --help\'.'))
    assert match(Command(script='hg env', output='hg: unknown command \'env\''))
    assert not match(Command(script='git env', output='env: command not found'))


# Generated at 2022-06-12 12:15:57.849079
# Unit test for function match
def test_match():
    command = Command('git commit -m "fuck"', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    assert get_new_command(command) == 'hg commit -m "fuck"'

    command = Command('git commit -m "fuck"', 'nothing wrong')
    assert not match(command)

# Generated at 2022-06-12 12:16:13.236934
# Unit test for function match
def test_match():
    # Test for a wrong version, should return true
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    # Test for a wrong version, should return true
    command2 = Command('hg status', 'abort: no repository found')
    assert match(command2)

    # Test for a wrong command, should return false
    command3 = Command('git push', 'fatal: Not a git repository')
    assert not match(command3)

    # Test for a correct command, should return false
    command4 = Command('git init', 'fatal: Not a git repository')
    assert not match(command4)


# Generated at 2022-06-12 12:16:17.584558
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"', 'fatal: Not a git repository', ''))
    assert not match(Command('git commit -m "message"', 'Illegal option', ''))

    assert match(Command('hg commit -m "message"', 'abort: no repository found', ''))
    assert not match(Command('hg commit -m "message"', 'wrong repo found', ''))


# Generated at 2022-06-12 12:16:22.653560
# Unit test for function match
def test_match():
    command_git = Command('git add .', 'fatal: Not a git repository')
    command_hg = Command('hg add .', 'abort: no repository found')
    command_pwd = Command('pwd', '')
    assert match(command_git)
    assert match(command_hg)
    assert not match(command_pwd)



# Generated at 2022-06-12 12:16:24.336564
# Unit test for function match
def test_match():
    assert (match(Command('git', 'origin', output='fatal: Not a git repository \n')))


# Generated at 2022-06-12 12:16:28.864905
# Unit test for function match
def test_match():
    assert match(Command(script='git', output= 'fatal: Not a git repository'))
    assert not match(Command(script='git', output='hi'))
    assert match(Command(script='hg', output= 'abort: no repository found'))
    assert not match(Command(script='git', output='hi'))

# Test for function get_new_command

# Generated at 2022-06-12 12:16:32.829978
# Unit test for function match
def test_match():
    wrong_output = 'fatal: Not a git repository (or any of the parent directory)'
    assert(match(Command('git status', wrong_output)) is True)

    wrong_output = 'abort: No hg repository found in '
    assert(match(Command('hg update', wrong_output)) is True)

    assert(match(Command('hg update', 'abort: 5 conflicts detected!')) is False)



# Generated at 2022-06-12 12:16:36.642487
# Unit test for function match
def test_match():
    command = Command('git branch', 'fatal: Not a git repository')
    assert match(command)
    assert get_new_command(command) == 'hg branch'
    # TODO: Add test message when hg will be similar.
    assert get_new_command(
        Command('hg branch', 'abort: no repository found')) == 'hg branch'

# Generated at 2022-06-12 12:16:38.095922
# Unit test for function match
def test_match():
    assert match(Command('git add somefile'))
    assert not match(Command('git status'))


# Generated at 2022-06-12 12:16:41.143708
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command('git branch', ''))
    assert not match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command('git branch', ''))


# Generated at 2022-06-12 12:16:47.139554
# Unit test for function match
def test_match():
    assert match(Command('git rev-parse --git-dir',
                         'fatal: Not a git repository'))
    assert not match(Command('git rev-parse --git-dir',
                             'fatal: Not a hg repository'))
    assert match(Command('hg status',
                         'abort: no repository found'))
    assert not match(Command('hg status',
                             'fatal: Not a hg repository'))


# Generated at 2022-06-12 12:17:10.839062
# Unit test for function match
def test_match():
	from os import chdir
	from os.path import expanduser
	from sys import path
	path.append(expanduser("~") + '/.config/thefuck')
	from thefuck.rules.wrong_scm import match
	from thefuck.main import Command

	git_cmd = Command("git pull origin master", "fatal: Not a git repository (or any of the parent directories): .git\n")
	hg_cmd = Command("hg pull", "abort: no repository found in '/home/atanu/Documents/Current/Workspace/kondaiah/tessy-reports' (.hg not found)\n")

# Generated at 2022-06-12 12:17:14.837763
# Unit test for function match
def test_match():
    assert(match(Command('git status', 'fatal: Not a git repository')) == True)
    assert(match(Command('git status', 'abort: no repository found')) == False)
    assert(match(Command('hg status', 'fatal: Not a git repository')) == False)
    assert(match(Command('hg status', 'abort: no repository found')) == True)



# Generated at 2022-06-12 12:17:20.223833
# Unit test for function match
def test_match():
    command = Command('git stash', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git stash', 'fatal: Not a hg repository')
    assert not match(command)
    command = Command('git stash', 'fatal: Not a svn repository')
    assert not match(command)
    command = Command('hg stash', 'abort: no repository found')
    assert match(command)
    command = Command('hg stash', 'abort: no git repository')
    assert not match(command)
    command = Command('hg stash', 'abort: no bzr repository')
    assert not match(command)
    command = Command('hg stash', 'abort: no svn repository')
    assert not match(command)

# Generated at 2022-06-12 12:17:22.627790
# Unit test for function match
def test_match():
    cmd = Command('hg status', 'fatal: Not a git repository')
    assert match(cmd) == True

    cmd = Command('git status', 'abort: no repository found')
    assert match(cmd) == False


# Generated at 2022-06-12 12:17:27.330892
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: Not a git repository"))
    assert match(Command("git status", "fatal: Not a git repository",
                         "abort: no repository found"))
    assert not match(Command("git status", ""))
    assert not match(Command("git status", "fatal: Not a git repository",
                             "abort: no repository found", "",
                             "fatal: Not a git repository"))

# Generated at 2022-06-12 12:17:33.080605
# Unit test for function match
def test_match():
    assert match(Command('git status',
                          'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('hg status', ''))
    assert not match(Command('git status', ''))
    assert not match(Command('hg status',
                             'abort: no repository found in /home/test/ (looked in [])!\n'))


# Generated at 2022-06-12 12:17:35.164475
# Unit test for function match
def test_match():
    assert match(Command('git command ouput', 
        'fatal: Not a git repository'))
    assert _get_actual_scm() == 'git'


# Generated at 2022-06-12 12:17:40.780106
# Unit test for function match
def test_match():
    match = Match(None, '', '', '', '')
    assert wrong_scm('git', match) is False
    assert wrong_scm('hg', match) is False

    match = Match(None, '', '', '', 'fatal: Not a git repository')
    assert wrong_scm('git', match) is True
    assert wrong_scm('hg', match) is False

    match = Match(None, '', '', '', 'abort: no repository found')
    assert wrong_scm('git', match) is False
    assert wrong_scm('hg', match) is True

# Generated at 2022-06-12 12:17:48.008929
# Unit test for function match
def test_match():
    test_cased = {
        0: {
            'command': Command('git status', 'fatal: Not a git repository'),
            'expected': False
        },
        1: {
            'command': Command('hg status', 'abort: no repository found'),
            'expected': False
        },
        2: {
            'command': Command('git status', 'fatal: Not a git repository'),
            'expected': True
        },
        3: {
            'command': Command('hg status', 'abort: no repository found'),
            'expected': True
        }
    }


# Generated at 2022-06-12 12:17:54.815325
# Unit test for function match
def test_match():
    assert not match(Command('git', '', ''))
    assert not match(Command('git', '', '', None))
    assert not match(Command('git', '', '',
                             wrong_scm_patterns['git']))
    assert match(Command('git', '', '',
                         '{}\n{}'.format(
                             wrong_scm_patterns['git'],
                             wrong_scm_patterns['hg'])))
    assert not match(Command('hg', '', ''))
    assert not match(Command('hg', '', '', None))
    assert not match(Command('hg', '', '',
                             wrong_scm_patterns['hg']))

# Generated at 2022-06-12 12:18:33.649909
# Unit test for function match
def test_match():
    assert match(Command(script='git status',
                         output='fatal: Not a git repository (or any of the parent directories): .git'))


# Generated at 2022-06-12 12:18:38.016320
# Unit test for function match
def test_match():
    cmd = Command('git diff', 'fatal: Not a git repository')
    assert match(cmd) is True

    cmd = Command('git diff', 'fatal: Not a git repositor')
    assert match(cmd) is False

    cmd = Command('hg diff', 'fatal: Not a git repository')
    assert match(cmd) is False


# Generated at 2022-06-12 12:18:42.379759
# Unit test for function match
def test_match():
    assert match(Command('git', 'git: \'credential-osxkeychain\' is not a git command. See \'git --help\'.'))
    assert not match(Command('git', 'git: \'commit\' is not a git command. See \'git --help\''))
    assert match(Command('hg', 'abort: no repository found!'))

# Generated at 2022-06-12 12:18:48.608395
# Unit test for function match
def test_match():
    command = Command('git diff', 'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command) == True

    command = Command('hg add', 'abort: no repository found')
    assert match(command) == True

    command = Command('git diff', 'fatal: Not a git repository (or any of the parent directories): .git\n\nfoo')
    assert match(command) == False

    command = Command('hg add', 'abort: no repository found\n\nfoo')
    assert match(command) == False


# Generated at 2022-06-12 12:18:51.623685
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository.\n', '', 42)
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository.\n', '', 42)
    assert not match(command)


# Generated at 2022-06-12 12:18:55.115258
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg log', 'abort: no repository found'))
    assert not match(Command('vim -e'))



# Generated at 2022-06-12 12:18:57.440909
# Unit test for function match
def test_match():
    assert not match(Command(script='git', output='fatal: Not a git repository (or any of the parent directories): .git\n'))



# Generated at 2022-06-12 12:18:59.590122
# Unit test for function match
def test_match():
    command = Command('git pull', 'fatal: Not a git repository', u'/')
    assert match(command)



# Generated at 2022-06-12 12:19:03.189933
# Unit test for function match
def test_match():
    command = Command('git push origin master', 'fatal: Not a git repository',
                      'fatal: Not a git repository')
    assert match(command)

    command = Command('hg push origin master', 'abort: no repository found',
                      'abort: no repository found')
    assert match(command)

# Generated at 2022-06-12 12:19:04.803159
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', 'fatal: Not a git repository'))
    return True


# Generated at 2022-06-12 12:20:32.596378
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository'))

# Generated at 2022-06-12 12:20:34.631899
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository\n')
    assert match(command) == True



# Generated at 2022-06-12 12:20:37.301425
# Unit test for function match
def test_match():
    # Test sript parts
    command = Command('git diff', 'fatal: Not a git repository')
    assert match(command)
    # Test if for_app works
    command = Command('test diff', 'test abort: no repository found')
    assert not match(command)


# Generated at 2022-06-12 12:20:41.725715
# Unit test for function match
def test_match():
    command = Command(script='git', output=u'fatal: Not a git repository')
    assert match(command)

    command = Command(script='hg', output=u'abort: no repository found')
    assert match(command)

# Generated at 2022-06-12 12:20:43.113503
# Unit test for function match
def test_match():
    from thefuck.rules.wrong_scm import match
    assert match("git -a") == False


# Generated at 2022-06-12 12:20:47.002527
# Unit test for function match
def test_match():
    assert not match(Command('git status', '', '/usr/bin/git'))
    assert not match(Command('hg status', '', '/usr/bin/hg'))

    assert match(Command('git status', 'fatal: Not a git repository', '/usr/bin/git'))
    assert match(Command('hg status', 'abort: no repository found', '/usr/bin/hg'))



# Generated at 2022-06-12 12:20:49.466061
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository')).output == 'git status'
    assert match(Command('git status', 'fatal: Not a git repository')) != None
    assert match(Command('hg status', 'abort: no repository found')) != None


# Generated at 2022-06-12 12:20:51.146737
# Unit test for function match
def test_match():
    assert match(Command('git log', 'fatal: Not a git repository'))
    assert not match(Command('git log', ''))

# Generated at 2022-06-12 12:20:54.060570
# Unit test for function match
def test_match():
    output1 = 'fatal: Not a git repository'
    output2 = 'abort: no repository found'
    assert (match(Command('git status', output1)) != False)
    assert (match(Command('hg status', output2)) != False)
    assert (match(Command('git status', '')) == False)

test_match()

# Generated at 2022-06-12 12:20:56.404262
# Unit test for function match
def test_match():
    assert match(Command('git branch', ''))
    assert match(Command('hg branch', ''))
    assert not match(Command('hg branch', 'abort: no repository found'))
