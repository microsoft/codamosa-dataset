

# Generated at 2022-06-12 12:11:50.952660
# Unit test for function match
def test_match():
    # Test: Using git command in mercurial repository
    command = Command(script=u'git status',
                      stdout=u'fatal: Not a git repository', stderr=u'',
                      env={u'PWD': u'/home/user'},)
    assert match(command) == True

    # Test: Using hg command in git repository
    command = Command(script=u'hg status', stdout=u'',
                      stderr=u'abort: no repository found',
                      env={u'PWD': u'/home/user'},)
    assert match(command) == True

    # Test: Using git command in git repository

# Generated at 2022-06-12 12:11:52.807393
# Unit test for function match
def test_match():
    assert match(
        Command('git status', 'fatal: Not a git repository'))



# Generated at 2022-06-12 12:11:58.762416
# Unit test for function match
def test_match():
    # Set up the shell return values
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command) == True
    command = Command('git status', 'On branch master')
    assert match(command) == False
    command = Command('hg status', 'abort: no repository found')
    assert match(command) == True
    command = Command('hg status', 'On branch master')
    assert match(command) == False


# Generated at 2022-06-12 12:12:05.871005
# Unit test for function match
def test_match():
    assert match(Command(script = 'git commit -a -m "test"',
                         output = 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command(script = 'hg commit -a -m "test"',
                         output = "abort: no repository found in '.' or in a parent directory"))
    assert not match(Command(script = 'git commit -a -m "test"',
                             output = 'Nothing specified, nothing added.'))
    assert not match(Command(script = 'hg commit -a -m "test"',
                             output = 'adding changesets'))


# Generated at 2022-06-12 12:12:08.883784
# Unit test for function match
def test_match():
    command1 = Command("git branch", "fatal: Not a git repository")
    wrong_command = Command("git branch", "")

    assert match(command1)
    assert not match(wrong_command)


# Generated at 2022-06-12 12:12:14.325810
# Unit test for function match
def test_match():
    command = Command('hg status', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git status', 'fatal: Not a git repository')
    assert not match(command)
    command = Command('hg status', 'abort: no repository found')
    assert not match(command)
    

# Generated at 2022-06-12 12:12:19.042072
# Unit test for function match
def test_match():

    assert match(command = Command('git', output = wrong_scm_patterns['git']))
    assert not match(command = Command('git', output = wrong_scm_patterns['hg']))
    assert not match(command = Command('hg', output = wrong_scm_patterns['git']))
    assert match(command = Command('hg', output = wrong_scm_patterns['hg']))

# Generated at 2022-06-12 12:12:27.123809
# Unit test for function match
def test_match():
    assert match(Command('git', 'status', 'fatal: Not a git repository'))
    assert match(Command('git', 'status', 'fatal: Not a git repository\n'))
    assert match(Command('git', 'status', 'lala\nfatal: Not a git repository\n'))

    assert not match(Command('git', 'status', 'lal'))
    assert not match(
            Command('git', 'status', 'fatal: Not a git repository\nlal'))
    assert not match(
            Command('git', 'status', 'lal\nfatal: Not a git repository\nlal'))

    assert match(Command('hg', 'status', 'abort: no repository found'))
    assert not match(Command('hg', 'status', 'lal'))

# Generated at 2022-06-12 12:12:29.795611
# Unit test for function match
def test_match():
    assert match(Command('hg status', ''))
    assert match(Command('git status', ''))
    assert not match(Command('svn status', ''))
    assert not match(Command('git status', 'On branch master'))

# Generated at 2022-06-12 12:12:33.152690
# Unit test for function match
def test_match():
    assert match(Command(script='git',
                         output="fatal: Not a git repository"))
    assert match(Command(script='hg',
                         output="abort: no repository found"))
    assert not match(Command(script='svn',
                             output="fatal: Not a git repository"))



# Generated at 2022-06-12 12:12:42.286436
# Unit test for function match
def test_match():
    """
    Should return true, if called with specific parameters
    """

    # Change current_dir to the current directory
    # of the script (used in match)
    current_dir = os.getcwd()
    os.chdir(os.path.dirname(os.path.realpath(__file__)))

    # Create a new command with script_parts
    command = create_command("""git add .""", "")

    # Set output to the output of our command
    command.output = "fatal: Not a git repository"

    assert match(command)

    # Change current_dir back to the previous one
    os.chdir(current_dir)

# Generated at 2022-06-12 12:12:46.409748
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: Not a git repository", ""))
    assert not match(Command("git status", "fatal: Not a git rep", ""))
    assert match(Command("hg status", "abort: no repository found", ""))
    assert not match(Command("hg status", "abort: no found", ""))


# Generated at 2022-06-12 12:12:56.876651
# Unit test for function match
def test_match():
    # Test for git
    output_git = "fatal: Not a git repository"

    # Test for hg
    output_hg = "abort: no repository found"

    # Test for both git and hg
    output_git_hg = "fatal: Not a git repository\nabort: no repository found"

    # Test for neither git and hg
    no_output = ""

    # Make an actual git and hg repository, delete them after test
    os.system("mkdir _test_repository")
    os.system("mkdir _test_repository/.git")
    os.system("mkdir _test_repository/.hg")

    # Mock Utilities
    command = "git status"
    mock_command = command

    # Test for git
    command = Command(command, output_git)

# Generated at 2022-06-12 12:13:01.169257
# Unit test for function match
def test_match():
    assert match(Command('git status', '', 'fatal: Not a git repository'))
    assert not match(Command('git status', '', ''))
    assert match(Command('hg status', '', 'abort: no repository found'))
    assert not match(Command('hg status', '', ''))
    assert not match(Command('hg status', '', 'abort: no repository found'))
    assert not match(Command('git status', '', ''))



# Generated at 2022-06-12 12:13:02.430454
# Unit test for function match
def test_match():
    assert match("git push") == True



# Generated at 2022-06-12 12:13:06.525698
# Unit test for function match
def test_match():
    assert match(Command('hg status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'fatal: Not a git repository'))

    assert match(Command('git status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found'))



# Generated at 2022-06-12 12:13:12.536731
# Unit test for function match
def test_match():
    command = Command("git commit", "fatal: Not a git repository")
    assert match(command)

    command = Command("git init", "fatal: Not a git repository")
    assert not match(command)

    command = Command("hg commit", "abort: no repository found")
    assert match(command)

    command = Command("hg init", "abort: no repository found")
    assert not match(command)


# Generated at 2022-06-12 12:13:14.861839
# Unit test for function match
def test_match():
    assert match(Command(script='git commit', output="fatal: Not a git repository"))
    assert match(Command(script='hg commit', output="abort: no repository found"))


# Generated at 2022-06-12 12:13:21.787846
# Unit test for function match
def test_match():
    assert match(Command('git status',
                'fatal: Not a git repository'))
    assert match(Command('git diff',
                'fatal: Not a git repository'))
    assert not match(Command('git diff',
                'diff --git a/README b/README'))
    assert not match(Command('hg status',
                'status'))
    assert match(Command('hg diff',
                'abort: no repository found'))
    # Set no repository for current dir in function _get_actual_scm
    assert not match(Command('git status',
                'fatal: Not a git repository'))
    assert not match(Command('hg diff'))


# Generated at 2022-06-12 12:13:25.299148
# Unit test for function match
def test_match():
    assert match(Command(script='git commit',
                         stderr=u'fatal: Not a git repository',
                         stdout=u'',
                         script_parts=['git', 'commit']))


# Generated at 2022-06-12 12:13:32.913081
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert not match(Command('git status', '', ''))
    assert match(Command('hg status', 'abort: no repository found', ''))
    assert match(Command('git status', 'fatal: Not a git repository', '', 'dd'))
    assert not match(Command('hg status', 'fatal: Not a git repository', ''))
    assert not match(Command('git status', '', '', 'dd'))


# Generated at 2022-06-12 12:13:38.570695
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository (or any of the parent directories): .git',
                         '?? test.py'))
    assert not match(Command('git status',
                         'On branch master',
                         '?? test.py'))
    assert match(Command('hg status',
                         'abort: no repository found in',
                         '?? test.py'))
    assert not match(Command('hg status',
                         'On branch master',
                         '?? test.py'))


# Generated at 2022-06-12 12:13:44.178011
# Unit test for function match
def test_match():
    assert not match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('git diff', 'fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert match(Command('hg status', 'abort: no repository found in /path/.hg (or any parent directory)\n'))
    assert not match(Command('hg status', 'abort: no repository found in /path/\n'))

# Generated at 2022-06-12 12:13:47.854026
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', ''))
    assert not match(Command('hg status', ''))
    assert not match(Command('fg status', ''))


# Generated at 2022-06-12 12:13:56.799671
# Unit test for function match
def test_match():
    from thefuck.rules.shell import match
    from thefuck.types import Command
    from thefuck.system import Path

    with patch('thefuck.rules.shell.Path') as PathMock:
        PathMock.return_value.exists.return_value = True
        PathMock.return_value.is_dir.return_value = True

        command = Command('git branch', 'fatal: Not a git repository')
        assert match(command)

    with patch('thefuck.rules.shell.Path') as PathMock:
        PathMock.return_value.exists.return_value = False
        PathMock.return_value.is_dir.return_value = False

        command = Command('git branch', 'fatal: Not a git repository')
        assert not match(command)


# Generated at 2022-06-12 12:14:00.561360
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: Not a git repository"))
    assert match(Command("hg status", "fatal: Not a git repository")) is False
    assert match(Command("git status", "abort: Not a git repository")) is False

# Generated at 2022-06-12 12:14:05.315035
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'nope')) is False
    assert match(Command('git status', 'abort: No repository found')) is False
    assert match(Command('hg status', 'abort: No repository found'))

# Generated at 2022-06-12 12:14:08.592285
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('ls', '/tmp/', 'fatal: Not a git repository'))
    assert not match(Command('ls', '/tmp/', 'fatal: Not a git repository'))


# Generated at 2022-06-12 12:14:11.281091
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git commit -m ""', '', '/bin/bash'))
    assert match(Command('hg commit -m ""', '', '/bin/bash'))


# Generated at 2022-06-12 12:14:12.604866
# Unit test for function match
def test_match():
    command = Command('git foo bar', 'fatal: Not a git repository')
    assert match(command) is True

# Generated at 2022-06-12 12:14:22.516299
# Unit test for function match
def test_match():
    assert match(Command('ls', '', 'fatal: Not a git repository'))
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert match(Command('ls', '', 'fatal Not a git repository'))
    assert not match(Command('ls', '', 'fatal: Not a git reposito'))
    assert not match(Command('git', '', 'fatal: Not a git reposito'))
    assert not match(Command('ls', '', 'fatal Not a git reposito'))
    assert not match(Command('git', '', 'abort: no repository found'))


# Generated at 2022-06-12 12:14:27.477528
# Unit test for function match
def test_match():
    def run_match(output, output_scm):
        return match(Command('git add', output=output,
                             script_parts=[u'git'])) == output_scm

    assert run_match('abort: no repository found', False)
    assert run_match('fatal: Not a git repository', False)
    assert run_match('abort: no repository found', True)

# Generated at 2022-06-12 12:14:32.565910
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: Not a git repository'))
    assert not match(Command('git push', 'fatal: Not a working directory'))

    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no file found'))


# Generated at 2022-06-12 12:14:33.486713
# Unit test for function match
def test_match():
    # TODO
    pass


# Generated at 2022-06-12 12:14:39.024951
# Unit test for function match
def test_match():
    scm = _get_actual_scm()
    assert match(Command('git status', 'fatal: Not a git repository')) == True
    assert match(Command('hg status', 'abort: no repository found')) == True
    assert match(Command('git status', 'abort: no repository found')) == False
    assert match(Command('hg status', 'fatal: Not a git repository')) == False
    assert match(Command('hg status', '')) == False


# Generated at 2022-06-12 12:14:41.409701
# Unit test for function match
def test_match():
    command = 'git branch'
    command_out = 'fatal: Not a git repository (or any of the parent directories): .git'


# Generated at 2022-06-12 12:14:46.612901
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository (fatal)'))
    assert not match(Command('git log', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found (abort)'))

# Generated at 2022-06-12 12:14:48.254188
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))


# Generated at 2022-06-12 12:14:50.602188
# Unit test for function match
def test_match():
    command = Command(script = 'git commit -m "test"',output = 'fatal: Not a git repository')
    assert match(command)


# Generated at 2022-06-12 12:14:53.294914
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository', '', None))
    assert match(Command('hg status', 'abort: no repository found', '', None))


# Generated at 2022-06-12 12:15:03.234810
# Unit test for function match
def test_match():
    """
    thefuck.shells.zsh.match should tell
    that the command is wrong
    """
    assert match(WrongCommand('git status', 'fatal: Not a git repository'))
    assert match(WrongCommand('hg status', 'abort: no repository found'))
    assert not match(WrongCommand('git status', 'fatal: not a git repository'))
    assert not match(WrongCommand('hg status', 'abort: not a hg repository'))
    Path('.git').touch()
    Path('.hg').touch()
    assert match(WrongCommand('git status', 'fatal: Not a git repository'))
    assert match(WrongCommand('hg status', 'abort: no repository found'))
    Path('.git').remove()
    Path('.hg').touch

# Generated at 2022-06-12 12:15:07.302831
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))
    assert not match(Command('hg commit', 'nothing changed'))


# Generated at 2022-06-12 12:15:11.801961
# Unit test for function match
def test_match():
    actual_scm = _get_actual_scm()
    script_file_name = actual_scm
    result_of_script = wrong_scm_patterns[actual_scm]
    command = Command('git sta', script_file_name, result_of_script)
    assert match(command)


# Generated at 2022-06-12 12:15:13.434640
# Unit test for function match
def test_match():
    output = 'fatal: Not a git repository'
    assert match(Command(script = 'git', output = output,))

# Generated at 2022-06-12 12:15:15.528135
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-12 12:15:19.052130
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository\n'))
    assert not match(Command('git status', ''))


# Generated at 2022-06-12 12:15:22.168012
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert match(Command('git status', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git status', 'On branch master'))


# Generated at 2022-06-12 12:15:32.132807
# Unit test for function match
def test_match():
    assert match({'output': 'fatal: Not a git repository (or any of the parent directories): .git\n', 'script_parts':['git']})
    assert match({'output': 'abort: no repository found in /home/toyg/reps/reps/jedi-vim\n', 'script_parts':['hg']})
    assert not match({'output': '', 'script_parts':['git']})
    assert not match({'output': '', 'script_parts':['hg']})
    assert not match({'output': 'fatal: Not a git repository (or any of the parent directories): .git\n', 'script_parts':['hg']})

# Generated at 2022-06-12 12:15:34.484488
# Unit test for function match
def test_match():
    assert match("git branch")
    assert not match("hg branch")
    assert not match("cvs branch")


# Generated at 2022-06-12 12:15:36.404790
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg update', 'abort: no repository found'))


# Generated at 2022-06-12 12:15:42.339478
# Unit test for function match
def test_match():
    assert match(Command('git Init'))
    assert match(Command('Hg Init'))
    assert match(Command('git status'))
    assert not match(Command('hg status'))

# Generated at 2022-06-12 12:15:44.017642
# Unit test for function match
def test_match():
    command = Command('git branch', '\nfatal: Not a git repository\n')
    assert match(command)


# Generated at 2022-06-12 12:15:46.012958
# Unit test for function match
def test_match():
    assert match(Command('hg commit', '', '', 'hg'))
    assert not match(Command('git commit', '', '', 'git'))

# Generated at 2022-06-12 12:15:52.081719
# Unit test for function match
def test_match():
    command = Command('git branch', 'fatal: Not a git repository')
    assert match(command)

    command = Command('git branch', 'verifying files')
    assert not match(command)

    command = Command('hg branch', 'abort: no repository found')
    assert match(command)

    command = Command('hg branch', 'verifying files')
    assert not match(command)


# Generated at 2022-06-12 12:15:55.688365
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))

    assert not match(Command('git status', 'error: Not a git repository'))
    assert not match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-12 12:15:57.698630
# Unit test for function match
def test_match():
    assert match(Command(script='git status'))
    assert match(Command(script='hg status'))


# Generated at 2022-06-12 12:16:02.022428
# Unit test for function match
def test_match():
    actual_scm = _get_actual_scm()
    assert match(Command('hg', 'unknown command'))
    assert match(Command('git', 'unknown command'))
    assert match(Command('git', 'unknown command', 'unknown command'))
    assert not match(Command('ls', 'unknown command'))
    assert not match(Command(actual_scm, 'unknown command'))

# Generated at 2022-06-12 12:16:03.740642
# Unit test for function match
def test_match():
    """
    Unit test for function match.
    """
    command = Command("git status", "fatal: Not a git repository")
    assert match(command)

# Generated at 2022-06-12 12:16:05.201645
# Unit test for function match
def test_match():
    assert match('git status') == True
    asser

# Generated at 2022-06-12 12:16:07.177962
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

# Generated at 2022-06-12 12:16:16.841459
# Unit test for function match
def test_match():
    assert match(Command(script='git rev-parse', output='fatal: Not a git repository'))
    assert match(Command(script='hg push', output='abort: no repository found'))
    assert not match(Command(script='git', output=''))

# Generated at 2022-06-12 12:16:23.423119
# Unit test for function match
def test_match():
    test_command_fails_git = Command('git init', wrong_scm_patterns['git'])
    test_command_pass_git = Command('git init', 'Initialized empty Git repository')
    test_command_pass_hg = Command('hg init', 'abort: repository . already exists!')

    assert match(test_command_fails_git)
    assert not match(test_command_pass_git)
    assert not match(test_command_pass_hg)


# Generated at 2022-06-12 12:16:27.059629
# Unit test for function match
def test_match():
    assert match(Command('git status', '')) is False
    assert match(Command('git status', 'fatal: Not a git repository \
(or any of the parent directories): .git'), '') is True
    assert match(Command('hg status', '')) is False
    assert match(Command('hg status', 'abort: no repository found '), '') is True
    assert match(Command('svn status', '')) is False

# Generated at 2022-06-12 12:16:31.244399
# Unit test for function match
def test_match():
    from thefuck.tests.utils import Command

    assert match(Command('git branch -a', 'fatal: Not a git repository'))
    assert match(Command('hg clone ...',
                         'abort: no repository found'))

    assert not match(Command('git branch -a',
                             'fatal: Not a git repository '
                             '(or any of the parent directories): .git'))
    assert not match(Command('hg clone ...',
                             'abort: foo repository found'))
    assert not match(Command('git', ''))
    assert not match(Command('hg', ''))



# Generated at 2022-06-12 12:16:33.875846
# Unit test for function match
def test_match():
    assert match(Command('git --version', 'fatal: Not a git repository'))
    assert match(Command('hg --version', 'abort: no repository found'))
    assert not match(Command('git --version', ''))
    assert not match(Command('hg --version', ''))

# Generated at 2022-06-12 12:16:37.741864
# Unit test for function match
def test_match():                                                                                                         
    result = match(Command(script='git', output='fatal: NOT A git repository'))
    assert(result == True)
    result = match(Command(script='git', output='fatal: git repository'))
    assert(result == False)
    result = match(Command(script='hg', output='abort: no repository found'))
    asser

# Generated at 2022-06-12 12:16:40.605225
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: Not a git repository")) == False
    assert match(Command("git status", "fatal: Not a git repository")) == False
    assert match(Command("hg branch", "abort: no repository found", "")) == False


# Generated at 2022-06-12 12:16:44.121090
# Unit test for function match
def test_match():
    assert(match(Command('lol', 'some_output')) == False)
    assert(match(Command('git', 'some_output')) == False)
    assert(match(Command('git', 'fatal: Not a git repository (or any of the parent directories): .git\n')) == True)
    assert(match(Command('hg', 'abort: no repository found (try running this command in the root of a repository)\n')) == True)



# Generated at 2022-06-12 12:16:54.080162
# Unit test for function match
def test_match():
    # This is how we mock the output of the command
    # See https://github.com/nvbn/thefuck/issues/333
    from thefuck.types import Command

    assert match(Command('git status', '''
fatal: Not a git repository (or any of the parent directories): .git
'''))
    assert not match(Command('git', ''))
    # Uncomment the next line to test with a real output
    # assert match(Command('git status', ''))
    assert not match(Command('hg status', ''))
    assert match(Command('hg status', '''
abort: no repository found in '/home' (.hg not found)!
'''))
    # Uncomment the next line to test with a real output
    # assert match(Command('hg status', ''))

# Generated at 2022-06-12 12:16:57.884636
# Unit test for function match
def test_match():
    assert match(Command("git", "fatal: Not a git repository"))
    assert not match(Command("git", "fatal: Git repository"))
    assert not match(Command("git", "fatal: Not a hg repository"))
    assert match(Command("hg", "abort: no repository found"))
    assert not match(Command("hg", "abort: no git repository found"))


# Generated at 2022-06-12 12:17:14.158458
# Unit test for function match
def test_match():
    assert match(Command('scm status', 'abort: no repository found\n'))
    assert not match(Command('git diff', 'abort: no repository found\n'))

# Generated at 2022-06-12 12:17:20.965979
# Unit test for function match
def test_match():
    output = 'fatal: Not a git repository.\n'
    assert not match(Command(script='git status', output=output))

    output = 'abort: no repository found\n'
    assert not match(Command(script='hg status', output=output))

    output = 'abcdefg\n'
    assert not match(Command(script='git status', output=output))

    output = 'abort: no repository found\n'
    assert match(Command(script='hg status', output=output))

    output = 'fatal: Not a git repository.\n'
    assert match(Command(script='git status', output=output))

# Generated at 2022-06-12 12:17:23.159811
# Unit test for function match
def test_match():
    assert match(Command('git foo', 'fatal: Not a git repository'))
    assert not match(Command('hg foo', 'abort: no repository found'))



# Generated at 2022-06-12 12:17:25.424788
# Unit test for function match
def test_match():
    command = Command('git commit',
                      'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(command)



# Generated at 2022-06-12 12:17:27.520520
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))

    assert not match(Command('git status', 'git'))


# Generated at 2022-06-12 12:17:29.935539
# Unit test for function match
def test_match():
    for key, value in wrong_scm_patterns.iteritems():
        assert match(Command(u'{} {}'.format(key, value)))

# Generated at 2022-06-12 12:17:34.744988
# Unit test for function match
def test_match():
    script = 'git status'
    command = Command(script, '/path/to/git/repo')
    command.output = 'fatal: Not a git repository'
    assert match(command)

    script = 'hg status'
    command = Command(script, '/path/to/hg/repo')
    command.output = 'abort: no repository found'
    assert match(command)


# Generated at 2022-06-12 12:17:36.790948
# Unit test for function match
def test_match():
    assert match(Command('git init', r'fatal: Not a git repository'))
    assert not match(Command('git init', r'test1'))



# Generated at 2022-06-12 12:17:39.800161
# Unit test for function match
def test_match():
    assert match(Command('git status', '/home/user'))
    assert not match(Command('ls', '/home/user'))
    assert match(Command('hg status', '/home/user'))
    assert not match(Command('ls', '/home/user'))


# Generated at 2022-06-12 12:17:44.764176
# Unit test for function match
def test_match():
    from thefuck.types import Command

    # Should not match if output does not match regex
    assert not match(Command('git status', 'gitinit\n'))

    # Should not match if there is no other scm in folder
    assert not match(Command('git status', 'fatal: Not a git repository'))

    # Should match if output matches regex and there is another scm
    assert  match(Command('git status', 'fatal: Not a git repository\n'))



# Generated at 2022-06-12 12:18:26.674367
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository\n')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg status', 'abort: no repository found')
    assert match(command)

    command = Command('foo bar', 'abort: no repository found')
    assert not match(command)

    command = Command('hg status', 'abort: no repository found\n')
    assert match(command)



# Generated at 2022-06-12 12:18:28.549343
# Unit test for function match
def test_match():
    command = Command('git ci -am "example commit"', '')
    assert match(command)

# Generated at 2022-06-12 12:18:29.618085
# Unit test for function match
def test_match():

    #TODO
    assert(False)


# Generated at 2022-06-12 12:18:35.562931
# Unit test for function match
def test_match():
    command = Command(script = 'git status')
    assert match(command) is True, 'Should be True'

    command = Command(script = 'hg status')
    assert match(command) is True, 'Should be True'

    command = Command(script = 'git status', output = 'output: fatal: Not a git repository')
    assert match(command) is True, 'Should be True'

    command = Command(script = 'hg status', output = 'output: abort: no repository found')
    assert match(command) is True, 'Should be True'

    command = Command(script = 'git status', output = 'output: no repository found')
    assert match(command) is False, 'Should be False'

    command = Command(script = 'git commit', output = 'output: fatal: Not a git repository')
    assert match(command)

# Generated at 2022-06-12 12:18:37.658079
# Unit test for function match
def test_match():
    assert(match(Command('git status', 'fatal: Not a git repository')))
    assert(not(match(Command('git status', ''))))



# Generated at 2022-06-12 12:18:41.619867
# Unit test for function match
def test_match():
    assert match(Command(script='git status',
                         stderr='fatal: Not a git repository'))
    assert match(Command(script='hg status',
                         stderr='abort: no repository found'))
    assert not match(Command(script='git status'))



# Generated at 2022-06-12 12:18:44.023567
# Unit test for function match
def test_match():
    right = u'git status'
    wrong = u'git status'
    assert match(Command(right, ''))
    assert not match(Command(wrong, ''))
    

# Generated at 2022-06-12 12:18:49.144308
# Unit test for function match
def test_match():
    from thefuck import types
    command = types.Command('git status', 'fatal: Not a git repository')
    assert match(command)
    command = types.Command('git status', 'fatal: Not a git repository yet')
    assert not match(command)
    command = types.Command('hg status', 'abort: no repository found')
    assert match(command)
    command = types.Command('hg status', 'abort: no repository found yet')
    assert not match(command)


# Generated at 2022-06-12 12:18:55.160202
# Unit test for function match
def test_match():
    assert match(Command(script='git', stderr='fatal: Not a git repository'))
    assert match(Command(script='hg', stderr='abort: no repository found'))
    assert not match(Command(script='git', stderr='fatal: Not a git repository'))
    assert not match(Command(script='hg', stderr='abort: no repository found'))
    assert not match(Command(script='svn', stderr='Error: working copy path not found'))

# Generated at 2022-06-12 12:18:57.478643
# Unit test for function match
def test_match():
    assert not match(Command('ls'))
    assert match(Command('./git.py'))
    assert match(Command('./hg.py'))


# Generated at 2022-06-12 12:20:15.688170
# Unit test for function match
def test_match():
    assert match


# Generated at 2022-06-12 12:20:17.845738
# Unit test for function match
def test_match():
    assert match(Command('git branch',
                         'fatal: Not a git repository'))
    assert match(Command('hg branch',
                         'abort: no repository found'))



# Generated at 2022-06-12 12:20:21.356107
# Unit test for function match
def test_match():
    command = Command('git status')
    assert match(command)
    command = Command('hg status')
    assert not match(command)


# Generated at 2022-06-12 12:20:24.932193
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'On branch master'))

# Generated at 2022-06-12 12:20:29.644446
# Unit test for function match
def test_match():
    command = type('Command', (object,),
                   {'output': 'fatal: Not a git repository', 'script': 'git branch'})
    assert match(command)
    command = type('Command', (object,),
                   {'output': 'abort: no repository found', 'script': 'hg branch'})
    assert match(command)
    command = type('Command', (object,),
                   {'output': 'Not a git repository', 'script': 'git branch'})
    assert not match(command)
    command = type('Command', (object,),
                   {'output': '', 'script': 'hg branch'})
    assert not match(command)



# Generated at 2022-06-12 12:20:33.781958
# Unit test for function match
def test_match():
    assert match(Command(script='git submodule update',
                         output='fatal: Not a git reository'))
    assert match(Command(script='hg branch',
                         output='abort: no repository found!'))
    assert not match(Command(script='git submodule update',
                             output='fatal: Not a repository'))

# Generated at 2022-06-12 12:20:36.832335
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'fatal: Not a git repository'))
    assert match(Command('hg add .', 'abort: no repository found'))
    assert not match(Command('git add .'))
    assert not match(Command('hg add .'))



# Generated at 2022-06-12 12:20:44.073744
# Unit test for function match
def test_match():
    # Test success and failure
    assert match(Command('git', '', 'fatal: Not a git repository')) == True
    assert match(Command('git', '', 'git status')) == False
    assert match(Command('git', '', 'git status', 'hg status')) == False
    assert match(Command('hg', '', 'abort: no repository found')) == True
    assert match(Command('hg', '', 'hg status')) == False
    assert match(Command('hg', '', 'hg status', 'git status')) == False


# Generated at 2022-06-12 12:20:48.527863
# Unit test for function match
def test_match():
    output_git = u'fatal: Not a git repository \
    (or any of the parent directories): .git'
    output_hg = u'abort: no repository found \
    (or any of the parent directories): .hg'
    assert match(Command('git status', output_git))
    assert match(Command('git status', output_hg)) is False
    assert match(Command('hg status', output_hg))
    assert match(Command('hg status', output_git)) is False


# Generated at 2022-06-12 12:20:53.899587
# Unit test for function match
def test_match():

    command = type('obj', (object,), {'script_parts': ['git', 'commit', '-a']})
    command.output = 'fatal: Not a git repository'
    assert match(command)

    command.script_parts = ['hg', 'commit', '-a']
    command.output = 'abort: no repository found'
    assert match(command)

    command.output = 'fatal: Not a git repository'
    assert match(command) == False

    command.output = 'abort: no repository found'
    assert match(command) == False

    command.output = 'Not a git repository'
    assert match(command) == False
