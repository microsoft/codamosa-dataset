

# Generated at 2022-06-12 12:11:50.137996
# Unit test for function match
def test_match():
	# Test 1
	command = Command('git merge origin/master',
					  'fatal: Not a git repository (or any of the parent directories): .git')
	assert(match(command))
	# Test 2
	command = Command('git merge origin/master',
					  'fatal: Not a git repository (or any of the parent directories): .git')
	command.script_parts = ['git', 'merge', 'origin/master']
	assert(match(command))
	# Test 3
	command = Command('git merge origin/master',
					  'fatal: Not a git repository (or any of the parent directories): .git')
	command.script_parts = ['merge', 'origin/master']
	assert(not match(command))
	# Test 4

# Generated at 2022-06-12 12:11:51.770282
# Unit test for function match
def test_match():
    assert(match('git status').script_parts[0] == 'git')

# Generated at 2022-06-12 12:11:55.030853
# Unit test for function match
def test_match():
    assert match(Command(script='git', stderr='fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command(script='git', stderr='some error'))


# Generated at 2022-06-12 12:11:59.105906
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'On branch master'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'nothing changed'))


# Generated at 2022-06-12 12:12:00.847296
# Unit test for function match
def test_match():
    assert not match(Command('git remote -v', 'fatal: Not a git repository', ''))
    assert not m

# Generated at 2022-06-12 12:12:02.403026
# Unit test for function match
def test_match():
    command = Command('hg commit', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-12 12:12:06.385649
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository')) is True
    assert match(Command('git branch', 'abort: no repository found')) is False
    assert match(Command('hg branch', 'fatal: Not a git repository')) is False
    assert match(Command('hg branch', 'abort: no repository found')) is True


# Generated at 2022-06-12 12:12:10.889523
# Unit test for function match
def test_match():
    assert match(Command('git status', wrong_scm_patterns['git']))
    assert match(Command('hg status', wrong_scm_patterns['hg']))
    assert not match(Command('git status'))
    assert not match(Command('hg status'))


# Generated at 2022-06-12 12:12:16.334959
# Unit test for function match
def test_match():
	assert not match(Command("git", "rebase -i HEAD~~"))
	assert not match(Command("hg", "commit "))
	assert match(Command("git", "commit", stderr=u"fatal: Not a git repository"))
	assert match(Command("hg", "commit", stderr=u"abort: no repository found"))

# Generated at 2022-06-12 12:12:19.201783
# Unit test for function match
def test_match():
    command = Command('git status')
    command.output = 'fatal: Not a git repository'
    assert match(command) == True
    command = Command('hg push')
    command.output = 'abort: no repository found'
    assert match(command) == True


# Generated at 2022-06-12 12:12:26.086740
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg commit -m test', 'abort: no repository found'))
    assert not match(Command('git branch', ''))
    assert not match(Command('git branch', 'git branch'))
    assert not match(Command('hg commit -m test', ''))
    assert not match(Command('hg commit -m test', 'hg commit -m test'))

# Generated at 2022-06-12 12:12:30.044798
# Unit test for function match
def test_match():
    command1 = Command("ggit pull origin master")
    assert match(command1) == False

    command2 = Command("git pull origin master", "fatal: Not a git repository")
    assert match(command2) == True

    command3 = Command("hg pull origin master", "abort: no repository found")
    assert match(command3) == True


# Generated at 2022-06-12 12:12:34.032350
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository',
                         stderr='fatal: Not a git repository'))
    assert match(Command('hg status',
                         'abort: no repository found',
                         stderr='abort: no repository found'))
    assert not match(Command('git status', ''))


# Generated at 2022-06-12 12:12:35.029585
# Unit test for function match
def test_match():
    output = 'fatal: Not a git repository'
    assert match(Command('git status', output))

# Generated at 2022-06-12 12:12:36.730583
# Unit test for function match
def test_match():
    assert match(Command('git rebase 1', 'fatal: Not a git repository'))
    assert not match(Command('git rebase 1', ''))
    assert not match(Command('hg rebase 1', ''))


# Generated at 2022-06-12 12:12:40.027168
# Unit test for function match
def test_match():
    command = Command('git config --global --remove-section user')
    command.output = 'fatal: Not a git repository'
    assert match(command)
    command.output = 'No such section!'
    assert not match(command)


# Generated at 2022-06-12 12:12:43.577366
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command('hg branch', 'default'))
    assert not match(Command('git branch', 'default'))

# Generated at 2022-06-12 12:12:45.186846
# Unit test for function match
def test_match():
    command = Command("git push master")
    assert match(command) == False


# Generated at 2022-06-12 12:12:47.876105
# Unit test for function match
def test_match():
    command = Command('git push')
    assert match(command)
    command = Command('git push origin master')
    assert match(command)
    command = Command('git push origin master --force')
    assert match(command)


# Generated at 2022-06-12 12:12:56.393690
# Unit test for function match
def test_match():
    assert match(Command('git remote -v', 'fatal: Not a git repository'))
    assert match(Command('git add', 'fatal: Not a git repository'))
    assert match(Command('git commit', 'fatal: Not a git repository'))
    assert match(Command('git init', 'fatal: Not a git repository'))

    assert match(Command('hg add', 'abort: no repository found'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert match(Command('hg init', 'abort: no repository found'))



# Generated at 2022-06-12 12:13:05.293187
# Unit test for function match
def test_match():
    # git command in git repository
    assert match(Command(script='git branch')) == False
    # git command in hg repository
    assert match(Command(script='git branch', output=wrong_scm_patterns['git'])) == True
    # hg command in git repository
    assert match(Command(script='hg branch', output=wrong_scm_patterns['hg'])) == True
    # hg command in hg repository
    assert match(Command(script='hg branch')) == False


# Generated at 2022-06-12 12:13:10.240370
# Unit test for function match
def test_match():
    # Expected to fail
    assert not match(Command(script="git branch",
                             output="fatal: Not a git repository"))
    assert not match(Command(script="git branch",
                             output="fatal: Not a git repository"))
    assert not match(Command(script="git branch",
                             output="abort: no repository found"))

    # Expected to pass
    assert match(Command(script="git branch",
                         output="fatal: Not a git repository"))
    assert match(Command(script="hg branch",
                         output="abort: no repository found"))



# Generated at 2022-06-12 12:13:12.807313
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)
    command = Command('git status', '')
    assert not match(command)


# Generated at 2022-06-12 12:13:16.501072
# Unit test for function match
def test_match():
    if not match(Command("git pull origin master", "fatal: Not a git repository", "")) and match(Command("hg pull origin master", "abort: no repository found", "")):
        print("Unit test match: OK")
    else:
        print("Unit test match: FAILURE")


# Generated at 2022-06-12 12:13:18.942603
# Unit test for function match
def test_match():
    script = Command('git commit -a')
    assert match(script) == False

    script = Command(wrong_scm_patterns['git'])
    assert match(script) == True


# Generated at 2022-06-12 12:13:20.849132
# Unit test for function match
def test_match():
    assert match(Script('git branch'))
    assert not match(Script('hg branch'))
    assert match(Script('git branch', None))


# Generated at 2022-06-12 12:13:22.690626
# Unit test for function match
def test_match():
    assert match(u'git checkout master')
    assert not match(u'hg checkout master')

# Generated at 2022-06-12 12:13:26.232972
# Unit test for function match
def test_match():
    assert match(Command('git comment', 'fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git comment', ''))


# Generated at 2022-06-12 12:13:28.869098
# Unit test for function match
def test_match():
    try:
        os.makedirs('.git')
    except:
        pass
    assert match('git status')
    # os.removedirs('.git')
    # assert match('git status') == False

# Generated at 2022-06-12 12:13:30.447339
# Unit test for function match
def test_match():
    assert not match(Command("git status"))
    assert not match(Command("hg status"))


# Generated at 2022-06-12 12:13:37.052420
# Unit test for function match
def test_match():
	assert match(Command("git commit -m \"fix bug\"", "fatal: Not a git repository (or any of the parent directories): .git", None))
	assert not match(Command("hg commit -m \"fix bug\"", "abort: no repository found", None))

# Generated at 2022-06-12 12:13:39.396363
# Unit test for function match
def test_match():
    from thefuck.types import Command
    command = Command('git branch', 'fatal: Not a git repository (or any of the parent directories): .git', '')
    assert match(command)



# Generated at 2022-06-12 12:13:40.726688
# Unit test for function match
def test_match():
    command = Command('hg status', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-12 12:13:49.878090
# Unit test for function match
def test_match():
    # Git works in a Git repository
    assert not match(Command('git status',
                            'On branch master',
                            ''))
    # Hg works in a Hg repository
    assert not match(Command('hg status',
                            '',
                            ''))
    # Git works in a Git repository with warnings
    assert not match(Command('git status',
                            'warning: whatever',
                            'On branch master'))
    # Git does not work in a Hg repository
    assert match(Command('git status',
                        'fatal: Not a git repository',
                        ''))
    # Hg does not work in a Git repository
    assert match(Command('hg status',
                        'abort: no repository found',
                        ''))


# Generated at 2022-06-12 12:13:52.378640
# Unit test for function match
def test_match():
    assert match(Command('git commit', 'fatal: Not a git repository'))
    assert not match(Command('git init', 'Existing Git repository'))



# Generated at 2022-06-12 12:13:54.561993
# Unit test for function match
def test_match():
    command = Command(script = "git push origin master")
    assert not match(command)
    command = Command(script = "git push origin master", output = "fatal: Not a git repository")
    assert match(command)


# Generated at 2022-06-12 12:13:58.544670
# Unit test for function match
def test_match():
    command = Command('git status foo', 'fatal: Not a git repository')
    assert match(command)

    command = Command('hg status foo', 'abort: no repository found')
    assert match(command)

    command = Command('git status', 'fatal: Not a git repository')
    assert not match(command)

    command = Command('hg status', 'abort: no repository found')
    assert not match(command)


# Generated at 2022-06-12 12:14:04.755296
# Unit test for function match
def test_match():
    # Unit test for function match
    assert match(Command('git status', '',
        wrong_scm_patterns['git'])) is True
    assert match(Command('hg status', '',
        wrong_scm_patterns['hg'])) is True
    assert match(Command('svn status', '',
        'abort: no repository found')) is False


# Generated at 2022-06-12 12:14:09.047522
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert match(Command('hg branch', 'abort: no repository found'))
    assert not match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command('hg branch', 'abort: no repository found'))

# Generated at 2022-06-12 12:14:10.780166
# Unit test for function match
def test_match():
    assert match(Command('git', '', 'fatal: Not a git repository'))



# Generated at 2022-06-12 12:14:20.459746
# Unit test for function match
def test_match():
    output = 'fatal: Not a git repository'
    assert match(Command('git init', output))
    assert not match(Command('git init', 'Initialized empty Git repository'))

    output = 'abort: no repository found'
    assert match(Command('hg init', output))
    assert not match(Command('hg init', 'initial repository state'))


# Generated at 2022-06-12 12:14:22.995789
# Unit test for function match
def test_match():
    command = Command('git status')
    command.output = wrong_scm_patterns['git']
    assert match(command)
    assert get_new_command(command) == 'hg status'

# Generated at 2022-06-12 12:14:24.312835
# Unit test for function match
def test_match():
    command = Command('git stash')
    assert match(command)


# Generated at 2022-06-12 12:14:25.765596
# Unit test for function match
def test_match():
    assert match('git') == False
    assert match('hg') == False

# Generated at 2022-06-12 12:14:27.521147
# Unit test for function match
def test_match():
    command = Command("git status", "fatal: Not a git repository")
    assert match(command)



# Generated at 2022-06-12 12:14:31.470932
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"', 'fatal: Not a git repository'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert not match(Command('git status', ''))



# Generated at 2022-06-12 12:14:34.941989
# Unit test for function match
def test_match():
    # Test for git
    command = Command('git log', 'fatal: Not a git repository')
    assert match(command)
    # Test for hg
    command = Command('hg log', 'abort: no repository found')
    assert match(command)



# Generated at 2022-06-12 12:14:40.201303
# Unit test for function match
def test_match():
    wrong_git_command = Command('git status')
    wrong_git_command.output = \
        u'fatal: Not a git repository (or any of the parent directories): .git'

    wrong_hg_command = Command('hg status')
    wrong_hg_command.output = \
        u'abort: no repository found in /path/to/repo/.hg (try running ' \
        u'`hg debuginstall`)'

    assert match(wrong_git_command)
    assert not match(wrong_hg_command)

# Generated at 2022-06-12 12:14:42.035162
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert not match(Command('hg status', ''))



# Generated at 2022-06-12 12:14:42.875363
# Unit test for function match

# Generated at 2022-06-12 12:14:56.081722
# Unit test for function match
def test_match():
    command = Command('git commit .', 'fatal: Not a git repository')
    command_hg = Command('hg add .', 'abort: no repository found')
    command_wrong = Command('hg add .', 'abort')
    f = match(command)
    f_hg = match(command_hg)
    f_wrong = match(command_wrong)
    assert f is True
    assert f_hg is True
    assert f_wrong is False



# Generated at 2022-06-12 12:15:01.628594
# Unit test for function match
def test_match():
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert not match(Command('git', '', 'fatal: Not a git repository',
                             'fatal: Not a git repository'))
    assert match(Command('hg', '', 'abort: no repository found'))
    assert not match(Command('hg', '', 'abort: no repository found',
                             'abort: no repository found'))



# Generated at 2022-06-12 12:15:06.045997
# Unit test for function match
def test_match():

    from mock import Mock
    command = Mock(output='fatal: Not a git repository')
    command.script_parts = ['git', 'push']
    assert match(command)

    command = Mock(output='abort: no repository found')
    command.script_parts = ['hg', 'push']
    assert match(command)

# Generated at 2022-06-12 12:15:09.986235
# Unit test for function match
def test_match():
    command = Command(script='git status', output='fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command) == True
    command = Command(script='git status', output='fatal: no repository found')
    assert match(command) == False

# Generated at 2022-06-12 12:15:14.756587
# Unit test for function match
def test_match():
    assert not match(Command('git status'))
    assert match(Command('git status', 'nothing to commit, working directory clean'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('hg status', 'nothing to commit, working directory clean'))
    assert match(Command('hg status', 'abort: no repository found'))


# Generated at 2022-06-12 12:15:20.500556
# Unit test for function match
def test_match():
    # Test current invalid command
    assert _get_actual_scm() == 'git'
    assert match(Command('git status', ''))
    
    # Test current invalid command
    assert _get_actual_scm() == 'git'
    assert match(Command('git status', 'fatal: Not a git repository'))
    
    # Test current valid command
    assert _get_actual_scm() == 'git'
    assert not match(Command('git status', 'On branch master'))
    
    # Test with invalid scm
    assert _get_actual_scm() == 'git'
    assert match(Command('hg status', ''))
    
    

# Generated at 2022-06-12 12:15:30.716635
# Unit test for function match
def test_match():
    assert match(Command("git foo", "fatal: Not a git repository"))
    assert match(Command("hg foo", "abort: no repository found"))
    assert not match(Command("git foo", "fatal: Hello repository"))
    assert not match(Command("git foo", "fatal: Hello repository", "Hello repository"))
    assert not match(Command("git foo", "Not a git repository"))
    assert not match(Command("hg foo", "no repository found"))
    assert not match(Command("hg foo", "Hello repository"))
    assert not match(Command("hg foo", "Hello repository", "Hello repository"))
    assert not match(Command("git foo", "fatal: Not a hg repository"))
    assert not match(Command("hg foo", "abort: Not a git repository"))



# Generated at 2022-06-12 12:15:35.203057
# Unit test for function match
def test_match():
    assert not match(Command('git status', '', ''))
    assert not match(Command('git status', 'fatal: Not a git repository', ''))

    assert match(Command('git status', 'fatal: Not a git repository', ''))
    assert match(Command('hg status', 'abort: no repository found', ''))



# Generated at 2022-06-12 12:15:36.986861
# Unit test for function match
def test_match():
    assert match(Command('git stash', wrong_scm_patterns['git']))
    assert not match(Command('hg log 5', 'asd'))


# Generated at 2022-06-12 12:15:40.796111
# Unit test for function match
def test_match():
    types_of_scm = {
        'git': 'git status',
        'hg': 'hg status'
    }
    for type_of_scm in types_of_scm:
        command = Command('{}'.format(types_of_scm[type_of_scm]), None)
        assert match(command)

# Generated at 2022-06-12 12:15:57.677153
# Unit test for function match
def test_match():
    thefuck.conf.settings.wrong_scm_patterns = wrong_scm_patterns
    assert match(Command('git', '', 'fatal: Not a git repository'))
    assert not match(Command('hg', '', ''))

# Generated at 2022-06-12 12:15:59.595592
# Unit test for function match
def test_match():
    test_pattern = 'fatal: Not a git repository'
    command = Command(command=test_pattern)
    assert match(command)


# Generated at 2022-06-12 12:16:05.949622
# Unit test for function match
def test_match():
    """match should detect all scms except the current one,
    and if the current one is in the output it should return False
    """
    assert match(Command('git status', 'fatal: Not a git repository')) == False
    assert match(Command('git status', 'abort: no repository found')) == False
    assert match(Command('git status', 'no repositorium')) == False
    assert match(Command('git status', 'git fatal: No repository')) == False
    assert match(Command('hg status', 'fatal: Not a git repository')) == False
    assert match(Command('hg status', 'abort: no repository found')) == False
    assert match(Command('hg status', 'no repositorium')) == False
    assert match(Command('hg status', 'git fatal: No repository'))

# Generated at 2022-06-12 12:16:13.015175
# Unit test for function match
def test_match():
    command_git = Command('git status',
                          'fatal: Not a git repository')
    command_hg = Command('hg status',
                         'abort: no repository found')
    command_git_hg = Command('git status',
                             'fatal: Not a git repository')
    command_git_hg.environment['HGRCPATH'] = '~/.hgrc'

    assert match(command_git) == True
    assert match(command_hg) == False
    assert match(command_git_hg) == True


# Generated at 2022-06-12 12:16:15.811674
# Unit test for function match
def test_match():
    command1 = Command('git add .', '')
    command2 = Command('hg commit -m "test code"', '')

    assert match(command1)
    assert match(command2)

# Generated at 2022-06-12 12:16:23.242250
# Unit test for function match
def test_match():
    # Test when no scm repository is found in current directory
    command = Command('hg add main.py', 'abort: no repository found')
    assert match(command)

    command = Command('git add main.py', 'fatal: Not a git repository')
    assert match(command)

    # Test when wrong scm command is executed in current directory
    command = Command('hg add main.py', '')
    assert not match(command)

    # Test when no scm command is executed in current directory
    command = Command('ls', '')
    assert not match(command)



# Generated at 2022-06-12 12:16:24.903805
# Unit test for function match
def test_match():
    command = Command('git status', 'fatal: Not a git repository')
    assert match(command)



# Generated at 2022-06-12 12:16:29.481710
# Unit test for function match
def test_match():
    assert match(Command('git pull origin master', 'fatal: Not a git repository'))
    assert match(Command('hg push origin master', 'abort: no repository found'))
    assert not match(Command('git push origin master', 'fatal: Not a git repository'))
    assert not match(Command('hg pull origin master', 'abort: no repository found'))



# Generated at 2022-06-12 12:16:32.941455
# Unit test for function match
def test_match():
    command = 'git status'
    commandout = "fatal: Not a git repository (or any of the parent directories): .git"
    assert match(Command(command, commandout)) == False

    command = 'git status'
    commandout = "fatal: Not a git repository (or any of the parent directories): .git"
    assert match(Command(command, commandout))


# Generated at 2022-06-12 12:16:36.147013
# Unit test for function match
def test_match():
    assert match(Command("git status"))
    assert match(Command("git status", "fatal: Not a git repository"))
    assert not match(Command("git status", "On branch master"))
    assert not match(Command("git status", "fatal: Not a git repository", "On branch master"))



# Generated at 2022-06-12 12:16:56.583321
# Unit test for function match
def test_match():
    assert match(Command('gitk', '', 'fatal: Not a git repository: .'))
    assert match(Command('hg log', '', 'abort: no repository found'))
    assert not match(Command('gitk', '', 'Not a git repository'))
    assert not match(Command('gitk', '', 'Not a git repository: .'))
    assert not match(Command('gitk', '', 'not a git repository'))
    assert not match(Command('gitk', '', 'not a git repository.\nfatal: Not a git repository: .'))
    assert not match(Command('hg log', '', 'Not a git repository'))
    assert not match(Command('hg log', '', 'Not a git repository: .'))

# Generated at 2022-06-12 12:16:58.151110
# Unit test for function match
def test_match():
    assert match(u'git status')
    assert match(u'hg status')

# Generated at 2022-06-12 12:17:01.822375
# Unit test for function match
def test_match():
    for_app(*wrong_scm_patterns.keys())(match)
    assert match(Command('git commit', (u'fatal: Not a git repository', u'')))
    assert not match(Command('git commit', (u'', u'')))
    assert not match(Command('hg commit', (u'', u'')))

# Generated at 2022-06-12 12:17:03.059115
# Unit test for function match
def test_match():
    assert match(Command('git commit', 'fatal: Not a git repository'))



# Generated at 2022-06-12 12:17:08.975251
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository', 'sadg'))
    assert not match(Command('hg status', 'abort: no repository found', 'sadg'))
    assert not match(Command('git status', 'fatal: sadg'))
    assert not match(Command('hg status', 'abort: sadg'))



# Generated at 2022-06-12 12:17:16.294240
# Unit test for function match
def test_match():
    assert not match(Command('git status', ''))
    assert not match(Command('git status', 'fatal: no'))
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository (or any'
                         ' of the parent directories): .git'))
    assert not match(Command('hg status', ''))
    assert not match(Command('hg status', 'abort: no repository found'))
    assert match(Command('hg status', 'abort: no repository found'
                         ' (.hg not found in /path/to/repo)'))



# Generated at 2022-06-12 12:17:18.206261
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git branch', 'abort: no repository found'))



# Generated at 2022-06-12 12:17:23.331035
# Unit test for function match
def test_match():
    cmd = Command('hg status', '/usr/local/bin/hg')
    assert not match(cmd)
    cmd = Command('git status', '/usr/local/bin/git')
    assert not match(cmd)

    cmd = Command('git status', '/usr/local/bin/git', 'fatal: Not a git repository')
    assert match(cmd)
    cmd = Command('hg status', '/usr/local/bin/hg', 'abort: no repository found')
    assert match(cmd)


# Generated at 2022-06-12 12:17:27.177579
# Unit test for function match
def test_match():
    assert match(Script('git status', 'fatal: Not a git repository', None))
    assert not match(Script('git status', 'master', None))
    assert not match(Script('hg diff', 'abort: no repository found', None))
    assert not match(Script('hg status', 'my_branch', None))


# Generated at 2022-06-12 12:17:36.103156
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git repository\n'))
    assert match(Command('git status', 'fatal: Not a git repository (or any of'))
    assert match(Command('hg status', 'abort: no repository found'))
    assert not match(Command('hg status', 'abort: no repository found\n'))
    assert not match(Command('hg status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'abort: no repository found'))
    assert not match(Command('git status', 'fatal: Not a git repository\nabort: no repository found\n'))


# Generated at 2022-06-12 12:18:12.839279
# Unit test for function match
def test_match():
    assert match(Command('git status', '', 'fatal: Not a git repository'))
    assert match(Command('hg st', '', 'abort: no repository found'))

# Generated at 2022-06-12 12:18:21.762271
# Unit test for function match
def test_match():
    command1 = Command('git branch', '', '')
    command2 = Command('git branch', '', '')
    command3 = Command('git branch', '', '')
    assert (not match(command1)
            and not match(command2)
            and not match(command3))

    command4 = Command('git branch', '', '')
    command5 = Command('git branch', '', '')
    command6 = Command('git branch', '', '')
    assert (not match(command4)
            and not match(command5)
            and not match(command6))

    command7 = Command('git branch', '', '')
    command8 = Command('git branch', '', '')
    command9 = Command('git branch', '', '')

# Generated at 2022-06-12 12:18:23.481766
# Unit test for function match
def test_match():
    """Unit test

    for function match
    """
    assert match('git not_a_repo/')



# Generated at 2022-06-12 12:18:30.357354
# Unit test for function match
def test_match():
    command = Command('git status', r'fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)

    command = Command('git status', r'abort: no repository found')
    assert not match(command)

    command = Command('hg status', r'fatal: Not a git repository (or any of the parent directories): .git')
    assert not match(command)

    command = Command('hg status', r'abort: no repository found')
    assert match(command)



# Generated at 2022-06-12 12:18:32.677846
# Unit test for function match
def test_match():
    assert match(Command('hg status', 'abort: no repository found !\n'))
    assert match(Command('git status', 'fatal: Not a git repository\n'))
    assert not match(Command('git status', 'fatal : Not a git repository\n'))



# Generated at 2022-06-12 12:18:38.802861
# Unit test for function match
def test_match():
    output = 'foo: command not found'
    scm = 'git'

    assert not match(Command(scm, output))

    output = 'fatal: Not a git repository'
    scm = 'git'

    assert match(Command(scm, output))

    output='foo: command not found'
    scm = 'hg'

    assert not match(Command(scm, output))

    output='abort: no repository found'
    scm = 'hg'

    assert match(Command(scm, output))


# Generated at 2022-06-12 12:18:43.264464
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('git status', 'fatal: Not a git reposito'))
    assert match(Command('hg status', 'abort: no repository found'))

    assert not match(Command('git status', 'abort: no repository found'))

# Generated at 2022-06-12 12:18:46.823779
# Unit test for function match
def test_match():
    wrong_command = Command('git branch', 'fatal: Not a git repository')
    assert match(wrong_command)
    wrong_command = Command('git branch', 'abort: no repository found')
    assert not match(wrong_command)



# Generated at 2022-06-12 12:18:49.843715
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert match(Command('hg commit', 'abort: no repository found'))
    assert not match(Command('git commit', 'fatal: Not a git repository'))


# Generated at 2022-06-12 12:18:52.222439
# Unit test for function match
def test_match():
    wrong_command = Command('git status',
                            'fatal: Not a git repository (or any of the parent directories): .git\n')
    assert match(wrong_command)


# Generated at 2022-06-12 12:20:13.981077
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('git branch',
                         u'fatal: Not a git repository'))
    assert match(Command('hg log',
                         u'abort: no repository found'))
    assert not match(Command('git branch',
                             u'fatal: Not a hg repository'))
    assert not match(Command('hg log',
                             u'abort: no hg repository found'))


# Generated at 2022-06-12 12:20:16.756895
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: Not a git repository',
                         path='.'))

    assert match(Command('hg status',
                         'abort: no repository found',
                         path='.'))



# Generated at 2022-06-12 12:20:19.353559
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: Not a git repository'))
    assert not match(Command('git branch', ''))
    assert not match(Command('git branch'))
    assert not match(Command('svn branch', 'svn: E155004: '/' is not a working copy'))



# Generated at 2022-06-12 12:20:25.516871
# Unit test for function match
def test_match():
    assert match(Command('git status', 'fatal: Not a git repository'))
    assert not match(Command('git status', 'git status'))
    assert not match(Command('ls', 'abort: no repository found'))
    assert not match(Command('ls', 'ls'))


# Generated at 2022-06-12 12:20:27.052025
# Unit test for function match
def test_match():
    command = Command('not a git repository', 'something')
    match(command)
    assert match(command)


# Generated at 2022-06-12 12:20:29.633632
# Unit test for function match
def test_match():
    assert match(Command('git merge'))
    assert not match(Command('hg merge'))
    

# Generated at 2022-06-12 12:20:33.465153
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git status', 'fatal: Not a git repository', stderr=True))
    assert not match(Command('git status', 'fatal: Not a git repository\nusage: git ...', stderr=True))
    


# Generated at 2022-06-12 12:20:35.140428
# Unit test for function match
def test_match():
    command = Command("git status", "fatal: Not a git repository (or any of the parent directories): .git\n")
    assert match(command)

# Generated at 2022-06-12 12:20:38.943156
# Unit test for function match
def test_match():
    output = "fatal: Not a git repository"
    script = "git add ."
    versions = {'git': '2.0.0', 'hg': '1.0.0'}
    command = Command(script, output, 'git', versions, '', '')

    assert match(command)


# Generated at 2022-06-12 12:20:41.936145
# Unit test for function match
def test_match():
    assert match('git branch -a') == True
    assert match('hg branch -a') == False
    assert match('hg branch -a') == False
