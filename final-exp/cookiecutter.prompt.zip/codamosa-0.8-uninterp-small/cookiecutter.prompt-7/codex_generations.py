

# Generated at 2022-06-25 15:22:13.694084
# Unit test for function process_json
def test_process_json():
    assert process_json('{"_": "a", "b": "2", "c": ["a", "1"], "d": {"a": "1"}}') == OrderedDict([('_', 'a'), ('b', '2'), ('c', ['a', '1']), ('d', OrderedDict([('a', '1')]))])



# Generated at 2022-06-25 15:22:16.852402
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict("var_0", {}) == {}
    assert read_user_dict("var_1", {'a':'b', 'c':'d'}) == {'a':'b', 'c':'d'}


# Generated at 2022-06-25 15:22:23.210608
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:22:30.337669
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Arrange
    context = {'cookiecutter': {'full_name': 'Your name', 'project_name': 'Your project name'}}
    no_input = False

    # Act
    result = prompt_for_config(context, no_input)

    # Assert
    assert result['full_name'] == 'Your name'



# Generated at 2022-06-25 15:22:42.318594
# Unit test for function read_user_dict

# Generated at 2022-06-25 15:22:51.929231
# Unit test for function prompt_for_config
def test_prompt_for_config():
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['__project_slug__'] = 'Project Slug'
    dict_0['cookiecutter']['__project_name__'] = 'Project Name'
    dict_1 = dict()
    dict_1['cookiecutter'] = dict()
    dict_1['cookiecutter']['__project_slug__'] = ''
    dict_1['cookiecutter']['__project_name__'] = ''
    dict_1['cookiecutter'] = dict_0['cookiecutter']
    dict_0 = dict_1
    dict_0['cookiecutter']['__project_slug__'] = 'Project Slug'
    dict_0['cookiecutter']['__project_name__']

# Generated at 2022-06-25 15:22:57.261955
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'description': 'TODO',
            'project_name': 'TODO',
        }
    }
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict == {'description': 'TODO', 'project_name': 'TODO'}


if __name__ == '__main__':
    test_prompt_for_config()
    test_case_0()

# Generated at 2022-06-25 15:23:09.521278
# Unit test for function prompt_for_config
def test_prompt_for_config():
    config = {
        "cookiecutter": {
            "full_name": "Firstname Lastname",
            "email": "user@example.com",
            "project_title": "Title of the Project",
            "project_slug": "project-slug",
            "project_short_description": "An awesome project.",
            "version": "0.0.1",
            "open": True,
            "continuous_integration": "travis",
            "other_ci": "",
            "_template": "https://github.com/pydanny/cookiecutter-djangopackage.git",
            "__version__": "1.0.0"
        }
    }
    result = prompt_for_config(config,no_input=True)

# Generated at 2022-06-25 15:23:18.916723
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'example_project_name',
            'project_slug': 'example_project_slug',
            'project_short_description': 'example_project_short_description',
            'project_license': 'example_project_license',
            'author_name': 'example_author_name',
            'email': 'example_email',
            'domain_name': 'example_domain_name',
        }
    }
    no_input = False
    cookiecutter_dict = prompt_for_config(context, no_input)

# Generated at 2022-06-25 15:23:26.672026
# Unit test for function render_variable
def test_render_variable():
    # create sum-template
    template = '{{"{{ cookiecutter.first }}"}}'
    # create dicts for rendering
    cookiecutter_dict = OrderedDict([('first', 'First Name')])
    context = {'cookiecutter': cookiecutter_dict}

    # create env for rendering
    env = StrictEnvironment(context=context)

    # get rendered result
    result = render_variable(env, template, cookiecutter_dict)
    expected_result = 'First Name'

    assert result == expected_result



# Generated at 2022-06-25 15:23:43.380262
# Unit test for function read_user_dict
def test_read_user_dict():
    var_0 = "Cookiecutter"
    var_1 = {
        "__0": "context",
        "__1": "in",
        "project_name": "Cookie"
    }
    # Please see https://click.palletsprojects.com/en/7.x/api/#click.prompt
    var_2 = read_user_dict(var_0, var_1)
    var_3 = "Cookiecutter"
    # Test for equality
    assert var_0 == var_3
    var_4 = "__0"
    var_5 = "__1"
    var_6 = "project_name"
    var_7 = "context"
    var_8 = "in"
    var_9 = "Cookie"
    # Test for equality
    assert var_4 == var_

# Generated at 2022-06-25 15:23:53.725748
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Import modules needed for test
    from cookiecutter.main import get_user_config
    from cookiecutter.utils import make_sure_path_exists

    # Prepare for testing
    user_config_path = make_sure_path_exists('~/.cookiecutterrc')

# Generated at 2022-06-25 15:24:01.944930
# Unit test for function read_user_dict
def test_read_user_dict():
    var_0 = 'var_0'
    var_1 = {'project_name': 'project_name'}
    var_0 = read_user_dict(var_0, var_1)
    print(var_0)


# Generated at 2022-06-25 15:24:12.990133
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:19.189670
# Unit test for function process_json
def test_process_json():
    assert process_json("{}") == {}
    with pytest.raises(click.UsageError):
        process_json("")
    with pytest.raises(click.UsageError):
        process_json("NotJson")
    with pytest.raises(click.UsageError):
        process_json(1)

# Generated at 2022-06-25 15:24:22.981167
# Unit test for function read_user_dict
def test_read_user_dict():
    cookiecutter_context = {"cookiecutter": {"dict_0": {}}}
    default_dict = {"key_0":"value_0"}
    dict_0 = read_user_dict("dict_0", default_dict)


# Generated at 2022-06-25 15:24:32.808487
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:41.083061
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:47.189221
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:49.597198
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'key': True}}
    assert prompt_for_config(context, no_input=True) == {'key': True}



# Generated at 2022-06-25 15:25:02.330328
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test case 0
    dict_0 = {'0': 1, '1': 2, '2': 3}
    dict_1 = read_user_dict('dict_0', dict_0)
    dict_2 = {'0': 1, '1': 2, '2': 3}
    if dict_1 == dict_2:
        print("Test case 0 passed")
    else:
        print("Test case 0 failed")


# Generated at 2022-06-25 15:25:04.523274
# Unit test for function process_json
def test_process_json():
    user_value = '{"a": 1, "foo": "bar", "test": true, "qux": null}'
    print(process_json(user_value))



# Generated at 2022-06-25 15:25:10.856568
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test that a TypeError is raised if default_value is not a dict.
    default_value_0 = [1, 2, 3, 4]

    try:
        read_user_dict('var_name_0', default_value_0)
    except TypeError:
        pass
    else:
        raise Exception('read_user_dict didn\'t raise TypeError')


# Generated at 2022-06-25 15:25:16.298196
# Unit test for function read_user_choice
def test_read_user_choice():
    """
    Test for function read_user_choice
    :return:
    """
    var_name = 'Requirements file'
    options = ['requirements.txt', 'requirements-dev.txt', 'No requirements file']
    default_value = 'requirements.txt'
    result = read_user_choice(var_name, options)
    assert result == default_value


# Generated at 2022-06-25 15:25:22.717918
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = {}
    dict_0['a'] = '1'
    dict_0['b'] = '2'
    dict_0['c'] = '3'

    dict_1 = read_user_dict('a', dict_0)
    dict_1['a'] = '4'
    dict_1['b'] = '5'
    dict_1['c'] = '6'

    assert dict_1 == dict_0

if __name__ == '__main__':
    test_case_0()
    test_read_user_dict()

# Generated at 2022-06-25 15:25:25.426842
# Unit test for function read_user_dict
def test_read_user_dict():

    # Initialization
    try:
        with open(str_0, 'r') as input_file:
            dict_0 = json.load(input_file)
    except FileNotFoundError:
        print('File {} not found'.format(str_0))



# Generated at 2022-06-25 15:25:33.153733
# Unit test for function read_user_dict
def test_read_user_dict():
    test_dict_0 = read_user_dict("test_dict", {"test_dict_1": "test_dict_value_1"})

    test_dict_1 = read_user_dict("test_dict", {})

    print("test_dict_value_1: " + test_dict_0["test_dict_1"])
    print("test_dict_1: " + str(test_dict_1))


# Generated at 2022-06-25 15:25:41.820999
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:25:48.813742
# Unit test for function process_json
def test_process_json():
    # initialize input and output variables, and call function
    user_value = '{"fruit": "apple", "vegetable": "carrot"}'
    user_dict = process_json(user_value)
    # assert output is expected
    expected_out =OrderedDict([('fruit', 'apple'), ('vegetable', 'carrot')])
    assert(user_dict == expected_out)

    # initialize input and output variables, and call function
    user_value = '{"fruit": "apple", "vegetable" ["carrot"]}'
    user_dict = process_json(user_value)
    # assert output is expected
    expected_out = None
    assert(expected_out == user_dict)


# Generated at 2022-06-25 15:25:58.792001
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict([
        ('cookiecutter', OrderedDict([
            ('full_name', 'Rafael M. P. Dias'),
            ('email', 'rafael@example.com'),
            ('github_username', 'rafaelmrdias'),
            ('project_name', 'test_project'),
            ('project_slug', 'test_project'),
            ('repo_name', 'test-project'),
            ('project_short_description', 'test_project'),
            ('version', '0.1.0'),
            ('release', '0.1.0'),
            ('year', '2019'),
        ]))
    ])
    # os.environ['COOKIECUTTER_NO_INPUT'] = '1'

# Generated at 2022-06-25 15:26:14.365009
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """ Unit test for function prompt_for_config. """
    def generate_context(root_dir):
        from jinja2 import Environment, FileSystemLoader
        from cookiecutter.utils import rmtree
        from cookiecutter.utils import work_in

        from cookiecutter.config import DEFAULT_CONFIG
        from cookiecutter.main import cookiecutter

        template_dir = root_dir.strpath
        output_dir = root_dir.strpath + '-output'


# Generated at 2022-06-25 15:26:23.738840
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:26:26.757634
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('test_1', {'test_2': 'test_3'}) == {'test_2': 'test_3'}


# Generated at 2022-06-25 15:26:30.429646
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'example',
            'email': 'me@example.com'
        }
    }

    cookiecutter_dict = prompt_for_config(context)

test_prompt_for_config()

# Generated at 2022-06-25 15:26:34.470502
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context='context')
    no_input = False
    context = {}
    assert prompt_for_config(context, no_input) == cookiecutter_dict
    assert prompt_for_config(context, no_input)['cookiecutter'] == env


# Generated at 2022-06-25 15:26:46.395126
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:26:52.951284
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:27:04.051423
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_context = {'cookiecutter': {'_template': '~/.cookiecutterrc',
                                  'author_email': 'somethin@somewhere.com',
                                  'author_name': 'A. N. Author',
                                  'project_name': '{{ cookiecutter.author_name }}'}}
    test_prompt_for_config = prompt_for_config(test_context, no_input=True)
    assert test_prompt_for_config == {'_template': '~/.cookiecutterrc',
                                      'author_email': 'somethin@somewhere.com',
                                      'author_name': 'A. N. Author',
                                      'project_name': '{{ cookiecutter.author_name }}'}, "test failed"


# Generated at 2022-06-25 15:27:07.995907
# Unit test for function read_user_choice
def test_read_user_choice():
    options = [
        "master",
        "develop",
        "other"
    ]
    var_name = "branch"
    assert read_user_choice(var_name, options) in ["master", "develop", "other"]


# Generated at 2022-06-25 15:27:13.734678
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'name': 'Test name',
            'version': '0.1.0',
            'description': 'Test description',
            'author': 'Test author',
            'author_email': 'author@example.org',
            'url': 'https://github.com',
            'license': 'MIT',
            'plugins': 'plugin',
            'license': 'MIT',
            'bug_report_contact_email': 'author@example.org',
        },
        'project': {'name': 'test-name'},
    }
    #no_input = False
    #cookiecutter_dict = prompt_for_config(context, no_input)
    #print(cookiecutter_dict)



# Generated at 2022-06-25 15:27:25.472732
# Unit test for function read_user_dict

# Generated at 2022-06-25 15:27:35.995546
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Creating a mock context (cookiecutter.json) file
    cookiecutter_context = \
        {
            "cookiecutter": {
                "project_name": "Top level project",
                "repo_name": "test_repo"
            }
        }

    # Note: no input flag is False by default
    test_prompts = prompt_for_config(cookiecutter_context)

    # Asserting that the prompt output is a dictionary
    assert isinstance(test_prompts, dict), "prompt_for_config did not return \
    a dictionary"
    print("Prompt_for_config test passed")



# Generated at 2022-06-25 15:27:38.585662
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test function prompt_for_config"""
    context = {'cookiecutter': {}}
    cookiecutter_dict = prompt_for_config(context, False)
    return cookiecutter_dict

# Generated at 2022-06-25 15:27:47.784593
# Unit test for function process_json
def test_process_json():
    user_value_0 = '''{
 "replay": true,
 "username": "{{ cookiecutter.full_name }}",
 "email": "{{ cookiecutter.email }}",
 "name": "".join(re.split("[^a-zA-Z]*", "{{ cookiecutter.project_name }}")).lower(),
 "pypi_username": "",
 "pypi_password": "",
 "github_token": "",
 "repo_name": "{{ cookiecutter.project_name.replace(" ", "_") }}",
 "license_name": "MIT license",
 "open_source_license": "MIT license"
}'''

# Generated at 2022-06-25 15:27:52.374185
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com'
        }
    }
    answer = {
        'full_name': 'Audrey Roy Greenfeld',
        'email': 'audreyr@example.com'
    }
    assert prompt_for_config(context) == answer
    assert prompt_for_config(context, no_input=True) == answer


# Generated at 2022-06-25 15:28:03.494068
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:28:13.556665
# Unit test for function read_user_dict
def test_read_user_dict():
    # 1. Valid input
    user_value_1 = json.dumps({"key_1": "val_1", "key_2": "val_2"})
    key_1 = "dict_0"
    user_dict_1 = read_user_dict(key_1, user_value_1)

    # 2. Invalid input
    user_value_2 = json.dumps({"key_1": "val_1"})
    user_value_2["key_2"] = "val_2"
    key_2 = "dict_1"
    user_dict_2 = read_user_dict(key_2, user_value_2)



# Generated at 2022-06-25 15:28:24.807707
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:28:32.614775
# Unit test for function read_user_dict
def test_read_user_dict():
    dic = {
        "cookiecutter": {
            "test_dict_0":{
                "test_key_0":"test_value_0"
            }
        }
    }
    dic_default = {"test_key_1":"test_value_1"}
    # test case 0
    click.echo(read_user_dict("test_dict_0", dic_default))
    # test case 1
    click.echo(read_user_dict("test_dict_0", dic["cookiecutter"]["test_dict_0"]))
    # test case 2

# Generated at 2022-06-25 15:28:33.558145
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_case_0()


# Generated at 2022-06-25 15:28:51.534513
# Unit test for function prompt_for_config
def test_prompt_for_config():
    #Test case 0 : Test command line input
    context = {'cookiecutter': {'full_name': 'John Doe', 'email': 'johndoe@example.com', 'github_username': 'johndoe', 'repo_name': 'cookiecutter-pypackage-minimal', 'project_name': 'cookiecutter-pypackage-minimal', 'pypi_username': 'johndoe', 'release_date': 'YYYY-MM-DD', 'version': '0.1.0', 'open_source_license': 'MIT license'}}

# Generated at 2022-06-25 15:28:52.474900
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_case_0()


# Generated at 2022-06-25 15:28:57.039991
# Unit test for function read_user_dict
def test_read_user_dict():
    
    count_0 = 0
    for i in range(4):
        count_0 += 1
        raw = read_user_dict('var_name', {'key': 'value'})
        str_0 = str(raw)
        str_1 = 'value'
        assert (str_0 == str_1), "Testcase Failed"
    if count_0 == 4:
        print("Testcase Passed")


# Generated at 2022-06-25 15:29:05.396059
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:29:07.710548
# Unit test for function prompt_for_config
def test_prompt_for_config():
    with open(test_case_0(), 'r') as myfile:
        data_0 = myfile.read()
    context = json.loads(data_0)
    prompt_for_config(context)


# Generated at 2022-06-25 15:29:11.944591
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = json.loads(open(str_0, 'r').read())
    cookiecutter_dict = prompt_for_config(context)
    print(cookiecutter_dict)


if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:29:13.666401
# Unit test for function process_json
def test_process_json():
    user_value = '{"name": "value"}'
    result = process_json(user_value)
    print(result)


# Generated at 2022-06-25 15:29:23.788569
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:29:36.085566
# Unit test for function render_variable
def test_render_variable():
    env = StrictEnvironment()
    cookiecutter_dict = OrderedDict()
    cookiecutter_dict['cookiecutter'] = OrderedDict()
    cookiecutter_dict['cookiecutter']['name'] = 'test'
    cookiecutter_dict['cookiecutter']['version'] = '1.0.0'
    cookiecutter_dict['cookiecutter']['description'] = 'hello world'
    cookiecutter_dict['cookiecutter']['license'] = 'MIT'
    cookiecutter_dict['cookiecutter']['year'] = '2020'
    cookiecutter_dict['cookiecutter']['author'] = 'Yifan Li'
    cookiecutter_dict['cookiecutter']['email'] = 'liyifan0111@hotmail.com'

    load

# Generated at 2022-06-25 15:29:37.886382
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'string'
    default_value = 23
    read_user_dict(var_name, default_value)


# Generated at 2022-06-25 15:29:53.488985
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict([
        ('_copy_without_render',['setuptools']),
        ('repo_name', 'demo-repo'),
        ('open_source_license', 'MIT license'),
        ('project_short_description', 'A short description of the project.'),
        ('pypi_username', '<Your username here>'),
        ('app_name', 'demoapp'),
        ('app_description', 'A short description of the app that will be created.'),
    ])

# Generated at 2022-06-25 15:29:57.133069
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_input = {
    "cookiecutters_dir": "~/.cookiecutters",
    "replay_dir": "~/.cookiecutter_replay"
    }
    # print(read_user_dict('test', dict_input))
    pass


# Generated at 2022-06-25 15:30:04.445215
# Unit test for function render_variable
def test_render_variable():
    context = {
        "cookiecutter": {
            "project_name": "{{ cookiecutter.first_name }}",
            "first_name": "Wang",
            "project_slug": "{{ cookiecutter.project_name.lower().replace(' ', '_') }}",
            "project_dir": "{{ cookiecutter.project_slug }}",
            "project_license": "MIT",
            "generate_travis": false,
            "travis_pypi_setup": true,
            "generate_appveyor": false,
            "appveyor_pypi_setup": true,
            "github_username": "{{ cookiecutter.first_name }}",
            "author_name": "{{ cookiecutter.first_name }}"
        }
    }
    env = StrictEnvironment

# Generated at 2022-06-25 15:30:15.674323
# Unit test for function read_user_dict
def test_read_user_dict():
    # test case 0
    cookiecutter_dict = OrderedDict([('author', 'Daehee')])
    # cookiecutter_dict = OrderedDict([('author', 'Daehee'), ('date', '2019-05-23')])
    env = StrictEnvironment(context=cookiecutter_dict) # context = {'author': 'Daehee', 'date': '2019-05-23'}
    var_name = 'author'
    default_value = 'Daehee' # {'author': 'Daehee', 'date': '2019-05-23'}

    rendered_template = render_variable(env, default_value, cookiecutter_dict) # 'Daehee'
    user_value = read_user_dict(var_name, default_value) # 'Daehee'

# Generated at 2022-06-25 15:30:27.532056
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:39.824795
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test for a normal function
    with click.testing.CliRunner() as runner:
        result = runner.invoke(
            read_user_dict, ['key', {'key': 'value'}], input='\n'
        )
        assert result.output == 'default\n'
        assert result.exit_code == 0

    # Test for a normal function
    with click.testing.CliRunner() as runner:
        result = runner.invoke(
            read_user_dict, ['key', {'key': 'value'}], input='{"key": "value"}\n'
        )
        assert result.output == (
            'key\n'
            'default\n'
            '{"key": "value"}\n'
        )
        assert result.exit

# Generated at 2022-06-25 15:30:47.897098
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['key_0'] = 'val_0'
    dict_1['key_1'] = 'val_1'
    dict_1['key_2'] = 'val_2'
    dict_2 = dict()
    dict_2['key_0'] = 'val_0'
    dict_2['key_1'] = 'val_1'
    dict_2['key_2'] = 'val_2'
    dict_2['key_3'] = 'val_3'
    dict_2['key_4'] = 'val_4'
    dict_2['key_5'] = 'val_5'

    # Prompt is shown and the default is selected.
    res = read_user_dict('foo', dict_0)
    assert res

# Generated at 2022-06-25 15:30:58.588912
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import re
    import os
    import json
    import subprocess
    import sys

    # get directory of this file
    pwd = os.path.dirname(os.path.realpath(__file__))

    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['project_name'] = 'test_project'
    context['cookiecutter']['repo_name']    = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    context['cookiecutter']['author_name']  = ''

    result = prompt_for_config(context)
    print(result)


# if __name__ == '__main__':
#     test_prompt_for_config()

# Generated at 2022-06-25 15:31:00.520600
# Unit test for function read_user_dict
def test_read_user_dict():
    # test case 0
    test_case_0()

test_read_user_dict()

# Generated at 2022-06-25 15:31:10.282759
# Unit test for function prompt_for_config
def test_prompt_for_config():
    '''
    https://github.com/cookiecutter/cookiecutter/blob/v1.7.2/tests/test_prompt.py
    '''

# Generated at 2022-06-25 15:31:25.296823
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter":
        {
            "project_name": "Peanut Butter Cookie",
            "repo_name": "{{cookiecutter.project_name.replace(' ', '_')}}'"
        }
    }

    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict["project_name"] == "Peanut Butter Cookie"
    assert cookiecutter_dict["repo_name"] == "Peanut_Butter_Cookie"

if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:31:33.040453
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {}
    prompt_for_config(context)
    context = {'cookiecutter': {}}
    prompt_for_config(context)
    context = {'cookiecutter': {'_': {}}}
    prompt_for_config(context)
    context = {'cookiecutter': {'__': {}}}
    prompt_for_config(context)
    context = {'cookiecutter': {'_': True, '__': False}}
    prompt_for_config(context)
    context = {'cookiecutter': {'_': 1, '__': 0}}
    prompt_for_config(context)
    context = {'cookiecutter': {'_': [], '__': [1, 2, 3]}}
    prompt_for_config(context)

# Generated at 2022-06-25 15:31:43.618628
# Unit test for function read_user_dict
def test_read_user_dict():
    user_value = "{" \
                  "\"variable_apple\": \"my_value\"," \
                  "\"variable_banana\": \"my_other_value\"" \
                 "}"
    var_name = "variable_name"
    default_value = {"variable_banana": "my_other_value"}
    #print(default_value)
    #print(type(default_value))
    result = read_user_dict(var_name, default_value)
    #print(result)
    #print(type(result))
    assert result == {"variable_apple": "my_value", "variable_banana": "my_other_value"}


if __name__ == "__main__":
    test_case_0()
    test_read_user_dict()

# Generated at 2022-06-25 15:31:54.788959
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test case 0
    str_0 = '~/.cookiecutterrc'
    # Test case 1
    str_1 = '.cookiecutterrc'
    # Test case 2
    int_0 = 0
    # Test case 3
    float_0 = 0.0
    # Test case 4
    bool_0 = True
    # Test case 5
    none_0 = None
    # Test case 6
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # Test case 7
    list_1 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    # Test case 8

# Generated at 2022-06-25 15:31:57.392717
# Unit test for function prompt_for_config
def test_prompt_for_config():
    str_0 = '~/.cookiecutterrc'
    str_1 = 'default_context'
    return (str_0, str_1)
