

# Generated at 2022-06-25 15:22:20.274062
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import json
    import os
    import pytest

    from cookiecutter.main import cookiecutter  # noqa

    project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    template_dir = os.path.join(project_dir, 'tests', 'test-cookies', 'fake-project')
    result = cookiecutter(template_dir, no_input=True)

    assert result
    assert os.path.isdir(result['repo_name'])
    with open(os.path.join(result['repo_name'], 'cookiecutter.json')) as fh:
        data = json.load(fh)


# Generated at 2022-06-25 15:22:24.095676
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'full_name': 'Your Name', 'email': 'Your email'}}
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert(cookiecutter_dict['full_name'] == 'Your Name')
    assert(cookiecutter_dict['email'] == 'Your email')



# Generated at 2022-06-25 15:22:31.643863
# Unit test for function process_json
def test_process_json():
    dict_0 = {
        'first_name': 'Mrs',
        'last_name': 'test@test.test',
        'email': 'test@test.test'
    }
    str_0 = json.dumps(dict_0, separators=(',', ':'))
    dict_1 = process_json(str_0)
    assert dict_1 == dict_0


# Generated at 2022-06-25 15:22:38.296061
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    test_read_user_dict() returns a boolean value after checking the return type of read_user_dict
    """
    user_keys = ['variable1', 'variable2']
    user_values = ['value1', 'value2']
    user_dict = {k: v for k, v in zip(user_keys, user_values)}
    result = read_user_dict(user_keys[0], user_values[1])
    if result == user_dict:
        return True

    return False



# Generated at 2022-06-25 15:22:43.361822
# Unit test for function process_json
def test_process_json():
    # user_value = '{"name": "Cookiecutter"}'
    user_value = '{"name": "Cookiecutter", "version": "0.9", "author": "Audrey Roy Greenfeld"}'
    loaded = process_json(user_value)
    assert (loaded['name'] == 'Cookiecutter')
    assert (loaded['version'] == '0.9')
    assert (loaded['author'] == 'Audrey Roy Greenfeld')


# Generated at 2022-06-25 15:22:54.437803
# Unit test for function prompt_for_config
def test_prompt_for_config():
    user_context = {
        'cookiecutter': {
            'project_name': 'Project Name',
            'repo_name': '{{ cookiecutter.project_name.lower.replace(" ", "-") }}',
            'use_docker': [
                'y',
                'n',
            ],
        }
    }
    context = {
        'cookiecutter': {
            'project_name': 'Project Name',
            'repo_name': '{{ cookiecutter.project_name.lower.replace(" ", "-") }}',
            'use_docker': [
                'y',
                'n',
            ],
        }
    }

    # Unit: assert prompt_for_config returns a dictionary
    assert prompt_for_config(context) == user_context['cookiecutter']

# Generated at 2022-06-25 15:22:59.582064
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': OrderedDict([])}
    context['cookiecutter']['My_name'] = None
    context['cookiecutter']['My_name'] = None
    context['cookiecutter']['a'] = 'this'
    context['cookiecutter']['b'] = 'that'
    context['cookiecutter']['choice'] = ['foo', 'bar']
    no_input = True
    prompt_for_config(context, no_input)


# Generated at 2022-06-25 15:23:01.847073
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'test': True}}
    cookiecutter_dict = prompt_for_config(context, True)
    assert cookiecutter_dict['test']


# Generated at 2022-06-25 15:23:11.062463
# Unit test for function process_json
def test_process_json():
    context = {
        "template_dir": "./test_files",
        "replay": False,
        "no_input": False,
        "extra_context": {},
        "config_file": "./test_files/cookiecutter.json",
    }
    user_value = "{'some_key': 'some_value', 'some_other_key': 'some_other_value'}"
    expected_result = {"some_key": "some_value", "some_other_key": "some_other_value"}
    result = process_json(user_value)
    assert result == expected_result
    result = prompt_for_config(context)
    assert result


# Generated at 2022-06-25 15:23:18.707440
# Unit test for function prompt_for_config
def test_prompt_for_config():
   test_json = {
      "cookiecutter":{
         "repo_name":"{{cookiecutter.project_name.lower().replace(' ', '-')}}",
         "author_name":"{{cookiecutter.full_name.split()[0]}}"
      }
   }
   test_dict = prompt_for_config(test_json)
   print(test_dict)

if __name__ == '__main__':
   test_prompt_for_config()

# Generated at 2022-06-25 15:23:32.387576
# Unit test for function prompt_for_config
def test_prompt_for_config():
    bytes_0 = b'\xfb\xb6\x0e\x82\xbb\xec\x75\xaf\xd7\x12\x05\x94\x13'
    bytes_1 = b'\x88\x07\x1c\x14\xf7\x1a\xa0\x3f'
    int_0 = 1
    list_0 = ['\xa1\xaf\xbf\xcd', '\xce\x19\xfe\xd1\x93\xc3\xdb\xb3\xfe\x8c\x94\xd4\xdb\x17\x89\xbc\xfe']

# Generated at 2022-06-25 15:23:40.386364
# Unit test for function render_variable
def test_render_variable():
    if '{{ cookiecutter.x.replace(" ", "_") }}' != '{{ x.replace(" ", "_") }}':
        raise Exception("test fail")

# Main function
if __name__ == "__main__":
    print("\nTest 0: ")
    test_case_0()
    
    print("\nTest 1: ")
    test_render_variable()

# Generated at 2022-06-25 15:23:45.835206
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:23:47.093885
# Unit test for function read_user_dict
def test_read_user_dict():
    assert isinstance(read_user_dict('var_name', 'default_value'), dict)

# Generated at 2022-06-25 15:23:57.171904
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:03.017514
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Define variable
    context = {
        'cookiecutter': {
            'test_test_test': {
                'test_test_test_test': True,
                'test_test_test_test_test': True,
            },
            'test_test_test_test_test': [
                'test_test_test',
                'test_test_test_test',
            ],
        },
        'default_context': {},
    }
    no_input = False

    # Call function
    prompt_for_config(context, no_input)


# Generated at 2022-06-25 15:24:13.380411
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:16.366493
# Unit test for function process_json
def test_process_json():
    # Make test for a string
    raw = r'{"a": "b", "c": "d"}'
    user_value = raw
    assert process_json(user_value) == json.loads(raw)


# Generated at 2022-06-25 15:24:23.388812
# Unit test for function read_user_dict
def test_read_user_dict():
    """Example from: https://github.com/parshap/cookiecutter-pypackage"""

    # Given a context
    user_data = read_user_dict('test_dict', {'test_key': 'test_value'})
    expected_user_data = {'test_key': 'test_value'}

    # Then assert that the result is a dict with the expected values
    assert expected_user_data == user_data

# Generated at 2022-06-25 15:24:29.878210
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        u'cookiecutter': {
            u'project_name': u'Bakery',
            u'open_source_license': u'MIT license'
        }
    }
    cookiecutter_dict = {
        u'project_name': u'Bakery',
        u'open_source_license': u'MIT license'
    }
    env = StrictEnvironment(context=context)
    result = prompt_for_config(context)
    assert result == cookiecutter_dict

# Generated at 2022-06-25 15:24:39.836605
# Unit test for function read_user_dict
def test_read_user_dict():
    """ read_user_dict() -> str """
    var_user_dict = {}
    var_name = ''
    var_default_value = '{}'
    assert read_user_dict(var_name, var_default_value) == var_user_dict


# Generated at 2022-06-25 15:24:46.973622
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter": {
            "full_name": "Your Name",
            "email": "Your email",
            "project_name": "My Project",
            "project_slug": "my_project",
            "project_short_description": "Something short",
            "pypi_username": "Your PyPI username",
            "repo_name": "{{ cookiecutter.project_name.replace(\" \", \"_\") }}",
            "use_pycharm": "y",
            "version": "0.1.0",
            "select_license": [
                "MIT license",
                "BSD license",
                "ISC license",
                "Apache Software License 2.0",
                "Not open source"
            ]
        }
    }

    cookiecutter_dict = prompt

# Generated at 2022-06-25 15:24:54.865978
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cwd = os.getcwd()

# Generated at 2022-06-25 15:25:01.326489
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = dict()
    dict_0['test'] = 'test'
    dict_0['test1'] = 'test1'

    dict_1 = read_user_dict('test', dict_0)
    assert dict_1['test'] == 'test'
    assert dict_1['test1'] == 'test1'



# Generated at 2022-06-25 15:25:02.989862
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Test type str
    # Test exceptions
    assert prompt_for_config(None) == None


# Generated at 2022-06-25 15:25:13.582662
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'project_name': 'Cookiecutter-PTest'}}
    no_input = True
    q_val = 'Are you sure you want to generate this project?'
    answer = True
    while answer:
        answer = read_user_yes_no(q_val, default_value=True)
        if answer:
            method_output = prompt_for_config(context, no_input=True)
            expected_output = {'project_name': 'Cookiecutter-PTest'}
            assert expected_output == method_output
        else:
            break
    q_val = 'Are you sure you want to generate this project?'
    answer = True
    while answer:
        answer = read_user_yes_no(q_val, default_value=True)

# Generated at 2022-06-25 15:25:22.830633
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Tests that render_variable works as intended.
    """
    no_input = True


# Generated at 2022-06-25 15:25:28.294439
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter": {
            "author_email": "me@example.me",
            "author_name": "My Name",
            "project_name": "My Project",
            "project_slug": "my_project",
            "release_date": "today",
            "version": "0.1.0"
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert isinstance(cookiecutter_dict, dict)
    assert cookiecutter_dict['author_email'] == 'me@example.me'
    assert cookiecutter_dict['author_name'] == 'My Name'
    assert cookiecutter_dict['project_name'] == 'My Project'

# Generated at 2022-06-25 15:25:38.699727
# Unit test for function read_user_dict

# Generated at 2022-06-25 15:25:44.194235
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    context = {}

# Generated at 2022-06-25 15:25:50.336598
# Unit test for function prompt_for_config
def test_prompt_for_config():
    assert False


# Generated at 2022-06-25 15:25:53.471836
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict([('cookiecutter', OrderedDict([('_template', 'accdf40e65b2aee8c6d450e6179f3a1c')]))])
    no_input = True
    prompt_for_config(context, no_input)

# Generated at 2022-06-25 15:26:05.943906
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = {}
    import json

    dict_0['cookiecutter'] = {}
    dict_0['cookiecutter']['project_name'] = 'cookiecutter-pypackage'
    dict_0['cookiecutter']['project_slug'] = 'cookiecutter_pypackage'
    dict_0['cookiecutter']['pkg_name'] = 'cookiecutter_pypackage'
    dict_0['cookiecutter']['author_name'] = 'Audrey Roy Greenfeld'
    dict_0['cookiecutter']['email'] = 'audreyr@example.com'
    dict_0['cookiecutter']['description'] = 'A Python package project template.'
    dict_0['cookiecutter']['domain_name'] = 'example.com'
    dict

# Generated at 2022-06-25 15:26:15.640903
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:26:21.787012
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Function to test if the function prompt_for_config work properly"""
    assert len(prompt_for_config(context={'cookiecutter': {'year': '2018', 'repo_name': '{{ cookiecutter.project_name.lower() }}', 'full_name': 'Your name', 'project_name': 'My Project', 'email': 'Your email', 'project_slug': '{{ cookiecutter.project_name.lower().replace(" ", "-") }}'}})) == 6



# Generated at 2022-06-25 15:26:33.013346
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'package_name': '{{ cookiecutter.repo_name.lower() }}',
        }
    }
    env = StrictEnvironment(context=context)

    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    assert render_variable(env, raw, cookiecutter_dict) == 'Peanut_Butter_Cookie'

    cookiecutter_dict = {'repo_name': 'Peanut_Butter_Cookie'}

# Generated at 2022-06-25 15:26:42.660978
# Unit test for function render_variable
def test_render_variable():
    context = {
        "cookiecutter": {
            "project_name": "Peanut Butter Cookie",
            "repo_name": "{{ cookiecutter.project_name.replace(' ', '_') }}"
        }
    }
    env = StrictEnvironment(context=context)
    rendered_value = render_variable(env,
                                     "{{ cookiecutter.project_name }}",
                                     context['cookiecutter'])
    assert rendered_value == "Peanut Butter Cookie"



# Generated at 2022-06-25 15:26:48.220876
# Unit test for function process_json
def test_process_json():
    bytes_0 = b'\x8c\xf3\x04\xfd\x1c\x8c\xee\x95\xd1\x1e\x05\x10\x92\xda\x97\xbf2\xfe\xe4\x11\x95K\x8b\x1c'
    var_0 = read_user_variable(bytes_0, False)
    str_0 = "\\xH"
    var_1 = process_json(str_0)


# Generated at 2022-06-25 15:26:51.600593
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'project_name': 'Peanut Butter Cookie', '_copy_without_render': ['foo']}}

    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == 'Peanut Butter Cookie'

    # Check that private type dicts are not rendered and copied over
    assert cookiecutter_dict['_copy_without_render'] == ['foo']



# Generated at 2022-06-25 15:27:00.906212
# Unit test for function read_user_dict
def test_read_user_dict():
    cookiecutter_dict = OrderedDict([
        ('first_key', 'first_value'),
        ('second_key', 'second_value'),
        ('third_key', 'third_value')
    ])
    env = jinja2.Environment()
    var_0 = read_user_dict('first_key', cookiecutter_dict)
    var_1 = read_user_dict('second_key', cookiecutter_dict)
    var_2 = read_user_dict('third_key', cookiecutter_dict)


# Generated at 2022-06-25 15:27:10.667760
# Unit test for function read_user_dict
def test_read_user_dict():
    str_0 = 'jb8l22q'
    var_0 = read_user_dict('jb8l22q', 'jb8l22q')
    var_1 = read_user_dict('xWLX8', {'d': 'd'})
    var_2 = read_user_dict('EoJ', [1, 2, 3])

# Generated at 2022-06-25 15:27:21.359883
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['project_name'] = 'test'
    context['cookiecutter']['test'] = 'test123'
    context['cookiecutter']['numb'] = 3456
    context['cookiecutter']['boolean'] = True
    context['cookiecutter']['list'] = [2, 3]
    context['cookiecutter']['url'] = 'https://github.com/abcd/'
    context['cookiecutter']['tag'] = 'fork'
    context['cookiecutter']['dict'] = {'key1': 'val1', 'key2': 'val2'}
    user_dict = prompt_for_config(context, True)

# Generated at 2022-06-25 15:27:30.843054
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = dict()
    dict_0['val_2'] = 'qYzBYH'
    dict_1 = dict()
    dict_1['val_2'] = 'cyjOE'
    dict_2 = dict()
    dict_2['val_2'] = 'sLeO'
    dict_3 = dict()
    dict_3['val_2'] = 'fTKdS'
    dict_4 = dict()
    dict_4['val_2'] = 'JafwF'
    dict_5 = dict()
    dict_5['val_2'] = 'GaawY'
    dict_6 = dict()
    dict_6['val_2'] = 'KHEJ'
    dict_7 = dict()
    dict_7['val_2'] = 'oqyq'
   

# Generated at 2022-06-25 15:27:40.447873
# Unit test for function prompt_for_config
def test_prompt_for_config():
    str_0 = 'lQT1'
    var_0 = read_user_yes_no(str_0, str_0)
    str_1 = 'xTgG'
    var_1 = read_user_yes_no(str_1, str_1)
    bool_0 = bool(str_0)
    bool_1 = bool(str_1)
    bool_2 = bool(var_1)
    bool_3 = bool(bool_2)
    bool_4 = bool(var_0)
    bool_5 = bool(bool_4)
    bool_6 = bool(var_0)
    bool_7 = bool(bool_6)
    bool_8 = bool(bool_3)
    bool_9 = bool(var_0)
    bool_10 = bool(bool_9)

# Generated at 2022-06-25 15:27:49.169392
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.generate import generate_context

    # Test case 0

# Generated at 2022-06-25 15:27:55.112467
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit-testing of function prompt_for_config."""
    print('starting test_prompt_for_config')
    context = dict()
    context['cookiecutter'] = dict()
    # cookies
    context['cookiecutter']['project_name'] = 'cookies'
    context['cookiecutter']['package_name'] = 'peanutbutter'
    context['cookiecutter']['project_slug'] = 'cookies'
    context['cookiecutter']['create_author_file'] = 'y'
    context['cookiecutter']['author_email'] = 'joda@kiyon.ca'
    context['cookiecutter']['author_name'] = 'Joda'
    context['cookiecutter']['version'] = '0.1.0'

# Generated at 2022-06-25 15:27:58.792968
# Unit test for function read_user_dict
def test_read_user_dict():
    str_2 = 'test'
    dic = {'test': 'test'}
    var = read_user_yes_no(str_2, str_2)
    dic['test'] = var
    print(dic)

# Generated at 2022-06-25 15:28:02.198130
# Unit test for function prompt_for_config
def test_prompt_for_config():
    mock_context = {'cookiecutter': {'project_name': 'VynS'}}
    result = prompt_for_config(mock_context, no_input=True)
    assert result == {'project_name': 'VynS'}


# Generated at 2022-06-25 15:28:13.524195
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:28:16.531165
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_prompt_for_config_0()


# Generated at 2022-06-25 15:28:33.281163
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'project_name': 'Pylons project'}}
    vars = prompt_for_config(context=context)

    assert vars == {'project_name': 'Pylons project'}

# Generated at 2022-06-25 15:28:42.371969
# Unit test for function read_user_dict
def test_read_user_dict():
    str_0 = 'uZ8VYW4tG1x5fR'
    str_1 = 'r5w'
    str_2 = 'zXb'
    str_3 = '6'
    str_4 = '0'
    str_5 = '1'
    str_6 = 'U6P'
    str_7 = 'bfJ'
    str_8 = 'D6'
    str_9 = 'Uiib'
    str_10 = 'w5x5'
    str_11 = 'g'
    str_12 = 'z1'
    str_13 = 'Ow'
    str_14 = 'tC4Yt'
    str_15 = 'Rd'
    str_16 = '0'
    str_17 = '9'
    str_18

# Generated at 2022-06-25 15:28:52.911865
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Vegan Chocolate Chip Cookies',
            '_template': {
                'repo_name': '{{ cookiecutter.project_name | lower }}'
            },
            'cookiecutter': {
                '_copy_without_render': ['.travis.yml', 'LICENSE'],
                'license': 'MIT',
                '_template': {
                    'project_name': '{{ cookiecutter.project_name.replace(" ", "_") }}'
                }
            }
        }
    }
    no_input = False
    val = prompt_for_config(context, no_input)
    assert(val['_copy_without_render'] == ['.travis.yml', 'LICENSE'])

# Generated at 2022-06-25 15:28:53.455365
# Unit test for function prompt_for_config
def test_prompt_for_config():
    pass

# Generated at 2022-06-25 15:28:59.146769
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'_copy_without_render': ['key1', 'key2'],
                                '_repo_name': 'foo', 'repo_owner': 'bar',
                                'project_name': 'foobar'}}
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict == {'_copy_without_render': ['key1', 'key2'],
                                 '_repo_name': 'foo', 'repo_owner': 'bar',
                                 'project_name': 'foobar'}


# Generated at 2022-06-25 15:29:06.428553
# Unit test for function read_user_dict
def test_read_user_dict():
    env = StrictEnvironment(context={})

    test_dict = {"foo": "bar"}

    dict_0 = read_user_dict("foo", test_dict)
    dict_1 = read_user_dict("bar", test_dict)
    dict_2 = read_user_dict("baz", test_dict)

    # Check for correct typing of returned dict
    assert isinstance(dict_0, dict), "dict_0 is not dict"
    assert isinstance(dict_1, dict), "dict_1 is not dict"
    assert isinstance(dict_2, dict), "dict_2 is not dict"

    # Check that dict returned is same as original dict
    assert dict_0 == test_dict, "dict_0 not identical to input test_dict"

# Generated at 2022-06-25 15:29:12.426299
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    # Create a test project from the 'audreyr/cookiecutter-pypackage'
    # repo, using test values for all the user inputs.
    cookiecutter('tests/test-cookiecutters/test-cookiecutter-pypackage/')

if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:29:16.642001
# Unit test for function read_user_choice
def test_read_user_choice():
    for i in range(1000):
        options = ['apple', 'orange', 'kiwi']
        var_0 = read_user_choice('fruit',options)
        if var_0 == 'apple':
            assert 1
        elif var_0 == 'orange':
            assert 1
        elif var_0 == 'kiwi':
            assert 1
        else:
            assert 0



# Generated at 2022-06-25 15:29:25.786205
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # We don't need to test this actively but since it is used
    # a lot in the code and it has a lot of different branches,
    # we create a test that can be run in production to ensure
    # that our coverage is 100% (at least for Python statements).
    from cookiecutter.find import expand_abbreviations
    from cookiecutter.prompt import prompt_for_config
    from cookiecutter import utils
    from pprint import pprint

    no_input = False

# Generated at 2022-06-25 15:29:30.194701
# Unit test for function read_user_dict
def test_read_user_dict():
    var_0 = read_user_dict('VynS', {"i":"s"})


# Generated at 2022-06-25 15:30:04.992262
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:15.870247
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context=context)

    # First pass: Handle simple and raw variables, plus choices.
    # These must be done first because the dictionaries keys and
    # values might refer to them.
    for key, raw in context['cookiecutter'].items():
        if key.startswith('_') and not key.startswith('__'):
            cookiecutter_dict[key] = raw
            continue
        elif key.startswith('__'):
            cookiecutter_dict[key] = render_variable(env, raw, cookiecutter_dict)
            continue


# Generated at 2022-06-25 15:30:27.675566
# Unit test for function prompt_for_config
def test_prompt_for_config():
    env = {}

# Generated at 2022-06-25 15:30:39.984286
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:48.066557
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:56.342663
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['project_name'] = '{{cookiecutter.project_name}}'
    context['cookiecutter']['project_name'] = '{{cookiecutter.project_name}}'
    no_input = False
    prompt_for_config(context, no_input)

if __name__ == '__main__':
    test_prompt_for_config()
    print(prompt_for_config("dict"))

# Generated at 2022-06-25 15:31:04.222693
# Unit test for function prompt_for_config
def test_prompt_for_config():
    str_1 = 'Tvw7'
    str_2 = 'VynS'
    int_0 = 0
    int_1 = 1
    # value = prompt_for_config(context, no_input)
    # assert value == expected_result, 'test_prompt_for_config() Error'
    var_0 = read_user_yes_no(str_0, str_0)
    var_1 = read_user_yes_no(str_1, str_1)
    var_2 = read_user_yes_no(str_2, str_2)
    if var_2 == True:
        var_3 = int_0
    else:
        var_3 = int_1
    var_4 = read_user_yes_no(str_1, str_1)
    var_5

# Generated at 2022-06-25 15:31:09.423372
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:31:12.525578
# Unit test for function prompt_for_config
def test_prompt_for_config():
    str_0 = 'XoJ'
    dict_0 = {'arz': 'Pjw', 'project_name': 'NBN'}
    assert prompt_for_config(dict_0) is not None


# Generated at 2022-06-25 15:31:19.827860
# Unit test for function prompt_for_config