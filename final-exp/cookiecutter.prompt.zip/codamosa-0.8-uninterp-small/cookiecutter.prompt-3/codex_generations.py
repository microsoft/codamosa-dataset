

# Generated at 2022-06-25 15:22:17.653776
# Unit test for function read_user_choice
def test_read_user_choice():
    assert read_user_choice("test_0", [1,2,3]) == 1
    assert read_user_choice("test_1", ['a','b','c']) == 'a'
    assert read_user_choice("test_2", []) == []
    assert read_user_choice("test_3", [1,2,3]) == 1


# Generated at 2022-06-25 15:22:23.697073
# Unit test for function prompt_for_config
def test_prompt_for_config():
    with open("cookiecutter.json") as f:
        context = json.load(f)

    cookiecutter_dict = prompt_for_config(context)
    assert isinstance(cookiecutter_dict, dict)
    assert len(cookiecutter_dict) == 6

# Generated at 2022-06-25 15:22:29.125366
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # cookiecutter_dict = prompt_for_config()
    # assert isinstance(cookiecutter_dict, dict)
    pass



if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:22:32.098472
# Unit test for function process_json
def test_process_json():
    bool_0 = True
    var_0 = process_json(bool_0)
    # Assertion Error
    assert not (var_0 == True)


# Generated at 2022-06-25 15:22:41.420917
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    context = {"cookiecutter": {
        "project_slug": "{{ cookiecutter.project_name.replace(' ', '_').lower() }}",
        "open_source_license": [
            "MIT license",
            "BSD license",
            "ISC license",
            "Apache Software License 2.0",
            "Not open source"
        ]
    }}
    cookiecutter_dict = OrderedDict([
        ('project_name', 'project_name'),
        ('project_slug', 'project_slug'),
        ('open_source_license', 'open_source_license')
    ])
    env = StrictEnvironment(context=context)
    key = "open_source_license"

# Generated at 2022-06-25 15:22:45.911711
# Unit test for function process_json
def test_process_json():
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0 failed due to:")
        print(e)
        return False
    return True

# Test cases for function process_json
# Test case 0 passed
# Test case 1 passed
# Test case 2 passed
# Test case 3 passed
# Test case 4 passed
# Test case 5 passed
# Test case 6 passed
# Test case 7 passed
# Test case 8 passed
# Test case 9 passed


# Generated at 2022-06-25 15:22:51.041843
# Unit test for function read_user_choice
def test_read_user_choice():
    options = ['item_0', 'item_1', 'item_2']
    # Prompt user to select one item of options, and return the selected item
    var_0 = read_user_choice('test_read_user_choice', options)
    assert var_0 == 'item_0'


# Generated at 2022-06-25 15:22:59.399584
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config with fixtures
    """
    context = {}
    context['cookiecutter'] = {
    'project_name': 'My Project',
    'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
    'package_name': '{{ cookiecutter.repo_name }}',
    'author_name': 'Firstname Lastname',
    'author_email': 'firstname.lastname@email.com',
    'version': '0.1.0',
    'select_license': [
        'MIT license',
        'BSD license',
        'ISC license',
        'Apache Software License 2.0',
        'GNU General Public License v3',
    ]
    }
    no_input = False
    cookiecutter_dict = prompt_for_

# Generated at 2022-06-25 15:23:09.649990
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context=context)

    # First pass: Handle simple and raw variables, plus choices.
    # These must be done first because the dictionaries keys and
    # values might refer to them.
    for key, raw in context['cookiecutter'].items():
        if key.startswith('_') and not key.startswith('__'):
            cookiecutter_dict[key] = raw
            continue
        elif key.startswith('__'):
            cookiecutter_dict[key] = render_variable(env, raw, cookiecutter_dict)
            continue


# Generated at 2022-06-25 15:23:13.476252
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Arrange
    context = {}

    # Act
    result = prompt_for_config(context)

    # Assert
    assert result == {}

# Generated at 2022-06-25 15:23:24.320842
# Unit test for function process_json
def test_process_json():
    user_value = '{"a": {"b": "c", "d": "e"}, "f": "g"}'
    user_dict = process_json(user_value)
    # Assume that JSON was parsed correctly
    assert user_dict == {'a': {'b': 'c', 'd': 'e'}, 'f': 'g'}


# Generated at 2022-06-25 15:23:33.500317
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict()
    context['cookiecutter'] = OrderedDict()
    context['cookiecutter']['full_name'] = 'Peter'
    context['cookiecutter']['email'] = 'peter@example.com'
    context['cookiecutter']['project_name'] = 'Cookiecutter'
    context['cookiecutter']['project_slug'] = 'cookiecutter'
    context['cookiecutter']['pkg_name'] = 'cookiecutter'
    context['cookiecutter']['version'] = '1.0.0'
    context['cookiecutter']['description'] = 'A command-line utility that creates projects from cookiecutters (project templates). E.g. Python package projects, jQuery plugin projects.'

# Generated at 2022-06-25 15:23:40.966475
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    context = {'cookiecutter': {'test_prompt_choice_for_config': ['yes', 'no']}}
    env = StrictEnvironment(context=context)
    cookiecutter_dict = {}
    key = 'test_prompt_choice_for_config'
    options = ['yes', 'no']
    no_input = False
    assert prompt_choice_for_config(cookiecutter_dict, env, key, options, no_input) == 'yes'


# Generated at 2022-06-25 15:23:48.275341
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    cookiecutter_dict = {"user_name": "Emanuel"}
    context = {
        "cookiecutter": {"user_name": "{{ cookiecutter.user_name }}"},
        "user_name": "Emanuel",
    }
    env = StrictEnvironment(context=context)
    key = "user_name"
    options = ["{{ cookiecutter.user_name }}"]
    no_input = True
    prompt_choice_for_config(cookiecutter_dict, env, key, options, no_input)


if __name__ == '__main__':
    test_case_0()
    test_prompt_choice_for_config()

# Generated at 2022-06-25 15:23:52.487677
# Unit test for function read_user_dict
def test_read_user_dict():
    var_0 = OrderedDict([('a', 'b'), ('c', 'd')])
    context = {'cookiecutter': var_0}
    read_user_dict('a', context)


# Generated at 2022-06-25 15:23:58.169513
# Unit test for function prompt_for_config
def test_prompt_for_config():
    tuple_0 = ()
    bool_0 = False
    str_0 = '@K5D6U^7{o#g8w.1[>'
    str_1 = 'vC8W#7iRdKj'
    str_2 = '/{T$'
    str_3 = 'NhOz_g=Y/s'
    str_4 = 'p*'
    str_5 = 'A0'
    str_6 = 'mS'
    float_0 = 114.69249611781325
    str_7 = 't=%c'
    str_8 = 'gF'
    int_0 = 2
    tuple_1 = ('et', 'n=')
    str_9 = 'S'
    list_0 = [str_5, str_6]


# Generated at 2022-06-25 15:24:04.879734
# Unit test for function read_user_dict
def test_read_user_dict():
    cookiecutter_dict = OrderedDict([])
    cookiecutter_dict = {
        "repo_name": "biscuit",
        "project_name": "sugar cookie",
        "description": "ginger snap",
        "author_name": "oat cookie",
        "email": "shortbread"
    }
    assert read_user_dict("repo_name", cookiecutter_dict) == cookiecutter_dict["repo_name"]
    assert read_user_dict("project_name", cookiecutter_dict) == cookiecutter_dict["project_name"]


# unit test for function prompt_choice_for_config
# note: this function also calls render_variable and prompt_choice_for_config

# Generated at 2022-06-25 15:24:17.519087
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import tempfile
    import json

    with tempfile.TemporaryDirectory() as template_folder:
        # Create a simple cookiecutter.json
        json_file = os.path.join(template_folder, 'cookiecutter.json')
        with open(json_file, 'w') as fh:
            fh.write(
                json.dumps(
                    {'project_name': 'Foo', 'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}'}
                )
            )

        # Test case 1:
        # Prompt the user for a value.
        # Check if the rendered value is provided by default.
        # Check if the value for each key matches the value given by the user.

# Generated at 2022-06-25 15:24:27.800294
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {u'cookiecutter': {u'_copy_without_render': [u'foobar'],
                                 u'foobar': [u'{{cookiecutter.name}}'],
                                 u'name': u'Jinja2',
                                 u'repo_name': u'{{cookiecutter.name}}'}}
    cookiecutter_dict = prompt_for_config(context)
    assert (u'Jinja2' == cookiecutter_dict.get('repo_name'))
    assert (u'{{cookiecutter.name}}' == cookiecutter_dict.get('foobar'))
    cookiecutter_dict = OrderedDict([])


# Generated at 2022-06-25 15:24:29.878181
# Unit test for function process_json
def test_process_json():
    example_dict = {'key': 'value'}
    assert process_json(json.dumps(example_dict)) == example_dict


# Generated at 2022-06-25 15:24:52.132485
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment()
    # These are defined directly, and can be used in the cookiecutter.json file,
    # but they may not be used in the cookiecutter dict itself.
    # They can be used in any other variables in the cookiecutter dict.
    # They use the format_var filter as a poor man's way of defining a
    # function that can be used in the cookiecutter dict.
    # {{ cookiecutter["_repo_name"] | format_var(cookiecutter["project_name"]) }}
    # TODO: replace with a formal function
    cookiecutter_dict['_repo_name'] = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    # {{ cookiecutter["_year"] | format_var }}

# Generated at 2022-06-25 15:24:54.846307
# Unit test for function read_user_dict
def test_read_user_dict():
    user = '{"name":"ng" , "age":10}'
    print(type(read_user_dict(user, "")))


# Generated at 2022-06-25 15:25:04.413333
# Unit test for function render_variable
def test_render_variable():
    cookiecutter_dict = OrderedDict([])
    context = OrderedDict([])
    context = {
        "cookiecutter":{
            "_template":{
                "repo_name": "project_name"
            },
            "project_name": "myproject"
        }
    }
    env = StrictEnvironment(context)
    raw = "{{ cookiecutter.project_name }}"
    cookiecutter_dict["repo_name"] = render_variable(env, raw, cookiecutter_dict)
    assert cookiecutter_dict["repo_name"] == "myproject"


# Generated at 2022-06-25 15:25:16.299049
# Unit test for function prompt_for_config
def test_prompt_for_config():
    assert prompt_for_config({'cookiecutter': {'project_name': 'test', 'project_slug': 'tester'}}) == {"project_name": 'test', 'project_slug': 'tester'}
    assert prompt_for_config({'cookiecutter': {'project_name': 'test', 'project_slug': 'tester', 'author_name': 'mark'}}) == {"project_name": 'test', 'project_slug': 'tester', "author_name": 'mark'}

# Generated at 2022-06-25 15:25:19.848228
# Unit test for function process_json
def test_process_json():
    user_value = '{ "name": "peanut butter cookie", "type": "cookie" }'
    process_json(user_value)

if __name__ == '__main__':
    test_case_0()
    test_process_json()

# Generated at 2022-06-25 15:25:21.404704
# Unit test for function prompt_for_config
def test_prompt_for_config():
    tuple_0 = ()
    var_0 = prompt_for_config(tuple_0)


# Generated at 2022-06-25 15:25:28.119613
# Unit test for function read_user_dict
def test_read_user_dict():
    tuple_0 = ('0', None, '[1, 2, 3]')
    obj_0 = read_user_dict(tuple_0[0], tuple_0[1])
    obj_1 = read_user_dict(tuple_0[0], tuple_0[2])
    obj_2 = read_user_dict(tuple_0[1], tuple_0[0])
    obj_3 = read_user_dict(tuple_0[1], tuple_0[2])
    obj_4 = read_user_dict(tuple_0[2], tuple_0[0])
    obj_5 = read_user_dict(tuple_0[2], tuple_0[1])
    obj_6 = read_user_dict(tuple_0[0], tuple_0[0])

# Generated at 2022-06-25 15:25:30.389992
# Unit test for function read_user_dict
def test_read_user_dict():
    read_user_dict("var_name", "default_value")


# Generated at 2022-06-25 15:25:33.714653
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict([('cookiecutter', OrderedDict([('repo_name', 'foobar')]))])
    cookiecutter_dict = prompt_for_config(context, False)
    print(cookiecutter_dict)

# Generated at 2022-06-25 15:25:38.465918
# Unit test for function read_user_dict
def test_read_user_dict():
    user_dict = read_user_dict(
        "joke",
        {"How do you make a Kleenex dance?": "Put a little boogie in it!"}
    )
    # Note: This is pretty weak. Should be compared to
    # {"How do you make a Kleenex dance?": "Put a little boogie in it!"}
    assert user_dict

# Generated at 2022-06-25 15:25:48.843509
# Unit test for function read_user_dict
def test_read_user_dict():
    # dict as input test
    dict_0 = OrderedDict()
    var_0 = read_user_dict('var_0', dict_0)

    # str as input test
    var_1 = 'Foobar'
    var_2 = read_user_dict('var_1', var_1)

    # int as input test
    var_3 = 42
    var_4 = read_user_dict('var_2', var_3)

    # float as input test
    var_5 = 42.0
    var_6 = read_user_dict('var_3', var_5)

    # list as input test
    list_0 = []
    var_7 = read_user_dict('var_4', list_0)

    # bool as input test
    var_8 = True

# Generated at 2022-06-25 15:25:49.989424
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'key0': 'value0'}}
    no_input = False
    prompt_for_config(context, no_input)


# Generated at 2022-06-25 15:25:54.801274
# Unit test for function render_variable
def test_render_variable():

    # In this line '_' is replaced by a space before showing in prompt
    context = '{{ cookiecutter.repo_name.replace("_", " ") }}'
    env = StrictEnvironment(context={})
    cookiecutter_dict = {'repo_name': 'Cookie_Cutter'}
    var = render_variable(env, context, cookiecutter_dict)

    assert var == 'Cookie Cutter', "Expected cookiecutter value not found"

# Generated at 2022-06-25 15:25:58.678561
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {}
    no_input = True
    prompt_for_config(context, no_input)

# Generated at 2022-06-25 15:26:01.316480
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = dict()
    env = dict()
    context = dict()
    no_input = False
    val = prompt_for_config(context, no_input)

# Generated at 2022-06-25 15:26:03.941336
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = {}
    var_0 = read_user_dict(dict_0, False)
    assert var_0 == False



# Generated at 2022-06-25 15:26:13.701502
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:26:15.152862
# Unit test for function read_user_dict
def test_read_user_dict():
    tuple_0 = ()
    dict_0 = read_user_dict(tuple_0, dict())



# Generated at 2022-06-25 15:26:19.311567
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = json.loads(open('tests/test_files/test_dict.json').read())
    print(prompt_for_config(context))


if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:26:23.370000
# Unit test for function read_user_dict
def test_read_user_dict():
    context = {
        'cookiecutter': {
            'key_01': '{{ cookiecutter.key_02 }}',
            'key_02': '{{ cookiecutter.key_01 }}',
        },
    }
    no_input = True
    cookiecutter_dict = prompt_for_config(context, no_input)
    assert cookiecutter_dict['key_01']


# Generated at 2022-06-25 15:26:46.485847
# Unit test for function prompt_for_config
def test_prompt_for_config():
    try:
        from cookiecutter.main import cookiecutter
    except ModuleNotFoundError:
        # Cookiecutter is not installed.
        # Ignore the error.
        return

    # Prompt the user to enter the configuration.

# Generated at 2022-06-25 15:26:48.648136
# Unit test for function prompt_for_config
def test_prompt_for_config():
    return read_repo_password("Test_prompt_for_config", "Test_prompt_for_config")


# Generated at 2022-06-25 15:27:00.876407
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = dict()
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = 'value_1'
    dict_0['key_2'] = 'value_2'

    dict_1 = dict()
    dict_1['key_0'] = 'value_0'
    dict_1['key_1'] = 'value_1'
    dict_1['key_2'] = 'value_2'

    dict_2 = dict()
    dict_2['key_0'] = 'value_0'
    dict_2['key_1'] = 'value_1'
    dict_2['key_2'] = 'value_2'

    dict_3 = dict()
    dict_3['key_0'] = 'value_0'

# Generated at 2022-06-25 15:27:10.938314
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:27:21.581017
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {"cookiecutter": {"name": "project1", "version": "1.0.0", "short_description": "Short description of project1"}}
    no_input = True
    result = prompt_for_config(context, no_input)
    assert result == {"name": "project1", "version": "1.0.0", "short_description": "Short description of project1"}

    context = {"cookiecutter": {"name": "project1", "version": "1.0.0", "short_description": "Short description of project1"}}
    no_input = False
    result = prompt_for_config(context, no_input)
    assert result == {"name": "project1", "version": "1.0.0", "short_description": "Short description of project1"}


# Generated at 2022-06-25 15:27:28.759751
# Unit test for function prompt_for_config
def test_prompt_for_config():
    try:
        context = {'cookiecutter': {'name': 'TestName', 'language': 'TestLanguage', 'unit_test': 'True', 'command_line_interface': 'TestCLI'}}
        no_input = False
        cookiecutter_dict = prompt_for_config(context, no_input)
        print('cookiecutter_dict: {}'.format(cookiecutter_dict))
    except Exception as e:
        print('Caught exception when calling prompt_for_config: {}'.format(e))



# Generated at 2022-06-25 15:27:31.353094
# Unit test for function prompt_for_config
def test_prompt_for_config():
    tuple_0 = ()
    var_0 = read_repo_password(tuple_0)

# Generated at 2022-06-25 15:27:34.055845
# Unit test for function read_user_dict
def test_read_user_dict():
    key = "tuple_0"
    default_value = {}
    res = read_user_dict(key, default_value)
    assert res == {}, "read_user_dict is broken"


# Generated at 2022-06-25 15:27:46.525277
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:27:52.423797
# Unit test for function render_variable
def test_render_variable():
    from jinja2 import Environment, FileSystemLoader

    # Reference: https://jinja.palletsprojects.com/en/2.10.x/api/
    template_directory = '.'
    env = Environment(loader=FileSystemLoader(template_directory))

    # Mock values for the test.
    key = 'project_name'
    raw = 'repo_{{cookiecutter.project_name}}'
    cookiecutter_dict = {'project_name': 'Chocolate'}

    rendered_variable = render_variable(env, raw, cookiecutter_dict)
    assert rendered_variable == 'repo_Chocolate'


# Generated at 2022-06-25 15:28:21.457571
# Unit test for function prompt_for_config
def test_prompt_for_config():

    context = {
        "cookiecutter": {
            "full_name": "Your Name",
            "email": "you@example.com",
        }
    }

    result = prompt_for_config(context)

    assert result is not None


if __name__ == '__main__':
    test_case_0()
    test_prompt_for_config()

# Generated at 2022-06-25 15:28:22.651120
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('', '') == {}


# Generated at 2022-06-25 15:28:26.345719
# Unit test for function read_user_choice
def test_read_user_choice():
    dict_0 = dict()
    dict_0['options'] = ['option 1', 'option 2', 'option 3', 'option 4']
    var_0 = read_user_choice('none', dict_0['options'])
    assert var_0 == 'option 1'



# Generated at 2022-06-25 15:28:29.016234
# Unit test for function read_user_dict
def test_read_user_dict():
    # This will fail because the default value is empty
    tuple_0 = ()
    var_0 = read_user_dict(tuple_0, None)
    print(var_0)


# Generated at 2022-06-25 15:28:40.232871
# Unit test for function prompt_for_config
def test_prompt_for_config():
    print("test_prompt_for_config")
    from cookiecutter.environment import Environment
    import os
    import shutil
    import tempfile
    import unittest
    import warnings
    from cookiecutter import utils

    def make_temp_directory():
        try:
            temp_dir = tempfile.mkdtemp()
        except OSError:
            # In case the operating system raises an OSError because it cannot
            # create a temporary directory (full disk, permissions, etc), we
            # fall back to a temporary directory in the current working
            # directory.
            warnings.warn(
                'Unable to create a temporary directory at an OS level. '
                'Falling back to a temporary directory in the current '
                'directory.'
            )

# Generated at 2022-06-25 15:28:46.198385
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    context = {
        'cookiecutter': {
            'project_name': 'test_project',
            'project_slug': 'test_project',
            'project_description': 'A short description of the project.',
            'project_license': 'MIT license',
            'author_name': 'Firstname Lastname',
            'email': 'f@l.com',
            'version': '0.1.0',
            'timezone': 'Europe/Paris',
        }
    }
    test_prompt_for_config = prompt_for_config(context, no_input=True)

    assert test_prompt_for_config


# Generated at 2022-06-25 15:28:53.241103
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': OrderedDict(
            [
                ('_template', 'foobar'),
                ('project_name', 'Cookiecutter-Puppet-Module')
            ]
        )
    }
    no_input = False
    cookiecutter_dict = prompt_for_config(context, no_input)
    assert cookiecutter_dict == {
        '_template': 'foobar',
        'project_name': 'Cookiecutter-Puppet-Module'
    }

# Generated at 2022-06-25 15:29:00.463197
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:29:05.389450
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = {}
    var_0 = read_user_dict(dict_0, dict_0)
    print(var_0)


# Generated at 2022-06-25 15:29:10.623001
# Unit test for function prompt_for_config
def test_prompt_for_config():
    var_0 = OrderedDict([])
    var_1 = StrictEnvironment()
    var_0['cookiecutter'] = OrderedDict([])
    var_0['cookiecutter']['full_name'] = "Your Name"
    var_0['cookiecutter']['email'] = "Your email"
    var_0['cookiecutter']['project_name'] = "Project Name"
    var_0['cookiecutter']['project_slug'] = "{{ cookiecutter.project_name.lower().replace(' ', '-') }}"
    var_0['cookiecutter']['project_short_description'] = "Project short description"
    var_0['cookiecutter']['pypi_username'] = "PyPI username"

# Generated at 2022-06-25 15:29:37.835449
# Unit test for function read_user_dict
def test_read_user_dict():
    data_0 = {}
    var_0 = read_user_dict("var_0", data_0)
    assert var_0 is {"": ""}


# Generated at 2022-06-25 15:29:43.063870
# Unit test for function process_json
def test_process_json():
    test_cases = []
    json_0 = '{"dict_key": "dict_value"}'
    var_0 = process_json(json_0)
    dict_0 = {'dict_key': 'dict_value'}
    test_cases.append((dict_0, var_0))
    json_1 = '0'
    var_1 = process_json(json_1)
    dict_1 = 0
    test_cases.append((dict_1, var_1))
    return test_cases


# Generated at 2022-06-25 15:29:44.388783
# Unit test for function prompt_for_config
def test_prompt_for_config():
    assert callable(prompt_for_config)


# Generated at 2022-06-25 15:29:48.487540
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter": {
            "foo": "bar"
        }
    }
    val = prompt_for_config(context=context)
    assert val["foo"] == "bar"

# Generated at 2022-06-25 15:29:58.984050
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_dict = {}
    env = StrictEnvironment()
    key = 'key'
    raw = 'raw'
    test_options = ['option_0', 'option_1', 'option_2']
    test_no_input = False

    # Call function prompt_for_config
    tuple_0 = (test_dict, env, key, test_options, test_no_input)
    val = prompt_choice_for_config(*tuple_0)

    # Check if the return of function prompt_for_config is equal to expected
    # return
    assert val == 'option_0'

    # Call function prompt_for_config
    test_dict = {}
    env = StrictEnvironment()
    key = 'key'
    raw = 'raw'
    test_no_input = False


# Generated at 2022-06-25 15:30:06.104479
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:08.296196
# Unit test for function read_user_dict
def test_read_user_dict():
    dict_0 = {}
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = 'value_1'
    dict_1 = read_user_dict('foo', dict_0)



# Generated at 2022-06-25 15:30:16.665990
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'My Project',
            'repo_name': '{{ cookiecutter.project_name.lower().replace(" ", "-") }}',
            'author_name': 'Simon Pamies',
            'year': 2017,
            'use_pytest': [
                {'false': 'n'},
                {'true': 'y'},
            ],
            '_some_dict': {
                'foo': 'bar',
            },
            '__some_dict': {
                'foo': 'bar',
            },
        }
    }
    cookiecutter = prompt_for_config(context, no_input=True)
    assert 'project_name' in cookiecutter
    assert cookiecutter['project_name'] == 'My Project'

# Generated at 2022-06-25 15:30:28.104451
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {}}
    assert prompt_for_config(context) == {}, 'Empty context raises error'

    # Setup test context
    context['cookiecutter'] = {'foo': 'bar'}
    context['cookiecutter']['foo'] = 'bar'
    context['cookiecutter']['foo'] = 'bar'
    assert prompt_for_config(context) == {'foo': 'bar'}, 'Renders a single variable'

    # Setup test context
    context['cookiecutter']['baz'] = 'qux'
    assert prompt_for_config(context) == {'foo': 'bar', 'baz': 'qux'}, 'Renders multiple variables'

    # Setup test context
    context['cookiecutter']['_copy_without_render'] = 'test'


# Generated at 2022-06-25 15:30:40.372892
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {"cookiecutter":
        {"repo_name": "Cookiecutter",
        "repo_description": "A command-line utility that creates projects from project templates.",
        "author_name": "Audrey Roy Greenfeld",
        "author_email": "audreyr@example.com",
        "github_username": "audreyr",
        "project_name": "Cookiecutter Django",
        "pypi_username": "audreyr",
        "release_date": "2013-06-18",
        "year": "2013",
        "version": "0.1.0"
         }
    }

    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context=context)

    # First pass: Handle simple and raw variables, plus choices.
    # These must

# Generated at 2022-06-25 15:31:40.868268
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'no_input': True,
            'repo_name': 'Default Repo Name',
            'use_pypi_deployment_with_travis': True,
        }
    }
    no_input = True
    cookiecutter_dict = {
        '_template': None,
        'cookiecutter': {
            'no_input': True,
            'repo_name': 'Default Repo Name',
            'use_pypi_deployment_with_travis': True,
        },
        '__repo_name': 'Default Repo Name',
        '__use_pypi_deployment_with_travis': True,
    }
    assert prompt_for_config(context, no_input) == cookiecutter_dict

# Generated at 2022-06-25 15:31:44.097854
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import cookiecutter
    template_path = r"C:\Work\cookiecutter-skeleton\tests\guinea_bissau"

    if cookiecutter.main.cookiecutter(template_path):
        print("SUCCESS")
    else:
        print("FAILED")


# Generated at 2022-06-25 15:31:55.188732
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'_template': {'abbr': 'cpp'}, 'project_slug': 'Peanut Butter Cookie', 'repo_name': '{{ cookiecutter.project_slug.replace(" ", "_") }}'}}
    cookiecutter_dict = OrderedDict([('_template', {'abbr': 'cpp'}), ('project_slug', 'Peanut Butter Cookie'), ('repo_name', 'Peanut_Butter_Cookie')])
    env = StrictEnvironment(context=context)

    # Pass #1: Regular variables
    for key, raw in context['cookiecutter'].items():
        if (key.startswith("_") and not key.startswith("__")):
            cookiecutter_dict[key] = raw
            continue

# Generated at 2022-06-25 15:31:56.959048
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict(key = "name", value = "jaja") == "jaja"


# Generated at 2022-06-25 15:32:03.423154
# Unit test for function read_user_choice
def test_read_user_choice():
    context = {
        'cookiecutter': {
            'cookiecutter': {
                'vars': {
                    'x': 'hello',
                    'y': 'world',
                    'z': 'Palo Alto',
                    'my_list': [1, 2, 3, 4]
                }
            }
        }
    }
    expected = {
        'cookiecutter': {
            'vars': {
                'x': 'hello',
                'y': 'world',
                'z': 'Palo Alto',
                'my_list': [1, 2, 3, 4]
            }
        }
    }
    assert prompt_for_config(context) == expected
