

# Generated at 2022-06-25 15:22:12.598956
# Unit test for function process_json
def test_process_json():
    # Note: Test fails because of unicode in output
    print('Expected: {u\'a\': 1, u\'b\': 2, u\'c\': 3}')
    user_value = '{"a": 1, "b": 2, "c": 3}'
    print('Actual: {}'.format(process_json(user_value)))

# Generated at 2022-06-25 15:22:14.634118
# Unit test for function read_user_dict
def test_read_user_dict():
    var_0 = read_user_dict('Ix\x02\xa3>', 'Ix\x02\xa3>')
    assert var_0 == b'Ix\x02\xa3>'

# Generated at 2022-06-25 15:22:21.911434
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment({})
    context = {'cookiecutter': {'_copy_without_render': {'yes': 'yes'}}}

    for key, raw in context['cookiecutter'].items():
        if key.startswith('_') and not key.startswith('__'):
            cookiecutter_dict[key] = raw
            continue
        elif key.startswith('__'):
            cookiecutter_dict[key] = render_variable(env, raw, cookiecutter_dict)
            continue


# Generated at 2022-06-25 15:22:27.853269
# Unit test for function process_json
def test_process_json():
    """
    >>> val = process_json('{"foo": "bar"}')
    >>> assert(isinstance(val, dict))
    """


# Generated at 2022-06-25 15:22:33.483470
# Unit test for function read_user_dict
def test_read_user_dict():
    context = {
        'cookiecutter': {
            'project_slug': 'testing_read_user_dict',
            '_copy_without_render': [
                'LICENSE'
            ],
            'license': 'MIT'
        }
    }
    user_dict = prompt_for_config(context, False)
    assert user_dict['project_slug'] == 'testing_read_user_dict'

# Generated at 2022-06-25 15:22:38.547718
# Unit test for function read_user_dict
def test_read_user_dict():
    context = {
        'cookiecutter': {
            'name': 'Unit test for function read_user_dict',
            '_template': '{{cookiecutter.name}} ({{cookiecutter.greeting}} {{cookiecutter.audience}})',
            'greeting': 'Hello',
        }
    }
    cookiecutter_dict = prompt_for_config(context)
    name = 'Unit test for function read_user_dict (Hello world)'
    assert name == cookiecutter_dict['_template']


# Generated at 2022-06-25 15:22:46.233243
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:22:56.448309
# Unit test for function process_json
def test_process_json():
    assert process_json('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}
    assert process_json('[1, 2, 3]') == [1, 2, 3]
    assert process_json('1') == 1
    assert process_json('"foo"') == "foo"
    assert process_json('true') == True
    assert process_json('false') == False
    assert process_json('null') == None
    assert process_json('{"a": "\\"", "b": "\'"}') == {"a": '"', "b": "'"}
    assert process_json('{"a": "\\\\", "b": "\\/"}') == {"a": "\\", "b": "/"}
    assert process_json('') == ''
   

# Generated at 2022-06-25 15:23:03.454547
# Unit test for function read_user_dict
def test_read_user_dict():
    print(read_user_dict(b'\x87\x94\xce\xcf[\x9a',b'\x87\x94\xce\xcf[\x9a'))



# Generated at 2022-06-25 15:23:10.581782
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Test 0
    context = {
        'cookiecutter': {
            'test_0': 'test_0',
            'test_1': 'test_1',
            'test_2': 'test_3',
            'test_3': 'test_4',
            'test_4': 'test_4',
            'test_5': 'test_5',
        }
    }
    no_input = False
    cookiecutter_dict = prompt_for_config(context, no_input)
    # Test 1
    pass  # no-op



# Generated at 2022-06-25 15:23:21.618260
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'key': ['value A', 'value B', 'value C'],
            'other_key': '{{cookiecutter.key[0]}} and {{cookiecutter.key[1]}}'
            }
        }
    env = StrictEnvironment(context=context)

    cookiecutter_dict = {
        'key': context['cookiecutter']['key'][0]
        }
    value = context['cookiecutter']['other_key']
    result = render_variable(env, value, cookiecutter_dict)

    print(result)


# Generated at 2022-06-25 15:23:31.333763
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test input arguments
    context_0 = OrderedDict()
    context_0['project_name'] = 'my-repo'
    context_0['archive_format'] = 'zip'
    context_0['_copy_without_render'] = []
    context_0['package_name'] = 'cookiecutter-django'
    context_0['version'] = '0.0.0'
    context_0['description'] = "A cookiecutter for creating a Django project"
    context_0['repo_name'] = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    context_0['year'] = '2019'
    context_0['full_name'] = 'Your name'
    context_0['email'] = 'your@email.com'

# Generated at 2022-06-25 15:23:37.808001
# Unit test for function read_user_dict
def test_read_user_dict():
    cookiecutter_dict = {}
    print('\n    >>> read_user_dict("Test for read_user_dict", {}, cookiecutter_dict)')
    test_case_0()

if __name__ == '__main__':
    # Unit test
    test_read_user_dict()

# Generated at 2022-06-25 15:23:47.092239
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context_0 = {}
    context_0['cookiecutter'] = {}
    context_0['cookiecutter']['full_name'] = 'Your Name'
    context_0['cookiecutter']['email'] = 'your.email@example.com'
    context_0['cookiecutter']['project_name'] = 'Your project name'
    context_0['cookiecutter']['repo_name'] = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    context_0['cookiecutter']['project_short_description'] = 'A short description of the project.'
    context_0['cookiecutter']['pypi_username'] = 'your pypi username'
    context_0['cookiecutter']['version'] = '0.1.0'
    context_

# Generated at 2022-06-25 15:23:54.372097
# Unit test for function prompt_for_config
def test_prompt_for_config():
    json_0 = '{"cookiecutter": {"project_slug": "foobar"}}'
    str_0 = '\n    >>> cookiecutter_dict = prompt_for_config(json.loads(json_0))\n    >>> assert(cookiecutter_dict["project_slug"] == "foobar")\n    '
    json_1 = '{"cookiecutter": {"repo_name": "cookiecutter-foobar", "project_slug": "foobar"}}'

# Generated at 2022-06-25 15:24:02.370124
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.context import Config
    from cookiecutter.main import main
    from pathlib import Path

    # Test without --no-input
    config_path = Path(__file__).parent.parent / 'tests' / 'test-config.yaml'
    try:
        config = Config.from_path(config_path)
        main(config)
    except Exception as err:
        print(err)

    # Test with --no-input
    config_path = Path(__file__).parent.parent / 'tests' / 'test-config.yaml'

# Generated at 2022-06-25 15:24:13.145789
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Instantiate mock object with mock method and mock arguments
    dummy_context = {}
    # Set mock attributes
    dummy_context['cookiecutter'] = mock_cookiecutter
    # Set mock return values
    mock_context = {}
    mock_context['cookiecutter'] = mock_cookiecutter
    # Set mock side effects
    # Call method with mock arguments, mock return values and mock side effects
    cookiecutter_dict = prompt_for_config(dummy_context)

    # Check call count
    # Check if function called

# Generated at 2022-06-25 15:24:20.296313
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:30.488469
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:38.896321
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:24:51.363130
# Unit test for function prompt_for_config
def test_prompt_for_config():
    global __test_counter
    __test_counter += 1
    assert(True), "Test case 0 ran"
    __test_counter += 1
    assert(True), "Test case 1 ran"

__test_counter = 0
if __name__ == '__main__':
    test_case_0()
    test_prompt_for_config()
    print('{} of 1 test cases ran.'.format(__test_counter))

# Generated at 2022-06-25 15:24:57.826773
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'val': '{{ cookiecutter.foo }}'}}
    no_input = True
    cookiecutter_dict = prompt_for_config(context, no_input)
    test_case_0()

if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:25:06.662344
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_dict_0 = OrderedDict([('raw_1', OrderedDict([('_raw_dict', OrderedDict([('project_name', 'cookiecutter-pypackage')]))])), ('raw_2', OrderedDict([('_raw_dict', OrderedDict([('project_name', 'cookiecutter-pypackage')]))]))])
    test_dict_1 = OrderedDict([('raw_1', OrderedDict([('_raw_dict', OrderedDict([('project_name', 'cookiecutter-pypackage')]))])), ('raw_2', OrderedDict([('_raw_dict', OrderedDict([('project_name', 'cookiecutter-pypackage')]))]))])
    test_dict_2 = OrderedDict

# Generated at 2022-06-25 15:25:12.214035
# Unit test for function read_user_dict
def test_read_user_dict():
    # Do not test on empty str or nonzero length str
    #if len(str_0) == 0 or len(str_0) > 1:
        #raise ValueError

    print("test_read_user_dict")
    print(test_case_0())
    print("\n")


# Generated at 2022-06-25 15:25:22.063604
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'some_key': 'some_value', 'another_key': 'another_value'}}
    # Testing normal cases
    assert(prompt_for_config({'cookiecutter': {'some_key': 'some_value', 'another_key': 'another_value'}}) == {'some_key': 'some_value', 'another_key': 'another_value'})
    assert(prompt_for_config({'cookiecutter': {'some_key': '{{ cookiecutter.another_key }}', 'another_key': 'another_value'}}) == {'some_key': 'another_value', 'another_key': 'another_value'})

# Generated at 2022-06-25 15:25:26.478451
# Unit test for function render_variable
def test_render_variable():
    cookiecutter_dict = {'project_name': 'cookiecutter-pypackage'}
    assert render_variable(context={}, raw='{{ cookiecutter.project_name }}',
                           cookiecutter_dict=cookiecutter_dict) == 'cookiecutter-pypackage'

if __name__ == '__main__':
    test_render_variable()

# Generated at 2022-06-25 15:25:37.447586
# Unit test for function read_user_dict
def test_read_user_dict():
    context = {'cookiecutter': {'foo': {'bar': 'baz'}}}
    no_input = True
    cookiecutter_dict = {}
    key = 'foo'
    raw = {'bar': 'baz'}

    # The first pass of the main loop in prompt_for_config does not
    # handle dictionaries.
    for k, v in context['cookiecutter'].items():
        if k.startswith('_') and not k.startswith('__'):
            cookiecutter_dict[k] = v
            continue
        elif k.startswith('__'):
            asset_equals(k, '__dict__', str_0)
            cookiecutter_dict[k] = render_variable(env, v, cookiecutter_dict)
            continue


# Generated at 2022-06-25 15:25:46.963785
# Unit test for function read_user_dict
def test_read_user_dict():
    print("Loading variables from context...")

    context = {'cookiecutter': {'foo': 'bar'}}
    no_input = True
    user_dict = prompt_for_config(context, no_input)

    user_dict_keys = list(user_dict.keys())
    foo = user_dict_keys[0]
    bar = user_dict_keys[1]

    print("\nContext keys:")
    print("    foo: " + foo)
    print("    bar: " + bar)

    print("\nTest cases:")
    print(str_0)

test_case_0()

# Generated at 2022-06-25 15:25:54.228053
# Unit test for function prompt_for_config
def test_prompt_for_config():
    env = '\n    >>> import subprocess\n    >>> from cookiecutter.main import cookiecutter\n    >>> context = cookiecutter(str(PWD), no_input=True)\n    >>> prompt_for_config(context)\n    '
    env_0 = '\n    >>> import subprocess\n    >>> from cookiecutter.main import cookiecutter\n    >>> context = cookiecutter(str(PWD), no_input=True)\n    >>> prompt_for_config(context)\n    '


# Generated at 2022-06-25 15:26:01.077132
# Unit test for function prompt_for_config
def test_prompt_for_config():
    str_0 = '\n    >>> mydict = { "A": "AAAA", "B": "BBBB", "C": "CCCC", "D": "DDDD" }\n    >>> result = prompt_for_config(mydict)\n    >>> assert(isinstance(result, OrderedDict))\n    '


# Generated at 2022-06-25 15:26:08.269797
# Unit test for function prompt_for_config
def test_prompt_for_config():
    str_1 = '\n    >>> val = prompt_for_config(__cookiecutter)\n    >>> assert(isinstance(val, dict))\n    '


# Generated at 2022-06-25 15:26:14.854227
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict([])
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])

    context = OrderedDict([])
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])
    key = 'key'
    raw = 'raw'
    no_input = False

    cookiecutter_dict[key] = raw


    assert(cookiecutter_dict[key] == raw)
    print("Test for function prompt_for_config() passed!")


# Generated at 2022-06-25 15:26:19.162897
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import sys
    import os
    import numpy as np
    import subprocess
    os.system("python test_prompt.py")
    os.system("python test_prompt.py --no-input")

test_prompt_for_config()

# Generated at 2022-06-25 15:26:26.212379
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['project_name'] = 'Cookiecutter'
    context['cookiecutter']['package_name'] = 'cookiecutter'
    context['cookiecutter']['repo_name'] = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    context['cookiecutter']['_copy_without_render'] = '[filename1, filename2]'
    context['cookiecutter']['__version__'] = '{{ cookiecutter.package_name }}-1.2.3'

    cookiecutter_dict = prompt_for_config(context)
    assert(cookiecutter_dict['project_name'] == 'Cookiecutter')


# Generated at 2022-06-25 15:26:35.431695
# Unit test for function prompt_for_config
def test_prompt_for_config():
    json_0 = '{"project_name": "Project name", "author_email": "me@example.com"}'
    context_0 = json.loads(json_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    cookiecutter_dict_0 = prompt_for_config(context_0, 1)
    print(cookiecutter_dict_0)


# Generated at 2022-06-25 15:26:39.224767
# Unit test for function prompt_for_config
def test_prompt_for_config():
    pass


if __name__ == '__main__':
    test_case_0()
    test_prompt_for_config()

# Generated at 2022-06-25 15:26:45.569399
# Unit test for function read_user_dict
def test_read_user_dict():
    expected_0 = 'bar'

    # Read 3 lines at end of file
    with open('examples/tests/test_read_user_dict.txt', 'r') as f:
        for i in range(3):
            f.readline()
        context_0 = json.load(f)
    result_0 = read_user_dict('foo', context_0)
    print(result_0)
    assert result_0 == expected_0


# Generated at 2022-06-25 15:26:52.371675
# Unit test for function prompt_for_config
def test_prompt_for_config():
    print('\nRunning test_prompt_for_config...')
    cookiecutter_dict = OrderedDict([])
    context = {
        'cookiecutter': {
            'access_token': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            'api_base_url': 'https://api.github.com',
            'description': 'A short description of the project.',
            'github_username': 'audreyr',
            'homepage': 'https://github.com/<github_username>/<repo_name>',
            'license': 'MIT',
            'name': 'Audrey Roy Greenfeld',
            'project_name': 'Cookiecutter-Pylibrary',
            'repo_name': 'cookiecutter-pylibrary',
            'version': '0.1.0'
        }
    }

# Generated at 2022-06-25 15:26:57.205848
# Unit test for function prompt_for_config
def test_prompt_for_config():
    print("Test of the function prompt_for_config")

    test_case_0()

if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:27:09.521815
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:27:15.792378
# Unit test for function read_user_dict
def test_read_user_dict():
    test_case_0()


# Generated at 2022-06-25 15:27:19.183206
# Unit test for function process_json
def test_process_json():
    # This test case will pass
    test_case_0()
    # It is pretty hard to write a unit test that would fail
    # It can be done by passing a non-JSON string,
    # but this will be caught by click
    pass



# Generated at 2022-06-25 15:27:22.230783
# Unit test for function prompt_for_config
def test_prompt_for_config():
    session = True
    context = {'cookiecutter': {'name': 'cookiecutter'}}
    no_input = True
    cookiecutter_dict = prompt_for_config(context, no_input)
    print(cookiecutter_dict)


# Generated at 2022-06-25 15:27:24.199287
# Unit test for function read_user_choice
def test_read_user_choice():
    name = "Which one?"
    options = ["Option 0", "Option 1"]
    choice = read_user_choice(name, options)


# Generated at 2022-06-25 15:27:32.996354
# Unit test for function process_json
def test_process_json():
    bool_0 = False
    bool_1 = True
    dict_0 = {"fgd":"XjO_"}
    dict_1 = {"!":"eH:"}
    dict_2 = {"xl,1_':X=":"oJh;"}
    list_0 = ["yG,`"]
    list_1 = ["?zt,Q%"]
    list_2 = ["t]S"]
    num_0 = 80845983
    num_1 = 130875964
    num_2 = 67788876

# Generated at 2022-06-25 15:27:41.886354
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:27:46.970018
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import work_in
    from cookiecutter.prompt import prompt_for_config

    with work_in('tests/test-case-0'):
        context = cookiecutter(
            '.',
            extra_context={
                'cookiecutter': {
                    'full_name': 'Peter',
                    'email': 'Peter@Peter.com',
                    'github_username': 'Pete',
                    'domain_name': 'Peter.com',
                }
            },
        )

        # Assert that the cookiecutter context has been properly populated

# Generated at 2022-06-25 15:27:53.643301
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:27:56.746306
# Unit test for function read_user_dict
def test_read_user_dict():
    var_0 = {}
    var_0 = read_user_dict('var_0', var_0)
    assert var_0 == {}


# Generated at 2022-06-25 15:28:06.187987
# Unit test for function prompt_for_config
def test_prompt_for_config():
    expected_value = {
        'project_name': 'TEST',
        'version': '0.0.0',
        'author_username': 'TEST',
        'author_email': 'TEST',
        'project_short_description': 'TEST',
        'repo_name': 'TEST',
        'repo_url': 'TEST',
        'repo_description': 'TEST',
        'year': 2018,
        'full_name': 'TEST',
        'github_username': 'TEST',
        'pypi_username': 'TEST',
        'first_element': 'TEST',
    }


# Generated at 2022-06-25 15:28:14.351261
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict(1, 2) == 2

# Generated at 2022-06-25 15:28:20.690165
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'project_name': 'foo'}}
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    assert ('project_name' in cookiecutter_dict) and (
        cookiecutter_dict['project_name'] == 'foo'
    )



# Generated at 2022-06-25 15:28:28.609602
# Unit test for function prompt_for_config
def test_prompt_for_config():
    print("\nStart unit test for function prompt_for_config")
    # Create a project with a given name
    project_name = 'Test Project'

    # Create a dict with the configs, with descriptions
    config = {}
    config['cookiecutter'] = {}
    config['cookiecutter']['project_name'] = '{{ cookiecutter.project_name.lower() }}'
    config['cookiecutter']['project_slug'] = '{{ cookiecutter.project_name.lower().replace(" ", "-") }}'
    config['cookiecutter']['project_short_description'] = 'A short description of the project.'
    config['cookiecutter']['pypi_username'] = 'github username'
    config['cookiecutter']['author_name'] = 'John Smith'

# Generated at 2022-06-25 15:28:39.944117
# Unit test for function process_json
def test_process_json():
    assert process_json(True) == True
    assert process_json('true') == True
    assert process_json('True') == True
    assert process_json('False') == False
    assert process_json('false') == False
    assert process_json('false') == False
    assert process_json(1) == True
    assert process_json(0) == False
    assert process_json('1') == True
    assert process_json('0') == False
    assert process_json(1) == True
    assert process_json(0) == False
    assert process_json('y') == True
    assert process_json('n') == False
    assert process_json('yes') == True
    assert process_json('no') == False
    assert process_json('Y') == True
    assert process_json('N') == False
   

# Generated at 2022-06-25 15:28:46.604586
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter JSON Loader Test',
            'project_slug': 'cookiecutter-json-loader-test',
            'project_short_description': 'Cookiecutter JSON Loader Test',
            '_template': 'https://github.com/xhochy/cookiecutter-json-loader-test',
            '_copy_without_render': '',
            '__version__': '0.0.1',
            'cookiecutter_version': '1.1.1',
            # '_destination': '.',
            # 'overwrite_if_exists': False
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    print(cookiecutter_dict)

# Generated at 2022-06-25 15:28:56.402226
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:29:05.273972
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:29:12.646197
# Unit test for function prompt_for_config
def test_prompt_for_config():
    file = 'tests/test-config.json'
    with open (file, 'r+') as json_file:
        context = json.load(json_file, object_pairs_hook=OrderedDict)
        no_input = False
        cookiecutter_dict = prompt_for_config(context, no_input)

    json_file.close()

if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-25 15:29:18.001234
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'project_name': 'test project'}}
    param_prompt_for_config = prompt_for_config(context, no_input=True)
    ans_prompt_for_config = {'project_name': 'test project'}
    assert param_prompt_for_config == ans_prompt_for_config

if __name__ == "__main__":
    test_case_0()
    test_prompt_for_config()
    print("Test cases passed")

# Generated at 2022-06-25 15:29:26.687750
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:29:36.770466
# Unit test for function prompt_for_config
def test_prompt_for_config():
    project_context = {'cookiecutter': {'_template': {'repo_name': 'foo'}}}
    cookiecutter_dict = prompt_for_config(project_context, no_input=True)
    assert cookiecutter_dict['repo_name'] == 'foo'

# Generated at 2022-06-25 15:29:44.141874
# Unit test for function prompt_for_config
def test_prompt_for_config():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    bool_3 = True
    bool_4 = False
    bool_5 = False
    bool_6 = True
    bool_7 = False
    bool_8 = False
    bool_9 = True
    bool_10 = False
    bool_11 = False
    bool_12 = True
    bool_13 = False
    bool_14 = False
    bool_15 = True
    bool_16 = False
    bool_17 = False
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()
    str_8 = str()
   

# Generated at 2022-06-25 15:29:53.489203
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:01.999212
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:14.156823
# Unit test for function prompt_for_config

# Generated at 2022-06-25 15:30:16.146561
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = OrderedDict([('cookiecutter', OrderedDict([('a_test_key', 'a_test_value')]))])
    prompt_for_config(context)
    #TODO finish this test

# Generated at 2022-06-25 15:30:19.076506
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_context = {"cookiecutter": {"repo_name": "Cookiecutter-Pylibrary"}}
    prompt_for_config(test_context)

# Generated at 2022-06-25 15:30:24.312599
# Unit test for function prompt_for_config
def test_prompt_for_config():
    assert (type(prompt_for_config({'cookiecutter': {'var_0': {'one': '1'}}}, True)) == type(OrderedDict()))


# Generated at 2022-06-25 15:30:26.598516
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test for prompt_for_config"""
    context = {'cookiecutter': {'repo_name': 'project_name'}}
    prompt_for_config(context)

# Generated at 2022-06-25 15:30:29.377442
# Unit test for function prompt_for_config
def test_prompt_for_config():
    with open("tests/test_context.json", "r") as f:
        json_data = json.load(f)
        new_dict = prompt_for_config(json_data, False)
    print("Test Results: ", new_dict)


# Generated at 2022-06-25 15:30:43.368146
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Sample context.
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            '_copy_without_render': ['do not copy me'],
        }
    }

    # Sanity check.
    cookiecutter_dict = prompt_for_config(context)
    assert (
        isinstance(cookiecutter_dict, dict) and
        'full_name' in cookiecutter_dict and
        'email' in cookiecutter_dict
    )



# Generated at 2022-06-25 15:30:49.928545
# Unit test for function render_variable
def test_render_variable():
    context = {
      "cookiecutter": {
        "name": "My i3 config",
        "from_user": "{{ cookiecutter.name }}",
        "var": {
            "from_var": "{{ cookiecutter.from_user }}"
        },
        "from_var": "{{ cookiecutter.var.from_var }}"
      }
    }
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    env = StrictEnvironment(context=context)
    q = render_variable(env, cookiecutter_dict["from_var"], cookiecutter_dict)
    assert q == "My i3 config"


# Generated at 2022-06-25 15:30:54.606023
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = OrderedDict([])
    question = 'Is this a test?'
    default_value = 'NO'
    no_input = False
    env = StrictEnvironment()
    context = {'cookiecutter': {}}
    result = prompt_for_config(context, no_input)
    assert result == cookiecutter_dict

# Generated at 2022-06-25 15:31:02.533547
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': '{{cookiecutter.repo_name}}',
            'repo_name': 'Project Name',
            '_template': {
                # This is only required for the 2nd pass
                'repo_name': '{{cookiecutter.repo_name}}',
            },
        },
    }
    no_input = True
    cookiecutter_dict = prompt_for_config(context, no_input)
    assert cookiecutter_dict['project_name'] == 'Project Name'
    assert cookiecutter_dict['repo_name'] == 'Project Name'


# Generated at 2022-06-25 15:31:11.333530
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'full_name': "Your Name",
            'email': "Your email",
            'github_username': 'Your GitHub username',
            'project_name': "My Project",
            'project_short_description': 'A short description of the project.'
        }
    }
    cookiecutter_dict = prompt_for_config(context)
    expected = {
        'full_name': 'Your Name',
        'email': 'Your email',
        'github_username': 'Your GitHub username',
        'project_name': 'My Project',
        'project_short_description': 'A short description of the project.'
    }
    assert cookiecutter_dict == expected

# Generated at 2022-06-25 15:31:14.109691
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # context = {'cookiecutter': {'x': 'y'}}
    # print(prompt_for_config(context))
    return


if __name__ == '__main__':
    try:
        _test()
    except:
        pass

# Generated at 2022-06-25 15:31:17.708123
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'project_name': 'Awesome Project',
            'username': 'audreyr',
            'description': 'The best project ever.',
            'version': '0.0.1',
            'open_source_license': 'MIT license'
        }
    }
    env = StrictEnvironment()
    assert render_variable(env, context, context['cookiecutter']) == context

# Generated at 2022-06-25 15:31:18.643083
# Unit test for function read_user_dict
def test_read_user_dict():
    read_user_dict("var_name", "default_value")


# Generated at 2022-06-25 15:31:30.656013
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Awesome Project',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'python_version': '3.6',
            'release_date': '{{ cookiecutter.project_slug|replace("-", "")|upper() }}',
            '_template': {
                'some': 'set',
                'of': 'raw',
                'variables': 'for',
                'testing': 'purposes',
            },
            'test_bool': False,
            'test_list': [0, 1],
        }
    }
    prompt_for_config(context)


if __name__ == '__main__':
    test_case_0()
    test_prompt_for_

# Generated at 2022-06-25 15:31:34.150516
# Unit test for function read_user_dict
def test_read_user_dict():
    a = read_user_dict("a", {'b': 1, 'c': 2})
    print(a)



# Generated at 2022-06-25 15:31:46.855573
# Unit test for function prompt_for_config
def test_prompt_for_config():
    bool_0 = True
    dict_0 = OrderedDict()
    dict_0['key_0'] = dict()
    dict_0['key_1'] = dict()
    dict_0['key_1']['key_0'] = dict()
    dict_0['key_2'] = dict()
    dict_0['key_2']['key_0'] = dict()
    dict_0['key_2']['key_1'] = dict()
    dict_0['key_2']['key_1']['key_0'] = dict()
    dict_0['key_2']['key_1']['key_0']['key_0'] = dict()
    dict_0['key_2']['key_1']['key_0']['key_1'] = dict

# Generated at 2022-06-25 15:31:58.231419
# Unit test for function prompt_for_config
def test_prompt_for_config():
    bool_0 = True
    list_0 = ['a', 'b', 'c']
    list_1 = ['a', 'b', 'c']
    list_2 = ['a', 'b', 'c']
    dict_0 = OrderedDict()
    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'}
    str_0 = 'str_0'
    context = OrderedDict([])
    context = {'cookiecutter': {'key_0': list_0, 'key_1': bool_0, 'key_2': dict_0, 'key_3': list_1, 'key_4': list_2, 'key_5': str_0}}
    no_input = False
    prompt_for_