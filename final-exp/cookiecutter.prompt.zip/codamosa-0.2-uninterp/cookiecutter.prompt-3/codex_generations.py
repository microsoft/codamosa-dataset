

# Generated at 2022-06-22 17:10:37.789789
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:49.074366
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:00.471872
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:11.578519
# Unit test for function process_json
def test_process_json():
    assert process_json('{"key": "value"}') == {'key': 'value'}
    assert process_json('{"key": "value", "key2": "value2"}') == {'key': 'value', 'key2': 'value2'}
    assert process_json('{"key": "value", "key2": "value2", "key3": "value3"}') == {'key': 'value', 'key2': 'value2', 'key3': 'value3'}
    assert process_json('{"key": "value", "key2": "value2", "key3": "value3", "key4": "value4"}') == {'key': 'value', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}

# Generated at 2022-06-22 17:11:24.667224
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}
    user_value = '{"key1": "value1", "key2": "value2", "key3": ["value3", "value4"]}'

# Generated at 2022-06-22 17:11:35.701975
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert user_dict == {"key1": "value1", "key2": "value2"}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    user_dict = process_json(user_value)
    assert user_dict == {"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": ["value3", "value4"]}'
    user_dict

# Generated at 2022-06-22 17:11:43.892766
# Unit test for function process_json
def test_process_json():
    assert process_json('{"foo": "bar"}') == {"foo": "bar"}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {"foo": "bar", "baz": "qux"}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux"}}') == {"foo": "bar", "baz": {"qux": "quux"}}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux", "corge": "grault"}}') == {"foo": "bar", "baz": {"qux": "quux", "corge": "grault"}}

# Generated at 2022-06-22 17:11:55.881610
# Unit test for function process_json
def test_process_json():
    """Test that process_json works as expected."""
    # Test that a valid JSON dict is returned
    user_value = '{"foo": "bar"}'
    result = process_json(user_value)
    assert isinstance(result, dict)
    assert result == {'foo': 'bar'}

    # Test that a valid JSON list is returned
    user_value = '["foo", "bar"]'
    result = process_json(user_value)
    assert isinstance(result, list)
    assert result == ['foo', 'bar']

    # Test that a valid JSON string is returned
    user_value = '"foo"'
    result = process_json(user_value)
    assert isinstance(result, str)
    assert result == 'foo'

    # Test that a valid JSON integer is returned

# Generated at 2022-06-22 17:12:05.824197
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    context['cookiecutter']['test_dict'] = {'a': 'b'}
    context['cookiecutter']['test_dict_default'] = {'a': 'b'}
    context['cookiecutter']['test_dict_default']['default'] = True
    context['cookiecutter']['test_dict_default_2'] = {'a': 'b'}
    context['cookiecutter']['test_dict_default_2']['default'] = True
    context['cookiecutter']['test_dict_default_2']['c'] = 'd'

# Generated at 2022-06-22 17:12:16.963368
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:35.909540
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:47.749013
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:12:53.865472
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": "bar", "baz": "qux", "quux": "corge"}') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert process_json('{"foo": "bar", "baz": "qux", "quux": "corge", "grault": "garply"}') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge', 'grault': 'garply'}


# Generated at 2022-06-22 17:13:05.421251
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:17.421954
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    # Test a valid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    # Test an invalid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        raise AssertionError

    # Test a valid JSON list
    user_value = '["value1", "value2"]'
    assert process_json(user_value) == ['value1', 'value2']

    # Test an invalid JSON list

# Generated at 2022-06-22 17:13:26.220360
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:36.385160
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:45.699531
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:56.947451
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:06.897203
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:19.007830
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:26.786817
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:32.671777
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'key': 'value'}
    assert read_user_dict('var_name', default_value) == default_value

    # Test with user input
    user_input = '{"key": "value"}'
    assert read_user_dict('var_name', default_value) == default_value

    # Test with invalid user input
    user_input = '{"key": "value'
    assert read_user_dict('var_name', default_value) == default_value

# Generated at 2022-06-22 17:14:41.651188
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test the function read_user_choice."""
    # Test with a list of options
    options = ['option1', 'option2', 'option3']
    var_name = 'test_var'
    user_choice = read_user_choice(var_name, options)
    assert user_choice in options
    # Test with an empty list
    options = []
    var_name = 'test_var'
    try:
        read_user_choice(var_name, options)
    except ValueError:
        pass
    # Test with a non-list
    options = 'option1'
    var_name = 'test_var'
    try:
        read_user_choice(var_name, options)
    except TypeError:
        pass

# Generated at 2022-06-22 17:14:50.426012
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    # Test for a simple variable
    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Fake Project'

    # Test for a choice variable
    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['open_source_license'] == 'MIT license'

    # Test for a dict variable
    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['author_name'] == 'Your Name'

    # Test for a private dict variable

# Generated at 2022-06-22 17:15:00.323436
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:11.592903
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:15:23.669585
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:34.779223
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:42.092872
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""

# Generated at 2022-06-22 17:15:52.304602
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'a': 'b'}
    user_value = '{"a": "b"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:16:02.527261
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:13.386450
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:21.513843
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import __version__ as cookiecutter_version
    import os
    import sys

    # Create a temporary directory
    temp_dir = os.path.join(os.path.dirname(__file__), 'temp')
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)

    # Create a temporary cookiecutter template
    template_dir = os.path.join(temp_dir, 'template')
    if not os.path.exists(template_dir):
        os.makedirs(template_dir)

    # Create a temporary cookiecutter template

# Generated at 2022-06-22 17:16:31.725728
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"name": "test", "version": "1.0.0"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['name'] == 'test'
    assert user_dict['version'] == '1.0.0'

    user_value = '{"name": "test", "version": "1.0.0", "dependencies": {"foo": "bar"}}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['name'] == 'test'
    assert user_dict['version'] == '1.0.0'
    assert user_dict['dependencies']['foo'] == 'bar'



# Generated at 2022-06-22 17:16:43.320526
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:52.033223
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test for function read_user_dict"""
    # Test for valid input
    assert read_user_dict('test_key', {'test_key': 'test_value'}) == {'test_key': 'test_value'}
    # Test for invalid input
    assert read_user_dict('test_key', {'test_key': 'test_value'}) != {'test_key': 'test_value2'}
    # Test for invalid input
    assert read_user_dict('test_key', {'test_key': 'test_value'}) != {'test_key2': 'test_value'}
    # Test for invalid input

# Generated at 2022-06-22 17:16:57.415568
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'a': 'b'}
    user_value = '{"c": "d"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value, user_value) == {'c': 'd'}

# Generated at 2022-06-22 17:17:06.962132
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:18.160683
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014/01/01'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'

# Generated at 2022-06-22 17:17:33.016888
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['_template'] == 'tests/fake-repo-tmpl/'
    assert context['cookiecutter']['__version__'] == '0.1.0'
    assert context['cookiecutter']['__author__'] == 'Audrey Roy'
    assert context['cookiecutter']['__email__'] == 'audreyr@example.com'

# Generated at 2022-06-22 17:17:36.890910
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    user_dict = read_user_dict('test_dict', {'test_key': 'test_value'})
    assert user_dict == {'test_key': 'test_value'}

# Generated at 2022-06-22 17:17:48.253516
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:53.552466
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'a': 'b'}
    user_value = '{"c": "d"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value, user_value) == {'c': 'd'}

# Generated at 2022-06-22 17:18:06.355960
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:18.519003
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:23.467794
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test the default value
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

    # Test the user input
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:18:31.282649
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    var_name = 'test_var'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key3": "value3", "key4": "value4"}'
    expected_value = {'key3': 'value3', 'key4': 'value4'}
    result = read_user_dict(var_name, default_value)
    assert result == expected_value

# Generated at 2022-06-22 17:18:43.494094
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:50.657729
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == json.loads(user_value)

# Generated at 2022-06-22 17:19:09.238466
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:13.478994
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/')
    assert context['repo_name'] == 'cookiecutter-fake-repo'

# Generated at 2022-06-22 17:19:22.592989
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    # Create a temporary project from the test repo
    context = cookiecutter('tests/test-repo-pre/', no_input=True)

    # Test the function
    user_dict = read_user_dict('test_dict', context['test_dict'])
    assert user_dict == context['test_dict']

# Generated at 2022-06-22 17:19:33.011147
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:42.361837
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/test-generate-dict/', no_input=True)
    assert context['cookiecutter']['dict_var'] == {'key1': 'value1'}

    context = cookiecutter('tests/test-generate-dict/', no_input=False)
    assert context['cookiecutter']['dict_var'] == {'key1': 'value1'}

    context = cookiecutter('tests/test-generate-dict/', no_input=False, extra_context={'dict_var': {'key2': 'value2'}})
    assert context['cookiecutter']['dict_var'] == {'key2': 'value2'}

# Generated at 2022-06-22 17:19:53.025129
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:20:05.434920
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:15.784945
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": {"bar": "baz"}}') == {'foo': {'bar': 'baz'}}
    assert process_json('{"foo": {"bar": "baz"}, "qux": "quux"}') == {'foo': {'bar': 'baz'}, 'qux': 'quux'}
    assert process_json('{"foo": ["bar", "baz"]}') == {'foo': ['bar', 'baz']}