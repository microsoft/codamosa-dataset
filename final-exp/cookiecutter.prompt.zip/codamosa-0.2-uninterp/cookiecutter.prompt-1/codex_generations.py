

# Generated at 2022-06-22 17:10:37.846649
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    # Test that the function works with a simple context
    context = {
        'cookiecutter': {
            'project_name': 'Test Project',
            'project_slug': 'test_project',
            'author_name': 'Test Author',
            'email': 'test@example.com',
            'description': 'A short description of the project.',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'timezone': 'UTC',
            'open_source_license': 'MIT',
        }
    }
    cookiecutter_dict = prompt_for_config(context)

# Generated at 2022-06-22 17:10:49.117363
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""

# Generated at 2022-06-22 17:11:00.512120
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:10.316292
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) != user_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) != read_user_dict(var_name, user_value)

# Generated at 2022-06-22 17:11:18.955885
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:25.931935
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, user_value)

# Generated at 2022-06-22 17:11:33.399318
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""
    # Setup
    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'

    # Test
    rendered_template = render_variable(env, raw, cookiecutter_dict)

    # Assert
    assert rendered_template == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:11:40.634005
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:52.273148
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:00.136109
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": {"f": "g"}}') == {"a": "b", "c": "d", "e": {"f": "g"}}
    assert process_json('{"a": "b", "c": "d", "e": {"f": "g", "h": "i"}}') == {"a": "b", "c": "d", "e": {"f": "g", "h": "i"}}

# Generated at 2022-06-22 17:12:12.521317
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:18.736785
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:12:31.392245
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:39.953723
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    assert context['cookiecutter']['_template'] == '.'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-22 17:12:46.783374
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/test-extend/', no_input=True)
    assert context['cookiecutter']['_dict'] == {'key': 'value'}

    context = cookiecutter('tests/test-extend/', no_input=False)
    assert context['cookiecutter']['_dict'] == {'key': 'value'}

# Generated at 2022-06-22 17:12:52.719732
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    # Test with default value
    var_name = 'test_var'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:12:54.972178
# Unit test for function read_user_choice
def test_read_user_choice():
    options = ['a', 'b', 'c']
    var_name = 'test'
    assert read_user_choice(var_name, options) == 'a'

# Generated at 2022-06-22 17:13:06.316615
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:14.264356
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:25.151463
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    var_name = 'var_name'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
   

# Generated at 2022-06-22 17:13:40.961918
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:47.868597
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:59.200589
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == default_value

    # Test with user input
    user_input = '{"key3": "value3", "key4": "value4"}'
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == {'key3': 'value3', 'key4': 'value4'}

    # Test with invalid user input
    user_input = '{"key3": "value3", "key4": "value4'
    user_dict = read_user_dict('test_dict', default_value)

# Generated at 2022-06-22 17:14:08.324997
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'

# Generated at 2022-06-22 17:14:17.232337
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function"""

# Generated at 2022-06-22 17:14:23.132889
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test for correct input
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test for incorrect input
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:14:28.270095
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment


# Generated at 2022-06-22 17:14:35.184545
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'
    assert process_json(user_value)

# Generated at 2022-06-22 17:14:45.102882
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:55.593731
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'})

# Generated at 2022-06-22 17:15:12.301177
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:20.057850
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key3": "value3", "key4": "value4"}'
    expected_value = {'key3': 'value3', 'key4': 'value4'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:15:30.965668
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:15:43.812447
# Unit test for function render_variable
def test_render_variable():
    """Unit test for function render_variable."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)

    env = StrictEnvironment(context=context)

    # Test for simple variable
    raw = '{{ cookiecutter.project_name }}'
    cookiecutter_dict = {'project_name': 'Test'}
    assert render_variable(env, raw, cookiecutter_dict) == 'Test'

    # Test for raw variable
    raw = '{{ cookiecutter._project_name }}'
    cookiecutter_dict = {'_project_name': 'Test'}
    assert render_variable(env, raw, cookiecutter_dict) == 'Test'

    # Test for choice variable

# Generated at 2022-06-22 17:15:53.828255
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:03.408576
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with a valid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = read_user_dict('var_name', {'key1': 'value1'}, user_value)
    assert user_dict == {'key1': 'value1', 'key2': 'value2'}

    # Test with a valid JSON dict with default value
    user_value = 'default'
    user_dict = read_user_dict('var_name', {'key1': 'value1'}, user_value)
    assert user_dict == {'key1': 'value1'}

    # Test with an invalid JSON dict

# Generated at 2022-06-22 17:16:13.801535
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:19.200783
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:30.540294
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:37.374531
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test'
    default_value = {'a': 'b'}
    user_value = '{"c": "d"}'
    result = read_user_dict(var_name, default_value)
    assert result == default_value
    result = read_user_dict(var_name, default_value, user_value)
    assert result == {'c': 'd'}

# Generated at 2022-06-22 17:16:52.247047
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:01.058415
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:12.228777
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True, output_dir='.')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014/02/01'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'
    assert context

# Generated at 2022-06-22 17:17:22.421316
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test prompt_for_config function
    """

# Generated at 2022-06-22 17:17:32.529883
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:43.877494
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:48.109679
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test_var'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key3": "value3", "key4": "value4"}'
    expected_value = {'key3': 'value3', 'key4': 'value4'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:18:00.787080
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:09.414055
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    assert context['cookiecutter']['test_dict'] == {
        'test_key': 'test_value'
    }

    context = cookiecutter('.', no_input=False)
    assert context['cookiecutter']['test_dict'] == {
        'test_key': 'test_value'
    }

    context = cookiecutter('.', no_input=False, extra_context={'test_dict': {'test_key': 'test_value'}})
    assert context['cookiecutter']['test_dict'] == {
        'test_key': 'test_value'
    }


# Generated at 2022-06-22 17:18:16.429452
# Unit test for function render_variable
def test_render_variable():
    """Test for function render_variable."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:18:33.148406
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter-Puppet',
            'project_slug': 'cookiecutter-puppet',
            'author_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'description': 'A cookiecutter for a Puppet module',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'timezone': 'UTC',
            'open_source_license': 'MIT license',
            '_template': '.',
            '__version__': '1.4.0',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)

# Generated at 2022-06-22 17:18:45.105087
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:51.585621
# Unit test for function render_variable
def test_render_variable():
    """Test render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()

# Generated at 2022-06-22 17:18:58.653224
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_slug'] == 'fake-project'
    assert context['cookiecutter']['repo_name'] == 'fake-project'
    assert context['cookiecutter']['project_name'] == 'Fake Project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'

# Generated at 2022-06-22 17:19:10.626491
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:15.831862
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'key': 'value'}
    user_value = '{"key": "value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == json.loads(user_value)

# Generated at 2022-06-22 17:19:21.769297
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test'
    default_value = {'a': 'b'}
    user_value = '{"a": "b"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)

# Generated at 2022-06-22 17:19:32.429012
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:38.455787
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:52.753937
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from click.testing import CliRunner
    from cookiecutter.main import cookiecutter

    runner = CliRunner()
    result = runner.invoke(
        cookiecutter,
        [
            'tests/test-generate-files/fake-repo-pre/',
            '--no-input',
            '--config-file',
            'tests/test-generate-files/fake-repo-pre/cookiecutter.json',
        ],
    )
    assert result.exit_code == 0
    assert result.output.count('fake_key') == 1
    assert result.output.count('fake_value') == 1


# Generated at 2022-06-22 17:20:10.126483
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:19.752140
# Unit test for function prompt_for_config