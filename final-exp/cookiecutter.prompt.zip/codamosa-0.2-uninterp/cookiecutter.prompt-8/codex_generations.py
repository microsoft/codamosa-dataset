

# Generated at 2022-06-22 17:10:29.383685
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    Test read_user_dict function
    """
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:10:38.519017
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

# Generated at 2022-06-22 17:10:49.904139
# Unit test for function render_variable
def test_render_variable():
    """Test render_variable function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    env = StrictEnvironment(context=context)

    # Test that render_variable returns the same value as the default
    # if no input is provided.
    assert render_variable(env, '{{ cookiecutter.project_name }}', context) == '{{ cookiecutter.project_name }}'

    # Test that render_variable returns the same value as the default
    # if no input is provided.
    assert render_variable(env, '{{ cookiecutter.project_name }}', context) == '{{ cookiecutter.project_name }}'

    # Test that render_variable returns the same value as the default
    # if no input is provided.


# Generated at 2022-06-22 17:11:01.239378
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:11.970184
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:24.705943
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:35.774841
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:38.913300
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test function read_user_choice."""
    assert read_user_choice('var_name', ['a', 'b', 'c']) == 'a'
    assert read_user_choice('var_name', ['a', 'b', 'c']) == 'b'
    assert read_user_choice('var_name', ['a', 'b', 'c']) == 'c'

# Generated at 2022-06-22 17:11:43.875249
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test with default value
    default_value = {'a': 'b'}
    assert read_user_dict('test', default_value) == default_value

    # Test with user input
    user_value = '{"a": "b"}'
    assert read_user_dict('test', default_value) == default_value

    # Test with invalid user input
    user_value = '{"a": "b"'
    try:
        read_user_dict('test', default_value)
    except click.UsageError:
        pass
    else:
        assert False, 'Should have raised click.UsageError'

# Generated at 2022-06-22 17:11:54.443604
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    from cookiecutter.prompt import read_user_dict
    from click.testing import CliRunner
    import json

    runner = CliRunner()
    result = runner.invoke(
        read_user_dict,
        ['var_name', '{"key1": "value1", "key2": "value2"}'],
        input='{"key3": "value3", "key4": "value4"}',
    )
    assert result.exit_code == 0
    assert json.loads(result.output) == {
        'key3': 'value3',
        'key4': 'value4',
    }

# Generated at 2022-06-22 17:12:08.265961
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:19.505173
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:25.236050
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux"}}') == {'foo': 'bar', 'baz': {'qux': 'quux'}}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux"}, "corge": "grault"}') == {'foo': 'bar', 'baz': {'qux': 'quux'}, 'corge': 'grault'}

# Generated at 2022-06-22 17:12:36.558601
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:12:45.860258
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test prompt_for_config function
    """

# Generated at 2022-06-22 17:12:53.332615
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test that the function returns the default value if no input is provided
    default_value = {'key1': 'value1', 'key2': 'value2'}
    assert read_user_dict('var_name', default_value) == default_value

    # Test that the function returns the default value if the user inputs 'default'
    assert read_user_dict('var_name', default_value) == default_value

    # Test that the function returns the correct value if the user inputs a valid dict
    user_input = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict('var_name', default_value) == default_value

    # Test that the function raises a click.UsageError if the user inputs an invalid dict

# Generated at 2022-06-22 17:13:04.657603
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    result = read_user_dict('test_var', default_value)
    assert result == default_value

    # Test with user input
    user_input = '{"key1": "value1", "key2": "value2"}'
    result = read_user_dict('test_var', default_value)
    assert result == default_value

    # Test with user input
    user_input = '{"key1": "value1", "key2": "value2"}'
    result = read_user_dict('test_var', default_value)
    assert result == default_value

    # Test with user input

# Generated at 2022-06-22 17:13:12.836541
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:23.621758
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:29.428684
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:39.753164
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    assert render_variable(env, '{{ cookiecutter.project_name.replace(" ", "_") }}', cookiecutter_dict) == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:13:47.327868
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function"""

# Generated at 2022-06-22 17:13:58.669524
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:07.853818
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:16.826863
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:26.002002
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:33.966947
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2"}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'

# Generated at 2022-06-22 17:14:44.060914
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:52.732207
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:15:03.493077
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:14.807087
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:29.449351
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    # Test with a simple context

# Generated at 2022-06-22 17:15:38.830829
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:48.206470
# Unit test for function process_json
def test_process_json():
    assert process_json('{"a": "b"}') == {'a': 'b'}
    assert process_json('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-22 17:15:59.583009
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    Test the function read_user_dict
    """
    # Test with a valid input
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict("test", {"key1": "value1", "key2": "value2"}) == json.loads(user_value, object_pairs_hook=OrderedDict)

    # Test with an invalid input
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict("test", {"key1": "value1", "key2": "value2"}) == json.loads(user_value, object_pairs_hook=OrderedDict)

# Generated at 2022-06-22 17:16:11.470326
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:18.083825
# Unit test for function render_variable
def test_render_variable():
    """Unit test for function render_variable."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment(context={'cookiecutter': {'project_name': 'Peanut Butter Cookie'}})
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    cookiecutter_dict = {}
    assert render_variable(env, raw, cookiecutter_dict) == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:16:25.494593
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with default value
    default_value = {'a': 'b'}
    assert read_user_dict('test', default_value) == default_value

    # Test with user input
    user_value = '{"a": "b"}'
    assert read_user_dict('test', default_value) == json.loads(user_value)

# Generated at 2022-06-22 17:16:35.457394
# Unit test for function process_json
def test_process_json():
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": {"d": "e", "f": "g"}}') == {"a": "b", "c": {"d": "e", "f": "g"}}

# Generated at 2022-06-22 17:16:38.230097
# Unit test for function read_user_choice
def test_read_user_choice():
    options = ['foo', 'bar', 'baz']
    var_name = 'test'
    assert read_user_choice(var_name, options) in options


# Generated at 2022-06-22 17:16:52.063204
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:01.033543
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:06.478380
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"a": "c"}'
    expected_value = {'a': 'c'}
    actual_value = read_user_dict(var_name, default_value)
    assert actual_value == expected_value

# Generated at 2022-06-22 17:17:17.812750
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""

# Generated at 2022-06-22 17:17:24.791936
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:33.517766
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:42.248836
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:17:53.080043
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:00.704212
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == user_value

# Generated at 2022-06-22 17:18:09.364838
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""

# Generated at 2022-06-22 17:18:26.323979
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:34.772102
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    env = StrictEnvironment(context=context)

    # Test a simple variable
    assert render_variable(env, '{{ cookiecutter.project_name }}', context) == 'fakeproject'

    # Test a variable with a filter
    assert render_variable(env, '{{ cookiecutter.project_name|lower }}', context) == 'fakeproject'

    # Test a variable with a filter and an argument
    assert render_variable(env, '{{ cookiecutter.project_name|replace(" ", "_") }}', context) == 'fakeproject'

    # Test a variable with a filter and an

# Generated at 2022-06-22 17:18:46.309264
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"a": "b", "c": "d"}'
    assert process_json(user_value) == {'a': 'b', 'c': 'd'}

    user_value = '{"a": "b", "c": "d", "e": {"f": "g"}}'
    assert process_json(user_value) == {'a': 'b', 'c': 'd', 'e': {'f': 'g'}}

    user_value = '{"a": "b", "c": "d", "e": ["f", "g"]}'
    assert process_json(user_value) == {'a': 'b', 'c': 'd', 'e': ['f', 'g']}


# Generated at 2022-06-22 17:18:52.274519
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:18:56.193245
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with default value
    user_dict = read_user_dict('test_dict', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test with user input
    user_dict = read_user_dict('test_dict', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:19:08.821554
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:14.308541
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test with default value
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

    # Test with user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-22 17:19:26.852993
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:19:35.584001
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == default_value

    # Test with user input
    user_input = '{"key3": "value3", "key4": "value4"}'
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == {'key3': 'value3', 'key4': 'value4'}

# Generated at 2022-06-22 17:19:43.408678
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": ["value3", "value4"]}'

# Generated at 2022-06-22 17:19:55.527030
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:20:07.059037
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:17.610840
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    # Create a temporary project
    project_dir = cookiecutter(
        'tests/test-render-variable/',
        no_input=True,
        extra_context={'project_name': 'Foo Bar'},
    )

    # Read the cookiecutter.json file
    with open(project_dir + '/cookiecutter.json') as f:
        context = json.load(f)

    # Create the environment
    env = StrictEnvironment(context=context)

    # Render the variable
    rendered_variable = render_variable(env, '{{ cookiecutter.project_name }}', context)

    # Assert that the variable was rendered correctly