

# Generated at 2022-06-22 17:10:29.984956
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:38.765575
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:50.150511
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:55.098300
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:11:05.957595
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:14.420886
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test 1
    var_name = 'test'
    default_value = {'a': 'b'}
    user_value = '{"a": "b"}'
    assert read_user_dict(var_name, default_value) == default_value

    # Test 2
    var_name = 'test'
    default_value = {'a': 'b'}
    user_value = '{"a": "c"}'
    assert read_user_dict(var_name, default_value) == {'a': 'c'}

    # Test 3
    var_name = 'test'
    default_value = {'a': 'b'}
    user_value = '{"a": "c", "d": "e"}'
    assert read_user_dict

# Generated at 2022-06-22 17:11:20.517465
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test with user input
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:11:28.269597
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:33.520859
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    expected_result = {'key1': 'value1', 'key2': 'value2'}
    result = process_json(user_value)
    assert result == expected_result

# Generated at 2022-06-22 17:11:36.022532
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test'
    default_value = {'test': 'test'}
    assert read_user_dict(var_name, default_value) == {'test': 'test'}

# Generated at 2022-06-22 17:11:51.851869
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    # Test a valid JSON string
    user_value = '{"foo": "bar"}'
    assert process_json(user_value) == {"foo": "bar"}

    # Test an invalid JSON string
    user_value = '{"foo": "bar"'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        raise AssertionError("process_json should raise click.UsageError")

    # Test a valid JSON string that is not a dict
    user_value = '["foo", "bar"]'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        raise AssertionError("process_json should raise click.UsageError")

# Generated at 2022-06-22 17:12:00.027354
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['project_short_description'] == 'A command-line utility that creates projects from project templates, e.g. creating a Python package project from a Python package project template.'
    assert context['cookiecutter']['release_date'] == '2013-09-25'
    assert context['cookiecutter']['year']

# Generated at 2022-06-22 17:12:08.202286
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a temporary project from the test repo
    repo_dir = 'tests/test-repo-pre/'
    context = cookiecutter(repo_dir, no_input=True)

    # Test the render_variable function
    env = StrictEnvironment(context=context)
    assert render_variable(env, '{{ cookiecutter.project_name }}', context) == 'Cookiecutter'
    assert render_variable(env, '{{ cookiecutter.project_name.upper() }}', context) == 'COOKIECUTTER'

# Generated at 2022-06-22 17:12:19.504952
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:25.390857
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    # Test with a valid JSON string
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    # Test with an invalid JSON string
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True
    else:
        assert False

    # Test with a valid JSON string but not a dict
    user_value = '["value1", "value2"]'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True

# Generated at 2022-06-22 17:12:36.688410
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:47.808940
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    # Create a temporary project
    project_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Load the context
    context_file = project_dir + '/cookiecutter.json'
    with open(context_file) as f:
        context = json.load(f)

    # Create a Jinja2 environment
    env = StrictEnvironment(context=context)

    # Test the render_variable function
    assert render_variable(env, '{{ cookiecutter.project_name }}', context) == 'fake-project'

# Generated at 2022-06-22 17:12:54.876424
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:06.281675
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:14.220545
# Unit test for function process_json
def test_process_json():
    """Test for function process_json"""
    assert process_json('{"key": "value"}') == {"key": "value"}
    assert process_json('{"key": "value", "key2": "value2"}') == {"key": "value", "key2": "value2"}
    assert process_json('{"key": "value", "key2": "value2", "key3": "value3"}') == {"key": "value", "key2": "value2", "key3": "value3"}
    assert process_json('{"key": "value", "key2": "value2", "key3": "value3", "key4": "value4"}') == {"key": "value", "key2": "value2", "key3": "value3", "key4": "value4"}

# Generated at 2022-06-22 17:13:24.126528
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:13:30.592248
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"c": "d"}'
    expected_value = {'c': 'd'}
    assert read_user_dict(var_name, default_value) == expected_value
    assert read_user_dict(var_name, default_value, user_value) == expected_value

# Generated at 2022-06-22 17:13:33.333955
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"foo": "bar"}'
    assert process_json(user_value) == {"foo": "bar"}

# Generated at 2022-06-22 17:13:43.819139
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'


# Generated at 2022-06-22 17:13:49.670287
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    var_name = 'test_var'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == user_value

# Generated at 2022-06-22 17:14:00.995186
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:13.163771
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:24.033250
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:27.213127
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    var_name = "test"
    default_value = {"a": "b"}
    user_value = '{"a": "b"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:14:34.613852
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:46.380753
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:14:55.959171
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:05.661307
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:09.962733
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"a": "c"}'
    expected_value = {'a': 'c'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:15:23.566953
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:34.711725
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:15:42.015850
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:52.544601
# Unit test for function render_variable
def test_render_variable():
    """Test for function render_variable"""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.exceptions import UndefinedVariableInTemplate

    env = StrictEnvironment(context={'cookiecutter': {'project_name': 'Peanut Butter Cookie'}})
    cookiecutter_dict = OrderedDict([])

    # Test for simple variable
    raw = '{{ cookiecutter.project_name }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut Butter Cookie'

    # Test for variable with function
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)

# Generated at 2022-06-22 17:16:02.690232
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""

# Generated at 2022-06-22 17:16:13.516685
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:30.619747
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    env = StrictEnvironment(context=context)

    # Test that a simple variable is rendered correctly
    rendered_variable = render_variable(env, '{{ cookiecutter.project_name }}', context)
    assert rendered_variable == 'Cookiecutter'

    # Test that a complex variable is rendered correctly
    rendered_variable = render_variable(env, '{{ cookiecutter.project_name.replace(" ", "_") }}', context)
    assert rendered_variable == 'Cookiecutter'

    # Test that a list variable is rendered correctly

# Generated at 2022-06-22 17:16:42.565339
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:51.331134
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""

# Generated at 2022-06-22 17:17:00.641231
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:11.616545
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:22.022590
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    from click.testing import CliRunner
    from cookiecutter.prompt import read_user_dict

    runner = CliRunner()
    result = runner.invoke(
        read_user_dict,
        ['var_name', '{"key": "value"}'],
        input='{"key": "value"}',
    )
    assert result.exit_code == 0
    assert result.output == '{\n    "key": "value"\n}\n'

    result = runner.invoke(
        read_user_dict,
        ['var_name', '{"key": "value"}'],
        input='{"key": "value"}',
    )
    assert result.exit_code == 0

# Generated at 2022-06-22 17:17:31.301790
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    # Test with a valid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2"}

    # Test with an invalid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        raise AssertionError("process_json should raise a click.UsageError")

# Generated at 2022-06-22 17:17:43.094299
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "test_dict"
    default_value = {"a": "b"}
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value
    user_value = read_user_dict(var_name, default_value)

# Generated at 2022-06-22 17:17:53.805532
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:06.426455
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:15.656955
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    user_dict = read_user_dict('test', {'test': 'test'})
    assert user_dict == {'test': 'test'}

# Generated at 2022-06-22 17:18:27.061843
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:34.956798
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:39.869843
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment


# Generated at 2022-06-22 17:18:50.623011
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:58.283245
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:09.956164
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:19.578002
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:30.726747
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:40.745368
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:54.946686
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:06.640757
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:20:17.238773
# Unit test for function prompt_for_config