

# Generated at 2022-06-22 17:10:30.536005
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:38.983295
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:50.611736
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:01.812317
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:12.305740
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """Unit test for function prompt_choice_for_config."""
    context = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.project_slug.replace("-", " ") }}',
            'project_slug': '{{ cookiecutter.project_name.replace(" ", "-") }}',
            'project_type': [
                '{{ cookiecutter.project_slug.replace("-", " ") }}',
                '{{ cookiecutter.project_name.replace(" ", "-") }}',
            ],
        }
    }
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context=context)

    # First pass: Handle simple and raw variables, plus choices.
    # These must be done first because the dictionaries keys and
    # values might refer

# Generated at 2022-06-22 17:11:16.809525
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    # Test with a valid JSON string
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2"}

    # Test with an invalid JSON string
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True
    else:
        assert False

    # Test with a valid JSON string but not a dict
    user_value = '["value1", "value2"]'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True

# Generated at 2022-06-22 17:11:26.564644
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:37.188940
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:46.783380
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    # Test a valid JSON dict
    user_value = '{"a": "b"}'
    expected = {"a": "b"}
    assert process_json(user_value) == expected

    # Test an invalid JSON dict
    user_value = '{"a": "b"'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        assert False, "Should have raised click.UsageError"

    # Test a valid JSON list
    user_value = '["a", "b"]'
    expected = ["a", "b"]
    assert process_json(user_value) == expected

    # Test an invalid JSON list
    user_value = '["a", "b"'

# Generated at 2022-06-22 17:11:57.698095
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:13.056465
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('test_var', {'test_key': 'test_value'}) == {'test_key': 'test_value'}

    # Test with user input
    assert read_user_dict('test_var', {'test_key': 'test_value'}) == {'test_key': 'test_value'}

# Generated at 2022-06-22 17:12:22.148853
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'

# Generated at 2022-06-22 17:12:33.835767
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:40.628481
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "biz"}') == {'foo': 'bar', 'baz': 'biz'}
    assert process_json('{"foo": {"bar": "baz"}}') == {'foo': {'bar': 'baz'}}
    assert process_json('{"foo": {"bar": "baz", "biz": "buz"}}') == {'foo': {'bar': 'baz', 'biz': 'buz'}}
    assert process_json('{"foo": ["bar", "baz"]}') == {'foo': ['bar', 'baz']}

# Generated at 2022-06-22 17:12:51.195448
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:01.890259
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/test-cookiecutter-prj/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2013-07-10'
    assert context['cookiecutter']['year'] == '2013'

# Generated at 2022-06-22 17:13:10.979188
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:18.125559
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test the prompt_for_config function
    """

# Generated at 2022-06-22 17:13:27.819092
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:37.746940
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test function read_user_choice."""
    # Test with empty list
    try:
        read_user_choice('var_name', [])
    except ValueError:
        pass
    else:
        raise AssertionError

    # Test with list of strings
    assert read_user_choice('var_name', ['a', 'b', 'c']) == 'a'

    # Test with list of integers
    assert read_user_choice('var_name', [1, 2, 3]) == 1

    # Test with list of floats
    assert read_user_choice('var_name', [1.0, 2.0, 3.0]) == 1.0

    # Test with list of booleans
    assert read_user_choice('var_name', [True, False]) == True

    # Test with list of mixed types


# Generated at 2022-06-22 17:13:53.801622
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test function read_user_choice."""
    # Test with empty list
    try:
        read_user_choice('test', [])
        assert False
    except ValueError:
        assert True

    # Test with list of one element
    assert read_user_choice('test', ['a']) == 'a'

    # Test with list of two elements
    assert read_user_choice('test', ['a', 'b']) in ['a', 'b']

    # Test with list of three elements
    assert read_user_choice('test', ['a', 'b', 'c']) in ['a', 'b', 'c']

    # Test with list of four elements
    assert read_user_choice('test', ['a', 'b', 'c', 'd']) in ['a', 'b', 'c', 'd']

    #

# Generated at 2022-06-22 17:14:03.555524
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:13.282010
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:14:24.076038
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:26.567683
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "test_var"
    default_value = {'a': 'b', 'c': 'd'}
    user_value = '{"a": "b", "c": "d"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == user_value

# Generated at 2022-06-22 17:14:30.626772
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:14:40.194428
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""

# Generated at 2022-06-22 17:14:42.931371
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:14:47.974036
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test for default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test for user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:14:57.855822
# Unit test for function render_variable
def test_render_variable():
    """Test function render_variable."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
        }
    }
    cookiecutter_dict = {}
    assert render_variable(env, '{{ cookiecutter.repo_name }}', cookiecutter_dict) == 'Peanut_Butter_Cookie'
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    assert render_variable(env, '{{ cookiecutter.repo_name }}', cookiecutter_dict) == 'Peanut_Butter_Cookie'
    cookiecutter_dict

# Generated at 2022-06-22 17:15:13.535328
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:24.640261
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    context['cookiecutter']['test_dict'] = {'test_key': 'test_value'}
    context['cookiecutter']['test_dict_default'] = {'test_key': 'test_value'}
    context['cookiecutter']['test_dict_default']['default'] = True

    # Test default value
    assert read_user_dict('test_dict_default', context['cookiecutter']['test_dict_default']) == context['cookiecutter']['test_dict_default']

    # Test user input

# Generated at 2022-06-22 17:15:35.492675
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:39.928915
# Unit test for function render_variable
def test_render_variable():
    """Test function render_variable."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment(context={'cookiecutter': {'project_name': 'Peanut Butter Cookie'}})
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    assert render_variable(env, raw, cookiecutter_dict) == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:15:50.198537
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:16:01.327103
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:12.134071
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter',
            'project_slug': 'cookiecutter',
            '_template': {'key': 'value'},
            '__secret': 'secret',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == 'Cookiecutter'
    assert cookiecutter_dict['project_slug'] == 'cookiecutter'
    assert cookiecutter_dict['_template'] == {'key': 'value'}
    assert cookiecutter_dict['__secret'] == 'secret'

# Generated at 2022-06-22 17:16:17.657072
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

    # Test with user input
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:16:28.929897
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:41.034269
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:58.725136
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:08.416179
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test if read_user_dict returns a dictionary
    assert isinstance(read_user_dict('var_name', {'a': 'b'}), dict)
    # Test if read_user_dict returns a dictionary with the same keys and values
    assert read_user_dict('var_name', {'a': 'b'}) == {'a': 'b'}
    # Test if read_user_dict returns a dictionary with the same keys and values
    assert read_user_dict('var_name', {'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    # Test if read_user_dict returns a dictionary with the same keys and values

# Generated at 2022-06-22 17:17:19.803024
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:30.846695
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    # Test simple variable
    context = {'cookiecutter': {'project_name': 'Peanut Butter Cookie'}}
    env = StrictEnvironment(context=context)
    rendered_template = render_variable(
        env, '{{ cookiecutter.project_name }}', context['cookiecutter']
    )
    assert rendered_template == 'Peanut Butter Cookie'

    # Test variable with filter
    rendered_template = render_variable(
        env, '{{ cookiecutter.project_name|lower }}', context['cookiecutter']
    )
    assert rendered_template == 'peanut butter cookie'

    # Test variable with filter and argument

# Generated at 2022-06-22 17:17:42.680260
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:53.306870
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:06.140673
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:13.380372
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var_name'
    default_value = {'a': 'b'}
    user_value = '{"a": "b"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:18:17.334656
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test_var', default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict('test_var', default_value)
    assert user_value == {'key3': 'value3', 'key4': 'value4'}

# Generated at 2022-06-22 17:18:29.567003
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:46.602037
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:48.701720
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:18:57.271837
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:09.189854
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:19.199242
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'


# Generated at 2022-06-22 17:19:22.790835
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test function read_user_choice."""
    var_name = 'test_var'
    options = ['option1', 'option2', 'option3']
    assert read_user_choice(var_name, options) in options


# Generated at 2022-06-22 17:19:33.194609
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    # Create a temporary cookiecutter project
    cookiecutter('tests/test-render-variable/', no_input=True)

    # Read the cookiecutter.json file
    with open('tests/test-render-variable/cookiecutter.json') as f:
        context = json.load(f)

    # Create a Jinja2 Environment object
    env = StrictEnvironment(context=context)

    # Create a cookiecutter dictionary
    cookiecutter_dict = OrderedDict([])

    # Render the variables

# Generated at 2022-06-22 17:19:42.466855
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:53.079321
# Unit test for function render_variable
def test_render_variable():
    """Unit test for function render_variable."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    env = StrictEnvironment(context=context)

    # Test for a simple variable
    raw = '{{ cookiecutter.project_name }}'
    rendered_template = render_variable(env, raw, context)
    assert rendered_template == 'Cookiecutter'

    # Test for a variable with a filter
    raw = '{{ cookiecutter.project_name | lower }}'
    rendered_template = render_variable(env, raw, context)
    assert rendered_template == 'cookiecutter'

    # Test for a variable with a filter and a function

# Generated at 2022-06-22 17:20:00.254309
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:20:16.342676
# Unit test for function read_user_dict
def test_read_user_dict():
    from cookiecutter.prompt import read_user_dict
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'test_dict': {
                'test_key': 'test_value',
                'test_key2': 'test_value2',
            }
        }
    }

    # Test that the default value is returned if no input is given
    default_value = {'test_key': 'test_value', 'test_key2': 'test_value2'}
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == default_value

    # Test that the user input is returned if valid JSON is given