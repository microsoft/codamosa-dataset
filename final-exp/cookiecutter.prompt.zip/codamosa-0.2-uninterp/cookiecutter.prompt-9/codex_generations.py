

# Generated at 2022-06-22 17:10:29.892229
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    # pylint: disable=unused-variable
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['project_short_description'] == 'A command-line utility that creates projects from project templates, e.g. creating a Python package project from a Python package project template.'
    assert context['cookiecutter']['release_date'] == '2013-04-06'

# Generated at 2022-06-22 17:10:38.747841
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:10:50.150084
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:10:55.098148
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:05.956689
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:14.421019
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test the function read_user_choice."""
    # Test with a list of options
    options = ['option1', 'option2', 'option3']
    var_name = 'var_name'
    assert read_user_choice(var_name, options) in options
    # Test with an empty list
    options = []
    assert read_user_choice(var_name, options) is None
    # Test with a list of options and a default value
    options = ['option1', 'option2', 'option3']
    var_name = 'var_name'
    assert read_user_choice(var_name, options) in options
    # Test with an empty list and a default value
    options = []
    assert read_user_choice(var_name, options) is None
    # Test with a list of options and a default value

# Generated at 2022-06-22 17:11:22.648484
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    # Test default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test user value
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test invalid user value
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:11:28.879118
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    cookiecutter_dict = OrderedDict([])

    # Test that a string is returned as is
    raw = 'test'
    assert render_variable(env, raw, cookiecutter_dict) == 'test'

    # Test that a number is returned as a string
    raw = 123
    assert render_variable(env, raw, cookiecutter_dict) == '123'

    # Test that a list is returned as a list
    raw = [1, 2, 3]
    assert render_variable(env, raw, cookiecutter_dict) == [1, 2, 3]

    # Test that a dictionary is returned as a dictionary
    raw = {'a': 1, 'b': 2}

# Generated at 2022-06-22 17:11:38.747035
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:44.822823
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'

# Generated at 2022-06-22 17:11:55.040863
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test for function read_user_dict."""
    # Test for default value
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

    # Test for user input
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:12:01.460745
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:12:08.985521
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:14.462571
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:12:19.505087
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"c": "d"}'
    expected_value = {'c': 'd'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:12:25.235224
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:36.558440
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter_pypackage'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A Python package project template.'

# Generated at 2022-06-22 17:12:45.859392
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:53.332760
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:13:04.699668
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:23.713303
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:29.465178
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    user_value = '{"foo": "bar"}'
    assert process_json(user_value) == {'foo': 'bar'}

    user_value = '{"foo": "bar", "baz": "qux"}'
    assert process_json(user_value) == {'foo': 'bar', 'baz': 'qux'}

    user_value = '{"foo": {"bar": "baz"}}'
    assert process_json(user_value) == {'foo': {'bar': 'baz'}}

    user_value = '{"foo": ["bar", "baz"]}'
    assert process_json(user_value) == {'foo': ['bar', 'baz']}


# Generated at 2022-06-22 17:13:40.165612
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:46.640915
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with a default value
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:13:57.849516
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'

# Generated at 2022-06-22 17:14:07.658260
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:16.662633
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:25.929135
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:33.895328
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:39.907162
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    user_dict = read_user_dict('test_dict', {'test_key': 'test_value'})
    assert user_dict == {'test_key': 'test_value'}

    # Test with user input
    user_dict = read_user_dict('test_dict', {'test_key': 'test_value'})
    assert user_dict == {'test_key': 'test_value'}

# Generated at 2022-06-22 17:14:56.120693
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""

# Generated at 2022-06-22 17:15:00.054805
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with default value
    assert read_user_dict('test_dict', {'test_key': 'test_value'}) == {'test_key': 'test_value'}

    # Test with user input
    assert read_user_dict('test_dict', {'test_key': 'test_value'}) == {'test_key': 'test_value'}

# Generated at 2022-06-22 17:15:07.193705
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with default value
    default_value = {'a': 'b'}
    user_dict = read_user_dict('test', default_value)
    assert user_dict == default_value

    # Test with user input
    user_dict = read_user_dict('test', default_value)
    assert user_dict == default_value

    # Test with invalid user input
    user_dict = read_user_dict('test', default_value)
    assert user_dict == default_value

# Generated at 2022-06-22 17:15:14.462472
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:24.953948
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'

# Generated at 2022-06-22 17:15:35.556528
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:15:39.500531
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = '{"key3": "value3", "key4": "value4"}'
    expected_value = {'key3': 'value3', 'key4': 'value4'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:15:49.268894
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:00.922433
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter-Puppet',
            'repo_name': '{{ cookiecutter.project_name.lower().replace("-", "_") }}',
            'puppet_version': '3.8',
            'operatingsystem_support': [
                'Debian',
                'RedHat',
                'Solaris',
                'Suse',
                'Windows',
            ],
            '_template': {
                'key1': 'value1',
                'key2': 'value2',
            },
            '__secret': 'I am a secret',
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)


# Generated at 2022-06-22 17:16:12.403159
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:31.278889
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": 1}') == {'a': 1}
    assert process_json('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert process_json('{"a": 1, "b": 2, "c": 3}') == {'a': 1, 'b': 2, 'c': 3}
    assert process_json('{"a": 1, "b": 2, "c": 3, "d": 4}') == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-22 17:16:42.982159
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"a": 1, "b": 2}'
    assert process_json(user_value) == {"a": 1, "b": 2}

    user_value = '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'
    assert process_json(user_value) == {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}

    user_value = '{"a": 1, "b": 2, "c": [1, 2, 3]}'
    assert process_json(user_value) == {"a": 1, "b": 2, "c": [1, 2, 3]}


# Generated at 2022-06-22 17:16:51.762595
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:00.928590
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:12.033597
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:17:22.270080
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter-Puppet',
            'project_slug': 'cookiecutter-puppet',
            'author_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'description': 'A cookiecutter for Puppet modules.',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'open_source_license': 'MIT',
            'year': '2014',
            '_copy_without_render': [
                '.travis.yml',
                'LICENSE',
                'README.rst',
                'tests/test_cookiecutter_puppet.py',
            ],
        }
    }
    cookiecutter_dict

# Generated at 2022-06-22 17:17:32.482655
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert user_dict == {'key1': 'value1', 'key2': 'value2'}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    user_dict = process_json(user_value)
    assert user_dict == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": ["value3", "value4"]}'

# Generated at 2022-06-22 17:17:39.045488
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_input = '{"key1": "value1", "key2": "value2"}'
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:17:50.701767
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    from click.testing import CliRunner
    from cookiecutter.main import cookiecutter

    runner = CliRunner()
    with runner.isolated_filesystem():
        result = runner.invoke(
            cookiecutter,
            [
                'tests/test-generate-dict-prompt/',
                '--no-input',
                '--extra-context',
                '{"cookiecutter": {"dict_var": {"key1": "value1"}}}',
            ],
        )
        assert result.exit_code == 0
        assert result.exception is None


# Generated at 2022-06-22 17:18:02.952474
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    # Test with valid JSON
    user_value = '{"key1": "value1", "key2": "value2"}'
    expected_result = {"key1": "value1", "key2": "value2"}
    assert process_json(user_value) == expected_result

    # Test with invalid JSON
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True
    else:
        assert False

    # Test with not a dict
    user_value = '["key1", "value1", "key2", "value2"]'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True

# Generated at 2022-06-22 17:18:21.227595
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:18:32.396697
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:43.683542
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:50.908779
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:55.087151
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:07.434702
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:13.642472
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == json.loads(user_value)

# Generated at 2022-06-22 17:19:26.812636
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
        }
    }
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    rendered_template = render_variable(env, '{{ cookiecutter.repo_name }}', cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'


# Generated at 2022-06-22 17:19:38.051363
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'
    assert isinstance(user_dict['key3'], dict)

# Generated at 2022-06-22 17:19:45.010997
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test 1:
    # Test with default value
    # Expected result:
    #   - Return default value
    #   - No input from user
    #   - No error
    default_value = {'a': 'b'}
    var_name = 'test_var'
    user_value = ''
    expected_result = default_value
    result = read_user_dict(var_name, default_value)
    assert result == expected_result

    # Test 2:
    # Test with user input
    # Expected result:
    #   - Return user input
    #   - No error
    default_value = {'a': 'b'}
    var_name = 'test_var'
    user_value = '{"a": "c"}'
    expected

# Generated at 2022-06-22 17:20:05.561958
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:15.892526
# Unit test for function prompt_for_config