

# Generated at 2022-06-22 17:10:28.921914
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:38.436661
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """Test prompt_choice_for_config function."""
    context = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.project_slug.replace("-", " ") }}',
            'project_slug': '{{ cookiecutter.project_name.replace(" ", "-") }}',
            'project_type': [
                '{{ cookiecutter.project_name.replace(" ", "-") }}',
                '{{ cookiecutter.project_name.replace(" ", "_") }}',
            ],
        }
    }
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])
    cookiecutter_dict['project_name'] = 'Peanut Butter Cookie'

# Generated at 2022-06-22 17:10:49.813291
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    context = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.project_slug.replace("-", " ") }}',
            'project_slug': '{{ cookiecutter.project_name.replace(" ", "-") }}',
            'project_type': [
                '{{ cookiecutter.project_slug.replace("-", " ") }}',
                '{{ cookiecutter.project_name.replace(" ", "-") }}',
            ],
        }
    }
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context=context)
    key = 'project_type'
    raw = context['cookiecutter']['project_type']
    no_input = True

# Generated at 2022-06-22 17:11:01.071623
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:11.900393
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:11:24.704159
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:35.740854
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'
    assert isinstance(user_dict['key3'], dict)

# Generated at 2022-06-22 17:11:38.450846
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert user_dict == {'key1': 'value1', 'key2': 'value2'}



# Generated at 2022-06-22 17:11:41.901684
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    # Test valid JSON
    user_value = '{"key": "value"}'
    assert process_json(user_value) == {"key": "value"}

    # Test invalid JSON
    user_value = '{"key": "value"'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 17:11:54.171410
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:16.691139
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'dict_var': {'key': '{{ cookiecutter.project_name }}'},
            'list_var': ['{{ cookiecutter.project_name }}'],
        }
    }

    cookiecutter_dict = prompt_for_config(context)

    assert cookiecutter_dict['project_name'] == 'Peanut Butter Cookie'
    assert cookiecutter_dict['repo_name'] == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:12:24.103087
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

# Generated at 2022-06-22 17:12:35.950753
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:39.639228
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}

    # Test with user input
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}

# Generated at 2022-06-22 17:12:49.862834
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'

# Generated at 2022-06-22 17:12:55.697198
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'dict_var': {
                'key': '{{ cookiecutter.project_name }}',
                'key2': '{{ cookiecutter.repo_name }}',
            },
            'list_var': ['{{ cookiecutter.project_name }}', '{{ cookiecutter.repo_name }}'],
        }
    }

# Generated at 2022-06-22 17:13:03.897582
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:13:10.539500
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'project_name': 'Peanut Butter Cookie',
        }
    }
    cookiecutter_dict = {
        'project_name': 'Peanut Butter Cookie',
    }
    assert render_variable(env, '{{ cookiecutter.project_name.replace(" ", "_") }}', cookiecutter_dict) == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:13:17.937171
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    assert read_user_dict('var_name', {'a': 1}) == {'a': 1}
    assert read_user_dict('var_name', {'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert read_user_dict('var_name', {}) == {}
    assert read_user_dict('var_name', {'a': {'b': 1}}) == {'a': {'b': 1}}
    assert read_user_dict('var_name', {'a': [1, 2]}) == {'a': [1, 2]}

# Generated at 2022-06-22 17:13:24.495178
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    var_name = "test_var"
    default_value = {"test_key": "test_value"}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:13:43.600362
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:49.276252
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:00.512301
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux"}}') == {'foo': 'bar', 'baz': {'qux': 'quux'}}
    assert process_json('{"foo": "bar", "baz": ["qux", "quux"]}') == {'foo': 'bar', 'baz': ['qux', 'quux']}

# Generated at 2022-06-22 17:14:06.073318
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    # Test valid JSON
    assert process_json('{"a": "b"}') == {"a": "b"}
    # Test invalid JSON
    try:
        process_json('{"a": "b"')
    except click.UsageError:
        pass
    # Test non-dict JSON
    try:
        process_json('["a", "b"]')
    except click.UsageError:
        pass

# Generated at 2022-06-22 17:14:14.104407
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.prompt import read_user_dict
    from cookiecutter.environment import StrictEnvironment

    context = {
        'cookiecutter': {
            'test_dict': {
                'key1': 'value1',
                'key2': 'value2',
            },
        }
    }
    env = StrictEnvironment(context=context)

    # Test default
    test_dict = read_user_dict('test_dict', context['cookiecutter']['test_dict'])
    assert test_dict == context['cookiecutter']['test_dict']

    # Test user input
    test_dict = read_user_dict('test_dict', context['cookiecutter']['test_dict'])

# Generated at 2022-06-22 17:14:24.452866
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""

# Generated at 2022-06-22 17:14:28.794316
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'key': 'value'}
    user_value = '{"key": "value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:14:35.453056
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['project_short_description'] == 'A command-line utility that creates projects from project templates, e.g. creating a Python package project from a Python package project template.'
    assert context['cookiecutter']['release_date'] == '2013-06-01'
    assert context['cookiecutter']['year']

# Generated at 2022-06-22 17:14:40.232630
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test'
    default_value = {'test': 'test'}
    user_value = '{"test": "test"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:14:49.477860
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:13.684010
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": {"b": "c"}}') == {"a": {"b": "c"}}
    assert process_json('{"a": {"b": "c", "d": "e"}}') == {"a": {"b": "c", "d": "e"}}
    assert process_json('{"a": {"b": {"c": "d"}}}') == {"a": {"b": {"c": "d"}}}

# Generated at 2022-06-22 17:15:24.694080
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}}

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'

# Generated at 2022-06-22 17:15:35.522434
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:37.732594
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test the function read_user_choice."""
    var_name = 'test_var'
    options = ['test_option1', 'test_option2']
    assert read_user_choice(var_name, options) in options

# Generated at 2022-06-22 17:15:44.905275
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:15:54.917269
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:07.170079
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:15.999767
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:22.212545
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:32.202403
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    import click
    from click.testing import CliRunner

    @click.command()
    @click.option('--dict', type=click.STRING, callback=read_user_dict)
    def cli(dict):
        click.echo(dict)

    runner = CliRunner()

    result = runner.invoke(cli, ['--dict', '{"foo": "bar"}'])
    assert result.exit_code == 0
    assert result.output == '{\n    "foo": "bar"\n}\n'

    result = runner.invoke(cli, ['--dict', '{"foo": "bar", "baz": "qux"}'])
    assert result.exit_code == 0

# Generated at 2022-06-22 17:16:49.754355
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"name": "test"}'
    user_dict = process_json(user_value)
    assert user_dict == {'name': 'test'}

    user_value = '{"name": "test", "age": "20"}'
    user_dict = process_json(user_value)
    assert user_dict == {'name': 'test', 'age': '20'}

    user_value = '{"name": "test", "age": "20", "address": {"city": "Beijing", "country": "China"}}'
    user_dict = process_json(user_value)
    assert user_dict == {'name': 'test', 'age': '20', 'address': {'city': 'Beijing', 'country': 'China'}}

   

# Generated at 2022-06-22 17:16:59.592167
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:09.803061
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:20.995676
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with a user-supplied value that is not a dict
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with a user-supplied value that is not a dict
    user_value = read_user_dict('var_name', default_value)
   

# Generated at 2022-06-22 17:17:29.638966
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"foo": "bar"}'
    user_dict = process_json(user_value)
    assert user_dict == {'foo': 'bar'}

    user_value = '{"foo": "bar", "baz": "qux"}'
    user_dict = process_json(user_value)
    assert user_dict == {'foo': 'bar', 'baz': 'qux'}

    user_value = '{"foo": "bar", "baz": {"qux": "quux"}}'
    user_dict = process_json(user_value)
    assert user_dict == {'foo': 'bar', 'baz': {'qux': 'quux'}}


# Generated at 2022-06-22 17:17:35.554459
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:46.712629
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""

# Generated at 2022-06-22 17:17:59.032230
# Unit test for function render_variable
def test_render_variable():
    """Test function render_variable."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a temporary project from the test repo
    project_dir = cookiecutter(
        'tests/test-render-variable/',
        no_input=True,
        extra_context={'project_name': 'Test Project'},
    )

    # Load the project's cookiecutter.json file
    with open(project_dir + '/cookiecutter.json') as f:
        context = json.loads(f.read())

    # Create a Jinja2 environment
    env = StrictEnvironment(context=context)

    # Render the next variable to be displayed in the user prompt

# Generated at 2022-06-22 17:18:08.651307
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    # Test with a valid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

    # Test with an invalid JSON dict
    user_value = '{"key1": "value1", "key2": "value2}'
    try:
        user_dict = process_json(user_value)
    except click.UsageError:
        pass
    else:
        assert False, "Expected click.UsageError"

    # Test with a non-dict JSON

# Generated at 2022-06-22 17:18:21.471282
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:42.952614
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    assert read_user_dict('var_name', default_value) == default_value

    # Test with user input
    user_value = '{"a": "b"}'
    assert read_user_dict('var_name', default_value) == {'a': 'b'}

    # Test with user input
    user_value = '{"a": "b", "c": "d"}'
    assert read_user_dict('var_name', default_value) == {'a': 'b', 'c': 'd'}

    # Test with user input
    user_value = '{"a": "b", "c": "d", "e": {"f": "g"}}'

# Generated at 2022-06-22 17:18:52.260816
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:56.490110
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'



# Generated at 2022-06-22 17:19:09.026370
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:19.113160
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:30.295498
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:37.823709
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

# Generated at 2022-06-22 17:19:44.945035
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:52.152927
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test'
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:20:03.454772
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    assert read_user_dict('var_name', default_value) == default_value

    # Test with user input
    user_input = '{"a": "b"}'
    assert read_user_dict('var_name', default_value) == {'a': 'b'}

    # Test with user input
    user_input = '{"a": "b", "c": "d"}'
    assert read_user_dict('var_name', default_value) == {'a': 'b', 'c': 'd'}

    # Test with user input
    user_input = '{"a": "b", "c": "d", "e": {"f": "g"}}'

# Generated at 2022-06-22 17:20:21.826856
# Unit test for function prompt_for_config