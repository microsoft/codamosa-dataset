

# Generated at 2022-06-22 17:10:27.983521
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    assert read_user_dict('var_name', default_value) == default_value

    # Test with user input
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict('var_name', default_value) == json.loads(user_value)

# Generated at 2022-06-22 17:10:37.962936
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with user input
    user_input = '{"key1": "value1", "key2": "value2"}'
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with user input
    user_input = '{"key1": "value1", "key2": "value2"}'
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with

# Generated at 2022-06-22 17:10:49.201000
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:00.593175
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)

# Generated at 2022-06-22 17:11:05.546279
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:11:11.578662
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for function read_user_dict"""
    # Test with default value
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test with user input
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:11:24.666428
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": {"d": "e"}}') == {"a": "b", "c": {"d": "e"}}
    assert process_json('{"a": "b", "c": {"d": "e", "f": "g"}}') == {"a": "b", "c": {"d": "e", "f": "g"}}

# Generated at 2022-06-22 17:11:35.702256
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:43.897711
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:55.880910
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"a": "b"}'
    assert process_json(user_value) == {"a": "b"}

    user_value = '{"a": "b", "c": "d"}'
    assert process_json(user_value) == {"a": "b", "c": "d"}

    user_value = '{"a": "b", "c": "d", "e": {"f": "g"}}'
    assert process_json(user_value) == {"a": "b", "c": "d", "e": {"f": "g"}}

    user_value = '{"a": "b", "c": "d", "e": {"f": "g", "h": "i"}}'

# Generated at 2022-06-22 17:12:07.746162
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    import io
    import sys

    # Test with default value
    sys.stdin = io.StringIO("\n")
    result = read_user_dict("test", {"a": "b"})
    assert result == {"a": "b"}

    # Test with user input
    sys.stdin = io.StringIO('{"a": "b"}\n')
    result = read_user_dict("test", {"a": "c"})
    assert result == {"a": "b"}

    # Test with invalid user input
    sys.stdin = io.StringIO('{"a": "b"\n')
    result = read_user_dict("test", {"a": "c"})
    assert result == {"a": "c"}

# Generated at 2022-06-22 17:12:19.164922
# Unit test for function render_variable
def test_render_variable():
    """Test function render_variable."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}

    # Test rendering of a string
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'

    # Test rendering of a list
    raw = ['{{ cookiecutter.project_name.replace(" ", "_") }}']
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == ['Peanut_Butter_Cookie']

    # Test rendering of a dictionary

# Generated at 2022-06-22 17:12:31.430168
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:39.984997
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:50.234435
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:55.893924
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test prompt_for_config function
    """
    from cookiecutter.main import cookiecutter
    import os
    import shutil
    import tempfile

    # Create a temporary directory to store the project
    temp_project_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the template
    temp_template_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned template
    temp_clone_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned template
    temp_clone_dir2 = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned template
    temp_clone_dir3 = tempfile.mkdtemp()

    # Create a temporary directory to store the cloned template
    temp_clone_dir4

# Generated at 2022-06-22 17:13:06.832939
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:14.698458
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""

# Generated at 2022-06-22 17:13:25.543859
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:35.938184
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"a": "b"}') == {'a': 'b'}
    assert process_json('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-22 17:13:47.689826
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    # Test with default value
    assert read_user_dict(var_name, default_value) == default_value
    # Test with user input
    user_input = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    # Test with invalid user input
    user_input = '{"test_key": "test_value"'
    try:
        read_user_dict(var_name, default_value)
    except click.UsageError:
        pass
    # Test with invalid default value
    default_value = 'test_value'

# Generated at 2022-06-22 17:13:55.692485
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:14:06.038526
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": "bar", "baz": "qux", "quux": "corge"}') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert process_json('{"foo": "bar", "baz": "qux", "quux": "corge", "grault": "garply"}') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge', 'grault': 'garply'}
   

# Generated at 2022-06-22 17:14:11.844950
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test_var', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test_var', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:14:23.729293
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:25.853074
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:14:38.471363
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:46.165797
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:14:51.456444
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {'cookiecutter': {'project_name': 'Peanut Butter Cookie'}}
    cookiecutter_dict = {'cookiecutter': {'project_name': 'Peanut Butter Cookie'}}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:14:57.352467
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:12.392064
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:15:24.064238
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:35.060561
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:15:42.396738
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 17:15:50.626254
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for function read_user_dict"""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:16:01.627280
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:12.968425
# Unit test for function process_json
def test_process_json():
    """Test for function process_json."""
    user_value = '{"a": "b"}'
    assert process_json(user_value) == {"a": "b"}

    user_value = '{"a": "b", "c": "d"}'
    assert process_json(user_value) == {"a": "b", "c": "d"}

    user_value = '{"a": {"b": "c"}}'
    assert process_json(user_value) == {"a": {"b": "c"}}

    user_value = '{"a": {"b": "c"}, "d": {"e": "f"}}'
    assert process_json(user_value) == {"a": {"b": "c"}, "d": {"e": "f"}}


# Generated at 2022-06-22 17:16:19.040506
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:16:30.299026
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"a": "b", "c": "d"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['a'] == 'b'
    assert user_dict['c'] == 'd'

    user_value = '{"a": "b", "c": "d", "e": {"f": "g"}}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['a'] == 'b'
    assert user_dict['c'] == 'd'
    assert isinstance(user_dict['e'], dict)
    assert user_dict['e']['f'] == 'g'

    user_

# Generated at 2022-06-22 17:16:42.342309
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'
    assert context['cookiecutter']['year'] == '2013'
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'

# Generated at 2022-06-22 17:16:53.870654
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test for function prompt_for_config"""

# Generated at 2022-06-22 17:16:58.460185
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "test_var"
    default_value = {"test_key": "test_value"}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:17:04.232330
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:17:16.151502
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:22.957616
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"a": "b"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:17:32.754187
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'


# Generated at 2022-06-22 17:17:44.078760
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:17:56.103731
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:07.295602
# Unit test for function process_json
def test_process_json():
    user_value = '{"key": "value"}'
    assert process_json(user_value) == {"key": "value"}

    user_value = '{"key": "value", "key2": "value2"}'
    assert process_json(user_value) == {"key": "value", "key2": "value2"}

    user_value = '{"key": "value", "key2": "value2", "key3": {"key4": "value4"}}'
    assert process_json(user_value) == {"key": "value", "key2": "value2", "key3": {"key4": "value4"}}

    user_value = '{"key": "value", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'

# Generated at 2022-06-22 17:18:19.690630
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:34.221618
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:36.417668
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    assert read_user_dict("var_name", {"key": "value"}) == {"key": "value"}

# Generated at 2022-06-22 17:18:47.136955
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:52.734416
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:58.951555
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:10.924274
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:17.546522
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test for function read_user_dict"""
    # Test for default value
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

    # Test for user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

    # Test for invalid user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-22 17:19:29.009865
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:35.655750
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test the default value
    assert read_user_dict('test', {}) == {}

    # Test the user input
    assert read_user_dict('test', {}) == {'test': 'test'}

    # Test the user input with a default value
    assert read_user_dict('test', {'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-22 17:19:43.455897
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:52.718968
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a temporary project from the test repo
    project_dir = cookiecutter('tests/test-repo-pre/', no_input=True)

    # Delete the project directory
    rmtree(project_dir)

# Generated at 2022-06-22 17:20:04.821047
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['email'] == 'cookiecutter@example.com'

# Generated at 2022-06-22 17:20:10.565521
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:20:20.370121
# Unit test for function prompt_for_config