

# Generated at 2022-06-22 17:10:30.658134
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:40.973458
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:52.297595
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:03.940695
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:13.329370
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:19.530609
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import config

    # Create a temporary project from the test repo
    project_dir = cookiecutter('tests/test-repo-pre/', no_input=True)

    # Load the context from the project
    context_file = project_dir + '/cookiecutter.json'
    with open(context_file) as f:
        context = json.load(f, object_pairs_hook=OrderedDict)

    # Prompt the user for a new config
    new_config = prompt_for_config(context, no_input=False)

    # Clean up
    rmtree(project_dir)

    # Check the new config

# Generated at 2022-06-22 17:11:27.756913
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": "b"}') == {'a': 'b'}
    assert process_json('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}
    assert process_json('{"a": "b", "c": {"d": "e"}}') == {'a': 'b', 'c': {'d': 'e'}}
    assert process_json('{"a": "b", "c": {"d": "e", "f": "g"}}') == {'a': 'b', 'c': {'d': 'e', 'f': 'g'}}

# Generated at 2022-06-22 17:11:38.719710
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:44.773149
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:49.334586
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2"}



# Generated at 2022-06-22 17:12:02.267808
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    var_name = "test_var_name"
    default_value = {"key1": "value1", "key2": "value2"}
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == json.loads(user_value)

# Generated at 2022-06-22 17:12:14.962768
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:26.485853
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:32.083521
# Unit test for function render_variable
def test_render_variable():
    """Test render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:12:40.320331
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:46.489321
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    # Test with default value
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test with user input
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:12:53.630992
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux"}}') == {'foo': 'bar', 'baz': {'qux': 'quux'}}
    assert process_json('{"foo": "bar", "baz": {"qux": "quux", "corge": "grault"}}') == {'foo': 'bar', 'baz': {'qux': 'quux', 'corge': 'grault'}}

# Generated at 2022-06-22 17:13:05.131356
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:13.202728
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:23.882364
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:39.812360
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    import sys
    import io
    import unittest
    from unittest.mock import patch

    class TestReadUserDict(unittest.TestCase):
        """Test the read_user_dict function."""

        @patch('sys.stdout', new_callable=io.StringIO)
        def test_read_user_dict_with_default(self, mock_stdout):
            """Test the read_user_dict function with default value."""
            default_value = {'a': 'b'}
            var_name = 'test_var'
            sys.stdin = io.StringIO('\n')
            sys.stdout = mock_stdout
            result = read_user_dict(var_name, default_value)
            self.assertE

# Generated at 2022-06-22 17:13:47.354091
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a temporary project from the test repo
    project_dir = cookiecutter(
        'tests/test-render-variable/',
        no_input=True,
        extra_context={'project_name': 'Foobar'},
    )

    # Load the project's cookiecutter.json file
    with open(project_dir + '/cookiecutter.json') as f:
        context = json.load(f)

    # Create a Jinja2 environment
    env = StrictEnvironment(context=context)

    # Render the variables in the context

# Generated at 2022-06-22 17:13:58.713509
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function"""

# Generated at 2022-06-22 17:14:03.208955
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"a": "c"}'
    expected_value = {'a': 'c'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:14:12.892399
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    # Test with a valid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"}'
    result = process_json(user_value)
    assert isinstance(result, dict)
    assert result == {"key1": "value1", "key2": "value2"}

    # Test with an invalid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        assert False

    # Test with a valid JSON list
    user_value = '["value1", "value2"]'
    result = process_json(user_value)
    assert isinstance(result, list)


# Generated at 2022-06-22 17:14:19.080278
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)

# Generated at 2022-06-22 17:14:26.806365
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:14:34.362414
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['email'] == 'cookiecutter@example.com'

# Generated at 2022-06-22 17:14:35.740458
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    user_value = '{"name": "John Doe", "age": 42}'
    assert process_json(user_value) == {"name": "John Doe", "age": 42}

# Generated at 2022-06-22 17:14:45.558903
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:56.984131
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:08.010419
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:14.782298
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:24.438360
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

# Generated at 2022-06-22 17:15:35.374986
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:42.472530
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    # Test with a default value
    default_value = {'a': 'b'}
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == default_value

    # Test with a user-supplied value
    user_value = '{"a": "b"}'
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == {'a': 'b'}

    # Test with a user-supplied value that is not a dict
    user_value = '["a", "b"]'
    user_dict = read_user_dict('test_dict', default_value)
    assert user_dict == default_value

# Generated at 2022-06-22 17:15:50.755669
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('var_name', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:16:01.714675
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:12.968703
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:18.553750
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

# Generated at 2022-06-22 17:16:33.183926
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:44.472561
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    # Test with default values
    context = cookiecutter('tests/fake-repo-pre/', no_input=True)

# Generated at 2022-06-22 17:16:49.113364
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var_name'
    default_value = {'key': 'value'}
    user_value = '{"key": "value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:16:59.220218
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a default value
    default_value = {'name': 'default'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with a user-supplied value that is not a JSON dict
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with a user-supplied value that is not a JSON dict
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:17:09.262687
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:19.349252
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter',
            'project_slug': 'cookiecutter',
            '_template': {'key': 'value'},
            '__secret': 'to be kept secret',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict == {
        'project_name': 'Cookiecutter',
        'project_slug': 'cookiecutter',
        '_template': {'key': 'value'},
        '__secret': 'to be kept secret',
    }

# Generated at 2022-06-22 17:17:30.744524
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:42.596109
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:53.206546
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:57.672494
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:20.853359
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:26.624241
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test'
    default_value = {'a': 'b'}
    user_value = '{"c": "d"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value, user_value) == {'c': 'd'}

# Generated at 2022-06-22 17:18:34.891428
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:46.380671
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:18:52.307843
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.repo_name.replace("-", "_") }}',
            'repo_name': '{{ cookiecutter.project_name.lower() }}',
            '_template': {'license': 'MIT'},
            '__version__': '0.1.0',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == '{{ cookiecutter.repo_name.replace("-", "_") }}'
    assert cookiecutter_dict['repo_name'] == '{{ cookiecutter.project_name.lower() }}'
    assert cookiecutter_dict['_template'] == {'license': 'MIT'}

# Generated at 2022-06-22 17:19:01.757213
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:13.478941
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:26.812593
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()

# Generated at 2022-06-22 17:19:34.257040
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, default_value)
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:19:44.408238
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:06.068834
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'var_name'
    default_value = {'a': 'b'}
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == {'a': 'b'}
    assert read_user_dict(var_name, default_value) == {'a': 'b'}
    assert read_user_dict(var_name, default_value) == {'a': 'b'}
    assert read_user_dict(var_name, default_value) == {'a': 'b'}
    assert read_user_dict(var_name, default_value) == {'a': 'b'}

# Generated at 2022-06-22 17:20:16.588687
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    user_value = '{"foo": "bar"}'
    assert process_json(user_value) == {'foo': 'bar'}

    user_value = '{"foo": "bar", "baz": "qux"}'
    assert process_json(user_value) == {'foo': 'bar', 'baz': 'qux'}

    user_value = '{"foo": {"bar": "baz"}}'
    assert process_json(user_value) == {'foo': {'bar': 'baz'}}

    user_value = '{"foo": ["bar", "baz"]}'
    assert process_json(user_value) == {'foo': ['bar', 'baz']}
