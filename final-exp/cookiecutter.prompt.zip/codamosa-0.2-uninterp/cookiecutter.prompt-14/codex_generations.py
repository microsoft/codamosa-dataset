

# Generated at 2022-06-22 17:10:29.819617
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:38.721722
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    assert process_json('{"a": "b"}') == {"a": "b"}
    assert process_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert process_json('{"a": "b", "c": "d", "e": "f"}') == {"a": "b", "c": "d", "e": "f"}
    assert process_json('{"a": "b", "c": "d", "e": "f", "g": "h"}') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-22 17:10:44.648250
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a valid dictionary
    user_dict = read_user_dict('test', {'key': 'value'})
    assert user_dict == {'key': 'value'}

    # Test with an invalid dictionary
    user_dict = read_user_dict('test', 'value')
    assert user_dict == {'key': 'value'}

# Generated at 2022-06-22 17:10:56.233384
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    var_name = 'test_var'
    default_value = {'a': 'b', 'c': 'd'}
    user_value = '{"a": "b", "c": "d"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == default_value

# Generated at 2022-06-22 17:11:07.710922
# Unit test for function prompt_choice_for_config

# Generated at 2022-06-22 17:11:14.965150
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:19.687613
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}

# Generated at 2022-06-22 17:11:27.820947
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:38.719592
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:49.422065
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014/01/01'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'

# Generated at 2022-06-22 17:12:04.433736
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    # Test with default value
    context = cookiecutter(
        'tests/test-generate-files/',
        no_input=True,
        extra_context={'project_name': 'My Project'},
    )
    assert context['project_name'] == 'My Project'

    # Test with user input
    context = cookiecutter(
        'tests/test-generate-files/',
        no_input=False,
        extra_context={'project_name': 'My Project'},
    )
    assert context['project_name'] == 'My Project'

# Generated at 2022-06-22 17:12:16.854137
# Unit test for function process_json
def test_process_json():
    """Test the process_json function."""
    # Test with a valid json string
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2"}

    # Test with an invalid json string
    user_value = '{"key1": "value1", "key2": "value2"'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True
    else:
        assert False

    # Test with a valid json string, but not a dict
    user_value = '["value1", "value2"]'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True

# Generated at 2022-06-22 17:12:24.200552
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'repo_url': 'https://github.com/{{ cookiecutter.repo_name }}',
            'dict_var': {
                'key1': 'val1',
                'key2': 'val2',
                'key3': '{{ cookiecutter.project_name }}',
            },
            'list_var': ['val1', 'val2', '{{ cookiecutter.project_name }}'],
        }
    }

# Generated at 2022-06-22 17:12:35.950748
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:39.870292
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    user_dict = read_user_dict('var_name', {'key': 'value'})
    assert user_dict == {'key': 'value'}
    user_dict = read_user_dict('var_name', {'key': 'value'})
    assert user_dict == {'key': 'value'}

# Generated at 2022-06-22 17:12:50.093481
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:12:54.778563
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    # Create a project from the tests/fake-repo-pre/ folder.
    context = cookiecutter('tests/fake-repo-pre/', no_input=True)

    # Create a new environment
    env = StrictEnvironment(context=context)

    # Test the rendering of the variable
    rendered_variable = render_variable(env, '{{ cookiecutter.project_name }}', context)

    assert rendered_variable == 'Cookiecutter'



# Generated at 2022-06-22 17:13:06.163337
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:14.084932
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:20.226963
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = '{"test_key": "test_value"}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) != user_value
    assert read_user_dict(var_name, default_value) == process_json(user_value)

# Generated at 2022-06-22 17:13:43.635203
# Unit test for function read_user_dict
def test_read_user_dict():
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}


# Generated at 2022-06-22 17:13:46.395470
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('test', {'a': 1}) == {'a': 1}

    # Test with user input
    assert read_user_dict('test', {'a': 1}) == {'a': 1}

# Generated at 2022-06-22 17:13:57.593205
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:07.149114
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:14:14.412258
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

    user_value = '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    user_dict = process_json(user_value)
    assert isinstance(user_dict, dict)
    assert user_dict['key1'] == 'value1'
    assert user_dict['key2'] == 'value2'

# Generated at 2022-06-22 17:14:24.644753
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:33.104967
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:43.131847
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:55.537849
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:05.342184
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:25.949225
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

    # Test with user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

    # Test with invalid user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-22 17:15:36.178091
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:44.568736
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:53.169038
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with valid input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:16:03.083214
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:13.685921
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:18.584744
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "test_var"
    default_value = {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
    }
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:16:30.141633
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:42.187284
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test 1
    var_name = "test_var_name"
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) == read_user_dict(var_name, user_value)

    # Test 2
    var_name = "test_var_name"
    default_value = {'a': 1, 'b': 2}
    user_value = '{"a": 1, "b": 2}'
    assert read_user_dict(var_name, default_value) == default_value

# Generated at 2022-06-22 17:16:51.019459
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['repo_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['year'] == '2014'

# Generated at 2022-06-22 17:17:14.631386
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:29.750057
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:33.983567
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}
    # Test with user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}
    # Test with user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-22 17:17:44.927188
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'

    context = cookiecutter('.', no_input=False)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'

    context = cookiecutter('.', no_input=False, extra_context={'project_name': 'Test'})
    assert context['cookiecutter']['project_name'] == 'Test'

    context = cookiecutter('.', no_input=False, extra_context={'project_name': 'Test', '_template': '.'})

# Generated at 2022-06-22 17:17:48.889176
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    # Test with default value
    default_value = {'a': 'b'}
    assert read_user_dict('test', default_value) == default_value

    # Test with user input
    user_input = '{"a": "b"}'
    assert read_user_dict('test', default_value) == default_value

    # Test with invalid user input
    user_input = '{"a": "b"'
    try:
        read_user_dict('test', default_value)
    except click.UsageError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 17:18:01.272180
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    var_name = 'test_var'
    default_value = {'test_key': 'test_value'}
    user_value = '{"test_key": "test_value"}'
    result = read_user_dict(var_name, default_value)
    assert result == default_value
    result = read_user_dict(var_name, default_value, user_value)
    assert result == default_value
    user_value = '{"test_key": "test_value", "test_key2": "test_value2"}'
    result = read_user_dict(var_name, default_value, user_value)
    assert result == {'test_key': 'test_value', 'test_key2': 'test_value2'}
    user_

# Generated at 2022-06-22 17:18:09.664984
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['_template'] == 'tests/fake-repo-tmpl/'
    assert context['cookiecutter']['__version__'] == '0.1.0'

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=False)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'

# Generated at 2022-06-22 17:18:18.139715
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:30.227476
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:34.117913
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:19:03.320948
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""
    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    assert render_variable(env, raw, cookiecutter_dict) == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:19:15.222095
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:26.892233
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:38.122989
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['repo_name'] == 'cookiecutter-fake-repo'
    assert context['project_name'] == 'Cookiecutter Fake Repo'
    assert context['project_slug'] == 'cookiecutter-fake-repo'
    assert context['project_short_description'] == 'A short description of the project.'
    assert context['pypi_username'] == 'audreyr'
    assert context['github_username'] == 'audreyr'
    assert context['author_name'] == 'Audrey Roy'
    assert context['email'] == 'audreyr@example.com'

# Generated at 2022-06-22 17:19:45.046984
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test for function read_user_dict."""
    # Test for default value
    default_value = {'a': 'b'}
    assert read_user_dict('var_name', default_value) == default_value

    # Test for user input
    user_value = '{"a": "b"}'
    assert read_user_dict('var_name', default_value) == {'a': 'b'}

    # Test for user input with invalid JSON
    user_value = '{"a": "b"'
    try:
        read_user_dict('var_name', default_value)
    except click.UsageError:
        pass
    else:
        assert False, 'Should have raised click.UsageError'

    # Test for user input with non-dict JSON
    user_value = '["a", "b"]'

# Generated at 2022-06-22 17:19:54.266909
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:06.028423
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:20:16.590179
# Unit test for function prompt_for_config