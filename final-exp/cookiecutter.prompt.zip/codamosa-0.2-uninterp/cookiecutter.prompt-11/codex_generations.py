

# Generated at 2022-06-22 17:10:30.432445
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:10:38.952583
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2"}
    user_value = '{"key1": "value1", "key2": "value2", "key3": "value3"}'
    assert process_json(user_value) == {"key1": "value1", "key2": "value2", "key3": "value3"}
    user_value = '{"key1": "value1", "key2": "value2", "key3": "value3", "key4": "value4"}'

# Generated at 2022-06-22 17:10:50.570726
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:01.754225
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:12.245634
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:24.704093
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:35.740794
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:11:43.931431
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:11:55.953031
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/test-data/fake-repo-pre/', no_input=True)
    context['cookiecutter']['test_dict'] = {'key1': 'val1', 'key2': 'val2'}
    context['cookiecutter']['test_dict2'] = {'key1': 'val1', 'key2': 'val2'}
    context['cookiecutter']['test_dict3'] = {'key1': 'val1', 'key2': 'val2'}
    context['cookiecutter']['test_dict4'] = {'key1': 'val1', 'key2': 'val2'}

# Generated at 2022-06-22 17:12:00.929154
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:16.936749
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:21.986814
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    default_dict = {'key1': 'value1', 'key2': 'value2'}
    user_dict = read_user_dict('test_dict', default_dict)
    assert user_dict == default_dict

    # Test with user input
    user_dict = read_user_dict('test_dict', default_dict)
    assert user_dict == default_dict

# Generated at 2022-06-22 17:12:33.352001
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:40.519995
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:12:50.511958
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    user_value = '{"key1": "value1", "key2": "value2"}'
    user_dict = process_json(user_value)
    assert user_dict == {"key1": "value1", "key2": "value2"}

    user_value = '{"key1": "value1", "key2": "value2'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        raise AssertionError

    user_value = '{"key1": "value1", "key2": "value2", "key3": "value3"}'
    user_dict = process_json(user_value)

# Generated at 2022-06-22 17:12:52.866377
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    assert read_user_dict('test', {}) == {}
    # Test with user input
    assert read_user_dict('test', {}) == {'test': 'test'}

# Generated at 2022-06-22 17:13:04.040227
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:13:15.176260
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    # Create a temporary project
    project_dir = cookiecutter(
        'tests/test-render-variable',
        no_input=True,
        extra_context={'project_name': 'Foo Bar'},
    )

    # Load the context from the temporary project
    context_file = project_dir / 'cookiecutter.json'
    with context_file.open('r', encoding='utf-8') as fh:
        context = json.load(fh)

    # Create an environment
    env = StrictEnvironment(context=context)

    # Test the function

# Generated at 2022-06-22 17:13:23.669585
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test invalid user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:13:29.092627
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter',
            'project_slug': 'cookiecutter',
            '_template': {'foo': 'bar'},
            '__secret': '{{ cookiecutter.project_name }}',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict == {
        'project_name': 'Cookiecutter',
        'project_slug': 'cookiecutter',
        '_template': {'foo': 'bar'},
        '__secret': 'Cookiecutter',
    }

# Generated at 2022-06-22 17:13:44.927206
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:13:49.484585
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test read_user_dict function."""
    # Test with default value
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

    # Test with user input
    assert read_user_dict('test', {'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-22 17:14:00.845002
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:10.654750
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with a user-supplied value that is not a dict
    user_value = read_user_dict('test_dict', default_value)
    assert user_value == default_value

    # Test with a user-supplied value that is not a dict
    user_value = read_user_dict('test_dict', default_value)
   

# Generated at 2022-06-22 17:14:19.015379
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:26.812710
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:34.338134
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'dict_var': {
                'key1': '{{ cookiecutter.project_name }}',
                'key2': '{{ cookiecutter.repo_name }}',
            },
            'list_var': [
                '{{ cookiecutter.project_name }}',
                '{{ cookiecutter.repo_name }}',
            ],
        }
    }
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])

    # Test a simple variable
    raw = '{{ cookiecutter.project_name }}'

# Generated at 2022-06-22 17:14:44.384968
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:14:48.652443
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    user_dict = read_user_dict('test_dict', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test with user input
    user_dict = read_user_dict('test_dict', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:14:56.188904
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:12.392895
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid user input

# Generated at 2022-06-22 17:15:23.181645
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    assert read_user_dict

# Generated at 2022-06-22 17:15:34.532691
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    import os
    import tempfile

    from cookiecutter.main import cookiecutter

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to store the project
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 17:15:41.114797
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == 'Peanut_Butter_Cookie'

# Generated at 2022-06-22 17:15:51.486964
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:15:58.945340
# Unit test for function read_user_dict
def test_read_user_dict():
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:16:08.756839
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:16:20.513065
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:16:31.234219
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function."""
    from cookiecutter.environment import StrictEnvironment

    env = StrictEnvironment()
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    assert render_variable(env, raw, cookiecutter_dict) == 'Peanut_Butter_Cookie'

    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    assert render_variable(env, raw, cookiecutter_dict) == 'Peanut_Butter_Cookie'

    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'

# Generated at 2022-06-22 17:16:37.463779
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a default value
    default_value = {'key': 'value'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:16:52.063522
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:17:01.033266
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:12.184900
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:16.264054
# Unit test for function read_user_choice
def test_read_user_choice():
    options = ['option1', 'option2', 'option3']
    var_name = 'test_var'
    assert read_user_choice(var_name, options) in options


# Generated at 2022-06-22 17:17:23.367783
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    # Test with default value
    default_value = {'a': 'b'}
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with invalid user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

    # Test with valid user input
    user_value = read_user_dict('test', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:17:32.922213
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:17:37.882937
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    var_name = 'test_var'
    default_value = {'a': 'b'}
    user_value = '{"a": "c"}'
    expected_value = {'a': 'c'}
    assert read_user_dict(var_name, default_value) == expected_value

# Generated at 2022-06-22 17:17:49.604238
# Unit test for function render_variable
def test_render_variable():
    """Test the function render_variable."""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.main import cookiecutter

    # Create a temporary project
    project_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Load the context
    context_file = project_dir + '/cookiecutter.json'
    with open(context_file) as fh:
        context = json.load(fh, object_pairs_hook=OrderedDict)

    # Create a Jinja2 Environment
    env = StrictEnvironment(context=context)

    # Test the rendering of a simple variable
    raw = '{{ cookiecutter.project_name }}'
    cookiecutter_dict = OrderedDict([])

# Generated at 2022-06-22 17:18:01.962169
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:10.006780
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    # Test with a valid JSON dict
    user_value = '{"key1": "value1", "key2": "value2"}'
    assert process_json(user_value) == {'key1': 'value1', 'key2': 'value2'}

    # Test with an invalid JSON dict
    user_value = '{"key1": "value1", "key2": "value2'
    try:
        process_json(user_value)
    except click.UsageError:
        assert True
    else:
        assert False

    # Test with a valid JSON list
    user_value = '["value1", "value2"]'
    assert process_json(user_value) == ['value1', 'value2']

    # Test with an invalid JSON list

# Generated at 2022-06-22 17:18:26.997237
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:18:34.957099
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    context['cookiecutter']['_copy_without_render'] = ['tests/fake-repo-tmpl/']
    context['cookiecutter']['_template'] = 'tests/fake-repo-tmpl/'
    context['cookiecutter']['_repo_name'] = 'tests/fake-repo-tmpl/'
    context['cookiecutter']['_repo_dir'] = 'tests/fake-repo-tmpl/'
    context['cookiecutter']['_repo_name'] = 'tests/fake-repo-tmpl/'

# Generated at 2022-06-22 17:18:46.440256
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('.', no_input=True)
    user_dict = read_user_dict('test_dict', {'key': 'value'})
    assert user_dict == {'key': 'value'}

    user_dict = read_user_dict('test_dict', {'key': 'value'}, context)
    assert user_dict == {'key': 'value'}

    user_dict = read_user_dict('test_dict', {'key': 'value'}, context, True)
    assert user_dict == {'key': 'value'}

    user_dict = read_user_dict('test_dict', {'key': 'value'}, context, False)

# Generated at 2022-06-22 17:18:52.339127
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    import sys
    import io
    import json
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # Test 1: Test that the default value is returned if no input is given
    with captured_output() as (out, err):
        default_value = {'foo': 'bar'}
        user_dict = read_user_

# Generated at 2022-06-22 17:19:02.052919
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""

# Generated at 2022-06-22 17:19:13.641094
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:26.817278
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:38.051241
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['_template'] == 'tests/fake-repo-tmpl/'
    assert context['cookiecutter']['__version__'] == '0.1.0'

    context = cookiecutter('tests/fake-repo-tmpl/', no_input=False)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'

# Generated at 2022-06-22 17:19:45.010260
# Unit test for function prompt_for_config

# Generated at 2022-06-22 17:19:51.926574
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    # Test with a default value
    default_value = {'key1': 'value1', 'key2': 'value2'}
    user_value = read_user_dict('test_variable', default_value)
    assert user_value == default_value

    # Test with a user-supplied value
    user_value = read_user_dict('test_variable', default_value)
    assert user_value == default_value

# Generated at 2022-06-22 17:20:00.596299
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    user_dict = read_user_dict('test', {'test': 'test'})
    assert user_dict == {'test': 'test'}

# Generated at 2022-06-22 17:20:06.275023
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict."""
    # Test with default value
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

    # Test with user input
    user_dict = read_user_dict('test', {'a': 'b'})
    assert user_dict == {'a': 'b'}

# Generated at 2022-06-22 17:20:16.931437
# Unit test for function prompt_for_config