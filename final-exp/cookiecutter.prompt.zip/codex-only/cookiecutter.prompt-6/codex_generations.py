

# Generated at 2022-06-23 16:12:23.070008
# Unit test for function process_json
def test_process_json():
    """Unit test for function process_json"""
    user_value = '{"a" : 1, "b": 2, "c": 3 }'

    # Act
    my_dict = process_json(user_value)

    # Assert
    assert len(my_dict) == 3

# Generated at 2022-06-23 16:12:31.982372
# Unit test for function read_user_dict
def test_read_user_dict():
    test_dict = {
        "one": 1,
        "two": 2,
        "three": 3
    }

    parsed_dict = read_user_dict("test", test_dict)
    assert parsed_dict == test_dict

    test_dict = {
        "one": 1,
        "two": 2,
        "three": 3,
        "four": {
            "five": 5,
            "six": 6,
            "seven": 7
        }
    }

    parsed_dict = read_user_dict("test", test_dict)
    assert parsed_dict == test_dict


# Generated at 2022-06-23 16:12:36.559725
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    case1 = read_user_yes_no('Do you want to run unit test for read_user_yes_no (y/n)?', 'y')
    assert case1

    case2 = read_user_yes_no('Do you want to run unit test for read_user_yes_no (y/n)?', 'n')
    assert not case2



# Generated at 2022-06-23 16:12:38.911439
# Unit test for function read_user_variable
def test_read_user_variable():
    var_name = "Test 1"
    default_value = "Test 1"

    assert callable(read_user_variable)


# Generated at 2022-06-23 16:12:41.618546
# Unit test for function read_repo_password
def test_read_repo_password():
    print("Testing function read_repo_password...")
    assert (
        read_repo_password("Please enter your password: ") ==
        input("Please enter your password: ")
    )
    print("PASSED")



# Generated at 2022-06-23 16:12:42.581450
# Unit test for function read_user_variable
def test_read_user_variable():
    assert read_user_variable("test", "test") == "test"


# Generated at 2022-06-23 16:12:54.089671
# Unit test for function render_variable
def test_render_variable():
    """Test the render_variable function.

    Initial tests are based on render_variable_test_context dict
    """

    # Test a simple string - no render required
    env = StrictEnvironment({})
    cookiecutter_dict = OrderedDict([])
    raw = 'test'
    assert render_variable(env, raw, cookiecutter_dict) == 'test'

    # Test a simple dict - no render required
    raw ={'test': 1}
    assert render_variable(env, raw, cookiecutter_dict) == {'test': 1}

    # Test a simple list - no render required
    raw = [1, 2, 3]
    assert render_variable(env, raw, cookiecutter_dict) == [1, 2, 3]

    # Test a simple variable - no render required

# Generated at 2022-06-23 16:12:55.931448
# Unit test for function read_user_variable
def test_read_user_variable():
    assert read_user_variable("Ask a question", "Some default value") == "Some default value"



# Generated at 2022-06-23 16:12:58.232377
# Unit test for function read_repo_password
def test_read_repo_password():
    """Unit: Test function read_repo_password"""
    secret = read_repo_password("enter secret")
    assert secret == "secret"

# Generated at 2022-06-23 16:13:01.004909
# Unit test for function read_user_variable
def test_read_user_variable():
    var_name = 'username'
    default_value = 'alice'
    assert read_user_variable(var_name = var_name, default_value = default_value) == 'alice'


# Generated at 2022-06-23 16:13:02.445695
# Unit test for function process_json
def test_process_json():
    assert(process_json("{'foo': 'bar'}") == {'foo': 'bar'})

# Generated at 2022-06-23 16:13:08.778068
# Unit test for function read_user_dict
def test_read_user_dict():
    from collections import OrderedDict
    # test empty dict as input
    empty_dict = {}
    assert read_user_dict("key", empty_dict) == empty_dict
    # test normal dict as input
    normal_dict = {"key": "value"}
    assert read_user_dict("key", normal_dict) == normal_dict
    # test dict with multiple keys
    complex_dict = OrderedDict({"key1": ["value1", "value2"], "key2": {"key3":"value3"}})
    prompted_dict = {"key1": ["value1", "value2"], "key2": {"key3":"value3"}}
    assert read_user_dict("key", complex_dict) == prompted_dict


# Generated at 2022-06-23 16:13:10.247168
# Unit test for function read_user_choice
def test_read_user_choice():
    var_name = 'var'
    options = ['option1', 'option2']

    ret_value = read_user_choice(var_name, options)
    assert ret_value in options

# Generated at 2022-06-23 16:13:12.803471
# Unit test for function read_repo_password
def test_read_repo_password():
    click.echo(read_repo_password('What is your password?'))


# Generated at 2022-06-23 16:13:15.622056
# Unit test for function read_user_variable
def test_read_user_variable():
    "Tests if read_user_variable asks the question correctly with the right answer given"
    click.confirm("hello") == True



# Generated at 2022-06-23 16:13:24.829464
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test if prompt_for_config works as expected
    """
    context = {
        'cookiecutter': {
            "project_name": "NOVACookie",
            "database_name": "myproject_test",
            "database_user": "myproject_user",
            "database_password": "myproject_user_pass"
        },
        'cookiecutter': {'project_name': 'NOVACookie'}
    }
    cookiecutter_dict = prompt_for_config(context, False)
    assert cookiecutter_dict == {
        "project_name": "NOVACookie",
        "database_name": "myproject_test",
        "database_user": "myproject_user",
        "database_password": "myproject_user_pass"
    }

# Generated at 2022-06-23 16:13:27.346548
# Unit test for function read_user_variable
def test_read_user_variable():

    options = 'Yes'
    assert read_user_variable('Test prompt',options) == options


# Generated at 2022-06-23 16:13:30.407749
# Unit test for function read_user_variable
def test_read_user_variable():
    var_name = 'name'
    default_value = 'default'
    res = read_user_variable(var_name, default_value)
    assert(res == default_value)


# Generated at 2022-06-23 16:13:32.327407
# Unit test for function read_user_variable
def test_read_user_variable():
    assert read_user_variable('var_name', 'default_value') == 'default_value'

# Generated at 2022-06-23 16:13:38.780238
# Unit test for function render_variable
def test_render_variable():
    """
    Test for render_variable function
    """
    import os
    import pytest
    from jinja2 import Undefined
    from jinja2.exceptions import UndefinedError
    from cookiecutter.template import get_template_from_url
    from cookiecutter.zipfile import extract_zip

    # absolute path of project
    abspath = os.path.abspath(os.path.dirname(__file__))

    #Project name with underscore, to test underscore in render_variable
    project_name_underscore = "project_name_underscore"

    #Test with a project which has simple and raw variables
    project = os.path.join(abspath, "fixtures/new_project")

# Generated at 2022-06-23 16:13:48.445468
# Unit test for function read_user_dict
def test_read_user_dict():
    val = read_user_dict('dict_name', {})
    assert val == {}
    assert isinstance(val, dict)

    val = read_user_dict('dict_name', {'k':'v'})
    assert val == {}
    assert isinstance(val, dict)

    val = read_user_dict('dict_name', {'k':'v'})
    assert val == {'k':'v'}
    assert isinstance(val, dict)

    val = read_user_dict('dict_name', {'k':['v1','v2']})
    assert val == {'k':['v1','v2']}
    assert isinstance(val, dict)

# Generated at 2022-06-23 16:13:54.218929
# Unit test for function read_user_choice
def test_read_user_choice():
    """Unit test for function read_user_choice"""
    options = ['foo', 'bar', 'baz']
    var_name = 'foo'
    assert read_user_choice(var_name, options) == 'foo'
    read_user_choice('foo', ['foo', 'bar', 'baz'])
    read_user_choice('foo', [1, 2, 3])
    with pytest.raises(TypeError):
        read_user_choice('foo', 'foo')
    with pytest.raises(ValueError):
        read_user_choice('foo', [])
    read_user_choice('foo', ['foo', 'bar', 'baz'], 'foo')
    read_user_choice('foo', [1, 2, 3], 1)

    class O(object):
        """Object"""


# Generated at 2022-06-23 16:14:03.822670
# Unit test for function render_variable
def test_render_variable():
    # Test 1
    context = {'cookiecutter': {'project_name': 'hello', 'version': '0.1.0'}}
    env = StrictEnvironment(context=context)
    cookiecutter_dict = {'project_name': 'hello'}
    raw = '{{ cookiecutter.project_name }}'
    assert render_variable(env, raw, cookiecutter_dict) == 'hello'
    # Test 2
    context = {'cookiecutter': {'project_name': 'hello', 'version': '0.1.0'}}
    env = StrictEnvironment(context=context)
    cookiecutter_dict = {'project_name': 'hello'}
    raw = '{{ cookiecutter.project_name + "-" + cookiecutter.version }}'

# Generated at 2022-06-23 16:14:10.371389
# Unit test for function read_user_dict
def test_read_user_dict():
    from collections import OrderedDict

# Generated at 2022-06-23 16:14:12.368080
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    assert read_user_yes_no("Pizza", True) == True
    assert read_user_yes_no("Pizza", False) == False

# Generated at 2022-06-23 16:14:15.239043
# Unit test for function read_user_choice
def test_read_user_choice():
    choice = read_user_choice("Option", ("one", "two", "three"))
    assert (choice == "one")

if __name__ == '__main__':
    test_read_user_choice()

# Generated at 2022-06-23 16:14:23.394525
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo-pre/', no_input=True)

    assert context == {
        'project_name': 'Cookie Monster',
        '_template': 'tests/fake-repo-pre/',
        'project_slug': 'cookie-monster',
        'pypi_username': 'audreyr',
        'github_username': 'audreyr',
        'release_date': '2014-04-14',
        'year': '2014'
    }

# Generated at 2022-06-23 16:14:25.281988
# Unit test for function read_user_dict
def test_read_user_dict():
    read_user_dict('test_dict', {'a': 1, 'b': 2})


# Generated at 2022-06-23 16:14:29.887397
# Unit test for function read_user_choice
def test_read_user_choice():
    var_name = 'a'
    options = ['a','b','c','d']
    assert read_user_choice(var_name,options) == 'a'
    assert read_user_choice(var_name,options) == 'b'
    assert read_user_choice(var_name,options) == 'c'
    assert read_user_choice(var_name,options) == 'd'

# Generated at 2022-06-23 16:14:38.578074
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    """Test the read_user_yes_no() function."""

    # Test yes answers
    answer = read_user_yes_no("Yes/No Test", 'yes')
    assert answer is True
    answer = read_user_yes_no("Yes/No Test", 'y')
    assert answer is True
    answer = read_user_yes_no("Yes/No Test", 'true')
    assert answer is True
    answer = read_user_yes_no("Yes/No Test", '1')
    assert answer is True

    # Test no answers
    answer = read_user_yes_no("Yes/No Test", 'no')
    assert answer is False
    answer = read_user_yes_no("Yes/No Test", 'n')
    assert answer is False

# Generated at 2022-06-23 16:14:45.540250
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'My Test Project',
            '_private': True,
            '__private': 'hidden',
            'hello': {'foo': 'bar'},
            'nested': {'a': {'b': 'c'}},
            'thing': {'foo': {'bar': 'baz'}},
        }
    }

# Generated at 2022-06-23 16:14:48.304861
# Unit test for function read_user_variable
def test_read_user_variable():
    var_name = "a"
    default_value = 1
    assert(read_user_variable(var_name, default_value) == 1)


# Generated at 2022-06-23 16:14:59.843176
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    raw_value = {
        'first': 'first value',
        'second': 'second value',
    }
    test_value = ['first value', 'second value']
    context = {
        'cookiecutter': {
            'value': test_value
        }
    }

    rendered_value = prompt_choice_for_config(context, StrictEnvironment(), 'value', test_value, no_input=True)
    assert rendered_value == test_value[0]
    rendered_value = prompt_choice_for_config(context, StrictEnvironment(), 'value', test_value, no_input=False)
    assert rendered_value in test_value

    # Test if rendered string is same as original

# Generated at 2022-06-23 16:15:07.236375
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    '''
    Test if the function returns the correct value for a given input
    '''
    assert read_user_yes_no("Do you know the muffin man?", True) == True
    assert read_user_yes_no("Do you know the muffin man?", True) == True
    assert read_user_yes_no("Do you know the muffin man?", False) == False
    assert read_user_yes_no("Do you know the muffin man?", True) == True
    assert read_user_yes_no("Do you know the muffin man?", False) == False

# Generated at 2022-06-23 16:15:14.835834
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """Test prompt_choice_for_config."""
    context = OrderedDict([('cookiecutter', OrderedDict())])
    context['cookiecutter']['version_control_system'] = [
        '{{ cookiecutter.repo_name | replace(" ", "_") }}.git',
        'git'
    ]
    context['cookiecutter']['repo_name'] = 'test_repo'
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])
    cookiecutter_dict['repo_name'] = 'test_repo'
    assert prompt_choice_for_config(cookiecutter_dict, env, 'version_control_system',
                                    context['cookiecutter']['version_control_system'], False) == 'git'

# Generated at 2022-06-23 16:15:19.585470
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    click.testing.CliRunner(mix_stderr=False).invoke(
        read_user_yes_no, ["question", "question", "default_value", "n"]
    )


# Generated at 2022-06-23 16:15:28.368902
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    question = "Is that true?"
    assert read_user_yes_no(question, "no") == read_user_yes_no()
    assert read_user_yes_no(question, "yes") == read_user_yes_no()
    assert read_user_yes_no(question, "1") == read_user_yes_no()
    assert read_user_yes_no(question, "0") == read_user_yes_no()
    assert read_user_yes_no(question, "y") == read_user_yes_no()
    assert read_user_yes_no(question, "n") == read_user_yes_no()

# Generated at 2022-06-23 16:15:39.303979
# Unit test for function process_json
def test_process_json():
    """Test the function process_json."""
    from collections import OrderedDict

    dict1 = {'a': 2, 'b': 3}
    dict2 = {'k': 2, 'l': 3}

    empty_dict = {}
    list1 = []
    list2 = [1, 2, 3]
    dict_list = [dict1, dict2]
    empty_list = [{}, list1, list2]
    empty_dict_list = [empty_dict, empty_dict, empty_dict]
    empty_str = ''

    dict_str = json.dumps(dict1)
    list_str = json.dumps(list2)
    dict_list_str = json.dumps(dict_list)
    empty_list_str = json.dumps(empty_list)

    assert process_

# Generated at 2022-06-23 16:15:48.395453
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    """
    Prompts user to answer the following question and return the value.
    """

    question = 'Do you want to use the default value?'

    default_value_1 = 'y'
    default_value_2 = 'Y'
    default_value_3 = 'n'
    default_value_4 = 'N'
    default_value_5 = 'yes'
    default_value_6 = 'Yes'
    default_value_7 = 'no'
    default_value_8 = 'No'
    default_value_9 = 'half'
    default_value_10 = 'no-default'


    if read_user_yes_no(question, default_value_1) == True:
        print('Success 1')
    else:
        print('Success 1')


# Generated at 2022-06-23 16:15:54.459843
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """Check rendering of options for choices."""
    choices = ["a/{{ cookiecutter.project_name }}", "b/{{ cookiecutter.project_name }}"]
    cookiecutter_dict = {}
    env = StrictEnvironment(context={'cookiecutter': {'project_name': 'my_project'}})
    assert prompt_choice_for_config(cookiecutter_dict, env, 'test', choices, no_input=True) == 'a/my_project'
    assert prompt_choice_for_config(cookiecutter_dict, env, 'test', choices, no_input=True) == 'b/my_project'

# Generated at 2022-06-23 16:15:56.001548
# Unit test for function process_json
def test_process_json():
    assert process_json('{"a": "b"}') == {"a": "b"}

# Generated at 2022-06-23 16:16:06.145596
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """Unit test for function prompt_choice_for_config"""
    config = {
        'cookiecutter': {
            'project_slug': [
                '{{ cookiecutter.project_name.lower().replace(" ", "-") }}',
                '{{ cookiecutter.project_name.lower().replace(" ", "_") }}',
                '{{ cookiecutter.project_name.lower().replace(" ", "") }}',
            ]
        },
    }

    # Test for regex in project_slug: '{{ cookiecutter.project_name.lower().replace(" ", "-") }}'
    result1 = prompt_choice_for_config(
        {'project_name': 'test project'}, StrictEnvironment(context=config),
        'project_slug', config['cookiecutter']['project_slug'], False
    )

# Generated at 2022-06-23 16:16:13.847900
# Unit test for function read_user_choice
def test_read_user_choice():
    # No input returns the first item
    assert read_user_choice('var_name', ['foo', 'bar']) == 'foo'
    assert read_user_choice('var_name', ['foo', 'bar', 'baz']) == 'foo'
    # Only one choice in the sequence
    assert read_user_choice('var_name', ['foo']) == 'foo'
    # No input with one item, raises warning
    assert read_user_choice('var_name', []) == []
    # Not a list
    assert read_user_choice('var_name', 'foo') == 'foo'

# Generated at 2022-06-23 16:16:25.909606
# Unit test for function prompt_for_config

# Generated at 2022-06-23 16:16:35.002656
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Test with a small context
    test_context = {
        'cookiecutter': {
            'project_name': 'Hello World',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'select_test': {'test_option': 'Test'}
        }
    }
    cookiecutter_dict = prompt_for_config(test_context)
    assert cookiecutter_dict['project_name'] == 'Hello World'
    assert cookiecutter_dict['repo_name'] == 'Hello_World'

    # Test with a choice list

# Generated at 2022-06-23 16:16:42.192362
# Unit test for function render_variable
def test_render_variable():
    """Test render_variable function against expected values."""
    raw = "{{ cookiecutter.x }}"
    cookiecutter_dict = {'x': 'X'}
    env = StrictEnvironment()
    assert render_variable(env, raw, cookiecutter_dict) == raw
    raw = "{{ cookiecutter.x }}"
    cookiecutter_dict = {'x': 'X'}
    env = StrictEnvironment()
    assert render_variable(env, raw, cookiecutter_dict) == raw



# Generated at 2022-06-23 16:16:45.124310
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    __no_input = True
    __question = 'question'
    __default_value = 'default_value'
    assert read_user_yes_no(__question, __default_value) == __no_input


# Generated at 2022-06-23 16:16:50.131943
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    env = StrictEnvironment()
    context = {'cookiecutter': {'select': [1]}}
    key = "select"

    expected = 1
    actual = prompt_choice_for_config(context, env, key, [1], True)
    assert expected == actual

# Generated at 2022-06-23 16:16:54.798887
# Unit test for function process_json
def test_process_json():
    """Test processing of JSON input"""
    input_data = '{"foo": "bar", "foobar": "foobar", "foofoo": {"barbar": {"bar": "foo"}}}'
    output_data = process_json(input_data)
    if not isinstance(output_data, dict):
        raise ValueError
    if output_data["foo"] != "bar":
        raise ValueError
    return True


# Generated at 2022-06-23 16:16:55.871495
# Unit test for function read_repo_password
def test_read_repo_password():
    question = "test for password function: "
    password_test = read_user_yes_no(question)
    assert password_test == "test for password function: "


# Generated at 2022-06-23 16:17:05.323458
# Unit test for function read_user_choice
def test_read_user_choice():
    options = ['django', 'flask']

    # Test that our first option is chosen
    def simulate_read_user_choice(prompt, default):
        return ''
    read_user_choice.read_user_choice = simulate_read_user_choice
    assert read_user_choice('framework', options) == 'django'

    # Test for custom index
    def simulate_read_user_choice(prompt, default):
        return '2'
    read_user_choice.read_user_choice = simulate_read_user_choice
    assert read_user_choice('framework', options) == 'flask'

    # Test for custom index that is out of range
    def simulate_read_user_choice(prompt, default):
        return '3'
    read_user_choice.read_user_choice = simulate_read

# Generated at 2022-06-23 16:17:16.598160
# Unit test for function render_variable
def test_render_variable():
    class FakeEnv(object):
        def from_string(self, template):
            return template

    env = FakeEnv()


# Generated at 2022-06-23 16:17:26.523683
# Unit test for function prompt_for_config

# Generated at 2022-06-23 16:17:28.558984
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "foo"
    default_value = {}
    result = read_user_dict(var_name, default_value)
    assert isinstance(result, dict)

# Generated at 2022-06-23 16:17:36.216618
# Unit test for function prompt_for_config

# Generated at 2022-06-23 16:17:37.977498
# Unit test for function read_user_variable
def test_read_user_variable():
    assert read_user_variable("foo", "bar") == "bar"


# Generated at 2022-06-23 16:17:49.510058
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    function read_user_dict should work as expected.
    """
    # Current version of click causes a TypeError when testing the
    # read_user_dict function because click.prompt (which is used inside
    # the read_user_dict function) is called with the `default` of type
    # python dict. In the click._compat module, there is a condition that
    # checks if `default` is of type `str` or `None`. Because it is neither,
    # a TypeError is thrown. This exception is caught here, so we can
    # continue with the unit test.
    try:
        from click._compat import PY2, WIN
        read_user_dict('foo', {})
    except TypeError:
        pass
    else:
        raise


# Generated at 2022-06-23 16:17:52.163793
# Unit test for function read_user_choice
def test_read_user_choice():
    result = read_user_choice('my_name', ['first', 'second', 'third'])
    assert result == 'first'

# Generated at 2022-06-23 16:18:03.641596
# Unit test for function prompt_for_config

# Generated at 2022-06-23 16:18:15.038483
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():

    # Test 1: The first choice is to be presented as the default
    options = [{"key1":"value1"},{"key2":"value2"}]
    assert prompt_choice_for_config(context = "" , env = "", key = "", options = options, no_input = True) == options[0]

    # Test 2: The second choice is to be presented as the default - this should fail
    options = [{"key1":"value1"},{"key2":"value2"}]
    assert prompt_choice_for_config(context = "" , env = "", key = "", options = options, no_input = True) != options[1]

    # Test 3: Only one choice is available
    options = [{"key1":"value1"}]

# Generated at 2022-06-23 16:18:20.076714
# Unit test for function process_json
def test_process_json():
    user_value = '{"test": "this is a test"}'
    user_value1 = '{"test": "this is a test'
    user_value2 = '"test": "this is a test"}'

    assert(process_json(user_value) == {"test": "this is a test"})

    try:
        process_json(user_value1)
        assert False
    except click.UsageError:
        assert True

    try:
        process_json(user_value2)
        assert False
    except click.UsageError:
        assert True

# Generated at 2022-06-23 16:18:31.609731
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """Unit test for function prompt_choice_for_config"""

    no_input = True
    prompt = False


# Generated at 2022-06-23 16:18:41.784023
# Unit test for function read_user_variable
def test_read_user_variable():
    var_name = "Variable prompt"
    default_value = "default_value"

    # dummy inputs to simulate user inputs
    user_input = "user_input"
    user_input2 = ""
    user_input3 = " "
    user_input4 = "  "

    # var_name and default value are the same
    assert(read_user_variable(var_name, default_value) == default_value)
    # default value is None
    assert(read_user_variable(var_name, None) == "")
    # var_name is None
    assert(read_user_variable(None, default_value) == "")
    # var_name and default value are None
    assert(read_user_variable(None, None) == "")
    # user_input is not None or empty string

# Generated at 2022-06-23 16:18:47.844524
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function
    """
    from cookiecutter.main import cookiecutter
    user_dict = {"author": "Foo Bar"}
    cookiecutter_dict = cookiecutter(
        'tests/test-generate/input-user-dict/',
        no_input=True,
        extra_context=user_dict)
    assert cookiecutter_dict["author"] == user_dict["author"]

# Generated at 2022-06-23 16:18:55.465519
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    from cookiecutter import utils
    from cookiecutter.cli import ui

    context = {"cookiecutter": {"name": "Jinja2", "version": "2.9"}}
    cc = {"_template": ".", "name": "Jinja2", "version": "2.9"}

    # Test 1: Prompt
    ui.yes_no_prompt = lambda x, y: True
    ui.read_user_variable = lambda x, y: "Blue"
    env = StrictEnvironment(context=context)

    print(
        prompt_choice_for_config(cc, env, "color", ["Red", "Green", "Blue"], no_input=False)
    )
    # Correct answer: Blue

# Generated at 2022-06-23 16:18:59.699319
# Unit test for function process_json
def test_process_json():

    user_value = {'test': '{{ cookiecutter.val }}'}
    cookiecutter_dict = {'val': 'value'}

    env = StrictEnvironment(context=cookiecutter_dict)

    val = render_variable(env, user_value, cookiecutter_dict)

    assert val is not None

# Generated at 2022-06-23 16:19:02.610573
# Unit test for function read_repo_password
def test_read_repo_password():
    question = 'hi'
    assert (read_repo_password(question) == click.prompt(question, hide_input=True))



# Generated at 2022-06-23 16:19:08.373801
# Unit test for function read_user_choice
def test_read_user_choice():
    """
    Test: read_user_choice

    This function tests the read_user_choice function by testing the function
    with a valid scenario.
    """

    # Arrange
    test_data = ["Choice A", "Choice B", "Choice C"]
    return_value = read_user_choice("var_name", test_data)

    # Assert
    assert return_value == "Choice A"

# Generated at 2022-06-23 16:19:11.481340
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    assert read_user_yes_no('Yes or No?', True) == True
    assert read_user_yes_no('Yes or No?', True) == False

# Generated at 2022-06-23 16:19:21.493400
# Unit test for function render_variable
def test_render_variable():
    """Test rendering of variable."""
    env = StrictEnvironment()
    cookiecutter_dict = {
        "project_name": "Peanut Butter Cookie",
        "project_slug": "peanut-butter-cookie",
        "x": "hello",
        "y": "world",
        "z": 2,
        "apps": [],
        "meta": {},
    }
    raw = "{{ cookiecutter.project_name.replace(' ', '_') }}"  # This must be rendered
    assert render_variable(env, raw, cookiecutter_dict) == "Peanut_Butter_Cookie"
    raw = "{{ cookiecutter.x }}"  # This must be rendered
    assert render_variable(env, raw, cookiecutter_dict) == "hello"

# Generated at 2022-06-23 16:19:33.324388
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict("test", {'test': 'test'}) == {'test': 'test'}
    assert read_user_dict("test", {'test': {'test': 'test'}}) == {'test': {'test': 'test'}}
    assert read_user_dict("test", {'test': {'test': {'test': 'test'}}}) == {'test': {'test': {'test': 'test'}}}
    assert read_user_dict("test", {'test': {'test': {'test': {'test': 'test'}}}}) == {'test': {'test': {'test': {'test': 'test'}}}}

# Generated at 2022-06-23 16:19:43.264768
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read_user_dict function."""
    def test_read_user_dict_exception_types():
        """Test the read_user_dict function when the types are invalid."""
        with pytest.raises(TypeError):
            read_user_dict('hello', None)

    def test_read_user_dict_valid_case():
        """Test the read_user_dict function when the types are valid."""
        default_value = {'test': 'TEST'}
        user_dict = read_user_dict('hello', default_value)

        assert isinstance(user_dict, dict)
        assert user_dict == default_value

    test_read_user_dict_exception_types()
    test_read_user_dict_valid_case()

# Generated at 2022-06-23 16:19:54.884818
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    """
    Test the function prompt_choice_for_config.
    """
    # Default test
    context = {
        'cookiecutter': {'test_key':[{'test_key2':'{{cookiecutter.test_key3}}'}]}
    }
    answer = prompt_choice_for_config(context, None, 'test_key', [{'test_key2':'{{cookiecutter.test_key3}}'}], False)
    assert answer == {'test_key2':'{{cookiecutter.test_key3}}'}

    # Replace variables

# Generated at 2022-06-23 16:20:02.990208
# Unit test for function render_variable
def test_render_variable():
    """Test that render_variable makes substitutions correctly."""
    context = {
        'cookiecutter': {
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "-") }}',
            'project_name': 'Awesome Project',
        }
    }
    env = StrictEnvironment(context=context)
    rendered = render_variable(env, 'repo_name', context['cookiecutter'])
    assert rendered == '{{ cookiecutter.project_name.replace(" ", "-") }}'
    rendered = render_variable(env, '{{ cookiecutter.repo_name }}', context['cookiecutter'])
    assert rendered == 'Awesome-Project'
    rendered = render_variable(env, '{{ cookiecutter.repo_name }}.git', context['cookiecutter'])
    assert rendered

# Generated at 2022-06-23 16:20:08.544515
# Unit test for function render_variable
def test_render_variable():
    """Test for function render_variable."""
    raw = '{{ cookiecutter.project_name }}'
    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    env = StrictEnvironment(context=cookiecutter_dict)
    rendered_variable = render_variable(env, raw, cookiecutter_dict)
    assert rendered_variable == 'Peanut Butter Cookie'



# Generated at 2022-06-23 16:20:15.624404
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for function read_user_dict"""
    test_dict = {'ab': 'cd', 'ef': 'gh'}
    test_default_dict = {'ab': 'cd', 'ef': 'gh'}
    test_input = '{"ab":"cd","ef":"gh"}'

    result = read_user_dict('test_var', test_dict)
    assert test_default_dict == result

    result = read_user_dict('test_var', test_dict)
    assert test_default_dict == result

    result = read_user_dict('test_var', test_dict)
    assert test_default_dict == result



# Generated at 2022-06-23 16:20:23.577843
# Unit test for function prompt_for_config

# Generated at 2022-06-23 16:20:30.213698
# Unit test for function read_repo_password
def test_read_repo_password():
    """Test the function read_repo_password."""
    from click.testing import CliRunner

    runner = CliRunner()
    result = runner.invoke(
        read_repo_password,
        ['Please, enter your password to access the repository:'],
        input='password',
    )
    assert result.output == 'Please, enter your password to access the repository: \n'
    assert result.exit_code == 0

# Generated at 2022-06-23 16:20:31.975435
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    assert 'yes' == read_user_yes_no('Do you like Cookiecutter?', True)


# Generated at 2022-06-23 16:20:34.296565
# Unit test for function process_json
def test_process_json():
    result = process_json("{'key': 'value'}")
    assert result['key'] == 'value'

# Generated at 2022-06-23 16:20:45.886419
# Unit test for function render_variable
def test_render_variable():
    """Test function that renders variables in Jinja2 template format."""
    # Setup 1
    # Given
    context = {
        'cookiecutter': {
            'project_slug': '{{ cookiecutter.project_name.replace(" ","_") }}',
            'project_name': 'Test 1',
        }
    }
    # When
    rendered_variable = render_variable(context['cookiecutter']['project_slug'], context)
    # Then
    assert rendered_variable == 'Test_1'

    # Setup 2
    # Given
    context = {'cookiecutter': {'project_name': 'Test 2'}}
    # When
    rendered_variable = render_variable(context['cookiecutter']['project_name'], context)
    # Then

# Generated at 2022-06-23 16:20:53.551917
# Unit test for function read_user_variable
def test_read_user_variable():
    var_name = 'Project name:'
    default_value = 'My Project'
    selected_value = 'Your Project'

    assert read_user_variable(var_name, default_value) == default_value

    with patch('click.prompt') as mock_prompt:
        mock_prompt.return_value = selected_value
        assert read_user_variable(var_name, default_value) == selected_value
        mock_prompt.assert_called_once_with(
            var_name, default=default_value
        )


# Generated at 2022-06-23 16:20:56.506177
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    assert read_user_yes_no('Foo bar?', True) == True
    assert read_user_yes_no('Foo bar?', False) == False


# Generated at 2022-06-23 16:21:05.851836
# Unit test for function process_json
def test_process_json():
    """Unit test for function process_json to make sure it works for reasonable inputs."""
    assert process_json("""{"a": "A", "b": "B", "c": "C", "d": ["D", "E", "F"], "e": {"f": "G", "g": "H"}}""") == {
        'a': 'A',
        'b': 'B',
        'c': 'C',
        'd': ['D', 'E', 'F'],
        'e': {
            'f': 'G',
            'g': 'H'
        }
    }

# Generated at 2022-06-23 16:21:10.119739
# Unit test for function process_json
def test_process_json():
    """
    Unit test for function process_json
    """
    input_1 = '{"a": 1, "b": 2, "c": 3}'
    input_2 = process_json(input_1)
    assert isinstance(input_2, OrderedDict)
    assert input_2['a'] == 1
    assert input_2['b'] == 2
    assert input_2['c'] == 3

# Generated at 2022-06-23 16:21:17.270306
# Unit test for function prompt_choice_for_config
def test_prompt_choice_for_config():
    test_options = ['default', 'override']
    test_context = OrderedDict([('cookiecutter', OrderedDict([('test_key', test_options)]))])
    test_cookiecutter_dict = OrderedDict([])
    test_env = StrictEnvironment(context=test_context)
    assert prompt_choice_for_config(test_cookiecutter_dict, test_env, 'test_key', test_options, False) == 'default'
    assert prompt_choice_for_config(test_cookiecutter_dict, test_env, 'test_key', test_options, True) == 'default'


if __name__ == '__main__':
    test_prompt_choice_for_config()

# Generated at 2022-06-23 16:21:18.580117
# Unit test for function read_repo_password
def test_read_repo_password():
    question = 'GitHub Password (never stored)'
    assert read_user_yes_no(question, 'yes'), True


# Generated at 2022-06-23 16:21:29.505866
# Unit test for function render_variable
def test_render_variable():
    render_variable_dict = {
        'render_variable': render_variable
    }
    
    render_variable_env = StrictEnvironment(context=render_variable_dict)
    
    cookiecutter_dict = OrderedDict({})
    cookiecutter_dict['foo'] = 'bar'

    assert render_variable(render_variable_env, '{{cookiecutter.foo}}', cookiecutter_dict) == 'bar'
    assert render_variable(render_variable_env, 'Foo {{cookiecutter.foo}}', cookiecutter_dict) == 'Foo bar'
    assert render_variable(render_variable_env, 'Foo bar', cookiecutter_dict) == 'Foo bar'

# Generated at 2022-06-23 16:21:37.993534
# Unit test for function read_user_choice
def test_read_user_choice():
    test_cases = [
        {
            'test_case_name': 'Test user selection',
            'var_name': 'selection',
            'options': ['Yes', 'No'],
            'expected_choice': 'Yes',
            'choice_to_test': '1',
        },
        {
            'test_case_name': 'Test user selection',
            'var_name': 'selection',
            'options': ['Yes', 'No'],
            'expected_choice': 'No',
            'choice_to_test': '2',
        },
    ]

    for test_case in test_cases:
        if test_case['choice_to_test'] == '1':
            choice = read_user_choice(
                test_case['var_name'],
                test_case['options'],
            )


# Generated at 2022-06-23 16:21:49.112027
# Unit test for function read_user_variable
def test_read_user_variable():
    """Test the User Prompts"""
    cookiecutter_dict = OrderedDict([])

# Generated at 2022-06-23 16:22:00.532967
# Unit test for function prompt_choice_for_config

# Generated at 2022-06-23 16:22:08.493076
# Unit test for function process_json
def test_process_json():
    # Unit test for function process_json
    dict1 = {"key1": 1, "key2": [2, 3], "key3": {"key4": 4}}
    assert process_json(json.dumps(dict1)) == dict1

    dict2 = {"key1": "value1", "key2": {"key3": "value3"}}
    assert process_json(json.dumps(dict2)) == dict2

    dict3 = {
        "key1": {"key2": {"key3": {"key4": {"key5": {"key6": {"key7": {"key8": {"key9": {"key10": "value10"}}}}}}}}}
    }
    assert process_json(json.dumps(dict3)) == dict3

# Generated at 2022-06-23 16:22:14.200788
# Unit test for function read_user_yes_no
def test_read_user_yes_no():
    assert read_user_yes_no("y", "yes") == True
    assert read_user_yes_no("n", "no") == False
    assert read_user_yes_no("1", "1") == True
    assert read_user_yes_no("0", "0") == False
    assert read_user_yes_no("Yes", "Yes") == True
    assert read_user_yes_no("No", "No") == False


# Generated at 2022-06-23 16:22:21.355296
# Unit test for function read_user_dict
def test_read_user_dict():
    from cookiecutter.prompt import read_user_dict
    from click.testing import CliRunner
    # Note - this test is a bit fubar.
    # It doesn't actually test that the default value is returned.
    # Instead, it just tests that the function executes without error.
    runner = CliRunner()
    result = runner.invoke(read_user_dict, [
        'test',
        '--default-value', '{"test": "value"}',
    ])
    assert result.output == ''