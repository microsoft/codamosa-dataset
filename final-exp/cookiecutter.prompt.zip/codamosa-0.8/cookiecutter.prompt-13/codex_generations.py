

# Generated at 2022-06-22 14:43:31.033481
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """ Test This Function """

# Generated at 2022-06-22 14:43:34.085621
# Unit test for function read_user_choice
def test_read_user_choice():
    test_options = ['option1', 'option2', 'option3', 'option4']
    test_var_name = "test_var_name"
    assert read_user_choice(test_var_name, test_options) in test_options
    return

# Generated at 2022-06-22 14:43:46.590981
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test to verify the functionality of prompt_for_config.
    Use the following command to run:
        pytest tests/test_prompt.py
    """

# Generated at 2022-06-22 14:43:58.686822
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function `prompt_for_config`"""

    import sys
    import shlex

    context = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.repo_name|replace(" ", "_") }}',
            'repo_name': '{{ cookiecutter.repo_name|replace(" ", "-") }}',
            'repo_name_lower': '{{ cookiecutter.repo_name|lower() }}',
            'repo_name_format': '[a-z][a-z0-9]*',
        }
    }
    no_input = False
    cookiecutter_dict = prompt_for_config(context, no_input)
    assert 'repo_name' in cookiecutter_dict

    if sys.platform == 'win32':
        fake

# Generated at 2022-06-22 14:44:02.122191
# Unit test for function read_user_dict
def test_read_user_dict():
    read_user_dict("A",{'B':1,'C':2})

# Generated at 2022-06-22 14:44:11.538440
# Unit test for function process_json
def test_process_json():
    # test with a valid JSON
    my_json = '{"name" : "John", "age" : 30}'
    assert(process_json(my_json) ==  {"name": "John", "age": 30})

    # test with a valid JSON
    my_json = '{"name" : "John", "age" : null}'
    assert(process_json(my_json) ==  {"name": "John", "age": None})

    # test with an invalid JSON (unclosed parenthesis)
    my_json = '{"name" : "John", "age" : 30'
    try:
        process_json(my_json)
        assert(False)
    except click.UsageError:
        assert(True)

    # test with an invalid JSON (invalid syntax)

# Generated at 2022-06-22 14:44:15.869080
# Unit test for function read_user_choice
def test_read_user_choice():
    var_name = "env"
    options = ['dev', 'stage', 'prod']
    assert read_user_choice(var_name, options) == options[0]

# Generated at 2022-06-22 14:44:23.938031
# Unit test for function render_variable
def test_render_variable():
    """Test successful rendering of a variable value."""
    env = StrictEnvironment()
    cookiecutter_dict = {}
    val = render_variable(env, '{{ cookiecutter.name }}', cookiecutter_dict)
    assert val == ''

    cookiecutter_dict = {'name': 'Foo'}
    val = render_variable(env, '{{ cookiecutter.name }}', cookiecutter_dict)
    assert val == 'Foo'

    val = render_variable(env, '{{ cookiecutter.name|upper }}', cookiecutter_dict)
    assert val == 'FOO'



# Generated at 2022-06-22 14:44:36.414756
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:44:49.140537
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for method prompt_for_config()."""
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': "My Project",
            'project_slug': 'my_project',
        }
    }

    no_input_result = prompt_for_config(context, no_input=True)
    assert no_input_result == context['cookiecutter']

    input_result = prompt_for_config(context, no_input=False)
    assert isinstance(input_result, OrderedDict)
    assert len(input_result) == len(context['cookiecutter'])

# Generated at 2022-06-22 14:45:02.080913
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('Test variable', {'test_key': 'test_value'}) == {'test_key': 'test_value'}



# Generated at 2022-06-22 14:45:14.769420
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:45:20.321826
# Unit test for function read_user_dict
def test_read_user_dict():
    assert {"a": 1, "b": 2} == read_user_dict("test", {"a": 1, "b": 2}, True)
    assert {"a": 1} == read_user_dict("test", {"a": 1, "b": 2}, True)
    assert {"a": 1, "b": 2} == read_user_dict("test", {"a": 1, "b": 2})

# Generated at 2022-06-22 14:45:29.558270
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:45:41.218143
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:45:52.610836
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test 1: With default value
    value = read_user_dict(
        'Test Message',
        {'first':'first-1', 'second':'second-1', 'third':'third-1'}
    )
    # The result should still be a dictionary
    assert(isinstance(value, dict))
    # And it should be identical to the default value
    assert(value == {'first':'first-1', 'second':'second-1', 'third':'third-1'})

    # Test 2: With valid user input
    print('You should see the following message below this line:')
    print('Test Message')
    print('{')
    print('  "first": "first-2",')
    print('  "third": "third-2",')

# Generated at 2022-06-22 14:46:01.843009
# Unit test for function read_user_dict
def test_read_user_dict():
    from cookiecutter.prompt.prompt_methods import read_user_dict
    import click
    class FakeContextObj(object):
        def __init__(self, param_dict=None):
            self.params = param_dict or {}

    test_dict = {
        "first_key" : "first_value",
        "second_key" : "second_value",
        "third_key" : ["test", "second", "third", "fourth"],
        "forth_key" : {
            "first_key_of_forth_key" : "first_value_of_fourth_key",
            "second_key_of_forth_key" : "second_value_of_fourth_key"
        }
    }

    def test_input(prompt, default=False):
        contextobj = FakeContextObj

# Generated at 2022-06-22 14:46:10.305092
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:46:17.537616
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the function read_user_dict.
    """
    env = StrictEnvironment(context={})
    default_value = {
        'test_key': 'test_value'
    }
    user_dict = read_user_dict('dict_test', default_value)
    assert user_dict == default_value

    user_dict = read_user_dict('dict_test', default_value, env=env)
    assert user_dict == default_value

# Generated at 2022-06-22 14:46:22.178585
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
        'project_name': 'foo',
        '_secret': 'bar',
        '__secret2': 'baz',
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)

    assert cookiecutter_dict['project_name'] == 'foo'
    assert cookiecutter_dict['_secret'] == 'bar'
    assert cookiecutter_dict['__secret2'] == 'baz'

# Generated at 2022-06-22 14:46:40.143729
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter import main
    import os
    import shutil
    from pprint import pprint
    # Given:
    # A valid project template
    #   where the cookiecutter.json defines a valid variable and a default
    #   that can be rendered from another variable in the same cookiecutter.json
    # When:
    #   prompt_for_config is invoked
    #   for that template, not passing any input variable
    # Then:
    #   the resulting cookiecutter_dict variable should contain:
    #     variable and default variable
    #     with default variable having been rendered from the input variable
    cwd = os.getcwd()
    tmp = os.path.abspath(os.path.join(cwd, 'tmp'))

# Generated at 2022-06-22 14:46:51.154863
# Unit test for function prompt_for_config
def test_prompt_for_config():
    '''Tests for the prompt_for_config function'''
    context = {'cookiecutter': {'test':'test', 'test2':'test2'}}
    assert prompt_for_config(context) == {'test':'test', 'test2':'test2'}
    context = {'cookiecutter': {'test':'test', 'test2':'test2'}}
    assert prompt_for_config(context, no_input=True) == {'test':'test', 'test2':'test2'}
    context = {'cookiecutter': {'test':'{{cookiecutter.test2}}'}}
    assert prompt_for_config(context) == {'test':'test2'}

# Generated at 2022-06-22 14:47:02.818916
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:47:08.241261
# Unit test for function read_user_dict
def test_read_user_dict():
    variable_name = 'test_variable'
    default_value = {
        'test_key': 'test_value',
    }
    user_value = json.dumps(default_value, indent=2)
    user_value_dict = read_user_dict(variable_name, default_value)
    assert user_value == user_value_dict

# Generated at 2022-06-22 14:47:14.510275
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test if prompt_for_config works in a very simple case."""
    context = {
        'cookiecutter': {
            'first_name': 'Default first name',
            'last_name': 'Default last name',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)

    assert cookiecutter_dict['first_name'] == 'Default first name'
    assert cookiecutter_dict['last_name'] == 'Default last name'


# Generated at 2022-06-22 14:47:19.732211
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    Test the read_user_dict function
    """

    assert read_user_dict('first_key', {'second_key': 'test'}) == {'second_key': 'test'}

    assert read_user_dict('first_key', 0) == 0

# Generated at 2022-06-22 14:47:24.592034
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context_file = {
        'cookiecutter': {
            'project_name': 'Awesome Project',
            'project_slug': 'awesome_project',
            'release_date': '2014-08-14',
            'author_name': 'Your Name',
            'copyright_year': '2014',
            'version': '0.1.0',
            'pypi_username': 'your_username',
            'email': 'Your Name <email@example.com>',
            'description': 'An awesome project.',
            'domain_name': 'example.com',
            'timezone': 'UTC',
            'use_pycharm': True,
            'use_docker': True,
            'dockerhub_username': 'your_username',
        }
    }
    cookiecutter_dict = prompt_for

# Generated at 2022-06-22 14:47:25.792920
# Unit test for function prompt_for_config
def test_prompt_for_config():
    pass
    # TODO

# Generated at 2022-06-22 14:47:32.090980
# Unit test for function read_user_dict
def test_read_user_dict():
    test = {}
    testRead = read_user_dict("test", {})
    assert test == testRead, "testRead: " + str(testRead)
    test = {'test_key': 'test_value'}
    testRead = read_user_dict("test", test)
    assert test == testRead, "testRead: " + str(testRead)

    test = {"test_dict": {"test_key": "test_value"}}
    testRead = read_user_dict("test", test)
    assert test == testRead, "testRead: " + str(testRead)

    test = {"test_dict": "test_value"}
    testRead = read_user_dict("test", test)
    assert test == testRead, "testRead: " + str(testRead)


# Generated at 2022-06-22 14:47:42.632363
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('test1', {'a': 'a', 'b': 'c'}) == {'a': 'a', 'b': 'c'}
    assert read_user_dict('test2', {'a': 'a', 'b': 'c'}) == {'a': 'a', 'b': 'c'}
    assert read_user_dict('test3', {'a': 'a', 'b': 'c'}) == {'a': 'a', 'b': 'c'}
    assert read_user_dict('test4', {'a': 'a', 'b': 'c'}) == {'a': 'a', 'b': 'c'}

# Generated at 2022-06-22 14:48:03.655325
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Check if prompt_for_config() works as expected
    """
    env = StrictEnvironment(context={})
    cookiecutter_dict = OrderedDict([
        ('project_name', 'Peanut Butter Cookie'),
        ('repo_name', 'Peanut_Butter_Cookie'),
        ('_template', {'key1': 'value1', 'key2': 'value2'}),
    ])

# Generated at 2022-06-22 14:48:16.457286
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:48:27.107710
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    import json
    from tempfile import NamedTemporaryFile
    from os import path


    class TestObj(object):
        """Mock click.prompt method for testing"""

        def __init__(self, cookiecutter_dict):
            self.cookiecutter_dict = cookiecutter_dict

        def __call__(self, key, default=None, value_proc=None):
            """Returns default if default is in cookiecutter_dict"""
            if default is not None and default in self.cookiecutter_dict:
                return default
            return '{}'.format(self.cookiecutter_dict[key])



# Generated at 2022-06-22 14:48:35.177768
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict, env, context = {}, {}, {}
    read_user_variable("foo", "bar")
    read_user_dict("foo", "bar")
    read_user_yes_no("foo", "bar")
    read_user_choice("foo", {})
    render_variable("foo", "bar", "bar")
    result = prompt_for_config("foo", "bar")
    print("result = {}".format(result))


# Generated at 2022-06-22 14:48:44.051260
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test read_user_dict with non-dict default_value
    default_value = "default_string"
    try:
        read_user_dict("var_name", default_value)
    except TypeError:
        assert 1
    else:
        assert 0

    # Test read_user_dict with user-supplied empty string
    default_value = {}
    user_dict = read_user_dict("var_name", default_value)
    assert user_dict is default_value

    # Test read_user_dict with user-supplied JSON dict.
    default_value = {}
    user_value = '{"hello": "world"}'
    user_dict = read_user_dict("var_name", default_value, user_value)
    assert user_dict == {"hello": "world"}

    # Test read_user

# Generated at 2022-06-22 14:48:50.326053
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/test-cookiecutter-cli/fake-repo-pre/', no_input=True)
    assert context['repo_name'] == 'fake-repo'
    assert context['a_dict'] == {'key1': 'val1', 'key2': 'val2'}
    assert context['lowercase_variable'] == 'lowercase_value'

# Generated at 2022-06-22 14:48:58.961563
# Unit test for function process_json
def test_process_json():
    assert (
        process_json('{"proj_name": "test", "proj_version": "1.0"}') ==
        {"proj_name": "test", "proj_version": "1.0"}
    )

    assert (
        process_json(
            '{"project_name": "test", "project_version": "1.0", "repo_name": '
            '"test_repo"}'
        ) == {
            "project_name": "test",
            "project_version": "1.0",
            "repo_name": "test_repo"
        }
    )

# Generated at 2022-06-22 14:49:01.050668
# Unit test for function process_json
def test_process_json():
    """Test the function process_json()."""
    assert process_json("{}") == {}


# Generated at 2022-06-22 14:49:08.524909
# Unit test for function render_variable
def test_render_variable():
    env = StrictEnvironment()
    test_dict = {'test1': 'test2', 'test3': 'test4'}
    test_dict_raw = {'test1': '{{ cookiecutter.test3 }}',
                     'test3': '{{ cookiecutter.test1 }}'}
    assert render_variable(env, test_dict, test_dict_raw) == test_dict
    assert render_variable(env, '{{ cookiecutter.test1 }}', test_dict) == 'test2'
    assert render_variable(env, test_dict_raw, test_dict) == test_dict

# Generated at 2022-06-22 14:49:15.426200
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Hello World',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    cookiecutter_dict == {'project_name': 'Hello World', 'repo_name': 'Hello_World'}

# Generated at 2022-06-22 14:49:41.913401
# Unit test for function read_user_dict
def test_read_user_dict():
    """A function to test the read_user_dict function."""
    # Run the function.
    test_out = read_user_dict("dict_var", {'default': 'default'})
    test_out2 = read_user_dict("dict_var2", {'item1': 'item1', 'item2': 'item2'})

    # Assert that we get the correct output.
    assert(test_out == {'default': 'default'})
    assert(test_out2 == {'item1': 'item1', 'item2': 'item2'})

# Generated at 2022-06-22 14:49:54.082035
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['_hidden'] = {'hidden': 'This is hidden'}
    context['cookiecutter']['project_name'] = '{{ _hidden["hidden"] }}'

    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['_hidden'] == {'hidden': 'This is hidden'}
    assert cookiecutter_dict['project_name'] == 'This is hidden'

    # Test for failing variables
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['_hidden'] = {'hidden': 'This is hidden'}
    context['cookiecutter']['project_name'] = '{{ not_there }}'


# Generated at 2022-06-22 14:50:02.620302
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'repo_name': 'helloworld',
            'repo_description': 'hello world example',
            'open_source_license': 'MIT',
        },
    }
    cookiecutter_dict = prompt_for_config(context, True)
    assert 'repo_name' in cookiecutter_dict
    assert 'repo_description' in cookiecutter_dict
    assert 'open_source_license' in cookiecutter_dict



# Generated at 2022-06-22 14:50:06.192410
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""
    cookiecutter_dict = prompt_for_config({'cookiecutter': {'project_name': 'test'}})
    print(cookiecutter_dict)
    assert cookiecutter_dict['project_name'] == 'test'

# Generated at 2022-06-22 14:50:18.431197
# Unit test for function prompt_for_config
def test_prompt_for_config():

    # Test that if no_input, then read_user_variable doesn't get called (which raises a click.exceptions.Abort)
    try:
        context = {
            "cookiecutter": {
                "project_name": "My Project",
                "project_slug": "my_project",
                "python_interpreter": "python3.6",
            }
        }
        cookiecutter_dict = prompt_for_config(context, True)
        assert cookiecutter_dict["project_name"] == "My Project", "No-input test failed"
    except click.exceptions.Abort:
        assert False, "Tests should not raise an abort"
    except UndefinedVariableInTemplate:
        assert False, "Tests should not raise a jinja2 UndefinedVariableInTemplate"

# Generated at 2022-06-22 14:50:24.441178
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for prompt_for_config()"""
    from .main import context_from_dict

# Generated at 2022-06-22 14:50:31.150914
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
            'cookiecutter': {"project_name": "Test name", "list_of_vals": [1, 2, 3]},
            '_template_dir': ""
            }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == "Test name"
    assert cookiecutter_dict['list_of_vals'] == 1

# Generated at 2022-06-22 14:50:36.725837
# Unit test for function read_user_dict
def test_read_user_dict():
    # Not a dict
    assert read_user_dict('test', 1) == 1
    # Empty dict
    assert read_user_dict('test', {}) == {}
    # Non-empty dict
    assert read_user_dict('test', {'a': 1}) == {'a': 1}
    # Not a JSON
    assert read_user_dict('test', '{a: 1}') == {'a': 1}

# Generated at 2022-06-22 14:50:49.479116
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:55.608125
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the configuration prompt function."""
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/test-generate-json-prompts', no_input=True)


# Generated at 2022-06-22 14:52:50.771938
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:57.530453
# Unit test for function render_variable
def test_render_variable():
    """Render the next variable to be displayed in the user prompt."""
    # pylint: disable=unused-argument
    env = StrictEnvironment(context={'cookiecutter':{'project_name': 'Peanut Butter Cookie'}})
    assert render_variable(env, '{{ cookiecutter.project_name }}', {}) == 'Peanut Butter Cookie'
    assert render_variable(env, '{{ cookiecutter.project_name.replace(" ", "_") }}', {}) == 'Peanut_Butter_Cookie'

# # Unit test for function prompt_choice_for_config

# Generated at 2022-06-22 14:53:03.855904
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for function read_user_dict."""
    env = {'cookiecutter': {'_name': 'initial'}}
    ##### Test reading string.
    val = read_user_dict('_name', 'initial', env, no_input=True)
    assert val == 'initial'
    ##### Test reading string with spaces.
    val = read_user_dict('_name', 'This is an initial string.', env, no_input=True)
    assert val == 'This is an initial string.'
    ##### Test reading json string.
    val = read_user_dict('_name', '"This is an initial string."', env, no_input=True)
    assert val == 'This is an initial string.'
    ##### Test reading bool.

# Generated at 2022-06-22 14:53:09.130513
# Unit test for function prompt_for_config