

# Generated at 2022-06-22 14:43:18.631357
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from .main import get_context
    print(prompt_for_config(get_context(), no_input=True))

# Generated at 2022-06-22 14:43:26.639475
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit tests for function prompt_for_config."""

# Generated at 2022-06-22 14:43:34.358290
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:43:42.963512
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_context = {
        'cookiecutter': {
            'app_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'project_name': "Peanut Butter Cookie",
        }
    }
    test_no_input = False
    test_dict = prompt_for_config(test_context, no_input=test_no_input)
    target_dict = OrderedDict([('app_name', 'Peanut_Butter_Cookie')])
    assert(test_dict == target_dict)

# Generated at 2022-06-22 14:43:55.694504
# Unit test for function read_user_dict
def test_read_user_dict():
    from tempfile import NamedTemporaryFile
    from shutil import copy
    import os

    base_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(base_dir, 'test.txt')

    with open(test_file, 'w') as f:
        json.dump({'foo': 1}, f, indent=0)

    with NamedTemporaryFile('w', delete=False, suffix='.json') as prompt_file:
        copy(test_file, prompt_file.name)
        prompt_file.seek(0)

        with click.Context(read_user_dict) as ctx:
            click.Context.invoke(ctx, 'foo', prompt_file.name)


# Generated at 2022-06-22 14:43:58.680340
# Unit test for function render_variable
def test_render_variable():
    """Check if render_variable returns the appropriate value."""
    env = StrictEnvironment()
    cookiecutter_dict = {'project_name': 'Jelly Bean Cookie'}
    raw = '{{ cookiecutter.project_name.replace(" ", "_") }}'

    rendered_val = render_variable(env, raw, cookiecutter_dict)

    assert rendered_val == 'Jelly_Bean_Cookie'

# Generated at 2022-06-22 14:44:07.045753
# Unit test for function process_json
def test_process_json():
    json_string_good = '{"A": ["B", "C", "D"], "E": "F"}'
    json_string_bad = '{"A": ["B", "C", "D"] "E": "F"}'
    dict_good = process_json(json_string_good)
    dict_bad = process_json(json_string_bad)
    assert isinstance(dict_good, dict)
    assert isinstance(dict_bad, dict) == False

# Generated at 2022-06-22 14:44:10.063983
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    context = cookiecutter(".", no_input=True)
    assert len(context) == 13

    context = cookiecutter(".", no_input=False)
    assert len(context) == 13

# Generated at 2022-06-22 14:44:22.199506
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {}

# Generated at 2022-06-22 14:44:34.594167
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""
    def __dummy_read_user_variable(var_name, default_value):
        """Test function for read_user_variable."""
        return default_value

    def __dummy_read_user_dict(var_name, default_value):
        """Test function for read_user_dict."""
        return default_value

    def __dummy_read_user_choice(var_name, options):
        """Test function for read_user_choice."""
        return options[1]


# Generated at 2022-06-22 14:44:52.135928
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:44:58.075664
# Unit test for function read_user_dict
def test_read_user_dict():
    context = {
        "cookiecutter": {
            'dict_variable': {
                'key1': 'value1',
                'key2': 'value2',
            },
        },
    }
    expected_dict = {
        'key1': 'value1',
        'key2': 'value2',
    }
    actual_dict = prompt_for_config(context, no_input=True)
    print(actual_dict)
    assert expected_dict == actual_dict['dict_variable']

# Generated at 2022-06-22 14:45:02.548409
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test the function read_user_choice()."""
    var_name = "abcd"
    options = ["1", "2", "3"]
    assert read_user_choice(var_name, options) == "1"


# Generated at 2022-06-22 14:45:15.299075
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Test Project',
            'project_slug': 'test_project',
            'project_short_description': 'Test',
            'license': 'BSD-2-Clause',
            'author_name': 'Test User',
            'copyright_holder_name': 'Test User',
            'email': 'test@example.com',
            'url': 'https://example.com',
            'version': '0.0.1',
            'release': '0.0.1',
            'namespace': 'test.project',
            'is_pypi_project': False
        }
    }
    cookiecutter_dict = prompt_for_config(context, True)
    assert context == cookiecutter_dict

test_prompt_for

# Generated at 2022-06-22 14:45:23.074806
# Unit test for function read_user_choice
def test_read_user_choice():
    context = {'cookiecutter': {'test_choice': ['option1', 'option2', 'option3']}}
    env = {StrictEnvironment(context=context)}
    cookiecutter_dict = {OrderedDict([])}
    key = "test_choice"
    options = ['option1', 'option2', 'option3']
    no_input = False
    choice = prompt_choice_for_config(cookiecutter_dict, env, key, options, no_input)
    assert choice == 'option1'
    

# Generated at 2022-06-22 14:45:31.083373
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:45:43.869083
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    This is a unit test for the function `prompt_for_config` to cover the
    new prompt for dict-type variables.
    """
    # Create context dictionary
    context = {
        'cookiecutter': {
            'project_slug': '{{ cookiecutter.project_name.lower() }}.git',
            'project_name': 'My Project',
            'project_desc': 'The best project ever.',
            'author_name': 'Your name',
            'greeting': {},
            'pre_commit_config': '{}',
            'special_dict': {'a': 'b', 'c': 'd'},
            'special_list': ['a', 'b', 'c']
        }
    }

    # Prompt the user for input and create the cookiecutter_dict
    cookie

# Generated at 2022-06-22 14:45:48.876278
# Unit test for function read_user_dict
def test_read_user_dict():
    user_value = "{\"a\": \"b\"}"
    c = read_user_dict("a",{})
    assert c == {"a": "b"}
    user_value = "{\"a\": 1}"
    c = read_user_dict("a",{})
    assert c == {"a": "1"}



# Generated at 2022-06-22 14:45:59.875352
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config is working as expected"""

# Generated at 2022-06-22 14:46:10.220254
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    # first check that the regular prompt works
    context = cookiecutter('tests/fake-repo-pre/', no_input=False)
    assert isinstance(context['cookiecutter']['first_name'], str)
    assert isinstance(context['cookiecutter']['__private_first_name'], str)
    assert isinstance(context['cookiecutter']['_private_first_name'], str)

    # test the default case
    context = cookiecutter('tests/fake-repo-pre/', no_input=True)
    assert isinstance(context['cookiecutter']['first_name'], str)
    assert isinstance(context['cookiecutter']['__private_first_name'], str)

# Generated at 2022-06-22 14:46:18.902372
# Unit test for function read_user_choice
def test_read_user_choice():
    options = ['option-1', 'option-2']
    var_name = 'myVariable'
    response = read_user_choice(var_name, options)
    assert response in options

# Generated at 2022-06-22 14:46:26.412929
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""

# Generated at 2022-06-22 14:46:34.293263
# Unit test for function process_json
def test_process_json():
    """Test processing of string to json."""
    assert process_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert process_json('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert process_json('{"foo": {"baz": "qux"}}') == {'foo': {'baz': 'qux'}}



# Generated at 2022-06-22 14:46:36.737872
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'foo': 'bar',
            'baz': '{{ cookiecutter.foo }}',
        }
    }
    rendered_value = render_variable(StrictEnvironment(context=context), '{{ cookiecutter.baz }}', context['cookiecutter'])
    assert rendered_value == 'bar'

# Generated at 2022-06-22 14:46:40.728742
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for read_user_dict
    """
    result = read_user_dict('test_var', {'test': 'test'})
    assert result == {'test': 'test'}
    result = read_user_dict('test_var', {'test': 'test', 'test1': 'test1'})
    assert result == {'test': 'test', 'test1': 'test1'}

# Generated at 2022-06-22 14:46:51.442761
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:47:03.026249
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.environment import get_env

    # TODO: fix ContextError with context.

# Generated at 2022-06-22 14:47:13.309619
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config."""
    from cookiecutter.environment import StrictEnvironment

    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter',
            'project_slug': 'cookiecutter',
            'default_context': {'repo_name': 'cookiecutter-{{ cookiecutter.project_slug }}'}
        }
    }

    env = StrictEnvironment(context=context)
    config = {}

    cookiecutter_dict = [config, env]

    context['cookiecutter']['project_name'] = '{{ cookiecutter.project_slug }}'
    config = prompt_for_config(context, no_input=False)
    assert config['project_name'] == 'cookiecutter'

# Generated at 2022-06-22 14:47:20.315697
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import os
    from .main import cookiecutter

    context = cookiecutter('.', no_input=True)
    assert context['project_name'] == 'Cookiecutter Cookiecutter'
    assert context['project_slug'] == 'cookiecutter-cookiecutter'
    assert context['repo_name'] == 'cookiecutter-cookiecutter'
    assert context['repo_description'] == 'A short description of the project.'
    assert context['author_name'] == 'Audrey Roy Greenfeld'
    assert context['email'] == 'audreyr@example.com'
    assert context['version'] == '0.1.0'
    assert context['year'] == '2014'
    assert context['release'] == context['version']
    assert context['license'] == 'BSD'


# Generated at 2022-06-22 14:47:24.085975
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = get_default_context()
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict['cookiecutter']['repo_name'] == 'cookiecutter-peanut-butter'

# Generated at 2022-06-22 14:47:35.041799
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test if the function returns the correct result without crashing.
    """
    try:
        prompt_for_config({'cookiecutter':{'key':'value'}})
    except Exception:
        assert False
    assert True

# Generated at 2022-06-22 14:47:44.503389
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Test variables
    context = {}
    context['cookiecutter'] = {'project_name': 'A test project',
                               'project_slug': 'test_project',
                               'github_username': 'A test user',
                               'js_module_name': 'test_module',
                               'js_module_format': 'iife',
                               'documentation_url': 'test_url',
                               'project_short_description': 'A test project for testing',
                               'css_extension': 'scss',
                               'use_postcss': 'no',
                               'use_pug':'no',
                               'boolean_value': True}

    # Test functions
    val = prompt_for_config(context, no_input=True)
    assert val is not None

    # Test exceptions

# Generated at 2022-06-22 14:47:52.347635
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    context = {
        'cookiecutter': {'repo_name': '{{ cookiecutter.project_name }}'},
        'project_name': 'peanut butter cookie',
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['repo_name'] == 'peanut butter cookie'

    # Also asserts that the repo_name does not contain jinja2 syntax
    assert not cookiecutter_dict['repo_name'].startswith('{{')
    assert not cookiecutter_dict['repo_name'].endswith('}}')


if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-22 14:48:03.170451
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Smoke test
    assert prompt_for_config({}) == OrderedDict([])

    # No variables
    context = {'cookiecutter': {'random': 'default_value'}}
    expected = OrderedDict([('random', 'default_value')])
    assert prompt_for_config(context) == expected

    # Override default variable value
    context = {'cookiecutter': {'random': 'default_value'}}
    expected = OrderedDict([('random', 'new_value')])
    assert prompt_for_config(context, no_input=True) == expected

    # Prompt for choice of 3 + default
    context = {'cookiecutter': {'random': ['optionA', 'optionB', 'optionC']}}
    expected = OrderedDict([('random', 'optionA')])

# Generated at 2022-06-22 14:48:14.461367
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'platform'
    default_value = {}
    click.confirm = lambda x, y: True
    click.prompt = lambda x, y, z: '[{"name": "iOS", "publisher": "Apple", "price": "Free"}, {"name": "Android", "publisher": "Google", "price": "Free"}]'
    expected_result = [{"name": "iOS", "publisher": "Apple", "price": "Free"}, {"name": "Android", "publisher": "Google", "price": "Free"}]

    result = read_user_dict(var_name, default_value)

    assert result == expected_result



# Generated at 2022-06-22 14:48:25.488383
# Unit test for function render_variable
def test_render_variable():
    from jinja2.loaders import DictLoader
    from cookiecutter.utils import merge_dict

    tpl = {
        'cookiecutter': {
            'repo_name': '{{cookiecutter.project_name}}',
            'output_dir': '{{cookiecutter.repo_name}}',
            'Package': '{{cookiecutter.repo_name|lower}}',
        },
    }
    ctx = {
        'cookiecutter': {
            'project_name': 'Test Project',
        },
    }
    env = StrictEnvironment(
        loader=DictLoader(merge_dict(ctx, tpl)),
        context=ctx,
    )
    cookiecutter_dict = prompt_for_config(ctx, no_input=True)
    rendered_variable = ''

   

# Generated at 2022-06-22 14:48:37.234644
# Unit test for function render_variable
def test_render_variable():
    # Test render_variable function:
    # render a variable from an existing variable
    from cookiecutter.environment import StrictEnvironment
    from click.testing import CliRunner
    from .main import cli
    env = StrictEnvironment()

    cookiecutter_dict = {'project_name': 'Peanut Butter Cookie'}
    value = "`{{ cookiecutter.project_name.replace(' ', '_') }}`"

    rendered_template = render_variable(env, value, cookiecutter_dict)

    assert rendered_template == "`Peanut_Butter_Cookie`"

    # Test render_variable function:
    # render a variable from an existing list variable
    cookiecutter_dict = {'repo_name': ['abc', 'def', 'ghi']}

# Generated at 2022-06-22 14:48:42.732264
# Unit test for function read_user_dict
def test_read_user_dict():
    """test for read_user_dict read_user_dict(var_name, default_value)"""
    # test with empty string such as how the input from user is read into this function
    assert read_user_dict("test", {"test1": "test2"}) == {"test1": "test2"}
    # test with sample json string
    assert read_user_dict("test", {"test1": "test2"}) == {"test1": "test2"}

# Generated at 2022-06-22 14:48:50.262839
# Unit test for function process_json
def test_process_json():
    sample_json_correct = '{"foo": "bar", "baz": {"q": "b"}, "x": "y"}'
    sample_json_incorrect1 = '{"foo: "bar", "baz": {"q": "b"}, "x": "y"}'
    sample_json_incorrect2 = '{"foo": "bar", "baz": {"q": "b"}} "x": "y"}'
    sample_json_incorrect3 = '{"foo": "bar", "baz": {"q": "b"}, "x": "y"} 123'

    sample_dict = {'foo': 'bar', 'baz': {'q': 'b'}, 'x': 'y'}

    # Positive case: Correct JSON input
    assert process_json(sample_json_correct) == sample_dict

    # Negative case 1

# Generated at 2022-06-22 14:48:56.712205
# Unit test for function process_json
def test_process_json():
    result = process_json('{"a":1, "b": 2}')
    assert result['a'] == 1
    assert result['b'] == 2
    assert result == OrderedDict([('a', 1), ('b', 2)])

    with pytest.raises(click.UsageError):
        process_json('{"a":1, "b": x')

    with pytest.raises(click.UsageError):
        process_json(1)

# Generated at 2022-06-22 14:49:18.462189
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {"cookiecutter": {"cookie_name": "cookie_value"}}
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    assert cookiecutter_dict['cookie_name'] == "cookie_value"

# Generated at 2022-06-22 14:49:28.712692
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Testing prompt_for_config"""

# Generated at 2022-06-22 14:49:38.777682
# Unit test for function read_user_choice
def test_read_user_choice():
    # Test assertion when options are not list
    try:
        read_user_choice("test", "test")
        raise
    except TypeError:
        pass
    # Test assertion when no options are given
    try:
        read_user_choice("test", [])
        raise
    except ValueError:
        pass
    # Test that first item is returned with no input (mocked)
    assert read_user_choice("test", ["test"]) == "test"
    assert read_user_choice("test", ["test1", "test2"]) == "test1"
    assert read_user_choice("test", ["test1", "test2", "test3"]) == "test1"

# Generated at 2022-06-22 14:49:45.939898
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "test_var"
    default_value = {
        "key1": "value1",
        "key2": "value2"
    }
    expected_value = {
        "key1": "value1_updated",
        "key2": "value2_updated"
    }
    # Test case when the user does not provide an input
    # and the default value should be returned without any modification
    user_value = ""
    user_dict = read_user_dict(var_name, default_value)
    assert user_dict == default_value
    # Test case when the user provides an input
    # and it should be returned as a Python dictionary
    user_value = '{"key1":"value1_updated","key2":"value2_updated"}'

# Generated at 2022-06-22 14:49:57.353640
# Unit test for function read_user_dict
def test_read_user_dict():
    from click.testing import CliRunner
    import json

    v = {'this': 'that'}

    def internal_test(user_value, is_json, expected_result):
        print(user_value, is_json, expected_result)
        runner = CliRunner()
        result = runner.invoke(
            read_user_dict, ['this', v], input='{}\n'.format(user_value)
        )
        if is_json:
            assert json.loads(result.output[:-1]) == expected_result
        else:
            assert result.output[:-1] == expected_result

    internal_test('default', False, v)
    internal_test('{"this": "that"}', True, v)
    internal_test('{"this": "that"}', True, v)

# Generated at 2022-06-22 14:50:09.050830
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:15.863917
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    # Retrieve the context of the test project
    context = cookiecutter('tests/fake-repo-pre/', no_input=True)

    # Render the context
    result = prompt_for_config(context, no_input=False)

    # Expected results for the test render

# Generated at 2022-06-22 14:50:27.806812
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:38.017494
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "whatever"
    default_value = {"a_key": "a_value"}
    # only the default value is accepted (case insensitive)
    user_value = click.prompt(
        var_name, default="default", type=click.STRING, value_proc=process_json
    )
    assert user_value == default_value

    # valid json is accepted
    user_value = click.prompt(
        var_name, default="default", type=click.STRING, value_proc=process_json
    )
    assert user_value == default_value

    # valid json is accepted
    user_value = click.prompt(
        var_name, default="{\"a_key\":\"a_value\"}", type=click.STRING, value_proc=process_json
    )

# Generated at 2022-06-22 14:50:50.786107
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test that prompt_for_config works correctly."""
    context = {
        'cookiecutter': {
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'project_name': 'CamelCase',
            'include_repo_in_package': [
                {'name': 'CamelCase', 'value': 'false'},
                {'name': 'camel_case', 'value': 'true'},
            ],
        },
    }
    cookiecutter_dict = prompt_for_config(context=context, no_input=False)
    assert cookiecutter_dict == {
        'repo_name': 'CamelCase',
        'project_name': 'CamelCase',
        'include_repo_in_package': 'false',
    }

# Generated at 2022-06-22 14:51:09.197442
# Unit test for function read_user_choice
def test_read_user_choice():
    """
    unit test for function read_user_choice
    """
    from cookiecutter.prompt.prompt_utils import read_user_choice
    options = ['Python', 'Django', 'Flask']
    choice = read_user_choice('select', options)
    print(choice)

# Generated at 2022-06-22 14:51:17.343574
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test for function prompt_for_config."""

# Generated at 2022-06-22 14:51:27.750437
# Unit test for function read_user_dict
def test_read_user_dict():
    from .main import (
        get_context_from_dict,
        prompt_for_config
    )
    context = get_context_from_dict({'cookiecutter': {'test1': {'foo': 'bar'}, 'test2': 'bar', 'test3': [1,2]}, '_copy_without_render': []})
    cookiecutter_dict = prompt_for_config(context)
    assert (cookiecutter_dict['test1'] == {'foo': 'bar'})
    assert (isinstance(cookiecutter_dict['test1'], dict))
    assert (cookiecutter_dict['test2'] == 'bar')
    assert (cookiecutter_dict['test3'] == [1,2])



# Generated at 2022-06-22 14:51:32.692085
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from tests.test_commands.test_create_project.test_prompts import (
        CC_PYPROJECT_TOML,
        CC_PYPROJECT_TOML_WITH_UNDEFINED,
        CC_PYPROJECT_TOML_WITH_UNDEFINED_IN_SEQUENCE,
        CC_PYPROJECT_TOML_WITH_UNDEFINED_IN_DICT,
        CC_PYPROJECT_TOML_WITH_UNDEFINED_IN_LIST,
        CC_PYPROJECT_TOML_WITH_UNDEFINED_IN_TEMPLATE,
        CC_PYPROJECT_TOML_WITH_UNDEFINED_IN_TEMPLATE_WITH_CHOICES,
    )

# Generated at 2022-06-22 14:51:42.226378
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = dict()
    # context['_copy_without_render'] = ['test']

    cookiecutter_dict = dict()
    cookiecutter_dict['test'] = 'test'

    env = StrictEnvironment(context=context)

    assert cookiecutter_dict == prompt_for_config(context)

    cookiecutter_dict['test'] = 'test'
    assert cookiecutter_dict == {'test': 'test'}

    cookiecutter_dict['test'] = 'test'
    assert render_variable(env, cookiecutter_dict['test'], cookiecutter_dict) == 'test'

# Generated at 2022-06-22 14:51:52.632112
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'package_name': 'sampledata',
            'project_name': '{{ cookiecutter.package_name.title() }}',
            'version': '0.1.0',
            'author_name': 'Firstname Lastname',
            'email': 'firstname.lastname@example.com',
            'description': 'A short description of the project.',
            'domain_name': 'example.com',
            'timezone': 'UTC',
            'use_whitenoise': 'y',
            'use_celery': 'n',
            'use_mailhog': 'n',
            'use_sentry': 'n',
            'use_docker': 'n',
            'debug': 'n',
        }
    }


# Generated at 2022-06-22 14:52:05.331945
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    # Test for a simple variable
    result = cookiecutter('tests/test-cookiecutters/demo-reload-prompts')
    assert result['project_name'] == 'Project Name'

    # Test for a more complex variable
    result = cookiecutter('tests/test-cookiecutters/demo-reload-prompts')
    assert result['project_slug'] == 'project_name'

    # Test that the user can override a variable
    result = cookiecutter(
        'tests/test-cookiecutters/demo-reload-prompts',
        no_input=True,
        extra_context={'project_name': 'New Project'}
    )
    assert result['project_name'] == 'New Project'


# Generated at 2022-06-22 14:52:11.118359
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:20.861119
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 14:52:32.313852
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    # Unit test data

# Generated at 2022-06-22 14:52:50.211699
# Unit test for function prompt_for_config
def test_prompt_for_config(): 
    assert 1 == 1

# Generated at 2022-06-22 14:52:59.436842
# Unit test for function process_json

# Generated at 2022-06-22 14:53:08.330538
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'filename'
    default_value = {'like this': ['item1', 'item2'], 'or this': ['item1', 'item2']}
    
    try: 
        read_user_dict(var_name, default_value)
    except TypeError:
        assert True
    else:
        assert False
    
    try:
        read_user_dict(var_name, {})
    except ValueError:
        assert True
    else:
        assert False
        
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, default_value) != {}
    assert read_user_dict(var_name, default_value) is not default_value
    
test_read_user_dict()
# Unit test