

# Generated at 2022-06-22 14:43:26.207265
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:43:34.138647
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import prompt_and_generate

    context = DEFAULT_CONFIG

# Generated at 2022-06-22 14:43:46.591359
# Unit test for function prompt_for_config
def test_prompt_for_config():
    c = {
        "cookiecutter": {
            "full_name": "First Last",
            "email": "first.last@email.com",
        }
    }
    d = prompt_for_config(c, no_input=True)
    assert d["full_name"] == "First Last"
    assert d["email"] == "first.last@email.com"

    choices = ["val1", "val2"]
    c = {
        "cookiecutter": {
            "var": choices,
        }
    }
    d = prompt_for_config(c, no_input=True)
    assert d["var"] == "val1"

    dict_var = {"key": "val"}

# Generated at 2022-06-22 14:43:58.685620
# Unit test for function read_user_choice
def test_read_user_choice():
    choice_map = OrderedDict(
        ('{}'.format(i), value) for i, value in enumerate(['foo', 'bar'], 1)
    )
    choices = choice_map.keys()
    default = '1'
    choice_lines = ['{} - {}'.format(*c) for c in choice_map.items()]
    prompt = '\n'.join(
        (
            'Select something:',
            '\n'.join(choice_lines),
            'Choose from {}'.format(', '.join(choices)),
        )
    )
    user_choice = '1'
    assert read_user_choice('something', ['foo', 'bar']) == 'foo'
    assert read_user_choice('something', ['foo', 'bar'], no_input=True) == 'foo'


# Generated at 2022-06-22 14:44:05.313911
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test'
    default_value = {'test': 'value'}
    user_value = read_user_dict(var_name, default_value)
    assert user_value == default_value


if __name__ == '__main__':
    test_read_user_dict()

# Generated at 2022-06-22 14:44:11.836574
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('var_name', {'x':'y'}) == {'x': 'y'}
    assert read_user_dict('var_name', {'a':'b'}) == {'a': 'b'}
    assert read_user_dict('var_name', {'c':'d'}) == {'c': 'd'}
    assert read_user_dict('var_name', {'e':'f'}) == {'e': 'f'}
    assert read_user_dict('var_name', {'g':'h'}) == {'g': 'h'}

# Generated at 2022-06-22 14:44:21.393284
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test that prompt_for_config is returning the correct set of variables. """

    foo = 'foo'
    bar = 'bar'
    baz = 'baz'
    context = {
        'cookiecutter': {
            '_hidden': {
                'foo': foo,
                'bar': bar,
            },
            'baz': baz,
        }
    }

    result = prompt_for_config(context)

    assert result == {
        '_hidden': {
            'foo': foo,
            'bar': bar,
        },
        'baz': baz,
    }

# Generated at 2022-06-22 14:44:33.737626
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for prompt_for_config.

    This is a full-coverage test to ensure that every branch and edge case is
    handled.
    """
    from cookiecutter.prompt import _load

    # This is the most comprehensive example context that is used.
    # Most tests are done with a subset of the keys.
    full_context_path = 'tests/test-render/context.yaml'
    full_context = _load(full_context_path)
    # The subset of the full context used for most of the tests.
    context = full_context['cookiecutter'].copy()
    # The subset of the full context used for the list/dict tests.
    longlist_context = _load('tests/test-render/context.longlist.yaml')['cookiecutter']
    # The subset of the full context used

# Generated at 2022-06-22 14:44:41.355941
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    # Create a temporary project from a local template.
    # We don't want to use the standard test for this, because
    # it is not possible to modify the context of the standard
    # project.
    context = cookiecutter('.', no_input=True)

    # Add some prompt_type: string
    context['cookiecutter'].update(
        {
            'project_name': 'My project',
            'project_slug': 'my_project',
            'project_description': 'My new package',
            'author_name': 'John Doe',
        }
    )

    # Add some prompt_type: choice

# Generated at 2022-06-22 14:44:47.826942
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict"""
    default_value = {"foo": "bar"}
    no_input_result = read_user_dict("", default_value)
    assert(no_input_result == default_value)
    user_input_result = read_user_dict("", default_value)
    assert(user_input_result == default_value)



# Generated at 2022-06-22 14:45:00.440477
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'namespace': '',
            'namespace_slashes': '{{ cookiecutter.namespace.replace(".", "/") }}',
            'github_namespace': '{{ cookiecutter.github_username }}'
        }
    }

    env = StrictEnvironment(context=context)


# Generated at 2022-06-22 14:45:05.693196
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {}}
    context['cookiecutter']['full_name'] = 'Alex Gaynor'
    context['cookiecutter']['email'] = 'alex.gaynor@gmail.com'
    context['cookiecutter']['github_username'] = 'alex'
    context['cookiecutter']['project_name'] = 'Cookiecutter'
    context['cookiecutter']['repo_name'] = '{{ cookiecutter.project_name.lower().replace(" ", "-") }}'
    context['cookiecutter']['pypi_username'] = '{{ cookiecutter.github_username }}'
    context['cookiecutter']['description'] = 'A command-line utility that creates projects from project templates.'

# Generated at 2022-06-22 14:45:18.269919
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Test with a regular variable
    context = {'cookiecutter': {'test_var': 'test_value', 'test_list': ['a', 'b', 'c']}}
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['test_var'] == 'test_value'
    assert len(cookiecutter_dict) == 2

    # Test with a dictionary variable
    context = {'cookiecutter': {'test_dict': {'key': 'value'}}}
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['test_dict'] == {'key': 'value'}

    # Test with a Dict of Dicts

# Generated at 2022-06-22 14:45:26.879104
# Unit test for function render_variable
def test_render_variable():
    #test without when variable is not in context
    context = {'cookiecutter': {'test':'{{ cookiecutter.test_var }}'}}
    env = StrictEnvironment(context=context)
    cookiecutter_dict = OrderedDict([])
    assert render_variable(env, context['cookiecutter']['test'], cookiecutter_dict) is None
    #test when variable is in context
    context['cookiecutter']['test_var'] = 'This is a test'
    assert render_variable(env, context['cookiecutter']['test'], cookiecutter_dict) == context['cookiecutter']['test_var']


# Generated at 2022-06-22 14:45:32.806571
# Unit test for function prompt_for_config
def test_prompt_for_config():
	context = {
		'cookiecutter': {
			'name': 'Audrey Roy',
			'email': 'audreyr@example.com',
			'github_username': 'audreyr',
			'project_name': '{{ cookiecutter.github_username|upper }}',
			'_copy_without_render': [
				'LICENSE',
			],
		}
	}

	cookiecutter_dict = prompt_for_config(context, no_input=True)

	assert isinstance(cookiecutter_dict, dict)
	assert set(cookiecutter_dict.keys()) == {'name', 'email', 'github_username', 'project_name', '_copy_without_render'}

# Generated at 2022-06-22 14:45:44.888298
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import os
    cwd = os.getcwd()
    os.chdir('./tests/files/fake-repo-pre/')
    context = {}

# Generated at 2022-06-22 14:45:52.049755
# Unit test for function read_user_dict
def test_read_user_dict():
    x = read_user_dict("dict_var", {'a':1, 'b':2})

    # assert if input is not a dict
    try:
        x = read_user_dict("dict_var", 1)
        assert False
    except TypeError:
        assert True

    # assert if input is not a dict with keys of type string
    try:
        x = read_user_dict("dict_var", {1:1, 2:2})
        assert False
    except TypeError:
        assert True

    # assert if input is not a dict with keys of type string
    try:
        x = read_user_dict("dict_var", {'a':1, 2:2})
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-22 14:45:55.635831
# Unit test for function read_user_dict
def test_read_user_dict():
    input_dict = {"var_name": "cool", "default_value": {}}
    out_dict = read_user_dict(input_dict["var_name"], input_dict["default_value"])
    assert isinstance(out_dict, dict)

# Generated at 2022-06-22 14:46:03.905822
# Unit test for function process_json
def test_process_json():
    for test_str in [
            "[\"Test 1\", \"Test 2\"]",
            """
            {
                "test1": "test1",
                "test2": "test2"
            }
            """,
            "{\"test\": [\"test1\", \"test2\"]}",
            "{\"test\": {\"test1\": \"test1\", \"test2\": \"test2\"}}",
            "{\"test\": [\"test1\", {\"test2\": \"test2\"}]}",
            "{\"test\": [\"test1\", [\"test2\", {\"test3\":[\"test4\"]}]]}",
    ]:
        print(f"Testing for string: {test_str}")
        print(process_json(test_str))
        print()

# Generated at 2022-06-22 14:46:09.306942
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for function read_user_dict"""
    variable_test_dict = {'test_dict': {'test_key': 'test_value'}}
    assert read_user_dict('test_dict', variable_test_dict['test_dict']) == variable_test_dict['test_dict']
    variable_test_dict['test_dict'] = {'test_key': 'new_value'}
    assert read_user_dict('test_dict', variable_test_dict['test_dict']) == variable_test_dict['test_dict']

# Generated at 2022-06-22 14:46:17.773830
# Unit test for function read_user_choice
def test_read_user_choice():
    """Testing the function to read user choice."""
    options = ['foo', 'bar']
    assert read_user_choice('test', options) == 'foo'

# Generated at 2022-06-22 14:46:25.549095
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Prompt user to enter a new config."""

# Generated at 2022-06-22 14:46:29.844510
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""
    # Test case data

# Generated at 2022-06-22 14:46:39.545673
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:46:47.629718
# Unit test for function render_variable
def test_render_variable():
    env = StrictEnvironment()
    cookiecutter_dict = {'var': 'test', 'var2': 'test2'}
    assert render_variable(env, '{{ cookiecutter.var }}', cookiecutter_dict) == 'test'
    assert render_variable(env, '{{ cookiecutter.var2 }}', cookiecutter_dict) == 'test2'
    assert render_variable(env, '{{ cookiecutter.var }}{{ cookiecutter.var2 }}',
                           cookiecutter_dict) == 'testtest2'



# Generated at 2022-06-22 14:46:52.256829
# Unit test for function process_json
def test_process_json():
    json_string = '[{"a":"b", "c":"d"}, {"e":"f", "g":"h"}]'
    assert process_json(json_string) == [{"a":"b", "c":"d"}, {"e":"f", "g":"h"}]

    json_string = '{"a": "b", "c": "d"}'
    assert process_json(json_string) == {"a": "b", "c": "d"}


# Generated at 2022-06-22 14:47:03.680129
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'full_name': "Paul Müller",
            'email': "paul.mueller@web.de",
            'github_username': "paulmueller",
            'project_name': "Awesome project",
            'project_slug': "awesome_project",
            'project_license': "MIT",
            'version': "0.1.0",
            'project_short_description': "An awesome project.",
            'pypi_username': "pypi_username",
            'select_type': ["one", "two", "three"]
        }
    }
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict['full_name'] == "Paul Müller"

# Generated at 2022-06-22 14:47:13.762335
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    # This sample context is a simplified version of the
    # "cookiecutter.json" file in own template:
    # https://github.com/ionelmc/cookiecutter-pylibrary/blob/master/%7B%7Bcookiecutter.repo_name%7D%7D/cookiecutter.json

# Generated at 2022-06-22 14:47:20.032982
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['project_name'] = '{{cookiecutter.repo_name}}'
    context['cookiecutter']['repo_name'] = 'testing'

    val = prompt_for_config(context, True)

    assert val['project_name'] == 'testing'

# Generated at 2022-06-22 14:47:29.685945
# Unit test for function prompt_for_config
def test_prompt_for_config():

  class MockContext(object):
    def __init__(self, data):
      self.obj = data

    def __getattr__(self, name):
      try:
        return self.obj[name]
      except KeyError:
        raise AttributeError

    def __getitem__(self, key):
      return self.obj[key]

  from collections import OrderedDict

  """ Processes a config file and prompts the user to enter a new one. """

# Generated at 2022-06-22 14:47:48.908446
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Silly test for prompt_for_config. No mocking for now."""
    c = {
        'cookiecutter': {
            'foo': '123',
            'bar': 'abc',
            '_dict_key': {'value': 'foobar'},
            '__dict_key_force': {'value': 'foobar'},
            '_list_key': [
                {'value': 'first'},
                {'value': 'second'},
                {'value': 'third'},
            ],
        }
    }
    cookie_dict = prompt_for_config(c)
    assert cookie_dict['foo'] == '123'
    assert cookie_dict['bar'] == 'abc'
    assert cookie_dict['_dict_key'] == {'value': 'foobar'}
    assert cookie_dict

# Generated at 2022-06-22 14:47:55.759486
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "person"
    default_value = {
        "name": "Jim",
        "age": "52"
    }

    dict_value = read_user_dict(var_name, default_value)
    assert(dict_value == default_value)



# Generated at 2022-06-22 14:48:04.640817
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter Demo Project',
            'project_slug': 'cookiecutter-demo-project',
            'project_short_description': 'One line description of the project.',
            'pypi_username': 'audreyr',
            'open_source_license': 'MIT license',
            'author_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'test_command': 'pytest'
        }
    }


# Generated at 2022-06-22 14:48:17.243383
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:48:27.586395
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test the read user dict process"""
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.prompt import _prepare_default_value

    # Please see https://click.palletsprojects.com/en/7.x/api/#click.prompt

    # Test the default value
    assert read_user_dict("var_name", {}) == {}

    # Test user input
    with mock.patch(
        'click.prompt', return_value=json.dumps({"print": ["lpr", "LP"]})
    ):
        assert read_user_dict("var_name", {}) == {"print": ["lpr", "LP"]}

    # Test user input in wrong format

# Generated at 2022-06-22 14:48:40.180981
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import os, copy
    from cookiecutter.main import cookiecutter
    context = cookiecutter("tests/test-cookiecutter-repo/")
    assert context

    config_filepath = os.path.join("tests/test-cookiecutter-repo/", "cookiecutter.json")
    config_file = open(config_filepath, 'r')
    json_parsed = json.load(config_file, object_pairs_hook=OrderedDict)

    # Test function with json_parsed
    test_context = {"cookiecutter": json_parsed, "project_name": context["project_name"]}

    user_context = prompt_for_config(test_context, True)
    assert user_context
    user_context.pop("cookiecutter")

# Generated at 2022-06-22 14:48:46.178802
# Unit test for function render_variable
def test_render_variable():
    """Unit test for function render_variable."""
    raw = '{{ cookiecutter.repo_name.replace(" ", "_") }}'
    cookiecutter_dict = {'repo_name': 'peanut butter'}
    # the function returned an unexpected result
    assert (
        render_variable(StrictEnvironment(context={'repo_name': 'peanut butter'}), raw, cookiecutter_dict)
        == 'peanut_butter'
    )

# Generated at 2022-06-22 14:48:57.476546
# Unit test for function render_variable
def test_render_variable():
    """Validate that render_variable function works correctly."""

    # Set up a minimal jinja environment to render our cookiecutter variables
    context = {}
    env = StrictEnvironment(context=context)

    # We need a cookiecutter dict to pass to render_variable, but it will
    # be updated in place below
    cookiecutter_dict = OrderedDict([])

    # Test render variable without variable in template
    raw = 'Hello'
    rendered_raw = render_variable(env, raw, cookiecutter_dict)
    assert rendered_raw == 'Hello'

    # Add a variable named 'project_name' to cookiecutter_dict, and test
    # the value of that variable by rendering 'raw'.
    raw = '{{ cookiecutter.project_name }}'

# Generated at 2022-06-22 14:49:07.551501
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            '_copy_without_render': ["foo/"],
            'project_name': '{{ cookiecutter.project_name.upper() }}',
            'project_slug': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'author_name': '{{ cookiecutter.author_name.upper() }}',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == '{{ cookiecutter.project_name.upper() }}'

# Generated at 2022-06-22 14:49:18.375871
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from .prompts import prompt_for_config

    from .main import find_template

    template_dir = find_template("example-cookiecutter-pypackage", True)
    with open("{}/cookiecutter.json".format(template_dir)) as template_file:
        template_data = json.load(template_file, object_pairs_hook=OrderedDict)

    context = {"cookiecutter": template_data}
    cookiecutter_dict = prompt_for_config(context, no_input=False)

    print("\nContext...")
    for k, v in cookiecutter_dict.items():
        print("{}: {}".format(k, v))

# Generated at 2022-06-22 14:49:32.565052
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'project_name': 'Hello world',
            'names': {
                'first': 'James',
                'last': 'Hetfield',
            },
            'table': [
                {'model': 'model 1', 'price': '$100',},
                {'model': 'model 2', 'price': '$200',},
            ],
            '__description': '{{ cookiecutter.project_name }}',
            'contact': '{{ cookiecutter["names"]["first"] }} {{ cookiecutter["names"]["last"] }}',
        }
    }
    result = render_variable(StrictEnvironment(context=context),
                             '{{ cookiecutter.__description }}',
                             context['cookiecutter'])
    assert result == 'Hello world'

   

# Generated at 2022-06-22 14:49:42.639168
# Unit test for function process_json
def test_process_json():
    assert process_json({"dict": "value"}) == {"dict": "value"}
    assert process_json('{"dict": "value"}') == {"dict": "value"}
    assert process_json(1) == 1
    assert process_json('1') == '1'
    assert process_json('"1"') == '"1"'
    assert process_json(True) == True
    assert process_json('true') == True
    assert process_json(False) == False
    assert process_json('False') == False
    import numpy as np

    x = np.array([0, 1, 2])
    assert x == process_json(json.dumps(x.tolist()))
    assert x == process_json(json.dumps(x))
    assert process_json('"aa"') == '"aa"'

# Generated at 2022-06-22 14:49:55.065034
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Test',
            'project_slug': 'test',
            'project_dir': "{{ cookiecutter.project_slug }}",
            'project_type': 'Regular Package',
            'author_name': 'Your Name',
            'package_name': "{{ cookiecutter.project_slug }}",
            'github_username': "{{ cookiecutter.author_name.lower().replace(' ', '') }}",
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == 'Test'
    assert cookiecutter_dict['project_slug'] == 'test'
    assert cookiecutter_dict['project_dir'] == 'test'

# Generated at 2022-06-22 14:50:06.693492
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test for the functions prompt_for_config and render_variable."""

# Generated at 2022-06-22 14:50:18.687773
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:31.041383
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:39.655316
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config.

    Create a dict with a few variables, run the function and test if
    the output from the function is the same as the input.
    """

# Generated at 2022-06-22 14:50:46.714020
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    Test for function read_user_dict
    """
    test_dict = {"key1": "value1"}
    x = read_user_dict("test", test_dict)
    assert x == {"key1": "value1"}

    test_dict = {1: "value1"}
    x = read_user_dict("test", test_dict)
    assert x == {"1": "value1"}



# Generated at 2022-06-22 14:50:54.458193
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from contextlib import redirect_stdout
    from io import StringIO
    from click.testing import CliRunner

    # Mock the cookiecutter json file for testing:
    config = {
        "cookiecutter": {
            "test_dict_key": {"test_variable": "test_value"},
            "test_regular_variable": "test_default_value",
            "test_choice_variable": ["test_option1", "test_option2"],
            "test_yes_or_no": True,
            "test_private_variable": "test_private_value"
        }
    }

    # Mock the click prompt function to return "test_value" or "test_option2"
    # as expected:

# Generated at 2022-06-22 14:51:03.956582
# Unit test for function render_variable
def test_render_variable():
    from cookiecutter.main import cookiecutter

    # Create a context for the test
    context = cookiecutter('tests/fake-repo-tmpl/')

    # Set some values
    context['cookiecutter']['project_name'] = 'Neo'
    context['cookiecutter']['repo_name'] = '{{ cookiecutter.project_name }}'

    # Render the variable
    rendered_variable = render_variable(
        StrictEnvironment(context=context),
        context['cookiecutter']['repo_name'],
        context['cookiecutter']
    )

    # Check that the template was rendered properly
    assert rendered_variable == 'Neo'

# Generated at 2022-06-22 14:51:18.728406
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test to see that we get a default value, and a non-default value
    # back when running the function read_user_dict
    # This test includes handling the case where an exception is raised
    class CatchUsageError():
        def __init__(self, errormsg):
            self.errormsg = errormsg

    try:
        read_user_dict(
            "Please enter a default value", default_value={"key": "value"}
        )
        default_value = True
    except click.UsageError:
        default_value = False
    assert default_value

    try:
        read_user_dict(
            "Please enter a non-default value", default_value={"key": "value"}
        )
        default_value = False
    except click.UsageError:
        default_value = True

# Generated at 2022-06-22 14:51:29.512446
# Unit test for function read_user_dict
def test_read_user_dict():
    """
    Test function: read_user_dict
    """
    default_value = {"key1": "value1", "key2": ["value21", "value22"]}
    var_name = "Variable name"

    # Testcase #1 - valid input
    user_value = '''{"key1" : "value1", "key2" : ["value21", "value22"]}'''
    returned_value = read_user_dict(var_name, default_value)
    assert user_value == json.dumps(returned_value)

    # Testcase #2 - invalid input
    user_value = "invalid json"

# Generated at 2022-06-22 14:51:41.094517
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Define dictionary of default values
    dict = {
        "project_name": "My Project",
        "repo_name": "{{cookiecutter.project_name.replace(' ','_')}}",
        "package_name": "{{cookiecutter.repo_name.lower()}}",
        "description": "A short description of the project.",
        "version": "0.1.0",
        "author_name": "Your Name",
        "author_email": "your@email.com",
        "github_username": "your-github-username",
        "release_date": "",
        "year": "",
        "include_tox": False,
        "select_linter": "yapf"
    }
    context = {'cookiecutter': dict}
    cookiecutter_dict = prompt

# Generated at 2022-06-22 14:51:41.784924
# Unit test for function prompt_for_config
def test_prompt_for_config():
    pass

# Generated at 2022-06-22 14:51:52.264604
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from pathlib import Path
    from .samples import cookiecutters_abspath
    # This works only for samples with a single option for the choice variable.
    project_dir_tests = ('sample-app-jinja',)
    for test in project_dir_tests:
        project_dir = cookiecutter(str(cookiecutters_abspath/test),no_input=True)
        with open(project_dir['cookiecutter']['json_config'], 'r') as f:
            context = json.load(f)
        cookiecutter_dict = prompt_for_config(context, no_input=False)
        assert isinstance(cookiecutter_dict, dict)
        Path(project_dir['project_dir']).rmdir()

# Generated at 2022-06-22 14:52:04.271705
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('android', {'yes': 'Yes'}) == {'yes': 'Yes'}
    assert read_user_dict('android', {'no': 'No'}) == {'no': 'No'}
    assert read_user_dict('android', {'yes': 'Yes', 'no': 'No'}) != {'yes':'Yes', 'no':'No'}
    assert read_user_dict('android', {'yes': 'Yes', 'no': 'No'}) != {'yes': 'No', 'no': 'Yes'}
    assert read_user_dict('android', {'yes': 'Yes', 'no': 'No'}) == {'yes': 'Yes', 'no': 'No'}

# Generated at 2022-06-22 14:52:10.739142
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:19.903365
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'Your email',
            'project_name': 'Your Project',
            'project_slug': {"default": "{{ cookiecutter.project_name.lower().replace(' ', '_') }}"}
        }
    }
    cookie_dict = prompt_for_config(context, no_input=True)
    assert cookie_dict['full_name'] == 'Your Name'
    assert cookie_dict['email'] == 'Your email'
    assert cookie_dict['project_name'] == 'Your Project'
    assert cookie_dict['project_slug'] == 'your_project'

# Generated at 2022-06-22 14:52:25.898817
# Unit test for function read_user_dict
def test_read_user_dict():
    # current_context = {}
    # CookiecutterDictionary = {'foo':'bar', 'baz':'qux'}
    # key = 'baz'
    # options = {'foo':'bar'}
    print(read_user_dict('baz', {'foo':'bar'}))


# Generated at 2022-06-22 14:52:33.000818
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Test Project',
            'package_name': 'test_project',
            'author': 'Test Author',
            'open_source_license': ['MIT', 'BSD'],
            "email": 'test@example.com'
        }
    }
    cookie_dict = prompt_for_config(context, no_input=True)
    print(cookie_dict)


if __name__ == '__main__':
    test_prompt_for_config()

# Generated at 2022-06-22 14:52:49.797976
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test prompt_for_config
    """
    context = {
        'cookiecutter': {
            'project_name': 'Test Project',
            'repo_name': 'Test-Project',
            'project_slug': 'Test-Project',
            'domain_name': 'example.com',
            'email': 'testing@example.com',
            'github_username': 'examplusername',
            '__meta_install_project_name__': 'Test Project',
            '__meta_install_repo_name__': 'Test-Project',
            '__meta_install_npm_client__': 'npm',
            '__meta_install_npm_package_manager__': 'npm'
        }
    }


# Generated at 2022-06-22 14:52:58.653068
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter

    # Mock user-config.json
    context = cookiecutter('tests/fake-repo-pre/', no_input=True)

    # Read user-config
    cookiecutter_dict = prompt_for_config(context)

    # Check that user-config key/value pairs are correctly
    # loaded from user-config.json
    assert cookiecutter_dict['project_name'] == "Cookiecutter"
    assert cookiecutter_dict['project_short_description'] == "A command-line utility that creates projects from project " \
                                                              "templates, e.g. creating a Python package project from a " \
                                                              "Python package project template."

# Generated at 2022-06-22 14:53:02.592518
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'full_name': 'Firstname Lastname',
        }
    }
    cookiecutter_dict = prompt_for_config(context)
    assert isinstance(cookiecutter_dict, dict)
    assert 'full_name' in cookiecutter_dict.keys()

# Generated at 2022-06-22 14:53:11.683033
# Unit test for function prompt_for_config