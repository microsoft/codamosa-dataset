

# Generated at 2022-06-22 14:43:31.074340
# Unit test for function process_json
def test_process_json():
    """Unit test for process_json function."""
    sample_json1 = "{"
    sample_json2 = "{'a': 1}"
    sample_json3 = '{"a": 1}'
    sample_json4 = '{"a": 1, "b": {"c": 1}}'
    sample_json5 = '{"a": 1, "b": {"c": 1}, "d": [1, 2, 3]}'


# Generated at 2022-06-22 14:43:42.751687
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:43:55.498947
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:43:56.677469
# Unit test for function prompt_for_config
def test_prompt_for_config():
    assert prompt_for_config({'cookiecutter': {'foo': 'default'}}) == {'foo': 'default'}


# Generated at 2022-06-22 14:43:58.953751
# Unit test for function read_user_dict
def test_read_user_dict():

    def foo_func(x):
        return x

    with click.Context(
        foo_func, info_name='foo', parent=None, params=None, auto_envvar_prefix='FOO'
    ):
        read_user_dict('foo', test_dict)
# Unit test function

# Generated at 2022-06-22 14:44:10.597145
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Test regular variable.
    context = {'cookiecutter': {'test_var': 'test'}}
    result = prompt_for_config(context, no_input=True)
    assert result == {'test_var': 'test'}
    result = prompt_for_config(context, no_input=False)
    assert result == {'test_var': 'test'}

    # Test list variable.
    context = {'cookiecutter': {'test_var': ['test1', 'test2']}}
    result = prompt_for_config(context, no_input=True)
    assert result == {'test_var': 'test1'}
    result = prompt_for_config(context, no_input=False)
    assert result == {'test_var': 'test1'}

    # Test dict variable.

# Generated at 2022-06-22 14:44:15.764833
# Unit test for function process_json
def test_process_json():
    user_dict = {'name': 'Varun', 'age': 25}
    user_value = json.dumps(user_dict)
    json_dict = process_json(user_value)
    assert user_dict == json_dict

# Generated at 2022-06-22 14:44:26.157309
# Unit test for function read_user_dict
def test_read_user_dict():
    """Verify that read_user_dict returns the same dictionary after serialization and deserialization."""
    import json
    import click

    def process_json(user_value):
        """Load user-supplied value as a JSON dict."""
        # user_value is a string representing a JSON object
        try:
            user_dict = json.loads(user_value, object_pairs_hook=OrderedDict)
        except Exception:
            # Leave it up to click to ask the user again
            raise click.UsageError("Unable to decode to JSON.")

        if not isinstance(user_dict, dict):
            # Leave it up to click to ask the user again
            raise click.UsageError("Requires JSON dict.")

        return user_dict

    # Test using the same dictionary

# Generated at 2022-06-22 14:44:38.167953
# Unit test for function process_json
def test_process_json():
    user_value = '{"name": "John", "age": 25, "married": true, "divorced": false, "children": ["Ann", "Billy"], "pets": null, "cars": [{"model": "BMW 230", "mpg": 27.5}, {"model": "Ford Edge", "mpg": 24.1}]}'
    expected_dict = {
            "name": "John",
            "age": 25,
            "married": True,
            "divorced": False,
            "children": ["Ann", "Billy"],
            "pets": None,
            "cars": [{"model": "BMW 230", "mpg": 27.5}, {"model": "Ford Edge", "mpg": 24.1}]
        }
    assert process_json(user_value) == expected_dict

# Generated at 2022-06-22 14:44:50.212686
# Unit test for function read_user_dict
def test_read_user_dict():
    question = "Do you like peanut butter?"
    default_value = {
        "name": "test_test",
        "age": 23,
        "address": {
            "city": "Pittsburgh",
            "state": "Pennsylvania"
        }
    }

    # test default
    response = read_user_dict(question, default_value)
    assert response == default_value

    # test default with null
    response = read_user_dict(question, None)
    assert response == None

    # test throw TypeError when input is not a dict
    with pytest.raises(TypeError):
        response = read_user_dict(question, "not a dict")

    # test custom dict
    response = read_user_dict(question, default_value)
    assert response == default_value

# Generated at 2022-06-22 14:44:58.235566
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from tests.sample_repos import test_unrendered_repo

    context = test_unrendered_repo

# Generated at 2022-06-22 14:45:00.434061
# Unit test for function prompt_for_config
def test_prompt_for_config():
    assert prompt_for_config({'cookiecutter': {'test': 'test'}})

# Generated at 2022-06-22 14:45:12.601423
# Unit test for function prompt_for_config
def test_prompt_for_config():
    user_input = [
        'some_repo_name',
        '[master]',
        'y',
        '{ "cookiecutter": {"project_slug": "slugified_project_name", "version": "1.2"}}'
    ]

# Generated at 2022-06-22 14:45:13.876707
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # TODO
    return

# Generated at 2022-06-22 14:45:25.261599
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test function prompt_for_config"""
    import json
    import pytest
    import tempfile
    import os
    from jinja2 import Template

    # Create temporary cookiecutter.json and context files
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(os.path.join(temp_dir, 'cookiecutter.json'), 'w') as json_file:
            json_dict = OrderedDict([
                ('project_name', {'foo': 'bar'}),
                ('project_slug', '{{ cookiecutter.project_name | lower }}'),
                ('project_dir', '{{ cookiecutter.project_name | lower }}'),
                ('author_name', 'Peter Pan'),
                ('copyright', '{{ cookiecutter.author_name }}'),
            ])
            json.dump

# Generated at 2022-06-22 14:45:29.560525
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for prompt_for_config"""
    from cookiecutter.prompt import console_prompt
    from cookiecutter.prompt import is_dict_variable

    prompt_for_config({
        'cookiecutter': {
            'project_name': 'project_name'
        }
    }, True)
    assert True, "test_prompt_for_config() did not crash"


# Generated at 2022-06-22 14:45:41.217645
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the process of prompting the user for template variable values."""

# Generated at 2022-06-22 14:45:43.272571
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context_file_dict = {
    'project_name': 'Cookiecutter',
    'project_slug': 'cookiecutter'
    }
    cookiecutter_dict = prompt_for_config(context_file_dict)
    assert cookiecutter_dict['project_name'] == 'Cookiecutter'
    assert cookiecutter_dict['project_slug'] == 'cookiecutter'


# Generated at 2022-06-22 14:45:47.671436
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter": {
            "project_name": "Cookiecutter cookie",
            "project_slug": "cookie_cookie",
            "repo_name": "{{ cookiecutter.project_name.replace(' ', '_') }}",
            "author_name": "Cookie Monster",
        }
    }
    result = prompt_for_config(context, no_input=True)
    assert result['project_name'] == 'Cookiecutter cookie'
    assert result['repo_name'] == 'Cookiecutter_cookie'
    assert result['author_name'] == 'Cookie Monster'
    assert result['project_slug'] == 'cookie_cookie'

# Generated at 2022-06-22 14:45:59.120214
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""
    import tempfile
    import json
    import shutil
    from cookiecutter.main import cookiecutter

    temp_directory = tempfile.mkdtemp()
    context = cookiecutter('tests/test-example-repo/', no_input=True,
                           output_dir=temp_directory)
    filename = '{}/{}/cookiecutter.json'.format(temp_directory, context['project_slug'])
    with open(filename) as fh:
        file_content = fh.read()
        context['cookiecutter'] = json.loads(file_content, object_pairs_hook=OrderedDict)


# Generated at 2022-06-22 14:46:11.296613
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config()."""

# Generated at 2022-06-22 14:46:21.224643
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 14:46:25.992459
# Unit test for function process_json
def test_process_json():
    # Test correct usage
    assert process_json('{"test": "value"}') == {
        "test": "value"
    }
    assert process_json('{"test": ["value1", "value2"]}') == {
        "test": ["value1", "value2"]
    }

    # Test incorrect usage
    try:
        process_json(None)
        raise RuntimeError
    except click.UsageError:
        pass
    try:
        process_json('')
        raise RuntimeError
    except click.UsageError:
        pass
    try:
        process_json('[1, 2, ]')
        raise RuntimeError
    except click.UsageError:
        pass
    try:
        process_json('{1, 2, }')
        raise RuntimeError
    except click.UsageError:
        pass


# Generated at 2022-06-22 14:46:37.673762
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:46:50.145949
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:46:52.580297
# Unit test for function read_user_choice
def test_read_user_choice():
    assert(read_user_choice("Please select a number", ['1', '2', '3']) == '1')

# Generated at 2022-06-22 14:47:04.226008
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    """

# Generated at 2022-06-22 14:47:14.180369
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:47:25.671117
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'My Test Project',
            'is_open_source': True,
            'project_slug': '{{ cookiecutter.project_name.lower().replace(" ", "-") }}',  # noqa
            'select_license': [
                "BSD License",
                "MIT License",
                "GPLv2",
                "Apache Software License 2.0",
                "Not open source",
            ],
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_slug'] == 'my-test-project'
    assert cookiecutter_dict['select_license'] == "BSD License"

# Generated at 2022-06-22 14:47:36.544900
# Unit test for function prompt_for_config
def test_prompt_for_config():

    context = {
        "cookiecutter": {
            'project_name': "Peanut Butter Cookie",
            'rolled_context':'{{ cookiecutter.project_name.replace(" ", "_") }}',
            'description': "A package to make cookiecutters.",
            'author_name': "Your Name Here",
            'JSON_KEY': { "key": "value" },
            'has_tests': ["y", "n"],
            '_copy_without_render': { "key": "value" },
            '__copy_without_render_but_render_context': { "key": "{{ cookiecutter.project_name }}" },
            'version': '0.1.0',
            'open_source_license': 'MIT',
            'command_line_interface': 'Click'
        },
    }

    cookiecut

# Generated at 2022-06-22 14:48:01.820460
# Unit test for function prompt_for_config
def test_prompt_for_config():
    print("Running tests...", end=' ')
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter',
            'project_slug': 'cookiecutter',
            'year': '2014',
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'description': 'A command-line utility that creates '
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['project_name'] == 'Cookiecutter'

    del context['cookiecutter']['email']
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['email'] == ''


# Generated at 2022-06-22 14:48:03.467369
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "dict"
    default_value = {}
    assert read_user_dict(var_name, default_value) == {}

# Generated at 2022-06-22 14:48:16.371118
# Unit test for function read_user_dict
def test_read_user_dict():
    value = read_user_dict('test', default_value={'a': 1, 'b': 2})
    assert value == {'a': 1, 'b': 2}
    value = '{"a": 1, "b": 2}'
    value = process_json(value)
    assert value == {'a': 1, 'b': 2}

    value = read_user_dict('test', default_value={'a': 1, 'b': 2, 'c': 3})
    assert value == {'a': 1, 'b': 2, 'c': 3}
    value = '{"a": 1, "b": 2, "c": 3}'
    value = process_json(value)
    assert value == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-22 14:48:26.499566
# Unit test for function read_user_dict
def test_read_user_dict():
    # This will be the default
    default_value = OrderedDict(a=1, b='two', c=OrderedDict(d=[1, 2], e=3))
    # This is what the user enters (note: no newlines allowed)
    user_value = r'{"x": "test", "y": {"z": [1, 2, 3]}}'

    # This is what will be returned by the function
    expected_result = OrderedDict(x='test', y=OrderedDict(z=[1, 2, 3]))

    # Call the function
    result = read_user_dict('var_name', default_value)

    # Make sure the result is correct
    assert result == expected_result


# Generated at 2022-06-22 14:48:35.414547
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.utils import parse_context
    context = parse_context(
        {
            'cookiecutter': {
                'name': 'Test',
                'version': {'__type__': 'version', 'value': '0.1.0'},
            }
        }
    )
    context = prompt_for_config(context, no_input=True)
    assert context['cookiecutter']['name'] == 'Test'
    assert context['cookiecutter']['version'] == '0.1.0'



# Generated at 2022-06-22 14:48:45.530510
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:48:56.810892
# Unit test for function render_variable
def test_render_variable():
    """Tests for function `render_variable()`."""
    from unittest import TestCase
    from jinja2 import DictLoader

    # Setup a simple environment to work with
    env = StrictEnvironment(loader=DictLoader({}))

    # Test a simple substitution
    hw = render_variable(env, 'Hello {{ cookiecutter.world }}', {'world': 'world!'})
    assert hw == 'Hello world!', hw

    # Test a simple substitution
    hw = render_variable(
        env, 'Hello {{ cookiecutter.wo }}', {'world': 'world!'},
    )
    assert hw == 'Hello ', hw

    # Test a simple dictionary

# Generated at 2022-06-22 14:49:07.010062
# Unit test for function read_user_dict
def test_read_user_dict():
    """Tests read_user_dict function."""
    test_dict = {'test_key': 'test_value'}
    test_dict_json = '{"test_key": "test_value"}'
    # decode to dict
    result_dict = read_user_dict('test_key', test_dict)
    assert result_dict == test_dict
    # json input with one key
    result_dict = read_user_dict('test_key', test_dict_json)
    assert result_dict == test_dict
    # json input with multiple keys
    test_dict = {'test_key1': 'test_value1', 'test_key2': 'test_value2', 'test_key3': 'test_value3'}

# Generated at 2022-06-22 14:49:21.581466
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import os
    import tempfile

    def _generate_config_file(filename, config_content):
        with open(filename, 'w') as fh:
            json.dump(config_content, fh)

    # Case 1: Prompt user to enter a new configuration

# Generated at 2022-06-22 14:49:24.859172
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context={'cookiecutter':{'name':'tom'}}
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    assert cookiecutter_dict['name'] == 'tom'

# Generated at 2022-06-22 14:49:46.877758
# Unit test for function process_json
def test_process_json():
    """Unit test for function process_json."""

    test_dict = {
        'a': 1,
        'b': 2,
    }

    result = process_json(json.dumps(test_dict))

    assert result == test_dict

test_process_json()

# Generated at 2022-06-22 14:49:55.319547
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test function read_user_dict()."""
    user_dict = read_user_dict(
        "Do you want to use Docker?", {'answer': 'Y', 'version': '2.0.0'}
    )
    assert isinstance(user_dict, dict)
    assert isinstance(user_dict['answer'], str)
    assert isinstance(user_dict['version'], str)
    assert user_dict['answer'] == "Y"
    assert user_dict['version'] == "2.0.0"

# Generated at 2022-06-22 14:49:55.878704
# Unit test for function prompt_for_config
def test_prompt_for_config():
    pass

# Generated at 2022-06-22 14:50:06.761341
# Unit test for function prompt_for_config
def test_prompt_for_config():

    context = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.project_slug }}',
            'project_slug': 'my_project',
            '_template': {
                'foo': '{{ cookiecutter.project_name }}',
                'bar': 'baz',
            },
        }
    }

    user_config_dict = prompt_for_config(context, no_input=True)
    assert user_config_dict == {
        'project_name': 'my_project',
        'project_slug': 'my_project',
        '_template': {
            'foo': '{{ cookiecutter.project_name }}',
            'bar': 'baz'
        }
    }

# Generated at 2022-06-22 14:50:13.759386
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:25.112041
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test'
    default_value = {'test1':'testvalue1'}
    user_input = {'test2':'testvalue2', 'test3':'testvalue3'}

    # Test if the user provides correctly formatted JSON code
    assert(read_user_dict(var_name, default_value) == default_value)
    user_input_json = json.dumps(user_input).replace("'", '"')
    assert(read_user_dict(var_name, default_value) == user_input)

    # Test if the user provides a wrong formatted JSON code
    var_name = 'test'
    default_value = {'test1':'testvalue1'}
    user_input = {'test2':'testvalue2'}

# Generated at 2022-06-22 14:50:36.577413
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test for user_dict"""

    sample_dict = {'foo': 1, 'bar': 2}
    assert read_user_dict('foo', sample_dict) == sample_dict
    assert read_user_dict('foo', {}) == {}
    assert read_user_dict('foo', {'bar': 5}) == {'bar': 5}
    assert read_user_dict('foo', {'foo': 5}) == {'foo': 5}
    assert read_user_dict('foo', {'foo': 5, 'bar': 2}) == {'foo': 5, 'bar': 2}
    assert read_user_dict('foo', {'foo': 'hello'}) == {'foo': 'hello'}

# Generated at 2022-06-22 14:50:41.068310
# Unit test for function read_user_dict
def test_read_user_dict():
    d = read_user_dict("What?", "{}")
    assert d == {}
    d = read_user_dict("What?", '{"foo": "bar"}')
    assert d == {"foo": "bar"}

# Generated at 2022-06-22 14:50:52.075839
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:51:03.573245
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'My Project',
            'package_name': '{{ cookiecutter.project_name.lower().replace(" ", "_") }}',
            'open_source_license': 'MIT',
            'pypi_username': 'audreyr',
            'version': '0.1.0',
            'repo_name': '{{ cookiecutter.project_name.lower().replace(" ", "_") }}',
            'use_pypi_deployment_with_travis': True,
            'command_line_interface': 'click',
            'select_linter': 'flake8',
        },
    }
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict['package_name'] == 'my_project'

# Generated at 2022-06-22 14:51:29.842267
# Unit test for function prompt_for_config
def test_prompt_for_config():
    json_dict = {
        'cookiecutter': {
            'project_name': 'Test project',
            'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
            'use_grid_search': {
                '__default__': True,
                '__prompt__': 'Do you want to use gridsearch?',
            }
        }
    }
    cookiecutter_dict = prompt_for_config(json_dict, no_input=True)
    assert cookiecutter_dict['project_name'] == 'Test project'
    assert cookiecutter_dict['repo_name'] == 'Test_project'
    assert cookiecutter_dict['use_grid_search'] is True


# Generated at 2022-06-22 14:51:34.222154
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('a', {'b':'c'}) == {'b': 'c'}
    assert read_user_dict('a', 10) == 10
    assert read_user_dict('a', 'd') == 'd'
    assert read_user_dict('a', True) == True


# Generated at 2022-06-22 14:51:46.162646
# Unit test for function prompt_for_config
def test_prompt_for_config():
    def test(my_dict, result):
        context = {'cookiecutter': my_dict}
        cookiecutter_dict = prompt_for_config(context, no_input=True)
        assert cookiecutter_dict == result

    # Test regular variable
    test(
        my_dict={'full_name': 'Peter Parker'},
        result={'full_name': 'Peter Parker'}
    )
    # Test regular variable
    test(
        my_dict={'full_name': 'Peter Parker'},
        result={'full_name': 'Peter Parker'}
    )

    # Test default variable

# Generated at 2022-06-22 14:51:54.935221
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:06.441720
# Unit test for function read_user_choice
def test_read_user_choice():
    import sys
    from unittest import mock
    from cookiecutter.prompt import read_user_choice

    sys.argv = ['cookiecutter', '--no-input', 'test-test-test']
    context = {
        'cookiecutter': {
            'test_key': ['Test Value 1', 'Test Value 2']
        }
    }

    with mock.patch('cookiecutter.prompt.click.prompt') as mock_prompt:
        mock_prompt.return_value = '1'
        read_user_choice('test_key', context['cookiecutter']['test_key'])

    assert mock_prompt.call_count == 1
    assert context['cookiecutter']['test_key'] == 'Test Value 1'

# Generated at 2022-06-22 14:52:12.508911
# Unit test for function read_user_dict
def test_read_user_dict():
    question = 'What is the value of foo?'
    default_value = {'bar': 42}
    user_input = "{'bar': 42}"
    user_output = read_user_dict(question, default_value)

    assert user_output == default_value
    assert user_output == json.loads(user_input, object_pairs_hook=OrderedDict)

# Generated at 2022-06-22 14:52:21.778264
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:32.465346
# Unit test for function process_json
def test_process_json():
    """Unit test for function process_json."""
    assert {"a": 1} == process_json("{\"a\": 1}")
    assert {"a": 1} == process_json("    {\"a\": 1}    ")
    assert {"a": 1} == process_json("{\"a\" : 1}")
    assert {"a": 1} == process_json("{\"a\": 1 }")
    assert {"a": 1} == process_json("{\n\"a\": 1}")
    assert {"a": 1} == process_json("{\"a\": 1\n}")
    assert {"a": 1} == process_json("{\r\n\"a\": 1}")
    assert {"a": 1} == process_json("{\"a\": 1\r\n}")


# Generated at 2022-06-22 14:52:44.740047
# Unit test for function render_variable
def test_render_variable():
    """Unit test for function render_variable."""

# Generated at 2022-06-22 14:52:49.106659
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'full_name': 'First Last',
            'email': 'first.last@example.com'
        }
    }

    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict['full_name'] == 'First Last'
    assert cookiecutter_dict['email'] == 'first.last@example.com'

# Generated at 2022-06-22 14:53:07.909606
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Tests prompt_for_config.
    """
    assert prompt_for_config({
        "cookiecutter": {
            "project_name": "My Test Project",
            "author_name": "Joe Tester",
        }
    }, True) == {
        'project_name': 'My Test Project',
        'author_name': 'Joe Tester',
    }

