

# Generated at 2022-06-22 14:43:18.686240
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """ Unit test for function prompt_for_config."""
    import pdb, os
    pdb.set_trace()
    this_dir = os.path.abspath(os.path.dirname(__file__))
    print(this_dir)

# Generated at 2022-06-22 14:43:24.003662
# Unit test for function process_json
def test_process_json():
    """Cases to test the process_json function."""
    assert process_json("{'key': 'value'}") == {'key': 'value'}



# Generated at 2022-06-22 14:43:32.817718
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test for function prompt_for_config."""
    import pytest
    from cookiecutter.config import DEFAULT_CONFIG, get_user_config

    # No input scenario
    context = get_user_config(config_file=DEFAULT_CONFIG, default_config=True)
    context['cookiecutter'] = {}

    # Test simple argument
    with pytest.raises(UndefinedVariableInTemplate):
        context['cookiecutter']['name'] = '{{ non_existent_variable }}'
        prompt_for_config(context, no_input=False)

    # Test default argument
    with pytest.raises(UndefinedVariableInTemplate):
        context['cookiecutter']['name'] = '{{ non_existent_variable }}'
        prompt_for_config(context, no_input=True)

   

# Generated at 2022-06-22 14:43:43.759269
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.config import DEFAULT_CONFIG, DEFAULT_CONTEXT

    context = DEFAULT_CONTEXT.copy()
    context['cookiecutter'] = dict(DEFAULT_CONFIG, **context['cookiecutter'])
    config_dict = prompt_for_config(context, no_input=True)
    assert config_dict['repo_name']
    assert config_dict['project_name']
    assert config_dict['author_name']
    assert config_dict['email']
    assert config_dict['description']
    assert config_dict['domain_name']
    assert config_dict['version']
    assert config_dict['timezone']
    assert config_dict['use_black']

# Generated at 2022-06-22 14:43:56.361062
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter-Pylibrary',
            'repo_name': '{{ cookiecutter.project_name.lower().replace("-", "_") }}',
            'package_name': '{{ cookiecutter.repo_name }}',
            'author_name': 'Mariano Anaya',
            'email': 'mariano@anayaprogramming.com',
            'description': 'A Python library starter project.',
            'domain_name': 'anayaprogramming.com',
            'version': '0.1.0',
            'timezone': 'UTC',
            'open_source_license': 'MIT license',
            '_template': {'name': 'template', 'path': '/some/path'},
        }
    }

# Generated at 2022-06-22 14:44:01.179117
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'var'
    default_value = {'foo': 'bar', 'baz': ['q', 'x'], 'spam': 'ham'}
    print(default_value)

    print('! Test valid input')
    print('@ Input: empty string (default)')
    user_value = ''
    user_dict = read_user_dict(var_name, default_value)
    print('it: {}, is: {}'.format(user_value, user_dict))
    print('@ Input: bar')
    user_value = 'bar'
    user_dict = read_user_dict(var_name, default_value)
    print('it: {}, is: {}'.format(user_value, user_dict))

# Generated at 2022-06-22 14:44:10.966182
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:44:23.238092
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter": {
            "full_name": "Monty Python",
            "email": "monty@python.org",
            "date": "2017-11-9",
            "release_date": "{{ cookiecutter.date }}",
            "version": "0.1.0",
            "select_nums": [1, 2, 3, 4],
            "select_letters": ["a", "b", "c", "d"],
            "select_colors": ["red", "green", "yellow", "blue"],
            "select_shapes": ["circle", "square", "triangle", "star"],
            "project_name": "Django Cmd Test",
            "pypi_username": "montypython",
        }
    }

    cookiecutter_dict = prompt_

# Generated at 2022-06-22 14:44:35.712035
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import prompt_for_config

# Generated at 2022-06-22 14:44:38.706078
# Unit test for function read_user_dict
def test_read_user_dict():
    result = read_user_dict(var_name='My var', default_value={'first': True})
    assert result == {'first': True}

# Generated at 2022-06-22 14:44:55.049084
# Unit test for function process_json
def test_process_json():
    entry = '{"first_name": "{{ cookiecutter.full_name.split()[0] }}"}'
    true = {"first_name": "{{ cookiecutter.full_name.split()[0] }}"}
    assert process_json(entry) == true
    assert process_json(str(true)) == true
    assert process_json(json.dumps(true)) == true
    # Wrong type
    with pytest.raises(click.UsageError):
        process_json(5)
    # Wrong format
    with pytest.raises(click.UsageError):
        process_json(5)
    # Can be empty if default is actually set
    assert process_json('', '') == ''
    with pytest.raises(click.UsageError):
        process_json('', 5)

# Generated at 2022-06-22 14:44:58.916694
# Unit test for function process_json
def test_process_json():
    user_dict = {
        "foo": "bar"
    }
    user_value = json.dumps(user_dict)
    new_dict = process_json(user_value)
    assert new_dict == user_dict


# Unit tests for function render_variable

# Generated at 2022-06-22 14:45:12.082835
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:45:14.569969
# Unit test for function read_user_choice
def test_read_user_choice():
    assert read_user_choice('What would you like to do?', ['foo', 'bar']) == 'foo'

# Generated at 2022-06-22 14:45:25.515474
# Unit test for function read_user_dict
def test_read_user_dict():
    from click.testing import CliRunner
    from click.decorators import _transform_legacy_param

    def process_json_invoked(value, param, ctx):
        return test_read_user_dict.process_json_invoked_value

    # Test values
    test_read_user_dict.process_json_invoked_value = "xxx"
    process_json_invoked_value_is_none = "None"
    process_json_invoked_value_is_not_dict = "NotDict"
    default_value = {"key": "value"}
    value = "{}"
    not_json = "Not json"

    # Test setup
    runner = CliRunner()
    var_name = "var_name"
    input_values = {"input": value}

    # Test for case of process

# Generated at 2022-06-22 14:45:31.175991
# Unit test for function process_json
def test_process_json():
    """Test function process_json."""
    test_dict = {
        'test_str': 'test_str',
        'test_2': 'test_2',
        'test_3': 'test_3',
        'test_4': 'test_4',
        'test_5': 'test_5',
    }
    test_dict_json = json.dumps(test_dict, indent=4)
    assert process_json(test_dict_json) == test_dict

# Generated at 2022-06-22 14:45:35.326608
# Unit test for function process_json
def test_process_json():
    user_dict = {'hello': 'world'}
    user_dict_json = json.dumps(user_dict)

    assert process_json(user_dict_json) == user_dict

# Generated at 2022-06-22 14:45:46.745023
# Unit test for function prompt_for_config
def test_prompt_for_config():
  import pytest

# Generated at 2022-06-22 14:45:51.195591
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test the prompt for config function.
    """
    context = {"cookiecutter": {"test": "hi"}}

    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict == {"test": "hi"}



# Generated at 2022-06-22 14:46:00.910138
# Unit test for function read_user_dict
def test_read_user_dict():
    from click.testing import CliRunner
    from cookiecutter.prompt import read_user_dict
    import sys

    click.testing.CliRunner = CliRunner
    click.testing.CliRunner().get_default_proc_name = "test"
    click.testing.CliRunner()._default_map = None

    # Case 1 : type(default_value) != dict
    def test_read_user_dict_typeerror():
        read_user_dict('key', [])

    # Check that we raise a TypeError
    if sys.version_info[0] == 2:
        import pytest
        with pytest.raises(TypeError):
            test_read_user_dict_typeerror()

    # Case 2 : user_value != default

# Generated at 2022-06-22 14:46:18.185204
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    from cookiecutter.main import cookiecutter
    from tempfile import TemporaryDirectory

    template_dir = cookiecutter(
        "gh:audreyr/cookiecutter-pypackage", no_input=True, output_dir="./tmp"
    )

    with open(f"{template_dir}/cookiecutter.json") as f:
        config = json.load(f, object_pairs_hook=OrderedDict)

    with TemporaryDirectory() as tempdir:
        cookiecutter_dict = prompt_for_config(
            context=dict(
                cookiecutter=config,
            ),
            no_input=False,
        )

# Generated at 2022-06-22 14:46:26.095486
# Unit test for function read_user_dict
def test_read_user_dict():
    # test case : input is string
    assert read_user_dict('dict', 'hello') == 'hello'
    # test case : input is empty
    assert read_user_dict('dict', '') == ''
    # test case : input is dict
    assert read_user_dict('dict', {'key': 'value'}) == {'key': 'value'}
    # test case : isinstance(input, dict) is False
    assert read_user_dict('dict', ['list']) == ['list']
    try:
        # test case : isinstance(input, dict) is True, but input is empty
        read_user_dict('dict', [])
    except ValueError:
        assert True

# Generated at 2022-06-22 14:46:37.673526
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:46:50.152792
# Unit test for function render_variable
def test_render_variable():
    context = {
        'cookiecutter': {
            'first_name': 'Ralph',
            'last_name': 'Bean',
            'data': {
                'devel': {
                    'env': {
                        'a': '{{cookiecutter.first_name}}',
                        'b': '{{cookiecutter.last_name}}',
                        'c': [
                            '{{cookiecutter.first_name}}',
                            '{{cookiecutter.last_name}}',
                        ],
                        'd': {
                            'e': '{{cookiecutter.first_name}}',
                        },
                    },
                }
            },
            'd': [
                '{{cookiecutter.first_name}}',
                '{{cookiecutter.last_name}}',
            ],
        }
    }


# Generated at 2022-06-22 14:46:57.399516
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'name': '{{ cookiecutter.full_name }}',
            'full_name': 'Firstname Lastname',
        }
    }
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict == {'name': 'Firstname Lastname', 'full_name': 'Firstname Lastname'}

# Generated at 2022-06-22 14:46:58.002272
# Unit test for function prompt_for_config
def test_prompt_for_config():
    pass

# Generated at 2022-06-22 14:47:06.599194
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # Read the config file
    with open('tests/test-config.json') as f:
        config_data = json.loads(f.read())

    # Create a test config file
    print('Testing prompt_for_config')

    # Prompt the user
    cookiecutter_dict = prompt_for_config(config_data, no_input=True)

    # Test the results
    assert cookiecutter_dict['test_type'] == 1
    assert cookiecutter_dict['test_key'] == 'value'
    assert cookiecutter_dict['test_bool'] == True
    assert cookiecutter_dict['test_choice'] == 'choice1'
    assert cookiecutter_dict['test_list'] == ['list1', 'list2']

# Generated at 2022-06-22 14:47:15.955354
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from tests.end2end.prompts.fixtures import context
    context = {'cookiecutter': context}
    cookiecutter_dict = prompt_for_config(context, no_input=True)

# Generated at 2022-06-22 14:47:27.568467
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import random, sys, os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from cookiecutter.main import cookiecutter
    r = random.randint(1, 10000000)
    out = cookiecutter(os.path.join(os.path.dirname(__file__), 'tests'))
    assert out['repo_name'] == 'Existing-Repo'
    assert out['project_name'] == 'Existing Repo'
    assert out['project_slug'] == "existing-repo-{}".format(r)
    assert out['year'] == '2019'
    assert out['full_name'] == 'Audrey Roy Greenfeld'
    assert out['email'] == 'audreyr@example.com'

# Generated at 2022-06-22 14:47:38.477758
# Unit test for function render_variable
def test_render_variable():
    """Test function render_variable from module prompt."""
    from cookiecutter.main import cookiecutter
    import os
    import shutil
    import tempfile

    # Create a temporary directory for the cookiecutter template
    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, 'base_sample')
    os.makedirs(template_dir)

    # Create a file to render
    file_name = os.path.join(template_dir, 'test_file')
    with open(file_name, 'w') as f:
        f.write('{{ cookiecutter.project_name }}')

    # Create the cookiecutter.json file
    with open(os.path.join(temp_dir, 'cookiecutter.json'), 'w') as f:
        f

# Generated at 2022-06-22 14:47:53.835317
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """ Test prompt_for_config"""

# Generated at 2022-06-22 14:48:02.828750
# Unit test for function read_user_dict
def test_read_user_dict():
    def process_json(user_value):
        """Load user-supplied value as a JSON dict."""
        return {'a': 1, 'b': 2}

    var_name = 'test_name'
    default_value = {'b': 2, 'a': 1}
    assert read_user_dict(var_name, default_value) == {'a': 1, 'b': 2}
    read_user_dict.value_proc = process_json
    assert read_user_dict(var_name, default_value) == {'a': 1, 'b': 2}
    read_user_dict.value_proc = None



# Generated at 2022-06-22 14:48:15.400920
# Unit test for function process_json
def test_process_json():

    try:
        assert process_json('{"VAR1": "myvar1"}')
    except Exception as e:
        assert 'Unable to decode to JSON' in str(e)

    try:
        assert process_json(1)
    except Exception as e:
        assert 'Unable to decode to JSON' in str(e)

    try:
        assert process_json('1')
    except Exception as e:
        assert 'Unable to decode to JSON' in str(e)

    try:
        assert process_json('VAR1')
    except Exception as e:
        assert 'Unable to decode to JSON' in str(e)

    try:
        assert process_json({"VAR1": "myvar1"})
    except Exception as e:
        assert 'Unable to decode to JSON' in str(e)

# Generated at 2022-06-22 14:48:26.346706
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function
    """

# Generated at 2022-06-22 14:48:35.979308
# Unit test for function read_user_dict
def test_read_user_dict():
    
    # Prompt user for a dictionary
    var_name = 'Project dependencies'
    default_value = {'python': '3.5'}
    print('\nVariable: {}'.format(var_name))
    print('Default value: {}'.format(default_value))

    # Select a JSON dict as the user-supplied value
    print('Please type in a JSON dict below:')
    user_dict = read_user_dict(var_name, default_value)
    
    # Print the JSON dict obtained from user input
    print('\nUser-supplied JSON dict:')
    print(user_dict)

# Generated at 2022-06-22 14:48:46.108056
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:48:57.477798
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config"""

# Generated at 2022-06-22 14:49:02.425631
# Unit test for function prompt_for_config
def test_prompt_for_config():
    prompt_for_config({
        'cookiecutter': {
            'name': 'Jedi',
            'light_side': 'true',
            'favorite_episode': {
                'question': 'What is your favorite Star Wars episode?',
                'choices': ['IV', 'V', 'VI'],
                'default': 'V'
            }
        }
    })

# Generated at 2022-06-22 14:49:11.166674
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:49:15.279901
# Unit test for function read_user_dict
def test_read_user_dict():
    assert isinstance(read_user_dict('foo', {}), dict), 'Did not return a dictionary'
    assert isinstance(read_user_dict('foo', {'blah': 'blah'}), dict), 'Did not return a dictionary'

# Generated at 2022-06-22 14:49:31.890606
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:49:42.430799
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:49:45.803706
# Unit test for function read_user_choice
def test_read_user_choice():
    variable = 'variable'
    options = ['option_a', 'option_b', 'option_c']
    assert read_user_choice(variable, options) in options



# Generated at 2022-06-22 14:49:55.065436
# Unit test for function prompt_for_config
def test_prompt_for_config():
    class LocalArgs:
        no_input = False
        config_file = None
        extra_context = None
        replay = False
        overwrite_if_exists = False
        skip_if_file_exists = False
        output_dir = ''
        default_config = True
        default_context = True
    args = LocalArgs()
    context = {'cookiecutter': {'project_name': 'Peanut Butter Cookie'}}

    cookiecutter_dict = prompt_for_config(context, no_input=args.no_input)

    assert 'project_name' in cookiecutter_dict



# Generated at 2022-06-22 14:50:06.694649
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:13.690895
# Unit test for function render_variable
def test_render_variable():
    """Test function render_variable.

    It's a bit convoluted to set up the required Jinja2 Environment object
    first and then use it to render the variable. However, currently this is
    the only way to check for specific UndefinedErrors.
    """
    from cookiecutter.environment import StrictEnvironment

    # A valid variable definition with a simple variable
    context = {'cookiecutter': {'project_name': 'MyProject'}}
    env = StrictEnvironment(context=context)

    rendered_var = render_variable(env, '{{ cookiecutter.project_name }}', context)
    assert rendered_var == 'MyProject'

    # A valid variable definition with a dictionary value
    context = {'cookiecutter': {'project_type': {'web': 'Web application', 'lib': 'Library'}}}
    env = Strict

# Generated at 2022-06-22 14:50:25.067613
# Unit test for function read_user_dict
def test_read_user_dict():
    
    for value in [2, '1', '3', '4', '5', '6', '7', '8', '9', '0']:
        assert process_json(value) == value
    
    for value in ['true', 'false', 'null', '[]', '{}', '"test"']:
        assert process_json(value) == json.loads(value)

    value = '{"a": "b"}'
    assert process_json(value) == json.loads(value)

    assert process_json("") is None
    try:
        process_json("{")
        assert False
    except click.UsageError:
        pass
    
    try:
        process_json("[]foo")
        assert False
    except click.UsageError:
        pass


# Generated at 2022-06-22 14:50:33.396467
# Unit test for function process_json
def test_process_json():
    dict_with_quotes = {'name': '"Peanut Butter"'}
    dict_without_quotes = {'name': 'Peanut Butter'}

    import json
    json_with_quotes = json.dumps(dict_with_quotes)
    json_without_quotes = json.dumps(dict_without_quotes)

    assert process_json(json_with_quotes) == dict_with_quotes
    assert process_json(json_without_quotes) == dict_without_quotes

# Generated at 2022-06-22 14:50:40.423697
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test for function prompt_for_config
    """
    from tests.test_cookiecutter import project_dir
    from cookiecutter.config import DEFAULT_CONFIG

    DEFAULT_CONFIG_PYPROJ = {
        'cookiecutter': {
            'project_name': '{{ cookiecutter.repo_name }}',
            'repo_name': '{{ cookiecutter.project_name.lower().replace(" ", "-") }}',
        },
    }

    DEFAULT_CONFIG_PYPROJ_LOWER = {
        'cookiecutter': {
            'project_name': 'pyproj',
            'repo_name': 'pyproj',
        },
    }


# Generated at 2022-06-22 14:50:51.611571
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['project_name'] = 'Test Project'
    context['cookiecutter']['project_slug'] = 'test-project'
    context['cookiecutter']['pypi_username'] = 'audreyr'
    context['cookiecutter']['open_source_license'] = 'MIT'
    context['cookiecutter']['author_name'] = 'Audrey Roy'
    context['cookiecutter']['email'] = 'audreyr@example.com'
    context['cookiecutter']['description'] = 'The best project ever.'
    context['cookiecutter']['domain_name'] = 'example.com'

# Generated at 2022-06-22 14:51:06.578135
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test the correctness of prompt for configuration.
    
    This test can be seen as a kind of unit test for the above function.
    """

# Generated at 2022-06-22 14:51:16.379758
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_context = OrderedDict([
        ('name', 'Paul'),
        ('version', '0.1.0'),
        ('description', 'My awesome package'),
        ('long_description', 'The text of my awesome package'),
        ('authors', ['Paul Klerk']),
        ('email', 'paulklerk@example.com'),
        ('license', 'MIT license'),
        ('year', 2018),
        ('project_url', 'https://github.com/paulklerk/awesome-package'),
        ('package_name', 'awesome_package'),
        ('key_name', 'value_name')
    ])

    test_config = prompt_for_config(test_context, True)

    # Check keys
    assert test_config.keys() == test_context.keys()
    # Check values

# Generated at 2022-06-22 14:51:27.626473
# Unit test for function read_user_dict
def test_read_user_dict():
    # TypeError if default_value is not a dictionary
    with pytest.raises(TypeError):
        read_user_dict('', [])

    # Ask the user for a user_dict if the default is not a dict
    with patch.object(click, 'prompt') as mocked_prompt:
        mocked_prompt.return_value = '{"a": "foo", "b": "bar"}'
        # TypeError if wrong format
        with pytest.raises(click.UsageError):
            read_user_dict('', {})
        # Default is returned if empty dict is given
        assert read_user_dict('', {}) == {}

        # Dict is returned if user provides a dict
        assert read_user_dict('', {}) == {'a': 'foo', 'b': 'bar'}


# Unit Tests

# Generated at 2022-06-22 14:51:31.229699
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict('var_name', {'key': 'value'}) == {'key': 'value'}
    # Return the given default w/o any processing
    assert read_user_dict('var_name', {}) == {}


# Generated at 2022-06-22 14:51:43.171481
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:51:49.066401
# Unit test for function read_user_dict
def test_read_user_dict():
    """Test for function read_user_dict"""
    # define expected and actual variables
    expected = '{"test": "test"}'
    actual = read_user_dict("test", {"test": "test"})

    # return read_user_dict as a string
    if type(actual) != str:
        actual = json.dumps(actual)

    # test that actual and expected are equal
    assert expected == actual

# Generated at 2022-06-22 14:51:56.326734
# Unit test for function prompt_for_config
def test_prompt_for_config():
    project_dir = "/home/travis/build/sarathambadas/cookiecutter-pypackage/tests"
    context_file = "{}/test-config/cookiecutter.json".format(project_dir)
    env = StrictEnvironment(context_file=context_file)
    context = env.get_template('cookiecutter.json').render()
    context = json.loads(context)
    cookiecutter_dict = prompt_for_config(context, False)

    # Imports the test files
    import os
    import unittest
    import sys

    sys.path.append(os.path.join(
        os.path.dirname(__file__), 'cookiecutter-pypackage/tests'
    ))

    # Load tests that are in test-config/tests

# Generated at 2022-06-22 14:52:07.511420
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:19.181909
# Unit test for function process_json
def test_process_json():
    assert process_json('{"project-name": "value"}') == {"project-name": "value"}
    assert process_json('{"project_name": "value"}') == {"project_name": "value"}
    assert process_json('{"project_name": "value", "project-name": "value"}') == {"project_name": "value", "project-name": "value"}
    assert process_json('{"project-name": "value", "project_name": "value"}') == {"project-name": "value", "project_name": "value"}
    assert process_json('{"project-name1": "value1", "project-name2": "value2"}') == {"project-name1": "value1", "project-name2": "value2"}

# Generated at 2022-06-22 14:52:31.745399
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'My New Project',
            'project_slug': 'my_new_project',
            'repo_name': 'my_new_project',
            'project_short_description': 'A short description of the project.',
            'pypi_username': 'your_pypi_username',
            'use_pycharm': 'y',
            'command_line_interface': 'click',
            'version': '0.1.0',
            'select_license': 'MIT license',
            'open_source_license': 'MIT license',
            'include_travis': 'y',
        }
    }


# Generated at 2022-06-22 14:52:49.450322
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': ['Spam', 'Eggs'],
            'project_slug': '{{ cookiecutter.project_name.lower() }}',
            'key_dict': {
                'key1': '{{ cookiecutter.project_name }}',
                'key2': ['Value1', 'Value2'],
                'key3': '{{ cookiecutter.key_dict.key2[0] }}',
            },
            'key_list': ['{{ cookiecutter.project_name }}'],
            'private': {
                'private1': ['private_key1'],
                'private2': ['private_key2'],
            }
        }
    }


# Generated at 2022-06-22 14:52:58.213884
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:53:04.314261
# Unit test for function prompt_for_config